// 帽子工厂：仿《帽子工厂》报帽子名的贯口节奏词表，不是原文照录。只吐词，不带话术。
const HATS = [
  '走资派',
  '翻案风',
  '回潮派',
  '复辟狂',
  '右倾保守',
  '业务挂帅',
  '白专道路',
  '唯生产力论',
  '利润挂帅',
  '洋奴哲学',
  '爬行主义',
  '黑线人物',
  '黑秀才',
  '黑干将',
  '黑后台',
  '臭老九',
  '资产阶级知识分子',
  '调和主义',
  '折中主义',
  '投降主义',
  '修正主义',
  '教条主义',
  '经验主义',
  '宗派主义',
  '山头主义',
  '一言堂',
  '个人崇拜',
  '牛鬼蛇神',
  '阶级异己分子',
  '官僚主义',
  '形式主义',
  '本位主义',
  '自由主义',
  '尾巴主义',
  '冒险主义',
  '盲动主义',
  '平均主义',
  '分散主义',
  '极端民主化',
  '流寇思想',
  '军阀主义',
  '享乐主义',
  '消极怠工',
  '算账派',
  '观潮派',
  '秋后算账派',
  '促退派',
  '动摇分子',
  '落后分子',
  '顽固派',
  '蜕化变质分子',
  '叛徒',
  '内奸',
  '工贼',
  '特务',
  '走狗',
  '右派',
  '小资产阶级狂热性',
  '左派幼稚病',
  '大军阀',
  '反党分子',
  '野心家',
  '投降派',
  '大恶霸',
  '不革命',
  '黑手',
  '黑帮凶',
  '民主派',
  '中庸之道',
  '变色龙',
  '反革命分子',
  '孟什维克思想残余',
  '右倾机会主义',
  '左倾冒险分子',
  '反动会道门成员',
  '新军阀主义',
  '反苏维埃势力',
  '资本附庸者',
  '剥削阶级意识继承者',
  '阶级调和论者',
  '资本家走狗',
  '分裂党野心家',
  '革命队伍里的懒汉',
  '假积极的两面人',
  '混日子的老油条',
  '不务正业的二流子',
  '官僚主义小爬虫',
  '见风使舵的政治投机客',
  '阻碍变革的绊脚石',
  '抗拒不改造的死硬分子',
  '装糊涂的蒙混者',
  '阳奉阴违的伪革命者',
  '破坏运动的黑手',
  '运动里的绊脚石',
  '反动教门鼓吹手',
  '地方恶势力代言人',
  '宗族主义复辟者',
  '封建把头继承者',
  '流氓无产者做派',
  '游民阶级思想感染者',
  '无政府主义冒进者',
  '破坏计划的投机分子',
  '私营商贩里的奸商',
  '囤积居奇的吸血鬼',
  '扰乱物价的黑手',
  '腐蚀国营经济的蛀虫',
  '消极怠工的赖虫',
  '破坏劳动维新的刺头',
  '阻碍技术革新的守旧派',
  '吃大锅饭的寄生虫',
  '封建帝王意识残留者',
  '孔孟之道吹鼓手',
  '旧官场意识继承者',
  '门阀观念复活者',
  '等级制度维护者',
  '旧文化的糟粕者',
  '历史垃圾拾荒者'
];

const SHORT_HATS = [
  '叛徒',
  '特务',
  '大军阀',
  '反党分子',
  '野心家',
  '走资派',
  '投降派',
  '修正主义',
  '大恶霸',
  '黑线人物',
  '不革命',
  '黑秀才',
  '黑手',
  '黑帮凶',
  '经验主义',
  '民主派',
  '中庸之道',
  '变色龙'
];

export async function setup(api) {
  const handler = async (args = {}) => {
    const target = String(args && args.target ? args.target : '').trim();
    const raw = String(args && args.mode ? args.mode : '').trim().toLowerCase();
    let mode = 'single';
    if (raw === 'full' || raw.includes('++')) mode = 'full';
    else if (raw.includes('+') || raw === 'short') mode = 'short';
    else if (raw === 'single') mode = 'single';

    let body;
    if (mode === 'full') {
      const i = HATS.indexOf('叛徒');
      body = HATS.slice(i >= 0 ? i : 0).join('、');
    } else if (mode === 'short') {
      body = SHORT_HATS.join('、');
    } else {
      body = HATS[Math.floor(Math.random() * HATS.length)];
    }
    const head = target ? '@' + target + ' ' : '';
    return head + body;
  };

  api.registerTool({
    id: 'hat_factory',
    name: 'hat_factory',
    description:
      '帽子工厂扣帽子。mode=single 发随机一个词（扣帽子），short 发你指定的 18 个词（扣帽子+），full 发从"叛徒"起的全部（扣帽子++）。只返回词表本身，没有头尾话术。target 填被扣帽子的人，可为空。',
    parameters: {
      type: 'object',
      properties: {
        target: { type: 'string', description: '被扣帽子的人：昵称或 QQ 号，可留空' },
        mode: {
          type: 'string',
          enum: ['single', 'short', 'full'],
          description: 'single=一个（扣帽子），short=一小段（扣帽子+），full=叛徒那段全部（扣帽子++）'
        }
      },
      required: ['mode']
    },
    execute: async (_ctx, args) => ({ content: await handler(args), isError: false })
  });
}
