// 角色扮演（LLM 型技能）—— 把本地角色故事文档变成机器人的记忆库。
//
// 为什么放在 skills/ 而不是 plugins/：什么时候该回忆哪段剧情、哪句话是谁说的，
// 只能靠模型理解人话判断；plugins/ 是确定性型（providers/hooks），没有"满足条件
// 必然执行"的时机可言，放那里且只 registerTool 会触发 lintKindPlacement 警告。
//
// 供给分两层（这是省 token 的关键）：
//   prompt.sections + promptSections()  每轮只注入"目录 + 少量开头"（默认合计 1200 字）
//   registerTool 查看角色故事          细节按需取：标题命中取整节，正文命中取段落
// 文档只读不写 —— skills/ 是热重载监听目录，不往里写任何运行时数据。

import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

let cfg = () => ({});

const HERE = path.dirname(fileURLToPath(import.meta.url));
const DEFAULTS = { fileName: '', injectChars: 1200, queryLimit: 4000 };

const clamp = (n, lo, hi) => Math.min(hi, Math.max(lo, Math.round(n)));
const num = (v, dflt) => { const n = Number(v); return Number.isFinite(n) ? n : dflt; };
const norm = (s) => String(s ?? '').toLowerCase().replace(/[\s\u3000]+/g, '');

function conf() {
  const c = cfg() || {};
  return {
    fileName: String(c.fileName ?? DEFAULTS.fileName).trim(),
    injectChars: clamp(num(c.injectChars, DEFAULTS.injectChars), 0, 8000),
    queryLimit: clamp(num(c.queryLimit, DEFAULTS.queryLimit), 200, 20000)
  };
}

// 绝对路径原样用；其余（纯文件名、带分隔符的相对写法）一律相对技能目录。
// resolve 相对路径会落到进程 cwd，那里没有用户的文档。
function resolveFile(name) {
  if (!name) return '';
  return path.isAbsolute(name) ? path.normalize(name) : path.join(HERE, name);
}

// ── 文档读取（3 秒 TTL + mtime/size 校验）────────────────────────────────────
// available() 会在每轮对话里被调用多次，每次都同步读盘没必要；
// 缓存只影响"改了文件多久生效"的延迟（≤3 秒），不影响热重载。
let cache = { at: 0, file: '', mtimeMs: -1, size: -1, text: '' };

function loadStory({ force = false } = {}) {
  const file = resolveFile(conf().fileName);
  if (!file) {
    return { file: '', text: '', error: '未配置角色故事文件：在「技能 → 角色扮演 → 设置」里填路径，或把文档放进本技能目录后只填文件名' };
  }

  let st;
  try { st = fs.statSync(file); } catch { return { file, text: '', error: `找不到角色故事文件：${file}` }; }
  if (!st.isFile()) return { file, text: '', error: `不是普通文件：${file}` };

  const now = Date.now();
  if (!force && cache.file === file && cache.text
    && now - cache.at < 3000 && cache.mtimeMs === st.mtimeMs && cache.size === st.size) {
    return { file, text: cache.text, error: '' };
  }

  let text;
  try { text = fs.readFileSync(file, 'utf8'); }
  catch (error) { return { file, text: '', error: `读取失败（${error?.message ?? error}）：${file}` }; }
  // 记事本 / PowerShell 存的 UTF-8 常带 BOM，读进来必须剥掉，否则首行标题会带个怪字符
  if (text.charCodeAt(0) === 0xFEFF) text = text.slice(1);
  text = text.replace(/\r\n/g, '\n');
  if (!text.trim()) return { file, text: '', error: `文件是空的：${file}` };

  cache = { at: now, file, mtimeMs: st.mtimeMs, size: st.size, text };
  return { file, text, error: '' };
}

// ── 解析：标题 → 章节（章节 = 本标题到下一个同级或更高级标题之间）──────────
function parseDoc(text) {
  const lines = text.split('\n');
  const heads = [];
  for (let i = 0; i < lines.length; i += 1) {
    const m = /^(#{1,6})[ \t]+(.*?)[ \t]*$/.exec(lines[i]);
    if (m) heads.push({ level: m[1].length, title: m[2], line: i });
  }
  const secs = heads.map((h, idx) => {
    let end = lines.length;
    for (let j = idx + 1; j < heads.length; j += 1) {
      if (heads[j].level <= h.level) { end = heads[j].line; break; }
    }
    return { ...h, end, body: lines.slice(h.line + 1, end).join('\n').trim() };
  });
  return { lines, heads, secs };
}

const tocOf = (heads) => heads.map((h) => `${'#'.repeat(h.level)} ${h.title}`);

function cutLines(lines, budget) {
  const out = [];
  let used = 0;
  for (const line of lines) {
    const add = line.length + 1;
    if (used + add > budget && out.length) break;
    out.push(line);
    used += add;
  }
  return { lines: out, used };
}

// 目录优先、剩余额度给正文开头，合计不超过 budget 字。
// 目录让模型知道"库里有哪些故事"（74 条标题才 800 字，比塞一节正文划算），
// 开头给一点原文语感；截断一律按行边界，不在句子中间切。
function digest(text, budget) {
  const { heads, lines } = parseDoc(text);
  const head = cutLines(tocOf(heads), budget);
  const rest = budget - head.used - '【故事开头】'.length - 2;
  const body = rest > 60 ? cutLines(lines, rest).lines : [];
  const parts = [];
  if (head.lines.length) parts.push(head.lines.join('\n'));
  if (body.length) parts.push(`【故事开头】\n${body.join('\n')}`);
  return parts.join('\n\n');
}

function truncate(text, max) {
  if (text.length <= max) return { body: text, more: 0 };
  const cut = text.slice(0, max);
  const nl = cut.lastIndexOf('\n');
  const kept = (nl > max * 0.6 ? cut.slice(0, nl) : cut).replace(/\s+$/, '');
  return { body: `${kept}\n…（已截断，还剩 ${text.length - kept.length} 字，可缩小 keyword 或调大 maxChars）`, more: text.length - kept.length };
}

/** 动态提示词片段：目录 + 少量开头，随文档变化（读取带 3 秒缓存）。 */
export function promptSections() {
  const { text, error } = loadStory();
  if (error || !text) return [];   // 失败原因由 available() 报到 UI，不往提示词里塞半截
  const limit = conf().injectChars;
  if (limit <= 0) return [];
  const body = digest(text, limit);
  if (!body) return [];
  return [{
    id: 'character-story',
    title: '角色故事速写',
    priority: 60,
    content: `【角色故事速写】目录之外的细节，用「查看角色故事」工具按标题/关键词查，查不到不要编。\n${body}`
  }];
}

/** 技能自检：文档缺失/为空时明确报出来，而不是让工具静默变哑巴。 */
export function available() {
  const { error } = loadStory();
  return error ? { ok: false, reason: error } : true;
}

export function setup(api) {
  cfg = api.config;

  const first = loadStory({ force: true });
  if (first.error) api.warn('角色故事暂不可用：%s', first.error);
  else api.log('角色扮演已加载：%s（%d 字）', path.basename(first.file), first.text.length);

  api.registerTool({
    id: 'get_story',
    name: '查看角色故事',
    description: '读取本地角色故事文档（剧情、人物关系、角色语音、喜好与说过的话）。需要回忆自己的往事、某段剧情怎么发展、和谁是什么关系、喜欢/讨厌什么、说过哪句话、要引用角色语音时，先调用本工具再回答；查不到就如实说没有这段故事，不许编剧情。参数 keyword 用目录里的标题词，例如「角色故事·七」「水牢」「关于达达利亚」「喜欢的食物」；不传 keyword 返回目录加开头，便于先看有哪些标题。',
    category: 'knowledge',
    icon: '📖',
    parameters: {
      type: 'object',
      properties: {
        keyword: {
          type: 'string',
          description: '标题或正文里的关键词，例如「水牢」「关于队长」「角色故事·十二」。命中标题时返回该节全文，只命中正文时返回该段及前后各一段'
        },
        maxChars: {
          type: 'number',
          description: '本次最多返回多少字，默认取设置值（4000），可填 200~20000'
        }
      }
    },
    async execute(_ctx, args) {
      try {
        const { text, error } = loadStory();
        if (error) {
          return { content: `${error}。请在「技能 → 角色扮演 → 设置」里检查角色故事文件路径。`, isError: true };
        }

        const c = conf();
        const kwRaw = args?.keyword;
        if (kwRaw !== undefined && kwRaw !== null && typeof kwRaw !== 'string') {
          return { content: 'keyword 必须是文字：传目录里的标题词，例如「水牢」「关于队长」。', isError: true };
        }
        const keyword = String(kwRaw ?? '').trim();

        let maxChars = c.queryLimit;
        if (args?.maxChars !== undefined && args?.maxChars !== null && args?.maxChars !== '') {
          const n = Number(args.maxChars);
          if (!Number.isFinite(n)) return { content: 'maxChars 必须是数字，例如 4000。', isError: true };
          maxChars = clamp(n, 200, 20000);
        }

        const doc = parseDoc(text);

        // 不传 keyword：给目录 + 开头，让模型先看有哪些标题再精确取
        if (!keyword) {
          const body = digest(text, maxChars);
          return {
            content: `${body}\n\n（上面是目录和开头；全文 ${text.length} 字、${doc.heads.length} 个标题。用 keyword 指定标题或关键词可取到某一节，例如 keyword=「角色故事·七」「水牢」「关于达达利亚」。）`
          };
        }

        const kw = norm(keyword);

        // 1) 标题命中：精确匹配优先，其次标题更短（更具体）的，再按出现顺序
        const headHits = doc.secs.filter((s) => norm(s.title).includes(kw));
        if (headHits.length) {
          const exact = headHits.filter((s) => norm(s.title) === kw);
          const pick = (exact.length ? exact : headHits)
            .sort((a, b) => a.title.length - b.title.length || a.line - b.line)[0];
          const raw = `${'#'.repeat(pick.level)} ${pick.title}\n${pick.body}`.trim();
          const out = truncate(raw, maxChars);
          return { content: out.body };
        }

        // 2) 正文命中：按空行分段，取命中段及前后各一段
        for (const s of doc.secs) {
          const paras = s.body.split(/\n[ \t]*\n+/).map((p) => p.trim()).filter(Boolean);
          const idx = paras.findIndex((p) => norm(p).includes(kw));
          if (idx >= 0) {
            const from = Math.max(0, idx - 1);
            const to = Math.min(paras.length, idx + 2);
            const raw = `${'#'.repeat(s.level)} ${s.title}（节选）\n\n${paras.slice(from, to).join('\n\n')}`;
            const out = truncate(raw, maxChars);
            return { content: out.body };
          }
        }

        // 3) 没有：明说没有 + 给全部标题，让模型换个词再查
        const toc = cutLines(tocOf(doc.heads), maxChars).lines.join('\n');
        return {
          content: `故事里没提到「${keyword}」。全部标题如下，换个标题词再查：\n\n${toc}\n\n确实没有就如实说没有这段故事，不要编。`
        };
      } catch (e) {
        return { content: `读取角色故事失败：${e?.message ?? e}`, isError: true };
      }
    }
  });
}
