/**
 * haigui-tang · 海龟汤（群里的水平思考猜谜）
 *
 * 玩法：机器人当主持人，先发「汤面」（一个反常的现象），群友只能问「是不是……」，
 * 主持人只回答 是 / 不是 / 无关 / 部分对；有人推出完整真相就公布「汤底」。
 *
 * 为什么做成"每问一句都要调一次工具"（而不是把汤底丢给模型自己玩）：
 *   ① **防剧透**：汤底只在工具返回里、带明显的"不许发出"标记；模型每轮都被提醒一次，
 *      比"开头给一次、后面靠记忆"稳得多（多轮聊天里模型很容易顺口说漏）。
 *   ② **算接近度**：题库里每题都带关键词，玩家这次的问法和关键词对上了多少，工具能算出来，
 *      命中度高就提示模型"他基本猜对了，可以公布"。
 *   ③ **记进度**：问了几题、给过几条提示、这一局开了多久、这个群出过哪些题（避免重复出同一碗）。
 *
 * 状态按会话存在磁盘上（`<数据目录>/haigui-tang/state.json`），所以重启后同一局还能接着玩；
 * 一局默认挂 3 小时没人问就作废（设置可调），不会半个群永远卡在一碗汤上。
 */
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { PUZZLES } from './puzzles.js';

const DEFAULT_SETTINGS = {
  includeDark: true,        // 是否包含黑暗向（谋杀/自杀/吃人/案件）的汤
  maxStars: 5,              // 出题的难度上限 3~5（3★ 起步，5★ 最难）
  sessionHours: 3,          // 一局最多挂多久（超过没人问就作废）
  hintLimit: 3,             // 一局最多给几条提示
  revealAfterQuestions: 5,  // 少于这个提问数就嚷嚷"公布答案"时，先劝再猜两轮
  showRules: true,          // 开头要不要带玩法说明
  avoidRepeat: true         // 同一个群出过的题不再出（题库出完一轮后自动重置）
};

let cfg = () => ({});
let logger = { log: () => {}, warn: () => {}, error: () => {} };
let stateDir = null;
let stateFile = null;
let state = { chats: {} };

const sleep = () => new Promise((r) => setTimeout(r, 0));   // 占位，保持风格一致
const clamp = (n, lo, hi, dflt) => {
  const v = Number(n);
  if (!Number.isFinite(v)) return dflt;
  return Math.min(hi, Math.max(lo, Math.round(v)));
};
/**
 * 难度：v1.1 起是 3~5 星（3★ 起步、5★ 最难）。
 * 老题库用的是 difficulty 1~3，这里做个兜底换算（1→3★、2→4★、3→5★），
 * 万一以后有人往库里塞老格式的条目也不会崩。
 */
function starsOf(p) {
  const raw = p?.stars ?? (Number(p?.difficulty) ? Number(p.difficulty) + 2 : 3);
  return clamp(raw, 3, 5, 3);
}
/** 5 格显示：★★★☆☆（一眼看出是几星、离满星还差几颗） */
const DIF_STARS = (n) => '★'.repeat(starsOf({ stars: n })) + '☆'.repeat(5 - starsOf({ stars: n }));

function nowText(ts = Date.now()) {
  return new Date(ts).toLocaleString('zh-CN', { hour12: false });
}
function agoText(ts) {
  const s = Math.max(0, Math.round((Date.now() - ts) / 1000));
  if (s < 60) return `${s} 秒`;
  if (s < 3600) return `${Math.round(s / 60)} 分钟`;
  return `${Math.round(s / 3600)} 小时`;
}

// ── 状态（按会话） ──────────────────────────────────────────────────────
function loadState() {
  try {
    const raw = JSON.parse(fs.readFileSync(stateFile, 'utf8'));
    if (raw && typeof raw === 'object' && raw.chats && typeof raw.chats === 'object') state = { chats: raw.chats };
  } catch { /* 首次运行 */ }
}
function saveState() {
  try {
    fs.mkdirSync(path.dirname(stateFile), { recursive: true });
    const tmp = `${stateFile}.${process.pid}.tmp`;
    fs.writeFileSync(tmp, JSON.stringify(state), 'utf8');
    fs.renameSync(tmp, stateFile);
  } catch (e) {
    logger.warn('haigui-tang: 进度写入失败（不影响这一局）：%s', e?.message ?? e);
  }
}
function chatKeyOf(ctx) {
  const k = ctx?.chatKey || ctx?.chatId || ctx?.session?.chatKey;
  return typeof k === 'string' && k.trim() ? k.trim() : 'default';
}
function getChat(key) {
  if (!state.chats[key]) state.chats[key] = { puzzleId: null, at: 0, lastAt: 0, asked: 0, hints: 0, used: [], custom: null };
  const c = state.chats[key];
  if (!Array.isArray(c.used)) c.used = [];
  return c;
}
function isExpired(chat, sessionHours) {
  if (!chat.puzzleId) return true;
  return Date.now() - (chat.lastAt || chat.at || 0) > sessionHours * 3600 * 1000;
}
/** 当前这一局的题（自定义题直接存在会话里，题库题按 id 找）。 */
function currentPuzzle(chat) {
  if (!chat.puzzleId) return null;
  if (chat.custom && chat.custom.id === chat.puzzleId) return chat.custom;
  return PUZZLES.find((p) => p.id === chat.puzzleId) || null;
}

// ── 出题 ────────────────────────────────────────────────────────────────
function pickPuzzle({ chat, includeDark, maxStars, avoidRepeat, wantStars }) {
  let pool = PUZZLES.filter((p) => starsOf(p) <= maxStars);
  if (!includeDark) pool = pool.filter((p) => !(p.tags || []).includes('dark'));
  if (!pool.length) pool = PUZZLES.slice();                        // 过滤太狠就退回全库，别没题可出
  if (wantStars) {
    const exact = pool.filter((p) => starsOf(p) === clamp(wantStars, 3, 5, 3));
    if (exact.length) pool = exact;
  }
  let note = '';
  if (avoidRepeat) {
    let fresh = pool.filter((p) => !chat.used.includes(p.id));
    if (!fresh.length) {
      chat.used = [];                                              // 题库这一轮出完了，重新开始
      fresh = pool;
      note = '（题库这一轮已经出完了，现在从头再来一遍，不会立刻重复刚刚那碗）';
    }
    pool = fresh;
  }
  // 别紧接着重复上一碗：换题时如果库里还有别的，就把上一碗排除掉
  if (chat.lastPicked && pool.length > 1) {
    const filtered = pool.filter((p) => p.id !== chat.lastPicked);
    if (filtered.length) pool = filtered;
  }
  const p = pool[Math.floor(Math.random() * pool.length)] || PUZZLES[0];
  return { puzzle: p, note };
}

// ── 判断"猜得多接近" ────────────────────────────────────────────────────
function hitReport(puzzle, question) {
  const q = String(question || '');
  const keys = Array.isArray(puzzle?.keys) ? puzzle.keys : [];
  const matched = keys.filter((k) => String(k).split('|').some((x) => x && q.includes(x)));
  const ratio = keys.length ? matched.length / keys.length : 0;
  const level = ratio >= 0.6 ? '高' : ratio >= 0.3 ? '中' : '低';
  return { matched, ratio, level, matchedText: matched.map((k) => String(k).split('|')[0]).join('、') };
}

// ── 文案 ────────────────────────────────────────────────────────────────
function soupBlock(puzzle, showRules, note) {
  const head = `🐢 海龟汤（难度 ${DIF_STARS(starsOf(puzzle))}）`;
  const rules = showRules
    ? '规则：只能问我「是不是……」，我只回答 是／不是／无关；有人推出完整真相，我就公布汤底。（要提示说「提示」，要放弃说「公布答案」）'
    : '';
  return [head, puzzle.soup, rules, note].filter(Boolean).join('\n');
}

function hiddenBlock({ puzzle, chat, extra = [] }) {
  const tags = (puzzle.tags || []).map((t) => ({ dark: '黑暗', gore: '血腥', case: '案件', classic: '经典', light: '轻口味' }[t] || t)).join('/');
  const lines = [
    '【以下内容只给你判断用 · 绝对不要发到群里】',
    `本碗：${puzzle.title}`,
    `本碗 id：${puzzle.id}`,
    `难度：${DIF_STARS(starsOf(puzzle))}（${starsOf(puzzle)}/5）${tags ? ` · 类型：${tags}` : ''}`,
    `汤底：${puzzle.answer}`,
    `关键词（玩家提到这些就说明接近了）：${(puzzle.keys || []).join(' / ') || '（无）'}`,
    ...(extra.length ? ['', ...extra] : [])
  ];
  return lines.join('\n');
}

function progressLine(chat) {
  return `进度：已问 ${chat.asked || 0} 题 · 提示用过 ${chat.hints || 0} 次 · 这一局 ${agoText(chat.at)} 前开始`;
}

// ── 技能入口 ────────────────────────────────────────────────────────────
export async function setup(api) {
  cfg = typeof api.config === 'function' ? api.config : () => ({});
  logger = {
    log: typeof api.log === 'function' ? (...a) => api.log(...a) : () => {},
    warn: typeof api.warn === 'function' ? (...a) => api.warn(...a) : () => {},
    error: typeof api.error === 'function' ? (...a) => api.error(...a) : () => {}
  };

  stateDir = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..', '..', 'data', 'haigui-tang');
  try {
    const m = await import('../../src/config.js');
    if (m?.DATA_DIR) stateDir = path.join(m.DATA_DIR, 'haigui-tang');
  } catch { /* 兜底路径 */ }
  stateFile = path.join(stateDir, 'state.json');
  loadState();

  api.registerTool({
    id: 'haigui_tang',
    name: '海龟汤',
    category: 'knowledge',
    icon: '🐢',
    description: '在群里主持一局海龟汤（水平思考猜谜）：给出「汤面」（一个反常的现象），群友只能问「是不是……」，'
      + '你只回答 是／不是／无关／部分对；有人推出完整真相就公布「汤底」。工具里带 112 碗汤，**难度 3★ 起步、最高 5★**：'
      + '3★（36 碗）轻口味或一个弯就通的（打嗝、电梯、末班车、七根蜡烛）、4★（42 碗）经典汤和单起案件（海龟汤、半根火柴、水草、守灵夜、同一张便条）、'
      + '5★（34 碗）连环案（三座城市的三具尸体、每周三的那班车、剪掉的人、第二个报警的人）；每碗都有关键词、分级提示，'
      + '会算"这次猜得多接近"，并记录问了几题/给过几条提示/这个群出过哪几碗（不重复出）。'
      + '用法：action=start 出一碗新的（可选 stars=3~5 指定难度、force=true 换题），action=ask 带上群友原话来判断（**每次回答群友的提问或猜测前都要先调这个**），'
      + 'action=hint 要一条提示，action=reveal 公布汤底（reason=solved|giveup），action=status 看当前这局的进度。'
      + '也支持群友自己出题：action=start 时带 customSoup（汤面）和 customAnswer（汤底）就能主持他们的题。'
      + '用户说「玩海龟汤」「来一碗海龟汤」「出个海龟汤」「猜谜」「汤底是什么」「给个提示」「换一题」时使用。',
    parameters: {
      type: 'object',
      properties: {
        action: {
          type: 'string',
          description: 'start=出一碗新的（群里有人想玩时用）；ask=判断群友这次的提问/猜测（**每次要回答群友前都必须调这个**，把群友原话放在 question 里）；hint=给一条提示；reveal=公布汤底；status=看当前进度。'
        },
        question: { type: 'string', description: 'action=ask 时必填：群友这次说的原话（原封不动抄过来，不要改写）。' },
        stars: { type: 'number', description: '可选，指定难度 3~5 星（3=简单，4=中等，5=难）。用户说「来个简单的」传 3，「要难的/来点狠的」传 5。' },
        force: { type: 'boolean', description: '可选，action=start 时用它换题（用户说「换一题」就传 true，会放弃当前这碗）。' },
        customSoup: { type: 'string', description: '可选，群友自己想出题时，把他们的汤面放这里（配合 customAnswer 一起传）。' },
        customAnswer: { type: 'string', description: '可选，群友自己出题时的汤底。' },
        reason: { type: 'string', description: '可选，action=reveal 用：solved=有人猜出来了，giveup=大家放弃/直接要答案。' }
      }
    },
    async execute(ctx, args = {}) {
      const c = cfg() || {};
      const includeDark = c.includeDark !== false;
      const maxStars = clamp(c.maxStars, 3, 5, 5);
      const sessionHours = clamp(c.sessionHours, 1, 24, 3);
      const hintLimit = clamp(c.hintLimit, 1, 10, 3);
      const revealAfter = clamp(c.revealAfterQuestions, 1, 30, 5);
      const showRules = c.showRules !== false;
      const avoidRepeat = c.avoidRepeat !== false;

      const key = chatKeyOf(ctx);
      const chat = getChat(key);
      const action = String(args?.action || 'start').toLowerCase().trim();
      const active = currentPuzzle(chat);
      const expired = isExpired(chat, sessionHours);

      // ---- 出题 / 换题 ----
      if (action === 'start' || action === 'new' || action === 'next') {
        const force = args?.force === true || action === 'new' || action === 'next';
        if (active && !expired && !force) {
          return {
            content: `${soupBlock(active, showRules, '')}\n\n【仅参考·不要发出】\n`
              + `群里已经有一局在进行（${active.title}），上面这段汤面重复发一次就行，**不要**换题、**不要**把汤底说出来。\n`
              + `${progressLine(chat)}\n`
              + `想换题就说「换一题」（下次调 start 时传 force=true）。\n\n`
              + hiddenBlock({ puzzle: active, chat })
          };
        }

        const custom = String(args?.customSoup || '').trim();
        const customAnswer = String(args?.customAnswer || '').trim();
        let puzzle = null;
        let pickNote = '';
        if (custom && customAnswer) {
          puzzle = {
            id: `custom-${Date.now()}`,
            title: '群友自出的题',
            stars: 3,
            tags: [],
            soup: custom,
            answer: customAnswer,
            keys: [],
            hints: ['（这是群友自出的题，没有内置提示，可以让他们自己提示）']
          };
          pickNote = '这一碗是群友自己出的题（汤面/汤底都是他们给的）。';
        } else {
          const picked = pickPuzzle({ chat, includeDark, maxStars, avoidRepeat, wantStars: args?.stars });
          puzzle = picked.puzzle;
          pickNote = picked.note || '';
        }

        const oldExpired = !!(active && expired);
        const prevAt = chat.lastAt || chat.at || Date.now();   // 上一局最后活动时间（下面更新 chat.at 之前先记下来）
        chat.puzzleId = puzzle.id;
        chat.custom = puzzle.id.startsWith('custom-') ? puzzle : null;
        // ⚠️ 出过的题**当场记账**（不能等 reveal 才记）：
        //    否则连点两次「换一题」会从同一个池子里随机，很可能又抽到刚看过的这碗（实测踩过）。
        if (!chat.used.includes(puzzle.id)) chat.used.push(puzzle.id);
        chat.lastPicked = puzzle.id;
        chat.at = Date.now();
        chat.lastAt = Date.now();
        chat.asked = 0;
        chat.hints = 0;
        saveState();

        const notes = [];
        if (oldExpired) notes.push(`上一碗（${active.title}）挂了 ${agoText(prevAt)}没人问，已经作废，这是新的一碗。`);
        if (pickNote) notes.push(pickNote);
        notes.push(`这个群已经出过 ${chat.used.length} 碗（不重复出，题库出完一轮会自动重置）。`);
        notes.push('回答纪律：**只能**用「是 / 不是 / 无关 / 部分对」这四个说法，一次一句、不解释、不举例、不透露汤底；'
          + '每次群友提问或猜测，先调 action=ask 把他的话原样传进来再回答。');

        return {
          content: `${soupBlock(puzzle, showRules, '')}\n\n【仅参考·不要发出】\n${notes.join('\n')}\n\n`
            + hiddenBlock({ puzzle, chat, extra: [`提示（按顺序给，共 ${(puzzle.hints || []).length} 条）：${(puzzle.hints || []).join(' → ') || '（无）'}`] })
        };
      }

      // ---- 判断群友的提问/猜测 ----
      if (action === 'ask' || action === 'answer' || action === 'judge') {
        const question = String(args?.question || '').trim();
        if (!active || expired) {
          return {
            content: `（这段是判断材料，不要发出去）\n现在这个群没有进行中的海龟汤${active ? `（上一碗「${active.title}」已经凉了）` : ''}。\n`
              + '如果群友是想玩，就调 action=start 出一碗新的；如果他只是在问别的，就正常回答他。'
          };
        }
        if (!question) {
          return { content: '（这段是判断材料，不要发出去）没带群友的原话：请把群友这次说的那句话放到 question 里重新调用。', isError: true };
        }
        chat.asked = (chat.asked || 0) + 1;
        chat.lastAt = Date.now();
        saveState();
        const hit = hitReport(active, question);
        const extra = [
          `群友这次说的：「${question}」`,
          `接近度：${hit.level}${hit.matchedText ? `（提到了 ${hit.matchedText}）` : '（没碰到关键词）'}`,
          progressLine(chat),
          '怎么回：只回一个词 —— 是 / 不是 / 无关 / 部分对。**不要解释、不要复述汤底、不要加表情、不要把他说的和真相拼在一起说。**',
          hit.level === '高'
            ? '如果他这句话的意思已经等于真相 → 先调 action=reveal（reason=solved）拿完整汤底，再公布。'
            : '如果他只是问到某个细节，就如实回答是/不是/无关；问得偏就回「无关」，然后再问他想不想换个方向。',
          `提示还剩 ${Math.max(0, hintLimit - (chat.hints || 0))} 条（群友说「提示」时才给）。`
        ];
        return { content: `（下面全是判断材料，一个字都不要发到群里）\n\n` + hiddenBlock({ puzzle: active, chat, extra }) };
      }

      // ---- 要提示 ----
      if (action === 'hint') {
        if (!active || expired) {
          return { content: '（这段是判断材料，不要发出去）现在没有进行中的海龟汤，先调 action=start 出一碗。' };
        }
        chat.lastAt = Date.now();
        const hints = Array.isArray(active.hints) ? active.hints : [];
        if ((chat.hints || 0) >= Math.min(hintLimit, hints.length)) {
          saveState();
          return {
            content: `💡 提示已经给完了，再猜猜？真猜不出来就说一声「公布答案」。\n\n【仅参考·不要发出】\n`
              + `${progressLine(chat)}；本碗还有 ${Math.max(0, hints.length - (chat.hints || 0))} 条内置提示没给（设置里每局最多给 ${hintLimit} 条）。\n\n`
              + hiddenBlock({ puzzle: active, chat })
          };
        }
        const text = hints[chat.hints || 0] || '（这碗没有内置提示）';
        chat.hints = (chat.hints || 0) + 1;
        saveState();
        return {
          content: `💡 提示：${text}\n\n【仅参考·不要发出】\n这已经是第 ${chat.hints} 条提示（最多 ${Math.min(hintLimit, hints.length)} 条）。`
            + `发出去就这一行，不要补充解释、不要顺着提示把答案说出来。\n${progressLine(chat)}\n\n`
            + hiddenBlock({ puzzle: active, chat })
        };
      }

      // ---- 公布汤底 ----
      if (action === 'reveal' || action === 'giveup') {
        if (!active || expired) {
          return { content: '（这段是判断材料，不要发出去）现在没有进行中的海龟汤，先调 action=start 出一碗。' };
        }
        const reason = String(args?.reason || 'giveup').toLowerCase();
        const usedMs = Date.now() - (chat.at || Date.now());
        const head = reason === 'solved' ? '🎉 猜对了！这碗汤的真相是：' : '🐢 公布汤底：';
        const stat = `（这一局 ${Math.max(1, Math.round(usedMs / 60000))} 分钟 · 问了 ${chat.asked || 0} 题 · 用了 ${chat.hints || 0} 条提示）`;
        const notes = [];
        if (reason !== 'solved' && (chat.asked || 0) < revealAfter) {
          notes.push(`只问了 ${chat.asked || 0} 题（少于设置里的 ${revealAfter} 题）。可以先哄一句「再猜两轮？」，他坚持要就直接把上面那段发出去。`);
        }
        notes.push('这一局到此结束；下次群友说「再来一碗 / 继续」就调 action=start 出新题。');
        // 收尾：记为已出过，清掉当前局
        if (active.id && !chat.used.includes(active.id)) chat.used.push(active.id);
        chat.puzzleId = null;
        chat.custom = null;
        chat.lastAt = Date.now();
        saveState();
        return {
          content: `${head}\n${active.answer}\n${stat}\n\n【仅参考·不要发出】\n本碗：${active.title}\n${notes.join('\n')}\n`
            + `（上面那两行是**已经公布**的内容，可以发；汤底到此为止，不用再补解释。）`
        };
      }

      // ---- 看进度 ----
      if (action === 'status') {
        if (!active || expired) {
          return { content: `（这段是判断材料，不要发出去）这个群现在没有进行中的海龟汤。\n这个群一共出过 ${chat.used.length} 碗。` };
        }
        return {
          content: `（这段是判断材料，不要发出去）\n本碗：${active.title}\n${progressLine(chat)}\n这一局还要 ${Math.max(0, sessionHours * 60 - Math.round((Date.now() - chat.lastAt) / 60000))} 分钟没人问就作废。\n\n`
            + hiddenBlock({ puzzle: active, chat })
        };
      }

      return {
        content: `（这段是判断材料，不要发出去）没听懂 action=「${args?.action}」。可选：start（出题）/ ask（判断群友的话）/ hint（提示）/ reveal（公布汤底）/ status（进度）。`,
        isError: true
      };
    }
  });

  await sleep();
}

/** 题库自检：至少有一碗能出的题。 */
export function available() {
  const usable = PUZZLES.filter((p) => p && p.soup && p.answer);
  if (!usable.length) return { ok: false, reason: '题库是空的' };
  return true;
}
