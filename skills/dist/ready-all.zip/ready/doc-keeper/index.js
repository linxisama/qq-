// 文件柜（doc-keeper）：让机器人自己决定创建 / 读取 / 续写 / 删除 txt、md 文档。
//
// 为什么是 LLM 型（skills/）而不是确定性型（plugins/）：
//   核心代码没法替模型判断「这句话值不值得记、该记到哪个文件、现在该不该读」，
//   这是要理解人话之后才能拍板的事 —— 只能做成注册给模型的工具，由模型自己调用。
//
// 「位置」（v1.2）：
//   文件柜     <数据目录>/documents/ —— 默认位置，分 scope=shared / chat
//   桌面/文档/下载  系统已知文件夹（开关 allowKnownFolders）
//   自定义     设置里 extraLocations 配的「名称=路径」，说名字就认出
//   外部位置是"平铺"的：不区分群、不占文件柜配额，只受单文件大小限制。
//
// 可改的「条件」分两层：
//   硬开关（代码真拦）：autoWrite / writeScope / allowDelete / 位置白名单 / 各类上限
//   软规则（进提示词，模型照做）：只记这些主题 / 绝对不记 / 文件柜里的「规则.txt」
//
// 约定（与项目里其它 Skill 一致）：
//   · 入口必须导出 setup(api)，工具靠 api.registerTool 注册，id 会被加 <skillId>__ 前缀
//   · 工具 execute 返回 { content, isError }；抛错由核心包成「错误：…」回给模型
//   · 写文件用「临时文件 + rename」落盘，避免中途崩掉留下半截文档

import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

// 以技能自身位置为锚点，不用 process.cwd()（打包版里 cwd 未必是应用根目录）
const appRoot = globalThis.__qqAgentRoot
  || path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../..');
const { DATA_DIR } = await import(pathToFileURL(path.join(appRoot, 'src/config.js')).href);
// 技能配置是**扁平**存在 config.skills['doc-keeper'] 里的（不是 .settings 子对象），
// getSkillConfig 会拿 manifest 默认值补齐，避免"读原始配置拿到 undefined"。
const { getSkillConfig } = await import(pathToFileURL(path.join(appRoot, 'src/skills/config.js')).href);

const SKILL_ID = 'doc-keeper';
const DEFAULT_SETTINGS = {
  autoWrite: true,
  writeScope: '两个都行',
  allowTopics: '',
  forbidTopics: '',
  allowKnownFolders: true,
  extraLocations: '',
  useCustomRules: true,
  rulesFile: '规则.txt',
  rulesMaxChars: 1200,
  allowDelete: false,
  maxDocs: 200,
  maxDocKB: 200,
  readChars: 4000,
  docDir: ''
};

const DEFAULT_ROOT = path.join(DATA_DIR, 'documents');
const DOC_EXT = ['.txt', '.md'];
const MAX_WRITE_CHARS = 20000;            // 单次写入上限，超出请分批 append
const MAX_TOTAL_BYTES = 50 * 1024 * 1024; // 文件柜 50MB 上限
const CONTROL_RE = /[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]/;
const CABINET = '文件柜';

const RULES_TEMPLATE = `# 说明：以 # 开头的行是给你看的，机器人会忽略；其它行它都会照做。
# 改完保存即可，下一句话就按新规则走，不用重启、不用改代码。

【什么时候可以记】
- 我让你「记下来 / 保存 / 整理成文件」时，一定要记。
- 你自己判断值得长期留存的（群规、约定、待办、名单、群友的外号）也可以记。
- 纯闲聊、玩笑、一次性的话题不要记。

【写到哪】
- 默认都放文件柜。
- 只有我明确说「写到桌面 / 存到文档 / 放到下载 / 放到某某文件夹」时，才换位置。
- 换位置前先确认目标名字我在设置里开过，不要瞎编目录。

【写什么内容】
- 每条尽量带上日期，方便以后翻。
- 只写结论和事实，不要抄大段聊天记录。
- 群里的东西优先记到群专属区（scope=chat）。

【什么时候可以读】
- 用户提到「上次那个 / 之前记的 / 文件柜里」时，先 list_docs 再看内容。
- 不要每次说话都翻文件。

【绝对不能写】
- 密码、API Key、身份证、住址、电话等隐私。
- 别人的私事和八卦。
`;

const reply = (value, isError = false) => ({
  content: JSON.stringify(value),
  ...(isError ? { isError: true } : {})
});

function clampInt(value, fallback, min, max) {
  const n = Number(value);
  if (!Number.isFinite(n)) return fallback;
  return Math.max(min, Math.min(max, Math.floor(n)));
}

function splitList(raw) {
  return String(raw ?? '')
    .split(/[,，、;；\s]+/)
    .map((s) => s.trim())
    .filter(Boolean)
    .slice(0, 30);
}

/**
 * 解析「名称=路径; 名称2=路径2」。
 * 相对路径按数据目录解析；名字里不许出现路径符号，避免用户写错后变成怪目录名。
 */
function parseLocations(raw) {
  const map = new Map();
  for (const item of String(raw ?? '').split(/[;；\n]+/)) {
    // 中文输入法下很容易打出全角「＝」，直接忽略会让用户以为配好了却没生效
    const line = item.trim().replace(/＝/g, '=');
    if (!line) continue;
    const eq = line.indexOf('=');
    if (eq <= 0) continue;
    const name = line.slice(0, eq).trim().replace(/[\\/:*?"<>|]/g, '').slice(0, 16);
    const dir = line.slice(eq + 1).trim().replace(/^["']|["']$/g, '');
    if (!name || !dir) continue;
    if (name === CABINET || name === '默认' || name === '全部') continue;
    map.set(name, path.isAbsolute(dir) ? path.normalize(dir) : path.resolve(DATA_DIR, dir));
  }
  return [...map.entries()].map(([name, dir]) => ({ name, dir }));
}

/** 把原始配置（可能是 undefined / 字符串数字）规整成稳定形状。 */
function normalize(raw = {}) {
  const c = raw && typeof raw === 'object' ? raw : {};
  const custom = String(c.docDir || '').trim();
  const scopeRaw = String(c.writeScope || '').trim();
  const writeScope = ['群专属', '共用区', '两个都行'].includes(scopeRaw) ? scopeRaw : '两个都行';
  const rulesName = path.basename(String(c.rulesFile || '').trim() || '规则.txt');
  return {
    autoWrite: c.autoWrite !== false,
    allowDelete: c.allowDelete === true,
    allowKnownFolders: c.allowKnownFolders !== false,
    writeScope,
    allowTopics: splitList(c.allowTopics),
    forbidTopics: splitList(c.forbidTopics),
    extraLocations: parseLocations(c.extraLocations),
    useCustomRules: c.useCustomRules !== false,
    rulesName,
    rulesMaxChars: clampInt(c.rulesMaxChars, 1200, 0, 6000),
    maxDocs: clampInt(c.maxDocs, 200, 10, 2000),
    maxDocKB: clampInt(c.maxDocKB, 200, 4, 2048),
    readChars: clampInt(c.readChars, 4000, 200, 12000),
    root: custom ? path.resolve(DATA_DIR, custom) : DEFAULT_ROOT
  };
}

function readSettings() {
  try {
    return normalize(getSkillConfig(SKILL_ID, DEFAULT_SETTINGS));
  } catch {
    return normalize(DEFAULT_SETTINGS);
  }
}

/** 已知文件夹在本机可能不存在（如 OneDrive 重定向），取第一个存在的，否则保留候选让报错更准确。 */
function firstExisting(candidates) {
  for (const dir of candidates) {
    try { if (fs.statSync(dir).isDirectory()) return dir; } catch { /* 不存在就看下一个 */ }
  }
  return candidates[0];
}

/** 当前位置表：文件柜 + 桌面/文档/下载 + 自定义。Map 的插入顺序就是提示词里的展示顺序。 */
function knownLocations(c) {
  const locs = new Map();
  locs.set(CABINET, { dir: c.root, kind: 'cabinet' });
  if (c.allowKnownFolders) {
    const home = os.homedir();
    locs.set('桌面', { dir: firstExisting([path.join(home, 'Desktop'), path.join(home, 'OneDrive', 'Desktop')]), kind: 'external' });
    locs.set('文档', { dir: firstExisting([path.join(home, 'Documents'), path.join(home, 'OneDrive', 'Documents')]), kind: 'external' });
    locs.set('下载', { dir: firstExisting([path.join(home, 'Downloads')]), kind: 'external' });
  }
  for (const { name, dir } of c.extraLocations) locs.set(name, { dir, kind: 'external' });
  return locs;
}

/** 名字 → 位置。不认识的立刻报错并列出可用名字，避免模型瞎猜目录。 */
function locationOf(c, raw) {
  const locs = knownLocations(c);
  const name = String(raw ?? '').trim();
  if (!name || name === '默认' || name === '文件柜') return { ...locs.get(CABINET), name: CABINET };
  const hit = locs.get(name);
  if (!hit) throw new Error(`没有「${name}」这个位置；可用：${[...locs.keys()].join('、')}`);
  return { ...hit, name };
}

/** 文件名规范化：禁路径分隔符、控制字符、隐藏文件，统一补扩展名。 */
function docName(raw) {
  let s = String(raw ?? '').trim().replace(/\s+/g, ' ');
  if (!s) throw new Error('文件名不能为空');
  if (/[\\/:*?"<>|]/.test(s)) throw new Error('文件名不能包含 \\ / : * ? " < > | 这些字符');
  if (CONTROL_RE.test(s)) throw new Error('文件名里有非法控制字符');
  if (s.startsWith('.')) throw new Error('文件名不能以 . 开头');
  // Windows 会悄悄吃掉结尾的点和空格：不先清掉，写进去的名字和读出来的名字就对不上
  s = s.replace(/[.．\s]+$/g, '') || s;
  const ext = path.extname(s).toLowerCase();
  if (!ext) s += '.txt';
  else if (!DOC_EXT.includes(ext)) throw new Error('只支持 .txt 和 .md 文档');
  if (s.length > 80) throw new Error('文件名太长（最多 80 个字符），用简短的名字概括主题');
  return s;
}

/** 拼出文件绝对路径，并再挡一次路径穿越。 */
function fileIn(dir, name) {
  const file = path.join(dir, name);
  const rel = path.relative(dir, file);
  if (!rel || rel.startsWith('..') || path.isAbsolute(rel)) throw new Error('文件名不合法');
  return file;
}

/** 解析 scope 对应的目录。chat 目录名由 chatKey 派生，天然隔离。 */
function scopeDir(root, scope, ctx) {
  if (scope === 'shared') return root;
  if (scope === 'chat') {
    const key = String(ctx?.chatKey || '').replace(/[^a-zA-Z0-9_-]/g, '_').slice(0, 60);
    if (!key) throw new Error('拿不到当前会话，scope 请用 shared');
    return path.join(root, `chat-${key}`);
  }
  throw new Error('scope 只能是 shared 或 chat');
}

/** 只读文件开头若干字节，用于列表预览和关键字搜索（不把整个文件读进内存）。 */
function readHead(file, bytes = 160) {
  const fd = fs.openSync(file, 'r');
  try {
    const buf = Buffer.alloc(bytes);
    const n = fs.readSync(fd, buf, 0, bytes, 0);
    // 按字节截断可能切开一个 3 字节的汉字，尾部会留下 U+FFFD；列表预览里不该出现乱码
    return buf.subarray(0, n).toString('utf8')
      .replace(/\uFFFD+$/g, '')
      .replace(/[\u0000-\u001f\s]+/g, ' ')
      .trim();
  } finally {
    try { fs.closeSync(fd); } catch { /* 关不上也无所谓 */ }
  }
}

/**
 * 收集文件柜里的文档（根目录 + chat-* 子目录）。
 * 规则文件不属于"文档"，列表/写入都要排除，否则模型可能把用户的规则改掉。
 */
function collectCabinet(root, rulesName = '') {
  const out = [];
  const skip = String(rulesName || '').toLowerCase();
  const pushFile = (file, scope) => {
    try {
      const st = fs.statSync(file);
      if (!st.isFile()) return;
      const base = path.basename(file);
      if (skip && base.toLowerCase() === skip) return;
      out.push({ file, scope, name: base, size: st.size, mtime: st.mtimeMs });
    } catch { /* 刚好被删掉就跳过 */ }
  };
  let entries = [];
  try { entries = fs.readdirSync(root, { withFileTypes: true }); } catch { return out; }
  for (const e of entries) {
    const full = path.join(root, e.name);
    if (e.isDirectory()) {
      if (!e.name.startsWith('chat-')) continue;
      let inner = [];
      try { inner = fs.readdirSync(full, { withFileTypes: true }); } catch { continue; }
      for (const f of inner) {
        if (f.isFile() && DOC_EXT.includes(path.extname(f.name).toLowerCase())) pushFile(path.join(full, f.name), 'chat');
      }
      continue;
    }
    if (e.isFile() && DOC_EXT.includes(path.extname(e.name).toLowerCase())) pushFile(full, 'shared');
  }
  return out;
}

/** 外部位置的文档（平铺，不分群）。 */
function collectFlat(dir) {
  const out = [];
  let entries = [];
  try { entries = fs.readdirSync(dir, { withFileTypes: true }); } catch { return out; }
  for (const e of entries) {
    if (!e.isFile() || !DOC_EXT.includes(path.extname(e.name).toLowerCase())) continue;
    const full = path.join(dir, e.name);
    try {
      const st = fs.statSync(full);
      out.push({ file: full, scope: null, name: e.name, size: st.size, mtime: st.mtimeMs });
    } catch { /* 读不到就跳过 */ }
  }
  return out;
}

const isRulesName = (c, name) => String(name).toLowerCase() === String(c.rulesName).toLowerCase();

/** 读「规则.txt」：缺失时自动生成模板；# 开头是注释，其余行拼成规则正文。 */
function loadRules(c) {
  if (!c.useCustomRules || !c.rulesName) return { text: '', path: '' };
  const file = path.join(c.root, c.rulesName);
  try {
    if (!fs.existsSync(file)) {
      fs.mkdirSync(c.root, { recursive: true });
      fs.writeFileSync(file, RULES_TEMPLATE, 'utf8');
      return { text: '', path: file, created: true };
    }
    const raw = fs.readFileSync(file, 'utf8');
    const text = raw
      .split(/\r?\n/)
      .map((line) => line.trim())
      .filter((line) => line && !line.startsWith('#'))
      .join('\n');
    return { text: text.slice(0, c.rulesMaxChars), path: file, truncated: text.length > c.rulesMaxChars };
  } catch {
    return { text: '', path: file, error: true };
  }
}

/** 写作用域：按设置收敛到允许的区。返回实际 scope 与调整说明。 */
function resolveWriteScope(c, requested) {
  const allowed = c.writeScope === '群专属' ? ['chat']
    : c.writeScope === '共用区' ? ['shared']
      : ['shared', 'chat'];
  const want = (requested === 'chat' || requested === 'shared') ? requested
    : (allowed.includes('shared') ? 'shared' : allowed[0]);
  if (allowed.includes(want)) return { scope: want, note: '' };
  return { scope: allowed[0], note: `按当前设置只允许写到 ${allowed[0]}，已自动改用 scope=${allowed[0]}` };
}

export function createService({ settings }) {
  const cfg = () => normalize(settings() || {});

  return {
    /** 列出文档（可按文件名/正文关键字过滤）。 */
    list_docs(ctx, args = {}) {
      const c = cfg();
      const locs = knownLocations(c);
      const want = String(args.location ?? '').trim();
      const all = want === '全部' || want === 'all';
      const picked = all
        ? [...locs.entries()].map(([name, loc]) => ({ ...loc, name }))
        : [locationOf(c, want)];
      const scope = ['all', 'shared', 'chat'].includes(args.scope) ? args.scope : 'all';
      const query = String(args.query ?? '').trim();

      let docs = [];
      for (const loc of picked) {
        const rows = loc.kind === 'cabinet' ? collectCabinet(c.root, c.rulesName) : collectFlat(loc.dir);
        for (const d of rows) {
          // scope 只对文件柜有意义；外部位置是平铺的，不参与筛选
          if (loc.kind === 'cabinet' && scope !== 'all' && d.scope !== scope) continue;
          docs.push({ ...d, location: loc.name });
        }
      }
      if (query) {
        const q = query.toLowerCase();
        docs = docs.filter((d) => {
          if (d.name.toLowerCase().includes(q)) return true;
          try { return readHead(d.file, 4000).toLowerCase().includes(q); } catch { return false; }
        });
      }
      docs.sort((a, b) => b.mtime - a.mtime);
      const total = docs.length;
      const shown = docs.slice(0, 100);
      return reply({
        ok: true,
        location: all ? '全部' : picked[0].name,
        locations: [...locs.keys()],
        scope,
        total,
        root: c.root,
        writeScope: c.writeScope,
        docs: shown.map((d) => ({
          name: d.name,
          location: d.location,
          scope: d.scope,
          size: d.size,
          updatedAt: new Date(d.mtime).toISOString(),
          preview: readHead(d.file, 160).slice(0, 60),
          path: d.file
        })),
        ...(total > shown.length ? { truncated: true, hint: '只列出最近修改的 100 个，可用 query 或 location 缩小范围' } : {})
      });
    },

    /** 分段读取一篇文档。 */
    read_doc(ctx, args = {}) {
      const c = cfg();
      const loc = locationOf(c, args.location);
      const name = docName(args.name);
      const scope = args.scope === 'chat' ? 'chat' : 'shared';
      const dir = loc.kind === 'cabinet' ? scopeDir(c.root, scope, ctx) : loc.dir;
      const file = fileIn(dir, name);
      if (!fs.existsSync(file)) {
        throw new Error(`「${loc.name}」里没有「${name}」，先用 list_docs 看看有哪些文档`);
      }
      const text = fs.readFileSync(file, 'utf8');
      const lines = text.split(/\r?\n/);
      const offset = clampInt(args.offset, 1, 1, Math.max(1, lines.length));
      const limit = clampInt(args.limit, 400, 1, 2000);
      const collected = [];
      let used = 0;
      for (let i = offset - 1; i < lines.length && collected.length < limit; i += 1) {
        const line = lines[i];
        // 首行永远收下（否则超长单行会读不出东西），后续行按 readChars 截断
        if (collected.length && used + line.length + 1 > c.readChars) break;
        const put = collected.length === 0 && line.length > c.readChars ? line.slice(0, c.readChars) : line;
        collected.push(put);
        used += put.length + 1;
      }
      const nextOffset = offset + collected.length;
      const more = nextOffset - 1 < lines.length;
      return reply({
        ok: true,
        name,
        location: loc.name,
        scope: loc.kind === 'cabinet' ? scope : null,
        path: file,
        totalLines: lines.length,
        offset,
        lines: collected.length,
        content: collected.join('\n'),
        ...(more ? { truncated: true, nextOffset, hint: `后面还有内容，用 offset=${nextOffset} 继续读` } : {})
      });
    },

    /** 新建 / 整篇覆盖 / 追加。 */
    write_doc(ctx, args = {}) {
      const c = cfg();
      const loc = locationOf(c, args.location);
      const name = docName(args.name);
      if (loc.kind === 'cabinet' && isRulesName(c, name)) {
        throw new Error(`「${name}」是用户自己的规则文件，不要改它；要调整规则请告诉用户去改`);
      }
      const mode = args.mode === 'append' ? 'append' : 'overwrite';
      const content = typeof args.content === 'string' ? args.content : '';
      if (!content.trim()) throw new Error('content 不能为空');
      if (CONTROL_RE.test(content)) throw new Error('content 里含控制字符，请先清理');
      if ([...content].length > MAX_WRITE_CHARS) throw new Error(`单次最多写 ${MAX_WRITE_CHARS} 字，请分批用 mode=append 追加`);
      const reason = String(args.reason ?? '').trim();
      if (!c.autoWrite && reason !== 'user_request') {
        throw new Error('自主记录已关闭：只有用户明确让你保存时才写文件（reason 填 user_request）');
      }

      const isCabinet = loc.kind === 'cabinet';
      const picked = isCabinet ? resolveWriteScope(c, args.scope) : { scope: null, note: '' };
      const dir = isCabinet ? scopeDir(c.root, picked.scope, ctx) : loc.dir;
      const file = fileIn(dir, name);
      const isNew = !fs.existsSync(file);

      // 配额只管文件柜：外部位置是用户自己的文件夹，不该被这里的上限卡住
      if (isCabinet) {
        const docs = collectCabinet(c.root, c.rulesName);
        if (isNew && docs.length >= c.maxDocs) {
          throw new Error(`文件柜已满（最多 ${c.maxDocs} 个文档），先删掉不用的再写`);
        }
        const totalBytes = docs.reduce((sum, d) => sum + d.size, 0);
        if (totalBytes > MAX_TOTAL_BYTES) throw new Error('文件柜总大小超过 50MB，先清理一些文档');
      }

      const prev = isNew ? '' : fs.readFileSync(file, 'utf8');
      const next = mode === 'append' && prev
        ? `${prev}${prev.endsWith('\n') ? '' : '\n'}${content}`
        : content;
      const size = Buffer.byteLength(next, 'utf8');
      if (size > c.maxDocKB * 1024) {
        throw new Error(`「${name}」会超过单文件上限 ${c.maxDocKB}KB，请精简内容或拆成多个文档`);
      }

      try {
        fs.mkdirSync(dir, { recursive: true });
        const tmp = `${file}.tmp-${process.pid}-${Date.now()}`;
        fs.writeFileSync(tmp, next, 'utf8');
        fs.renameSync(tmp, file);
      } catch (error) {
        throw new Error(`写不进「${loc.name}」（${dir}）：${error?.message ?? error}`);
      }

      return reply({
        ok: true,
        name,
        location: loc.name,
        scope: picked.scope,
        dir,
        path: file,
        mode,
        created: isNew,
        bytes: size,
        chars: [...next].length,
        lines: next.split(/\r?\n/).length,
        message: isNew ? `已在「${loc.name}」新建` : `已写入「${loc.name}」`,
        ...(picked.note ? { scopeNote: picked.note } : {})
      });
    },

    /** 删除（受「允许删除文档」开关管辖，默认关）。 */
    delete_doc(ctx, args = {}) {
      const c = cfg();
      if (!c.allowDelete) throw new Error('删除功能没开：请让用户在「技能」页打开本技能的「允许删除文档」');
      const loc = locationOf(c, args.location);
      const scope = args.scope === 'chat' ? 'chat' : 'shared';
      const name = docName(args.name);
      if (loc.kind === 'cabinet' && isRulesName(c, name)) throw new Error(`「${name}」是用户自己的规则文件，不能删`);
      const dir = loc.kind === 'cabinet' ? scopeDir(c.root, scope, ctx) : loc.dir;
      const file = fileIn(dir, name);
      if (!fs.existsSync(file)) throw new Error(`「${loc.name}」里没有「${name}」，无需删除`);
      fs.unlinkSync(file);
      return reply({ ok: true, name, location: loc.name, scope: loc.kind === 'cabinet' ? scope : null, deleted: true });
    }
  };
}

export function setup(api) {
  const service = createService({ settings: api.config });
  const scopeProp = {
    type: 'string',
    enum: ['shared', 'chat'],
    description: '只对文件柜有效：shared=所有会话共用；chat=只有当前这个群/私聊能看到。外部位置忽略此项。'
  };
  const locationProp = {
    type: 'string',
    description: '放在哪：文件柜（默认，不传就是它）/ 桌面 / 文档 / 下载 / 用户在设置里起的自定义名字。只有用户明确要求换位置时才传。'
  };

  api.registerTool({
    id: 'list_docs',
    name: '列出文件柜里的文档',
    description: '列出某个位置的文档（名字、大小、更新时间、开头预览）。读或写之前先用它确认文件是否存在、叫什么名字；也可以用 query 按文件名或正文关键字查找。',
    category: 'knowledge',
    icon: '🗂️',
    parameters: {
      type: 'object',
      properties: {
        location: { type: 'string', description: '文件柜（默认）/ 桌面 / 文档 / 下载 / 自定义名字 / 全部（所有位置一起看）' },
        scope: { type: 'string', enum: ['all', 'shared', 'chat'], description: '只对文件柜有效：all=全部（默认）；shared=共用区；chat=当前会话区' },
        query: { type: 'string', description: '可选：文件名或正文里的关键字' }
      },
      additionalProperties: false
    },
    execute: service.list_docs
  });

  api.registerTool({
    id: 'read_doc',
    name: '读取文档',
    description: '读取某个位置里的一篇 txt/md 文档。大文件用 offset（起始行，从 1 开始）和 limit（最多读多少行）分段读，返回里会告诉你怎么继续。',
    category: 'knowledge',
    icon: '📄',
    parameters: {
      type: 'object',
      properties: {
        name: { type: 'string', description: '文档名，例如「群规.txt」' },
        location: locationProp,
        scope: scopeProp,
        offset: { type: 'integer', description: '从第几行开始读，默认 1' },
        limit: { type: 'integer', description: '最多读多少行，默认 400' }
      },
      required: ['name'],
      additionalProperties: false
    },
    execute: service.read_doc
  });

  api.registerTool({
    id: 'write_doc',
    name: '写文档（新建/覆盖/追加）',
    description: '把内容写进文档：文件不存在就新建；mode=overwrite 是整篇替换（默认，会覆盖原内容）；mode=append 是追加到末尾。改已有文档前先 read_doc 读全文，避免把旧内容弄丢。默认放文件柜；用户要求放桌面/文档/下载/自定义目录时才传 location。',
    category: 'knowledge',
    icon: '✍️',
    parameters: {
      type: 'object',
      properties: {
        name: { type: 'string', description: '文档名，简短概括主题，例如「待办-本周.txt」' },
        content: { type: 'string', description: '要写入的正文' },
        mode: { type: 'string', enum: ['overwrite', 'append'], description: 'overwrite=整篇替换（默认）；append=追加' },
        location: locationProp,
        scope: scopeProp,
        reason: { type: 'string', description: '为什么写这份文件（一句话）；用户明确要求保存时填 user_request' }
      },
      required: ['name', 'content'],
      additionalProperties: false
    },
    execute: service.write_doc
  });

  api.registerTool({
    id: 'delete_doc',
    name: '删除文档',
    description: '删除某个位置里的一篇文档。只在用户明确要求删除、或确认某个文件已经没用了的时候调用；删除不可恢复。',
    category: 'knowledge',
    icon: '🗑️',
    parameters: {
      type: 'object',
      properties: {
        name: { type: 'string', description: '要删除的文档名' },
        location: locationProp,
        scope: scopeProp
      },
      required: ['name'],
      additionalProperties: false
    },
    execute: service.delete_doc
  });
}

/**
 * 动态提示片段：每一轮把「当前条件」告诉模型。
 * 只读配置与规则文件，不写任何业务状态；规则文件缺失时顺手生成模板（一次性）。
 */
export function promptSections() {
  const c = readSettings();
  const rules = loadRules(c);
  const locs = knownLocations(c);
  const scopeText = c.writeScope === '群专属' ? '只写群专属区（scope=chat）'
    : c.writeScope === '共用区' ? '只写共用区（scope=shared）'
      : '两个区都行，群相关的优先群专属';

  const lines = [
    '以下是文件柜的当前使用条件，必须遵守：',
    `- 自主记录：${c.autoWrite ? '已开启（你觉得值得长期留存就可以记）' : '已关闭（只有用户明确要求时才写，reason 填 user_request）'}`,
    `- 文件柜内的写入位置：${scopeText}`,
    `- 可以放的位置：${[...locs.keys()].map((n) => (n === CABINET ? '文件柜（默认）' : n)).join('、')}。没有用户明确要求时一律放「文件柜」，不要自作主张往桌面或别处写。`,
    `- 删除：${c.allowDelete ? '已允许' : '未允许（只能新建和修改）'}`
  ];
  if (c.allowTopics.length) lines.push(`- 只记这些主题：${c.allowTopics.join('、')}（其它主题不要写文件）`);
  if (c.forbidTopics.length) lines.push(`- 绝对不记：${c.forbidTopics.join('、')}`);
  if (rules.text) {
    lines.push(`- 用户在「${c.rulesName}」里亲手写的规则（优先级最高，与上面冲突时以它为准）：`);
    lines.push(rules.text);
  } else if (c.useCustomRules && rules.created) {
    lines.push(`- 用户还没有写自定义规则（已为他生成「${c.rulesName}」模板），按上面的条件执行即可。`);
  }

  return [{
    id: 'doc-keeper-policy',
    title: '文件柜当前规则',
    priority: 63,
    content: lines.join('\n')
  }];
}
