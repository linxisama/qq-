// 今天吃什么 —— 被 @ 问"今天吃啥"时给一个具体推荐；星期四推荐肯德基疯狂星期四
//
// 为什么做成技能（skills/）而不是插件（plugins/）：
//   · 触发条件由模型判断 —— 群友说"饿了""中午吃啥""随便推荐一个"，措辞千变万化，
//     只有进了模型的 function 列表它才看得见、才会调（插件的能力/hook 不经过模型，模型不知道有这回事）。
//   · 推荐本身是确定性的（从菜库抽一个），所以菜库、去重、口味筛选都写死在代码里，
//     模型只负责"什么时候调"和"怎么说得像人话"，不负责编菜名。
//
// 硬约束（照 src/ 源码执行）：
//   · 导出的钩子是 `hooks['before-context']`，能力是 `providers['tool.guard']`（见 ak-news / arknights-master）。
//   · 钩子里绝不发消息 / 发网络请求，只记状态。
//   · 每次调用都现读 cfg()：改设置不会重新触发 activate。
//   · 失败路径一律 return { content, isError: true }，不让异常冒到上层。
//   · 工具 id 只用 [a-zA-Z0-9_-]（注册后自动变成 eat-what__eat_what）。
//
// 菜单来源（菜单范围只在设置里改）：
//   · 「外卖能点的」= src 含 takeout
//   · 「日常吃的」  = src 含 home / canteen（家常菜、早餐主食、食堂小馆子）
//   默认只推外卖能点到的；聊天只是在"自动"模式下微调（说了"自己做"就往家常走），
//   不会因为一句话就把整份菜单换掉。

import fs from 'node:fs';
import path from 'node:path';
import { DATA_DIR, getConfig } from '../../src/config.js';
import { DISHES_DAILY } from './dishes-daily.js';

const STATE_FILE = path.join(DATA_DIR, 'eat-what-state.json');
const MAX_HISTORY = 60;          // 每个群记最近多少条推荐（去重只需要最近几十条）

// ── 运行时注入（setup 里赋值） ───────────────────────────────────────────
let cfg = () => ({});
let log = () => {};
let warn = () => {};

// ── 小工具 ───────────────────────────────────────────────────────────────

function clampInt(v, lo, hi, dflt) {
  const n = Math.round(Number(v));
  if (!Number.isFinite(n)) return dflt;
  return Math.min(hi, Math.max(lo, n));
}

function pick(arr) {
  return arr[Math.floor(Math.random() * arr.length)];
}

function shuffle(arr) {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i -= 1) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

// ── 菜库 ─────────────────────────────────────────────────────────────────
// 菜分三种来源（src 字段）：
//   takeout 外卖能点到的 —— 这家店送的、有包装、能送到家的那些
//   canteen 食堂/小馆子 —— 单位食堂、楼下小馆能吃上的
//   home    自己弄的 —— 家常菜、早饭主食，做起来简单的那种
// 一条菜可以同时属于多个来源（比如"西红柿炒蛋盖饭"外卖有、食堂有、家里也能做）。
// 字段：
//   n 名字   t 标签   hot 辣（1=微辣 2=中辣 3=爆辣）   spicy 辣但不能标辣度
//   p 均价（元）  meal 适合哪顿（早餐/午餐/晚餐/夜宵/加餐）  group 分类
//   cold 冷食（早餐不推）  healthy 相对清淡   light 是"填肚子"不是正餐

const MEALS = ['早餐', '午餐', '晚餐', '夜宵', '加餐'];

const DISHES = [
  // ── 快餐简餐 ──
  { n: '黄焖鸡米饭', t: ['米饭', '鸡肉'], p: 25, meal: ['午餐', '晚餐'], group: '快餐', src: ['takeout'] },
  { n: '兰州牛肉面', t: ['面食', '牛肉'], p: 20, meal: ['早餐', '午餐', '晚餐', '夜宵'], group: '面食', src: ['takeout'] },
  { n: '麻辣烫', t: ['火锅类', '自由搭配'], hot: 2, p: 28, meal: ['午餐', '晚餐', '夜宵'], group: '快餐', src: ['takeout'] },
  { n: '沙县小吃（拌面＋蒸饺）', t: ['面食', '蒸饺'], p: 18, meal: ['早餐', '午餐', '晚餐', '夜宵'], group: '快餐', src: ['takeout'] },
  { n: '隆江猪脚饭', t: ['米饭', '猪肉'], p: 22, meal: ['午餐', '晚餐'], group: '快餐', src: ['takeout'] },
  { n: '重庆小面', t: ['面食'], hot: 2, p: 16, meal: ['早餐', '午餐', '夜宵'], group: '面食', src: ['takeout'] },
  { n: '螺蛳粉', t: ['粉', '重口'], hot: 1, p: 22, meal: ['午餐', '晚餐', '夜宵'], group: '粉面', src: ['takeout'] },
  { n: '过桥米线', t: ['米线', '汤'], p: 26, meal: ['午餐', '晚餐'], group: '粉面', src: ['takeout'] },
  { n: '酸辣粉', t: ['粉'], hot: 2, p: 14, meal: ['午餐', '夜宵', '加餐'], group: '粉面', src: ['takeout'] },
  { n: '鸡公煲', t: ['鸡肉', '锅物'], hot: 1, p: 45, meal: ['午餐', '晚餐'], group: '锅物', src: ['takeout'] },
  { n: '石锅拌饭', t: ['米饭', '韩式'], hot: 1, p: 28, meal: ['午餐', '晚餐'], group: '韩式', src: ['takeout'] },
  { n: '咖喱鸡排饭', t: ['米饭', '咖喱'], p: 28, meal: ['午餐', '晚餐'], group: '快餐', src: ['takeout'] },
  { n: '盖浇饭', t: ['米饭'], p: 20, meal: ['午餐', '晚餐'], group: '快餐', src: ['takeout'] },
  { n: '兰州炒饭', t: ['米饭'], p: 18, meal: ['午餐', '晚餐', '夜宵'], group: '快餐', src: ['takeout'] },
  { n: '鸡蛋灌饼', t: ['饼', '早餐'], p: 9, meal: ['早餐', '加餐'], group: '早餐', src: ['takeout'] },
  { n: '煎饼果子', t: ['饼', '早餐'], p: 10, meal: ['早餐', '加餐'], group: '早餐', src: ['takeout'] },
  { n: '豆浆油条', t: ['早餐'], p: 8, meal: ['早餐'], group: '早餐', src: ['takeout'] },
  { n: '小笼包配粥', t: ['包子', '早餐'], p: 12, meal: ['早餐'], group: '早餐', src: ['takeout'] },
  { n: '生煎', t: ['包子', '早餐'], p: 15, meal: ['早餐', '午餐', '加餐'], group: '早餐', src: ['takeout'] },
  { n: '肠粉', t: ['早餐', '粤式'], p: 12, meal: ['早餐', '午餐', '加餐'], group: '早餐', src: ['takeout'] },
  { n: '牛肉汤配烧饼', t: ['汤', '饼'], p: 16, meal: ['早餐', '午餐', '晚餐'], group: '早餐', src: ['takeout'] },

  // ── 面食 ──
  { n: '炸酱面', t: ['面食'], p: 20, meal: ['午餐', '晚餐'], group: '面食', src: ['takeout'] },
  { n: '西红柿打卤面', t: ['面食', '家常'], p: 18, meal: ['午餐', '晚餐'], group: '面食', src: ['takeout'] },
  { n: '油泼面', t: ['面食'], hot: 2, p: 22, meal: ['午餐', '晚餐'], group: '面食', src: ['takeout'] },
  { n: '武汉热干面', t: ['面食'], hot: 1, p: 12, meal: ['早餐', '午餐'], group: '面食', src: ['takeout'] },
  { n: '山西刀削面', t: ['面食'], p: 24, meal: ['午餐', '晚餐'], group: '面食', src: ['takeout'] },

  // ── 米饭家常 ──
  { n: '番茄炒蛋盖饭', t: ['米饭', '家常'], p: 18, meal: ['午餐', '晚餐'], group: '家常菜', src: ['takeout'] },
  { n: '红烧肉饭', t: ['米饭', '猪肉'], p: 32, meal: ['午餐', '晚餐'], group: '家常菜', src: ['takeout'] },
  { n: '鱼香肉丝饭', t: ['米饭', '川菜'], hot: 2, p: 24, meal: ['午餐', '晚餐'], group: '家常菜', src: ['takeout'] },
  { n: '回锅肉饭', t: ['米饭', '川菜', '猪肉'], hot: 2, p: 28, meal: ['午餐', '晚餐'], group: '家常菜', src: ['takeout'] },
  { n: '宫保鸡丁饭', t: ['米饭', '鸡肉'], hot: 2, p: 26, meal: ['午餐', '晚餐'], group: '家常菜', src: ['takeout'] },
  { n: '土豆炖牛肉饭', t: ['米饭', '牛肉'], hearty: true, p: 34, meal: ['午餐', '晚餐'], group: '家常菜', src: ['takeout'] },
  { n: '青椒肉丝饭', t: ['米饭'], p: 22, meal: ['午餐', '晚餐'], group: '家常菜', src: ['takeout'] },
  { n: '梅菜扣肉饭', t: ['米饭', '猪肉'], p: 30, meal: ['午餐', '晚餐'], group: '家常菜', src: ['takeout'] },

  // ── 火锅烧烤 ──
  { n: '火锅', t: ['火锅类'], hot: 1, p: 80, meal: ['午餐', '晚餐', '夜宵'], group: '火锅烧烤', src: ['takeout'] },
  { n: '烤鱼', t: ['鱼', '烧烤'], hot: 2, p: 70, meal: ['午餐', '晚餐', '夜宵'], group: '火锅烧烤', src: ['takeout'] },
  { n: '烧烤', t: ['烧烤'], hot: 1, p: 60, meal: ['晚餐', '夜宵'], group: '火锅烧烤', src: ['takeout'] },
  { n: '串串香', t: ['火锅类'], hot: 2, p: 65, meal: ['晚餐', '夜宵'], group: '火锅烧烤', src: ['takeout'] },
  { n: '椰子鸡火锅', t: ['火锅类', '鸡肉', '清淡'], healthy: true, p: 90, meal: ['午餐', '晚餐'], group: '火锅烧烤', src: ['takeout'] },
  { n: '潮汕牛肉火锅', t: ['火锅类', '牛肉', '清淡'], healthy: true, p: 95, meal: ['午餐', '晚餐'], group: '火锅烧烤', src: ['takeout'] },

  // ── 米线粉面小炒 ──
  { n: '炒粉', t: ['粉'], hot: 1, p: 16, meal: ['午餐', '晚餐', '夜宵'], group: '粉面', src: ['takeout'] },
  { n: '炒面', t: ['面食'], p: 16, meal: ['午餐', '晚餐', '夜宵'], group: '面食', src: ['takeout'] },
  { n: '干锅花菜', t: ['蔬菜', '川菜'], hot: 2, p: 28, meal: ['午餐', '晚餐'], group: '家常菜', src: ['takeout'] },

  // ── 日韩 ──
  { n: '拉面', t: ['面食', '日式'], p: 38, meal: ['午餐', '晚餐', '夜宵'], group: '日韩', src: ['takeout'] },
  { n: '日式咖喱饭', t: ['米饭', '日式', '咖喱'], p: 35, meal: ['午餐', '晚餐'], group: '日韩', src: ['takeout'] },
  { n: '寿司', t: ['米饭', '日式', '冷食'], cold: true, p: 45, meal: ['午餐', '晚餐', '加餐'], group: '日韩', src: ['takeout'] },
  { n: '部队锅', t: ['锅物', '韩式'], hot: 1, p: 60, meal: ['午餐', '晚餐'], group: '韩式', src: ['takeout'] },
  { n: '韩式炸鸡', t: ['鸡肉', '韩式'], hot: 1, p: 55, meal: ['晚餐', '夜宵'], group: '韩式', src: ['takeout'] },

  // ── 西式 ──
  { n: '汉堡套餐', t: ['西式'], p: 30, meal: ['午餐', '晚餐', '夜宵', '加餐'], group: '西式', src: ['takeout'] },
  { n: '披萨', t: ['西式'], p: 55, meal: ['午餐', '晚餐', '夜宵'], group: '西式', src: ['takeout'] },
  { n: '意大利面', t: ['西式', '面食'], p: 35, meal: ['午餐', '晚餐'], group: '西式', src: ['takeout'] },
  { n: '三明治加咖啡', t: ['西式', '早餐'], p: 25, meal: ['早餐', '加餐'], group: '西式', src: ['takeout'] },
  { n: '炸鸡＋可乐', t: ['鸡肉', '西式'], p: 35, meal: ['午餐', '晚餐', '夜宵', '加餐'], group: '西式', src: ['takeout'] },

  // ── 清淡 / 健康 ──
  { n: '鸡胸肉沙拉', t: ['沙拉', '鸡肉', '清淡'], healthy: true, light: true, p: 28, meal: ['午餐', '晚餐', '加餐'], group: '健康', src: ['takeout'] },
  { n: '杂粮饭＋清蒸鱼', t: ['米饭', '鱼', '清淡'], healthy: true, p: 32, meal: ['午餐', '晚餐'], group: '健康', src: ['takeout'] },
  { n: '白粥配小菜', t: ['早餐', '清淡'], healthy: true, light: true, p: 10, meal: ['早餐', '夜宵'], group: '健康', src: ['takeout'] },
  { n: '轻食三明治', t: ['西式', '清淡'], healthy: true, light: true, p: 25, meal: ['早餐', '午餐', '加餐'], group: '健康', src: ['takeout'] },
  { n: '牛肉汤饭', t: ['米饭', '牛肉', '汤'], p: 26, meal: ['午餐', '晚餐'], group: '家常菜', src: ['takeout'] },

  // ── 宵夜小食 ──
  { n: '小龙虾', t: ['河鲜'], hot: 2, p: 90, meal: ['晚餐', '夜宵'], group: '宵夜', src: ['takeout'] },
  { n: '卤味拼盘', t: ['卤味'], hot: 1, p: 35, meal: ['晚餐', '夜宵', '加餐'], group: '宵夜', src: ['takeout'] },
  { n: '烤冷面', t: ['面食', '小吃'], p: 10, meal: ['夜宵', '加餐'], group: '宵夜', src: ['takeout'] },
  { n: '关东煮', t: ['小吃', '日式'], p: 20, meal: ['夜宵', '加餐'], group: '宵夜', src: ['takeout'] },
  { n: '章鱼小丸子', t: ['小吃', '日式'], p: 15, meal: ['夜宵', '加餐'], group: '宵夜', src: ['takeout'] },
  { n: '肉夹馍', t: ['饼', '小吃'], p: 12, meal: ['早餐', '午餐', '夜宵', '加餐'], group: '小吃', src: ['takeout'] },
  { n: '凉皮', t: ['粉', '冷食'], hot: 1, cold: true, p: 12, meal: ['午餐', '晚餐', '加餐'], group: '小吃', src: ['takeout'] },
  { n: '包子配豆浆', t: ['包子', '早餐'], p: 10, meal: ['早餐'], group: '早餐', src: ['takeout'] },
  { n: '炸串', t: ['小吃', '油炸'], hot: 1, p: 25, meal: ['夜宵', '加餐'], group: '宵夜', src: ['takeout'] },
  { n: '螺蛳粉加鸭脚', t: ['粉', '重口'], hot: 1, p: 28, meal: ['午餐', '晚餐', '夜宵'], group: '粉面', src: ['takeout'] },

  // ── 甜甜的（下午茶/加餐） ──
  { n: '奶茶配小蛋糕', t: ['甜品'], light: true, p: 25, meal: ['加餐'], group: '甜品', src: ['takeout'] },
  { n: '冰淇淋', t: ['甜品', '冷食'], cold: true, light: true, p: 15, meal: ['加餐'], group: '甜品', src: ['takeout'] },
  { n: '糖水', t: ['甜品', '粤式'], light: true, p: 16, meal: ['加餐', '夜宵'], group: '甜品', src: ['takeout'] }
];

// 家常菜 / 早餐主食 / 食堂那一类，单独一个文件（见 dishes-daily.js）
export const DISHES_ALL = [...DISHES, ...DISHES_DAILY];

// 星期四的肯德基菜单池：让每周的"疯狂星期四"不总是同一句
const KFC_PICKS = [
  '吮指原味鸡',
  '香辣鸡腿堡',
  '黄金脆皮鸡',
  '烤翅桶',
  '黄金鸡块',
  '沃帕·汉堡套餐',
  '香骨鸡',
  '蛋挞一打',
  '圣诞半鸡（季节款）',
  '十翅一桶',
  '薯条＋可乐套餐',
  '绝味鸭脖风味鸡翅（联名款）'
];

// ── 口味识别（从群聊里读"不吃辣""我素食"这类话） ────────────────────

const NO_SPICY_RE = /(不吃辣|不能吃辣|吃不了辣|吃不来辣|怕辣|讨厌辣|戒辣|微辣都不行|一点点辣都不|别太辣|少辣|不辣)/;
const VEG_RE = /(我吃素|我是素食|吃素|素食主义|只吃素|不吃肉|不沾荤|戒肉)/;
const SEAFOOD_RE = /(不吃海鲜|海鲜过敏|海鲜不行|不能吃海鲜|对虾过敏|贝类过敏|虾蟹过敏|不吃虾|不吃蟹|不吃鱼)/;
const BEEF_RE = /(不吃牛|牛肉过敏|不吃牛肉)/;
const PORK_RE = /(不吃猪|猪肉过敏|不吃猪肉|清真|不吃大肉)/;
// 明确点名的忌口：直接按菜名拉黑（不用 /g 的正则，避免循环里共享 lastIndex 的坑）
const DISH_BAN_RE = /(?:不吃|受不了|不想吃|讨厌|吃不了|别推|别给我)\s*([\u4e00-\u9fa5A-Za-z0-9＋+]{2,10})/g;
const MEAT_TAGS = ['鸡肉', '猪肉', '牛肉', '鱼', '河鲜', '卤味', '烧烤'];
const SEAFOOD_TAGS = ['鱼', '河鲜'];
const PORK_TAGS = ['猪肉'];
const BEEF_TAGS = ['牛肉'];

/** 把一句话解析成忌口集合（同一个群的所有人忌口取并集：宁可少推一个，也别推错人）。 */
function parseConstraints(text, into = {}) {
  const s = String(text ?? '');
  const out = { ...into };
  if (NO_SPICY_RE.test(s)) out.noSpicy = true;
  if (VEG_RE.test(s)) out.veg = true;
  if (SEAFOOD_RE.test(s)) out.noSeafood = true;
  if (BEEF_RE.test(s)) out.noBeef = true;
  if (PORK_RE.test(s)) out.noPork = true;
  // 「不吃X」里点名的菜：X 要是菜库里存在的词才算数，否则当闲聊丢掉
  const banned = new Set(Array.isArray(out.banned) ? out.banned : []);
  DISH_BAN_RE.lastIndex = 0;
  let m;
  while ((m = DISH_BAN_RE.exec(s)) !== null) {
    const word = String(m[1] || '').replace(/(吧|了|啊|呀|呗|的|啦|哦|吗|都行)/g, '');
    if (word.length < 2) continue;
    const hit = DISHES_ALL.find((d) => d.n.includes(word));
    if (hit) banned.add(hit.n);
  }
  DISH_BAN_RE.lastIndex = 0;
  if (banned.size) out.banned = [...banned];
  return out;
}

function dishAllowed(d, cons) {
  if (!cons) return true;
  if (Array.isArray(cons.banned) && cons.banned.some((b) => d.n.includes(b) || String(b).includes(d.n))) return false;
  const tags = d.t || [];
  const name = String(d.n || '');
  if (cons.noSpicy && (d.hot || 0) > 0) return false;
  // 素食：既看标签，也看菜名里的肉字（"章鱼小丸子""牛肉汤饭"这类标签写得笼统的也会被拦下）
  if (cons.veg && (tags.some((x) => MEAT_TAGS.includes(x)) || /肉|鸡|鸭|猪|牛|羊|鱼|虾|蟹|丸|肠|排|骨|翅|卤/.test(name))) return false;
  if (cons.noSeafood && (tags.some((x) => SEAFOOD_TAGS.includes(x)) || /鱼|虾|蟹|贝|螺|章鱼|鱿鱼|海参/.test(name))) return false;
  if (cons.noPork && (tags.some((x) => PORK_TAGS.includes(x)) || /猪|猪脚|扣肉|排骨/.test(name))) return false;
  if (cons.noBeef && (tags.some((x) => BEEF_TAGS.includes(x)) || /牛/.test(name))) return false;
  return true;
}

// ── 时间 / 场景判断 ──────────────────────────────────────────────────────

/** 用本地时间判断现在算哪一顿。夜宵从 22 点开始算到凌晨 4 点。 */
function mealOfNow(now = new Date()) {
  const h = now.getHours();
  if (h >= 4 && h < 10) return '早餐';
  if (h >= 10 && h < 14) return '午餐';
  if (h >= 14 && h < 17) return '加餐';
  if (h >= 17 && h < 22) return '晚餐';
  return '夜宵';
}

function mealFromWord(word) {
  const w = String(word ?? '');
  if (!w) return '';
  if (/早餐|早饭|早上/.test(w)) return '早餐';
  if (/午餐|午饭|中午|中饭/.test(w)) return '午餐';
  if (/晚餐|晚饭|晚上吃|晚上吃啥|晚饭吃/.test(w)) return '晚餐';
  if (/夜宵|宵夜|半夜/.test(w)) return '夜宵';
  if (/下午茶|加餐|零食|嘴馋/.test(w)) return '加餐';
  return '';
}

function weekdayOf(now = new Date()) {
  return now.getDay(); // 0 日 1 一 ... 4 四
}

// ── 菜单范围：外卖能点的 / 日常吃的 ────────────────────────────────────
//
// menuScope 只在设置里改（用户选的：默认外卖，设置里可改）：
//   外卖能点的      → 只要 src 含 takeout
//   日常吃的        → 只要 src 含 home / canteen
//   两种都要        → 全都要
// 另外有一个"只限这一次"的口子：群友这句话里明说了"自己做/点外卖"，这一次按他说的来，
// 但不改设置、不留记忆 —— 用户要的是"设置里定调"，聊天不该私自把菜单换掉。

const SCOPE_LABELS = {
  takeout: '外卖能点的',
  daily: '日常吃的',
  both: '外卖＋日常都要'
};

function scopeOf(c) {
  const raw = String(c?.menuScope ?? '');
  if (raw.includes('日常') && !raw.includes('外卖')) return 'daily';
  if (raw.includes('都') || raw.includes('全') || raw.includes('不限')) return 'both';
  return 'takeout'; // 默认：外卖能点的
}

/** 从一句话里看出这次想吃哪一类；看不出来返回 ''（= 按设置）。 */
function modeFromText(text) {
  const s = String(text ?? '');
  if (!s) return '';
  if (/(自己做|自己做菜|自己做点|下厨|在家做|家里做|做饭|开火|买菜|随便对付|凑合一口)/.test(s)) return 'home';
  if (/(外卖|点个外卖|点餐|叫个外卖|配送|美团|饿了么)/.test(s)) return 'takeout';
  if (/(食堂|小馆|楼下吃|单位吃|公司吃|店里吃|堂食)/.test(s)) return 'canteen';
  return '';
}

/** srcs：这次可用的来源集合（home/canteen/takeout）。 */
function menuFilter(srcs) {
  const set = new Set(srcs);
  return (d) => Array.isArray(d.src) && d.src.some((s) => set.has(s));
}

/** 设置 + 这次的口头诉求 → 这次可用的来源集合 + 给回复用的一句说明。 */
function resolveSources(c, wanted) {
  const scope = scopeOf(c);
  let srcs;
  if (scope === 'daily') srcs = ['home', 'canteen'];
  else if (scope === 'both') srcs = ['takeout', 'home', 'canteen'];
  else srcs = ['takeout'];

  let note = '';
  if (scope === 'both') {
    // 两种都要时，口头说一句就收窄到那一种
    if (wanted === 'home') { srcs = ['home']; note = '对方说了自己做，这次只推家常的'; }
    else if (wanted === 'takeout') { srcs = ['takeout']; note = '对方说了点外卖，这次只推外卖能点的'; }
    else if (wanted === 'canteen') { srcs = ['canteen']; note = '对方说去食堂/小馆，这次只推那类'; }
  }
  // 菜单范围是设置定的：外卖模式下即使说了"自己做"也不改菜单，只当作闲聊
  if (scope === 'takeout' && wanted === 'home') {
    note = '（对方提到自己做，但设置里只推外卖，按设置来）';
  }
  return { scope, srcs, note };
}

// ── 状态（去重 + 口味记忆） ─────────────────────────────────────────────

let state = { chats: {} };

function loadState() {
  try {
    const raw = JSON.parse(fs.readFileSync(STATE_FILE, 'utf8'));
    if (raw && typeof raw === 'object' && raw.chats && typeof raw.chats === 'object') {
      state = { chats: raw.chats };
    }
  } catch {
    // 没有 / 坏了：用默认值，下次保存重建
  }
}

function saveState() {
  try {
    fs.mkdirSync(path.dirname(STATE_FILE), { recursive: true });
    fs.writeFileSync(STATE_FILE, JSON.stringify(state, null, 2), 'utf8');
  } catch (error) {
    warn(`保存「今天吃什么」状态失败（不影响本次推荐）：${error?.message ?? error}`);
  }
}

function chatState(chatKey) {
  const key = String(chatKey || 'global');
  if (!state.chats[key] || typeof state.chats[key] !== 'object') {
    state.chats[key] = { history: [], cons: {}, updatedAt: 0 };
  }
  const s = state.chats[key];
  if (!Array.isArray(s.history)) s.history = [];
  if (!s.cons || typeof s.cons !== 'object') s.cons = {};
  return s;
}

// ── 推荐 ─────────────────────────────────────────────────────────────────

function fmtKfc(now = new Date()) {
  const choice = pick(KFC_PICKS);
  return {
    name: '肯德基疯狂星期四',
    reason: `今天星期四！疯狂星期四，${choice}走起（记得看看今天的主推，兴许更划算）`,
    kfc: true,
    price: 40,
    meal: mealOfNow(now)
  };
}

/**
 * 挑一个菜。
 * @param {{ chatKey?: string, meal?: string, budget?: number, want?: string }} spec
 */
function recommend(spec = {}) {
  const c = cfg() || {};
  const now = new Date();
  const cs = chatState(spec.chatKey);
  const cons = c.includeTaste === true ? (cs.cons || {}) : {};

  // 星期四：先给疯狂星期四（可关）。spec.now 只给测试用，生产始终是当前时间
  const dayRef = spec.now instanceof Date ? spec.now : now;
  if (c.kfcThursday !== false && weekdayOf(dayRef) === 4 && !spec.noKfc) {
    const k = fmtKfc(dayRef);
    remember(cs, k.name, clampInt(c.avoidRepeatRounds, 0, 50, 8));
    return { ...k, weekday: '星期四' };
  }

  const meal = spec.meal || mealOfNow(now);
  const budget = Number(spec.budget) > 0 ? Number(spec.budget) : 0;
  const been = new Set((cs.history || []).map((h) => String(h.name)));

  // 菜单范围：优先用调用方给的（tool 已按设置+口头诉求算好），否则按设置自己算
  const resolved = Array.isArray(spec.srcs) ? { scope: scopeOf(c), srcs: spec.srcs, note: '' } : resolveSources(c, spec.want);
  const inMenu = menuFilter(resolved.srcs);

  // 逐层放宽：宁可给一个"不太合适但能吃"的，也不要回"想不出来"
  // 硬条件（任何一层都不许破）：① 菜单范围（设置说只推外卖就只推外卖）
  // ② 忌口（说了不吃辣就不许推火锅）—— 破了这两条，这条回复就是负分。
  // 软条件（可以放宽）：时段是否对口、早餐是否推冷的。
  const filters = [
    (d) => inMenu(d) && (d.meal || []).includes(meal) && dishAllowed(d, cons) && !(meal === '早餐' && d.cold),
    (d) => inMenu(d) && (d.meal || []).includes(meal) && dishAllowed(d, cons),
    (d) => inMenu(d) && dishAllowed(d, cons)
  ];

  for (let round = 0; round < filters.length; round += 1) {
    const pass = filters[round];
    let pool = DISHES_ALL.filter(pass);
    if (budget > 0) {
      const cheap = pool.filter((d) => Number(d.p) <= budget);
      if (cheap.length) pool = cheap;
    }
    if (!pool.length) continue;

    const keepN = clampInt(c.avoidRepeatRounds, 0, 50, 8);
    const fresh = pool.filter((d) => !been.has(d.n));
    const source = fresh.length ? fresh : pool;   // 全推过了就允许重复（总比没有好）
    const chosen = pick(shuffle(source));
    remember(cs, chosen.n, keepN || 0);
    if (round > 0 && isVerbose()) log(`推荐放宽到第 ${round + 1} 层（时段/口味筛完太少）`);
    return {
      name: chosen.n,
      reason: buildReason(chosen, meal, cons, round > 0),
      kfc: false,
      price: chosen.p,
      meal,
      scope: resolved.scope,
      srcs: resolved.srcs,
      note: resolved.note,
      _keepN: keepN
    };
  }

  // 忌口太刁钻 / 菜单里没这类菜：如实说明，绝不推破忌口或超出菜单的菜
  return {
    name: '',
    reason: '',
    kfc: false,
    price: 0,
    meal,
    scope: resolved.scope,
    srcs: resolved.srcs,
    exhausted: true,
    hint: `按现在的菜单范围（${SCOPE_LABELS[resolved.scope] || '外卖能点的'}）和忌口，这次没有能推的了。`
      + '跟对方说句实话，并告诉他可以在技能设置里把「菜单范围」改成「两种都要」。'
  };
}

function buildReason(d, meal, cons, relaxed) {
  const bits = [];
  const tags = (d.t || []).filter((t) => !['早餐', '午餐', '晚餐'].includes(t));
  if (tags.length) bits.push(tags.slice(0, 2).join('、'));
  if (d.hot && cons?.noSpicy !== true) bits.push(d.hot >= 3 ? '够辣，辣星人快上' : '微辣刚好提味');
  if (d.healthy) bits.push('清淡不撑');
  if (d.hearty) bits.push('扎实抗饿');
  if (Number(d.p)) bits.push(`大概 ${d.p} 块`);
  const head = meal ? `${meal}吃这个${bits.length ? '：' : '吧'}` : '';
  return `${head}${bits.join('，')}${relaxed ? '（今天筛选项有点严，给你放宽了一点）' : ''}`;
}

function remember(cs, name, keepN) {
  cs.history = Array.isArray(cs.history) ? cs.history : [];
  cs.history.push({ name: String(name), at: Date.now() });
  const cap = Math.max(keepN * 2 + 10, 12);
  if (cs.history.length > Math.min(MAX_HISTORY, cap)) {
    cs.history = cs.history.slice(-Math.min(MAX_HISTORY, cap));
  }
  cs.updatedAt = Date.now();
  saveState();
}

// ── 触发闸门（与被@才启用） ─────────────────────────────────────────────

const decisions = new Map();   // sessionId → { addressed, topic, at }
const lastTurnAt = new Map();  // chatKey → 最近一次被叫到的时间

function modeOf(c) {
  const raw = String(c?.triggerMode ?? '被@或戳一戳时');
  if (raw === '总是') return 'always';
  if (raw === '聊到吃饭时') return 'topic';
  return 'addressed';
}

function selfIdOf(ctx) {
  const v = ctx?.selfId ?? getConfig()?.snowluma?.selfId ?? getConfig()?.selfId ?? '';
  return v == null ? '' : String(v);
}

function selfNamesOf(ctx) {
  const persona = getConfig()?.persona || {};
  const set = new Set();
  const push = (v) => { const s = String(v ?? '').trim(); if (s) set.add(s.toLowerCase()); };
  push(ctx?.selfNickname);
  push(persona.botName);
  push(persona.selfNickname);
  return set;
}

function entryAddressesBot(entry, ctx) {
  if (!entry) return false;
  if (entry.atMe === true) return true;
  const selfId = selfIdOf(ctx);
  const names = selfNamesOf(ctx);
  const atNames = Array.isArray(entry.atNames) ? entry.atNames : [];
  for (const n of atNames) {
    const s = String(n ?? '').trim().toLowerCase();
    if (!s) continue;
    if (s === selfId) return true;
    if (names.has(s)) return true;
  }
  const text = String(entry.text ?? '');
  const cq = /\[CQ:at,qq=(\d+)\]/gi;
  let m;
  while ((m = cq.exec(text))) {
    if (selfId && m[1] === selfId) return true;
  }
  for (const name of names) {
    if (name && text.toLowerCase().includes(`@${name}`)) return true;
  }
  return entry?.isPoke === true && /拍了拍\s*我/.test(text);
}

const TOPIC_RE = /(今天吃什么|吃什么|吃啥|吃点儿什么|吃点什么|饿死|好饿|饿了|点外卖|外卖|午饭|晚饭|早饭|宵夜|夜宵|加餐|想吃)/;

function textHasTopic(entries) {
  const text = (entries || []).map((e) => String(e?.text ?? '')).join('\n');
  return TOPIC_RE.test(text);
}

/** 本轮的判定结果。 */
function decide(ctx) {
  const c = cfg() || {};
  const mode = modeOf(c);
  if (mode === 'always') return { allow: true, why: '设置为总是可用' };

  const entries = Array.isArray(ctx?.triggerEntries) ? ctx.triggerEntries : [];
  const addressed = entries.some((e) => entryAddressesBot(e, ctx));
  const topic = textHasTopic(entries);

  const sid = ctx?.sessionId == null ? '' : String(ctx.sessionId);
  const d = sid ? decisions.get(sid) : null;
  if (d && Date.now() - d.at < 10 * 60 * 1000) {
    if (d.addressed) return { allow: true, why: '本轮被叫到' };
    if (mode === 'topic' && d.topic) return { allow: true, why: '本轮聊到吃饭' };
  }
  if (addressed) return { allow: true, why: '本轮被叫到' };
  if (mode === 'topic' && topic) return { allow: true, why: '本轮聊到吃饭' };

  const chatKey = String(ctx?.chatKey ?? '');
  const grace = clampInt(c.graceMinutes, 0, 30, 3) * 60 * 1000;
  if (grace > 0 && chatKey) {
    const last = lastTurnAt.get(chatKey) || 0;
    if (last && Date.now() - last < grace) return { allow: true, why: '几分钟前刚被叫到（宽限内）' };
  }
  return { allow: false, why: mode === 'topic' ? '本轮没被 @、也没聊到吃饭' : '本轮没被 @ 或戳一戳' };
}

function isVerbose() {
  return cfg()?.verbose === true;
}

// ── 提示词片段 ───────────────────────────────────────────────────────────

const GUIDE_TEXT = [
  '群友问「今天吃什么/吃啥/中午吃啥/随便推荐个吃的」时，**直接调 eat_what 工具**，不要自己编菜名。',
  '拿到结果后，把菜名说清楚（连同理由里那句特色、大概价格），一句话回完，别罗列一堆备选让人再选一次。',
  '如果对方追问「换个」「还有别的吗」，再调一次 eat_what；他们说「不想吃这个」时，把那个菜名放进 avoid 参数里。',
  '如果对方说了忌口（不吃辣、吃素、不吃海鲜等），把它原样放进 avoid 传给工具，并且以后在这个群也照着来。',
  '菜单范围由技能设置决定（默认只推外卖能点到的菜）。对方明说「自己做/在家吃」「点外卖」「去食堂」时，把原话放进 want 参数传给工具；设置是外卖模式时工具仍按设置来，你照实说「按现在的设置只推外卖能点的」就行，不要自己编家常菜单。',
  '星期三晚上/星期四整天，回答里记得点出「疯狂星期四」。',
  '不要凭记忆编菜的价格；工具没给价格就别硬报。'
].join('\n');

export function promptSections(ctx) {
  try {
    const verdict = decide(ctx || {});
    if (!verdict.allow) return [];
    const c = cfg() || {};
    const isThu = weekdayOf(new Date()) === 4;
    const scopeWord = SCOPE_LABELS[scopeOf(c)] || '外卖能点的';
    const extra = `\n\n【今天吃什么·状态】现在是${mealOfNow()}${isThu ? '，今天星期四（疯狂星期四）' : ''}；菜单范围：${scopeWord}。`;
    return [{ id: 'eat-what-guide', title: '今天吃什么', priority: 46, content: GUIDE_TEXT + extra }];
  } catch {
    return [];
  }
}

// ── 钩子（只记状态，绝不发消息） ───────────────────────────────────────

export const hooks = {
  'before-context': (ctx) => {
    try {
      const entries = Array.isArray(ctx?.triggerEntries) ? ctx.triggerEntries : [];
      const addressed = entries.some((e) => entryAddressesBot(e, ctx));
      const topic = textHasTopic(entries);
      const sid = ctx?.sessionId == null ? '' : String(ctx.sessionId);
      if (sid) {
        decisions.set(sid, { addressed, topic, at: Date.now() });
        if (decisions.size > 200) {
          const cutoff = Date.now() - 10 * 60 * 1000;
          for (const [k, v] of decisions) if (v.at < cutoff) decisions.delete(k);
        }
      }
      const chatKey = String(ctx?.chatKey ?? '');
      if (chatKey && addressed) lastTurnAt.set(chatKey, Date.now());

      // 顺手把群里的忌口记下来（只记"我/本人"的口吻，避免把玩笑当忌口）
      const c = cfg() || {};
      if (c.includeTaste === true && chatKey) {
        const cs = chatState(chatKey);
        const next = parseConstraints(entries.map((e) => String(e?.text ?? '')).join('\n'), cs.cons);
        if (JSON.stringify(next) !== JSON.stringify(cs.cons)) {
          cs.cons = next;
          saveState();
          if (isVerbose()) log(`记下 ${chatKey} 的忌口：${JSON.stringify(next)}`);
        }
      }
      if (isVerbose() && (addressed || topic)) {
        log(`闸门：${chatKey || '?'} 本轮 ${addressed ? '被叫到' : ''}${addressed && topic ? ' + ' : ''}${topic ? '聊到吃饭' : ''}`);
      }
    } catch {
      // 钩子失败绝不影响主流程
    }
  }
};

export const providers = {
  'tool.guard': ({ toolId, context }) => {
    if (!String(toolId ?? '').startsWith('eat-what__')) return null;
    try {
      const verdict = decide(context || {});
      if (verdict.allow) return null;
      return { ok: false, reason: `今天吃什么：${verdict.why}` };
    } catch {
      return null;
    }
  }
};

// 必须同步返回
export function available() {
  return true;
}

// ── 入口 ─────────────────────────────────────────────────────────────────

export function setup(api) {
  cfg = () => api.config() || {};
  log = (...a) => api.log(...a);
  warn = (...a) => api.warn(...a);
  loadState();

  api.registerTool({
    id: 'eat_what',
    name: '今天吃什么',
    description:
      '给群友推荐今天/这一顿吃啥，返回一个具体的菜名、理由和大概价格（星期四统一推荐肯德基疯狂星期四）。'
      + '群友说「今天吃什么」「中午吃啥」「随便推荐个吃的」「饿了，有啥吃的」时用它；'
      + '需要换一个时再调一次；对方说不吃辣/吃素/不吃海鲜等忌口时，填进 avoid 参数；'
      + '对方明说「自己做/在家吃」「点外卖」「去食堂」，把原话填进 want 参数。',
    category: 'utility',
    icon: '🍚',
    parameters: {
      type: 'object',
      properties: {
        meal: {
          type: 'string',
          description: '哪一顿：早餐/午餐/晚餐/夜宵/加餐。不填就按当前时间自动判断。'
        },
        budget: {
          type: 'number',
          description: '对方说出的预算（元/人均）。不填则不限制。'
        },
        avoid: {
          type: 'string',
          description: '对方不想吃/不能吃的东西，原话照抄，比如「不吃辣」「素食」「不要海鲜」「不想吃黄焖鸡」。'
        },
        want: {
          type: 'string',
          description: '对方对吃法说的话，原话照抄，比如「自己做饭」「点个外卖」「去食堂」。没提就留空。'
        },
        chatKey: {
          type: 'string',
          description: '当前会话的聊天标识（系统提示里的 chatKey），用来记住这个群最近推过什么、有什么忌口。'
        }
      },
      required: []
    },
    async execute(ctx, args) {
      try {
        const a = args || {};
        const chatKey = String(a.chatKey || ctx?.chatKey || 'global');
        const cs = chatState(chatKey);
        // 模型这次说出的忌口也并进这个群的记忆里
        if (a.avoid) {
          const next = parseConstraints(a.avoid, cs.cons);
          if (JSON.stringify(next) !== JSON.stringify(cs.cons)) {
            cs.cons = next;
            saveState();
          }
        }
        const mealWord = mealFromWord(a.meal) || mealFromWord(String(a.avoid || ''));
        const wantedMeal = mealWord || mealOfNow();

        // 菜单范围：设置定调，口头诉求只在"两种都要"模式下收窄这一次
        const c = cfg() || {};
        const resolved = resolveSources(c, modeFromText(String(a.want || '')) || modeFromText(String(a.avoid || '')));

        // 如果对方明确说了"不想吃X"，这一轮就不再给 X
        const banText = String(a.avoid || '');
        const banned = (state.chats[chatKey]?.history || [])
          .map((h) => String(h.name))
          .filter((n) => n && banText.includes(n));

        const spec = { chatKey, meal: wantedMeal, budget: a.budget, srcs: resolved.srcs };
        let pickResult = null;
        for (let i = 0; i < 6; i += 1) {
          const r = recommend(spec);
          if (r.exhausted) { pickResult = r; break; }
          if (!banned.includes(r.name)) { pickResult = r; break; }
        }
        if (!pickResult) pickResult = recommend(spec);

        if (pickResult.exhausted) {
          return {
            content: `这次没菜可推：菜单范围「${SCOPE_LABELS[resolved.scope] || '外卖能点的'}」，这个群记下的忌口 ${JSON.stringify(cs.cons)}，两头一卡就没剩什么了。\n`
              + `请如实告诉对方，并提醒他可以在技能设置里把「菜单范围」改成「两种都要」；不要瞎编一个破忌口或超出菜单的菜端上去。`,
            isError: true
          };
        }

        const out = [];
        out.push(`菜单范围：${SCOPE_LABELS[resolved.scope] || '外卖能点的'}`);
        if (resolved.note) out.push(`本次说明：${resolved.note}`);
        out.push(`推荐：${pickResult.name}`);
        if (pickResult.reason) out.push(`理由：${pickResult.reason}`);
        if (pickResult.kfc) out.push('（今天是星期四，按设置推肯德基疯狂星期四）');
        out.push(`参考时段：${pickResult.meal}`);
        out.push('请直接用一句自然的话把这道菜推荐给群友，不要罗列菜库，也不要编造工具没给的信息。');
        return { content: out.join('\n') };
      } catch (error) {
        return { content: `推荐失败了：${error?.message ?? error}（随便点个能吃的也行，别编菜名）`, isError: true };
      }
    }
  });

  log('今天吃什么已就绪（工具 eat_what）');
}

export function activate(ctx = {}) {
  log('今天吃什么已启用' + (ctx?.reason ? `（${ctx.reason}）` : ''));
}

export function deactivate() {}

export function dispose() {
  decisions.clear();
  lastTurnAt.clear();
}

// ── 测试替身（仅供人工排查） ─────────────────────────────────────────────
export const internals = {
  recommend,
  parseConstraints,
  mealOfNow,
  mealFromWord,
  weekdayOf,
  dishAllowed,
  decide,
  DISHES: DISHES_ALL,
  DISHES_ALL,
  menuFilter,
  modeFromText,
  state: () => state,
  chatState
};
