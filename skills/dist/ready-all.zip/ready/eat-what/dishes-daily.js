// 菜库续（二）：早餐主食 + 家常菜（做法简单的）。由 index.js 直接 import 使用。
// 字段同 DISHES：n 名字 / t 标签 / hot 辣度 0-3 / p 均价 / meal 适合哪顿 / group 分类
// src 这一份是给"外卖 / 食堂 / 家常"三种来源共用的，index.js 会按 src 归类。

export const DISHES_DAILY = [
  // ── 早餐主食（家常那类的早饭） ──
  { n: '煮挂面卧个蛋', t: ['面食', '家常'], p: 6, meal: ['早餐', '夜宵'], group: '早餐', src: ['home'] },
  { n: '白粥配咸菜', t: ['清淡', '家常'], p: 4, meal: ['早餐', '夜宵'], group: '早餐', light: true, src: ['home', 'canteen'] },
  { n: '蛋炒饭', t: ['米饭', '家常'], p: 8, meal: ['午餐', '晚餐', '夜宵'], group: '家常菜', src: ['home', 'canteen'] },
  { n: '煮玉米＋水煮蛋', t: ['家常', '清淡'], p: 6, meal: ['早餐', '加餐'], group: '早餐', light: true, src: ['home'] },
  { n: '蒸红薯', t: ['家常', '清淡'], p: 5, meal: ['早餐', '加餐'], group: '早餐', light: true, src: ['home'] },
  { n: '速冻水饺', t: ['饺子', '家常'], p: 15, meal: ['午餐', '晚餐', '夜宵'], group: '家常菜', src: ['home'] },
  { n: '馒头就咸菜', t: ['家常'], p: 5, meal: ['早餐', '加餐'], group: '早餐', light: true, src: ['home', 'canteen'] },
  { n: '豆浆＋包子', t: ['早餐', '家常'], p: 9, meal: ['早餐'], group: '早餐', src: ['home', 'canteen', 'takeout'] },
  { n: '牛奶＋面包', t: ['早餐', '西式'], p: 10, meal: ['早餐', '加餐'], group: '早餐', light: true, src: ['home'] },
  { n: '燕麦粥', t: ['早餐', '清淡'], p: 8, meal: ['早餐', '加餐'], group: '早餐', light: true, healthy: true, src: ['home'] },

  // ── 家常菜（做起来简单的） ──
  { n: '西红柿炒蛋盖饭', t: ['米饭', '家常'], p: 10, meal: ['午餐', '晚餐'], group: '家常菜', src: ['home', 'canteen', 'takeout'] },
  { n: '蛋炒饭加个汤', t: ['米饭', '家常'], p: 12, meal: ['午餐', '晚餐'], group: '家常菜', src: ['home', 'canteen'] },
  { n: '青椒炒肉配米饭', t: ['米饭', '家常'], hot: 1, p: 14, meal: ['午餐', '晚餐'], group: '家常菜', src: ['home', 'canteen', 'takeout'] },
  { n: '土豆丝炒肉盖饭', t: ['米饭', '家常'], hot: 1, p: 13, meal: ['午餐', '晚餐'], group: '家常菜', src: ['home', 'canteen', 'takeout'] },
  { n: '醋溜土豆丝配米饭', t: ['蔬菜', '家常'], p: 8, meal: ['午餐', '晚餐'], group: '家常菜', src: ['home', 'canteen'] },
  { n: '蒜苗炒肉配米饭', t: ['米饭', '家常'], p: 14, meal: ['午餐', '晚餐'], group: '家常菜', src: ['home', 'canteen', 'takeout'] },
  { n: '红烧豆腐配米饭', t: ['豆制品', '家常'], p: 9, meal: ['午餐', '晚餐'], group: '家常菜', src: ['home', 'canteen'] },
  { n: '清炒时蔬＋白饭', t: ['蔬菜', '清淡', '家常'], p: 7, meal: ['午餐', '晚餐'], group: '家常菜', healthy: true, src: ['home', 'canteen'] },
  { n: '紫菜蛋花汤配饭', t: ['汤', '家常'], p: 8, meal: ['午餐', '晚餐'], group: '家常菜', light: true, src: ['home'] },
  { n: '手抓饼卷蛋', t: ['饼', '家常'], p: 7, meal: ['早餐', '加餐', '夜宵'], group: '早餐', src: ['home'] },
  { n: '蛋包饭', t: ['米饭', '家常'], p: 12, meal: ['午餐', '晚餐'], group: '家常菜', src: ['home', 'takeout'] },
  { n: '雪菜肉丝面', t: ['面食', '家常'], p: 12, meal: ['早餐', '午餐', '晚餐'], group: '面食', src: ['home', 'takeout', 'canteen'] },
  { n: '清汤挂面', t: ['面食', '清淡'], p: 6, meal: ['早餐', '夜宵'], group: '面食', light: true, src: ['home'] },
  { n: '方便面加蛋加肠', t: ['面食', '家常'], hot: 1, p: 8, meal: ['午餐', '晚餐', '夜宵'], group: '面食', src: ['home'] },
  { n: '凉拌黄瓜配粥', t: ['清淡', '家常'], p: 6, meal: ['早餐', '晚餐'], group: '家常菜', healthy: true, light: true, src: ['home'] },

  // ── 食堂 / 小馆子那种 ──
  { n: '食堂两荤一素', t: ['米饭', '食堂'], p: 15, meal: ['午餐', '晚餐'], group: '食堂', src: ['canteen'] },
  { n: '食堂一两荤一素', t: ['米饭', '食堂'], p: 11, meal: ['午餐', '晚餐'], group: '食堂', light: true, src: ['canteen'] },
  { n: '小馆红烧茄子配饭', t: ['米饭', '家常', '素食'], p: 14, meal: ['午餐', '晚餐'], group: '家常菜', src: ['canteen', 'takeout'] },
  { n: '小馆麻婆豆腐配饭', t: ['米饭', '川菜', '家常'], hot: 2, p: 13, meal: ['午餐', '晚餐'], group: '家常菜', src: ['canteen', 'takeout'] },
  { n: '小馆回锅肉配饭', t: ['米饭', '川菜', '猪肉'], hot: 2, p: 18, meal: ['午餐', '晚餐'], group: '家常菜', src: ['canteen', 'takeout'] },
  { n: '小馆青椒土豆丝配饭', t: ['米饭', '家常'], p: 10, meal: ['午餐', '晚餐'], group: '家常菜', src: ['canteen', 'takeout'] },
  { n: '小馆水煮肉片配饭', t: ['米饭', '川菜', '猪肉'], hot: 3, p: 26, meal: ['午餐', '晚餐'], group: '家常菜', src: ['canteen', 'takeout'] },
  { n: '小馆酸菜鱼配饭', t: ['米饭', '鱼', '川菜'], hot: 2, p: 32, meal: ['午餐', '晚餐'], group: '家常菜', src: ['canteen', 'takeout'] },
  { n: '小馆糖醋里脊配饭', t: ['米饭', '猪肉', '家常'], p: 20, meal: ['午餐', '晚餐'], group: '家常菜', src: ['canteen', 'takeout'] },
  { n: '小馆西红柿鸡蛋面', t: ['面食', '家常'], p: 12, meal: ['午餐', '晚餐'], group: '面食', src: ['canteen', 'takeout'] },
  { n: '小馆拌面加小菜', t: ['面食', '家常'], hot: 1, p: 14, meal: ['午餐', '晚餐'], group: '面食', src: ['canteen', 'takeout'] },
  { n: '小馆卤肉饭', t: ['米饭', '猪肉'], p: 16, meal: ['午餐', '晚餐'], group: '家常菜', src: ['canteen', 'takeout'] },
  { n: '小馆炒时蔬配饭', t: ['蔬菜', '清淡', '家常'], p: 10, meal: ['午餐', '晚餐'], group: '家常菜', healthy: true, src: ['canteen', 'takeout'] }
];
