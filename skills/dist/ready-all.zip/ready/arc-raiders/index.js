// ARC Raiders 资料库 —— LLM 型技能（skills/arc-raiders）。
//
// 两个工具：
//   arc_item   查物品/武器：分解回收、制作配方、用途、价值、武器数值
//   arc_world  查地图 / ARC 敌人 / 实时地图事件 / 每周试炼
//
// 查到后由工具自己把资料卡发到群里（渲染 PNG → ctx.sender.sendImage）：
//   桌面版用主进程隐藏窗口截图；纯 Node（npm run server）用一次性 Electron worker 截图。
// 渲染或发送失败就退回文字版 —— 用户要求“正常返回图片，失败返回文本”。
// 数据：items/maps/bots/events 来自构建时打包的 data.json；事件排期与试炼走 MetaForge 公开 API。
//
// ⚠️ 为什么用动态 import + ?v=：宿主的热重载只给**入口**加 ?t= 破缓存，静态 import 的
// lib/*.js 会一直复用进程里第一次加载的旧版本。改了 lib 却还是旧行为（曾表现为「发不出图」），
// 就是踩了这个坑。这里每次加载给依赖加一个新版本号，保证热重载改一处生效一处。
const VER = `?v=${Date.now()}`;

import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const SKILL_DIR = path.dirname(fileURLToPath(import.meta.url));
const PROJECT_ROOT = path.resolve(SKILL_DIR, '..', '..');
// 图标是本地缓存（不随技能目录走），优先项目 data 目录，其次技能自带
const ICON_DIRS = [
  path.join(PROJECT_ROOT, 'data', 'arc-raiders', 'icons'),
  path.join(SKILL_DIR, 'icons')
];
const iconCache = new Map();

/** 读本地图标 → data URI（没有就返回空串，卡片退化成无图标）。 */
function iconFor(id) {
  if (iconCache.has(id)) return iconCache.get(id);
  const name = `${String(id).replace(/[^\w.-]+/g, '_')}.png`;
  for (const dir of ICON_DIRS) {
    try {
      const buf = fs.readFileSync(path.join(dir, name));
      const uri = `data:image/png;base64,${buf.toString('base64')}`;
      if (iconCache.size > 400) iconCache.clear();
      iconCache.set(id, uri);
      return uri;
    } catch { /* 换下一个目录 */ }
  }
  iconCache.set(id, '');
  return '';
}

const dbm = await import(`./lib/db.js${VER}`);
const cardm = await import(`./lib/card.js${VER}`);
const shotm = await import(`./lib/shot.js${VER}`);
const livem = await import(`./lib/live.js${VER}`);
const wikim = await import(`./lib/wiki.js${VER}`);

const {
  db, searchItems, searchMaps, searchBots, searchEvents, botsOnMap, norm
} = dbm;
const {
  itemCard, botCard, mapCard, eventsCard, eventTypesCard, trialsCard, candidatesCard,
  textItem, textBot, textMap, textEvents, textTrials, textCandidates
} = cardm;
const { renderCardPng, savePng, diag } = shotm;
const { setFetch, getEventGroups, getTrials } = livem;
const { setWikiFetch, searchItem: searchWikiItem, getItem: getWikiItem } = wikim;

cardm.createCard({ itemName: dbm.itemName, mapName: dbm.mapName, DATA_DATE: dbm.DATA_DATE });
livem.createLive({ db });

let cfg = () => ({});
let log = () => {};

export function setup(api) {
  cfg = api.config;
  log = api.log;
  const hasFetch = typeof api.fetch === 'function';
  setFetch(hasFetch ? api.fetch : null);
  setWikiFetch(hasFetch ? api.fetch : null);

  api.registerTool({
    id: 'arc_item',
    name: '查 ARC Raiders 物品',
    description:
      '查询《ARC Raiders》物品与武器的资料：能分解/回收出什么、用什么材料制作、被哪些配方需要、价值、重量，'
      + '武器还会给伤害/射速/弹匣/护甲穿透等数值。'
      + '当群友问「XX 能分解成什么」「XX 怎么做/要什么材料」「XX 有什么用」「XX 值多少钱」「某把枪数据怎么样」'
      + '「XX 在哪找」时使用。query 直接填他们说的物品名，中文名、英文名、缩写都行（如「肾上腺素针剂」「山猫 III」「Bobcat」）。'
      + '本地图鉴没收录的东西会自动去中文维基 ArcWiki 联网查一次（多花 1~2 秒），所以没搜到时先别急着说没有，等工具返回。'
      + '工具会把资料卡图片直接发到当前群，你不需要再调用发送工具，也不要把卡片内容复述一遍。',
    category: 'knowledge',
    icon: '🎒',
    parameters: {
      type: 'object',
      properties: {
        query: {
          type: 'string',
          description: '要查的物品或武器名称。中文名（肾上腺素针剂）、英文名（Adrenaline Shot）或 id 都可以。'
        }
      },
      required: ['query']
    },
    async execute(ctx, args) {
      const query = String(args?.query ?? '').trim();
      if (!query) return { content: '缺少 query：把要查的物品名给我（中文/英文都行）。', isError: true };

      try {
        const hits = searchItems(query);
        if (!hits.length) {
          // 本地库没收录（它比游戏实际物品少）→ 现场去 ArcWiki 查一次，仍查不到才算没有。
          if (cfg().wikiFallback !== false) {
            try {
              const found = await searchWikiItem(query);
              if (found && found.score >= 60) {
                const remote = await getWikiItem(found);
                return deliver(ctx, {
                  html: itemCard(remote, { icon: iconFor(remote.id) }),
                  text: textItem(remote),
                  note: `${remote.zh}资料`,
                  tell: `本地图鉴没收录「${query}」，已从 ArcWiki 实时查到「${remote.zh}」并发卡。不要复述卡片内容。`
                });
              }
            } catch (error) {
              diag(`wiki fallback failed (${query}): ${error?.message ?? error}`);
            }
          }
          return {
            content:
              `本地图鉴和 ArcWiki 都没查到「${query}」。`
              + '可以换成英文名再试一次（如 Adrenaline Shot、Bobcat III），或者告诉群友「没查到这个名字」。'
          };
        }

        const top = hits[0];
        const tied = hits[1] && hits[1].score >= top.score - 5 && hits[1].ref.id !== top.ref.id;
        const confident = top.score === 100 || (top.score >= 60 && !tied);

        if (!confident) {
          const list = pickCandidates(hits, query).map((h) => ({
            name: h.ref.zh,
            sub: h.ref.en,
            meta: h.ref.typeZh || h.ref.type
          }));
          return deliver(ctx, {
            html: candidatesCard('物品', list),
            text: textCandidates('物品', list),
            note: '物品候选',
            tell:
              `「${query}」匹配到多个物品，已发候选卡：${list.map((x) => x.name).join('、')}。`
              + '让群友确认是哪一个再用完整名字查。'
          });
        }

        const item = top.ref;
        return deliver(ctx, {
          html: itemCard(item, { icon: iconFor(item.id) }),
          text: textItem(item),
          note: `${item.zh}资料`,
          tell: `已把「${item.zh}${item.en ? `（${item.en}）` : ''}」的资料卡发到群里。图片内容你看不到，不要复述卡片细节，也不要再发一次。`
        });
      } catch (error) {
        return { content: `查物品失败：${error?.message ?? error}`, isError: true };
      }
    }
  });

  api.registerTool({
    id: 'arc_world',
    name: '查 ARC Raiders 世界资料',
    description:
      '查询《ARC Raiders》的物品之外资料：地图（出没的 ARC、本图事件）、ARC 敌人（类型、威胁等级、弱点、掉落、出没地图）、'
      + '实时地图事件排期（未来 3 小时哪张图刷什么）、每周试炼（当前生效的挑战）。'
      + '当群友问「XX 图有什么」「这个 ARC 怎么打/掉什么」「现在哪张图在刷什么事件」「本周试炼是什么」时使用。'
      + 'category 选 map / arc / event / trial；query 对 map 和 arc 填名字（中文/英文都行），event 和 trial 可留空。'
      + '工具会把资料卡图片直接发到当前群，你不需要再调用发送工具，也不要把卡片内容复述一遍。',
    category: 'knowledge',
    icon: '🗺️',
    parameters: {
      type: 'object',
      properties: {
        category: {
          type: 'string',
          enum: ['map', 'arc', 'event', 'trial'],
          description: '查哪一类：map=地图，arc=ARC 敌人，event=地图事件排期，trial=每周试炼。'
        },
        query: {
          type: 'string',
          description: '地图名或 ARC 名（category 为 event/trial 时可省略）。如「大坝」「Bastion」「Dam Battlegrounds」。'
        }
      },
      required: ['category']
    },
    async execute(ctx, args) {
      const category = String(args?.category ?? '').trim().toLowerCase();
      const query = String(args?.query ?? '').trim();
      if (!category) return { content: '缺少 category（map/arc/event/trial）', isError: true };

      try {
        if (category === 'map') return await handleMap(ctx, query);
        if (category === 'arc') return await handleArc(ctx, query);
        if (category === 'event') return await handleEvent(ctx, query);
        if (category === 'trial') return await handleTrial(ctx);
        return { content: `不认识的 category：${category}（只能是 map/arc/event/trial）`, isError: true };
      } catch (error) {
        return { content: `查询失败：${error?.message ?? error}`, isError: true };
      }
    }
  });

  const weapons = db.items.filter((i) => i.weapon).length;
  log(`ARC Raiders 资料库已加载：${db.items.length} 件物品（含 ${weapons} 把武器）/ ${db.maps.length} 张图 / ${db.bots.length} 种 ARC`);
}

/* ── 各类查询 ───────────────────────────────────────────────────────── */

async function handleMap(ctx, query) {
  const hits = query ? searchMaps(query) : [];
  if (!query) {
    const list = db.maps.map((m) => ({ name: m.zh, sub: m.en, meta: '地图' }));
    return deliver(ctx, {
      html: candidatesCard('地图', list),
      text: `ARC Raiders 地图：${db.maps.map((m) => m.zh).join('、')}`,
      note: '地图列表',
      tell: `还没有指定地图。可选：${db.maps.map((m) => m.zh).join('、')}。`
    });
  }
  if (!hits.length) {
    return { content: `没有叫「${query}」的地图。现有地图：${db.maps.map((m) => m.zh).join('、')}。` };
  }
  const map = hits[0].ref;
  const bots = botsOnMap(map);
  const liveEnabled = cfg().liveEvents !== false;
  const live = liveEnabled ? await getEventGroups({ horizonMs: 3 * 3600 * 1000, perMap: 5 }) : { ok: false, error: '设置里关了实时事件' };
  const events = live.ok ? (live.groups.find((g) => g.map === map.zh)?.events || []) : [];

  return deliver(ctx, {
    html: mapCard(map, { bots, events, liveOk: live.ok, liveReason: live.error, source: live.source }),
    text: textMap(map, { bots, events }),
    note: `${map.zh} 地图`,
    tell: `已把「${map.zh}」地图卡发到群里（含出没 ARC${events.length ? '和本图事件' : ''}）。不要复述卡片内容。`
  });
}

async function handleArc(ctx, query) {
  if (!query) {
    const list = db.bots.map((b) => ({ name: b.zh || b.en, sub: b.en, meta: b.threatZh || b.threat }));
    return deliver(ctx, {
      html: candidatesCard('ARC', list),
      text: `ARC 种类：${db.bots.map((b) => b.zh || b.en).join('、')}`,
      note: 'ARC 一览',
      tell: `还没指定 ARC。现有：${db.bots.map((b) => b.zh || b.en).join('、')}。`
    });
  }
  const hits = searchBots(query);
  if (!hits.length) {
    const list = db.bots.map((b) => ({ name: b.zh || b.en, sub: b.en, meta: b.threatZh || b.threat }));
    return deliver(ctx, {
      html: candidatesCard('ARC', list),
      text: `没找到「${query}」。ARC 种类：${db.bots.map((b) => b.zh || b.en).join('、')}`,
      note: 'ARC 一览',
      tell: `没找到叫「${query}」的 ARC，已发全部 ARC 列表让群友挑。`
    });
  }
  const top = hits[0];
  const tied = hits[1] && hits[1].score >= top.score - 5;
  if (top.score < 60 || tied) {
    const list = pickCandidates(hits, query).map((h) => ({ name: h.ref.zh || h.ref.en, sub: h.ref.en, meta: h.ref.threatZh || h.ref.threat }));
    return deliver(ctx, {
      html: candidatesCard('ARC', list),
      text: textCandidates('ARC', list),
      note: 'ARC 候选',
      tell: `「${query}」匹配到多个 ARC，已发候选卡：${list.map((x) => x.name).join('、')}。`
    });
  }
  const bot = top.ref;
  return deliver(ctx, {
    html: botCard(bot),
    text: textBot(bot),
    note: `${bot.en} 图鉴`,
    tell: `已把 ARC「${bot.zh || bot.en}」的图鉴卡发到群里。不要复述卡片内容。`
  });
}

async function handleEvent(ctx, query) {
  const useLive = cfg().liveEvents !== false;
  const live = useLive ? await getEventGroups({ horizonMs: 3 * 3600 * 1000, perMap: 4 }) : { ok: false, error: '已关闭实时事件' };

  if (live.ok && live.groups.length) {
    let groups = live.groups;
    if (query) {
      const maps = searchMaps(query).map((h) => h.ref.zh);
      const evs = searchEvents(query).map((h) => h.ref.zh);
      const filtered = groups.filter((g) => maps.includes(g.map) || g.events.some((e) => evs.includes(e.zh)));
      groups = filtered.length ? filtered : [];
    }
    if (!groups.length) {
      return {
        content: query
          ? `接下来 3 小时没有涉及「${query}」的事件排期。可以参考事件类型：${db.events.map((e) => e.zh).join('、')}。`
          : '接下来 3 小时的排期是空的，可能刚好在空档。'
      };
    }
    return deliver(ctx, {
      html: eventsCard(groups, { fetchedAt: new Date().toLocaleTimeString('zh-CN', { hour12: false, hour: '2-digit', minute: '2-digit' }), live: true, source: live.source }),
      text: textEvents(groups),
      note: '地图事件',
      tell: '已把未来 3 小时的地图事件排期卡发到群里。不要复述卡片内容。'
    });
  }

  // 实时失败 → 本地事件类型一览
  const list = query ? (searchEvents(query).length ? searchEvents(query).map((h) => h.ref) : db.events) : db.events;
  return deliver(ctx, {
    html: eventTypesCard(list),
    text: `实时事件排期没拉到（${live.error || '未知原因'}）。事件类型：${list.map((e) => e.zh).join('、')}。`,
    note: '地图事件类型',
    tell: `实时排期拉不到（${live.error || '原因不明'}），已发事件类型一览。可以告诉群友「实时排期暂时拉不到」。`
  });
}

async function handleTrial(ctx) {
  const useLive = cfg().liveTrials !== false;
  const live = useLive ? await getTrials() : { ok: false, error: '已关闭实时试炼' };

  if (live.ok && live.trials.length) {
    return deliver(ctx, {
      html: trialsCard(live.trials, {
        fetchedAt: new Date().toLocaleTimeString('zh-CN', { hour12: false, hour: '2-digit', minute: '2-digit' }),
        period: live.period,
        source: live.source
      }),
      text: textTrials(live.trials, { period: live.period }),
      note: '每周试炼',
      tell: `已把本周试炼卡（${live.trials.length} 个）发到群里。不要复述卡片内容。`
    });
  }

  const reason = live.error || '当前没有生效的试炼';
  return {
    content:
      `试炼数据暂时拿不到（${reason}）。`
      + '可以告诉群友：本周试炼在游戏内 Trials 界面查看，或打开 https://www.arcwiki.top/trial/ 。',
    isError: false
  };
}

/* ── 候选筛选 ───────────────────────────────────────────────────────── */

/**
 * 从命中里挑候选：优先「名字以查询开头」的（山猫 → 山猫 I/II/III，而不是碰巧含这两个字的别的物品），
 * 再按分数收敛，最多 5 个。
 */
function pickCandidates(hits, query) {
  const q = norm(query);
  const pref = q ? hits.filter((h) => h.keys.some((k) => k.startsWith(q))) : [];
  const base = pref.length ? pref : hits;
  const top = base[0]?.score ?? 0;
  return base.filter((h) => h.score >= Math.max(40, top - 8)).slice(0, 5);
}

/* ── 发送：优先图片，失败退回文字 ───────────────────────────────────── */
async function deliver(ctx, { html, text, note, tell, textTell }) {
  if (!ctx?.sender || !ctx?.chatKey) {
    return { content: `${text}\n（当前没有发送上下文，直接把上面内容告诉群友。）` };
  }

  let renderFailed = false;

  // 1) 图片
  try {
    const png = await renderCardPng(html, { width: 1000 });
    if (png) {
      const file = savePng(png);
      try {
        await ctx.sender.sendImage(
          ctx.chatKey,
          { file: file || undefined, dataUrl: `base64://${png.toString('base64')}` },
          { note }
        );
        return { content: tell };
      } catch (error) {
        const msg = String(error?.message ?? error);
        if (/刚刚发过|已跳过|重复/.test(msg)) {
          return { content: `「${note}」刚刚已经发过一张一样的卡了，这轮不用再发。` };
        }
        diag(`sendImage failed (${note}): ${msg}`);
        log(`发图失败，回退文字：${msg}`);
      }
    } else {
      renderFailed = true;
      diag(`render returned null (${note})`);
    }
  } catch (error) {
    renderFailed = true;
    diag(`render failed (${note}): ${error?.message ?? error}`);
    log(`渲染卡片失败，回退文字：${error?.message ?? error}`);
  }

  // 2) 文字
  try {
    await ctx.sender.sendTextBatch(ctx.chatKey, [text]);
    const reason = renderFailed ? '图片渲染不可用' : '图片没发出去';
    return { content: textTell || `已把「${note}」的文字版发到群里（${reason}）。不要复述卡片内容，也不要再发一次。` };
  } catch (error) {
    diag(`sendTextBatch failed (${note}): ${error?.message ?? error}`);
    return { content: `发送失败：${error?.message ?? error}`, isError: true };
  }
}
