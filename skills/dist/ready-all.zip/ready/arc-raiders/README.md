# ARC Raiders 资料库（arc-raiders）

群友在群里问《ARC Raiders》的东西时，机器人直接甩一张资料卡（图片）出来；图片渲染不出来就发文字。

## 群友怎么用

直接问，或者 @机器人 问，例如：

- 「肾上腺素针剂能分解成什么？」
- 「山猫 III 怎么做 / 用什么材料」
- 「这枪伤害多少」
- 「大坝战场有什么 ARC」
- 「堡垒怎么打、掉什么」
- 「现在哪张图在刷什么事件」
- 「本周试炼是什么」

## 两个工具

| 工具 | 管什么 |
|---|---|
| `arc_item` | 物品 / 武器：回收台分解产物、战场内拆解产物、制作配方、被哪些配方需要、价值重量、武器数值 |
| `arc_world` | 地图（出没的 ARC + 本图事件）、ARC 敌人（类型/威胁/弱点/掉落）、实时地图事件排期、每周试炼 |

工具会自己把卡片发到当前会话，模型只负责接话，不需要再调发送工具。

## 数据从哪来

本地 `data.json` 是**三个来源合并**的（1142 条，606KB）：

1. **arcraiders.wiki**（Cargo `items`/`crafting`/`recycling` 表 + 武器页信息框）：**配方、回收、拆解、
   出没区域、武器数值以它为准**（303 条配方、438 条有回收/拆解、233 条有出没区域、88 把武器有 12 项数值）。
   一个武器页覆盖 I~IV 全部型号，耐久按型号取对应档；武器变体（增强型“铁砧” 之类）沿用同系列数值，
   卡片会标注「数值沿用「XX」系列」。
2. **RaidTheory/arcraiders-data**（581 条）：物品 id、游戏内简中名与描述、武器改装特性（百分比类）。
   它没有覆盖到的物品由第 3 个来源补。
3. **arcwiki.top**（补 561 条）：本地没收录的中文物品（家具/设计/武器变体/蓝图/研究/饰品…），
   以及 ARC 机械体的中文名、描述、弱点、血量。

**两个维基怎么对齐的**：两个站用的是同一批游戏图标文件，所以按「图片文件 md5 相同」逐条配对
（`match-images.mjs` 生成 `bridge.json`），从而把 arcraiders.wiki 的英文配方/回收数据翻成中文名
挂到中文条目上。图标重复的条目（比如同一张蓝图图标对应多个物品）一律跳过，宁缺不错。

**物品图标**：卡片右上角 108px。图标是本地缓存，放在 `<项目>\data\arc-raiders\icons\`（1120 张、约 15MB，
128px PNG），不占技能目录；缺失的条目自动不显示图标。重抓命令：

```
node_modules\electron\dist\electron.exe skills\arc-raiders\lib\build-icons.mjs
```

例：`手持电钻` = Hand Drill → 回收出机械元件 ×1、拆解出金属零件 ×2、用于制作「铁砧 I」×3，
重量 0.5kg、堆叠 3、出没区域「机械区 / 工业区」——这些本地老数据里都没有。

实时部分：

- 地图事件排期：优先 [ArcWiki 事件接口](https://www.arcwiki.top/api/event/data/)（中文、亚服），
  失败退回 [MetaForge](https://metaforge.app/arc-raiders)。
- 每周试炼：优先 [ArcWiki 试炼页](https://www.arcwiki.top/trial/)（中文名 + 计分规则 + 轮换周期），
  失败退回 MetaForge（英文原名）。
- **本地库没收录的物品**：现场去 [ArcWiki 物品库](https://www.arcwiki.top/items/) 查一次
  （列表页缓存 30 分钟），卡片标注「数据：ArcWiki（实时查询）」。

事件缓存 3 分钟、试炼缓存 30 分钟；拉不到就退回本地事件类型列表或纯文字说明，不会报错刷屏。

游戏更新后数据会过期。要更新：重跑三个抓取脚本（RaidTheory 原始 JSON、arcwiki 列表+详情、
arcraiders.wiki Cargo），再用构建脚本压成 `data.json`。

## 设置项

| 设置 | 默认 | 说明 |
|---|---|---|
| 地图事件用实时数据 | 开 | 关掉后查事件只给本地事件类型列表，不联网 |
| 每周试炼用实时数据 | 开 | 关掉后查试炼直接回文字说明，不联网 |
| 本地没有时联网查 ArcWiki | 开 | 关掉后只查本地这 1142 条，查不到就直接回没有 |

## 已知限制

- **中文数据来自社区维基（ArcWiki）**，游戏大版本更新后可能滞后；关键数值以游戏内为准。
- **图标不在安装包里**：卡片图标是本地缓存（`<项目>\data\arc-raiders\icons\`，128px，约 15MB），
  新装默认没有，卡片自动不显示图标；想要图标就运行上面的 `build-icons.mjs`。图标缺 22 条。
- **每周试炼每周轮换**，卡片只反映抓取时刻的生效项。
- **图片两种运行方式都支持**：桌面版直接用主进程的隐藏窗口截图（约 0.3 秒）；`npm run server`
  纯 Node 模式没有浏览器窗口，会临时起一个 Electron 进程（`lib/render-worker.cjs`，约 0.8 秒）来截。
  两者都不可用时自动退回文字版。渲染失败的原因会写进 `data/logs/arc-raiders-render.log`。
- 实时接口挂了 / 网络不通时不会报错，只会降级（事件→事件类型列表，试炼→文字说明）。

## 数据来源与许可

- 物品/武器基础数据：[RaidTheory/arcraiders-data](https://github.com/RaidTheory/arcraiders-data)（MIT）。
- 中文名称、描述、ARC 图鉴、事件与试炼：[ArcWiki](https://www.arcwiki.top/)（社区维基，CC BY-SA 4.0）。
- 配方/回收/出没区域/武器数值：[ARC Raiders Wiki](https://arcraiders.wiki/)（社区维基，CC BY-SA 4.0）。
- 本技能是非官方玩家工具，与 Embark Studios 无关；数据以游戏内为准。

## 维护提示（改代码的人看）

宿主的热重载只给**入口** `index.js` 加 `?t=时间戳` 破缓存，静态 `import` 的 `lib/*.js`
会一直复用进程里第一次加载的旧版本 —— 改了 `lib/` 却还是旧行为（曾表现为「发不出图」）。
所以 `index.js` 用 `await import('./lib/xxx.js?v=时间戳')` 动态加载，并且 `lib/card.js`、
`lib/live.js` 不 import 兄弟模块（依赖由 `index.js` 注入）。**改代码时不要把它改回静态 import。**
