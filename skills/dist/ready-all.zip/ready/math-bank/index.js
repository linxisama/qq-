// 高数题库 —— Skill（QQ Agent 规范）
//
// 两个工具：
//   math-bank__chapters  列出题库里有哪些章节 / 知识点（模型拿不准时先查）
//   math-bank__search    按【章节/知识点】+【难度 1~5】检索 N 道题（默认 3 道）
//
// ── 设计要点 ──────────────────────────────────────────────────────────────
//
// 1) 题目【不由模型生成】。全部来自 bank.json，只做检索。
//    理由和 twenty-q「谜底不由模型产生」一致：模型临时编的题，答案十有八九是错的，
//    而数学题一旦答案是错的，学生照着做只会更困惑。
//
// 2) 检索要容忍【自然语言】。用户会说「极限」「求极限」「lim」「极限那块」，
//    所以要同时匹配：章节名 / 章节别名 / 知识点名 / 题目关键词 / 别名表。
//    匹配不上时【不要编题】，如实说题库里没有，并列出有哪些章节。
//
// 3) 难度 1~5：1 = 会考基础、2 = 课后题、3 = 期末中档、4 = 期末压轴 / 竞赛入门、
//    5 = 考研 / 竞赛。用户不说难度就随机（1~5 等权重）。
//
// 4) 抽题要【避免连着重复】。最近发过的题号记在内存里，同一会话内不再重复抽到；
//    池子被抽空时自动放宽（先放宽难度、再放宽章节），并在返回里说明。
//
// 5) 答案默认【不给】。用户明确要答案（「答案呢」「给答案」「看看对不对」）时才附上，
//    避免一上来就看到答案。这个默认值可以在技能设置里改。

import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const SKILL_ID = 'math-bank';

const DEFAULTS = {
  enabled: true,
  defaultCount: 3,
  showAnswerByDefault: false,
  avoidRepeat: true
};

let api = null;
let bank = null;
let current = () => DEFAULTS;

/** 最近发过的题号（内存里，跨会话不保留；重启就清空，这是刻意的）。 */
const recentIds = [];
const RECENT_MAX = 40;

function pushRecent(id) {
  recentIds.push(id);
  while (recentIds.length > RECENT_MAX) recentIds.shift();
}

// ── 读题库 ────────────────────────────────────────────────────────────────

function loadBank() {
  if (bank) return bank;
  const file = path.join(HERE, 'bank.json');
  const raw = fs.readFileSync(file, 'utf8');
  bank = JSON.parse(raw);
  return bank;
}

function chapters() {
  return loadBank().chapters || [];
}

function problems() {
  return loadBank().problems || [];
}

function chapterById(id) {
  return chapters().find((c) => c.id === id) || null;
}

// ── 检索 ──────────────────────────────────────────────────────────────────

/** 把用户输入规范化：去空格、去标点、转小写，便于宽松匹配。 */
function norm(s) {
  return String(s ?? '')
    .toLowerCase()
    .replace(/[\s\u3000]+/g, '')
    .replace(/[，。、；：？！（）()【】\[\]"'`~!@#$%^&*_+=|\\/<>?.,:;-]/g, '');
}

/**
 * 从用户的自由说法里判断他想问哪一章。
 * 匹配顺序：章节 id > 章节名 > 章节别名 > 知识点名 > 题目关键词。
 * 返回 { id, reason } 或 null。
 */
function resolveChapter(topicRaw) {
  const t = norm(topicRaw);
  if (!t) return null;

  // ① 章节 id / 章节名 / 别名
  for (const c of chapters()) {
    if (t === norm(c.id) || t === norm(c.name)) return { id: c.id, reason: '章节名' };
    for (const a of c.aliases || []) {
      if (t === norm(a)) return { id: c.id, reason: '章节别名：' + a };
    }
  }
  // ② 包含式：用户说「极限那块」「求极限的题」
  let best = null;
  for (const c of chapters()) {
    const keys = [c.id, c.name, ...(c.aliases || [])];
    for (const k of keys) {
      const nk = norm(k);
      if (nk && nk.length >= 2 && t.includes(nk)) {
        if (!best || nk.length > best.len) best = { id: c.id, len: nk.length, reason: '章节关键词：' + k };
      }
    }
  }
  if (best) return { id: best.id, reason: best.reason };

  // ③ 知识点名 / 题目关键词（题库里真实的 topic 与 keywords）
  let best2 = null;
  for (const p of problems()) {
    const keys = [p.topic, ...(p.keywords || [])];
    for (const k of keys) {
      const nk = norm(k);
      if (nk && nk.length >= 2 && t.includes(nk)) {
        if (!best2 || nk.length > best2.len) best2 = { id: p.chapter, len: nk.length, reason: '知识点：' + k };
      }
    }
  }
  if (best2) return { id: best2.id, reason: best2.reason };

  return null;
}

/** 列出所有知识点（去重），供 chapters 工具与「匹配不上」时提示用。 */
function topicList(chapterId = null) {
  const set = new Set();
  for (const p of problems()) {
    if (chapterId && p.chapter !== chapterId) continue;
    if (p.topic) set.add(p.topic);
  }
  return [...set];
}

function shuffle(arr) {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

/**
 * 抽题。优先满足【章节 + 难度】，不够就按顺序放宽：
 *   章节+难度 → 章节（任意难度）→ 全库同难度 → 全库
 * 返回 { picked, relaxed }
 */
function pickProblems({ chapterId, difficulty, count, avoidRepeat }) {
  const all = problems();
  const notRecent = (p) => !(avoidRepeat && recentIds.includes(p.id));

  const tiers = [];
  if (chapterId && difficulty) tiers.push((p) => p.chapter === chapterId && p.difficulty === difficulty);
  if (chapterId) tiers.push((p) => p.chapter === chapterId);
  if (difficulty) tiers.push((p) => p.difficulty === difficulty);
  tiers.push(() => true);

  for (let i = 0; i < tiers.length; i++) {
    const pool = all.filter(tiers[i]).filter(notRecent);
    if (pool.length >= count) {
      return { picked: shuffle(pool).slice(0, count), relaxed: i > 0 ? i : 0 };
    }
    // 池子不够：若已经是最后一档，就退回允许重复
    if (i === tiers.length - 1) {
      const loose = all.filter(tiers[i]);
      if (loose.length >= count) return { picked: shuffle(loose).slice(0, count), relaxed: i };
      if (loose.length) return { picked: shuffle(loose), relaxed: i };
      return { picked: [], relaxed: i };
    }
  }
  return { picked: [], relaxed: 0 };
}

const DIFF_NAME = {
  1: '1 档（基础）',
  2: '2 档（课后题）',
  3: '3 档（期末中档）',
  4: '4 档（期末压轴）',
  5: '5 档（考研/竞赛）'
};

function formatProblems(picked, { withAnswer }) {
  const lines = [];
  picked.forEach((p, i) => {
    const ch = chapterById(p.chapter);
    lines.push(`【${i + 1}】${p.q}`);
    lines.push(`      · ${ch ? ch.name : p.chapter} · ${p.topic} · ${DIFF_NAME[p.difficulty] || p.difficulty + ' 档'} · 题号 ${p.id}`);
    if (withAnswer && p.a) lines.push(`      ✅ 答案：${p.a}`);
  });
  return lines.join('\n');
}

// ── 工具实现 ──────────────────────────────────────────────────────────────

/**
 * 成功：必须返回 { content } —— 这是与内置工具同款的返回格式。
 * content 里放一行 JSON，模型读里面的 text 来说话。
 * ⚠️ 之前写成了 { ok: true, ...payload }，工具结果里没有 content 字段，
 *    模型收到的是空结果，表现为「工具直接报错、什么都没有」。
 */
function ok(payload) {
  return { content: JSON.stringify(payload) };
}
/** 失败：isError 让模型知道这是「不能继续」而不是「结果就是这个」。 */
function err(message) {
  return { content: `错误：${message}`, isError: true };
}

function doChapters() {
  try {
    const list = chapters().map((c) => {
      const n = problems().filter((p) => p.chapter === c.id).length;
      const topics = topicList(c.id);
      return `· ${c.name}（${c.id}，共 ${n} 题）\n    知识点：${topics.join('、')}`;
    });
    const total = problems().length;
    return ok({
      total,
      text: `📚 题库共 ${total} 道题，分 ${chapters().length} 章：\n\n${list.join('\n')}\n\n`
        + '用法：说「来三道 <章节/知识点> 的题，<1~5> 档」即可。'
    });
  } catch (e) {
    return err('读题库失败：' + (e && e.message ? e.message : e));
  }
}

function doSearch(args = {}) {
  const conf = current();
  const topicRaw = String(args.topic ?? args.chapter ?? '').trim();
  let difficulty = Number(args.difficulty);
  if (!Number.isFinite(difficulty) || difficulty < 1 || difficulty > 5) difficulty = 0;
  let count = Number(args.count);
  if (!Number.isFinite(count) || count < 1) count = conf.defaultCount || 3;
  count = Math.min(Math.max(Math.round(count), 1), 10);
  const withAnswer = args.withAnswer === true
    || (args.withAnswer === undefined && conf.showAnswerByDefault === true);

  let chapterId = null;
  let matchReason = '';
  if (topicRaw) {
    const hit = resolveChapter(topicRaw);
    if (!hit) {
      const allTopics = topicList();
      return ok({
        matched: false,
        text: `题库里没找到和「${topicRaw}」匹配的章节或知识点 🤔\n\n`
          + `现在有这些章节：\n${chapters().map((c) => '· ' + c.name).join('\n')}\n\n`
          + `知识点（部分）：${allTopics.slice(0, 40).join('、')}\n\n`
          + '换个说法再试试（比如「极限」「中值定理」「不定积分」）。',
        note: '题库里没有匹配项。不要自己编题，把这段如实发给用户即可。'
      });
    }
    chapterId = hit.id;
    matchReason = hit.reason;
  }

  const { picked, relaxed } = pickProblems({
    chapterId,
    difficulty: difficulty || null,
    count,
    avoidRepeat: conf.avoidRepeat !== false
  });

  if (!picked.length) {
    return ok({ matched: false, text: '题库里暂时没有符合条件的题目。', note: '如实告知，不要编题。' });
  }

  picked.forEach((p) => pushRecent(p.id));

  const chName = chapterId ? (chapterById(chapterId) || {}).name : '不限章节';
  const diffName = difficulty ? DIFF_NAME[difficulty] : '不限难度';
  const relaxNote = relaxed === 1 ? '\n（该难度下题不够，已放宽到同一章的其它难度）'
    : relaxed === 2 ? '\n（该难度下题不够，已放宽到全库同难度）'
      : relaxed >= 3 ? '\n（符合条件的题不够，已放宽到全库）' : '';

  const head = `📝 给你 ${picked.length} 道题 —— ${chName} · ${diffName}${matchReason ? `（识别为 ${matchReason}）` : ''}${relaxNote}`;
  const body = formatProblems(picked, { withAnswer });

  return ok({
    matched: true,
    chapter: chapterId,
    difficulty: difficulty || null,
    count: picked.length,
    ids: picked.map((p) => p.id),
    withAnswer,
    text: `${head}\n\n${body}\n\n需要答案就说「给答案」，想换一批说「再来三道」。`,
    note: 'text 就是最终消息，原样发出去即可。默认不给答案；用户要答案时再调一次并传 withAnswer=true。'
      + '不要自己改题目数字、不要自己编新题。'
  });
}

// ── 注册 ──────────────────────────────────────────────────────────────────

export function setup(registerApi) {
  api = registerApi;
  // 读设置的正确姿势：api.config 是一个【函数】，调用它才拿到本技能的设置对象。
  // （api 上【没有】tools 字段，也没有 settings(id) 方法。）
  current = typeof api?.config === 'function' ? api.config : () => ({ ...DEFAULTS });

  api.registerTool({
    id: 'chapters',
    name: '高数题库：看有哪些章节',
    description: '列出题库里的章节与知识点（含每章题量）。用在：用户只想随便看看、或者不知道题库有什么、'
      + '或者上一次检索没匹配上时。不需要参数。',
    category: 'knowledge',
    icon: '📚',
    parameters: { type: 'object', properties: {} },
    execute() {
      try { return doChapters(); } catch (e) { return err('失败：' + (e && e.message ? e.message : e)); }
    }
  });

  api.registerTool({
    id: 'search',
    name: '高数题库：按章节和难度抽题',
    description: '按【章节/知识点】和【难度 1~5】从本地题库抽题，默认 3 道。'
      + 'topic 填用户说的章节或知识点原话（如「极限」「中值定理」「不定积分」「洛必达」），可留空表示不限。'
      + 'difficulty 填 1~5，可留空。count 默认取技能设置（3）。'
      + 'withAnswer 默认 false —— 只有用户明确要答案时才传 true。'
      + '返回的 text 是最终消息，原样发出；题目一律来自题库，绝不要自己编。',
    category: 'knowledge',
    icon: '📝',
    parameters: {
      type: 'object',
      properties: {
        topic: { type: 'string', description: '章节或知识点，用户的原话即可，如「极限」「中值定理」。留空=不限章节' },
        difficulty: { type: 'integer', description: '难度 1~5（1 基础 / 2 课后题 / 3 期末中档 / 4 期末压轴 / 5 考研竞赛）。留空=不限' },
        count: { type: 'integer', description: '要几道，默认 3，最多 10' },
        withAnswer: { type: 'boolean', description: '是否附答案，默认 false。用户要答案时才传 true' }
      }
    },
    execute(ctx, args) {
      try { return doSearch(args ?? {}); } catch (e) { return err('检索失败：' + (e && e.message ? e.message : e)); }
    }
  });
}

/** 动态提示词：只在开了这个技能时注入。 */
export function promptSections() {
  return [{
    id: `${SKILL_ID}-usage`,
    title: '高数题库',
    priority: 42,
    content: '本机装了「高数题库」技能（两个工具：`math-bank__search`、`math-bank__chapters`）。\n\n'
      + '**什么时候用**：有人想要高数练习题 —— 「来三道极限的题」「中值定理 4 档」「出几道不定积分」'
      + '「有没有难一点的题」「刷题」「练手」。闲聊、问概念、让讲题时【不要】用（那是讲题，不是抽题）。\n\n'
      + '**怎么用**：\n'
      + '① 先弄清两件事：**要哪一章/哪个知识点**、**几档难度（1~5）**。用户没说的就问一句'
      + '（「想练哪块？难度 1~5 挑一个」），别自己替他定。用户说「随便」就直接 `math-bank__search` 不传 topic。\n'
      + '② 调 `math-bank__search`（topic=用户说的章节原话，difficulty=1~5，count 默认 3）。\n'
      + '③ **把返回的 `text` 原样发出去**，它是排好版的最终消息。不要自己重排、不要增删题目。\n'
      + '④ 用户说「给答案」「看看对不对」→ 再调一次 `math-bank__search` 并传 `withAnswer=true`；'
      + '或者直接照上次那几道题的答案回答（工具返回里有 a 字段的题目才会附答案）。\n\n'
      + '**硬规矩**：\n'
      + '· 题目**只能来自题库**。返回 matched=false（没匹配上）时，把提示原样发给用户，'
      + '**绝对不要自己编题、编答案** —— 数学题答案错了比没有题更糟。\n'
      + '· 不要改题号、不要改数字、不要「顺手把题目变简单一点」。\n'
      + '· 用户要难度档以外的说法（「简单点」「来点难的」）→ 映射成 1~2 档 / 4~5 档，'
      + '并在回复里说清你按几档抽的。\n'
      + '· 用户说「再来三道」→ 再调一次（同一个 topic/difficulty 即可），技能会自动避开刚发过的题。'
  }];
}

export function dispose() {
  api = null;
  bank = null;
  recentIds.length = 0;
  current = () => DEFAULTS;
}

export { DEFAULTS };
