// 碧蓝幻想 · GameWith 查译 —— LLM 型技能（skills/）
//
// 只做一件事：**在 GameWith 上查碧蓝幻想资料，抓日文正文，交给模型翻成中文回答**，
// 并把条目里的图片/链接给出来发到群里。不做中文维基、不做别的站。
//
// 为什么需要"条目 ID"这一步（本机实测）：
//   · GameWith 的条目页是**服务端渲染**的，正文 1 万字量级，技能/奥义/被动/使用间隔
//     全在 <div class="gbf-table_abi2"><table> 里 —— 抓取没问题。
//   · 但 GameWith **没有可用的站内搜索**：/search、/search/index、/api/search、
//     /article/search_result 等一律 405 或只回站点外壳；/search/results?query= 是
//     纯客户端渲染（四个不同关键词返回完全相同的链接集）。sitemap 只有 6500 条
//     article/show/<数字>，**不含任何标题**，没法反查名字。
//   因此工具的设计是：
//     ① 能拿到 ID（模型参数 / 群友贴的链接 / 已记住的映射）→ 直接抓取翻译；
//     ② 拿不到 ID → 返回一段明确的"去搜什么"的指引 + 已知的相近条目，
//        由模型调它自己的 web_search 找到 article/show/<数字>，再调一次本工具。
//     ③ 每次成功都会把 "日文名 → 条目 ID + 标题" 记进 <数据目录> 与技能目录下的
//        id-map.json，所以同一个角色只需要搜一次。
//
// 翻译工作交给模型（它比规则代码更会翻），本工具只负责：找对页面、把正文清干净、
// 把图片直链挑出来、并防止"抓不到就编"。

import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36';
const DEFAULT_BASE = 'https://xn--bck3aza1a2if6kra4ee0hf.gamewith.jp';

let cfg = () => ({});

// ══════════════════════════════════════════════════════════════════════
//  一、群里的叫法 → 日文名（含 GBF 黑话）
//     用途有两个：给 web_search 提供正确的日文关键词、以及去 id-map 里查已记住的 ID。
// ══════════════════════════════════════════════════════════════════════
const NAME_JA = {
  // 六属黑话
  '火': '火', '火属性': '火', '水': '水', '水属性': '水', '土': '土', '土属性': '土',
  '风': '風', '风属性': '風', '光': '光', '光属性': '光', '暗': '闇', '暗属性': '闇',
  // 武器盘 / 机制
  '方阵': 'マグナ', '方阵盘': 'マグナ', '马格纳': 'マグナ', '主神': '神石', '神石盘': '神石',
  '老王': '神石', '武器盘': '武器編成', '盘子': '武器編成', '编成': '編成', '配队': '編成',
  '奥义': '奥義', '奥义回转': '奥義回転', '被动': 'サポアビ', '技能': 'アビリティ',
  '特动': '特殊行動', '特动表': '特殊行動', '特殊行动': '特殊行動',
  '上限解放': '上限解放', '终突': '最終上限解放', '觉醒': '覚醒', '限界超越': '限界超越',
  '超越': '限界超越', '天星器': '天星器', '十天众': '十天衆', '十天': '十天衆',
  '十贤者': '十賢者', '塔罗': 'タロット', '塔罗牌': 'タロット', '转世': 'ルピ',
  '六龙': '六竜', '加护': '加護', '得意武器': '得意武器', '古战场': '古戦場', '团战': '古戦場',
  '天井': '天井', '井': '天井', '抽卡': 'ガチャ', '职业': 'ジョブ', '攻略': '攻略',
  // 召唤石 / 星晶兽
  '巴哈': 'バハムート', '巴哈姆特': 'バハムート', '大巴': 'バハムート', '大巴哈': 'バハムート',
  '路西': 'ルシファー', '路西法': 'ルシファー', '路西弗': 'ルシファー', '鲁西法': 'ルシファー',
  '贝爷': 'ベルゼバブ', '贝利尔': 'ベルゼバブ', '贝尔杰布': 'ベルゼバブ', '巴布': 'ベルゼバブ',
  '撒旦': 'サタン', '佐伊': 'ゾーイ', '格兰迪': 'グランデ', '湿婆': 'シヴァ',
  '梅塔': 'メタトロン', '梅塔特隆': 'メタトロン', '卡俄斯': 'カオス', '宙斯': 'ゼウス',
  '哈迪斯': 'ハーデス', '提妈': 'ティアマト', '提亚马特': 'ティアマト',
  '科罗': 'コロッサス', '科罗萨斯': 'コロッサス', '雷维': 'リヴァイアサン', '利维坦': 'リヴァイアサン',
  '尤格': 'ユグドラシル', '尤格多拉希尔': 'ユグドラシル', '阿波罗': 'アポロン',
  '加百列': 'ガブリエル', '米迦勒': 'ミカエル', '拉斐尔': 'ラファエル', '乌列尔': 'ウリエル',
  '欧罗巴': 'ヨーロッパ', '阿卡夏': 'アーカーシャ', '阿凡达': 'アバター',
  '格利姆': 'グリームニル', '格利姆尼尔': 'グリームニル', '欧西里斯': 'オシリス',
  '赫克托尔': 'ヘクトル', '加兰': 'ガルーダ', '普罗米修斯': 'プロメテウス',
  // 高难度 Boss
  '路西HL': 'ルシファーHL', '路西法HL': 'ルシファーHL', '超路西': 'ルシファーHL',
  '路西法零': 'ルシファー・ゼロ', '零路西': 'ルシファー・ゼロ',
  '贝利尔HL': 'ベルゼバブHL', '巴布HL': 'ベルゼバブHL', '超贝': 'ベルゼバブHL',
  '阿卡夏HL': 'アーカーシャHL', '六龙': '六竜', '方阵HL': 'マグナHL',
  // 主人公一行
  '姬塔': 'ジータ', '吉塔': 'ジータ', '女主人公': 'ジータ', '古兰': 'グラン', '男主人公': 'グラン',
  '露莉亚': 'ルリア', '露利亚': 'ルリア', '碧': 'ビィ',
  '卡塔莉娜': 'カタリナ', '卡姐': 'カタリナ', '卡塔': 'カタリナ',
  '伊欧': 'イオ', '伊奥': 'イオ', '拉卡姆': 'ラカム', '拉卡': 'ラカム',
  '欧根': 'オイゲン', '奥根': 'オイゲン', '罗塞塔': 'ロゼッタ', '罗泽塔': 'ロゼッタ',
  '莉夏': 'リシャ', '德兰克': 'ドランク', '娜露梅亚': 'ナルメア', '娜露梅': 'ナルメア',
  '齐格飞': 'ジークフリート', '齐格': 'ジークフリート', 'ジーク': 'ジークフリート',
  '夏洛特': 'シャルロッテ', '夏洛': 'シャルロッテ', '克拉丽丝': 'クラリス',
  '瑟蕾菲拉': 'セレフィラ', '薇拉': 'ヴィーラ', '法斯蒂瓦': 'ファスティバ',
  '兰斯洛特': 'ランスロット', '兰斯': 'ランスロット', '贝恩': 'ベイン', '希尔瓦': 'シルヴァ',
  '尤艾尔': 'ユエル', '索希耶': 'ソシエ', '亚丽莎': 'アリーザ', '露娜': 'ルナ',
  '安苏莉娅': 'アンスリア', '阿妮拉': 'アニラ', '阿妮娜': 'アニラ', '猴': 'アニラ',
  '安琪拉': 'アンチラ', '羊': 'アンチラ', '玛琪拉': 'マキラ', '库库鲁': 'ククル',
  '斑比': 'ヴァンピィ', '瓦妮': 'ヴァンピィ', '卡莉奥斯特萝': 'カリオストロ', '卡莉': 'カリオストロ',
  '黑骑士': '黒騎士', '白骑士': '白騎士', '贝阿特丽丝': 'ベアトリクス', '贝阿朵': 'ベアトリクス',
  '莫妮卡': 'モニカ', '奥莉薇': 'オリヴィエ', '奥利维亚': 'オリヴィエ',
  '尤斯提斯': 'ユーステス', '伊尔莎': 'イルザ', '卡因': 'カイン', '艾瑟尔': 'エッセル',
  '萨拉': 'サラ', '缇娜': 'ティナ', '阿米拉': 'アーミラ', '蕾娜': 'レナ', '菲莉': 'フェリ',
  '多萝西': 'ドロシー', '阿露露梅亚': 'アルルメイヤ', '佩可莉姆': 'ペコリーヌ',
  '芙莉亚': 'フュリアス', '莉娜': 'リナ', '莉露露': 'リルル', '索恩': 'ソーン',
  // 十天众（常按序号叫）
  '乌诺': 'ウーノ', '1爷': 'ウーノ', '一爷': 'ウーノ', '索恩': 'ソーン', '2姐': 'ソーン',
  '二姐': 'ソーン', '萨拉萨': 'サラーサ', '3妹': 'サラーサ', '三妹': 'サラーサ',
  '卡托尔': 'カトル', '4弟': 'カトル', '四弟': 'カトル', '芬芙': 'フュンフ', '5妹': 'フュンフ',
  '五妹': 'フュンフ', '希耶提': 'シエテ', '6爷': 'シエテ', '六爷': 'シエテ',
  '尼欧': 'ニオ', '7妹': 'ニオ', '七妹': 'ニオ', '奥克托': 'オクトー', '8爷': 'オクトー',
  '八爷': 'オクトー', '图艾尔': 'トゥエルヴ', '10姐': 'トゥエルヴ', '十姐': 'トゥエルヴ',
};

/** 圈内黑话释义：命中时直接把解释给模型，避免去查一个不存在的条目 */
const SLANG = {
  '天井': '抽卡保底（累计 300 抽可指定换取）',
  '井': '抽卡保底（累计 300 抽可指定换取）',
  '古战场': '公会战（古戦場），按属性轮换的团战活动',
  '团战': '公会战（古戦場）',
  '英雄': '古战场个人排名奖励（英雄級）',
  '方阵': 'マグナ系列武器盘（靠免费武器凑的盘）',
  '主神': '神石系列武器盘（靠扭蛋武器/神石加护，成本高上限高）',
  '奥义回转': '让奥义槽快速攒满、频繁放奥义的编成思路',
  '特动': '敌人特殊行动（特殊行動），Boss 在特定条件下放的技能',
  '特动表': '敌人特殊行动一览（血量/CT 触发的行动顺序表）',
  'fa': '全自动战斗（フルオート）',
  'phf': '骑空团/公会相关黑话（团内约人开黑）',
  '开黑': '组团一起打副本',
  '6人': '六人副本（マルチバトル）',
  '18人': '十八人副本（グランドマルチバトル）',
  '水着': '泳装版本（限定皮肤角色）',
  '浴衣': '浴衣版本（限定皮肤角色）',
  '普池': '常驻卡池角色',
  '天司': '天司武器/天司系列',
  '星幽': '星幽武器系列',
  '巴布塔': 'バブ・イール塔（爬塔活动）',
  'relink': 'Granblue Fantasy Relink',
  'vs': 'Granblue Fantasy Versus',
};

// ══════════════════════════════════════════════════════════════════════
//  二、目录与缓存
// ══════════════════════════════════════════════════════════════════════
function dataDir() {
  const base = process.env.QQ_AGENT_DATA_DIR
    || path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..', '..', '..', '..', 'data');
  return path.join(base, 'gbf-gamewith');
}

const skillDir = () => path.dirname(fileURLToPath(import.meta.url));

/** <数据目录>/gbf-gamewith/：页面缓存 + 记忆到的条目映射 */
const cachePath = () => path.join(dataDir(), 'cache.json');
const mapPath = () => path.join(dataDir(), 'id-map.json');
/** 技能目录下的 id-map.json：跟着技能一起，方便你自己查看/手工补条目 */
const skillMapPath = () => path.join(skillDir(), 'id-map.json');

let cache = null;

function loadCache() {
  if (cache) return cache;
  try {
    const raw = JSON.parse(fs.readFileSync(cachePath(), 'utf8'));
    cache = (raw && typeof raw === 'object' && !Array.isArray(raw)) ? raw : {};
  } catch { cache = {}; }
  return cache;
}

function saveCache() {
  try {
    fs.mkdirSync(dataDir(), { recursive: true });
    const p = cachePath();
    fs.writeFileSync(`${p}.tmp`, JSON.stringify(cache), 'utf8');
    fs.renameSync(`${p}.tmp`, p);   // 原子写：断电不会留下半截 JSON 毁掉整个缓存
  } catch { /* 写不进去不该让这次查询失败 */ }
}

function cacheGet(key, ttlMinutes) {
  const c = loadCache()[key];
  if (!c) return null;
  if (ttlMinutes > 0 && Date.now() - c.at > ttlMinutes * 60000) return null;
  return c.value;
}

function cacheSet(key, value) {
  const c = loadCache();
  c[key] = { at: Date.now(), value };
  saveCache();
}

function readJson(file, fallback) {
  try {
    const raw = JSON.parse(fs.readFileSync(file, 'utf8'));
    return (raw && typeof raw === 'object' && !Array.isArray(raw)) ? raw : fallback;
  } catch { return fallback; }
}

/**
 * 已记住的「日文名 → { id, title, at }」。
 * 两个来源：技能目录里的 id-map.json（可手工编辑/长期保留） +
 * 数据目录缓存里的自动记录（运行时学习到的，更新更勤）。
 */
function knownIds() {
  const fromCache = cacheGet('gw-id-map', 0) || {};
  const fromSkill = readJson(skillMapPath(), {});
  // 缓存里的（更新的）优先
  const merged = { ...fromSkill, ...fromCache };
  const out = {};
  for (const [k, v] of Object.entries(merged)) {
    if (k.startsWith('_')) continue;   // id-map.json 里的说明项，不是条目
    if (v && typeof v === 'object' && /^\d+$/.test(String(v.id || ''))) out[k] = v;
  }
  return out;
}

function rememberId(jaName, id, title) {
  if (!jaName || !/^\d+$/.test(String(id || ''))) return;
  const map = cacheGet('gw-id-map', 0) || {};
  map[jaName] = { id: String(id), title: String(title || '').slice(0, 120), at: Date.now() };
  cacheSet('gw-id-map', map);
}

// ══════════════════════════════════════════════════════════════════════
//  三、抓页面
// ══════════════════════════════════════════════════════════════════════
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

async function fetchPage(url, { api, timeoutMs = 20000, cacheMinutes = 720, method = 'GET' } = {}) {
  const key = `${method}:${url}`;
  const cached = cacheGet(key, cacheMinutes);
  if (cached) return { ...cached, cached: true };

  let res;
  try {
    const ac = new AbortController();
    const timer = setTimeout(() => ac.abort(), Math.max(2000, timeoutMs));
    let r;
    try {
      r = await api.fetch(url, {
        method,
        signal: ac.signal,
        redirect: 'follow',
        headers: {
          'User-Agent': UA,
          'Accept': 'text/html,application/xhtml+xml,image/*,*/*;q=0.8',
          'Accept-Language': 'ja,zh-CN;q=0.9,zh;q=0.8',
        },
      });
    } finally { clearTimeout(timer); }

    const status = r.status;
    const ctype = String(r.headers?.get?.('content-type') || '');

    if (method === 'HEAD') {
      res = { ok: r.ok && /^image\//i.test(ctype), status, blocked: status === 403 || status === 401, html: '', text: '', contentType: ctype };
    } else {
      const html = await r.text();
      const head = html.slice(0, 4000).toLowerCase();
      const challenged = /just a moment|cf-challenge|cf_chl|请稍候|人机验证|安全验证/.test(head);
      const usable = r.ok && !challenged && html.length > 0;
      res = {
        ok: usable,
        status,
        blocked: challenged || status === 403 || status === 401,
        html: usable ? html : '',      // 被挡时不留 HTML，避免把挑战页当资料
        text: usable ? htmlToText(html) : '',
        contentType: ctype,
      };
    }
  } catch (error) {
    const msg = String(error?.message ?? error);
    res = { ok: false, status: 0, blocked: false, html: '', text: '', error: /abort/i.test(msg) ? `请求超时（${timeoutMs}ms）` : msg };
  }
  cacheSet(key, res);
  return res;
}

/** HTML → 纯文本 */
function htmlToText(html) {
  return String(html)
    .replace(/<!--[\s\S]*?-->/g, ' ')
    .replace(/<script[\s\S]*?<\/script>/gi, ' ')
    .replace(/<style[\s\S]*?<\/style>/gi, ' ')
    .replace(/<noscript[\s\S]*?<\/noscript>/gi, ' ')
    .replace(/<br\s*\/?>/gi, '\n')
    .replace(/<\/(p|div|li|tr|h[1-6]|td|th|section|article|dd|dt)>/gi, '\n')
    .replace(/<[^>]+>/g, ' ')
    .replace(/&nbsp;/gi, ' ')
    .replace(/&amp;/gi, '&')
    .replace(/&quot;/gi, '"')
    .replace(/&#0?39;|&apos;/gi, "'")
    .replace(/&lt;/gi, '<')
    .replace(/&gt;/gi, '>')
    .replace(/[ \t\u00a0]+/g, ' ')
    .replace(/\n[ \t]+/g, '\n')
    .replace(/\n{3,}/g, '\n\n')
    .trim();
}

/** 表格 → 一行一条，列用「｜」分隔（技能效果/数值这样最好读） */
function tableToText(tableHtml) {
  const rows = [];
  for (const tr of String(tableHtml).matchAll(/<tr[^>]*>([\s\S]*?)<\/tr>/gi)) {
    const cells = [...tr[1].matchAll(/<(th|td)[^>]*>([\s\S]*?)<\/\1>/gi)]
      .map((c) => htmlToText(c[2]).replace(/\n+/g, ' ').trim())
      .filter((s, i, a) => s || a.length === 1);
    if (cells.length) rows.push(cells.join(' ｜ '));
  }
  return rows.join('\n');
}

// ══════════════════════════════════════════════════════════════════════
//  四、GameWith 正文与图片
// ══════════════════════════════════════════════════════════════════════
/**
 * 抽正文：按 h2/h3 切块，优先保留「评价/点数/奥义/アビリティ/サポ/攻略/素材/特动」，
 * 块内表格转文本。实测能把技能名、效果倍率、上限、使用间隔、被动完整带出来。
 */
function extractBody(html, { maxChars = 6000 } = {}) {
  const h = String(html || '').replace(/<!--[\s\S]*?-->/g, ' ');
  const heads = [...h.matchAll(/<h([23])[^>]*>([\s\S]*?)<\/h\1>/gi)];
  const chunks = [];
  for (let i = 0; i < heads.length; i++) {
    const title = htmlToText(heads[i][2]).replace(/\s+/g, ' ').trim();
    if (!title || /^目次$/.test(title)) continue;
    const start = heads[i].index + heads[i][0].length;
    const end = i + 1 < heads.length ? heads[i + 1].index : Math.min(h.length, start + 20000);
    const seg = h.slice(start, end);
    const tables = [...seg.matchAll(/<table[^>]*>([\s\S]*?)<\/table>/gi)].map((m) => tableToText(m[0]));
    const plain = htmlToText(seg);
    if (tables.length || plain.length > 60) chunks.push({ title, tables, text: plain });
  }

  // 技能/数值类优先，其次是评价与运用
  const skill = /奥義|アビ|能力|サポ|スキル|効果|特動|特殊行動|ステータス|LB|リミットボーナス|覚醒/i;
  const other = /評価|点数|評点|強い点|弱い点|使い方|運用|性能|編成|攻略|ドロップ|素材|入手/i;
  const picked = [...chunks.filter((c) => skill.test(c.title)), ...chunks.filter((c) => !skill.test(c.title) && other.test(c.title))];
  const use = picked.length ? picked : chunks;

  const out = [];
  let len = 0;
  for (const c of use) {
    out.push(`## ${c.title}`);
    const part = c.tables.length ? c.tables.join('\n') : c.text.slice(0, 1200);
    out.push(part);
    len += c.title.length + part.length;
    if (len > maxChars) break;
  }
  let body = out.join('\n').trim();

  // 分段抽取很少时（列表/总览类页面常见），改用全文 —— 但要先用正文首块标题
  // 当锚点把前面的站点导航裁掉，否则会把菜单当资料交给模型
  if (body.length < 1200) {
    let full = htmlToText(h);
    const anchor = chunks.find((c) => c.title && c.title.length >= 4)?.title;
    if (anchor) {
      const i = full.indexOf(anchor);
      if (i > 0) full = full.slice(i);
    }
    if (full.length > body.length) body = full;
  }

  if (body.length < 200) {
    // 站点结构变了就退回"含技能关键词的表格"
    const tables = [...h.matchAll(/<table[^>]*>([\s\S]*?)<\/table>/gi)]
      .map((m) => tableToText(m[0]))
      .filter((t) => /奥義|アビリティ|効果|使用間隔/.test(t));
    if (tables.length) body = tables.join('\n\n').trim();
  }
  return body.slice(0, maxChars);
}

const BAD_IMG = /logo|icon|banner|sprite|btn_|common\/|avatar_default|transparent1px|article_tools|\/rank_|\/gacha\/|_s\.png$|_ss\.png$|ad_|widget/i;

/** 挑可发的图片直链：懒加载真地址优先，50x50 小图标降级 */
function pickImages(html, baseUrl, { max = 3 } = {}) {
  const found = [];
  const push = (raw, score) => {
    let u = String(raw || '').replace(/&amp;/g, '&').trim();
    if (!u) return;
    if (!/^https?:\/\//i.test(u)) { try { u = new URL(u, baseUrl).href; } catch { return; } }
    if (/\.(svg|ico)(\?|$)/i.test(u)) return;
    if (BAD_IMG.test(u)) return;
    if (found.some((x) => x.u === u)) return;
    found.push({ u, score });
  };
  const h = String(html || '').replace(/<!--[\s\S]*?-->/g, ' ');
  // 懒加载真地址
  for (const m of h.matchAll(/data-(?:original|src)=["']([^"']+)["']/gi)) {
    const small = /width=50px|height=50px/i.test(m[0]);   // 技能小图标
    push(m[1], small ? 40 : 80);
  }
  // 普通 img
  for (const m of h.matchAll(/<img[^>]+src=["']([^"']+)["']/gi)) push(m[1], 60);

  found.sort((a, b) => b.score - a.score);
  return found.slice(0, Math.max(0, max)).map((x) => x.u);
}

// ══════════════════════════════════════════════════════════════════════
//  五、辅助
// ══════════════════════════════════════════════════════════════════════
const norm = (s) => String(s || '').replace(/[（(][^）)]*[）)]/g, '').replace(/[\s　・:：\-—_]/g, '').toLowerCase();

/** 黑话/俗称 → 日文名（查不到返回空串） */
function jaNameOf(query) {
  const q = String(query || '').trim();
  if (!q) return '';
  if (NAME_JA[q]) return NAME_JA[q];
  const bare = q.replace(/[（(][^）)]*[）)]/g, '').replace(/[的了吗呢啊]+$/, '').trim();
  if (NAME_JA[bare]) return NAME_JA[bare];
  // 带后缀的（路西法HL / 斑比泳装）先剥后缀再查
  const stem = bare.replace(/(ssr|sr|ur|hl|零|泳装|水着|浴衣|圣诞|限定|终突|觉醒)$/i, '').trim();
  if (stem && NAME_JA[stem]) {
    const suffix = bare.slice(stem.length);
    return NAME_JA[stem] + (/hl/i.test(suffix) ? 'HL' : '');
  }
  const lower = bare.toLowerCase();
  for (const k of Object.keys(NAME_JA).filter((x) => x.length >= 3).sort((a, b) => b.length - a.length)) {
    if (lower.includes(k.toLowerCase())) return NAME_JA[k];
  }
  return '';
}

function slangOf(query) {
  const q = String(query || '').trim().toLowerCase();
  if (!q) return '';
  if (SLANG[q]) return SLANG[q];
  for (const [k, v] of Object.entries(SLANG)) {
    if (k.length >= 2 && q.includes(k.toLowerCase())) return v;
  }
  return '';
}

const num = (v, def, lo, hi) => {
  const n = Number(v);
  return Math.max(lo, Math.min(hi, Number.isFinite(n) ? n : def));
};

/** 从文本里取 GameWith 条目 ID（支持整条链接、纯数字、article/show/<id>） */
function idFrom(text) {
  const s = String(text || '').trim();
  const m = s.match(/article\/show\/(\d+)/i) || s.match(/^(?:id[:\s]*)?(\d{3,})$/i);
  return m ? m[1] : '';
}

const pageUrl = (base, id) => `${String(base || DEFAULT_BASE).replace(/\/+$/, '')}/article/show/${id}`;

/** 这个条目是不是碧蓝幻想的（防止 ID 记错时抓到别的游戏） */
const looksGranblue = (title) => /グラブル|グランブルーファンタジー/.test(String(title || ''));

const RECENT_KEY = 'gw-recent';

function rememberRecent(entry) {
  const list = cacheGet(RECENT_KEY, 0) || [];
  const next = [{ ...entry, at: Date.now() }, ...list.filter((x) => x.id !== entry.id)].slice(0, 30);
  cacheSet(RECENT_KEY, next);
}

// ══════════════════════════════════════════════════════════════════════
//  六、结果渲染
// ══════════════════════════════════════════════════════════════════════
function renderFound({ query, jaName, slang, url, title, body, images, fromCache }) {
  const L = [];
  L.push(`【来源】GameWith（ゲームウィズ）日文攻略`);
  L.push(`【条目】${title || jaName || query}`);
  L.push(`【链接】${url}`);
  if (jaName) L.push(`【日文名】${jaName}`);
  if (slang) L.push(`【圈内说法】「${query}」= ${slang}`);
  if (fromCache) L.push('（本条来自缓存，未重新请求站点）');
  L.push('');
  L.push('【日文正文】（请**翻译成中文**后回答；技能名/奥义名/特动名可保留日文并加中文解释）');
  L.push(body || '(没有抽取到可用正文)');
  L.push('');
  if (images.length) {
    L.push('【可直接发送的图片直链】(用 send_image 发到群里；建议先 preview=true 看一眼再发)');
    images.forEach((u, i) => L.push(`${i + 1}. ${u}`));
  } else {
    L.push('【图片】这个条目里没找到可发的图片。');
  }
  L.push('');
  L.push('【回答要求】先用一句中文给结论，再给关键数据（技能效果/倍率/上限/CD/被动），'
    + '最后附上上面的 GameWith 链接。不要整段照贴日文，也不要把原文里没有的数值写进去。');
  return L.join('\n');
}

function renderNeedId({ query, jaName, slang, known, recent }) {
  const L = [];
  L.push(`【查询】${query}`);
  if (jaName) L.push(`【日文名】${jaName}`);
  if (slang) L.push(`【圈内说法】「${query}」= ${slang}`);
  L.push('');
  L.push('【状态】没有 GameWith 条目 ID，无法抓取正文。');
  L.push('');
  L.push('【下一步：用内置 web_search 搜一次，再把数字填回来】');
  const kw = jaName || query;
  L.push(`· 建议查询词：gamewith グラブル ${kw} 評価`);
  L.push(`· 找不到就换：gamewith グラブル ${kw} 攻略 編成`);
  L.push('· 从结果里找形如 gamewith.jp/article/show/<数字> 的链接，把那个数字填进 articleId，再次调用本工具。');
  L.push('· 群友直接贴了 GameWith 链接时：把链接整条填进 query 即可，本工具会自动识别。');
  L.push('· 只搜一两次就够；两次都没有，就如实告诉群友没查到，**不要凭印象编技能数值**。');

  const keys = Object.keys(known);
  if (keys.length) {
    L.push('');
    L.push(`【已记住的条目】共 ${keys.length} 个（可直接用 jaName 字段填这些名字跳过搜索）`);
    const hit = jaName ? keys.filter((k) => k.includes(jaName) || jaName.includes(k)).slice(0, 5) : [];
    const show = (hit.length ? hit : keys.slice(0, 10));
    for (const k of show) L.push(`· ${k} → articleId ${known[k].id}${known[k].title ? `（${known[k].title}）` : ''}`);
  } else {
    L.push('');
    L.push('【已记住的条目】暂无。成功查到一次后，同一个角色下次就不用再搜了。');
  }

  if (recent && recent.length) {
    L.push('');
    L.push('【最近查过的条目】');
    for (const r of recent.slice(0, 8)) L.push(`· ${r.name || r.id} → articleId ${r.id}${r.title ? `（${r.title}）` : ''}`);
  }
  return L.join('\n');
}

function renderList({ known, recent }) {
  const L = [];
  L.push('【已记住的 GameWith 条目】（日文名 → 条目 ID；可直接把这些名字填进 jaName，或把 ID 填进 articleId）');
  const keys = Object.keys(known);
  if (!keys.length) L.push('（暂无。先在群里查一次，或在技能目录的 id-map.json 里手工补）');
  else for (const k of keys) L.push(`· ${k} → ${known[k].id}${known[k].title ? `（${known[k].title}）` : ''}`);
  if (recent && recent.length) {
    L.push('');
    L.push('【最近查过】');
    for (const r of recent.slice(0, 10)) L.push(`· ${r.name || r.id} → ${r.id}${r.title ? `（${r.title}）` : ''}`);
  }
  return L.join('\n');
}

// ══════════════════════════════════════════════════════════════════════
//  七、技能入口
// ══════════════════════════════════════════════════════════════════════
export async function setup(api) {
  cfg = () => api.config() || {};
  api.log('GameWith 查译技能已加载（只查 GameWith；需要条目 ID，工具会指引模型去搜）');

  const settings = () => {
    const c = cfg() || {};
    return {
      base: String(c.siteBase || DEFAULT_BASE).trim(),
      maxChars: num(c.maxChars, 6000, 1500, 20000),
      maxImages: num(c.maxImages, 3, 0, 6),
      timeoutMs: num(c.timeoutMs, 20000, 3000, 60000),
      cacheMinutes: num(c.cacheMinutes, 720, 0, 10080),
    };
  };

  api.registerTool({
    id: 'lookup',
    name: 'GameWith查碧蓝幻想',
    description: '在 GameWith（日文攻略站）查碧蓝幻想资料并返回**日文正文**（交给模型翻译成中文回答），同时给出条目里可直接发送的图片直链。用法：① 只填 query 先试一次；② 若返回要求先搜条目 ID，就用 web_search 搜它给的查询词，把结果里 gamewith.jp/article/show/<数字> 的数字填进 articleId 再调一次；③ 群友直接贴了 GameWith 链接时，把链接整条填进 query 即可。action=list 可列出已记住的条目 ID。',
    category: 'knowledge',
    icon: '📘',
    defaultEnabled: true,
    parameters: {
      type: 'object',
      properties: {
        query: { type: 'string', description: '要查的内容（群友原话即可，含黑话俗称，如「大巴」「阿妮拉」「路西HL」「武器盘」），也可以直接是一条 GameWith 链接' },
        articleId: { type: 'string', description: 'GameWith 条目 ID（gamewith.jp/article/show/<数字> 里的数字）。先用 web_search 搜到再填。' },
        jaName: { type: 'string', description: '可选：日文名（如 ルリア）。填了能提高在 id-map 里命中的概率，也用于生成搜索关键词。' },
        action: { type: 'string', enum: ['lookup', 'list'], description: 'lookup=正常查（默认）；list=列出已记住的条目 ID' },
        wantImages: { type: 'boolean', description: '是否返回图片直链，默认要' },
      },
      required: ['query'],
    },
    async execute(ctx, args) {
      const s = settings();
      const known = knownIds();
      const recent = cacheGet(RECENT_KEY, 0) || [];

      if (args.action === 'list') return { content: renderList({ known, recent }) };

      const rawQuery = String(args.query ?? '').trim();
      if (!rawQuery) return { content: 'query 不能为空', isError: true };
      const wantImages = args.wantImages !== false;

      // 1) 定日文名：显式参数 > 黑话表 > 已被记住的键模糊匹配
      const jaGiven = String(args.jaName || '').trim();
      let jaName = jaGiven || jaNameOf(rawQuery);
      if (!jaName) {
        const n = norm(rawQuery);
        const hit = Object.keys(known).find((k) => norm(k) === n || (n.length >= 2 && norm(k).includes(n)));
        if (hit) jaName = hit;
      }
      const slang = slangOf(rawQuery);

      // 2) 定条目 ID：参数/链接 > 已记住的
      let id = idFrom(args.articleId) || idFrom(rawQuery);
      if (!id && jaName && known[jaName]) id = String(known[jaName].id);
      if (!id && jaName) {
        const key = Object.keys(known).find((k) => norm(k) === norm(jaName));
        if (key) id = String(known[key].id);
      }

      // 3) 没有 ID：给出明确的搜索指引（这是 GameWith 的硬约束，不是失败）
      if (!id) {
        const content = renderNeedId({ query: rawQuery, jaName, slang, known, recent });
        api.log(`查询「${rawQuery}」：没有条目 ID，已给出搜索指引（建议词：gamewith グラブル ${jaName || rawQuery} 評価）`);
        return { content };
      }

      // 4) 抓取
      const url = pageUrl(s.base, id);
      const r = await fetchPage(url, { api, timeoutMs: s.timeoutMs, cacheMinutes: s.cacheMinutes });
      const title = String((r.html.match(/<title>([\s\S]*?)<\/title>/i) || [, ''])[1]).replace(/\s+/g, ' ').trim()
        .replace(/\s*-\s*ゲームウィズ\s*$/, '');

      if (!r.ok) {
        const why = r.blocked ? '被人机校验挡住' : (r.error || `HTTP ${r.status}`);
        api.log(`查询「${rawQuery}」：article ${id} 抓取失败（${why}）`);
        return {
          content: `【状态】❌ GameWith 条目 ${id} 抓取失败：${why}\n`
            + `【链接】${url}\n`
            + '【下一步】可以让模型换一组关键词用 web_search 再找一个条目 ID（例如把「評価」换成「攻略 編成」）；'
            + '仍然不行就如实告诉群友没查到，不要编数值。',
        };
      }

      // 5) ID 记错时会抓到别的游戏 —— 必须拦下来
      if (!looksGranblue(title)) {
        api.log(`查询「${rawQuery}」：article ${id} 不是碧蓝幻想条目（标题：${title}）`);
        return {
          content: `【状态】❌ 条目 ${id} 不是碧蓝幻想的页面（标题：「${title}」）。\n`
            + `【链接】${url}\n`
            + '【下一步】这个 ID 记错了。请用 web_search 搜「'
            + `gamewith グラブル ${jaName || rawQuery} 評価」重新找一个 gamewith.jp/article/show/<数字>，`
            + '确认标题里带「グラブル」再填进 articleId。',
        };
      }

      const body = extractBody(r.html, { maxChars: s.maxChars });
      const images = wantImages ? pickImages(r.html, url, { max: s.maxImages }) : [];

      // 记住映射（下次直接命中；也写进缓存供 id-map 参考）
      const key = jaName || rawQuery;
      rememberId(key, id, title);
      rememberRecent({ id: String(id), name: key, title });

      api.log(`查询「${rawQuery}」：article ${id} 抓取成功（正文 ${body.length} 字，图片 ${images.length} 张）`);
      return {
        content: renderFound({
          query: rawQuery, jaName, slang, url, title, body, images, fromCache: r.cached === true,
        }),
      };
    },
  });
}

export function dispose() {
  cache = null;
}
