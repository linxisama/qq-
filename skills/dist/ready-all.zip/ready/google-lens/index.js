import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { randomUUID } from 'node:crypto';
import { createRequire } from 'node:module';
import { fileURLToPath } from 'node:url';
import { DATA_DIR } from '../../src/config.js';
import { safeFetchBinary, validateFetchUrl } from '../../src/safe-fetch.js';
import { selectImageTarget } from './lib/image-target.js';
import { formatLensResults, unwrapGoogleUrl } from './lib/result.js';
import { searchSerpApi } from './lib/serpapi.js';

const SKILL_DIR = path.dirname(fileURLToPath(import.meta.url));
const APP_ROOT = path.resolve(SKILL_DIR, '../..');
let getSettings = () => ({});
let log = () => {};
let apiFetch = (...args) => globalThis.fetch(...args);
let queue = Promise.resolve();
let lastRequestAt = 0;
let cooldownUntil = 0;

const MAX_IMAGE_BYTES = 15 * 1024 * 1024;
const MIN_REQUEST_GAP_MS = 3000;
const CAPTCHA_COOLDOWN_MS = 60_000;

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function queued(task) {
  const current = queue.then(task, task);
  queue = current.catch(() => {});
  return current;
}

function effectiveSettings() {
  const raw = getSettings() || {};
  return {
    engine: raw.engine === 'serpapi' ? 'serpapi' : 'browser',
    serpApiKey: String(raw.serpApiKey || '').trim(),
    serpApiType: String(raw.serpApiType || 'all').trim(),
    serpApiLanguage: String(raw.serpApiLanguage || 'zh-cn').trim(),
    serpApiCountry: String(raw.serpApiCountry || '').trim(),
    browserExecutablePath: String(raw.browserExecutablePath || '').trim(),
    proxyServer: String(raw.proxyServer || '').trim(),
    timeoutMs: Math.min(180_000, Math.max(15_000, Number(raw.timeoutMs) || 60_000)),
    defaultMaxResults: Math.min(20, Math.max(1, Number(raw.defaultMaxResults) || 10))
  };
}

function browserCandidates() {
  if (process.platform === 'win32') {
    const candidates = [];
    for (const envName of ['PROGRAMFILES', 'PROGRAMFILES(X86)', 'LOCALAPPDATA']) {
      const root = process.env[envName];
      if (!root) continue;
      candidates.push(
        path.join(root, 'Google', 'Chrome', 'Application', 'chrome.exe'),
        path.join(root, 'Microsoft', 'Edge', 'Application', 'msedge.exe'),
        path.join(root, 'BraveSoftware', 'Brave-Browser', 'Application', 'brave.exe')
      );
    }
    return candidates;
  }
  if (process.platform === 'darwin') {
    return [
      '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',
      '/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge',
      '/Applications/Brave Browser.app/Contents/MacOS/Brave'
    ];
  }
  return [
    '/usr/bin/google-chrome',
    '/usr/bin/google-chrome-stable',
    '/usr/bin/microsoft-edge',
    '/usr/bin/brave-browser',
    '/usr/bin/chromium',
    '/usr/bin/chromium-browser'
  ];
}

async function resolveBrowserExecutable(configured) {
  if (configured) {
    try {
      await fs.access(configured);
      return configured;
    } catch {
      throw new Error(`配置的浏览器文件不存在：${configured}`);
    }
  }
  for (const candidate of browserCandidates()) {
    try {
      await fs.access(candidate);
      return candidate;
    } catch { /* 检查下一个系统默认路径 */ }
  }
  throw new Error('未找到 Chrome / Edge / Brave。请安装其中一个，或在「技能 → Google Lens 图片溯源」设置里填写浏览器路径。');
}

function imageExtension(buffer) {
  if (buffer.length >= 8 && buffer.subarray(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]))) return '.png';
  if (buffer.length >= 3 && buffer[0] === 0xff && buffer[1] === 0xd8 && buffer[2] === 0xff) return '.jpg';
  if (buffer.length >= 6 && /^GIF8[79]a$/.test(buffer.subarray(0, 6).toString('ascii'))) return '.gif';
  if (buffer.length >= 12 && buffer.subarray(0, 4).toString('ascii') === 'RIFF' && buffer.subarray(8, 12).toString('ascii') === 'WEBP') return '.webp';
  if (buffer.length >= 12 && buffer.subarray(4, 12).toString('ascii').includes('ftypavif')) return '.avif';
  return '';
}

function checkedImage(buffer, maxBytes = MAX_IMAGE_BYTES) {
  if (!Buffer.isBuffer(buffer) || !buffer.length) throw new Error('图片内容为空');
  if (buffer.length >= maxBytes) throw new Error(`图片达到大小上限（${Math.round(maxBytes / 1024 / 1024)} MB）`);
  const extension = imageExtension(buffer);
  if (!extension) throw new Error('获取到的内容不是支持的图片格式（PNG / JPEG / GIF / WebP / AVIF）');
  return { buffer, extension };
}

function isSafeOneBotFileKey(value) {
  const file = String(value || '').trim();
  if (!file || file.length > 2048) return false;
  if (/^(?:[a-z]:[\\/]|\\\\|\/)/i.test(file)) return false;
  if (/(?:^|[\\/])\.\.(?:[\\/]|$)/.test(file)) return false;
  return true;
}

async function imageFromUrl(url) {
  const { buffer, contentType } = await safeFetchBinary(String(url), MAX_IMAGE_BYTES);
  if (contentType && !/^image\//i.test(contentType) && !imageExtension(buffer)) {
    throw new Error(`图片地址返回了非图片内容（${contentType}）`);
  }
  return checkedImage(buffer);
}

async function imageFromMessage(ctx, target) {
  const media = target.media;
  let lastError = null;
  if (media.file && isSafeOneBotFileKey(media.file)) {
    try {
      const result = await ctx.onebot.call('get_image', { file: String(media.file) });
      if (result?.file) {
        const returnedPath = String(result.file);
        if (!path.isAbsolute(returnedPath)) throw new Error('OneBot 返回的图片路径不是绝对路径');
        const filePath = path.resolve(returnedPath);
        const stat = await fs.stat(filePath);
        if (!stat.isFile()) throw new Error('OneBot 返回的图片路径不是普通文件');
        if (stat.size > MAX_IMAGE_BYTES) throw new Error('图片超过大小上限（15 MB）');
        return checkedImage(await fs.readFile(filePath));
      }
      if (result?.url) return await imageFromUrl(result.url);
    } catch (error) {
      lastError = error;
    }
  }
  if (media.url) {
    try {
      return await imageFromUrl(media.url);
    } catch (error) {
      lastError = error;
    }
  }
  throw new Error(`无法读取消息图片${lastError ? `：${lastError.message}` : ''}`);
}

async function publicImageUrlForCloudLens(ctx, args) {
  let rawUrl = String(args.imageUrl || '').trim();
  if (!rawUrl) {
    const target = selectImageTarget(ctx, args);
    rawUrl = String(target.media?.url || '').trim();
    // Some OneBot implementations only retain the file token. Ask OneBot for
    // its public download URL when available; a local filesystem path cannot be
    // consumed by SerpAPI itself.
    if (!rawUrl && target.media?.file && isSafeOneBotFileKey(target.media.file)) {
      try {
        const image = await ctx.onebot.call('get_image', { file: String(target.media.file) });
        rawUrl = String(image?.url || '').trim();
      } catch { /* Report the URL requirement below. */ }
    }
  }
  if (!rawUrl) {
    throw new Error('SerpAPI 需要 Google 可访问的公网图片 URL；当前消息只有本地图片文件，请切换到「无头浏览器」引擎。');
  }
  try {
    // The URL is sent to a third-party service which fetches it server-side.
    // Always reject private/reserved hosts here, even if the local image
    // download exception (allowPrivateImageHosts) is enabled in QQ-agent.
    const checked = await validateFetchUrl(rawUrl);
    return checked.url.toString();
  } catch (error) {
    throw new Error(`SerpAPI 图片 URL 未通过公网地址校验：${error?.message ?? error}`);
  }
}

async function firstVisible(page, selectors, timeoutMs = 5000) {
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    for (const selector of selectors) {
      try {
        const locator = page.locator(selector).first();
        if (await locator.count() && await locator.isVisible()) return locator;
      } catch { /* 候选选择器失配时继续尝试 */ }
    }
    await sleep(200);
  }
  return null;
}

async function acceptConsentIfShown(page) {
  if (!/consent\.google\./i.test(page.url())) return;
  for (const label of [/全部接受/i, /我同意/i, /Accept all/i, /I agree/i]) {
    try {
      const button = page.getByRole('button', { name: label }).first();
      if (await button.count() && await button.isVisible()) {
        await button.click({ timeout: 2500 });
        await page.waitForLoadState('domcontentloaded', { timeout: 8000 }).catch(() => {});
        return;
      }
    } catch { /* 同意页结构变化时继续尝试 */ }
  }
}

async function uploadImage(page, imagePath) {
  const searchByImage = await firstVisible(page, [
    'button[aria-label*="Search by image" i]',
    '[role="button"][aria-label*="Search by image" i]',
    'button[aria-label*="按图搜索"]',
    '[role="button"][aria-label*="按图搜索"]',
    'button[aria-label*="以图搜图"]',
    '[role="button"][aria-label*="以图搜图"]',
    'button[aria-label*="按图片搜索"]',
    '[role="button"][aria-label*="按图片搜索"]'
  ], 12_000);
  if (!searchByImage) throw new Error('Google 首页没有找到「按图搜索」入口，可能是页面结构已变化');

  await searchByImage.click({ timeout: 6000 });
  const deadline = Date.now() + 12_000;
  let lastError = null;
  while (Date.now() < deadline) {
    try {
      const input = page.locator('input[type="file"]').first();
      if (await input.count()) {
        await input.setInputFiles(imagePath, { timeout: 8000 });
        return;
      }
    } catch (error) { lastError = error; }
    await sleep(250);
  }
  throw new Error(`Google Lens 上传入口不可用${lastError ? `：${lastError.message}` : ''}`);
}

async function detectGoogleBlock(page) {
  if (/\/sorry(?:\/|\?|$)|captcha|challenge/i.test(page.url())) {
    return 'Google 返回了验证/限流页面';
  }
  try {
    const text = (await page.locator('body').innerText({ timeout: 1500 })).slice(0, 5000);
    if (/unusual traffic|automated queries|人机验证|异常流量|检测到异常流量|自动化查询/i.test(text)) {
      return 'Google 页面提示异常流量或需要验证';
    }
  } catch { /* 页面切换期间暂时读不到正文 */ }
  return '';
}

async function extractLensPage(page) {
  return page.evaluate(() => {
    const tidy = (value) => String(value || '').replace(/\s+/g, ' ').trim();
    const absolute = (raw) => {
      try {
        const url = new URL(raw, location.href);
        if (/google\./i.test(url.hostname)) {
          for (const key of ['url', 'q', 'imgurl', 'adurl']) {
            const value = url.searchParams.get(key);
            if (value && /^https?:\/\//i.test(value)) return value;
          }
        }
        return /^https?:$/.test(url.protocol) ? url.href : '';
      } catch { return ''; }
    };
    const isGoogle = (value) => {
      try { return /(^|\.)google\.[a-z.]+$/i.test(new URL(value).hostname); }
      catch { return true; }
    };

    const bodyText = tidy(document.body?.innerText || '');
    const overviewLabels = [...document.querySelectorAll('span, div, h1, h2, h3, h4, p')]
      .filter((node) => node.children.length <= 1 && /^(AI Overview|AI 概览)$/i.test(tidy(node.textContent)));
    let aiOverview = '';
    let overviewRoot = null;
    for (const label of overviewLabels.reverse()) {
      let parent = label.parentElement;
      for (let depth = 0; depth < 5 && parent; depth += 1, parent = parent.parentElement) {
        const text = tidy(parent.innerText || '');
        if (text.length >= 60) {
          aiOverview = text.slice(0, 3000);
          overviewRoot = parent;
          break;
        }
      }
      if (aiOverview) break;
    }

    const overviewLinks = [];
    const seenOverview = new Set();
    if (overviewRoot) {
      for (const anchor of overviewRoot.querySelectorAll('a[href]')) {
        const url = absolute(anchor.href);
        const title = tidy(anchor.innerText || anchor.getAttribute('aria-label'));
        if (!url || isGoogle(url) || !title || seenOverview.has(url)) continue;
        seenOverview.add(url);
        overviewLinks.push({ title: title.slice(0, 160), url });
        if (overviewLinks.length >= 10) break;
      }
    }

    const matches = [];
    const seenMatches = new Set();
    const pushMatch = (anchor, heading = null) => {
      if (!anchor) return;
      const url = absolute(anchor.href);
      if (!url || isGoogle(url) || seenMatches.has(url)) return;
      const title = tidy(heading?.innerText) || tidy(anchor.innerText).split('\n').map(tidy).filter(Boolean).sort((a, b) => b.length - a.length)[0] || '';
      if (!title || title.length < 3) return;
      const lines = String(anchor.innerText || '').split('\n').map(tidy).filter(Boolean);
      let source = lines.find((line) => line !== title) || '';
      if (!source) {
        try { source = new URL(url).hostname.replace(/^www\./, ''); } catch { source = ''; }
      }
      seenMatches.add(url);
      matches.push({ title: title.slice(0, 220), source: source.slice(0, 100), url });
    };

    const hasMatchHeading = [...document.querySelectorAll('h1, h2, h3, h4, h5, h6')]
      .some((node) => /visual matches|exact matches|外观匹配|视觉匹配|完全匹配/i.test(tidy(node.innerText)));
    if (hasMatchHeading) {
      for (const heading of document.querySelectorAll('h3')) pushMatch(heading.closest('a'), heading);
      if (matches.length < 5) {
        for (const anchor of document.querySelectorAll('a[href*="/goto?url="], a[href*="/url?"]')) pushMatch(anchor);
      }
    }

    const similarImages = [];
    const seenImages = new Set();
    for (const image of document.querySelectorAll('img[src]')) {
      const src = image.src || '';
      if (!/gstatic\.com|googleusercontent\.com/i.test(src) || seenImages.has(src)) continue;
      seenImages.add(src);
      similarImages.push({ alt: String(image.alt || '').slice(0, 120), src });
      if (similarImages.length >= 8) break;
    }
    return {
      bodyText: bodyText.slice(0, 5000),
      aiOverview,
      overviewLinks,
      matches: matches.slice(0, 30),
      similarImages,
      pageTitle: document.title || '',
      resultUrl: location.href
    };
  });
}

async function searchWithBrowser(imagePath, config) {
  const playwright = await loadPlaywright();
  const executablePath = await resolveBrowserExecutable(config.browserExecutablePath);
  const profileDir = path.join(DATA_DIR, 'google-lens', 'browser-profile');
  await fs.mkdir(profileDir, { recursive: true });

  let context;
  try {
    const launchOptions = {
      headless: true,
      executablePath,
      viewport: { width: 1440, height: 1000 },
      locale: 'zh-CN',
      args: ['--no-first-run', '--no-default-browser-check']
    };
    if (config.proxyServer) launchOptions.proxy = { server: config.proxyServer };
    context = await playwright.chromium.launchPersistentContext(profileDir, launchOptions);
    const page = context.pages()[0] || await context.newPage();
    const timeout = config.timeoutMs;
    let flowNote = '';
    try {
      await page.goto('https://www.google.com/ncr', { waitUntil: 'domcontentloaded', timeout }).catch(() => {});
      await page.goto('https://www.google.com/?hl=zh-CN', { waitUntil: 'domcontentloaded', timeout });
      await acceptConsentIfShown(page);

      const blockedBeforeUpload = await detectGoogleBlock(page);
      if (blockedBeforeUpload) throw new Error(`${blockedBeforeUpload}，已停止本次反搜`);
      await uploadImage(page, imagePath);
    } catch (homepageError) {
      const blocked = await detectGoogleBlock(page);
      if (blocked) {
        cooldownUntil = Date.now() + CAPTCHA_COOLDOWN_MS;
        throw new Error(`${blocked}，已停止本次反搜，不会自动重试`);
      }
      flowNote = `首页上传流程不可用，已改用 Google Lens 上传页：${String(homepageError?.message ?? homepageError).slice(0, 180)}`;
      await page.goto('https://lens.google.com/', { waitUntil: 'domcontentloaded', timeout });
      await acceptConsentIfShown(page);
      const fileInput = page.locator('input[type="file"]').first();
      await fileInput.waitFor({ state: 'attached', timeout: Math.min(timeout, 15_000) });
      await fileInput.setInputFiles(imagePath, { timeout: 10_000 });
    }

    const deadline = Date.now() + timeout;
    let previousLength = -1;
    let stableSamples = 0;
    let latest = null;
    while (Date.now() < deadline) {
      const blocked = await detectGoogleBlock(page);
      if (blocked) {
        cooldownUntil = Date.now() + CAPTCHA_COOLDOWN_MS;
        throw new Error(`${blocked}。已停止重试，请稍后再试；如 Google 明确要求验证，请人工处理浏览器 profile 后再调用。`);
      }

      try { latest = await extractLensPage(page); } catch { latest = null; }
      const onResultsPage = Boolean(latest && /\/search(?:[/?#]|$)|lens\.google\.com\/upload/i.test(latest.resultUrl));
      const resultTextLength = latest ? Math.max(latest.aiOverview.length, latest.matches.length ? 1 : 0, latest.bodyText.length) : 0;
      if (onResultsPage && resultTextLength > 100) {
        if (resultTextLength === previousLength) stableSamples += 1;
        else stableSamples = 0;
        previousLength = resultTextLength;
        if (stableSamples >= 2) break;
      }
      await sleep(800);
    }

    if (!latest || !latest.resultUrl || latest.resultUrl.includes('google.com/?')) {
      throw new Error('Google Lens 未能打开识图结果页');
    }
    const publicLinks = (items) => (Array.isArray(items) ? items : []).flatMap((item) => {
      const url = unwrapGoogleUrl(item?.url);
      if (!url) return [];
      try {
        if (/(^|\.)google\.[a-z.]+$/i.test(new URL(url).hostname)) return [];
      } catch { return []; }
      return [{ ...item, url }];
    });
    latest.matches = publicLinks(latest.matches);
    latest.overviewLinks = publicLinks(latest.overviewLinks);
    return {
      ...latest,
      flowNote: flowNote || (latest.matches.length ? '' : '识别概览可能受 Google 登录状态、图片清晰度或地区可用性影响。')
    };
  } finally {
    if (context) await context.close().catch(() => {});
  }
}

/** 按应用目录而非当前工作目录解析依赖，并兼容 Electron 安装目录。 */
export async function loadPlaywright() {
  const resourcesPath = String(process.resourcesPath || '').trim();
  const bases = [...new Set([
    APP_ROOT,
    process.cwd(),
    path.dirname(process.execPath),
    resourcesPath,
    resourcesPath ? path.join(resourcesPath, 'app') : ''
  ].filter(Boolean))];
  const resolverErrors = [];
  let packageEntry = '';
  let loadError = null;

  for (const base of bases) {
    const localRequire = createRequire(path.join(base, 'package.json'));
    let resolved;
    try {
      resolved = localRequire.resolve('playwright-core');
    } catch (error) {
      resolverErrors.push(`${base}: ${error?.code || error?.message || error}`);
      continue;
    }

    packageEntry = resolved;
    try {
      const loaded = localRequire('playwright-core');
      const playwright = loaded?.chromium ? loaded : loaded?.default;
      if (!playwright?.chromium) throw new Error('模块没有导出 chromium API');
      return playwright;
    } catch (error) {
      loadError = error;
    }
  }

  if (packageEntry && loadError) {
    throw new Error(`已定位 playwright-core（${packageEntry}），但模块加载失败：${loadError?.message ?? loadError}`);
  }

  if (!packageEntry) {
    throw new Error(
      `找不到 playwright-core。请在运行中的 QQ-agent 应用目录执行 npm install playwright-core，` +
      '然后彻底退出并重启 QQ-agent。' +
      `已检查：${bases.join('；')}。${resolverErrors[0] ? `（${resolverErrors[0]}）` : ''}`
    );
  }
}

async function performSearch(ctx, args) {
  const config = effectiveSettings();
  if (config.engine === 'browser' && Date.now() < cooldownUntil) {
    const seconds = Math.ceil((cooldownUntil - Date.now()) / 1000);
    throw new Error(`Google Lens 冷却中，约 ${seconds} 秒后再试`);
  }

  const waitMs = MIN_REQUEST_GAP_MS - (Date.now() - lastRequestAt);
  if (lastRequestAt && waitMs > 0) await sleep(waitMs);
  lastRequestAt = Date.now();

  const maxResults = Math.min(20, Math.max(1, Number(args.maxResults) || config.defaultMaxResults));
  if (config.engine === 'serpapi') {
    const imageUrl = await publicImageUrlForCloudLens(ctx, args);
    const result = await searchSerpApi({
      imageUrl,
      apiKey: config.serpApiKey,
      type: config.serpApiType,
      language: config.serpApiLanguage,
      country: config.serpApiCountry,
      maxResults,
      timeoutMs: config.timeoutMs,
      fetchImpl: apiFetch
    });
    log('SerpAPI Google Lens 搜索完成：来源候选 %s 条', result.matches.length);
    return { content: formatLensResults(result, maxResults) };
  }
  let image;
  if (String(args.imageUrl || '').trim()) {
    image = await imageFromUrl(args.imageUrl);
  } else {
    const target = selectImageTarget(ctx, args);
    image = await imageFromMessage(ctx, target);
  }

  const tempDir = await fs.mkdtemp(path.join(os.tmpdir(), 'qqagent-lens-'));
  const imagePath = path.join(tempDir, `${randomUUID()}${image.extension}`);
  try {
    await fs.writeFile(imagePath, image.buffer, { flag: 'wx' });
    const result = await searchWithBrowser(imagePath, config);
    log('Google Lens 识图完成：AI 概览 %s 字符，来源候选 %s 条', result.aiOverview.length, result.matches.length);
    return { content: formatLensResults(result, maxResults) };
  } finally {
    await fs.rm(tempDir, { recursive: true, force: true }).catch(() => {});
  }
}

export function setup(api) {
  getSettings = api.config;
  apiFetch = api.fetch;
  log = (...args) => (api.log || console.log)(...args);

  api.registerTool({
    id: 'image_source_search',
    name: 'Google Lens 图片溯源',
    category: 'media',
    icon: '🔎',
    description: [
      '使用配置的图片溯源引擎查找识别概览、相似图片标题与来源页面链接：SerpAPI Google Lens 或本机无头 Chrome/Edge。',
      '用户询问图片出处、原图/相似图来源、截图中的角色或物体来自哪里时使用。',
      '默认查本轮触发消息里的图片；可传 messageId 查本会话历史图片，imageIndex 从 1 开始。',
      '也可传公网 imageUrl。SerpAPI 模式要求 Google 可访问的公网图片 URL，不加载 Playwright；图片会提交给所选云端服务，结果只是来源候选。'
    ].join(' '),
    parameters: {
      type: 'object',
      properties: {
        messageId: { type: ['integer', 'string'], description: '可选：要反搜图片所在消息的 id（聊天记录里的 #数字）；不传时优先使用本轮触发消息图片。' },
        imageIndex: { type: 'integer', description: '同一条消息里的第几张图片，从 1 开始，默认 1。' },
        imageUrl: { type: 'string', description: '可选：公网 http(s) 图片直链；传入后优先使用此图片。' },
        maxResults: { type: 'integer', description: '最多返回多少条来源候选，默认按 Skill 设置，范围 1–20。' }
      }
    },
    async execute(ctx, args = {}) {
      try {
        return await queued(() => performSearch(ctx, args));
      } catch (error) {
        return { content: `Google Lens 反搜失败：${error?.message ?? error}`, isError: true };
      }
    }
  });
}

export { selectImageTarget, formatLensResults };
export { performSearch, publicImageUrlForCloudLens };
