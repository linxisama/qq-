// 足球赛事查询（懂球帝）—— LLM 型技能：查赛程 / 赛果 / 积分榜。
//
// 为什么是 skill 而不是 plugin：
//   「什么时候该查球、查哪一天、哪支队」只能由模型理解用户那句话来判断，
//   没有「满足条件必然执行」的时机，所以走 registerTool + prompt 引导。
//
// 数据来源（全部是公开页面，无需 API Key、不消耗任何额度）：
//   栏目页  https://m.dongqiudi.com/match/<board>?date=YYYY-MM-DD
//           —— 服务端直出，含：日期分组、每场的北京时间、联赛名、主客队名、比分（或未开始）
//   数据页  https://www.dongqiudi.com/data?cid=<competitionId>&tab=standings
//           —— 服务端直出的积分榜表格
//
// 三个刻意的技术选择，都是踩过才知道的：
//   ① 只认「服务端直出」的页面。懂球帝 PC 版 /match 是前端渲染的，抓回来只有表头没有比赛；
//      移动版栏目页把比赛直接写在 HTML 里。所以解析的是移动版。
//   ② 解析按「块」切，不按「空行」切。页面里的换行数量不稳定（抓取/渲染方式一变就变），
//      所以先按 `- ` 列表项切出每一场比赛的块，再在块内逐行认字段 —— 只依赖语义顺序，不依赖排版。
//   ③ 队名靠「去掉图片行之后剩下的短行」来取，而不是靠固定行号：中立场地、直播角标（"爱奇艺"）、
//      "已结束" 这些附加字样会插进来，但「紧邻时间行的上一行 = 主队」「比分行之后的第一个非状态行 = 客队」
//      这个关系在所有实测样本里都成立。
//
// ⚠️ 工具 id 由宿主自动加前缀（skillId__工具id），所以对模型暴露的名字是：
//      football-match__schedule / football-match__results / football-match__standings
//    工具 id 只允许 [a-zA-Z0-9_-]（它会成为 OpenAI function name），别写点号或冒号。

let cfg = () => ({});
let httpFetch = null;

const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Safari/537.36';

// ── 栏目（board）表：懂球帝移动版 /match/<id> ─────────────────────────
// 要加新的：打开 m.dongqiudi.com/match，看顶部导航里那一串链接的编号。
const BOARDS = {
  important: { id: 10, label: '重要（精选）' },
  global: { id: 12, label: '全球' },
  soccer: { id: 70, label: '足球' },
  csl: { id: 5, label: '中超' },
  csl2: { id: 100, label: '中甲' },
  csl3: { id: 101, label: '中乙' },
  epl: { id: 6, label: '英超' },
  laliga: { id: 7, label: '西甲' },
  bundesliga: { id: 8, label: '德甲' },
  seriea: { id: 9, label: '意甲' },
  ligue1: { id: 30, label: '法甲' },
  ucl: { id: 31, label: '欧冠' },
  uel: { id: 34, label: '欧联' },
  uecl: { id: 84, label: '欧协联' },
  afccl: { id: 105, label: '亚冠精英' },
  saudi: { id: 99, label: '沙特联' },
  mls: { id: 26, label: '美职联' },
  aleague: { id: 98, label: '澳超' },
  cwc: { id: 111, label: '世俱杯' },
  scotland: { id: 112, label: '苏超' },
};

// 用户嘴里的联赛名 → 栏目 key。null = 认得出是联赛但没有独立栏目，只能全栏目查。
const LEAGUE_ALIAS = {
  '英超': 'epl', '英格兰': 'epl', 'epl': 'epl', 'premier league': 'epl',
  '西甲': 'laliga', '西班牙': 'laliga', 'laliga': 'laliga', 'la liga': 'laliga',
  '德甲': 'bundesliga', '德国': 'bundesliga', 'bundesliga': 'bundesliga',
  '意甲': 'seriea', '意大利': 'seriea', 'seriea': 'seriea', 'serie a': 'seriea',
  '法甲': 'ligue1', '法国': 'ligue1', 'ligue1': 'ligue1', 'ligue 1': 'ligue1',
  '欧冠': 'ucl', '欧洲冠军联赛': 'ucl', 'ucl': 'ucl', 'champions league': 'ucl',
  '欧联': 'uel', '欧罗巴': 'uel', 'uel': 'uel', 'europa league': 'uel',
  '欧协联': 'uecl', 'uecl': 'uecl',
  '中超': 'csl', 'csl': 'csl',
  '中甲': 'csl2',
  '中乙': 'csl3',
  '亚冠': 'afccl', '亚冠精英': 'afccl', 'afc': 'afccl',
  '沙特': 'saudi', '沙特联': 'saudi', '沙特联赛': 'saudi',
  '美职联': 'mls', '美国大联盟': 'mls', 'mls': 'mls',
  '澳超': 'aleague', '澳甲': 'aleague',
  '世俱杯': 'cwc',
  '苏超': 'scotland',
  '足球': 'soccer',
  '全球': 'global',
  '重要': 'important',
};

// ── 积分榜（数据页）用的赛事 id ───────────────────────────────────────
// 来源：www.dongqiudi.com/data?cid=<id>
const STANDING_CID = {
  '中超': 43, '英超': 4, '西甲': 3, '意甲': 9, '德甲': 5, '法甲': 12,
  '欧冠': 6, '欧联': 14, '欧协联': 3904, '亚冠精英': 226, '亚冠二级': 228,
  '沙特联': 197, '美职联': 26, '苏超': 8647, '中甲': 129, '中乙': 1535,
  '世界杯': 61, '亚洲杯': 225, '欧国联': 2442,
};

// ── 时间小工具 ──────────────────────────────────────────────────────
const WEEK_CN = ['周日', '周一', '周二', '周三', '周四', '周五', '周六'];

/** 某个时区下的「今天」= YYYY-MM-DD（en-CA 的格式天然就是它） */
function todayIn(tz) {
  try {
    return new Intl.DateTimeFormat('en-CA', {
      timeZone: tz || 'Asia/Shanghai', year: 'numeric', month: '2-digit', day: '2-digit',
    }).format(new Date());
  } catch {
    return new Date().toISOString().slice(0, 10);
  }
}

/** YYYY-MM-DD 加减天数 */
function shiftDate(dateStr, days) {
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(String(dateStr || ''));
  if (!m) return dateStr;
  const d = new Date(Date.UTC(Number(m[1]), Number(m[2]) - 1, Number(m[3])));
  d.setUTCDate(d.getUTCDate() + days);
  return d.toISOString().slice(0, 10);
}

/** YYYY-MM-DD → 「10月12日 周一」 */
function humanDate(dateStr) {
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(String(dateStr || ''));
  if (!m) return String(dateStr || '');
  const d = new Date(Date.UTC(Number(m[1]), Number(m[2]) - 1, Number(m[3])));
  return `${Number(m[2])}月${Number(m[3])}日 ${WEEK_CN[d.getUTCDay()] || ''}`;
}

function isDateStr(s) {
  return /^\d{4}-\d{2}-\d{2}$/.test(String(s || ''));
}

/** 「今天/明天/昨天/后天/10月12日/2026-10-12」→ YYYY-MM-DD；认不出返回 null */
function resolveDateWord(word, tz) {
  const t = String(word || '').trim();
  if (!t) return null;
  if (isDateStr(t)) return t;
  const base = todayIn(tz);
  const table = {
    '今天': 0, '今日': 0, '今晚': 0, '今夜': 0, '刚才': 0, '现在': 0,
    '明天': 1, '明日': 1, '明晚': 1,
    '后天': 2, '大后天': 3, '大大后天': 4,
    '昨天': -1, '昨日': -1, '昨晚': -1,
    '前天': -2, '前日': -2,
  };
  if (Object.prototype.hasOwnProperty.call(table, t)) return shiftDate(base, table[t]);
  const md = /^(?:(\d{4})[-/年])?(\d{1,2})[-/月](\d{1,2})日?$/.exec(t);
  if (md) {
    const y = md[1] ? Number(md[1]) : Number(base.slice(0, 4));
    return `${y}-${String(Number(md[2])).padStart(2, '0')}-${String(Number(md[3])).padStart(2, '0')}`;
  }
  return null;
}

// ── 抓取 ───────────────────────────────────────────────────────────
async function fetchText(url, timeoutMs) {
  if (!httpFetch) return { error: '未启用网络权限（web_fetch）' };
  const ms = Math.max(3000, timeoutMs || 12000);
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), ms);
  try {
    const res = await httpFetch(url, {
      headers: {
        'User-Agent': UA,
        'Accept': 'text/html,application/xhtml+xml',
        'Accept-Language': 'zh-CN,zh;q=0.9',
      },
      signal: ctrl.signal,
    });
    if (!res || !res.ok) return { error: `HTTP ${res ? res.status : '无响应'}` };
    const text = await res.text();
    if (!text || text.length < 200) return { error: '返回内容为空' };
    return { text };
  } catch (e) {
    const msg = (e && e.name === 'AbortError')
      ? `超时（${Math.round(ms / 1000)} 秒）`
      : `网络错误：${e && e.message ? e.message : e}`;
    return { error: msg };
  } finally {
    clearTimeout(timer);
  }
}

// ── 解析：移动版栏目页 ──────────────────────────────────────────────
function clean(s) {
  return String(s == null ? '' : s)
    .replace(/\s+/g, ' ')
    .replace(/^[-–—·|>\s]+|[-–—·|>\s]+$/g, '')
    .trim();
}

const RE_TIME_LEAGUE = /^(\d{1,2}:\d{2})(?:\s+(\S.{0,19}))?$/;
const RE_SCORE = /^(\d{1,2})\s*-\s*(\d{1,2})$/;
const RE_STATUS = /(已结束|完场|进行中|中场|未开始|延期|取消|腰斩)/;

/**
 * 把 m.dongqiudi.com/match/<board>?date=… 的页面解析成比赛数组。
 *
 * 形状（语义顺序，正则只锚这个顺序）：
 *   ### 2026-10-14 星期三
 *   - ![](主队队徽) 主队名 00:45 欧冠 [![](直播角标)] 3 - 1 [已结束] ![](客队队徽) 客队名
 *
 * @returns {Array<object>} [{date,time,league,home,away,homeScore,awayScore,status}]
 */
function parseBoardPage(html) {
  const text = String(html || '');
  const out = [];

  // ① 按日期标题切大块
  const marks = [];
  const dateRe = /###\s*(\d{4}-\d{2}-\d{2})\s*(周[一二三四五六日])?/g;
  let m;
  while ((m = dateRe.exec(text)) !== null) marks.push({ date: m[1], start: dateRe.lastIndex });
  for (let i = 0; i < marks.length; i++) {
    const end = i + 1 < marks.length ? marks[i + 1].start : text.length;
    const seg = text.slice(marks[i].start, end);

    // ② 按列表项切出每一场比赛的块
    const chunks = seg.split(/\n\s*-\s+/).slice(1);
    for (const chunk of chunks) {
      const item = parseMatchChunk(chunk, marks[i].date);
      if (item) out.push(item);
    }
  }
  return out;
}

/** 解析单个比赛块；认不出来返回 null（宁可少一条，不要塞脏数据给模型） */
function parseMatchChunk(chunk, date) {
  // 逐行，去掉空行与图片行（图片行里只有 URL / base64，不含信息）
  const lines = String(chunk || '')
    .split('\n')
    .map(clean)
    .filter((l) => l && !/^!\[/.test(l) && !/^https?:\/\//.test(l));
  if (lines.length < 4) return null;

  // 时间 + 联赛那一行（唯一的 "HH:MM" 开头行）
  let ti = -1;
  for (let i = 0; i < lines.length; i++) {
    if (RE_TIME_LEAGUE.test(lines[i])) { ti = i; break; }
  }
  if (ti < 0) return null;

  // 比分那一行（时间行之后第一个 "N - M" 或 "vs"）
  let score = null;
  let sawVs = false;
  let si = -1;
  for (let i = ti + 1; i < lines.length; i++) {
    if (/^vs$/i.test(lines[i])) { sawVs = true; si = i; break; }
    const sc = RE_SCORE.exec(lines[i]);
    if (sc) { score = { home: Number(sc[1]), away: Number(sc[2]) }; si = i; break; }
  }

  // 队名：紧邻时间行的上一行 = 主队；比分行之后第一个非状态行 = 客队
  const home = ti > 0 ? lines[ti - 1] : '';
  let away = '';
  if (si >= 0) {
    for (let i = si + 1; i < lines.length; i++) {
      const l = lines[i];
      if (RE_STATUS.test(l) || RE_SCORE.test(l) || /^vs$/i.test(l)) continue;
      away = l;
      break;
    }
  }
  if (!home || !away) return null;
  if (RE_STATUS.test(home) || RE_SCORE.test(home)) return null;
  if (RE_STATUS.test(away) || RE_SCORE.test(away)) return null;

  const tm = RE_TIME_LEAGUE.exec(lines[ti]);
  const whole = lines.join(' ');

  let status;
  if (sawVs || !score) {
    status = '未开始';
  } else if (/进行中|中场/.test(whole)) {
    const mi = /进行中\s*(\d{1,3})/.exec(whole);
    status = mi ? `进行中 ${mi[1]}'` : '进行中';
  } else if (/已结束|完场/.test(whole)) {
    status = '已结束';
  } else {
    status = '已结束或进行中';
  }

  return {
    date,
    time: tm[1],
    league: clean(tm[2] || ''),
    home,
    away,
    homeScore: score ? score.home : null,
    awayScore: score ? score.away : null,
    status,
  };
}

/** 队名筛选：双向子串匹配（「曼联」命中「曼联」，输入更长的名字也能反向命中） */
function teamHit(name, filters) {
  const n = String(name || '').toLowerCase();
  return filters.some((f) => {
    const q = String(f || '').toLowerCase().trim();
    if (!q) return false;
    return n.includes(q) || q.includes(n);
  });
}

function readList(v) {
  return String(v == null ? '' : v).split(/[,，、\s]+/).map((s) => s.trim()).filter(Boolean);
}

/** 联赛词 → 栏目 key（认不出返回 null） */
function leagueToBoard(word) {
  const w = String(word || '').trim().toLowerCase();
  if (!w) return null;
  if (Object.prototype.hasOwnProperty.call(LEAGUE_ALIAS, w)) return LEAGUE_ALIAS[w];
  for (const [k, v] of Object.entries(LEAGUE_ALIAS)) {
    if (v && (k.toLowerCase().includes(w) || w.includes(k.toLowerCase()))) return v;
  }
  return null;
}

/** 比赛数组 → 文本行 */
function renderMatches(list) {
  return list.map((x) => {
    const score = x.homeScore === null ? 'vs' : `${x.homeScore} - ${x.awayScore}`;
    const lg = x.league ? `${x.league}｜` : '';
    return `· ${humanDate(x.date)} ${x.time}｜${lg}${x.home} ${score} ${x.away}｜${x.status}`;
  });
}

// ── 解析：数据页积分榜 ──────────────────────────────────────────────
/**
 * www.dongqiudi.com/data?cid=<id>&tab=standings 里的表格：
 * | # | 球队 | 赛 | 胜 | 平 | 负 | 进/失 | 净胜 | 积分 |
 */
function parseStandings(html) {
  const text = String(html || '');
  const rows = [];
  const re = /\|\s*(\d{1,3})\s*\|\s*(?:!\[\]\([^)]*\)\s*)?\[([^\]]{1,40})\]\(\/team\/\d+\)\s*\|\s*(\d{1,3})\s*\|\s*(\d{1,3})\s*\|\s*(\d{1,3})\s*\|\s*(\d{1,3})\s*\|\s*(\d{1,4})\s*\/\s*(\d{1,4})\s*\|\s*([+\-]?\d{1,4})\s*\|\s*(\d{1,4})\s*\|/g;
  let m;
  while ((m = re.exec(text)) !== null) {
    rows.push({
      rank: Number(m[1]),
      team: clean(m[2]),
      played: Number(m[3]),
      win: Number(m[4]),
      draw: Number(m[5]),
      loss: Number(m[6]),
      goalsFor: Number(m[7]),
      goalsAgainst: Number(m[8]),
      diff: clean(m[9]),
      points: Number(m[10]),
    });
  }
  return rows;
}

// ── 共用执行体 ──────────────────────────────────────────────────────
function ctxOf(raw) {
  const c = raw || {};
  return {
    c,
    timeoutMs: Math.min(30000, Math.max(3000, Number(c.timeoutMs) || 12000)),
    tz: c.timeZone || 'Asia/Shanghai',
    max: Math.min(30, Math.max(1, Number(c.maxResults) || 12)),
  };
}

async function runMatchQuery(args, mode) {
  if (!httpFetch) return { content: '未启用网络权限（web_fetch），无法查询赛事。', isError: true };
  const { c, timeoutMs, tz, max } = ctxOf(cfg());
  const a = args || {};

  // 日期：参数（支持「今天/明天/昨天/10月12日」）优先，否则按模式取默认
  let date = resolveDateWord(a.date, tz);
  if (!date) date = mode === 'results' ? shiftDate(todayIn(tz), -1) : todayIn(tz);
  const days = Math.min(7, Math.max(1, Number(a.days) || (a.date ? 1 : (mode === 'results' ? 1 : 2))));

  // 联赛 → 栏目
  const leagueWord = clean(a.league || '');
  let boardKey = leagueWord ? leagueToBoard(leagueWord) : null;
  let boardNote = '';
  if (leagueWord && !boardKey) boardNote = `（没认出来「${leagueWord}」是哪个联赛，已按全部比赛查）`;
  if (!boardKey) {
    const def = String(c.defaultBoard || 'important');
    boardKey = BOARDS[def] ? def : 'important';
  }
  const board = BOARDS[boardKey];

  // 球队 / 联赛筛选：工具参数优先，其次技能设置
  const teamFilters = a.team ? readList(a.team) : readList(c.filterTeams);
  const leagueFilters = (!leagueWord && c.showLeagueFilter) ? readList(c.showLeagueFilter) : [];

  const all = [];
  const errors = [];
  for (let i = 0; i < days; i++) {
    const d = shiftDate(date, i);
    const got = await fetchText(`https://m.dongqiudi.com/match/${board.id}?date=${d}`, timeoutMs);
    if (got.error) { errors.push(`${d}：${got.error}`); continue; }
    all.push(...parseBoardPage(got.text));
    if (i < days - 1) await new Promise((r) => setTimeout(r, 300)); // 别把站点打急
  }

  const span = `${humanDate(date)}${days > 1 ? ` 起 ${days} 天` : ''}`;

  if (!all.length) {
    const why = errors.length ? `（抓取失败：${errors.join('；')}）` : '';
    return {
      content: `没查到 ${span} 的比赛${boardNote}${why}。数据源：懂球帝「${board.label}」栏目。`
        + `可以换个日期，或点名一个联赛（英超/西甲/欧冠/中超…）再试。`,
    };
  }

  // 去重：同一天重复抓时用 日期+时间+双方 做键
  const seen = new Set();
  let list = all.filter((x) => {
    const k = `${x.date}|${x.time}|${x.home}|${x.away}`;
    if (seen.has(k)) return false;
    seen.add(k);
    return true;
  });

  if (teamFilters.length) list = list.filter((x) => teamHit(x.home, teamFilters) || teamHit(x.away, teamFilters));
  if (leagueFilters.length) list = list.filter((x) => leagueFilters.some((f) => String(x.league || '').includes(f)));

  if (!list.length) {
    const who = teamFilters.length ? `球队「${teamFilters.join('、')}」` : (leagueWord ? `联赛「${leagueWord}」` : '');
    return {
      content: `${span} 在懂球帝「${board.label}」栏目里没有${who ? `${who}的` : ''}比赛。`
        + `\n（这个栏目这几天一共 ${all.length} 场其他比赛）`
        + `\n可以换日期、换联赛名，或把队名换成常见叫法（如「皇马」→「皇家马德里」）再试。`,
    };
  }

  const shown = list.slice(0, max);
  const head = mode === 'results' ? `⚽ ${span} 足球赛果/比分` : `⚽ ${span} 足球赛程`;
  const scope = teamFilters.length
    ? `（只看 ${teamFilters.join('、')}）`
    : (leagueWord ? `（${leagueWord}）` : `（懂球帝「${board.label}」）`);

  return {
    content: `${head}${scope}${boardNote}：共 ${list.length} 场，下面是前 ${shown.length} 场\n`
      + renderMatches(shown).join('\n')
      + (list.length > shown.length ? `\n……还有 ${list.length - shown.length} 场没列出来（想细看可以点名球队或联赛）` : '')
      + `\n\n（时间均为北京时间；数据来源：懂球帝公开页面）`
      + (errors.length ? `\n⚠️ 部分日期没抓到：${errors.join('；')}` : ''),
  };
}

// ── 对宿主暴露 ──────────────────────────────────────────────────────
export function setup(api) {
  cfg = api.config;
  httpFetch = typeof api.fetch === 'function' ? (...args) => api.fetch(...args) : null;

  // 工具1：赛程 / 当日比分
  api.registerTool({
    id: 'schedule',
    name: '足球赛程比分',
    category: 'query',
    icon: '⚽',
    description: '查某一天（或从某天起几天）的主流足球赛程与当场比分，数据来自懂球帝。返回每场的日期、北京时间、联赛、主客队与比分；未开始的显示「未开始」，正在踢的带「进行中 83\'」这种分钟数。date 支持"今天""明天""昨天"或 2026-10-12 / 10月12日；league 只看某联赛（英超/西甲/意甲/德甲/法甲/欧冠/欧联/中超/亚冠等）；team 只看某队。用户问「今晚有什么球」「明天谁打谁」「现在比分多少」「这周末有什么比赛」时使用。',
    parameters: {
      type: 'object',
      properties: {
        date: { type: 'string', description: '哪天，默认今天。可写"今天""明天""昨天""前天""后天"，或 2026-10-12 / 10月12日 这种写法。' },
        days: { type: 'number', description: '从 date 起查几天，默认 2，最多 7。用户问"这周末""未来几天"时用。' },
        league: { type: 'string', description: '可选，只看某个联赛，例如 英超 / 西甲 / 意甲 / 德甲 / 法甲 / 欧冠 / 欧联 / 中超 / 亚冠 / 沙特联 / 美职联。不传则按技能设置里的默认栏目返回。' },
        team: { type: 'string', description: '可选，只看某支球队，中文队名即可（曼联 / 皇马 / 巴萨 / 拜仁 / 利物浦），逗号分隔可给多支。' },
      },
    },
    async execute(_ctx, args = {}) {
      return runMatchQuery(args, 'schedule');
    },
  });

  // 工具2：赛果
  api.registerTool({
    id: 'results',
    name: '足球赛果比分',
    category: 'query',
    icon: '🏁',
    description: '查某一天已经踢完的足球比分结果，数据来自懂球帝。默认查昨天；date 可指定（"昨天""前天""2026-10-11"），league 只看某联赛，team 只看某队。返回主客队与最终比分，并区分已结束与进行中。用户问「昨天曼联比分」「刚才那场谁赢了」「皇马最近赛果」时使用。',
    parameters: {
      type: 'object',
      properties: {
        date: { type: 'string', description: '哪天，默认昨天。支持"昨天""前天""今天"，或 2026-10-11 / 10月11日。' },
        league: { type: 'string', description: '可选，只看某个联赛，例如 英超 / 西甲 / 欧冠 / 中超。' },
        team: { type: 'string', description: '可选，只看某支球队（中文队名，逗号分隔可多支）。' },
      },
    },
    async execute(_ctx, args = {}) {
      return runMatchQuery(args, 'results');
    },
  });

  // 工具3：积分榜
  api.registerTool({
    id: 'standings',
    name: '足球积分榜',
    category: 'query',
    icon: '📊',
    description: '查某个联赛的积分榜（排名、场次、胜平负、进失球、净胜球、积分），数据来自懂球帝数据页。用户问「英超积分榜」「西甲现在谁第一」「中超排名」时使用。',
    parameters: {
      type: 'object',
      properties: {
        league: { type: 'string', description: '联赛名，例如 英超 / 西甲 / 意甲 / 德甲 / 法甲 / 欧冠 / 中超 / 中甲 / 沙特联 / 美职联。' },
        limit: { type: 'number', description: '最多显示几行，默认 10，最多 30。' },
      },
      required: ['league'],
    },
    async execute(_ctx, args = {}) {
      if (!httpFetch) return { content: '未启用网络权限（web_fetch），无法查询积分榜。', isError: true };
      const { timeoutMs } = ctxOf(cfg());
      const a = args || {};
      const word = clean(a.league || '');
      if (!word) return { content: '要查哪个联赛的积分榜？例如「英超」「西甲」「中超」。' };

      let cid = STANDING_CID[word];
      if (!cid) {
        for (const [k, v] of Object.entries(STANDING_CID)) {
          if (k.includes(word) || word.includes(k)) { cid = v; break; }
        }
      }
      if (!cid) {
        return { content: `没认出来「${word}」是哪个联赛。可以试试：${Object.keys(STANDING_CID).slice(0, 12).join('、')} 等。` };
      }

      const got = await fetchText(`https://www.dongqiudi.com/data?cid=${cid}&tab=standings`, timeoutMs);
      if (got.error) return { content: `查积分榜失败（${got.error}）。数据源是懂球帝数据页，稍后再试。`, isError: true };

      const rows = parseStandings(got.text);
      if (!rows.length) {
        return { content: `没解析到「${word}」的积分榜 —— 可能是该赛事当前没有积分榜（杯赛/赛季未开始），或页面结构变了。可以换成查赛程试试。` };
      }
      const limit = Math.min(30, Math.max(1, Number(a.limit) || 10));
      const lines = rows.slice(0, limit).map((r) =>
        `${r.rank}. ${r.team}｜${r.points} 分｜${r.played} 场 ${r.win}胜${r.draw}平${r.loss}负｜进${r.goalsFor}失${r.goalsAgainst}（${r.diff}）`
      );
      return {
        content: `📊 ${word}积分榜（前 ${Math.min(limit, rows.length)} 名，共 ${rows.length} 队）\n${lines.join('\n')}\n\n数据来源：懂球帝数据页（www.dongqiudi.com/data）。`,
      };
    },
  });

  api.log(`已加载：足球赛事查询（懂球帝）—— ${Object.keys(BOARDS).length} 个栏目、${Object.keys(STANDING_CID).length} 个赛事积分榜`);
}

/** 供宿主判断可用性：声明了 web_fetch 才有网络能力 */
export function available() {
  return httpFetch
    ? { ok: true }
    : { ok: false, reason: '缺少 web_fetch 权限，无法访问懂球帝页面' };
}

/** 内部引用：留着手工核对解析结果用（宿主不会调用） */
export const internals = { parseBoardPage, parseMatchChunk, parseStandings, leagueToBoard, resolveDateWord, shiftDate, todayIn };
