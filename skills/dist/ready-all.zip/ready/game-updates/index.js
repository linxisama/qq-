// 游戏更新概要（game-updates）—— 自包含技能
//
// 群友问「XX 更新了啥」时，去 Steam 抓该游戏最近的更新公告：
//   · 外文公告 → 先用配置的模型翻译，再归纳成概要
//   · 中文公告 → 直接归纳
// 最后整理成一份**带更新时间**的概要返回给模型，由模型发到群里。
//
// ── 为什么不用官方 News API ──────────────────────────────────────────
//   api.steampowered.com / ISteamNews/* 和 steamcommunity.com/*/rss
//   实测在国内网络下直连不通（fetch failed，挂代理也不行）。
//   能用的是商店这张口子：
//     store.steampowered.com/events/ajaxgetpartnereventspageable/
//   它返回 JSON，events[].event_type === 12 就是更新公告，
//   正文在 events[].announcement_body.{headline, body, posttime}。
//   实测幸福工厂/戴森球/异星工厂都能正常拿到（含中文公告）。
//
// ── 语言判断 ────────────────────────────────────────────────────────
//   不靠 announcement_body.language（英文公告那栏经常是空的/问号），
//   直接数正文里的中日韩字符占比 —— 见 looksChinese()。

import fs from 'node:fs';
import path from 'node:path';
import { getConfig, DATA_DIR } from '../../src/config.js';

const SKILL_ID = 'game-updates';
const UA = {
  'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120 Safari/537.36',
  'accept-language': 'zh-CN,zh;q=0.9',
};
const EVENTS_API = 'https://store.steampowered.com/events/ajaxgetpartnereventspageable/';
const SEARCH_API = 'https://store.steampowered.com/api/storesearch/';
// ★ 更新公告的事件类型不是一个值 —— 实测：
//   幸福工厂 12=小补丁、14=大型更新上线（"Satisfactory 1.2 Update out now!"）
//   泰拉瑞亚 14=更新（"Terraria 1.4.5.7 - Out Now"）、12 一条都没有
//   → 只收 12 的话泰拉瑞亚会返回"最近没有更新公告"（错得很难看）
//   28 是新闻中心的开发日志/促销/周边（State of the Game、Collector's Edition），不收。
const UPDATE_EVENT_TYPES = new Set([12, 13, 14]);
const ALL_EVENT_TYPES = new Set([12, 13, 14, 28]);   // 兜底：一条都没有时放宽到全部

const DEFAULTS = {
  enabled: true,
  count: 1,
  maxSourceChars: 6000,
  maxDigestChars: 180,       // 概要：只挑重点，越短越好
  detailMaxChars: 800,       // 追问某一条时展开的篇幅
  // 注意：这份默认值必须和 skill.json 里的 settings.aliases 保持一致 ——
  // 配置里没有这个技能的条目时走的是这里（实测 星露谷物语 就是这样漏掉的）。
  aliases: [
    '幸福工厂|||526870', 'satisfactory|||526870',
    '戴森球计划|||1366540', '戴森球|||1366540', 'dsp|||1366540',
    '异星工厂|||427520', 'factorio|||427520',
    '星露谷物语|||413150', 'stardew|||413150',
    '泰拉瑞亚|||105600', 'terraria|||105600',
    '我的世界|||1313860', '环世界|||294100', 'rimworld|||294100',
    '缺氧|||457140', '都市天际线|||255710', '文明6|||289070',
    '怪猎崛起|||1446780', '艾尔登法环|||1245620', '黑神话悟空|||2358720',
  ].join('\n'),
};

let api = null;
let log = () => {};
const stats = { calls: 0, resolved: 0, fetched: 0, summarized: 0, networkFails: 0, lastError: '' };
/** 别名/搜索结果的进程内缓存（appid 不会变，缓存久一点没关系） */
const appCache = new Map();

export function setup(a) {
  api = a;
  log = (typeof a?.log === 'function' ? a.log : () => {});
  a.registerTool({
    id: 'game_update_digest',
    name: '游戏更新概要',
    category: 'knowledge',
    icon: '🆕',
    description: '查某个游戏最近在 Steam 上更新了什么，返回一份**已翻译并归纳好、带更新时间**的概要。'
      + '群友问「XX 更新了啥 / XX 最近更新日志 / XX 出什么新版本了」时用。'
      + 'game 传游戏名（中文或英文都行）；群友想听最近几次就传 count=2~3。',
    parameters: {
      type: 'object',
      additionalProperties: false,
      properties: {
        game: { type: 'string', description: '游戏名，中文或英文都可以，例如「幸福工厂」「戴森球计划」「Factorio」。' },
        count: { type: 'number', description: '抓最近几条更新，1~5，默认 1。群友说「最近几次更新」就传 2~3。' },
        detail: { type: 'number', description: '群友**追问上一条概要里的某一点**时用：传那一行的序号（1 起），会把那条更新详细展开。平时不要传。' },
      },
      required: ['game'],
    },
    async execute(ctx, args = {}) {
      stats.calls += 1;

      // ★ 追问分支：群友在追「上一条概要里的第 N 点」→ 把那条详细展开，不重新抓
      //   ⚠️ 这一段必须排在"game 不能为空"检查**之前** ——
      //      追问时模型只会传 detail、不传 game（见 howToReport 第 3 条），
      //      先检查 game 的话追问永远直接被拒。
      if (args.detail !== undefined && args.detail !== null && args.detail !== '') {
        const rec = recallUpdates(ctx.chatKey);
        if (!rec) return bad('上次那份更新列表已经过期（超过 30 分钟）。重新查一次，再让群友追问。');
        const idx = Number(args.detail);
        const item = rec.items.find((x) => x.index === idx);
        if (!item) return bad(`刚才那份列表里没有第 ${idx} 条（可选 1~${rec.items.length}）。把可选范围告诉群友。`);
        let text = '';
        try {
          text = await digest(item, { zh: item.zh, maxChars: settings().detailMaxChars, mode: 'detail' });
        } catch (error) { stats.lastError = String(error?.message ?? error); }
        if (!text) text = fallbackSummary(item.body, settings().detailMaxChars);
        return ok({
          game: rec.game,
          index: idx,
          title: item.title,
          time: item.timeText,
          content: `【${rec.game}】${item.title}\n更新时间：${item.timeText}\n${text}`,
          note: '这是群友追问的那一条的**详细展开**。按它回话即可，一条消息发完；不要把整份概要重复一遍。',
        });
      }

      const game = String(args.game || '').trim();
      if (!game) return bad('game 不能为空 —— 得先知道要查哪个游戏（追问才用 detail）。');

      // ① 游戏名 → appid
      let hit;
      try {
        hit = await resolveAppId(game);
      } catch (error) {
        const msg = String(error?.message ?? error);
        stats.lastError = msg;
        stats.networkFails += 1;
        log(`${SKILL_ID} 解析 appid 失败：${msg}`);
        if (isNetworkError(error)) {
          // ★ 网络问题必须说成网络问题（见文件头注释）—— 别让群友一直换关键词试
          return bad(`${networkFailText(msg)}\n\n【怎么回话】告诉群友是网络没通、挂个梯子再试；**不要**说成"没查到这个游戏"，也**不要**让他换关键词。`);
        }
        return bad(`查 Steam 的时候出错了（${msg}）。如实告诉群友暂时查不到，别编内容。`);
      }
      if (!hit) {
        return bad(`Steam 上没找到叫「${game}」的游戏。让群友确认一下名字（换成英文名或全名再试），不要自己猜是哪款。`);
      }
      stats.resolved += 1;

      // ② 拉更新公告
      const want = clampNum(args.count, settings().count, 1, 5);
      let updates;
      try {
        updates = await fetchUpdates(hit.appid, want);
      } catch (error) {
        const msg = String(error?.message ?? error);
        stats.lastError = msg;
        stats.networkFails += 1;
        log(`${SKILL_ID} 拉公告失败：${msg}`);
        if (isNetworkError(error)) {
          return bad(`${networkFailText(msg)}\n\n【怎么回话】告诉群友是网络没通、挂个梯子再试；**不要**说成"这个游戏没更新"。`);
        }
        return bad(`拉 ${hit.name} 的更新公告时出错了（${msg}）。如实说查不到。`);
      }
      stats.fetched += 1;
      if (!updates.length) {
        return ok({
          game: hit.name,
          appid: hit.appid,
          found: 0,
          content: `${hit.name}（Steam）最近没有发布更新公告。`,
          note: '如实转告群友"最近没有更新公告"，不要编。',
        });
      }

      // ③ 逐条翻译 + 归纳
      const out = [];
      const forDetail = [];       // 落盘给"追问展开"用的完整记录
      let seq = 0;
      for (const u of updates) {
        seq += 1;
        const zh = looksChinese(u.body);
        let summary = '';
        try {
          summary = await digest(u, { zh, maxChars: settings().maxDigestChars, mode: 'highlight' });
          if (summary) stats.summarized += 1;
        } catch (error) {
          stats.lastError = String(error?.message ?? error);
          log(`${SKILL_ID} 归纳失败（退回原文摘要）：${stats.lastError}`);
        }
        out.push({
          index: seq,
          title: u.title,
          time: fmtTime(u.time),
          timeAgo: ago(u.time),
          sourceLang: zh ? '中文' : '外文（已翻译）',
          url: u.url,
          summary: summary || fallbackSummary(u.body, settings().maxDigestChars),
          summarized: Boolean(summary),
        });
        forDetail.push({ index: seq, title: u.title, zh, timeText: `${fmtTime(u.time)}（${ago(u.time)}）`, body: u.body.slice(0, clampNum(settings().maxSourceChars, 6000, 500, 20000)) });
      }
      // 存下来：群友追问"第 N 条"时用（不发进上下文，省 token）
      rememberUpdates(ctx.chatKey, hit.name, forDetail);

      // ④ 组装给模型看的结论
      const lines = [];
      for (const u of out) {
        lines.push(`【${hit.name}】${u.title}`);
        lines.push(`更新时间：${u.time}（${u.timeAgo}）`);
        if (u.summary) lines.push(u.summary);
        lines.push('');
      }
      return ok({
        game: hit.name,
        appid: hit.appid,
        matchedBy: hit.how,
        found: out.length,
        updateTimes: out.map((u) => `${u.title} → ${u.time}`),
        updates: out,
        content: lines.join('\n').trim(),
        note: '上面就是结论，可直接按它回话。**必须带上更新时间**；外文公告已经翻成中文了，不要再自己翻一遍。'
          + '如果条目里有原文链接需要给群友，可以附在最后。不要在群里复述这份 JSON。',
        // ★ 汇报口径 ——
        //   概要只挑重点讲，别把几十条修复全倒出来刷屏；群友追问某一条时再展开。
        howToReport: [
          '1. **只讲重点**：上面 content 已经是挑过的重点，按它一两句话讲完就行，不要再自己补充细节、不要逐条罗列。',
          '2. **必须带上更新时间**（content 里那行）。',
          '3. **群友追问某一条时再展开**：他说「第 2 条那个详细说说」「修复了什么」这类，就再调一次 game_update_digest，**只传 detail=那一行的序号**（game 可以不传），会返回那一条的详细内容。',
          '4. 追问回来的详细内容也保持简洁（一条消息），讲完就停；他不再追问就不用再展开别的条目。',
        ].join('\n'),
      });
    },
  });
}

// ── 设置 ────────────────────────────────────────────────────────────
function settings() {
  let raw = {};
  try { raw = (api && typeof api.config === 'function' ? api.config() : null) || {}; } catch { /* 没就绪用默认 */ }
  const out = { ...DEFAULTS };
  for (const [k, v] of Object.entries(raw)) if (v !== undefined && v !== null) out[k] = v;
  return out;
}

/** 别名表：「别名|||appid」，一行一条。 */
function aliasTable() {
  const map = new Map();
  for (const line of String(settings().aliases || '').split(/\n+/)) {
    const [name, id] = line.split('|||');
    const n = String(name || '').trim().toLowerCase();
    const a = String(id || '').trim();
    if (n && /^\d+$/.test(a)) map.set(n, Number(a));
  }
  return map;
}

// ── 网络问题识别 ────────────────────────────────────────────────────
// 为什么单独拎出来：这个技能的所有失败长得都一样（一句"查不到"），
// 但底下是两种完全不同的原因 ——
//   · 游戏名写错 / 群里没这份公告 → 让群友换个名字说，是**用户**要动
//   · 连不上 store.steampowered.com → 是**网络**问题，群友挂个梯子就好
// 混在一起说"没查到"，群友会一直换关键词试，永远试不出来。
const NETWORK_ERR_RE = /fetch failed|ENOTFOUND|EAI_AGAIN|ECONNREFUSED|ECONNRESET|ETIMEDOUT|EPIPE|socket hang up|UND_ERR|Connect Timeout|network|aborted|timeout|超时/i;

/** 这个错误是不是"网没通"。 */
export function isNetworkError(err) {
  const msg = String(err?.message ?? err ?? '');
  const code = String(err?.cause?.code ?? err?.code ?? '');
  return NETWORK_ERR_RE.test(msg) || NETWORK_ERR_RE.test(code);
}

/** 给群友看的"网络没通"话术（不是给模型看的技术报错）。 */
function networkFailText(what) {
  return [
    `连不上 Steam，这次是**网络问题** —— 不是游戏名写错，也不是群里没这份公告。`,
    '',
    '这个技能要访问 store.steampowered.com。国内直连时通时不通（实测会卡十几秒然后失败），',
    '**把梯子挂上再试一次**就行 —— 本地代理开着的话它就自动走代理，不用改任何设置。',
    '',
    `（刚才卡在：${what}）`,
  ].join('\n');
}

// ── 带重试的 JSON 请求 ──────────────────────────────────────────────
// Steam 这两张口子偶尔会慢到 20 秒以上（实测 fetchUpdates 超时过），
// 所以统一走这里：超时 40 秒、失败再试一次，并把最后一次的真实原因抛出去。
/** 和 fetchJson 同款的带重试 POST（给模型接口用）。 */
async function fetchWithRetry(url, init, { timeoutMs = 70000, retries = 1 } = {}) {
  let lastErr = null;
  for (let i = 0; i <= retries; i += 1) {
    try {
      return await fetch(url, { ...init, signal: AbortSignal.timeout(timeoutMs) });
    } catch (error) {
      lastErr = error;
      if (i < retries) await new Promise((s) => setTimeout(s, 1200));
    }
  }
  throw new Error(String(lastErr?.message ?? lastErr));
}

async function fetchJson(url, { timeoutMs = 40000, retries = 1, label = 'Steam' } = {}) {
  let lastErr = null;
  for (let i = 0; i <= retries; i += 1) {
    try {
      const res = await fetch(url, { headers: UA, signal: AbortSignal.timeout(timeoutMs) });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      return await res.json();
    } catch (error) {
      lastErr = error;
      if (i < retries) await new Promise((s) => setTimeout(s, 900));
    }
  }
  const msg = String(lastErr?.message ?? lastErr);
  throw new Error(`${label} 请求失败（试了 ${retries + 1} 次）：${/timeout|aborted/i.test(msg) ? '超时' : msg}`);
}

// ── 最近一次查询的完整结果（供「追问展开」用）────────────────────
// 为什么不塞进工具返回：公告原文动辄几万字，塞进上下文是白烧 token。
// 落一份在 data 下；30 分钟内群友追问第 N 条时直接取。
const DETAIL_FILE = () => path.join(DATA_DIR, 'game-updates', 'pending-detail.json');
const DETAIL_TTL_MS = 30 * 60 * 1000;

function loadDetails() {
  try { return JSON.parse(fs.readFileSync(DETAIL_FILE(), 'utf8')) || {}; } catch { return {}; }
}
/** 记下这次查到的几条更新（含正文），供追问展开。 */
function rememberUpdates(chatKey, game, items) {
  const all = loadDetails();
  const now = Date.now();
  for (const k of Object.keys(all)) if (!all[k]?.at || now - all[k].at > DETAIL_TTL_MS) delete all[k];
  all[chatKey] = { at: now, game, items };
  try {
    fs.mkdirSync(path.dirname(DETAIL_FILE()), { recursive: true });
    fs.writeFileSync(DETAIL_FILE(), JSON.stringify(all), 'utf8');
  } catch { /* 写不进去只影响"追问"那一步 */ }
}
function recallUpdates(chatKey) {
  const rec = loadDetails()[chatKey];
  if (!rec?.at || Date.now() - rec.at > DETAIL_TTL_MS) return null;
  return rec;
}

// ── 游戏名 → appid ──────────────────────────────────────────────────
async function resolveAppId(term) {
  const key = String(term).trim().toLowerCase();
  if (appCache.has(key)) return appCache.get(key);

  // ① 别名表先命中（中文名走这里，不用联网搜）
  const alias = aliasTable().get(key);
  if (alias) {
    const hit = { appid: alias, name: String(term).trim(), how: '别名表' };
    appCache.set(key, hit);
    return hit;
  }

  // ② 纯数字：当 appid 直接用
  if (/^\d{3,9}$/.test(key)) {
    const hit = { appid: Number(key), name: `appid ${key}`, how: '直接给的 appid' };
    appCache.set(key, hit);
    return hit;
  }

  // ③ Steam 商店搜索
  const url = `${SEARCH_API}?term=${encodeURIComponent(term)}&cc=CN&l=schinese`;
  const j = await fetchJson(url, { timeoutMs: 30000, retries: 1, label: 'Steam 商店搜索' });
  const items = Array.isArray(j?.items) ? j.items : [];
  if (!items.length) { appCache.set(key, null); return null; }

  // 优先"名字完全对上/包含"的那个；否则取第一个（商店已按相关度排）
  const pick = items.find((x) => String(x.name || '').toLowerCase() === key)
    || items.find((x) => String(x.name || '').toLowerCase().includes(key))
    || items[0];
  const hit = { appid: Number(pick.id), name: String(pick.name || term).trim(), how: 'Steam 商店搜索' };
  appCache.set(key, hit);
  return hit;
}

// ── 拉更新公告 ──────────────────────────────────────────────────────
async function fetchUpdates(appid, count) {
  // 多抓几条再筛：events 里混着活动/直播/促销，只有 12/13/14 是更新公告（见上面常量注释）
  const want = Math.max(1, Math.min(5, Number(count) || 1));
  const url = `${EVENTS_API}?clan_accountid=0&appid=${appid}&offset=0&count=${Math.max(16, want * 6)}&l=schinese`;
  const j = await fetchJson(url, { timeoutMs: 45000, retries: 2, label: 'Steam 公告接口' });
  const events = Array.isArray(j?.events) ? j.events : [];

  const pick = (types) => {
    const acc = [];
    for (const e of events) {
      if (!types.has(Number(e?.event_type))) continue;
      const ab = e.announcement_body || {};
      const body = stripBbcode(String(ab.body || ''));
      if (!body.trim()) continue;                    // 没有正文的（纯活动）跳过
      const t = Number(ab.posttime || e.rtime32_start_time || 0);
      acc.push({
        title: String(ab.headline || e.event_name || '(无标题)').trim(),
        body,
        time: t * 1000,
        url: `https://store.steampowered.com/news/app/${appid}/view/${e.gid || ''}`,
      });
    }
    return acc.sort((a, b) => b.time - a.time).slice(0, want);
  };
  const out = pick(UPDATE_EVENT_TYPES);
  // 一个都没有（小众游戏可能只用 28）→ 放宽到全部类型，别硬说"没更新"
  if (!out.length) return pick(ALL_EVENT_TYPES);
  return out;
}

// ── 翻译 + 归纳（走配置里那个模型）────────────────────────────────
async function digest(u, { zh, maxChars, mode = 'highlight' }) {
  const conf = getConfig();
  const base = String(conf?.api?.baseUrl || '').replace(/\/+$/, '');
  const key = String(conf?.api?.apiKey || '');
  const model = String(conf?.api?.model || '');
  if (!base || !key || !model) throw new Error('没配好模型（baseUrl/apiKey/model 缺一个）');

  const cap = clampNum(maxChars, 500, 100, 1500);
  const src = String(u.body).slice(0, clampNum(settings().maxSourceChars, 6000, 500, 20000));

  const sys = [
    '你在帮一个 QQ 群友归纳游戏更新公告。',
    mode === 'detail'
      ? '现在是**追问展开**模式：群友想细看这一次更新的某个方面，把公告里相关的条目尽量讲完整。'
      : '现在是**概要**模式：群友只想知道"这次更新改了啥"，只挑最重要的几点讲。',
    '硬规则：',
    `1. 只输出归纳本身，不要开场白、不要"以下是"、不要结尾总结，不要用 markdown 标题。`,
    `2. 全文不超过 ${cap} 个字，越紧凑越好。`,
    mode === 'detail'
      ? '3. 可以分段讲，允许保留必要的细节（物品名、数值、机制说明）。'
      : '3. **只挑 3~4 条最重要的**，每条**一行、不超过 40 字**（新内容、机制改动、影响大的平衡调整优先；细碎的 bug 修复合并成一句「另外修复了若干崩溃与显示问题」即可）。**不要逐条罗列**——那是留给群友追问的。',
    '4. 用中文输出。原文是外文就翻成中文再归纳；原文已经是中文就直接归纳。',
    '5. 保留具体信息：改了哪些数值、加了什么内容、修了什么 bug。**数字、版本号、物品名一律照抄，不要含糊成"若干""一些"。**',
    '6. 按类别分行，每条一行，行首用「·」；类别名可以带，例如「新增」「平衡」「修复」。',
    '7. 别加你自己的想法、评价、推荐；公告没说的不要编。',
    '8. 公告里的宣传语、感谢语、活动广告可以省略，只留实质改动。',
    zh ? '' : '9. 原文是外文公告：先在心里翻译，**只输出中文归纳结果**，不要附英文原文。',
  ].filter(Boolean).join('\n');

  // 模型调用也重试一次：偶发 502/超时不该让整条归纳变成英文原文
  // ★★ 关键参数：reasoning_effort = 'none' ★★
  //   如果配的是**推理模型**（reasoning model），英文补丁说明会让它推理爆炸：
  //   实测 2363 字的 Factorio 公告，它把 8000 个 token 全花在 reasoning_content 上，
  //   content 一个字没吐（finish_reason=length），整条归纳直接失败。
  //   加上这个参数后同一条：**推理 0 token、耗时 14.8s → 1.9s、正文正常输出**。
  //   万一哪家 API 不认这个参数（返回 400），下面会自动去掉它重试一次。
  const mkBody = (noReason) => JSON.stringify({
    model,
    temperature: 0.3,
    max_tokens: 8000,   // 上限给够；只是上限，不是花费
    ...(noReason ? { reasoning_effort: 'none' } : {}),
    messages: [
      { role: 'system', content: sys },
      { role: 'user', content: `游戏：${u.title}\n\n公告正文：\n${src}` },
    ],
  });
  const endpoint = `${base}/chat/completions`;
  const headers = { 'content-type': 'application/json', authorization: `Bearer ${key}` };
  let res = await fetchWithRetry(endpoint, { method: 'POST', headers, body: mkBody(true) });
  if (!res.ok) {
    // 这家不认 reasoning_effort → 去掉它再试一次（那就只能接受它慢慢推理）
    log(`${SKILL_ID} reasoning_effort 不被接受（HTTP ${res.status}），去掉该参数重试`);
    res = await fetchWithRetry(endpoint, { method: 'POST', headers, body: mkBody(false) });
  }
  if (!res.ok) {
    let detail = `HTTP ${res.status}`;
    try { const t = await res.text(); if (t) detail += ' ' + t.slice(0, 160); } catch { /* 读不到就算了 */ }
    throw new Error(`模型归纳请求失败：${detail}`);
  }
  const j = await res.json();
  const choice = j?.choices?.[0] || {};
  let txt = String(choice?.message?.content || '').trim();
  txt = txt.replace(/^```[a-z]*\n?|\n?```$/g, '').trim();
  // ★ 空正文 + finish_reason=length：token 被推理吃光了 —— 这算失败，不能当"没内容"糊过去
  if (!txt && choice?.finish_reason === 'length') {
    const rk = Number(j?.usage?.completion_tokens_details?.reasoning_tokens || 0);
    throw new Error(`模型的 max_tokens 被推理吃光（reasoning ${rk || '?'} 个），正文没写出来`);
  }
  return txt;
}

/** 模型不可用时的兜底：把原文压成前若干字，至少不至于空手。 */
function fallbackSummary(body, maxChars) {
  const t = String(body).replace(/\s+/g, ' ').trim();
  const cap = clampNum(maxChars, 500, 100, 1500);
  const why = String(stats.lastError || '').slice(0, 60);
  const reason = why || '模型没返回内容';
  return t.length > cap ? `${t.slice(0, cap)}…（模型归纳失败：${reason}）` : `${t}（模型归纳失败：${reason}）`;
}

// ── 工具函数 ────────────────────────────────────────────────────────
/** 中日韩字符占比 ≥ 20% 就当它是中文公告。 */
function looksChinese(text) {
  const s = String(text || '');
  if (!s) return false;
  const cjk = (s.match(/[\u4e00-\u9fff\u3400-\u4dbf]/g) || []).length;
  const letters = (s.match(/[A-Za-z\u4e00-\u9fff\u3400-\u4dbf]/g) || []).length || 1;
  return cjk / letters >= 0.2;
}

/** 去掉 Steam 公告里的 BBCode / HTML，留纯文本。 */
function stripBbcode(s) {
  return String(s || '')
    .replace(/\[img\][\s\S]*?\[\/img\]/gi, '')
    .replace(/\[url=[^\]]*\]([\s\S]*?)\[\/url\]/gi, '$1')
    .replace(/\[\/?(b|i|u|h1|h2|h3|quote|spoiler|list|olist|\*|hr|table|tr|td|th|noparse|pre|code)[^\]]*\]/gi, '')
    .replace(/\[[^\]]{0,40}\]/g, '')
    .replace(/<br\s*\/?>/gi, '\n')
    .replace(/<[^>]{0,60}>/g, '')
    .replace(/&nbsp;/g, ' ').replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"')
    .replace(/[ \t]+\n/g, '\n')
    .replace(/\n{3,}/g, '\n\n')
    .trim();
}

function fmtTime(ms) {
  if (!ms) return '(时间未知)';
  const d = new Date(ms);
  const p = (n) => String(n).padStart(2, '0');
  return `${d.getFullYear()}/${p(d.getMonth() + 1)}/${p(d.getDate())} ${p(d.getHours())}:${p(d.getMinutes())}`;
}
function ago(ms) {
  if (!ms) return '';
  const h = (Date.now() - ms) / 3600000;
  if (h < 1) return '刚刚';
  if (h < 24) return `${Math.round(h)} 小时前`;
  const d = h / 24;
  if (d < 30) return `${Math.round(d)} 天前`;
  const mo = d / 30;
  if (mo < 24) return `${Math.round(mo)} 个月前`;
  return `${(mo / 12).toFixed(1)} 年前`;
}
function clampNum(v, dflt, min, max) {
  const n = Number(v);
  if (!Number.isFinite(n)) return dflt;
  return Math.max(min, Math.min(max, n));
}
function ok(data) { return { content: JSON.stringify(data) }; }
function bad(reason) { return { content: JSON.stringify({ ok: false, reason }) }; }

export const providers = {
  [`${SKILL_ID}.status`]: () => ({
    enabled: settings().enabled !== false,
    calls: stats.calls,
    resolved: stats.resolved,
    fetched: stats.fetched,
    summarized: stats.summarized,
    cachedGames: appCache.size,
    networkFails: stats.networkFails,
    lastError: stats.lastError,
    networkHint: stats.networkFails > 0
      ? '最近出现过连接 Steam 失败。先确认梯子/本地代理开着 —— 应用里 net-proxy 的 fallback 模式会自动走代理，不用改技能设置。'
      : '正常。连不上 Steam 时会返回明确的"网络问题"提示（不会说成"没查到"）。',
    note: '数据来自 Steam 商店的公告接口（api.steampowered.com 在本机直连不通，见文件头注释）。',
  }),
};

export const internals = { settings, resolveAppId, fetchUpdates, looksChinese, stripBbcode, fmtTime, ago, digest, appCache, stats, UPDATE_EVENT_TYPES, ALL_EVENT_TYPES, rememberUpdates, recallUpdates, isNetworkError };
