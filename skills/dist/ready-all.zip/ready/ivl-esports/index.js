// 第五人格赛事播报（v2）—— 后台定时巡检 + 有新赛果就主动说 + 被提起时回答
//
// ── 三类数据，能力不一样，代码里不能混为一谈 ─────────────────────────────
//   IVL   （职业联赛）官方 JSON 接口：逐场赛程 / 比分 / 积分榜 —— 完整
//   COA   （深渊的呼唤）只有官网「每日战报」文章：标题里常含结果，
//         **没有逐场比分、没有排行榜**，所以推送只能到"官方战报已更新"这一级
//   其他赛事 官方新闻中心公告：只有标题+链接，当"大概信息"用
// 这一差别直接写进提示词，避免模型把 COA 说成有比分有排名。
//
// ── 主动播报怎么拿到「嘴」（这是本技能最麻烦的地方）──────────────────────
// 核心的 reloadSkills 调 activate() **不带上下文**，所以 activate 里拿不到 sender；
// 能拿到 sender 的只有两处（见 plugins/bili-live-notify 的文件头注释）：
//   ① 工具 execute(ctx) —— ctx.sender
//   ② media.download 能力入参 { onebot, sender, kind, chatId, text }
// ②对群里**任何人发的任何 http 链接**都会触发（核心对每个候选链接挨个问提供者），
// 所以本技能提供一个"只点火不干活"的 media.download 提供者：收到链接就记下 sender，
// 立刻返回 { skip: true } 把机会让给真正的下载插件。
// 兜底：万一整个进程周期内一次都没点着火（比如刚启动、群里没人发链接），
// 直接用配置里的 OneBot HTTP 地址发——代价是这条消息不进入机器人自己的聊天存档
// （它以后不记得"我说过这句"）。所以只在没有 sender 时才走这条路，并打日志说明。
//
// ── 巡检时段 ─────────────────────────────────────────────────────────────
// 按设置里的 checkWindow（默认 14:00-23:30）+ intervalMinutes（默认 60）对齐到
// 时段起点整点触发；时段外不抓不推，避免半夜莫名其妙刷屏。

import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

const SKILL_DIR = path.dirname(fileURLToPath(import.meta.url));
const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36';

// 官方数据源
const PAGE_URL = 'https://ivl.163.com/saichenlist.html';
const API_BASE = 'https://comp-sync.webapp.163.com/';
const SCHEDULE_PATH = 'h55_schedule_result/free_convey';
const RANKING_PATH = 'h55_team_ranking/free_convey';
const COA_NEWS_URL = 'https://id5.163.com/sszx/news/sydhh/';   // 深渊的呼唤频道
const OTHER_NEWS_URL = 'https://id5.163.com/news/official/';   // 官网新闻中心

const FETCH_TIMEOUT_MS = 15000;
const CACHE_FILE = 'ivl-esports-cache.json';
const MAX_CACHE_AGE_MS = 7 * 24 * 3600 * 1000;
const MAX_SEEN = 400;          // 记住多少条已播报记录（去重用）
const MAX_PUSH_ITEMS = 3;      // 一次巡检最多推几条，防刷屏
const RECENT_RESULT_HOURS = 12; // 只推这么多小时内结束的比赛，避免补推陈年旧赛果

// COA 只推"结果类"文章：规则/报名这类公告不推
const COA_RESULT_RE = /战报|赛果|比分|冠军|夺冠|晋级|淘汰|小组赛|总决赛|决赛|落幕|Day\s*\d|D\d+\s*[:：]/i;

// ── 模块状态 ───────────────────────────────────────────────────────────────
// 热重载会带 ?t= 重新 import，这些变量随新实例重置 → activate 里先从磁盘恢复。
let apiRef = null;
let core = null;              // src/config.js 的动态引用（拿 DATA_DIR / allow.groups / snowluma）
let state = emptyState();
let timer = null;             // 下一次巡检的 setTimeout
let inflight = null;          // 抓取并发保护
let senderRef = null;         // 从工具/能力上下文里点着的 sender
let lastError = '';

function emptyState() {
  return {
    fetchedAt: 0,
    ivl: { uuid: '', name: '', matches: [], ranking: [] },
    coa: [],
    news: [],
    seenMatches: [],
    seenCoa: [],
    errors: []
  };
}

function log(...args) {
  try { (apiRef?.log || console.log)(...args); } catch { /* 日志失败不影响主流程 */ }
}

// ── 基础工具 ───────────────────────────────────────────────────────────────

function bjTimeStr(ms) {
  return new Intl.DateTimeFormat('sv-SE', {
    timeZone: 'Asia/Shanghai',
    year: 'numeric', month: '2-digit', day: '2-digit',
    hour: '2-digit', minute: '2-digit', hour12: false
  }).format(new Date(ms));
}

const bjNowStr = () => bjTimeStr(Date.now());

function humanAge(ms) {
  if (!ms || ms < 0) return '未知';
  const min = Math.floor(ms / 60000);
  if (min < 1) return '刚刚';
  if (min < 60) return `${min} 分钟前`;
  const hour = Math.floor(min / 60);
  if (hour < 24) return `${hour} 小时前`;
  return `${Math.floor(hour / 24)} 天前`;
}

/** "2026-11-01 18:00" → "11-01 18:00"：群里看日期就够了，不用带年份。 */
function shortTime(s) {
  const t = String(s || '').trim();
  const m = /^(\d{4})-(\d{2})-(\d{2})[ T](\d{2}:\d{2})/.exec(t);
  return m ? `${m[2]}-${m[3]} ${m[4]}` : t;
}

const STATUS_TEXT = { 0: '未开始', 1: '进行中', 2: '已结束' };

function clamp(n, min, max) { return Math.max(min, Math.min(max, n)); }

function settings() {
  let cfg = {};
  try { cfg = apiRef?.config?.() || {}; } catch { cfg = {}; }
  const num = (v, dflt, min, max) => {
    const n = Number(v);
    return Number.isFinite(n) && n > 0 ? clamp(Math.round(n), min, max) : dflt;
  };
  return {
    pushEnabled: cfg.pushEnabled !== false,
    checkWindow: String(cfg.checkWindow || '14:00-23:30'),
    intervalMinutes: num(cfg.intervalMinutes, 60, 10, 24 * 60),
    targets: String(cfg.targets ?? '').trim(),
    rankingSize: num(cfg.rankingSize, 6, 1, 10),
    watchTeams: String(cfg.watchTeams ?? '').trim(),
    seasonUuid: String(cfg.seasonUuid ?? '').trim()
  };
}

const watchList = (raw) => String(raw || '').split(/[,，、\s]+/).map((s) => s.trim()).filter(Boolean);

// ── 磁盘缓存 ───────────────────────────────────────────────────────────────
/**
 * 缓存必须放在 <安装目录>/data，**绝不能**写进技能目录：
 * 热重载监听的正是 skills/，写文件会触发"重载→抓取→写文件→再重载"的死循环。
 */
function resolveDataDir() {
  // 与 src/config.js 自己的一致优先级：env 覆盖 > 核心导出的 DATA_DIR > 向上找 <安装目录>/data
  const fromEnv = String(process.env.QQ_AGENT_DATA_DIR || '').trim();
  if (fromEnv) return fromEnv;
  if (core?.DATA_DIR) return core.DATA_DIR;
  let dir = SKILL_DIR;
  for (let i = 0; i < 6; i += 1) {
    dir = path.dirname(dir);
    try {
      if (fs.existsSync(path.join(dir, 'data', 'config.json'))) return path.join(dir, 'data');
    } catch { /* 继续向上找 */ }
  }
  return null;
}

function cachePath() {
  const dir = resolveDataDir();
  return dir ? path.join(dir, CACHE_FILE) : null;
}

function loadCacheFromDisk() {
  const file = cachePath();
  if (!file) return false;
  try {
    if (!fs.existsSync(file)) return false;
    const raw = JSON.parse(fs.readFileSync(file, 'utf8').replace(/^\uFEFF/, ''));
    if (!raw) return false;

    // v1 的形状是 { fetchedAt, competitionName, matches, ranking }：迁进 ivl 里
    const ivl = raw.ivl || (Array.isArray(raw.matches)
      ? { uuid: raw.seasonUuid || '', name: raw.competitionName || '', matches: raw.matches, ranking: raw.ranking || [] }
      : { uuid: '', name: '', matches: [], ranking: [] });
    if (!Array.isArray(ivl.matches)) ivl.matches = [];
    if (!Array.isArray(ivl.ranking)) ivl.ranking = [];

    const fetchedAt = Number(raw.fetchedAt) || 0;
    if (!fetchedAt || Date.now() - fetchedAt > MAX_CACHE_AGE_MS) return false;

    state = {
      fetchedAt,
      ivl,
      coa: Array.isArray(raw.coa) ? raw.coa : [],
      news: Array.isArray(raw.news) ? raw.news : [],
      seenMatches: Array.isArray(raw.seenMatches) ? raw.seenMatches : [],
      seenCoa: Array.isArray(raw.seenCoa) ? raw.seenCoa : [],
      errors: []
    };
    log(`已从磁盘缓存恢复赛事数据（${humanAge(Date.now() - fetchedAt)}，IVL ${ivl.matches.length} 场）`);
    return true;
  } catch (error) {
    log(`读取缓存失败（忽略，用实时抓取）：${error?.message ?? error}`);
    return false;
  }
}

function saveCacheToDisk() {
  const file = cachePath();
  if (!file) return;
  try {
    // 先写临时文件再改名，避免应用恰好退出时留下半个 JSON
    const tmp = `${file}.tmp`;
    fs.writeFileSync(tmp, JSON.stringify(state), 'utf8');
    fs.renameSync(tmp, file);
  } catch (error) {
    log(`写缓存失败（不影响功能）：${error?.message ?? error}`);
  }
}

// ── 抓取 ───────────────────────────────────────────────────────────────────

async function fetchText(url, referer) {
  const doFetch = apiRef?.fetch || globalThis.fetch;
  if (typeof doFetch !== 'function') throw new Error('没有 fetch 权限（skill.json 需要声明 web_fetch）');
  const res = await doFetch(url, {
    headers: {
      'user-agent': UA,
      referer: referer || 'https://ivl.163.com/',
      accept: 'application/json,text/html;q=0.9,*/*;q=0.8',
      'accept-language': 'zh-CN,zh;q=0.9'
    },
    signal: AbortSignal.timeout(FETCH_TIMEOUT_MS)
  });
  const text = Buffer.from(await res.arrayBuffer()).toString('utf8');
  if (!res.ok) throw new Error(`HTTP ${res.status}（${url}）`);
  return text;
}

/** 接口是 jsonp 风格，但裸请求直接回 JSON；兼容万一被包成 callback({...})。 */
function parseMaybeJsonp(text) {
  const t = String(text || '').trim();
  if (t.startsWith('{') || t.startsWith('[')) return JSON.parse(t);
  const m = /^[\w$.]+\s*\(\s*([\s\S]*?)\s*\)\s*;?\s*$/.exec(t);
  if (m) return JSON.parse(m[1]);
  throw new Error('返回内容不是 JSON');
}

/** 从官网赛程页的赛季下拉里认出当前赛季（换赛季自动跟上，不用改代码）。 */
async function discoverSeasonUuid() {
  const html = await fetchText(PAGE_URL, 'https://ivl.163.com/');
  const items = [];
  for (const m of html.matchAll(/<li[^>]*data-uuid=["']([^"']+)["'][^>]*>([^<]*)<\/li>/gi)) {
    const uuid = m[1].trim();
    const label = m[2].trim();
    const season = /(\d{4})\s*IVL\s*([春夏秋冬季])季/i.exec(label);
    if (!uuid || !season) continue;     // 「近期赛程」这类别名不算
    items.push({ uuid, label, year: Number(season[1]), order: { 春: 1, 夏: 2, 秋: 3, 冬: 4 }[season[2]] || 0 });
  }
  if (!items.length) throw new Error('官网赛程页里没找到赛季列表（页面结构可能变了）');
  items.sort((a, b) => (b.year - a.year) || (b.order - a.order));
  return items[0];
}

function teamOf(prefix, row) {
  const abbr = String(row?.[`team${prefix}Abbr`] ?? '').trim();
  const eng = String(row?.[`team${prefix}NameEng`] ?? '').trim();
  const zh = String(row?.[`team${prefix}Name`] ?? '').trim();
  return { short: abbr || eng || zh, full: zh || eng || abbr };
}

function normalizeMatch(row) {
  const status = Number(row?.scheduleStatus);
  const sa = row?.teamAWinAmount;
  const sb = row?.teamBWinAmount;
  const scoreA = sa === null || sa === undefined || sa === '' ? null : Number(sa);
  const scoreB = sb === null || sb === undefined || sb === '' ? null : Number(sb);
  let outcome = null;
  if (status === 2 && Number.isFinite(scoreA) && Number.isFinite(scoreB)) {
    // ⚠️ 只按比分判胜负：平局（1:1）时接口的 winTeamID 照样有值，用它会把平局报成有输赢
    outcome = scoreA > scoreB ? 'winA' : (scoreB > scoreA ? 'winB' : 'draw');
  }
  return {
    id: String(row?.scheduleUUID || row?.scheduleID || ''),
    start: String(row?.scheduleStartDatetime || row?.scheduleDatetime || '').trim(),
    stage: String(row?.competitionStageName || '').trim(),
    status,
    teamA: teamOf('A', row),
    teamB: teamOf('B', row),
    scoreA: Number.isFinite(scoreA) ? scoreA : null,
    scoreB: Number.isFinite(scoreB) ? scoreB : null,
    outcome
  };
}

function normalizeRanking(row) {
  const rate = Number(row?.scheduleWinRate);
  return {
    rank: Number(row?.rank) || 0,
    short: String(row?.teamAbbr || row?.teamNameEng || row?.teamName || '').trim(),
    full: String(row?.teamName || row?.teamNameEng || '').trim(),
    win: Number(row?.scheduleWinAmount) || 0,
    lose: Number(row?.scheduleLoseAmount) || 0,
    winRate: Number.isFinite(rate) ? Math.round(rate * 100) : null,
    overtime: Number(row?.scheduleOvertimeAmount) || 0
  };
}

async function fetchIvl() {
  const cfg = settings();
  let uuid = cfg.seasonUuid;
  if (!uuid) uuid = (await discoverSeasonUuid()).uuid;
  const url = (p) => `${API_BASE}${p}?competition_uuid=${encodeURIComponent(uuid)}`;
  const [scheduleText, rankingText] = await Promise.all([
    fetchText(url(SCHEDULE_PATH), PAGE_URL),
    fetchText(url(RANKING_PATH), 'https://ivl.163.com/')
  ]);
  const scheduleRows = parseMaybeJsonp(scheduleText)?.data?.data;
  const rankingRows = parseMaybeJsonp(rankingText)?.data?.data;
  if (!Array.isArray(scheduleRows) || !scheduleRows.length) throw new Error('赛程接口没返回数据（赛季编号可能不对）');

  const matches = scheduleRows.map(normalizeMatch).filter((m) => m.start && m.id)
    .sort((a, b) => a.start.localeCompare(b.start));
  const ranking = (Array.isArray(rankingRows) ? rankingRows : []).map(normalizeRanking)
    .filter((r) => r.short).sort((a, b) => a.rank - b.rank);
  return {
    uuid,
    name: String(scheduleRows[0]?.competitionName || '').trim() || '第五人格 IVL',
    matches,
    ranking
  };
}

/** 解析官网新闻列表：标题 + 绝对链接 + 日期（日期优先取 URL 里的 YYYYMMDD）。 */
function parseArticleList(html, { limit = 20 } = {}) {
  const out = [];
  const seen = new Set();
  for (const m of html.matchAll(/<a[^>]+href=["']([^"']*(?:zixun|news)\/[^"']*\.html)["'][^>]*>([\s\S]{0,240}?)<\/a>/gi)) {
    let url = m[1].trim();
    if (url.startsWith('//')) url = `https:${url}`;
    if (seen.has(url)) continue;
    const title = m[2].replace(/<[^>]+>/g, ' ').replace(/&[a-z#0-9]+;/gi, ' ').replace(/\s+/g, ' ').trim();
    if (title.length < 6) continue;
    const date = /(\d{4})(\d{2})(\d{2})/.exec(url);
    seen.add(url);
    out.push({
      id: url,
      title,
      url,
      date: date ? `${date[2]}-${date[3]}` : ''
    });
    if (out.length >= limit) break;
  }
  return out;
}

async function fetchCoa() {
  const html = await fetchText(COA_NEWS_URL, 'https://id5.163.com/');
  return parseArticleList(html, { limit: 20 });
}

async function fetchNews() {
  const html = await fetchText(OTHER_NEWS_URL, 'https://id5.163.com/');
  // 官方新闻中心包含很多非赛事内容（联动、活动），这里只留看起来跟赛事相关的
  return parseArticleList(html, { limit: 30 })
    .filter((a) => /IVL|COA|深渊|赛事|联赛|赛报|赛程|冠军|晋级|亚运|总决赛|挑战赛|杯/.test(a.title))
    .slice(0, 10);
}

/** 抓一次完整快照。三类数据各自容错：一类挂了不影响另一类。 */
async function refresh(reason = 'manual') {
  if (inflight) return inflight;
  inflight = (async () => {
    const errors = [];
    const ivl = await fetchIvl().catch((e) => { errors.push(`IVL：${e?.message ?? e}`); return null; });
    const coa = await fetchCoa().catch((e) => { errors.push(`COA：${e?.message ?? e}`); return null; });
    const news = await fetchNews().catch((e) => { errors.push(`资讯：${e?.message ?? e}`); return null; });

    if (ivl) state.ivl = ivl;
    if (coa && coa.length) state.coa = coa;
    if (news && news.length) state.news = news;
    if (ivl || (coa && coa.length)) state.fetchedAt = Date.now();

    state.errors = errors;
    lastError = errors.join('；');
    saveCacheToDisk();

    const ok = Boolean(ivl || (coa && coa.length));
    if (errors.length) log(`抓取出错（${reason}）：${errors.join('；')}`);
    log(`赛事数据已更新（${reason}）：IVL ${state.ivl.matches.length} 场 / COA ${state.coa.length} 篇 / 资讯 ${state.news.length} 条`);
    return { ok, errors };
  })();
  try { return await inflight; } finally { inflight = null; }
}

// ── 发送（主动播报只有这一条链）────────────────────────────────────────────

/** 点火的唯一入口：任何拿到 sender 的地方都走这里。 */
function arm({ sender, onebot } = {}) {
  if (sender && typeof sender.sendTextBatch === 'function') {
    if (senderRef !== sender) log('已拿到发送通道（sender），可以主动播报了');
    senderRef = sender;
    armOneBot(onebot);
    return true;
  }
  armOneBot(onebot);
  return Boolean(senderRef);
}

let onebotRef = null;
function armOneBot(onebot) {
  if (onebot && typeof onebot.call === 'function') onebotRef = onebot;
}

/** 播报到哪些群：设置优先，留空用「允许列表」里的群。 */
function resolveTargets() {
  const cfg = settings();
  const raw = String(cfg.targets || '').trim();
  const explicit = raw ? raw.split(/[,，、\s]+/).filter(Boolean) : [];
  let allowGroups = [];
  try { allowGroups = core?.getConfig?.()?.allow?.groups || []; } catch { allowGroups = []; }
  const groups = explicit.length ? explicit : allowGroups;
  const out = [];
  for (const g of groups) {
    const s = String(g).trim();
    if (!s) continue;
    if (s.includes(':')) { out.push(s); continue; }      // 已是 group:xxx / private:xxx
    if (/^\d+$/.test(s)) out.push(`group:${s}`);
  }
  return [...new Set(out)];
}

/**
 * 发消息：优先走核心 sender（有按会话串行、限频、去重、留档）；
 * 拿不到 sender 时才直连 OneBot HTTP —— 这条路的消息不会进机器人自己的聊天存档。
 */
async function sendTo(chatKey, texts) {
  const list = (Array.isArray(texts) ? texts : [texts])
    .map((t) => String(t ?? '').trim()).filter(Boolean).slice(0, MAX_PUSH_ITEMS + 1);
  if (!list.length) return { ok: false, via: 'none', error: '没有内容' };

  if (senderRef && typeof senderRef.sendTextBatch === 'function') {
    try {
      await senderRef.sendTextBatch(chatKey, list);
      return { ok: true, via: 'sender' };
    } catch (error) {
      log(`经 sender 发送失败，尝试直连：${error?.message ?? error}`);
    }
  }

  let snow = {};
  try { snow = core?.getConfig?.()?.snowluma || {}; } catch { snow = {}; }
  const httpUrl = String(snow.httpUrl || '').replace(/\/+$/, '');
  const token = String(snow.httpAccessToken || snow.accessToken || '');
  if (!httpUrl) return { ok: false, via: 'none', error: '既没拿到 sender，也没配置 OneBot httpUrl' };

  const [kind, id] = String(chatKey).split(':');
  const isPrivate = kind === 'private';
  const params = isPrivate
    ? { user_id: Number(id), message: list.join('\n') }
    : { group_id: Number(id), message: list.join('\n') };
  const doFetch = apiRef?.fetch || globalThis.fetch;
  const res = await doFetch(`${httpUrl}/${isPrivate ? 'send_private_msg' : 'send_group_msg'}`, {
    method: 'POST',
    headers: { 'content-type': 'application/json', ...(token ? { authorization: `Bearer ${token}` } : {}) },
    body: JSON.stringify(params),
    signal: AbortSignal.timeout(30000)
  });
  if (!res.ok) throw new Error(`OneBot HTTP ${res.status}`);
  const body = await res.json().catch(() => ({}));
  if (body?.status !== 'ok' && body?.retcode !== 0) {
    throw new Error(`OneBot 发送失败：retcode=${body?.retcode ?? body?.status} ${body?.wording ?? ''}`);
  }
  log(`⚠️ 经由 OneBot 直连发出（未经过 sender，这条不会记进机器人自己的聊天存档）：${chatKey}`);
  return { ok: true, via: 'onebot' };
}

// ── 新结果检测 ─────────────────────────────────────────────────────────────

function pushTextMatches(list) {
  const lines = list.map((m) => `${shortTime(m.start)} ${m.stage}${m.stage ? ' ' : ''}`
    + `${m.teamA.short} ${m.scoreA}:${m.scoreB} ${m.teamB.short}${m.outcome === 'draw' ? '（平局）' : ''}`);
  return `🏆 第五人格 IVL 赛果｜${state.ivl.name}\n${lines.join('\n')}\n`
    + `（官方数据 ivl.163.com，抓取 ${shortTime(bjTimeStr(state.fetchedAt))}）`;
}

function pushTextCoa(article) {
  return `🏆 第五人格 COA 战报更新\n${article.title}\n${article.url}\n（官方战报，非逐场比分）`;
}

/**
 * 巡检后决定要不要播报。
 * 首次运行（seen 为空）只做"标记为已读"，绝不把历史赛果一股脑推出来。
 */
async function notifyIfNeeded() {
  const cfg = settings();

  // 1) IVL：已结束、还没播过、且是最近结束的
  const finished = state.ivl.matches.filter((m) => m.status === 2);
  const seenMatches = new Set(state.seenMatches);
  const freshMatches = finished.filter((m) => !seenMatches.has(m.id));

  // 2) COA：看起来是结果类的战报，且没播过
  const seenCoa = new Set(state.seenCoa);
  const freshCoa = state.coa.filter((a) => COA_RESULT_RE.test(a.title) && !seenCoa.has(a.id));

  // 首次运行：全部记为已读，不推送
  const firstRun = state.seenMatches.length === 0 && state.seenCoa.length === 0;
  if (firstRun) {
    state.seenMatches = finished.map((m) => m.id).slice(-MAX_SEEN);
    state.seenCoa = state.coa.map((a) => a.id).slice(-MAX_SEEN);
    saveCacheToDisk();
    log(`首次运行：已把现有 ${state.seenMatches.length} 场赛果、${state.seenCoa.length} 篇 COA 资讯标记为已读，不补推历史`);
    return;
  }

  const cutoff = Date.now() - RECENT_RESULT_HOURS * 3600 * 1000;
  const isRecent = (m) => {
    const t = Date.parse(String(m.start).replace(' ', 'T') + ':00+08:00');
    return !Number.isFinite(t) || t >= cutoff;
  };
  const toPush = freshMatches.filter(isRecent)
    .sort((a, b) => b.start.localeCompare(a.start))
    .slice(0, MAX_PUSH_ITEMS);
  // 早就超出补推窗口的直接记为已读，免得它永远挂在"待推"里
  const expiredMatches = freshMatches.filter((m) => !isRecent(m));

  const markSeen = (matchIds, coaIds) => {
    state.seenMatches = [...new Set([...state.seenMatches, ...matchIds])].slice(-MAX_SEEN);
    state.seenCoa = [...new Set([...state.seenCoa, ...coaIds])].slice(-MAX_SEEN);
    saveCacheToDisk();
  };

  if (!cfg.pushEnabled) {
    // 关闭播报时"消费掉"这些新结果：打开开关后不该把关闭期间的历史一股脑推出来
    markSeen([...freshMatches.map((m) => m.id)], freshCoa.map((a) => a.id));
    if (toPush.length || freshCoa.length) log(`有新赛果但播报已关闭：IVL ${toPush.length} 场、COA ${freshCoa.length} 篇（已记为已读）`);
    return;
  }
  if (!toPush.length && !freshCoa.length) {
    if (expiredMatches.length) markSeen(expiredMatches.map((m) => m.id), []);
    return;
  }

  const targets = resolveTargets();
  if (!targets.length) {
    // 没配置播报目标：先记为已读并告警，否则每次巡检都白抓一遍
    markSeen([...freshMatches.map((m) => m.id)], freshCoa.map((a) => a.id));
    log('有新赛果但没有可播报的群（设置 targets 为空，且允许列表里没有群），本次不推');
    return;
  }

  const messages = [];
  if (toPush.length) messages.push(pushTextMatches(toPush));
  for (const a of freshCoa.slice(0, MAX_PUSH_ITEMS)) messages.push(pushTextCoa(a));

  // ⚠️ 只有**真的发出去了**才记为已读：发送失败（协议端没连上、限频等）时保留待推状态，
  //    下一轮巡检会重试。否则一条结果会因为一次网络抖动永远丢掉。
  let delivered = false;
  for (const chatKey of targets) {
    try {
      const r = await sendTo(chatKey, messages);
      if (r.ok) delivered = true;
      log(`播报${r.ok ? '成功' : '失败'}（${r.via}）：${chatKey}，IVL ${toPush.length} 场 / COA ${freshCoa.length} 篇`);
    } catch (error) {
      log(`播报失败：${chatKey} → ${error?.message ?? error}`);
    }
  }
  if (delivered) markSeen([...toPush.map((m) => m.id), ...expiredMatches.map((m) => m.id)], freshCoa.map((a) => a.id));
  else if (expiredMatches.length) markSeen(expiredMatches.map((m) => m.id), []);
}

// ── 巡检调度 ───────────────────────────────────────────────────────────────

/** "14:00-23:30" → { startMin, endMin }（分钟数，从 00:00 算）。 */
function parseWindow(str) {
  const m = /^\s*(\d{1,2}):(\d{2})\s*[-~—到至]\s*(\d{1,2}):(\d{2})\s*$/.exec(String(str || ''));
  if (!m) return { startMin: 14 * 60, endMin: 23 * 60 + 30 };
  const startMin = clamp(Number(m[1]), 0, 23) * 60 + clamp(Number(m[2]), 0, 59);
  let endMin = clamp(Number(m[3]), 0, 23) * 60 + clamp(Number(m[4]), 0, 59);
  if (endMin <= startMin) endMin = 23 * 60 + 59;
  return { startMin, endMin };
}

/** 下一次巡检时刻：对齐到时段起点 + 间隔的整数倍，并在时段收尾（23:30）补一次；过了时段排到明天。 */
function nextTickAt(nowMs = Date.now()) {
  const cfg = settings();
  const { startMin, endMin } = parseWindow(cfg.checkWindow);
  const interval = Math.max(10, cfg.intervalMinutes) * 60000;
  const day = new Date(nowMs);
  day.setHours(0, 0, 0, 0);
  const base = day.getTime() + startMin * 60000;
  const end = day.getTime() + endMin * 60000;

  const cands = [];
  for (let t = base; t <= end; t += interval) cands.push(t);
  // 时段末尾（默认 23:30）单独补一次：晚上那场往往刚打完，别等明天
  if (cands[cands.length - 1] !== end) cands.push(end);

  const next = cands.find((t) => t > nowMs);
  return next || base + 24 * 3600 * 1000;
}

function clearTimer() {
  if (timer) { clearTimeout(timer); timer = null; }
}

function armTimer() {
  clearTimer();
  const at = nextTickAt();
  // 最少等 5 秒，避免异常情况下原地打转
  const delay = Math.max(5000, at - Date.now());
  timer = setTimeout(() => { tick('schedule').catch(() => {}); }, delay);
  timer.unref?.();   // 不阻止进程退出；进程活着照常触发
  log(`下次赛事巡检：${bjTimeStr(at)}（时段 ${settings().checkWindow}，每 ${settings().intervalMinutes} 分钟）`);
}

async function tick(reason) {
  try {
    await refresh(reason);
    await notifyIfNeeded();
  } finally {
    armTimer();   // 无论成败都排下一轮
  }
}

// ── 渲染（给模型看的）──────────────────────────────────────────────────────

function matchTeam(m, name) {
  const n = String(name || '').trim().toLowerCase();
  if (!n) return false;
  return [m.teamA.short, m.teamA.full, m.teamB.short, m.teamB.full]
    .some((v) => String(v || '').toLowerCase().includes(n));
}

function matchLine(m, stars) {
  const hot = stars.length && stars.some((t) => matchTeam(m, t));
  const score = m.status === 2 && m.scoreA !== null && m.scoreB !== null ? `${m.scoreA}:${m.scoreB}` : 'vs';
  const tail = m.status === 2 && m.outcome === 'draw' ? '（平局）' : '';
  return `${hot ? '★ ' : ''}${shortTime(m.start)} ${m.stage}${m.stage ? ' ' : ''}${m.teamA.short} ${score} ${m.teamB.short}${tail}`;
}

const rankingLine = (r) => `${r.rank}. ${r.short} ${r.win}-${r.lose}${r.winRate === null ? '' : `（胜率 ${r.winRate}%）`}`;

function digestText({ focus = 'ivl', team = '', limit = 3 } = {}) {
  const cfg = settings();
  const stars = watchList(cfg.watchTeams);
  const now = bjNowStr();
  const parts = [];
  const ageMs = state.fetchedAt ? Date.now() - state.fetchedAt : Infinity;
  const stale = !state.fetchedAt || ageMs > 120 * 60000;

  const wantIvl = focus === 'all' || focus === 'ivl' || focus === 'schedule' || focus === 'result' || focus === 'ranking';
  const wantCoa = focus === 'all' || focus === 'coa' || focus === 'news';
  const wantNews = focus === 'all' || focus === 'news';

  if (wantIvl) {
    parts.push(`【第五人格 IVL · ${state.ivl.name || '赛季未知'}】`);
    const finished = state.ivl.matches.filter((m) => m.status === 2).length;
    parts.push(`数据抓取于 ${state.fetchedAt ? shortTime(bjTimeStr(state.fetchedAt)) : '—'}（${state.fetchedAt ? humanAge(ageMs) : '从未成功抓取'}）；`
      + `赛程共 ${state.ivl.matches.length} 场，已结束 ${finished} 场`);
  }
  if (state.errors.length) parts.push(`⚠️ 本次抓取有问题：${state.errors.join('；')}`);

  const teamFilter = String(team || '').trim();

  if (teamFilter) {
    const mine = state.ivl.matches.filter((m) => matchTeam(m, teamFilter));
    const upcoming = mine.filter((m) => m.status !== 2).slice(0, limit);
    const recent = mine.filter((m) => m.status === 2).reverse().slice(0, limit);
    parts.push(`\n▍${teamFilter} 的比赛`);
    if (!upcoming.length && !recent.length) {
      const all = [...new Set(state.ivl.matches.flatMap((m) => [m.teamA.short, m.teamB.short]))];
      parts.push(`没有找到「${teamFilter}」的比赛。现有战队：${all.join('、')}`);
    }
    if (upcoming.length) { parts.push('接下来：'); upcoming.forEach((m) => parts.push(`  ${matchLine(m, [])}`)); }
    if (recent.length) { parts.push('最近：'); recent.forEach((m) => parts.push(`  ${matchLine(m, [])}`)); }
    const row = state.ivl.ranking.find((r) => r.short.toLowerCase().includes(teamFilter.toLowerCase()));
    if (row) {
      parts.push(`积分榜：第 ${row.rank} 名，大场 ${row.win}-${row.lose}`
        + `${row.winRate === null ? '' : `（胜率 ${row.winRate}%）`}${row.overtime ? `，加时 ${row.overtime} 场` : ''}`);
    }
    parts.push(`\n现在（北京时间）：${now}`);
    return parts.join('\n');
  }

  if (focus === 'ivl' || focus === 'all' || focus === 'schedule') {
    const upcoming = state.ivl.matches.filter((m) => m.status !== 2 && m.start >= now).slice(0, limit);
    const later = upcoming.length ? upcoming : state.ivl.matches.filter((m) => m.status !== 2).slice(0, limit);
    parts.push(`\n▍接下来 ${later.length} 场`);
    if (!later.length) parts.push('  赛程里已经没有未开始的比赛（本阶段可能比完了）。');
    later.forEach((m) => parts.push(`  ${matchLine(m, stars)}`));
  }

  if (focus === 'ivl' || focus === 'all' || focus === 'result') {
    const recent = state.ivl.matches.filter((m) => m.status === 2).reverse().slice(0, limit);
    parts.push(`\n▍最近 ${recent.length} 场赛果`);
    if (!recent.length) parts.push('  还没有已结束的比赛。');
    recent.forEach((m) => parts.push(`  ${matchLine(m, stars)}`));
  }

  if (focus === 'ivl' || focus === 'all' || focus === 'ranking') {
    const top = state.ivl.ranking.slice(0, cfg.rankingSize);
    parts.push(`\n▍积分榜前 ${top.length}（大场 胜-负 胜率）`);
    if (!top.length) parts.push('  没拿到积分榜数据。');
    top.forEach((r) => parts.push(`  ${rankingLine(r)}`));
  }

  if (wantCoa) {
    const coa = state.coa.slice(0, Math.max(limit, 3));
    parts.push(`\n▍COA（深渊的呼唤）最新官方资讯 · ${coa.length} 条`);
    if (!coa.length) parts.push('  没拿到 COA 资讯。');
    coa.forEach((a) => parts.push(`  ${a.date ? `[${a.date}] ` : ''}${a.title}\n    ${a.url}`));
    if (coa.length) parts.push('  ⚠️ COA 只有官方每日战报，没有逐场比分和排行榜；别自己推比分。');
  }

  if (wantNews) {
    const news = state.news.slice(0, Math.max(limit, 3));
    parts.push(`\n▍其他赛事与官方资讯 · ${news.length} 条`);
    if (!news.length) parts.push('  没拿到资讯。');
    news.forEach((a) => parts.push(`  ${a.date ? `[${a.date}] ` : ''}${a.title}\n    ${a.url}`));
  }

  if (stars.length && wantIvl) {
    const hit = state.ivl.matches.filter((m) => stars.some((t) => matchTeam(m, t)));
    if (hit.length) parts.push(`\n★ = 你关注的战队（${stars.join('、')}）的比赛`);
  }

  parts.push(`\n现在（北京时间）：${now}`);
  if (stale) parts.push('提示：这份数据偏旧，如需最新结果请先调 ivl-esports__refresh 刷新。');
  parts.push('来源：第五人格赛事官网 ivl.163.com 官方赛程/积分接口 + 官网赛事中心资讯。');
  return parts.join('\n');
}

// ── 入口 ───────────────────────────────────────────────────────────────────

/** 只点火不干活：群里任何人发 http 链接都会走到这里，顺手把 sender 记下来。 */
export const providers = {
  'media.download': async (args = {}) => {
    try { arm(args); } catch { /* 点火失败不影响别的插件 */ }
    return { skip: true };   // 不认领这条链接，机会留给真正的下载插件
  }
};

export function setup(api) {
  apiRef = api;

  api.registerTool({
    id: 'digest',
    name: '查第五人格赛事',
    description: '返回第五人格赛事整合信息：IVL 接下来赛程/最新赛果/积分榜，以及 COA 和其他赛事的最新官方资讯。群友问到赛事、赛程、比分、积分榜、战队成绩时调用；问某支战队就传 team。',
    category: 'knowledge',
    icon: '🏆',
    parameters: {
      type: 'object',
      properties: {
        focus: {
          type: 'string',
          description: 'ivl=IVL 全部（默认）/ ranking=只要积分榜 / result=只要赛果 / schedule=只要接下来赛程 / coa=COA 资讯 / news=其他赛事与官方资讯 / all=全都要',
          enum: ['ivl', 'ranking', 'result', 'schedule', 'coa', 'news', 'all']
        },
        team: { type: 'string', description: '只看某支战队，例如 ACT / 成都GG / GR / 北京WBG / FPX.ZQ' },
        limit: { type: 'number', description: '每类列几条，默认 3，上限 8' }
      }
    },
    async execute(ctx, args) {
      arm(ctx);   // 工具上下文里有 sender —— 顺手完成点火
      const limit = Math.max(1, Math.min(8, Number(args?.limit) || 3));
      const focus = ['ivl', 'ranking', 'result', 'schedule', 'coa', 'news', 'all'].includes(String(args?.focus))
        ? String(args.focus) : 'ivl';
      const team = String(args?.team ?? '').trim();

      if (!state.ivl.matches.length && !state.coa.length) {
        const r = await refresh('first-use');
        if (!r.ok) {
          return {
            content: `没能抓到第五人格赛事数据：${r.errors.join('；')}\n`
              + '现在不能报赛程或比分（不要编）。可以告诉对方数据源暂时连不上，或用联网搜索查一下官方赛况。',
            isError: true
          };
        }
      }
      return { content: digestText({ focus, team, limit }) };
    }
  });

  api.registerTool({
    id: 'refresh',
    name: '刷新第五人格赛事',
    description: '立刻重新抓取一次官方赛事数据（IVL 赛程赛果积分榜 + COA/官方资讯）。群友问「今天/现在/刚打完」的结果、或工具提示数据偏旧时调用。',
    category: 'knowledge',
    icon: '🔄',
    parameters: { type: 'object', properties: {} },
    async execute(ctx) {
      arm(ctx);
      const r = await refresh('tool');
      if (!r.ok) {
        const tail = state.ivl.matches.length
          ? `\n下面仍是 ${humanAge(Date.now() - state.fetchedAt)}抓到的旧数据，回答时要说明数据没更新上。\n${digestText({ limit: 3 })}`
          : '\n目前没有任何可用数据，不要编造赛程或比分。';
        return { content: `刷新失败：${r.errors.join('；')}${tail}`, isError: true };
      }
      return {
        content: `已刷新（${state.ivl.name}）：IVL ${state.ivl.matches.length} 场（已结束 ${state.ivl.matches.filter((m) => m.status === 2).length}），`
          + `积分榜 ${state.ivl.ranking.length} 队，COA/资讯 ${state.coa.length + state.news.length} 条。\n\n${digestText({ limit: 3 })}`
      };
    }
  });

  log('第五人格赛事播报 v2 已注册（digest / refresh + 定时巡检），等待 activate');
}

/** 启用：恢复缓存 → 立刻抓一次 → 排下一次巡检。 */
export function activate() {
  if (!apiRef) return;
  if (!state.fetchedAt) loadCacheFromDisk();
  // activate 里没有 sender，主动播报要等"点火"；先按计划跑起来，点火后自然能发
  tick('activate').catch(() => {});
}

/** 禁用/热重载：必须清掉定时器，否则会留下重复巡检的幽灵任务。 */
export function deactivate() {
  clearTimer();
  log('赛事巡检已停止');
}

export function dispose() {
  clearTimer();
}

/**
 * 给测试/排障用的钩子（项目里 app.js 的 __testUsageDaily 也是这个路数）。
 * 正式运行时没有任何代码会调用它。
 */
export const __test = {
  parseWindow,
  nextTickAt,
  tick,
  notifyIfNeeded,
  state: () => state,
  seedSeen: (patch = {}) => {
    if (Array.isArray(patch.seenMatches)) state.seenMatches = patch.seenMatches;
    if (Array.isArray(patch.seenCoa)) state.seenCoa = patch.seenCoa;
  }
};

/** 惰性拿核心配置（用动态 import；失败也不让技能整体加载失败，缓存路径还有兜底）。 */
for (const href of [
  // 安装版布局：<app>/skills/<id>/index.js → <app>/src/config.js
  new URL('../../src/config.js', import.meta.url).href,
  pathToFileURL(path.resolve(SKILL_DIR, '..', '..', 'src', 'config.js')).href
]) {
  try {
    core = await import(href);
    break;
  } catch {
    core = null;
  }
}
if (!core) console.warn('[ivl-esports] 未加载到 src/config.js，将用环境变量/向上查找定位 data 目录');
