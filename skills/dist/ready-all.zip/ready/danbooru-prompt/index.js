// D 站标签查证 + 提示词生成 Skill —— 画图前先去 Danbooru 查真实存在的标签，
// 再按 Anima3 模板的规则组装成一条可直接投喂本地绘图的英文 prompt。
//
// ── 设计要点（为什么这么写）──────────────────────────────────────────────
//   · 为什么要有这个技能：Anima3 是 Danbooru 标签体系的模型，**凭空编的标签
//     命中率很低**，而且编错了不报错（模型忽略它），出图才发现跑偏。所以写 prompt
//     之前必须去 D 站把每个概念**查证**一遍，拿到真实标签。
//   · 模板怎么用：**不常驻系统提示词**（那是 10 万+ 字，只有真要画图时才有用）。
//     规则骨架（§2 输出格式 / §4 槽位顺序 / §3.1 互斥表 / §3 自检）压成 RULES 常量，
//     跟着 build_prompt 一起出现，保证不查模板也能装出合规 prompt；
//     细粒度的**标签库原文**（§6~§14）留在 references/anima3-template.md，
//     由 `anima_template` 工具**按需**取用。见下面 TEMPLATE 一节。
//   · 官方建议带自定义 User-Agent，且读请求建议 ~1 次/秒 → 多关键词**串行 + 间隔**。
//   · 查询结果落盘缓存（默认 24h），重复关键词不再打 D 站。
//   · 网络失败/查不到 → 如实返回 isError，**绝不静默降级成一个看起来正常的结果**。
//   · available() 必须是同步函数（可用性判定走同步调用链，返回 Promise 会被当成可用）。

import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

let cfg = () => ({});
let log = () => {};
let warn = () => {};

/** 构建标记：加载时打进日志。"没生效"和"没改对"必须能一眼区分。 */
const BUILD_TAG = 'v1.2.0-merged-template';

/** 缓存里的时间戳（每次成功请求后更新）。 */
let LAST_FETCH_AT = 0;

/** 日志里不打印带凭证的 URL。 */
const SECRET_PARAM = /(api_key|password|token)=/i;

// ══════════════════════════════════════════════════════════════════════════
// RULES —— Anima3 模板（v3.0）规则骨架的精简固化版
//
// 这是**用代码固化的规则**，不是让你自己推断的。出处是本技能自己的模板原文
//   references/anima3-template.md
// 的 §2（OUTPUT PROTOCOL）、§3（自检）、§3.1（互斥表）、§4（槽位顺序）。
// 标签**库**（§6~§14 的槽位词表与特殊题材配方）**不抄在这** ——
// 需要时用 `anima_template(slot=...)` 或 `anima_template(section=...)` 现取原文
// （见下面 TEMPLATE 一节），或者用 `tag_search` 到 D 站查真实存在性。
//
// 为什么规则骨架仍要固化成常量、而不是让模型每次去读模板：
//   组装 prompt 是高频动作，每次先取一轮模板 = 每次多绕一次工具调用；
//   而 §2/§3/§4 这几条是"违背了就出废图"的硬规则，必须无条件跟着 build_prompt 一起出现。
//   细粒度的标签库才走按需取用。
// ══════════════════════════════════════════════════════════════════════════
const ANIMA3_RULES = [
  '【Anima3 提示词规范（照做，别自由发挥）】',
  '',
  '一、槽位顺序 —— 靠前权重更高，必须按这个顺序排：',
  'count/gender → character/series → appearance → clothing/state → pose/action/sex',
  '→ expression/reaction → camera/shot → scene/environment → detail/mood → 自然语言补充',
  '',
  '二、输出格式（硬规则）：',
  '1. 只有 1 行，不要换行；标签之间用 ", "（英文逗号 + 一个空格）分隔。',
  '2. 全部小写英文；score_ 这类标签保留下划线。',
  '3. 禁止写权重，例如 (tag:1.2)。顺序本身就是权重。',
  '4. 禁止输出质量词（masterpiece / best quality / score_X 等）和画师名（@artist）—— 脚本会处理。',
  '5. 禁止光线/光影/色调标签（sunlight / moonlight / rim light / warm lighting 等）—— LoRA 已内置。',
  '   环境天气可以写（rain / snow / fog / steam 等）。',
  '6. 输出纯文本，不要 markdown、不要代码围栏、不要任何引导语和解释。',
  '7. 标签表达不了的内容（多人角色归属、复杂构图、特殊姿势、分镜关系）',
  '   用英文自然语言短句补充，**统一放在所有标签之后（prompt 末尾）**。',
  '',
  '三、互斥（同时出现即为错误，组装时必须排除）：',
  '· 视角：from front ✗ from behind；from above ✗ from below；looking at viewer ✗ facing away；',
  '  pov ✗ full body；close-up ✗ full body。',
  '· 身份：solo ✗ hetero / 1boy / yuri；femdom ✗ male-on-female rape；',
  '  sleeping / unconscious ✗ looking at viewer；blindfold ✗ heart-shaped pupils / rolling eyes。',
  '· 服装：completely nude ✗ 任何具体服装；pantyhose ✗ barefoot（除非 torn pantyhose）；',
  '  blindfold ✗ glasses；内衣套装（cat lingerie / lace lingerie / babydoll / negligee / chemise）',
  '  ✗ no panties / bottomless（要暴露就拆成单件：cat bra + no panties）。',
  '  ✅ 不互斥：外衣制服（maid outfit / school uniform / bunny suit 等）与 no panties 完全兼容。',
  '· 动作：standing sex ✗ lying / on back；missionary ✗ doggystyle；',
  '  cowgirl position ✗ prone bone；同一人 fellatio ✗ cunnilingus。',
  '· 同一部位细节标签 ≤2 个且不能互斥：spread toes ✗ toe scrunch / toes curling；',
  '  spread fingers ✗ clenched fist / gripping；open mouth ✗ clenched teeth / closed mouth；',
  '  rolling eyes ✗ looking at viewer；spread legs ✗ legs together。',
  '',
  '四、视线默认规则：',
  '· 单人：除非用户明确要「背影/背对/转身/侧脸/profile/from behind」，',
  '  否则必须注入 direct eye contact, facing viewer。',
  '· 两人及以上：不强制 direct eye contact，按互动关系选（如 looking at another）。',
  '',
  '五、标签总数（按复杂度）：单人 16~30；双人 22~38；多人/特殊主题 30~48。',
  '   服装槽位天然标签多（基础服装 + 材质 + 1~3 个改造维度 + 丝袜鞋类），其他槽位保持精简。',
  '',
  '六、提交前逐项自检：',
  '1) 人数一致性：count/gender 数量与实际角色数一致，无 1boy,2boys 这类矛盾。',
  '2) 互斥冲突：对照上面的互斥表，无视角/身份/服装/动作/细节矛盾。',
  '3) 无重复标签：同一标签不出现两次（强调靠位置，不靠重复）。',
  '4) 场景合理性：场景与动作物理兼容（如 underwater 不能配 cigarette）。',
  '5) 无灯光类标签。',
  '6) 标签总数在范围内。'
].join('\n');

// ══════════════════════════════════════════════════════════════════════════
// TEMPLATE —— Anima3 模板原文，**按需取用**
//
// 模板全文 10 万+ 字（§0~§15）。它**不再常驻系统提示词** —— 那些内容只有真要画图时
// 才有用，常驻等于每条消息白烧几万 token。改成：写 prompt 时用 `anima_template` 现取。
//
// 两种取法各管一段：
//   · 整章的「规则」（§2 输出格式 / §3 自检 / §3.1 互斥 / §4 槽位顺序）
//     → 已固化成上面的 ANIMA3_RULES，跟着 build_prompt 一起出现，不用额外取；
//   · 细粒度的「标签库」（§6 人数外貌 / §7 头发眼睛 / §8 服装 / §9 体位 /
//     §11 镜头 / §12 场景 / §13 质感 / §14 特殊题材配方）
//     → 用 anima_template(slot="appearance") 按槽位取、或 anima_template(section="9.3")
//       按编号取，别凭记忆编。**标签只此一份来源**（原 comfy-draw 的 anima_tags
//       派生索引已删，避免同一套标签两处维护、越走越偏）。
//
// ⚠️ 模板原文就在 references/anima3-template.md。**升级模板只改那个文件，不用改代码**
//    —— 这也是把原文留在文件里、而不是抄进常量的原因（抄进代码迟早静默漂移）。
// ══════════════════════════════════════════════════════════════════════════
const TEMPLATE_FILE = path.join(
  path.dirname(fileURLToPath(import.meta.url)), 'references', 'anima3-template.md'
);

// ── 槽位 → 模板章节 ──────────────────────────────────────────────────────
// 为什么留这张表：写 prompt 时最常问的是"这类标签在哪一节"，光记编号不现实。
// 这层映射**模板原文里没有**（原文只有章节标题），所以必须由代码提供。
// 它合并自原 comfy-draw 的 anima_tags 工具（那份派生索引已删，标签只留模板原文这一份）。
// 键与上面 SLOTS 的 id 对齐，另含只在模板里成章的 character/series 与 theme。
const SLOT_SECTIONS = {
  'count/gender': { go: '6', desc: '人数与性别、IP 角色、体型/年龄差' },
  'character/series': { go: '6.2', desc: 'IP 角色规则' },
  appearance: { go: '7', desc: '发色发型/瞳色/体型/肤色/身体部位/非人特征/身体标记' },
  'clothing/state': { go: '8', desc: '服装类型/材质/穿着状态/改造维度/道具' },
  'pose/action/sex': { go: '9', desc: '体位与动作：单人/双人前戏/双人正戏/多人/百合' },
  'expression/reaction': { go: '10', desc: '表情维度/强度/身体反应/液体/痕迹' },
  'camera/shot': { go: '11', desc: '景别/视角/POV/构图/部位聚焦/分镜' },
  'scene/environment': { go: '12', desc: '场所/场景心理/天气时辰/场景细节' },
  'detail/mood': { go: '13', desc: '画面质感/运动渲染/光学效果/氛围基调' },
  theme: { go: '14', desc: 'NTR/束缚/男娘/异种/调教/胁迫/偷窥/事后/隐奸 等特殊配方' }
};

/** 槽位名归一：认宽松写法（大小写/空格/下划线随意），也认只写前半段（如 'clothing'）。 */
function resolveSlot(name) {
  const key = String(name ?? '').trim().toLowerCase().replace(/[\s_]+/g, '/');
  if (!key) return null;
  if (SLOT_SECTIONS[key]) return { slot: key, ...SLOT_SECTIONS[key] };
  const head = key.split('/')[0];
  const found = Object.keys(SLOT_SECTIONS).find((s) => s.split('/')[0] === head);
  return found ? { slot: found, ...SLOT_SECTIONS[found] } : null;
}

/** 槽位清单（查不到槽位时回给模型）。 */
function slotListText() {
  return Object.entries(SLOT_SECTIONS)
    .map(([k, v]) => `  · ${k}（§${v.go}）${v.desc}`)
    .join('\n');
}

/** 模板缓存：带 mtime+size，文件一改就自动重读。 */
let TEMPLATE_CACHE = null;

/**
 * 读模板并切成章节。**读不到就抛错**，由调用方转成 isError ——
 * 绝不返回空内容（那会让模型以为"模板里没写"，转而凭记忆编标签）。
 */
function loadTemplate() {
  const st = fs.statSync(TEMPLATE_FILE);
  if (TEMPLATE_CACHE && TEMPLATE_CACHE.mtimeMs === st.mtimeMs && TEMPLATE_CACHE.size === st.size) {
    return TEMPLATE_CACHE;
  }
  const text = fs.readFileSync(TEMPLATE_FILE, 'utf8').replace(/^\uFEFF/, '');
  const lines = text.split(/\r?\n/);
  const sections = [];
  lines.forEach((line, i) => {
    const m = /^(#{2,3})\s+(.+?)\s*$/.exec(line);
    if (m) sections.push({ level: m[1].length, title: m[2], line: i, num: '' });
  });
  sections.forEach((s, i) => {
    const end = i + 1 < sections.length ? sections[i + 1].line : lines.length;
    s.body = lines.slice(s.line, end).join('\n').trimEnd();
    // 章节号取标题开头：'4. SLOT ORDER' → 4；'4.1 xxx' → 4.1
    const n = /^(\d+(?:\.\d+)?)\s*[.、]?\s+/.exec(s.title);
    if (n) s.num = n[1];
  });
  TEMPLATE_CACHE = { mtimeMs: st.mtimeMs, size: st.size, sections, text, chars: text.length };
  return TEMPLATE_CACHE;
}

/**
 * 按 section 参数挑章节。
 *   '4'    → §4 以及它的全部子节（4.1~4.6）
 *   '9.3'  → 只取 §9.3
 *   '束缚' → 编号报不上来时按标题关键词找
 *   '龟甲缚' → 标题里也没有时**搜正文**（合并自原 anima_tags 的关键词检索：
 *             概念常写在正文说明里而不是标题里，光看标题会"查不到"）
 */
function pickTemplateSections(tpl, want) {
  const raw = String(want ?? '').trim();
  if (!raw) return [];
  const key = raw.replace(/^[§#\s]+/, '').replace(/[.、\s]+$/, '');
  if (key) {
    const byNum = tpl.sections.filter((s) => s.num && (s.num === key || s.num.startsWith(`${key}.`)));
    if (byNum.length) return byNum;
  }
  const lower = raw.toLowerCase();
  const byTitle = tpl.sections.filter((s) => s.title.toLowerCase().includes(lower));
  if (byTitle.length) return byTitle;
  const byBody = tpl.sections.filter((s) => s.body.toLowerCase().includes(lower));
  if (byBody.length) return byBody;
  return key ? tpl.sections.filter((s) => s.num && s.num.startsWith(key)) : [];
}

/** 目录：只列顶级章 + 它的子节编号，够模型定位即可（别把 92 个标题全铺开）。 */
function templateToc(tpl) {
  const lines = [`【Anima3 模板目录】全文 ${tpl.chars} 字，共 ${tpl.sections.length} 节。`];
  for (const s of tpl.sections.filter((x) => x.level === 2)) {
    const kids = tpl.sections.filter((x) => x.level === 3 && x.num.startsWith(`${s.num}.`));
    const kidTxt = kids.length ? `　子节 ${kids.map((k) => k.num).join(' ')}` : '';
    lines.push(`§${s.num || '?'} ${s.title}${kidTxt}`);
  }
  lines.push('');
  lines.push('取用方式：anima_template(section="4") 取整章（含子节）；section="9.3" 取单节；'
    + '记不住编号就传标题关键词（如 section="束缚"）。');
  lines.push('⚠️ 需要具体标签时**照着原文抄**，不要凭记忆改写 —— 模型认不出的标签写进去不报错、就是没效果。');
  return lines.join('\n');
}

// ══════════════════════════════════════════════════════════════════════════
// 槽位归类（辅助，不是硬校验）
//
// 为什么要做：光把标签按用户给的顺序排出来，槽位顺序错了就要靠模型自己重排 ——
// 我们既然已经有模板，就应该顺手把顺序排对。
// 这只是**启发式关键词匹配**，匹配不到的落到 other 并提示模型自己核对。
// ══════════════════════════════════════════════════════════════════════════

// 顺序 = 输出顺序 = 判定优先级（先判的先归位）。
// ⚠️ 两条踩过的坑，改这里之前先看：
//   1) **不能用 `\b` 词边界**。标签里的 `_` 是 JS 正则的单词字符，所以
//      `\bhair\b` 匹配不到 `blue_hair` —— 曾经因此让 blue_hair / full body
//      这类最常见的标签全部落到 other。判定前统一把 `_` 换成空格，再按短语整词匹配。
//   2) count/gender 用**整串锚定**，其余用 `(^| )…( |$)` —— 这样 `hairband`
//      不会被当成 hair，而 `blue hair` 能命中。
const SLOTS = [
  {
    id: 'count/gender',
    label: '人数/性别',
    re: /^(solo|1girl|1boy|2girls|2boys|3girls|3boys|\d+ ?(girl|boy)s?|multiple (girls|boys)|group sex|hetero|yuri|yaoi|futanari|otoko no ko|femboy|trap|male focus|female focus|no humans)$/
  },
  {
    id: 'expression/reaction',
    label: '表情/反应',
    // 放在 appearance 前面：`looking at another` 这类要归表情，不能落到五官
    re: /(^| )(smile|smirk|grin|blush|tears?|crying|expressionless|serious|angry|embarrassed|shy|surprised|scared|fear|sweat|drool|saliva|tongue|parted lips|open mouth|closed mouth|clenched teeth|biting|half closed|heavy lidded|rolling eyes|empty eyes|heart shaped|ahegao|moaning|screaming|panting|heavy breathing|in heat|drunk|aroused|after sex|stained|juice|cum|liquid|trembling|shivering|nose blush|orgasm|ecstasy|seductive|smug|dominant|submission|helpless|looking at (viewer|another)|looking back|looking away|looking down|looking up|eye contact|facing (away|viewer)|heart)( |$)/
  },
  {
    id: 'appearance',
    label: '外貌',
    re: /(^| )(hair|bangs|ahoge|sidelocks|twintails?|ponytail|braid|bun|eyes?|pupils?|eyelashes|heterochromia|sclera|skin|breasts?|nipples?|areola|areolae|thighs?|hips|waist|legs?|navel|midriff|collarbone|abs|muscular|petite|curvy|voluptuous|plump|slim|slender|tomboy|mature female|loli|shota|ears?|tails?|horns?|wings?|halo|elf|demon|succubus|angel|dragon|scales|fangs|freckles|mole|tattoo|scar|piercing|pubic hair|pussy|anus|clitoris|penis|testicles|erection|foreskin|androgynous|crossdressing|monster girl|mermaid|vampire|werewolf|zombie|ghost|slime|doll|furry|anthro|soles|toes|narrow waist|wide hips)( |$)/
  },
  {
    id: 'clothing/state',
    label: '服装/穿着状态',
    re: /(^| )(uniform|serafuku|sailor|school|outfit|dress|skirt|shirt|blouse|jacket|coat|suit|tuxedo|kimono|yukata|hanfu|cheongsam|qipao|maid|nurse|police|doctor|teacher|office lady|waitress|bunny|race queen|witch|nun|saint|armor|lingerie|bra|panties|thong|g string|swimsuit|bikini|leotard|bodystocking|bodysuit|catsuit|pantyhose|thighhighs|stockings|socks|fishnets|boots|heels|shoes|sneakers|loafers|mary janes|gloves|elbow gloves|collar|choker|leash|blindfold|gag|handcuffs|shackles|ropes|chains|corset|garter|apron|scarf|hat|cap|headdress|veil|ribbon|bowtie|belt|harness|pasties|lotion|oil|nude|naked|topless|bottomless|undressed|clothed|barefoot|wet clothes|torn|ripped|damaged|see through|off shoulder|strap slip|open (shirt|jacket|kimono)|unbuttoned|unzipped|shirt lift|skirt lift|clothes lift|micro skirt|crop top|latex|leather|pvc|fishnet)( |$)/
  },
  {
    id: 'pose/action/sex',
    label: '姿势/动作',
    re: /(^| )(sex|fellatio|cunnilingus|handjob|footjob|paizuri|masturbation|missionary|doggystyle|cowgirl|pegging|tribadism|fingering|spitroast|gangbang|penetration|insertion|deepthroat|irrumatio|vaginal|anal|creampie|bukkake|position)( |$)|(^| )(standing|sitting|kneeling|squatting|crawling|bending|bent over|presenting|straddling|on all fours|on back|spread legs|legs together|arms up|arched back|touching self|hand on|grabbing|holding|licking|lift|lifting|undressing|stripping|pulling|spreading|crossed legs|bow|salute|dancing|walking|running|jumping|sleeping|lying|laying|hugging|kissing|carrying|pinned|restrained|suspended|riding)( |$)/
  },
  {
    id: 'camera/shot',
    label: '镜头/景别',
    re: /(^| )(from (front|behind|above|below|side|outside)|pov|full body|cowboy shot|upper body|lower body|close up|closeup|portrait|wide shot|dutch angle|top down|bottom up|over shoulder|symmetrical|profile|zoom|fish eye|panorama|split screen|multiple views|scan|panel|selfie)( |$)/
  },
  {
    id: 'scene/environment',
    label: '场景/环境',
    re: /(^| )(bedroom|bed|bathroom|shower|kitchen|classroom|office|hospital|library|shrine|temple|church|street|alley|rooftop|balcony|beach|pool|onsen|bath|train|bus|car|elevator|stairs|window|curtain|door|couch|sofa|chair|table|desk|floor|wall|ceiling|garden|forest|mountain|field|city|indoors|outdoors|night|day|sunset|sunrise|dawn|dusk|rain|snow|fog|steam|underwater|snowing|raining|autumn|winter|summer|spring|apartment|hotel|love hotel|dungeon|prison|public|school|park|poolside|towel|sheet|pillow|blanket|under covers|mirror|glass|frosted glass|restaurant|cafe|bar|nightclub|public bath)( |$)/
  },
  {
    id: 'detail/mood',
    label: '质感/氛围',
    re: /(^| )(motion lines|motion blur|blurry|depth of field|bokeh|lens flare|chromatic aberration|glitch|digital|vignette|film grain|noise|sketch|monochrome|greyscale|watercolor|oil painting|cel shading|flat color|dark atmosphere|atmospheric|dramatic|melancholic|serene|tense|moody|eerie|peaceful|x ray|silhouette|see through silhouette)( |$)/
  }
];

/** 标签 → 槽位 id。匹配不到返回 'other'（交给模型自己核对，不硬塞）。 */
function classifyTag(tag) {
  // 归一化：下划线当空格用（见上面坑 1 的说明）。只用于判定，不改写标签原文。
  const probe = String(tag || '').replace(/_/g, ' ');
  for (const slot of SLOTS) {
    if (slot.re.test(probe)) return slot.id;
  }
  return 'other';
}

/** 解析并归类的标签集合。纯函数，便于单测。 */
export function analyzeTags(raw) {
  const all = [];
  const invalid = [];
  for (const piece of String(raw ?? '').split(/[,\n;]+/)) {
    const t = piece.trim().toLowerCase().replace(/\s+/g, '_');
    if (!t) continue;
    // D 站标签的真实字符集：小写字母、数字、_ ( ) : ' . -
    // ⚠️ 严格点好：像 `blue hair!!!` 这种写法如果放过去，模型会照抄进 prompt，
    //    而模型根本不认这种标签 —— 出图没效果却不报错，正是本技能要防的失败模式。
    //    （`!` 不在允许集里，它会落在 invalid 并被明确回报给模型。）
    if (!/^[a-z0-9][a-z0-9_()':.-]*$/.test(t)) { invalid.push(piece.trim()); continue; }
    if (!all.includes(t)) all.push(t);
  }

  const groups = new Map();
  for (const t of all) {
    const slot = classifyTag(t);
    if (!groups.has(slot)) groups.set(slot, []);
    groups.get(slot).push(t);
  }

  // 按 SLOTS 声明顺序输出，other 排最后
  const ordered = [];
  for (const slot of SLOTS) {
    if (groups.has(slot.id)) ordered.push({ id: slot.id, label: slot.label, tags: groups.get(slot.id) });
  }
  if (groups.has('other')) ordered.push({ id: 'other', label: '未归类（请自己核对槽位）', tags: groups.get('other') });

  return { all, invalid, ordered, counts: countRoles(all) };
}

/** 从标签里推断复杂度档位，用于校验标签总数。 */
function countRoles(tags) {
  let girls = 0;
  let boys = 0;
  for (const t of tags) {
    const g = t.match(/^(\d+)girls?$/);
    const b = t.match(/^(\d+)boys?$/);
    if (g) girls += Number(g[1]);
    else if (b) boys += Number(b[1]);
    else if (t === '1girl' || t === 'solo') girls = Math.max(girls, 1);
  }
  return { girls, boys, people: girls + boys };
}

/** 标签总数 → 该落在哪个区间（模板 §4.2）。 */
function sizeBand(people) {
  if (people >= 3) return { name: '复杂（多人/特殊主题）', min: 30, max: 48 };
  if (people === 2) return { name: '标准（双人）', min: 22, max: 38 };
  return { name: '简单（单人）', min: 16, max: 30 };
}

/**
 * 组装 prompt 骨架。纯函数（不联网），便于单测。
 * 返回给模型看的文本：槽位整理后的标签 + 规则 + 自检提示。
 */
export function buildPromptText({ confirmed_tags, known_tags, description, notes } = {}) {
  const parts = [];
  if (confirmed_tags) parts.push(confirmed_tags);
  if (known_tags) parts.push(known_tags);
  if (notes) parts.push(notes);
  const analysis = analyzeTags(parts.join(', '));

  const lines = [];
  lines.push(`【标签清单】共 ${analysis.all.length} 个（已去重、已排序）`);
  if (!analysis.all.length) {
    lines.push('⚠️ 一个标签都没有。先用 tag_search 把每个概念查成真实标签，再来组装。');
  }
  for (const g of analysis.ordered) {
    lines.push(`${g.id === 'other' ? '⚠️ ' : ''}${g.id}（${g.label}）：${g.tags.join(', ')}`);
  }
  if (analysis.invalid.length) {
    lines.push(`⚠️ 这些写法不合法、已丢弃：${analysis.invalid.join(' / ')}（标签只能用小写英文、数字、_ ( ) : ' . ! -）`);
  }

  const band = sizeBand(analysis.counts.people);
  lines.push('');
  lines.push(`【用量】当前 ${analysis.all.length} 个标签；推断复杂度「${band.name}」（模板要求 ${band.min}~${band.max} 个）。`);
  if (analysis.all.length && analysis.all.length < band.min) {
    lines.push(`→ 偏少，容易出画面空洞的图。按槽位补：appearance（头发2 + 眼睛1 + 体型1 + 肤色1）、`);
    lines.push(`  clothing/state（基础服装 + 材质 + 1~3 个改造维度 + 丝袜鞋类）、camera/shot（景别至少 1 个）、`);
    lines.push(`  scene/environment（主场所 + 1 个环境锚点）。`);
  } else if (analysis.all.length > band.max) {
    lines.push('→ 偏多，模型会顾此失彼。同一部位不要堆叠多个状态标签，服装改造维度压到 2 层以内。');
  }
  if (!analysis.counts.people) {
    lines.push('→ ⚠️ 没找到 count/gender 标签（1girl / 1boy / 2girls …）。这是必填槽位，必须补上。');
  }
  if (description) lines.push(`【用户原始需求】${String(description).trim()}`);

  lines.push('');
  lines.push(ANIMA3_RULES);
  lines.push('');
  lines.push('【你要做的事】把上面的标签按槽位顺序排成一条 prompt，然后逐项自检。');
  lines.push('如果还需要上面没覆盖到的具体标签（发色发型/服装/体位/镜头/场景，或特殊题材配方），'
    + '用 anima_template(slot="appearance") 这类**槽位取法**到模板原文里抄 —— **不要凭记忆编标签**。');
  lines.push('把 assembled_prompt 用代码块单独列一次，方便用户复制 —— 除此之外不要有多余的客套话。');
  return lines.join('\n');
}

// ══════════════════════════════════════════════════════════════════════════
// 配置 / 网络 / 缓存 / 站点解析
//
// 为什么这么复杂（多站兜底 + 双协议解析）：这不是过度设计，是实测逼出来的。
// 在本机上探测的结果（2026-10 实测）：
//   danbooru.donmai.us  → TCP 直接不通（超时，被墙）
//   safebooru.donmai.us → Cloudflare 挑战，Node 直连一律 403
//   konachan / yande.re → 超时
//   gelbooru.com        → 超时
//   safebooru.org       → ✅ 200，dapi 接口返回 XML，含标签名与投稿数
// 所以只支持"官方 D 站 + JSON"的话，这个技能在用户机器上就是**完全没用**的。
// 结论：多站候选 + 自动换站 + 记住能用的那个 + 同时认 JSON/XML 两种返回。
// ══════════════════════════════════════════════════════════════════════════

function num(value, fallback, min, max) {
  const n = Number(value);
  if (!Number.isFinite(n)) return fallback;
  return Math.min(max, Math.max(min, n));
}

/** 归一化站点地址：补协议、去尾部斜杠、去空白。非法返回空串。 */
function normalizeBase(value) {
  let s = String(value ?? '').trim().replace(/\/+$/, '');
  if (!s) return '';
  if (!/^https?:\/\//i.test(s)) {
    s = /^[a-z0-9.-]+(:\d+)?(\/|$)/i.test(s) ? `https://${s.replace(/^\/+/, '')}` : '';
  }
  if (!s) return '';
  try {
    const u = new URL(s);
    if (u.protocol !== 'http:' && u.protocol !== 'https:') return '';
    return `${u.protocol}//${u.host}`;
  } catch {
    return '';
  }
}

/**
 * 站点类型：moebooru 用 /tag.json，dapi 用 /index.php?page=dapi，其余按 danbooru 处理。
 */
function siteKind(base) {
  const host = (() => { try { return new URL(base).host.toLowerCase(); } catch { return ''; } })();
  if (/donmai\.us$/.test(host)) return 'danbooru';   // danbooru / safebooru.donmai.us
  if (/konachan|yande\.re|sakugabooru/.test(host)) return 'moebooru';
  if (/safebooru\.org|gelbooru|realbooru|xbooru|rule34/.test(host)) return 'dapi';
  return 'danbooru';
}

/**
 * 判断"看起来是拼接垃圾的标签"。
 *
 * 为什么必须有这个：safebooru.org 这类站的标签表里有大量上传者手滑造出来的拼接标签
 * （`taupe+pantyhose`、`gray__pantyhose`、`taupe_pantyhose3girls`…），投稿数都是 1~2。
 * 实测查 `pantyhose` 时，模糊搜索的前 25 条**全是这类垃圾**，真正的标签（34 万投稿）根本不在里面。
 * 把这些当真标签交给模型，就是"看起来成功、实际有害" —— 比查不到更坏。
 *
 * ⚠️ 已知局限（诚实说明）：像 `blue_hairt`、`popsicleadjusting_hairblue_hair` 这种
 * "把两个词粘起来"的标签，**光看名字无法与合法复合词（black_pantyhose、frilled_cat_ears）区分**，
 * 所以只能靠"名字长度远长于用户输入的关键词"这类弱信号兜（ratio > 2.5）。
 * 真正兜住质量的是另一条规则：pickForDisplay 里"相近写法必须达到精确标签热度的一半"，
 * 而垃圾标签的投稿数通常是 1 —— 所以在精确标签存在时它们根本上不了台面。
 *
 * @param {string} name 标签名
 * @param {string} term 用户输入的关键词（用于长度比判断；不传则跳过该条判断）
 */
function looksLikeJunkTag(name, term = '') {
  const s = String(name || '');
  if (!s) return true;
  if (s.startsWith('_')) return true;              // _black_pantyhose
  if (s.includes('+')) return true;                // taupe+pantyhose
  if (s.includes('__')) return true;               // gray__pantyhose
  if (/\d+(girl|boy)s?$/.test(s) && !/^\d+(girl|boy)s?$/.test(s)) return true;  // taupe_pantyhose3girls
  // 名字远长于关键词 → 大概率是把好几段粘在一起（popsicleadjusting_hairblue_hair）
  const t = String(term || '').trim();
  if (t && s.length > Math.max(12, t.length * 2.5)) return true;
  return false;
}

/**
 * 站点协议适配：一个站点的"精确查"和"模糊查"两种 URL。
 * ⚠️ dapi 必须用 `name=` 做精确查 —— 用 `name_pattern` 只能按 id 倒序拿一串垃圾。
 *    这是实测出来的（见 looksLikeJunkTag 的注释）。
 */
function buildExactUrl(base, term, c) {
  const kind = siteKind(base);
  if (kind === 'dapi') return `${base}/index.php?page=dapi&s=tag&q=index&name=${encodeURIComponent(term)}&limit=20`;
  if (kind === 'moebooru') return `${base}/tag.json?name=${encodeURIComponent(term)}&limit=20`;
  const params = new URLSearchParams();
  params.set('search[name_normalize]', term);   // name_normalize 是精确匹配（支持逗号分隔多个）
  params.set('limit', '20');
  return `${base}/tags.json?${params.toString()}`;
}

/** 模糊查（查不到精确匹配时用）。三种站点协议各不相同。 */
function buildSearchUrl(base, term, c) {
  const kind = siteKind(base);
  if (kind === 'dapi') {
    // Gelbooru 系：name_pattern 的 % 必须转义成 %25，否则服务端解不出来
    return `${base}/index.php?page=dapi&s=tag&q=index&name_pattern=%25${encodeURIComponent(term)}%25&limit=${Math.min(100, c.maxResults * 2)}`;
  }
  if (kind === 'moebooru') {
    return `${base}/tag.json?name=${encodeURIComponent(term)}*&limit=${Math.min(100, c.maxResults * 2)}`;
  }
  const params = new URLSearchParams();
  // name_matches 支持 * 通配；末尾加 * 让 "cat_ears" 也能命中派生写法
  params.set('search[name_matches]', `${term}*`);
  params.set('search[order]', 'count');      // 按投稿数降序：先看主流标签
  if (c.hideEmpty) params.set('search[hide_empty]', 'true');
  params.set('limit', String(Math.min(100, c.maxResults * 2)));
  return `${base}/tags.json?${params.toString()}`;
}

/** 配置一律**执行时**读。setup 时快照会导致"改了设置不生效"。 */
function readConfig() {
  const c = cfg() || {};
  const primary = normalizeBase(c.apiBase) || 'https://safebooru.org';
  const fallbacks = String(c.fallbackBases ?? '')
    .split(/[,\n;]+/)
    .map(normalizeBase)
    .filter(Boolean);
  // 候选 = 首选 + 备用（去重）。allowFallback=false 时只留首选。
  const bases = [primary, ...fallbacks.filter((b) => b !== primary)];
  return {
    primary,
    bases,
    userAgent: String(c.userAgent || 'QQAgent-DanbooruPrompt/1.0 (local ComfyUI prompt helper)').trim(),
    timeoutMs: num(c.timeoutMs, 9000, 3000, 60000),
    switchDelayMs: num(c.switchDelayMs, 300, 0, 5000),
    maxResults: num(c.maxResults, 25, 5, 60),
    maxQueries: num(c.maxQueries, 6, 1, 10),
    cacheTtlHours: num(c.cacheTtlHours, 24, 0, 720),
    hideEmpty: c.hideEmpty !== false,
    minPostCount: num(c.minPostCount, 1, 0, 100000),
    relatedLimit: num(c.relatedLimit, 30, 5, 100)
  };
}

function fail(content) {
  return { content, isError: true };
}

function humanize(error) {
  const msg = String(error?.message ?? error ?? '未知错误');
  if (/abort|timeout|timed out/i.test(msg)) return '请求超时';
  if (/ENOTFOUND|EAI_AGAIN|getaddrinfo/i.test(msg)) return '域名解析失败（DNS 不通）';
  if (/ECONNREFUSED|ECONNRESET|socket hang up|fetch failed/i.test(msg)) return '连不上（连接被重置/拒绝）';
  if (/HTTP 4\d\d/.test(msg)) return msg;
  return msg;
}

function cachePath() {
  const base = process.env.QQ_AGENT_DATA_DIR || path.join(process.cwd(), 'data');
  return path.join(base, 'cache', 'danbooru-prompt-tags.json');
}

function readCache() {
  try {
    const raw = fs.readFileSync(cachePath(), 'utf8');
    const data = JSON.parse(raw);
    return data && typeof data === 'object' ? data : {};
  } catch {
    return {};
  }
}

function writeCache(data) {
  try {
    const p = cachePath();
    fs.mkdirSync(path.dirname(p), { recursive: true });
    fs.writeFileSync(p, JSON.stringify(data), 'utf8');
  } catch (error) {
    // 缓存写不进去不影响功能，只是下次还得重新查
    warn(`查询缓存写入失败（不影响使用）：${error?.message ?? error}`);
  }
}

/** 日志里不要出现带凭证的 URL。 */
function safeUrl(url) {
  return SECRET_PARAM.test(url) ? url.replace(/(api_key|password|token)=[^&]*/gi, '$1=***') : url;
}

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

/**
 * GET 一段文本。**失败抛错**，由调用方转成 isError ——
 * 绝不静默返回空结果（那会让模型以为"站点上没有这个标签"，从而编造标签）。
 */
async function fetchText(url, { timeoutMs, userAgent }, { retries = 0 } = {}) {
  let lastError;
  for (let attempt = 0; attempt <= retries; attempt += 1) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeoutMs);
    try {
      const res = await fetch(url, {
        headers: { 'User-Agent': userAgent, Accept: 'application/json, text/xml, */*' },
        signal: controller.signal
      });
      if (!res.ok) {
        // 429 = 被限频；403 = Cloudflare 挑战或被封。这两种重试也没用，直接说清楚。
        const text = await res.text().catch(() => '');
        const challenge = /Just a moment|cf-browser-verification|challenge-platform|Enable JavaScript/i.test(text);
        const hint = res.status === 429 ? '（被限频，等一会儿再试，或把「一次最多查几个关键词」调小）'
          : res.status === 403 && challenge ? '（被 Cloudflare 人机验证挡住，程序访问不了这种站）'
            : res.status === 403 ? '（被拒绝：可能需要登录，或 User-Agent 不合规）'
              : '';
        throw new Error(`HTTP ${res.status} ${res.statusText}${hint}`);
      }
      return await res.text();
    } catch (error) {
      lastError = error;
      if (attempt >= retries) break;
      await sleep(500);
    } finally {
      clearTimeout(timer);
    }
  }
  throw lastError;
}

/** 解析 XML 标签属性（不引依赖：属性顺序各站不同，逐个属性取值最稳）。 */
function parseAttrs(chunk) {
  const out = {};
  for (const m of String(chunk).matchAll(/([A-Za-z_:][\w:.-]*)\s*=\s*"([^"]*)"/g)) {
    out[m[1].toLowerCase()] = m[2];
  }
  return out;
}

function decodeEntities(s) {
  return String(s ?? '')
    .replace(/&lt;/g, '<').replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/&apos;/g, "'")
    .replace(/&amp;/g, '&');
}

/** Gelbooru/dapi 的标签名是连字符写法（cat-ears），统一成 D 站的下划线写法。 */
function normalizeTagName(name) {
  return decodeEntities(name).trim().toLowerCase().replace(/-/g, '_').replace(/\s+/g, '_');
}

/** dapi 的分类编码 → 统一分类码（与 D 站 0/1/3/4/5 对齐）。 */
function dapiCategory(raw) {
  const s = String(raw ?? '').trim().toLowerCase();
  const map = { general: 0, artist: 1, copyright: 3, character: 4, metadata: 5, meta: 5, deprecated: 0 };
  if (s in map) return map[s];
  const n = Number(s);
  return Number.isFinite(n) ? n : 0;
}

/**
 * 解析站点返回。同时支持：
 *   · Danbooru JSON： [{ name, post_count, category, is_deprecated }]
 *   · dapi XML：<tag name="cat-ears" count="3" type="general" .../>
 */
export function parseTagPayload(text) {
  const t = String(text ?? '').trim();
  const out = [];

  // ── JSON（Danbooru / moebooru）────────────────────────────────────────
  if (t.startsWith('[') || t.startsWith('{')) {
    let data;
    try { data = JSON.parse(t); } catch { return out; }
    const list = Array.isArray(data) ? data : (Array.isArray(data?.tag) ? data.tag : []);
    for (const item of list) {
      const name = String(item?.name ?? '').trim();
      if (!name) continue;
      out.push({
        name: name.toLowerCase().replace(/-/g, '_'),
        postCount: Number(item?.post_count ?? item?.count) || 0,
        category: Number(item?.category) || 0,
        deprecated: item?.is_deprecated === true || item?.deprecated === true
      });
    }
    return out;
  }

  // ── XML（dapi）────────────────────────────────────────────────────────
  // ⚠️ 用 /<tag\b/ 而不是 /<tag>/：单标签可以是自闭合的 <tag ... />
  for (const m of t.matchAll(/<tag\b([^>]*?)\/?>/gi)) {
    const attrs = parseAttrs(m[1]);
    const name = attrs.name;
    if (!name) continue;
    out.push({
      name: normalizeTagName(name),
      postCount: Number(attrs.count ?? attrs.post_count) || 0,
      category: dapiCategory(attrs.type ?? attrs.category),
      deprecated: String(attrs.deprecated ?? '') === 'true'
    });
  }
  return out;
}

// 记住"哪个站能用"。进程级：一次探测成功后，后续查询直接用它，不再重复试探被墙的站。
let WORKING_BASE = '';
// 探测过一次就置位，供 activate() 的后台预热用。
let PREWARMED = false;

/** 首选站能通就优先用它；不通就依次试备用站，谁先通用谁。 */
function candidateBases(c) {
  if (!WORKING_BASE || !c.bases.includes(WORKING_BASE)) return c.bases;
  return [WORKING_BASE, ...c.bases.filter((b) => b !== WORKING_BASE)];
}

// ⚠️ buildSearchUrl / buildExactUrl 定义在上面（与 siteKind 放在一起），这里不要重复定义 ——
// 重复声明同名函数是 SyntaxError，而且 ESM 下报错时机很晚，排查起来很费时间。

function buildRelatedUrl(base, tag, limit) {
  const kind = siteKind(base);
  if (kind === 'dapi') return '';   // dapi 没有关联标签接口
  if (kind === 'moebooru') return `${base}/tag.json?name=${encodeURIComponent(tag)}&limit=${limit}`;
  return `${base}/related_tag.json?query=${encodeURIComponent(tag)}&limit=${limit}`;
}

/**
 * 在某个站点上查一个关键词。**精确匹配为主，同时带出更主流的相近写法**。
 *
 * 为什么不是"精确命中就返回那一条"（实测教训）：safebooru.org 上确实存在一个
 * 拼写不全的冷僻标签 `thighhigh`（只有 4 张投稿），而真正主流的写法是 `thighhighs`（几十万）。
 * 如果模型查 `thighhigh` 只拿到那 4 张的那个，它会照着抄，出图质量就白丢了。
 * 所以：精确命中照样报"确实存在"，但**把明显更热门的相近写法也带出来**，由模型挑。
 *
 * 为什么两步（另一条实测教训）：直接模糊查 `pantyhose`，前 25 条全是投稿数 1 的
 * 拼接垃圾（`taupe+pantyhose`、`gray__pantyhose`…），真正的标签根本不在里面。
 * 所以模糊结果必须过一遍 looksLikeJunkTag。
 *
 * @returns {{exact: boolean, exactItem: object|null, variants: Array, junkDropped: number}}
 */
async function queryOneBase(base, term, c) {
  // ① 精确查
  const exactText = await fetchText(buildExactUrl(base, term, c), c);
  const exactItem = parseTagPayload(exactText).find((r) => r.name === term) || null;

  // ② 相近写法（模糊查 + 过滤拼接垃圾）
  let variants = [];
  let junkDropped = 0;
  try {
    const fuzzyText = await fetchText(buildSearchUrl(base, term, c), c);
    const raw = parseTagPayload(fuzzyText);
    const kept = raw.filter((r) => !looksLikeJunkTag(r.name, term));
    junkDropped = raw.length - kept.length;
    variants = kept.filter((r) => r.name !== term);
  } catch {
    // 精确已命中时，模糊轮失败不影响结论（少给几个参考写法而已）
    if (!exactItem) throw new Error('精确查与模糊查都没拿到数据');
  }

  return { exact: Boolean(exactItem), exactItem, variants, junkDropped };
}

/**
 * 决定最终呈现给模型的标签集合。
 * 规则：精确那条排第一；相近写法里**投稿数不低于精确标签的一半**的才带出来
 * （挡掉同为冷僻的噪声，只保留"明显更主流"的写法）。精确没命中时全部给出，按热度降序。
 */
function pickForDisplay(hit, limit) {
  const out = [];
  if (hit.exactItem) out.push(hit.exactItem);
  const floor = hit.exactItem ? Math.max(1, Math.floor((hit.exactItem.postCount || 0) / 2)) : 0;
  const variants = [...hit.variants]
    .sort((a, b) => (b.postCount || 0) - (a.postCount || 0))
    .filter((r) => (r.postCount || 0) >= floor);
  for (const v of variants) {
    if (out.length >= limit) break;
    if (!out.some((x) => x.name === v.name)) out.push(v);
  }
  return out.slice(0, limit);
}

/**
 * 按候选站顺序查一个关键词。返回 { results, base, errors, exact, note }。
 *
 * 换站策略：一个站要么给结果、要么抛错；给了结果就用它（精确或相近写法都算结果）。
 * 全都没结果 → 返回空 + 各站原因，由调用方**如实报错**（绝不静默变成"标签不存在"）。
 */
async function searchAcrossBases(term, c, { includeDeprecated } = {}) {
  const errors = [];
  const bases = candidateBases(c);
  const clean = (raw) => {
    let list = raw;
    if (!includeDeprecated) list = list.filter((r) => !r.deprecated);
    return list.filter((r) => r.postCount >= c.minPostCount);
  };

  for (const base of bases) {
    let hit;
    try {
      hit = await queryOneBase(base, term, c);
    } catch (error) {
      errors.push(`${base}：${humanize(error)}`);
      if (c.switchDelayMs > 0) await sleep(c.switchDelayMs);
      continue;
    }

    const list = clean(pickForDisplay(hit, Math.max(5, c.maxResults)));
    if (!list.length) {
      errors.push(hit.exact
        ? `${base}：命中了「${term}」但投稿数为 0（低于门槛 ${c.minPostCount}）`
        : `${base}：没有名字含「${term}」的标签`);
      continue;
    }

    if (WORKING_BASE !== base) {
      WORKING_BASE = base;
      log(`标签查询站点已定为 ${base}（${hit.exact ? '精确命中' : '相近写法'}「${term}」）`);
    }

    const note = hit.exact
      ? ''
      : `精确标签「${term}」在该站不存在；下面是名字里含它的相近标签`
        + `${hit.junkDropped > 0 ? `（已过滤 ${hit.junkDropped} 个拼接垃圾标签）` : ''}。用之前先确认它符合你的意思。`;
    return { results: dedupe(list), base, errors, exact: hit.exact, note };
  }

  return { results: [], base: '', errors, exact: false, note: '' };
}

/** 查关联标签（仅 danbooru 协议站点支持）。 */
async function relatedAcrossBases(tag, c, limit) {
  const errors = [];
  for (const base of candidateBases(c)) {
    const url = buildRelatedUrl(base, tag, limit);
    if (!url) { errors.push(`${base}：该站不支持「关联标签」接口`); continue; }
    try {
      const text = await fetchText(url, c);
      let data = null;
      try { data = JSON.parse(text); } catch { errors.push(`${base}：返回格式不认识`); continue; }
      const groups = Array.isArray(data?.[0]?.related_tags) ? data[0].related_tags : [];
      const out = groups.map((g) => ({
        name: String(g?.tag?.name ?? '').toLowerCase(),
        postCount: Number(g?.tag?.post_count) || 0,
        category: Number(g?.tag?.category) || 0,
        frequency: Number(g?.frequency) || 0,
        group: String(g?.category ?? 'general')
      })).filter((r) => r.name);
      if (!out.length) { errors.push(`${base}：没查到「${tag}」的关联标签`); continue; }
      if (WORKING_BASE !== base) WORKING_BASE = base;
      return { results: out.sort((a, b) => b.frequency - a.frequency || b.postCount - a.postCount), base, errors };
    } catch (error) {
      errors.push(`${base}：${humanize(error)}`);
      if (c.switchDelayMs > 0) await sleep(c.switchDelayMs);
    }
  }
  return { results: [], base: '', errors };
}

/** 分类名（统一成 D 站的分类编码）。 */
const CATEGORY = { 0: 'general', 1: 'artist', 3: 'copyright', 4: 'character', 5: 'meta' };

function categoryName(code) {
  return CATEGORY[Number(code)] || `其他(${code})`;
}

/**
 * 热度分级：给模型一个"这个标签有多主流"的直观判断。
 * ⚠️ 阈值按 D 站官方站的量级定的。safebooru.org 这类小站投稿数只有个位数到几千，
 *    同一个标签在小站会显示成「冷门」——不代表这个标签没用，只代表这个站小。
 *    所以返回里**必须同时给出站点名**，让模型知道这个数字是哪个站的口径。
 */
function heat(postCount) {
  const n = Number(postCount) || 0;
  if (n >= 100000) return '极热门';
  if (n >= 10000) return '热门';
  if (n >= 1000) return '常用';
  if (n >= 100) return '少见';
  if (n > 0) return '冷门';
  return '空标签';
}

/** 去重（按标签名，保留投稿数最高的那条）。 */
function dedupe(list) {
  const map = new Map();
  for (const item of list) {
    const prev = map.get(item.name);
    if (!prev || (item.postCount || 0) > (prev.postCount || 0)) map.set(item.name, item);
  }
  return [...map.values()];
}

function formatSearchResult(term, results, meta) {
  const lines = [];
  lines.push(`查询「${term}」→ ${results.length} 个候选（来源 ${meta.base}${meta.fromCache ? '，缓存命中' : ''}）`);
  if (meta.exact) {
    lines.push(`✅ 该站上确实存在名为「${term}」的标签（下面第一条），可以直接用。`);
    if (results.length > 1) {
      lines.push(`后面几条是名字相近、**在该站更热门**的写法 —— 如果它们更贴合你要画的东西，用更热门的那个通常出图更稳。`);
    }
  } else if (meta.note) {
    lines.push(`⚠️ ${meta.note}`);
  }
  lines.push('格式：标签名（投稿数 / 分类 / 热度）');
  for (const r of results) {
    const flag = r.deprecated ? ' ⚠️已废弃' : '';
    lines.push(`  · ${r.name}（${r.postCount} / ${categoryName(r.category)} / ${heat(r.postCount)}${flag}）`);
  }
  return lines.join('\n');
}

/**
 * 站点规模提示。不同站的投稿数量级差好几个数量级（官方 D 站百万，safebooru.org 千级），
 * 不给提示的话模型会把「冷门」当成"这个标签不好"，从而放弃一个其实很主流的标签。
 */
function sourceScaleHint(results) {
  const top = Math.max(...results.map((r) => Number(r.postCount) || 0), 0);
  if (top >= 100000) return '';
  return `ℹ️ 该站规模较小，投稿数普遍偏低（本页最大 ${top}），「冷门」不代表标签不好用，只代表这个站小。`
    + `判断标签是否主流请看名字是否精确、分类是否为 general。`;
}

// ══════════════════════════════════════════════════════════════════════════
// setup —— 注册工具
// ══════════════════════════════════════════════════════════════════════════

export function setup(api) {
  cfg = api.config || (() => ({}));
  log = api.log || (() => {});
  warn = api.warn || (() => {});

  log(`D 站标签查证技能已加载（${BUILD_TAG}）：注册 tag_search / related_tags / build_prompt / anima_template`);
  // ⚠️ 这里不要打印 api.config() 的内容：setup 跑在 skillManager.register() 之前，
  //    此刻读到的永远是空对象（comfy-draw 踩过这个坑，见它的注释）。

  // ── 工具 1：查标签 ───────────────────────────────────────────────────
  api.registerTool({
    id: 'tag_search',
    name: 'D 站查标签（真实存在性 + 热度）',
    category: 'media',
    icon: '🔎',
    description: '到 Danbooru（D 站）搜索标签，返回**真实存在**的标签名、投稿数（热度）和分类。'
      + '用途：准备画图提示词时，把中文概念翻成英文关键词后**先来这里查证**——'
      + '确认标签真的存在、以及哪个写法最主流。'
      + '什么时候用：用户要求画图/生成提示词，而你需要某个概念的英文标签时（尤其是角色名、服装、姿势、特殊题材）；'
      + '或者你拿不准某个标签是否存在。'
      + '一次可以传多个关键词（用英文逗号分隔），会逐个查（串行、有间隔，不会触发限频）。'
      + '返回里带「投稿数」：数越大说明标签越主流、出图越稳；0 或极小的不建议用。'
      + '⚠️ 本工具只查标签，**不画图、也不组装最终 prompt**（组装用 build_prompt）。'
      + '⚠️ 查不到就换个说法再查，仍然查不到就如实告诉用户这个效果模型里没有——'
      + '绝对不要凭记忆编一个看起来像的英文标签。',
    parameters: {
      type: 'object',
      additionalProperties: false,
      properties: {
        queries: {
          type: 'string',
          description: '要查证的英文关键词，多个用英文逗号分隔，例如 "cat_ears, pantyhose, blue_hair"。'
            + '先用最直白的英文词；查不到再用同义词或更宽的词。中文词请先自己翻成英文。'
        },
        limit: {
          type: 'number',
          description: '可选：每个关键词最多返回几个候选，默认用技能设置里的值（通常 25）。'
        },
        include_deprecated: {
          type: 'boolean',
          description: '可选：是否保留 D 站已废弃的标签（默认 false，废弃标签写进 prompt 通常无效）。'
        }
      },
      required: ['queries']
    },
    async execute(_ctx, args) {
      const c = readConfig();
      const raw = String(args?.queries ?? '').trim();
      if (!raw) return fail('缺少 queries：请给出要查证的英文关键词，多个用英文逗号分隔。');

      let terms = raw.split(/[,\n;]+/).map((s) => s.trim()).filter(Boolean);
      if (!terms.length) return fail(`没解析出关键词：${raw}`);
      const dropped = terms.length > c.maxQueries ? terms.slice(c.maxQueries) : [];
      terms = terms.slice(0, c.maxQueries);

      const limit = num(args?.limit, c.maxResults, 5, 60);
      const includeDeprecated = args?.include_deprecated === true;
      const ttlMs = c.cacheTtlHours * 3600 * 1000;
      const cache = readCache();
      const now = Date.now();

      const blocks = [];
      const errors = [];
      let anyLive = false;

      for (let i = 0; i < terms.length; i += 1) {
        const term = terms[i];
        const key = `search:${term.toLowerCase()}`;
        const cached = cache[key];

        let list = null;
        let fromCache = false;
        let meta = null;

        if (ttlMs > 0 && cached && Array.isArray(cached.results) && (now - Number(cached.at || 0)) < ttlMs) {
          list = cached.results;
          meta = { base: cached.base || c.primary, fromCache: true, exact: cached.exact !== false, note: cached.note || '' };
          fromCache = true;
        } else {
          // 多站兜底：先各站精确查，再各站模糊查，谁先命中用谁
          const hit = await searchAcrossBases(term, c, { includeDeprecated });
          if (hit.results.length) {
            list = hit.results;
            meta = { base: hit.base, fromCache: false, exact: hit.exact, note: hit.note };
            anyLive = true;
            cache[key] = { at: now, base: hit.base, exact: hit.exact, note: hit.note, results: list, errors: hit.errors };
            LAST_FETCH_AT = now;
          } else {
            errors.push(`「${term}」查证失败（候选站全部未返回数据）：\n    ${hit.errors.join('\n    ')}`);
            // 换站试探本身也要间隔，别把失败路径变成高频请求
            if (i < terms.length - 1) await sleep(Math.max(300, c.switchDelayMs));
            continue;
          }
          // 同一站点连续请求之间留间隔（官方建议读请求约 1 次/秒）
          if (i < terms.length - 1) await sleep(Math.max(350, c.switchDelayMs));
        }

        let shown = list;
        if (!includeDeprecated) shown = shown.filter((r) => !r.deprecated);
        shown = shown.slice(0, limit);
        // 按投稿数降序：模型先看到的就是该站上最主流的写法
        shown.sort((a, b) => b.postCount - a.postCount);

        if (!shown.length) {
          blocks.push(`查询「${term}」→ **一个都没查到**。\n`
            + `  · 换个说法再来（同义词、单数复数、更宽或更窄的词）；`
            + `中文概念请先翻成英文（例如「黑丝」→ pantyhose / thighhighs）。\n`
            + `  · ⚠️ 查不到不等于"随便写一个也行"——写进 prompt 的必须是查证过的标签，否则不会生效。`);
        } else {
          blocks.push(formatSearchResult(term, shown, meta));
          const hint = sourceScaleHint(shown);
          if (hint) blocks.push(hint);
        }
      }

      if (anyLive) writeCache(cache);

      if (!blocks.length) {
        return fail(`所有关键词都没查成。\n${errors.join('\n')}\n`
          + `下一步（按顺序试）：\n`
          + `  1) 去技能设置页把「首选站点」改成别的候选站（当前候选：${c.bases.join('、')}）；\n`
          + `  2) 确认这台机器能上网（被墙的站怎么配都不通）；\n`
          + `  3) 或者放弃联网查证，用你确定存在的标签走 build_prompt(known_tags=..., skip_reason=...) 并如实说明没能查证。`);
      }

      const tail = [];
      if (dropped.length) tail.push(`⚠️ 一次最多查 ${c.maxQueries} 个关键词，这些没查：${dropped.join(', ')}（可再调一次）。`);
      if (errors.length) tail.push(errors.join('\n'));
      tail.push('—— 拿到标签后：需要看「还该搭配什么」用 related_tags；'
        + '组装最终 prompt 用 build_prompt（把查证过的标签放进 confirmed_tags）。');
      tail.push('⚠️ 标签名请按返回里的下划线写法原样抄写（如 cat_ears），不要自己改成 cat-ears 或别的拼法。');

      return { content: [...blocks, '', ...tail].join('\n') };
    }
  });

  // ── 工具 2：关联标签 ─────────────────────────────────────────────────
  api.registerTool({
    id: 'related_tags',
    name: 'D 站查关联标签',
    category: 'media',
    icon: '🕸️',
    description: '查一个标签在 D 站上**通常还和哪些标签一起出现**（按共现频率排序）。'
      + '用途：已经拿到一个核心标签（如 cat_ears），想让画面更贴近这个题材的常见搭配时用它补齐周围标签。'
      + '什么时候用：tag_search 查到主标签之后、组装 prompt 之前，用来扩充细节而不是凭空想。'
      + '⚠️ 只有 D 站协议的站点（danbooru / safebooru.donmai.us 这类）有这个功能；'
      + '如果当前用的是 Gelbooru 式的站（safebooru.org 这类），本工具会明确告诉你该站不支持，'
      + '这时不要反复重试，直接进 build_prompt 即可。'
      + '⚠️ 返回的是"常见共现"，不代表你必须全加——按用户的描述挑，别把画面堆满。',
    parameters: {
      type: 'object',
      additionalProperties: false,
      properties: {
        tag: {
          type: 'string',
          description: '要查关联的标签名，必须是真实标签（先用 tag_search 确认过），例如 cat_ears。'
        },
        limit: {
          type: 'number',
          description: '可选：最多返回几个，默认用技能设置里的值（通常 30）。'
        },
        category: {
          type: 'string',
          description: '可选：只保留某一类关联标签。general / artist / copyright / character / meta。留空 = 全都要。'
        }
      },
      required: ['tag']
    },
    async execute(_ctx, args) {
      const c = readConfig();
      const tag = String(args?.tag ?? '').trim().toLowerCase().replace(/\s+/g, '_');
      if (!tag) return fail('缺少 tag：请给出要查关联的标签名（如 cat_ears）。');

      const limit = num(args?.limit, c.relatedLimit, 5, 100);
      const wantCategory = String(args?.category ?? '').trim().toLowerCase();
      const key = `related:${tag}:${limit}:${wantCategory}`;
      const ttlMs = c.cacheTtlHours * 3600 * 1000;
      const cache = readCache();
      const now = Date.now();

      let list = null;
      let fromCache = false;
      let usedBase = '';
      const cached = cache[key];
      if (ttlMs > 0 && cached && Array.isArray(cached.results) && (now - Number(cached.at || 0)) < ttlMs) {
        list = cached.results;
        usedBase = cached.base || '';
        fromCache = true;
      } else {
        const hit = await relatedAcrossBases(tag, c, limit);
        if (!hit.results.length) {
          // 区分两种失败：站点不支持 vs 站点不支持这个站的接口 —— 给出可执行的下一步，
          // 而不是含糊的"失败了"（含糊的失败会诱使模型自己编标签）。
          const unsupported = hit.errors.some((e) => e.includes('不支持'));
          return fail(`查「${tag}」的关联标签失败：\n  ${hit.errors.join('\n  ')}\n`
            + (unsupported
              ? `⚠️ 当前站点（${c.primary}）是 Gelbooru 式的 dapi 接口，**没有「关联标签」这个功能**。\n`
              + `  这不是错误，是站点能力差异。替代做法：把你已经查到的核心标签连同用户需求一起想清楚，`
              + `直接进 build_prompt；或者把「首选站点」改成 danbooru.donmai.us 这类 D 站（能连通的话）再用本工具。`
              : `下一步：先用 tag_search 确认这个标签本身存在、拼写正确。`));
        }
        list = hit.results;
        usedBase = hit.base;
        cache[key] = { at: now, base: hit.base, results: list };
        writeCache(cache);
        LAST_FETCH_AT = now;
      }

      let filtered = list || [];
      if (wantCategory) filtered = filtered.filter((r) => (r.group || '').toLowerCase() === wantCategory);
      filtered = filtered.slice(0, limit);
      if (!filtered.length) {
        return { content: `「${tag}」没有查到关联标签${wantCategory ? `（限定了 category=${wantCategory}）` : ''}。`
          + `可能这个标签太冷门，或者名字拼错了——先用 tag_search 确认它存在。` };
      }

      const lines = [`「${tag}」的常见搭配 ${filtered.length} 个（来源 ${usedBase}${fromCache ? '，缓存命中' : ''}，按共现频率降序）：`];
      for (const r of filtered) {
        lines.push(`  · ${r.name}（共现 ${r.frequency} / 投稿 ${r.postCount} / ${r.group || categoryName(r.category)}）`);
      }
      lines.push('');
      lines.push('—— 按用户的描述**挑一部分**用，别全加（会把画面堆满、互相打架）。'
        + '挑好的连同主标签一起放进 build_prompt 的 confirmed_tags。');
      return { content: lines.join('\n') };
    }
  });

  // ── 工具 3：组装 prompt ──────────────────────────────────────────────
  api.registerTool({
    id: 'build_prompt',
    name: '按 Anima3 模板组装 prompt',
    category: 'media',
    icon: '🧩',
    description: '把已确认的标签按 Anima3 模板的槽位顺序整理、去重，并附上输出格式规则和自检清单。'
      + '什么时候用：面向本地绘图（Anima3 模型）准备提示词时，**在 tag_search 查证之后、调用 local_draw 之前**，'
      + '用它把标签拼成最终 prompt。**不要跳过这一步直接手写 prompt** —— 它负责槽位顺序、去重、数量校验和互斥提醒。'
      + '把 tag_search 查到的标签放进 confirmed_tags；你有把握、不需要查证的放进 known_tags。'
      + '⚠️ 本工具**只组装文本、不画图**。组装好之后要出图，再调「本地绘图」把结果发出去。',
    parameters: {
      type: 'object',
      additionalProperties: false,
      properties: {
        confirmed_tags: {
          type: 'string',
          description: '已经用 tag_search / related_tags 查证过的标签，用逗号分隔，例如 '
            + '"1girl, solo, blue_hair, cat_ears, pantyhose"。这些是 prompt 的主体。'
        },
        known_tags: {
          type: 'string',
          description: '可选：你确定存在、不需要联网查证的通用标签（如 1girl, solo, full body, looking at viewer）。'
            + '会和 confirmed_tags 合并去重。'
        },
        skip_reason: {
          type: 'string',
          description: '可选：如果这次**完全没查证**（confirmed_tags 为空），在这里说明原因'
            + '（例如「D 站连不上」或「用户只是要改一个已有的 prompt」）。'
            + '没查证又不说原因时，如实标注这一点，不要假装已经查过。'
        },
        description: {
          type: 'string',
          description: '可选：用户的原始需求（中文原文即可）。会附在结果里，方便对照画面是否跑偏。'
        },
        notes: {
          type: 'string',
          description: '可选：需要写进 prompt 末尾的英文自然语言短句（多人角色归属、复杂构图、分镜关系等）。'
            + '**它会作为标签一起参与排序**，所以只放真正要进 prompt 的内容。'
        },
        theme: {
          type: 'string',
          description: '可选：特殊题材名（如 NTR / 束缚 / 事后 / 隐奸 / 男娘），会提示你按模板 §14 的跨槽位配方补齐。'
        }
      }
    },
    execute(_ctx, args) {
      try {
        const confirmed = String(args?.confirmed_tags ?? '').trim();
        const known = String(args?.known_tags ?? '').trim();
        if (!confirmed && !known) {
          return fail('confirmed_tags 和 known_tags 都是空的：先用 tag_search 查证标签，'
            + '或把确定的通用标签放进 known_tags。纯靠编标签写 prompt 是本技能要避免的做法。');
        }

        const text = buildPromptText({
          confirmed_tags: confirmed,
          known_tags: known,
          description: args?.description,
          notes: args?.notes
        });

        const extra = [];
        if (!confirmed) {
          extra.push(`⚠️ 本次没有 tag_search 查证过的标签（confirmed_tags 为空）`
            + `${args?.skip_reason ? `，原因：${String(args.skip_reason).trim()}` : ''}。`
            + `这些标签的存在性未经核实，出图可能不生效。`);
        }
        if (args?.theme) {
          extra.push(`【特殊题材：${String(args.theme).trim()}】请按模板 §14 SPECIAL THEME 的跨槽位配方补齐`
            + `（束缚要加姿势+用具+绳痕；事后重残留与情感余韵、不加性行为标签；隐奸加 head out of frame / under covers / implied sex 等）。`);
        }

        return { content: [...extra, text].join('\n\n') };
      } catch (error) {
        return fail(`组装失败：${humanize(error)}`);
      }
    }
  });

  // ── 工具 4：按需取 Anima3 模板原文 ───────────────────────────────────
  api.registerTool({
    id: 'anima_template',
    name: '取 Anima3 模板原文（按需）',
    category: 'media',
    icon: '📖',
    description: '按需取 Anima3 提示词模板的**原文片段**（§0~§15），照原文抄标签。'
      + '什么时候用：准备画图提示词时，需要**具体标签**了 —— 发色发型/瞳色/体型、服装类型与改造、'
      + '体位与动作、镜头景别、场景、画面质感，或 NTR・束缚・事后 这类特殊题材的跨槽位配方。'
      + '三种取法：① 按**槽位**（推荐，不知道看哪节时用）slot="appearance" / "clothing/state" / '
      + '"pose/action/sex" / "theme" —— 由代码映射到对应章节；'
      + '② 按**编号** section="4" 取整章（含子节）、"9.3" 取双人正戏、"14.2" 取束缚配方；'
      + '③ 按**关键词** section="束缚"（先找标题，找不到再搜正文）。'
      + '不传任何参数返回目录。'
      + '⚠️ 规则骨架（输出格式/自检/互斥表/槽位顺序）**不用**来这里取 —— build_prompt 会自带，别重复占用上下文。'
      + '⚠️ 模板是唯一权威：照原文抄写，不要凭记忆改写标签。本工具只读模板，不查站、不画图。',
    parameters: {
      type: 'object',
      additionalProperties: false,
      properties: {
        slot: {
          type: 'string',
          description: '按槽位取（推荐）：count/gender、character/series、appearance、clothing/state、'
            + 'pose/action/sex、expression/reaction、camera/shot、scene/environment、detail/mood、theme。'
        },
        section: {
          type: 'string',
          description: '要取的章节：编号（"4" / "9.3" / "13.6" / "14.2"）或关键词（"束缚" / "镜头"）。'
            + '留空 = 先给目录。填 "all" = 全文（10 万+ 字，极占上下文，非必要别用）。'
        }
      }
    },
    execute(_ctx, args) {
      const want = String(args?.section ?? '').trim();
      const wantSlot = String(args?.slot ?? '').trim();
      let tpl;
      try {
        tpl = loadTemplate();
      } catch (error) {
        return fail(`读不到 Anima3 模板原文（${TEMPLATE_FILE}）：${humanize(error)}。`
          + '到技能目录确认 references/anima3-template.md 还在。');
      }

      // ── 取法①：槽位（由代码映射到章节，比让模型记编号稳）────────────────
      if (wantSlot) {
        const hit = resolveSlot(wantSlot);
        if (!hit) {
          return { content: `没有这个槽位「${wantSlot}」。可选：\n${slotListText()}` };
        }
        const secs = pickTemplateSections(tpl, hit.go);
        if (!secs.length) {
          return fail(`槽位「${hit.slot}」对应模板 §${hit.go}，但原文里找不到这一章`
            + `（模板被改过？确认 references/anima3-template.md 的章节编号）。`);
        }
        const body = secs.map((s) => s.body).join('\n\n');
        return {
          content: `【槽位 ${hit.slot}】${hit.desc} → 模板 §${hit.go}`
            + `（${secs.length} 节 / ${body.length} 字）\n\n${body}\n\n`
            + '—— 标签请**照原文抄写**（下划线写法）；挑定的再放进 build_prompt 的 confirmed_tags。'
        };
      }

      if (!want || /^(toc|index|目录)$/i.test(want)) return { content: templateToc(tpl) };

      if (/^(all|full|全部|全文)$/i.test(want)) {
        return { content: `【Anima3 模板全文】共 ${tpl.chars} 字 —— 很长、很占上下文；下次尽量按节取。\n\n${tpl.text}` };
      }

      // ── 取法②③：编号 / 关键词 ────────────────────────────────────────
      let picked = pickTemplateSections(tpl, want);
      if (!picked.length) {
        return { content: `模板里没有匹配「${want}」的章节。\n\n${templateToc(tpl)}` };
      }
      // 关键词（尤其正文搜索）可能命中很多节 —— 截到 8 节并**明说截断**，不静默少给。
      const CAP = 8;
      const matched = picked.length;
      const truncated = matched > CAP;
      if (truncated) picked = picked.slice(0, CAP);
      const body = picked.map((s) => s.body).join('\n\n');
      const head = picked.length === 1
        ? `【Anima3 模板 §${picked[0].num || '?'} ${picked[0].title}】${body.length} 字`
        : truncated
          ? `【Anima3 模板「${want}」】命中 ${matched} 节，只显示前 ${CAP} 节`
            + `（${picked.map((s) => s.num).join('、')}…）—— 改用更准的编号或标题关键词再取`
          : `【Anima3 模板「${want}」】共 ${matched} 节：${picked.map((s) => s.num).join('、')}`;
      return {
        content: `${head}\n\n${body}\n\n`
          + '—— 标签请**照原文抄写**（下划线写法）；挑定的再放进 build_prompt 的 confirmed_tags。'
      };
    }
  });
}

// ══════════════════════════════════════════════════════════════════════════
// 生命周期
// ══════════════════════════════════════════════════════════════════════════

export function activate() {
  const c = readConfig();
  log(`D 站标签查证已激活（${BUILD_TAG}）｜首选站 ${c.primary}｜候选 ${c.bases.length} 个｜缓存 ${c.cacheTtlHours}h`
    + `｜单站超时 ${c.timeoutMs}ms｜过滤空标签 ${c.hideEmpty ? '开' : '关'}｜最少投稿数 ${c.minPostCount}`);

  // 后台预热：被墙的站要等到超时才换下一个，如果等用户第一次问再探测，他就要多等十几秒。
  // 所以激活时就用一个常见词静默探一遍，把"哪个站能用"提前定下来。
  // 单个查询只试 1~2 个候选站，不会把整份候选表刷一遍，避免启动时打一堆请求。
  prewarm(c).catch((error) => warn(`后台预热失败（不影响使用，首次查询会自己探测）：${error?.message ?? error}`));
}

async function prewarm(c) {
  if (PREWARMED) return;
  PREWARMED = true;
  const term = String(cfg()?.prewarmQuery || 'cat_ears').trim().replace(/\s+/g, '_') || 'cat_ears';
  const started = Date.now();
  for (const base of c.bases.slice(0, 2)) {
    try {
      const text = await fetchText(buildSearchUrl(base, term, c), c);
      if (parseTagPayload(text).length) {
        WORKING_BASE = base;
        log(`预热探到可用站点：${base}（${Date.now() - started}ms，用「${term}」试的）`);
        return;
      }
    } catch (error) {
      warn(`预热试 ${base} 失败：${humanize(error)}`);
    }
  }
  warn('预热没探到可用站点。工具会照常工作并在被调用时如实报错；'
    + '可在技能设置里把「首选站点」改成一个能连通的标签站。');
}

/**
 * 依赖自检。⚠️ **必须是同步函数** —— 可用性判定走同步调用链，返回 Promise 会被当成"可用"。
 * 这里只检查"填的东西是不是合法"，**不探测网络**（网络不通时工具会如实报错并给出换站的建议）。
 */
export function available() {
  const c = cfg() || {};
  const rawBase = String(c.apiBase ?? '').trim();
  if (rawBase && !normalizeBase(rawBase)) {
    return { ok: false, reason: `「首选站点」不合法：${rawBase}。要写成 https://开头的域名，例如 https://safebooru.org。` };
  }
  if (!normalizeBase(rawBase) && !String(c.fallbackBases ?? '').split(/[,\n;]+/).some((b) => normalizeBase(b))) {
    return { ok: false, reason: '「首选站点」和「备用站点」都为空或都不合法，没有任何可用的标签站。' };
  }
  return true;
}

/** 卸载/热重载时清理。本技能没有定时器和监听器，只需重置模块级状态。 */
export function dispose() {
  LAST_FETCH_AT = 0;
  WORKING_BASE = '';
  PREWARMED = false;
}

/** 供测试直接调用纯函数（不进模型工具列表）。 */
export const internals = {
  analyzeTags,
  buildPromptText,
  classifyTag,
  sizeBand,
  countRoles,
  heat,
  categoryName,
  parseTagPayload,
  siteKind,
  normalizeBase,
  normalizeTagName,
  dapiCategory,
  buildExactUrl,
  buildSearchUrl,
  buildRelatedUrl,
  looksLikeJunkTag,
  pickForDisplay,
  readConfig,
  ANIMA3_RULES,
  SLOTS,
  // 模板按需取用（读文件 + 切章节 + 槽位映射）
  loadTemplate,
  pickTemplateSections,
  templateToc,
  SLOT_SECTIONS,
  resolveSlot,
  slotListText,
  TEMPLATE_FILE
};
