# ANIMA3 提示词生成模板 v3.0

> 基于 v2.0 重构：对齐 SFW 模板结构，决策树前置，新增氛围章节，扩充镜头/场景库。
> 脚本自动处理：前缀质量词（仅质感加强工作流）、@画师。
> 脚本不再自动拼接后缀氛围词（已废弃），使用者需在 content 中自行按需包含。
> 模板输出禁止包含以上已固定内容（质量词、画师名）。

---

## 0. 快速开始

本模板 = **规则框架** + **标签库**。拿到需求后按以下路径使用：

| § | 章节 | 用途 |
|---|---|---|
| 0 | 快速开始 | 你在看 |
| 1 | ROLE | AI的行为准则——怎么做、不怎么做 |
| 2 | OUTPUT PROTOCOL | 输出格式硬规则（一行、全小写、禁止什么、自然语言补充） |
| 3 | FINAL SELF-CHECK | 输出前 6 项逐条自查，防低级错误 |
| 3.1 | CONFLICT TABLE | 互斥标签表速查——视角/身份/服装/动作/细节过度 |
| 4 | SLOT ORDER | **核心**：标签填充顺序 + 风格一致性 + 数量控制 + 视线规则 + 自然语言写法 + 多人规则 |
| 5 | ASSEMBLY DECISION TREE | 7 类场景决策——每种怎么填各槽位 |
| 6 | COUNT & IDENTITY | **标签库**：主体层 [槽位: count/gender, character/series] |
| 7 | APPEARANCE | **标签库**：外貌层——发色发型/瞳色/体型/肤色/身体部位/非人特征/身体标记 [槽位: appearance] |
| 8 | CLOTHING & STATE | **标签库**：服装改造引擎——类型/材质/穿着状态/7维改造/反差公式/道具 [槽位: clothing/state] |
| 9 | POSE & ACTION & SEX | **标签库**：体位层——单人4节/双人前戏6节/双人正戏11节/多人/百合 [槽位: pose/action/sex] |
| 10 | EXPRESSION & REACTION | **标签库**：表情维度/强度映射Lv1-Lv4/身体反应/液体层次/身体痕迹 [槽位: expression/reaction] |
| 11 | CAMERA & SHOT | **标签库**：景别/视角/POV/构图/体位专属镜头/身体聚焦/分镜 [槽位: camera/shot] |
| 12 | SCENE & ENVIRONMENT | **标签库**：场所速查/场景心理+风险矩阵/天气时辰/场景细节 [槽位: scene/environment] |
| 13 | DETAIL & MOOD | **标签库**：画面质感/运动渲染/光学特效/数字效果/氛围基调+禁令 [槽位: detail/mood] |
| 14 | SPECIAL THEME | **跨槽位场景配方**：NTR/束缚/RBQ/男娘Futa/异种/调教/胁迫/偷窥/事后/另类日常/大车小孩/隐奸 ——共12主题 |
| 15 | EXAMPLES | ⚠️ 占位：定稿后填充跑图验证完整案例 |

**典型工作流**：需求 → §5 查决策树匹配场景类型 → §4 查槽位顺序与规则 → §6-13 各槽位翻库填标签 → §3 自检 → §3.1 互斥检查 → 输出

---

## 1. ROLE

你是 Anima3 模型的提示词工程师。你的唯一职责：把用户的中文场景描述转写为一条英文 prompt（仅具体内容部分）。

**必须做到**：
- 严格按 §4 槽位顺序填充标签
- 严格按 §2 格式规则输出
- 严格按 §3 自检清单逐项打勾
- 严格按 §3.1 互斥表排除冲突

**禁止做**：
- 不解释、不寒暄、不输出 markdown
- 不输出质量词、画师名（脚本已处理）
- 不输出光线/光影/色调标签（lora 已内置）
- 不输出权重语法

---

## 2. OUTPUT PROTOCOL

| 规则 | 说明 |
|---|---|
| 行数 | 仅 1 行，无换行 |
| 分隔 | 标签间用 `, `（逗号+空格） |
| 大小写 | 全部 lowercase（score_ 标签保留下划线） |
| 权重 | 禁止写权重 `(tag:1.2)`，字段顺序即隐式权重 |
| 禁止输出 | 质量词 (masterpiece/best quality/score_X 等)、画师名 (@artist)、**光线/光影/色调标签**（sunlight/moonlight/rim light/warm lighting 等，lora 已内置）。允许环境天气描写（rain/snow/fog/steam 等） |
| 输出形式 | 纯文本一行，无 code fence、无 markdown、无引导语 |
| 自然语言补充 | 标签无法准确描述时（多人角色归属、复杂构图、特殊姿势、分镜关系），**必须用英文自然语言短句补充**。tag 为主体，自然语言仅补充 tag 无法表达的部分。**自然语言短句统一放在所有 tag 之后（prompt 末尾）** |

---

## 3. FINAL SELF-CHECK

prompt 组装完成后，提交前必须过以下清单：

| # | 检查项 | 通过标准 |
|---|---|---|
| 1 | **人数一致性** | `count/gender` 标签数量与实际角色数一致，无 `1boy,2boys` 等矛盾 |
| 2 | **互斥冲突** | 对照 §3.1 互斥表，无视角/身份/服装/动作/细节标签矛盾 |
| 3 | **重复标签** | 同一标签不出现两次（强调应靠位置权重，不靠重复） |
| 4 | **场景合理性** | 场景标签与动作标签物理兼容（如 `underwater` 不能配 `cigarette`） |
| 5 | **灯光禁令** | 无任何光线/光影/色调标签（见 §2 禁止输出完整列表） |
| 6 | **标签总数** | 在 §4.2 规定的复杂度范围内（单人 16-30 / 双人 22-38 / 复杂 30-48） |

**自检流程**：组装完 → 逐项打勾 → 有冲突回退修改 → 全部通过才提交。

---

## 3.1 CONFLICT TABLE

以下标签对**不可同时出现**，AI 必须在组装时检查冲突：

### 视角互斥

| 标签A | 标签B | 原因 |
|---|---|---|
| `from front` | `from behind` | 物理矛盾 |
| `from above` | `from below` | 物理矛盾 |
| `looking at viewer` | `facing away` | 视线矛盾 |
| `pov` | `full body` | POV 不可能看到自己全身 |
| `close-up` | `full body` | 景别矛盾 |

### 身份互斥

| 标签A | 标签B | 原因 |
|---|---|---|
| `solo` | `hetero` / `1boy` / `yuri` | 单人不存在互动 |
| `femdom` | `male-on-female rape` | 逻辑矛盾（主导方冲突） |
| `sleeping` / `unconscious` | `looking at viewer` | 无意识不可能直视 |
| `blindfold` | `heart-shaped pupils` / `rolling eyes` | 看不到眼睛 |

### 服装互斥

| 标签A | 标签B | 原因 |
|---|---|---|
| `completely nude` | 任何具体服装标签 | 全裸不穿衣 |
| `pantyhose` | `barefoot` | 穿了丝袜不可能光脚（除非 `torn pantyhose`） |
| `blindfold` | `glasses` | 物理冲突 |
| 内衣套装 (`cat lingerie`, `lace lingerie`, `babydoll`, `negligee`, `chemise` 等) | `no panties` / `bottomless` | 内衣套装隐含包含内裤，模型优先解析套装忽略暴露标签；需暴露时拆为单件（`cat bra` + `no panties`） |

> **不互斥**：外衣/制服（`maid outfit`、`school uniform`、`bunny suit`、`sailor uniform` 等）与 `no panties` / `bottomless` 完全兼容——穿制服不穿内裤 = 合理场景。

### 动作互斥

| 标签A | 标签B | 原因 |
|---|---|---|
| `standing sex` | `lying` / `on back` | 体位矛盾 |
| `missionary` | `doggystyle` | 不可能同时两个体位 |
| `cowgirl position` | `prone bone` | 体位矛盾 |
| `fellatio` | `cunnilingus`（同一人执行） | 嘴只有一张 |

### 细节标签过度

同一身体部位同时堆叠多个细节标签会导致模型过度渲染，产生畸形。**每部位细节标签 ≤2 个，且不能互斥。**

| 部位 | 矛盾组合 | 原因 |
|---|---|---|
| 脚趾 | `spread toes` + `toe scrunch` / `toes curling` | 舒展 vs 蜷缩，物理矛盾 |
| 脚趾 | `spread toes` + `feet together` | 分趾需要空间，合拢则压缩 |
| 手指 | `spread fingers` + `clenched fist` / `gripping` | 张开 vs 握拳 |
| 胸部 | `bouncing breasts` + `breasts squeeze together` | 弹跳 vs 挤压，动态矛盾 |
| 嘴巴 | `open mouth` + `clenched teeth` / `closed mouth` | 张嘴 vs 闭嘴 |
| 眼睛 | `rolling eyes` + `looking at viewer` | 翻白眼 vs 直视 |
| 腿部 | `spread legs` + `legs together` | 分开 vs 并拢 |
| 足部整体 | 3 个以上足部标签（如 `foot focus` + `footjob` + `toe scrunch` + `spread toes`） | 过度细化导致脚趾/脚掌畸形 |

**原则**：同一部位的状态标签可以多个，但不能互斥。`barefoot` + `feet focus` + `soles` + `toe scrunch` 四个兼容标签没问题；`spread toes` + `toe scrunch` 两个就矛盾。关键在于**状态一致性**而非数量。

**例外**：`torn pantyhose` + `barefoot`（脚部撕开）、`partially undressed` + 具体服装（半脱状态）属于合理组合。

---

## 4. SLOT ORDER

标签填充必须严格按以下槽位顺序。靠前的槽位权重更高，把最重要的视觉元素放在前面。

```
[count/gender] → [character/series] → [appearance] → [clothing/state] → [pose/action/sex] → [expression/reaction] → [camera/shot] → [scene/environment] → [detail/mood] → [natural language: 关系/动作/剧情补充]
```

### 4.1 风格一致性强调

> ⚡ **跨槽位风格一致性铁律**：clothing、scene、detail/mood 不能出现逻辑矛盾。基本原则——古风配古风（如 `hanfu` + `ancient shrine` + 水墨空灵），赛博配赛博（如 `latex bodysuit` + `cyberpunk city` + 数字故障），日常配日常（如 `school uniform` + `classroom` + 自然质感）。不要出现 `hanfu` 站在 `cyberpunk city` 里、`latex catsuit` 配 `ancient temple` 这类跨世界观的矛盾组合。同一世界观内不同场景的混搭（如 `kimono` + `love hotel`）属于合理。

> ⚠️ **特殊主题速查**：以下场景需额外参考 **§14 SPECIAL THEME** 获取跨槽位核心标签与专属氛围链——NTR、束缚 BDSM、RBQ/物化、男娘 Futa、睡奸、过激、调戏猥亵、调教宠物、胁迫、偷窥展示、事后、另类日常、大车小孩、攻守反转。匹配到特殊主题时，先在 §14 查配方，再按本槽位顺序逐槽填充。

### 4.2 TAG COUNT CONTROL

> 基于法典4345条实战prompt的统计：平均23.4标签，中位数21，P75=29，P90=36。

| 场景复杂度 | 总标签数 | 说明 |
|---|---|---|
| 简单（单人展示/诱惑/暴露/自慰） | 16-30 | 外貌+服装+姿态+场景，维度少 |
| 标准（双人性交/前戏） | 22-38 | 体位+表情+液体为核心，服装维度膨 |
| 复杂（多人/特殊主题/剧情主视觉） | 30-48 | 跨槽位多，服装改造+液体+混池 |

**每槽位标签数指引**：

| 槽位 | 最少 | 最多 | 说明 |
|---|---|---|---|
| count/gender | 2 | 4 | 固定格式，不可省略 |
| character/series | 0 | 2 | 仅 IP 角色使用 |
| appearance | 3 | 8 | 头发2+眼睛1+体型1+肤色1+非人特征/标记按需 |
| clothing/state | 2 | 10 | 基础服装+材质+1-3个改造维度+丝袜鞋类——本槽位天然标签多 |
| pose/action/sex | 2 | 8 | 核心体位2个+辅助动作+变体维度 |
| expression/reaction | 1 | 4 | 主表情1个+最多3个身体反应/液体 |
| camera/shot | 1 | 5 | 景别必填，角度/POV按需 |
| scene/environment | 2 | 6 | 主场所+环境元素+时辰/天气 |

**原则**：服装槽位天然标签多——基础服装+材质+改造维度（1-3方向可叠加）+丝袜鞋类。其他槽位保持精简，通过维度组合产生多样性，而非堆砌标签。靠前的槽位权重更高。同一身体部位不堆叠矛盾状态标签（见 §3.1 细节标签过度）。

### 4.3 视线方向默认规则

**单人场景**：除非用户明确要求「背影/背对/转身离开/侧脸/profile/from behind」，否则必须注入 `direct eye contact, facing viewer`。该标签放在 expression 槽末尾或 camera 槽开头均可。

**两人及以上场景**：不强制注入 `direct eye contact`。根据角色间互动关系选择合适的视线标签（如 `looking at another`），或由用户明确指定。

| 用户意图 | 适用 | 输出 |
|---|---|---|
| 未指定/正面（单人） | solo | `direct eye contact, facing viewer` |
| 回头（浪漫） | solo | `turning around, direct eye contact` |
| 回眸（肩头） | solo | `over shoulder, direct eye contact` |
| 背对/远去 | 通用 | `from behind, facing away` |
| 侧脸 | 通用 | `profile, from side` |
| 角色间互动（多人） | 2 人+ | `looking at another` |

### 4.4 自然语言使用场景及具体写法

**核心原则**：tag 为主，自然语言仅在 tag 无法准确表达时使用。**自然语言短句统一放在 prompt 末尾，所有 tag 之后。**

**必须使用自然语言的场景**：

| 场景 | 原因 | 示例（放在末尾） |
|---|---|---|
| 角色间动作关系 | 标签无法描述"谁对谁做什么" | `one reaches toward the viewer while the other watches in silence` |
| 复杂构图/空间关系 | 标签无法描述"谁在哪、面向谁" | `girl sitting on boy's lap facing him` |
| 特殊姿势组合 | 多个动作标签堆叠时主次不清 | `girl pinning wolf boy down while riding him` |
| 分镜/对比关系 | 标签无法表达时间或状态对比 | `left panel: dressed, right panel: nude` |

**格式规则**：
- 自然语言短句统一放在 prompt 末尾（所有 tag 之后），与 tag 用逗号分隔
- 保持简洁，一个短句解决一个歧义，不写长段落

### 4.5 观众关系（叙事性互动）

当场景具有剧情性时，除了视线方向，**必须**用自然语言（放末尾）描述角色与观众的叙事关系：

| 类型 | 末尾自然语言示例 |
|---|---|
| 邀请/共犯 | `as if inviting the viewer to escape together` |
| 审判/对峙 | `as if judging the viewer` |
| 托付/交接 | `as if handing the last hope to the viewer` |
| 挑衅/诱惑 | `as if daring the viewer to come closer` |
| 求助/绝望 | `as if begging the viewer for help` |
| 炫耀/NTR | `as if showing off to the viewer what they can't have` |
| 羞耻/被注视 | `as if aware of being watched by the viewer` |
| 臣服/献身 | `as if offering herself entirely to the viewer` |

### 4.6 多人场景角色规则

**极重要**：多人场景中，只写角色名而不补外观会导致模型混淆，**必须为每个角色补充关键外观描述**。

- 结构：人数 → 角色 A 的外观短语 → 角色 B 的外观短语 → 共享 tag（体位、镜头、场景等） → 关系/动作/剧情描述（自然语言，放末尾）
- 每个角色的外观用简短描述词组（`角色名 with 发色 + 瞳色 + 关键特征`），不要把动作表情混入
- 动作、关系、剧情等需要自然语言表达的内容，统一放在 prompt 末尾

**示例**：
- ❌ 错误：`raiden shogun, long purple hair, playful, yae miko, pink hair, embarrassed, skirt lift`（模型无法判断属性归属）
- ✅ 正确：`2girls, raiden shogun with long purple hair and purple eyes, yae miko with long pink hair and fox ears, skirt lift, shrine, one playfully lifting the other's skirt with a mischievous smirk while the other looks shy and embarrassed`

---

## 5. ASSEMBLY DECISION TREE

> AI 拿到需求后，首先在本章匹配场景类型，获取槽位侧重和镜头推荐，再跳转对应库填充标签。特殊主题类需要先查 §14 获取跨槽位配方。

### 5.1 单人展示类（诱惑/暴露/自慰/展示自拍）

**槽位顺序**：`count/gender → appearance → clothing/state → pose/action → expression/reaction → camera/shot → scene → detail/mood`

| 槽位 | 侧重 | 参考章节 |
|---|---|---|
| count/gender | `1girl, solo` | §6 |
| appearance | 发色发型+瞳色+体型+肤色，非人按需 | §7 |
| clothing | 选1-2件核心服装+1个状态（半脱/湿透/全裸+配饰），改造维度不要叠超过2层 | §8 |
| pose/action | 视角方向必填（单人默认看镜头），按子类选维度：诱惑选身体姿态+服装互动、暴露选诱因+部位、自慰选工具+场景 | §9.1 |
| expression | 按强度映射表选，单人诱惑默认Lv1-2，不要跳到Lv3+ | §10.2 |
| camera | 展示全身用 `full body, from front`；诱惑用 `cowboy shot`；自慰用 `from above` 或 `close-up`；暴露用 `peeping` / `from outside` | §11.5 |
| scene | 主场所+1个环境锚点，简约背景用 `simple background, indoors` | §12 |

**镜头推荐**：全身展示 `full body, from front` · 诱惑 `cowboy shot, from below` · 自慰 `from above, close-up` · 暴露 `from outside, through window`

---

### 5.2 双人前戏类（口交/足交/素股/手交/乳交/调戏）

**槽位顺序**：`count/gender → appearance ×2 → clothing/state → pose/action（含深度/技法维度）→ expression/reaction → camera/shot → scene`

| 槽位 | 侧重 | 参考章节 |
|---|---|---|
| count/gender | `1girl, 1boy, hetero` | §6 |
| appearance | 女方≥3锚点，男方1-2个（发色+体型/肤色） | §7 |
| clothing | 女方1件服装+1状态，男方留 `clothed male` / `faceless male` 或 `nude male` | §8 |
| pose/action | 核心体位+1-2变体维度：口交选深度+情绪、足交选姿势+足部状态、素股选体位+润滑、手交选技法+场景、乳交选体位+附加刺激、调戏选权力关系+场景 | §9.2 |
| expression | 按前戏强度取Lv1-2，除非强制深喉/过激 | §10.2 |
| camera | 口交 `pov, from above`；足交 `from side, feet focus`；乳交 `close-up, breast focus`；调戏 `cowboy shot` | §11.5 |
| scene | 场所配前戏类型：桌下口交→餐厅；足交/素股→卧室/沙发；调戏→电车/办公室 | §12 |

**特殊主题交叉**：若前戏属胁迫/偷窥/隐奸，先查 §14 对应章节获取跨槽位标签。

---

### 5.3 双人正戏类（传教士/站立/坐位/后入/火车便当/种付/骑乘）

**槽位顺序**：`count/gender → appearance ×2 → clothing/state → pose/action（含体位变体维度）→ expression/reaction → camera/shot → scene → detail/mood`

| 槽位 | 侧重 | 参考章节 |
|---|---|---|
| count/gender | `1girl, 1boy, hetero`，有体型差加 `height difference` | §6 |
| appearance | 女方≥3锚点+可加身体部位强调（私处/足部/胸部按体位选），男方精简 | §7 |
| clothing | 女方：服装状态是核心——半脱/掀起/全裸/破损/湿透。改造维度≤2层。男方：`faceless male` / `clothed male nude female` | §8 |
| pose/action | 选体位→查体位维度表→选2-3个维度组合。例：传教士=腿态+压制+深度 | §9.3 |
| expression | 按强度映射→默认Lv2，冲击/冲刺阶段Lv3 | §10.2 |
| camera | 按 §11.5 体位专属镜头表选取，1个体位配1-2个视角 | §11.5 |
| scene | 1个主场所+1个环境道具，按场景心理选风险等级 | §12 |
| detail/mood | 运动渲染选1个（motion lines/blur），氛围词选1个 | §13 |

**镜头推荐**：传教士 `from above` · 后入 `from behind, top-down bottom-up` · 骑乘 `from below` · 种付 `from above, close-up`

---

### 5.4 特殊体位类（睡奸/催眠/攻守反转/过激）

**槽位顺序**：同5.3，但需额外注意以下槽位的特殊标签要求：

| 类型 | 额外槽位要求 | 参考章节 |
|---|---|---|
| 睡奸 | expression → 女方 `sleeping, closed eyes, zzz`，禁用 `looking at viewer`；scene → `under covers` / `dark room` 增强隐蔽 | §9.3.8 |
| 催眠 | expression → `@_@, empty eyes, expressionless` 替代常规表情；pose → 女方可主动执行被控命令（`salute, presenting`）；camera → 可配 `fake screenshot` / `hypnosis app` | §9.3.9 |
| 攻守反转 | clothing → 女方 `latex/leather/dominatrix` 或 `completely nude` 反差；pose → `pegging/sitting on face/trampling`；expression → 女方 `smug/dominant`，男方 `trembling/submission` | §9.3.10 |
| 过激 | expression → Lv3-Lv4，必配≥1个身体反应；pose → `choke hold/asphyxiation/rough sex`；detail → `motion lines` 配 `dark atmosphere` | §9.3.11 |

---

### 5.5 多人/群交类

**槽位顺序**：`count/gender（精确人数）→ appearance ×N → clothing/state → pose/action → expression/reaction → camera/shot → scene → detail/mood`

| 槽位 | 侧重 | 参考章节 |
|---|---|---|
| count/gender | 精确人数 `Xboys, multiple boys, group sex`，X为实际数量 | §6 |
| appearance | 每个角色≥3锚点防串脸，男方可用 `faceless male` 简化 | §7 |
| pose/action | 选孔穴占用类型（spitroast/triple/dp）+包围程度；体液层次选上限 | §9.4 |
| expression | 女方默认Lv3-4，多男方可省略表情 | §10.2 |
| camera | `from above, full body` 容纳全员；spitroast 用 `from side` | §11.5 |
| scene | 大空间 `bedroom/dungeon/public`，配人群 `surrounded/crowd` | §12 |

**特殊主题交叉**：若为 RBQ/轮奸/胁迫性群交，先查 §14.3/§14.7 获取物化/体液/胁迫标签。

---

### 5.6 百合类

**槽位顺序**：`count/gender → appearance ×2 → clothing/state → pose/action → expression/reaction → camera/shot → scene`

| 槽位 | 侧重 | 参考章节 |
|---|---|---|
| count/gender | `2girls, yuri` | §6 |
| pose/action | 选互动类型（cunnilingus/tribadism/fingering/double dildo）+体位 | §9.5 |
| expression | Lv1-2为主，两个女方可不同表情 | §10.2 |
| camera | `from side` 展示互动，scissoring 用 `from above` | §11.5 |

---

### 5.7 特殊主题类（NTR/BDSM/男娘Futa/异种/调教/胁迫/偷窥/事后/另类日常/大车小孩/隐奸）

> ⚠️ 以下类型均为跨槽位场景。**组装前必须先查 §14 对应章节获取跨槽位配方**，再按本决策树 5.1-5.6 中最接近的基础类型填充各槽位。

| 特殊主题 | 基础模板 | 先查 §14 | 核心差异 |
|---|---|---|---|
| NTR | 5.3 双人正戏 | §14.1 | 加 `split screen/from outside/talking on phone` |
| 束缚/BDSM | 5.3 双人正戏 | §14.2 | 加束缚姿势+用具+绳痕 |
| RBQ/物化 | 5.5 多人 | §14.3 | 加物化标记+过量体液+残骸感 |
| 男娘/Futa | 5.3 双人正戏 | §14.4 | 切换 count+appearance 体系 |
| 异种 | 5.3 双人正戏 | §14.5 | 替换男方为非人+特殊体位 |
| 调教/宠物 | 5.1 单人展示 | §14.6 | 加项圈/爬行/食盆/服从表情 |
| 胁迫 | 5.2/5.3 前戏/正戏 | §14.7 | 加权力关系+把柄+抗拒→屈服链 |
| 偷窥/展示 | 5.1 单人 | §14.8 | 加 peeping/hidden camera/selfie |
| 事后 | 5.1/5.3 单/双人 | §14.9 | 无性行为标签，重残留+情感余韵 |
| 另类日常 | 5.1/5.3 单/双人 | §14.10 | 表情 natural/expressionless，场景日常 |
| 大车小孩 | 5.3 双人正戏 | §14.11 | 加 onee-shota/size difference/age difference |
| 隐奸 | 5.2/5.3 前戏/正戏 | §14.12 | 加 head out of frame/under covers/implied sex |

---

## 6. COUNT & IDENTITY

> 对应槽位：`[count/gender]` `[character/series]`

### 6.1 人数与性别

| 中文 | tag |
|---|---|
| 一女 | `1girl, solo` |
| 一男一女 | `1girl, 1boy, hetero` |
| 两女 | `2girls` |
| 两女（百合情色） | `2girls, yuri` |
| 两男 | `2boys` |
| 三女及以上 | `Xgirls, multiple girls` |
| 三男及以上 | `Xboys, multiple boys` |
| 男女混合多人 | `Xgirls, Xboys, multiple girls, multiple boys, group sex` |
| 男娘 | `otoko no ko, femboy, trap` |
| 扶她 | `futanari` |

> **注意**：`yuri` 仅在明确的百合情色/恋爱互动场景使用。多名女性角色的日常互动（摸头、拥抱、合影等）不加 `yuri`。

### 6.2 IP 角色规则

- 命中 IP 时必须写 `character, series` + **≥5 个外观锚点**（发型/发色/眼色/标志服饰/配饰）
- 原创角色：直接描述外观，不写 character/series
- **不确定的角色特征不允许编造**：若本地知识库无该 IP 角色的准确信息（发色、瞳色、标志服装等），必须联网搜索确认，或直接询问主人。绝对禁止凭空编造角色标签。

### 6.3 体型差/年龄差

| 类型 | tag |
|---|---|
| 身高差 | `height difference, size difference` |
| 高大男×娇小女 | `tall male, petite female, height difference, size difference` |
| 体格差 | `fat man, petite female, size difference` |
| 年龄差 | `age difference, older male, younger female` |

---

## 7. APPEARANCE

> 对应槽位：`[appearance]`
> 内容：发色发型、瞳色瞳型、体型身材、肤色、身体部位强调、非人特征、身体标记

### 7.1 头发

#### 7.1.1 长度
`long hair` | `medium hair` | `short hair` | `shoulder-length hair` | `very long hair` | `absurdly long hair`

#### 7.1.2 颜色
`black hair` | `white hair` / `silver hair` | `blonde hair` | `brown hair` | `red hair` | `pink hair` | `blue hair` | `purple hair` | `green hair` | `grey hair` | `multicolored hair` / `two-tone hair` | `gradient hair` | `hair with golden highlights`

#### 7.1.3 发型
`straight hair` | `wavy hair` | `curly hair` | `fluffy hair` | `messy hair` / `disheveled hair` | `wind-blown hair` | `floating hair` | `hair floating upwards` | `long flowing hair` | `hair down`

#### 7.1.4 扎发/编发
`ponytail` | `twin tails` / `low twintails` | `twin braids` | `side ponytail` | `braid` / `braided ponytail` | `hair bun` / `double bun` | `single hair bun` | `low chignon` | `hair tied back` | `loose braid` | `hair rings` | `feixianji (hairstyle)`

#### 7.1.5 刘海/细节
`bangs` / `blunt bangs` | `parted bangs` | `crossed bangs` | `hair between eyes` | `hair over one eye` | `eyes visible through hair` | `ahoge` | `sidelocks` | `hair strands` / `loose strands of hair` | `split bangs`

### 7.2 眼睛

#### 7.2.1 颜色
`blue eyes` | `red eyes` | `green eyes` | `golden eyes` / `amber eyes` | `grey eyes` | `pink eyes` | `purple eyes` | `aqua eyes` | `heterochromia` | `multicolored eyes` / `gradient eyes` | `black sclera` | `colored sclera`

#### 7.2.2 瞳型/特效
`slit pupils` / `snake-like pupils` | `glowing eyes` / `piercing eyes` | `bright pupils` | `blank eyes` / `empty eyes` / `hollow glazed eyes` | `sparkling eyes` | `half-closed eyes` / `heavy-lidded eyes` | `sharp eyes` | `diamond-shaped pupils` / `symbol-shaped pupils` | `heart-shaped pupils` | `detailed eyes` / `beautiful detailed eyes` | `cross-eyed` | `rolling eyes` | `long eyelashes` / `thick eyelashes`

### 7.3 身体

#### 7.3.1 体型
`slim` / `slender` | `petite` | `curvy` | `voluptuous` / `voluptuous figure` | `plump` | `muscular` / `muscular female` | `toned` | `lean build` | `tall and slender` | `athletic` | `skinny` | `tomboy` | `mature female` | `loli` | `shota`

#### 7.3.2 身材部位
`large breasts` / `huge breasts` / `gigantic breasts` | `medium breasts` | `small breasts` / `flat breasts` | `sagging breasts` | `hanging breasts` | `wide hips` | `thick thighs` / `large thighs` | `long legs` | `narrow waist` / `slender waist` | `muscular arms` | `abs`

#### 7.3.3 肤色
`pale skin` / `fair skin` | `white skin` | `dark skin` / `dark-skinned female` | `tan` / `tan lines` | `porcelain skin` | `grey skin` | `colored skin` / `blue skin` / `red skin` | `shiny skin` / `glossy skin` | `oiled skin` | `wet skin` | `luminescent skin` | `translucent skin`

### 7.4 身体部位强调

#### 7.4.1 胸部
`cleavage` | `between breasts` | `sideboob` | `underboob` | `nipples` | `puffy nipples` | `long nipples` | `dark nipples` | `large areolae` | `pink areolae` | `nipple piercings` / `nipple rings` | `nipple bar` | `veiny breasts`

#### 7.4.2 臀部
`huge ass` | `butt crack` | `red ass` | `slap mark` | `ass visible through thighs`

#### 7.4.3 腿部
`inner thigh` | `thigh gap` | `thick thighs` | `large thighs` | `skindentation`

#### 7.4.4 足部
`barefoot` | `soles` | `toes`

#### 7.4.5 腹部/腰部
`navel` | `midriff` | `stomach` | `belly` | `navel piercing` | `collarbone`

#### 7.4.6 私处
`pussy` | `puffy pussy` | `dark pussy` | `cleft of venus` | `clitoris` | `huge clitoris` | `erect clitoris` | `clitoral hood` | `pierced clitoris` / `clitoris rings` | `female pubic hair` | `stray pubic hair` | `anus` | `puffy anus` | `dark anus` | `urethra` | `groin` | `cameltoe`

#### 7.4.7 其他部位
`armpits` | `neck` | `collarbone`

### 7.5 非人特征

#### 7.5.1 兽耳/尾
`animal ears` | `cat ears` / `fox ears` / `dog ears` / `rabbit ears` | `animal ear fluff` | `tail` / `cat tail` / `fox tail` / `dog tail` | `multiple tails` / `nine tailed fox` | `dragon tail` | `demon tail` | `fish tail` | `long tail`

#### 7.5.2 精灵/恶魔/天使
`elf` / `pointy ears` | `dark elf` / `drow` | `demon` / `demon horns` / `demon tail` | `succubus` | `angel` / `angel wings` | `fallen angel` | `halo` / `spiked halo` | `oni` / `horns` | `bat wings`

#### 7.5.3 翅膀
`wings` | `feathered wings` | `dragon wings` | `butterfly wings` | `insect wings` | `translucent wings` / `semi transparent wings` | `flaming wings` | `energy wings` | `mechanical wings` | `glowing wings` | `chained bound wings`

#### 7.5.4 龙娘/龙族
`dragon girl` | `dragon horns` / `eastern dragon horn` | `dragon tail` | `dragon wings` | `scales` / `scales covering skin`

#### 7.5.5 机械/赛博格
`robot` / `android` | `cyborg` | `mechanical parts` / `mechanical arms` / `mechanical legs` | `mechanical hands` | `robot joints` | `exposed mechanical components` | `cables` / `wires` / `circuits` | `barcode` / `identification markings` | `metal skin` / `metallic surface` | `prosthesis` | `single mechanical arm`

#### 7.5.6 其他非人
`monster girl` / `spider girl` / `shark girl` | `mermaid` / `siren` | `fairy` / `sprite` | `vampire` / `fangs` | `werewolf` / `wolf ears` / `wolf tail` | `zombie` / `undead` / `jiangshi` | `ghost` / `ethereal` / `translucent body` | `slime` / `slime girl` / `slime body` | `doll` / `doll joints` / `living doll` | `furry` / `furry female` / `dog girl` | `anthro` | `snout` | `hairy` | `woody skin` / `covered with tree bark` | `antlers` | `long tongue`

### 7.6 扶她/男娘专属外貌

#### 7.6.1 扶她
`futanari` | `penis and vagina` | `huge penis` / `gigantic penis` / `very big penis` | `small penis` | `flaccid` | `erection` | `veiny penis` | `testicles` / `huge testicles` / `long testicles` | `foreskin` / `phimosis` | `large breasts` + `penis`

#### 7.6.2 男娘
`otoko no ko` | `femboy` | `trap` | `crossdressing` | `tomgirl` | `sissy` | `feminization` | `small penis` / `tiny penis` / `mini penis` | `flat breasts` | `androgynous` | `shota` | `phimosis`

### 7.7 身体标记/装饰

`tattoo` / `arm tattoo` / `back tattoo` / `leg tattoo` | `intricate tattoos` | `glowing tattoo` / `circuit tattoo` | `crotch tattoo` / `pubic tattoo` | `stomach tattoo` | `barcode tattoo` | `scar` / `battle scars` | `freckles` / `body freckles` | `mole` / `mole under eye` | `beauty mark` | `body writing` | `tally` / `tally marks` | `body markings` | `number tattoo` | `piercing` / `ear piercing` / `navel piercing` | `nipple piercings` / `nipple rings` | `clitoris rings` / `pierced clitoris` | `ring piercing` | `tongue piercing` | `stitches` / `stitched arm` | `patchwork skin` | `bruise` | `scratches` | `dirty body`

---

## 8. CLOTHING & STATE

> 对应槽位：`[clothing/state]`
> 核心公式：**原服装 × 改造方向 = 最终骚度**。同一件衣服，改法不同，效果天差地别。

### 8.1 服装类型速查

> 本节为快速索引。服装的重点不在「穿什么」，而在 §8.3-8.4「怎么穿、怎么改」。

#### 内衣/泳装/睡衣
`bra` / `lace bra` | `panties` / `thong` / `g-string` | `lingerie` / `lace lingerie` | `corset` | `garter belt` | `babydoll` / `negligee` / `chemise` | `bodystocking` / `fishnet bodystocking` | `bikini` / `micro bikini` / `slingshot swimsuit` | `one-piece swimsuit` / `school swimsuit` / `competition swimsuit` | `pajamas` / `nightgown` / `silk robe` / `satin robe` | `oversized shirt` / `boyfriend shirt` / `camisole`

#### 职业制服
`school uniform` / `sailor uniform` / `serafuku` | `office lady` / `business suit` / `white shirt` + `pencil skirt` | `nurse` / `nurse cap` / `medical gown` | `doctor` / `white coat` / `lab coat` | `police uniform` / `police hat` | `flight attendant` / `stewardess` | `maid outfit` / `french maid` / `maid headdress` | `teacher` / `glasses` | `waitress` / `apron` | `naked apron`

#### 特殊服装
`bunny girl` / `playboy bunny` / `bunny ears` / `bunny tail` | `race queen` | `latex` / `rubber` / `pvc` / `leather` | `kimono` / `yukata` / `miko outfit` | `hanfu` / `cheongsam` / `china dress` / `qipao` | `armor` / `bikini armor` / `damaged armor` | `witch` / `witch hat` / `saint` / `nun` | `wedding dress` / `evening gown` | `idol costume` / `stage costume`

#### 丝袜/鞋类
`thighhighs` / `black thighhighs` / `white thighhighs` | `pantyhose` / `black pantyhose` / `white pantyhose` | `fishnets` / `fishnet thighhighs` | `knee-high socks` / `ankle socks` / `loose socks` | `torn pantyhose` / `ripped stockings` | `high heels` / `stiletto heels` | `boots` / `thigh boots` / `ankle boots` | `mary janes` / `loafers` / `sneakers` | `barefoot`

### 8.2 材质

`silk` / `satin`（柔滑光泽） | `lace` / `lace trim`（透视精致） | `thin` / `see-through` / `sheer`（完全透视） | `cotton`（日常清纯） | `latex` / `rubber` / `glossy` / `shiny`（紧贴光泽 fetish） | `leather`（支配感） | `fishnets` / `mesh`（若隐若现） | `pvc`（高光塑胶） | `transparent` / `translucent`（透明材质）

### 8.3 穿着状态

**正常 → 半脱 → 全裸** 是一个递进光谱，选点代表当前暴露程度：

| 梯度 | 标签 |
|---|---|
| 正常穿着 | 具体服装标签 |
| 滑落/露出 | `off shoulder` / `shoulder slip` / `strap slip` / `areola slip` / `panties peek` / `bra exposed` |
| 掀起/敞开 | `shirt lift` / `skirt lift` / `clothes lift` / `open shirt` / `unbuttoned` / `unzipped` / `open front` / `open fly` |
| 半脱 | `partially undressed` / `half-dressed` / `clothes pull` / `pants down` / `one leg out` |
| 仅剩配饰 | `completely nude` + 保留帽子/手套/丝袜/项圈等单一配件 |
| 破损 | `torn clothes` / `ripped clothes` / `torn pantyhose` / `damaged clothes`（自然暴露） |
| 湿透透视 | `wet clothes` / `see-through` / `wet shirt` / `nipples visible through clothes`（意外暴露） |

### 8.4 色情改造维度

> **核心公式**：`原服装 → 改造方向 → 最终效果`。以下 7 个维度可叠加使用，每个维度从法典提炼了具体的高频标签组合。

#### 8.4.1 透明化（See-through）
把正经服装的面料替换为透明/半透明材质。法典中最高频的改造方向。
- 基础：`see-through` / `transparent` / `sheer` / `translucent`
- 上衣：`see-through shirt` / `transparent shirt` / `see-through jacket` / `transparent jacket` / `see-through blouse`
- 下装：`see-through pants` / `transparent pants` / `see-through skirt` / `transparent shorts`
- 连体：`see-through leotard` / `translucent bodysuit` / `transparent bodysuit` / `see-through bodystocking`
- 特殊：`see-through dress` / `transparent dress` / `transparent wedding dress` / `see-through poncho` / `transparent tabard`
- 外套款：`naked jacket` + `see-through jacket` → 透明夹克内全裸
- 雨衣款：`clear transparent raincoat` / `glossy pvc material` / `wet appearance`
- 湿透自然透明：`wet clothes` / `wet shirt` / `nipples visible through clothes` / `see-through` + `wet`
- 经典组合：`see-through leotard, transparent, see-through sleeves, translucent bodysuit, covered nipples` | `see-through shirt, wet, no bra, nipples visible` | `clear transparent raincoat, hood up, wet body, glossy pvc`

#### 8.4.2 裁剪/缩短化（Cropped/Micro）
大幅缩短或裁剪，定向暴露。
- 上衣：`crop top` / `cropped jacket` / `cropped shirt` / `crop top overhang` / `crop jacket` / `cropped blouse`
- 下装：`micro skirt` / `micro shorts` / `micro dress` / `micro panties` / `extremely short skirt` / `short shorts`
- 高露：`highleg` / `high cut` / `highleg leotard` / `highleg panties` / `highleg swimsuit` / `high-waist skirt`
- 侧露：`side slit` / `hip vent` / `high slit` / `single side slit`
- 无袖：`sleeveless` / `detached sleeves` / `bare shoulders` / `bare arms` / `sideless outfit`
- 露背：`backless` / `bare back` / `backless outfit` / `backless dress`
- 经典组合：`crop top, micro skirt, no panties, highleg, sleeveless` | `cropped jacket, bare shoulders, micro shorts, open fly`

#### 8.4.3 镂空/开口化（Cutout）
开洞定向暴露，法典中变化最丰富的维度。
- 胸：`cleavage cutout` / `chest cutout` / `deep v-neckline` / `exposed chest` / `breasts out`
- 下乳：`underboob cutout` / `underboob` / `sideboob`
- 腹：`navel cutout` / `stomach cutout` / `midriff cutout` / `clothing cutout`
- 腰：`side cutout` / `side cut-out` / `waist cutout`
- 胯：`crotch cutout` / `pussy cut` / `crotch zipper` / `crotchless panties` / `crotchless`
- 臀：`butt crack cutout` / `bare ass`
- 全身多开口：`center opening` / `sideless outfit` / `clothing cutout` + `revealing clothes`
- 经典组合：`cleavage cutout, underboob cutout, navel cutout, side cutout` | `crotch cutout, no panties, side slit, exposed pussy` | `sideless outfit, bare shoulders, no bra, sideboob`

#### 8.4.4 破损化（Torn/Damaged）
撕裂/破坏，制造「暴力后/意外」的暴露感。
- 基础：`torn clothes` / `ripped clothes` / `damaged clothes` / `torn fabric`
- 上装：`torn shirt` / `torn dress` / `torn blouse` / `ripped shirt` / `open shirt`
- 下装：`torn pants` / `torn jeans` / `torn shorts` / `torn skirt`
- 袜：`torn pantyhose` / `ripped stockings` / `torn stockings`
- 制服特化：`torn school uniform` / `torn ninja outfit` / `torn prison uniform` / `torn sacrament robe`
- 铠甲：`damaged armor` / `cracked breastplate` / `torn cape` / `battle damage`
- 改造衍生：`revealing clothes`（被撕后暴露） / `bloodstain` / `blood on clothes`
- 经典组合：`torn school uniform, ripped collar, torn pantyhose` | `damaged armor, cracked breastplate, torn cape, battle scars` | `torn dress, bloodstain, revealing clothes, bare shoulders`

#### 8.4.5 胶衣/乳胶化（Latex/PVC）
高光紧贴材质替代原面料，强调身体曲线。
- 材质：`latex` / `rubber` / `pvc` / `glossy` / `shiny` / `wet look`
- 连体：`latex bodysuit` / `black bodysuit` / `latex catsuit` / `bodystocking` / `skintight` / `second skin`
- 分体：`latex dress` / `latex pants` / `latex skirt` / `latex bra` / `latex leotard` / `latex chaps`
- 配饰：`latex gloves` / `elbow gloves` / `latex thighhighs` / `latex boots`
- 透明胶：`transparent pvc` / `transparent vinyl clothing` / `holographic clothing`
- 经典组合：`latex bodysuit, shiny, skintight, second skin, highleg` | `black bodysuit, latex gloves, latex thighhighs, glossy, corset` | `transparent pvc, see-through, holographic clothing, neon trim`

#### 8.4.6 裸露简化化（Naked + Accessories）
脱到全裸但保留标志性配饰或外套，靠配件暗示原身份。法典最经典的反差手法。
- 裸+外套：`naked jacket` / `naked cape` / `naked cloak` / `naked coat` / `naked ribbon` / `naked tabard` / `naked poncho`
- 裸+职业配件：`completely nude` + `police hat` → 裸体警察 | `completely nude` + `maid headdress` + `frilled socks` → 裸体女仆 | `completely nude` + `nurse cap` + `white gloves` → 裸体护士 | `completely nude` + `bunny ears` + `bowtie` → 裸体兔女郎
- 裸+围裙：`naked apron` / `naked apron, bottomless, no bra`
- 裸+日式：`naked kimono` / `open kimono, nude, no panties` | `naked hanfu, open robe, no panties`
- 裸+婚嫁：`naked wedding dress` / `naked ribbon, red veil, nude` / `honggaitou, naked, chinese wedding`
- 裸+战术：`nude` + `load bearing vest` + `holding rifle` / `completely nude` + `gas mask` + `belt`
- 经典组合：`completely nude, naked jacket, open jacket, no panties, high heels` | `naked apron, bottomless, no bra, cooking` | `naked cloak, hooded cape, hood up, see-through silhouette`

#### 8.4.7 非对称化（Asymmetrical）
单侧裸露或单侧穿着，制造「匆忙/意外」的不对称暴露。
- 袖：`one sleeve` / `single sleeve` / `asymmetrical sleeves` / `single glove` / `mismatched gloves`
- 腿：`one leg out` / `one stocking rolled down` / `single thighhigh` / `single thigh boot` / `mismatched legwear` / `single bare shoulder`
- 鞋：`one shoe missing` / `one sneaker missing` / `single boot`
- 衣：`off shoulder` / `one breast out` / `single side slit` / `asymmetrical docking` / `asymmetrical legwear`
- 经典组合：`off shoulder, single bare shoulder, one stocking rolled down, one shoe missing, messy clothes`

#### 8.4.8 职业制服改造实例（法典精华）

以下为法典中经过出图验证的高频职业改造组合，展示了上述 7 个维度如何叠加应用：

**警察（12种改造方向）**：
- 超短连衣裙款：`police uniform, micro dress, white thighhighs, cleavage cutout, police hat`
- V字泳装款：`slingshot swimsuit, police hat, jacket, o-ring, micro shorts, open fly, no panties`
- 渔网裸身款：`crop top, police uniform, fishnet thighhighs, no panties, naked vest, clothes around waist`
- 高腰兔女郎款：`police uniform, blue leotard, highleg, cropped jacket, thong, black thighhighs`
- 夜店常客款：`pasties, torn jeans, open shorts, police cap, fishnet legwear, purple eyeshadow`
- 绑带援交款：`police hat, nude, bondage outfit, o-ring harness, metal collar, nipple rings, latex gloves, used condom belt`
- 仅乳贴网袜款：`pasties, torn jeans, shorts, unbuttoned, police cap, fishnet legwear`
- 裸体警察款：`completely nude, police hat, whistle, holding baton, traffic officer`

**护士（13种改造方向）**：
- 胶衣透明款：`naked poncho, latex pants, reverse bunnysuit, see-through, nurse cap`
- 弹弓泳衣款：`slingshot swimsuit, nurse cap, jacket, holding syringe`
- 破损绷带款：`nurse, torn clothes, bandages, bandaged arm, id card`
- 小恶魔护士款：`nurse outfit, frilled lingerie, lace thighhighs, garter belt, red bat wings, holding syringe`
- 束带护士款：`nurse cap, harness, chest belt, o-ring, transparent, see-through`
- 超短抹胸比基尼款：`nurse, no pants, thong panties, detached collar, detached sleeves, micro panties, strapless`
- 透明雨衣款：`clear transparent raincoat, glossy pvc material, hood up, erotic nurse uniform underneath, extremely short nurse skirt, deep v-neckline`
- 仅乳贴微型内裤款：`nurse cap, micro panties, g-string, pasties, bare shoulders, no bra`

**修女（8种改造方向）**：
- 乳帘修女：`nun, breasts curtain, no panties, between breasts, cross, white pantyhose`
- 舞娘修女：`nun, veil, bodystocking, see-through, harem outfit, breast curtains, pelvic curtain, cameltoe`
- 胶衣修女：`nun, latex catsuit, pussy cut, crotch cut, covered navel, shiny clothes, oil body`
- 逆兔修女：`nun, reverse bunnysuit, see-through leotard, crotchless, cross necklace`
- 仅乳贴修女：`nun, pasties, micro panties, g-string, black thighhighs, elbow gloves, stained glass`
- 战斗修女：`leather clothing, naked tabard, shining swimsuit, nun, holding revolver, sideboob, chains, cross`
- 帘幕式：`nun, see-through silhouette, covered nipples, cross necklace, veil, white breast curtain, puffy sleeves`

**女仆（6种改造方向）**：
- 无袖下乳开口：`maid outfit, bare shoulders, clothing cutout, underboob, white apron, sleeveless`
- 裸体女仆：`nude, maid headdress, bridal garter, frilled socks, mary janes`
- 胸部托盘：`maid headdress, topless, breasts on tray, body writing, black thighhighs, groin`
- 裸体围裙：`naked apron, no panties, no bra, maid headdress`
- 透明裁剪：`maid outfit, see-through, micro skirt, open front, crotchless panties`

**兔女郎（法典最丰富的服装类型，16+常规款+8+逆兔款）**：
- 经典款：`bunny ears, black leotard, highleg leotard, black pantyhose, white collar, bowtie, cuffs`
- 透明款：`translucent bunnysuit, black bodystocking, see-through leotard, crotch cutout, transparent heels`
- 双色开口款：`red bodystocking, cleavage cutout, clothing cutout, elbow gloves, two-tone leotard`
- 西装兔女郎：`tuxedo, black leotard, black suit, fishnet pantyhose, half gloves, white waistcoat`
- 逆兔女郎：`reverse bunnysuit, frontless outfit, shrug, heart pasties, see-through bodystocking, gloves`
- 逆兔透明兜帽款：`reverse bunnysuit, hooded bodysuit, hood up, shiny clothes, x pasties, tape on pussy, gas mask around neck`
- 逆兔渔网连体款：`reverse bunnysuit, shrug, heart pasties, nude, o-ring, waist chain, fishnet gloves, chain leash`
- 赛博雨衣逆兔：`clear transparent raincoat, glossy pvc, hood up, reverse bunny suit, black mesh fabric, fluorescent pink bunny ears, black garter belt, transparent stockings, linked piercing`

**巫女（8种改造方向）**：
- 弹弓泳装巫女：`slingshot swimsuit, miko outfit, detached sleeves, white thighhighs, cameltoe, sideboob`
- 半截裙巫女：`miko, short kimono, obi, sleeveless, sideboob, white panties, high-waist panties, groin`
- 室内绳缚巫女：`seiza, nude, miko, white kimono, open kimono, bottomless, red rope, covered nipples, shouji`
- 符咒遮点狐巫女：`miko, sideboob, crop top, bottomless, ofuda on pussy, no panties, fox hood`
- 露胸巫女：`white kimono, miko, cleavage, open clothes, no bra`

**学生/OL 日常改造**：
- 透明衬衫：`see-through shirt, tied shirt, no bra, nipples visible, micro shorts, denim`
- 低腰露内裤：`crop top, lowleg pants, open fly, no panties, exposed pocket, black bra, thigh gap`
- 裸外套：`completely nude, naked jacket, see-through jacket, open jacket, barcode tattoo`
- 裸围裙：`naked apron, bottomless, no bra, cooking, casual`
- 透明长裙：`see-through dress, wet dress, wet clothes, no bra, bare shoulders, sundress`
- 透明打结衬衫+短裤：`see-through shirt, tied shirt, denim shorts, no panties`

### 8.5 反差搭配公式

> **最强效果 = 最高正经度的服装 × 最高暴露度的改造**

| 反差类型 | 公式 | 效果 |
|---|---|---|
| 校服堕落 | `school uniform` + `micro skirt` + `no panties` + `open shirt` | 禁忌感 max |
| 修女亵渎 | `nun` + `torn habit` + `see-through` + `no panties` | 亵渎感 max |
| 婚纱悲剧 | `wedding dress` + `torn` + `ripped` + `tears` | 破灭感 max |
| 女警堕落 | `police uniform` + `slingshot swimsuit` + `fishnet thighhighs` + `no panties` | 公权力崩塌 |
| 女仆色情 | `maid outfit` + `micro skirt` + `crotchless panties` + `open front` | 服务变服务 |
| 巫女破戒 | `miko outfit` + `open kimono` + `bottomless` + `no panties` | 神圣破戒 |
| OL 反差点 | `office lady` + `pencil skirt` + `no panties` + `open shirt` + `braless` | 职场淫乱 |
| 护士失控 | `nurse` + `micro dress` + `crotch cutout` + `latex gloves` | 医疗变猥亵 |

### 8.6 涩涩道具与玩具

| 类别 | 核心标签 |
|---|---|
| 束缚具 | `handcuffs` / `shackles` / `ropes` / `chains` / `duct tape` / `tape bondage` |
| 口具 | `ball gag` / `bit gag` / `ring gag` / `cloth gag` / `tape over mouth` |
| 眼罩 | `blindfold` / `eye mask` |
| 项圈 | `collar` / `choker` / `bell collar` / `spiked collar` / `leash` / `o-ring choker` |
| 震动棒 | `vibrator` / `egg vibrator` / `wand vibrator` / `remote control vibrator` |
| 假阳具 | `dildo` / `double dildo` / `strap-on` / `suction cup dildo` |
| 肛塞 | `butt plug` / `tail plug` / `anal beads` |
| 乳夹 | `nipple clamps` / `clothespins` / `breast bondage` |
| 飞机杯 | `artificial vagina` / `onahole` / `masturbator` |
| 液体道具 | `lotion` / `oil` / `candle wax` / `ice` / `whipped cream` |
| 身体标记 | `body writing` / `tally marks` / `lipstick mark` / `handprint` |
| 贞操具 | `chastity cage` / `chastity belt` |
| 其他 | `feather` / `whip` / `crop` / `paddle` / `spreader bar` / `condom` / `used condom` / `condom belt`

---

## 9. POSE & ACTION & SEX

> 对应槽位：`[pose/action/sex]`
> 
> **本章每个子节统一格式**：① 核心公式 — 一句话点明场景精髓 ② 变体维度表 — 多维度×可选标签，AI自由组合 ③ 氛围链 — 情绪从轻到重递进 ④ 使用提示 — 如何组合、避坑 ⑤ 法典验证场景 — 法典出图验证过的具体组合，仅供参考不固定套用

### 9.1 单人

#### 9.1.1 诱惑姿态

**核心公式**：`暗示 > 直接展示 + 延迟满足 + 主动臣服`

**变体维度**（以下维度可自由组合，每个维度选1-2个标签）：

| 维度 | 可选标签 |
|---|---|
| 眼神 | `looking at viewer` / `half-closed eyes` / `looking back` / `looking up` / `looking down` / `heavy-lidded eyes` |
| 口唇 | `licking lips` / `tongue out` / `parted lips` / `finger on lips` / `finger in mouth` / `sucking finger` / `condom in mouth` / `biting lower lip` |
| 手部 | `touching self` / `hand on breast` / `hand between legs` / `grabbing own breast` / `bouncing breasts` / `hand:2 fingers on mouth` / `hand on own crotch` / `arms up` |
| 身体姿态 | `bending over` / `presenting` / `bent over` / `arched back` / `spread legs` / `kneeling` / `squatting` / `legs crossed` / `straddling` / `on all fours` |
| 服装互动 | `clothes pull by self` / `skirt lift by self` / `shirt lift by self` / `strap slip` / `off shoulder` / `open shirt` / `unworn panties` / `partially undressed` / `undressing` |
| 辅助道具 | `condom in mouth` / `holding vibrator` / `selfie` / `holding phone` / `wine glass` / `coffee mug` / `cigarette` |
| 情境氛围 | `in heat` / `drunk` / `sweat` / `steaming body` / `heart` / `heavy breathing` / `after sex` |

**氛围链**：`blush → seductive smile → half-closed eyes → tongue out → spreading legs → presenting`

**使用提示**：组合示例——眼神选 `looking back, half-closed eyes` + 口唇选 `parted lips, tongue out` + 身体选 `bent over, presenting` + 情境选 `sweat, in heat`。核心是传达「即将做但还没做」的张力，而非直接展示。

**法典验证场景**（以下为法典出图验证过的具体场景，供参考而非固定模板）：
- 二指开嘴口交邀请：`bare shoulders, virgin killer sweater, sideboobs, hand:2 fingers on mouth, tongue out, half-closed eyes, close-up, expressionless`
- 嘴叼避孕套欺身诱惑：`office lady, pencil skirt, side slit, bent over, hands on table, condom in mouth, knee up, looking down, seductive smile, 1boy, business suit, sitting`
- 雌小鬼旗袍大小姐嘲讽：`white cheongsam, highleg, feather boa, crossed legs, on couch, red wine, looking down, smug, from below, ojousama pose`
- 床上半脱预备性爱：`white shirt, open shirt, unworn panties, pussy juice stain, spread legs, black panties, side-tie panties, see-through thighhighs, on back, pillow, blush`

---

#### 9.1.2 暴露/露出

**核心公式**：`不该露的地方 × 不该露的时间 × 不该露的方式 = 暴露场景`

**变体维度**：

| 维度 | 可选标签 |
|---|---|
| 暴露诱因 | `accidental exposure` / `clothes slip` / `skirt lift by wind` / `wet clothes` / `see-through` / `torn clothes` / `undressing` / `pants pull` / `bra pull` / `topless` / `completely nude` |
| 暴露部位 | `nipples slip` / `areola slip` / `cleavage` / `breasts out` / `one breast out` / `downblouse` / `upskirt` / `panty peek` / `no panties` / `cameltoe` / `groin` / `bottomless` / `pussy visible` / `bare ass` |
| 地点 | `outdoors` / `public` / `train interior` / `classroom` / `office` / `kitchen` / `changing room` / `bathroom` / `shower` / `elevator` / `stairwell` / `cinema` / `rooftop` / `beach` / `swimming pool` / `alley` |
| 暴露后果 | `covering breasts` / `covering crotch` / `trying to be quiet` / `nervous` / `embarrassed` / `blush` / `surprised` / `tears` / `shy` / `risk of discovery` / `caught` |
| 旁观者（可选） | `strangers` / `crowd` / `hidden camera` / `webcam` / `streaming` / `mirror` / `selfie` / `from outside` |

**氛围链**：`secret → nervous → risk of discovery → exposed → public → humiliated`

**使用提示**：核心是制造「本该隐藏的突然暴露」的意外感。组合示例——诱因选 `wet clothes, see-through` + 部位选 `nipples visible, cameltoe` + 地点选 `train interior` + 后果选 `nervous, covering breasts`。不要同时选多个人多的地点和暴露后果，选一个核心张力就够了。

**法典验证场景**：
- 电车上无意识领口露出：`from side, accidental exposure, downblouse, train interior, areolae slip, loose clothes, dress shirt, shoulder bag, holding phone`
- 出浴薄纱透视：`close-up, see-through silhouette, shawl, nude, wet hair, standing, groin, wet skin, steam, light leaks, lens flare`
- 裸体围裙做饭：`back, naked apron, no bra, sideboob, black panties, looking back, holding cooking pot, kitchen, window, morning`
- 浴室裸体贴玻璃：`against glass, breasts on glass, frosted glass, nude, wet hair, wet face, steam, fog, condensation, tiled wall`
- 运动后汗湿透视：`white gym shirt, wet clothes, steaming body, see-through, covered nipples, sitting on playground, hanging breasts, blue sky, bokeh`

---

#### 9.1.3 自慰

**核心公式**：`工具 × 场景 × 辅助元素 = 无限组合`

**变体维度**：

| 维度 | 可选标签 |
|---|---|
| 工具 | `fingering` / `vibrator` / `wand vibrator` / `dildo` / `double dildo` / `anal beads` / `humping pillow` / `shower head` / `table humping` / `exercise ball` / `cucumber` / `artificial vagina` |
| 体位 | `lying on back` / `lying on stomach` / `sitting` / `squatting` / `all fours` / `kneeling` / `spread legs` / `m legs` / `on side` / `on chair` / `on bed` |
| 场景 | `bedroom` / `bathroom` / `shower` / `classroom` / `office` / `train interior` / `changing room` / `laundry` / `outdoors` / `public` |
| 辅助元素 | `holding phone` / `talking on phone` / `watching porn` / `reading porn magazine` / `looking at mirror` / `smelling clothes` / `holding book` / `selfie` / `after exercise` |
| 暴露程度 | `clothed masturbation` / `panties aside` / `panties pulled` / `no panties` / `completely nude` / `pussy juice` / `pussy juice trail` / `female ejaculation` |
| POV/视角情绪 | `female pov` / `first-person` / `head out of frame` / `from above` / `from side` / `close-up` / `mirror reflection` |

**氛围链**：`touching → fingering → vibrator → dildo → orgasm → squirting → trembling → afterglow`

**使用提示**：每次从3-4个维度各选1-2个标签即可生成新场景。举例——工具选 `vibrator` + 体位选 `lying on back, spread legs` + 场景选 `bedroom` + 辅助选 `watching porn` → 床上看片震动棒自慰。换两个维度就完全不同——工具选 `dildo` + 场景选 `train interior` + 暴露选 `clothed masturbation` + 情绪选 `nervous` → 地铁上隔着衣服假阳具自慰。

**法典验证场景**（法典已验证的特殊组合，标明风险）：
- 接电话时自慰：`open shirt, areola slip, panties aside, fingering, talking on phone, on bed, pussy juice trail, heart`
- 桌角摩擦自慰：`table humping, naughty face, pencil skirt, black pantyhose, pant suit, crotch rub, trembling, arched back, female ejaculation`
- 大屏幕看片自慰：`from back, sitting on chair, panties aside, legs on table, school uniform, big computer screen, sex from behind playing on screen, dark room`
- 办公室自慰：`skirt lift, panties under pantyhose, black pantyhose, pussy juice, wet pantyhose, feet focus, on chair, white shirt, id card, holding phone`
- 教室自慰：`school desk, clothed masturbation, panties, on stomach, upside-down, blush, open mouth`
- 双穴塞入自慰：`transparent dildo, glass dildo, anal beads, pulling anal beads, double penetration, squatting, shiny skin, from below, sweat`

#### 9.1.4 隐秘处展示/自拍/直播

**核心公式**：`谁在看 × 看哪里 × 怎么展示 = 窥探张力`

**变体维度**：

| 维度 | 可选标签 |
|---|---|
| 展示部位 | `pussy` / `spread pussy` / `anus` / `cameltoe` / `upskirt` / `panties` / `no panties` / `groin` / `cleavage` / `nipples` / `armpits` / `feet` / `tongue` / `oral cavity` |
| 展示方式 | `skirt lift` / `dress lift` / `clothes lift` / `pants pull` / `spread legs` / `presenting` / `bent over` / `squatting` / `from below` / `from behind` / `pigeon-toed` |
| 媒介 | `mirror` / `selfie` / `holding phone` / `smartphone` / `webcam` / `streaming` / `viewfinder` / `fake screenshot` / `recording` |
| 辅助道具 | `hand mirror` / `full-length mirror` / `phone` / `laptop` / `camera` / `remote control` / `underwear held up` |
| 情绪 | `embarrassed` / `blush` / `shy` / `seductive smile` / `smug` / `expressionless` / `nervous` / `heart-shaped pupils` / `looking at viewer` / `looking away` |
| 空间 | `bedroom` / `changing room` / `bathroom` / `public toilet` / `classroom` / `mirror` / `outdoors` / `against window` |

**氛围链**：`hidden → revealing → showing → presenting → viewer sees → embarrassed → public display`

**使用提示**：关键张力在「某人正在看（或即将看到）」——可以是自己（对镜）、别人（直播/展示给观众）、或看不见的窥视者（偷拍视角）。组合示例——媒介选 `mirror, selfie` + 部位选 `spread pussy` + 展示方式选 `spread legs, holding phone` + 情绪 `embarrassed, blush` → 对镜开腿自拍小穴。

**法典验证场景**：
- 撩起裙底展示：`maid headdress, no panties, white thighhighs, dress lift, lifted by self, groin, embarrassed, nose blush, covering own mouth`
- 裆下展示：`heart-shaped pupils, pigeon-toed, standing, clothes lift, excessive cum, cum pool, dripping, heavy breathing`
- 对镜自拍小穴：`nude, sailor collar, sitting on floor, legs spread, holding small mirror, looking down, open pussy by self, bedroom, morning light`
- 丰满大腿自拍：`chinese school uniform, no panties, sitting on table, crossed legs, looking at phone, upskirt, holding phone, selfie, curvy, steaming body`
- 手持内衣展示：`completely nude, standing, holding underwear, covering face, black bra, black panties, large areolae, female pubic hair, blush`
- 腋下展示：`arm up, presenting armpit, from side, sleeveless, school uniform, sweat, close-up, steam`避免同时使用3个以上辅助元素。

---

### 9.2 双人前戏

#### 9.2.1 口交

**核心公式**：`深度 × 体位 × 结果 = 无限组合`

**变体维度**：

| 维度 | 可选标签 |
|---|---|
| 深度梯度 | `glans licking, kissing tip, frenulum licking` / `shaft licking, licking penis, tongue out` / `half inserted, penis in mouth` / `deepthroat, throat bulge, gagging` / `irrumatio, face fucking, skull fucking, throat fucking` |
| 体位 | `kneeling` / `standing` / `sitting on chair (boy)` / `lying on back` / `upside-down` / `squatting` / `all fours` |
| 女方情绪 | `eager sucking, assertive female, lustful, looking up` / `reluctant, tears, struggling, scared` / `expressionless, bored, exhausted, empty eyes` / `devoted, closed eyes, blush, kissing penis` |
| 男方动作 | `hand on another's head` / `head grab, held down` / `standing, hands at sides` / `grabbing another's hair` / `pov hands on head` |
| 特殊状态 | `x-ray` (透视深喉) / `:>=` (脸颊凹陷) / `condom left inside` / `penis on face` / `penis over eyes` / `tongue tattoo` |
| 结果 | `cum in mouth, gokkun` / `facial, cum on face` / `excessive cum, cum bath` / `cum bubble, vomiting cum` / `cum string, after fellatio` / `female ejaculation (口交中自慰到达)` |

**氛围链**：`blush → tongue out → drooling → deepthroat → irrumatio → cum in mouth → excessive cum → tears → empty eyes`

**使用提示**：口交的核心张力在「谁主导」——女主动（eager, looking up）vs 男强制（irrumatio, head grab）。深度梯度要与情绪匹配：舔头吻鸡配虔诚/害羞，深喉配失神/崩溃。多人变体：`2girls, cooperative fellatio` 或 `1girl, multiple boys, bukkake`。

**法典验证场景**：
- 侧视跪姿深喉透视：`girl: completely nude, kneeling, deepthroat, throat bulge, arched back, hands on chest, pussy juice / boy: standing, large penis, dark-skinned male, from side, x-ray`
- 虔诚亲吻几把：`girl: kissing the side of penis, holding penis in both hands, closed eyes, blush, eyeshadow / boy: hand on another's head, erection, male pubic hair, standing, front view`
- 几把侧压脸舔蛋：`boy: standing, looking up, veiny penis, large testicles / girl: kneeling, licking testicle, penis on face, male pubic hair`

---

#### 9.2.2 足交

**核心公式**：`姿势 × 足部状态 × 男方反应 = 足交场景`

**变体维度**：

| 维度 | 可选标签 |
|---|---|
| 女方姿势 | `lying on stomach` / `lying on back` / `all fours, looking back` / `sitting` / `standing` / `hug from behind, leg lock` |
| 足部动作 | `foot on penis` / `two-footed footjob` / `tiptoes, toe scrunch` / `soles, foot dangle` / `ankle grabbing by male` |
| 足部状态 | `barefoot` / `black pantyhose` / `white thighhighs` / `fishnet stockings` / `oiled feet, lotion, shiny soles` / `ballet slippers, ballerina` / `wet, soapy` |
| 男方反应 | `trembling, nervous sweatdrop` / `erection, precum` / `cum on feet, cum on soles` / `muscular male, size difference` |
| 特殊道具/玩法 | `chastity cage` (贞操锁踩踏) / `stepped on artificial vagina` / `penis between feet, soles squeezing` / `after sex, sagging penis` |

**氛围链**：`feet → soles → toes → foot on penis → precum → cum on feet → cum between toes`

**使用提示**：足交核心是「脚的美学展示」+「非直接插入的羞耻感」。光脚适合纯欲风，丝袜适合fetish风，润滑油适合高光泽。可与手交同时进行（`footjob + handjob`）。

**法典验证场景**：
- 背身双足交：`lying on stomach, two-footed footjob, legs together, looking back, soles, barefoot, from behind`
- 丝袜足交：`black bodystocking, sheer, foot on penis, soles, pov, precum`
- 润滑油足交：`oiled feet, lotion, shiny soles, footjob, foot on penis, wet, cum on feet`

---

#### 9.2.3 素股

**核心公式**：`坐姿/体位 × 大腿状态 × 润滑/材质 = 素股场景`

**变体维度**：

| 维度 | 可选标签 |
|---|---|
| 体位 | `sitting on lap, face-to-face` / `sitting on lap, reverse upright straddle` / `cowgirl position, thighs squeezing penis` / `lying on side` / `standing, from behind` |
| 女方状态 | `clothed female nude male` / `no panties` / `completely nude` / `latex, bodysuit` / `wet, steam` |
| 额外刺激 | `grabbing another's breasts, from behind grab` / `breastfeeding, sitting sideways on lap` / `licking feet` / `handjob + thigh sex` |
| 润滑 | `lotion on thighs` / `oiled skin` / `pussy juice` / `wet, soapy` / `precum` |
| 场景 | `bedroom, on bed` / `bathroom, shower` / `onsen, steam` / `public, stealth sex` |

**氛围链**：`sitting on lap → grinding → frottage → thigh sex → precum → cum on thighs`

**使用提示**：素股核心是「腿根温热的包裹感」+「不插入但极度亲密」。最适合穿丝袜/胶衣进行（材质触感增强），坐位最适合stealth sex（上面正常下面在做）。

**法典验证场景**：
- 坐位素股：`sitting on lap, legs together, clothed female nude male, sitting sideways on lap, grinding`
- 涂油素股：`lotion on thighs, glansjob, thigh sex, wet, shiny skin, sitting on lap`
- 胶衣素股：`latex bodysuit, shiny clothes, thigh sex, girl on top, male pov`

---

#### 9.2.4 手交

**核心公式**：`手法 × 场景 × 辅助要素 = 手交场景`

**变体维度**：

| 维度 | 可选标签 |
|---|---|
| 技法 | `handjob` / `glansjob` (龟头专攻) / `two-handed handjob` / `reach-around` (背后伸手) / `double handjob` (双人) |
| 体位 | `kneeling in front` / `sitting on lap` / `from behind` / `lying beside` / `sitting on chair (boy), kneeling (girl)` |
| 覆盖物 | `panties on penis, cum through panties` / `stocking-covered handjob` / `latex gloves` / `oil, lotion` |
| 场景 | `bedroom` / `hospital, nurse` / `onsen, steam, soap` / `office, under desk` / `public, audience` |
| 结果 | `precum` / `cum` / `excessive cum` / `cum on hand, cum string` / `cum on face` / `trembling, male ejaculation` |

**氛围链**：`handjob → glansjob → two-handed → reach-around → cum → excessive cum → cum on hand → cum string`

**使用提示**：手交是灵活度最高的前戏，核心技术差异在「技法」——glansjob单攻龟头刺激最强，reach-around背后偷袭femdom感最强。手交+乳交+口交可叠加为三重刺激。

**法典验证场景**：
- 护士手交：`nurse, hospital, vertical-striped, handjob, glansjob, cum, trembling, male ejaculation`
- 背后偷袭：`reach-around, femdom, assertive female, from behind, hugging, whispering in ear`
- 内裤套手：`panties on penis, handjob, cum through panties, precum, cum string`

---

#### 9.2.5 乳交

**核心公式**：`体位 × 胸型 × 附加刺激 = 乳交场景`

**变体维度**：

| 维度 | 可选标签 |
|---|---|
| 体位 | `girl on top, paizuri` / `girl kneeling, boy standing` / `perpendicular paizuri` (站立压墙) / `reverse paizuri` (逆向，同时舔肛) |
| 胸型 | `large breasts` / `huge breasts, gigantic breasts` / `breasts squeeze together` / `sagging breasts` / `cleavage` |
| 附加刺激 | `handjob + paizuri` / `anilingus + paizuri` (逆向舔肛) / `fellatio + paizuri` / `trombone` (乳+手+肛三合一) |
| 润滑 | `lotion on breasts` / `pussy juice` / `precum` / `oiled skin` / `wet` |
| 特殊场景 | `penis under another's clothes` (衣服下进行) / `breastfeeding + paizuri` / `arms around waist, hug` (怀中挤乳) |
| 结果 | `cum on breasts` / `cum on face` / `cum silk, cum string` / `bukkake` |

**氛围链**：`breasts squeeze together → cleavage → breast press → precum → cum on breasts → cum on face`

**使用提示**：乳交视觉冲击力来自「胸围包裹鸡巴」的压迫感。逆向乳交（reverse paizuri, 女朝脚方向）可同时进行舔肛（anilingus）达到双重刺激。三合一（trombone: 乳+手+肛）是最高强度组合但标签需精简。

**法典验证场景**：
- 经典乳交：`paizuri, breasts squeeze together, breast press, large breasts, cleavage, penis on breasts, lotion on breasts`
- 逆向乳交+舔肛：`reverse paizuri, anilingus, looking back, girl on top, from side`
- 站立压墙乳交：`perpendicular paizuri, against wall, standing, huge breasts, boy standing, girl pinned`

---

#### 9.2.6 调戏猥亵

**核心公式**：`权力关系 × 场景 × 越界程度 = 猥亵场景`

**变体维度**：

| 维度 | 可选标签 |
|---|---|
| 权力关系 | `boss, office lady, power imbalance` / `teacher, schoolgirl, grooming` / `doctor, patient, medical examination` / `photographer, model, posing` / `stranger, public, groping` |
| 场景 | `train, crowded, chikan` / `office, after hours` / `classroom, after school` / `hospital room` / `massage table` / `gym` / `street, alley` |
| 越界方式 | `groping, can't move` / `unnecessary touching, medical excuse` / `skirt lift, panty shot` / `peeping, hidden camera` / `drugged, unconscious` / `drunk, taken advantage of` |
| 女方反应 | `scared, trembling, tears` / `ashamed, covering face` / `frozen, can't move, expressionless` / `secret, guilty pleasure` / `angry, resisting` |
| 旁观/暴露风险 | `crowded, surrounded` / `risk of discovery` / `hidden camera, on recording` / `public, strangers watching` |

**氛围链**：`accidental touch → groping → can't move → scared → crying → forced → given up → empty eyes`

**使用提示**：调戏猥亵的核心张力是「权力的错位」——不是暴力强奸，而是利用身份/场景/信任的越界。场景选择决定张力方向：电车=陌生人的侵犯、职场=上下级的胁迫、医疗=信任关系的背叛。

**法典验证场景**：
- 电车痴汉：`train, crowded, chikan, groping, can't move, scared, tears, pantyhose, skirt lift, hidden, surrounded`
- 职场骚扰：`office, boss, office lady, power imbalance, skirt lift, under desk, scared, risk of discovery`
- 摄影越界：`photographer, posing, model, nude modeling, gradually undressing, artistic, power imbalance`

---

### 9.3 双人正戏

#### 9.3.1 正身位（传教士）

**核心公式**：`女腿状态 × 男压制程度 × 视角 = 传教士场景`

**变体维度**：

| 维度 | 可选标签 |
|---|---|
| 女方腿态 | `spread legs` / `legs together` / `legs lift, legs up` / `folded legs, m legs` / `leg lock, crossed ankles` / `one leg lifted` / `legs on another's shoulders` |
| 男方压制 | `missionary, boy on top` / `man covered the girl, full body` / `held down, arm grab, restrained` / `torso grab` / `leg grab, ankle grab` / `hands on another's head` |
| 深度/体位变种 | `piledriver, upside-down, top-down bottom-up` / `deep penetration, stomach bulge` / `just the tip, imminent penetration` |
| 视角 | `from above` / `from side` / `female pov, head out of frame` / `pov, pov crotch` / `front view` / `close-up, face focus` |
| 场景与附加 | `on bed, bedroom` / `on table, desk` / `in bathroom, bathtub` / `fake screenshot, speech bubble` / `greasy skin, sweat` / `ofuda on nipples, breast curtains` |

**氛围链**：`blush → sweat → steaming body → half-closed eyes → tongue out → ahegao → cum inside → fucked silly`

**使用提示**：传教士位核心看「腿」——腿态决定视觉层次。并腿=矜持、锁腰=亲密、折叠提臀=深度暴露。视角选 from above 强调压制感，female pov 强调女性视角。桌上正身是小众但视觉冲击强的变体。

**法典验证场景**：
- 全身压住侵犯：`man covered the girl, full body, from above, greasy skin, lying, sex, spread legs, sheet grab, motion lines`
- 第一人称传教士分穴插入：`female pov, hands pov, sex, labia pull, spread pussy, from above, legs up, tears, lying on bed, folded, pussy juice`
- 抓腿提臀传教士：`front view, upside-down, leg grab, legs lift, spread legs, on back, on bed, speed line, motion blur, heavy breathing`

---

#### 9.3.2 站立位

**核心公式**：`支撑方式 × 面对方向 × 重力状态 = 站立场景`

**变体维度**：

| 维度 | 可选标签 |
|---|---|
| 支撑方式 | `against wall` / `lifting person, carrying` / `one leg lifted, leg on shoulder` / `legs on another's shoulders` / `standing, free balance` / `bent over, hands on wall` |
| 面对方向 | `face-to-face, standing missionary` / `sex from behind, against wall` / `side view` |
| 重力状态 | `lifting, feet don't touch the ground` / `suspended congress, hanging` / `upside-down, legs up` / `standing, feet on ground` |
| 压迫感 | `choking, choke hold` / `against glass, breast press` / `arms around waist, hug` / `hand grabbing another's hair` |
| 场景 | `alley, night` / `shower, steam, wet` / `against window, city view` / `love hotel` / `public toilet stall` |

**氛围链**：`standing → against wall → lifting → feet don't touch the ground → choking → sweating → orgasm`

**使用提示**：站立位核心是「重力」——双脚离地=男方完全控制，压墙后入=强制压迫感最强，窗玻璃后入=羞耻+暴露双重刺激。站立位最爱配 choke hold 增强支配感。

**法典验证场景**：
- 压墙后入：`standing sex, against wall, sex from behind, choking, bent over, hand on wall`
- 悬空抱起正面：`suspended congress, face-to-face, carrying, legs lock, hug, breast press, feet don't touch the ground`
- 窗玻璃后入：`against glass, breast press, sex from behind, standing, from outside, stealth sex, night, city view`

---

#### 9.3.3 坐身位

**核心公式**：`面对方向 × 场景情境 × 隐密度 = 坐位场景`

**变体维度**：

| 维度 | 可选标签 |
|---|---|
| 面对方向 | `face-to-face, upright straddle` / `reverse upright straddle, sex from behind` / `sitting sideways on lap` / `sitting between his legs, back hug` |
| 女方动作 | `grinding` / `bouncing` / `leg lock, hug` / `leaning forward` / `arched back, head back` |
| 情境 | `playing games, holding controller, stealth sex` / `reading book, expressionless` / `eating, drinking, casual` / `talking on phone, secret` |
| 场景 | `on bed` / `on chair` / `izakaya, table, drunk` / `public toilet stall` / `imperial throne room` / `office desk` |
| 隐密度 | `stealth sex, implied sex` / `hand covering own mouth` / `under covers` / `public, risk of discovery` |

**氛围链**：`sitting on lap → hug → grinding → bouncing → stealth → discovered → excessive cum`

**使用提示**：坐身位是最舒适可持续最久的体位，核心看「情境」——正常坐位是温存，游戏坐位/读书坐位是另类日常（上面正常下面在做），女帝坐位是权势反转。stealth sex 是坐位的独有优势。

**法典验证场景**：
- 面对坐位：`face-to-face, sitting on lap, upright straddle, hug, grinding, blush, on bed, sweat`
- 游戏坐位：`playing games, holding controller, sitting on lap, implied sex, stealth sex, expressionless, from side`
- 马桶坐位：`public toilet stall, sitting on lap, hand covering own mouth, reverse upright straddle, stealth sex, nervous`

---

#### 9.3.4 后入位

**核心公式**：`女方支撑 × 插入方向 × 强制程度 = 后入场景`

**变体维度**：

| 维度 | 可选标签 |
|---|---|
| 女方支撑 | `all fours` / `bent over, hands on knees` / `lying on stomach, prone bone` / `against wall, standing` / `on bed, arm support` / `upside-down, hanging` |
| 插入方向 | `sex from behind, doggystyle` / `top-down bottom-up` / `reverse doggystyle, ass-to-ass` / `from side, side doggy` |
| 强制程度 | `hand on another's head, head grab` / `hair pull` / `arms held back` / `choking` / `torso grab` / `armlock, locked arms` |
| 特殊场景 | `against glass, from outside` / `underwater` / `public, stealth sex` / `mirror, reflection` / `all fours on bed` |
| 深度/速度 | `deep penetration` / `rough sex` / `motion lines, speed lines` / `ass ripple` / `bouncing breasts` |

**氛围链**：`all fours → bent over → hair pull → head grab → rough sex → ahegao → mind break → cum inside`

**使用提示**：后入位的核心是「女方看不见男方」——这天然带来支配感和羞耻感。窗玻璃后入（against glass）是羞耻MAX变体。prone bone（女方平趴）比起 all fours 更有压制的重量感。

**法典验证场景**：
- 经典后入：`all fours, on bed, sex from behind, doggystyle, arm support, motion lines, rough sex`
- 窗玻璃后入：`against glass, breast press, sex from behind, standing, from outside, city lights, night, stealth sex`
- 单手压身后入：`hand on another's head, top-down bottom-up, bent over, prone bone, head grab, rough sex`

---

#### 9.3.5 火车便当

**核心公式**：`抱起方式 × 面对方向 × 悬空程度 = 火车便当`

**变体维度**：

| 维度 | 可选标签 |
|---|---|
| 抱起方式 | `suspended congress, carrying` / `reverse suspended congress, folded` / `girl lifting, legs up` / `face-to-face carrying` / `arm support, arms around neck` |
| 面对方向 | `face-to-face, hug, breast press` / `reverse, looking back` / `side view` |
| 悬空程度 | `feet don't touch the ground` / `hanging, legs dangling` / `midair, suspended` / `upside-down` |
| 深度/情绪 | `deep penetration` / `imminent penetration, foreshortening` / `penis awe, nervous` / `vibrator + anal` (双插版) |
| 身体反应 | `trembling, legs shaking` / `arched back` / `stomach bulge` / `ahegao` |

**氛围链**：`suspended congress → lifting → carrying → feet don't touch the ground → folded → nervous → penis awe → trembling`

**使用提示**：火车便当是视觉冲击最强的体位——全身悬空+双脚离地+男方完全控制。逆火车（reverse suspended congress, 背对抱起）比正火车更有暴露感。预备插入（imminent penetration+foreshortening）可制造强张力而不需要真的画插入。

**法典验证场景**：
- 正火车便当：`suspended congress, carrying, face-to-face, leg grab, hug, feet don't touch the ground, motion lines`
- 逆火车便当：`reverse suspended congress, folded, legs up, carrying, looking back, sex from behind, collarbone`
- 预备插入：`suspended congress, imminent penetration, foreshortening, penis awe, nervous, trembling, face-to-face`

---

#### 9.3.6 种付位

**核心公式**：`覆盖程度 × 腿态 × 插入深度 = 种付场景`

**变体维度**：

| 维度 | 可选标签 |
|---|---|
| 覆盖程度 | `mating press, boy on top` / `male fully covers female` / `man on top, man covered the girl` / `prone bone, torso grab` |
| 女方腿态 | `folded, legs up` / `spread legs, on back` / `legs together, m legs` / `ankle grab, piledriver` / `legs on another's shoulders` |
| 深度/结果 | `deep penetration, stomach bulge` / `cum inside, creampie` / `cum overflow, excessive cum` / `pussy gaping, after sex` |
| 视觉/表情 | `from above, close-up` / `from side` / `face focus, ahegao, rolled eyes` / `instant loss, 2koma, before and after` |
| 情境 | `on bed, bedroom` / `drunk, full face blush` / `bored, holding phone, looking at phone` / `after fellatio, cleanup` |

**氛围链**：`boy on top → man covers girl → deep penetration → stomach bulge → ahegao → fucked silly → cum overflow → cum pool`

**使用提示**：种付位是压制感最强的体位——男方全身覆盖+深度插入。关键是「女方被完全折叠」。无感情种付（bored/holding phone）是法典特色变体，反差感极强。种付最爱配差分解构（2koma, before and after）。

**法典验证场景**：
- 标准种付：`mating press, boy on top, deep penetration, male fully covers female, folded, on back, from above, close-up`
- 提腿种付：`legs up, folded, ankle grab, piledriver, deep penetration, on bed, motion lines, ahegao`
- 无感情种付：`mating press, bored, emotionless sex, holding phone, looking at phone, on bed, expressionless`

---

#### 9.3.7 骑乘位

**核心公式**：`面对方向 × 女方主导程度 × 情境play = 骑乘场景`

**变体维度**：

| 维度 | 可选标签 |
|---|---|
| 面对方向 | `cowgirl position, face-to-face` / `reverse cowgirl position, ass focus` / `side view, from side` |
| 女方主导 | `girl on top, straddling` / `leaning forward, breast press` / `grinding` / `bouncing, bouncing breasts` / `stretching, yawning` / `reading book, expressionless` |
| 男方视角 | `pov, from below` / `male pov, looking up` / `from above, overhead` / `pov hands, grabbing another's head` |
| 情境 | `under covers, at night` / `kfc uniform, feeding, public indecency` / `holding gun, scared, coercion` / `streaming, public` / `drunk, love hotel` |
| 速度/强度 | `grinding → bouncing → rough sex → motion lines → speed lines → orgasm` |

**氛围链**：`girl on top → grinding → bouncing breasts → motion lines → speed lines → orgasm → cum overflow`

**使用提示**：骑乘位是女方主导权最强的体位，核心看「女方想干什么」——主动榨取/敷衍日常/被迫胁迫。逆骑乘（reverse cowgirl）突出臀部视觉，POV抱头突出男方仰视感。

**法典验证场景**：
- 标准骑乘：`cowgirl position, girl on top, straddling, leaning forward, grinding, motion lines, sweat`
- 被子下骑乘：`under covers, cowgirl position, dark, at night, on bed, stealth sex, implied sex, from above`
- 逆骑乘：`reverse cowgirl position, ass focus, girl on top, straddling, from behind, on bed, motion lines`

---

#### 9.3.8 睡奸

**核心公式**：`睡眠深度 × 体位 × 侵犯程度 = 睡奸场景`

**变体维度**：

| 维度 | 可选标签 |
|---|---|
| 睡眠状态 | `sleeping, closed eyes, zzz` / `fast asleep, unconscious` / `drunk, messy hair` / `expressionless, relaxed face` / `drugged, limp body` |
| 体位 | `missionary, from above` / `sex from behind, lying on side` / `mating press, man on top` / `prone bone, lying on stomach` / `side doggy, front-to-back` |
| 侵犯程度 | `sleep molestation` / `rape` / `rough sex` / `gentle sex, implied` / `before sex, condom box` |
| 隐蔽感 | `under covers, night` / `dark room, dark background` / `pillow hug` / `on recording, fake screenshot` |
| 事后结果 | `drunk, full face blush` / `expressionless sex, empty eyes` / `cum in pussy, cum overflow` / `saliva, drooling` |

**氛围链**：`zzz → fast asleep → sleeping → closed eyes → unconscious → expressionless sex → cum overflow → empty eyes`

**使用提示**：睡奸的核心禁忌感来自「女方完全无意识，零互动」。体位不要选需要女方配合的类型（骑乘/火车便当）。醉酒（drunk）是睡奸的合理前提。盖被睡奸（under covers）增加隐蔽和偷窥感。与催眠的区别——睡奸中女方处于生理睡眠，催眠中是醒着但意志被剥夺。

**法典验证场景**：
- 传教士睡奸：`sleeping, closed eyes, from above, sex, on back, missionary, on bed, expressionless, sleep molestation`
- 背后位睡奸：`lying on side, sex from behind, pillow hug, under covers, sleeping, closed eyes, zzz, night`
- 醉奸种付：`drunk, mating press, man on top, full face blush, sleeping, messy hair, on bed, deep penetration`

---

#### 9.3.9 催眠

**核心公式**：`控制手段 × 控制深度 × 被控表现 = 催眠场景`

**变体维度**：

| 维度 | 可选标签 |
|---|---|
| 控制手段 | `hypnosis, hypnosis clock` / `hypnosis app, smartphone` / `mind control` / `coin on string` / `hypnotic pocket watch` / `spiral eyes, spiral background` |
| 控制深度 | `@_@, empty eyes` / `expressionless, dull eyes` / `glowing eyes` / `heart-shaped pupils` / `spiral eyes, woman hypnotized lewd` / `unconscious, in a trance-like state` |
| 被控表现 | `zombie pose, outstretched arms` / `salute, standing` / `kneeling, obedient` / `presenting, spread legs` / `undressing, clothes lift by self` / `expressionless sex` |
| 操控者 | `pov, disembodied hand` / `faceless male, standing` / `priest, religious authority` / `app on phone, technology` |
| 结果 | `cum on body, cum on face` / `excessive cum, cum bath` / `corruption, dark persona` / `bimbofication` / `mind break` |
| 差分/对比 | `before and after` / `instant loss, 2koma` / `normal → hypnotized` / `innocent → corrupted` |

**氛围链**：`looking at phone → @_@ → empty eyes → zombie pose → clothes lift by self → expressionless sex → cum on body → mind break`

**使用提示**：催眠与睡奸的核心区别——催眠中女方**醒着但被控**，会主动执行命令（敬礼/掀衣/展示），睡奸中女方完全无意识。手机催眠（hypnosis app）是法典特色现代变体。催眠最爱配差分解构（before and after对比正常态与催眠态）。

**法典验证场景**：
- 手机催眠性爱差分：`hypnosis, pov holding phone, @_@, empty eyes, 2koma, instant loss, micro skirt, white pantyhose, standing sex, cum`
- 催眠二女敬礼：`2girls, front view, hypnosis, empty eyes, glowing eyes, expressionless, salute, standing, saliva, ass to ass`
- 催眠前后对比：`before and after, normal → hypnosis, mind control, empty eyes, corruption, bimbofication, dark persona, heart-shaped pupils`

---

#### 9.3.10 攻守反转/Femdom

**核心公式**：`主导方式 × 男方反应 × 羞辱程度 = 攻守反转场景`

**变体维度**：

| 维度 | 可选标签 |
|---|---|
| 主导方式 | `sitting on face, facesitting` / `pegging, strap-on` / `cowgirl position, pinning down` / `trampling, foot on face` / `chastity cage, keyholder` / `remote control vibrator, public` |
| 男方反应 | `male submission, trembling` / `kneeling, worship` / `bound, restrained` / `defeated, captured, scars` / `aroused despite humiliation` |
| 羞辱程度 | `private, bedroom` / `public, livestream, audience` / `trampling, stepping on` / `foot kiss, foot worship` / `forced open mouth, ring gag` |
| 女性状态 | `assertive female, confident` / `dominant, smug` / `latex, leather, dominatrix` / `nude, completely nude` (女裸男穿=特殊反差) |
| 道具 | `strap-on, dildo` / `chastity cage, chastity belt` / `crop, whip` / `leash, collar` / `remote control` |

**氛围链**：`femdom → assertive female → girl on top → pinning down → male submission → trembling → kneeling → worship → public humiliation`

**使用提示**：攻守反转的核心不是暴力而是「权力倒置」。坐脸是最直接的femdom姿势；pegging是物理层面的角色互换；chastity cage+keyholder是精神控制。与过激的区别——femdom强调女性主导的羞辱，过激强调男性施加的暴力。

**法典验证场景**：
- 坐脸：`sitting on face, facesitting, implied cunnilingus, ass focus, female domination, from below, male submission`
- 假阳具反攻：`pegging, strap-on, role reversal, anal, bent over, girl on top, assertive female, male trembling`
- 踩踏：`trampling, foot on face, foot on crotch, stepping on, heels, male submission, kneeling, worship`

---

#### 9.3.11 过激

**核心公式**：`暴力程度 × 体位 × 女方失神程度 = 过激场景`

**变体维度**：

| 维度 | 可选标签 |
|---|---|
| 暴力手段 | `choke hold, strangling` / `face in water, drowning` / `hair pull` / `arms held back, restrained` / `slap mark, bruise` / `whip marks, red marks` |
| 体位 | `missionary, from above` / `sex from behind, rough sex` / `prone bone, pinned` / `lifting girl, feet don't touch the ground` / `suspended, hanging` |
| 女方失神度 | `tears, crying, streaming tears` / `ahegao, tongue out, drooling` / `empty eyes, expressionless` / `fucked silly, mind break` / `foaming at the mouth` / `convulsing, limp body` |
| 液体/体液 | `excessive cum, cum overflow` / `saliva, drooling, saliva trail` / `pussy juice, pussy juice pool` / `blood on face, blood from mouth` / `sweat, greasy skin` |
| 人数与场景 | `1boy, solo (boy on girl)` / `2boys, spitroast` / `gangbang, multiple boys` / `dark room, dungeon` / `prison cell` / `bedroom, messy room` |

**氛围链**：`rape → rough sex → choke hold → strangling → asphyxiation → fucked silly → empty eyes → foaming at the mouth → convulsing → limp body`

**使用提示**：过激是暴力程度最高的类别，核心区分于普通性爱的是「真实的痛苦」+「失控的体液」。扼喉/窒息/水中是极端变体，使用时分寸要精确——表情链应从「tears → ahegao → empty eyes → foaming」递进选，不要直接跳到最极端。

**法典验证场景**：
- 扼喉传教：`strangling, asphyxiation, missionary, foaming at the mouth, veiny hands, tears, motion lines`
- 全压身爆炒：`man covered the girl, lying on the girl, greasy skin, rough sex, missionary, fucked silly, ahegao`
- 脚不沾地悬空侵犯：`lifting girl, feet don't touch the ground, hanging legs, sex from behind, choking, tears, midair`

---

### 9.4 多人

**核心公式**：`人数 × 孔穴占用 × 体液量 = 多人场景`

**变体维度**：

| 维度 | 可选标签 |
|---|---|
| 人数 | `2boys` / `3boys` / `4boys` / `5boys, multiple boys` / `3girls, 1boy` / `group sex` |
| 孔穴占用 | `spitroast (口+穴)` / `triple penetration (口+膣+肛)` / `double penetration, vaginal + anal` / `one after another (轮奸)` / `cooperative (双人服侍一男)` |
| 包围/压迫 | `surrounded, circle` / `no escape` / `held down, restrained` / `forced to watch, audience` / `waiting turn` |
| 体液 | `bukkake` / `cum bath` / `excessive cum` / `cum on body, cum on face, cum on hair` / `cum pool` / `cum overflow` |
| 事后状态 | `after gangbang, exhausted` / `cum covered, cum dump` / `empty eyes, mind break` / `limp body, convulsing` / `used condom, many used condoms` |
| 主导方 | `assisted rape (协作侵犯)` / `gangbang, group effort` / `male domination` / `femdom, multiple males serving` |

**氛围链**：`2boys → 3boys → group sex → spitroast → gangbang → surrounded → no escape → excessive cum → cum bath → exhausted`

**使用提示**：多人场景核心是「同时发生的多重刺激」+「被包围的无助感」。spitroast（前后夹击）是最经典的多人构图。人数标签必须精确——`Xboys` 的X是实际人数。体液量随人数增多而指数级增长。

**法典验证场景**：
- 前后夹击：`spitroast, 2boys, blowjob, sex from behind, lying on back, group sex, from side`
- 三穴同入：`triple penetration, oral + vaginal + anal, 3boys, group sex, gangbang, lying, ahegao`
- 轮奸事后：`after gangbang, cum covered, excessive cum, cum pool, exhausted, empty eyes, 4boys, multiple boys`

---

### 9.5 百合

**核心公式**：`互动类型 × 亲密程度 × 道具 = 百合场景`

**变体维度**：

| 维度 | 可选标签 |
|---|---|
| 互动类型 | `cunnilingus, face sitting` / `tribadism, scissoring, pussy to pussy` / `fingering, hand between legs` / `double dildo, ass-to-ass` / `kissing, hug, embrace` |
| 体位 | `face-to-face, intimate` / `from side, profile` / `from above, overhead` / `69, mutual oral` / `girl on top, straddling` |
| 道具 | `double dildo, ass-to-ass penetration` / `vibrator, shared vibrator` / `strap-on, pegging` / `anal beads` / `no toys, pure bodies` |
| 包容第三人 | `yuri, 2girls only` / `2girls, 1boy, cooperative fellatio` / `multiple girls, 1boy, harem` / `2girls, 1boy, one watches` |
| 液体/反应 | `pussy juice` / `female ejaculation` / `blush, intimate` / `sweat, wet skin` / `trembling, orgasm` |

**氛围链**：`kissing → embrace → cunnilingus → tribadism → scissoring → grinding → orgasm → afterglow`

**使用提示**：百合核心是「平等亲密」——没有男女体位那种天然权力差。tribadism/scissoring 是百合独有的插入替代体位。道具互插（double dildo ass-to-ass）是百合特色玩法。协作服务（2girls+1boy）是百合+异性的混合场景。

**法典验证场景**：
- 骑乘摩擦：`tribadism, scissoring, grinding, pussy to pussy, girl on top, from above, sweat, blush`
- 口舌：`cunnilingus, face sitting, oral, tongue out, from below, pussy juice`
- 道具互插：`double dildo, ass-to-ass penetration, 2girls, yuri, all fours, from side, trembling`

---

### 9.6 动作氛围链汇总

以下链式结构贯穿所有体位，从轻到重递进。AI 可根据用户描述的强度自动匹配对应梯级，从链首取1-2词+链中取1-2词，不越级跃迁。

**强制链**：`restrained → arms held back → held down → hair pull → rape → rough sex → choke hold → asphyxiation`

**失神链**：`blush → half-closed eyes → ahegao → tongue out → drooling → fucked silly → rolling eyes → mind break → heart-shaped pupils → foaming at the mouth`

**羞耻链**：`shy → blush → embarrassed → nervous → scared → crying → humiliated → ashamed → empty eyes`

**运动链**：`motion lines → motion blur → speed lines → bouncing breasts → ass ripple → hip attack → multiple overlapping motion blurs`

**液体链**（不互斥，可叠加）：`pussy juice → saliva → sweat → precum → cum → cum inside → cum overflow → cum drip → excessive cum → cum bath → bukkake → female ejaculation`

### 9.7 差分/分镜表现

用于表现前后变化、时间对比或同时发生的多视角。可单独使用或叠加在任意体位上。

| 标签 | 效果 |
|---|---|
| `instant loss` | 角色状态急转直下（战败/屈服） |
| `2koma` | 两格漫画对比（前后/因果） |
| `before and after` | 事前vs事后对比 |
| `2views` | 同一时刻两个视角 |
| `split screen` | 画面分屏（NTR经典：左聊天右做爱） |
| `comic` | 漫画风格排布 |
| `multiple views` | 多视角同屏 |

---

## 10. EXPRESSION & REACTION

> 对应槽位：`[expression/reaction]`
> 表情、身体反应、液体是互相关联的叠加层——同一体位可叠加不同强度。本章不拆分独立子节，而是按**强度递进**组织，AI 根据用户描述的关键词自动匹配对应梯级。

### 10.1 表情维度

按情绪光谱分类。每类选 1-2 个标签，不可跨类矛盾（如 `smile` + `crying` 通常矛盾，除非刻意营造破灭感）。

| 情绪类型 | 核心标签 |
|---|---|
| 诱惑/邀请 | `seductive smile, half-closed eyes, looking at viewer, heavy-lidded eyes, licking lips, parted lips, come hither, naughty face` |
| 服从/献身 | `submissive, devoted, obedient, looking up, kneeling, closed eyes, peaceful, light smile` |
| 主导/得意 | `smug, smirk, confident, dominant, evil smile, looking down, sadistic, cool, composed` |
| 抗拒/痛苦 | `scared, reluctant, crying, tears, streaming tears, struggling, frown, clenched teeth, pain, wavy mouth` |
| 失神/崩坏 | `ahegao, tongue out, drooling, rolling eyes, fucked silly, mind break, heart-shaped pupils, torogao, cross-eyed, empty eyes` |
| 羞耻/内疚 | `embarrassed, blush, ashamed, guilty, humiliated, covering face, looking away, nervous` |
| 平静/中性 | `expressionless, emotionless, bored, sleepy, yawning, looking at phone, closed eyes, calm` |
| 惊讶/好奇 | `surprised, wide-eyed, @_@, nervous sweatdrop, curious, o_o` |

### 10.2 强度映射

根据用户描述中的情绪关键词，自动匹配对应标签等级。**同一 prompt 中表情标签不超过 3 个**，选最能代表当前强度的。

| 用户描述关键词 | 强度 | 表情标签 | 身体反应 |
|---|---|---|---|
| 有点害羞/微红/不好意思 | Lv1 轻度 | `blush, shy, slight smile` | `slight trembling` |
| 喘气/忍不住/舒服 | Lv2 中度 | `moaning, panting, heavy breathing, blush` | `trembling, sweat` |
| 快哭了/受不了/要坏了 | Lv3 高度 | `ahegao, tears, tongue out, drooling, crying` | `arched back, toes curling, shaking, body blush` |
| 彻底坏掉/崩溃/失神 | Lv4 极限 | `fucked silly, mind break, heart-shaped pupils, rolling eyes` | `convulsing, limp body, foaming at the mouth, squirting` |
| 得意/主导/享受 | 主导型 | `smug, smirk, confident, seductive smile` | 无明显生理失控 |
| 害怕/不情愿/被迫 | 抗拒型 | `scared, reluctant, crying, tears` | `struggling, trembling, clenched fists` |
| 认命/顺从/放弃抵抗 | 屈服型 | `empty eyes, submissive, defeated, expressionless` | `limp body, no resistance, twitching` |
| 困倦/无力/睡眠中 | 无意识型 | `closed eyes, sleeping, zzz, expressionless` | `limp body, no reaction, relaxed face` |

**使用规则**：用户未明确描述情绪时，根据场景默认取 Lv2。强制/胁迫场景默认取"抗拒型"，除非用户指定已屈服。Lv3 以上必须搭配至少 1 个身体反应标签。

### 10.3 身体反应

| 类型 | 核心标签 |
|---|---|
| 生理反应 | `trembling, goosebumps, flush, sweat, shaking, steaming body, sweat drops, full-face blush, body blush, nose blush` |
| 高潮反应 | `orgasm, arched back, toes curling, legs shaking, convulsing, squirting, female ejaculation, head back, trembling` |
| 抵抗/顺从 | `struggling, grabbing sheets, clinging, limp body, twitching, no resistance, arms at sides` |
| 体力消耗 | `sweat, sweaty, sweating profusely, greasy skin, heavy breathing, panting, exhausted, collapsed` |

**使用规则**：生理反应和高潮反应可叠加（`trembling + arched back + orgasm`）。抵抗/顺从二选一。体力消耗按场景强度递增。每类选 1-2 个标签，总数不超过 3 个身体反应标签。

### 10.4 液体层次

从轻到重的递进光谱。不互斥，可按场景强度叠加 2-3 级。

| 层级 | 标签 | 适用场景 |
|---|---|---|
| 轻度湿润 | `pussy juice` / `wet` / `shiny skin` | 前戏/自慰/诱惑 |
| 中度液体 | `sweat` / `saliva` / `saliva trail` / `drooling` | 口交/深喉/过激 |
| 射精 | `precum` → `cum` → `cum inside` / `creampie` | 插入性爱 |
| 大量溢出 | `cum overflow` → `cum drip` → `cum string` → `cum pool` | 多人/种付/后入 |
| 极限精浴 | `excessive cum` → `cum bath` → `bukkake` | 轮奸/群交/RBQ |
| 女方潮喷 | `female ejaculation` / `squirting` / `pussy juice pool` | 高潮/过激/自慰 |

**使用规则**：不同角色可叠加不同液体（女方 pussy juice + 男方 cum）。液体层次选 1-2 级，不跨越超过 2 级（不要同时写 `pussy juice` 和 `bukkake`，除非刻意制造极端对比）。

### 10.5 身体痕迹

| 类型 | 核心标签 |
|---|---|
| 吻痕/咬痕 | `hickey, bite marks, lipstick mark, kiss mark` |
| 绳痕/束缚痕 | `rope marks, red marks, skindentation, bound wrists marks` |
| 掌印/击打痕 | `handprint, slap mark, spank mark, red ass` |
| 淤青/伤痕 | `bruise, bruise on face, scars, scratch marks, whip marks, cuts, blood on face` |
| 书写/标记 | `body writing, tally marks, tattoo, number tattoo, barcode tattoo, lipstick mark on body` |
| 体液痕迹 | `cum on body, cum on face, cum on breasts, cum on hair, cum on clothes, pussy juice stain, sweat stain` |

**使用规则**：痕迹隐含了前序动作，选 1-2 个能暗示剧情的即可。绳痕暗示束缚，掌印暗示打屁股，书写暗示调教/RBQ。不要同时堆叠所有痕迹标签。

---

## 11. CAMERA & SHOT

> 对应槽位：`[camera/shot]`
> 通用镜头体系 + 特化视角 + 体位专属搭配

### 11.1 景别

| 景别 | 标签 | 适用场景 |
|---|---|---|
| 极致特写 | `extreme close-up` | 脸部/眼睛/私处/龟头/乳头 |
| 标准特写 | `close-up` | 口交面部/胸部/足部/插入处 |
| 头部聚焦 | `face focus, head out of frame` | 身体局部匿名的暧昧特写 |
| 胸像 | `upper body, bust shot` | 半身诱惑/露胸/手交 |
| 牛仔镜头 | `cowboy shot` | 最常用中景——胯以上，展示身体+部分环境 |
| 全身 | `full body, full shot` | 完整展示体位/服装/场景互动 |
| 广景 | `wide shot` | 多人场景/暴露露出/环境叙事 |

### 11.2 视角方向

| 视角 | 标签 | 场景效果 |
|---|---|---|
| 正面 | `from front, front view` | 直接展示，平等视角 |
| 侧面 | `from side, profile` | 展示身体曲线/插入深度/体位弧线 |
| 背面 | `from behind, back view` | 臀部聚焦/后入位/偷窥感/匿名视角 |
| 俯视 | `from above, top-down view` | 压制感（传教士/种付）/ 女性POV / 桌下视角 |
| 仰视 | `from below, low angle` | 仰视压迫感（骑乘/坐脸）/ 乳房压在脸上 / 男方POV |
| 鸟瞰 | `bird's eye view, overhead` | 被完全压制的无助感 / 群交全景 |
| 过肩 | `over shoulder, from behind over shoulder` | 偷窥/旁观/第一人称代入 |

### 11.3 POV 镜头（核心）

| 类型 | 标签 | 适用体位 |
|---|---|---|
| 男方第一人称 | `pov, pov hands, pov crotch` | 口交/手交/乳交——看女方在下方服务 |
| 女方第一人称 | `female pov, head out of frame` | 传教士/骑乘——看男方压上来或仰视 |
| 俯视POV | `pov, from above, looking down` | 男方看口交/骑乘时看女方在下方 |
| 仰视POV | `pov, from below, looking up` | 坐脸/骑乘——女方臀部压向镜头 |
| 后入POV | `pov, from behind, top-down bottom-up` | 后入位——男方视角看自己插入 |
| 第一人称被骑 | `pov, from below, girl on top` | 骑乘位——仰视女方主导 |
| 手入镜POV | `pov hands` | 男方双手入镜（抓臀/抓胸/按头）增强代入感 |

**使用规则**：POV 不能与 `full body` 同时使用（看不到自己全身）。POV 拍单人自慰时用 `female pov`，拍双人互动时选对应体位POV。

### 11.4 构图与镜头效果

| 类型 | 标签 | 效果 |
|---|---|---|
| 荷兰角 | `dutch angle` | 不安/混乱/失控感——过激/强奸/恶堕 |
| 透视缩短 | `foreshortening` | 强调局部（鸡巴正对镜头/脚底特写/即将插入的压迫感） |
| 身体前倾 | `body leaning forward` | 增强角色向观众的冲击力——诱惑/封面/主视觉 |
| 鱼眼 | `fisheye, ultra wide angle` | 夸张变形——极端POV/多人包围 |
| 运动模糊 | `motion blur, speed lines` | 高速抽插/激烈性爱/高潮瞬间 |
| 对焦 | `depth of field, shallow depth of field, bokeh` | 虚化背景突出主体——室内私密/户外暴露 |
| 剪影 | `silhouette, backlit silhouette` | 透过门窗/雾气/玻璃的朦胧性爱 |
| 广角 | `wide angle` | 容纳多人/展示全景环境 |

### 11.5 体位专属镜头推荐

> AI 在选择了体位后，优先从此表推荐视角。1 个体位配 1-2 个推荐视角。

| 体位 | 推荐视角 | 效果 |
|---|---|---|
| 传教士 | `from above` / `from side` | 俯视=压制感 / 侧面=展示身体弧线 |
| 站立/压墙 | `from side` / `full body` | 展示全身动态 |
| 坐位 | `from side` / `cowboy shot` | 展示两人拥抱+环境 |
| 后入 | `from behind, top-down bottom-up` / `from side` | 突出臀部线条 |
| 火车便当 | `full body, from side` / `from below` | 展示悬空+男方力量 |
| 种付 | `from above, close-up` | 压制+深度插入感 |
| 骑乘 | `from below, looking up` / `pov, from below` | 仰视女方主导 |
| 口交 | `pov, from above` / `close-up, face focus` | 男方俯视 / 脸部特写 |
| 足交 | `from side, feet focus` / `pov crotch` | 展示足部动作 |
| 乳交 | `pov, from above` / `close-up, breast focus` | 男方俯视/胸部特写 |
| 坐脸 | `from below, pov` | 臀部压向镜头 |
| 睡奸 | `from above` | 偷窥/俯视侵犯感 |
| 百合 scissors | `from above` / `from side` | 展示两人身体交错 |
| 多人/群交 | `from above` / `wide shot, full body` | 容纳全员+包围感 |
| 暴露/露出 | `from outside, through window` / `peeping` | 偷窥/被发现的风险 |

### 11.6 身体部位聚焦（法典特化）

当画面以特定身体部位为核心时，配合景别标签使用：

| 聚焦部位 | 推荐组合 |
|---|---|
| 胸部 | `close-up, breast focus, head out of frame` |
| 裙底/私处 | `from below, upskirt, close-up` |
| 臀部 | `from behind, ass focus, full body` |
| 足部 | `close-up, feet focus, soles, from below` |
| 插入处 | `close-up, pov crotch, from above` |
| 腋下 | `close-up, armpit focus, from side, arm up` |
| 口腔/口交 | `close-up, face focus, from above` |
| 腿部 | `full body, thigh focus, from side` |

### 11.7 分镜/多画面

| 标签 | 效果 |
|---|---|
| `split screen` | 画面分屏（NTR经典：左聊天右做爱） |
| `2koma, 4koma` | 两格/四格漫画 |
| `before and after` | 事前vs事后对比 |
| `instant loss` | 战败/屈服瞬间转场 |
| `2views, multiple views` | 同屏多视角 |
| `comic` | 漫画风格排布 |

---

## 12. SCENE & ENVIRONMENT

> 对应槽位：`[scene/environment]`
> 场景不只是背景——它决定体位配合、风险感和情感氛围。本章按私密程度组织，每场景配适用体位提示。

### 12.1 场所速查

#### 私密空间（低风险，可尽情发挥）

| 场所 | 核心标签 | 适用体位 |
|---|---|---|
| 卧室 | `bedroom, on bed, bed sheet, pillow` | 所有体位通用 |
| 浴室 | `bathroom, shower, bathtub, wet floor, tiled wall, steam` | 站立压墙/坐位/素股 |
| 酒店 | `love hotel, hotel room, luxury hotel` | NTR/偷情/事后 |
| 地牢 | `dungeon, stone wall, chains` | 束缚BDSM/过激/调教 |

#### 半公开空间（中风险，随时可能被发现）

| 场所 | 核心标签 | 适用体位 |
|---|---|---|
| 客厅/沙发 | `couch, sofa, living room` | 坐位/骑乘/半公开匆忙 |
| 厨房 | `kitchen, counter` | 站立后入/裸体围裙/日常 |
| 办公室 | `office, desk, office chair, after hours` | 桌上正身/职场胁迫/桌下口交 |
| 车内 | `in car, car interior, backseat` | 坐位/口交/素股 |
| 教室 | `classroom, school desk, chalkboard` | 桌上/自慰/师生 |
| 窗边 | `against window, glass, city view, exposed` | 后入压窗/暴露刺激 |

#### 公共空间（高风险，羞耻+禁忌）

| 场所 | 核心标签 | 适用体位 |
|---|---|---|
| 电车/公交 | `train, crowded train, handrail, train interior` | 痴汉/站立/暴露 |
| 电梯 | `elevator` | 快速暴露/闪露/时间压力 |
| 楼梯间 | `stairwell, emergency stairs, concrete wall` | 快速后入/死角紧迫 |
| 公园/长椅 | `park, park bench, outdoors` | 暴露露出/无内短裙 |
| 试衣间 | `fitting room, curtain, mirror` | 偷情/暴露/更衣 |
| 电影院 | `cinema, dark, movie theater, seats` | 暗中口交/手交/隐蔽 |
| 餐厅/居酒屋 | `restaurant, izakaya, table` | 餐桌坐位/桌下服务 |
| 海滩/泳池 | `beach, swimming pool, ocean` | 泳装露出/暴露 |

#### 特殊场景

| 场所 | 核心标签 | 适用主题 |
|---|---|---|
| 教堂 | `cathedral, stained glass, pews, confessional` | 修女亵渎/堕落 |
| 神社/寺庙 | `ancient shrine, torii gate, shouji, tatami` | 巫女破戒/和风 |
| 废墟/战后 | `ruins, destroyed building, rubble, collapsed` | 战败/俘虏/过激 |
| 实验室 | `laboratory, sci-fi, culture tank` | 机械/催眠/改造 |
| 温泉 | `onsen, hot spring, steam, wooden bath` | 共浴/素股/手交 |

### 12.2 场景心理

**四要素公式**：`场所选择 + 体位配合 + 风险元素 + 情感氛围 = 完整场景叙事`

**场所风险矩阵**：

| 场所 | 私密程度 | 风险等级 | 核心张力 |
|---|---|---|---|
| 卧室/酒店 | ⭐⭐⭐⭐⭐ | 低 | 经典安全，可尽情发挥 |
| 浴室/厨房/客厅 | ⭐⭐⭐⭐ | 中 | 日常突破+半公开紧张 |
| 车内 | ⭐⭐⭐ | 中 | 空间创意+车震显眼 |
| 窗边/阳台 | ⭐⭐ | 高 | 暴露刺激+被看到的风险 |
| 办公室/教室 | ⭐⭐⭐ | 高 | 职场/校园禁忌+随时有人回来 |
| 楼梯间 | ⭐⭐ | 极高 | 死角隐蔽+脚步声压迫 |
| 电梯 | ⭐ | 极高 | 时间倒计时+门开恐惧 |
| 试衣间/电影院 | ⭐⭐ | 高 | 半私密+周围有陌生人 |
| 电车/公交 | ⭐ | 极高 | 人群中被围+无法逃脱 |
| 教堂/废墟 | ⭐⭐⭐ | 中 | 神圣亵渎/战后苍凉 |

**场景心理关键词**：
- 安全温柔 → `bedroom, gentle, tender, pillow, soft lighting`
- 湿滑挑战 → `shower, bathroom, wet, steam, against wall, soap`
- 日常突破 → `kitchen, counter, cooking, interrupted, casual`
- 匆忙激情 → `couch, quickie, clothes on, pants down, skirt up, open fly`
- 暴露刺激 → `window, against glass, exposed, curtains open, from outside`
- 职场禁忌 → `office, desk, after hours, overtime, coworker risk`
- 时间压力 → `elevator, stairwell, urgent, quick, footsteps, risk of discovery`
- 神圣亵渎 → `cathedral, stained glass, confessional, corrupted, fallen, blasphemy`

### 12.3 天气/时辰

> 光线/光影/色调标签禁止输出（lora已内置）。以下仅允许环境天气和时辰描写。

| 类型 | 可选标签 |
|---|---|
| 晴/昼 | `day, sunlight, afternoon, morning` |
| 雨 | `rain, rainy night, wet pavement, rain droplets, rainy cityscape` |
| 雪 | `snow, snowfall, snowfield, blizzard` |
| 雾 | `fog, mist, dense fog, morning mist, steam, condensation` |
| 夜 | `night, dark, moonlight, night cityscape, starry sky` |
| 黄昏/黎明 | `sunset, twilight, golden hour` |
| 室内氛围 | `dim lighting, dark room, candlelight, ambient light` |

### 12.4 场景细节

让画面有故事感的锚点道具，按需选1-3个即可。

| 类别 | 标签 |
|---|---|
| 衣物散落 | `scattered clothes, clothes on floor, unworn panties, crumpled sheets, shoes removed` |
| 避孕套 | `used condom, condom wrapper, condom box, many used condoms, condom belt` |
| 事后痕迹 | `cum on sheets, cum pool, pussy juice stain, sweat stain, used tissue` |
| 道具散落 | `sex toy nearby, vibrator on bed, dildo on floor, anal beads on table` |
| 饮食物品 | `wine glass, beer mug, coffee mug, cigarette, ashtray, candle` |
| 电子设备 | `smartphone, laptop, big computer screen, webcam, recording` |
| 空间细节 | `wooden floor, carpet, tatami, curtain, mirror, window, picture frame` |

---

## 13. DETAIL & MOOD

> 对应槽位：`[detail/mood]`
> 画面「看起来像什么」和「给人什么感觉」——不包含场景地点（§12）和镜头（§11）。灯光/光影/色调禁止输出（lora已内置），仅允许以下非光影的氛围与特效标签。

### 13.1 画面质感

改变画面的「媒介感」——让它看起来像水墨、素描、漫画、老照片等。选1个即可，除非刻意混搭。

| 风格 | 核心标签 | 法典使用频率 | 适用场景 |
|---|---|---|---|
| 水墨风 | `ink splash, ink wash, calligraphic brushstrokes, watercolor texture` | ★★★★★ 611次 | 古风/和风/写意 |
| 漫画风 | `comic-style, halftone dots, screentone patterns, comic, greyscale` | ★★★★ 49次 | 差分/前后对比/恶堕 |
| 素描风 | `sketch, lineart, scribbly shading` | ★★ | 粗粝感/未完成感 |
| 绘画风 | `painterly` | ★ | 油画/厚涂质感 |
| 胶片风 | `film grain, vintage film grain, heavy film grain overlay, emulsion scratch` | ★★★ | 怀旧/偷拍/记录感 |
| 黑白 | `greyscale, black and white, monochrome, spot color, limited palette` | ★★ | 压抑/严肃/艺术化 |

**使用规则**：同一个 prompt 不混搭超过 2 种质感风格。`ink splash` + `comic-style` = 水墨漫画风，合理；`ink splash` + `film grain` + `glitch` = 车祸。

### 13.2 运动渲染

法典中使用频率最高的 mood 类标签类型。强化动作感和速度感，适合高强度性爱场景。

| 类型 | 核心标签 | 法典频率 | 效果 |
|---|---|---|---|
| 运动线 | `motion lines` | ★★★★★ 361次 | 漫画式动作线——抽插/冲刺/高潮瞬间 |
| 速度线 | `speed lines` | ★★★★ 87次 | 更密集的方向性速度线——狂暴后入/骑乘 |
| 运动模糊 | `motion blur` | ★★★★ 128次 | 摄影级运动模糊——身体颤抖/快速抽送 |
| 多重运动模糊 | `multiple overlapping motion blurs` | ★★ | 连续动作的残影叠加 |
| 残影 | `afterimages, afterimages due to excessive speed` | ★★ | 高速运动的视觉残留 |

**使用规则**：`motion lines` 偏漫画风格，`motion blur` 偏摄影风格，二选一即可。`speed lines` + `motion blur` 可叠加但不要叠 3 个以上运动标签。适用体位——后入、骑乘、种付、传教士冲刺阶段。

### 13.3 光学/摄影效果

| 类型 | 核心标签 | 法典频率 | 效果与适用 |
|---|---|---|---|
| 景深 | `depth of field, shallow depth of field, bokeh` | ★★★★★ 101+37次 | 虚化背景突出主体——私密场景/室内/户外暴露 |
| 剪影 | `silhouette, backlit silhouette` | ★★★★ 99次 | 透过门窗/磨砂玻璃/雾气——偷窥/匿名/神秘感 |
| 镜头光晕 | `lens flare, lens flare streaks` | ★★★ 34次 | 逆光光晕——浪漫/沐浴后/户外 |
| 辉光溢出 | `bloom` | ★★ 15次 | 画面高光溢出——梦幻/高潮/恍惚 |
| 柔焦 | `soft focus, soft-focus` | ★★ 4次 | 柔和朦胧——事后温存/睡奸/浪漫 |
| 色差 | `chromatic aberration` | ★★ 14次 | 紫边/色彩分离——赛博/故障/催眠 |
| 暗角 | `vignette` | ★ | 边缘压暗——私密/压抑/聚焦中心 |
| 多重曝光 | `multiple exposure effect` | ★ | 重叠影像——回忆/幻象/恍惚 |

### 13.4 数字/故障效果

| 类型 | 核心标签 | 适用场景 |
|---|---|---|
| 数字故障 | `digital glitch effects, glitch art` | 赛博/机械/催眠/精神崩坏 |
| VHS/CRT | `VHS distortion, tracking errors, scan lines, CRT scanlines` | 偷拍/录像带/怀旧监控 |
| 像素化 | `pixelated outlines, blocky pixelated texture` | 羞耻部位遮挡/像素风 |
| 数据流 | `data stream effects, binary code particles` | 赛博/数字化/催眠app |

**使用规则**：数字效果是强风格标签，选1个即可。`glitch` + `VHS` 可叠加（故障录像带），但不要叠到第3个。适合赛博/催眠/偷拍类场景，日常性爱不要用。

### 13.5 氛围基调

非光线的纯情绪氛围词，给画面定情绪基调。

| 类型 | 核心标签 | 适用场景 |
|---|---|---|
| 电影感 | `cinematic, cinematic composition, cinematic angle` | 封面/主视觉/剧情大图 |
| 戏剧张力 | `dramatic tension, dramatic shadows` | 过激/胁迫/对峙 |
| 空灵 | `ethereal, dreamcore, dreamlike` | 浮空/幻想/仙境/恍惚高潮 |
| 暗黑 | `dark atmosphere, suspenseful, ominous` | 地牢/过激/恐怖/恶堕 |
| 明暗对照 | `chiaroscuro` | 经典油画光——束缚/艺术化性爱 |
| 诗意 | `poetic atmosphere` | 古风/和风/事后温存 |
| 混乱 | `chaos, explosive composition` | 群交/多人/过激/战败 |

**使用规则**：氛围词只选1个，它是全局情绪基调。`cinematic` + `ethereal` 可以（史诗空灵），`dark atmosphere` + `poetic` 矛盾。

### 13.6 禁止输出清单

> ⚠️ 以下类型标签绝对禁止出现在 prompt 中（lora已内置光影效果，违者画面将被强光源污染）：

| 禁止类型 | 示例标签 |
|---|---|
| 光线描述 | `sunlight, moonlight, dim light, candlelight, neon light, neon lights, streetlights` |
| 光影技术 | `backlighting, rim light, warm lighting, cool lighting, golden hour glow, soft lighting` |
| 色调描述 | `warm tone, cool tone, sepia, blue tone, amber tone` |
| 光学现象 | `god rays, light rays, light particles, volumetric light beams, tyndall effect` |
| 发光描述 | `glowing, illuminated, lit, backlit, spotlight, flash` |

> **允许**：环境天气描写（`rain, snow, fog, steam, stormy, dust particles, underwater`）和 §12.3 中的时辰/大气标签。

---

## 14. SPECIAL THEME

> 跨槽位场景配方库。以下每个主题需要协调 count/gender → clothing → pose/action → expression → scene 多个槽位，而非单槽位可选。按 §9 标准：公式 + 跨槽位标签链 + 氛围链 + 使用提示 + 法典验证场景。

### 14.1 NTR

**核心公式**：`被夺走的人 × 夺走的方式 × 见证者的痛苦`

**跨槽位标签链**：

| 槽位 | 核心标签 |
|---|---|
| count/gender | `1girl, 1boy, hetero` + 被夺方 + 夺走方 + 苦主（可选入镜或分屏） |
| pose/action | `sex from behind, stealth sex` / `talking on phone, sex` / `watching, forced to watch` |
| expression | 女方：`guilty pleasure, ahegao, corrupted` / 苦主：`crying, empty eyes, despair` |
| camera/shot | `split screen` / `from outside, through window` / `pov, cuckold` |
| scene | `love hotel` / `bedroom, another man` / `phone screen visible, text message` |

**关键变体**：
- 电话NTR：`talking on phone, sex from behind, stealth sex, hand covering own mouth` — 通话中被干
- 窗外NTR：`from outside, through window, peeping, cuckold, forced to watch` — 亲眼看到女友被干
- 分屏NTR：`split screen, left: chatting on phone, right: sex from behind, netorare`
- 事后归宅：`after sex, coming home, messy hair, disheveled clothes, suspicious, husband waiting`
- 女友堕落：`corrupted, mind break, ahegao, heart-shaped pupils, from reluctant to eager`

**氛围链**：`secret → cheating → guilty pleasure → netorare → corrupted → mind break → cuckold despair`

**使用提示**：NTR 的核心是「关系背叛的视觉呈现」——不在体位多刺激，而在「谁在看/谁知道」。分屏（split screen）是 NTR 最强镜头工具。电话要素（talking on phone / smartphone visible / text message）是法典最高频 NTR 符号。

**法典验证场景**：
- 电话NTR：`talking on phone, sex from behind, stealth sex, hand covering own mouth, blush, guilty pleasure, from side`
- 窗外NTR：`from outside, through window, peeping, cuckold, netorare, couple having sex inside, forced to watch, tears`

---

### 14.2 束缚/BDSM

**核心公式**：`束缚方式 × 束缚位置 × 被缚者状态`

**跨槽位标签链**：

| 槽位 | 核心标签 |
|---|---|
| pose/action | `shibari, bound, tied up, arms behind back, hogtie, spread eagle, suspension` |
| clothing | `ropes, hemp rope, red rope, handcuffs, ball gag, ring gag, blindfold, chains, duct tape` |
| expression | `tears, crying, scared, struggling, empty eyes, mind break` |
| body marks | `rope marks, red marks, skindentation, bruise, whip marks` |
| scene | `dungeon, stone wall, prison cell, bedroom, dark room` |

**关键变体**：
- 日式绳艺：`shibari, kinbaku, hemp rope, turtle shell bondage, breast bondage, bound arms, bound torso`
- 十字架/柱缚：`st andrews cross, tied to post, spread eagle, pillory, public display`
- 口具拘束：`ball gag, ring gag, bit gag, drooling, saliva trail, forced open mouth`
- 另类束缚：`duct tape, tape bondage, plastic wrap, mummified, vacuum seal`
- 公开凌辱：`pillory, public display, humiliation, audience, body writing`

**氛围链**：`bound → restrained → gagged → helpless → struggling → crying → empty eyes → mind break`

**使用提示**：束缚核心在「剥夺行动自由」——tag要写清楚束缚了什么部位（arms/legs/torso/wrists/ankles）。绳痕（rope marks + skindentation）是束缚场景的关键真实感标签，没有绳痕=刚绑上去还没开始。另类束缚（duct tape/plastic wrap）适合现代/犯罪场景。

**法典验证场景**：
- 日式后手缚：`shibari, arms behind back, bound arms, bound torso, hemp rope, red rope, rope marks, kneeling, nude, crying, dungeon`
- 口球束缚：`ball gag, drooling, saliva trail, bound wrists, arms behind back, tears, struggling, choker, leash`

---

### 14.3 RBQ/物化

**核心公式**：`物化程度 × 使用人数 × 被使用后的残骸感`

**跨槽位标签链**：

| 槽位 | 核心标签 |
|---|---|
| pose/action | `glory hole, through wall, public use, pillory, all fours, presenting, kneeling` |
| expression | `empty eyes, mind break, expressionless, fucked silly, broken in, exhausted` |
| body marks | `body writing, tally marks, price tag, barcode tattoo, used goods` |
| liquid | `bukkake, cum bath, excessive cum, cum pool, cum covered, cumdump` |
| scene | `public toilet, glory hole, dungeon, pillory, public, surrounded` |

**关键变体**：
- 标准肉便器：`human toilet, urinal, bukkake, cum on body, cum bath, cum pool`
- 壁尻：`through wall, stationary restraints, pillory, glory hole, public use`
- 身体写字：`body writing, tally marks, price tag, degradation, humiliation, barcode tattoo`
- 展示台：`pillory, public display, objectification, audience, forced to watch`
- 多人共用：`public use, gangbang, multiple boys, free use, one after another, cumdump`
- 事后残骸：`after use, cum covered, empty eyes, exhausted, broken in, limp body`

**氛围链**：`objectification → degradation → used goods → human toilet → cumdump → mind break → empty eyes → broken in`

**使用提示**：RBQ核心在「人变成物」——标签应强调非人化（objectification/degradation/used goods）和过量体液（excessive cum/cum bath）。tally marks/price tag/body writing 是画龙点睛的物化标记。区别RBQ和普通群交——RBQ强调「被用完后丢弃」的残骸感，群交强调过程的刺激。

**法典验证场景**：
- 标准RBQ：`human toilet, urinal, bukkake, cum on body, cum bath, excessive cum, cum pool, public use, empty eyes, broken in`
- 壁尻：`through wall, glory hole, stationary restraints, pillory, public use, body writing, tally marks`

---

### 14.4 男娘/Futa

**核心公式**：`生理特征 × 性行为方向 × 身份呈现`

**跨槽位标签链**：

| 槽位 | 男娘 | 扶她 |
|---|---|---|
| count/gender | `otoko no ko, femboy, trap, 1boy` | `futanari, 1girl` |
| appearance | `small penis, flat breasts, androgynous, shota, phimosis, chastity cage` | `huge penis, large breasts, penis and vagina, testicles` |
| clothing | `crossdressing, pantyhose, china dress, maid outfit, school uniform, naked apron` | `bodystocking, latex, reverse bunnysuit, slingshot swimsuit` |
| pose/action | `anal, pegging, sex from behind, fellatio, double dildo, yaoi` | `pegging, futa on female, futa with futa, circle formation, masturbation` |
| expression | `blush, embarrassed, shy, ahegao` | `smug, dominant, evil smile, ahegao, lustful` |

**男娘关键变体**：
- 壮汉后入男娘：`muscular male, sex from behind, otoko no ko, yaoi, anal`
- 带锁男娘：`chastity cage, small penis, phimosis, crotchless pantyhose, femboy`
- 裸体围裙男娘：`naked apron, small penis visible, flat breasts, crossdressing, otoko no ko`

**扶她关键变体**：
- 扶她×女：`futanari, futa on female, pegging, huge penis, girl on top`
- 扶她×扶她：`futa with futa, circle formation, double dildo, ass-to-ass`
- 扶她自慰：`futanari masturbation, huge penis, artificial vagina, dildo riding, cum`

**氛围链**：
- 男娘：`shy → blush → embarrassed → reluctant → ahegao → cum in ass`
- 扶她：`confident → dominant → smug → aggressive → excessive cum → satisfied`

**使用提示**：男娘和扶她是两个独立体系，不能混用（otoko no ko ≠ futanari）。男娘核心在「男性身体+女性外观+被侵犯」的倒错感；扶她核心在「女性身体+男性性器+主导侵犯」的征服感。男娘配 small penis + chastity cage，扶她配 huge penis + large breasts。

**法典验证场景**：
- 壮汉后入男娘：`muscular male, sex from behind, otoko no ko, anal, yaoi, blushing, trembling, hands on hips`
- 扶她爆炒小扶她：`futanari, futa on female, pegging, huge penis, anal sex, x-ray, excessive speed, ahegao`

---

### 14.5 异种

**核心公式**：`异种类型 × 交互方式 × 人类方的反应`

**跨槽位标签链**：

| 异种类型 | 核心标签 |
|---|---|
| 触手 | `tentacles, tentacle sex, multiple tentacles, tentacle pit, tentacle egg, oviposition` |
| 兽交 | `bestiality, knot, canine penis, mounting, breeding, animal on top` |
| 史莱姆 | `slime, slime girl, slime body, tentacle slime, absorption, corruption` |
| 兽人 | `orc, goblin, monster, muscular monster, huge penis, breeding` |
| 虫类 | `insect, arachnid, oviposition, egg, parasite, infestation` |
| 机械 | `machine, robot, mechanical tentacles, milking machine, android` |
| 外星 | `alien, xenomorph, alien egg, probing, abduction` |

**关键变体**：
- 触手拘束侵犯：`tentacles, bound by tentacles, tentacle sex, multiple tentacles, suspended, oviposition`
- 史莱姆吞噬：`slime, absorption, slime body, tentacle slime, inside slime, translucent slime`
- 兽人种付：`orc, huge penis, mating press, breeding, size difference, monstrous, knot`
- 机械榨乳：`machine, milking machine, mechanical tentacles, robot, automated, lactation`

**氛围链**：`surprised → scared → struggling → overwhelmed → ahegao → egg laying / cum overflow → exhausted`

**使用提示**：异种场景核心在「人类vs非人」的体型/力量/数量的绝对不对等。触手适合多孔同时侵犯（tentacle pit），兽人适合体型碾压和种付，史莱姆适合溶解/吸收/体内视角。oviposition（产卵）和 egg 是异种特色结果标签。

**法典验证场景**：
- 触手拘束：`tentacles, bound by tentacles, tentacle sex, multiple tentacles, suspended, oviposition, ahegao, tentacle egg`
- 兽人种付：`orc, huge penis, mating press, breeding, size difference, monstrous, deep penetration, stomach bulge`

---

### 14.6 调教/宠物

**核心公式**：`驯化类型 × 服从表现 × 主人/支配者`

**跨槽位标签链**：

| 槽位 | 核心标签 |
|---|---|
| clothing | `collar, leash, bell collar, tail plug, pet bowl, harness, bit gag` |
| pose/action | `on all fours, crawling, presenting, kneeling, eating from bowl, paw pose` |
| expression | `obedient, submissive, devoted, empty eyes, expressionless, happy, tail wag` |
| body marks | `body writing, tally marks, tattoo, brand, ownership mark` |
| scene | `cage, kennel, pet bowl on floor, indoors, public (遛狗)` |

**关键变体**：
- 犬化训练：`puppy play, collar, leash, crawling, on all fours, tail plug, panting, tongue out`
- 猫化训练：`kitten play, bell collar, cat ears, paw gloves, cat tail, paw pose, tail wag`
- 宠物喂食：`pet bowl, on all fours, eating from bowl, on floor, collar, leash`
- 笼中等待：`cage, locked, trapped, collar, waiting, obedient, on all fours`
- 公共遛狗：`public, leash, crawling, outdoors, collar, tail plug, humiliation, crowd`
- 展示服从：`presenting, spread legs, obedient, kneeling, arms up, paw pose`

**氛围链**：`collar on → leash attached → on all fours → crawling → eating from bowl → obedient → tail wag → public display`

**使用提示**：宠物调教核心是「人格剥夺+动物化」——tag应强调非人行为（crawling/eating from bowl）和服从道具（collar/leash/tail plug）。与RBQ的区别：宠物调教有「主人-宠物」的关系纽带，RBQ是彻底弃用的肉块。

**法典验证场景**：
- 犬化训练：`puppy play, collar, leash, crawling, on all fours, tail plug, panting, tongue out, nude, obedient`
- 笼中宠物：`cage, locked, collar, tail plug, on all fours, waiting, obedient, empty eyes`

---

### 14.7 胁迫

**核心公式**：`权力来源 × 胁迫手段 × 屈服程度`

**跨槽位标签链**：

| 胁迫类型 | 核心标签 |
|---|---|
| 职权胁迫 | `boss, office lady, blackmail, power imbalance, economic dependence` |
| 债务胁迫 | `debt, loan shark, forced prostitution, can't pay back` |
| 把柄威胁 | `secret, blackmail, hidden camera, being watched, recording` |
| 暴力强制 | `rape, held down, restrained, struggling, crying, knife, gun` |
| 药物迷奸 | `drugged, unconscious, spiked drink, limp body` |
| 集体胁迫 | `gang rape, multiple boys, surrounded, no escape, group blackmail` |

**关键变体**：
- 职权胁迫：`boss, office lady, blackmail, promotion, economic dependence, desk, office, reluctant`
- 把柄威胁：`hidden camera, on recording, blackmail, secret, scared, can't refuse`
- 暴力强制：`held down, restrained, knife, gun, scared, crying, struggling, rape`
- 药物迷奸：`drugged, unconscious, limp body, spiked drink, no resistance, expressionless`
- 持续控制：`ongoing, always available, mind break, given up, 24/7, slave`

**氛围链**：`threat → scared → reluctant → forced → struggling → crying → given up → mind break → obedient`

**使用提示**：胁迫核心是「权力的不对等」——不是单纯的暴力（那是过激），而是利用弱点/秘密/地位让对方无法拒绝。把柄威胁（hidden camera/blackmail/recording）是胁迫最独特的标签组合，过激和强奸没有这些要素。

**法典验证场景**：
- 职权胁迫：`boss, office lady, blackmail, desk, pencil skirt, reluctant, tears, scared, hand covering own mouth`
- 把柄威胁：`hidden camera, on recording, blackmail, scared, can't refuse, school uniform, crying`

---

### 14.8 偷窥/展示

**核心公式**：`看的人 × 被看的人 × 观看渠道`

**跨槽位标签链**：

| 槽位 | 核心标签 |
|---|---|
| camera | `peeping, through window, from outside, hidden camera, fake screenshot, viewfinder` |
| 被看方状态 | `unaware, sleeping, showering, changing clothes, masturbating, having sex` |
| 展示方状态 | `exhibitionism, looking at viewer, presenting, selfie, webcam, streaming` |
| scene | `window, door gap, keyhole, hidden camera pov, mirror, computer screen` |

**关键变体**：
- 窗外偷窥：`from outside, through window, peeping, voyeurism, couple inside having sex, unaware`
- 门缝发现：`opening door, walk-in, caught, surprised, !, accidental witness`
- 偷拍摄像头：`hidden camera, on recording, fake screenshot, pov, viewfinder, battery indicator`
- 自拍展示：`selfie, mirror, holding phone, exhibitionism, presenting, looking at viewer`
- 直播：`webcam, streaming, chat visible, donation alert, public, audience`
- 暗处窥视：`peeping, hiding, from behind, shadow, silhouette, keyhole`

**氛围链**：`watching → hidden → unaware → peeping → discovered → caught → ! → embarrassed`

**使用提示**：偷窥和展示是同一个硬币的两面——前者是「不被发现的看」，后者是「故意给人看」。偷窥配 hidden camera/fake screenshot 制造真实感；展示配 selfie/mirror/webcam/streaming 制造自媒体感。

**法典验证场景**：
- 窗外偷窥：`from outside, through window, peeping, voyeurism, couple having sex inside, unaware, night, city lights`
- 自拍展示：`selfie, mirror, holding phone, exhibitionism, presenting, spread legs, looking at viewer, bedroom`

---

### 14.9 事后

**核心公式**：`结束后的状态 × 残留痕迹 × 情感余韵`

**跨槽位标签链**：

| 槽位 | 核心标签 |
|---|---|
| pose/action | `after sex, lying on bed, exhausted, cuddling, spooning, heavy breathing` |
| expression | `afterglow, satisfied, peaceful, tired, asleep, empty eyes, ashamed, regret` |
| liquid/residue | `cum inside, cumdrip, cum on body, cum on sheets, cum pool, used condom` |
| clothing | `disheveled clothes, messy hair, unworn clothes, partially undressed` |
| scene | `crumpled sheets, used tissue, condom wrapper, wine glass, cigarette, morning light` |

**关键变体**：
- 床上瘫软：`after sex, lying on bed, exhausted, cum on body, heavy breathing, messy hair, afterglow`
- 浴室清洗：`shower, after sex, washing each other, wet, steam, tender, soap`
- 拥抱入睡：`cuddling, sleeping, spooning, holding each other, peaceful, closed eyes`
- 穿衣离开：`getting dressed, leaving, hurry, hotel, morning, awkward, one night stand`
- 再次插入：`another round, insertion, exhausted but willing, greedy, cum string`
- 事后羞耻：`ashamed, covering face, regret, tissue, used condom, pregnancy test`
- 事后检查：`checking, pregnancy test, morning after pill, anxious, used condom`

**氛围链**：`heavy breathing → afterglow → exhausted → satisfied → cuddling → peaceful → asleep / regret`

**使用提示**：事后核心是「过程结束后的余韵」——分两种方向：温存（cuddling/tender/afterglow）和空虚（regret/ashamed/used condom）。事后场景是少数可以合法写大量 cum 残留但不需要写性行为的场景。

**法典验证场景**：
- 床上瘫软：`after sex, lying on bed, exhausted, cum on body, cum on sheets, heavy breathing, messy hair, afterglow, crumpled sheets, used condom`
- 事后羞耻：`ashamed, covering face, regret, sitting on bed, used condom on floor, messy hair, tissue, morning light`

---

### 14.10 另类日常

**核心公式**：`日常场景 + 色情改造 + 自然态度 = 另类日常`

**关键变体**：
- 裸体家务：`nude, housework, cooking, cleaning, casual nudity, comfortable, natural state`
- 隐蔽玩具外出：`egg vibrator, remote controlled, inserted, public, trying to focus, secret`
- 肛塞日常：`butt plug, tail plug, daily routine, secret, under clothes`
- 情趣内衣通勤：`lingerie under clothes, secret, office lady, nobody knows`
- 裸体围裙做饭：`naked apron, bottomless, cooking, kitchen, casual, natural`
- 假装睡着诱惑：`pretending to sleep, closed eyes, provocative pose, teasing, waiting`
- 精液美容：`cum on face, facial mask, casual, morning routine`
- 游戏中被骑乘：`playing games, holding controller, implied sex, girl on top, expressionless`

**氛围链**：`daily routine → casual → secret → normal on surface → erotic underneath → nobody knows`

**使用提示**：另类日常核心是「将色情正常化」——女方表情要 natural/casual/expressionless，不要用任何兴奋/羞耻/高潮标签。日常场景道具（cooking pot/washing machine/laptop/game controller）反而是这类场景的关键锚点。与暴露露出的区别——另类日常不追求「被发现」的刺激，追求「这就是日常」的理所当然感。

**法典验证场景**：
- 裸体围裙做饭：`naked apron, bottomless, cooking, kitchen, casual, holding cooking pot, looking back, natural, morning`
- 游戏中被骑乘：`playing games, holding controller, implied sex, girl on top, expressionless, couch, casual`

---

### 14.11 大车小孩

**核心公式**：`体型反差 × 年龄差 × 主导方`

**跨槽位标签链**：

| 槽位 | 核心标签 |
|---|---|
| count/gender | `1girl, 1boy, onee-shota, shota, hetero` |
| appearance | 女方：`mature female, large breasts, tall, curvy` / 男方：`shota, petite male, small penis` |
| body diff | `height difference, size difference, large breasts small penis` |
| pose/action | `girl on top, cowgirl position` / `mating press, boy on top` / `breastfeeding, lactation` |
| expression | 女方：`motherly, gentle, teaching` / 男方：`blush, nervous, first time` |

**关键变体**：
- 正太主动后入：`shota, sex from behind, onee-shota, small penis, boy on top`
- 大姐姐骑乘：`onee-shota, girl on top, cowgirl position, mature female, shota, teaching`
- 母性授乳：`breastfeeding, onee-shota, lactation, large breasts, motherly figure`
- 体格碾压：`size difference, height difference, large breasts, petite male, lifting, huge size difference`
- 多对一服务：`multiple girls, 1boy, shota, group sex, harem, mature female`

**氛围链**：`shy → nervous → first time → teaching → guided → gentle → passionate`

**使用提示**：大车小孩核心是「体型×年龄的双重反差」——视觉上 maximal size difference（large breasts + small penis），心理上经验差（mature female teaching + shota first time）。与常规体型的区别——必须有 onee-shota 或明确的 age difference + size difference 标签。

**法典验证场景**：
- 大姐姐骑乘：`onee-shota, girl on top, cowgirl position, mature female, large breasts, shota, small penis, teaching, height difference`
- 正太后入大姐姐：`shota, onee-shota, sex from behind, petite male, mature female, large breasts, size difference, age difference`

---

### 14.12 隐奸

**核心公式**：`可见部分 + 遮挡手法 + 暗示线索 = 观众脑补完整画面`

> ⚠️ 隐奸对标签精度要求极高——构图类标签用错一个，就从「隐」变成「露」，完全垮掉。

**跨槽位标签链**（按遮挡手法分5大类）：

| 遮挡手法 | 核心标签 | 效果 |
|---|---|---|
| 画面外裁剪 | `head out of frame` / `upper body out of frame` / `lower body only` / `feet only` / `ass only` / `out-of-frame censoring` | 只展示身体的局部——腿悬空、脚趾蜷曲、体液滴落，观众看不到脸和整体 |
| 上下分裂 | `upper body normal, lower body exposed` / `upper body normal, under desk` / `table, upper body normal` | 画面上半=正常日常（聊天/吃饭/工作），画面下半或桌下=交配中 |
| 介质遮挡 | `against glass, frosted glass` / `under covers` / `through window, from outside` / `in locker` / `in cubicle` / `shower curtain` | 透过磨砂/被子/布帘的模糊轮廓和动作剪影 |
| 伪媒介视角 | `fake screenshot` / `viewfinder, recording` / `cellphone photo` / `speech bubble` / `implied sex` | 伪聊天截图/偷拍画面——只显示局部+UI元素暗示这是私密记录 |
| 暗示性构图 | `view between legs` / `through legs` / `lower body, head out of frame` / `implied fellatio` / `implied after sex` | 不画性器不画插入，靠体位角度和相邻身体部位暗示正在发生 |

**关键变体**：

- 桌子上下分裂（最经典隐奸）：`upper body normal, smile, talking, restaurant / under table, no panties, sex from behind, pussy juice, legs trembling, lower body` — 上半身正常用餐社交，下半身在交配
- 悬空腿脚特写：`head out of frame, lifting person, hanging legs, feet, toes, toe scrunch, trembling, pussy juice trail, lower body only, sex from behind` — 只展示被抱起的腿和脚，观众从蜷曲的脚趾和体液推断
- 磨砂玻璃后：`against glass, frosted glass, standing sex, breast press, stealth sex, from outside, night, apartment, x-ray` — 透过磨砂玻璃的模糊轮廓+蒸汽+动作线
- 被子下鼓起：`under covers, girl on top, cowgirl position, dark, at night, implied sex, nude, motion lines, steam from under covers` — 被子隆起+有节奏的动线+露出的表情
- 伪手机截图：`fake phone screenshot, speech bubble, viewfinder, upper body, collarbone, teeth, open mouth, tongue out, implied sex, stomach bulge` — 聊天框+局部身体+暗示文字
- 桌下足交暗示：`under table, footjob, two-footed footjob, feet, toes, soles, no shoes, erection under clothes, bulge, restaurant, pov across table, upper body normal, smile` — 上半身正常聊天，桌面视角，桌下脚在动
- 垃圾桶下半身：`lower body only, upper body in trash can, pussy, cum in pussy, used condom on ass, sweat, in alley, darkness` — 只有下半身露在外面，上半身在垃圾桶里
- 游戏坐位隐奸：`playing games, holding controller, sitting on lap, stealth sex, implied sex, expressionless, upper body normal, speech bubble, cum string` — 上面在打游戏，下面在做

**氛围链**：`normal on surface → hidden underneath → trembling → pussy juice visible → cum drip → heavy breathing but silent → discovered? → !`

**使用规则（极重要）**：

1. **「隐」的关键在裁剪**：`head out of frame` 或 `lower body only` 是最强隐奸工具——不画脸就永远有「谁也不知道」的想象空间
2. **上下分裂最忌画错**：上正常+下交配时，必须保证上半身没有任何性暗示标签（不要 blush/heavy breathing），否则「正常」崩塌
3. **介质遮挡不能太透**：`frosted glass` 比 `glass` 更「隐」；`under covers` 必须配 `dark` 或 `at night`，否则被子下轮廓太清晰
4. **暗示靠液体**：`pussy juice trail` / `cum drip` / `cum string` 是隐奸场景最强的「证据」标签——不画性器，体液暗示一切
5. **隐奸不是偷窥**：偷窥是「有人藏在暗处看」，隐奸是「观众自己也看不全」。不要加 `peeping` / `voyeurism` / `hidden camera`

**法典验证场景**：
- 桌下隐奸：`upper body normal, smile, drinking, restaurant, table / under table, no panties, sex from behind, pussy juice trail, legs trembling, head out of frame, lower body`
- 腿上游戏隐奸：`playing games, holding controller, sitting on lap, stealth sex, implied sex, expressionless, on couch, upper body normal, speech bubble, cum string, from side`
- 磨砂玻璃隐奸：`against glass, frosted glass, standing sex, breast press, stealth sex, from outside, night, apartment window, x-ray, motion lines, steam`

---

## 15. EXAMPLES

> ⚠️ **占位**：本章将在模板全部定稿后，填充跑图验证过的完整案例。格式为：中文场景描述 + 完整英文 prompt + 简短推理注释。每案例覆盖不同场景类型（单人诱惑/双人正戏/多人/前戏/特殊主题），确保 AI 和人类读者都能从案例中理解本章模板在实际使用中的标签选择逻辑。