// 视频抽帧（本机 ffmpeg）—— skills/ 下的 LLM 型技能。
//
// 为什么做成技能，而不是插件：
//   · 不是每条消息都值得抽帧。抽一次要起 ffmpeg、还要为几张图付几千 token，
//     "这条视频要不要看、看几帧"该由模型按上下文判断 —— 这正是 LLM 型
//     （注册工具进 function 列表）的定位。
//   · 插件（plugins/）是"满足条件就一定执行"的确定性能力，放这里会被每条
//     视频都触发，既慢又贵。判定依据见 src/skills/manifest.js 的 DIR_KIND。
//
// 和内置 read_video / frame-detective 的分工：
//   内置链路走 `video.frames` 能力，而那个能力只在 PATH 里找 ffmpeg；
//   本机 ffmpeg 装在 D:\下载\... 这种非 PATH 目录时，内置链路会安静地降级成
//   "只给时长/分辨率"。本技能把 ffmpeg 路径写进设置、自己抽帧，把图片作为
//   工具结果直接交给模型看。
//
// 实现上必须遵守的几条（不这么做会静默失效）：
//   1. 工具结果里的图必须走 parts：{ content: [{type:'text'}, {type:'image_url'}] }。
//      把 base64 拼进文本，模型看不到图还要为几十万 token 付费。
//   2. 工具 id 会被加上 "<skillId>__" 前缀并成为 OpenAI function name，
//      只允许 [a-zA-Z0-9_-]，所以这里用 id: 'frames'（实际名字 ffmpeg-frames__frames）。
//   3. Windows 路径一律交给 spawn 的数组参数，不拼命令行字符串（空格、中文目录都安全）。

import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { spawn } from 'node:child_process';
import { fileURLToPath, pathToFileURL } from 'node:url';

// 必须用"模块自身位置"反推项目根：安装版的入口在 <install>/resources/app/skills/<id>/，
// 用 process.cwd() 会指到启动目录，动态 import 直接失败。
const APP_ROOT = globalThis.__qqAgentRoot
  || path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../..');
const IS_WIN = process.platform === 'win32';
const ERR_TEXT_MAX = 300;

let cfg = () => ({});
let log = () => {};

function num(value, fallback) {
  const n = Number(value);
  return Number.isFinite(n) ? n : fallback;
}

function clampInt(value, min, max, fallback) {
  const n = Math.round(num(value, NaN));
  if (!Number.isFinite(n)) return fallback;
  return Math.max(min, Math.min(max, n));
}

function fail(text) {
  return { content: String(text), isError: true };
}

/** 把子进程 stderr 收敛成一句人话，别把几百行日志塞给模型。 */
function tail(text) {
  return String(text || '')
    .split(/\r?\n/)
    .map((s) => s.trim())
    .filter(Boolean)
    .slice(-3)
    .join(' ｜ ')
    .slice(0, ERR_TEXT_MAX);
}

/** 跑外部命令：带超时、收集 stdout/stderr、绝不因为 spawn 失败而抛。 */
function run(cmd, args, { timeoutMs = 30000, maxOutput = 400000 } = {}) {
  return new Promise((resolve) => {
    let stdout = '';
    let stderr = '';
    let timer = null;
    let settled = false;
    const finish = (result) => {
      if (settled) return;
      settled = true;
      if (timer) clearTimeout(timer);
      resolve(result);
    };

    let child;
    try {
      child = spawn(cmd, args, { windowsHide: true, stdio: ['ignore', 'pipe', 'pipe'] });
    } catch (error) {
      return finish({ ok: false, code: -1, stdout: '', stderr: String(error?.message || error), spawnError: true });
    }

    child.stdout.on('data', (d) => { if (stdout.length < maxOutput) stdout += d; });
    child.stderr.on('data', (d) => { if (stderr.length < maxOutput) stderr += d; });

    timer = setTimeout(() => {
      try { child.kill(); } catch { /* ignore */ }
      finish({
        ok: false,
        code: -1,
        stdout,
        stderr: `${stderr}\n（超过 ${Math.round(timeoutMs / 1000)} 秒没跑完，已终止）`
      });
    }, Math.max(1000, timeoutMs));

    child.on('error', (error) => finish({
      ok: false, code: -1, stdout, stderr: String(error?.message || error), spawnError: true
    }));
    child.on('close', (code) => finish({ ok: code === 0, code, stdout, stderr }));
  });
}

/** 设置里的 ffmpeg；路径写错/文件不在了就退回 PATH（并在日志里说一声）。 */
function ffmpegOf(settings) {
  const configured = String(settings.ffmpegPath || '').trim();
  if (configured && fs.existsSync(configured)) return configured;
  if (configured) log(`设置的 ffmpeg 路径不存在，回退到 PATH 查找：${configured}`);
  return IS_WIN ? 'ffmpeg.exe' : 'ffmpeg';
}

/** ffprobe 默认找 ffmpeg 同目录的兄弟文件；找不到再试 PATH。 */
function ffprobeOf(settings, ffmpeg) {
  const configured = String(settings.ffprobePath || '').trim();
  if (configured && fs.existsSync(configured)) return configured;
  if (path.isAbsolute(ffmpeg)) {
    const sibling = path.join(path.dirname(ffmpeg), IS_WIN ? 'ffprobe.exe' : 'ffprobe');
    if (fs.existsSync(sibling)) return sibling;
  }
  return IS_WIN ? 'ffprobe.exe' : 'ffprobe';
}

async function probeWithFfprobe(ffprobe, file, timeoutMs) {
  const r = await run(ffprobe, [
    '-v', 'quiet', '-print_format', 'json', '-show_format', '-show_streams', file
  ], { timeoutMs });
  if (!r.ok) return { durationSec: 0, width: 0, height: 0 };
  try {
    const data = JSON.parse(r.stdout);
    const video = (Array.isArray(data.streams) ? data.streams : [])
      .find((s) => s && s.codec_type === 'video') || {};
    const duration = Number(data.format?.duration);
    return {
      durationSec: Number.isFinite(duration) && duration > 0 ? duration : 0,
      width: Number(video.width) || 0,
      height: Number(video.height) || 0
    };
  } catch {
    return { durationSec: 0, width: 0, height: 0 };
  }
}

/** 没有 ffprobe 时，从 `ffmpeg -i` 的 stderr 里抠 Duration。 */
async function probeDurationByFfmpeg(ffmpeg, file, timeoutMs) {
  const r = await run(ffmpeg, ['-hide_banner', '-i', file], { timeoutMs });
  const m = /Duration:\s*(\d+):(\d+):(\d+(?:\.\d+)?)/.exec(r.stderr || '');
  if (!m) return 0;
  return Number(m[1]) * 3600 + Number(m[2]) * 60 + Number(m[3]);
}

/**
 * 下载视频到临时文件。
 * 优先复用应用的 safe-fetch（带 SSRF 白名单 + 流式落盘 + 大小上限），
 * 它不在时退回原生 fetch —— 两条路都不把整个视频读成巨型字符串。
 */
async function downloadTo(url, dest, { maxBytes, timeoutMs }) {
  try {
    const mod = await import(pathToFileURL(path.join(APP_ROOT, 'src/safe-fetch.js')).href);
    if (typeof mod.safeFetchBinaryToFile === 'function') {
      await mod.safeFetchBinaryToFile(String(url), dest, maxBytes, { timeoutMs });
      if (fs.existsSync(dest) && fs.statSync(dest).size > 0) return dest;
    }
  } catch (error) {
    log(`safe-fetch 没走通，改用原生 fetch：${error?.message || error}`);
  }

  const res = await fetch(String(url), { signal: AbortSignal.timeout(timeoutMs) });
  if (!res.ok) throw new Error(`下载视频失败：HTTP ${res.status}`);
  const buf = Buffer.from(await res.arrayBuffer());
  if (!buf.length) throw new Error('下载到的视频是空的');
  if (buf.length > maxBytes) throw new Error(`视频超过 ${Math.round(maxBytes / 1048576)}MB 上限`);
  fs.writeFileSync(dest, buf);
  return dest;
}

/** 视频落地成本地文件：消息里给的 path → OneBot 缓存 → 链接下载。 */
async function localize(ctx, media, { tmpDir, maxBytes, timeoutMs }) {
  const direct = String(media?.path || '');
  if (direct && fs.existsSync(direct)) return direct;

  if (media?.file && ctx?.onebot?.call) {
    for (const action of ['get_video', 'get_file']) {
      try {
        const ret = await ctx.onebot.call(action, { file: String(media.file) }, Math.min(timeoutMs, 20000));
        const local = ret?.file && fs.existsSync(String(ret.file)) ? String(ret.file) : '';
        if (local) return local;
        if (ret?.url) {
          const dest = path.join(tmpDir, `src_${Date.now().toString(36)}.mp4`);
          return await downloadTo(ret.url, dest, { maxBytes, timeoutMs });
        }
      } catch { /* 换下一个 action 试 */ }
    }
  }

  if (media?.url) {
    const dest = path.join(tmpDir, `src_${Date.now().toString(36)}.mp4`);
    return await downloadTo(media.url, dest, { maxBytes, timeoutMs });
  }

  throw new Error('拿不到视频文件（QQ 缓存里没有，链接也下载失败）');
}

/** 抽一张图。返回到底成没成，顺便带回失败原因。 */
async function grabFrame(ffmpeg, source, atSec, outPath, { maxWidth, quality, timeoutMs }) {
  // 最长边封顶 + 偶数尺寸：竖屏视频不会变成细长条，yuv420p/mjpeg 也吃偶数。
  const scale = `scale='min(${maxWidth},iw)':'min(${maxWidth},ih)':force_original_aspect_ratio=decrease:force_divisible_by=2`;
  const args = ['-hide_banner', '-loglevel', 'error', '-nostdin', '-y'];
  if (atSec > 0) args.push('-ss', atSec.toFixed(3));   // 放在 -i 前是快速定位，不用解码整段
  args.push(
    '-i', source,
    '-frames:v', '1',
    '-vf', scale,
    '-q:v', String(quality),
    '-an', '-sn',
    outPath
  );
  const r = await run(ffmpeg, args, { timeoutMs });
  const ok = r.ok && fs.existsSync(outPath) && fs.statSync(outPath).size > 0;
  return { ok, error: ok ? '' : tail(r.stderr) };
}

/** 时长决定张数：约每 3 秒一张，最少 4 张、最多 12 张；读不到时长就给 6 张。 */
function autoCount(durationSec) {
  const d = Number(durationSec) || 0;
  if (!(d > 0)) return 6;
  return Math.max(4, Math.min(12, Math.round(d / 3) + 1));
}

/** 每张截图取在各自时间片的正中间，开头结尾各留一点余量（避免黑帧）。 */
function planTimes(durationSec, count) {
  const out = [];
  const duration = Number(durationSec) || 0;
  if (duration > 0) {
    const step = duration / count;
    for (let i = 0; i < count; i++) {
      const t = Math.min(Math.max(step * (i + 0.5), 0), Math.max(0, duration - 0.12));
      out.push(Number(t.toFixed(2)));
    }
  } else {
    // 时长读不到：每 2 秒取一张，抽到视频结束为止；抽不满就少给几张。
    for (let i = 0; i < count; i++) out.push(i * 2);
  }
  return out;
}

async function runHandle(ctx, args) {
  const startedAt = Date.now();
  const settings = cfg() || {};
  const a = args && typeof args === 'object' ? args : {};

  const maxWidth = clampInt(a.maxWidth, 160, 1600, clampInt(settings.maxWidth, 160, 1600, 768));
  const quality = clampInt(settings.quality, 2, 31, 4);
  const budgetMs = clampInt(settings.timeoutMs, 5000, 300000, 90000);
  const maxBytes = clampInt(settings.maxFileMB, 10, 2048, 300) * 1024 * 1024;
  const maxDurationSec = clampInt(settings.maxDurationSec, 5, 7200, 600);
  const deadline = startedAt + budgetMs;
  const remaining = () => Math.max(1500, deadline - Date.now());

  const messageId = String(a.messageId ?? '').trim().replace(/^#+/, '');
  const customPath = String(a.filePath ?? '').trim();

  if (!messageId && !customPath) {
    return fail('要指定一条带视频的消息：把聊天记录里那条消息的 #编号 填进 messageId（只填数字，不要 #）。');
  }

  // 先按消息编号找到视频媒体段（和内置 read_video 同一套数据）
  let media = null;
  if (messageId) {
    if (typeof ctx?.store?.findByMid !== 'function') {
      return fail('当前会话读不到消息记录，没法按消息编号找视频。');
    }
    const entry = ctx.store.findByMid(ctx.chatKey, messageId);
    if (!entry) return fail(`当前会话里找不到消息 #${messageId}，确认编号没写错（只要数字）。`);
    media = (Array.isArray(entry.media) ? entry.media : []).find((m) => m && m.kind === 'video') || null;
    if (!media) return fail(`消息 #${messageId} 里没有视频（可能是文字、图片或文件）。`);
  }

  const tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), 'qqa-frames-'));
  let frameError = '';
  try {
    const ffmpeg = ffmpegOf(settings);
    const ffprobe = ffprobeOf(settings, ffmpeg);

    // 先真跑一次 -version：路径写错时给出明确原因，而不是让人对着"抽帧失败"猜
    const ready = await run(ffmpeg, ['-version'], { timeoutMs: 8000 });
    if (!ready.ok) {
      return fail(`ffmpeg 起不来：${tail(ready.stderr) || '找不到可执行文件'}。`
        + `请到「技能 → 视频抽帧」检查 ffmpeg 路径（现在填的是：${settings.ffmpegPath || '空'}）。`);
    }

    let source = '';
    if (customPath) {
      if (!fs.existsSync(customPath)) return fail(`本机没有这个文件：${customPath}`);
      source = customPath;
    } else {
      try {
        source = await localize(ctx, media, {
          tmpDir, maxBytes, timeoutMs: Math.min(remaining(), 30000)
        });
      } catch (error) {
        return fail(`拿不到视频文件：${error?.message || error}`);
      }
    }

    let size = 0;
    try { size = fs.statSync(source).size; } catch { /* ignore */ }
    if (!size) return fail('视频文件是空的（0 字节）。');
    if (size > maxBytes) {
      return fail(`视频 ${(size / 1048576).toFixed(1)}MB，超过单文件上限 ${Math.round(maxBytes / 1048576)}MB。`
        + '可以在「技能 → 视频抽帧」里调大「视频大小上限」。');
    }

    const meta = await probeWithFfprobe(ffprobe, source, Math.min(remaining(), 20000));
    if (!meta.durationSec) {
      meta.durationSec = await probeDurationByFfmpeg(ffmpeg, source, Math.min(remaining(), 20000));
    }
    if (meta.durationSec > maxDurationSec) {
      return fail(`视频 ${(meta.durationSec / 60).toFixed(1)} 分钟，超过 ${Math.round(maxDurationSec / 60)} 分钟上限`
        + '（抽帧会又慢又贵）。想支持更长的视频，去「技能 → 视频抽帧」调大「视频时长上限」。');
    }

    const explicit = clampInt(a.frames, 0, 12, 0);
    const preset = clampInt(settings.count, 0, 12, 0);
    const count = Math.max(1, Math.min(12,
      explicit > 0 ? explicit : (preset > 0 ? preset : autoCount(meta.durationSec))));

    const times = planTimes(meta.durationSec, count);
    const frames = [];
    const used = [];
    const failed = [];

    for (let i = 0; i < times.length; i++) {
      if (Date.now() >= deadline) { failed.push('时间用完'); break; }
      const outPath = path.join(tmpDir, `f_${String(i).padStart(2, '0')}.jpg`);
      const got = await grabFrame(ffmpeg, source, times[i], outPath, {
        maxWidth, quality, timeoutMs: Math.min(remaining(), 25000)
      });
      if (!got.ok) {
        failed.push(`${times[i]}s`);
        frameError = got.error || frameError;
        continue;
      }
      try {
        const buf = fs.readFileSync(outPath);
        if (!buf.length) { failed.push(`${times[i]}s`); continue; }
        frames.push(`data:image/jpeg;base64,${buf.toString('base64')}`);
        used.push(times[i]);
      } catch (error) {
        failed.push(`${times[i]}s`);
        frameError = String(error?.message || error);
      }
    }

    if (!frames.length) {
      return fail(`ffmpeg 一张都没抽出来${failed.length ? `（${failed.slice(0, 3).join('、')} 失败）` : ''}。`
        + (frameError ? `最后的错误：${frameError}` : '可能编码不受支持或文件损坏。'));
    }

    const bits = [];
    if (meta.durationSec > 0) bits.push(`${meta.durationSec.toFixed(1)} 秒`);
    if (meta.width && meta.height) bits.push(`${meta.width}×${meta.height}`);
    const text = `已从视频抽出 ${frames.length} 张画面（${bits.join('，') || '时长/分辨率读不到'}；`
      + `分别在 ${used.join('、')} 秒）。这是静态截图，不是连续视频：帧与帧之间的过程看不到，`
      + '描述时用「看起来」「某一帧里」，别编连续动作。'
      + (failed.length ? `\n还有 ${failed.length} 张没抽出来。` : '');

    log(`抽帧成功：${frames.length}/${count} 张，耗时 ${((Date.now() - startedAt) / 1000).toFixed(1)}s，`
      + `来源 ${path.basename(source)}`);

    // 关键：文本走 parts[0]，图片逐张作为 image_url 紧随其后 ——
    // 编排层会把它们作为一条 user 消息补发给模型（见 orchestrator.js 的 media 处理）。
    return {
      content: [
        { type: 'text', text },
        ...frames.map((url) => ({ type: 'image_url', image_url: { url } }))
      ]
    };
  } catch (error) {
    return fail(`抽帧失败：${error?.message || error}`);
  } finally {
    try { fs.rmSync(tmpDir, { recursive: true, force: true }); } catch { /* 临时文件清不掉不影响结果 */ }
  }
}

export function setup(api) {
  cfg = typeof api.config === 'function' ? api.config : () => ({});
  log = typeof api.log === 'function' ? api.log : () => {};

  api.registerTool({
    id: 'frames',
    name: '视频抽帧',
    description: '把一条视频按时间均匀抽成几张静态图，直接作为图片交给视觉模型看。'
      + '群友发来视频、聊天记录里出现 [视频]，或用户说「截几帧 / 抽几张图看看」时用它。'
      + '返回的是截图，不是连续视频。messageId 填聊天记录里那条消息的 #编号（只填数字）。',
    category: 'media',
    icon: '🎞️',
    requiresVision: true,
    parameters: {
      type: 'object',
      properties: {
        messageId: {
          type: ['integer', 'string'],
          description: '带视频的那条消息的 QQ 消息 id（聊天记录里每条消息前的 #数字，只填数字）'
        },
        frames: {
          type: ['integer', 'string'],
          description: '可选：抽几张（1~12）。不填就按视频时长自动定：约每 3 秒一张，最少 4 张、最多 12 张'
        },
        maxWidth: {
          type: ['integer', 'string'],
          description: '可选：每张图最长边的像素上限，默认 768。越小越省 token，但太小的图看不清细节'
        },
        filePath: {
          type: 'string',
          description: '可选：本机视频文件路径（调试用；有消息编号时优先用 messageId）'
        }
      },
      required: []
    },
    execute: runHandle
  });
}
