// 萌娘百科查资料（LLM 型技能）。
//
// 为什么是技能而不是插件：
//   "这句话是不是在聊二次元""问的是哪个角色""该用什么关键词搜"全是自然语言判断，
//   规则写不死。所以这里只注册工具（模型自己决定什么时候调），不提供能力/钩子。
//
// 数据来源：手机版萌娘百科的 MediaWiki 开放接口（https://mobile.moegirl.org.cn/api.php）。
//   · 电脑版 zh.moegirl.org.cn 的 api.php 对未授权调用直接返回 action-notallowed，
//     而手机版可以正常用 —— 这是两处唯一可靠的区别，别随手换成电脑版。
//   · action=parse 会被站点 WAF 拦（返回 "fault filter abort"），所以正文走
//     action=query&prop=extracts（纯文本），信息框走 prop=revisions（wikitext）。
//   · 只做只读查询：搜索 + 读条目，不改任何东西、不需要登录。
//
// 一次 lookup 的最坏开销：3 个 GET（搜索 + 正文 + 信息框），默认 10 秒超时，
// 结果进本地缓存（默认 60 分钟），同一句里反复问同一个角色不会重复打站点。

const DEFAULT_SITE = 'https://mobile.moegirl.org.cn';
// UA 按 MediaWiki 的礼貌要求带上身份与来源；不带 UA 容易被站点风控当成爬虫。
// ⚠️ HTTP 头只能是 latin1（ByteString）：这里写中文会让 fetch 在发请求前就抛
//    "Cannot convert argument to a ByteString"，而且报错完全看不出是 UA 的问题。
const USER_AGENT = 'QQAgent-MoegirlSkill/1.0 (QQ group bot skill; +https://mobile.moegirl.org.cn)';
const CACHE_MAX = 80;
// 站点对 exchars 有硬上限：请求 12000 实际只回 1200 字（而且只给开头），
// 反而比不传更少 —— 所以这里不传 exchars，拿整篇纯文本，再自己按预算截。
// 超大条目（10 万字级）留个上限，避免白占内存和 CPU。
const MAX_EXTRACT_CHARS = 60000;

let httpFetch = null;
let cfgFn = () => ({});
let log = () => {};

const searchCache = new Map();
const pageCache = new Map();

class WikiError extends Error {
  constructor(message, kind = 'unknown') {
    super(message);
    this.name = 'WikiError';
    this.kind = kind;
  }
}

export function setup(api) {
  // 只有清单里声明了 permissions: ["web_fetch"]，这里拿到的才是真 fetch；
  // 否则 loader 给的是一个"一调用就 reject"的桩函数 —— 把错误转成人话见 fail()。
  httpFetch = typeof api.fetch === 'function' ? (...args) => api.fetch(...args) : null;
  cfgFn = typeof api.config === 'function' ? api.config : () => ({});
  log = typeof api.log === 'function' ? api.log : () => {};

  api.registerTool({
    id: 'moegirl_search',
    name: '萌娘百科搜索',
    description: '在萌娘百科（专门收 ACGN 的维基百科）里搜条目，只返回候选标题和一句话摘要，不返回正文。适合：不确定条目的准确全名、怕重名（比如「葛叶」是消歧义页）、或者想先确认有没有这个条目。确认标题后再用 moegirl_lookup 读内容。',
    category: 'knowledge',
    icon: '📖',
    parameters: {
      type: 'object',
      properties: {
        query: {
          type: 'string',
          description: '搜索词：角色名 / 作品名 / 声优名 / 梗，越接近条目的正式名字越准'
        },
        limit: {
          type: 'number',
          description: '返回几条候选，1~8，默认用技能设置里的值'
        }
      },
      required: ['query']
    },
    async execute(_ctx, args) {
      const c = readConfig();
      const query = String(args?.query ?? '').trim();
      if (!query) return { content: '缺少 query：要搜什么？', isError: true };
      const limit = clampInt(args?.limit, 1, 8, c.searchLimit);
      try {
        let hits = await searchWiki(query, limit, c);
        let used = query;
        if (!hits.length) {
          const alt = simplifyQuery(query);
          if (alt) {
            hits = await searchWiki(alt, limit, c);
            used = hits.length ? alt : query;
          }
        }
        if (!hits.length) {
          return {
            content: `萌娘百科上没搜到「${query}」。换个更短、更正式的名字再试（只留作品名或角色全名）；也可能是这个词条真的没有。`,
            isError: true
          };
        }
        const lines = hits.map((h, i) => `${i + 1}. ${h.title}${h.snippet ? ` — ${h.snippet}` : ''}`);
        return {
          content: `「${used}」的搜索结果（萌娘百科，${hits.length} 条）：\n${lines.join('\n')}\n\n确认是哪个之后，用 moegirl_lookup(title="条目名") 读正文；都不像就换个词再搜。`
        };
      } catch (error) {
        return fail('搜索', error);
      }
    }
  });

  api.registerTool({
    id: 'moegirl_lookup',
    name: '萌娘百科查条目',
    description: '查萌娘百科条目：自动搜索并取回最相关条目的资料卡（生日 / 身高 / 声优 / 所属 / 登场作品等）和正文节选，已按问题挑出相关段落。遇到二次元相关的问题、冷门设定、具体数值、梗的出处时，用它核对事实再回答。传 title 直接读指定条目；只传 query 会先搜索再取最像的那条。',
    category: 'knowledge',
    icon: '🔎',
    parameters: {
      type: 'object',
      properties: {
        query: {
          type: 'string',
          description: '要查什么：条目名，或者一句人话（如「初音未来的生日」），会先搜索'
        },
        title: {
          type: 'string',
          description: '已知的确切条目名（可选）。给了就直接读它，不再搜索'
        },
        maxChars: {
          type: 'number',
          description: '这次最多取多少字正文，300~6000，默认用技能设置里的值'
        }
      }
    },
    async execute(_ctx, args) {
      const c = readConfig();
      let query = String(args?.query ?? '').trim();
      let title = String(args?.title ?? '').trim();
      const explicitTitle = title;
      if (!query && !title) return { content: '缺少 query / title：要查哪个条目？', isError: true };
      const budget = clampInt(args?.maxChars, 300, 6000, c.maxChars);
      try {
        let hits = [];
        let basis = query;
        if (!title) {
          const resolved = await resolveTitle(query, c);
          if (!resolved) {
            return {
              content: `萌娘百科上没搜到「${query}」，暂时没资料可讲。可以换个正式的名字再查一次（角色全名 / 作品名+角色名）；还是不行就按你自己知道的谨慎回答，别编。`,
              isError: true
            };
          }
          title = resolved.title;
          hits = resolved.hits;
          basis = resolved.basis || query;
        }

        let page = await readPage(title, c);
        // 直接给的 title 不一定对（简称、错字）：退回搜索结果里逐个试。
        if (!page && !hits.length) {
          hits = await searchWiki(query || title, c.searchLimit, c);
          if (!hits.length) {
            const alt = simplifyQuery(query || title);
            if (alt) hits = await searchWiki(alt, c.searchLimit, c);
          }
        }
        if (!page) {
          for (const hit of hits) {
            if (hit.title === title) continue;
            page = await readPage(hit.title, c);
            if (page) { title = hit.title; break; }
          }
        }
        if (!page) {
          return {
            content: `萌娘百科上没有「${title}」这个条目（或它没有可读正文）。换个名字再试，或者直说没查到。`,
            isError: true
          };
        }

        // 搜索对不上时别硬塞结果：拿"测试123456"这种不存在的词去搜，MediaWiki
        // 仍会返回一条"最相关"的无关条目（实测把原神角色当成结果），
        // 模型会当成事实讲出去 —— 宁可回"没查到"。
        if (!explicitTitle && !looksRelevant(basis, page)) {
          const close = hits.slice(0, 3).map((hit) => `《${hit.title}》`).join('、');
          return {
            content: `萌娘百科上没有和「${query || title}」对得上的条目${close ? `（搜索最接近的是${close}）` : ''}。换个正式的名字再查，或者直说没查到。`,
            isError: true
          };
        }

        return { content: renderPage(page, { query, budget, c, hits }) };
      } catch (error) {
        return fail('查条目', error);
      }
    }
  });
}

export function available() {
  return true;
}

// ── 配置 ────────────────────────────────────────────────────────────────────

function readConfig() {
  const raw = cfgFn() || {};
  const siteBase = String(raw.siteBase || DEFAULT_SITE).trim().replace(/\/+$/, '') || DEFAULT_SITE;
  return {
    siteBase,
    maxChars: clampInt(raw.maxChars, 400, 4000, 1600),
    maxFacts: clampInt(raw.maxFacts, 0, 30, 12),
    searchLimit: clampInt(raw.searchLimit, 1, 8, 5),
    cacheMinutes: clampInt(raw.cacheMinutes, 0, 1440, 60),
    timeoutMs: clampInt(raw.timeoutMs, 3000, 25000, 10000),
    includeFacts: raw.includeFacts !== false
  };
}

// ── 网络 ────────────────────────────────────────────────────────────────────

/**
 * 调一次 MediaWiki 接口。
 * 超时用 AbortController 而不是依赖平台默认值：站点偶尔会挂住几十秒，
 * 卡住的那一次会让整轮对话一起卡住（模型在等工具返回）。
 */
async function wikiJson(params, c) {
  try {
    return await wikiJsonOnce(params, c);
  } catch (error) {
    // 只重试"可能自己好"的失败；4xx / 接口报错重试也没用，直接抛给上层出人话提示。
    const retryable = error?.kind === 'timeout' || error?.kind === 'network' || error?.kind === 'waf';
    if (!retryable) throw error;
    log(`第一次请求失败（${error.message}），重试一次`);
    await sleep(450);
    return await wikiJsonOnce(params, c);
  }
}

async function wikiJsonOnce(params, c) {
  if (!httpFetch) throw new WikiError('没有网络请求能力（web_fetch）', 'no-fetch');

  const url = new URL('/api.php', c.siteBase);
  url.searchParams.set('format', 'json');
  for (const [key, value] of Object.entries(params)) {
    if (value === undefined || value === null || value === '') continue;
    url.searchParams.set(key, String(value));
  }

  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), c.timeoutMs);
  try {
    const res = await httpFetch(url.toString(), {
      method: 'GET',
      headers: {
        'User-Agent': USER_AGENT,
        Accept: 'application/json, text/plain;q=0.8',
        'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.5'
      },
      signal: controller.signal
    });
    const text = await res.text();
    if (!res.ok) throw new WikiError(`HTTP ${res.status}`, 'http');
    let data;
    try {
      data = JSON.parse(text);
    } catch {
      // 站点 WAF 有时会回 HTTP 200 + 一段纯文本（"fault filter abort"），
      // 不单独识别的话会变成 "Unexpected token" 这种没人看得懂的报错。
      throw new WikiError(text.slice(0, 120) || '返回内容不是 JSON', 'waf');
    }
    if (data?.error) throw new WikiError(String(data.error.info || data.error.code || '接口报错'), 'api');
    return data;
  } catch (error) {
    if (error instanceof WikiError) throw error;
    if (error?.name === 'AbortError') {
      throw new WikiError(`请求超时（${Math.round(c.timeoutMs / 1000)} 秒）`, 'timeout');
    }
    const msg = String(error?.message ?? error);
    // loader 在没声明 web_fetch 时塞的桩函数会抛 "…未声明 web_fetch 权限"
    if (/web_fetch/i.test(msg)) throw new WikiError(msg, 'no-fetch');
    throw new WikiError(`网络错误：${msg}`, 'network');
  } finally {
    clearTimeout(timer);
  }
}

async function searchWiki(query, limit, c) {
  const cacheKey = `s:${limit}:${query}`;
  const cached = cacheGet(searchCache, cacheKey, c.cacheMinutes);
  if (cached) return cached;

  const data = await wikiJson({
    action: 'query',
    list: 'search',
    srsearch: query,
    srlimit: limit,
    srnamespace: 0,
    srprop: 'snippet|wordcount'
  }, c);

  const hits = (data?.query?.search || [])
    .map((item) => ({
      title: String(item?.title || '').trim(),
      snippet: truncate(cleanSnippet(item?.snippet), 120)
    }))
    .filter((item) => item.title);

  if (c.cacheMinutes > 0) cacheSet(searchCache, cacheKey, hits);
  return hits;
}

/**
 * 读一个条目：正文（纯文本）+ 信息框（wikitext）并发取。
 * 两个都失败才报错；只坏一个就用另一个 —— 宁可给半份资料，也别整个查失败。
 */
async function readPage(title, c) {
  const cacheKey = `p:${title}`;
  const cached = cacheGet(pageCache, cacheKey, c.cacheMinutes);
  if (cached) return cached;

  const [extractRes, wikitextRes] = await Promise.allSettled([
    wikiJson({
      action: 'query',
      prop: 'extracts',
      explaintext: 1,
      exsectionformat: 'plain',
      redirects: 1,
      titles: title
    }, c),
    wikiJson({
      action: 'query',
      prop: 'revisions',
      rvprop: 'content',
      rvslots: 'main',
      rvsection: 0,
      redirects: 1,
      titles: title
    }, c)
  ]);

  if (extractRes.status === 'rejected' && wikitextRes.status === 'rejected') {
    throw extractRes.reason;
  }

  const extractPage = extractRes.status === 'fulfilled' ? firstPage(extractRes.value) : null;
  const wikiPage = wikitextRes.status === 'fulfilled' ? firstPage(wikitextRes.value) : null;
  const page = extractPage || wikiPage;
  if (isMissing(page)) return null;

  const realTitle = String(page?.title || title).trim() || title;
  const wikitext = readRevisionContent(wikiPage);
  const extract = String(extractPage?.extract || '').slice(0, MAX_EXTRACT_CHARS);
  const data = {
    title: realTitle,
    url: pageUrl(c.siteBase, realTitle),
    extract,
    facts: c.includeFacts ? extractFacts(wikitext, c.maxFacts) : [],
    disambig: isDisambig(wikitext, extract)
  };

  if (c.cacheMinutes > 0) {
    cacheSet(pageCache, cacheKey, data);
    cacheSet(pageCache, `p:${realTitle}`, data); // 重定向后的正式名也缓存一份
  }
  return data;
}

function firstPage(data) {
  const pages = data?.query?.pages;
  if (!pages) return null;
  const list = Array.isArray(pages) ? pages : Object.values(pages);
  if (!list.length) return null;
  // 有正常条目就优先它（多标题查询时可能夹着 missing 的）
  return list.find((p) => !isMissing(p)) || list[0];
}

function isMissing(page) {
  if (!page) return true;
  if (page.missing !== undefined) return true;
  if (page.invalid !== undefined) return true;
  return page.pageid === -1;
}

function readRevisionContent(page) {
  const rev = page?.revisions?.[0];
  if (!rev) return '';
  return String(
    rev.slots?.main?.['*']
    ?? rev.slots?.main?.content
    ?? rev['*']
    ?? rev.content
    ?? ''
  );
}

// ── 资料卡（信息框）解析 ────────────────────────────────────────────────────

// 纯排版/图片类字段对聊天没用，还会把"基本资料"挤满。
const SKIP_FACT_KEY = /^(image|img|caption|tabs?|color|colors|textcolor|bordercolor|bgcolor|width|height|font|size|style|图片|图像|图片信息|图片说明|背景图片|背景图|立绘|立绘说明|相关图片|其他图片|封面|封面图|logo|banner|图标|排序|备注图片|$)/i;
const SKIP_FACT_KEY_CN = /图片|立绘|图像|背景图|图标|海报|封面|图集/;

// 这几个字段最常被问，排在资料卡最前面。
const FACT_PRIORITY = [
  '本名', '姓名', '中文名', '日文名', '罗马字', '假名', '别名', '昵称', '外号', '称号',
  '生日', '出生', '年龄', '身高', '体重', '血型', '三围', '声优', 'cv', '配音', '多位声优',
  '所属', '阵营', '种族', '职业', '身份', '出身', '国籍', '登场作品', '作品', '作者', '原作',
  '出版社', '连载', '动画', '游戏', '歌曲', '萌点', '性格', '发色', '瞳色', '代表色',
  '代表作品', '形象', '名言', '口头禅', '关系', '亲属', '喜欢', '讨厌', '能力', '武器'
];

/**
 * 从条目开头的 wikitext 里抠出信息框，整理成 key/value。
 *
 * 为什么不直接从纯文本拿：TextExtracts 会把表格（信息框）整体丢掉，
 * 而"生日/身高/声优"恰恰几乎只存在于信息框里 —— 少了它，最常见的那类问题反而答不上。
 */
// 信息框的模板名五花八门（人物信息 / 用语信息 / Comic Infobox / 游戏信息…），
// 而条目开头还常挂着「生日祝福」「Customtop」「XXtop」这类横幅模板 ——
// 后者参数也有几个，不筛的话会把"完整描述：小波奇"当成基本资料返回。
const INFOBOX_NAME = /infobox|信息|人物|角色|作品|用语|游戏|动画|漫画|歌曲|声优|虚拟|组织|公司|团队|comic|manga|anime|game|novel|album|character/i;

function extractFacts(wikitext, maxFacts) {
  if (!wikitext || maxFacts <= 0) return [];
  const lead = String(wikitext).slice(0, 30000);
  const templates = [];
  for (const block of findTemplates(lead).slice(0, 40)) {
    const parsed = parseTemplate(block);
    if (parsed && parsed.params.length >= 3) templates.push(parsed);
  }
  if (!templates.length) return [];

  // 优先只在"像信息框"的模板里挑；都不像才退回参数最多那个。
  const infoboxLike = templates.filter((t) => INFOBOX_NAME.test(t.name));
  const pool = infoboxLike.length ? infoboxLike : templates;
  pool.sort((a, b) => scoreTemplate(b) - scoreTemplate(a));
  const best = pool[0];

  const facts = [];
  const seen = new Set();
  for (const { key, value } of best.params) {
    const name = String(key).replace(/\s+/g, '').replace(/[：:]+$/, '');
    if (!name || name.length > 24) continue;
    if (SKIP_FACT_KEY.test(name) || SKIP_FACT_KEY_CN.test(name) || /color$|颜色$/i.test(name)) continue;
    if (!value || value.length < 1) continue;
    // 文件名的残留（"xxx.svg width:200px"）和纯图片字段一样，对聊天没用
    if (/\.(svg|png|jpe?g|gif|webp)\b/i.test(value)) continue;
    const lower = name.toLowerCase();
    if (seen.has(lower)) continue;
    seen.add(lower);
    facts.push({ key: name, value: truncate(value, 160) });
  }
  if (!facts.length) return [];

  // sort 在 V8 里是稳定的：同优先级字段保持信息框里的原顺序。
  facts.sort((a, b) => factRank(a.key) - factRank(b.key));
  return facts.slice(0, maxFacts);
}

function factRank(key) {
  const idx = FACT_PRIORITY.findIndex((k) => k.toLowerCase() === String(key).toLowerCase());
  return idx < 0 ? FACT_PRIORITY.length + 1 : idx;
}

function scoreTemplate(t) {
  let score = t.params.length;
  if (/infobox|信息/i.test(t.name)) score += 6;
  if (/人物|角色|作品|用语|游戏|动画|漫画|歌曲|声优|虚拟|组织|公司|团队/i.test(t.name)) score += 3;
  return score;
}

/**
 * 是不是消歧义页。
 * 模板一般挂在页面最末，而只取 section 0 拿不到它；所以再按正文特征判一遍
 * （消歧义页的正文几乎都以「X 可以指：」开头）。
 */
function isDisambig(wikitext, extract = '') {
  if (/\{\{\s*(消歧义|消歧義|disambig|disambiguation|dab|人名消歧义|地名消歧义)/i.test(String(wikitext || ''))) return true;
  return /可以指[：:]|可能指[：:]|可以指代|这是一个消歧义页|消歧义页/.test(String(extract || '').slice(0, 300));
}

/** 找出 wikitext 里所有顶层 {{...}}（不受嵌套模板干扰）。 */
function findTemplates(source) {
  const out = [];
  const text = String(source || '');
  let depth = 0;
  let start = -1;
  // 只按两个字符一组数花括号：{{ 开、}} 闭。
  // 不要为 "{{{" / "}}}" 写特例 —— `{{a|{{b}}}}` 结尾是四个右括号，
  // 特例会把第三个 `}` 当成三连闭合并吞掉，depth 永远回不到 0，
  // 结果整页只认出第一个模板（信息框就是这么被漏掉的）。
  for (let i = 0; i < text.length;) {
    if (text.startsWith('{{', i)) {
      if (depth === 0) start = i;
      depth += 1;
      i += 2;
      continue;
    }
    if (text.startsWith('}}', i) && depth > 0) {
      depth -= 1;
      i += 2;
      if (depth === 0 && start >= 0) { out.push(text.slice(start, i)); start = -1; }
      continue;
    }
    i += 1;
  }
  return out;
}

function parseTemplate(block) {
  const inner = String(block || '')
    .replace(/^\{\{\{?/, '')
    .replace(/\}\}\}?$/, '');
  const parts = splitTopLevel(inner, '|');
  const name = String(parts.shift() || '').trim().replace(/^subst:/i, '');
  const params = [];
  for (const part of parts) {
    const eq = indexOfTopLevel(part, '=');
    if (eq < 0) continue;
    const key = cleanWiki(part.slice(0, eq));
    const value = cleanWiki(part.slice(eq + 1));
    if (!key || !value) continue;
    if (/^\d+$/.test(key)) continue; // 匿名参数（常用于图片尺寸）不要
    params.push({ key, value });
  }
  return { name, params };
}

/** 按 depth=0 的 sep 切分，尊重 {{...}} 与 [[...]] 的嵌套。 */
function splitTopLevel(text, sep) {
  const parts = [];
  let buf = '';
  let curly = 0;
  let square = 0;
  for (let i = 0; i < text.length; i++) {
    if (text.startsWith('{{', i)) { curly++; buf += '{{'; i++; continue; }
    if (text.startsWith('}}', i) && curly > 0) { curly--; buf += '}}'; i++; continue; }
    if (text.startsWith('[[', i)) { square++; buf += '[['; i++; continue; }
    if (text.startsWith(']]', i) && square > 0) { square--; buf += ']]'; i++; continue; }
    const ch = text[i];
    if (ch === sep && curly === 0 && square === 0) { parts.push(buf); buf = ''; continue; }
    buf += ch;
  }
  parts.push(buf);
  return parts;
}

function indexOfTopLevel(text, target) {
  let curly = 0;
  let square = 0;
  for (let i = 0; i < text.length; i++) {
    if (text.startsWith('{{', i)) { curly++; i++; continue; }
    if (text.startsWith('}}', i) && curly > 0) { curly--; i++; continue; }
    if (text.startsWith('[[', i)) { square++; i++; continue; }
    if (text.startsWith(']]', i) && square > 0) { square--; i++; continue; }
    if (text[i] === target && curly === 0 && square === 0) return i;
  }
  return -1;
}

/** 把一段 wikitext 洗成人能读的纯文本（信息框的值、摘要都会走这里）。 */
function cleanWiki(value, depth = 0) {
  let s = String(value ?? '');
  s = s.replace(/<!--[\s\S]*?-->/g, ' ');
  s = s.replace(/<ref[^>]*\/>/gi, ' ');
  s = s.replace(/<ref[^>]*>[\s\S]*?<\/ref>/gi, ' ');
  s = s.replace(/<br\s*\/?>/gi, ' ');
  s = s.replace(/<\/?[a-z][^>]*>/gi, ' ');
  if (depth < 4) {
    s = s.replace(/\{\{([^{}]*)\}\}/g, (_m, inner) => renderInlineTemplate(inner, depth + 1));
  }
  s = s.replace(/\{\{[^{}]*\}\}/g, ' ');
  s = s.replace(/\[\[(?:File|Image|文件|图像|檔案|图片)\s*:[^\]]*\]\]/gi, ' ');
  s = s.replace(/\[\[([^\]|]+)\|([^\]]+)\]\]/g, '$2');
  s = s.replace(/\[\[([^\]]+)\]\]/g, '$1');
  s = s.replace(/\[https?:\/\/[^\s\]]+\s+([^\]]+)\]/g, '$1');
  s = s.replace(/\[https?:\/\/[^\s\]]+\]/g, ' ');
  s = s.replace(/'{2,}/g, '');
  s = decodeEntities(s);
  return s.replace(/[\s\u00a0\u3000]+/g, ' ').trim();
}

/** {{jpn|初音|はつね|ミク}} / {{ruby|葛葉|くずは|ja}} 这类内联模板：留下文字，扔掉配色等噪声。 */
function renderInlineTemplate(inner, depth) {
  const parts = splitTopLevel(String(inner || ''), '|');
  const name = String(parts.shift() || '').trim();
  // 纯图片/纯日期计算的模板：留名字会把文件名、数字塞进资料卡
  if (/^(useimg|img|image|file|icon|logo|flag|星座|astrology|生年月日|birth)/i.test(name)) return '';
  const values = [];
  for (const part of parts) {
    const eq = indexOfTopLevel(part, '=');
    const raw = (eq >= 0 ? part.slice(eq + 1) : part).trim();
    if (!raw) continue;
    if (/^#[0-9a-f]{3,8}$/i.test(raw)) continue;
    if (/^\d+(px|em|rem|%)$/i.test(raw)) continue;
    if (/^(red|blue|green|black|white|gray|grey|yellow|orange|purple|pink|brown|cyan|magenta|gold|silver|transparent|inherit|none)$/i.test(raw)) continue;
    if (/^(ja|jp|zh|zh-cn|zh-tw|en|ko|ru|fr|inline-block|center|left|right|top|bottom)$/i.test(raw)) continue;
    const cleaned = cleanWiki(raw, depth);
    if (cleaned) values.push(cleaned);
  }
  return values.join(' ');
}

// ── 正文节选（按问题挑相关段落） ─────────────────────────────────────────────

const NAV_LINE = /^(注释与外部链接|注释|参考资料|参考文献|参考来源|外部链接|参见|导航|分类|引用|相关条目|参考|外部链接与注释|脚注)$/;
const HEADING_MAX = 18;

function isNavLine(line) {
  if (NAV_LINE.test(line)) return true;
  if (/^查\s*[·・]\s*论\s*[·・]\s*编/.test(line)) return true;
  if (line.length >= 3 && /^[·・|｜\-—=_*#\s]+$/.test(line)) return true;
  return false;
}

function isHeading(line) {
  if (!line || line.length > HEADING_MAX) return false;
  if (/[。！？!?；;：:]/.test(line)) return false;
  if (/^[·・\-—*#\s]/.test(line)) return false;
  return true;
}

/**
 * 从整篇纯文本里挑出跟问题最相关的部分。
 * 预算内：先保证"它是什么"（开头几段），再按问题关键词补最相关的段落，
 * 段落连同所属小标题一起带出去（否则"外貌""性格"这类内容会失去上下文）。
 */
function pickRelevantText(extract, query, budget) {
  const text = String(extract || '').replace(/\r\n?/g, '\n');
  if (!text.trim()) return '';

  const lines = text.split('\n')
    .map((line) => line.replace(/[\t\u00a0\u3000]+/g, ' ').trim())
    .filter((line) => line && !isNavLine(line));
  if (!lines.length) return '';

  const blocks = [];
  let heading = '';
  for (const line of lines) {
    if (isHeading(line)) { heading = line; continue; }
    blocks.push({ text: line, heading });
  }
  if (!blocks.length) return '';

  const totalChars = blocks.reduce((sum, b) => sum + b.text.length, 0);
  const terms = queryTerms(query);
  const weights = blocks.map((b) => scoreText(b.heading ? `${b.heading}\n${b.text}` : b.text, terms));

  const chosen = new Set();
  let used = 0;
  const leadBudget = Math.max(240, Math.round(budget * 0.4));
  for (let i = 0; i < blocks.length && used < leadBudget; i++) {
    chosen.add(i);
    used += blocks[i].text.length + 2;
  }

  const ranked = weights
    .map((weight, index) => ({ index, weight }))
    .filter((item) => item.weight > 0 && !chosen.has(item.index))
    .sort((a, b) => b.weight - a.weight || a.index - b.index);
  for (const { index } of ranked) {
    const block = blocks[index];
    const cost = block.text.length + (block.heading ? block.heading.length + 1 : 0) + 2;
    if (used + cost > budget) continue;
    chosen.add(index);
    used += cost;
  }

  // 关键词一个都没命中（比如问法太口语）时，别只给开头两段就交差。
  if (used < budget * 0.55) {
    for (let i = 0; i < blocks.length && used < budget * 0.9; i++) {
      if (chosen.has(i)) continue;
      chosen.add(i);
      used += blocks[i].text.length + 2;
    }
  }

  let out = '';
  let lastHeading = '';
  for (let i = 0; i < blocks.length; i++) {
    if (!chosen.has(i)) continue;
    const block = blocks[i];
    if (block.heading && block.heading !== lastHeading) {
      if (out) out += '\n';
      out += `${block.heading}\n`;
      lastHeading = block.heading;
    }
    out += `${block.text}\n`;
  }
  out = out.trim();
  if (!out) return '';

  const limit = Math.round(budget * 1.15);
  if ([...out].length > limit) out = `${[...out].slice(0, limit).join('').trim()}…`;
  if (totalChars > out.length * 1.3) {
    out += `\n（原条目约 ${totalChars} 字，这里按问题挑了相关的部分）`;
  }
  return out;
}

const STOP_TERMS = new Set([
  '什么', '怎么', '为什么', '怎么样', '哪个', '哪些', '哪里', '多少', '是谁', '是不是',
  '请问', '帮我', '查一下', '查查', '一下', '告诉', '告诉我', '介绍', '资料', '百科', '萌娘',
  '萌百', '这个', '那个', '角色', '作品', '人物', '相关', '信息', '详细', '说说', '讲讲',
  '知道', '有没', '没有', '可以', '能不能', '的', '了', '吗', '呢', '啊', '吧', '呀',
  '和', '与', '在', '有', '是', '我', '你', '他', '她', '它', '这', '那', '些', '个'
]);

/** 中文没有空格，按二元组切；英文/数字按词切。够用且不引入分词依赖。 */
function queryTerms(query) {
  const text = String(query || '').toLowerCase();
  const terms = new Set();
  for (const match of text.matchAll(/[a-z0-9][a-z0-9_.+-]{1,}/g)) {
    if (!STOP_TERMS.has(match[0])) terms.add(match[0]);
  }
  for (const match of text.matchAll(/[\u4e00-\u9fa5]{2,}/g)) {
    const run = match[0];
    if (run.length <= 8 && !STOP_TERMS.has(run)) terms.add(run);
    for (let i = 0; i < run.length - 1; i++) {
      const bigram = run.slice(i, i + 2);
      if (!STOP_TERMS.has(bigram)) terms.add(bigram);
    }
  }
  return [...terms].filter((term) => term.length >= 2).slice(0, 48);
}

function scoreText(text, terms) {
  if (!text) return 0;
  const haystack = text.toLowerCase();
  let score = 0;
  for (const term of terms) {
    let from = 0;
    let hits = 0;
    while (hits < 6) {
      const at = haystack.indexOf(term, from);
      if (at < 0) break;
      hits += 1;
      from = at + term.length;
    }
    if (hits) score += hits * (term.length >= 3 ? 2 : 1);
  }
  return score;
}

// ── 标题挑选 ────────────────────────────────────────────────────────────────

function normalizeTitle(value) {
  return String(value || '')
    .toLowerCase()
    .replace(/[\s\u3000]+/g, '')
    .replace(/[!！?？。，,、·・:：;；'"“”‘’()（）[\]【】《》〈〉<>~～_\-—－]/g, '');
}

/** 搜索第一名不一定是最该读的那条：全名命中 > 前缀命中 > 包含。 */
function pickBestTitle(query, hits) {
  const q = normalizeTitle(query);
  if (!q) return hits[0].title;
  let best = hits[0].title;
  let bestScore = 0;
  for (const hit of hits) {
    const t = normalizeTitle(hit.title);
    if (!t) continue;
    let score = 0;
    if (t === q) score = 100;
    else if (t.length >= 2 && q.includes(t)) score = 70 + Math.min(20, t.length);
    else if (t.length >= 2 && t.includes(q)) score = 60 + Math.min(20, q.length);
    // 只是开头几个字一样的"弱相似"（波奇探 vs 波奇酱）不能推翻搜索排序，
    // 否则一旦列表里有个同前缀的条目，就会把真正的条目挤掉。
    if (score > bestScore) { bestScore = score; best = hit.title; }
  }
  return best;
}

/** 查询和标题有没有至少两个字的公共片段（"葛叶身高" vs 《葛叶》就算）。 */
function sharesFragment(a, b) {
  if (!a || !b) return false;
  for (let i = 0; i < a.length - 1; i++) {
    if (b.includes(a.slice(i, i + 2))) return true;
  }
  return false;
}

/** 有区分度的词：英文/数字整词，或 3 字以上的中文片段。两字组太容易撞车。 */
function isDistinctive(term) {
  if (/^\d+$/.test(term)) return false; // 纯数字到处都有（日期、身高、密码…），不能当证据
  return term.length >= 3 || /^[a-z0-9]/.test(term);
}

/**
 * 判断搜到的条目跟问题是否真有关。
 * 只用来拦"完全对不上"的那种（站点对任意乱码都会硬塞一条结果），
 * 两条任一成立就算有关：
 *   1. 标题和问题有 ≥2 字的公共片段（「葛叶身高」vs《葛叶》）；
 *   2. 有一个有区分度的词（英文整词、3 字以上片段）出现在条目开头。
 * 故意不拿两字组当证据："不存在"这种词在正文里到处都是，会放过乱码查询。
 */
function looksRelevant(query, page) {
  const q = normalizeTitle(query);
  const t = normalizeTitle(page?.title);
  if (!q || !t) return true;
  if (sharesFragment(q, t)) return true;
  const haystack = `${page.title}\n${String(page.extract || '').slice(0, 1500)}`.toLowerCase();
  return queryTerms(query).some((term) => isDistinctive(term) && haystack.includes(term));
}

const FILLER = /萌娘百科|萌百|百科|请帮我|帮我|请问|麻烦|查一下|查一查|查查|搜一下|搜搜|告诉我|给我讲|讲讲|说说|是谁|是什么样|是什么|怎么样|为什么|有什么区别|资料|介绍/gu;

/** 口语问题搜不到时的退路：去掉客套和疑问词，只留实体词。 */
function simplifyQuery(query) {
  const original = String(query || '').trim();
  const stripped = original
    .replace(FILLER, ' ')
    .replace(/[?？!！。，,、；;：:]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
  if (!stripped || stripped === original || stripped.length < 2) return '';
  return stripped.slice(0, 40);
}

// 在疑问词/属性词出现的地方把问题切开，前半截通常就是"到底在问谁/哪部作品"。
// 例：「波奇酱的声优是谁」→「波奇酱」；「孤独摇滚讲什么」→「孤独摇滚」。
const ENTITY_CUT = /的|是|有|多高|多重|多大|多少|几岁|谁|什么|啥|怎么|为什么|如何|哪个|哪些|哪里|讲|介绍|剧情|设定|声优|cv|生日|身高|体重|年龄|血型|星座|出处|来历|全名|性别/;

function entityQuery(query) {
  const text = String(query || '').trim();
  const at = text.search(ENTITY_CUT);
  if (at < 2) return '';
  const head = text.slice(0, at).trim();
  return head.length >= 2 ? head.slice(0, 30) : '';
}

function titleInsideQuery(title, query) {
  const t = normalizeTitle(title);
  const q = normalizeTitle(query);
  return Boolean(t) && t.length >= 2 && q.includes(t);
}

function dedupeHits(hits) {
  const seen = new Set();
  const out = [];
  for (const hit of hits) {
    const key = hit.title.toLowerCase();
    if (seen.has(key)) continue;
    seen.add(key);
    out.push(hit);
  }
  return out;
}

/**
 * 把"一句人话"变成要读的条目名。
 *
 * 两步的理由（都是实测踩出来的）：
 *   1. 先按原句搜。如果搜索第一名的标题就出现在原句里（"原神的法尔伽"→《法尔伽》），
 *      基本可以确定是它，直接收工，省一次请求。
 *   2. 否则把疑问词切开、用前半截的实体词再搜一次。整句直接搜会被功能词带偏：
 *      「波奇酱的声优是谁」的第一名是《波奇探》（同为"波奇"开头），
 *      而搜「波奇酱」第一名才是《后藤一里》。
 */
async function resolveTitle(query, c) {
  let hits = await searchWiki(query, c.searchLimit, c);
  if (!hits.length) {
    const alt = simplifyQuery(query);
    if (alt) hits = await searchWiki(alt, c.searchLimit, c);
  }
  if (!hits.length) return null;
  if (hits[0] && titleInsideQuery(hits[0].title, query)) {
    return { title: hits[0].title, hits, basis: query };
  }

  const entity = entityQuery(query);
  if (entity && entity !== query) {
    let entityHits = await searchWiki(entity, c.searchLimit, c);
    if (!entityHits.length) {
      const alt = simplifyQuery(entity);
      if (alt) entityHits = await searchWiki(alt, c.searchLimit, c);
    }
    if (entityHits.length) {
      return {
        title: pickBestTitle(entity, entityHits),
        hits: dedupeHits([...hits, ...entityHits]),
        // 用实体词（而不是整句）做"相关性"判断：整句里的"的/是谁"会干扰匹配
        basis: entity
      };
    }
  }
  return { title: pickBestTitle(query, hits), hits, basis: query };
}

// ── 输出 ────────────────────────────────────────────────────────────────────

function renderPage(page, { query, budget, c, hits }) {
  const parts = [];
  parts.push(page.disambig
    ? `《${page.title}》（萌娘百科 · 消歧义页，同名/相近的条目有多个）`
    : `《${page.title}》（萌娘百科）`);
  parts.push(`链接：${page.url}`);

  if (c.includeFacts && page.facts.length) {
    parts.push('', '基本资料：');
    for (const fact of page.facts.slice(0, c.maxFacts)) parts.push(`· ${fact.key}：${fact.value}`);
  }

  const body = pickRelevantText(page.extract, query, budget);
  if (body) parts.push('', '正文：', body);

  if (page.disambig && hits?.length) {
    const list = hits.slice(0, 6).map((hit, i) => `${i + 1}. ${hit.title}`).join('；');
    if (list) parts.push('', `候选条目：${list}（要读哪个就用 moegirl_lookup(title="...")）`);
  }

  if (!page.facts.length && !body) parts.push('', '（这个条目没有可读的正文或资料）');
  parts.push('', '——以上是条目节选。用你自己的话回答，别照抄百科腔；节选里没有的别补。');
  return parts.join('\n');
}

function fail(action, error) {
  const kind = error?.kind;
  const message = String(error?.message ?? error ?? '未知错误');
  let hint;
  switch (kind) {
    case 'no-fetch':
      hint = '这个技能没拿到联网权限。请在「技能」页确认「萌娘百科查资料」是开启的；还不行就重启一下 QQ Agent。';
      break;
    case 'timeout':
      hint = '可以过几秒再查一次；还不行就先按你自己知道的谨慎回答，别硬编。';
      break;
    case 'waf':
      hint = '萌娘百科这次没返回正常数据（可能被站点风控拦了一下）。过几秒再试，别连续猛查。';
      break;
    case 'http':
      hint = '稍后再试，先别反复重试。';
      break;
    default:
      hint = '这次没查到。换个关键词再试一次，或者直说没查到。';
  }
  return { content: `萌娘百科${action}失败：${message}。${hint}`, isError: true };
}

// ── 杂项 ────────────────────────────────────────────────────────────────────

function clampInt(value, min, max, fallback) {
  const n = Number(value);
  if (!Number.isFinite(n)) return fallback;
  return Math.min(max, Math.max(min, Math.round(n)));
}

function truncate(value, max) {
  const text = String(value ?? '');
  const chars = [...text];
  if (chars.length <= max) return text.trim();
  return `${chars.slice(0, max).join('').trim()}…`;
}

function pageUrl(siteBase, title) {
  // 用 index.php?title=... 而不是 /条目名：手机站的"漂亮路径"对非浏览器请求
  // 直接回 403（实测 /初音未来、/ 都是 403，index.php 才是 200）。
  // 群友点开的是浏览器，但这个链接也可能被模型原样抄进聊天，所以选能打开的那种。
  return `${siteBase}/index.php?title=${encodeURIComponent(String(title).replace(/ /g, '_'))}`;
}

function cleanSnippet(value) {
  return decodeEntities(String(value ?? '').replace(/<[^>]+>/g, ' '))
    .replace(/[\s\u00a0\u3000]+/g, ' ')
    .replace(/^[…\s]+|[…\s]+$/g, '')
    .trim();
}

function decodeEntities(value) {
  return String(value ?? '')
    .replace(/&#(\d+);/g, (_m, code) => codePoint(Number(code)))
    .replace(/&#x([0-9a-f]+);/gi, (_m, code) => codePoint(parseInt(code, 16)))
    .replace(/&nbsp;/gi, ' ')
    .replace(/&amp;/gi, '&')
    .replace(/&lt;/gi, '<')
    .replace(/&gt;/gi, '>')
    .replace(/&quot;/gi, '"')
    .replace(/&#39;/g, "'");
}

function codePoint(code) {
  try { return String.fromCodePoint(code); } catch { return ''; }
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function cacheGet(map, key, minutes) {
  if (!minutes) return null;
  const hit = map.get(key);
  if (!hit) return null;
  if (Date.now() - hit.at > minutes * 60000) {
    map.delete(key);
    return null;
  }
  // 轻量 LRU：命中后挪到队尾
  map.delete(key);
  map.set(key, hit);
  return hit.value;
}

function cacheSet(map, key, value) {
  map.delete(key);
  map.set(key, { at: Date.now(), value });
  while (map.size > CACHE_MAX) map.delete(map.keys().next().value);
}

// 给排障/自测用（loader 会忽略未知导出）
export const __test = {
  pickRelevantText, extractFacts, pickBestTitle, queryTerms, findTemplates, parseTemplate, isDisambig
};
