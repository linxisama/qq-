// 「苦命鸳鸯（外置文件版）」技能 —— 入口。
//
// 与内置版（skills/kuming-yuanyang）的区别，只有一个：
//   **文件不随技能打包**。使用者要在设置里填「PDF 文件地址」（本地完整路径），
//   另外可以选填一个网络直链：本地路径读不到时（换电脑、文件被删、U 盘拔了）
//   自动从直链下载并缓存，下次直接用缓存。
//
// 其余行为与内置版一致：打点评分、可先问后发、失败如实转达。
// 两版**互不影响**（各自的工具 id 前缀、各自的设置、各自的内存态），
// 但两个都开着就会对同一批消息各响应一次 —— 所以本技能默认关闭，
// 建议只开一个（见 skill.json 的 enabledByDefault: false）。
//
// 静默失效防护（与内置版同源的三个坑）：
//   1. 工具 id 只用 [a-z0-9_]；加载器自动加 `kuming-yuanyang-ext__` 前缀。
//   2. 工具的 ctx 里**没有** triggerEntries —— 本轮现场靠钩子记进 state。
//   3. 工具返回值里必须写清"下一步做什么"，否则常见结果是"文件发了但一句话没说"。

import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

import { createState, keywordList, affirmText, denyText } from './lib/state.js';
import { resolvePdf, humanSize, DATA_DIR, DOWNLOAD_DIR, cacheNameFor, cleanPartials } from './lib/pdf.js';
import { deliverFile, sendQuestion, groupQuota } from './lib/deliver.js';

const SKILL_ID = 'kuming-yuanyang-ext';
const DIR = path.dirname(fileURLToPath(import.meta.url));

let api = null;
/** 现场 / 待确认 / 节流状态（一个实例一份，热重载会重建）。 */
let state = createState();

// ── 小工具 ────────────────────────────────────────────────────────────────

function warn(...args) {
  try { api?.warn?.(...args); } catch { /* 日志失败不影响主流程 */ }
}

function clampInt(value, min, max, fallback) {
  const n = Number.parseInt(String(value ?? '').trim(), 10);
  if (!Number.isFinite(n)) return fallback;
  return Math.min(max, Math.max(min, n));
}

function stamp(ts) {
  const n = Number(ts);
  if (!Number.isFinite(n) || n <= 0) return '?';
  try {
    return new Date(n).toLocaleString('zh-CN', { hour12: false, month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit' });
  } catch { return '?'; }
}

/** 读取本技能设置。 */
function cfg() {
  let c = {};
  try { c = api?.config?.() || {}; } catch (error) { warn(`读取设置失败：${error?.message ?? error}`); }
  return {
    enabled: c.enabled !== false,
    triggerWords: String(c.triggerWords ?? '').trim() || '苦命鸳鸯,董卓,吕布,奉先,义父,貂蝉',
    localPath: String(c.localPath ?? '').trim(),
    downloadUrl: String(c.downloadUrl ?? '').trim(),
    cacheName: String(c.cacheName ?? '').trim(),
    sendFile: c.sendFile !== false,
    askBeforeSend: c.askBeforeSend === true,
    askText: String(c.askText ?? '').trim(),
    askWindowMinutes: clampInt(c.askWindowMinutes, 0, 120, 10),
    checkQuota: c.checkQuota !== false,
    minResendMinutes: clampInt(c.minResendMinutes, 0, 1440, 5),
    maxDownloadMB: clampInt(c.maxDownloadMB, 1, 4096, 300),
    reviewPairs: clampInt(c.reviewPairs, 1, 10, 3),
    profileMembers: clampInt(c.profileMembers, 4, 30, 14),
    messagesPerMember: clampInt(c.messagesPerMember, 2, 12, 6),
    impressionsPerMember: clampInt(c.impressionsPerMember, 0, 8, 3),
    styleNote: String(c.styleNote ?? '').trim()
  };
}

/** 框架只有声明了 web_fetch 权限才给 fetch。 */
function fetchImpl() {
  if (typeof api?.fetch === 'function') return api.fetch;
  if (typeof globalThis.fetch === 'function') return globalThis.fetch.bind(globalThis);
  return null;
}

/** 解析要发的文件（本地 → 缓存 → 直链）。 */
function locatePdf(c = cfg()) {
  return resolvePdf({
    localPath: c.localPath,
    downloadUrl: c.downloadUrl,
    cacheName: c.cacheName,
    fetchImpl: fetchImpl(),
    maxDownloadMB: c.maxDownloadMB
  });
}

// ── 群友素材（点评"随群聊印象更新"的数据来源）───────────────────────────

function collectProfiles(ctx, c) {
  const chatKey = String(ctx?.chatKey || '');
  const limit = c.profileMembers;
  const perMember = c.messagesPerMember;
  const impPerMember = c.impressionsPerMember;

  const speaking = new Map();
  let recent = [];
  try {
    recent = ctx?.store?.recent?.(chatKey, { limit: limit * perMember * 2, includeSelf: false }) || [];
  } catch (error) {
    warn(`读最近消息失败：${error?.message ?? error}`);
  }
  for (let i = recent.length - 1; i >= 0; i -= 1) {
    const m = recent[i];
    if (!m || m.self) continue;
    const uid = String(m.senderId || m.senderName || '');
    if (!uid) continue;
    if (!speaking.has(uid)) speaking.set(uid, { userId: String(m.senderId || ''), name: String(m.senderName || uid), count: 0, lines: [] });
    const rec = speaking.get(uid);
    rec.count += 1;
    if (rec.lines.length < perMember) {
      rec.lines.push({ at: m.ts, text: String(m.text || '').replace(/\s+/g, ' ').slice(0, 120) });
    }
  }

  const impressions = new Map();
  let members = [];
  try {
    members = ctx?.memory?.members?.(chatKey) || [];
  } catch (error) {
    warn(`读群友印象失败：${error?.message ?? error}`);
  }
  for (const m of members) {
    const uid = String(m.userId || m.name || '');
    if (!uid) continue;
    if (!impressions.has(uid)) impressions.set(uid, { name: String(m.name || uid), list: [] });
    const rec = impressions.get(uid);
    for (const e of (m.impressions || []).slice(-Math.max(0, impPerMember))) {
      rec.list.push(String(e?.content || '').slice(0, 160));
    }
  }

  const merged = [];
  const seen = new Set();
  for (const s of [...speaking.values()].sort((a, b) => b.count - a.count)) {
    if (merged.length >= limit) break;
    const key = s.userId || s.name;
    if (seen.has(key)) continue;
    seen.add(key);
    const imp = impressions.get(s.userId) || impressions.get(s.name) || null;
    merged.push({
      name: s.name || imp?.name || '群友',
      userId: s.userId,
      messages: s.lines.slice(0, perMember),
      impressions: imp ? imp.list.slice(-impPerMember) : [],
      active: s.count
    });
  }
  if (merged.length < limit) {
    for (const [uid, imp] of impressions) {
      if (merged.length >= limit) break;
      if (seen.has(uid) || seen.has(imp.name)) continue;
      seen.add(uid);
      merged.push({
        name: imp.name || uid,
        userId: /^\d+$/.test(String(uid)) ? String(uid) : '',
        messages: [],
        impressions: imp.list.slice(-impPerMember),
        active: 0
      });
    }
  }
  return merged;
}

function renderProfiles(profiles) {
  if (!profiles.length) {
    return '（这个会话还没有可用的群友素材：既没有最近的聊天记录，也没有历史印象。'
      + '这种情况下不要硬编具体的人名 —— 可以顺着话题玩梗，但不要说"根据我的印象"。）';
  }
  const out = [];
  for (const p of profiles) {
    const who = `${p.name}${p.userId ? `(QQ:${p.userId})` : ''}`;
    const lines = [`【${who}】最近发言 ${p.active} 条`];
    for (const im of p.impressions) lines.push(`  · 印象：${im}`);
    for (const m of p.messages.slice(0, 4)) lines.push(`  · ${stamp(m.at)}：${m.text}`);
    out.push(lines.join('\n'));
  }
  return out.join('\n');
}

/**
 * 点评指令。sentState:
 *   sent     文件已发出
 *   asking   先问后发，本轮还没发（不要说已发送）
 *   declined 对方明确拒绝（别提文件）
 *   none     本轮不发文件
 */
function reviewInstruction(c, scene, sentState = 'sent') {
  const p = c.reviewPairs;
  const bits = [];
  bits.push(`现在立刻用 send_message 说一段点评：从下面的群友里挑出最像「苦命鸳鸯」的 ${p} 组（最多 ${p} 组，素材不够就少说几组，宁缺毋滥）。`);
  bits.push('每一组要写清"谁和谁"+ "为什么是苦命鸳鸯"：理由必须落在素材里的**具体印象或具体发言**上（谁总在等谁、谁一开口另一个就出现、谁被谁反复坑、谁的评价里总带着同一个人……）。');
  bits.push('语气是玩梗调侃，不是心理分析；不要复述文件名、不要罗列群友名单、不要输出"印象/发言"这类字眼，直接说人话。');
  if (scene?.hits?.length) bits.push(`本轮触发词：${scene.hits.join('、')}。`);
  if (c.styleNote) bits.push(`额外风格要求（必须遵守）：${c.styleNote}`);
  if (sentState === 'sent') {
    bits.push('文件已经发到会话里了，不用再解释文件是什么、也不要说"已为你发送"；点评可以顺口带一句"东西发上面了"这种程度的呼应。');
    return bits.join('\n');
  }
  if (sentState === 'asking') {
    bits.push('「发送前先问一句」已开启，询问的话**已经替你发出去了**：不要再重复问一遍，也不要说"已发送 / 发给你了"这种没发生的事。');
    bits.push('等对方回肯定答复后系统会让你再调一次工具，那一轮才真正发送。你只管把点评说完。');
    return bits.join('\n');
  }
  if (sentState === 'declined') {
    bits.push('对方已经明确表示不要这份文件，所以本轮不发、也不要再问。只做点评，别提"文件"两个字。');
    return bits.join('\n');
  }
  bits.push('本轮没有发送文件（发文件被关掉，或文件地址没配好/发不出去），所以一句话都不要提文件。');
  return bits.join('\n');
}

// ── 生命周期 ──────────────────────────────────────────────────────────────

export function setup(injected) {
  api = injected;
  state = createState();                     // 热重载时丢掉上一版的内存态

  // 启动时把上次下载中断留下的 .part 清掉，避免占地方（也不影响缓存命中）
  try {
    const n = cleanPartials();
    if (n) api.log?.(`清理了 ${n} 个未完成的下载残片`);
  } catch { /* ignore */ }

  // ── 工具 1：发文件 + 给点评素材 ──────────────────────────────────────
  api.registerTool({
    id: 'post',
    name: '发苦命鸳鸯·外置（文件+点评素材）',
    category: 'message',
    icon: '🪶',
    description:
      '当群聊/私聊里出现「苦命鸳鸯」「董卓」「吕布」这类关联词，且对方确实在聊这个话题'
      + '（感叹、玩梗、点名叫你评价都算）时调用。'
      + '它负责发送使用者自己配好的 PDF，并返回本轮点评所需的群友印象与最近发言，'
      + '然后你必须紧接着用 send_message 写出"谁和谁是苦命鸳鸯、为什么"。'
      + '文件是"直接发"还是"先问一句再发"由技能设置决定 —— 返回值里会写明，照它执行。'
      + '如果对方只是顺口提到这些词，不要调用。',
    parameters: {
      type: 'object',
      properties: {
        action: {
          type: 'string',
          enum: ['both', 'ask', 'post', 'file', 'review'],
          description: 'both=按设置处理文件并准备点评（默认）；ask=进入"先问后发"的问询；'
            + 'post=对方已答应，真正发出文件；file=只要文件不要点评；review=只要点评素材、不碰文件。'
        },
        reason: {
          type: 'string',
          description: '可选：一句话说明你为什么判断对方在聊这个话题（不会发到群里）。'
        }
      },
      required: []
    },
    async execute(ctx, args) {
      const c = cfg();
      if (!c.enabled) {
        return { content: '「苦命鸳鸯（外置文件版）」在技能设置里被关掉了。请让管理员打开（或改用内置版）。', isError: true };
      }
      const chatKey = String(ctx?.chatKey || '');
      if (!chatKey) {
        return { content: '拿不到当前会话信息，无法在本会话发文件。请在群里或私聊里再试一次。', isError: true };
      }
      const action = ['both', 'file', 'review', 'ask', 'post'].includes(String(args?.action || '')) ? String(args.action) : 'both';
      const scene = state.sceneOf(ctx);
      const c2 = cfg();
      const profiles = collectProfiles(ctx, c2);
      const profilesText = renderProfiles(profiles);
      const ask = state.askState(ctx, c2.askWindowMinutes);
      const sceneAt = Number(scene?.at || 0);

      const finish = (fileLine, sentState, how = sentState) => {
        state.markHandled(chatKey, sceneAt, how);
        const out = [];
        out.push(`【苦命鸳鸯·外置文件版】${fileLine}`);
        out.push(`点评组数：${c2.reviewPairs} 组（技能设置「一次性评价组的数量」）`);
        out.push(`发送方式：${c2.sendFile
          ? (c2.askBeforeSend ? '先问后发（勾了「发送前先问一句」）' : '直接发送')
          : '只点评、不发文件'}`);
        out.push('');
        out.push('本轮可用的群友素材（印象 = 以往聊天攒下的长期印象；发言 = 最近实际说的话）：');
        out.push(profilesText);
        if (scene?.who) {
          out.push('');
          out.push(`本轮开口的人：${scene.who}`);
        }
        out.push('');
        out.push('接下来怎么做：');
        out.push(reviewInstruction(c2, scene, sentState));
        out.push(`（候选池共 ${profiles.length} 人；想让机器人参考更多人/更多发言，调技能设置里的「每轮参考多少位群友」「每位群友参考几条最近发言」。）`);
        return { content: out.join('\n') };
      };

      // ── 只给点评素材 ──
      if (action === 'review') return finish('（本次只要点评素材，没有发送文件）', 'none');

      // ── 先问后发的三种状态 ──
      if (c2.sendFile && c2.askBeforeSend) {
        const wantsAsk = action === 'ask' || action === 'both';
        if (ask.declined) {
          state.clearAsked(chatKey);
          return finish('对方已经明确说不要这份文件，本轮不发送、也不再问。', 'declined', 'declined');
        }
        if (ask.confirmed) {
          // 对方答应了 → 继续走发送
        } else if (wantsAsk) {
          const q = c2.askText || '要不要这本经典名著？回「要」我就发';
          // 问话由技能自己发：问话必须真的出现在聊天记录里，答复判定才看得见它
          const sent = await sendQuestion(ctx, q);
          state.markAsked(chatKey, c2.cacheName || c2.localPath || c2.downloadUrl);
          if (!sent.ok) {
            return finish(
              `⚠️ 想先问一句，但问话没发出去：${sent.error}。`
              + '这一轮没有发送文件；请你自己用 send_message 问一句要不要这本经典名著，等对方答应后再调本工具（action=post）。',
              'asking',
              'asked'
            );
          }
          return finish(
            `还没有发送（勾了「发送前先问一句」）。询问的话已经替你发出去了：「${q}」\n`
            + '⚠️ 这一轮**不要**说文件已发送、也不要重复问一遍。'
            + '等对方回了肯定答复（要/发/好/来一份/可以）之后，系统会让你再调一次本工具（action=post），那一轮才会真正发送；'
            + `对方说不要、或 ${c2.askWindowMinutes || 30} 分钟内没回就不发。`,
            'asking',
            'asked'
          );
        } else {
          return finish(
            '还没有发送：勾了「发送前先问一句」，但没有"对方已经答应"的记录。'
            + '请先用 send_message 问一句要不要这本经典名著，等对方回肯定答复后再调本工具（action=post）。',
            'asking',
            'asked'
          );
        }
      }

      if (!c2.sendFile) {
        return finish('（技能设置里关掉了「发送文件」，本轮只做点评）', 'none');
      }

      // ── 定位文件（本地 → 缓存 → 直链）──
      let found;
      try {
        found = await locatePdf(c2);
      } catch (error) {
        return finish(`⚠️ 文件没有发出去：定位文件时出错（${error?.message ?? error}）`, 'none');
      }
      if (!found.ok) {
        return finish(`⚠️ 文件没有发出去：${found.error}（点评照常进行）`, 'none');
      }
      if (found.warn) warn(`注意：${found.warn}（${found.file}）`);

      if (state.sentRecently(chatKey, found.name, c2.minResendMinutes)) {
        return finish(
          `（《${found.name}》${c2.minResendMinutes} 分钟内在本会话已经发过，这次不重复上传；`
          + '需要每次都发就把设置里「同一会话重复发送的最小间隔」改成 0）',
          'sent'
        );
      }

      const res = await state.withUploadLock(chatKey, () => deliverFile({
        onebot: ctx?.onebot || null,
        chatKey,
        file: found.file,
        name: found.name,
        checkQuota: c2.checkQuota
      }));
      if (res.ok) {
        state.markSent(chatKey, found.name);
        state.clearAsked(chatKey);
        try { ctx?.emit?.('session-update', ctx?.session?.id); } catch { /* UI 刷新失败无所谓 */ }
        const src = found.source === 'local' ? '本地文件'
          : found.source === 'cache' ? '本地缓存'
            : '网络直链（已缓存）';
        return finish(
          `✅ 已把《${found.name}》（${humanSize(res.size)}，来源：${src}）发到本会话`
          + `${res.note ? `（${res.note}）` : ''}。`,
          'sent'
        );
      }
      return finish(`⚠️ 文件没有发出去：${res.error}（点评照常进行）`, 'none');
    }
  });

  // ── 工具 2：只看有谁可以组 CP，不发文件 ──────────────────────────────
  api.registerTool({
    id: 'scene_info',
    name: '看看有谁·外置（不发文件）',
    category: 'query',
    icon: '👀',
    description:
      '不发送任何文件，只查看当前会话里最近活跃的群友与既有印象，用来判断"有谁可以组苦命鸳鸯"。'
      + '只是被问"你觉得谁和谁最苦命"而对方没要文件时用它。',
    parameters: {
      type: 'object',
      properties: {
        members: { type: 'integer', description: '最多列出几位，默认按技能设置。' }
      },
      required: []
    },
    async execute(ctx, args) {
      const c = cfg();
      if (!c.enabled) return { content: '「苦命鸳鸯（外置文件版）」已被关闭。', isError: true };
      const chatKey = String(ctx?.chatKey || '');
      if (!chatKey) return { content: '拿不到当前会话信息。', isError: true };
      const want = clampInt(args?.members, 4, 30, c.profileMembers);
      const c2 = { ...c, profileMembers: want };
      const profiles = collectProfiles(ctx, c2);
      const scene = state.sceneOf(ctx);
      const askNow = state.askState(ctx, c.askWindowMinutes);
      const sentState = askNow.confirmed ? 'sent' : (c.sendFile && c.askBeforeSend ? 'asking' : 'none');
      const out = [];
      out.push(`【苦命鸳鸯·外置·候选群友】共 ${profiles.length} 人（本轮没有发送文件）`);
      out.push(renderProfiles(profiles));
      if (scene.hits.length) out.push(`本轮触发词：${scene.hits.join('、')}`);
      out.push('');
      out.push(reviewInstruction(c2, scene, sentState));
      return { content: out.join('\n') };
    }
  });

  // ── 工具 3：外置版专属 —— 看看文件配好了没 ──────────────────────────
  api.registerTool({
    id: 'file_status',
    name: '检查外置文件是否可用',
    category: 'system',
    icon: '📄',
    description:
      '检查「苦命鸳鸯（外置文件版）」要发送的 PDF 现在能不能拿到（本地地址 / 缓存 / 直链）。'
      + '当群里问"文件在哪 / 怎么发不出来 / 你配好了吗"时用它，它只检查、不发送。',
    parameters: { type: 'object', properties: {}, required: [] },
    async execute() {
      const c = cfg();
      const found = await locatePdf(c);
      const lines = [];
      lines.push(`本技能设置：${c.enabled ? '已启用' : '已关闭'}；${c.sendFile ? '会发文件' : '只点评不发文件'}；`
        + `${c.askBeforeSend ? '先问后发' : '直接发送'}。`);
      lines.push(`本地地址：${c.localPath || '（未填写）'}`);
      lines.push(`网络直链：${c.downloadUrl || '（未填写）'}`);
      lines.push(`缓存目录：${DOWNLOAD_DIR}`);
      if (found.ok) {
        const src = found.source === 'local' ? '本地文件'
          : found.source === 'cache' ? '本地缓存'
            : '网络直链（刚下载并缓存）';
        lines.push(`结果：✅ 现在能发出去 —— ${found.name}（${humanSize(found.size)}，来源：${src}）`);
        lines.push(`实际路径：${found.file}`);
        if (found.warn) lines.push(`注意：${found.warn}`);
      } else {
        lines.push(`结果：❌ 现在发不出去 —— ${found.error}`);
        if (found.tried?.length) lines.push(`已经试过：${found.tried.join('；')}`);
        lines.push(`把 PDF 文件放到技能自己的 data 目录也可以：${DATA_DIR}`);
      }
      return { content: lines.join('\n') };
    }
  });

  const c0 = cfg();
  api.log(`已加载（外置文件版）：本地地址 ${c0.localPath || '未填写'}${c0.downloadUrl ? '；直链已配' : ''}；关联词 ${keywordList(c0.triggerWords).join(' / ')}`);
}

// ── 钩子 ──────────────────────────────────────────────────────────────────
// ⚠️ 只有框架认识的那几个钩子名有效；工具 ctx 里没有 triggerEntries。

/** 生成给模型的现场提示。返回 null = 这轮不需要提醒。 */
function buildHint(ctx = {}) {
  const c = cfg();
  if (!c.enabled) return null;
  const scene = state.sceneOf(ctx);
  const ask = state.askState(ctx, c.askWindowMinutes);

  if (ask.declined) {
    return '对方已经明确说不要这份文件了：不要发送，也不要再问，更不要提"文件"两个字。只把苦命鸳鸯的点评说完即可。';
  }
  if (ask.confirmed && c.sendFile) {
    return `对方刚刚答应了发送（${scene.who ? `${scene.who} 说的` : '上一轮问过'}）。`
      + `现在就调用 ${SKILL_ID}__post（action 填 post）：它会把文件发到本会话。`
      + `调用后紧接着用 send_message 写出最像苦命鸳鸯的 ${c.reviewPairs} 组人及理由（跟着素材里的印象走）。`;
  }
  if (state.handledHow(ctx)) return null;
  if (!scene.hits.length) return null;

  const words = scene.hits.join('、');
  const who = scene.who ? `（${scene.who} 说的）` : '';
  const tail = `调用后紧接着用 send_message 写出最像苦命鸳鸯的 ${c.reviewPairs} 组人及理由（跟着素材里的印象走）。`;

  if (!c.sendFile) {
    return `${words}${who}：本群在聊「苦命鸳鸯」这个话题，但技能里关掉了发送文件。`
      + `现在就调用工具 ${SKILL_ID}__post（action 填 review），然后只做点评，不要说文件的事。`;
  }
  if (!c.localPath && !c.downloadUrl) {
    return `${words}${who}：本群在聊「苦命鸳鸯」这个话题，但这个技能还没填 PDF 文件地址（设置里是空的）。`
      + `可以调用 ${SKILL_ID}__post 让文件那一步给出明确原因（点评仍会照常返回），`
      + `也可以先调用 ${SKILL_ID}__file_status 看具体要求什么 —— 但**不要**说文件已发送。${tail}`;
  }
  if (c.askBeforeSend) {
    return `${words}${who}：本群在聊「苦命鸳鸯」这个话题。技能勾了「发送前先问一句」：`
      + `现在就调用 ${SKILL_ID}__post（action 填 ask）—— 它会替你把"要不要这本经典名著"这句问出去，`
      + `并返回点评素材；**这一轮不要说文件已发送**。等对方回肯定答复后再调一次本工具（action 填 post），那一轮才真正发送。${tail}`;
  }
  return `${words}${who}：如果对方是在跟你聊这个话题（感叹、玩梗、点名叫你评价都算），`
    + `现在就调用 ${SKILL_ID}__post：它会把使用者配好的 PDF 发到本会话并返回点评素材。`
    + `如果这些话只是在聊别的、顺口提到，就不要调用。${tail}`;
}

export const hooks = {
  async 'before-context'(ctx = {}) {
    try {
      if (!api || !cfg().enabled) return;
      state.remember(ctx, keywordList(cfg().triggerWords));
    } catch (error) {
      warn(`before-context 钩子出错（已跳过）：${error?.message ?? error}`);
    }
  },

  async 'before-llm-messages'(ctx = {}) {
    try {
      if (!api || !cfg().enabled) return;
      state.remember(ctx, keywordList(cfg().triggerWords));
      if (!Array.isArray(ctx.messages)) return;
      const hint = buildHint(ctx);
      if (!hint) return;
      const marker = `[${SKILL_ID}]`;
      if (ctx.messages.some((m) => String(m?.content || '').includes(marker))) return;
      ctx.messages.push({ role: 'system', content: `${marker} ${hint}` });
    } catch (error) {
      warn(`before-llm-messages 钩子出错（已跳过）：${error?.message ?? error}`);
    }
  },

  async 'before-tool'(ctx = {}) {
    try {
      if (!api) return;
      state.remember(ctx, keywordList(cfg().triggerWords));
    } catch (error) {
      warn(`before-tool 钩子出错（已跳过）：${error?.message ?? error}`);
    }
  }
};

// ── 可用性自检（技能页会显示 detail 里的话）──────────────────────────────

export function available() {
  const c = cfg();
  if (!c.enabled) return { ok: false, reason: '技能设置里的「启用本技能」是关的' };
  if (!c.sendFile) return { ok: true, detail: '「发送文件」是关的：只做点评，不会发文件。' };
  if (!c.localPath && !c.downloadUrl) {
    // 这里刻意**不**把技能判成不可用：判成不可用会把本技能的三个工具一起从
    // 模型面前摘掉（连"检查文件配好了没"都调不了），用户看到的是"技能开着却
    // 毫无反应"。改为保持可用，由 post / file_status 在调用时给出现成的原因。
    return {
      ok: true,
      detail: '⚠️ 还没填 PDF 文件地址：请在设置里填「PDF 文件地址（必填，本地路径）」，或填一个网络直链。'
        + '现在调用工具不会发送文件，但会明确告诉你是这个原因（也可以让机器人调 file_status 自查）。'
    };
  }
  return {
    ok: true,
    detail: `PDF 地址已填写（${c.localPath ? `本地：${c.localPath}` : '无本地地址'}${c.downloadUrl ? '；另配了直链兜底' : ''}）。`
      + '真正发送时才去检查文件是否存在/下载，失败会如实报告原因。'
  };
}

export function promptSections() {
  const c = cfg();
  if (!c.enabled) return [];
  const bits = [`一次点评最多说 ${c.reviewPairs} 组苦命鸳鸯`];
  if (!c.sendFile) {
    bits.push('只做点评、不发文件（面板里关掉了发送文件）');
  } else if (!c.localPath && !c.downloadUrl) {
    bits.push('⚠️ 还没在面板里填 PDF 文件地址，现在发不出文件，按工具返回如实说明，不要说已发送');
  } else if (c.askBeforeSend) {
    bits.push('要**先问后发**：调用 post 时技能会把"要不要这本经典名著"替你问出去，对方答应后再调一次才真正发送');
  } else {
    bits.push('直接发送使用者配好的 PDF，不需要先征求同意');
  }
  if (c.styleNote) bits.push(`点评风格：${c.styleNote}`);
  return [{
    id: 'kuming-yuanyang-ext-rules-dynamic',
    title: '苦命鸳鸯（外置文件版·当前设置）',
    priority: 51,
    content: `「苦命鸳鸯（外置文件版）」当前设置：${bits.join('；')}。关联词：${keywordList(c.triggerWords).join('、')}。`
  }];
}

export function deactivate() {
  state.clear();
}

export function dispose() {
  deactivate();
}

/** 给本地自检用（框架不读这个导出）。 */
export const __test = {
  cfg, keywordList, collectProfiles, renderProfiles, reviewInstruction, buildHint,
  affirmText, denyText, locatePdf, humanSize, cacheNameFor, DATA_DIR, DOWNLOAD_DIR, DIR,
  getState: () => state
};
