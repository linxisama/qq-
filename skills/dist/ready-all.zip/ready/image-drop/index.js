// 「一键发网图」—— LLM 型技能（skills/）
// =====================================================================
// 一次工具调用完成「搜图 → 校验 → 发送」，补的是现有两条路各自的短板：
//   · 核心的 search_images + send_image：免密钥、但发图前**必须先预览**，模型要跑两轮
//   · 技能 search-image（apihz）：一步到位、但依赖第三方**免费额度**，且图片直链
//     不做本地校验 —— 搜到的可能是防盗链失效图，发出去是个红叉
//
// 本技能的做法：
//   1. 候选来源优先复用同安装包内已验证的图搜实现（百度优先、Bing 兜底，免密钥），
//      拿不到就自己抓 Bing 图片搜索兜底；
//   2. 每张候选都**先下载再按文件魔数校验**（只认真正的 png/jpg/gif/webp），
//      顺手带上 Referer 绕开常见防盗链；不合格就自动换下一张；
//   3. 发送时同时给 url 与 base64 兜底：协议端能直连就传链接（body 极小），
//      取不到图时自动回退 base64（见 sender.js 的 sendImage）。
//
// ⚠️ 规范要点（写错会静默失效，已逐条对齐 plugin-loader.js / skills/manifest.js）：
//   · 拿网络权限靠清单顶层的 `permissions: ["web_fetch"]`；
//     `requires` 是"依赖别人提供的能力"（硬依赖），把 web_fetch 写进 requires
//     会找不到提供者 → 判定"依赖未就绪" → 工具永远不出现，且不会报错。
//   · 入口必须导出 setup(api)（或 register(api)），工具只能靠 registerTool 注册，
//     光写清单里的 tools[] 不会被注册。
//   · 工具 id 会由加载器加上 `技能id__` 前缀，所以不会和核心的
//     search_images / send_image 撞名。

const UA =
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 ' +
  '(KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36';

let cfg = () => ({});
let doFetch = null;

/** 同安装包内的成熟实现：能复用就复用，路径变了就自动降级 */
const core = { loaded: false, searchImages: null, safeFetchBinary: null, detectMime: null };

export function setup(api) {
  cfg = api.config;
  doFetch = typeof api.fetch === 'function' ? (...args) => api.fetch(...args) : null;

  api.registerTool({
    id: 'send_web_image',
    name: '一键发网图',
    description:
      '搜一张网图并直接发到当前聊天，一次到位（搜图、校验、发送全做完，不需要先预览）。' +
      '当用户说「发张猫图」「来张风景照」「找张二次元图发我」时用它。' +
      '参数 keyword 是搜索关键词，越具体越准；count 是发几张（默认 1）。',
    category: 'media',
    icon: '🖼️',
    requiresVision: false,
    requiresSearch: true,
    parameters: {
      type: 'object',
      properties: {
        keyword: { type: 'string', description: '搜索关键词，例如「橘猫幼猫」「雪山日落」「二次元少女」' },
        count: { type: 'integer', description: '要发几张，1~5，默认用设置里的值' },
        note: { type: 'string', description: '可选：随图配一句话' }
      },
      required: ['keyword']
    },

    async execute(ctx, args) {
      try {
        return await run(ctx, args, api);
      } catch (error) {
        return { content: `发网图失败：${text(error)}`, isError: true };
      }
    }
  });

  api.log('已注册工具：一键发网图（send_web_image）');
}

/** 没拿到网络权限时如实报不可用，而不是运行时才炸 */
export function available() {
  return true;
}

// ─────────────────────────────────────────────────────────── 主流程

async function run(ctx, args, api) {
  const c = cfg() || {};
  const keyword = String(args?.keyword ?? '').trim();
  if (!keyword) return { content: '缺少 keyword：要搜什么图？', isError: true };
  if (!doFetch) {
    return { content: '当前没有网络权限（清单需要声明 permissions: ["web_fetch"]）。', isError: true };
  }
  if (!ctx?.sender?.sendImage) {
    return { content: '当前环境不支持发图（缺少 sender）。', isError: true };
  }

  const maxCount = clamp(c.maxCount, 1, 5, 3);
  const defaultCount = clamp(c.defaultCount, 1, maxCount, 1);
  const want = clamp(args?.count, 1, maxCount, defaultCount);
  const maxBytes = clamp(c.maxImageMB, 1, 32, 6) * 1024 * 1024;
  const tryLimit = clamp(c.tryLimit, 1, 15, 6);
  const note = String(args?.note ?? '').trim() || String(c.note ?? '').trim() || undefined;

  // ── 1) 拿候选 ─────────────────────────────────────────────────────
  let found;
  try {
    found = await searchCandidates(keyword, Math.max(tryLimit, want));
  } catch (error) {
    return {
      content: `没搜到「${keyword}」的图片：${text(error)}。换个更具体的词再试一次。`,
      isError: true
    };
  }

  // ── 2) 逐个「下载 → 魔数校验 → 发送」，坏的自动换下一张 ──────────────
  let sent = 0;
  const skipped = [];
  for (const cand of found.list.slice(0, tryLimit)) {
    if (sent >= want) break;
    let buffer = null;
    try {
      buffer = await fetchImageBytes(cand.url, maxBytes);
      const mime = await detectMimeOf(buffer);
      if (!mime) {
        skipped.push('不是图片（多半是防盗链页或已失效）');
        continue;
      }
      await ctx.sender.sendImage(
        ctx.chatKey,
        { url: cand.url, dataUrl: `base64://${buffer.toString('base64')}` },
        { note }
      );
      sent += 1;
      // 与核心的 send_image 保持一致：把发出的图记进会话，
      // 否则 UI 会话视图与「最近消息」里都看不到机器人发过图，和实际对话对不上。
      try {
        ctx.session?.sent?.push({
          type: 'image',
          text: `[图片${note ? `:${String(note).slice(0, 40)}` : ''}]`,
          at: new Date().toLocaleTimeString('zh-CN', { hour12: false })
        });
        ctx.emit?.('session-update', ctx.session?.id);
      } catch {
        /* 记录失败不影响发送本身 */
      }
      api.log(
        `第 ${sent} 张已发送：${mime} ${Math.round(buffer.length / 1024)}KB ` +
          `[${found.source}] ${cand.url.slice(0, 100)}`
      );
    } catch (error) {
      skipped.push(text(error));
      api.warn(`候选跳过：${text(error)} —— ${cand.url.slice(0, 100)}`);
    }
  }

  if (!sent) {
    return {
      content:
        `搜到了「${keyword}」的结果，但一张都没发成功（${skipped.slice(0, 3).join('；') || '原因未知'}）。` +
        '换个更具体的词再试一次。',
      isError: true
    };
  }

  const tail = sent < want ? `（另有 ${want - sent} 张候选不合格已跳过）` : '';
  return {
    content: `已发送 ${sent} 张「${keyword}」的图片${tail}。不要再复述图片内容。`
  };
}

// ─────────────────────────────────────────────────────────── 搜候选

async function searchCandidates(keyword, limit) {
  const errors = [];
  const pool = [];
  const push = (list, source) => {
    for (const item of list) if (item?.url) pool.push({ ...item, source });
  };

  // ① 百度图搜 JSON 接口 —— 优先。实测中文关键词命中率最好，直链来自百度自家 CDN
  try {
    const list = await baiduAcjson(keyword, limit);
    if (list.length) push(list, '百度图片');
  } catch (error) {
    errors.push(`百度图片：${text(error)}`);
  }

  // ② 自己抓 Bing（连结果标题一起取，供下面做相关性过滤）
  try {
    const list = await bingImages(keyword, Math.max(12, limit * 3));
    if (list.length) push(list, 'Bing');
  } catch (error) {
    errors.push(`Bing：${text(error)}`);
  }

  // ③ 复用同安装包内核心的图搜实现，仅当前两个源都没结果时兜底
  if (!pool.length) {
    try {
      const c = await loadCore();
      if (typeof c.searchImages === 'function') {
        const list = normalizeList(await c.searchImages(keyword, limit));
        if (list.length) push(list, '内置图搜');
      }
    } catch (error) {
      errors.push(`内置图搜：${text(error)}`);
    }
  }

  if (!pool.length) {
    throw new Error(errors.length ? errors.join('；') : '所有图源都没有返回结果');
  }
  const ranked = rankCandidates(pool, keyword);
  return { list: ranked, source: [...new Set(ranked.map((r) => r.source))].join(' + ') };
}

/**
 * 百度图片的 JSON 接口（acjson）。
 *
 * ⚠️ 这是本次踩坑的核心，别换回「抓 HTML 页面」那种做法：
 * 实测 `image.baidu.com/search/index?tn=baiduimage` 现在只返回一个 **1438 字符的反爬
 * 空页**，`objURL / middleURL / thumbURL / hoverURL` 一个都抓不到 —— 核心的
 * baiduImageSearch 因此**必然抛错**，于是每次搜索都降级到 Bing；而 Bing 对
 * 「橘猫幼猫可爱」这类中文长尾词的召回极差（整屏返回「电脑壁纸/风景壁纸」），
 * 结果就是"用户要小猫、机器人发来一张壁纸"。
 *
 * 这个 JSON 接口实测稳定，且直链就是百度自家 CDN（img0/img1.baidu.com）：
 * 无防盗链、体积小（约 30~50KB）、尺寸适中，最适合直接发出去。
 */
async function baiduAcjson(keyword, limit) {
  const n = clamp(limit, 1, 30, 8);
  const url =
    'https://image.baidu.com/search/acjson?tn=resultjson_com&ipn=rj&ct=201326592&fp=result' +
    `&word=${encodeURIComponent(keyword)}&pn=0&rn=${n}`;
  const resp = await doFetch(url, {
    headers: {
      'User-Agent': UA,
      Accept: 'application/json, text/plain, */*',
      'Accept-Language': 'zh-CN,zh;q=0.9',
      // 百度对缺少 Referer 的请求会返回空数据
      Referer: 'https://image.baidu.com/'
    }
  });
  if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
  const data = await resp.json().catch(() => null);
  const arr = Array.isArray(data?.data) ? data.data : [];
  const out = [];
  for (const item of arr) {
    if (!item || typeof item !== 'object') continue;
    // middleURL 约 500px：比 thumbURL 清楚，又比原图小得多
    const u = String(item.middleURL || item.thumbURL || item.hoverURL || '').trim();
    if (!/^https?:\/\//i.test(u)) continue;
    out.push({
      url: u.replace(/\\\//g, '/'),
      title: decodeEntities(String(item.fromPageTitleEnc || item.fromPageTitle || ''))
    });
  }
  return out;
}

/**
 * Bing 图片搜索。图片直链藏在结果的 `m="{...}"` 属性里。
 *
 * ⚠️ 必须把标题（t 字段）一起取出来：没有标题就无法判断这张图是否与关键词相关，
 * 而 Bing 对中文长尾关键词的质量很差，不做过滤就会把壁纸当猫发出去。
 */
async function bingImages(keyword, limit) {
  const url =
    'https://www.bing.com/images/search?q=' +
    encodeURIComponent(keyword) +
    '&first=1&tsc=ImageBasicHover';
  const resp = await doFetch(url, {
    headers: { 'User-Agent': UA, 'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8' }
  });
  if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
  const html = await resp.text();

  const out = [];
  // 优先解析完整的 m 属性：能同时拿到 murl（图链）和 t（标题）
  for (const m of html.matchAll(/m="([^"]+)"/g)) {
    const raw = decodeEntities(m[1]);
    let j = null;
    try {
      j = JSON.parse(raw);
    } catch {
      /* 少数属性不是合法 JSON，留给下面的裸 murl 兜底 */
    }
    if (!j) continue;
    const u = String(j.murl || j.mediaurl || '');
    if (/^https?:\/\//i.test(u)) {
      out.push({ url: decodeEntities(u), title: decodeEntities(String(j.t || j.desc || '')) });
    }
  }
  // 兜底形态：只有图链、没有标题
  if (!out.length) {
    for (const re of [/murl&quot;:&quot;(.*?)&quot;/g, /"murl":"(.*?)"/g]) {
      let m;
      while ((m = re.exec(html)) !== null) {
        const u = decodeEntities(m[1]);
        if (/^https?:\/\//i.test(u)) out.push({ url: u, title: '' });
      }
      if (out.length) break;
    }
  }
  return normalizeList(out).slice(0, clamp(limit, 1, 60, 12));
}

/**
 * 关键词相关性过滤 + 排序 —— 拦住"要猫却发壁纸"的那道闸。
 *
 * 做法：把关键词切成相邻二字片段（「橘猫幼猫可爱」→ 橘猫/猫幼/幼猫/猫可/可爱），
 * 看它在结果标题里命中几个。壁纸类标题里不会出现「橘猫」「幼猫」这种片段，所以能
 * 干净地剔掉；只要命中一个片段就保留（宁可宽松，不误杀）。全部候选都没标题时
 * 不做过滤 —— 没有判断依据时不能瞎猜。
 */
function rankCandidates(list, keyword) {
  const seen = new Set();
  const uniq = [];
  for (const item of list) {
    if (!item?.url || seen.has(item.url)) continue;
    seen.add(item.url);
    uniq.push(item);
  }

  const kw = String(keyword || '').replace(/\s+/g, '');
  const grams = new Set();
  for (let i = 0; i < kw.length - 1; i++) grams.add(kw.slice(i, i + 2));
  if (!grams.size && kw) grams.add(kw);

  const scored = uniq.map((item) => {
    const title = String(item.title || '').trim();
    // 没有标题 = 无法判断，给中性分并一律保留（不因"没证据"而误杀）
    if (!title) return { ...item, _known: false, _hit: 1, _score: 10 };
    let hit = 0;
    for (const g of grams) if (title.includes(g)) hit++;
    const exact = kw && title.includes(kw) ? 1 : 0;
    return {
      ...item,
      _known: true,
      _hit: hit,
      _score: exact * 100 + (grams.size ? (hit / grams.size) * 50 : 0)
    };
  });

  const kept = scored.filter((x) => !x._known || x._hit >= 1);
  if (!kept.length) {
    const sample = scored
      .slice(0, 2)
      .map((x) => String(x.title || '').slice(0, 24))
      .join('」「');
    // 一句建议由调用方统一补，这里只说清原因
    throw new Error(`搜到的图都和「${keyword}」不相关（例如「${sample}」）`);
  }
  kept.sort((a, b) => b._score - a._score);
  return kept;
}

function normalizeList(list) {
  if (!Array.isArray(list)) return [];
  const seen = new Set();
  const out = [];
  for (const item of list) {
    const url = String(item?.url ?? item?.imgurl ?? item?.image_url ?? '').trim();
    if (!/^https?:\/\//i.test(url)) continue;
    if (/\.svg(\?|#|$)/i.test(url)) continue; // svg 不是 QQ 能直接发的位图
    if (seen.has(url)) continue;
    seen.add(url);
    out.push({ url, title: String(item?.title ?? '').slice(0, 60) });
  }
  return out;
}

// ─────────────────────────────────────────────────────────── 下载 + 校验

async function fetchImageBytes(url, maxBytes) {
  const c = await loadCore();

  // 优先走核心的 safe-fetch：DNS 固定、逐跳校验、SSRF 防护、限量
  if (typeof c.safeFetchBinary === 'function') {
    try {
      const r = await c.safeFetchBinary(url, maxBytes, {});
      if (r?.buffer?.length) return r.buffer;
    } catch {
      /* 落到下面的自实现（例如核心限制了该主机） */
    }
  }

  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 15000);
  try {
    const resp = await doFetch(url, {
      signal: controller.signal,
      redirect: 'follow',
      headers: {
        'User-Agent': UA,
        // 实测百度 CDN 不看 Accept 头、总是吐 webp（更省流量），这不影响最终发送：
        // 发图时优先把 url 交给协议端自己下载（协议端拿到的是 jpeg），
        // 这里的字节只在协议端取不到图时作为 base64 兜底。
        Accept: 'image/jpeg,image/png,image/gif,*/*;q=0.5',
        // 不少图床按 Referer 防盗链，带上站点自身地址能显著提高成功率
        Referer: originOf(url)
      }
    });
    if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
    const buf = Buffer.from(await resp.arrayBuffer());
    if (!buf.length) throw new Error('图片内容为空');
    if (buf.length > maxBytes) {
      throw new Error(`图片超过 ${Math.round(maxBytes / 1048576)}MB`);
    }
    return buf;
  } finally {
    clearTimeout(timer);
  }
}

async function detectMimeOf(buffer) {
  const c = await loadCore();
  if (typeof c.detectMime === 'function') {
    try {
      const m = c.detectMime(buffer);
      if (m) return m;
    } catch {
      /* 用下面的自实现 */
    }
  }
  return sniffMime(buffer);
}

/** 只认文件头，不认 Content-Type —— 很多"图片链接"实际返回 HTML 错误页 */
function sniffMime(buf) {
  if (!buf || buf.length < 12) return null;
  if (buf[0] === 0x89 && buf[1] === 0x50 && buf[2] === 0x4e && buf[3] === 0x47) return 'image/png';
  if (buf[0] === 0xff && buf[1] === 0xd8 && buf[2] === 0xff) return 'image/jpeg';
  if (buf[0] === 0x47 && buf[1] === 0x49 && buf[2] === 0x46) return 'image/gif';
  if (buf.toString('latin1', 0, 4) === 'RIFF' && buf.toString('latin1', 8, 12) === 'WEBP') {
    return 'image/webp';
  }
  if (buf[0] === 0x42 && buf[1] === 0x4d) return 'image/bmp';
  return null;
}

// ─────────────────────────────────────────────────────────── 工具函数

/**
 * 复用同安装包内的核心实现。
 * 用模块自身位置做锚点（不能用 process.cwd()：安装版的"起始位置"未必是 app 目录）。
 * 任一个取不到都只是降级，不影响本技能工作。
 */
async function loadCore() {
  if (core.loaded) return core;
  core.loaded = true;
  const wanted = [
    ['../../src/web-search.js', 'searchImages'],
    ['../../src/safe-fetch.js', 'safeFetchBinary'],
    ['../../src/image-type.js', 'detectMime']
  ];
  for (const [rel, name] of wanted) {
    try {
      const mod = await import(/* @vite-ignore */ new URL(rel, import.meta.url).href);
      if (typeof mod?.[name] === 'function') core[name] = mod[name];
    } catch {
      /* 核心路径变了：走自实现 */
    }
  }
  return core;
}

function clamp(value, lo, hi, fallback) {
  const n = Math.round(Number(value));
  if (!Number.isFinite(n)) return fallback;
  return Math.min(hi, Math.max(lo, n));
}

function originOf(url) {
  try {
    const u = new URL(url);
    return `${u.protocol}//${u.host}/`;
  } catch {
    return '';
  }
}

/** 解码搜索引擎返回内容里的各种转义：`https:\/\/x\/y.jpg`、`&quot;`、`&amp;` 等 */
function decodeEntities(raw) {
  return String(raw ?? '')
    .replace(/\\u0026/gi, '&')
    .replace(/\\\//g, '/')
    .replace(/&amp;/gi, '&')
    .replace(/&quot;/gi, '"')
    .replace(/&#0?39;/g, "'")
    .trim();
}

function text(error) {
  return String(error?.message ?? error ?? '未知错误');
}
