// 订阅推送子模块 —— 由 skills/bili-dynamic/index.js 组合进来。
//
// ── 为什么是"一个技能里的一个子模块"，而不是独立的 plugins/bili-subscribe ──
// 原本这是两个条目（一个 skills/ 的技能 + 一个 plugins/ 的插件），分开的理由是
// 加载器的语义分类：skills/ = LLM 型（注册工具），plugins/ = 确定性型（定时器/钩子）。
//
// 但那个分类**只是语义归类，不是能力限制**。加载器源码里两处关键事实：
//   1. plugin-loader.js 的 normalizeManifest：两个目录走同一条规范化路径，
//      "字段与扩展点完全等价"
//   2. app.js 的 reloadSkills：对 skillManager.list() 里所有条目（不分目录）
//      统一调 activate(ctx) —— 所以 skills/ 里的模块一样能起定时器、拿到 sender
//   3. lintKindPlacement 对"放错目录"只**告警**不阻断（原文："能用，但语义混乱"）
//
// 反过来，拆成两个条目的代价是实打实的：市场把技能与插件放在两个独立页面
// （skill-market / plugin-market），每条目一个口令。于是"订阅推送"必须 import
// 另一个条目里的接口层 —— 用户只装其中一个就会拿到一个用不了的东西。
//
// 合并后：一个条目、一个口令、一次安装，查询与订阅都在里面。
//
// ── 与查询侧的分工 ────────────────────────────────────────────────────────
//   index.js   注册查询工具 bili_dynamic（模型按需调用）
//   本文件     注册订阅工具 + 后台轮询定时器（确定性，不经过模型）
//   两者共用同目录的 lib/，不存在跨条目依赖。
//
// ── 推送为什么必须走核心 sender ───────────────────────────────────────────
// 走核心统一发送管道才能获得：每会话串行化、真人化间隔、分钟/小时限频、内容去重、
// 超长切分、CQ 转义，以及**留档**（发出的消息进 ChatStore，机器人下一轮能看到
// "自己说过这句"）。自己调 OneBot HTTP 会绕过全部这些。
// sender 由 app.js 的 reloadSkills 通过 activate(ctx) 注入。

import fs from 'node:fs';
import path from 'node:path';
import { createHttp } from './lib/http.mjs';
import { fetchDynamics } from './lib/bili-api.mjs';

const MIN_INTERVAL_MS = 2000;

// ── 模块级运行态 ──────────────────────────────────────────────────────────
// 前缀 sub 是为了与 index.js 的状态区分（两者同处一个技能目录，但各自独立）
let subApi = null;
let cfg = () => ({});
let log = () => {};
let warn = () => {};

let store = null;
let sender = null;
let pollTimer = null;
let firstTimer = null;
let polling = false;
let http = null;
let injectedHttp = null;   // 测试注入（见 __testInject）
let httpFingerprint = '';
let dirty = false;

/**
 * 接口层绑定。生产路径直接用本技能 lib/ 里的真实实现；测试可整体替换
 * （见 __testInject 的 lib 参数），这样"判定与去重"的逻辑能在不联网的情况下验证。
 */
let lib = {
  createHttp,
  fetchDynamics,
  /** 确保拿到浏览器指纹 Cookie（动态接口没它会返回 -412）。 */
  ensureFingerprint: (h) => h.ensureFingerprint()
};

// ── 订阅存储 ──────────────────────────────────────────────────────────────

/**
 * 订阅存储。
 *
 * 一条订阅 = 一个会话的一个 UP 主：
 *   { chatKey, kind, chatId, mid, name, watermark, initialized, addedAt, addedBy }
 *
 * ⚠️ 落盘位置在技能目录**之外**：加载器对 skills/ 做递归 fs.watch 热重载，
 *    往技能目录写文件会每次轮询都触发一次热重载（并清掉运行态）。
 */
export class SubStore {
  constructor(file) {
    this.file = file;
    this.subs = this.#load();
  }

  #load() {
    try {
      const parsed = JSON.parse(fs.readFileSync(this.file, 'utf8'));
      if (Array.isArray(parsed?.subs)) return parsed.subs.filter((s) => s && s.chatKey && s.mid);
    } catch { /* 首次运行或文件损坏 */ }
    return [];
  }

  save() {
    try {
      fs.mkdirSync(path.dirname(this.file), { recursive: true });
      const tmp = `${this.file}.${process.pid}.tmp`;
      fs.writeFileSync(tmp, JSON.stringify({ version: 1, subs: this.subs }, null, 1), 'utf8');
      fs.renameSync(tmp, this.file);
      return true;
    } catch (error) {
      warn(`订阅数据落盘失败（内存中仍然有效，但重启会丢）：${error?.message ?? error}`);
      return false;
    }
  }

  all() { return this.subs; }
  ofChat(chatKey) { return this.subs.filter((s) => s.chatKey === chatKey); }
  find(chatKey, mid) {
    return this.subs.find((s) => s.chatKey === chatKey && String(s.mid) === String(mid)) || null;
  }
  countByMid(mid) { return this.subs.filter((s) => String(s.mid) === String(mid)).length; }

  add(entry) { this.subs.push(entry); this.save(); return entry; }

  remove(chatKey, mid) {
    const before = this.subs.length;
    this.subs = this.subs.filter((s) => !(s.chatKey === chatKey && String(s.mid) === String(mid)));
    if (this.subs.length < before) { this.save(); return true; }
    return false;
  }

  /** 更新水位（不立即落盘；由 flushIfDirty 批量写，避免每条动态一次 IO）。 */
  setWatermark(chatKey, mid, watermark, initialized = null) {
    const s = this.find(chatKey, mid);
    if (!s) return false;
    if (watermark) s.watermark = String(watermark);
    if (initialized !== null) s.initialized = Boolean(initialized);
    s.updatedAt = Date.now();
    dirty = true;
    return true;
  }
}

function flushIfDirty(force = false) {
  if (!store) return;
  if (!dirty && !force) return;
  dirty = false;
  store.save();
}

// ── 配置与请求器 ──────────────────────────────────────────────────────────

function fingerprintOf(c) {
  return [c.cookie, c.sessdata, c.timeoutMs, c.minIntervalMs].join('|');
}

function ensureHttp() {
  if (injectedHttp) return injectedHttp;
  const c = cfg() || {};
  const fp = fingerprintOf(c);
  if (http && fp === httpFingerprint) return http;
  http = lib.createHttp({
    // 权限声明了 web_fetch 才会拿到真实 fetch（skill.json 里有 permissions: ["web_fetch"]）
    fetchImpl: subApi.fetch,
    cookie: c.cookie,
    sessdata: c.sessdata,
    userAgent: c.userAgent,
    minIntervalMs: Math.max(MIN_INTERVAL_MS, Number(c.minIntervalMs) || MIN_INTERVAL_MS),
    timeoutMs: Math.max(3000, Number(c.timeoutMs) || 15000),
    log: (m) => { if (c.verboseLog) log(m); }
  });
  httpFingerprint = fp;
  return http;
}

/** 用 BigInt 比较动态 ID（雪花号超过 2^53，用 Number 比会得出错误大小关系）。 */
export function compareId(a, b) {
  try {
    const x = BigInt(String(a || '0'));
    const y = BigInt(String(b || '0'));
    return x < y ? -1 : (x > y ? 1 : 0);
  } catch {
    return String(a) < String(b) ? -1 : (String(a) > String(b) ? 1 : 0);
  }
}

/**
 * 从动态列表里挑出需要推送的那些。
 *   · 只取 ID 大于水位线的 —— 去重的唯一依据
 *   · **跳过置顶动态**：置顶那条 ID 很大（发布很久仍排在列表最前），
 *     不排除它就会每轮都重推一遍
 *   · 按时间正序返回，符合时间线阅读
 */
export function pickNew(items = [], watermark = '') {
  const fresh = items.filter((d) => {
    if (!d?.id) return false;
    if (d.pinned) return false;
    if (!watermark) return true;
    return compareId(d.id, watermark) > 0;
  });
  return fresh.sort((a, b) => (a.pubTs || 0) - (b.pubTs || 0));
}

/** 取列表里最大的（非置顶）动态 ID，用作水位。 */
export function maxId(items = []) {
  let best = '';
  for (const d of items) {
    if (!d?.id || d.pinned) continue;
    if (!best || compareId(d.id, best) > 0) best = String(d.id);
  }
  return best;
}

/** 渲染一条推送文本：UP 名 + 内容 + 链接，三行以内。 */
export function formatPush(d, { name = '', withStats = false } = {}) {
  const who = name || d?.author?.name || '订阅的 UP 主';
  const lines = [`📺 ${who} 发布了新动态（${d.pubTime || ''}）`];

  const title = d.videoTitle || '';
  if (title) {
    const dur = d.media?.find?.((m) => m.kind === 'video')?.duration;
    lines.push(`【${d.typeLabel}】${title}${dur ? `（${dur}）` : ''}`);
  } else if (d.text) {
    const t = d.text.replace(/\s+/g, ' ').trim();
    lines.push(`【${d.typeLabel}】${t.length > 80 ? `${t.slice(0, 80)}…` : t}`);
  } else {
    lines.push(`【${d.typeLabel}】`);
  }

  if (withStats) {
    lines.push(`👍 ${d.stats?.like ?? 0}　💬 ${d.stats?.comment ?? 0}　🔁 ${d.stats?.forward ?? 0}`);
  }
  const url = d.bvid ? `https://www.bilibili.com/video/${d.bvid}` : d.url;
  if (url) lines.push(url);
  return lines.join('\n');
}

// ── 轮询 ──────────────────────────────────────────────────────────────────

/**
 * 跑一轮轮询。可单独调用（测试与"订阅后立刻初始化水位"都用它）。
 *
 * @param {{ only?: {chatKey, mid}, silent?: boolean, send?: Function }} [opts]
 */
export async function pollOnce(opts = {}) {
  const { only = null, silent = false, send = null } = opts;
  const out = { checked: 0, pushed: 0, failed: 0, details: [] };
  if (!store) return out;

  const c = cfg() || {};
  const verbose = Boolean(c.verboseLog);
  const maxPush = Math.max(1, Number(c.maxPushPerTick) || 3);
  const withStats = String(c.pushFormat || '') === '带互动数据';

  // 按 mid 归并：同一 UP 主被多个会话订阅时只请求一次接口，然后分发。
  // 这是"多个群订阅同一个人"场景下最省请求的做法（也最不容易触发风控）。
  const targets = new Map();
  const list = only ? [store.find(only.chatKey, only.mid)].filter(Boolean) : store.all();
  for (const s of list) {
    if (!targets.has(String(s.mid))) targets.set(String(s.mid), { mid: String(s.mid), subs: [] });
    targets.get(String(s.mid)).subs.push(s);
  }

  for (const { mid, subs } of targets.values()) {
    out.checked++;
    let feed;
    try {
      feed = await lib.fetchDynamics({ mid, http: ensureHttp(), log: verbose ? log : () => {} });
    } catch (error) {
      // 单条订阅失败绝不能中断整轮：否则一个失效的订阅会把其他所有人的推送拖死
      warn(`轮询 UID ${mid} 异常，本轮跳过：${error?.message ?? error}`);
      out.failed++;
      out.details.push({ mid, ok: false, error: String(error?.message ?? error) });
      continue;
    }

    // 空结果与风控：不更新水位、不推送，下一轮再试。
    // ⚠️ 这里必须原样保留水位 —— 把"取不到数据"误当成"没有新动态"还算无害，
    //    但若因此重置水位就会漏推；不动它才是最安全的。
    if (!feed.ok || feed.emptySuspect) {
      const why = feed.error || '返回空列表';
      if (verbose) log(`UID ${mid} 本轮未取到数据（${why}），保持水位不变`);
      out.failed++;
      out.details.push({ mid, ok: false, error: why, emptySuspect: Boolean(feed.emptySuspect) });
      continue;
    }

    const items = feed.items || [];
    const newest = maxId(items);

    for (const sub of subs) {
      // 首次：只记水位，不推历史（避免订阅瞬间被历史动态刷屏）
      if (!sub.initialized || !sub.watermark) {
        if (newest) store.setWatermark(sub.chatKey, sub.mid, newest, true);
        if (verbose) log(`UID ${mid} 完成首次水位初始化（水位 ${newest || '空'}），不推送历史动态`);
        out.details.push({ mid, chatKey: sub.chatKey, ok: true, initialized: true });
        continue;
      }

      const fresh = pickNew(items, sub.watermark);
      if (!fresh.length) continue;

      if (silent) {
        if (newest) store.setWatermark(sub.chatKey, sub.mid, newest, true);
        continue;
      }

      // 一次更新太多条：只推最新的 maxPush 条，但水位要推到最新 ——
      // 否则下一轮又会把这次没推的旧动态当成"新"再推一遍。
      const toPush = fresh.slice(-maxPush);
      const sendFn = send || defaultSend;
      let sentOk = false;
      for (const d of toPush) {
        try {
          await sendFn(sub, formatPush(d, { name: sub.name, withStats }));
          sentOk = true;
          out.pushed++;
        } catch (error) {
          warn(`推送到 ${sub.chatKey} 失败：${error?.message ?? error}`);
          out.failed++;
          sentOk = false;
          break;
        }
      }

      // ⚠️ 只有推送成功（或没有要推的）才推进水位。
      //    推送失败而推进水位 = 那条动态永远不会再被推 —— 静默丢消息。
      if (sentOk || !toPush.length) {
        if (newest) store.setWatermark(sub.chatKey, sub.mid, newest, true);
      } else {
        warn(`UID ${mid} → ${sub.chatKey} 推送失败，水位保持不动，下一轮重试`);
      }
      if (verbose) log(`UID ${mid} → ${sub.chatKey} 推送 ${sentOk ? toPush.length : 0} 条（候选 ${fresh.length} 条）`);
      out.details.push({ mid, chatKey: sub.chatKey, ok: sentOk, pushed: sentOk ? toPush.length : 0, candidates: fresh.length });
    }
  }

  flushIfDirty();
  return out;
}

/** 默认发送：走核心统一发送管道（限频 / 去重 / 切分 / 留档）。 */
async function defaultSend(sub, text) {
  if (!sender || typeof sender.sendTextBatch !== 'function') {
    // 拿不到 sender 时**必须**明确失败：静默吞掉会让"订阅了但永远收不到"无从排查。
    // 这曾经是 plugins/affinity 的真实故障形态（activeCtx?.sender 取不到就 return）。
    throw new Error('未拿到核心发送管道（activate 未注入 sender）；请确认内核会把 sender 传给 activate(ctx)');
  }
  await sender.sendTextBatch(sub.chatKey, [text]);
}

// ── 生命周期（由 index.js 转调）───────────────────────────────────────────

/**
 * 初始化。由 skills/bili-dynamic/index.js 在自身的 setup 里调用。
 *
 * @param {object} o
 * @param {object} o.api      技能的 api（用于 registerTool / config / log）
 * @param {string} o.dataFile 订阅数据文件路径（由 index.js 按内核 DATA_DIR 口径算出）
 */
export function setup({ api, dataFile }) {
  subApi = api;
  cfg = api.config;
  log = (...a) => api.log(...a);
  warn = (...a) => api.warn(...a);

  // 重置运行态：热重载时不能沿用旧实例（旧 http 握着旧 Cookie 且闭包捕获旧 api.fetch）
  http = null;
  injectedHttp = null;
  httpFingerprint = '';
  dirty = false;

  try { fs.mkdirSync(path.dirname(dataFile), { recursive: true }); } catch (error) {
    warn(`订阅数据目录创建失败：${error?.message ?? error}`);
  }
  store = new SubStore(dataFile);

  registerTools((def) => api.registerTool(def));
  log(`订阅推送已就绪｜${store.all().length} 条订阅｜轮询间隔 ${cfg().pollIntervalMin || 5} 分钟`);
}

/**
 * 激活：拿到 sender，起轮询定时器。
 *
 * ⚠️ ctx.sender 由 app.js 的 reloadSkills 注入。拿不到时**不要**假装没事 ——
 *    那样订阅会"登记成功但永远不推"。这里明确 warn 一条，推送时还会再抛错一次。
 */
export async function activate(ctx = {}) {
  sender = ctx?.sender || null;
  if (!sender) {
    warn('activate 未拿到 sender：订阅推送无法发送消息。'
      + '（内核需要把 sender 作为 activate 上下文传入，见 src/app.js 的 reloadSkills）');
  } else {
    log('已取得核心发送管道，推送将走统一的限频/去重/切分/留档路径');
  }
  flushIfDirty(true);   // 启动自检：数据文件真的能写吗
  startPolling();
}

export function deactivate() {
  stopPolling();
  flushIfDirty(true);
  sender = null;
  http = null;
  httpFingerprint = '';
  log('订阅推送已停用（轮询已停止，订阅数据已保留）');
}

function startPolling() {
  stopPolling();   // 幂等：重复 activate 不会叠加出两个定时器
  const minutes = Math.max(1, Number(cfg().pollIntervalMin) || 5);
  const intervalMs = minutes * 60000;

  const tick = async () => {
    if (polling) {
      // 上一轮还没跑完（订阅多、网络慢、正在退避重试）→ 跳过本轮而不是叠加
      if (cfg().verboseLog) log('上一轮轮询尚未结束，跳过本轮');
      return;
    }
    polling = true;
    try {
      const r = await pollOnce();
      if (r.pushed && cfg().verboseLog) log(`轮询完成：检查 ${r.checked} 个 UP 主，推送 ${r.pushed} 条，失败 ${r.failed} 个`);
    } catch (error) {
      // 轮询异常绝不能把定时器打断：否则一次网络故障就永久停止推送
      warn(`轮询异常（定时器继续运行）：${error?.message ?? error}`);
    } finally {
      polling = false;
    }
  };

  pollTimer = setInterval(() => { tick().catch(() => {}); }, intervalMs);
  // unref 让轮询定时器不阻止进程退出。这里用 unref 是对的 ——
  // 与 lib/http.mjs 里"请求超时定时器"的情况正好相反（那个绝不能 unref，
  // 否则事件循环一空就退出，请求会永久挂起）。
  if (typeof pollTimer?.unref === 'function') pollTimer.unref();

  // 启动后 20 秒跑第一轮：等网络与 OneBot 连接就绪，避免开机瞬间必然失败一次
  firstTimer = setTimeout(() => { tick().catch(() => {}); }, 20000);
  if (typeof firstTimer?.unref === 'function') firstTimer.unref();
}

function stopPolling() {
  if (pollTimer) { clearInterval(pollTimer); pollTimer = null; }
  if (firstTimer) { clearTimeout(firstTimer); firstTimer = null; }
}

/** 供 index.js 的 dispose 调用：释放全部模块态。 */
export function dispose() {
  stopPolling();
  flushIfDirty(true);
  store = null;
  sender = null;
  http = null;
  injectedHttp = null;
  subApi = null;
  cfg = () => ({});
  log = () => {};
  warn = () => {};
}

/**
 * 仅供测试：注入 store / cfg / log / warn / http。
 *
 * 为什么需要这个口子：pollOnce 的职责是**判定与去重**，那部分必须能在不联网、
 * 不落盘、不启动定时器的情况下验证。把 lib 依赖改成参数传递会让三个工具的调用点
 * 全部变啰嗦，所以留一个显式的测试注入口。
 */
export function __testInject({ store: s, cfg: c, log: lg, warn: wn, http: h, lib: l } = {}) {
  if (s !== undefined) store = s;
  if (c !== undefined) cfg = c;
  if (lg !== undefined) log = lg;
  if (wn !== undefined) warn = wn;
  // 注入 http 后 ensureHttp 直接沿用，不再去碰 subApi.fetch
  if (h !== undefined) { injectedHttp = h; httpFingerprint = '__injected__'; }
  // 注入 lib 可替换 fetchDynamics，让判定逻辑不联网可测
  if (l !== undefined) lib = l;
}

/** 供测试观察：当前是否已有轮询定时器。 */
export function __hasTimer() {
  return Boolean(pollTimer || firstTimer);
}

// ── 工具 ──────────────────────────────────────────────────────────────────

/** 把工具上下文变成推送目标。 */
function targetOf(ctx) {
  const chatKey = String(ctx?.chatKey ?? '').trim();
  if (!chatKey) return null;
  const [kind, chatId] = chatKey.split(':');
  return { chatKey, kind: kind || 'group', chatId: chatId || '' };
}

function registerTools(register) {
  register({
    id: 'subscribe',
    name: '订阅B站UP主动态',
    description: '订阅一个 B站 UP 主：插件会在后台定时检查其动态，一有新动态就自动发到当前会话。mid 与 name 都要提供（mid 用于请求，name 用于推送显示）。首次订阅不会推送历史动态，只从此刻开始跟踪。',
    category: 'query',
    icon: '🔔',
    parameters: {
      type: 'object',
      properties: {
        mid: { type: 'string', description: 'UP 主的 UID（纯数字）。可先用 bili_dynamic 搜昵称拿到。' },
        name: { type: 'string', description: 'UP 主昵称，用于推送消息里显示是谁更新了。' }
      },
      required: ['mid']
    },
    execute: async (ctx, args = {}) => {
      try {
        const target = targetOf(ctx);
        if (!target) return { content: '订阅失败：拿不到当前会话标识。', isError: true };
        const mid = String(args.mid ?? '').trim();
        if (!/^\d{3,}$/.test(mid)) {
          return { content: `订阅失败：UID 不合法（${mid || '空'}）。请先用 bili_dynamic 按昵称搜出 UID。`, isError: true };
        }
        const name = String(args.name ?? '').trim() || `UID ${mid}`;

        if (store.find(target.chatKey, mid)) {
          return { content: `这个会话已经订阅过「${name}」（UID ${mid}）了，无需重复订阅。` };
        }
        const maxSubs = Math.max(1, Number(cfg().maxSubs) || 10);
        if (store.all().length >= maxSubs) {
          return { content: `订阅失败：已达上限（${maxSubs} 条，含其他会话的订阅）。请先用 unsubscribe 取消一个不再需要的。`, isError: true };
        }

        store.add({
          chatKey: target.chatKey, kind: target.kind, chatId: target.chatId,
          mid, name, watermark: '', initialized: false,
          addedAt: Date.now(), addedBy: String(ctx?.selfId || '')
        });

        // 立刻初始化水位（只记不推）。做这一步而不是等下一轮，是为了让"订阅时刻"
        // 成为明确的分界线：之后的才算新动态。
        polling = true;
        let initNote = '';
        try {
          const r = await pollOnce({ only: { chatKey: target.chatKey, mid }, silent: true });
          const detail = r.details.find((d) => d.chatKey === target.chatKey && d.mid === mid);
          initNote = detail?.ok ? '' : `（注意：暂时没能读到该 UP 主的动态${detail?.error ? `：${detail.error}` : ''}，插件会在下一轮自动重试）`;
        } catch (error) {
          initNote = `（注意：初始化时出错：${error?.message ?? error}，插件会在下一轮自动重试）`;
        } finally {
          polling = false;
        }

        const minutes = Math.max(1, Number(cfg().pollIntervalMin) || 5);
        return {
          content: `已订阅「${name}」（UID ${mid}）。每 ${minutes} 分钟检查一次，有新动态会自动发到本会话。\n`
            + `注意：刚订阅时不会把已有的历史动态发出来，只从此刻开始跟踪。${initNote}`
        };
      } catch (error) {
        return { content: `订阅时出错：${error?.message ?? error}`, isError: true };
      }
    }
  });

  register({
    id: 'unsubscribe',
    name: '取消B站动态订阅',
    description: '取消当前会话对某个 B站 UP 主的动态订阅，之后不再推送。mid 传 UID；不确定订了哪些可以先用 list_subscriptions 查。',
    category: 'query',
    icon: '🔕',
    parameters: {
      type: 'object',
      properties: {
        mid: { type: 'string', description: '要取消订阅的 UP 主 UID（纯数字）。' }
      },
      required: ['mid']
    },
    execute: async (ctx, args = {}) => {
      try {
        const target = targetOf(ctx);
        if (!target) return { content: '取消失败：拿不到当前会话标识。', isError: true };
        const mid = String(args.mid ?? '').trim();
        if (!mid) return { content: '取消失败：请给出要取消的 UID。', isError: true };
        const hit = store.find(target.chatKey, mid);
        if (!hit) return { content: `本会话没有订阅 UID ${mid}。可以用 list_subscriptions 查看当前订阅了哪些。`, isError: true };
        store.remove(target.chatKey, mid);
        return { content: `已取消对「${hit.name || `UID ${mid}`}」的订阅。` };
      } catch (error) {
        return { content: `取消订阅时出错：${error?.message ?? error}`, isError: true };
      }
    }
  });

  register({
    id: 'list_subscriptions',
    name: '查看B站动态订阅',
    description: '列出当前会话已订阅的 B站 UP 主，含 UID、昵称与跟踪进度。用于回答「订了哪些」或取消前的确认。',
    category: 'query',
    icon: '📋',
    parameters: { type: 'object', properties: {}, required: [] },
    execute: async (ctx) => {
      try {
        const target = targetOf(ctx);
        if (!target) return { content: '拿不到当前会话标识。', isError: true };
        const mine = store.ofChat(target.chatKey);
        if (!mine.length) return { content: '当前会话还没有订阅任何 B站 UP 主。可以说「订阅一下影视飓风」来添加。' };
        const lines = mine.map((s, i) => `${i + 1}. ${s.name || `UID ${s.mid}`}（UID ${s.mid}）${s.initialized ? '｜已开始跟踪' : '｜等待首次检查'}`);
        const minutes = Math.max(1, Number(cfg().pollIntervalMin) || 5);
        return { content: `当前会话订阅了 ${mine.length} 个 UP 主（每 ${minutes} 分钟检查一次）：\n${lines.join('\n')}` };
      } catch (error) {
        return { content: `查询订阅时出错：${error?.message ?? error}`, isError: true };
      }
    }
  });
}
