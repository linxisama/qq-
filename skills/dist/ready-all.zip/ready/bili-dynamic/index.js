// B站 UP 主动态查询 —— LLM 型 Skill（放 skills/）。
//
// ── 这个插件解决什么 ──────────────────────────────────────────────────────
// 群友问「影视飓风最近发什么了」，模型调用本工具拿到真实动态并转述。
// 这是一个**只读查询**工具：不发消息、不改群状态、所有对外动作都由模型决定。
//
// ── 调试这个插件时最该先看的三件事（都是踩过的坑）────────────────────────
//   1. 动态接口**不要**加 WBI 签名。加了签名它返回的 data 是
//      `{total:"0", has_more:false, items:[]}` —— 看起来像"这人没发过动态"。
//      去掉签名才拿到真实数据。签名只用于"按昵称搜人"那个接口。
//   2. `offset` 参数必须出现（可以为空串）。整个省掉时接口也返回 200，
//      但 items 是空的 —— 又一个静默失败。
//   3. `data.total` 恒为 "0"，判断有没有更多必须用 `has_more`。用 total 判断
//      会永远以为没数据、永远不翻页。
//
// ── 为什么访客身份也够用（不需要强制登录）────────────────────────────────
// 实测：先访问一次 https://www.bilibili.com/ 拿到 buvid3 / b_nut 指纹 Cookie，
// 之后不带 SESSDATA 也能读到公开动态（真实拿到 12 条，含标题与播放数据）。
// 直接请求动态接口而跳过这一步会得到 HTTP 412 `request was banned`。
// 所以 SESSDATA 是"选填的稳定性增强"，不是可用前提 —— 这一点与最初的设计
// 假设相反，是实测纠正过来的。
//
// ── 缓存与限速为什么必须有 ────────────────────────────────────────────────
// 连续快速请求会触发风控（HTTP 200 但 code -352）。群友反复问同一个人是很自然
// 的行为，不做缓存就等于主动把自己打进限流。所以：UID 解析结果落盘长期缓存，
// 动态列表进程内缓存数分钟，两次请求之间强制最小间隔。

import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createHttp } from './lib/http.mjs';
import { searchUser, fetchDynamics } from './lib/bili-api.mjs';
import { renderUserCandidates, renderDynamicList, relativeTime } from './lib/format.mjs';
import { TtlCache, UidResolverCache } from './lib/cache.mjs';
// 订阅推送子模块：同一个技能目录内，不存在跨条目依赖（见 subscribe.mjs 头部说明）
import * as subscribe from './subscribe.mjs';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const APP_ROOT = path.resolve(HERE, '..', '..');

/**
 * 数据目录 —— 与内核 DATA_DIR 的口径保持一致（src/config.js:24）。
 *
 * 优先级：QQ_AGENT_DATA_DIR > data${QQ_AGENT_PROFILE 后缀} > data
 * 不能写死 `<APP_ROOT>/data`：内核支持多实例（PROFILE=2 → `data-2/`）与
 * 数据目录重定向，写死会让本插件的数据落到另一个实例的目录里 —— 订阅数据
 * 串台是真实后果（两个实例互相覆盖订阅），不只是缓存不准。
 *
 * 与内核同源但不 import src/：市场版插件要在标准核心上独立加载得起来，
 * 依赖核心里可能不存在的文件会让插件直接加载失败。
 */
function resolveDataDir() {
  const override = String(process.env.QQ_AGENT_DATA_DIR ?? '').trim();
  if (override) return override;
  const profile = String(process.env.QQ_AGENT_PROFILE ?? '').trim();
  const suffix = /^\d+$/.test(profile) ? `-${profile}` : '';
  return path.join(APP_ROOT, `data${suffix}`);
}

/**
 * 数据目录名固定为 `bili-dynamic`（= 本技能的 id），**不跟随实际目录名**。
 *
 * 为什么：市场安装遇到同名目录冲突时会把落地目录改成 `bili-dynamic_1`
 * （src/zip-install.js 的冲突递增）。若数据目录跟着目录名走，重装一次
 * 订阅数据就全丢了 —— 用户眼里是"插件更新后我的订阅没了"。
 */
const DATA_SUBDIR = 'bili-dynamic';

// ⚠️ 数据落盘位置在技能目录**之外**：插件加载器对 skills/ 与 plugins/ 做
//    fs.watch 递归热重载，往技能目录里写文件 = 每次查询触发一次热重载。
const DATA_DIR = path.join(resolveDataDir(), DATA_SUBDIR);
const UID_CACHE_FILE = path.join(DATA_DIR, 'uid-map.json');
const SUBS_FILE = path.join(DATA_DIR, 'subscriptions.json');

/** 模块级状态（由 setup / deactivate 管理生命周期）。 */
let api = null;
let cfg = () => ({});
let log = () => {};
let warn = () => {};
let http = null;                 // createHttp 实例
let uidCache = null;             // 昵称 → UID 落盘缓存
let feedCache = null;            // UID → 动态列表进程内缓存
let httpFingerprint = '';        // 当前 http 实例对应的配置指纹，配置变了要重建

/** 配置指纹：Cookie / UA / 超时 / 间隔任意一项变化都重建 http 实例。 */
function fingerprintOf(c) {
  return [c.cookie, c.sessdata, c.userAgent, c.timeoutMs, c.minIntervalMs].join('|');
}

/** 按当前配置取（必要时重建）请求器。 */
function ensureHttp() {
  const c = cfg() || {};
  const fp = fingerprintOf(c);
  if (http && fp === httpFingerprint) return http;

  http = createHttp({
    // 权限声明了 web_fetch 才会拿到真实 fetch；没声明时 api.fetch 会 reject，
    // 那种情况下配置页会显示加载失败原因，而不是运行时才炸。
    fetchImpl: api.fetch,
    cookie: c.cookie,
    sessdata: c.sessdata,
    userAgent: c.userAgent,
    minIntervalMs: Math.max(300, Number(c.minIntervalMs) || 1500),
    timeoutMs: Math.max(3000, Number(c.timeoutMs) || 15000),
    log: (m) => { if (c.verboseLog) log(m); }
  });
  httpFingerprint = fp;
  log(`请求器已重建（登录态：${http.hasLogin ? '已提供 Cookie' : '访客'}）`);
  return http;
}

/** 按当前配置取（必要时重建）动态列表缓存 —— TTL 可在设置里改，要跟着变。 */
function ensureFeedCache() {
  const ttlSec = Number(cfg().feedCacheTtlSec);
  const ttlMs = Number.isFinite(ttlSec) ? Math.max(0, ttlSec) * 1000 : 300000;
  if (!feedCache || feedCache.ttlMs !== ttlMs) {
    feedCache = new TtlCache({ ttlMs, max: 100 });
    if (ttlMs > 0) log(`动态列表缓存已就绪：TTL ${Math.round(ttlMs / 1000)} 秒`);
  }
  return feedCache;
}

/**
 * 把用户输入（昵称或 UID）解析成确定的 UP 主 { mid, name }。
 * 优先级：落盘缓存 → 纯数字直通 → 联网搜索。
 *
 * @returns {Promise<{ ok: boolean, up?: object, message?: string }>}
 */
async function resolveUp(query) {
  const q = String(query ?? '').trim();
  if (!q) return { ok: false, message: '没有给出 UP 主昵称或 UID。' };

  // 1) 纯数字：直接当 UID，省掉搜索与签名（这是唯一会失败的环节）
  if (/^\d{3,}$/.test(q)) return { ok: true, up: { mid: q, name: '' } };

  // 2) 落盘缓存
  const cached = uidCache.get(q);
  if (cached) {
    if (cfg().verboseLog) log(`昵称「${q}」命中缓存 → UID ${cached.mid}`);
    return { ok: true, up: { mid: cached.mid, name: cached.name } };
  }

  // 3) 联网搜索
  const r = await searchUser({ keyword: q, http: ensureHttp(), log });
  if (!r.ok) return { ok: false, message: `搜索 UP 主失败：${r.error}${r.hint ? `\n建议：${r.hint}` : ''}` };
  if (!r.users?.length) return { ok: false, message: renderUserCandidates([], q) };

  // 同名多个：把候选全给模型，由它挑或反问群友 —— 不替它拍板
  if (r.users.length > 1) {
    const first = r.users[0];
    // 仍然缓存第一条：模型若决定用第一个，下次就不必再搜（省一次签名请求）
    uidCache.set(q, first);
    if (cfg().verboseLog) log(`昵称「${q}」命中 ${r.users.length} 个候选，首选 ${first.name}(${first.mid})`);
    return { ok: true, up: { mid: first.mid, name: first.name }, candidates: r.users, ambiguous: true };
  }

  const only = r.users[0];
  uidCache.set(q, only);
  return { ok: true, up: { mid: only.mid, name: only.name } };
}

/**
 * 取某个 UID 的动态列表，带缓存与翻页累积。
 *
 * @param {string} mid
 * @param {boolean} nextPage 是否取下一页（在已缓存的列表基础上往后拉）
 */
async function getDynamics(mid, nextPage = false) {
  const c = cfg();
  const useCache = Number(c.feedCacheTtlSec) !== 0;
  const key = `feed:${mid}`;
  const cache = ensureFeedCache();

  let state = useCache ? cache.get(key) : undefined;
  // 需要联网的两种情况：没有缓存，或者要翻页且上次说还有更多。
  // 注意 hasMore === false 时翻页请求直接返回现有缓存 —— 避免明知没有下一页还打接口。
  const needFetch = !state || (nextPage && state.hasMore !== false);

  if (!needFetch) {
    if (c.verboseLog) log(`UID ${mid} 命中动态缓存（${state.items.length} 条）`);
    return { ok: true, items: state.items, hasMore: state.hasMore, fromCache: true };
  }

  if (!state) state = { items: [], offset: '', hasMore: true };

  const r = await fetchDynamics({
    mid,
    http: ensureHttp(),
    offset: state.offset,
    log: c.verboseLog ? log : () => {}
  });

  // "软空"（code 0 但列表为空）已由 fetchDynamics 重试过；重试仍空说明多半是风控。
  // ⚠️ 绝对不能把这个结果写进缓存：那会让"此人没动态"这个**错误结论**固化好几分钟
  //   （缓存 TTL 默认 5 分钟），比多打两次接口糟糕得多。
  if (r.ok && r.emptySuspect) {
    warn(`UID ${mid} 连续 ${r.attempts} 次返回空动态列表，疑似风控软空，本次不缓存`);
    if (state.items.length) {
      return { ok: true, items: state.items, hasMore: false, degraded: true, error: r.error, hinted: r.hinted };
    }
    return { ok: false, error: r.error, hint: r.hint, hinted: r.hinted, transient: true };
  }

  if (!r.ok) {
    // 翻页失败但有旧数据：降级返回旧数据，别让整次查询失败
    if (state.items.length) {
      warn(`UID ${mid} 翻页失败（${r.error}），返回已缓存的 ${state.items.length} 条`);
      return { ok: true, items: state.items, hasMore: false, degraded: true, error: r.error };
    }
    return { ok: false, error: r.error, hint: r.hint, hinted: r.hinted, code: r.rawCode, transient: r.transient };
  }

  // 累积 + 按 id 去重 + 按发布时间倒序：翻页时 B站会重复给置顶动态
  const merged = [...state.items];
  const seen = new Set(merged.map((d) => d.id));
  for (const item of r.items) {
    if (seen.has(item.id)) continue;
    seen.add(item.id);
    merged.push(item);
  }
  merged.sort((a, b) => (b.pubTs || 0) - (a.pubTs || 0));

  const next = { items: merged, offset: r.offset, hasMore: r.hasMore };
  if (useCache) cache.set(key, next);
  if (c.verboseLog) log(`UID ${mid} 已拉取：新增 ${r.items.length} 条，累积 ${merged.length} 条，has_more=${r.hasMore}`);
  return { ok: true, items: merged, hasMore: r.hasMore, fetched: r.items.length };
}

export async function setup(skillApi) {
  api = skillApi;
  cfg = api.config;
  log = (...a) => api.log(...a);
  warn = (...a) => api.warn(...a);

  // ⚠️ 必须先把上一次装载留下的运行态清干净，再重建。
  //    http 实例里握着 Cookie jar 与"指纹已就绪"标记，还闭包捕获了**上一个** api.fetch。
  //    热重载/重扫时若不重置：新配置的 Cookie 不会生效（jar 是旧的），指纹不会重取，
  //    更糟的是网络走的是已经失效的旧 fetch —— 表现为"设置改了、插件页也显示已保存，
  //    但行为完全没变"，极难排查。加载器虽然会先调 deactivate，但 setup 自身也必须
  //    是幂等且自洽的，不能依赖调用方的顺序。
  http = null;
  httpFingerprint = '';
  feedCache = null;

  try {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  } catch (error) {
    // 目录建不出来只影响"昵称缓存"，查询本身仍可用
    warn(`数据目录创建失败（昵称缓存将不可用）：${error?.message ?? error}`);
  }
  uidCache = new UidResolverCache({ file: UID_CACHE_FILE, log: (...a) => (cfg().verboseLog ? log(...a) : undefined) });

  api.registerTool({
    id: 'bili_dynamic',
    name: '查询B站动态',
    description: '查询 B站 UP 主的最新动态（视频投稿、图文、转发）。输入昵称或 UID，返回该 UP 主最近发布的动态列表，含发布日期、正文摘要、视频标题与链接、点赞评论转发数。当群友问某个 UP 主最近发了什么、更新了没有时使用。',
    category: 'web',
    icon: '📺',
    parameters: {
      type: 'object',
      properties: {
        query: {
          type: 'string',
          description: 'UP 主昵称（如「影视飓风」）或纯数字 UID。昵称会先联网搜索，重名时会返回多个候选。'
        },
        limit: {
          type: 'integer',
          description: '返回多少条动态，1~20，默认取插件设置里的值（通常是 8）。注意每条动态正文较长，不要设太大。',
          minimum: 1,
          maximum: 20
        },
        cursor: {
          type: 'string',
          description: '翻页游标。想知道更早的动态时传 "next"，会在上一次结果基础上继续往后拉；默认从头开始。',
          enum: ['next']
        },
        videosOnly: {
          type: 'boolean',
          description: '只关心视频投稿时设为 true（过滤掉纯转发、纯文字动态）。'
        }
      },
      required: ['query']
    },
    execute: async (_ctx, args = {}) => {
      const started = Date.now();
      try {
        const query = String(args.query ?? '').trim();
        const c = cfg();
        const limit = Math.min(
          20,
          Math.max(1, Number(args.limit) || Number(c.maxItems) || 8)
        );
        const nextPage = String(args.cursor ?? '').trim().toLowerCase() === 'next';

        const resolved = await resolveUp(query);
        if (!resolved.ok) return { content: resolved.message, isError: true };

        // 重名：把候选摊开让模型判断。同时**仍然**附上首选的结果 ——
        // 否则模型要么多调一轮工具，要么只能干等群友回答。
        const { up, candidates, ambiguous } = resolved;
        const feed = await getDynamics(up.mid, nextPage);
        if (!feed.ok) {
          const parts = [`查询失败：${feed.error}`];
          if (feed.hint) parts.push(`建议：${feed.hint}`);
          if (feed.hinted) {
            // 明确告诉模型"这可能是风控而不是真的没动态"，否则它会对群友说
            // "这个 UP 主没发过动态" —— 一个由限流造成的错误事实。
            parts.push(`补充：${feed.hinted}`);
          }
          if (feed.transient) {
            parts.push('请告诉群友是暂时查不到、稍后再试；**不要**说这个人没发过动态，也**不要**编造内容。');
          }
          if (feed.code === -352 || feed.code === -412) {
            parts.push('（这是 B站的风控提示。插件已自动退避重试过，仍未通过；可以在插件设置里填 SESSDATA 提高稳定性。）');
          }
          return { content: parts.join('\n'), isError: true };
        }

        // 动态列表里作者名是权威的（比搜索到的 uname 更可靠）
        const authorName = feed.items[0]?.author?.name || up.name || `UID ${up.mid}`;
        const body = renderDynamicList(feed.items, {
          authorName,
          mid: up.mid,
          limit,
          onlyVideos: args.videosOnly === true
        });

        const head = [];
        head.push(`【UP主】${authorName}（UID ${up.mid}）`);
        head.push(`【链接】https://space.bilibili.com/${up.mid}/dynamic`);
        if (ambiguous && candidates?.length) {
          head.push(renderUserCandidates(candidates, query));
          head.push('⚠️ 上面是全部同名候选。若群友问的不是粉丝数最多的那个，请按 UID 重新查询或向群友确认。');
        }
        if (feed.items.length) {
          const newest = feed.items.reduce((a, b) => ((a.pubTs || 0) > (b.pubTs || 0) ? a : b));
          head.push(`【最新动态】${relativeTime(newest.pubTs)}发布（共取到 ${feed.items.length} 条）`);
        }
        if (feed.hasMore) head.push('（还有更早的动态：需要时用 cursor="next" 继续取）');
        if (feed.degraded) head.push(`（提示：翻页时遇到「${feed.error}」，以下为已缓存的内容）`);

        const content = `${head.join('\n')}\n\n${body}`;
        if (c.verboseLog) log(`查询完成：「${query}」→ UID ${up.mid}，返回 ${limit} 条，耗时 ${Date.now() - started} ms`);
        return { content };
      } catch (error) {
        const msg = String(error?.message ?? error);
        warn(`查询异常：${msg}`);
        return { content: `查询 B站动态时出错：${msg}`, isError: true };
      }
    }
  });

  // 启动自检：把"能不能用"和"用的是哪种身份"明确写进日志。
  // 不给网络请求（启动阶段不该发请求），只报告配置状态。
  const c = cfg();
  log(`已加载｜身份：${c.cookie || c.sessdata ? '已配置 Cookie' : '访客（可读公开动态）'}｜`
    + `单次最多 ${c.maxItems || 8} 条｜缓存 ${c.feedCacheTtlSec ?? 300} 秒｜`
    + `昵称缓存 ${uidCache.size} 条`);

  // 订阅推送子模块：注册 3 个工具 + 建立订阅存储。
  // 定时器在 activate 里起（那时才拿得到 sender）。
  try {
    subscribe.setup({ api, dataFile: SUBS_FILE });
  } catch (error) {
    // 订阅侧挂掉不该连带查询侧不可用 —— 两者是独立能力
    warn(`订阅推送初始化失败（查询功能不受影响）：${error?.message ?? error}`);
  }
}

/**
 * 激活：拿 sender 并启动订阅轮询。
 *
 * ⚠️ 这是本技能既是"LLM 型"又能做"确定性定时"的关键 —— 加载器对 skills/ 与
 *    plugins/ 一视同仁地调 activate(ctx)（见 src/app.js 的 reloadSkills）。
 *    ctx.sender 由那里注入；拿不到时 subscribe 会明确告警而不是静默空转。
 */
export async function activate(ctx = {}) {
  try {
    await subscribe.activate(ctx);
  } catch (error) {
    warn(`订阅轮询启动失败（查询功能不受影响）：${error?.message ?? error}`);
  }
}

/** 停用：清掉内存缓存与请求器；订阅侧停止轮询（落盘数据保留）。 */
export async function deactivate() {
  try { subscribe.deactivate(); } catch (error) { warn(`订阅停用出错：${error?.message ?? error}`); }
  feedCache?.clear();
  feedCache = null;
  http = null;
  httpFingerprint = '';
  log('已停用（内存缓存已清空，订阅数据已保留）');
}

/**
 * 释放全部模块态（热重载/卸载时由加载器调用）。
 * 与 deactivate 的区别：连 api 引用也放开，避免卸载后仍持有宿主对象。
 */
export function dispose() {
  try { subscribe.dispose(); } catch { /* 卸载路径不该抛错 */ }
  feedCache?.clear();
  feedCache = null;
  http = null;
  httpFingerprint = '';
  api = null;
  cfg = () => ({});
  log = () => {};
  warn = () => {};
}
