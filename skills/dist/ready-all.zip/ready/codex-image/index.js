import fs from 'node:fs';
import fsp from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { randomUUID } from 'node:crypto';
// QQAgent cache-busts the entry only. Version every local edge in the dependency graph as well.
import { settings, safeError, createTransport, CodexClient, atomicJson, imageMime } from './core.js?release=1.0.0-public.1';
import { loadReference } from './reference.js?release=1.0.0-public.1';

const skillDir=path.dirname(fileURLToPath(import.meta.url));
let config=()=>({});
let fetcher=globalThis.fetch;
let enabled=false;
const running=new Set();
let refreshGate=Promise.resolve();

function cacheRoot() {
  const appRoot=path.resolve(skillDir,'../..');
  const installRoot=path.basename(path.dirname(appRoot))==='resources' ? path.resolve(appRoot,'../..') : appRoot;
  const profile=String(process.env.QQ_AGENT_PROFILE || '').trim();
  const dataDir=process.env.QQ_AGENT_DATA_DIR || path.join(installRoot,`data${profile && profile!=='1'?'-'+profile:''}`);
  return path.join(dataDir,'codex-image');
}

export function activate() { enabled=true; }
export function deactivate() {
  enabled=false;
  for(const controller of running) controller.abort(new Error('技能已停用或重新加载；若请求已提交，生成可能仍在继续，不要立即重试'));
}
export function dispose() { deactivate(); }

export function available() {
  try {
    const cfg=settings(config());
    const stat=fs.statSync(cfg.authFile);
    if(!stat.isFile() || stat.size>131072) throw new Error('登录文件大小或格式异常');
    const auth=JSON.parse(fs.readFileSync(cfg.authFile,'utf8').replace(/^\uFEFF/,''));
    if(auth.auth_mode==='apikey' || !(auth.tokens || auth).access_token) return {ok:false,reason:'请在官方 Codex 中使用 ChatGPT 登录；不支持 API Key 模式'};
    return {ok:true};
  } catch(error) { return {ok:false,reason:error.code==='ENOENT'?'未找到本机 Codex 登录文件，请先在官方 Codex 中登录 ChatGPT':safeError(error)}; }
}

export function promptSections() {
  if(!enabled || !available().ok) return [];
  return [{id:'codex-image-routing',title:'Codex 生图',priority:45,content:
    '用户明确要求画图、生成图片或设计画面时，优先使用 codex-image__gen；基于聊天中的参考图片修改时使用 codex-image__edit。每次只生成一张，消耗用户的 Codex 用量。'
    +'用户提供完整提示词或要求原样提交时，prompt 必须逐字保留，不翻译、不润色、不增加风格。普通短请求可整理为简洁画面描述。'
    +'不要为闲聊主动生成图片。参考图必须来自当前聊天真实消息；指代不清时先确认。'
    +'工具直接把图片发到当前聊天，不要重复发送；没有查看图片时不要编造画面细节。'
    +'超时、断连或发送失败都不要自动重新生成。工具返回缓存任务 ID 时，用户要求重发才用 resend，禁止用 gen 代替重发。'}];
}

export function setup(api) {
  deactivate();
  config=api.config || (()=>({}));
  fetcher=api.fetch || globalThis.fetch;
  enabled=true;
  const common={prompt:{type:'string',minLength:1,maxLength:12000,description:'实际提交给图像接口的提示词。用户要求原样提交时逐字保留。'},size:{type:'string',description:'可选 auto 或 宽x高，省略使用技能默认尺寸'}};
  api.registerTool({id:'gen',name:'Codex 文生图',category:'media',icon:'🎨',description:'用户明确要求从文字生成图片时调用。使用当前电脑登录的 Codex 账号，一次生成一张，并直接发送到当前聊天。',parameters:{type:'object',properties:common,required:['prompt']},execute:(ctx,args)=>execute('generate',ctx,args)});
  api.registerTool({id:'edit',name:'Codex 改图',category:'media',icon:'🖌️',description:'用户要求修改或参考当前聊天中的图片时调用。messageId 必须是真实消息 id；省略时取当前触发消息或最近图片。结果直接发回。',parameters:{type:'object',properties:{...common,messageId:{type:['string','integer'],description:'当前聊天中真实带图消息 id'},imageIndex:{type:'integer',minimum:1,maximum:100,description:'消息中第几张图，默认 1'}},required:['prompt']},execute:(ctx,args)=>execute('edit',ctx,args)});
  api.registerTool({id:'resend',name:'重发 Codex 图片',category:'media',icon:'📨',description:'仅当用户要求重发已生成图片时调用。使用之前工具返回的 taskId，只能发送当前聊天的缓存图片，不产生新的生图请求。',parameters:{type:'object',properties:{taskId:{type:'string',description:'之前生图工具返回的缓存任务 UUID'}},required:['taskId']},execute:resend});
}

function checkContext(ctx) {
  if(!enabled) throw new Error('技能未启用');
  if(!ctx?.chatKey || typeof ctx?.sender?.sendImage!=='function') throw new Error('当前会话没有图片发送器');
  if(['aborted','error','done','noreply'].includes(ctx.session?.status)) throw new Error('当前会话已结束');
}

async function sendCached(ctx,file,mime) {
  checkContext(ctx);
  const stat=await fsp.stat(file);
  const cfg=settings(config());
  if(!stat.isFile() || stat.size>cfg.maxImageBytes) throw new Error('缓存图片不存在或超过体积上限');
  const buffer=await fsp.readFile(file);
  if(imageMime(buffer)!==mime) throw new Error('缓存图片格式异常');
  const before=ctx.session?.sent?.length;
  const receipt=await ctx.sender.sendImage(ctx.chatKey,{file,dataUrl:'base64://'+buffer.toString('base64')},{note:'Codex 生图'});
  if(Array.isArray(ctx.session?.sent) && ctx.session.sent.length===before) ctx.session.sent.push({type:'image',text:'[图片:Codex生图]',messageId:receipt?.message_id ?? null,at:new Date().toLocaleTimeString('zh-CN',{hour12:false})});
  try { ctx.emit?.('session-update',ctx.session?.id); } catch {}
}

async function execute(mode,ctx,args) {
  let controller,transport,interval,timer,journal,file,submitted=false;
  try {
    checkContext(ctx);
    if(running.size) throw new Error('已有一个 Codex 生图任务正在进行，请等它完成，不要重复提交');
    const cfg=settings(config());
    const current=available(); if(!current.ok) throw new Error(current.reason);
    controller=new AbortController(); running.add(controller);
    interval=setInterval(()=>{try {checkContext(ctx);}catch(error){controller.abort(error);}},500);
    timer=setTimeout(()=>controller.abort(new Error('生图请求超时；服务端可能仍在生成，不自动重新提交')),cfg.timeoutMs);
    transport=createTransport(fetcher,cfg);
    await transport.prepare();
    const client=new CodexClient(cfg,transport);
    // Serialize token refresh across all instances of this module generation.
    const originalRefresh=client.refreshAuth.bind(client);
    client.refreshAuth=(...params)=>{ const work=refreshGate.then(()=>originalRefresh(...params)); refreshGate=work.catch(()=>{}); return work; };
    const reference=mode==='edit'?await loadReference(ctx,args,cfg,(...params)=>transport.request(...params),controller.signal):undefined;
    const id=randomUUID(); const dir=path.join(cacheRoot(),id); file=path.join(dir,'task.json');
    journal={id,chatKey:String(ctx.chatKey),operation:mode,status:'prepared',createdAt:new Date().toISOString(),prompt:args.prompt,size:args.size || cfg.size,quality:cfg.quality,requestedModel:cfg.model,serverReportedModel:null,reference:!!reference};
    await atomicJson(file,journal);
    const image=await client.generate({prompt:args.prompt,size:args.size,reference,signal:controller.signal,onAccepted:async()=>{journal.status='submitting';await atomicJson(file,journal);submitted=true;}});
    const ext=image.mime==='image/jpeg'?'jpg':image.mime.split('/')[1];
    const imageFile=path.join(dir,'image.'+ext);
    await fsp.writeFile(imageFile,image.buffer,{flag:'wx'});
    Object.assign(journal,{status:'generated',image:'image.'+ext,mime:image.mime,usage:image.usage,revisedPrompt:image.revisedPrompt,serverReportedModel:image.serverReportedModel,responseMetadata:image.responseMetadata,network:image.network});
    await atomicJson(file,journal);
    controller.signal.throwIfAborted();
    await sendCached(ctx,imageFile,image.mime);
    journal.status='sent'; journal.sentAt=new Date().toISOString();
    await atomicJson(file,journal).catch(()=>{});
    return {content:`已生成并发送 1 张图片。请求模型：${cfg.model}。服务端模型标识：${image.serverReportedModel || '未返回，不能据请求参数确认实际版本'}。缓存任务 ID：${id}。无需再次发送；未查看图片时不要描述画面。使用 Codex 通道，实际额度以官方用量页面为准。`};
  } catch(error) {
    const message=safeError(controller?.signal.aborted?controller.signal.reason:error);
    if(journal) { journal.error=message; if(!['generated','sent'].includes(journal.status)) journal.status=submitted?'request_outcome_unknown':'failed_before_submit'; await atomicJson(file,journal).catch(()=>{}); }
    return {content:`Codex 生图失败：${message}。${submitted?'请求可能已经消耗用量，不要自动重新生成。':''}${journal?.image?`已有缓存图片，任务 ID：${journal.id}，用户要求重发时可调用 resend。`:''}`,isError:true};
  } finally {
    clearInterval(interval); clearTimeout(timer);
    if(transport) await transport.close();
    if(controller) running.delete(controller);
  }
}

async function resend(ctx,args) {
  try {
    checkContext(ctx);
    const id=String(args.taskId || '');
    if(!/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(id)) throw new Error('缓存任务 ID 格式无效');
    const dir=path.join(cacheRoot(),id); const task=JSON.parse(await fsp.readFile(path.join(dir,'task.json'),'utf8'));
    if(task.chatKey!==String(ctx.chatKey)) throw new Error('只能重发当前聊天生成的图片');
    if(!/^image\.(png|jpg|webp)$/.test(task.image || '')) throw new Error('这个任务没有完整缓存图片，不能自动重新生成');
    await sendCached(ctx,path.join(dir,task.image),task.mime);
    return {content:`已重发缓存图片（${id}），没有提交新的生图请求。`};
  } catch(error) { return {content:'缓存重发失败：'+safeError(error),isError:true}; }
}
