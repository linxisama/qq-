import fs from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import { imageMime, limitedBytes } from './core.js?release=1.0.0-public.1';

const mediaOf = message => message?.recalled ? [] : (message?.media || []).filter(item=>item.kind==='image' && (item.url || item.file));

export async function loadReference(ctx,args,config,fetcher,signal) {
  const index=args.imageIndex ?? 1;
  if(!Number.isSafeInteger(index) || index<1 || index>100) throw new Error('imageIndex 应为 1–100 的整数');
  let candidates;
  if(args.messageId!=null && String(args.messageId).trim()) {
    const id=String(args.messageId).trim().replace(/^#/,'');
    if(!/^-?\d+$/.test(id)) throw new Error('请提供真实的 QQ 消息 id');
    const message=await ctx.store?.findByMid?.(ctx.chatKey,id);
    if(!message) throw new Error('当前聊天中找不到指定消息，请重新发送参考图');
    candidates=[message];
  } else {
    const triggers=Array.isArray(ctx.session?.trigger)?ctx.session.trigger:[];
    if(triggers.some(item=>mediaOf(item).length)) candidates=triggers;
    else {
      const recent=await ctx.store?.recent?.(ctx.chatKey,{limit:30}) || [];
      const cutoff=Math.max(0,...triggers.map(x=>Number(x.ts)||0),Number(ctx.session?.startedAt)||0);
      const lastId=Math.max(0,...triggers.map(x=>Number(x.id)||0));
      candidates=recent.filter(x=>lastId && Number(x.id)>0 ? Number(x.id)<=lastId : !cutoff || !Number(x.ts) || Number(x.ts)<=cutoff);
    }
  }
  const message=[...candidates].reverse().find(item=>mediaOf(item).length);
  if(!message) throw new Error('当前聊天最近没有可用参考图，请先发送图片');
  const media=mediaOf(message)[index-1];
  if(!media) throw new Error(`这条消息只有 ${mediaOf(message).length} 张图片`);
  signal?.throwIfAborted();
  const download=async value=>{
    const url=new URL(value);
    // Sources come only from this chat's stored QQ media; never from a model-provided URL.
    if(!['http:','https:'].includes(url.protocol) || url.username || url.password) throw new Error('参考图地址无效');
    const response=await fetcher(url.href,{signal,redirect:'error',headers:{Accept:'image/*'}});
    if(!response.ok) { await response.body?.cancel().catch(()=>{}); throw new Error('参考图链接失效'); }
    return limitedBytes(response,config.maxRefBytes);
  };
  let buffer;
  if(media.url) { try { buffer=await download(media.url); } catch { signal?.throwIfAborted(); } }
  if(!buffer && media.file && typeof ctx.onebot?.call==='function') {
    const info=await ctx.onebot.call('get_image',{file:String(media.file)});
    const result=info?.data || info;
    const source=String(result?.url || result?.file || result?.path || '');
    if(/^https?:\/\//i.test(source)) buffer=await download(source);
    else if(source) {
      const file=/^file:/i.test(source)?fileURLToPath(source):source;
      const handle=await fs.open(file,'r');
      try {
        const stat=await handle.stat();
        if(!stat.isFile() || stat.size>config.maxRefBytes) throw new Error('参考图文件超过体积上限');
        buffer=Buffer.alloc(stat.size);
        let offset=0;
        while(offset<buffer.length) { signal?.throwIfAborted(); const read=await handle.read(buffer,offset,buffer.length-offset,offset); if(!read.bytesRead) break; offset+=read.bytesRead; }
        buffer=buffer.subarray(0,offset);
      } finally { await handle.close(); }
    }
  }
  signal?.throwIfAborted();
  if(!buffer?.length || buffer.length>config.maxRefBytes) throw new Error('参考图无法读取或超过上限，请重新发送');
  imageMime(buffer);
  return buffer;
}
