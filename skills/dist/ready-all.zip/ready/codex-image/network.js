import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
import { createRequire } from 'node:module';

const runFile=promisify(execFile);
const require=createRequire(import.meta.url);

export function normalizeProxy(value) {
  let text=String(value || '').trim();
  if(!text) return '';
  if(!/^[a-z][a-z0-9+.-]*:\/\//i.test(text)) text='http://'+text;
  let url;try {url=new URL(text);}catch {throw new Error('代理地址无效，请填写 http://主机:端口');}
  if(!['http:','https:'].includes(url.protocol) || !url.hostname || (url.pathname && url.pathname!=='/') || url.search || url.hash) throw new Error('代理地址仅支持 HTTP/HTTPS；SOCKS/PAC 请改用代理软件的 HTTP 端口');
  return url.href;
}

export function parseWindowsProxy(value) {
  const text=String(value || '').trim();
  if(!text.includes('=')) return normalizeProxy(text);
  const map=new Map(text.split(';').map(item=>{const i=item.indexOf('=');return i<0?[]:[item.slice(0,i).trim().toLowerCase(),item.slice(i+1).trim()];}).filter(x=>x.length===2));
  return normalizeProxy(map.get('https') || map.get('http') || '');
}

export async function readWindowsProxy({platform=process.platform,run=runFile}={}) {
  if(platform!=='win32') return '';
  const key='HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Internet Settings';
  const options={windowsHide:true,timeout:2500,maxBuffer:16384,encoding:'utf8'};
  try {
    const enable=await run('reg.exe',['query',key,'/v','ProxyEnable'],options);
    if(!/ProxyEnable\s+REG_DWORD\s+0x0*1\b/i.test(enable.stdout)) return '';
    const server=await run('reg.exe',['query',key,'/v','ProxyServer'],options);
    const value=server.stdout.match(/ProxyServer\s+REG_\w+\s+(.+)/i)?.[1]?.trim();
    return parseWindowsProxy(value);
  } catch(error) {
    // Lack of registry access is not evidence of a configured proxy.
    if(error?.code==='ENOENT' || error?.code==='EPERM' || error?.code==='EACCES' || error?.killed || typeof error?.code==='number') return '';
    throw error;
  }
}

export function publicProxy(value) {
  if(!value) return '';
  const url=new URL(value);
  return `${url.protocol}//${url.hostname}${url.port?':'+url.port:''}`;
}

export async function resolveProxy(config,{env=process.env,systemProxy=readWindowsProxy}={}) {
  const mode=config.proxyMode || 'auto';
  if(mode==='direct') return {source:'direct',url:''};
  if(config.proxyUrl) return {source:'configured',url:normalizeProxy(config.proxyUrl)};
  if(mode==='custom') throw new Error('已选择自定义代理，请填写代理地址；需要自动检测时选择自动');
  for(const name of ['HTTPS_PROXY','https_proxy','HTTP_PROXY','http_proxy','ALL_PROXY','all_proxy']) {
    if(String(env[name] || '').trim()) return {source:'environment:'+name,url:normalizeProxy(env[name])};
  }
  const system=await systemProxy();
  return system?{source:'windows-system',url:system}:{source:'direct',url:''};
}

export function createTransport(fetcher,config,{useProxy=true,env=process.env,systemProxy=readWindowsProxy,agentFactory}={}) {
  let agent,closed=false,selected,initializing;
  const initialize=()=>initializing ||= (async()=>{
    selected=await resolveProxy(useProxy?config:{...config,proxyMode:'direct'},{env,systemProxy});
    if(closed) throw new Error('网络连接已关闭');
    if(selected.url) {
      if(agentFactory) agent=agentFactory(selected.url);
      else {
        let undici;try{undici=require('undici');}catch{throw new Error('QQAgent 的 undici 网络依赖不可用');}
        agent=new undici.ProxyAgent(selected.url);
      }
    }
  })();
  return {
    async prepare(){if(closed)throw new Error('网络连接已关闭');await initialize();},
    async request(url,options={}) {
      if(closed) throw new Error('网络连接已关闭');
      await initialize();
      options.signal?.throwIfAborted();
      if(closed) throw new Error('网络连接已关闭');
      return fetcher(url,{...options,redirect:options.redirect || 'error',...(agent?{dispatcher:agent}:{})});
    },
    info(){return selected?{source:selected.source,proxy:publicProxy(selected.url)}:{source:'not-resolved',proxy:''};},
    async close(){closed=true;if(agent){await agent.destroy().catch(()=>{});agent=null;}}
  };
}

export function networkError(error,transport) {
  const parts=[],seen=new Set();
  function visit(item,depth=0) {
    if(!item || seen.has(item) || depth>3) return;
    seen.add(item);
    const code=typeof item.code==='string'?'['+item.code+'] ':'';
    const message=typeof item.message==='string'?item.message:'';
    if(code || message) parts.push(code+message);
    if(item.cause) visit(item.cause,depth+1);
    if(Array.isArray(item.errors)) for(const child of item.errors.slice(0,3)) visit(child,depth+1);
  }
  visit(error);
  const info=transport?.info?.();
  let result=[...new Set(parts)].join('；') || '网络请求失败';
  if(info && info.source!=='not-resolved') result+=`；网络=${info.source}${info.proxy?' '+info.proxy:''}`;
  if(/ECONNREFUSED|ENOTFOUND|CONNECT_TIMEOUT|fetch failed/i.test(result)) result+='；请检查代理软件是否运行、代理端口是否正确，或选择适合当前网络的连接方式';
  return result;
}
