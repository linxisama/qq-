import fs from 'node:fs/promises';
import path from 'node:path';
import os from 'node:os';
import { randomUUID } from 'node:crypto';
import { networkError } from './network.js?release=1.0.0-public.1';
export { createTransport } from './network.js?release=1.0.0-public.1';

const BASE = 'https://chatgpt.com/backend-api/codex';
const TOKEN_URL = 'https://auth.openai.com/oauth/token';
const CLIENT_ID = 'app_EMoamEEZ73f0CkXaXp7hrann';
const USER_AGENT = 'codex-tui/0.163.0 (Windows; x64)';
const MB = 1048576;

export function settings(raw = {}) {
  const number = (v, fallback, min, max) => Math.min(max, Math.max(min, Number.isFinite(Number(v)) && v !== '' ? Math.round(Number(v)) : fallback));
  const authFile = path.resolve(String(raw.authFile || '').trim() || path.join(process.env.CODEX_HOME || path.join(os.homedir(), '.codex'), 'auth.json'));
  const size = String(raw.defaultSize || 'auto');
  if (!/^(auto|[1-9]\d{1,4}x[1-9]\d{1,4})$/.test(size)) throw new Error('默认尺寸应为 auto 或 宽x高');
  const model=String(raw.model || 'gpt-image-2').trim();
  if(!/^[a-z0-9][a-z0-9._-]{0,127}$/i.test(model)) throw new Error('模型 ID 只能包含字母、数字、点、下划线和连字符');
  const quality=raw.quality || 'auto';
  if (!['auto','low','medium','high','xhigh','max'].includes(quality)) throw new Error('图片质量设置无效');
  if(/^gpt-image-2(?:-\d{4}-\d{2}-\d{2})?$/.test(model) && ['xhigh','max'].includes(quality)) throw new Error('GPT Image 2 请使用 auto/low/medium/high；xhigh/max 用于支持这些档位的模型');
  const proxyMode=raw.proxyMode || 'auto';
  if(!['auto','direct','custom'].includes(proxyMode)) throw new Error('网络方式应为 auto、direct 或 custom');
  return { authFile, model, size, quality, proxyMode, timeoutMs: number(raw.timeoutMs,600000,5000,1200000), maxImageBytes:number(raw.maxImageMB,32,1,64)*MB, maxRefBytes:number(raw.maxRefMB,20,1,32)*MB, proxyUrl: String(raw.proxyUrl || '').trim() };
}

export function safeError(error, secrets = []) {
  let value = String(error?.message || error || '未知错误');
  for (const secret of secrets.filter(Boolean)) value = value.split(String(secret)).join('[已隐藏]');
  return value.replace(/Bearer\s+[^\s"',;]+/gi,'Bearer [已隐藏]')
    .replace(/(?:data:image\/[^;,]+;base64,|base64:\/\/)[A-Za-z0-9+/=\s]+/gi,'[图片数据]')
    .replace(/[A-Za-z0-9_+/=-]{90,}/g,'[长数据已隐藏]')
    .replace(/https?:\/\/[^\s"<>]+/g,v=>{try{const url=new URL(v);url.username='';url.password='';url.search='';url.hash='';return url.href;}catch{return '[链接]';}}).slice(0,1100);
}

export async function readAuth(file) {
  const stat = await fs.stat(file).catch(()=>{ throw new Error('找不到 Codex 登录文件。请先在官方 Codex 中使用 ChatGPT 登录。'); });
  if (!stat.isFile() || stat.size > 131072) throw new Error('Codex 登录文件格式或大小异常');
  let raw;
  try { raw=JSON.parse((await fs.readFile(file,'utf8')).replace(/^\uFEFF/,'')); } catch { throw new Error('Codex 登录文件不是有效 JSON'); }
  const token=raw.tokens || raw;
  if (raw.auth_mode === 'apikey' || typeof token.access_token !== 'string' || !token.access_token) throw new Error('需要 ChatGPT OAuth 登录态；本技能不会使用或回退到单独计费的 API Key');
  return { raw, access:token.access_token, refresh:token.refresh_token || '', account:token.account_id || '' };
}

export function imageMime(buffer) {
  if (buffer.length>=8 && buffer.subarray(0,8).equals(Buffer.from([137,80,78,71,13,10,26,10]))) return 'image/png';
  if (buffer.length>=3 && buffer[0]===255 && buffer[1]===216 && buffer[2]===255) return 'image/jpeg';
  if (buffer.length>=12 && buffer.toString('ascii',0,4)==='RIFF' && buffer.toString('ascii',8,12)==='WEBP') return 'image/webp';
  throw new Error('结果不是受支持的 PNG/JPEG/WebP 图片');
}

export async function limitedBytes(response, limit) {
  const length=Number(response.headers.get('content-length'));
  if (length>limit) { await response.body?.cancel().catch(()=>{}); throw new Error('响应超过体积上限'); }
  if (!response.body) return Buffer.alloc(0);
  const reader=response.body.getReader(); const chunks=[]; let size=0;
  try { while(true) { const item=await reader.read(); if(item.done) break; size+=item.value.length; if(size>limit) throw new Error('响应超过体积上限'); chunks.push(Buffer.from(item.value)); } return Buffer.concat(chunks); }
  finally { await reader.cancel().catch(()=>{}); reader.releaseLock(); }
}

export function buildPayload(prompt, size, quality, reference, model='gpt-image-2') {
  if(typeof prompt!=='string' || !prompt.trim() || prompt.length>12000) throw new Error('请提供 1–12000 字的提示词');
  if(!/^(auto|[1-9]\d{1,4}x[1-9]\d{1,4})$/.test(size)) throw new Error('尺寸应为 auto 或 宽x高');
  return { model, prompt, n:1, size, quality, output_format:'png', ...(reference ? {images:[{image_url:`data:${imageMime(reference)};base64,${reference.toString('base64')}`}]} : {}) };
}

export function responseMetadata(response,result,item) {
  const responseModel=typeof result.model==='string'?result.model:null;
  const imageModel=typeof item.model==='string'?item.model:null;
  const headers={};
  for(const name of ['x-request-id','openai-model','x-model','x-model-id','openai-version']) {const value=response.headers.get(name);if(value)headers[name]=value.slice(0,512);}
  // Keep non-image metadata while removing inline image data, signed URLs and credential-shaped keys.
  function trim(value,depth=0) {
    if(depth>5)return '[嵌套省略]';
    if(value===null || typeof value==='number' || typeof value==='boolean')return value;
    if(typeof value==='string')return value.length>4096?'[长字段省略]':safeError(value);
    if(Array.isArray(value))return value.slice(0,20).map(x=>trim(x,depth+1));
    if(typeof value==='object') {
      const output={};
      for(const [key,item] of Object.entries(value).slice(0,80)) {
        if(/^(data|b64_json|base64|image|images|image_url|url|access_token|refresh_token|id_token|authorization|api_key)$/i.test(key))continue;
        output[key]=trim(item,depth+1);
      }
      return output;
    }
    return undefined;
  }
  return {responseModel,imageModel,headers,response:trim(result),image:trim(item)};
}

export function allowedAssetUrl(raw) {
  const url=new URL(raw);
  const trusted=['oaiusercontent.com','openai.com','chatgpt.com','oaistatic.com','blob.core.windows.net'];
  if(url.protocol!=='https:' || url.username || url.password || (url.port && url.port!=='443') || !trusted.some(host=>url.hostname===host || url.hostname.endsWith('.'+host))) throw new Error('拒绝下载来自未知主机的结果图片');
  return url;
}

export async function atomicJson(file, value) {
  await fs.mkdir(path.dirname(file),{recursive:true});
  const temporary=file+'.'+randomUUID()+'.tmp';
  try { await fs.writeFile(temporary,JSON.stringify(value,null,2),{encoding:'utf8',mode:0o600,flag:'wx'}); await fs.rename(temporary,file); }
  finally { await fs.unlink(temporary).catch(()=>{}); }
}

export class CodexClient {
  constructor(config, transport) { this.config=config; this.transport=transport; }

  async refreshAuth(previous, signal) {
    const lockPath=this.config.authFile+'.qqagent-refresh.lock';
    let lock;
    try { lock=await fs.open(lockPath,'wx',0o600); } catch { throw new Error('登录凭据正在更新或无法写入，请稍后重试；没有重新提交生图'); }
    try {
      const current=await readAuth(this.config.authFile);
      if(current.access!==previous.access) return current;
      if(!current.refresh) throw new Error('登录态已失效，请在官方 Codex 中重新登录');
      const response=await this.transport.request(TOKEN_URL,{ method:'POST', signal, headers:{'Content-Type':'application/x-www-form-urlencoded'}, body:new URLSearchParams({grant_type:'refresh_token',client_id:CLIENT_ID,refresh_token:current.refresh,scope:'openid profile email'}) });
      const bytes=await limitedBytes(response,131072);
      let result; try { result=JSON.parse(bytes.toString('utf8')); } catch { throw new Error('登录续期返回无效响应'); }
      if(!response.ok || !result.access_token) throw new Error(`登录续期失败（HTTP ${response.status}），请在官方 Codex 重新登录；没有使用 API Key`);
      const raw=structuredClone(current.raw); const tokens=raw.tokens || raw;
      tokens.access_token=result.access_token;
      if(result.refresh_token) tokens.refresh_token=result.refresh_token;
      if(result.id_token) tokens.id_token=result.id_token;
      raw.last_refresh=new Date().toISOString();
      // Re-read immediately before write to avoid overwriting a rotation by another client.
      const latest=await readAuth(this.config.authFile);
      if(latest.access!==current.access || latest.refresh!==current.refresh) throw new Error('其他客户端已更新登录凭据，请重新发起本次请求；未重新提交生图');
      await atomicJson(this.config.authFile,raw);
      return { raw, access:tokens.access_token, refresh:tokens.refresh_token || '', account:tokens.account_id || '' };
    } finally { await lock.close(); await fs.unlink(lockPath).catch(()=>{}); }
  }

  async generate({prompt,size,reference,signal,onAccepted=()=>{}}) {
    let auth=await readAuth(this.config.authFile);
    const payload=buildPayload(prompt,size || this.config.size,this.config.quality,reference,this.config.model);
    const endpoint=BASE+(reference?'/images/edits':'/images/generations');
    const session=randomUUID();
    const request=()=>this.transport.request(endpoint,{method:'POST',signal,headers:{'Content-Type':'application/json',Accept:'application/json',Authorization:`Bearer ${auth.access}`,Originator:'codex-tui','User-Agent':USER_AGENT,'Session_id':session,'X-Client-Request-Id':randomUUID(),...(auth.account?{'Chatgpt-Account-Id':auth.account}:{})},body:JSON.stringify(payload)});
    try {
      signal?.throwIfAborted();
      await onAccepted(); // Persist an uncertain/submitting state before handing the request to the network.
      let response=await request();
      if(response.status===401) { await response.body?.cancel().catch(()=>{}); auth=await this.refreshAuth(auth,signal); response=await request(); }
      const bytes=await limitedBytes(response,response.ok?Math.ceil(this.config.maxImageBytes*4/3)+1048576:65536);
      let result; try { result=JSON.parse(bytes.toString('utf8')); } catch { throw new Error(`Codex 返回无效响应（HTTP ${response.status}）；不自动重新生成`); }
      if(!response.ok) {
        if(response.status===429) throw new Error('Codex 用量不足或请求受限（HTTP 429），请查看官方 Codex 用量；未自动重试');
        const message=safeError(result?.error?.message || result?.message || '',[auth.access,auth.refresh]);
        throw new Error(`Codex 生图失败（HTTP ${response.status}）${message?'：'+message:''}；未自动重新生成`);
      }
      const item=result?.data?.[0];
      if(!item) throw new Error('Codex 未返回图片数据；不自动重新生成');
      let buffer;
      if(typeof item.b64_json==='string') {
        const base64=item.b64_json.replace(/^data:image\/[^;,]+;base64,/, '');
        if(base64.length>Math.ceil(this.config.maxImageBytes*4/3)+4 || !/^[A-Za-z0-9+/\r\n]+={0,2}$/.test(base64)) throw new Error('图片 Base64 格式或大小异常');
        buffer=Buffer.from(base64,'base64');
      } else if(typeof item.url==='string') {
        let url=allowedAssetUrl(item.url);
        for(let redirects=0;redirects<=3;redirects++) {
          const headers={Accept:'image/*','User-Agent':USER_AGENT};
          if(url.origin==='https://chatgpt.com' && url.pathname.startsWith('/backend-api/')) {
            headers.Authorization=`Bearer ${auth.access}`;
            if(auth.account) headers['Chatgpt-Account-Id']=auth.account;
          }
          // Redirects are followed manually; credentials never follow to an asset host.
          const asset=await this.transport.request(url.href,{signal,headers,redirect:'manual'});
          if([301,302,303,307,308].includes(asset.status)) {
            const location=asset.headers.get('location'); await asset.body?.cancel().catch(()=>{});
            if(!location || redirects===3) throw new Error('结果图重定向异常');
            url=allowedAssetUrl(new URL(location,url).href); continue;
          }
          if(!asset.ok) { await asset.body?.cancel().catch(()=>{}); throw new Error(`图片已生成但下载失败（HTTP ${asset.status}），不能自动重新生成`); }
          buffer=await limitedBytes(asset,this.config.maxImageBytes); break;
        }
      } else throw new Error('Codex 图片结果格式暂不支持；不自动重新生成');
      if(!buffer?.length || buffer.length>this.config.maxImageBytes) throw new Error('结果图片为空或超过体积上限');
      const mime=imageMime(buffer);
      const metadata=responseMetadata(response,result,item);
      return {buffer,mime,usage:result.usage || null,revisedPrompt:typeof item.revised_prompt==='string'?item.revised_prompt:null,requestedModel:payload.model,serverReportedModel:metadata.responseModel || metadata.imageModel || metadata.headers['openai-model'] || metadata.headers['x-model'] || metadata.headers['x-model-id'] || null,responseMetadata:metadata,network:this.transport.info?.() || null};
    } catch(error) {
      throw new Error(safeError(networkError(error,this.transport),[auth.access,auth.refresh]));
    }
  }
}
