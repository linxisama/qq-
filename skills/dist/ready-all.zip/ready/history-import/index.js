// 历史消息导入（LLM 型 / skills/）
//
// ── 为什么做成「技能」而不是「插件」──────────────────────────────────────────
// 用户想要的是：机器人在本地存档里只看到"部署之后"收到的消息，读不到更早的
// QQ 聊天记录。要补这个缺口，需要**从 QQ 服务器把更早的消息拉回来并写进存档**。
// 这件事的特点：
//   · 需要模型**动脑子判断何时该拉**（有人问"你还记得之前聊过啥吗"才拉；
//     平常每轮都拉会白烧时间、还容易被协议端限频）。
//   · 只能按需触发，不是"每条消息都必须执行的确定性动作"。
// 这正是 skills/（LLM 型，registerTool）的定义；做成 plugins/（确定性型、
// 靠 providers/hooks）反而拿不到 onebot 客户端，也做不到"按需"。
//
// ── 数据从哪来、写到哪 ───────────────────────────────────────────────────
// 数据源：SnowLuma 的 OneBot action
//   · get_group_msg_history（群）  —— 服务端 SsoGetGroupMsg 拉取，能拿到实时
//     WS 没见过的老消息（这正是"部署前"那批）。
//   · get_friend_msg_history（私聊）—— 无锚点时从服务器拉最新双向历史。
// 落盘：复用核心的 ctx.store.appendIncoming / appendSelf —— 与实时入库走
// **同一条写入路径**，格式、去重、截断规则完全一致，不需要自己拼 JSON 文件
// （自己写文件极易漏字段 / 写错日期，导致"存档里多了几行但模型看不到"）。
//
// ── 安全边界 ─────────────────────────────────────────────────────────────
// 只允许补**当前会话**：群/私聊由 ctx.kind + ctx.chatId 决定，工具不接受
// "别的群号/别人的 QQ"，模型物理上无法借这个工具去扒别处的历史。
//
// ── 去重 ─────────────────────────────────────────────────────────────────
// 服务器返回的消息可能和本地已有消息重叠（实时收到过 + 历史拉取）。用 mid
// （QQ message_id）比对本地存档已有的 mid，只写新的那部分，重复导入幂等。

const DEFAULTS = { defaultCount: 50, maxCount: 200 };

let apiRef = null;

const sleep = (ms) => new Promise((r) => setTimeout(r, Math.max(0, Number(ms) || 0)));

/**
 * 把用户/模型给的 "2026-10-19" 或 "2026-10-19 11:00" 解析成本地时区的毫秒时间戳。
 * 只要这一天就返回当天 00:00。解析失败返回 null（= 不限时间）。
 */
function parseUntil(raw) {
  const s = String(raw ?? '').trim();
  if (!s) return null;
  // 允许 2026-10-19 / 2026/10/19 / 2026-10-19 11:00 / 2026-10-19T11:00:00
  const m = /^(\d{4})[-/](\d{1,2})[-/](\d{1,2})(?:[ T](\d{1,2}):(\d{2})(?::(\d{2}))?)?/.exec(s);
  if (!m) return null;
  const y = Number(m[1]);
  const mo = Number(m[2]) - 1;
  const d = Number(m[3]);
  const hh = m[4] != null ? Number(m[4]) : 0;
  const mm = m[5] != null ? Number(m[5]) : 0;
  const ss = m[6] != null ? Number(m[6]) : 0;
  const t = new Date(y, mo, d, hh, mm, ss, 0).getTime();
  return Number.isFinite(t) ? t : null;
}

/** 毫秒时间戳 → "MM-DD HH:mm"（本地时区），用于回执里说明拉到了哪天。 */
function fmtTime(ms) {
  try {
    const d = new Date(Number(ms));
    const p = (n) => String(n).padStart(2, '0');
    return `${p(d.getMonth() + 1)}-${p(d.getDate())} ${p(d.getHours())}:${p(d.getMinutes())}`;
  } catch { return String(ms); }
}

function cfgNum(key, fallback) {
  try {
    const raw = (apiRef && typeof apiRef.config === 'function') ? (apiRef.config() || {}) : {};
    const v = Number(raw[key]);
    return Number.isFinite(v) && v > 0 ? v : fallback;
  } catch {
    return fallback;
  }
}

/** 把历史事件里的 OneBot 消息段转成存档用的纯文本（与核心 segmentsToText 口径一致）。 */
function segmentsToPlainText(segments) {
  if (typeof segments === 'string') return segments.trim();
  const out = [];
  for (const seg of Array.isArray(segments) ? segments : []) {
    const d = seg?.data ?? {};
    switch (seg?.type) {
      case 'text': out.push(d.text ?? ''); break;
      case 'at':
        out.push(d.qq === 'all' ? '@全体成员' : (d.name ? `@${d.name}` : `@${d.qq}`));
        break;
      case 'face': out.push(`[表情${d.id ?? ''}]`); break;
      case 'image': out.push('[图片]'); break;
      case 'record': out.push('[语音]'); break;
      case 'video': out.push('[视频]'); break;
      case 'file': out.push(`[文件${d.name ?? ''}]`); break;
      case 'json': out.push('[卡片消息]'); break;
      case 'xml': out.push('[卡片消息]'); break;
      case 'forward': out.push('[合并转发聊天记录]'); break;
      case 'reply': break; // 引用关系不展开，见下
      default: out.push(`[${seg?.type ?? '未知'}]`); break;
    }
  }
  return out.join('').replace(/\s+$/, '').trim();
}

/** 从历史事件里取一条可读的"引用了谁/说了啥"的摘要（可选）。 */
function buildReplySummary(segments) {
  const segs = Array.isArray(segments) ? segments : [];
  const replySeg = segs.find((s) => s?.type === 'reply');
  if (!replySeg) return null;
  // 历史事件通常只带被引用消息的 id，不带原文；这里只留 id 线索，够模型知道"这是回复"。
  const id = replySeg?.data?.id ?? null;
  if (id == null) return null;
  return { sender: '', senderId: '', text: `(引用消息 #${id})`, replyId: String(id) };
}

/** 历史事件是否来自机器人自己。 */
function isSelfEvent(event, selfId) {
  if (!selfId) return false;
  const uid = String(event?.sender?.user_id ?? event?.user_id ?? '');
  const pt = String(event?.post_type || '');
  if (pt === 'message_sent') return true;
  return Boolean(uid) && uid === String(selfId);
}

/** 事件时间：OneBot 的 time 是秒；有的实现会给 ms，这里统一成 ms。 */
function eventTsToMs(event) {
  const t = Number(event?.time);
  if (!Number.isFinite(t) || t <= 0) return Date.now();
  // 小于 1e12 视为秒级
  return t < 1e12 ? t * 1000 : t;
}

/** 从事件里取发送者名字：群名片 > 昵称 > QQ 号。 */
function senderNameOf(event) {
  const s = event?.sender || {};
  return String(s.card || s.nickname || (event?.sender?.user_id ?? event?.user_id ?? '')).trim();
}

/** 本地存档里已有的 mid 集合（用于去重）。 */
function existingMids(store, chatKey) {
  const set = new Set();
  try {
    const all = store.recent ? store.recent(chatKey, { limit: 100000, includeSelf: true }) : [];
    for (const m of all) {
      if (m && m.mid != null) set.add(String(m.mid));
    }
  } catch { /* 拿不到就当空集合，靠单条 try 去重兜底 */ }
  return set;
}

export function register(api) {
  apiRef = api;
  const log = api.log;

  api.registerTool({
    id: 'import_history',
    name: '导入更早的历史消息',
    description: '从 QQ 服务器把当前会话更早的聊天记录【自动分页回溯】拉下来并写进本地存档（补部署前 / 未实时收到的消息）。只说"导入更早的历史"就会一直往前翻，直到拿不出更早的或到达指定日期为止。只作用于当前会话，重复导入自动去重。',
    category: 'knowledge',
    icon: '🕰️',
    parameters: {
      type: 'object',
      properties: {
        until: { type: 'string', description: '一直往前拉到这一天/这个时间就停，格式 YYYY-MM-DD 或 YYYY-MM-DD HH:mm。例子：用户说"从19号开始聊的"，就填 "2026-10-19"。不填则尽量拉到能拉到的最早。' },
        count: { type: 'number', description: '总目标条数上限（所有页累加），默认 400，上限 2000。到量就停。' },
        perPage: { type: 'number', description: '每页拉多少条，默认群聊 200 / 私聊 20（协议限制），一般不用改。' },
        pages: { type: 'number', description: '最多翻几页，默认 10，上限 30。兜底防止无限翻。' }
      },
      required: []
    },
    async execute(ctx, args) {
      const kind = String(ctx?.kind || '');
      const chatKey = String(ctx?.chatKey || '');
      const chatId = Number(ctx?.chatId);
      const onebot = ctx?.onebot;
      const store = ctx?.store;
      const selfId = String(ctx?.selfId || '');

      if (!onebot || typeof onebot.call !== 'function') {
        return { content: '错误：当前环境拿不到 QQ 协议端连接，无法拉取历史。', isError: true };
      }
      if (!store || typeof store.appendIncoming !== 'function') {
        return { content: '错误：当前环境拿不到本地存档，无法写入历史。', isError: true };
      }
      if (!chatKey || !Number.isFinite(chatId) || chatId <= 0) {
        return { content: '错误：无法确定当前会话，不能导入历史。', isError: true };
      }
      if (kind !== 'group' && kind !== 'private') {
        return { content: `错误：未知会话类型「${kind}」，只能导入群聊或私聊历史。`, isError: true };
      }

      const maxCount = cfgNum('maxCount', DEFAULTS.maxCount);
      const defCount = cfgNum('defaultCount', DEFAULTS.defaultCount);
      let totalWant = Number(args?.count);
      if (!Number.isFinite(totalWant) || totalWant <= 0) totalWant = 400;
      totalWant = Math.max(1, Math.min(2000, Math.trunc(totalWant)));

      // 每页条数：群聊一次能给到 200；私聊首屏走 roam，服务端单页硬上限 20，
      // 所以私聊默认取小一点，翻页时靠带锚点的 SsoGetC2cMsg 继续往前。
      let perPage = Number(args?.perPage);
      if (!Number.isFinite(perPage) || perPage <= 0) perPage = kind === 'group' ? Math.min(200, maxCount) : 20;
      perPage = Math.max(1, Math.min(200, Math.trunc(perPage)));

      let maxPages = Number(args?.pages);
      if (!Number.isFinite(maxPages) || maxPages <= 0) maxPages = 10;
      maxPages = Math.max(1, Math.min(30, Math.trunc(maxPages)));

      // 目标时间下界（毫秒）：拉到比它还早的一页就停。不填 = 不限。
      const untilMs = parseUntil(args?.until);

      const action = kind === 'group' ? 'get_group_msg_history' : 'get_friend_msg_history';
      const mkParams = (anchorId, n) => (kind === 'group'
        ? { group_id: chatId, message_id: anchorId, count: n, reverse_order: true }
        : { user_id: chatId, message_id: anchorId, count: n, reverse_order: true });

      const seen = existingMids(store, chatKey);
      let written = 0;
      let skippedDup = 0;
      let skippedEmpty = 0;
      let writeError = 0;
      let fetchedTotal = 0;
      let pagesDone = 0;
      let anchorId = 0;          // 0 = 第一页（从最新往更早）
      let oldestTsMs = Infinity; // 已拉到的最旧时间
      let stopReason = '';
      const gapMs = kind === 'group' ? 350 : 2100; // 协议端节流：私聊 roam 有 2s 间隔

      const parseEvents = (data) => (Array.isArray(data?.messages) ? data.messages : Array.isArray(data) ? data : []);

      for (let page = 0; page < maxPages; page += 1) {
        if (totalWant > 0 && fetchedTotal >= totalWant) { stopReason = '达到目标条数'; break; }

        let data;
        try {
          data = await onebot.call(action, mkParams(anchorId, perPage));
        } catch (error) {
          if (pagesDone === 0) {
            return { content: `拉取历史失败：${String(error?.message ?? error)}。（可能协议端未登录、或该会话历史过老已被清理）`, isError: true };
          }
          stopReason = `第 ${pagesDone + 1} 页出错已停止：${String(error?.message ?? error)}`;
          break;
        }

        const events = parseEvents(data);
        pagesDone += 1;
        if (!events.length) { stopReason = pagesDone === 1 ? '服务器没有更早的消息' : '已经拉到最早了'; break; }
        fetchedTotal += events.length;

        // 按时间正序入库，让存档顺序与真实聊天一致
        const ordered = events.slice().sort((a, b) => eventTsToMs(a) - eventTsToMs(b));
        let pageWrote = 0;
        for (const ev of ordered) {
          let mid = null;
          if (ev && ev.message_id !== undefined && ev.message_id !== null) mid = ev.message_id;
          else if (ev && ev.real_id !== undefined && ev.real_id !== null) mid = ev.real_id;
          const midKey = mid != null ? String(mid) : null;
          if (midKey != null && seen.has(midKey)) { skippedDup += 1; continue; }

          const text = segmentsToPlainText(ev?.message ?? ev?.raw_message ?? '');
          if (!text) { skippedEmpty += 1; continue; }

          const ts = eventTsToMs(ev);
          try {
            if (isSelfEvent(ev, selfId)) {
              store.appendSelf(chatKey, { text, ts, mid });
            } else {
              const reply = buildReplySummary(ev?.message);
              store.appendIncoming(chatKey, {
                mid, ts,
                senderId: String(ev?.sender?.user_id ?? ev?.user_id ?? ''),
                senderName: senderNameOf(ev),
                text, reply
              });
            }
            if (midKey != null) seen.add(midKey);
            written += 1;
            pageWrote += 1;
          } catch (error) {
            writeError += 1;
            log('写入历史消息失败：', error?.message ?? error);
          }
        }

        // 这一页最旧一条的时间 & 消息 id：作为下一页往回翻的锚点
        const oldest = ordered[0];
        const oldestMs = eventTsToMs(oldest);
        let oldestMid = null;
        if (oldest && oldest.message_id !== undefined && oldest.message_id !== null) oldestMid = oldest.message_id;
        else if (oldest && oldest.real_id !== undefined && oldest.real_id !== null) oldestMid = oldest.real_id;

        // 到达目标日期：本页最旧已经 ≤ until，停止
        if (untilMs != null && Number.isFinite(oldestMs) && oldestMs <= untilMs) { stopReason = '到达指定日期'; break; }

        // 无法继续往前：没有可用锚点，或锚点没前进（服务器返回的一直是同一批）
        if (oldestMid == null) { stopReason = '已无法继续往前翻（缺锚点）'; break; }
        if (Number(oldestMs) >= Number(oldestTsMs) && pagesDone > 1) { stopReason = '已无法继续往前翻（无更早消息）'; break; }
        if (String(oldestMid) === String(anchorId)) { stopReason = '已无法继续往前翻（锚点未前进）'; break; }
        oldestTsMs = oldestMs;
        anchorId = oldestMid;

        // 这一页全都已经在存档里，且已经拿到过更早的锚点 —— 说明已追上视野，收工
        if (pageWrote === 0 && pagesDone > 1 && events.every((ev) => {
          const mid = ev?.message_id ?? ev?.real_id;
          return mid != null && seen.has(String(mid));
        }) && page === maxPages - 1) {
          stopReason = '已追上本地已有记录';
        }

        if (page < maxPages - 1 && !(untilMs != null && oldestMs <= untilMs)) {
          await sleep(gapMs);
        }
      }
      if (!stopReason) stopReason = '达到翻页上限';

      const label = kind === 'group' ? '本群' : '这个私聊';
      const span = oldestTsMs !== Infinity && Number.isFinite(oldestTsMs) ? `，最早到 ${fmtTime(oldestTsMs)}` : '';
      const parts = [`已从服务器拉取${label}历史：翻 ${pagesDone} 页、共 ${fetchedTotal} 条${span}。`];
      parts.push(`新写入存档 ${written} 条${skippedDup ? `，跳过 ${skippedDup} 条重复` : ''}${skippedEmpty ? `，跳过 ${skippedEmpty} 条空内容` : ''}${writeError ? `，${writeError} 条写入失败` : ''}。`);
      parts.push(`（停止原因：${stopReason}）`);
      if (written > 0) parts.push('这些消息已进入存档，可以直接引用讨论；它们的时间是真实的过去时间。');
      if (untilMs != null && stopReason !== '到达指定日期' && stopReason !== '达到目标条数') {
        parts.push('没能拉到你要的那天那么早——可能是服务器上更早的记录已被清理，或协议端只保留有限历史。可以再调一次继续往前试。');
      }
      return { content: parts.join('') };
    }
  });

  log('历史消息导入技能已注册（import_history，支持自动分页回溯）');
}
