// MC 白名单绑定技能
//
// 功能：
//   - 绑定：QQ号 ↔ MC玩家（验证码验证）
//   - 解绑
//   - 查询绑定关系
//
// 数据存储在 data/mc-whitelist/ 目录下：
//   - bindings.json  绑定关系
//   - pending.json   待确认的验证码
//
// RCON 客户端实现参考 mc-status 插件的 rcon.js（Source RCON 协议）。

import fs from 'node:fs';
import path from 'node:path';
import net from 'node:net';
import { fileURLToPath } from 'node:url';

// ── 数据目录 ──────────────────────────────────────────────────────
const HERE = path.dirname(fileURLToPath(import.meta.url));
const APP_ROOT = path.resolve(HERE, '..', '..');
const DATA_DIR = process.env.QQ_AGENT_DATA_DIR || path.join(APP_ROOT, 'data');
const STORE_DIR = path.join(DATA_DIR, 'mc-whitelist');
const BINDINGS_FILE = path.join(STORE_DIR, 'bindings.json');
const PENDING_FILE = path.join(STORE_DIR, 'pending.json');

function ensureStoreDir() {
  try { fs.mkdirSync(STORE_DIR, { recursive: true }); } catch { /* 忽略 */ }
}

// ── 存储工具 ──────────────────────────────────────────────────────
function readJson(file, fallback) {
  try {
    const text = fs.readFileSync(file, 'utf8');
    return JSON.parse(text);
  } catch {
    return fallback;
  }
}

function writeJson(file, data) {
  ensureStoreDir();
  try {
    fs.writeFileSync(file, JSON.stringify(data, null, 2), 'utf8');
    return true;
  } catch (e) {
    return false;
  }
}

// 绑定关系结构：{ [qq]: [{ playerName, uuid?, boundAt }] }
function getBindings() {
  return readJson(BINDINGS_FILE, {});
}

function saveBindings(data) {
  return writeJson(BINDINGS_FILE, data);
}

// 待确认结构：{ [qq]: { playerName, code, expiresAt } }
function getPending() {
  return readJson(PENDING_FILE, {});
}

function savePending(data) {
  return writeJson(PENDING_FILE, data);
}

// ── RCON 客户端 ──────────────────────────────────────────────────
const TYPE_RESPONSE = 0;
const TYPE_COMMAND = 2;
const TYPE_AUTH = 3;
const AUTH_ID = 1;
const CMD_ID = 2;
const SETTLE_MS = 250;

function pack(id, type, body) {
  const payload = Buffer.concat([Buffer.from(String(body ?? ''), 'utf8'), Buffer.from([0, 0])]);
  const buf = Buffer.alloc(4 + 4 + 4 + payload.length);
  buf.writeInt32LE(4 + 4 + payload.length, 0);
  buf.writeInt32LE(id, 4);
  buf.writeInt32LE(type, 8);
  payload.copy(buf, 12);
  return buf;
}

function splitPackets(buf) {
  const packets = [];
  let off = 0;
  while (buf.length - off >= 4) {
    const size = buf.readInt32LE(off);
    if (size < 10 || size > 4 * 1024 * 1024) break;
    if (buf.length - off < 4 + size) break;
    const id = buf.readInt32LE(off + 4);
    const type = buf.readInt32LE(off + 8);
    const raw = buf.subarray(off + 12, off + 4 + size);
    const body = raw.toString('utf8').replace(/\0+$/, '');
    packets.push({ id, type, body });
    off += 4 + size;
  }
  return { packets, rest: buf.subarray(off) };
}

function execRcon({ host, port = 25575, password = '', command = '', timeout = 5000 } = {}) {
  return new Promise((resolve) => {
    if (!host) return resolve({ ok: false, output: '', error: '没填 RCON 地址' });
    if (!password) return resolve({ ok: false, output: '', error: '没填 RCON 密码' });
    if (!String(command).trim()) return resolve({ ok: false, output: '', error: '命令是空的' });

    let settled = false;
    let buf = Buffer.alloc(0);
    let authed = false;
    const parts = [];
    let settle = null;
    const sock = new net.Socket();

    const finish = (r) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      clearTimeout(settle);
      try { sock.destroy(); } catch { /* 已断开 */ }
      resolve(r);
    };
    const timer = setTimeout(() => finish({ ok: false, output: '', error: 'RCON 超时（服务器没开 rcon 或端口不通）' }),
      Math.max(1000, Number(timeout) || 5000));

    sock.on('error', (e) => finish({ ok: false, output: '', error: `RCON 连接失败：${String(e?.message || e)}` }));

    sock.on('data', (chunk) => {
      buf = Buffer.concat([buf, chunk]);
      const { packets, rest } = splitPackets(buf);
      buf = rest;
      for (const p of packets) {
        if (!authed) {
          if (p.id === -1) return finish({ ok: false, output: '', error: 'RCON 认证失败（密码不对，或服务器没开 rcon）' });
          authed = true;
          sock.write(pack(CMD_ID, TYPE_COMMAND, command));
          continue;
        }
        if (p.id !== CMD_ID) continue;
        if (p.type !== TYPE_RESPONSE && p.type !== TYPE_COMMAND) continue;
        parts.push(p.body);
        if (!p.body) return finish({ ok: true, output: parts.join('') });
        clearTimeout(settle);
        settle = setTimeout(() => finish({ ok: true, output: parts.join('') }), SETTLE_MS);
      }
    });

    sock.on('close', () => {
      if (!settled) finish({ ok: false, output: '', error: authed ? 'RCON 连接被关闭，没拿到结果' : 'RCON 连接被关闭（密码不对？）' });
    });

    sock.connect(Number(port) || 25575, host, () => {
      sock.write(pack(AUTH_ID, TYPE_AUTH, password));
    });
  });
}

// ── 工具函数 ──────────────────────────────────────────────────────

// MC 玩家名：3-16 位，字母、数字、下划线
const MC_NAME_RE = /^[a-zA-Z0-9_]{3,16}$/;

function validatePlayerName(name) {
  const n = String(name ?? '').trim();
  if (!n) return { ok: false, reason: '玩家名不能为空' };
  if (!MC_NAME_RE.test(n)) return { ok: false, reason: '玩家名格式不对（3-16位，只能是字母、数字、下划线）' };
  return { ok: true, name: n };
}

// 生成随机数字验证码
function generateCode(length) {
  const len = Math.max(4, Math.min(8, Number(length) || 4));
  let code = '';
  for (let i = 0; i < len; i++) {
    code += Math.floor(Math.random() * 10).toString();
  }
  return code;
}

// 获取当前说话者 QQ 号（取批内第一个非机器人发送者）
function getCallerQQ(ctx) {
  try {
    const entries = Array.isArray(ctx?.session?.trigger) ? ctx.session.trigger : [];
    for (const m of entries) {
      if (m && !m.self && m.senderId) {
        return String(m.senderId);
      }
    }
  } catch { /* 忽略 */ }
  return '';
}

// 检查一个玩家是否已被任何 QQ 绑定
function findPlayerBinding(bindings, playerName) {
  const name = String(playerName).toLowerCase();
  for (const [qq, list] of Object.entries(bindings)) {
    for (const b of list) {
      if (String(b.playerName).toLowerCase() === name) {
        return { qq, binding: b };
      }
    }
  }
  return null;
}

// ── 工具定义 ──────────────────────────────────────────────────────

let cfg = () => ({});
let api = null;

function rconParams() {
  const c = cfg();
  return {
    host: String(c.rconHost || '').trim(),
    port: Number(c.rconPort) || 25575,
    password: String(c.rconPassword || ''),
    timeout: Number(c.rconTimeout) || 5000
  };
}

function toolBind() {
  return {
    id: 'bind',
    name: '发起白名单绑定',
    description: '发起 Minecraft 白名单绑定申请。会生成一个验证码并通过 RCON 发给游戏内的玩家（玩家必须在线）。玩家收到验证码后，再用 mc_whitelist__confirm 工具确认绑定。',
    category: 'utility',
    icon: '🔗',
    parameters: {
      type: 'object',
      properties: {
        playerName: { type: 'string', description: '要绑定的 Minecraft 玩家名（游戏ID），3-16位字母数字下划线。' }
      },
      required: ['playerName']
    },
    async execute(ctx, args) {
      const qq = getCallerQQ(ctx);
      if (!qq) return { content: '获取不到你的QQ号，无法绑定。' };

      const nameCheck = validatePlayerName(args.playerName);
      if (!nameCheck.ok) return { content: nameCheck.reason };
      const playerName = nameCheck.name;

      const c = cfg();
      const maxBinds = Number(c.maxBindsPerQQ) || 0;

      // 检查该QQ号的绑定数量
      const bindings = getBindings();
      const myBinds = bindings[qq] || [];
      if (maxBinds > 0 && myBinds.length >= maxBinds) {
        return { content: `你已经绑定了 ${myBinds.length} 个账号，上限是 ${maxBinds} 个。先解绑一个再绑新的吧。` };
      }

      // 检查玩家是否已被绑定
      const existing = findPlayerBinding(bindings, playerName);
      if (existing) {
        if (existing.qq === qq) {
          return { content: `你已经绑定了「${playerName}」这个账号了。` };
        }
        return { content: `「${playerName}」已经被别人绑定了，不能重复绑定。` };
      }

      // RCON 检查
      const rp = rconParams();
      if (!rp.host || !rp.password) {
        return { content: 'RCON 还没配置好，去控制台 → 技能 → MC白名单绑定，填上 RCON 地址和密码才能用。' };
      }

      // 生成验证码
      const codeLen = Number(c.codeLength) || 4;
      const code = generateCode(codeLen);
      const expireMin = Number(c.codeExpireMinutes) || 5;
      const expiresAt = Date.now() + expireMin * 60 * 1000;

      // 通过 tell 给玩家发验证码
      const tellCmd = `tell ${playerName} [QQ机器人] 你的白名单绑定验证码是：${code}。有效期${expireMin}分钟。请勿告诉任何人。`;
      const res = await execRcon({ ...rp, command: tellCmd });

      if (!res.ok) {
        return { content: `绑定失败：${res.error}\n（如果是「玩家不在线」之类的提示，让玩家先登录游戏再试）` };
      }

      // tell 命令失败时服务器会返回错误信息，但不会直接告诉我们玩家在不在线
      // 常见输出："There's no player by that name online." 或玩家名不存在
      if (res.output && /no player|not found|not online|不存在|不在线|找不到/i.test(res.output)) {
        return { content: `「${playerName}」当前不在线，或者名字不对。验证码要发到游戏里才行，让玩家先登录游戏再发起绑定。` };
      }

      // 保存待确认记录
      const pending = getPending();
      pending[qq] = { playerName, code, expiresAt };
      savePending(pending);

      api?.log?.(`绑定申请：QQ ${qq} 发起绑定 ${playerName}，验证码已发送`);

      return {
        content: `好的，我已经给游戏里的「${playerName}」发了一条私信，里面有${codeLen}位验证码。\n请玩家打开游戏查看私信，然后把验证码发给我确认绑定。\n验证码${expireMin}分钟内有效。`
      };
    }
  };
}

function toolConfirm() {
  return {
    id: 'confirm',
    name: '确认白名单绑定',
    description: '输入验证码确认绑定。验证通过后会自动把玩家加入服务器白名单，并记录绑定关系。',
    category: 'utility',
    icon: '✅',
    parameters: {
      type: 'object',
      properties: {
        code: { type: 'string', description: '收到的验证码（纯数字）。' }
      },
      required: ['code']
    },
    async execute(ctx, args) {
      const qq = getCallerQQ(ctx);
      if (!qq) return { content: '获取不到你的QQ号，无法确认。' };

      const code = String(args.code ?? '').trim().replace(/\D/g, '');
      if (!code) return { content: '验证码不能为空。' };

      const pending = getPending();
      const record = pending[qq];

      if (!record) {
        return { content: '你没有待确认的绑定申请。先跟我说「绑定 玩家名」来发起绑定。' };
      }

      // 检查过期
      if (Date.now() > record.expiresAt) {
        delete pending[qq];
        savePending(pending);
        return { content: '验证码已经过期了。重新发起绑定吧。' };
      }

      // 验证
      if (record.code !== code) {
        return { content: '验证码不对，再看看游戏里的私信。注意是纯数字，不要带空格。' };
      }

      const playerName = record.playerName;

      // 加白名单
      const rp = rconParams();
      const whitelistRes = await execRcon({ ...rp, command: `whitelist add ${playerName}` });

      if (!whitelistRes.ok) {
        return { content: `加白名单失败：${whitelistRes.error}` };
      }

      // 保存绑定关系
      const bindings = getBindings();
      if (!bindings[qq]) bindings[qq] = [];

      // 防重复
      const already = bindings[qq].find((b) => String(b.playerName).toLowerCase() === playerName.toLowerCase());
      if (!already) {
        bindings[qq].push({
          playerName,
          boundAt: Date.now()
        });
      }

      saveBindings(bindings);

      // 清除待确认
      delete pending[qq];
      savePending(pending);

      api?.log?.(`绑定成功：QQ ${qq} ↔ ${playerName}`);

      return {
        content: `✅ 绑定成功！「${playerName}」已经加入白名单，现在可以进服务器了。\n想解绑的话跟我说「解绑 ${playerName}」就行。`
      };
    }
  };
}

function toolUnbind() {
  return {
    id: 'unbind',
    name: '解绑白名单',
    description: '解绑已绑定的 Minecraft 玩家，同时从服务器白名单中移除。只能解绑自己绑定的账号。',
    category: 'utility',
    icon: '❌',
    parameters: {
      type: 'object',
      properties: {
        playerName: { type: 'string', description: '要解绑的 Minecraft 玩家名。' }
      },
      required: ['playerName']
    },
    async execute(ctx, args) {
      const qq = getCallerQQ(ctx);
      if (!qq) return { content: '获取不到你的QQ号，无法解绑。' };

      const nameCheck = validatePlayerName(args.playerName);
      if (!nameCheck.ok) return { content: nameCheck.reason };
      const playerName = nameCheck.name;

      const bindings = getBindings();
      const myBinds = bindings[qq] || [];
      const idx = myBinds.findIndex((b) => String(b.playerName).toLowerCase() === playerName.toLowerCase());

      if (idx < 0) {
        return { content: `你没有绑定「${playerName}」这个账号，没法解绑。` };
      }

      // 从白名单移除
      const rp = rconParams();
      if (rp.host && rp.password) {
        // 即使 RCON 失败也继续解绑本地记录，只是告诉用户手动删一下
        const res = await execRcon({ ...rp, command: `whitelist remove ${playerName}` });
        if (!res.ok) {
          // RCON 连不上，但本地记录还是要删
          myBinds.splice(idx, 1);
          if (myBinds.length === 0) delete bindings[qq];
          saveBindings(bindings);
          api?.log?.(`解绑（本地）：QQ ${qq} ↔ ${playerName}，RCON 失败：${res.error}`);
          return {
            content: `本地绑定关系已经解除了，但服务器那边的白名单没删掉（${res.error}）。\n你可以手动在服务器里执行「whitelist remove ${playerName}」。`
          };
        }
      }

      myBinds.splice(idx, 1);
      if (myBinds.length === 0) delete bindings[qq];
      saveBindings(bindings);

      api?.log?.(`解绑成功：QQ ${qq} ↔ ${playerName}`);

      return { content: `✅ 已解绑「${playerName}」，同时从服务器白名单中移除了。` };
    }
  };
}

function toolQuery() {
  return {
    id: 'query',
    name: '查询绑定关系',
    description: '查询当前QQ号绑定了哪些 Minecraft 玩家。只能查自己的。',
    category: 'utility',
    icon: '🔍',
    parameters: {
      type: 'object',
      properties: {}
    },
    async execute(ctx, args) {
      const qq = getCallerQQ(ctx);
      if (!qq) return { content: '获取不到你的QQ号，无法查询。' };

      const bindings = getBindings();
      const myBinds = bindings[qq] || [];

      if (myBinds.length === 0) {
        return { content: '你还没有绑定任何 Minecraft 账号。跟我说「绑定 玩家名」就能开始绑定。' };
      }

      const lines = myBinds.map((b, i) => {
        const date = new Date(b.boundAt).toLocaleString('zh-CN');
        return `${i + 1}. ${b.playerName}（绑定时间：${date}）`;
      });

      const c = cfg();
      const maxBinds = Number(c.maxBindsPerQQ) || 0;
      const limitStr = maxBinds > 0 ? ` / 上限 ${maxBinds} 个` : '';

      return { content: `你绑定了 ${myBinds.length} 个账号${limitStr}：\n${lines.join('\n')}` };
    }
  };
}

// ── 生命周期 ──────────────────────────────────────────────────────

export function setup(a) {
  api = a;
  cfg = a.config;

  ensureStoreDir();

  a.registerTool(toolBind());
  a.registerTool(toolConfirm());
  a.registerTool(toolUnbind());
  a.registerTool(toolQuery());

  const c = cfg();
  const hasRcon = Boolean(c.rconHost && c.rconPassword);
  a.log(`MC白名单绑定已加载（${hasRcon ? 'RCON已配置' : '未配置RCON'}）`);
}

export function available() {
  const c = cfg();
  if (!c.rconHost || !c.rconPassword) {
    return { ok: false, reason: '还没填 RCON 地址和密码' };
  }
  return { ok: true };
}
