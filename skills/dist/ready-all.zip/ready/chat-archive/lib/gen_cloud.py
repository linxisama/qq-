#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""群聊词云生成器（chat-archive 专用）

由 Node 侧把「这段时间的群友发言」写成 JSON 传来，这里用 **jieba 分词** + **wordcloud 库**
排布成一张 PNG，最后在左下角写一行说明文字。

用法：
  python gen_cloud.py --texts <文本.json> --out <输出.png> --top 80 --min-count 3 --title "……"
  python gen_cloud.py --texts <文本.json> --dry          # 只分词不画图（给"词表预览"用）

stdout 只输出一行 JSON（供 Node 解析）：
  {"ok":true,"image":"…","messages":123,"validWords":234,"placed":80,"top":[["词",次数],…]}

为什么用 Python 这两个库、而不是自己在 Node 里写：
  · **jieba** 是真分词：Node 侧没有词典，只能靠 n-gram 暴力统计，出来的是「人喊」「存一」
    这种切错边界的碎片 —— 词云一眼看过去就不像人话。
  · **wordcloud** 库内部按**排名**缩放字号（relative_scaling）、用积分图做碰撞检测，
    又快又密。自己写螺旋排布踩过的坑：群聊高频词次数咬得很紧（9 次 vs 3 次），按频率
    归一化会让所有词都撑到最大字号，几十个词就把画布塞满、后面全放不下。

依赖（pillow / jieba / wordcloud / numpy）：本机装在 data/py-cloud 这个独立虚拟环境里，
不动系统 Python。装法：python -m venv <data>/py-cloud && <data>/py-cloud/Scripts/pip install jieba wordcloud pillow
"""

import argparse
import json
import os
import re
import sys
import time
from collections import Counter

for _s in (sys.stdout, sys.stderr):
    try:
        _s.reconfigure(encoding="utf-8")
    except Exception:
        pass

# ── 内置停用词 ────────────────────────────────────────────────────────────
# 中文虚词 + 群聊口头禅 + 机器人状态卡里爱冒的通用词。
# ⚠️ 刻意**没有**屏蔽「姐姐」：在这类群里它是实打实的内容词（本群出现 300+ 次），
#    通用停用词表把它当寒暄词屏蔽掉是错的。要屏蔽的词由设置里的"额外屏蔽词"补。
STOP_WORDS = set("""
的 了 是 在 我 你 他 她 它 们 我们 你们 他们 咱们 自己 大家 各位
这 那 这个 那个 这些 那些 这样 那样 这么 那么 这里 那里 这种 那种
什么 怎么 为什么 咋 咋样 怎样 如何 多少 哪个 哪儿 哪里 谁
就 就是 还是 也是 都是 只是 但是 可是 不过 而且 或者 还有 然后 因为 所以 如果 虽然
可以 应该 可能 需要 必须 一定 差不多 大概 也许 其实 反正 毕竟 居然 竟然 果然
一个 一些 一下 一点 一直 一起 一样 一般 一切 一边 一次 一场 一批 一堆
没有 不是 不会 不要 不能 不用 不想 不知道 不算 不如 不管 不再
已经 曾经 现在 以前 以后 之前 之后 时候 时间 今天 明天 昨天 今年 去年
知道 觉得 感觉 认为 看到 听到 想到 发现 明白 清楚 搞不懂
出来 起来 上去 下去 过来 过去 回来 回去 进去 上来 下来
真的 好像 似乎 有点 有些 挺 太 很 更 最 特别 非常 超级
东西 事情 问题 意思 情况 样子 地方 方式 方法 原因 结果
哈哈 哈哈哈 哈哈哈哈 嘿嘿 嘻嘻 呵呵 233 2333 23333
嗯 哦 啊 呀 吧 呢 吗 嘛 啦 嘞 咯 咦 诶 哎 唉 喂 哈 嘿 唔 喔 哟
我操 卧槽 我靠 草 笑死 离谱 无语 不是吧
兄弟 老哥 老铁 朋友 各位 大佬 大哥 妹妹 小可爱
qq 引用 图片 表情 表情包 语音 视频 文件 链接 转发 撤回 拍一拍 消息 群聊 聊天 记录
at reply image img url amr record file video json png jpg gif
""".split())

# ── 调色板（白底深色，对比度足够；取自设计系统 600 档）───────────────────
PALETTE = [
    (215, 90, 48), (153, 60, 29), (31, 110, 86), (12, 68, 124), (60, 52, 137),
    (153, 53, 86), (186, 117, 23), (59, 109, 17), (163, 45, 45), (95, 94, 90),
    (127, 119, 221), (29, 158, 117), (214, 83, 126), (55, 138, 221), (99, 153, 34),
    (113, 43, 19), (8, 80, 65), (60, 34, 137), (114, 36, 62), (99, 55, 6),
]

CQ_RE = re.compile(r"\[CQ:[^\]]*\]")
URL_RE = re.compile(r"https?://\S+|www\.\S+")
AT_RE = re.compile(r"@[^\s@]{1,20}")
CN_CHAR = re.compile(r"[\u4e00-\u9fff]")
NUM_SYM = re.compile(r"^[\d\W_]+$")
# 系统提示类文本（退群/撤回/红包…）不是聊天内容
SYS_HINT = ("撤回了一条消息", "加入了群聊", "邀请了", "移出了群聊", "开启了全员禁言",
            "群主已同意", "上传了", "发起了群投票", "的红包", "领取了")
# 状态卡片：群里发「\状态」会回一张卡（版本/平台/运行时长），词频极高但不是聊天内容
CARD_RE = re.compile(r"运行时长|状态面板|平台[:：]\s*win|版本[:：]\s*\d+\.\d+|今日消耗|余额[:：]")


def parse_args():
    p = argparse.ArgumentParser(description="群聊词云生成器（chat-archive）")
    p.add_argument("--texts", required=True, help="发言文本的 JSON 文件（数组）")
    p.add_argument("--out", default="", help="输出 PNG 路径（--dry 时不需要）")
    p.add_argument("--top", type=int, default=80, help="最多显示多少个词")
    p.add_argument("--min-count", type=int, default=3, help="词频下限")
    p.add_argument("--font", default="C:/Windows/Fonts/msyh.ttc", help="中文字体文件")
    p.add_argument("--width", type=int, default=1400)
    p.add_argument("--height", type=int, default=900)
    p.add_argument("--stopwords", default="", help="额外停用词，逗号分隔")
    p.add_argument("--strip-words", default="", help="分词前直接从文本里删掉的字符串（机器人名字、群友外号），逗号分隔")
    p.add_argument("--title", default="", help="底部说明文字；留空则自动生成")
    p.add_argument("--min-len", type=int, default=2, help="词长下限")
    p.add_argument("--seed", type=int, default=42, help="排布随机种子（固定值＝同一批词出同一张图）")
    p.add_argument("--dry", action="store_true", help="只分词统计，不画图")
    return p.parse_args()


def fail(msg):
    print(json.dumps({"ok": False, "error": str(msg)}, ensure_ascii=False))
    sys.exit(1)


def strip_quotes(s):
    """去掉 QQ Agent 存档里的【引用】前缀。

    存档里的引用长这样（引号里还可能嵌一层，比如 [image]）：
      [引用 儒雅随和的大肥鱼(QQ:921061244)：[image]]@儒雅随和的大肥鱼 这期神了
    用正则 `\\[[^\\]]*\\]` 会在内层那个 `]` 上提前收尾、清不干净，于是
    QQ / 引用 / image 这些噪声词就会爬到词云最上面（实测它们能占到 500+ 次）。
    所以这里按**括号配对**扫一遍，把整块挖掉。
    """
    out = []
    i = 0
    n = len(s)
    while i < n:
        if s.startswith("[引用", i):
            depth = 0
            j = i
            while j < n:
                if s[j] == "[":
                    depth += 1
                elif s[j] == "]":
                    depth -= 1
                    if depth == 0:
                        j += 1
                        break
                j += 1
            out.append(" ")
            i = j
            continue
        out.append(s[i])
        i += 1
    return "".join(out)


def clean_text(s, strip_words=()):
    s = strip_quotes(s)
    s = CQ_RE.sub(" ", s)
    s = URL_RE.sub(" ", s)
    s = AT_RE.sub(" ", s)
    # 机器人自己的名字 / 群友外号：群里天天 @ 它，不去掉的话「儒雅」「随和」「大肥鱼」
    # 会霸占词云最上面（实测合计 600+ 次），而那不是大家在聊的内容。
    for w in strip_words:
        if w:
            s = s.replace(w, " ")
    return s


def load_texts(path, strip_words=()):
    if not os.path.exists(path):
        fail(f"文本文件不存在：{path}")
    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)
    if not isinstance(data, list):
        fail("文本文件格式不对：应该是字符串数组")
    out = []
    for raw in data:
        s = str(raw or "")
        if not s or any(h in s for h in SYS_HINT):
            continue
        if CARD_RE.search(s):
            continue
        c = clean_text(s, strip_words)
        # ⚠️ 截断必须放在清理之后：语音/文件类 CQ 码能长到 460+ 字符，
        #    先按长度截断会把结尾的 ] 切掉，CQ 码匹配不上、清不掉，
        #    词云上就会冒出 record / file / url / amr 这些噪声词（踩过）。
        if len(c) > 400:
            c = c[:400]
        out.append(c)
    return out


def tokenize(texts, stop, min_len=2):
    import jieba
    jieba.setLogLevel(60)
    counter = Counter()
    for c in texts:
        for w in jieba.lcut(c):
            w = w.strip()
            if len(w) < min_len:
                continue
            if NUM_SYM.match(w):
                continue
            if not CN_CHAR.search(w) and not w.isalpha():
                continue
            if w.lower() in stop:
                continue
            counter[w] += 1
    return counter


def pick_items(counter, min_count, top):
    items = [(w, c) for w, c in counter.most_common() if c >= min_count]
    # 小群 / 冷清期本来词就少：阈值过滤后铺不满画面时放宽到 2 次，
    # 免得词云上只有孤零零十几个词，看着像出错了。
    if len(items) < 25:
        items = [(w, c) for w, c in counter.most_common(80) if c >= 2]
    if len(items) < 5:
        items = counter.most_common(min(40, len(counter)))
    return items[:top]


def render_cloud(items, font_path, W, H, max_words, title, seed):
    from PIL import Image, ImageDraw, ImageFont
    from wordcloud import WordCloud

    wc_h = H - 54                      # 底部留给说明文字

    def color_func(word, font_size, position, orientation, random_state=None, **kwargs):
        # 按词的哈希取色：同一个词每次生成颜色一致，不会闪来闪去
        h = sum(ord(c) for c in word)
        r, g, b = PALETTE[h % len(PALETTE)]
        return f"rgb({r},{g},{b})"

    wc = WordCloud(
        font_path=font_path,
        width=W,
        height=wc_h,
        background_color="white",
        max_words=max_words,
        prefer_horizontal=0.92,
        relative_scaling=0.5,
        min_font_size=13,
        max_font_size=int(min(wc_h, W) * 0.17),
        collocations=False,
        margin=3,
        random_state=seed,
        color_func=color_func,
    )
    wc.generate_from_frequencies(dict(items))

    canvas = Image.new("RGB", (W, H), (255, 255, 255))
    canvas.paste(wc.to_image(), (0, 0))
    if title:
        d = ImageDraw.Draw(canvas)
        try:
            tf = ImageFont.truetype(font_path, 22)
            d.text((16, H - 38), title, font=tf, fill=(140, 138, 130))
        except Exception:
            pass
    return canvas, wc.words_


def main():
    args = parse_args()
    stop = set(STOP_WORDS)
    if args.stopwords.strip():
        stop |= {w.strip().lower() for w in re.split(r"[,，、;；\s]+", args.stopwords) if w.strip()}
    strip_words = [w.strip() for w in re.split(r"[,，、;；\s]+", args.strip_words) if w.strip()]

    raw = load_texts(args.texts, strip_words)
    texts = [t for t in raw if t.strip()]
    if not texts:
        fail("这段时间没有可用的群友发言")
    counter = tokenize(texts, stop, args.min_len)
    if not counter:
        fail("没有统计出有效词")
    items = pick_items(counter, args.min_count, args.top)
    if not items:
        fail("没有达到词频下限的词")

    if args.dry:
        print(json.dumps({
            "ok": True, "dry": True, "messages": len(texts),
            "validWords": len(counter),
            "top": [[w, c] for w, c in items],
        }, ensure_ascii=False))
        return

    if not args.out:
        fail("缺 --out")
    img, words = render_cloud(items, args.font, args.width, args.height, args.top, args.title, args.seed)
    if not words:
        fail("排布失败：没有词能被放下")
    out = os.path.abspath(args.out)
    os.makedirs(os.path.dirname(out), exist_ok=True)
    img.save(out, "PNG", optimize=True)

    top = sorted(((w, counter[w]) for w in words), key=lambda kv: -kv[1])[:12]
    print(json.dumps({
        "ok": True, "image": out, "messages": len(texts),
        "validWords": len(counter), "placed": len(words),
        "top": [[w, c] for w, c in top],
    }, ensure_ascii=False))


if __name__ == "__main__":
    t0 = time.time()
    try:
        main()
    except SystemExit:
        raise
    except Exception as e:
        fail(f"{type(e).__name__}: {e}")
