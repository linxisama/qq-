// 守望先锋（Overwatch / OWCS）电竞赛事查询技能（LLM 型）—— 查最近赛程、近期赛果。
//
// 为什么是 skill 而不是 plugin：什么时候该查、查哪几天、查哪支队，只能由模型
// 理解用户的话来判断，没有"满足条件必然执行"的时机，故走 registerTool + prompt 引导。
// 零第三方依赖：原生 fetch + JSON/HTML 正则解析。
//
// ── 数据源实测结论（2026-10-11 在本机实测，勿凭记忆改动）──────────────────
//   【主源·首选】owtics.gg —— 守望先锋官方赛事数据站（用户指定，2026-10-11 实测）：
//             ⭐ 它的网页是 React Router v7 + Apollo GraphQL，但**公开 GraphQL 端点可直连**，
//                无需任何鉴权/API Key：
//                  POST https://api.owtics.gg/graphql
//                  headers: Content-Type: application/json
//               实测直接 POST 一个 query 就返回结构化 JSON（200），内省也开放。
//             本技能用到的三个查询（全部实测通过）：
//                · scheduledMatches(limit:N)              未来已排期的比赛
//                · recentMatches(days:N, limit:N)         最近 N 天已结束的比赛
//                · matchesInRange(from:DateTime!, to:DateTime!) 任意时间窗内的比赛
//             每条 Match 的字段（实测）：
//                · scheduledAt   ISO 8601 UTC 时间戳（如 "2026-10-11T06:00:00.000Z"），
//                  比 Liquipedia 的 Unix 秒更省事，可直接 Date.parse；
//                · teamA / teamB → Team{ name 全名, abbreviation 缩写, slug, region }，
//                  **队伍全名和缩写都有**，中文界面下赛事名也是中文（"2026 OWCS ASIA - KOREA STAGE 3"）；
//                · competition → { title, slug, tier(S|A|QUALIFIER), region, series }，
//                  tier 直接给出了赛事等级，不用自己靠关键词猜；
//                · status 枚举：UPCOMING | COMPLETED | LIVE（LIVE 是"正在进行中"，
//                  本技能把 LIVE 也当未结束处理，会显示"进行中"）；
//                · format 枚举：FT2 | FT3 | FT4（即 BO3 / BO5 / BO7，"FT" = First To）；
//                · result → { teamAScore, teamBScore, winner{...} }（仅已结束才有，未开始时为 null）；
//                · phaseInfo → { name(REGULAR_SEASON|PLAYOFFS|...), format }。
//             额外能力（本技能暂未用，但已确认可用）：teams(search:...) 按队名搜索、
//                teamBySlug(slug:...).recentMatches/upcomingMatches 查单队赛程赛果、
//                matchById(id).mapResults 单图明细、competitions(...) 赛事列表。
//             ⚠️ 陷阱：teams / competitions 返回的是 **Paginated 包装**，字段必须写成
//                teams(search:"x"){ totalCount items{ ... } }，直接写 items 里的字段会
//                报 "Cannot query field ... on type TeamPaginated"。
//             ⚠️ 陷阱：matchesInRange 的变量类型是 **DateTime!**（非空），写成 DateTime 会
//                报 "used in position expecting type DateTime!"。
//             ⚠️ 网络：api.owtics.gg 走 Cloudflare，偶发连接超时（ConnectTimeoutError），
//                本技能的重试逻辑会兜住，见 fetchJson。
//
//   【次源】Liquipedia 守望先锋分站的"比赛聚合页"（无需任何 API Key）：
//             https://liquipedia.net/overwatch/api.php?action=parse
//               &page=Liquipedia:Matches&prop=text&format=json&formatversion=2
//           实测：HTTP 200，单请求返回全站 upcoming + finished 各 50 场（共 100 条）
//           的渲染 HTML（约 374KB）。结构与本项目 lol-match 技能所用的
//           Liquipedia:Matches **同构**，每场一个 <div class="match-info"> 块：
//             · <span class="timer-object" data-timestamp="1791698400">，
//               已结束的还带 data-finished="finished" 且 class 变为
//               "timer-object timer-object-datetime-only"；
//               data-timestamp 是 Unix 秒（UTC，无需解析时区缩写）；
//             · 左右队伍各一个 <div class="match-info-header-opponent ...">，缩写队名
//               在 <span class="name"><a title="全称">缩写</a></span>；
//             · 未开始：scoreholder-upper 里是文本 "vs"，scoreholder-lower 是 "(Bo5)"；
//               已结束：scoreholder-upper 里是两个
//               <span class="match-info-header-scoreholder-score ...">3</span> /
//               <span class="...">1</span>（胜方那个额外带 match-info-header-winner），
//               胜方 opponent div 带 "match-info-header-winner"、败方带 "match-info-header-loser"；
//             · 赛事名在 <span class="match-info-tournament-name"><a ...><span>OWCS Korea
//               Stage 3 - Regular Season - Week 2</span></a></span>，链接 title 是 wiki
//               页面路径（如 "Overwatch Champions Series/2026/Asia/Stage_3/Korea/..."）。
//           ⚠️ Liquipedia 对普通网页首页（/overwatch/Main_Page）返回 **403**（反爬），
//              但 api.php 这个解析端点实测 **200 可用** —— 所以必须走 api.php，不要抓网页。
//           ToU 限 2 请求/秒，且必须用自报身份的 UA（LIQUID_UA）。本技能每次查询只打 1 次。
//
//   【兜底】owtv.gg（用户最早指定）：
//             https://owtv.gg/ 与 https://owtv.gg/matches 实测 HTTP 200，
//             但它是 React Server Components 流式渲染站点 —— 页面里**没有**
//             __NEXT_DATA__，数据被转义在 self.__next_f.push([...]) 的字符串数组里，
//             而且 /api/matches、/api/schedule 都返回 404（无公开 JSON 接口）。
//             故它只能作为**前两个源都失败时的最后兜底**：尽力从 self.__next_f 的转义串里
//             抠出 "team1/team2/startTime/..." 这样的对象；抠不出来就如实报告失败，
//             **绝不编造**。它的页面结构随时可能变，不要把它当主源。
//
//   【三源取舍】owtics.gg 数据最全最准（有队伍全名、赛区、赛事等级、精确时间、比分、
//   中文赛事名），且是结构化接口 —— 所以**优先用它**；它挂了再退 Liquipedia；
//   两个都挂了才试 owtv.gg。任何一个源给出的结果都会在输出里标明来源。
//   三个源都不承诺 100% 覆盖：owtics 覆盖 OWCS 各级赛事最全，Liquipedia 收录更广但
//   只有大比分，owtv 只作兜底。所以输出里一律标注"非官方补充来源，仅供参考"。
//
// ── 第三方数据使用口径（沿用本项目 lol-match / cs2-match 的一贯做法）────────────
//   · 输出里凡是用到 owtics.gg / Liquipedia / owtv.gg，必须明确标注"非官方补充来源"，仅供参考；
//   · 不引入任何第三方交叉比对：不打分、不标注"一致/不一致"；
//   · 绝不声称数据经过验证——数据仅供参考，以官方渠道发布为准。
//
// ── 时间窗语义（与 lol-match 保持一致）────────────────────────────────────
//   · **赛程工具绝不按 state 过滤掉已结束的比赛**：用户问「今天有什么比赛」时，
//     当天已打完的必须照样列出（✅ 标注 + 带比分），否则就是数据丢失；
//   · 时间窗 =「含今天在内的 N 个自然日」，起点用目标时区的当天 00:00，
//     不能用 now - 6h ~ now + N*24h 这种相对窗口（当天已结束的比赛会掉出窗外）；
//   · 时区换算不能用 Date.UTC 硬算，必须用 Intl 取目标时区的年月日再换算，
//     并在夏令时切换日做二次校正（见 startOfDayInTz）。
//
// ── 功能 ────────────────────────────────────────────────────────────────
//   · 战队筛选：不填就全报；填了就只报这些战队，中文名 ↔ 英文名/缩写双向匹配。
//   · 赛事过滤：默认**不**按赛事等级过滤，各赛事都报；用户点名赛事（leagues 参数，
//     如 OWCS、大师赛、韩国赛区）就只报该赛事；设置里另有「只看一线赛事」开关（默认关）。
//     点名战队时一线开关自动失效。**被过滤掉的数量会如实告知。**
//   · 赛程：从「今天 00:00」起算 N 个自然日，含今天已结束（✅+比分）、未开始两类。
//   · 赛果：已结束比赛的大比分与胜方。
//
// 说明：OW 是地图制（BO5 先赢 3 张图获胜），但 Liquipedia 的 Matches 聚合页只给
// 大比分（地图数），不提供每张图的胜方与回合比分明细 —— 所以本技能**只报大比分**，
// 不猜、不编每张图的胜负（与 valorant-match 的处理口径一致）。

let cfg = () => ({});
let httpFetch = null;
let logger = null;

const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Safari/537.36';
// Liquipedia 使用条款要求自报身份的 UA，且限 2 请求/秒（本技能每次查询只打 1 次）
const LIQUID_UA = 'QQAgent-OwMatch/1.0 (local user skill for Overwatch schedule/results; contact: local user)';

const LIQUID_API = 'https://liquipedia.net/overwatch/api.php';
const OWTV_URL = 'https://owtv.gg/matches';
// owtics.gg 的公开 GraphQL 端点（2026-10-11 实测：无需鉴权，直接 POST query 即返回 200）
const OWTICS_GQL = 'https://api.owtics.gg/graphql';
const OWTICS_SITE = 'https://owtics.gg';
// owtics 的赛事分级枚举（实测）：S=顶级、A=次级、QUALIFIER=资格赛
const OWTICS_TIER_LABEL = { S: 'S级', A: 'A级', QUALIFIER: '资格赛' };
// owtics 赛区枚举 → 中文（实测枚举成员）
const OWTICS_REGION_CN = {
  GLOBAL: '全球', ASIA: '亚洲', EMEA: '欧洲/中东', SAUDI_ARABIA: '沙特',
  NORTH_AMERICA: '北美', AMERICAS: '美洲', PACIFIC: '太平洋',
  JAPAN: '日本', CHINA: '中国', KOREA: '韩国'
};

// ── 战队中英文对照：别名 → 用于匹配的关键词（队名缩写 or 英文名片段）───────────
// 匹配前两边都会小写化；长度 ≤3 的关键词只允许完全等于 code（避免误伤，见 teamMatchesToken）。
const TEAM_ALIASES = {
  // 中国战队
  '上海龙': ['shanghai dragons', 'shd', 'dragons'], '上海龙之队': ['shanghai dragons', 'shd'],
  'shanghai dragons': ['shanghai dragons', 'shd'], 'shd': ['shd'],
  '杭州闪电': ['hangzhou spark', 'hzs'], '杭州闪电队': ['hangzhou spark', 'hzs'],
  'hangzhou spark': ['hangzhou spark', 'hzs'], 'hzs': ['hzs'],
  '广州冲锋': ['guangzhou charge', 'gzc'], '广州冲锋队': ['guangzhou charge', 'gzc'],
  'guangzhou charge': ['guangzhou charge', 'gzc'], 'gzc': ['gzc'],
  '成都猎人': ['chengdu hunters', 'cdh'], 'chengdu hunters': ['chengdu hunters', 'cdh'], 'cdh': ['cdh'],
  // 韩国战队
  '首尔王朝': ['seoul dynasty', 'sdy'], 'seoul dynasty': ['seoul dynasty', 'sdy'], 'sdy': ['sdy'],
  '首尔烈火': ['seoul infernal', 'sinf'], 'seoul infernal': ['seoul infernal'],
  't1': ['t1'],
  // 欧美及其他
  'o2 blast': ['o2 blast', 'o2b'], 'o2b': ['o2b'],
  'team falcons': ['falcons', 'tmf'], 'falcons': ['falcons'], '猎鹰': ['falcons'],
  '旧金山震动': ['san francisco shock', 'sfs'], 'san francisco shock': ['san francisco shock', 'sfs'], 'sfs': ['sfs'],
  '洛杉矶英勇': ['los angeles valiant', 'lav'], 'los angeles valiant': ['los angeles valiant'],
  '洛杉矶角斗士': ['los angeles gladiators', 'lag'], 'los angeles gladiators': ['los angeles gladiators'],
  '达拉斯燃料': ['dallas fuel', 'dal'], 'dallas fuel': ['dallas fuel'],
  '伦敦喷火': ['london spitfire', 'ldn'], 'london spitfire': ['london spitfire'],
  '费城融合': ['philadelphia fusion', 'phi'], 'philadelphia fusion': ['philadelphia fusion'],
  '洛杉矶英勇队': ['los angeles valiant'],
  '多伦多捍卫者': ['toronto defiant', 'tor'], 'toronto defiant': ['toronto defiant'],
  '温哥华泰坦': ['vancouver titans', 'van'], 'vancouver titans': ['vancouver titans'],
  '弗罗里达狂欢': ['florida mayhem', 'flm'], 'florida mayhem': ['florida mayhem'],
  '休斯顿神枪手': ['houston outlaws', 'hou'], 'houston outlaws': ['houston outlaws'],
  '亚特兰大君临': ['atlanta reign', 'atl'], 'atlanta reign': ['atlanta reign'],
  '华盛顿正义': ['washington justice', 'was'], 'washington justice': ['washington justice'],
  '纽约九霄天擎': ['new york excelsior', 'nye'], 'new york excelsior': ['new york excelsior'],
  '波士顿崛起': ['boston uprising', 'bos'], 'boston uprising': ['boston uprising'],
  '巴黎永生': ['paris eternal', 'par'], 'paris eternal': ['paris eternal'],
  '正义': ['justice'], '狂欢': ['mayhem'], '神枪手': ['outlaws'], '崛起': ['uprising'],
  '角斗士': ['gladiators'], '喷火': ['spitfire'], '融合': ['fusion'], '泰坦': ['titans'], '捍卫者': ['defiant']
};

// 判定"一线赛事"时要排除的次级/青训赛事关键词（避免 OWCS 把其它同名前缀也算进来）
const TOP_EXCLUDE = [
  'academy', 'challengers', 'open', 'contenders', 'amateur', 'relegation',
  'qualifier', 'qualifiers', 'promotion', 'trial', 'trials', 'youth', 'collegiate'
];

// ── 赛事别名：用户口径的中文/口语名 → 数据源里的英文名 ─────────────────────────
const LEAGUE_ALIASES = {
  '守望先锋冠军系列赛': ['owcs', 'overwatch champions series'],
  'owcs': ['owcs', 'overwatch champions series'],
  '守望先锋联赛': ['owl', 'overwatch league'],
  'owl': ['owl', 'overwatch league'],
  'ow': ['owcs', 'overwatch champions series'],
  '大师赛': ['masters'],
  '冠军赛': ['champions'],
  '韩国赛区': ['korea'],
  '亚洲赛区': ['asia'],
  '欧洲赛区': ['emea', 'europe'],
  '北美赛区': ['north america', 'na '],
  '常规赛': ['regular season'],
  '季后赛': ['playoffs']
};

// ── 通用小工具 ───────────────────────────────────────────────────────────
function clamp(n, lo, hi, fallback) {
  const v = Number(n);
  if (!isFinite(v)) return fallback;
  return Math.min(hi, Math.max(lo, v));
}

const WEEKDAY_MAP = {
  周一: '周一', 周二: '周二', 周三: '周三', 周四: '周四', 周五: '周五', 周六: '周六', 周日: '周日',
  星期一: '周一', 星期二: '周二', 星期三: '周三', 星期四: '周四', 星期五: '周五', 星期六: '周六', 星期日: '周日'
};

/** 毫秒时间戳 → 用户时区的「M月D日 周X HH:MM」 */
function fmtTime(ms, tz) {
  const d = new Date(ms);
  try {
    const parts = new Intl.DateTimeFormat('zh-CN', {
      timeZone: tz, month: 'numeric', day: 'numeric',
      weekday: 'short', hour: '2-digit', minute: '2-digit', hour12: false
    }).formatToParts(d);
    const p = {};
    for (const x of parts) p[x.type] = x.value;
    const w = WEEKDAY_MAP[p.weekday] || p.weekday;
    return `${Number(p.month)}月${Number(p.day)}日 ${w} ${p.hour}:${p.minute}`;
  } catch {
    return d.toISOString().replace('T', ' ').slice(0, 16);
  }
}

/**
 * 目标时区在 ms 时刻的 UTC 偏移（毫秒）。
 * 用 Intl 逐字段取值再拼回 UTC，避免依赖本机时区；hour 取模 24 是因为部分环境下
 * hour12:false 的午夜会返回 "24"。
 */
function tzOffsetMs(ms, tz) {
  const parts = new Intl.DateTimeFormat('en-US', {
    timeZone: tz, hour12: false,
    year: 'numeric', month: '2-digit', day: '2-digit',
    hour: '2-digit', minute: '2-digit', second: '2-digit'
  }).formatToParts(new Date(ms));
  const p = {};
  for (const x of parts) p[x.type] = x.value;
  const asIfUtc = Date.UTC(
    Number(p.year), Number(p.month) - 1, Number(p.day),
    Number(p.hour) % 24, Number(p.minute), Number(p.second)
  );
  return asIfUtc - Math.floor(ms / 1000) * 1000;
}

/**
 * ms 所在「自然日」在该时区的 00:00 对应的 UTC 毫秒。
 * 夏令时切换日做二次校正：先用初次偏移算出午夜，再用午夜自身的偏移复核。
 * 不能改成相对窗口（见文件头"时间窗语义"）。
 */
function startOfDayInTz(ms, tz) {
  try {
    const parts = new Intl.DateTimeFormat('en-US', {
      timeZone: tz, year: 'numeric', month: '2-digit', day: '2-digit'
    }).formatToParts(new Date(ms));
    const p = {};
    for (const x of parts) p[x.type] = x.value;
    const utcGuess = Date.UTC(Number(p.year), Number(p.month) - 1, Number(p.day), 0, 0, 0, 0);
    let midnight = utcGuess - tzOffsetMs(utcGuess, tz);
    const off2 = tzOffsetMs(midnight, tz);
    if (off2 !== tzOffsetMs(utcGuess, tz)) midnight = utcGuess - off2;
    return midnight;
  } catch {
    return Math.floor(ms / 86400000) * 86400000;
  }
}

/** 该场是否为「对阵待定」（数据源常见 TBD vs TBD / 队伍缺失） */
function isTbdRow(m) {
  const norm = (s) => String(s || '').trim().toUpperCase();
  const a = norm(m?.code1);
  const b = norm(m?.code2);
  return !a || !b || a === 'TBD' || b === 'TBD' || a === '待定' || b === '待定';
}

/** 赛程行的状态前缀：已结束 ✅ / 进行中 🔴 / 未开始 无前缀 */
function scheduleStatePrefix(state) {
  if (state === 'completed') return '✅ ';
  if (state === 'live') return '🔴 ';
  return '';
}

/** 逗号/顿号/分号/竖线/空白分隔的普通列表 */
function readList(raw) {
  return String(raw || '')
    .split(/[,，、;；|\s]+/)
    .map((s) => s.trim())
    .filter(Boolean);
}

/**
 * 战队筛选词列表。先按逗号类符号切；如果整个片段是已知别名（如 "O2 Blast"），
 * 就整体保留，不拆开。
 */
function readTeamList(raw) {
  const parts = String(raw || '')
    .split(/[,，、;；|]+/)
    .map((s) => s.trim())
    .filter(Boolean);
  const out = [];
  for (const p of parts) {
    const low = p.toLowerCase();
    if (TEAM_ALIASES[low] || TEAM_ALIASES[p]) { out.push(p); continue; }
    if (/\s/.test(p)) { out.push(...p.split(/\s+/).filter(Boolean)); continue; }
    out.push(p);
  }
  return out;
}

/**
 * 某个 token 是否命中一支战队。
 * 长度 ≤3 的关键词只允许**完全等于**战队 code，避免 'shd' 之类误伤别队名；
 * 4 字符及以上的关键词才允许做名字包含匹配（沿用 lol-match 的踩坑经验）。
 */
function teamMatchesToken(team, token) {
  const code = String(team?.code || '').toLowerCase();
  const name = String(team?.name || '').toLowerCase();
  const t = String(token || '').toLowerCase().trim();
  if (!t || (!code && !name)) return false;
  if (code === t) return true;
  if (!code) {
    if (name === t) return true;
    const esc = t.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    return new RegExp(`(^|[^a-z0-9])${esc}([^a-z0-9]|$)`).test(name);
  }
  if (t.length <= 3) return false;
  if (code.includes(t)) return true;
  return name.includes(t);
}

/** 一支战队是否命中任一筛选词 */
function matchTeam(team, filters) {
  if (!filters.length) return true;
  for (const f of filters) {
    const key = String(f).trim().toLowerCase();
    if (!key) continue;
    const tokens = TEAM_ALIASES[key] || TEAM_ALIASES[f] || [key];
    for (const tk of tokens) {
      if (teamMatchesToken(team, tk)) return true;
    }
  }
  return false;
}

/** 归一化：小写、去掉空格/连字符/下划线/点，用于赛事名宽松比对 */
function normKey(s) {
  return String(s || '').toLowerCase().replace(/[\s\-_.]+/g, '');
}

/** 一个赛事关键词 → 参与匹配的关键词组（含别名展开，全部 normKey 过） */
function expandLeagueTokens(token) {
  const t = String(token || '').trim();
  if (!t) return [];
  const out = [normKey(t)];
  for (const a of LEAGUE_ALIASES[t.toLowerCase()] || []) out.push(normKey(a));
  return out;
}

/**
 * 某个关键词是否命中一个赛事。name 和 slug 都参与比对。
 * ≤3 字符的关键词只允许完全等于；4 字符以上才允许包含式匹配。
 */
function leagueMatchesToken(league, token) {
  const name = normKey(league?.name);
  const slug = normKey(league?.slug);
  if (!name && !slug) return false;
  for (const tk of expandLeagueTokens(token)) {
    if (!tk) continue;
    if (name === tk || slug === tk) return true;
    if (tk.length >= 4 && (name.includes(tk) || slug.includes(tk))) return true;
  }
  return false;
}

/** 赛事是否属于"一线赛事"。 */
function isTopLeague(league, tokens) {
  const normName = normKey(league?.name);
  const normSlug = normKey(league?.slug);
  const hay = `${normName} ${normSlug}`;
  for (const ex of TOP_EXCLUDE) {
    if (hay.includes(ex)) return false;
  }
  for (const t of tokens) {
    for (const tk of expandLeagueTokens(t)) {
      if (!tk) continue;
      if (normName === tk || normSlug === tk) return true;
      if (normName.includes(tk) || normSlug.includes(tk)) return true;
    }
  }
  return false;
}

// ── HTTP ────────────────────────────────────────────────────────────────
/**
 * 带 JSON 解析与瞬时重试的 GET。
 * 重试纪律（沿用 lol-match）：只在**连接层失败**（fetch reject / 超时 / 读响应体失败）
 * 后等 800ms 重试一次；HTTP 4xx/5xx 是服务器明确响应，绝不重试；JSON 解析失败也不重试。
 */
async function fetchJson(url, timeoutMs, headers, init) {
  const attempt = async () => {
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), timeoutMs);
    try {
      const res = await httpFetch(url, {
        signal: ctrl.signal,
        redirect: 'follow',
        method: (init && init.method) || 'GET',
        body: init && init.body,
        headers: { 'User-Agent': UA, 'Accept': 'application/json', ...(headers || {}) }
      });
      if (res.status === 204) return { error: '无数据（204）' };
      if (!res.ok) return { error: `HTTP ${res.status}` };
      const text = await res.text();
      if (!text) return { error: '空响应' };
      const data = JSON.parse(text);
      return { data };
    } catch (e) {
      if (e instanceof SyntaxError) {
        return { error: `抓取失败：解析 JSON 失败：${e.message}` };
      }
      const msg = e?.name === 'AbortError' ? `超时（${timeoutMs}ms）` : (e?.message ?? String(e));
      return { error: `抓取失败：${msg}`, transient: true };
    } finally {
      clearTimeout(timer);
    }
  };
  let out = await attempt();
  if (out.transient) {
    if (logger) logger.warn?.('ow-match: 网络瞬时故障，800ms 后重试一次：%s', url);
    await new Promise((r) => setTimeout(r, 800));
    out = await attempt();
  }
  return out.error ? { error: out.error } : out;
}

/** 取纯文本（供 owtv.gg 的 HTML 备用源用），同样只在连接层失败时重试一次。 */
async function fetchText(url, timeoutMs, headers) {
  const attempt = async () => {
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), timeoutMs);
    try {
      const res = await httpFetch(url, {
        signal: ctrl.signal,
        redirect: 'follow',
        headers: { 'User-Agent': UA, 'Accept': 'text/html,*/*', ...(headers || {}) }
      });
      if (!res.ok) return { error: `HTTP ${res.status}` };
      const text = await res.text();
      if (!text) return { error: '空响应' };
      return { text };
    } catch (e) {
      const msg = e?.name === 'AbortError' ? `超时（${timeoutMs}ms）` : (e?.message ?? String(e));
      return { error: `抓取失败：${msg}`, transient: true };
    } finally {
      clearTimeout(timer);
    }
  };
  let out = await attempt();
  if (out.transient) {
    await new Promise((r) => setTimeout(r, 800));
    out = await attempt();
  }
  return out.error ? { error: out.error } : out;
}

// ── HTML 文本反转义 ─────────────────────────────────────────────────────
function decodeHtmlText(s) {
  return String(s || '')
    .replace(/&amp;/g, '&')
    .replace(/&quot;/g, '"')
    .replace(/&#0?39;|&apos;/g, "'")
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&nbsp;/g, ' ');
}

/** 剥掉标签，只留文本（用于取"赛事名"里嵌套的 <span> 内文） */
function stripTags(s) {
  return decodeHtmlText(String(s || '').replace(/<[^>]*>/g, '')).replace(/\s+/g, ' ').trim();
}

// ── 主源·首选：owtics.gg 公开 GraphQL ────────────────────────────────────
/**
 * 对 owtics GraphQL 发一个 POST 查询，返回 { data } 或 { error }。
 * 复用 fetchJson 的重试纪律（只在连接层失败时重试一次）。
 * 注意 GraphQL 的分层错误：HTTP 200 也可能带 errors 数组，需显式检查。
 */
async function owticsGql(query, variables, timeoutMs) {
  const res = await fetchJson(OWTICS_GQL, timeoutMs, {
    'Content-Type': 'application/json',
    'Origin': OWTICS_SITE,
    'Referer': OWTICS_SITE + '/'
  }, {
    method: 'POST',
    body: JSON.stringify({ query, variables: variables || {} })
  });
  if (res.error) return { error: res.error };
  const j = res.data;
  if (j && j.errors && j.errors.length) {
    return { error: `接口报错：${String(j.errors[0]?.message || '').slice(0, 160)}` };
  }
  if (!j || !j.data) return { error: '接口返回结构异常（没有 data 字段）' };
  return { data: j.data };
}

// owtics Match 的统一字段选择集（三个查询共用，避免各写一份漂移）
const OWTICS_MATCH_FIELDS = `
  id scheduledAt format status detailsUrl
  teamA { name abbreviation slug region }
  teamB { name abbreviation slug region }
  competition { title slug tier region series }
  phaseInfo { name format }
  result { teamAScore teamBScore winner { name abbreviation } }
`;

/** owtics 的 format 枚举 FT3 → BO3（FT = First To，FT3 即先赢 3 张图，BO5） */
function owticsFormatToBestOf(fmt) {
  const n = Number(String(fmt || '').replace(/[^0-9]/g, ''));
  if (!n) return null;
  // 先赢 N 张图 ⇒ 最多打 2N-1 张，即 BO(2N-1)
  return n * 2 - 1;
}

/** 把一条 owtics Match 规整成与 Liquipedia 行一致的内部结构 */
function normalizeOwticsMatch(m) {
  if (!m) return null;
  const a = m.teamA;
  const b = m.teamB;
  // 未排定对阵的比赛（teamA/teamB 为 null）整条丢弃，宁缺勿错
  if (!a || !b || !a.abbreviation || !b.abbreviation) return null;
  const ts = Date.parse(m.scheduledAt);
  if (!isFinite(ts)) return null;
  const r = m.result;
  const hasScore = r && Number.isFinite(r.teamAScore) && Number.isFinite(r.teamBScore);
  const code1 = a.abbreviation;
  const code2 = b.abbreviation;
  let winnerCode = null;
  if (hasScore && r.winner) winnerCode = r.winner.abbreviation || null;
  else if (hasScore && r.teamAScore !== r.teamBScore) winnerCode = r.teamAScore > r.teamBScore ? code1 : code2;
  const st = String(m.status || '').toUpperCase();
  const state = st === 'COMPLETED' ? 'completed' : (st === 'LIVE' ? 'live' : 'unstarted');
  const comp = m.competition || {};
  return {
    eventId: m.id || null,
    ts,
    team1: a.name || code1,
    team2: b.name || code2,
    code1,
    code2,
    score1: hasScore ? r.teamAScore : null,
    score2: hasScore ? r.teamBScore : null,
    winnerCode,
    leagueName: comp.title || 'OWCS',
    leagueSlug: comp.slug || '',
    tier: comp.tier || null,
    region: comp.region || null,
    stage: m.phaseInfo && m.phaseInfo.name ? m.phaseInfo.name : '',
    bestOf: owticsFormatToBestOf(m.format),
    state,
    teamsRaw: [
      { code: code1, name: a.name || code1, result: { gameWins: hasScore ? r.teamAScore : null } },
      { code: code2, name: b.name || code2, result: { gameWins: hasScore ? r.teamBScore : null } }
    ],
    _src: 'owtics'
  };
}

/**
 * 抓 owtics 的比赛：一次拿全「已排期」+「最近 N 天已结束」两类，合并去重。
 * 用两个查询而不是 matchesInRange，因为 scheduledMatches/recentMatches 由站点
 * 自己定义"未来/最近"边界，比我们自己算窗口更不容易漏（尤其跨时区）。
 * days 用于 recentMatches 的窗口；limit 给足（站点侧上限未知，实测 50 没问题）。
 */
async function owticsMatches(timeoutMs, days) {
  const wantDays = clamp(days, 1, 30, 7);
  const limit = 100;
  const q1 = `query($limit:Int){ scheduledMatches(limit:$limit){${OWTICS_MATCH_FIELDS}} }`;
  const q2 = `query($days:Int,$limit:Int){ recentMatches(days:$days, limit:$limit){${OWTICS_MATCH_FIELDS}} }`;
  const [r1, r2] = await Promise.all([
    owticsGql(q1, { limit }, timeoutMs),
    owticsGql(q2, { days: wantDays, limit }, timeoutMs)
  ]);
  // 两个查询只要有一个成功就继续（另一个失败不影响已有数据）
  if (r1.error && r2.error) return { error: `owtics：${r1.error}` };
  const rows = [];
  const seen = new Set();
  const add = (arr) => {
    for (const raw of arr || []) {
      const row = normalizeOwticsMatch(raw);
      if (!row) continue;
      const key = row.eventId || `${row.ts}|${row.code1}|${row.code2}`;
      if (seen.has(key)) continue;
      seen.add(key);
      rows.push(row);
    }
  };
  add(r1.data && r1.data.scheduledMatches);
  add(r2.data && r2.data.recentMatches);
  if (!rows.length) {
    // 一个成功但没数据、另一个失败：如实说明，交给上层判断
    const which = r1.error ? `（scheduledMatches 失败：${r1.error}）` : '';
    return { error: `owtics 返回的比赛条数为 0 ${which}`.trim() };
  }
  return { rows };
}

// ── 次源：Liquipedia 守望先锋比赛聚合页 ──────────────────────────────────
/**
 * 抓取 Liquipedia:Matches 渲染 HTML，按 <div class="match-info"> 分块解析。
 * 单请求返回全站 upcoming + finished 各 50 场。
 */
async function liquipediaMatches(timeoutMs) {
  const url = `${LIQUID_API}?action=parse&page=${encodeURIComponent('Liquipedia:Matches')}&prop=text&format=json&formatversion=2`;
  const res = await fetchJson(url, timeoutMs, { 'User-Agent': LIQUID_UA });
  if (res.error) return { error: res.error };
  const html = String(res.data?.parse?.text || '');
  if (!html) return { error: '返回空内容' };
  const starts = [];
  const re = /<div class="match-info">/g;
  let m;
  while ((m = re.exec(html)) !== null) starts.push(m.index);
  const rows = [];
  for (let i = 0; i < starts.length; i++) {
    const block = html.slice(starts[i], i + 1 < starts.length ? starts[i + 1] : html.length);
    const row = parseLiquipediaBlock(block);
    if (row) rows.push(row);
  }
  if (!rows.length) return { error: '页面里没解析出任何比赛条目（页面结构可能变了）' };
  return { rows };
}

/**
 * 解析单个 match-info 块 → 统一行结构。
 * 字段实测样例（2026-10-11）：
 *   未开始：<span class="timer-object" data-timestamp="1791698400">October 11, 2026 - 15:00 …</span>
 *           比分位 <span class="match-info-header-scoreholder-upper">vs</span>
 *                  <span class="match-info-header-scoreholder-lower">(Bo5)</span>
 *   已结束：timer-object 带 data-finished="finished" 与 -datetime-only 类；
 *           比分位两个 <span class="match-info-header-scoreholder-score">3</span> /
 *           <span class="... match-info-header-winner">1</span>；
 *           胜方 opponent div 带 "match-info-header-winner"、败方带 "match-info-header-loser"。
 * 解析不出时间或两支队伍就整块丢弃（宁缺勿错）。
 */
function parseLiquipediaBlock(block) {
  const tsSec = Number((block.match(/data-timestamp="(\d+)"/) || [])[1]);
  if (!Number.isFinite(tsSec) || tsSec <= 0) return null;
  const finished = /data-finished="finished"/.test(block);

  // 左右两个 opponent 块。注意：未开始时第一个 opponent div 带 -opponent-left 类，
  // 第二个没有；已结束时可能还有 -winner/-loser 类。统一按"出现顺序"取左、右，
  // 并记录哪一侧带 winner 类（已结束才有）。
  const oppRe = /<div class="match-info-header-opponent([^"]*)">[\s\S]*?<span class="name"[^>]*><a [^>]*?title="([^"]*)"[^>]*?>([^<]+)<\/a>/g;
  const opps = [];
  let om;
  while ((om = oppRe.exec(block)) !== null) {
    opps.push({
      cls: om[1] || '',
      name: decodeHtmlText(om[2]).trim(),
      code: decodeHtmlText(om[3]).trim()
    });
    if (opps.length >= 2) break;
  }
  if (opps.length < 2) return null;
  const left = opps[0];
  const right = opps[1];
  if (!left.code || !right.code) return null;

  // 比分：scoreholder-upper 里，未开始是文本 "vs"，已结束是两个 score span。
  // 用带引号的类名精确匹配，避免抓到 "(Bo5)" 或图标。
  const upMatch = block.match(/class="match-info-header-scoreholder-upper"[^>]*>([\s\S]*?)<\/span>\s*<span class="match-info-header-scoreholder-lower/);
  const upperHtml = upMatch ? upMatch[1] : '';
  let score1 = null;
  let score2 = null;
  if (finished && upperHtml && !/>\s*vs\s*</i.test(upperHtml)) {
    const scoreRe = /class="match-info-header-scoreholder-score(?: match-info-header-winner)?"[^>]*>([^<]*)</g;
    const scores = [];
    let sm;
    while ((sm = scoreRe.exec(upperHtml)) !== null) scores.push(decodeHtmlText(sm[1]).trim());
    if (scores.length >= 2) {
      score1 = scores[0] !== '' ? Number(scores[0]) : null;
      score2 = scores[1] !== '' ? Number(scores[1]) : null;
    }
  }

  // 胜方：已结束时某一侧 opponent 带 match-info-header-winner。
  // （比分 span 上也带同样类名，所以只在 opponent 的类串里找。）
  let winnerSide = null;
  if (finished) {
    if (/match-info-header-winner/.test(left.cls)) winnerSide = 'left';
    else if (/match-info-header-winner/.test(right.cls)) winnerSide = 'right';
    // 有些场次 winner 类只标在比分 span 上而不在 opponent div 上，用比分兜底判断
    if (!winnerSide && score1 != null && score2 != null && score1 !== score2) {
      winnerSide = score1 > score2 ? 'left' : 'right';
    }
  }

  const bestOf = Number((block.match(/\(Bo(\d+)\)/i) || [])[1]) || null;

  // 赛事名：优先取 match-info-tournament-name 里的 <span> 内文（最干净，
  // 如 "OWCS Korea Stage 3 - Regular Season - Week 2"）；取不到再退回链接 title。
  let leagueName = '';
  const tnameMatch = block.match(/class="match-info-tournament-name"[\s\S]{0,400}?<span>([^<]+)<\/span>/);
  if (tnameMatch) leagueName = decodeHtmlText(tnameMatch[1]).trim();
  let tpath = '';
  if (!leagueName) {
    const titleMatch = block.match(/match-info-tournament[\s\S]{0,800}?<a [^>]*?title="([^"]+)"/);
    tpath = decodeHtmlText(titleMatch ? titleMatch[1] : '');
    const segs = tpath.split('#')[0].split('/').map((s) => s.trim().replace(/_/g, ' ')).filter(Boolean);
    leagueName = segs[0] || 'Liquipedia 赛事';
  } else {
    const titleMatch = block.match(/match-info-tournament[\s\S]{0,800}?<a [^>]*?title="([^"]+)"/);
    tpath = decodeHtmlText(titleMatch ? titleMatch[1] : '');
  }

  const state = finished ? 'completed' : 'unstarted';
  return {
    eventId: null,
    ts: tsSec * 1000,
    team1: left.name || left.code,
    team2: right.name || right.code,
    code1: left.code,
    code2: right.code,
    score1,
    score2,
    winnerCode: winnerSide === 'left' ? left.code : (winnerSide === 'right' ? right.code : null),
    leagueName: leagueName || 'Liquipedia 赛事',
    leagueSlug: tpath,
    stage: '',
    bestOf,
    state,
    teamsRaw: [
      { code: left.code, name: left.name || left.code, result: { gameWins: score1 } },
      { code: right.code, name: right.name || right.code, result: { gameWins: score2 } }
    ],
    _src: 'liquipedia'
  };
}

// ── 备用源：owtv.gg（React 流式渲染，尽力解析）────────────────────────────
/**
 * owtv.gg 是 React Server Components 站点：页面无 __NEXT_DATA__，数据被转义在
 * self.__next_f.push([...]) 的字符串数组里，且无公开 JSON API（/api/* 全 404）。
 * 这里采取"尽力而为"策略：把整页文本里的转义序列解开，再用宽松正则找形如
 * {"...team1..."} 的对象；能解析出条数就返回，解析不出就如实报错，**绝不编造**。
 * 它只作主源失败时的补充，输出里会明确标注"非备用来源"。
 */
async function owtvMatches(timeoutMs) {
  const res = await fetchText(OWTV_URL, timeoutMs);
  if (res.error) return { error: res.error };
  const raw = res.text || '';
  // 先把 RSC 的转义串合并：self.__next_f.push([1,"...\" ..."])
  // 做法：取出所有 push([1,"…"]) 里的字符串字面量，拼起来，再整体做一次反斜杠转义还原。
  let merged = raw;
  const pushes = [];
  const pre = /self\.__next_f\.push\(\[1,\s*"((?:\\.|[^"\\])*)"\s*\]\)/g;
  let pm;
  while ((pm = pre.exec(raw)) !== null) pushes.push(pm[1]);
  if (pushes.length) {
    const joined = pushes.join('');
    try {
      // 用 JSON 解析单个字符串字面量来还原转义，最可靠
      merged = JSON.parse(`"${joined}"`);
    } catch {
      merged = joined.replace(/\\"/g, '"').replace(/\\n/g, '\n').replace(/\\\\/g, '\\');
    }
  }
  // 宽松地找比赛对象：包含 team1/team2 或 opponent 之类字段的 JSON 片段
  const rows = [];
  const objRe = /\{[^{}]*"(?:team1|team2|opponent1|opponent2|startTime|beginAt|matchTime)"[^{}]*\}/g;
  let om;
  const seen = new Set();
  while ((om = objRe.exec(merged)) !== null) {
    let obj;
    try { obj = JSON.parse(om[0]); } catch { continue; }
    const row = normalizeOwtvObj(obj);
    if (!row) continue;
    const key = `${row.ts}|${row.code1}|${row.code2}`;
    if (seen.has(key)) continue;
    seen.add(key);
    rows.push(row);
  }
  if (!rows.length) return { error: '页面结构未能解析出比赛数据（owtv.gg 为动态渲染站点，结构可能已变）' };
  return { rows };
}

/** 把一个可能的 owtv 对象规整成统一行结构；不像比赛就返回 null。 */
function normalizeOwtvObj(o) {
  if (!o || typeof o !== 'object') return null;
  const pick = (...keys) => {
    for (const k of keys) if (o[k] != null && o[k] !== '') return o[k];
    return null;
  };
  const t1raw = pick('team1', 'opponent1', 'home', 'teamA');
  const t2raw = pick('team2', 'opponent2', 'away', 'teamB');
  const nameOf = (v) => {
    if (v == null) return '';
    if (typeof v === 'string') return v;
    if (typeof v === 'object') return String(v.name || v.title || v.tag || v.shortName || '');
    return String(v);
  };
  const code1 = nameOf(t1raw);
  const code2 = nameOf(t2raw);
  if (!code1 || !code2) return null;
  const tsRaw = pick('startTime', 'beginAt', 'matchTime', 'date', 'timestamp');
  let ts = NaN;
  if (typeof tsRaw === 'number') ts = tsRaw < 1e12 ? tsRaw * 1000 : tsRaw;
  else if (typeof tsRaw === 'string') ts = Date.parse(tsRaw);
  if (!isFinite(ts)) return null;
  const s1 = Number(pick('score1', 'team1Score', 'scoreA'));
  const s2 = Number(pick('score2', 'team2Score', 'scoreB'));
  const hasScore = isFinite(s1) && isFinite(s2);
  return {
    eventId: null,
    ts,
    team1: code1,
    team2: code2,
    code1,
    code2,
    score1: hasScore ? s1 : null,
    score2: hasScore ? s2 : null,
    winnerCode: hasScore && s1 !== s2 ? (s1 > s2 ? code1 : code2) : null,
    leagueName: String(pick('tournament', 'league', 'event', 'competition') || 'owtv.gg 赛事'),
    leagueSlug: '',
    stage: '',
    bestOf: Number(pick('bestOf', 'bo')) || null,
    state: hasScore ? 'completed' : 'unstarted',
    teamsRaw: [
      { code: code1, name: code1, result: { gameWins: hasScore ? s1 : null } },
      { code: code2, name: code2, result: { gameWins: hasScore ? s2 : null } }
    ],
    _src: 'owtv'
  };
}

// ── 渲染 ────────────────────────────────────────────────────────────────
/** 渲染对阵。已结束的带大比分，进行中的带当前比分，未开始的 "A vs B"。 */
function renderMatchup(m) {
  const tbd = isTbdRow(m);
  const s1 = m.score1;
  const s2 = m.score2;
  const hasScore = s1 != null && s2 != null;
  if (tbd) return `${m.code1} vs ${m.code2}（对阵待定）`;
  if (m.state === 'completed' && hasScore) return `${m.code1} ${s1}:${s2} ${m.code2}`;
  if (m.state === 'live') return hasScore ? `${m.code1} ${s1}:${s2} ${m.code2}（进行中）` : `${m.code1} vs ${m.code2}（进行中）`;
  return `${m.code1} vs ${m.code2}`;
}

/** 赛果行：大比分 + 胜方（胜方用 ✔ 标出，若已知） */
function renderResultLine(m, tz) {
  const score = (m.score1 != null && m.score2 != null) ? `${m.score1}:${m.score2}` : '比分未收录';
  const bo = m.bestOf ? `BO${m.bestOf}` : '';
  let who = '';
  if (m.winnerCode) who = `　胜方：${m.winnerCode}`;
  return `· ${m.ts ? fmtTime(m.ts, tz) : '日期未知'}｜${m.leagueName} ${bo}｜${m.code1} ${score} ${m.code2}${who}`;
}

export function setup(api) {
  cfg = typeof api.config === 'function' ? api.config : () => ({});
  httpFetch = typeof api.fetch === 'function' ? (...args) => api.fetch(...args) : null;
  logger = {
    log: typeof api.log === 'function' ? (...a) => api.log(...a) : () => {},
    warn: typeof api.warn === 'function' ? (...a) => api.warn(...a) : () => {},
    error: typeof api.error === 'function' ? (...a) => api.error(...a) : () => {}
  };

  // ── 工具1：赛程 ────────────────────────────────────────────────────────
  api.registerTool({
    id: 'recent_schedule',
    name: '守望先锋赛程查询',
    category: 'knowledge',
    icon: '📅',
    description: '抓取守望先锋（OWCS 等）赛程，返回「今天 00:00 起」N 个自然日内的全部比赛（默认 3 天）：星期、北京时间、对阵双方、赛事名和赛制（BO几）。已结束的标 ✅ 并带上大比分，未开始的无标记——今天已经打完的比赛也会列出，不会丢。可用 teams 参数只查指定战队（中文名和外文缩写都行，如 上海龙、首尔王朝、O2 Blast、Falcons）；可用 leagues 参数只看用户点名的赛事（如 OWCS、大师赛、韩国赛区）；两者都不传时默认全部赛事都报，只有设置里手动开了「只看一线赛事」才按一线过滤，被过滤掉的场次会如实告知数量。用户问「今天/最近有哪些守望先锋比赛」「OWCS 明天/后天谁打谁」「某队赛程」「只看韩国赛区」时使用。',
    parameters: {
      type: 'object',
      properties: {
        teams: {
          type: 'string',
          description: '可选，逗号分隔的战队名，只返回这些战队的比赛。中文名和外文缩写都认，例如「上海龙,首尔王朝」或「O2 Blast,Falcons」。不传则返回全部（或按设置过滤）。'
        },
        leagues: {
          type: 'string',
          description: '可选，逗号分隔的赛事关键词，只返回这些赛事的比赛，如「OWCS」「大师赛,冠军赛」「韩国赛区」。中文名（守望先锋冠军系列赛/大师赛/冠军赛/韩国赛区）和英文缩写都认。传了就以它为准（忽略设置里的「只看一线赛事」）；不传则默认全部赛事都报。'
        },
        days: {
          type: 'number',
          description: '查今天起几天，默认 3，最多 14。语义是「含今天在内的 N 个自然日」，所以 days=1 就是今天一整天。'
        }
      }
    },
    async execute(_ctx, args = {}) {
      if (!httpFetch) return { content: '未启用网络权限（web_fetch），无法查询守望先锋赛事。', isError: true };

      const c = cfg() || {};
      const timeoutMs = clamp(c.timeoutMs, 3000, 30000, 12000);
      const tz = c.timeZone || 'Asia/Shanghai';
      const topOnly = c.topOnly === true;
      const topEvents = readList(c.topEvents);
      const filters = args?.teams ? readTeamList(args.teams) : readTeamList(c.filterTeams);
      const hasTeamFilter = filters.length > 0;
      const leaguesRaw = readList(args?.leagues);
      const leagueMode = leaguesRaw.length > 0;
      const filterMode = leagueMode ? 'leagues' : (!hasTeamFilter && topOnly && topEvents.length ? 'top' : null);
      // 点名战队时把默认窗口放宽到 7 天（默认 3 天经常一场都捞不到）
      const days = clamp(args?.days, 1, 14, hasTeamFilter ? 7 : 3);
      const max = clamp(c.maxResults, 1, 20, 8);

      const applyTeamFilter = (rows) => (hasTeamFilter
        ? rows.filter((m) => matchTeam({ code: m.code1, name: m.team1 }, filters)
          || matchTeam({ code: m.code2, name: m.team2 }, filters))
        : rows);
      const applyLeagueFilter = (rows) => {
        let hidden = 0;
        const leagues = new Set();
        if (!filterMode) return { rows, hidden, leagues };
        const kept = rows.filter((m) => {
          const lg = { name: m.leagueName, slug: m.leagueSlug };
          const keep = filterMode === 'leagues'
            ? leaguesRaw.some((t) => leagueMatchesToken(lg, t))
            : isTopLeague(lg, topEvents);
          if (!keep) { hidden += 1; leagues.add(m.leagueName); }
          return keep;
        });
        return { rows: kept, hidden, leagues };
      };

      const now = Date.now();
      const dayStart = startOfDayInTz(now, tz);
      const windowEnd = dayStart + days * 86400000;

      let rows = [];
      let hiddenByFilter = 0;
      const hiddenLeagues = new Set();
      let mainError = null;
      let totalInWindow = 0;
      let usedSource = '';
      let backupNote = '';

      // ── 源1（首选）：owtics.gg 公开 GraphQL ──
      // days 多给几天，避免"跨时区落在窗口边缘"的比赛被 recentMatches 的 days 卡掉
      const ot = await owticsMatches(timeoutMs, Math.min(days + 2, 30));
      if (ot.error) {
        mainError = ot.error;
      } else {
        // ⚠️ 绝不按 state 过滤掉已结束的比赛（用户问"今天有什么比赛"时，已打完的必须照样列）
        const winRows = ot.rows
          .filter((m) => isFinite(m.ts) && m.ts >= dayStart && m.ts < windowEnd)
          .sort((a, b) => a.ts - b.ts);
        totalInWindow = winRows.length;
        const f = applyLeagueFilter(applyTeamFilter(winRows));
        rows = f.rows;
        hiddenByFilter = f.hidden;
        for (const l of f.leagues) hiddenLeagues.add(l);
        usedSource = 'owtics.gg';
      }

      // ── 源2：Liquipedia（owtics 挂了或窗口内没数据时）──
      if (!rows.length) {
        const got = await liquipediaMatches(timeoutMs);
        if (got.error) {
          if (!mainError) {
            mainError = got.error;
          } else {
            backupNote = backupNote ? `${backupNote}；Liquipedia：${got.error}` : `Liquipedia：${got.error}`;
          }
        } else {
          const winRows = got.rows
            .filter((m) => isFinite(m.ts) && m.ts >= dayStart && m.ts < windowEnd)
            .sort((a, b) => a.ts - b.ts);
          const f = applyLeagueFilter(applyTeamFilter(winRows));
          if (f.rows.length) {
            rows = f.rows;
            hiddenByFilter = f.hidden;
            hiddenLeagues.clear();
            for (const l of f.leagues) hiddenLeagues.add(l);
            usedSource = 'Liquipedia';
            if (mainError) { backupNote = `owtics：${mainError}`; mainError = null; }
          } else if (!f.hidden) {
            totalInWindow = totalInWindow || winRows.length;
            const n = `Liquipedia：该时段没有收录比赛`;
            backupNote = backupNote ? `${backupNote}；${n}` : n;
          }
        }
      }

      // ── 源3（兜底）：owtv.gg（第三方动态站点，尽力解析）──
      if (!rows.length) {
        const ov = await owtvMatches(timeoutMs);
        if (ov.rows && ov.rows.length) {
          const ovRows = ov.rows
            .filter((m) => isFinite(m.ts) && m.ts >= dayStart && m.ts < windowEnd)
            .sort((a, b) => a.ts - b.ts);
          const f = applyLeagueFilter(applyTeamFilter(ovRows));
          if (f.rows.length) {
            rows = f.rows;
            hiddenByFilter = f.hidden;
            hiddenLeagues.clear();
            for (const l of f.leagues) hiddenLeagues.add(l);
            usedSource = 'owtv.gg';
            mainError = null;
          } else if (!f.hidden) {
            const n = 'owtv.gg：该时段没有收录比赛';
            backupNote = backupNote ? `${backupNote}；${n}` : n;
          }
        } else if (ov.error) {
          const n = `owtv.gg：${ov.error}`;
          backupNote = backupNote ? `${backupNote}；${n}` : n;
        }
      }

      const scopeLabel = hasTeamFilter
        ? `战队「${filters.join('、')}」`
        : (leagueMode ? `赛事「${leaguesRaw.join('、')}」` : (filterMode === 'top' ? '一线赛事' : '全部赛事'));

      if (!rows.length) {
        // 主源挂了（备用也没救回来）是"数据源不可用"，不是"没有比赛"——必须标 isError
        if (mainError) {
          let msg = `今天起 ${days} 天的守望先锋赛程查询失败：数据源暂时不可用。主源出错：${mainError}。`;
          if (backupNote) msg += `备用源也不可用：${backupNote}。`;
          msg += '请稍后重试。';
          return { content: msg, isError: true };
        }
        let msg = `今天起 ${days} 天没有查到 ${scopeLabel} 的守望先锋赛程。`;
        if (backupNote) msg += `备用源本次未取到数据：${backupNote}。`;
        if (filterMode === 'top' && totalInWindow) {
          msg += `该时段数据源里共 ${totalInWindow} 场比赛，但都不属于设置里的一线赛事。可在技能设置里关闭「只看一线赛事」查看全部。`;
        } else if (filterMode === 'leagues' && totalInWindow) {
          msg += `该时段数据源里共 ${totalInWindow} 场比赛，但都不属于「${leaguesRaw.join('、')}」。请确认赛事关键词写法（如 OWCS、大师赛、韩国赛区）。`;
        } else if (hasTeamFilter) {
          msg += '请确认战队名写法，或换别的队试试。';
        }
        return { content: msg };
      }

      // 排序取前 max 场的优先级（实测教训，勿改回"纯按时间升序"）：
      //   2026-10-11 实测：days=7 时若纯按时间升序，今天凌晨已结束的比赛会排在最前，
      //   8 场的截断名额被它们占满，未来 6 天的比赛一场都显示不出来——用户问
      //   "今天起 7 天"最想看的是**接下来**要打的比赛，不是今天凌晨打完的。
      //   所以：① 进行中 🔴 排最前（正在打的马上想看）；② 未开始的排在已结束的前面；
      //   ③ 同组内有明确对阵的排在 TBD 前面；④ 最后都按时间升序。
      rows = rows.sort((a, b) => {
        const rank = (x) => (x.state === 'live' ? 0 : (x.state === 'completed' ? 2 : 1));
        const ra = rank(a);
        const rb = rank(b);
        if (ra !== rb) return ra - rb;
        const ta = isTbdRow(a) ? 1 : 0;
        const tb = isTbdRow(b) ? 1 : 0;
        if (ta !== tb) return ta - tb;
        return a.ts - b.ts;
      });
      const droppedByMax = Math.max(0, rows.length - max);
      rows = rows.slice(0, max);

      const lines = rows.map((m) => {
        const bo = m.bestOf ? `BO${m.bestOf}` : '赛制待定';
        return `· ${scheduleStatePrefix(m.state)}${fmtTime(m.ts, tz)}｜${m.leagueName} ${bo}｜${renderMatchup(m)}`;
      });

      const notes = [];
      if (hiddenByFilter > 0) {
        const names = [...hiddenLeagues].slice(0, 6).join('、');
        if (filterMode === 'leagues') {
          notes.push(`另有 ${hiddenByFilter} 场不属于「${leaguesRaw.join('、')}」的比赛未显示（${names}）；不传 leagues 参数即可看全部。`);
        } else {
          notes.push(`另有 ${hiddenByFilter} 场非一线赛事未显示（${names}）；想看全部可在技能设置里关闭「只看一线赛事」。`);
        }
      }
      if (droppedByMax > 0) {
        notes.push(`其余 ${droppedByMax} 场因超出单次返回上限（当前 ${max} 场）未列出，可调大「最多返回几场」设置。`);
      }
      // 未开始的比赛优先展示，所以当被截断线之外全是"今天已结束"的比赛时，
      // 明确说明一句，避免用户以为今天打完的比赛丢了（口径：不静默丢失）。
      const finishedShown = rows.filter((m) => m.state === 'completed').length;
      if (droppedByMax > 0 && finishedShown === 0) {
        notes.push('（本次优先列出接下来未开始的比赛；今天已结束的比赛排在后面，可调大「最多返回几场」查看。）');
      }

      const finishedCount = finishedShown;
      const liveCount = rows.filter((m) => m.state === 'live').length;
      const scopeNote = finishedCount ? `，含已结束 ${finishedCount} 场` : '';
      const tzLabel = tz === 'Asia/Shanghai' ? '北京时间' : tz;
      // 来源行：owtics / Liquipedia / owtv 都属第三方站点，必须标注"非官方补充来源"。
      // ✅ / 🔴 图例只在本次真的列出了对应状态的比赛时才出现，避免"说了却没有"的困惑。
      const legend = `${finishedCount ? '；✅=已结束' : ''}${liveCount ? '；🔴=进行中' : ''}`;
      const srcLine = `（${tzLabel}，来自 ${usedSource}——非官方补充来源，数据可能不全或有滞后，仅供参考，请以官方渠道发布为准${legend}）`;
      let content = `📅 守望先锋 今天起 ${days} 天${scopeLabel}赛程（共 ${rows.length} 场${scopeNote}）：\n${lines.join('\n')}\n\n${srcLine}`;
      if (notes.length) content += `\n${notes.join('\n')}`;
      return { content };
    }
  });

  // ── 工具2：赛果 ────────────────────────────────────────────────────────
  api.registerTool({
    id: 'recent_results',
    name: '守望先锋近期赛果',
    category: 'knowledge',
    icon: '🏆',
    description: '查询守望先锋最近几天已结束的比赛结果，返回对阵、大比分（地图比分，如 3:1）、赛事与胜方。可用 teams 参数只查指定战队（中文名或外文缩写）；可用 leagues 参数只看用户点名的赛事（如 OWCS、大师赛、韩国赛区）；两者都不传时默认全部赛事都报，只有设置里手动开了「只看一线赛事」才按一线过滤，点名战队时一线过滤自动失效，次级赛事也报。用户问「昨天/最近守望先锋赛果」「OWCS 昨天比分」「上海龙最近战绩」「某队上一场赢了没」时使用。',
    parameters: {
      type: 'object',
      properties: {
        teams: {
          type: 'string',
          description: '可选，逗号分隔的战队名，只返回这些战队的比赛。中文名和外文缩写都认，例如「上海龙,首尔王朝」或「O2 Blast,Falcons」。不传则返回全部（或按设置过滤）。'
        },
        leagues: {
          type: 'string',
          description: '可选，逗号分隔的赛事关键词，只返回这些赛事的比赛，如「OWCS」「大师赛,冠军赛」「韩国赛区」。中文名和英文缩写都认。传了就以它为准（忽略设置里的「只看一线赛事」）；不传则默认全部赛事都报。'
        },
        days: {
          type: 'number',
          description: '查最近几天已结束的比赛，默认 3，最多 14。语义同样是「含今天在内的 N 个自然日」，与赛程工具口径一致。'
        }
      }
    },
    async execute(_ctx, args = {}) {
      if (!httpFetch) return { content: '未启用网络权限（web_fetch），无法查询守望先锋赛果。', isError: true };

      const c = cfg() || {};
      const timeoutMs = clamp(c.timeoutMs, 3000, 30000, 12000);
      const tz = c.timeZone || 'Asia/Shanghai';
      const topOnly = c.topOnly === true;
      const topEvents = readList(c.topEvents);
      const filters = args?.teams ? readTeamList(args.teams) : readTeamList(c.filterTeams);
      const hasTeamFilter = filters.length > 0;
      const leaguesRaw = readList(args?.leagues);
      const leagueMode = leaguesRaw.length > 0;
      const filterMode = leagueMode ? 'leagues' : (!hasTeamFilter && topOnly && topEvents.length ? 'top' : null);
      const days = clamp(args?.days, 1, 14, hasTeamFilter ? 7 : 3);
      const max = clamp(c.maxResults, 1, 20, 8);

      const applyTeamFilter = (rows) => (hasTeamFilter
        ? rows.filter((m) => matchTeam({ code: m.code1, name: m.team1 }, filters)
          || matchTeam({ code: m.code2, name: m.team2 }, filters))
        : rows);
      const applyLeagueFilter = (rows) => {
        let hidden = 0;
        const leagues = new Set();
        if (!filterMode) return { rows, hidden, leagues };
        const kept = rows.filter((m) => {
          const lg = { name: m.leagueName, slug: m.leagueSlug };
          const keep = filterMode === 'leagues'
            ? leaguesRaw.some((t) => leagueMatchesToken(lg, t))
            : isTopLeague(lg, topEvents);
          if (!keep) { hidden += 1; leagues.add(m.leagueName); }
          return keep;
        });
        return { rows: kept, hidden, leagues };
      };

      let matches = [];
      let usedSource = '';
      let mainError = null;
      let totalInWindow = 0;
      let hiddenByFilter = 0;
      const hiddenLeagues = new Set();
      let droppedByMax = 0;
      let backupNote = '';

      const now = Date.now();
      const todayStart = startOfDayInTz(now, tz);
      const floor = todayStart - (days - 1) * 86400000;
      const ceil = todayStart + 86400000;

      // ── 源1（首选）：owtics.gg ──
      const ot = await owticsMatches(timeoutMs, Math.min(days + 2, 30));
      if (ot.error) {
        mainError = ot.error;
      } else {
        const winRows = ot.rows
          .filter((m) => m.state === 'completed')
          .filter((m) => isFinite(m.ts) && m.ts >= floor && m.ts < ceil)
          .sort((a, b) => b.ts - a.ts);
        totalInWindow = winRows.length;
        const f = applyLeagueFilter(applyTeamFilter(winRows));
        hiddenByFilter = f.hidden;
        for (const l of f.leagues) hiddenLeagues.add(l);
        droppedByMax = Math.max(0, f.rows.length - max);
        matches = f.rows.slice(0, max);
        usedSource = 'owtics.gg';
      }

      // ── 源2：Liquipedia ──
      if (!matches.length) {
        const got = await liquipediaMatches(timeoutMs);
        if (got.error) {
          if (!mainError) {
            mainError = got.error;
          } else {
            const n = `Liquipedia：${got.error}`;
            backupNote = backupNote ? `${backupNote}；${n}` : n;
          }
        } else {
          const winRows = got.rows
            .filter((m) => m.state === 'completed')
            .filter((m) => isFinite(m.ts) && m.ts >= floor && m.ts < ceil)
            .sort((a, b) => b.ts - a.ts);
          const f = applyLeagueFilter(applyTeamFilter(winRows));
          if (f.rows.length) {
            hiddenByFilter = f.hidden;
            hiddenLeagues.clear();
            for (const l of f.leagues) hiddenLeagues.add(l);
            droppedByMax = Math.max(0, f.rows.length - max);
            matches = f.rows.slice(0, max);
            usedSource = 'Liquipedia';
            if (mainError) { backupNote = `owtics：${mainError}`; mainError = null; }
          } else if (!f.hidden) {
            totalInWindow = totalInWindow || winRows.length;
            const n = 'Liquipedia：该时段没有已结束的比赛';
            backupNote = backupNote ? `${backupNote}；${n}` : n;
          }
        }
      }

      // ── 源3（兜底）：owtv.gg ──
      if (!matches.length) {
        const ov = await owtvMatches(timeoutMs);
        if (ov.rows && ov.rows.length) {
          const ovRows = ov.rows
            .filter((m) => m.state === 'completed' && isFinite(m.ts) && m.ts >= floor && m.ts < ceil)
            .sort((a, b) => b.ts - a.ts);
          const f = applyLeagueFilter(applyTeamFilter(ovRows));
          if (f.rows.length) {
            hiddenByFilter = f.hidden;
            hiddenLeagues.clear();
            for (const l of f.leagues) hiddenLeagues.add(l);
            droppedByMax = Math.max(0, f.rows.length - max);
            matches = f.rows.slice(0, max);
            usedSource = 'owtv.gg';
            mainError = null;
          } else if (!f.hidden) {
            const n = 'owtv.gg：该时段没有已结束的比赛';
            backupNote = backupNote ? `${backupNote}；${n}` : n;
          }
        } else if (ov.error) {
          const n = `owtv.gg：${ov.error}`;
          backupNote = backupNote ? `${backupNote}；${n}` : n;
        }
      }

      const scopeLabel = hasTeamFilter
        ? `战队「${filters.join('、')}」`
        : (leagueMode ? `赛事「${leaguesRaw.join('、')}」` : (filterMode === 'top' ? '一线赛事' : '全部赛事'));

      if (!matches.length) {
        if (mainError) {
          let msg = `最近 ${days} 天的守望先锋赛果查询失败：数据源暂时不可用。主源出错：${mainError}。`;
          if (backupNote) msg += `备用源也不可用：${backupNote}。`;
          msg += '请稍后重试。';
          return { content: msg, isError: true };
        }
        let msg = `最近 ${days} 天没有查到 ${scopeLabel} 已结束的守望先锋比赛。`;
        if (backupNote) msg += `备用源本次未取到数据：${backupNote}。`;
        if (filterMode === 'top' && totalInWindow) {
          msg += `该时段数据源里共 ${totalInWindow} 场已结束比赛，但都不属于设置里的一线赛事；可在技能设置里关闭「只看一线赛事」查看全部。`;
        } else if (filterMode === 'leagues' && totalInWindow) {
          msg += `该时段数据源里共 ${totalInWindow} 场已结束比赛，但都不属于「${leaguesRaw.join('、')}」。请确认赛事关键词写法（如 OWCS、大师赛、韩国赛区）。`;
        } else if (hasTeamFilter) {
          msg += '请确认战队名写法，或换别的队试试。';
        }
        return { content: msg };
      }

      const lines = matches.map((m) => renderResultLine(m, tz));

      let footer = `\n\n（来源：${usedSource}——非官方补充来源，数据可能不全或有滞后，仅供参考，请以官方渠道发布为准）`;      footer += '\n守望先锋为地图制（BO5 先赢 3 张图获胜），大比分即各自赢下的地图数；聚合页未提供每张图的胜方与回合明细，故不展开单图。';
      if (backupNote) {
        footer += `\n（备用源本次未取到数据：${backupNote}）`;
      }
      if (hiddenByFilter > 0) {
        const names = [...hiddenLeagues].slice(0, 6).join('、');
        if (filterMode === 'leagues') {
          footer += `\n另有 ${hiddenByFilter} 场不属于「${leaguesRaw.join('、')}」的比赛未显示（${names}）；不传 leagues 参数即可看全部。`;
        } else {
          footer += `\n另有 ${hiddenByFilter} 场非一线赛事未显示（${names}）；想看全部可在技能设置里关闭「只看一线赛事」。`;
        }
      }
      if (droppedByMax > 0) {
        footer += `\n其余 ${droppedByMax} 场因超出单次返回上限（当前 ${max} 场）未列出，可调大「最多返回几场」设置。`;
      }

      return {
        content: `🏆 最近 ${days} 天${scopeLabel}守望先锋赛果（共 ${matches.length} 场）：\n${lines.join('\n')}${footer}`
      };
    }
  });
}

/** 自检：没有网络权限时明确报出来。 */
export function available() {
  if (!httpFetch) return { ok: false, reason: '缺少 web_fetch 权限（清单里的 permissions 被删了？）' };
  return true;
}

// 内部函数暴露给离线自检用（不对外提供能力，别依赖）
export const internals = {
  clamp, fmtTime, startOfDayInTz, tzOffsetMs, isTbdRow, readList, readTeamList,
  teamMatchesToken, matchTeam, normKey, expandLeagueTokens, leagueMatchesToken, isTopLeague,
  decodeHtmlText, stripTags, parseLiquipediaBlock, normalizeOwtvObj,
  normalizeOwticsMatch, owticsFormatToBestOf,
  renderMatchup, renderResultLine, scheduleStatePrefix,
  TEAM_ALIASES, TOP_EXCLUDE, LEAGUE_ALIASES, OWTICS_TIER_LABEL, OWTICS_REGION_CN
};
