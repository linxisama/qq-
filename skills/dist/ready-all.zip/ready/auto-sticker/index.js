// 自动表情包（auto-sticker）—— 按设定的节奏自动找一张表情包发出去
//
// ── 为什么是个"技能 + 钩子"混合体 ────────────────────────────────────────
//   用户要的是**可控的频率**（每 N 条 / 对话收尾）。频率如果不能确定，这个功能就没意义：
//   让模型"自己记得每 6 条发一次"是不可靠的 —— 它没有计数器，发多发少全凭感觉。
//   所以这里把职责切开：
//     · **什么时候该发** → 程序算。hooks 里维护每个会话的计数器（确定性的）。
//     · **发哪一张、这轮算不算收尾** → 模型判断。没有任何规则能替代"这句话什么语气"。
//   两者通过 promptSections() 里那段动态「当前节奏」串起来：
//     before-context 更新计数 → promptSections 渲染成一句话 → 模型照做 → 工具执行并清零。
//
// ── 为什么发的是 sendSticker 而不是 sendImage ─────────────────────────────
//   QQ 的图片和表情是两个东西：`sendImage` 出去是一张撑满气泡的大图，`sendSticker`
//   出去才是小图、可长按收藏的「表情」（靠 image 段的 sub_type=1 区分，
//   由 plugins/sticker-send-as-emoji 补齐这个字段）。表情包要的就是后者。
//
// ── 图库 ────────────────────────────────────────────────────────────────
//   https://aigengtu.com/gallery-index.json —— 纯静态 JSON、免 Key、免鉴权，
//   条目带『梗名』（如『气鼓鼓』），所以能按语气检索。
//   坑（与 whale-memes 同源，实测）：**图不存在时它返回 HTTP 404 + text/html 错误页**。
//   只把 URL 甩给协议端就是一张裂图，且我们不知道失败了 —— 所以统一
//   "下载 → 认魔数 → 量尺寸 → 转 base64 → 发"，绝不裸发远端直链。
//
// ── 照 src/plugin-loader.js 的规矩 ──────────────────────────────────────
//   · 工具必须在 setup(api) 执行期间注册；
//   · promptSections / hooks 必须模块顶层 export；
//   · 状态一律落在 DATA_DIR/auto-sticker/ 下，不能用 process.cwd() 当锚点。

import fs from 'node:fs';
import path from 'node:path';
import { DATA_DIR } from '../../src/config.js';
import { getSkillConfig } from '../../src/skills/config.js';

const SKILL_ID = 'auto-sticker';
const SITE = 'https://aigengtu.com';
const INDEX_URL = `${SITE}/gallery-index.json`;
const SITE_NAME = '梗鲸';

const DEFAULTS = {
  enabled: true,
  mode: 'count',          // count | end | both | off
  everyN: 6,
  strictFallback: true,
  maxPerHour: 5,
  maxPerDay: 25,
  dedupe: true,
  minShortSide: 200,
  refreshHours: 12
};

const DIR = path.join(DATA_DIR, SKILL_ID);
const CATALOG_FILE = path.join(DIR, 'catalog.json');
const STATE_FILE = path.join(DIR, 'state.json');

/** 这个图床对非浏览器 UA 会 403（实测）。 */
const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36';

const MAX_DOWNLOADS = 5;
const DOWNLOAD_BUDGET_MS = 20000;
const MAX_BYTES = 12 * 1024 * 1024;
const MAX_SENT_IDS = 400;

let log = () => {};
let warn = () => {};
let httpFetch = null;

// ─────────────────────────────────────────────── 配置与小工具
function cfg() {
  try {
    return { ...DEFAULTS, ...(getSkillConfig(SKILL_ID, DEFAULTS) || {}) };
  } catch {
    return { ...DEFAULTS };
  }
}

function num(v, fallback) {
  const n = Number(v);
  return Number.isFinite(n) ? n : fallback;
}

function clamp(n, lo, hi) {
  const v = Number(n);
  if (!Number.isFinite(v)) return lo;
  return Math.max(lo, Math.min(hi, Math.round(v)));
}

function clean(s, max = 200) {
  return String(s ?? '').replace(/\s+/g, ' ').trim().slice(0, max);
}

function dayKey(ts = Date.now()) {
  const d = new Date(ts);
  const p = (n) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}`;
}

function readJson(file, fallback) {
  try {
    return JSON.parse(fs.readFileSync(file, 'utf8'));
  } catch {
    return fallback;
  }
}

function writeJson(file, data) {
  try {
    fs.mkdirSync(DIR, { recursive: true });
    const tmp = `${file}.tmp`;
    fs.writeFileSync(tmp, JSON.stringify(data), 'utf8');
    fs.renameSync(tmp, file);
    return true;
  } catch (e) {
    warn(`写盘失败（${path.basename(file)}）：${e?.message ?? e}`);
    return false;
  }
}

function abortAfter(ms) {
  return (typeof AbortSignal !== 'undefined' && typeof AbortSignal.timeout === 'function')
    ? AbortSignal.timeout(ms)
    : undefined;
}

/** 只放行公网 http(s) 直链（与项目里其它联网模块的 SSRF 口径一致）。 */
function isPublicHttpUrl(u) {
  if (!/^https?:\/\//i.test(String(u || ''))) return false;
  let host = '';
  try { host = new URL(u).hostname.toLowerCase(); } catch { return false; }
  if (!host) return false;
  if (host === 'localhost' || host.endsWith('.local') || host.endsWith('.internal')) return false;
  if (/^(127|10|0)\./.test(host)) return false;
  if (/^192\.168\./.test(host)) return false;
  if (/^169\.254\./.test(host)) return false;
  const m = host.match(/^172\.(\d{1,3})\./);
  if (m && Number(m[1]) >= 16 && Number(m[1]) <= 31) return false;
  if (host.includes(':')) return false;
  return true;
}

// ─────────────────────────────────────────────── 图片真伪校验（认魔数）
// 为什么不用 Content-Type：这个图床出错时回的就是 404/200 + text/html，头部字段完全不可信。
function sniffSize(buf) {
  if (!Buffer.isBuffer(buf) || buf.length < 24) return null;
  if (buf[0] === 0x89 && buf[1] === 0x50 && buf[2] === 0x4e && buf[3] === 0x47) {
    return { format: 'png', w: buf.readUInt32BE(16), h: buf.readUInt32BE(20) };
  }
  if (buf[0] === 0x47 && buf[1] === 0x49 && buf[2] === 0x46) {
    return { format: 'gif', w: buf.readUInt16LE(6), h: buf.readUInt16LE(8) };
  }
  if (buf[0] === 0xff && buf[1] === 0xd8) return sniffJpeg(buf);
  if (buf.toString('latin1', 0, 4) === 'RIFF' && buf.toString('latin1', 8, 12) === 'WEBP') {
    return sniffWebp(buf);
  }
  return null;
}

function sniffJpeg(buf) {
  let p = 2;
  while (p + 9 < buf.length) {
    if (buf[p] !== 0xff) { p += 1; continue; }
    const marker = buf[p + 1];
    if (marker === 0xff) { p += 1; continue; }
    if (marker === 0xd8 || marker === 0x01 || (marker >= 0xd0 && marker <= 0xd7)) { p += 2; continue; }
    const len = buf.readUInt16BE(p + 2);
    if (len < 2) return null;
    const isSof = marker >= 0xc0 && marker <= 0xcf
      && marker !== 0xc4 && marker !== 0xc8 && marker !== 0xcc;
    if (isSof) return { format: 'jpeg', h: buf.readUInt16BE(p + 5), w: buf.readUInt16BE(p + 7) };
    p += 2 + len;
  }
  return null;
}

function sniffWebp(buf) {
  const fourcc = buf.toString('latin1', 12, 16);
  try {
    if (fourcc === 'VP8X') {
      return {
        format: 'webp',
        w: 1 + (buf[24] | (buf[25] << 8) | (buf[26] << 16)),
        h: 1 + (buf[27] | (buf[28] << 8) | (buf[29] << 16))
      };
    }
    if (fourcc === 'VP8 ') {
      for (let i = 20; i < Math.min(buf.length - 9, 40); i++) {
        if (buf[i] === 0x9d && buf[i + 1] === 0x01 && buf[i + 2] === 0x2a) {
          return {
            format: 'webp',
            w: buf.readUInt16LE(i + 3) & 0x3fff,
            h: buf.readUInt16LE(i + 5) & 0x3fff
          };
        }
      }
    }
    if (fourcc === 'VP8L') {
      const bits = buf.readUInt32LE(21);
      return { format: 'webp', w: (bits & 0x3fff) + 1, h: ((bits >> 14) & 0x3fff) + 1 };
    }
  } catch { /* 结构异常就当认不出 */ }
  return null;
}

// ─────────────────────────────────────────────── 图库索引
let catalog = null;
let catalogPromise = null;

function ttlMs() {
  const h = num(cfg().refreshHours, DEFAULTS.refreshHours);
  return h > 0 ? h * 3600 * 1000 : Infinity;
}

/** 从「DeepSeek娘『真当我是便宜货啊』气鼓鼓表情包」里取出『』里的梗。 */
function captionOf(name) {
  const m = String(name || '').match(/[『「【]([^』」】]{1,60})[』」】]/);
  return m ? clean(m[1], 60) : '';
}

function stemOf(url) {
  try {
    const base = String(url).split('?')[0].split('/').pop() || '';
    return clean(base.replace(/\.[a-z0-9]+$/i, ''), 40);
  } catch {
    return '';
  }
}

function normalizeCatalog(json) {
  const gallery = (json && typeof json === 'object' && json.gallery) || {};
  const items = [];
  const categories = [];
  for (const [key, node] of Object.entries(gallery)) {
    const images = Array.isArray(node?.images) ? node.images : [];
    if (!images.length) continue;
    const character = clean(node?.name || key, 24);
    categories.push({ name: character, count: images.length });
    for (const im of images) {
      const original = String(im?.original || '').trim();
      if (!isPublicHttpUrl(original)) continue;
      const id = stemOf(original);
      if (!id) continue;
      const name = clean(im?.name || '', 80);
      items.push({
        id,
        name,
        caption: captionOf(name),
        character,
        url: original,
        preview: isPublicHttpUrl(im?.preview) ? String(im.preview).trim() : ''
      });
    }
  }
  return { at: Date.now(), site: SITE, categories, items };
}

async function fetchCatalog() {
  if (typeof httpFetch !== 'function') throw new Error('没有网络权限（web_fetch）');
  const resp = await httpFetch(INDEX_URL, {
    method: 'GET',
    redirect: 'follow',
    headers: { 'User-Agent': UA, Accept: 'application/json,*/*' },
    signal: abortAfter(15000)
  });
  if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
  const next = normalizeCatalog(await resp.json());
  if (!next.items.length) throw new Error('索引里没有可用条目');
  return next;
}

/** 内存 → 网络 → 磁盘缓存，逐级降级（图库挂了也不至于完全不能发）。 */
async function loadCatalog({ force = false } = {}) {
  if (!force && catalog && catalog.items.length && (Date.now() - catalog.at) < ttlMs()) return catalog;
  if (catalogPromise) return catalogPromise;
  catalogPromise = (async () => {
    try {
      const fresh = await fetchCatalog();
      catalog = fresh;
      writeJson(CATALOG_FILE, fresh);
      log(`图库索引已刷新：${fresh.items.length} 张 / ${fresh.categories.length} 个角色`);
      return catalog;
    } catch (e) {
      const disk = readJson(CATALOG_FILE, null);
      if (disk && Array.isArray(disk.items) && disk.items.length) {
        catalog = disk;
        warn(`图库索引刷新失败（${e?.message ?? e}），改用本地缓存（${disk.items.length} 张）`);
        return catalog;
      }
      throw new Error(`图库索引拿不到，本地也没有缓存：${e?.message ?? e}`);
    }
  })().finally(() => { catalogPromise = null; });
  return catalogPromise;
}

// ─────────────────────────────────────────────── 语气 → 检索词
// 中文没法靠分词命中：「生气」和图上写的「气鼓鼓」一个词都不一样。
// 所以按**情绪分组**做同义扩展，让"语气词"能真的找到贴切的图。
const MOOD_GROUPS = {
  开心: ['开心', '高兴', '笑', '嘿嘿', '哈哈', '乐', '眉开眼笑', '棒', '赞'],
  得意: ['得意', '太会', '会了', '简单', '小意思', '轻松', '拿捏', '厉害', '牛'],
  委屈: ['委屈', '哭', '泪', '呜呜', '呜哇', '可怜', '难受', '惨', '悲'],
  生气: ['气', '怒', '恼', '炸', '暴躁', '不爽', '生气', '翻脸', '气鼓鼓'],
  无语: ['无语', '无奈', '摊手', '算了', '服了', '麻了', '裂开', '扶额', '离谱', '吐槽'],
  疑惑: ['疑惑', '奇怪', '问号', '不懂', '懵', '迷惑', '啥啊', '不解'],
  敷衍: ['敷衍', '不关我事', '随便', '行吧', '懒得'],
  求饶: ['求饶', '放过', '饶', '救命', '救救', '别打', '对不起', '错了'],
  催促: ['催', '快点', '搞快', '速度', '赶紧', '急'],
  害羞: ['害羞', '脸红', '不好意思'],
  夸奖: ['夸', '厉害', '好看', '可爱', '谢谢', '牛啊'],
  摸鱼: ['摸鱼', '躺平', '摆烂', '累', '困', '睡', '下班', '白饭'],
  比心: ['比心', '喜欢', '爱你', '抱', '亲', '贴贴'],
  财迷: ['钱', '工资', '便宜', '穷', '氪', '充钱', '氪金'],
  吃: ['吃', '饿', '饭', '干饭', '吃了']
};

function expandTerms(keyword) {
  const kw = clean(keyword, 40).toLowerCase();
  if (!kw) return [];
  const out = new Set([kw]);
  for (const group of Object.values(MOOD_GROUPS)) {
    const hit = group.some((t) => kw.includes(t.toLowerCase()) || t.toLowerCase().includes(kw));
    if (hit) for (const t of group) out.add(t.toLowerCase());
  }
  return [...out];
}

/** 从一段话里猜语气（兜底补图时用：模型没发图，就用它这句话的口吻挑）。 */
function termsFromText(text) {
  const t = String(text || '').toLowerCase();
  if (!t) return [];
  const out = new Set();
  for (const group of Object.values(MOOD_GROUPS)) {
    if (group.some((k) => t.includes(k.toLowerCase()))) {
      for (const k of group) out.add(k.toLowerCase());
      break;
    }
  }
  return [...out];
}

function scoreItem(item, terms) {
  if (!terms.length) return 0;
  const caption = (item.caption || '').toLowerCase();
  const name = (item.name || '').toLowerCase();
  let score = 0;
  for (const t of terms) {
    if (!t) continue;
    if (caption === t) score += 120;
    else if (caption && caption.includes(t)) score += 60;
    if (name.includes(t)) score += 18;
  }
  if (item.caption) score += 3;
  if (/插画|壁纸|头像|立绘|换装|涂鸦|九宫格/.test(item.name)) score -= 8;
  return score;
}

function shuffle(arr) {
  const a = arr.slice();
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

// ─────────────────────────────────────────────── 状态（计数 / 额度 / 去重）
// chats[chatKey] = {
//   count           自上张表情以来机器人发出的条数（节奏的分子）
//   watermark       本会话已计入的 session.sent 长度（防重复计数）
//   watermarkSession 水位对应的会话 id
//   lastStickerAt   上张表情的时间戳
//   endUsedSession  发过收尾表情的会话 id（收尾表情每会话最多一次）
//   hour / day / dayUsed  额度
//   sentIds         本会话发过的图 id（去重）
// }
function stateRead() {
  const s = readJson(STATE_FILE, null);
  if (!s || typeof s !== 'object' || !s.chats || typeof s.chats !== 'object') return { chats: {} };
  return s;
}

function stateWrite(s) {
  return writeJson(STATE_FILE, s);
}

function ensureChat(s, chatKey) {
  if (!s.chats[chatKey] || typeof s.chats[chatKey] !== 'object') s.chats[chatKey] = {};
  const c = s.chats[chatKey];
  c.count = Math.max(0, num(c.count, 0));
  if (!Array.isArray(c.hour)) c.hour = [];
  if (!Array.isArray(c.sentIds)) c.sentIds = [];
  return c;
}

function quotaOf(chat) {
  const conf = cfg();
  const now = Date.now();
  const since = now - 3600 * 1000;
  const perHour = Math.max(0, num(conf.maxPerHour, DEFAULTS.maxPerHour));
  const perDay = Math.max(0, num(conf.maxPerDay, DEFAULTS.maxPerDay));
  const hour = (chat.hour || []).filter((t) => num(t, 0) >= since);
  const today = dayKey(now);
  const dayUsed = chat.day === today ? num(chat.dayUsed, 0) : 0;
  const leftHour = Math.max(0, perHour - hour.length);
  const leftDay = Math.max(0, perDay - dayUsed);
  return { perHour, perDay, leftHour, leftDay, left: Math.min(leftHour, leftDay) };
}

function recordSent(chat, item) {
  const now = Date.now();
  chat.lastStickerAt = now;
  chat.count = 0;
  const today = dayKey(now);
  if (chat.day !== today) { chat.day = today; chat.dayUsed = 0; }
  chat.dayUsed = num(chat.dayUsed, 0) + 1;
  chat.hour = [...(chat.hour || []).filter((t) => now - num(t, 0) < 3600 * 1000), now];
  chat.sentIds = [...(chat.sentIds || []).filter((x) => x !== item.id), item.id].slice(-MAX_SENT_IDS);
}

/** 当前这轮该不该发（promptSections 与工具共用同一套判断）。 */
function rateInfo(chatKey) {
  const conf = cfg();
  const mode = String(conf.mode || 'count');
  const everyN = clamp(num(conf.everyN, DEFAULTS.everyN), 1, 100);
  const st = stateRead();
  const chat = ensureChat(st, chatKey || '');
  const count = num(chat.count, 0);
  const quota = quotaOf(chat);
  const countMode = mode === 'count' || mode === 'both';
  const endMode = mode === 'end' || mode === 'both';
  return {
    mode, everyN, count, quota, countMode, endMode,
    due: countMode && count >= everyN && quota.left > 0,
    reach: Math.max(0, everyN - count)
  };
}

// ─────────────────────────────────────────────── QQ 自带表情（face 段）
/**
 * QQ 系统表情（小黄脸 / 超级表情）—— 发出去的是 QQ 自己的表情：会动、能长按收藏、
 * 不占图床、不用下载，一点就走。跟"表情包图片"是两套东西，用户两个都要。
 *
 * 编号表**不抄死**在代码里：宿主自带一份权威目录
 * `resources/app/snowluma/data/sys-face-catalog.json`（339 条，带中文名和别名），
 * 运行时读它；读不到就退回下面的常用表（离线也不至于一个都发不出）。
 *
 * 为什么不把 339 个名字写进提示词：系统提示多 1KB，缓存就整段重算（见 prefix-cache-boost），
 * 而且模型也记不住 339 个名字。所以只告诉它「填名字或语气词」，模糊匹配在这里兜。
 */
const FACE_CATALOG_URL = new URL('../../snowluma/data/sys-face-catalog.json', import.meta.url);

/** 兜底表：只放最常用的一批（宿主目录读不到时才用）。 */
const FACE_FALLBACK = [
  [14, '微笑'], [1, '撇嘴'], [3, '发呆'], [4, '得意'], [5, '流泪'], [6, '害羞'], [8, '睡'],
  [9, '大哭'], [10, '尴尬'], [11, '发怒'], [12, '调皮'], [13, '呲牙'], [0, '惊讶'], [15, '难过'],
  [16, '酷'], [20, '偷笑'], [21, '可爱'], [22, '白眼'], [24, '饥饿'], [25, '困'], [27, '流汗'],
  [28, '憨笑'], [29, '悠闲'], [30, '奋斗'], [32, '疑问'], [33, '嘘'], [39, '再见'], [49, '拥抱'],
  [59, '便便'], [60, '咖啡'], [63, '玫瑰'], [66, '爱心'], [67, '心碎'], [76, '赞'], [98, '抠鼻'],
  [99, '鼓掌'], [101, '坏笑'], [106, '委屈'], [107, '快哭了'], [124, 'OK'], [129, '挥手'],
  [171, '茶'], [179, 'doge'], [182, '笑哭'], [264, '捂脸'], [268, '问号脸'], [271, '吃瓜'],
  [285, '摸鱼'], [299, '牛啊'], [311, '打call'], [319, '比心'], [320, '庆祝'], [357, '裂开'],
  [428, '收到'], [475, '干饭'], [476, '不是吧'], [483, '略']
];

/** 语气词 → 表情名。模型记得住情绪，记不住 300 个名字。 */
const FACE_ALIAS = {
  无语: '白眼', 翻白眼: '白眼', 尴尬: '尴尬', 开心: '呲牙', 高兴: '呲牙', 笑: '偷笑',
  大笑: '笑哭', 笑哭: '笑哭', 哭: '大哭', 委屈: '委屈', 生气: '发怒', 气死: '发怒',
  累: '困', 睡觉: '睡', 晚安: '睡', 饿: '饥饿', 吃: '干饭', 干饭: '干饭', 吃饭: '干饭',
  厉害: '赞', 赞: '赞', 牛: '牛啊', 好的: 'OK', 收到: '收到', 明白: 'OK', 谢谢: '抱拳',
  感谢: '抱拳', 再见: '再见', 拜拜: '挥手', 摸鱼: '摸鱼', 摆烂: '摸鱼', 吃瓜: '吃瓜',
  看戏: '吃瓜', 加油: '奋斗', 打call: '打call', 喜欢: '比心', 爱你: '比心', 比心: '比心',
  害羞: '害羞', 嘘: '嘘', 汗: '流汗', 无语了: '白眼', 问号: '问号脸', 疑惑: '疑问',
  啥: '疑问', 懵: '小纠结', 崩了: '裂开', 裂开: '裂开', 求求: '拜托', 拜托: '拜托',
  抱抱: '拥抱', 亲亲: '左亲亲', 敬礼: '敬礼', 鼓掌: '鼓掌', 期待: '期待', 心动: '心动',
  羞: '害羞', 惊: '惊讶', 震惊: '惊恐', 害怕: '惊恐', 得意: '得意', 调皮: '调皮',
  酷: '酷', 可爱: '可爱', 困了: '睡', 喝茶: '茶', 咖啡: '咖啡', 玫瑰: '玫瑰', 心碎: '心碎',
  难过: '难过', 叹气: '叹气', 麻了: '裂开', 牛啊: '牛啊', 强: '赞', 棒: '你真棒棒'
};

let faceIndexCache = null;

function buildFaceIndex(packs) {
  const byId = new Map();
  const byName = new Map();
  for (const pack of packs || []) {
    for (const e of pack?.emojis || []) {
      const sid = String(e?.qSid ?? '').trim();
      if (!/^\d+$/.test(sid)) continue;   // emoji 包里的 qSid 是 😊 这种字符，face 段发不了
      const id = Number(sid);
      const rawName = String(e?.qDes ?? '').replace(/^\//, '').trim();
      if (!byId.has(sid)) byId.set(sid, rawName || `表情${sid}`);
      const names = [rawName, ...(Array.isArray(e?.emojiNameAlias) ? e.emojiNameAlias : [])];
      for (const n of names) {
        const key = String(n ?? '').replace(/^\//, '').trim().toLowerCase();
        if (key && !byName.has(key)) byName.set(key, { id, name: rawName || key });
      }
    }
  }
  return { byId, byName };
}

function faceIndex() {
  if (faceIndexCache) return faceIndexCache;
  let built = null;
  try {
    const raw = fs.readFileSync(FACE_CATALOG_URL, 'utf8');
    const json = JSON.parse(raw);
    built = buildFaceIndex(json?.packs || []);
    if (!built.byId.size) built = null;
  } catch {
    built = null;
  }
  if (!built) {
    const packs = [{ emojis: FACE_FALLBACK.map(([id, name]) => ({ qSid: String(id), qDes: name, emojiNameAlias: [] })) }];
    built = buildFaceIndex(packs);
    warn?.('读不到宿主的表情目录，QQ 自带表情只剩常用的一批');
  }
  faceIndexCache = built;
  return built;
}

/** 把「摸鱼」「白眼」「285」「开心」这类输入解析成 {id, name}；解析不出返回 null。 */
function findFace(query) {
  const idx = faceIndex();
  const raw = String(query ?? '').trim().replace(/^[「『"'“”\[（(]+|[」』"'“”\]）)]+$/g, '').trim();
  if (!raw) return null;
  if (/^\d+$/.test(raw)) {
    const name = idx.byId.get(raw);
    return name ? { id: Number(raw), name } : null;
  }
  const lower = raw.toLowerCase();
  if (idx.byName.has(lower)) return idx.byName.get(lower);
  const compact = lower.replace(/[\s。，、！？~～…·:：]+/g, '');
  if (idx.byName.has(compact)) return idx.byName.get(compact);
  // 语气词 / 近义词
  const aliasKeys = Object.keys(FACE_ALIAS).filter((k) => compact.includes(k) || k.includes(compact));
  if (aliasKeys.length) {
    aliasKeys.sort((a, b) => b.length - a.length);   // 长词优先：「无语了」比「无语」准
    const target = idx.byName.get(FACE_ALIAS[aliasKeys[0]].toLowerCase());
    if (target) return target;
  }
  // 名字包含关系（「摸鱼」→「摸鱼」；「考拉」→「考拉抱」）
  const cands = [];
  for (const [name, v] of idx.byName) {
    if (name.includes(compact) || compact.includes(name)) cands.push({ ...v, len: name.length });
  }
  if (cands.length) {
    cands.sort((a, b) => a.len - b.len);
    return { id: cands[0].id, name: cands[0].name };
  }
  return null;
}

/** 给错误信息用的候选提示。 */
function faceSuggestions(query, limit = 10) {
  const idx = faceIndex();
  const q = String(query ?? '').trim().toLowerCase();
  const hits = [];
  if (q) {
    for (const [name, v] of idx.byName) {
      if (name.includes(q) || q.includes(name)) hits.push(v.name);
      if (hits.length >= limit) break;
    }
  }
  if (!hits.length) {
    for (const [name, v] of idx.byName) {
      if (Object.values(FACE_ALIAS).some((a) => a.toLowerCase() === name)) hits.push(v.name);
      if (hits.length >= limit) break;
    }
  }
  return [...new Set(hits)].join('、');
}

function faceNameList() {
  const idx = faceIndex();
  const names = [];
  for (const [sid, name] of idx.byId) names.push(`${name}(${sid})`);
  return names.join(' ');
}

function recordFaceSent(chat, face) {
  const now = Date.now();
  chat.lastStickerAt = now;
  chat.count = 0;
  const today = dayKey(now);
  if (chat.day !== today) { chat.day = today; chat.dayUsed = 0; }
  chat.dayUsed = num(chat.dayUsed, 0) + 1;
  chat.hour = [...(chat.hour || []).filter((t) => now - num(t, 0) < 3600 * 1000), now];
  // 自带表情不进图片去重表（sentIds 是给图库用的），但记最近几个，避免连着同一张脸
  chat.recentFaces = [...(chat.recentFaces || []).filter((x) => num(x, -1) !== face.id), face.id].slice(-6);
}

/** 真发一个 QQ 自带表情（走 sendMedia，所以限频/留档/去重都不绕过）。 */
async function sendQqFace(ctx, face) {
  const chatKey = ctx.chatKey;
  await ctx.sender.sendMedia(chatKey, [{ type: 'face', data: { id: String(face.id) } }], {
    label: `[表情:${face.name}]`,
    // 同一个表情可以再发（这是聊天，不是刷屏）：去重键带时间戳，只防"同一毫秒重试"
    dedupeKey: `face-${face.id}-${Date.now()}`
  });

  try {
    ctx.session?.sent?.push({
      type: 'face',
      text: `[表情:${face.name}]`,
      at: new Date().toLocaleTimeString('zh-CN', { hour12: false })
    });
    ctx.emit?.('session-update', ctx.session?.id);
  } catch { /* 留档失败不影响发送 */ }

  const st = stateRead();
  const chat = ensureChat(st, chatKey);
  recordFaceSent(chat, face);
  chat.watermark = Array.isArray(ctx.session?.sent) ? ctx.session.sent.length : 0;
  chat.watermarkSession = ctx.session?.id || '';
  stateWrite(st);
  log(`已发 QQ 自带表情「${face.name}」（#${face.id}）`);
  return face;
}

// ─────────────────────────────────────────────── 选图 + 下载 + 发送
function pickCandidates(cat, { keyword, chatKey, terms, want = 6 }) {
  const conf = cfg();
  const st = stateRead();
  const chat = ensureChat(st, chatKey || '');
  const used = new Set(conf.dedupe !== false ? (chat.sentIds || []) : []);

  const searchTerms = terms && terms.length ? terms : expandTerms(keyword);
  const scored = cat.items
    .map((it) => ({ it, score: scoreItem(it, searchTerms) }))
    .filter((x) => x.score > 0);
  let ordered;
  let note = '';
  if (scored.length) {
    scored.sort((a, b) => b.score - a.score);
    // 先在"没发过的"里取，实在发完了才允许重复 —— 否则去重会让候选池塌成一张、反复发同一图
    const unused = scored.filter((x) => !used.has(String(x.it.id)));
    const pool = unused.length ? unused : scored;
    // 只在"同样贴切"的图里随机 —— 既保住贴合度，又不会每次都同一张
    const top = pool.filter((x) => x.score >= pool[0].score * 0.75).slice(0, 80);
    ordered = shuffle(top).map((x) => x.it);
  } else {
    const all = shuffle(cat.items.filter((it) => it.caption));
    const unusedAll = all.filter((it) => !used.has(String(it.id)));
    ordered = unusedAll.length ? unusedAll : all;
    if (searchTerms.length) note = `图库里没有直接贴「${clean(keyword, 20)}」的梗，从随机图里挑。`;
  }
  const items = ordered.slice(0, Math.max(1, want));
  return { items, note };
}

/** 下载并校验一张图；失败抛错（调用方换下一张）。 */
async function downloadImage(url, timeoutMs) {
  if (typeof httpFetch !== 'function') throw new Error('没有网络权限（web_fetch）');
  const resp = await httpFetch(url, {
    method: 'GET',
    redirect: 'follow',
    headers: {
      'User-Agent': UA,
      Accept: 'image/avif,image/webp,image/apng,image/*,*/*;q=0.8',
      'Accept-Language': 'zh-CN,zh;q=0.9',
      Referer: `${SITE}/`
    },
    signal: abortAfter(timeoutMs)
  });
  if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
  const declared = Number(resp.headers?.get?.('content-length') || 0);
  if (declared && declared > MAX_BYTES) throw new Error(`文件过大（${Math.round(declared / 1048576)}MB）`);
  const buf = Buffer.from(await resp.arrayBuffer());
  if (!buf.length) throw new Error('空响应');
  if (buf.length > MAX_BYTES) throw new Error(`文件过大（${Math.round(buf.length / 1048576)}MB）`);
  const size = sniffSize(buf);
  if (!size) {
    // 认不出魔数：多半就是那个 HTML 错误页。宁可不发，也不要发裂图。
    const head = buf.toString('latin1', 0, 24).replace(/[\x00-\x1f]/g, ' ').trim();
    throw new Error(`不是可识别的图片（开头是 ${JSON.stringify(head)}）`);
  }
  if (!size.w || !size.h || size.w > 20000 || size.h > 20000) throw new Error('尺寸异常');
  return { buf, w: size.w, h: size.h, format: size.format, bytes: buf.length };
}

/**
 * 下载 → 校验 → 以「表情」形式发出。返回实际发出的条目。
 * 判据里的 minShortSide 是"优先级"而不是硬门槛：原图太糊就试缩略图，都不行也照发（绝不空手）。
 */
async function sendStickerPick(ctx, cat, { keyword, terms, why }) {
  const conf = cfg();
  const chatKey = ctx.chatKey;
  const minShort = Math.max(0, num(conf.minShortSide, DEFAULTS.minShortSide));
  const { items, note } = pickCandidates(cat, { keyword, chatKey, terms, want: 6 });
  if (!items.length) return { sent: [], errors: ['图库里没有可发的图'], note };

  const deadline = Date.now() + DOWNLOAD_BUDGET_MS;
  let downloads = 0;
  const errors = [];

  for (const item of items) {
    if (downloads >= MAX_DOWNLOADS || Date.now() > deadline) break;
    const plan = [{ url: item.url, kind: '原图' }];
    if (item.preview) plan.push({ url: item.preview, kind: '缩略图' });

    for (const step of plan) {
      downloads += 1;
      const remain = deadline - Date.now();
      if (remain < 800) { errors.push('超出本轮下载时限'); break; }
      try {
        const d = await downloadImage(step.url, Math.min(8000, remain));
        const shortSide = Math.min(d.w, d.h);
        if (step.kind === '原图' && minShort > 0 && shortSide < minShort && item.preview) {
          errors.push(`${item.id} 原图仅 ${d.w}x${d.h}，改试缩略图`);
          continue;
        }
        // 转 base64 内联发送：协议端不必再去公网拉一次（那个直链随时可能失效），
        // 也避免把宿主机的本地路径暴露给协议端。
        const dataUrl = `base64://${d.buf.toString('base64')}`;
        const sticker = {
          id: `auto_${item.id}`,
          desc: item.caption || item.name || item.id,
          url: dataUrl
        };
        let form = '表情';
        try {
          await ctx.sender.sendSticker(chatKey, sticker, {});
        } catch (e) {
          // 发表情失败不能连"图"都发不出去：退回普通图片（sender.sendImage 走的是另一条管道）
          if (typeof ctx.sender.sendImage !== 'function') throw e;
          warn(`发表情失败（${e?.message ?? e}），改用普通图片重发`);
          await ctx.sender.sendImage(chatKey, { dataUrl }, { note: `${SITE_NAME}表情包` });
          form = '图片';
        }

        // 留档：控制台会话页要能看到这一条（与内置 send_sticker 的写法一致）
        try {
          ctx.session?.sent?.push({
            type: 'sticker',
            text: `[表情包:${sticker.desc}]`,
            at: new Date().toLocaleTimeString('zh-CN', { hour12: false })
          });
          ctx.emit?.('session-update', ctx.session?.id);
        } catch { /* 留档失败不影响发送 */ }

        // 清计数 + 同步水位（否则 after-response 会把这张自己发的表情再算成一条消息）
        const st = stateRead();
        const chat = ensureChat(st, chatKey);
        recordSent(chat, item);
        chat.watermark = Array.isArray(ctx.session?.sent) ? ctx.session.sent.length : 0;
        chat.watermarkSession = ctx.session?.id || '';
        stateWrite(st);

        log(`已发 ${item.id}（${d.w}x${d.h} ${d.format} ${step.kind}，${form}，${Math.round(d.bytes / 1024)}KB）`);
        return { sent: [{ item, ...d, via: step.kind, form }], errors, note, why };
      } catch (e) {
        errors.push(`${item.id}/${step.kind}: ${String(e?.message ?? e).slice(0, 60)}`);
      }
    }
  }
  return { sent: [], errors, note };
}

function ok(text) {
  return { content: text };
}
function fail(text) {
  return { content: text, isError: true };
}

// ─────────────────────────────────────────────── 工具
async function doAutoSticker(ctx, args) {
  const conf = cfg();
  if (conf.enabled === false) return fail('错误：自动表情包技能已被关掉，这一轮不发图。');
  if (!ctx?.sender?.sendSticker) return fail('错误：当前环境拿不到发送表情的能力，这张先不发了。');
  if (!ctx?.chatKey) return fail('错误：不知道要发到哪个会话。');

  const chatKey = ctx.chatKey;
  const st = stateRead();
  const chat = ensureChat(st, chatKey);
  const quota = quotaOf(chat);
  if (quota.left <= 0) {
    return fail(`错误：这个会话${quota.leftDay <= 0 ? `今天已经发了 ${quota.perDay} 张` : `这个小时已经发了 ${quota.perHour} 张`}，先不发了。这一轮不要重试。`);
  }

  let cat;
  try {
    cat = await loadCatalog();
  } catch (e) {
    return fail(`错误：表情包图库现在拿不到（${e?.message ?? e}）。请只回一句"表情包图库这会儿连不上"，不要编造图片。`);
  }

  const keyword = clean(args?.keyword ?? args?.mood ?? '', 40);
  const why = clean(args?.why ?? '', 60);
  const res = await sendStickerPick(ctx, cat, { keyword, why });

  if (!res.sent.length) {
    const detail = res.errors.slice(0, 3).join('；') || '所有候选图都下载/发送失败';
    return fail(`错误：这次一张都没发出去（${detail}）。请只回一句"表情包这会儿发不出去"，不要编造。`);
  }

  const s = res.sent[0];
  const after = quotaOf(ensureChat(stateRead(), chatKey));
  const lines = [
    `已发一张表情包：${s.item.caption ? `『${s.item.caption}』` : s.item.id}（${s.w}x${s.h} ${s.format}，${s.via}）。`
  ];
  if (s.form === '图片') lines.push('（这次「表情」格式没发出去，退回成了普通图片 —— 不用跟群友解释。）');
  if (res.note) lines.push(`（${res.note}）`);
  lines.push(`本会话今天还剩 ${after.leftDay} 张额度。`);
  lines.push('接下来：不要在回复里描述或复述图里画的是什么；顺着情绪说一句就行，也可以只发表情不说话。');
  return ok(lines.join('\n'));
}

/** 发 QQ 自带表情（小黄脸 / 超级表情）。 */
async function doQqFace(ctx, args) {
  const conf = cfg();
  if (conf.enabled === false) return fail('错误：自动表情包技能已被关掉，这一轮不发任何表情。');
  if (!ctx?.chatKey) return fail('错误：不知道要发到哪个会话。');
  if (!ctx?.sender?.sendMedia) return fail('错误：当前环境拿不到发送表情的能力，这一轮先不发。');

  const wantList = args?.list === true || String(args?.face ?? '').toLowerCase() === 'list';
  if (wantList) {
    return ok(`QQ 自带表情（填名字或编号都行，共 ${faceIndex().byId.size} 个）：\n${faceNameList()}`);
  }

  const raw = clean(args?.face ?? args?.name ?? args?.id ?? '', 24);
  if (!raw) return fail('错误：没给表情名。请填一个表情名或语气词，例如「摸鱼」「吃瓜」「开心」。');

  const face = findFace(raw);
  if (!face) {
    const hint = faceSuggestions(raw);
    return fail(`错误：QQ 里没有叫「${raw}」的表情。可以换成：${hint || '摸鱼、吃瓜、赞、比心、笑哭'}。换一个名再试，或者填 list:true 看全部。`);
  }

  const quota = quotaOf(ensureChat(stateRead(), ctx.chatKey));
  if (quota.left <= 0) {
    return fail(`错误：这个会话${quota.leftDay <= 0 ? `今天已经发了 ${quota.perDay} 张` : `这个小时已经发了 ${quota.perHour} 张`}，这一轮不发，也不要重试。`);
  }

  try {
    await sendQqFace(ctx, face);
  } catch (e) {
    return fail(`错误：这个 QQ 表情没发出去（${String(e?.message ?? e).slice(0, 60)}）。别重试，也别假装发了。`);
  }

  const after = quotaOf(ensureChat(stateRead(), ctx.chatKey));
  return ok([
    `已发 QQ 自带表情「${face.name}」（编号 ${face.id}）。`,
    `本会话今天还剩 ${after.leftDay} 张额度。`,
    '接下来：不要解释这个表情是什么意思，接着说话就行，也可以只发表情不说话。'
  ].join('\n'));
}

// ─────────────────────────────────────────────── 钩子（确定性的节奏计数）
export const hooks = {
  /**
   * 每轮开始前：把"本会话已计入的消息条数"水位对齐。
   * 会话 id 变了 = 新的一轮 run，水位归零重新从 0 开始算增量。
   */
  'before-context'(ctx) {
    try {
      const conf = cfg();
      if (conf.enabled === false || String(conf.mode) === 'off') return;
      if (!ctx?.chatKey) return;
      const st = stateRead();
      const chat = ensureChat(st, ctx.chatKey);
      const sid = ctx.sessionId || '';
      if (chat.watermarkSession !== sid) {
        chat.watermarkSession = sid;
        chat.watermark = 0;
      }
      stateWrite(st);
    } catch (e) {
      warn(`before-context 计数失败：${e?.message ?? e}`);
    }
  },

  /**
   * 每轮回复之后：
   *   ① 把这一轮真正发出去的消息条数累加进 count（水位增量，多轮工具调用不会重复计）
   *   ② 到了 N 条而模型没自己发图 → 按它这句话的语气补一张（strictFallback）
   */
  async 'after-response'(ctx) {
    try {
      const conf = cfg();
      if (conf.enabled === false || String(conf.mode) === 'off') return;
      const chatKey = ctx?.chatKey;
      if (!chatKey) return;

      const s = ctx.session || {};
      const sentLen = Array.isArray(s.sent) ? s.sent.length : 0;
      const st = stateRead();
      const chat = ensureChat(st, chatKey);

      if (chat.watermarkSession !== (s.id || '')) {
        // 会话换了（新的一轮 run）＝它里面的 sent 条目全是新的，水位归零重新算
        chat.watermarkSession = s.id || '';
        chat.watermark = 0;
      }
      const delta = Math.max(0, sentLen - num(chat.watermark, 0));
      if (delta) chat.count = num(chat.count, 0) + delta;
      chat.watermark = sentLen;
      stateWrite(st);

      const info = rateInfo(chatKey);
      if (!info.due || conf.strictFallback === false) return;
      if (!ctx?.sender?.sendSticker) return;

      let cat;
      try {
        cat = await loadCatalog();
      } catch (e) {
        warn(`到点补图失败（图库不可用）：${e?.message ?? e}`);
        return;
      }
      // 用这一轮的话来猜语气；猜不出就随机（有梗名的图）
      const terms = termsFromText(ctx.response || '');
      const res = await sendStickerPick(ctx, cat, { keyword: terms.length ? '补图' : '', terms, why: '按节奏补图' });
      if (res.sent.length) {
        log(`节奏补图：已发 ${res.sent[0].item.caption || res.sent[0].item.id}（第 ${info.count} 条触发，阈值 ${info.everyN}）`);
      } else {
        warn(`节奏补图失败：${res.errors.slice(0, 2).join('；')}`);
      }
    } catch (e) {
      warn(`after-response 补图失败：${e?.message ?? e}`);
    }
  }
};

// ─────────────────────────────────────────────── 提示词（动态节奏）
export function promptSections(context = {}) {
  try {
    const conf = cfg();
    if (conf.enabled === false || String(conf.mode) === 'off') return [];
    const info = rateInfo(context?.chatKey || '');

    const lines = [];
    const modeText = {
      count: `每 ${info.everyN} 条消息配一张`,
      end: '只在对话收尾时配一张',
      both: `每 ${info.everyN} 条消息配一张，收尾时再补一张`
    }[info.mode] || `每 ${info.everyN} 条消息配一张`;
    lines.push(`【当前节奏】${modeText}。`);

    if (info.countMode) {
      if (info.quota.left <= 0) {
        lines.push(`额度用完了（本小时 ${info.quota.leftHour} 张、今天 ${info.quota.leftDay} 张），这一轮**不要**发图。`);
      } else if (info.due) {
        lines.push(`现在距上张表情已经发了 ${info.count} 条 ≥ ${info.everyN} —— **该发了**：这一轮调一次 auto-sticker__auto_sticker，keyword 填你这句回复的语气词。若这轮本来就没什么情绪，填「敷衍」或「摸鱼」也行。`);
      } else {
        lines.push(`现在距上张表情已经发了 ${info.count} 条，还差 ${info.reach} 条才到 ${info.everyN} —— 这一轮**不要主动发图**。`);
      }
    }
    if (info.endMode) {
      lines.push('收尾表情：只有当这一轮确实是自然收尾（道别、晚安、对方说要去忙了、话题聊完了）时，才调 auto-sticker__auto_sticker 发一张收尾表情；每个会话最多一次，别硬凑。');
    }
    lines.push(`本会话还剩 ${info.quota.leftDay} 张额度（每小时上限 ${info.quota.perHour} 张）。群友点名要图不受节奏限制。`);
    lines.push('同一会话不会重发同一张图；发完不要在回复里描述图里画的是什么。');

    return [{
      id: `${SKILL_ID}-rate`,
      title: '自动表情包节奏',
      priority: 46,
      content: lines.join('\n')
    }];
  } catch (e) {
    warn(`生成节奏提示失败：${e?.message ?? e}`);
    return [];
  }
}

// ─────────────────────────────────────────────── 入口
export function setup(api) {
  log = api?.log || (() => {});
  warn = api?.warn || (() => {});
  httpFetch = typeof api?.fetch === 'function' ? api.fetch : null;

  const conf = cfg();
  log(
    `自动表情包已加载：mode=${conf.mode}，每 ${num(conf.everyN, DEFAULTS.everyN)} 条一张，`
    + `每小时 ${num(conf.maxPerHour, DEFAULTS.maxPerHour)} / 每天 ${num(conf.maxPerDay, DEFAULTS.maxPerDay)} 张；状态在 data/${SKILL_ID}/`
  );
  if (!httpFetch) warn('没有声明 web_fetch 权限，拿不到网络能力 —— 发图会失败。请检查 skill.json 的 permissions。');

  api.registerTool({
    id: 'auto_sticker',
    name: '发表情包',
    description:
      '从表情包图库挑一张贴当下语气的，直接以「表情」的形式发到当前会话（一次一张，不用再调别的发送工具）。'
      + '什么时候用：① 提示词里的「当前节奏」写着"该发了"；② 对话自然收尾要配一张收尾表情；③ 群友点名要图（不受节奏限制）。'
      + 'keyword 填语气词（无语/得意/委屈/摸鱼/敷衍/开心/催促/吃…），越贴当下语气越准；也可以填对方原话里的事物。'
      + '图库有就发，工具报错就如实说这一轮不发 —— 不要编造图片。发完不要在回复里描述图里画的是什么。',
    category: 'sticker',
    icon: '🧩',
    requiresVision: false,
    parameters: {
      type: 'object',
      properties: {
        keyword: {
          type: 'string',
          description: '语气词或对方点名的事物，例如「无语」「得意」「委屈」「摸鱼」「催更」。'
        },
        why: {
          type: 'string',
          description: '可选，一句话说明为什么这张贴切（只用于记录，不发给群友）。'
        }
      },
      required: []
    },
    async execute(ctx, args) {
      return doAutoSticker(ctx, args);
    }
  });

  api.registerTool({
    id: 'qq_face',
    name: '发QQ自带表情',
    description:
      '发一个 QQ 软件自带的表情（小黄脸 / 超级表情动画），直接发到当前会话，不用别的工具。'
      + '用途：① 「当前节奏」写着该发了，但这次更适合一个自带表情而不是图库表情包；'
      + '② 群友点名要某个小黄脸；③ 回复末尾想带一个表情。'
      + 'face 填表情名（摸鱼/吃瓜/赞/比心/笑哭/白眼/收到/打call/裂开…）或编号；'
      + '记不准名字就填语气词（无语/开心/委屈/困/尴尬/期待），会自动找最接近的那个；'
      + '想先看有哪些，传 list:true。跟图片表情包共用同一套频率与额度。'
      + '发完不要描述表情是什么意思。',
    category: 'sticker',
    icon: '😀',
    requiresVision: false,
    parameters: {
      type: 'object',
      properties: {
        face: {
          type: 'string',
          description: '表情名或编号，例如「摸鱼」「吃瓜」「285」「开心」。'
        },
        why: {
          type: 'string',
          description: '可选，一句话说明为什么贴切（只用于记录，不发给群友）。'
        },
        list: {
          type: 'boolean',
          description: 'true = 只列出所有可选表情，不发送。'
        }
      },
      required: []
    },
    async execute(ctx, args) {
      return doQqFace(ctx, args);
    }
  });

  // 预热图库索引（不 await：不能因为它拖慢启动；失败静默，工具调用时会再试）
  try {
    Promise.resolve(loadCatalog()).catch(() => {});
  } catch { /* 忽略 */ }
}

export function available() {
  return typeof globalThis.fetch === 'function';
}

export function dispose() {
  catalog = null;
  catalogPromise = null;
}

/** 供测试用：暴露内部纯函数。 */
export const internals = {
  expandTerms, termsFromText, scoreItem, pickCandidates, rateInfo, quotaOf,
  recordSent, ensureChat, stateRead, stateWrite, sniffSize, captionOf, normalizeCatalog,
  findFace, faceIndex, faceSuggestions, faceNameList, recordFaceSent, FACE_ALIAS
};
