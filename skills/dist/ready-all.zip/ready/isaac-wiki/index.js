import path from 'node:path';
import { DATA_DIR } from '../../src/config.js';
import { WikiClient } from './lib/wiki.js';
import {
  search, findBest, searchAchievements, allEntries, stats,
} from './lib/data.js';
import { dailyInfo, dateInt, weekdayName } from './lib/daily.js';

let cfg = () => ({});
let log = () => {};
let client = null;

const CATS = ['道具', '饰品', '卡牌', '胶囊', '角色'];
const CAT_ALIAS = {
  道具: '道具', 物品: '道具', item: '道具', items: '道具',
  饰品: '饰品', trinket: '饰品', trinkets: '饰品',
  卡牌: '卡牌', 卡片: '卡牌', card: '卡牌', cards: '卡牌',
  胶囊: '胶囊', 药丸: '胶囊', pill: '胶囊', pills: '胶囊',
  角色: '角色', 人物: '角色', character: '角色', characters: '角色',
};

function shanghaiNow() {
  const parts = new Intl.DateTimeFormat('en-CA', {
    timeZone: 'Asia/Shanghai',
    year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', hour12: false,
  }).formatToParts(new Date());
  const get = (t) => Number(parts.find((p) => p.type === t)?.value);
  return { y: get('year'), m: get('month'), d: get('day'), h: get('hour') % 24 };
}

const pad = (n) => String(n).padStart(2, '0');
const iso = ({ y, m, d }) => `${y}-${pad(m)}-${pad(d)}`;

function shiftDate(base, days) {
  const dt = new Date(Date.UTC(base.y, base.m - 1, base.d));
  dt.setUTCDate(dt.getUTCDate() + days);
  return { y: dt.getUTCFullYear(), m: dt.getUTCMonth() + 1, d: dt.getUTCDate() };
}

/** 支持 2026-10-21 / 10-21 / 今天 / 明天 / 昨天 */
function resolveDate(input) {
  const today = shanghaiNow();
  const raw = String(input ?? '').trim();
  if (!raw) return null;
  if (/^今天|^今日|^today$/i.test(raw)) return today;
  if (/^明天|^明日|^tomorrow$/i.test(raw)) return shiftDate(today, 1);
  if (/^昨天|^昨日|^yesterday$/i.test(raw)) return shiftDate(today, -1);
  let m = raw.match(/^(\d{4})[-/.](\d{1,2})[-/.](\d{1,2})$/);
  if (m) return { y: Number(m[1]), m: Number(m[2]), d: Number(m[3]) };
  m = raw.match(/^(\d{1,2})[-/.](\d{1,2})$/);
  if (m) return { y: today.y, m: Number(m[1]), d: Number(m[2]) };
  m = raw.match(/^(\d{4})\s*年\s*(\d{1,2})\s*月\s*(\d{1,2})\s*日?$/);
  if (m) return { y: Number(m[1]), m: Number(m[2]), d: Number(m[3]) };
  return undefined; // 无法识别
}

function normCat(cat) {
  if (!cat) return null;
  const key = String(cat).trim().toLowerCase();
  return CAT_ALIAS[key] || CAT_ALIAS[String(cat).trim()] || null;
}

function entryBrief(e) {
  const row = { 类别: e.cat, 编号: e.id, 中文名: e.zh, 英文名: e.en };
  if (e.desc) row.效果摘要 = e.desc.split('\n')[0].slice(0, 60);
  if (e.ach) row.解锁成就 = e.ach;
  return row;
}

function entryDetail(e) {
  const row = {
    类别: e.cat,
    编号: e.id,
    中文名: e.zh,
    英文名: e.en,
  };
  if (e.desc) row.效果 = e.desc;
  else if (e.cat === '角色') row.说明 = '本地资料只收录角色的解锁方式，没有初始属性/初始道具数据；不确定的别乱讲。';
  else row.效果 = '（本地图鉴没有记录效果描述）';
  if (e.ach) {
    row.解锁成就 = { 成就名: e.ach, 所属版本: e.achDlc || '未标注' };
    if (e.unlockZh) row.解锁成就['条件（中文）'] = e.unlockZh;
    if (e.unlockEn) row.解锁成就['条件（英文原文）'] = e.unlockEn;
  } else if (e.unlockZh) {
    row.解锁方式 = e.unlockZh;
  } else {
    row.解锁方式 = null;
    row.解锁说明 = '本地成就库里没有这件条目的「解锁成就」记录。以撒里大量道具是道具池常驻道具，本来就不需要完成成就才能拿到；也可能它是初始自带或在特定房间/挑战里获得。不要把这一点说成某个具体成就。';
  }
  return row;
}

function jsonOut(obj, isError = false) {
  return { content: JSON.stringify(obj), isError };
}

let itemNameMap = null;
function itemNames(ids) {
  if (!ids || !ids.length) return [];
  if (!itemNameMap) {
    itemNameMap = new Map();
    for (const e of allEntries()) {
      if (e.cat === '道具') itemNameMap.set(e.id, e.zh);
    }
  }
  return ids.map((id) => itemNameMap.get(id) || `编号${id}`);
}

function versionView(di, ver) {
  const info = dailyInfo(di, ver);
  const row = { 角色: info.character.name, 终点: info.target, 难度: info.difficulty };
  if (info.special) {
    row.节日 = info.special.name;
    if (info.special.items?.length) row.初始道具 = itemNames(info.special.items);
  }
  return row;
}

function fail(message, extra = {}) {
  return jsonOut({ ok: false, error: message, ...extra }, true);
}

export function setup(api) {
  cfg = typeof api.config === 'function' ? api.config : () => ({});
  log = typeof api.log === 'function' ? api.log : () => {};

  client = new WikiClient({
    fetchImpl: api.fetch,
    cacheDir: path.join(DATA_DIR, 'isaac-wiki-cache'),
    cacheMinutes: () => cfg().cacheMinutes,
    log,
  });
  api.log?.(`以撒图鉴已加载：${JSON.stringify(stats())}`);

  // ── 1. 搜索 ──
  api.registerTool({
    id: 'search',
    name: '搜索以撒资料',
    description:
      '在《以撒的结合》图鉴里按中文名、英文名或别名搜索道具/饰品/卡牌/胶囊/角色，返回候选列表（编号、中英文名、类别、解锁成就）。当群友提到某件以撒道具但名字可能记不全、或你不确定具体是哪一件时，先用它定位，再用 detail 查详情。',
    category: 'query',
    icon: '🔍',
    parameters: {
      type: 'object',
      properties: {
        query: { type: 'string', description: '关键词，中文或英文都行，如「妈刀」「硫磺火」「Brimstone」' },
        cat: { type: 'string', enum: CATS, description: '限定类别；不确定就不填' },
        limit: { type: 'integer', description: '返回几条，1~12，默认 6' },
      },
      required: ['query'],
    },
    async execute(_ctx, args) {
      try {
        const query = String(args?.query ?? '').trim();
        if (!query) return fail('缺少 query 参数，请把要查的名字放进来');
        const limit = Math.min(12, Math.max(1, Number(args?.limit) || 6));
        const cat = normCat(args?.cat);
        const rows = search(query, { cat, limit });
        if (!rows.length) {
          return jsonOut({
            ok: true,
            命中: 0,
            提示: `本地图鉴里没有匹配「${query}」的条目。可以换更短的关键词（如只写两个字），或英文名再试；确实没有就告诉群友查不到，不要编。`,
          });
        }
        return jsonOut({ ok: true, 命中: rows.length, 结果: rows.map(entryBrief) });
      } catch (error) {
        return fail(`搜索失败：${error?.message ?? error}`);
      }
    },
  });

  // ── 2. 详情 + 解锁条件 ──
  api.registerTool({
    id: 'detail',
    name: '查询资料与解锁条件',
    description:
      '查询《以撒的结合》某件道具/饰品/卡牌/胶囊/角色的详细效果，以及解锁它需要完成的成就（成就名、条件、所属DLC）。当群友问「XX有什么用」「XX怎么解锁」「解锁XX要什么成就」「XX是谁解锁的」时使用。名字记不准先调 search。',
    category: 'query',
    icon: '📖',
    parameters: {
      type: 'object',
      properties: {
        name: { type: 'string', description: '道具/角色名字，中文或英文，如「妈妈的菜刀」「妈刀」「Mom\'s Knife」' },
        cat: { type: 'string', enum: CATS, description: '限定类别；不确定就不填' },
        online: { type: 'boolean', description: '需要 wiki 补充资料时传 true（可能较慢）' },
      },
      required: ['name'],
    },
    async execute(_ctx, args) {
      try {
        const name = String(args?.name ?? '').trim();
        if (!name) return fail('缺少 name 参数');
        const cat = normCat(args?.cat);
        const hit = findBest(name, cat);
        if (!hit) {
          const guess = search(name, { limit: 3 }).map((e) => `${e.zh}（${e.en}）`);
          return fail(`本地图鉴里找不到「${name}」`, {
            建议: guess.length ? guess : '换更短的关键词或英文名再试',
          });
        }
        const payload = { ok: true, 条码匹配度: hit._score, 资料: entryDetail(hit) };

        if (args?.online && cfg().online !== false && client?.available) {
          try {
            const page = await client.page(hit.zh);
            payload.wiki = { 标题: page.title, 链接: page.url, 摘录: page.text.slice(0, 1200) };
          } catch (error) {
            payload.wiki = { 失败原因: String(error?.message || error), 提示: '在线资料没取到，用本地资料回答即可' };
          }
        }
        return jsonOut(payload);
      } catch (error) {
        return fail(`查询失败：${error?.message ?? error}`);
      }
    },
  });

  // ── 3. 成就反查 ──
  api.registerTool({
    id: 'achievement',
    name: '反查成就解锁内容',
    description:
      '反查《以撒的结合》成就：给一个成就名（中文条件或英文名都行），返回它解锁了哪些道具/角色/饰品/卡牌，以及达成条件。当群友问「这个成就有什么用」「这个成就解锁什么」「哪些东西是打XX解锁的」时使用。',
    category: 'query',
    icon: '🏆',
    parameters: {
      type: 'object',
      properties: {
        query: { type: 'string', description: '成就名、条件关键词，或某件道具/角色的名字（会顺带反查它的成就）' },
        dlc: { type: 'string', enum: ['Rebirth', 'Afterbirth', 'AfterbirthPlus', 'Repentance'], description: '限定DLC版本，可选' },
        limit: { type: 'integer', description: '返回几条，1~10，默认 5' },
      },
      required: ['query'],
    },
    async execute(_ctx, args) {
      try {
        const query = String(args?.query ?? '').trim();
        if (!query) return fail('缺少 query 参数');
        const limit = Math.min(10, Math.max(1, Number(args?.limit) || 5));
        const rows = searchAchievements(query, { dlc: args?.dlc || null, limit });
        if (!rows.length) {
          return jsonOut({ ok: true, 命中: 0, 提示: `没有匹配「${query}」的成就记录。可以直接告诉群友查不到，不要凭空编造成就名。` });
        }
        return jsonOut({
          ok: true,
          命中: rows.length,
          结果: rows.map((a) => ({
            成就名: a.name,
            所属版本: a.dlc,
            条件中文: a.conditionZh || null,
            条件英文: a.conditionEn || null,
            解锁内容: a.unlocks.slice(0, 8).map((u) => `${u.cat}·${u.zh}`),
            解锁数量: a.unlocks.length,
          })),
        });
      } catch (error) {
        return fail(`反查失败：${error?.message ?? error}`);
      }
    },
  });

  // ── 4. 每日挑战 ──
  api.registerTool({
    id: 'daily',
    name: '每日挑战',
    description:
      '回答《以撒的结合》每日挑战：某天用哪个角色、打到哪个终点Boss、普通还是困难、是否撞上节日，区分「忏悔」和「忏悔+」两个版本。当群友问「今天每日挑战是什么」「每日角色是谁」「明天/下周打什么」时使用。北京时间 18:00 换新。',
    category: 'query',
    icon: '📅',
    parameters: {
      type: 'object',
      properties: {
        date: { type: 'string', description: '日期，支持「今天」「明天」「昨天」「2026-10-21」「10-21」；不填=当前正在进行的那一场' },
        days: { type: 'integer', description: '从该日期起连续给几天，1~7，默认 1（想答「这周」就填 7）' },
        version: {
          type: 'string',
          enum: ['both', 'repPlus', 'rep'],
          description: 'both=两个版本都给（默认）；repPlus=只给忏悔+；rep=只给忏悔',
        },
      },
    },
    async execute(_ctx, args) {
      try {
        const now = shanghaiNow();
        const parsed = resolveDate(args?.date);
        if (parsed === undefined) {
          return fail(`看不懂这个日期：${args?.date}。可以写「今天」「明天」或「2026-10-21」。`);
        }
        // 每日挑战 18:00 换新：18 点前，正在进行的是前一天开始的那场
        const running = now.h < 18 ? shiftDate(now, -1) : now;
        const start = parsed || running;
        const days = Math.min(7, Math.max(1, Number(args?.days) || 1));
        const wanted = args?.version || cfg().dailyVersion || 'both';

        const rows = [];
        for (let i = 0; i < days; i++) {
          const day = shiftDate(start, i);
          const di = dateInt(day.y, day.m, day.d);
          const row = { 日期: iso(day), 星期: weekdayName(di) };
          if (wanted !== 'rep') row['忏悔+'] = versionView(di, 'repp');
          if (wanted !== 'repPlus') row['忏悔'] = versionView(di, 'rep');
          rows.push(row);
        }

        return jsonOut({
          ok: true,
          挑战: days === 1 ? rows[0] : rows,
          场次说明: '每日挑战北京时间 18:00 换新，这一场从当天 18:00 持续到次日 18:00',
          当前正在进行: iso(running),
          是否就是当前场次: days === 1 && iso(start) === iso(running),
          数据来源: '本地推算（与灰机wiki日历同源算法，可离线算任意日期）',
        });
      } catch (error) {
        return fail(`每日挑战查询失败：${error?.message ?? error}`);
      }
    },
  });
}

export function available() {
  // 纯本地数据，恒可用；联网只是增强
  return { ok: true };
}

export function promptSections() {
  const cats = stats();
  const total = allEntries().length;
  return [
    {
      id: 'isaac-wiki-stats',
      title: '以撒图鉴数据范围',
      priority: 30,
      content: `本地图鉴共 ${total} 条（${Object.entries(cats).map(([k, v]) => `${k}${v}`).join(' / ')}），数据来自社区中文图鉴与成就表。`,
    },
  ];
}
