// 空@技能：群聊乐子文化的"最高敬意"动作。
// - 工具 send_empty_at：模型看到特别好笑/特别炸的消息或图片时主动空@
//   （引用目标消息 + @ 其发送者，不写任何内容，一条消息完成）；
// - onMessage 钩子：检测别人的空@消息（引用+@、无正文），自动跟读一次
//   （同一源消息只跟一次；@ 目标是自己时跳过）。
// 发送全部走消息段数组 [reply, at]；跟读依赖核心钩子载荷提供的 sendSegments。
// 门槛在提示词里定死：绷不住级别才空@，普通好笑配不上。

let api = null;
const followedSet = new Set();   // 已跟读/已空@ 的源：`${chatKey}::${mid}`（内存态，重启清零）

const settings = () => api?.config?.() || {};

/**
 * 识别"空@"消息：引用 + @（@ 非全体成员、非机器人自己）、除空白文字外无其他内容段。
 * @returns {{replyId: string, atQq: string} | null}
 */
export function emptyAtTargetFromSegments(segments) {
  let replyId = null;
  let atQq = null;
  for (const seg of Array.isArray(segments) ? segments : []) {
    const type = seg?.type;
    const d = seg?.data ?? {};
    if (type === 'reply') {
      if (replyId === null && d.id != null && String(d.id).trim() !== '') replyId = String(d.id).trim();
    } else if (type === 'at') {
      const q = String(d.qq ?? '').trim();
      if (q && q !== 'all' && !atQq) atQq = q;
    } else if (type === 'text') {
      if (String(d.text ?? '').trim() !== '') return null;   // 有实质文字 = 不是空@
    } else {
      return null;   // 表情/图片/文件等任何其他内容段都不算空@
    }
  }
  if (replyId === null || !atQq) return null;
  return { replyId, atQq };
}

const followed = (chatKey, mid) => followedSet.has(`${chatKey}::${mid}`);
const markFollowed = (chatKey, mid) => followedSet.add(`${chatKey}::${mid}`);

export function setup(hostApi) {
  api = hostApi;
  api.registerTool({
    id: 'send_empty_at',
    name: '空@',
    category: 'messaging',
    icon: '🎯',
    description: '空@：引用一条消息并 @ 它的发送者，不写任何内容——群里对特别好笑/特别炸裂的乐子的最高敬意。门槛极高：只用于真的让你绷不住、笑出声的那种消息或图片；普通的好笑、日常玩梗都配不上。messageId 用聊天记录里的 #数字。只在群聊可用。',
    parameters: {
      type: 'object',
      properties: {
        messageId: { type: ['integer', 'string'], description: '#数字（聊天记录里的消息 id，可能为负数）' },
        atUserId: { type: ['integer', 'string'], description: '可选：覆盖默认的 @ 目标（默认 @ 被引用消息的发送者）' }
      },
      required: ['messageId']
    },
    async execute(ctx, args) {
      if (ctx.kind !== 'group') return { content: '空@只在群聊可用。', isError: true };
      const entry = ctx.store.findByMid(ctx.chatKey, args.messageId);
      if (!entry) return { content: `在当前会话找不到消息 ${args.messageId}。`, isError: true };
      if (!entry.mid) return { content: '这条消息没有可引用的 id。', isError: true };

      // @ 目标：优先取被引用消息的作者；允许模型用 atUserId 覆盖（如点名 summon 场景）
      let atTarget = String(args?.atUserId ?? '').trim();
      if (!atTarget) atTarget = String(entry.senderId ?? '').trim();
      if (!/^\d+$/.test(atTarget)) return { content: '拿不到要 @ 的 QQ 号。', isError: true };
      if (atTarget === String(ctx.selfId ?? '')) return { content: '这条消息是你自己发的，空@自己就别了吧。', isError: true };

      const key = `${ctx.chatKey}::${entry.mid}`;
      if (followedSet.has(key)) return { content: '这条消息已经被空@过了，不用重复。' };
      followedSet.add(key);

      await ctx.onebot.sendSegments(ctx.kind, Number(ctx.chatId), [
        { type: 'reply', data: { id: String(entry.mid) } },
        { type: 'at', data: { qq: atTarget } }
      ]);
      return { content: '空@已发送——对这条乐子的最高敬意，不用再说什么。' };
    }
  });
  api.log('空@技能已加载（跟读' + (settings().followEnabled === false ? '关' : '开') + '）');
}

export const hooks = {
  /**
   * 检测别人的空@消息并跟读一次。ctx = 核心 onMessage 钩子载荷：
   * { event, chatKey, kind, id, onebot, sender, store, sendSegments, log }
   */
  async onMessage(ctx = {}) {
    const c = settings();
    if (c.followEnabled === false) return;
    const ev = ctx?.event;
    const chatKey = String(ctx?.chatKey ?? '');
    if (!chatKey.startsWith('group:')) return;   // 空@是群聊文化，私聊无意义
    const target = emptyAtTargetFromSegments(ev?.message);
    if (!target) return;
    const selfId = String(ctx?.onebot?.selfId ?? '');
    if (String(target.atQq) === selfId) return;  // @ 的是机器人自己 → 不跟（跟自己很怪）
    const key = `${chatKey}::${target.replyId}`;
    if (followedSet.has(key)) return;
    followedSet.add(key);

    // 复刻别人的空@：引用同一源消息 + @ 同样的目标
    await ctx.sendSegments('group', Number(chatKey.slice(6)), [
      { type: 'reply', data: { id: String(target.replyId) } },
      { type: 'at', data: { qq: String(target.atQq) } }
    ]);
    ctx?.log?.(`空@跟读：已跟 ${chatKey} 里对 #${target.replyId} 的空@`);
  }
};

export function deactivate() {
  api = null;
  followedSet.clear();
}

// 供测试使用（纯逻辑与状态访问）
export const _internals = {
  emptyAtTargetFromSegments,
  followed: (chatKey, mid) => followedSet.has(`${chatKey}::${mid}`),
  markFollowed: (chatKey, mid) => followedSet.add(`${chatKey}::${mid}`),
  clearFollowed: () => followedSet.clear(),
  settings: () => ({ ...settings })
};
