// 冒烟测试：确认技能能加载、三个工具都在、报价链路走得通、指令前缀生效、
// 且不依赖任何已删除的模块。用最小宿主模拟，不往真实群里发消息。
const registered = [];
const sent = [];
const sentOptions = [];

const skillApi = {
  registerTool(def) { registered.push(def); return `eve-market__${def.id}`; },
  config: () => ({
    defaultLocation: 'jita', defaultServer: 'shenchen',
    // 用户要的三个指令前缀：jita / ojita / sjita
    serverPrefixShenchen: 'jita, 国服, 晨曦', serverPrefixInf: 'sjita, 曙光', serverPrefixTq: 'ojita, 欧服',
    autoSend: true,
    maxItemsPerQuery: 8, mergeIdleMs: 300, mergeBudgetMs: 60000, quoteContent: ''
  }),
  log: (...a) => console.log('[skill]', ...a),
  warn: (...a) => console.warn('[skill]', ...a),
  error: (...a) => console.error('[skill]', ...a),
  fetch: globalThis.fetch,
  interval: () => () => {},
  isSkillActive: () => true,
  capability: () => undefined,
  hasCapability: () => false
};

let pass = 0, fail = 0;
const check = (name, ok, extra = '') => {
  console.log(`  ${ok ? '✅' : '❌'} ${name}${extra ? '  ' + extra : ''}`);
  ok ? pass++ : fail++;
};

const mod = await import(new URL('../index.js', import.meta.url).href + '?smoke=1');
await mod.setup(skillApi);

console.log('=== ① 注册情况 ===');
const ids = registered.map((t) => t.id);
check('注册了 3 个工具', ids.length === 3, ids.join(', '));
check('工具是 quote / book / search', ids.join(',') === 'market_quote,market_book,market_search');
check('market_chart 已不存在', !ids.includes('market_chart'));
check('注册了 before-context 钩子', Object.keys(mod.hooks ?? {}).includes('before-context'));

console.log('\n=== ② 报价链路（真实 API）===');
const ASKER = { userId: '2248217876', senderName: '测试者' };
const ctx = {
  chatKey: 'group:100000',
  session: { id: 's1' },
  sender: {
    async sendTextBatch(chatKey, messages, options = {}) {
      sent.push({ chatKey, messages });
      sentOptions.push(options);
      return { sent: messages.map((m) => ({ text: m, messageId: 1 })), failed: [] };
    },
    // 画图已删除：这里如果被调用就说明有残留代码
    async sendImage() { throw new Error('画图功能已删除，不应该再发图'); }
  },
  store: { peekUnread: () => [] },
  emit: () => {}
};
await mod.hooks['before-context']({
  sessionId: 's1', chatKey: ctx.chatKey,
  triggerEntries: [{ senderId: ASKER.userId, senderName: ASKER.senderName, text: 'jita 阿贝拉' }]
});
const r = await registered.find((t) => t.id === 'market_quote').execute(ctx, { item: '阿贝拉', location: 'jita' });
const p = r.isError ? { error: r.content } : JSON.parse(r.content);
check('报价成功', !r.isError, r.isError ? String(r.content).slice(0, 60) : '');
await mod.flushQuotes();
check('发出 1 条卡片', sent.length === 1, `实际 ${sent.length}`);
const text = sent[0]?.messages?.[0] ?? '';
check('卡片含两位小数价格', /-出售：[\d,]+\.\d\d ISK/.test(text));
check('卡片不含走势图提示', !/想看走势/.test(text));
check('@ 指向提问者', sentOptions[0]?.atUserId === ASKER.userId, String(sentOptions[0]?.atUserId));

console.log('\n=== ③ 盘口与搜索 ===');
const rb = await registered.find((t) => t.id === 'market_book').execute(ctx, { item: '三钛合金', location: 'jita' });
check('盘口工具可用', !rb.isError);
const rs = await registered.find((t) => t.id === 'market_search').execute(ctx, { name: '地狱天使' });
const ps = rs.isError ? { count: 0 } : JSON.parse(rs.content);
check('搜索工具可用', ps.count > 0, `命中 ${ps.count} 条`);

console.log('\n=== ③.5 星域汇总要跟着地点走 ===');
// 这条曾经是 bug：星域分支硬编码伏尔戈，于是「艾玛 + region:true」拿到的是吉他的数据，
// 而 scope 也写死「伏尔戈星域（含吉他）」，看起来完全正常 —— 静默错误。
// 用两个地点的 regionId 与成交量都必须不同来钉住它。
const bookTool = registered.find((t) => t.id === 'market_book');
const rj = await bookTool.execute(ctx, { item: '三钛合金', location: 'jita', region: true });
const ra = await bookTool.execute(ctx, { item: '三钛合金', location: 'amarr', region: true });
const pj = rj.isError ? {} : JSON.parse(rj.content);
const pa = ra.isError ? {} : JSON.parse(ra.content);
check('吉他 → 伏尔戈(10000002)', pj.regionId === 10000002, `regionId=${pj.regionId} scope=${pj.scope}`);
check('艾玛 → 艾玛星域(10000043)', pa.regionId === 10000043, `regionId=${pa.regionId} scope=${pa.scope}`);
check('两个星域的数据确实不同', pj.stat?.sell?.volume !== pa.stat?.sell?.volume,
  `吉他 ${pj.stat?.sell?.volume} vs 艾玛 ${pa.stat?.sell?.volume}`);
check('scope 不再写死伏尔戈', pj.scope !== pa.scope, `${pj.scope} / ${pa.scope}`);

console.log('\n=== ⑤ 指令前缀（真实 API 验证确实换了数据源）===');
// 前缀的解析规则由 dev/triggers-test.mjs 单元测试覆盖；这里走**完整链路**：
// 前缀进 item → 被认成服务器 + 地点 → 物品名剥干净 → 真的向那个服务器发请求。
const quoteTool = registered.find((t) => t.id === 'market_quote');

// 前缀写进了工具参数说明，模型才知道该填 server
const serverDesc = quoteTool.parameters.properties.server.description;
check('参数说明里列出了三个前缀', /jita=shenchen/.test(serverDesc) && /ojita=tq/.test(serverDesc) && /sjita=inf/.test(serverDesc),
  serverDesc.slice(-52));

async function quoteWith(item, extra = {}) {
  const n = sent.length;
  const r = await quoteTool.execute(ctx, { item, ...extra });
  await mod.flushQuotes();
  const texts = sent.slice(n).map((s) => s.messages[0]);
  return { r, text: texts.join('\n'), server: (texts.join('\n').match(/服务器：(\S+)/) ?? [])[1] ?? '' };
}

const qDefault = await quoteWith('三钛合金');
check('不带前缀 → 默认服务器（晨曦）', qDefault.server === '晨曦', `服务器=${qDefault.server}`);

const qJita = await quoteWith('jita 三钛合金');
check('「jita 三钛合金」→ 晨曦', qJita.server === '晨曦', `服务器=${qJita.server}`);

const qOjita = await quoteWith('ojita 三钛合金');
check('「ojita 三钛合金」→ 宁静', qOjita.server === '宁静', `服务器=${qOjita.server}`);
check('前缀被剥掉，确实查到了物品（不是搜"ojita 三钛合金"）',
  /三钛合金/.test(qOjita.text) && /-出售：/.test(qOjita.text));

const qSjita = await quoteWith('sjita 三钛合金');
check('「sjita 三钛合金」→ 曙光', qSjita.server === '曙光', `服务器=${qSjita.server}`);

// 中文叫法也要能当指令前缀（否则会被当成物品名去搜）
const qGuofu = await quoteWith('国服 三钛合金');
check('「国服 三钛合金」→ 晨曦（且地点是吉他）', qGuofu.server === '晨曦', `服务器=${qGuofu.server}`);
check('  → 物品名剥干净，确实查到了物品', /三钛合金/.test(qGuofu.text) && /-出售：/.test(qGuofu.text));
const qOufu = await quoteWith('欧服 三钛合金');
check('「欧服 三钛合金」→ 宁静', qOufu.server === '宁静', `服务器=${qOufu.server}`);

// 价格本身就证明换了数据源：晨曦 9.x、宁静 3.x、曙光各不同
const priceOf = (t) => Number((t.match(/-出售：([\d,.]+) ISK/) ?? [])[1]?.replace(/,/g, '') ?? NaN);
const pxChenxi = priceOf(qJita.text), pxNingjing = priceOf(qOjita.text), pxShuguang = priceOf(qSjita.text);
check('三个服务器的价格确实不同（说明真的换了数据源）',
  Number.isFinite(pxChenxi) && Number.isFinite(pxNingjing) && Number.isFinite(pxShuguang)
    && new Set([pxChenxi, pxNingjing, pxShuguang]).size === 3,
  `晨曦 ${pxChenxi} / 宁静 ${pxNingjing} / 曙光 ${pxShuguang}`);

// 前缀带地点：ojita 指向吉他
check('前缀自带地点：ojita 查的是吉他', qOjita.text.includes('吉他') || qOjita.text.includes('10000002') === false,
  '（单件卡片不写地点行，地点由 §③.5 的星域用例覆盖）');

// 前缀在中间时不剥（避免误删物品名里的字）
const qMid = await quoteWith('阿贝拉 ojita');
check('前缀不在词首 → 不认，按原样搜（预期搜不到）',
  qMid.r.isError || !qMid.text.includes('服务器：'), qMid.r.isError ? 'isError（符合预期）' : '未发卡片（符合预期）');

// 模型自己把前缀填进 server 参数时也必须对 —— 否则会静默退回默认服务器，
// 查出来是别的服的价格还不报错。这条曾经是真空档（被断言抓到过）。
for (const [prefix, expect] of [['ojita', '宁静'], ['sjita', '曙光'], ['jita', '晨曦']]) {
  const r = await quoteTool.execute(ctx, { item: '三钛合金', server: prefix });
  const p = r.isError ? {} : JSON.parse(r.content);
  check(`模型把「${prefix}」填进 server 参数 → ${expect}`, p.server === expect, `server=${p.server}`);
}

console.log('\n=== ⑥ 不再依赖已删除的模块 ===');
const src = await (await import('node:fs/promises')).readFile(new URL('../index.js', import.meta.url), 'utf8');
for (const gone of ['chart.js', 'tape.js', 'history.js', 'draw-chart', 'renderChart', 'sendImage', 'skillApi.interval']) {
  check(`index.js 里没有 "${gone}"`, !src.includes(gone));
}
// 库的导入方式变了：现在是**动态导入 + mtime 查询串** —— 为了让"改了库内容"
// 能真正生效（静态相对导入的 URL 永远不变，改了也拿旧模块，这个坑踩过四次）。
// 所以这里断言新机制，而不是旧的静态导入写法。
const staticImports = [...src.matchAll(/from '(\.\/[^']+)'/g)].map((m) => m[1]);
const dynLibs = [...src.matchAll(/loadLib\('(\.\/lib-v\d+\/[^']+)'\)/g)].map((m) => m[1]);
check('没有静态的相对导入了（已全部改为动态）', staticImports.length === 0, staticImports.join(', ') || '（无）');
check('动态导入恰好两个库文件', dynLibs.length === 2 && dynLibs.every((p) => /^\.\/lib-v\d+\//.test(p)),
  dynLibs.join(', '));
check('用 mtime 查询串做缓存失效（改库内容能自动生效，不必手工升目录名）',
  /mtime=\$\{stamp\}/.test(src) && /statSync/.test(src));

console.log(`\n通过 ${pass} / ${pass + fail}`);
if (fail) process.exitCode = 1;
