// 逐条核对用户的要求："国服默认查询吉他市场"。
// 这句话可能指三件事，每件单独验：
//   A) 不带任何前缀时，默认服务器是国服（晨曦），默认地点是吉他
//   B) 「国服」这个词本身能被认出来（用户上一条消息里提过这个词）
//   C) 默认服务器 + 默认地点组合起来，真的是「晨曦的吉他」
import { buildPrefixes, matchPrefix, FALLBACK_HUB } from '../lib-v4/triggers.js';
import { resolveServer, resolveLocation, LOCATIONS } from '../lib-v4/ceve.js';

let pass = 0, fail = 0;
const check = (name, ok, extra = '') => {
  console.log(`  ${ok ? '✅' : '❌'} ${name}${extra ? '  ' + extra : ''}`);
  ok ? pass++ : fail++;
};

// 与 skill.json 的默认值保持一致
const DEFAULT_CFG = {
  defaultLocation: 'jita',
  defaultServer: 'shenchen',
  serverPrefixShenchen: 'jita, 国服, 晨曦',
  serverPrefixInf: 'sjita, 曙光',
  serverPrefixTq: 'ojita, 欧服'
};
console.log('被检查的默认配置:');
for (const [k, v] of Object.entries(DEFAULT_CFG)) console.log(`    ${k} = ${v}`);
console.log('');

console.log('=== A) 不带前缀时的默认行为 ===');
const srv0 = resolveServer(DEFAULT_CFG.defaultServer);
const loc0 = resolveLocation(DEFAULT_CFG.defaultLocation);
check('默认服务器是国服（晨曦）', srv0.key === 'shenchen' && srv0.label === '晨曦', `${srv0.label}(${srv0.key})`);
check('默认地点是吉他', loc0.key === 'jita' && loc0.label === '吉他', `${loc0.label}(${loc0.key})`);
check('吉他 = 星系 30000142（晨曦的吉他）', loc0.systemId === 30000142, `systemId=${loc0.systemId}`);
check('吉他的星域是伏尔戈 10000002', loc0.regionId === 10000002, `regionId=${loc0.regionId}`);

console.log('\n=== B) 中文叫法能不能被认出来 ===');
const P = buildPrefixes(DEFAULT_CFG);
// 作为 server 参数传给 resolveServer（走别名表）
check('resolveServer("国服") → 晨曦', resolveServer('国服').key === 'shenchen', resolveServer('国服').label);
check('resolveServer("晨曦") → 晨曦', resolveServer('晨曦').key === 'shenchen');
check('resolveServer("欧服") → 宁静', resolveServer('欧服').key === 'tq', resolveServer('欧服').label);

// 作为指令前缀：中文叫法也配上了。剥完认不出地点 → location=null → 回退默认 hub（吉他）
const hitGuofu = matchPrefix('国服 三钛合金', P);
check('「国服 三钛合金」命中前缀「国服」', hitGuofu?.prefix === '国服', String(hitGuofu?.prefix));
check('  → 服务器 = 晨曦', hitGuofu && resolveServer(hitGuofu.server).key === 'shenchen',
  hitGuofu ? resolveServer(hitGuofu.server).label : '');
check('  → 物品名剥干净 = 三钛合金', hitGuofu?.rest === '三钛合金', String(hitGuofu?.rest));
check('  → 地点交给默认 hub（前缀里没有地点信息）', hitGuofu?.location === null,
  '最终地点 = ' + resolveLocation(DEFAULT_CFG.defaultLocation).label);

console.log('\n=== C) 前缀 jita 的完整解析（晨曦 + 吉他）===');
const hit = matchPrefix('jita 三钛合金', P);
check('「jita 三钛合金」命中前缀 jita', hit?.prefix === 'jita');
check('  → 服务器 = 晨曦', hit && resolveServer(hit.server).label === '晨曦', hit ? resolveServer(hit.server).label : '');
check('  → 地点 = 吉他', hit?.location === 'jita', String(hit?.location));
check('  → 物品名 = 三钛合金', hit?.rest === '三钛合金', String(hit?.rest));
const finalLoc = resolveLocation(hit?.location ?? DEFAULT_CFG.defaultLocation);
check('  → 最终查的是吉他（星系 30000142）', finalLoc.systemId === 30000142, `${finalLoc.label} ${finalLoc.systemId}`);

console.log('\n=== D) 三个服务器的 jita 前缀都指向同一个吉他 ===');
for (const [srvKey, prefix] of [['shenchen', 'jita'], ['tq', 'ojita'], ['inf', 'sjita']]) {
  const h = matchPrefix(`${prefix} 三钛合金`, P);
  const loc = resolveLocation(h?.location ?? 'jita');
  const srv = resolveServer(h?.server ?? '');
  check(`${prefix.padEnd(6)} → ${srv.label} 的 ${loc.label}`, srv.key === srvKey && loc.systemId === 30000142,
    `${srv.label} / ${loc.label}(${loc.systemId})`);
}

console.log('\n=== E) 前缀默认 hub 与全局兜底互不干扰 ===');
// 把全局兜底故意改成艾玛：带前缀的查询应当**不受影响**，仍然查吉他。
// 这验证了「三个服务器默认都查吉他」是前缀体系的固定约定（FALLBACK_HUB），
// 而不是被那个全局值牵动。
const CFG_AMARR = { ...DEFAULT_CFG, defaultLocation: 'amarr' };
for (const [label, text] of [['国服 三钛合金', '国服'], ['jita 三钛合金', 'jita'],
  ['曙光 三钛合金', '曙光'], ['欧服 三钛合金', '欧服']]) {
  const h = matchPrefix(text, buildPrefixes(CFG_AMARR));
  // 与 index.js 的 resolveQuery 同一套回退：参数 → 前缀地点 → FALLBACK_HUB → 全局
  const loc = resolveLocation(h?.location ?? FALLBACK_HUB);
  check(`全局兜底=艾玛时，「${label}」仍查吉他`, loc.key === 'jita', `${loc.label}(${loc.key})`);
}
// 而没有任何前缀时才用全局兜底（艾玛）
const bare = resolveLocation(CFG_AMARR.defaultLocation);
check('没有前缀时才用全局兜底（此时是艾玛）', bare.key === 'amarr', `${bare.label}(${bare.key})`);
// 带地点的前缀照旧认自己
const hAmarr = matchPrefix('oamarr 三钛合金', buildPrefixes({ ...CFG_AMARR, serverPrefixTq: 'ojita, oamarr' }));
check('带地点的前缀照旧认自己（oamarr → 艾玛）', hAmarr?.location === 'amarr', String(hAmarr?.location));
check('FALLBACK_HUB 就是吉他（三个服的共同默认）', FALLBACK_HUB === 'jita', FALLBACK_HUB);

console.log(`\n通过 ${pass} / ${pass + fail}`);
console.log('\n=== 结论 ===');
console.log('A~E 全绿 → 「不带前缀 = 晨曦的吉他」成立，且国服的默认 hub 独立于全局兜底。');
console.log('中文叫法（国服/晨曦/曙光/欧服）也都配成了指令前缀，不会被当成物品名。');
if (fail) process.exitCode = 1;