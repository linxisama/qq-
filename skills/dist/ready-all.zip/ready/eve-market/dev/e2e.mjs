// 开发期自测：模拟 QQ Agent 的技能宿主，跑通 eve-market 技能全链路。
// 用法：node dev/e2e.mjs [物品名] [地点]
import fs from 'node:fs';
import path from 'node:path';

const registered = [];
const sentTexts = [];
const sentOptions = [];

/** 这个技能只有三个工具（图表工具已整个删掉，不该再注册回来）。 */
const EXPECTED_TOOLS = ['market_quote', 'market_book', 'market_search'];

const skillApi = {
  registerTool(def) { registered.push(def); return `eve-market__${def.id}`; },
  config: () => ({
    defaultLocation: 'jita',
    defaultServer: 'shenchen',
    autoSend: true,
    // ⚠️ 静默窗口要**明显大于**轮与轮之间的间隔（下面用的 120ms），否则定时器
    //    会在两次查询之间到点、把批次提前放出去，测试就会随机地拆成两条。
    //    300ms 对 120ms 只差 2.5 倍，实测偶发失败；这里放大到 3000ms（差 25 倍）。
    mergeIdleMs: 3000,
    mergeBudgetMs: 60000,
    quoteContent: ''
  }),
  log: (...a) => console.log('[skill]', ...a),
  warn: (...a) => console.warn('[skill]', ...a),
  error: (...a) => console.error('[skill]', ...a),
  fetch: globalThis.fetch,
  interval: () => () => {},
  isSkillActive: () => true,
  capability: () => undefined,
  hasCapability: () => false
};

const mod = await import(new URL('../index.js', import.meta.url).href);
await mod.setup(skillApi);
const toolIds = registered.map((t) => t.id);
const toolOk = toolIds.length === EXPECTED_TOOLS.length && EXPECTED_TOOLS.every((id) => toolIds.includes(id));
console.log('注册工具（' + toolIds.length + ' 个）:', toolIds.join(', '));
console.log('注册钩子:', Object.keys(mod.hooks ?? {}).join(', ') || '（无）');

const byId = (id) => registered.find((t) => t.id === id);
const ctx = {
  chatKey: 'group:100000',
  selfId: '10001',
  sender: {
    async sendTextBatch(chatKey, messages, options = {}) {
      sentTexts.push({ chatKey, messages });
      sentOptions.push(options);
      return { sent: messages.map((m) => ({ text: m, messageId: 1 })), failed: [] };
    },
    // 这个技能只发文字；留着这个方法只是让模拟宿主的接口保持完整
    async sendImage() { return { message_id: 1 }; }
  },
  session: { id: 's1', sent: [] },
  emit: () => {}
};

// 模拟核心在开轮前调 before-context（把"谁问的"交给技能）
const ASKER = { userId: '2248217876', senderName: '叱咤月海毛毛雨' };
await mod.hooks['before-context']({
  sessionId: 's1',
  chatKey: ctx.chatKey,
  triggerEntries: [
    { senderId: '10086', senderName: '别人', text: '无关的一句' },
    { senderId: ASKER.userId, senderName: ASKER.senderName, text: 'jita 阿贝拉' }
  ]
});

// ① 正常报价（贵物品）
const t0 = Date.now();
const r1 = await byId('market_quote').execute(ctx, { item: process.argv[2] ?? '阿贝拉', location: process.argv[3] ?? 'jita' });
const p1 = JSON.parse(r1.content);
await mod.flushQuotes();   // 合并窗口是异步的，测试里立刻放行
console.log(`\n=== ① 报价（${Date.now() - t0}ms, isError=${Boolean(r1.isError)}）===`);
console.log('报了', p1.reported ?? 0, '件 | sent =', p1.sent, '| 第一件 =', p1.items?.[0]?.typeName);
console.log('\n--- 实际发出的文本 ---');
console.log(sentTexts[0]?.messages?.[0] ?? '(未发出)');

// ② 简称命中多件：应一次全报
await byId('market_quote').execute(ctx, { item: '胡蜂', location: 'jita' });
await mod.flushQuotes();
const multiText = sentTexts[1]?.messages?.[0] ?? '';
const multiCount = (multiText.match(/^ {2}-出售：/gm) ?? []).length;
console.log('\n=== ② 简称「胡蜂」→ 报了 ' + multiCount + ' 件 ===');
console.log(multiText);

// ③ 小额物品：验证两位小数（三钛合金 8~10 ISK）
await byId('market_quote').execute(ctx, { item: '三钛合金', location: 'jita' });
await mod.flushQuotes();
console.log('\n=== ③ 小额物品（两位小数）===');
console.log(sentTexts[2]?.messages?.[0]);

// ③.5 合并：模拟模型一轮里连查两件
// 核心是 `for (const call of toolCalls) await executeTool(...)` —— 同一批工具调用
// **串行**执行，所以这里也要串行，卡片顺序才和线上一致（并发跑会把顺序随机化）。
const beforeMerge = sentTexts.length;
const seqA = await byId('market_quote').execute(ctx, { item: '皮特姆多谱式护盾增强器 A型', location: 'jita' });
const seqB = await byId('market_quote').execute(ctx, { item: '皮特姆多谱式护盾增强器 B型', location: 'jita' });
await mod.flushQuotes();
const mergedText = sentTexts[sentTexts.length - 1]?.messages?.[0] ?? '';
const mergedItemCount = (mergedText.match(/^ {2}-出售：/gm) ?? []).length;
const newMessages = sentTexts.length - beforeMerge;
const orderOk = mergedText.indexOf('A型') >= 0 && mergedText.indexOf('A型') < mergedText.indexOf('B型');
console.log('\n=== ③.5 一轮连查两件 → 新增消息 ' + newMessages + ' 条，合并后 ' + mergedItemCount + ' 件 ===');
console.log(mergedText);
console.log('工具返回 mergedInto =', JSON.parse(seqA.content).mergedInto, '/', JSON.parse(seqB.content).mergedInto,
  '| 顺序 A→B =', orderOk ? '正确' : '反了');

// ④ 查不到的物品
const r4 = await byId('market_quote').execute(ctx, { item: '这个东西不存在xyz' });
console.log('\n=== ④ 不存在的物品 ===');
console.log(r4.content.slice(0, 110));

// ⑤ 盘口明细
const r5 = await byId('market_book').execute(ctx, { item: '三钛合金', location: 'jita' });
const p5 = JSON.parse(r5.content);
console.log('\n=== ⑤ 盘口 三钛合金 ===');
console.log('卖一:', JSON.stringify(p5.sellTop?.[0]));
console.log('买一:', JSON.stringify(p5.buyTop?.[0]));
console.log('挂单数: 卖', p5.sellOrders, '/ 买', p5.buyOrders);

// ⑥ 星域汇总
const r6 = await byId('market_book').execute(ctx, { item: '三钛合金', region: true });
const p6 = JSON.parse(r6.content);
console.log('\n=== ⑥ 伏尔戈星域汇总 ===');
console.log('sell.volume =', p6.stat?.sell?.volume, '| buy.min =', p6.stat?.buy?.min);

// ⑦ 模糊搜索
const r7 = await byId('market_search').execute(ctx, { name: '地狱天使' });
console.log('\n=== ⑦ 搜索「地狱天使」 ===');
console.log(r7.content.replace(/\s+/g, ' ').slice(0, 160));

// ⑧ 数字 ID 直查
const r8 = await byId('market_quote').execute(ctx, { item: '92035', location: 'jita' });
await mod.flushQuotes();
console.log('\n=== ⑧ 按 ID 直查 ===');
console.log('第一件 =', JSON.parse(r8.content).items?.[0]?.typeName);

// ⑨ 插件不落盘：数据全部实时取自 API，技能目录下不该出现 data/
console.log('\n=== ⑨ 落盘检查 ===');
console.log('技能目录下 data/ 存在?', fs.existsSync(path.join(import.meta.dirname, '..', 'data')));

// ⑩ 断言：两位小数 + 简称多件 + @ 提问的人
const allText = sentTexts.map((s) => s.messages[0]).join('\n');
const priceLines = allText.match(/-[出售收购中间]+：[\d,]+(\.\d+)? ISK/g) ?? [];
const missingDecimals = priceLines.filter((l) => !/\.\d\d ISK$/.test(l));
const atTargets = sentOptions.map((o) => o?.atUserId).filter(Boolean);
const cardHasAt = /(^|\n)\s*@/.test(allText);
console.log('\n=== ⑩ 断言 ===');
console.log('价格行总数 =', priceLines.length, '| 缺两位小数的 =', missingDecimals.length, missingDecimals.length ? missingDecimals.join(' / ') : '（全部合格）');
console.log('简称多件 =', multiCount > 1 ? '合格' : '未触发');
console.log('@ 目标 =', JSON.stringify(atTargets), atTargets.length && atTargets.every((t) => t === ASKER.userId) ? '（全部指向提问者，合格）' : '（不合格）');
console.log('卡片正文里还有 @ =', cardHasAt ? '有（不合格）' : '无（合格）');
console.log('会话留档类型:', JSON.stringify(ctx.session.sent.map((s) => s.type)));

// ⑪ 兜底：钩子没跑到时，退回"存档里最后一条别人说的话"
const ctx2 = {
  chatKey: 'group:999',
  session: { id: 's2', sent: [] },
  store: {
    peekUnread: () => [
      { senderId: '111', senderName: '甲', text: '无关' },
      { senderId: '222', senderName: '乙', text: 'jita 阿贝拉' }
    ]
  },
  sender: {
    async sendTextBatch(chatKey, messages, options = {}) {
      sentTexts.push({ chatKey, messages });
      sentOptions.push(options);
      return { sent: [], failed: [] };
    }
  },
  emit: () => {}
};
const r11 = await byId('market_quote').execute(ctx2, { item: '阿贝拉', location: 'jita' });
await mod.flushQuotes();
console.log('\n=== ⑪ 兜底路径（无钩子，靠存档）===');
console.log('asker =', JSON.stringify(JSON.parse(r11.content).asker), '| atUserId =', sentOptions[sentOptions.length - 1]?.atUserId ?? '(无)');
const fallbackOk = sentOptions[sentOptions.length - 1]?.atUserId === '222';

// ⑫ autoSend 关闭时：不该发消息，且要把 @ 目标交给模型
const quiet = [];
const skillApiQuiet = { ...skillApi, config: () => ({ autoSend: false }) };
const mod2Path = new URL('../index.js', import.meta.url).href + '?quiet=1';
const mod2 = await import(mod2Path);
const tools2 = [];
await mod2.setup({ ...skillApiQuiet, registerTool: (d) => tools2.push(d) });
await mod2.hooks['before-context']({ sessionId: 's3', triggerEntries: [{ senderId: '333', senderName: '丙' }] });
const r12 = await tools2.find((t) => t.id === 'market_quote').execute({
  chatKey: 'group:1',
  session: { id: 's3', sent: [] },
  sender: { sendTextBatch: async (k, m) => { quiet.push(m[0]); return { sent: [], failed: [] }; } },
  emit: () => {}
}, { item: '阿贝拉', location: 'jita' });
await mod2.flushQuotes();
const p12 = JSON.parse(r12.content);
console.log('\n=== ⑫ autoSend 关闭 ===');
console.log('已发送条数 =', quiet.length, '| sent 字段 =', p12.sent, '| asker =', JSON.stringify(p12.asker));
console.log('note =', p12.note);
const quietOk = quiet.length === 0 && p12.sent === false && /333/.test(p12.note);

// ⑬ 合并断言：一轮两次查询 → 只多一条消息、两件都在这条里、顺序与提问一致
const mergeOk = newMessages === 1 && mergedItemCount === 2 && orderOk;

// ⑭ 复现线上那个真实场景：「月矿呢」被模型拆成很多轮一件一件问
//    关键点：轮次边界（before-context）**不能**把没问完的草稿提前放出去。
console.log('\n=== ⑭ 跨多轮连问 6 件（模拟「月矿呢」）===');
const minerals = ['沸石', '钾盐', '沥青', '柯石英', '钴酸盐', '黑稀金矿'];
const beforeFlood = sentTexts.length;
for (const name of minerals) {
  // 每一轮：核心先跑 before-context（模型又开口了），再调工具
  await mod.hooks['before-context']({
    sessionId: 's1',
    chatKey: ctx.chatKey,
    triggerEntries: [{ senderId: ASKER.userId, senderName: ASKER.senderName, text: name }]
  });
  await byId('market_quote').execute(ctx, { item: name, location: 'jita' });
  await new Promise((r) => setTimeout(r, 120));   // 轮与轮之间的小间隔（远小于静默窗口）
}
const midFlood = sentTexts.length - beforeFlood;
await mod.flushQuotes();                           // 等模型不再问了
// ⚠️ 断言要覆盖"这一轮发出的**所有**消息"，不能只看最后一条 ——
//    只看最后一条时，一旦提前放行就会读到空/半条，报出 "0 件" 这种假象（踩过）。
const floodMsgs = sentTexts.slice(beforeFlood).map((s) => s.messages[0]);
const floodText = floodMsgs.join('\n');
const floodItems = (floodText.match(/^ {2}-出售：/gm) ?? []).length;
const floodMessages = floodMsgs.length;
console.log('逐轮提问期间已发出 =', midFlood, '条（应为 0，说明没有提前放行）');
console.log('最终合计 =', floodMessages, '条消息 /', floodItems, '件');
console.log(floodMsgs[sentTexts.length - beforeFlood - 1] ?? '');
const floodOk = floodMessages === 1 && floodItems === minerals.length;

// ⑮ 线上误发事故的回归：搜不到 / 无挂单时，绝不能把"给模型的说明"当消息发出去
console.log('\n=== ⑮ 误发回归（事故复现）===');
const leakTexts = [];
const leakCtx = {
  chatKey: 'group:1',
  session: { id: 'sleak', sent: [] },
  sender: { sendTextBatch: async (k, m) => { leakTexts.push(m[0]); return { sent: [], failed: [] }; } },
  emit: () => {}
};
await mod.hooks['before-context']({
  sessionId: 'sleak',
  chatKey: 'group:1',
  triggerEntries: [{ senderId: '999', senderName: '某人', text: '吉他月矿产物' }]
});
const leakA = await byId('market_quote').execute(leakCtx, { item: '月矿产物', location: 'jita' });
await mod.flushQuotes();
const leakB = await byId('market_quote').execute(leakCtx, { item: '沸石', location: 'jita' });
await mod.flushQuotes();
// 「月矿产物」在 ceve 里搜不到 → 工具返回 isError 的提示（给模型看的），绝不能变成群消息
const leakRawA = leakA.isError ? leakA.content : (JSON.parse(leakA.content).note ?? '');
const leakNoteB = leakB.isError ? leakB.content : (JSON.parse(leakB.content).note ?? '');
const joined = [...leakTexts, leakRawA, leakNoteB].join('\n');

// 判定标准（比"没发消息"更精确）：发出去的只能是**报价卡片**，
// 不能包含任何"给模型的说明"腔调，也不能出现字面量 undefined。
const instructional = /如实告诉群友|不要编造|让群友确认|换个 hub|不要把技术错误|你自己组织|请原样发送|不要再重复/;
const leakedTexts = leakTexts.filter((t) => instructional.test(t));
const hasUndefined = /undefined/.test(joined);
// 沸石确实有买单 → 它那张卡片是**该发的**，这里只用来确认正常路径没被误伤
const cardOk = leakTexts.length === 1 && /^沸石\n-出售：/.test(leakTexts[0]);
console.log('搜不到时 isError =', Boolean(leakA.isError), '| 自动发出的消息数 =', leakTexts.length);
console.log('返回给模型的内容 =', leakRawA.slice(0, 70));
console.log('发出的卡片 =', JSON.stringify(leakTexts[0] ?? null).slice(0, 90));
console.log('其中"说明腔"的误发 =', leakedTexts.length, '条（应为 0）');
console.log('文本里出现字面量 undefined =', hasUndefined ? '有（不合格）' : '无（合格）');
const leakOk = leakedTexts.length === 0 && !hasUndefined && cardOk;

// ─────────────────────────────────────────────────────────────────────────────
console.log('\n=== ⑯ 汇总 ===');
console.log('工具数 =', toolOk ? `合格（${toolIds.length} 个：${toolIds.join(' / ')}）` : `不合格（${toolIds.join(' / ') || '无'}）`,
  '| 两位小数 =', missingDecimals.length ? '不合格' : '合格',
  '| 简称多件 =', multiCount > 1 ? '合格' : '不合格',
  '| 合并成一条 =', mergeOk ? `合格（${mergedItemCount} 件）` : `不合格（新增 ${newMessages} 条，${mergedItemCount} 件）`,
  '| 跨轮不刷屏 =', floodOk ? `合格（6 件 → ${floodMessages} 条）` : `不合格（${floodMessages} 条 / ${floodItems} 件）`,
  '| 不误发说明 =', leakOk ? '合格' : '不合格',
  '| 钩子 @ =', atTargets.every((t) => t === ASKER.userId) && atTargets.length ? '合格' : '不合格',
  '| 卡片无 @ =', cardHasAt ? '不合格' : '合格',
  '| 兜底 @ =', fallbackOk ? '合格' : '不合格',
  '| autoSend 关 =', quietOk ? '合格' : '不合格');
if (missingDecimals.length || multiCount <= 1 || !atTargets.length || !mergeOk || !floodOk || !leakOk
    || !atTargets.every((t) => t === ASKER.userId) || cardHasAt || !fallbackOk || !quietOk || !toolOk) {
  process.exitCode = 1;
}
