// 设置项审计：每一行都必须能对上代码里的实际读取点。
// 目的是抓"设置了但没人读"的死项，以及"描述与实际不符"的项。
import { readFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const HERE = dirname(fileURLToPath(import.meta.url));
const ROOT = join(HERE, '..');
const manifest = JSON.parse(readFileSync(join(ROOT, 'skill.json'), 'utf8'));
const src = readFileSync(join(ROOT, 'index.js'), 'utf8');
// 库文件里也可能读配置（目前没有，但一并扫，避免漏判）
const libs = ['lib-v4/ceve.js', 'lib-v4/triggers.js']
  .map((p) => { try { return readFileSync(join(ROOT, p), 'utf8'); } catch { return ''; } })
  .join('\n');
const all = src + '\n' + libs;
const lib = manifest.id ? '' : '';

let pass = 0, fail = 0;
const check = (name, ok, extra = '') => {
  console.log(`  ${ok ? '✅' : '❌'} ${name}${extra ? '  ' + extra : ''}`);
  ok ? pass++ : fail++;
};

const declared = Object.keys(manifest.settings ?? {});
const schema = Object.keys(manifest.configSchema ?? {});

console.log(`=== 清单里有 ${declared.length} 个设置项 ===`);
console.log('');

console.log('=== ① 声明了就必须有读取点（抓死项）===');
// 三种读法都要认，否则会把"真读了"误判成死项：
//   cfg().xxx            直接读
//   conf.xxx             cfg() 的结果存进局部变量后读（resolveQuery 就是这种）
//   cfg()[SOME_MAP[key]] 经映射表间接读（设置项名只作为字符串出现）
const indirectKeys = new Set([...all.matchAll(/'([A-Za-z]\w*)'/g)].map((m) => m[1]));
const READERS = ['cfg\\(\\)', 'config', 'conf'];
for (const key of declared) {
  const direct = READERS.some((r) => new RegExp(`${r}\\??\\.${key}\\b`).test(all));
  const indirect = indirectKeys.has(key) && /\[[^\]]*\]/.test(all);
  check(`${key.padEnd(22)} 代码里有读取点`, direct || indirect,
    direct ? '直接读' : (indirect ? '间接读（经映射表）' : '⚠️ 没人读 → 死项'));
}

console.log('\n=== ② settings 与 configSchema 必须一一对应 ===');
check('数量一致', declared.length === schema.length, `settings=${declared.length} schema=${schema.length}`);
const onlySettings = declared.filter((k) => !schema.includes(k));
const onlySchema = schema.filter((k) => !declared.includes(k));
check('没有"只在 settings 里"的项', onlySettings.length === 0, onlySettings.join(', ') || '（无）');
check('没有"只在 schema 里"的项', onlySchema.length === 0, onlySchema.join(', ') || '（无）');

console.log('\n=== ③ 每个 schema 项都必须有 label 与非空 description ===');
for (const key of schema) {
  const s = manifest.configSchema[key];
  const okLabel = typeof s.label === 'string' && s.label.trim().length > 0;
  const okDesc = typeof s.description === 'string' && s.description.trim().length >= 20;
  check(`${key.padEnd(22)} label+描述齐全`, okLabel && okDesc,
    okLabel && okDesc ? `描述 ${s.description.length} 字` : `label=${okLabel} desc=${s.description?.length ?? 0}字`);
}

console.log('\n=== ③.5 描述长度必须 ≤ 60 字（超过就整块占满一行）===');
// 这条是"设置页太乱"的真正原因：界面渲染器里
//   const isWide = d.type === 'string' && (d.multiline === true || String(d.description||'').length > 60);
// 描述一超过 60 字就整块占满一行 —— 几个长描述堆起来，设置页就变成一大坨文字。
for (const key of schema) {
  const s = manifest.configSchema[key];
  const len = String(s.description ?? '').length;
  // 多行文本框本身就是要占满一行的，不适用
  const exempt = s.multiline === true;
  check(`${key.padEnd(22)} 描述 ${String(len).padStart(3)} 字`, exempt || len <= 60,
    exempt ? '（多行文本框，豁免）' : (len <= 60 ? `余量 ${60 - len}` : '⚠️ 超过 60 → 界面会占满一行'));
}

console.log('\n=== ③.6 不该有界面不读的字段（避免误导维护者）===');
const RENDERER_FIELDS = new Set(['label', 'description', 'type', 'values', 'multiline', 'secret']);
for (const key of schema) {
  const extra = Object.keys(manifest.configSchema[key]).filter((k) => !RENDERER_FIELDS.has(k));
  check(`${key.padEnd(22)} 无多余字段`, extra.length === 0, extra.join(', ') || '（只用了界面认的字段）');
}

console.log('\n=== ④ 类型与默认值必须自洽 ===');
for (const key of schema) {
  const s = manifest.configSchema[key];
  const v = manifest.settings[key];
  let ok = true, why = '';
  if (s.type === 'enum') {
    ok = Array.isArray(s.values) && s.values.includes(v);
    why = `values=[${(s.values ?? []).join(',')}] 默认=${JSON.stringify(v)}`;
  } else if (s.type === 'boolean') {
    ok = typeof v === 'boolean'; why = `默认=${JSON.stringify(v)}`;
  } else if (s.type === 'number') {
    ok = Number.isFinite(v); why = `默认=${JSON.stringify(v)}`;
  } else if (s.type === 'string') {
    ok = typeof v === 'string'; why = `默认=${JSON.stringify(v).slice(0, 30)}`;
  }
  check(`${key.padEnd(22)} 类型自洽`, ok, why);
}

console.log('\n=== ⑤ 描述里提到的键必须真实存在 ===');
// 描述里常用 `键名` 交叉引用；引用了不存在的键会让用户找不到
for (const key of schema) {
  const desc = manifest.configSchema[key].description ?? '';
  const refs = [...desc.matchAll(/[`「](serverPrefix\w+|defaultLocation|defaultServer|autoSend|maxItemsPerQuery|mergeIdleMs|mergeBudgetMs|quoteContent)[`」]/g)]
    .map((m) => m[1]);
  const bad = [...new Set(refs)].filter((r) => !schema.includes(r));
  check(`${key.padEnd(22)} 交叉引用有效`, bad.length === 0, bad.join(', ') || `引用 ${refs.length} 处全有效`);
}

console.log('\n=== ⑥ 默认值之间不能自相矛盾 ===');
const st = manifest.settings;
// 默认服务器应该被某个前缀覆盖（否则"默认服务器"和前缀体系讲的是两件事）
const prefixText = [st.serverPrefixShenchen, st.serverPrefixInf, st.serverPrefixTq].join(' ');
const allPrefixes = prefixText.split(/[\s,，、;；|/]+/).filter(Boolean);
check('默认服务器 shenchen 有对应的前缀组',
  /jita|国服|晨曦/.test(prefixText), `晨曦组前缀: ${st.serverPrefixShenchen}`);
check('默认地点 jita 能从前缀推出（jita/ojita/sjita 都指向它）',
  allPrefixes.some((p) => /jita$/i.test(p)), allPrefixes.filter((p) => /jita/i.test(p)).join(', '));
check('三个前缀设置互不重复',
  new Set(allPrefixes).size === allPrefixes.length,
  `${allPrefixes.length} 个前缀，去重后 ${new Set(allPrefixes).size} 个`);

console.log(`\n通过 ${pass} / ${pass + fail}`);
if (fail) process.exitCode = 1;
