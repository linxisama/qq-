// 指令前缀的单元测试（纯函数，不需要网络）。
//
// 模型是：**三个服务器各配自己的指令前缀**，前缀本身还带地点信息。
//     jita 三钛合金    → 晨曦服的吉他
//     ojita 三钛合金   → 宁静服的吉他
//     sjita 三钛合金   → 曙光服的吉他
// 重点钉住：前缀按长度优先匹配、剥完能认出地点、只剥词首、认不出就不猜。
import { buildPrefixes, matchPrefix, parsePrefixes, describePrefixes } from '../lib-v4/triggers.js';

let pass = 0, fail = 0;
const eq = (name, actual, expected) => {
  const a = JSON.stringify(actual);
  const e = JSON.stringify(expected);
  if (a === e) { console.log(`  ✅ ${name}`); pass++; }
  else { console.log(`  ❌ ${name}\n     期望 ${e}\n     实际 ${a}`); fail++; }
};

// 用户要的三个（就是设置项默认值）
const CFG = { serverPrefixShenchen: 'jita', serverPrefixInf: 'sjita', serverPrefixTq: 'ojita' };
const P = buildPrefixes(CFG);

console.log('=== 拆前缀 ===');
eq('逗号分隔', parsePrefixes('jita, ojita'), ['jita', 'ojita']);
eq('空格与换行也认', parsePrefixes('jita  ojita\nsjita'), ['jita', 'ojita', 'sjita']);
eq('顿号/分号/斜杠', parsePrefixes('jita、ojita;sjita|jita2'), ['jita', 'ojita', 'sjita', 'jita2']);
eq('空值返回空数组', [parsePrefixes(''), parsePrefixes(null), parsePrefixes('   ')], [[], [], []]);

console.log('\n=== 构造前缀表 ===');
// 排序规则：长度降序，等长按 localeCompare('en')。三个前缀都是 5 字符，
// 实测 'ojita'.localeCompare('sjita') < 0，所以顺序是 ojita, sjita, jita。
eq('三个服务器各一条', P, [
  { prefix: 'ojita', server: 'tq' },
  { prefix: 'sjita', server: 'inf' },
  { prefix: 'jita', server: 'shenchen' }
]);
eq('长前缀排前面（先匹配长的）',
  buildPrefixes({ serverPrefixShenchen: 'jita', serverPrefixTq: 'jita2, ojita' }).map((x) => x.prefix),
  ['jita2', 'ojita', 'jita']);
eq('同一个前缀只归第一个声明它的服务器',
  buildPrefixes({ serverPrefixShenchen: 'jita', serverPrefixInf: 'jita' }),
  [{ prefix: 'jita', server: 'shenchen' }]);
eq('设置里写多个前缀', buildPrefixes({ serverPrefixTq: 'ojita, oamarr, 欧服' }).map((x) => x.prefix),
  ['oamarr', 'ojita', '欧服']);
eq('全空 → 空前缀表', buildPrefixes({}), []);

console.log('\n=== 用户要的三个指令（核心用例）===');
eq('jita 三钛合金 → 晨曦 + 吉他',
  matchPrefix('jita 三钛合金', P),
  { prefix: 'jita', server: 'shenchen', location: 'jita', rest: '三钛合金' });
eq('ojita 三钛合金 → 宁静 + 吉他',
  matchPrefix('ojita 三钛合金', P),
  { prefix: 'ojita', server: 'tq', location: 'jita', rest: '三钛合金' });
eq('sjita 三钛合金 → 曙光 + 吉他',
  matchPrefix('sjita 三钛合金', P),
  { prefix: 'sjita', server: 'inf', location: 'jita', rest: '三钛合金' });
eq('无空格也认（ojita阿贝拉）',
  matchPrefix('ojita阿贝拉', P),
  { prefix: 'ojita', server: 'tq', location: 'jita', rest: '阿贝拉' });
eq('大小写不敏感（OJITA）',
  matchPrefix('OJITA 三钛合金', P),
  { prefix: 'ojita', server: 'tq', location: 'jita', rest: '三钛合金' });
eq('只说了前缀 → 用前缀原文当物品名',
  matchPrefix('ojita', P),
  { prefix: 'ojita', server: 'tq', location: 'jita', rest: 'ojita' });

console.log('\n=== 前缀带出别的地点 ===');
// oamarr 里 o 是标记、amarr 是地点
const P2 = buildPrefixes({ serverPrefixTq: 'ojita, oamarr', serverPrefixInf: 'samarr' });
eq('oamarr → 宁静 + 艾玛', matchPrefix('oamarr 地狱天使级', P2),
  { prefix: 'oamarr', server: 'tq', location: 'amarr', rest: '地狱天使级' });
eq('samarr → 曙光 + 艾玛', matchPrefix('samarr 三钛合金', P2),
  { prefix: 'samarr', server: 'inf', location: 'amarr', rest: '三钛合金' });
// 认得地点就直接用（不剥标记）
eq('直接写地点名当地点（amarr）', matchPrefix('amarr 三钛合金', buildPrefixes({ serverPrefixTq: 'amarr' })),
  { prefix: 'amarr', server: 'tq', location: 'amarr', rest: '三钛合金' });
// 认不出地点 → location 为 null，交给「默认贸易 hub」
eq('前缀里的字认不出地点 → location=null', matchPrefix('oxx 三钛合金', buildPrefixes({ serverPrefixTq: 'oxx' })),
  { prefix: 'oxx', server: 'tq', location: null, rest: '三钛合金' });

console.log('\n=== 不该误判的情形 ===');
eq('没配前缀时什么都不认', matchPrefix('jita 三钛合金', buildPrefixes({})), null);
eq('前缀在中间不剥（避免误删物品名）', matchPrefix('阿贝拉 ojita', P), null);
eq('空话返回 null', [matchPrefix('', P), matchPrefix(null, P)], [null, null]);
eq('不相关的话返回 null', matchPrefix('三钛合金多少钱', P), null);
eq('中文物品名不会被误当前缀', matchPrefix('三钛合金', P), null);

console.log('\n=== 给模型看的提示串 ===');
eq('提示串（长前缀在前，等长按字典序）', describePrefixes(P), 'ojita=tq，sjita=inf，jita=shenchen');
eq('空前缀表 → 空串', describePrefixes([]), '');

console.log(`\n通过 ${pass} / ${pass + fail}`);
if (fail) process.exitCode = 1;
