// ceve-market.org API 客户端（EVE 国服：晨曦 / 曙光 / 宁静）。
//
// 用到三个公开接口（都是 EVE-Central 兼容的老接口，返回 XML/JSON）：
//   searchname  POST  name=中文名 → [{typeid, typename}]
//   quicklook   GET   typeid + usesystem/regionlimit → 逐条挂单（价格 + 剩余量 + 空间站）
//   marketstat  GET   typeid → 买卖盘汇总（volume/avg/max/min/median/percentile）
//
// 注意：POST searchname 必须显式带 Content-Type，否则服务端拒收（站点文档明说）。
// XML 解析刻意不用通用解析器：这些接口会返回自闭合的 <sell_orders />，
// 而且字段形状固定，用正则抓 order 标签比引一个 XML 依赖稳。

const SERVERS = {
  // 晨曦（Serenity，国服）—— 默认
  shenchen: { key: 'shenchen', label: '晨曦', base: 'https://www.ceve-market.org/api' },
  // 曙光（Infinity）
  inf: { key: 'inf', label: '曙光', base: 'https://www.ceve-market.org/infapi' },
  // 宁静（Tranquility，世界服）
  tq: { key: 'tq', label: '宁静', base: 'https://www.ceve-market.org/tqapi' }
};

export const DEFAULT_SERVER = 'shenchen';

/**
 * 常用地点。key 是给模型用的短名，也支持直接传 id。
 *
 * regionId 不能省：星域汇总（marketstat）是按**星域**统计的，各 hub 分属不同星域。
 * 全部落到伏尔戈的话，群友问「艾玛 XX 什么价（看星域）」会拿到吉他的数据 ——
 * 而且看起来完全正常，属于静默错误。systemId 用于单星系挂单（quicklook）。
 */
export const LOCATIONS = {
  jita: { key: 'jita', label: '吉他', systemId: 30000142, regionId: 10000002, systemName: '吉他', stationId: 60003760, stationName: '吉他 IV - 卫星 4 - 加达里海军 组装车间' },
  amarr: { key: 'amarr', label: '艾玛', systemId: 30002187, regionId: 10000043, systemName: '艾玛' },
  dodixie: { key: 'dodixie', label: '多迪谢', systemId: 30002659, regionId: 10000032, systemName: '多迪谢' },
  rens: { key: 'rens', label: '伦斯', systemId: 30002510, regionId: 10000030, systemName: '伦斯' },
  hek: { key: 'hek', label: '赫克', systemId: 30002053, regionId: 10000042, systemName: '赫克' }
};

const REGION_FORGE = 10000002;   // 伏尔戈（吉他所在星域）—— 拿不到地点星域时的兜底

/**
 * 地点 key → 地点定义 的查表（LOCATIONS 的别名）。
 *
 * 单独导出这个名字是为了给 triggers.js 用：它拿到的是「前缀剥完剩下的一截」
 * （如 `jita` / `amarr`），需要判断这一截是不是一个地点 —— 用 LOCTABLE 查比
 * 调 resolveLocation 更合适，因为 resolveLocation 对认不出的输入会**编造**一个
 * 地点出来（label 就是原文），而这里需要的是"认得出/认不出"的明确答案。
 */
export const LOCTABLE = LOCATIONS;

/**
 * 服务器名 → key 的别名表。
 *
 * 为什么放在这里而不是 triggers.js：**所有入口必须共用同一张表**。
 * 早先别名只在 triggers.js 里，于是「欧服三钛合金」能认成宁静（走关键词匹配），
 * 但模型自己把「欧服」填进 server 参数时却认不出来、静默退回默认服务器 ——
 * 两条路径结果不一致，而且都不报错。
 */
const SERVER_ALIASES = {
  shenchen: 'shenchen', 晨曦: 'shenchen', 国服: 'shenchen', serenity: 'shenchen',
  inf: 'inf', 曙光: 'inf', infinity: 'inf',
  tq: 'tq', 宁静: 'tq', 世界服: 'tq', 欧服: 'tq', tranquility: 'tq', 国际服: 'tq'
  // 注意：**指令前缀**（jita / ojita / sjita …）不在这里，它们是可配置的，
  // 归 index.js 的 resolveQuery 用「用户配的前缀表」处理。
  // 往这里加前缀会造成两份定义、将来必然漂移。
};

export function resolveServer(name) {
  const raw = String(name ?? '').trim();
  if (!raw) return SERVERS[DEFAULT_SERVER];
  const lower = raw.toLowerCase();
  if (SERVERS[lower]) return SERVERS[lower];
  const alias = SERVER_ALIASES[lower] ?? SERVER_ALIASES[raw];
  if (alias && SERVERS[alias]) return SERVERS[alias];
  return SERVERS[DEFAULT_SERVER];
}

/** 服务器别名表的只读副本（triggers.js 用它把关键词归一成 key）。 */
export function serverAliases() {
  return { ...SERVER_ALIASES };
}

export function resolveLocation(input) {
  const raw = String(input ?? '').trim();
  if (!raw) return { ...LOCATIONS.jita, assumed: true };
  const lower = raw.toLowerCase();
  if (LOCATIONS[lower]) return { ...LOCATIONS[lower] };
  for (const loc of Object.values(LOCATIONS)) {
    if (loc.label === raw || loc.systemName === raw) return { ...loc };
  }
  // 纯数字：当作星系或空间站 id 直接用
  if (/^\d+$/.test(raw)) {
    const numeric = Number(raw);
    return {
      key: raw,
      label: `星系 ${raw}`,
      systemId: numeric < 10000000 ? numeric : undefined,
      stationId: numeric >= 60000000 ? numeric : undefined
    };
  }
  return { key: raw, label: raw, systemName: raw };
}

async function requestJson(fetchImpl, url, init) {
  const res = await fetchImpl(url, init);
  if (!res.ok) throw new Error(`HTTP ${res.status}：${url}`);
  const text = await res.text();
  try { return JSON.parse(text); } catch { throw new Error(`返回不是合法 JSON：${text.slice(0, 120)}`); }
}

async function requestText(fetchImpl, url, init) {
  const res = await fetchImpl(url, init);
  if (!res.ok) throw new Error(`HTTP ${res.status}：${url}`);
  return res.text();
}

/** 按名称搜索物品 → [{ typeId, typeName }]（最多 20 条）。 */
export async function searchItems(fetchImpl, name, { server = DEFAULT_SERVER } = {}) {
  const { base } = resolveServer(server);
  const body = new URLSearchParams({ name: String(name ?? '').trim() });
  const data = await requestJson(fetchImpl, `${base}/searchname`, {
    method: 'POST',
    headers: { 'content-type': 'application/x-www-form-urlencoded' },
    body: body.toString()
  });
  if (!Array.isArray(data)) return [];
  return data
    .map((row) => ({ typeId: Number(row?.typeid), typeName: String(row?.typename ?? '') }))
    .filter((row) => Number.isFinite(row.typeId) && row.typeName);
}

/** 抓某个物品的挂单（逐条）。 */
export async function quicklook(fetchImpl, typeId, { server = DEFAULT_SERVER, systemId, regionId, hours = 8760 } = {}) {
  const { base } = resolveServer(server);
  const params = new URLSearchParams({ typeid: String(typeId), sethours: String(hours) });
  if (systemId) params.set('usesystem', String(systemId));
  else if (regionId) params.append('regionlimit', String(regionId));
  const xml = await requestText(fetchImpl, `${base}/quicklook?${params.toString()}`);
  return parseQuicklook(xml);
}

/** 解析 quicklook XML（字段固定，用正则抓 order 比引 XML 依赖稳）。 */
export function parseQuicklook(xml) {
  const text = String(xml ?? '');
  // ⚠️ 取值一律用 `[^<]*` 而不是 `[\s\S]*?`：<item> 既是外层元素名，也是每个挂单里
  // 的商品 ID 标签，非贪婪匹配会跳过内层的 `<item>92035</item>` 直接咬到外层，
  // 于是 item/quicklook 解析出一串带尖括号的原始 XML。限定"不含 <"就只匹配叶子值。
  const pick = (tag) => {
    const m = text.match(new RegExp(`<${tag}>([^<]*)</${tag}>`));
    return m ? decodeXml(m[1].trim()) : '';
  };
  const section = (tag) => {
    const m = text.match(new RegExp(`<${tag}>([\\s\\S]*?)</${tag}>`));
    return m ? m[1] : '';
  };
  const orders = (tag) => {
    const block = section(tag);
    const out = [];
    const re = /<order\b[^>]*>([\s\S]*?)<\/order>/g;
    let m;
    while ((m = re.exec(block))) {
      const inner = m[1];
      const field = (name) => {
        const f = inner.match(new RegExp(`<${name}>([^<]*)</${name}>`));
        return f ? decodeXml(f[1].trim()) : '';
      };
      const price = Number(field('price'));
      const vol = Number(field('vol_remain'));
      if (!Number.isFinite(price)) continue;
      out.push({
        price,
        volume: Number.isFinite(vol) ? vol : 0,
        minVolume: Number(field('min_volume')) || 1,
        stationId: Number(field('station')) || null,
        stationName: field('station_name'),
        regionId: Number(field('region')) || null,
        range: Number(field('range')) || 0,
        expires: field('expries') || field('expires'),
        reportedAt: field('reported_time')
      });
    }
    return out;
  };

  return {
    typeId: Number(pick('item')) || null,
    typeName: pick('quicklook'),
    hours: Number(pick('hours')) || null,
    minQuantity: Number(pick('minqty')) || 0,
    sellOrders: orders('sell_orders'),
    buyOrders: orders('buy_orders')
  };
}

/** marketstat（买卖盘汇总统计）。 */
export async function marketStat(fetchImpl, typeId, { server = DEFAULT_SERVER, regionId, systemId, hours = 8760, minQuantity = 0 } = {}) {
  const { base } = resolveServer(server);
  const params = new URLSearchParams({ typeid: String(typeId), hours: String(hours), minQ: String(minQuantity) });
  if (regionId) params.append('regionlimit', String(regionId));
  if (systemId) params.set('usesystem', String(systemId));
  const xml = await requestText(fetchImpl, `${base}/marketstat?${params.toString()}`);
  return parseMarketStat(xml);
}

export function parseMarketStat(xml) {
  const text = String(xml ?? '');
  const typeMatch = text.match(/<type\s+id="(\d+)">([\s\S]*?)<\/type>/);
  if (!typeMatch) return null;
  const typeId = Number(typeMatch[1]);
  const inner = typeMatch[2];
  const readSide = (tag) => {
    const m = inner.match(new RegExp(`<${tag}>([\\s\\S]*?)</${tag}>`));
    if (!m) return null;
    const field = (name) => {
      const f = m[1].match(new RegExp(`<${name}>([\\s\\S]*?)</${name}>`));
      return f ? Number(f[1]) : null;
    };
    return {
      volume: field('volume'),
      avg: field('avg'),
      max: field('max'),
      min: field('min'),
      stddev: field('stddev'),
      median: field('median'),
      percentile: field('percentile')
    };
  };
  return { typeId, buy: readSide('buy'), sell: readSide('sell'), all: readSide('all') };
}

/**
 * 把一批挂单压成"盘口"：卖一 / 买一 + 对应挂单量。
 * 只统计目标星系（默认吉他）的挂单 —— 全星域混在一起的价格没有参考意义。
 */
export function summarize(orders, { systemName = '' } = {}) {
  const filter = (list) => (systemName ? list.filter((o) => !o.stationName || o.stationName.includes(systemName)) : list);
  const sells = filter(orders.sellOrders ?? []).slice().sort((a, b) => a.price - b.price);
  const buys = filter(orders.buyOrders ?? []).slice().sort((a, b) => b.price - a.price);

  const bestSell = sells[0] ?? null;
  const bestBuy = buys[0] ?? null;
  const sellTotal = sells.reduce((sum, o) => sum + o.volume, 0);
  const buyTotal = buys.reduce((sum, o) => sum + o.volume, 0);

  return {
    typeId: orders.typeId,
    typeName: orders.typeName,
    sell: bestSell ? { price: bestSell.price, volume: bestSell.volume } : null,
    buy: bestBuy ? { price: bestBuy.price, volume: bestBuy.volume } : null,
    mid: bestSell && bestBuy ? (bestSell.price + bestBuy.price) / 2 : null,
    spread: bestSell && bestBuy ? bestSell.price - bestBuy.price : null,
    sellVolume: sellTotal,
    buyVolume: buyTotal,
    sellOrders: sells.length,
    buyOrders: buys.length,
    sellTop: sells.slice(0, 5).map((o) => ({ price: o.price, volume: o.volume, station: o.stationName })),
    buyTop: buys.slice(0, 5).map((o) => ({ price: o.price, volume: o.volume, station: o.stationName })),
    hours: orders.hours ?? null
  };
}

/**
 * 价格格式化：千分位 + **固定两位小数**。
 *
 * ISK 的挂单价格本身可以带小数（三钛合金 8.37 ISK、矿物 9.64 ISK 都是真实挂单价），
 * 取整会把小额物品的精度直接抹掉；统一保留两位既贴合真实盘口，也让大额报价更容易
 * 看清位数。中间价是两数平均，同样两位。
 */
export function formatIsk(value) {
  if (value === null || value === undefined || !Number.isFinite(Number(value))) return '—';
  const [intPart, decPart] = Number(value).toFixed(2).split('.');
  const sign = intPart.startsWith('-') ? '-' : '';
  const digits = sign ? intPart.slice(1) : intPart;
  return `${sign}${digits.replace(/\B(?=(\d{3})+(?!\d))/g, ',')}.${decPart}`;
}

function decodeXml(s) {
  return String(s)
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&apos;/g, "'")
    .replace(/&#(\d+);/g, (_m, d) => String.fromCodePoint(Number(d)))
    .replace(/&amp;/g, '&');
}

export { REGION_FORGE };