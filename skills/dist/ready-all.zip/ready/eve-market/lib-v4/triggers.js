// 指令前缀 → 服务器（+ 地点）的映射。
//
// ───────────────────── 设计：三个服务器各有自己的指令前缀 ─────────────────────
//
// 群友按习惯用不同前缀区分服务器，三个服务器各配一份：
//
//     晨曦服（shenchen）：jita 三钛合金
//     宁静服（欧服/tq）：  ojita 三钛合金
//     曙光服（inf）：      sjita 三钛合金
//
// 所以设置里是**三个独立设置项**（每个服务器一个），各自填自己的前缀，
// 一个设置项可以填多个前缀（逗号或换行分隔），比如宁静服填 `ojita, oamarr`。
//
// ───────────────────── 地点怎么定 ─────────────────────
//
// 前缀本身就带地点信息：`jita` / `ojita` / `sjita` 都指向**吉他**。
// 所以剥掉服务器前缀标记后剩下的那截（`jita`）会再去 ceve 的地点表里认一次：
//   · `ojita`   → 服务器=宁静，地点=吉他（剥掉 o 后认出 jita）
//   · `oamarr`  → 服务器=宁静，地点=艾玛（剥掉 o 后认出 amarr）
// 认不出地点也无妨 —— 那就走设置里的「默认贸易 hub」，前缀只负责选服务器。
//
// 为什么不做通用正则剥前缀：前缀是用户自定义的，`o` / `s` 这些标记没有通用含义
// （把 `s` 当标记会误伤 `sjita` 之外的东西）。改成**整词匹配用户配的前缀**，
// 匹配上就整段切掉、再把剩下的拿去认地点 —— 行为完全由配置决定，不做猜测。

import { LOCTABLE } from './ceve.js';

/** 标记字母：前缀剥完还剩一截时，再剥一层认地点（oamarr → amarr）。 */
const DEFAULT_MARKS = ['o', 's'];

/**
 * 前缀认不出地点时用哪个 hub（git 之前那版是三个可配置项，现在固定）。
 *
 * **刻意不做成设置项。** 要求就是"三个服务器的默认地点都是吉他"——这是个固定
 * 约定，不是需要调的东西。做成三个设置项会让设置页多三行，而它们几乎永远
 * 不会被改。真要给某个服指定别的地点，往那个服的前缀里加带地点的词即可
 * （`oamarr` 就会查艾玛）。
 */
export const FALLBACK_HUB = 'jita';

/** 把设置里的一行文本拆成前缀列表（逗号/顿号/分号/斜杠/空白都算分隔）。 */
export function parsePrefixes(text) {
  return String(text ?? '')
    .split(/[\s,，、;；|/]+/)
    .map((s) => s.trim())
    .filter(Boolean);
}

/**
 * 构造前缀表。
 *
 * @param {object} config 形如 { serverPrefixShenchen, serverPrefixInf, serverPrefixTq }
 * @returns {Array<{prefix:string, server:string}>} 按前缀长度**降序**（长的先匹配）、
 *          等长按字典序（保证结果稳定可预测）
 */
export function buildPrefixes(config = {}) {
  const groups = [
    { text: config.serverPrefixShenchen, server: 'shenchen' },
    { text: config.serverPrefixInf, server: 'inf' },
    { text: config.serverPrefixTq, server: 'tq' }
  ];
  const out = [];
  const seen = new Set();
  for (const g of groups) {
    for (const prefix of parsePrefixes(g.text)) {
      const key = prefix.toLowerCase();
      if (seen.has(key)) continue;      // 同一个前缀只归第一个声明它的服务器
      seen.add(key);
      out.push({ prefix: key, server: g.server });
    }
  }
  return out.sort((a, b) => (b.prefix.length - a.prefix.length)
    || a.prefix.localeCompare(b.prefix, 'en'));
}

/**
 * 从群友原话里认出服务器（和可能的地点），并返回**剥掉指令前缀后**的剩余文本。
 *
 * 只剥**词首**出现的前缀：「ojita 三钛合金」→「三钛合金」。
 * 前缀在中间时不剥 —— 无法可靠区分"指令"和"物品名的一部分"，
 * 宁可让搜索多带一个词，也不误删物品名里的字。
 *
 * @returns {{ prefix:string, server:string, location:string|null, rest:string }|null}
 *          location 是 ceve 的地点 key（'jita' 等），认不出为 null
 */
export function matchPrefix(query, prefixes) {
  const text = String(query ?? '').trim();
  if (!text) return null;
  const lower = text.toLowerCase();

  for (const p of prefixes ?? []) {
    if (!p?.prefix || !lower.startsWith(p.prefix)) continue;
    const rest = text.slice(p.prefix.length).trim();
    // 认地点要试两截：剥完前缀剩下的（'ojita 三钛合金' → ''）和前缀本身（'ojita'）。
    // ⚠️ 两截都要试 —— 前缀自己就是完整地点词时（jita/ojita/sjita），
    //    剩下那截是空的，只试它会一律得到 null（实测踩过）。
    const location = pickLocation(rest, p.prefix);
    return { prefix: p.prefix, server: p.server, location, rest: rest || p.prefix };
  }
  return null;
}

/**
 * 从候选文本里认出地点 key。
 *
 * 三级判断，全都是"认得出才用"，认不出返回 null（由调用方回退到 FALLBACK_HUB）：
 *   1. 整串就是地点名            → amarr
 *   2. 剥掉开头一个标记字母后是   → oamarr → amarr
 *   3. 整串只有标记字母、去掉后啥也不剩 → ojita 的剩余是空串，那就试前缀自己
 */
function pickLocation(rest, prefix) {
  for (const candidate of [rest, prefix]) {
    if (!candidate) continue;
    const s = String(candidate).toLowerCase().replace(/\s+/g, '');
    if (!s) continue;
    if (LOCTABLE[s]) return s;
    for (const mark of DEFAULT_MARKS) {
      if (!s.startsWith(mark)) continue;
      const inner = s.slice(mark.length);
      if (inner && LOCTABLE[inner]) return inner;
    }
  }
  return null;
}

/**
 * 给模型看的前缀提示，例如「jita=晨曦，ojita=宁静」。
 * 写进工具参数描述里，模型才知道前缀对应哪个服务器。
 */
export function describePrefixes(prefixes) {
  return (prefixes ?? []).map((p) => `${p.prefix}=${p.server}`).join('，');
}
