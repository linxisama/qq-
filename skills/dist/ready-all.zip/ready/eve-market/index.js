// EVE 晨曦市场查询技能（LLM 型）。
//
// 群友问「jita 阿贝拉」这类问题时，输出报价卡片：
//
//   @吉他 阿贝拉 SW-900-I
//   -出售：50,000,000.00 ISK(7)
//   -收购：22,040,000.00 ISK(20)
//   -中间：36,020,000.00 ISK
//   ----------------
//   服务器：晨曦
//
// 三个工具（注册 id 会被宿主加上技能前缀，模型看到的是 eve-market__xxx）：
//   eve-market__market_quote   主入口：物品名 → 出售/收购/中间价
//   eve-market__market_book    看盘口明细（前 5 档买卖单 + 空间站）
//   eve-market__market_search  名字对不上时先搜物品 ID
//
// 设计取舍：
//   · 报价**默认由工具直接发出**（autoSend）。报价是一段格式固定的播报，
//     让模型转述只会引入幻觉（数字抄错一位、少个千分位），所以文本由代码生成、
//     由代码发出；模型只负责判断"该不该报"和挑对物品名。
//   · 不发图：报价本身用文字就够了。这个技能**不做任何画图**——
//     装字库、渲染 PNG、派生子进程、清理临时图片，对"报个价"来说都是多余开销。
//     （曾经做过价格走势图，包括从盘口差分还原成交流水的方案，后来按要求整个删掉了。
//      如果哪天想加回来，git 历史或 eve-market-skill.zip 的早期版本里有完整实现。）

/**
 * 用一个**稳定的**查询串导入库文件，让"改了库内容"能真正生效。
 *
 * 为什么需要这一层：Node 的 ESM 按 **URL** 缓存模块，而技能重载只是给
 * **入口**加时间戳重新 import（loader 里是 `import(`${entryUrl}?t=${Date.now()}`)`）。
 * 入口里静态 `import './lib-vX/ceve.js'` 的 URL 永远不会变 —— 于是改了库内容、
 * 只点「刷新」，拿到的还是进程里那份老模块，报
 *   `does not provide an export named ...`
 * （这个坑在本项目里踩过四次，前三次靠把目录名从 lib → lib-v2 → v3 → v4 硬扛）。
 *
 * 这里的做法：查询串用**文件自己的 mtime**。内容没变 → URL 不变 → 照常命中缓存；
 * 内容一变 → mtime 变 → URL 变 → 自动加载新版。不用再手工升目录名。
 *
 * 拿不到 mtime 时（权限、沙箱）回退成普通静态导入：行为退化回"需要手工升版本"，
 * 但不会让技能加载失败。
 */
let loadLib;
try {
  const { statSync } = await import('node:fs');
  const { fileURLToPath } = await import('node:url');
  loadLib = async (relative) => {
    const url = new URL(relative, import.meta.url);
    const stamp = statSync(fileURLToPath(url)).mtimeMs;
    return import(`${url.href}?mtime=${stamp}`);
  };
} catch {
  loadLib = async (relative) => import(relative);
}

const ceve = await loadLib('./lib-v4/ceve.js');
const triggers = await loadLib('./lib-v4/triggers.js');
const {
  searchItems, quicklook, marketStat, summarize,
  resolveLocation, resolveServer, formatIsk, DEFAULT_SERVER, REGION_FORGE
} = ceve;
const { buildPrefixes, matchPrefix, describePrefixes, FALLBACK_HUB } = triggers;

let api = null;
let cfg = () => ({});
let fetcher = null;

/**
 * 合并窗口。
 *
 * 线上真实案例（这次改动的由来）：群友问「月矿呢」，模型一件一件地问，最后群里
 * 刷了 **18 条**卡片（跨 11 轮）；问「7种基础矿」刷了 7 条。核心是一轮里
 * `for (const call of toolCalls) await executeTool(...)` 串行调用本工具，
 * 每次调用各发一条 —— 所以必须在插件内部把同一批查询攒成一条。
 *
 * 关键事实：模型**不是**一次把 7 个调用丢过来，而是拆成多轮（每轮一次工具调用，
 * 轮与轮之间隔着一次模型请求）。所以窗口必须**跨轮**才有意义 —— 用 400ms 那种
 * 短窗口等于没合并。实测把 IDLE 设成 2.2s 时，7 件仍然发了 7 条。
 *
 * 两条规则（不是"固定时长"，而是"看起来还没问完就继续等"）：
 *   · IDLE（5s）：最后一次查询之后再静默这么久就发。模型两轮之间通常 2~4s
 *     （一次模型请求 + 一次工具执行），5s 能把这些轮收进同一批；
 *     单件查询也就多等这几秒，属于聊天机器人可接受的量级。
 *   · BUDGET（20s）：从第一件算起最多攒这么久。防止模型"边想边查"几十秒时
 *     群友一直等不到回复 —— 到点先把已有的发出去，剩下的重新攒。
 *     这也给刷屏设了上界：最密也不过每 20 秒一条。
 *     且 BUDGET 会被强制取成 ≥ IDLE（见 mergeBudgetMs），否则预算先到点、
 *     静默窗口永远等不到，用户在设置里调 IDLE 会感觉"完全没用"。
 *
 * 兜底不止定时器：
 *   · 开新一轮（before-context）时，**已过期**的草稿一定发出去，消息不会永久卡住；
 *   · 技能被停用/卸载时也会放掉（见文件尾的 deactivate / dispose）。
 */
const MERGE_IDLE_MS = 5000;
const MERGE_BUDGET_MS = 20000;

/**
 * 这两个窗口**已从设置里移除**（设置页精简掉了，实测没人会调它们）。
 *
 * 保留读取 `cfg()` 的能力是为了兼容老配置文件里残留的键 —— 读得到就沿用，
 * 读不到就用上面的常量。这样升级不会让老用户的既有调参突然失效。
 */
function mergeIdleMs() {
  const n = Number(cfg().mergeIdleMs);
  return Number.isFinite(n) && n >= 0 ? Math.min(60000, n) : MERGE_IDLE_MS;
}

/**
 * 一批最多攒多久。
 *
 * ⚠️ 必须兜住的边界：预算若**短于**静默窗口，预算会先到点、静默窗口永远等不到，
 * 用户会以为"调了静默时间完全没用"。所以预算至少不低于静默窗口。
 */
function mergeBudgetMs() {
  const n = Number(cfg().mergeBudgetMs);
  const configured = Number.isFinite(n) && n >= 1000 ? Math.min(300000, n) : MERGE_BUDGET_MS;
  return Math.max(configured, mergeIdleMs());
}
const BATCH_MAX_ITEMS = 40;      // 合并后的卡片最多列这么多件，兜住极端刷屏

/** sessionId/chatKey → { chatKey, serverLabel, sections, count, timer, startedAt, … } */
const batches = new Map();

/**
 * 本轮问价的人（sessionId/chatKey → { userId, name }）。
 *
 * 为什么走 `before-context` 钩子而不是直接读全局聊天存档：存档里最后一条消息
 * 未必是触发本轮的那条（群里可能已经又聊了两句），而触发批 triggerEntries
 * 正是"把机器人叫起来的那几条"，挂在这里最准。
 * 卡片要把 @ 打给提问的人，而不是 @ 地点或 @ 全场，所以这层归属必须有。
 */
const askers = new Map();
const ASKER_CACHE_MAX = 100;

/**
 * 会话键。**两套上下文的字段名不一样，必须都认**：
 *   钩子（before-context）给的是 `ctx.sessionId`（顶层字符串）
 *   工具（execute）拿到的是 `ctx.session.id`（对象里的字段）
 * 早先只读 sessionId，于是钩子存进 's1'、工具去查 'group:xxx'，永远查不到 ——
 * 表现就是"@ 目标为空"这种静默失效。
 */
function askerKey(ctx = {}) {
  return String(ctx.sessionId || ctx.session?.id || ctx.chatKey || '');
}

function noteAsker(ctx = {}) {
  try {
    const entries = Array.isArray(ctx.triggerEntries) ? ctx.triggerEntries : [];
    let picked = null;
    // 倒序取最后一条"人说的"消息：一轮里可能有好几条，回的是最新的那个
    for (let i = entries.length - 1; i >= 0; i--) {
      const e = entries[i];
      if (!e || e.self || e.isPoke) continue;
      const userId = String(e.senderId ?? '').trim();
      if (!userId || userId === 'self' || userId === '0') continue;
      picked = { userId, name: String(e.senderName ?? '').trim() };
      break;
    }
    if (!picked) return;
    const key = askerKey(ctx);
    if (!key) return;
    askers.set(key, picked);
    if (askers.size > ASKER_CACHE_MAX) {
      askers.delete(askers.keys().next().value);
    }
  } catch { /* 记不下只是这次 @ 不到人，不该影响查询 */ }
}

/** 取本轮提问的人；钩子没覆盖到就退回"存档里最后一条别人说的话"。 */
function currentAsker(ctx = {}) {
  const fromHook = askers.get(askerKey(ctx));
  if (fromHook?.userId) return fromHook;
  try {
    const chatKey = ctx.chatKey;
    const recent = chatKey ? (ctx.store?.peekUnread?.(chatKey, 5) ?? []) : [];
    for (let i = recent.length - 1; i >= 0; i--) {
      const e = recent[i];
      if (!e || e.self) continue;
      const userId = String(e.senderId ?? '').trim();
      if (userId && userId !== 'self') return { userId, name: String(e.senderName ?? '').trim() };
    }
  } catch { /* 拿不到就算了 */ }
  return null;
}

export const hooks = {
  /**
   * 开新一轮前：先记下"谁问的"，再把**已经过期**的草稿放出去。
   *
   * 这里只放"过期"的（静默超过 IDLE），不是无脑全放 —— 模型拆成多轮一件件问时
   * （「月矿呢」就是这种），每一轮都会走到这个钩子；如果每轮都 flush，就回到
   * 一次一条的刷屏老路了。合并窗口要跨轮攒，靠的是时间判据而不是轮次边界。
   *
   * 顺序也不能反：残留批次要用**它自己那轮**的提问者来 @，而不是新这轮的。
   */
  'before-context': (ctx) => {
    flushStale('turn-boundary').catch(() => {});
    noteAsker(ctx);
  }
};

/** 把某个物品并进本会话的草稿。 */
function enqueueQuote(batchKey, ctx, { chatKey, serverLabel, locationLabel, items }) {
  let batch = batches.get(batchKey);
  if (!batch) {
    batch = {
      chatKey,
      serverLabel,
      sections: new Map(),
      count: 0,
      timer: null,
      session: ctx.session,
      sender: ctx.sender,
      emit: ctx.emit,
      // 提问者与序号都**在入队时定下来**：
      //   · 提问者：flush 时上下文可能已经换轮/换会话，那时再查就查不到了
      //     （尤其"钩子没跑到、靠存档兜底"的路径）。
      //   · 序号：核心是 `for (const call of toolCalls) await executeTool(...)` ——
      //     同一批工具调用**串行**执行，所以入队顺序就是模型的调用顺序，
      //     也就是群友的提问顺序。并发跑测试时这个顺序会退化，卡片顺序随之不稳，
      //     但生产路径是稳定的。
      asker: null,
      seq: 0,
      startedAt: Date.now()
    };
    batches.set(batchKey, batch);
  }
  if (!batch.asker) {
    const asker = currentAsker(ctx);
    if (asker?.userId) batch.asker = asker;
  }
  const order = batch.seq++;

  // 同一件物品在一轮里被问了两遍 → 后者覆盖前者，不重复列
  for (const it of items) {
    batch.sections.set(String(it.typeId), {
      // 再兜一道：卡片是要发到群里的，名字绝不能是 undefined
      typeName: displayName(it.typeName, it.typeId),
      locationLabel,
      quote: it.quote,
      order
    });
  }
  batch.count += 1;
  batch.lastAt = Date.now();
  batch.serverLabel = serverLabel || batch.serverLabel;
  if (!batch.chatKey) batch.chatKey = chatKey;
  // 发送三件套以最新一次调用为准（同一轮里它们是同一个会话对象）
  if (ctx.session) batch.session = ctx.session;
  if (ctx.sender) batch.sender = ctx.sender;
  if (ctx.emit) batch.emit = ctx.emit;

  if (batch.timer) clearTimeout(batch.timer);
  scheduleFlush(batchKey, batch);
  return batch.sections.size;
}

/**
 * 安排发送：取"静默 1.5s 后发"和"最迟从第一件算起 12s"里更早的那个。
 * 每次有新查询进来都重排一次 —— 这就是"还在问就继续等"的实现。
 */
function scheduleFlush(batchKey, batch) {
  const now = Date.now();
  const idleAt = now + mergeIdleMs();
  const budgetAt = batch.startedAt + mergeBudgetMs();
  const wait = Math.max(80, Math.min(idleAt, budgetAt) - now);
  batch.timer = setTimeout(() => { flushBatch(batchKey, 'timer').catch(() => {}); }, wait);
}

/**
 * 物品名兜底显示。
 *
 * 线上事故：某次调用没解析出物品名（`typeName` 为空），卡片文本里就出现了
 * 字面量 "undefined 在吉他（晨曦）..."。任何要进消息的字符串都必须经过它，
 * 宁可不写名字，也不能把 undefined 甩给群友。
 */
function displayName(...candidates) {
  for (const c of candidates) {
    const s = String(c ?? '').trim();
    if (s && s !== 'undefined' && s !== 'null') return s;
  }
  return '该物品';
}

/** 把草稿发成一条消息（一轮一条）。 */

async function flushBatch(key, reason = 'manual') {
  const batch = batches.get(key);
  if (!batch) return { sent: false, reason: 'no-batch' };
  if (batch.timer) { clearTimeout(batch.timer); batch.timer = null; }
  batches.delete(key);
  if (!batch.sections.size) return { sent: false, reason: 'empty' };

  const asker = batch.asker ?? null;
  const chatKey = batch.chatKey;
  if (!chatKey) return { sent: false, reason: 'no-chat' };

  // 按入队序号排：并发查询的返回顺序不定，但卡片顺序要是提问顺序
  const entries = [...batch.sections.values()]
    .sort((a, b) => (a.order - b.order))
    .slice(0, BATCH_MAX_ITEMS);
  const omitted = Math.max(0, batch.sections.size - entries.length);

  // 按地点分组：一轮里可能既查了吉他、又查了艾玛，标出来才分得清
  const groups = [];
  for (const entry of entries) {
    const label = String(entry.locationLabel ?? '').trim();
    let group = groups.find((g) => g.locationLabel === label);
    if (!group) { group = { locationLabel: label, entries: [] }; groups.push(group); }
    group.entries.push(entry);
  }

  const text = buildQuoteText({
    sections: groups,
    server: { label: batch.serverLabel || '晨曦' },
    multi: entries.length > 1
  });
  if (omitted) {
    api?.log?.(`合并卡片超过 ${BATCH_MAX_ITEMS} 件，另有 ${omitted} 件未列出`);
  }

  // 上下文在 flush 时可能已经换轮/换会话，所以 chatKey 用发起时记下的那个
  const sender = batch.sender;
  if (!sender) return { sent: false, reason: 'no-sender' };

  await sender.sendTextBatch(chatKey, [text], asker?.userId ? { atUserId: asker.userId } : {});
  batch.session?.sent?.push({
    type: 'text',
    text: asker?.userId ? `[@${asker.name || asker.userId}] ${text}` : text
  });
  batch.emit?.('session-update', batch.session?.id);
  api?.log?.(`报价合并发出（${reason}）：${entries.length} 件 / 消息 ${text.length} 字`);
  return { sent: true, count: entries.length, omitted, merged: batch.count };
}

/** 兜底：把所有会话的草稿都发出去（技能停用/卸载、显式调用时）。 */
async function flushAllPending(reason) {
  const keys = [...batches.keys()];
  for (const key of keys) {
    try { await flushBatch(key, reason); } catch { /* 单条失败不影响其它 */ }
  }
}

/**
 * 只放"已经静默够久"的草稿（开新一轮时的兜底）。
 * 判据与定时器一致：静默超过 IDLE，或已经攒到 BUDGET 上限。
 */
async function flushStale(reason) {
  const now = Date.now();
  for (const [key, batch] of [...batches.entries()]) {
    const quietFor = now - (batch.lastAt ?? batch.startedAt ?? now);
    const aged = now - (batch.startedAt ?? now);
    if (quietFor >= mergeIdleMs() || aged >= mergeBudgetMs()) {
      try { await flushBatch(key, reason); } catch { /* 单条失败不影响其它 */ }
    }
  }
}

/** 给测试与外部调用：立刻合并发出。 */
export async function flushQuotes() {
  await flushAllPending('explicit');
  return batches.size === 0;
}

export function setup(skillApi) {
  api = skillApi;
  cfg = skillApi.config;
  fetcher = (...args) => skillApi.fetch(...args);
  api.log('EVE 市场技能已加载（ceve-market.org / 晨曦）');

  skillApi.registerTool({
    id: 'market_quote',
    name: 'EVE市场报价',
    description: [
      '查询 EVE 国服（晨曦服务器）某物品在吉他等贸易 hub 的实时市场价，并把报价卡片发到群里。',
      '触发场景：群友问「jita 阿贝拉」「XX 多少钱」「XX 什么价」「吉他 XX 价格」「帮我查下 XX 市场」等。',
      '参数 item 只填物品名本身（如「阿贝拉」「三钛合金」「地狱天使级」），把 jita/吉他/晨曦/多少钱 这类词剥掉；地点写进 location。',
      '名称与物品完全一致时只报这一个；否则（如「胡蜂」对「胡蜂 I / 胡蜂 II / 集成型胡蜂」）会把所有相关物品一次全报，无需你再逐个调用。',
      '查不到时如实说明，绝对不要凭记忆编造价格。',
      '⚠️ 不要自己复述价格、也不要自己 @ 人：工具已经把报价卡片 @ 给提问者发出去了，之后说一句简短的话即可（或直接结束）。'
    ].join(''),
    category: 'query',
    icon: '📈',
    parameters: {
      type: 'object',
      properties: {
        item: { type: 'string', description: '物品名称，如「阿贝拉」（可带型号后缀，如「阿贝拉 SW-900-I」）；也可以直接给物品 ID' },
        location: { type: 'string', description: "贸易 hub：'jita'（吉他，默认）/ 'amarr'（艾玛）/ 'dodixie' / 'rens' / 'hek'，或直接给星系 ID" },
        server: {
          type: 'string',
          description: [
            "服务器：'shenchen'（晨曦，默认）/ 'inf'（曙光）/ 'tq'（宁静）。",
            '群友用指令前缀指服务器时（如「ojita 三钛合金」），把前缀对应的服务器填到这里，并把前缀从 item 里去掉。',
            prefixHint()
          ].filter(Boolean).join('')
        }
      },
      required: ['item']
    },
    async execute(ctx, args) {
      try {
        const rawItem = String(args?.item ?? '').trim();
        if (!rawItem) return err('没给物品名。请把群友说的物品名传给 item。');

        // 指令前缀（jita/ojita/sjita…）在这里被认成服务器+地点，并从物品名里剥掉
        const { server, item: query, location } = resolveQuery(rawItem, args?.server, args?.location);

        const resolved = await resolveItem(query, { server: server.key });
        if (resolved.error) return err(resolved.error);

        // 逐个取价。命中多件时全部取（并发），单件时就是一次请求。
        const entries = await Promise.all(resolved.items.map(async (item) => {
          try {
            const orders = await fetchOrders(item.typeId, location, server.key);
            const quote = summarize(orders, { systemName: location.systemName ?? '' });
            return { ...item, quote, empty: !quote.sell && !quote.buy };
          } catch (error) {
            return { ...item, quote: null, empty: false, error: String(error?.message ?? error) };
          }
        }));

        const usable = entries.filter((e) => e.quote);
        const quoted = usable.filter((e) => !e.empty);
        const emptyNames = usable.filter((e) => e.empty).map((e) => displayName(e.typeName, e.typeId));
        const failed = entries.filter((e) => !e.quote);
        // 物品名可能因搜索异常而缺失，任何进消息的字符串都要过 displayName
        const subject = displayName(resolved.typeName, resolved.items?.[0]?.typeName, query);

        if (!quoted.length) {
          // ⚠️ 这里**绝不自动发消息**。
          //
          // 线上事故（2026-09-30）：这个分支早先把 note 直接发到了群里，而 note 是
          // 写给模型看的说明，于是群里出现了一条
          //   「undefined 在吉他（晨曦）当前没有任何挂单。如实告诉群友"…"，可以顺带
          //     说一句换个 hub 试试；不要编造价格。」
          // —— 模型把"给它的指示"当成消息发出去了，而且物品名是 undefined。
          // 教训：工具返回里凡是"对模型的指示"，都可能被模型当内容转发；这类文案
          // 一旦被自动发出，就是误发。所以只把**结论**给模型，由它自己组织人话。
          return ok({
            found: false,
            sent: false,
            typeName: subject,
            location: location.label,
            server: server.label,
            emptyNames,
            failed: failed.map((f) => ({ typeName: displayName(f.typeName, f.typeId), error: f.error })),
            note: `${subject} 在${location.label}（${server.label}）没有挂单。`
              + '请用一句人话告诉群友（例如"这个地点现在没货，换个 hub 试试"）—— 群友在等你回话，'
              + '但不要把这段说明原文复制出去，也不要编造价格。'
          });
        }

        // 无挂单的物品也并进卡片（如实写「无挂单」），而不是单独发一句说明 ——
        // 这样"哪几件没货"由卡片自己承载，不用模型转述，也就没有转述出错的机会。
        const emptyItems = usable.filter((e) => e.empty).map((e) => ({
          typeId: e.typeId,
          typeName: displayName(e.typeName, e.typeId),
          quote: { sell: null, buy: null, mid: null },
          empty: true
        }));
        const items = [
          ...quoted.map((e) => ({ typeId: e.typeId, typeName: displayName(e.typeName, e.typeId), quote: e.quote })),
          ...emptyItems
        ];
        const text = buildQuoteText({
          entries: items,
          location,
          server,
          multi: resolved.multi
        });

        // @ 提问的人（而不是 @ 地点）。atUserId 是**协议级** @ ——
        // 消息段里带一个 at 段，对方真会被提醒到；纯文本写个 "@某人" 不会有这个效果。
        const asker = currentAsker(ctx);
        const mention = asker?.userId ?? null;

        // 不立刻发：先并入本会话草稿，短窗口内的多次查询会合并成**一条**消息。
        // 模型一轮里连查几件（皮特姆多谱 A型、B型…）时，群里只多一条卡片而不是 N 条。
        const autoSend = cfg().autoSend !== false;
        const batchKey = askerKey(ctx);
        let queued = 0;
        let sent = false;
        if (autoSend) {
          queued = enqueueQuote(batchKey, ctx, {
            chatKey: ctx.chatKey,
            serverLabel: server.label,
            locationLabel: location.label,
            items
          });
          sent = true;   // 语义上"已安排发出"，避免模型自己再补一条
        }

        const note = [
          sent
            ? [
              '报价卡片已交给插件发出（同一轮的多次查询会自动合并成一条，不要重复发）。',
              '不要再重复价格，说一句简短的话或直接结束即可。'
            ].join('')
            : [
              '报价文本见 reply 字段，请原样发送（数字与千分位不要改动）。',
              mention ? `发送时请 @ 提问的人：tools 的 send_message 传 atUserId=${mention}。` : ''
            ].filter(Boolean).join(''),
          emptyNames.length ? `（${emptyNames.join('、')} 在当地无挂单，卡片里已经写成「无挂单」，不要替它们编价格。）` : '',
          resolved.truncated ? `（匹配到的物品超过上限，只报前 ${quoted.length} 个。）` : '',
          failed.length ? `（${failed.length} 个物品取价失败、没进卡片，不要把技术错误发到群里。）` : ''
        ].filter(Boolean).join('');

        return ok({
          reply: text,
          sent,
          mergedInto: queued,
          asker: asker ? { userId: asker.userId, name: asker.name || null } : null,
          reported: quoted.length,
          items: quoted.map((e) => ({
            typeId: e.typeId,
            typeName: displayName(e.typeName, e.typeId),
            sell: e.quote.sell,
            buy: e.quote.buy,
            mid: e.quote.mid
          })),
          noOrders: emptyItems.map((e) => e.typeName),
          location: location.label,
          server: server.label,
          alternates: resolved.alternates ?? [],
          note
        });
      } catch (error) {
        return err(`市场查询失败：${error?.message ?? error}`);
      }
    }
  });

  skillApi.registerTool({
    id: 'market_book',
    name: 'EVE市场盘口',
    description: '查看某物品在指定贸易 hub 的前 5 档买单/卖单明细（价格、数量、空间站）。群友想看盘口深度、问「挂单什么情况」「买一卖一多少」时用。',
    category: 'query',
    icon: '📊',
    parameters: {
      type: 'object',
      properties: {
        item: { type: 'string', description: '物品名称或物品 ID' },
        location: { type: 'string', description: "'jita'（默认）/ 'amarr' / 'dodixie' / 'rens' / 'hek'" },
        server: {
          type: 'string',
          description: [
            "'shenchen'（晨曦，默认）/ 'inf'（曙光）/ 'tq'（宁静）。",
            '群友用指令前缀指服务器时（如「ojita 三钛合金」），把前缀对应的服务器填到这里，并把前缀从 item 里去掉。',
            prefixHint()
          ].filter(Boolean).join('')
        },
        region: { type: 'boolean', description: 'true = 看整个星域（伏尔戈）的汇总统计，而不是单星系挂单' }
      },
      required: ['item']
    },
    async execute(_ctx, args) {
      try {
        const rawItem = String(args?.item ?? '').trim();
        if (!rawItem) return err('没给物品名。');
        const { server, item: query, location } = resolveQuery(rawItem, args?.server, args?.location);
        // 盘口是"细看某一个物品"，命中多件时只取最匹配的那个 ——
        // 想一次看一族用 eve-market__market_quote。
        const resolved = await resolveItem(query, { server: server.key });
        if (resolved.error) return err(resolved.error);
        const target = resolved.items[0];

        if (args?.region === true) {
          // ⚠️ 星域必须跟着 location 走。早先这里硬编码 10000002（伏尔戈），
          // 于是「艾玛 + region:true」拿到的是吉他的星域数据，而且返回里
          // scope 也写死「伏尔戈星域（含吉他）」，看起来完全正常 —— 静默错误。
          const regionId = location.regionId ?? REGION_FORGE;
          const regionLabel = location.regionId ? `${location.label}所在星域` : '伏尔戈星域（含吉他）';
          const stat = await marketStat(fetcher, target.typeId, { server: server.key, regionId });
          return ok({
            typeId: target.typeId,
            typeName: target.typeName,
            scope: regionLabel,
            regionId,
            stat,
            note: '用一两句话概括即可，别把整张表贴出去。'
          });
        }

        const orders = await fetchOrders(target.typeId, location, server.key);
        const quote = summarize(orders, { systemName: location.systemName ?? '' });
        return ok({
          typeId: target.typeId,
          typeName: target.typeName,
          location: location.label,
          server: server.label,
          sellTop: quote.sellTop,
          buyTop: quote.buyTop,
          sellVolume: quote.sellVolume,
          buyVolume: quote.buyVolume,
          sellOrders: quote.sellOrders,
          buyOrders: quote.buyOrders,
          others: resolved.items.length > 1 ? resolved.items.slice(1).map((i) => i.typeName) : [],
          note: '用文字简报前几档即可，不要把整张表贴出去。'
        });
      } catch (error) {
        return err(`盘口查询失败：${error?.message ?? error}`);
      }
    }
  });

  skillApi.registerTool({
    id: 'market_search',
    name: 'EVE物品搜索',
    description: '按名称模糊搜索 EVE 物品，返回候选物品 ID。群友说的名字查不到、或有多个同名/近名物品时用。',
    category: 'query',
    icon: '🔎',
    parameters: {
      type: 'object',
      properties: {
        name: { type: 'string', description: '物品名关键词' },
        server: {
          type: 'string',
          description: [
            "'shenchen'（晨曦，默认）/ 'inf'（曙光）/ 'tq'（宁静）。",
            '群友用指令前缀指服务器时（如「ojita 三钛合金」），把前缀对应的服务器填到这里，并把前缀从 name 里去掉。',
            prefixHint()
          ].filter(Boolean).join('')
        }
      },
      required: ['name']
    },
    async execute(_ctx, args) {
      try {
        const rawName = String(args?.name ?? '').trim();
        if (!rawName) return err('没给关键词。');
        const { server, item: name } = resolveQuery(rawName, args?.server, args?.location);
        const items = await searchItems(fetcher, name, { server: server.key });
        return ok({
          count: items.length,
          items: items.slice(0, 20),
          note: items.length
            ? '挑最匹配的那个，再用 eve-market__market_quote 按名称或 ID 查价。'
            : '没搜到，换个关键词（中文全名或英文名）再试。'
        });
      } catch (error) {
        return err(`物品搜索失败：${error?.message ?? error}`);
      }
    }
  });
}

// ── 内部实现 ──────────────────────────────────────────────────────────────

function fetchOrders(typeId, location, serverKey) {
  return quicklook(fetcher, typeId, {
    server: serverKey,
    systemId: location.systemId,
    regionId: location.systemId ? undefined : 10000002
  });
}

/**
 * 名称 → 物品列表。
 *
 * 命中多件时**全部返回**：群友说「胡蜂」多半想看的是这一族（胡蜂 I / II /
 * 集成型 / 加强型 / 蓝图…），只回一个最像的会逼着他再问一遍，而另一个机器人
 * 一次给全 —— 对比之下就显得"不全"。
 *
 * 但只有**全名**才触发"全报"：说「阿贝拉 SW-900-I」就只报这一件，
 * 不要因为搜索接口还返回了别的阿贝拉把无关的东西也刷出去。
 */
async function resolveItem(query, { server }) {
  if (/^\d+$/.test(query)) {
    const typeId = Number(query);
    const orders = await quicklook(fetcher, typeId, { server }).catch(() => null);
    return { items: [{ typeId, typeName: orders?.typeName || `物品 ${typeId}` }], multi: false };
  }

  const found = await searchItems(fetcher, query, { server });
  if (!found.length) {
    return {
      error: `没搜到「${query}」。`
        + '请用一句人话回群友（例如"这个名字没查到，换个说法或直接给物品 ID"）—— 群友在等你回话，'
        + '但不要把这句提示原文复制出去，也不要凭记忆编造价格。'
    };
  }

  const ranked = rankMatches(found, query);
  const best = ranked[0];
  if (best.score === 0) {
    // 全名精确命中 → 只报这一件（其余同族留给群友自己问）
    return { items: [{ typeId: best.typeId, typeName: best.typeName }], multi: false, alternates: ranked.slice(1, 5).map((s) => s.typeName) };
  }

  // 只保留"确实相关"的：前缀命中或整体包含。搜索接口会顺带返回一堆
  // 只是碰巧含有这几个字的蓝图/涂装（如搜「胡蜂」带出「胡蜂EC-900蓝图」），
  // 那些塞进卡片只是噪音。
  const related = ranked.filter((s) => s.score <= 2);
  // 上限**已从设置里移除**（精简设置页时去掉的）：8 是实测下来够用又不刷屏的值。
  // 仍读 cfg() 是为了兼容老配置里残留的键。
  const cap = Math.max(1, Math.min(20, Number(cfg().maxItemsPerQuery) || 8));
  const picked = related.slice(0, cap);
  return {
    items: picked.map((s) => ({ typeId: s.typeId, typeName: s.typeName })),
    multi: picked.length > 1,
    truncated: related.length > picked.length,
    alternates: related.slice(cap, cap + 4).map((s) => s.typeName)
  };
}

/**
 * 名字匹配排序：完全一致(0) > 前缀(1) > 包含(2) > 其它(3)；
 * 同一档内按**名称字典序** —— 这样「胡蜂 I / 胡蜂 II / 胡蜂蓝图 I / 胡蜂EC-900」
 * 会按大家习惯的顺序挨着排，而不是按名字长短把 I、II 拆散到列表两端。
 */
export function rankMatches(items, query) {
  const norm = (s) => String(s).toLowerCase().replace(/\s+/g, ' ').trim();
  const q = norm(query);
  return items.map((it) => {
    const name = norm(it.typeName);
    let score = 3;
    if (name === q) score = 0;
    else if (name.startsWith(q)) score = 1;
    else if (name.includes(q)) score = 2;
    return { ...it, score, name };
  }).sort((a, b) => (a.score - b.score)
    || a.name.localeCompare(b.name, 'zh-Hans-CN')
    || (a.typeId - b.typeId));
}

/** 兼容旧调用：只取最匹配的一个。 */
export function pickBestMatch(items, query) {
  const ranked = rankMatches(items, query);
  const best = ranked[0];
  return {
    typeId: best.typeId,
    typeName: best.typeName,
    alternates: ranked.slice(1, 5).map((s) => s.typeName)
  };
}

/** 单件的四行报价。 */
function quoteLines(quote) {
  const sell = quote.sell;
  const buy = quote.buy;
  const mid = quote.mid;
  return [
    `-出售：${sell ? `${formatIsk(sell.price)} ISK(${sell.volume})` : '无挂单'}`,
    `-收购：${buy ? `${formatIsk(buy.price)} ISK(${buy.volume})` : '无挂单'}`,
    `-中间：${mid === null || mid === undefined ? '—' : `${formatIsk(mid)} ISK`}`
  ];
}

/**
 * 报价文本。
 *
 * 卡片里**不写 @**：@ 由发送层以协议 @ 段的形式加在消息开头（见 flushBatch 里
 * 传的 atUserId），这样提醒的是**提问的人**，而不是文本里一个没有提醒效果的假 @。
 *
 * 结构：
 *   单地点：[地点]（可选表头）/ 物品名 + 三行价 / … / 分隔线 / 服务器
 *   多地点：每组前标 [地点]，便于分辨哪几行是哪个 hub 的
 *
 * 物品名顶格、价格缩进两格 —— 缩进比横线更能看出"这几行属于上一件"。
 * 价格一律两位小数。
 */
export function buildQuoteText({ sections, entries, quote, location, server, typeName, multi }) {
  const groups = Array.isArray(sections) && sections.length
    ? sections
    : [{
      // 兼容旧形态调用（单组、整批一个地点）
      locationLabel: location?.label ?? '',
      entries: entries ?? [{ typeName, quote }]
    }];
  const all = groups.flatMap((g) => g.entries ?? []);
  const total = all.length;
  const locations = [...new Set(groups.map((g) => String(g.locationLabel ?? '').trim()).filter(Boolean))];
  const singleLocation = locations.length === 1 ? locations[0] : '';
  const showGroupLabel = groups.length > 1 && !singleLocation;
  const lines = [];

  if (total === 1 && groups[0].entries.length === 1 && multi !== true) {
    // 最简形态：一件物品、没说多地点 → 不夹带任何多余行
    const only = groups[0].entries[0];
    if (singleLocation && groups.length > 1) lines.push(`[${singleLocation}]`);
    lines.push(only.typeName);
    lines.push(...quoteLines(only.quote));
  } else {
    if (singleLocation) lines.push(`[${singleLocation}]`);
    for (const group of groups) {
      const label = showGroupLabel ? String(group.locationLabel ?? '').trim() : '';
      if (label) lines.push(`[${label}]`);
      for (const entry of group.entries ?? []) {
        lines.push(entry.typeName);
        for (const line of quoteLines(entry.quote)) lines.push(`  ${line}`);
      }
    }
  }

  lines.push('----------------');
  lines.push(`服务器：${server.label}`);

  // 卡片尾部：配置里填什么就追加什么，留空则不加任何尾行。
  // 早先是个布尔开关（固定三行小程序推广 + 来源声明），换成文本框后自由度更大 ——
  // 想写群号、想写自己的小程序、想留空都由填的人决定。
  const tail = normalizeTail(cfg().quoteContent);
  if (tail) lines.push(...tail);

  return lines.join('\n');
}

/**
 * 把配置里的"卡片尾部内容"整理成若干行。
 *
 * 文本框里直接回车换行最自然，但通过配置文件/接口写入时往往是转义的 `\n`
 * 两个字符 —— 两种都认，否则用户会看到字面量 `\n` 挂在卡片上。
 * 顺带去掉首尾空行与多余的行尾空格。
 */
export function normalizeTail(text) {
  const raw = String(text ?? '');
  if (!raw.trim()) return [];
  const lines = raw
    .replace(/\\r\\n|\\n|\\r/g, '\n')     // 转义的 \n → 真换行（配置里手写常见）
    .replace(/\r\n?/g, '\n')             // 真 CRLF → LF
    .split('\n')
    .map((line) => line.replace(/\s+$/, ''));
  // 去掉首尾空行（中间的空行保留，那是用户自己的排版）
  while (lines.length && !lines[0].trim()) lines.shift();
  while (lines.length && !lines[lines.length - 1].trim()) lines.pop();
  return lines;
}

function ok(payload) { return { content: JSON.stringify(payload, null, 1) }; }
function err(message) { return { content: String(message), isError: true }; }

/**
 * 解析出这次查询用哪个服务器、哪个地点、物品名是什么。
 *
 * 三个服务器用**各自的指令前缀**区分：
 *
 *     jita 三钛合金    → 国服的吉他
 *     ojita 三钛合金   → 欧服的吉他
 *     sjita 三钛合金   → 曙光服的吉他
 *
 * 地点三级回退：
 *   1. 工具参数 location（群友自己说了地点，最明确）
 *   2. 前缀里带出的地点（`ojita`→吉他、`oamarr`→艾玛）
 *   3. FALLBACK_HUB（吉他）—— 「国服」这种前缀不含地点信息时用它
 * 全局 defaultLocation 只在前两步都没走通时兜底（例如地点名认不出来）。
 *
 * 为什么第 3 步是**常量**而不是设置项：要求就是"三个服的默认地点都是吉他"，
 * 这是个固定约定。做成三个设置项只会让设置页更长，而它们几乎不会被改；
 * 真要给某个服换默认地点，往那个服的前缀里加带地点的词就行（`oamarr`）。
 *
 * 服务器优先级：工具参数 server > 指令前缀 > 默认服务器。
 */
function resolveQuery(rawItem, argServer, argLocation) {
  const conf = cfg();
  const prefixes = buildPrefixes(conf);
  const hit = matchPrefix(rawItem, prefixes);

  // 模型可能把**整个前缀**填进 server 参数（`ojita`），而不只是服务器名。
  // resolveServer 对认不出的输入会静默退回默认服务器 —— 那就是"查出来是别的服的
  // 价格、还不报错"。所以这里先拿用户配的前缀表兜一层。
  const byPrefix = argServer
    ? prefixes.find((p) => p.prefix === String(argServer).trim().toLowerCase())
    : null;

  const groupKey = byPrefix ? byPrefix.server : (hit ? hit.server : null);
  const server = groupKey
    ? resolveServer(groupKey)
    : (argServer ? resolveServer(argServer) : resolveServer(conf.defaultServer ?? DEFAULT_SERVER));

  const item = hit ? hit.rest : rawItem;

  const locationInput = argLocation
    ?? hit?.location
    ?? (groupKey ? FALLBACK_HUB : null)
    ?? conf.defaultLocation
    ?? FALLBACK_HUB;
  const location = resolveLocation(locationInput);

  return { server, item, location, prefix: hit?.prefix ?? '', prefixServer: hit?.server ?? '' };
}

/** 前缀提示串，写进工具参数描述里，模型才知道前缀对应哪个服务器。 */
function prefixHint() {
  const desc = describePrefixes(buildPrefixes(cfg()));
  return desc ? `本群用这些指令前缀区分服务器：${desc}` : '';
}

/**
 * 技能被停用/卸载时，把还没发出去的草稿放掉 —— 否则"刚查完就被关掉"会让
 * 群友永远等不到那张卡片（合并窗口只有几百毫秒，这种情况很少但确实存在）。
 */
export function deactivate() {
  flushAllPending('deactivate').catch(() => {});
}

export function dispose() {
  flushAllPending('dispose').catch(() => {});
}

export const __test__ = { resolveItem, rankMatches, pickBestMatch, buildQuoteText, flushQuotes };
