// 优选B站 —— LLM 型技能（skills/bili-picks）
// ---------------------------------------------------------------------------
// ① 挑片 / 读懂：bili_pick + bili_read（不需要登录，匿名接口）
// ② 专用账号：bili_login（扫码，二维码直接发到当前 QQ 会话）→ bili_me / bili_logout
// ③ 互动：bili_reply（B站评论下回复）/ bili_dm（私信主人）
// ④ 日记：bili_diary（写进 data/bili-picks/diary/YYYY-MM-DD.md）
// ⑤ 后台：bili_watch（把 B 站的 @ / 回复 / 私信 转发到 QQ）+ bili_cron（每天定点推精选/写日记）
//
// 约束：只用 api.fetch；发送消息只走 ctx.sender（与项目里 bili-account 一致）。
// ---------------------------------------------------------------------------

import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import { createRequire } from 'node:module'
import { fileURLToPath } from 'node:url'
// 热重载只给 index.js 加 ?t=…，静态 import 的 lib 会被 Node 缓存住（改了 lib 不生效）。
// 用同一个 t 动态 import，lib 就跟着 index 一起刷新 ✓（和 bili-account 一样的做法）
const BUST = new URL(import.meta.url).searchParams.get('t') || String(Date.now())
const B = await import(`./lib/bili.js?t=${encodeURIComponent(BUST)}`)
const M = await import(`./lib/media.js?t=${encodeURIComponent(BUST)}`)
const { loadState, saveState, appendDiary, recentDiary, readDiary, listDiary, paths } = await import(
  `./lib/store.js?t=${encodeURIComponent(BUST)}`
)

const require = createRequire(import.meta.url)
const HERE = path.dirname(fileURLToPath(import.meta.url))

let QR = null
function qrLib() {
  if (!QR) {
    try {
      QR = require(path.join(HERE, '..', 'bili-account', 'lib', 'qrcode.cjs'))
    } catch (e) {
      throw new Error('找不到二维码渲染库（bili-account/lib/qrcode.cjs）：' + (e?.message ?? e))
    }
  }
  return QR
}
function qrDataUrl(text) {
  const lib = qrLib()
  const qr = lib(0, 'M')
  qr.addData(String(text))
  qr.make()
  return qr.createDataURL(8, 32)
}

const LOG_TAG = '优选B站'
// B 站 CDN 会解析出一批 175.4.62.* 的节点，Node 常常先挑到它们然后连接失败
// （PowerShell/浏览器会自己换一个，Node 不会）。这里用 undici Agent + 自定义 lookup 跳过。
const BAD_IP_PREFIX = '175.4.62.'
let rawFetch = null
let agentPromise = null

async function biliAgent() {
  if (agentPromise) return agentPromise
  agentPromise = (async () => {
    try {
      const dns = await import('node:dns')
      const { Agent } = await import('undici')
      const lookup = (host, opts, cb) => {
        dns.default.lookup(host, { all: true }, (err, addrs) => {
          if (err) return cb(err)
          const list = addrs.map((a) => a.address)
          const good = list.filter((ip) => !ip.startsWith(BAD_IP_PREFIX))
          const ip = good[0] || list[0]
          const family = ip.includes(':') ? 6 : 4
          if (opts && opts.all) return cb(null, [{ address: ip, family }])
          cb(null, ip, family)
        })
      }
      return new Agent({ connect: { timeout: 20_000, lookup } })
    } catch (e) {
      log('undici 不可用，退回默认 fetch：' + (e?.message ?? e))
      return null
    }
  })()
  return agentPromise
}

/** 统一出口：能用 Agent 就用（跳过坏 IP），不行就退回普通 fetch */
async function httpFetch(url, init = {}) {
  const doFetch = rawFetch || globalThis.fetch
  const agent = await biliAgent()
  if (agent) {
    try {
      return await doFetch(url, { ...init, dispatcher: agent })
    } catch {
      // 落到普通 fetch 再试一次
    }
  }
  return doFetch(url, init)
}

const DEFAULTS = {
  like: '明日方舟,二次元,抽象,搞笑,纪录片,科技',
  dislike: '带货,擦边,标题党,纯搬运',
  count: 5,
  maxDanmaku: 120,
  maxComments: 8,
  cookie: '',
  ownerMid: '',
  ownerName: '',
  loginMode: 'qr',
  scheduleEnabled: false,
  scheduleStart: '12:00',
  scheduleEnd: '13:00',
  scheduleProbability: 0.7,
  scheduleChannel: 'qq',
  scheduleKind: 'pick',
  scheduleCount: 3,
  ffmpegPath: '',
  subtitleMaxChars: 6000,
  frameGrid: 3,
  diaryPush: true,
  extraSchedules: '',
}

let api = null
let cfg = () => ({})
let state = loadState()
const runtime = { sender: null, chatKey: '' }
const timers = []
let quiet = false

const log = (...a) => {
  if (quiet) return
  try {
    api?.log?.(`[${LOG_TAG}]`, ...a)
  } catch {}
}

const clamp = (n, lo, hi, d) => {
  const v = Number(n)
  return Number.isFinite(v) ? Math.min(hi, Math.max(lo, v)) : d
}
const listOf = (s) =>
  String(s ?? '')
    .split(/[,，、\s]+/)
    .map((x) => x.trim())
    .filter(Boolean)

function settings() {
  let c = {}
  try {
    c = (typeof cfg === 'function' ? cfg() : cfg) || {}
  } catch {
    c = {}
  }
  return {
    like: listOf(c.like ?? DEFAULTS.like),
    dislike: listOf(c.dislike ?? DEFAULTS.dislike),
    count: Math.round(clamp(c.count ?? DEFAULTS.count, 1, 10, 5)),
    maxDanmaku: Math.round(clamp(c.maxDanmaku ?? DEFAULTS.maxDanmaku, 20, 400, 120)),
    maxComments: Math.round(clamp(c.maxComments ?? DEFAULTS.maxComments, 0, 20, 8)),
    cookie: String(c.cookie ?? '').trim(),
    ownerMid: String(c.ownerMid ?? '').trim(),
    ownerName: String(c.ownerName ?? '').trim(),
    loginMode: String(c.loginMode ?? DEFAULTS.loginMode) === 'cookie' ? 'cookie' : 'qr',
    scheduleEnabled: c.scheduleEnabled === true,
    scheduleStart: String(c.scheduleStart ?? DEFAULTS.scheduleStart),
    scheduleEnd: String(c.scheduleEnd ?? DEFAULTS.scheduleEnd),
    scheduleProbability: Math.min(1, Math.max(0, Number(c.scheduleProbability ?? DEFAULTS.scheduleProbability))),
    scheduleChannel: ['qq', 'dm', 'comment'].includes(String(c.scheduleChannel)) ? String(c.scheduleChannel) : 'qq',
    scheduleKind: String(c.scheduleKind) === 'diary' ? 'diary' : 'pick',
    scheduleCount: Math.round(clamp(c.scheduleCount ?? DEFAULTS.scheduleCount, 1, 10, 3)),
    ffmpegPath: String(c.ffmpegPath ?? '').trim(),
    subtitleMaxChars: Math.round(clamp(c.subtitleMaxChars ?? DEFAULTS.subtitleMaxChars, 800, 20000, 6000)),
    frameGrid: Math.round(clamp(c.frameGrid ?? DEFAULTS.frameGrid, 2, 4, 3)),
    diaryPush: c.diaryPush !== false,
    extraSchedules: String(c.extraSchedules ?? '').trim(),
  }
}

/** 把设置里手填的 Cookie 解析成 session（形如 SESSDATA=..; bili_jct=..）*/
function cookieSession(raw) {
  const t = String(raw || '').trim()
  if (!t) return null
  const get = (k) => {
    const m = new RegExp(`(?:^|;\\s*)${k}=([^;]+)`).exec(t)
    return m ? m[1].trim() : ''
  }
  const sess = get('SESSDATA')
  if (!sess) return null
  return {
    sessdata: sess,
    bili_jct: get('bili_jct'),
    buvid3: get('buvid3'),
    dedeUserId: get('DedeUserID'),
    at: Date.now(),
  }
}

function session() {
  const saved = state.session && state.session.sessdata ? state.session : null
  const s = settings()
  if (s.loginMode === 'cookie') {
    const c = cookieSession(s.cookie)
    if (c) return c
  }
  return saved || cookieSession(s.cookie) || biliAccountSession()
}

/**
 * 兜底：项目里另一个技能 bili-account 已经扫码登录过时，直接借它的会话。
 * 这样用户只要在任一技能里扫过码，这边就能用（读失败就当没登录，不影响）。
 */
let extCache = { at: 0, sess: null }
function biliAccountSession() {
  const now = Date.now()
  if (now - extCache.at < 60_000) return extCache.sess
  let sess = null
  try {
    const p = path.join(path.dirname(paths.STORE_DIR), 'bili-account', 'session.json')
    const j = JSON.parse(fs.readFileSync(p, 'utf8'))
    const c = j.cookies || {}
    const sessdata = c.SESSDATA || c.sessdata || ''
    if (sessdata) {
      sess = {
        sessdata,
        bili_jct: c.bili_jct || j.bili_jct || '',
        buvid3: c.buvid3 || '',
        dedeUserId: String(c.DedeUserID || j.mid || ''),
        mid: String(j.mid || ''),
        uname: j.uname || '',
        at: Date.now(),
        from: 'bili-account',
      }
    }
  } catch {
    sess = null
  }
  extCache = { at: now, sess }
  return sess
}
function needLogin() {
  if (!session()) throw new Error('还没登录 B 站。先调用 bili_login 发二维码，用「机器人专用小号」扫码。')
  return session()
}

// ── 匿名挑片（原有）───────────────────────────────────────────────────────
const API = 'https://api.bilibili.com'

async function getJsonAnonymous(url, tries = 2) {
  const headers = { 'user-agent': B.UA, referer: B.REFERER, accept: 'application/json, text/plain, */*' }
  let last = null
  for (let i = 0; i < tries; i += 1) {
    try {
      const res = await api.fetch(url, { headers })
      const text = await res.text()
      let body
      try {
        body = JSON.parse(text)
      } catch {
        throw new Error(`HTTP ${res.status} 非 JSON：${text.slice(0, 80)}`)
      }
      if (body && body.code !== 0) throw new Error(B.codeText(body.code, body.message))
      return body.data ?? {}
    } catch (e) {
      last = e
      if (i + 1 < tries) await new Promise((r) => setTimeout(r, 400))
    }
  }
  throw last ?? new Error('请求失败')
}

const cleanText = (s) =>
  String(s ?? '')
    .replace(/<[^>]+>/g, '')
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/\s+/g, ' ')
    .trim()

function normalize(v, source) {
  if (!v) return null
  const bvid = v.bvid || v.bv_id
  if (!bvid) return null
  return {
    bvid,
    title: cleanText(v.title),
    owner: v.owner?.name ?? v.author ?? '',
    view: Number(v.stat?.view ?? v.play ?? 0) || 0,
    danmaku: Number(v.stat?.danmaku ?? v.video_review ?? v.danmaku ?? 0) || 0,
    duration: Number(v.duration ?? 0) || 0,
    desc: cleanText(v.desc ?? ''),
    tname: v.tname ?? '',
    source,
  }
}

const fmtDur = (sec) => {
  const s = Math.max(0, Math.round(sec))
  return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`
}
const fmtNum = (n) => (n >= 1e8 ? `${(n / 1e8).toFixed(1)}亿` : n >= 1e4 ? `${(n / 1e4).toFixed(1)}万` : String(n))

async function fetchPopular(errors = []) {
  try {
    const d = await getJsonAnonymous(`${API}/x/web-interface/popular?ps=30&pn=1`)
    return (d.list ?? []).map((x) => normalize(x, '热门')).filter(Boolean)
  } catch (e) {
    errors.push(`热门：${e?.message ?? e}`)
    return []
  }
}
async function fetchRanking(errors = []) {
  try {
    const d = await getJsonAnonymous(`${API}/x/web-interface/ranking/v2?rid=0&type=all`)
    return (d.list ?? []).map((x) => normalize(x, '排行')).filter(Boolean)
  } catch (e) {
    errors.push(`排行：${e?.message ?? e}`)
    // 全站排行挂了就退到动画区排行
    try {
      const d = await getJsonAnonymous(`${API}/x/web-interface/ranking/v2?rid=1&type=all`)
      return (d.list ?? []).map((x) => normalize(x, '排行·动画')).filter(Boolean)
    } catch (e2) {
      errors.push(`排行(动画区)：${e2?.message ?? e2}`)
      return []
    }
  }
}
async function fetchSearch(keyword, errors = []) {
  try {
    const d = await getJsonAnonymous(
      `${API}/x/web-interface/search/type?search_type=video&page=1&page_size=20&keyword=${encodeURIComponent(keyword)}`,
    )
    return (d.result ?? []).map((x) => normalize(x, `搜索:${keyword}`)).filter(Boolean)
  } catch (e) {
    errors.push(`搜索：${e?.message ?? e}`)
    return []
  }
}

async function collect(theme) {
  const errors = []
  const pools = []
  if (theme) pools.push(...(await fetchSearch(theme, errors)))
  const [pop, rank] = await Promise.all([fetchPopular(errors), fetchRanking(errors)])
  pools.push(...pop, ...rank)
  if (theme) for (const v of pools) if (`${v.title}${v.desc}`.includes(theme)) v.themeHit = true
  const seen = new Set()
  const items = pools.filter((v) => (seen.has(v.bvid) ? false : (seen.add(v.bvid), true)))
  return { items, errors }
}

function rank(list, s, theme) {
  const byOwner = new Map()
  const out = []
  const scored = []
  for (const v of list) {
    const hay = `${v.title} ${v.desc} ${v.tname}`
    if (s.dislike.some((w) => hay.includes(w))) continue
    let score = 0
    const hits = []
    for (const w of s.like) if (hay.includes(w)) { score += 3; hits.push(w) }
    const density = v.view > 0 ? (v.danmaku / v.view) * 1000 : 0
    score += Math.min(6, density)
    if (theme && v.themeHit) score += 5
    scored.push({ v, score, hits })
  }
  scored.sort((a, b) => b.score - a.score)
  for (const it of scored) {
    const owner = it.v.owner || '?'
    const used = byOwner.get(owner) ?? 0
    if (used >= 2) continue
    byOwner.set(owner, used + 1)
    out.push(it)
    if (out.length >= s.count) break
  }
  return out
}

function renderPicks(items, theme, total) {
  const L = [`[优选B站] 候选池 ${total} 条${theme ? `，主题「${theme}」` : ''}，按口味+弹幕密度排（不看播放量），同一 UP 最多 2 条：`]
  if (!items.length) {
    L.push('（没有匹配的候选：可能被「不想推的」全过滤了，或者接口暂时拿不到数据）')
    return L.join('\n')
  }
  items.forEach((it, i) => {
    const v = it.v
    L.push(`${i + 1}. ${v.title}`)
    L.push(`   BV=${v.bvid} · ${v.owner || '未知UP'} · ${fmtDur(v.duration)} · 播放 ${fmtNum(v.view)} / 弹幕 ${fmtNum(v.danmaku)}`)
    L.push(`   来源 ${v.source}${it.hits.length ? ` · 命中「${it.hits.join('/')}」` : ''}`)
    if (v.desc) L.push(`   简介：${v.desc.slice(0, 90)}${v.desc.length > 90 ? '…' : ''}`)
  })
  L.push('')
  L.push('下一步：对想推荐的那 1~2 条调 bili_read 真读一遍，再决定推谁、怎么讲。')
  return L.join('\n')
}

// ── 读懂一条 ──────────────────────────────────────────────────────────────
const DM_RE = /<d p="([^"]*)">([\s\S]*?)<\/d>/g
const unescapeXml = (s) =>
  String(s)
    .replace(/&lt;/g, '<').replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"').replace(/&apos;/g, "'")
    .replace(/&#(\d+);/g, (_, d) => String.fromCodePoint(Number(d)))
    .replace(/&amp;/g, '&')

async function fetchDanmaku(cid, limit) {
  try {
    const res = await api.fetch(`https://comment.bilibili.com/${cid}.xml`, {
      headers: { 'user-agent': B.UA, referer: B.REFERER },
    })
    const xml = await res.text()
    const all = []
    let m
    DM_RE.lastIndex = 0
    while ((m = DM_RE.exec(xml))) {
      const text = unescapeXml(m[2]).trim()
      if (text) all.push({ t: Number(m[1].split(',')[0]) || 0, text })
    }
    if (!all.length) return { total: 0, sample: [] }
    const step = Math.max(1, Math.floor(all.length / limit))
    const seen = new Set()
    const sample = []
    for (let i = 0; i < all.length && sample.length < limit; i += step) {
      if (seen.has(all[i].text)) continue
      seen.add(all[i].text)
      sample.push(all[i])
    }
    return { total: all.length, sample }
  } catch (e) {
    return { total: 0, sample: [], error: String(e?.message ?? e) }
  }
}

async function fetchComments(aid, limit) {
  if (limit <= 0) return []
  try {
    const d = await getJsonAnonymous(`${API}/x/v2/reply?type=1&oid=${aid}&sort=2&ps=${Math.min(20, limit)}&pn=1`)
    return (d.replies ?? []).slice(0, limit).map((r) => ({
      user: r.member?.uname ?? '',
      like: Number(r.like ?? 0) || 0,
      text: cleanText(r.content?.message ?? ''),
    }))
  } catch {
    return []
  }
}

async function aidOf(bvid) {
  const d = await getJsonAnonymous(`${API}/x/web-interface/view?bvid=${encodeURIComponent(bvid)}`)
  return d.aid
}

async function readOne(bvid) {
  const s = settings()
  const d = await getJsonAnonymous(`${API}/x/web-interface/view?bvid=${encodeURIComponent(bvid)}`)
  const cid = d.cid ?? d.pages?.[0]?.cid
  const [dm, cm] = await Promise.all([
    cid ? fetchDanmaku(cid, s.maxDanmaku) : Promise.resolve({ total: 0, sample: [] }),
    fetchComments(d.aid, s.maxComments),
  ])
  const L = []
  L.push(`标题：${cleanText(d.title)}`)
  L.push(`UP：${d.owner?.name ?? ''} · 时长 ${fmtDur(d.duration ?? 0)} · 播放 ${fmtNum(Number(d.stat?.view ?? 0))} / 弹幕 ${fmtNum(Number(d.stat?.danmaku ?? 0))} / 点赞 ${fmtNum(Number(d.stat?.like ?? 0))}`)
  L.push(`分区：${d.tname ?? ''} · 链接 https://www.bilibili.com/video/${d.bvid}`)
  if (d.desc) L.push(`简介：${cleanText(d.desc).slice(0, 400)}`)
  if (dm.sample?.length) {
    L.push('')
    L.push(`弹幕抽样（共 ${dm.total} 条，均匀取 ${dm.sample.length} 条）：`)
    L.push(dm.sample.map((x) => `${fmtDur(x.t)} ${x.text}`).join('\n'))
  } else {
    L.push('')
    L.push(`弹幕：没取到${dm.error ? `（${dm.error}）` : ''}`)
  }
  if (cm.length) {
    L.push('')
    L.push('热评（按点赞）：')
    for (const c of cm) L.push(`- ${c.user}（${fmtNum(c.like)} 赞）：${c.text.slice(0, 160)}`)
  }
  L.push('')
  L.push('注意：以上是文字层面（简介/弹幕/热评），没有画面。别声称自己看了画面。')
  return L.join('\n')
}

// ── 后台：转发 & 定时 ─────────────────────────────────────────────────────
function pushToChat(text) {
  const sender = runtime.sender
  const chatKey = runtime.chatKey || state.watch.chatKey || state.cron.chatKey
  if (!sender || !chatKey) {
    log('没有可用的发送通道（进程重启后需要有人再说一句话来恢复）')
    return false
  }
  Promise.resolve(sender.sendTextBatch(chatKey, [String(text)])).catch((e) => log('发送失败：', e?.message ?? e))
  return true
}

async function watchTick() {
  if (!state.watch.on) return
  const s = session()
  if (!s) return
  const now = Date.now()
  if (now - (state.watch.lastCheckAt || 0) < Math.max(60, Number(state.watch.intervalSec) || 180) * 1000) return
  state.watch.lastCheckAt = now

  const kinds = state.watch.kinds || ['reply', 'at', 'dm']
  try {
    for (const kind of ['reply', 'at']) {
      if (!kinds.includes(kind)) continue
      const items = await B.pullFeed(api.fetch, s, kind)
      const seen = new Set(state.watch.lastIds?.[kind] || [])
      const fresh = items.filter((x) => x.id && !seen.has(x.id)).reverse()
      if (fresh.length) {
        for (const x of fresh.slice(0, 5)) {
          pushToChat([
            `【B站·${kind === 'at' ? '@你' : '回复你'}】${x.user}${x.user ? '：' : ''}`,
            x.text,
            x.title ? `视频：${x.title}` : '',
            x.uri,
            `坐标 oid=${x.oid} root=${x.root} source=${x.source}（要回复就用 bili_reply）`,
          ].filter(Boolean).join('\n'))
        }
        state.watch.lastIds[kind] = [...new Set([...(state.watch.lastIds[kind] || []), ...fresh.map((x) => x.id)])].slice(-100)
      }
    }
    if (kinds.includes('dm')) {
      const list = await B.sessions(api.fetch, s)
      const owner = settings().ownerMid
      const newest = list
        .filter((x) => x.ts > (state.watch.lastDmTs || 0))
        .filter((x) => !owner || x.talkerId === owner)
      for (const x of newest.slice(0, 3)) {
        pushToChat(`【B站·私信】${x.talkerId}：${B.dmText(x.content)}`)
      }
      if (newest.length) state.watch.lastDmTs = Math.max(...newest.map((x) => x.ts))
    }
    saveState(state)
  } catch (e) {
    log('监听出错：', e?.message ?? e)
  }
}

// ── 定时任务：窗口内随机时刻 + 每天按概率掷骰 + 三种渠道 ──────────────────
function parseHHMM(v) {
  const m = /^(\d{1,2}):(\d{2})$/.exec(String(v ?? ''))
  if (!m) return null
  const h = Number(m[1])
  const mi = Number(m[2])
  if (h > 23 || mi > 59) return null
  return h * 60 + mi
}
const todayStr = () => new Date().toLocaleDateString('sv-SE')

const PENDING_MAX = 20
const PENDING_TTL_MS = 3 * 86400_000

/** 通道不可用时先存起来（重启后到点的推送不会丢） */
function enqueue(text) {
  if (!Array.isArray(state.pending)) state.pending = []
  const d = new Date()
  const atText = `${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')} ${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`
  state.pending.push({
    at: new Date().toISOString(),
    atText,
    text: String(text),
    chatKey: runtime.chatKey || state.schedule?.chatKey || state.watch?.chatKey || '',
  })
  if (state.pending.length > PENDING_MAX) state.pending = state.pending.slice(-PENDING_MAX)
  saveState(state)
  log(`没有发送通道，已进补发队列（${state.pending.length} 条）`)
}

/** 有通道就补发；过 3 天的丢弃，发送失败的留到下轮 */
async function flushPending() {
  const q = Array.isArray(state.pending) ? state.pending : []
  if (!q.length || !runtime.sender) return 0
  const now = Date.now()
  const keep = []
  let sent = 0
  for (const it of q) {
    if (now - Date.parse(it.at) > PENDING_TTL_MS) continue
    const key = it.chatKey || runtime.chatKey
    if (!key) {
      keep.push(it)
      continue
    }
    try {
      await runtime.sender.sendTextBatch(key, [
        `${it.text}\n（补发 · 原定 ${it.atText || String(it.at).slice(5, 16).replace('T', ' ')}）`,
      ])
      sent++
    } catch {
      keep.push(it)
    }
  }
  state.pending = keep
  saveState(state)
  if (sent) log(`补发 ${sent} 条积压消息`)
  return sent
}

/** 把一段文字按指定渠道送出去：qq=本会话 / dm=B站私信主人 / comment=B站评论区 @主人 */
async function deliver(channel, text, bvid) {
  if (channel === 'qq') {
    if (!pushToChat(text)) {
      enqueue(text)
      return 'queued'
    }
    return 'qq'
  }
  const s = needLogin()
  if (channel === 'dm') {
    const to = settings().ownerMid
    if (!to) throw new Error('私信渠道需要设置里的「主人 mid」')
    await B.sendDm(api.fetch, s, to, text)
    return 'dm'
  }
  if (channel === 'comment') {
    if (!bvid) throw new Error('评论渠道需要一条视频')
    const owner = settings().ownerName
    const body = String(text).trimStart().startsWith('@') ? text : `@${owner || '主人'} ${text}`
    const { aid } = await B.videoAid(api.fetch, s, bvid)
    const r = await B.postComment(api.fetch, s, { oid: aid, message: body })
    return `comment:${r.rpid}`
  }
  throw new Error(`未知渠道：${channel}`)
}

/** 设置页里的定时配置（配置页是权威来源）*/
function scheduleConfigFromSettings() {
  const s = settings()
  return {
    on: s.scheduleEnabled === true,
    start: s.scheduleStart,
    end: s.scheduleEnd,
    probability: s.scheduleProbability,
    channel: s.scheduleChannel,
    kind: s.scheduleKind,
    count: s.scheduleCount,
  }
}

/** 解析设置里的「额外定时任务」多行文本，一行一条：`21:00-21:30 概率 渠道 类型 [条数]` */
function parseExtraSchedules(text) {
  const out = []
  for (const raw of String(text || '').split(/\r?\n/)) {
    const line = raw.trim()
    if (!line || line.startsWith('#')) continue
    const parts = line.split(/\s+/)
    const m = /^(\d{1,2}:\d{2})-(\d{1,2}:\d{2})$/.exec(parts[0] || '')
    if (!m) continue
    const start = m[1]
    const end = m[2]
    let p = Number(parts[1] ?? 0.7)
    if (!Number.isFinite(p)) p = 0.7
    if (p > 1) p = p / 100 // 允许写 70 或 0.7
    p = Math.min(1, Math.max(0, p))
    const channel = ['qq', 'dm', 'comment'].includes(parts[2]) ? parts[2] : 'qq'
    const kind = parts[3] === 'diary' ? 'diary' : 'pick'
    const count = Math.round(clamp(parts[4] ?? 3, 1, 10, 3))
    if (parseHHMM(start) == null || parseHHMM(end) == null || parseHHMM(end) <= parseHHMM(start)) continue
    out.push({ on: true, start, end, probability: p, channel, kind, count })
  }
  return out
}

/** 把「额外定时任务」文本同步成 id=x1..xN 的条目（内容没变就保留原来的掷骰状态）*/
function syncExtraSchedules() {
  const parsed = parseExtraSchedules(settings().extraSchedules)
  const old = new Map((state.schedules || []).filter((s) => String(s.id).startsWith('x')).map((s) => [s.id, s]))
  const next = parsed.map((p, i) => {
    const id = 'x' + (i + 1)
    const sig = JSON.stringify(p)
    const prev = old.get(id)
    return prev && prev.sig === sig ? prev : { id, ...p, sig, day: '', nextAt: 0, firedDay: '' }
  })
  state.schedules = [...(state.schedules || []).filter((s) => !String(s.id).startsWith('x')), ...next]
}

/** 保证 schedules 数组存在，并把「设置页」那条（id=config）同步进来 */
function ensureSchedules() {
  if (!Array.isArray(state.schedules)) state.schedules = []
  syncExtraSchedules()
  const cfgS = scheduleConfigFromSettings()
  const sig = JSON.stringify(cfgS)
  let entry = state.schedules.find((x) => x.id === 'config')
  if (!entry) {
    entry = { id: 'config', ...cfgS, day: '', nextAt: 0, firedDay: '', sig }
    state.schedules.push(entry)
    saveState(state)
  } else if (entry.sig !== sig) {
    Object.assign(entry, cfgS, { sig, day: '', nextAt: 0, firedDay: '' })
    saveState(state)
    log('定时任务配置已从设置页同步')
  }
  return state.schedules
}

/** 校验并组装一条定时任务 */
function buildSchedule(args, base = {}) {
  const s = {
    on: args?.on != null ? args.on !== false : base.on ?? true,
    start: String(args?.start ?? base.start ?? '12:00'),
    end: String(args?.end ?? base.end ?? '13:00'),
    probability:
      args?.probability != null
        ? Math.min(1, Math.max(0, Number(args.probability)))
        : base.probability ?? 0.7,
    channel: String(args?.channel ?? base.channel ?? 'qq'),
    kind: String(args?.kind ?? base.kind ?? 'pick'),
    count: args?.count != null ? Math.round(clamp(args.count, 1, 10, 3)) : base.count ?? 3,
  }
  if (!['qq', 'dm', 'comment'].includes(s.channel)) return { error: `渠道只能是 qq / dm / comment，收到「${s.channel}」` }
  if (!['pick', 'diary'].includes(s.kind)) return { error: `类型只能是 pick / diary，收到「${s.kind}」` }
  const from = parseHHMM(s.start)
  const to = parseHHMM(s.end)
  if (from == null || to == null) return { error: `时间格式不对：${s.start} ~ ${s.end}（要 HH:MM）` }
  if (to <= from) return { error: `结束时间必须晚于开始时间（${s.start} ~ ${s.end}）` }
  if (s.on && s.channel !== 'qq' && !session()) return { error: `渠道「${s.channel}」需要先登录 B 站。` }
  if (s.on && s.channel === 'comment' && !settings().ownerName) return { error: '评论渠道需要在设置里填「主人 B 站昵称」。' }
  return s
}

function renderSchedules() {
  const list = state.schedules || []
  if (!list.length) return '（还没有定时任务）'
  return list
    .map((x) => {
      const next = x.nextAt ? new Date(x.nextAt).toLocaleString('zh-CN', { hour12: false }).slice(5) : '今天未触发/未掷'
      return `· ${x.id} ${x.on ? '开' : '关'} ${x.start}~${x.end} · 概率 ${Math.round((x.probability ?? 0) * 100)}% · ${x.channel}/${x.kind}${x.kind === 'pick' ? ` ×${x.count}` : ''} → ${next}`
    })
    .join('\n')
}

async function scheduleTick() {
  const list = ensureSchedules()
  for (const c of list) {
    if (!c?.on) continue
    try {
      await tickOne(c)
    } catch (e) {
      log('定时任务出错：', e?.message ?? e)
    }
  }
}

async function tickOne(c) {
  const now = Date.now()
  const today = todayStr()

  // 每天只掷一次骰子：窗口内随机时刻，按概率决定今天要不要
  if (c.day !== today) {
    const from = parseHHMM(c.start)
    const to = parseHHMM(c.end)
    c.day = today
    c.firedDay = ''
    c.nextAt = 0
    if (from != null && to != null && to > from) {
      const base = new Date()
      base.setHours(0, 0, 0, 0)
      const startMs = base.getTime() + from * 60_000
      const endMs = base.getTime() + to * 60_000
      const p = Math.min(1, Math.max(0, Number(c.probability ?? 0.7)))
      if (Math.random() < p) c.nextAt = Math.floor(startMs + Math.random() * Math.max(1, endMs - startMs))
    }
    saveState(state)
    log(`今日骰子：${c.nextAt ? '触发 · 约 ' + new Date(c.nextAt).toTimeString().slice(0, 5) : '跳过'}`)
    return
  }

  if (!c.nextAt || c.firedDay === today || now < c.nextAt) return
  c.firedDay = today
  saveState(state)

  try {
    if (c.kind === 'diary') {
      const text = [
        `今天 ${today} 的自动日记。`,
        session() ? `B 站账号：${session().uname || session().mid}` : 'B 站账号：未登录',
        `记录目录：${paths.STORE_DIR}`,
      ].join('\n')
      const file = appendDiary({ kind: '自动日记', text })
      await deliver(c.channel, `【优选B站·日记】\n${text}\n（已写入 ${file}）`)
    } else {
      const s = settings()
      const { items: pool, errors } = await collect('')
      if (!pool.length) throw new Error('拿不到候选：' + (errors.join('；') || '无数据'))
      const items = rank(pool, { ...s, count: Math.max(1, Math.min(10, Number(c.count) || 3)) }, '')
      const text = '【优选B站·今日精选】\n' + renderPicks(items, '', pool.length)
      c.lastText = text
      saveState(state)
      await deliver(c.channel, text, items[0]?.v?.bvid)
    }
  } catch (e) {
    log('定时任务出错：', e?.message ?? e)
    pushToChat(`【优选B站】定时推送失败：${e?.message ?? e}`)
  }
}

function startTimers() {
  if (timers.length) return
  timers.push(setInterval(() => watchTick().catch(() => {}), 30_000))
  timers.push(setInterval(() => scheduleTick().catch(() => {}), 30_000))
  timers.push(setInterval(() => flushPending().catch(() => {}), 60_000))
}

// ── 工具注册 ──────────────────────────────────────────────────────────────
const BVID_RE = /BV[0-9A-Za-z]{10}/

export function setup(a) {
  rawFetch = typeof a.fetch === 'function' ? a.fetch : globalThis.fetch
  api = { ...a, fetch: httpFetch } // 所有 api.fetch(...) 自动走「跳过坏 IP」的通道
  cfg = a.config
  state = loadState()

  // 每次工具调用都顺手刷新一次「发送通道」：后台监听/定时在进程重启后没有 sender，
  // 只要机器人在这个会话里动过一次（哪怕只是挑片），通道就恢复 ✓
  if (typeof a.registerTool === 'function') {
    const rawRegister = a.registerTool.bind(a)
    a.registerTool = (def) => {
      const execute = def?.execute
      return rawRegister({
        ...def,
        execute: (ctx, args) => {
          if (ctx?.sender && ctx?.chatKey) {
            runtime.sender = ctx.sender
            runtime.chatKey = ctx.chatKey
            flushPending().catch(() => {})
          }
          return typeof execute === 'function' ? execute(ctx, args) : undefined
        },
      })
    }
  }

  // ① 挑片 / 读懂
  a.registerTool({
    id: 'bili_pick',
    name: '优选B站：挑候选',
    category: 'media',
    icon: '🎬',
    description:
      '有人要 B 站视频推荐、问「最近有什么好看的」「来点下饭的」，或要按主题挑片时，先用它拿候选。'
      + '从热门+排行按口味和弹幕密度排，同一 UP 最多两条。参数 theme 可选、count 可选。',
    parameters: {
      type: 'object',
      properties: {
        theme: { type: 'string', description: '主题关键词，可留空' },
        count: { type: 'number', description: '要几条（1~10），留空用设置值' },
      },
      required: [],
    },
    async execute(ctx, args) {
      const s = settings()
      const theme = String(args?.theme ?? '').trim()
      const count = args?.count ? Math.round(clamp(args.count, 1, 10, s.count)) : s.count
      try {
        const { items: pool, errors } = await collect(theme)
        if (!pool.length) {
          return {
            content: '拿不到 B 站候选。接口报错：' + (errors.join('；') || '（没有拿到任何数据，也没报错）'),
            isError: true,
          }
        }
        return { content: renderPicks(rank(pool, { ...s, count }, theme), theme, pool.length) }
      } catch (e) {
        return { content: `挑片失败：${e?.message ?? e}`, isError: true }
      }
    },
  })

  a.registerTool({
    id: 'bili_read',
    name: '优选B站：读懂一条',
    category: 'media',
    icon: '📖',
    description: '给定 BV 号，读标题/UP/数据/简介 + 弹幕抽样 + 热评。判断「它到底在讲什么、值不值得推荐」。',
    parameters: {
      type: 'object',
      properties: { bvid: { type: 'string', description: 'BV 号或视频链接' } },
      required: ['bvid'],
    },
    async execute(ctx, args) {
      const hit = BVID_RE.exec(String(args?.bvid ?? args?.url ?? ''))
      if (!hit) return { content: '没找到 BV 号（BV 开头 12 位，或完整链接）。', isError: true }
      try {
        return { content: await readOne(hit[0]) }
      } catch (e) {
        return { content: `读取失败：${e?.message ?? e}`, isError: true }
      }
    },
  })

  // ② 扫码登录
  a.registerTool({
    id: 'bili_login',
    name: '优选B站：扫码登录',
    category: 'utility',
    icon: '🔑',
    description:
      '发一张 B 站登录二维码到当前 QQ 会话，用「机器人专用小号」的 B 站 App 扫码。扫完自动保存登录态，'
      + '之后才能用回复/私信/监听。不需要参数。',
    parameters: { type: 'object', properties: {}, required: [] },
    async execute(ctx) {
      if (!ctx?.sender) return { content: '这个会话没法发图片（拿不到 sender）', isError: true }
      try {
        const q = await B.qrGenerate(api.fetch)
        runtime.sender = ctx.sender
        runtime.chatKey = ctx.chatKey
        await ctx.sender.sendImage(ctx.chatKey, { dataUrl: qrDataUrl(q.url) }, { note: 'B站登录二维码' })
        await ctx.sender.sendTextBatch(ctx.chatKey, [
          '📱 用「机器人专用小号」的 B 站 App 扫上面的二维码，确认登录。',
          '（2 分 55 秒内有效；扫完我会在这里说一声）',
        ])
        startLoginPoll(q.key, ctx)
        return { content: '二维码已发到当前会话，等扫码。扫完会自动保存登录态。' }
      } catch (e) {
        return { content: `生成二维码失败：${e?.message ?? e}`, isError: true }
      }
    },
  })

  a.registerTool({
    id: 'bili_me',
    name: '优选B站：账号状态',
    category: 'utility',
    icon: '👤',
    description: '查当前登录的 B 站账号（昵称/UID/是否登录）。没登录就直接说没登录。',
    parameters: { type: 'object', properties: {}, required: [] },
    async execute() {
      if (!session()) return { content: '还没登录 B 站（用 bili_login 扫码）。' }
      try {
        const n = await B.nav(api.fetch, session())
        if (!n.isLogin) return { content: 'cookie 失效了（B站说未登录），重新扫码。', isError: true }
        state.session = { ...session(), mid: n.mid, uname: n.uname }
        saveState(state)
        return { content: `已登录：${n.uname}（mid ${n.mid}）${n.vip ? ' · 大会员' : ''}` }
      } catch (e) {
        return { content: `查询失败：${e?.message ?? e}`, isError: true }
      }
    },
  })

  a.registerTool({
    id: 'bili_logout',
    name: '优选B站：退出登录',
    category: 'utility',
    icon: '🚪',
    description: '清掉本地保存的 B 站登录态（不影响账号本身）。',
    parameters: { type: 'object', properties: {}, required: [] },
    async execute() {
      state.session = null
      saveState(state)
      return { content: '已清掉本地登录态。' }
    },
  })

  // ③ 互动
  a.registerTool({
    id: 'bili_reply',
    name: '优选B站：回复评论',
    category: 'social',
    icon: '💬',
    description:
      '用登录的账号在 B 站 某条视频评论下回复。参数：bvid（视频）+ message（回复内容）；'
      + 'root/parent 可选——回复别人的楼中楼时传，不传就是顶层评论。',
    parameters: {
      type: 'object',
      properties: {
        bvid: { type: 'string', description: '视频 BV 号或链接' },
        message: { type: 'string', description: '回复正文' },
        root: { type: 'string', description: '根评论 rpid（回复楼中楼时传）' },
        parent: { type: 'string', description: '被回复的 rpid（回复楼中楼时传）' },
      },
      required: ['bvid', 'message'],
    },
    async execute(ctx, args) {
      try {
        const s = needLogin()
        const hit = BVID_RE.exec(String(args?.bvid ?? ''))
        if (!hit) return { content: '没找到 BV 号。', isError: true }
        const msg = String(args?.message ?? '').trim()
        if (!msg) return { content: '回复内容不能为空。', isError: true }
        const { aid, title } = await B.videoAid(api.fetch, s, hit[0])
        const r = await B.postComment(api.fetch, s, {
          oid: aid,
          message: msg,
          root: String(args?.root ?? ''),
          parent: String(args?.parent ?? ''),
        })
        appendDiary({ kind: 'B站回复', text: `在《${title}》回复：${msg.slice(0, 120)}（rpid ${r.rpid}）` })
        return { content: `已发布 ✓ rpid=${r.rpid}\nhttps://www.bilibili.com/video/${hit[0]}/#reply${r.rpid}` }
      } catch (e) {
        return { content: `回复失败：${e?.message ?? e}`, isError: true }
      }
    },
  })

  a.registerTool({
    id: 'bili_dm',
    name: '优选B站：发私信',
    category: 'social',
    icon: '✉️',
    description:
      '用登录的账号给 B 站用户发私信。默认发给「主人」（设置里的 ownerMid）。'
      + '参数 message 必填；to 可选（对方 mid）。对方需与机器人互关。',
    parameters: {
      type: 'object',
      properties: {
        message: { type: 'string', description: '私信正文' },
        to: { type: 'string', description: '收信人 mid，留空=设置里的主人' },
      },
      required: ['message'],
    },
    async execute(ctx, args) {
      try {
        const s = needLogin()
        const to = String(args?.to ?? '').trim() || settings().ownerMid
        if (!to) return { content: '没指定收信人：设置里填「主人 mid」，或传 to。', isError: true }
        const msg = String(args?.message ?? '').trim()
        if (!msg) return { content: '私信内容不能为空。', isError: true }
        await B.sendDm(api.fetch, s, to, msg)
        appendDiary({ kind: 'B站私信', text: `私信 ${to}：${msg.slice(0, 120)}` })
        return { content: `已发送私信给 ${to} ✓` }
      } catch (e) {
        return { content: `私信失败：${e?.message ?? e}`, isError: true }
      }
    },
  })

  // ④ 日记
  a.registerTool({
    id: 'bili_diary',
    name: '优选B站：日记',
    category: 'utility',
    icon: '📔',
    description:
      '日记本。action：write=写一段（默认，写完会直接发到当前 QQ 会话，设置里可关）；'
      + 'read=读某天的日记（date 默认今天，kind 可只读某一段，如「今天看了」/「给主人的话」）；'
      + 'list=列出有日记的日期。用户说「念一下你的日记」「看看 B 站那篇」时用 read，别用 write 糊弄。',
    parameters: {
      type: 'object',
      properties: {
        action: { type: 'string', description: 'write | read | list' },
        text: { type: 'string', description: 'write 时必填：日记正文' },
        kind: { type: 'string', description: '分类，如「今天看了」「给主人的话」；read 时可当过滤条件' },
        date: { type: 'string', description: 'read 时用：YYYY-MM-DD，默认今天' },
      },
      required: [],
    },
    async execute(ctx, args) {
      const action = String(args?.action ?? 'write')

      if (action === 'list') {
        const list = listDiary()
        if (!list.length) return { content: '还没有日记。' }
        return { content: '有日记的日期：\n' + list.slice(0, 30).map((x) => `· ${x.date}（${Math.round((x.size / 1024) * 10) / 10} KB）`).join('\n') }
      }

      if (action === 'read') {
        const date = String(args?.date ?? new Date().toLocaleDateString('sv-SE'))
        const raw = readDiary(date)
        if (!raw.trim()) return { content: `${date} 没有日记（用 action=list 看有哪些天）。` }
        let out = raw
        const kind = String(args?.kind ?? '').trim()
        if (kind) {
          const blocks = raw.split(/\n(?=## )/).filter((b) => b.includes(kind))
          out = blocks.join('\n\n')
          if (!out.trim()) return { content: `${date} 的日记里没有「${kind}」这一段。` }
        }
        out = out.trim()
        const cap = 6000
        return {
          content: `【${date} 日记${kind ? ' · ' + kind : ''}】\n${out.length > cap ? out.slice(0, cap) + '\n…（已截断）' : out}`,
        }
      }

      // write
      const text = String(args?.text ?? '').trim()
      if (!text) return { content: '写日记时 text 不能为空。', isError: true }
      const kind = String(args?.kind ?? '记')
      const file = appendDiary({ kind, text })
      let pushed = ''
      if (settings().diaryPush !== false && ctx?.sender && ctx?.chatKey) {
        try {
          await ctx.sender.sendTextBatch(ctx.chatKey, [`📔 ${kind}\n${text}`])
          pushed = '\n（已发到当前 QQ 会话）'
        } catch (e) {
          pushed = `\n（发 QQ 失败：${e?.message ?? e}）`
        }
      }
      return { content: `已写入 ${file}${pushed}` }
    },
  })

  // ⑤ 后台转发 / 定时
  a.registerTool({
    id: 'bili_watch',
    name: '优选B站：监听并转发到QQ',
    category: 'social',
    icon: '📡',
    description:
      '开关：监听 B 站 的「回复我的 / @我的 / 私信」，有新消息就自动转发到当前 QQ 会话。'
      + '参数 on 必填（true/false）；kinds 可选（reply,at,dm）；intervalSec 可选（默认 180）。',
    parameters: {
      type: 'object',
      properties: {
        on: { type: 'boolean', description: 'true=开启，false=关闭' },
        kinds: { type: 'array', items: { type: 'string' }, description: '要监听哪几类：reply / at / dm' },
        intervalSec: { type: 'number', description: '轮询间隔秒数（≥60）' },
      },
      required: ['on'],
    },
    async execute(ctx, args) {
      if (!session() && args?.on !== false) return { content: '先扫码登录（bili_login），监听需要登录态。', isError: true }
      const on = args?.on !== false
      state.watch = {
        ...state.watch,
        on,
        chatKey: on ? ctx?.chatKey || state.watch.chatKey : state.watch.chatKey,
        kinds: Array.isArray(args?.kinds) && args.kinds.length ? args.kinds.map(String) : state.watch.kinds,
        intervalSec: args?.intervalSec ? Math.max(60, Number(args.intervalSec)) : state.watch.intervalSec,
      }
      if (on) {
        runtime.sender = ctx?.sender ?? runtime.sender
        runtime.chatKey = ctx?.chatKey ?? runtime.chatKey
        state.watch.lastCheckAt = 0
      }
      saveState(state)
      startTimers()
      return { content: on ? `已开启监听（${state.watch.kinds.join('/')}，每 ${state.watch.intervalSec}s 一次），新消息转发到本会话。` : '已关闭监听。' }
    },
  })

  a.registerTool({
    id: 'bili_comments',
    name: '优选B站：读评论区',
    category: 'media',
    icon: '🧵',
    description:
      '按 BV 号拉评论区（热门或最新，可翻页），用来和群友讨论「评论区在吵什么/热评说了啥」。'
      + '返回紧凑列表（昵称+点赞+正文，单条截断），省 token。',
    parameters: {
      type: 'object',
      properties: {
        bvid: { type: 'string', description: 'BV 号或链接' },
        sort: { type: 'string', description: 'hot=按热度（默认）| time=按时间' },
        page: { type: 'number', description: '页码，默认 1' },
        ps: { type: 'number', description: '每页条数 1~20，默认 10' },
      },
      required: ['bvid'],
    },
    async execute(ctx, args) {
      const hit = BVID_RE.exec(String(args?.bvid ?? ''))
      if (!hit) return { content: '没找到 BV 号。', isError: true }
      const sort = String(args?.sort ?? 'hot') === 'time' ? 0 : 2
      const pn = Math.max(1, Number(args?.page) || 1)
      const ps = Math.round(clamp(args?.ps ?? 10, 1, 20, 10))
      try {
        const d = await getJsonAnonymous(
          `${API}/x/v2/reply?type=1&oid=${await aidOf(hit[0])}&sort=${sort}&ps=${ps}&pn=${pn}`,
        )
        const list = d.replies ?? []
        if (!list.length) return { content: '这一页没有评论（可能被关闭或还没人评论）。' }
        const L = [`评论区（${sort === 0 ? '最新' : '热度'} · 第 ${pn} 页 · ${list.length} 条 · 总 ${d.page?.count ?? '?'} 条）：`]
        list.forEach((r, i) => {
          L.push(`${(pn - 1) * ps + i + 1}. ${r.member?.uname ?? ''}（${fmtNum(Number(r.like) || 0)} 赞${r.rcount ? ` · ${r.rcount} 回复` : ''}）`)
          L.push(`   ${cleanText(r.content?.message ?? '').slice(0, 140)}`)
        })
        L.push('（只给了文字摘要；要更深的楼中楼可以说具体某一条）')
        return { content: L.join('\n') }
      } catch (e) {
        return { content: `读评论失败：${e?.message ?? e}`, isError: true }
      }
    },
  })

  a.registerTool({
    id: 'bili_schedule',
    name: '优选B站：定时任务（窗口+概率+渠道）',
    category: 'utility',
    icon: '⏰',
    description:
      '设定每天在某个时间段内随机挑一个时刻执行，并按概率决定今天要不要（每天只掷一次骰子）。'
      + '参数：on 必填；start/end 形如 "12:00"/"13:00"；probability 0~1（默认 0.7）；'
      + 'channel = qq（推到当前会话，0 token）| dm（B站私信主人）| comment（B站评论区 @主人）；'
      + 'kind = pick（推今日精选）| diary（写自动日记）；count 可选（pick 推几条）。',
    parameters: {
      type: 'object',
      properties: {
        on: { type: 'boolean', description: 'true=开启，false=关闭' },
        start: { type: 'string', description: '窗口开始 HH:MM，如 12:00' },
        end: { type: 'string', description: '窗口结束 HH:MM，如 13:00' },
        probability: { type: 'number', description: '今天触发的概率 0~1，默认 0.7' },
        channel: { type: 'string', description: 'qq | dm | comment' },
        kind: { type: 'string', description: 'pick | diary' },
        count: { type: 'number', description: 'pick 时推几条（1~10）' },
      },
      required: ['on'],
    },
    async execute(ctx, args) {
      const on = args?.on !== false
      const prev = (state.schedules || []).find((x) => x.id === 'config') || {}
      const next = {
        ...prev,
        on,
        start: String(args?.start ?? prev.start ?? '12:00'),
        end: String(args?.end ?? prev.end ?? '13:00'),
        probability: args?.probability != null ? Math.min(1, Math.max(0, Number(args.probability))) : prev.probability,
        channel: String(args?.channel ?? prev.channel ?? 'qq'),
        kind: String(args?.kind ?? prev.kind ?? 'pick'),
        count: args?.count != null ? Math.round(clamp(args.count, 1, 10, 3)) : prev.count,
        chatKey: on ? ctx?.chatKey || prev.chatKey : prev.chatKey,
      }
      if (!['qq', 'dm', 'comment'].includes(next.channel)) return { content: `渠道只能是 qq / dm / comment，收到「${next.channel}」`, isError: true }
      if (!['pick', 'diary'].includes(next.kind)) return { content: `类型只能是 pick / diary，收到「${next.kind}」`, isError: true }
      const from = parseHHMM(next.start)
      const to = parseHHMM(next.end)
      if (from == null || to == null) return { content: `时间格式不对：${next.start} ~ ${next.end}（要 HH:MM）`, isError: true }
      if (to <= from) return { content: `结束时间必须晚于开始时间（${next.start} ~ ${next.end}），跨午夜暂不支持`, isError: true }
      if (on && next.channel !== 'qq' && !session()) return { content: `渠道「${next.channel}」需要先 bili_login 扫码登录。`, isError: true }
      if (on && next.channel === 'comment' && !settings().ownerName) return { content: '评论渠道需要在设置里填「主人 B 站昵称」（@ 要用）。', isError: true }

      next.day = '' // 配置变了就重新掷今天的骰子
      next.nextAt = 0
      next.firedDay = ''
      // 标记为「与设置页同步」，否则下一次 tick 会被设置页的值覆盖回去。
      // 用户在设置页再改时，sig 变了 → 以设置页为准。
      next.sig = JSON.stringify(scheduleConfigFromSettings())
      next.id = 'config'
      state.schedules = [...(state.schedules || []).filter((x) => x.id !== 'config'), next]
      if (on) {
        runtime.sender = ctx?.sender ?? runtime.sender
        runtime.chatKey = ctx?.chatKey ?? runtime.chatKey
      }
      saveState(state)
      startTimers()
      if (!on) return { content: '已关闭定时任务。' }
      return {
        content: `已设定：每天 ${next.start}~${next.end} 之间随机一个时刻，触发概率 ${Math.round(next.probability * 100)}%，`
          + `渠道「${next.channel}」，内容「${next.kind}」${next.kind === 'pick' ? `（${next.count} 条）` : ''}。今天会按配置重新掷一次。`,
      }
    },
  })

  a.registerTool({
    id: 'bili_clean',
    name: '优选B站：清理缓存',
    category: 'utility',
    icon: '🧹',
    description:
      '清理这个技能留下的临时数据。target：tmp=临时文件（抽帧/下载残留）；queue=补发队列；'
      + 'schedules=清空额外定时任务（保留设置页那条）；diary=删 N 天前的日记（days 默认 30）；login=退出登录；all=tmp+queue。',
    parameters: {
      type: 'object',
      properties: {
        target: { type: 'string', description: 'tmp | queue | schedules | diary | login | all' },
        days: { type: 'number', description: 'diary 用：保留最近多少天，默认 30' },
      },
      required: ['target'],
    },
    async execute(ctx, args) {
      const target = String(args?.target ?? 'all')
      const report = []

      const cleanTmp = () => {
        const dir = os.tmpdir()
        let n = 0
        let bytes = 0
        try {
          for (const name of fs.readdirSync(dir)) {
            if (!/^(bili-pick-|bili-frames-)/.test(name)) continue
            const p = path.join(dir, name)
            try {
              const st = fs.statSync(p)
              if (st.isDirectory()) {
                for (const f of fs.readdirSync(p)) {
                  try {
                    bytes += fs.statSync(path.join(p, f)).size
                  } catch {}
                }
                fs.rmSync(p, { recursive: true, force: true })
                n += 1
              }
            } catch {}
          }
        } catch {}
        report.push(`临时文件：清掉 ${n} 个目录（${Math.round(bytes / 1024)} KB）`)
      }

      if (target === 'tmp' || target === 'all') cleanTmp()

      if (target === 'queue' || target === 'all') {
        const n = (state.pending || []).length
        state.pending = []
        saveState(state)
        report.push(`补发队列：清掉 ${n} 条`)
      }

      if (target === 'schedules') {
        const before = (state.schedules || []).length
        state.schedules = (state.schedules || []).filter((s) => s.id === 'config')
        saveState(state)
        report.push(`额外定时任务：删掉 ${before - state.schedules.length} 条（设置页那条保留）`)
      }

      if (target === 'diary') {
        const keep = Math.max(1, Math.round(clamp(args?.days ?? 30, 1, 3650, 30)))
        const dir = paths.diaryDir()
        let n = 0
        if (fs.existsSync(dir)) {
          const cutoff = new Date()
          cutoff.setDate(cutoff.getDate() - keep)
          const cut = cutoff.toLocaleDateString('sv-SE')
          for (const f of fs.readdirSync(dir)) {
            if (!f.endsWith('.md')) continue
            if (f.replace('.md', '') < cut) {
              try {
                fs.rmSync(path.join(dir, f), { force: true })
                n += 1
              } catch {}
            }
          }
        }
        report.push(`日记：删掉 ${n} 个 ${keep} 天前的文件`)
      }

      if (target === 'login') {
        state.session = null
        saveState(state)
        report.push('登录态：已清除（账号本身不受影响）')
      }

      if (!report.length) return { content: `不认识的 target：${target}`, isError: true }
      return { content: report.join('\n') + `\n\n数据目录：${paths.STORE_DIR}` }
    },
  })

  a.registerTool({
    id: 'bili_schedules',
    name: '优选B站：多个定时任务',
    category: 'utility',
    icon: '🗓️',
    description:
      '管理**多条**定时任务。设置页里那条固定叫 id=config；这里可以再加任意条。'
      + 'action=list 列出 / add 新建 / update 修改（需 id）/ remove 删除（需 id）。'
      + '每条各自带 start/end（时间段）、probability（概率）、channel（qq/dm/comment）、kind（pick/diary）、count。',
    parameters: {
      type: 'object',
      properties: {
        action: { type: 'string', description: 'list | add | update | remove' },
        id: { type: 'string', description: 'update/remove 时必填；add 时自动生成' },
        on: { type: 'boolean' },
        start: { type: 'string', description: 'HH:MM' },
        end: { type: 'string', description: 'HH:MM' },
        probability: { type: 'number', description: '0~1' },
        channel: { type: 'string', description: 'qq | dm | comment' },
        kind: { type: 'string', description: 'pick | diary' },
        count: { type: 'number', description: '1~10' },
      },
      required: ['action'],
    },
    async execute(ctx, args) {
      ensureSchedules()
      const action = String(args?.action ?? 'list')
      if (action === 'list') return { content: renderSchedules() }

      if (action === 'add') {
        const item = buildSchedule(args, {})
        if (item.error) return { content: item.error, isError: true }
        item.id = 's' + (Date.now() % 1000000)
        item.chatKey = ctx?.chatKey || ''
        item.day = ''
        item.nextAt = 0
        item.firedDay = ''
        state.schedules.push(item)
        saveState(state)
        if (ctx?.sender) {
          runtime.sender = ctx.sender
          runtime.chatKey = ctx.chatKey
        }
        return { content: `已添加定时任务 ${item.id}。\n${renderSchedules()}` }
      }

      if (action === 'remove' || action === 'update') {
        const id = String(args?.id ?? '')
        if (id === 'config') return { content: 'id=config 那条请在设置页里改/关，不要在这里删。', isError: true }
        const idx = (state.schedules || []).findIndex((x) => x.id === id)
        if (idx < 0) return { content: `没有 id=${id} 的定时任务`, isError: true }
        if (action === 'remove') {
          state.schedules.splice(idx, 1)
          saveState(state)
          return { content: `已删除 ${id}。\n${renderSchedules()}` }
        }
        const merged = buildSchedule(args, state.schedules[idx])
        if (merged.error) return { content: merged.error, isError: true }
        state.schedules[idx] = { ...state.schedules[idx], ...merged, day: '', nextAt: 0, firedDay: '' }
        saveState(state)
        return { content: `已更新 ${id}。\n${renderSchedules()}` }
      }

      return { content: 'action 只能是 list / add / update / remove', isError: true }
    },
  })

  a.registerTool({
    id: 'bili_subtitles',
    name: '优选B站：读字幕',
    category: 'media',
    icon: '📝',
    description:
      '取一条视频的官方/AI 字幕全文（带时间戳）。比 bili_read 更准，适合回答「这条到底讲了什么」。'
      + '需要登录；没有字幕轨会明确说明（这时改用 bili_read 看弹幕/热评，或 bili_watch_video 看画面）。',
    parameters: {
      type: 'object',
      properties: {
        bvid: { type: 'string', description: 'BV 号或链接' },
        maxChars: { type: 'number', description: '最多返回多少字，默认用设置值（6000）' },
      },
      required: ['bvid'],
    },
    async execute(ctx, args) {
      try {
        const s = needLogin()
        const hit = BVID_RE.exec(String(args?.bvid ?? ''))
        if (!hit) return { content: '没找到 BV 号。', isError: true }
        const info = await B.videoAid(api.fetch, s, hit[0])
        const r = await M.subtitles(api.fetch, s, { bvid: hit[0], cid: info.cid })
        if (!r.list.length) return { content: `《${info.title}》\n\n${r.note}` }
        const cap = Math.round(clamp(args?.maxChars ?? settings().subtitleMaxChars, 800, 20000, 6000))
        const truncated = r.text.length > cap
        const body = truncated ? `${r.text.slice(0, cap)}\n…（还有 ${r.text.length - cap} 字；要全文调大 maxChars）` : r.text
        return {
          content: `《${info.title}》字幕（${r.lang} · ${r.list.length} 条${truncated ? ' · 已截断' : ''}）：\n${body}`,
        }
      } catch (e) {
        return { content: `读字幕失败：${e?.message ?? e}`, isError: true }
      }
    },
  })

  a.registerTool({
    id: 'bili_watch_video',
    name: '优选B站：看画面',
    category: 'media',
    icon: '🎞️',
    description:
      '下载视频流并抽帧拼成九宫格，把画面交给模型看。费流量、费时间，只在需要判断画面时用'
      + '（短视频、或用户明确要求「看看画面」）。缺 ffmpeg 会返回安装方法；本机没装就先用字幕。',
    parameters: {
      type: 'object',
      properties: {
        bvid: { type: 'string', description: 'BV 号或链接' },
        grid: { type: 'number', description: '拼图网格 2~4，默认用设置值（3）' },
      },
      required: ['bvid'],
    },
    async execute(ctx, args) {
      try {
        const s = needLogin()
        const hit = BVID_RE.exec(String(args?.bvid ?? ''))
        if (!hit) return { content: '没找到 BV 号。', isError: true }
        const info = await B.videoAid(api.fetch, s, hit[0])
        if (info.duration > 45 * 60) {
          return {
            content: `这条 ${Math.round(info.duration / 60)} 分钟，太长了不适合整条抽帧；先用 bili_subtitles 读字幕吧。`,
            isError: true,
          }
        }
        const grid = Math.round(clamp(args?.grid ?? settings().frameGrid, 2, 4, 3))
        const r = await M.extractFrames(api.fetch, s, {
          bvid: hit[0],
          cid: info.cid,
          duration: info.duration,
          grid,
          ffmpegPath: settings().ffmpegPath,
        })
        return {
          content: [
            {
              type: 'text',
              text: `《${info.title}》\n${r.note}（${Math.round(r.bytes / 1024)} KB）。拼图按从左到右、从上到下是时间顺序。`,
            },
            { type: 'image_url', image_url: { url: r.dataUrl } },
          ],
        }
      } catch (e) {
        return { content: `看画面失败：${e?.message ?? e}`, isError: true }
      }
    },
  })

  startTimers()
  log(`已注册工具：pick/read/comments/subtitles/watch-video/login/me/logout/reply/dm/diary/watch/schedule（登录：${session() ? session().uname || session().mid || 'cookie 登录' : '未登录'}）`)
}

function startLoginPoll(key, ctx) {
  const started = Date.now()
  const timer = setInterval(async () => {
    try {
      if (Date.now() - started > 175_000) {
        clearInterval(timer)
        await ctx.sender.sendTextBatch(ctx.chatKey, ['二维码过期了，再发一次 bili_login 就好。'])
        return
      }
      const r = await B.qrPoll(api.fetch, key)
      if (r.code === 0) {
        clearInterval(timer)
        state.session = { ...r.session, at: Date.now(), uname: '' }
        try {
          const n = await B.nav(api.fetch, state.session)
          if (n.isLogin) {
            state.session.mid = n.mid
            state.session.uname = n.uname
          }
        } catch {}
        saveState(state)
        appendDiary({ kind: '登录', text: `B 站专用账号已登录：${state.session.uname || state.session.mid || state.session.dedeUserId}` })
        await ctx.sender.sendTextBatch(ctx.chatKey, [
          `✅ 登录成功：${state.session.uname || state.session.mid || state.session.dedeUserId}`,
          '现在可以用 bili_reply / bili_dm / bili_watch 了。',
        ])
      }
    } catch (e) {
      // 轮询失败不打断，等下一轮
    }
  }, 3000)
  timers.push(timer)
}

export function available() {
  return true
}

export function dispose() {
  for (const t of timers.splice(0)) {
    try {
      clearInterval(t)
    } catch {}
  }
}

export const internals = { settings, rank, collect, readOne, scheduleTick, deliver, enqueue, flushPending, state: () => state, paths }
