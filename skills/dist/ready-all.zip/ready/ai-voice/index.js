// AI 语音技能（LLM 型）：把一句短文本用本机 VoxCPM **纯克隆**成本机参考音频的音色，发成 QQ 语音。
//
// 设计原则（v2.0.0 重置版）：一切以「贴合参考音频」为准。
//   不加任何风格/情绪控制指令，不做生成后处理 —— 之前那些会让人声偏离参考音色。
//
// 链路：
//   1) 校验字数（合成前拦住超长文本，不浪费 CPU 算力）
//   2) 探测本机 TTS 服务，不通且开了自动拉起时 spawn python server.py
//   3) POST /api/generate：mode=clone + reference=参考音频（缺失则回退内置音色）
//   4) 轮询 /api/history 等 job 完成，超时取消任务
//   5) 取 outputs/<job_id>.wav，清理旧文件
//   6) ctx.sender.sendMedia({type:'record'}) —— 走官方发送管道（限频/去重/留档），
//      协议端会把 wav 自动转成 QQ 要的 SILK 格式，这里不用管转码。
import fs from 'node:fs';
import path from 'node:path';
import { spawn } from 'node:child_process';

const DEFAULTS = {
  referenceAudio: '',
  serverBase: 'http://127.0.0.1:7860',
  serverDir: 'D:\\AI\\hear',
  pythonCmd: 'python',
  autoStart: true,
  maxChars: 50,
  styleHint: '年轻女性嗓音，中高音域，音色轻盈柔和清澈，带明显空气感与细腻高频质感，中等偏轻的气声，薄薄一层呼吸感但主体是清晰实声，不虚弱不漏气，中高频柔亮通透无金属质感、不尖锐不刺耳，中频偏薄偏低干净，低频存在感弱，不做厚重磁性御姐音，共鸣以口腔与头腔为主胸腔少，声音靠前贴耳亲近，自然咬字，逗号和句末停顿处有轻微呼气声',
  notifyStart: true,
  fallbackToDesign: true,
  fallbackVoice: 'young_female',
  cfgValue: 2,
  inferenceTimesteps: 16,
  seed: 0,
  readyTimeoutMs: 300000,
  jobTimeoutMs: 600000,
  keepOutputs: 30
};

let cfg = () => ({});
let fetchFn = null;
const runtime = { starting: null, spawnError: null, logFd: null };

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const trimBase = (s) => String(s ?? '').trim().replace(/\/+$/, '');
const nowText = () => new Date().toLocaleTimeString('zh-CN', { hour12: false });

function ok(payload) { return { content: JSON.stringify(payload, null, 1) }; }
function err(message) { return { content: `错误：${message}`, isError: true }; }

/**
 * 风格提示会以 `(提示)正文` 拼进模型输入，所以括号类字符必须先剥掉，
 * 否则模型会把多余括号念出来，或被拼出畸形提示词。
 */
function cleanHint(raw, maxLen = 200) {
  let s = String(raw ?? '')
    .replace(/[()（）\[\]【】{}<>「」『』"'\u2018\u2019\u201c\u201d`]/g, ' ')
    .replace(/[\r\n\t]+/g, ' ')
    .replace(/\s{2,}/g, ' ')
    .replace(/^[,，、\s]+|[,，、\s]+$/g, '')
    .trim();
  if (s.length > maxLen) s = s.slice(0, maxLen).trim();
  return s;
}

function resolveConfig() {
  const raw = (typeof cfg === 'function' ? cfg() : null) || {};
  const out = { ...DEFAULTS };
  for (const k of Object.keys(DEFAULTS)) {
    if (raw[k] !== undefined && raw[k] !== null) out[k] = raw[k];
  }
  return out;
}

function outputsDir(c) { return path.join(String(c.serverDir), 'outputs'); }

async function getJson(c, pathname, timeoutMs) {
  const res = await fetchFn(trimBase(c.serverBase) + pathname, { signal: AbortSignal.timeout(timeoutMs) });
  const text = await res.text();
  let body = null;
  try { body = text ? JSON.parse(text) : null; } catch { body = null; }
  if (!res.ok) {
    const detail = body && typeof body.detail === 'string' ? body.detail : `HTTP ${res.status}`;
    throw new Error(detail);
  }
  return body;
}

function openLogs(c) {
  if (runtime.logFd) return runtime.logFd;
  try {
    runtime.logFd = {
      out: fs.openSync(path.join(String(c.serverDir), 'server.log'), 'a'),
      err: fs.openSync(path.join(String(c.serverDir), 'server.err.log'), 'a')
    };
  } catch {
    runtime.logFd = null;
  }
  return runtime.logFd;
}

/** 拉起服务并轮询到就绪。同一次启动的并发调用共用同一个 promise。 */
function startServer(c) {
  if (runtime.starting) return runtime.starting;
  const script = path.join(String(c.serverDir), 'server.py');
  if (!fs.existsSync(script)) return Promise.reject(new Error(`找不到语音服务脚本：${script}`));

  const run = async () => {
    const logFd = openLogs(c);
    let child;
    try {
      child = spawn(String(c.pythonCmd || 'python'), [script], {
        cwd: String(c.serverDir),
        detached: true,
        stdio: logFd ? ['ignore', logFd.out, logFd.err] : 'ignore',
        windowsHide: true
      });
    } catch (e) {
      throw new Error(`拉起语音服务失败（${c.pythonCmd} ${script}）：${e.message}`);
    }
    runtime.spawnError = null;
    child.on('error', (e) => { runtime.spawnError = e; });
    child.unref();

    const budget = Math.max(5000, Number(c.readyTimeoutMs) || DEFAULTS.readyTimeoutMs);
    const deadline = Date.now() + budget;
    let last = null;
    while (Date.now() < deadline) {
      if (runtime.spawnError) {
        throw new Error(`拉起语音服务失败（${c.pythonCmd}）：${runtime.spawnError.message}`);
      }
      try {
        const st = await getJson(c, '/api/status', 5000);
        if (st && st.model_status === 'error') {
          const fatal = new Error(st.model_error || 'TTS 模型加载失败');
          fatal.fatal = true;
          throw fatal;
        }
        return st;
      } catch (e) {
        if (e && e.fatal) throw e;
        last = e;
      }
      await sleep(1000);
    }
    throw new Error(`语音服务在 ${Math.round(budget / 1000)} 秒内未就绪（${trimBase(c.serverBase)}）${last ? `：${last.message}` : ''}`);
  };

  const p = run();
  runtime.starting = p;
  const reset = () => { if (runtime.starting === p) runtime.starting = null; };
  p.then(reset, reset);
  return p;
}

async function ensureServer(c) {
  try {
    const st = await getJson(c, '/api/status', 5000);
    if (st && st.model_status === 'error') throw new Error(st.model_error || 'TTS 模型加载失败');
    return { status: st, started: false };
  } catch (e) {
    if (c.autoStart === false) {
      throw new Error(`语音服务不可达（${trimBase(c.serverBase)}）：${e.message}。可到技能设置里开启「自动拉起语音服务」，或手动启动它。`);
    }
  }
  return { status: await startServer(c), started: true };
}

async function submitJob(c, spec) {
  const form = new FormData();
  form.set('mode', spec.mode);
  form.set('text', spec.text);
  // 纯克隆：不传风格/情绪控制指令（control 只在回退到内置音色时用于指定音色）
  form.set('control', spec.control || '');
  form.set('cfg_value', String(spec.cfgValue));
  form.set('inference_timesteps', String(spec.timesteps));
  form.set('seed', String(spec.seed ?? 0));
  form.set('normalize', 'false');
  form.set('denoise', 'false');
  form.set('prompt_text', '');
  if (spec.refBuffer && spec.refBuffer.length) {
    form.set('reference', new Blob([spec.refBuffer]), spec.refName || 'reference.mp3');
  }

  const res = await fetchFn(trimBase(c.serverBase) + '/api/generate', {
    method: 'POST',
    body: form,
    signal: AbortSignal.timeout(60000)
  });
  const raw = await res.text();
  let body = null;
  try { body = raw ? JSON.parse(raw) : null; } catch { body = null; }
  if (!res.ok) {
    throw new Error(body && typeof body.detail === 'string' ? body.detail : `HTTP ${res.status}`);
  }
  if (!body || typeof body.job_id !== 'string') throw new Error('语音服务没有返回 job_id');
  return body;
}

async function waitForJob(c, jobId, timeoutMs) {
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    try {
      const history = await getJson(c, '/api/history', 8000);
      const hit = Array.isArray(history) ? history.find((e) => e && e.job_id === jobId) : null;
      if (hit) return hit;
    } catch {
      // 瞬时网络错误交给下一轮轮询
    }
    await sleep(700);
  }
  try {
    await fetchFn(`${trimBase(c.serverBase)}/api/cancel/${encodeURIComponent(jobId)}`, {
      method: 'POST',
      signal: AbortSignal.timeout(5000)
    });
  } catch {
    // 服务已不在或任务已结束，忽略
  }
  throw new Error(`合成超时（${Math.round(timeoutMs / 1000)} 秒）`);
}

/** 取本地 wav；服务不在本机时退回从 /outputs/ 下载。 */
async function resolveWav(c, jobId) {
  const local = path.join(outputsDir(c), `${jobId}.wav`);
  if (fs.existsSync(local)) return local;
  const url = `${trimBase(c.serverBase)}/outputs/${encodeURIComponent(jobId)}.wav`;
  try {
    const res = await fetchFn(url, { signal: AbortSignal.timeout(30000) });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const buf = Buffer.from(await res.arrayBuffer());
    fs.mkdirSync(outputsDir(c), { recursive: true });
    fs.writeFileSync(local, buf);
    return local;
  } catch (e) {
    throw new Error(`合成成功但找不到语音文件（${local}），下载也失败：${e.message}。可到技能设置里核对「语音服务目录」。`);
  }
}

function pruneOutputs(c) {
  const keep = Number(c.keepOutputs) || 0;
  if (keep <= 0) return;
  try {
    const dir = outputsDir(c);
    const files = fs.readdirSync(dir)
      .filter((f) => f.endsWith('.wav'))
      .map((f) => ({ f, t: fs.statSync(path.join(dir, f)).mtimeMs }))
      .sort((a, b) => b.t - a.t);
    for (const item of files.slice(keep)) {
      try { fs.unlinkSync(path.join(dir, item.f)); } catch { /* 删不掉不影响发送 */ }
    }
  } catch {
    // 清理失败不影响主流程
  }
}

/**
 * 纯合成：解析配置 → 确保服务 → 提交任务 → 等待完成 → 返回本地 wav 路径。
 * 不发送、不发进度提示，供 voice_speak 工具与 'ai-voice.synthesize' 能力共用。
 */
async function synthesize(c, text) {
  if (typeof fetchFn !== 'function') {
    throw new Error('缺少网络能力（web_fetch 权限未声明），无法调用语音服务。');
  }
  const ref = String(c.referenceAudio || '').trim();
  let mode = 'design';
  let control = '';
  let refBuffer = null;
  let refName = '';
  if (ref && fs.existsSync(ref)) {
    try {
      refBuffer = fs.readFileSync(ref);
      refName = path.basename(ref);
      mode = 'clone';
    } catch (e) {
      if (c.fallbackToDesign === false) throw new Error(`读取参考音频失败：${e.message}`);
    }
  } else if (ref && c.fallbackToDesign === false) {
    throw new Error(`参考音频不存在：${ref}。请到技能设置里改「参考音频」路径。`);
  }
  if (mode === 'design') control = String(c.fallbackVoice || DEFAULTS.fallbackVoice).trim();
  // clone 模式：只加固定风格提示（标点停顿处的吐气声），不额外描述音色/情绪
  if (mode === 'clone') control = cleanHint(c.styleHint);

  const startedAt = Date.now();
  const ready = await ensureServer(c);

  const job = await submitJob(c, {
    text,
    mode,
    control,
    refBuffer,
    refName,
    cfgValue: Number(c.cfgValue) || DEFAULTS.cfgValue,
    seed: Math.max(0, Math.trunc(Number(c.seed) || 0)),
    timesteps: Math.min(100, Math.max(1, Math.trunc(Number(c.inferenceTimesteps) || DEFAULTS.inferenceTimesteps)))
  });

  const entry = await waitForJob(c, job.job_id, Math.max(1000, Number(c.jobTimeoutMs) || DEFAULTS.jobTimeoutMs));
  if (entry.status === 'error') throw new Error(entry.error || '语音合成失败');
  if (entry.status === 'cancelled') throw new Error('语音任务被取消');

  const wav = await resolveWav(c, job.job_id);
  return { wav, jobId: job.job_id, mode, control, started: ready.started, elapsed: (Date.now() - startedAt) / 1000 };
}

/** 供其它技能/插件调用的能力实现（reminder 插件用它「提前合成定时语音」）。 */
export const providers = {
  'ai-voice.synthesize': async (args = {}) => {
    const c = resolveConfig();
    const text = String(args?.text ?? '').trim();
    if (!text) throw new Error('要合成的文本为空');
    const max = Math.max(10, Number(c.maxChars) || DEFAULTS.maxChars);
    if (text.length > max) {
      throw new Error(`文本 ${text.length} 字，超过单条语音上限 ${max} 字`);
    }
    const r = await synthesize(c, text);
    pruneOutputs(c);
    return {
      file: r.wav,
      job_id: r.jobId,
      mode: r.mode,
      chars: text.length,
      elapsed_sec: Math.round(r.elapsed * 10) / 10
    };
  }
};

export function available() {
  const c = resolveConfig();
  const script = path.join(String(c.serverDir), 'server.py');
  if (!fs.existsSync(script)) {
    return { ok: false, reason: `找不到语音服务脚本：${script}。请到技能设置里改「语音服务目录」。` };
  }
  const ref = String(c.referenceAudio || '').trim();
  if (ref && !fs.existsSync(ref) && c.fallbackToDesign === false) {
    return { ok: false, reason: `参考音频不存在：${ref}。请到技能设置里改「参考音频」路径。` };
  }
  return { ok: true };
}

export function setup(api) {
  cfg = api.config;
  fetchFn = typeof api.fetch === 'function' ? api.fetch : null;

  api.registerTool({
    id: 'voice_speak',
    name: '发语音',
    description: '把一句话用本机参考音频克隆出的音色合成语音（标点停顿处自带轻柔吐气声），直接发到当前会话，群友听到的就是这条语音。只在用户明确要求语音（「用语音说」「念给我听」「发个语音」）时调用；text 必须是口语化的一句话、越短越好，调用前自己压到字数上限以内。不要自己添加任何语气/风格描述，音色与语气完全跟随参考音频。语音发出后不要再用文字把这句复述一遍；还有补充就等语音发完后用简短文字说。合成要等 30~90 秒，工具会先发一句进度提示，不要重复调用。',
    category: 'media',
    icon: '🔊',
    parameters: {
      type: 'object',
      properties: {
        text: { type: 'string', description: '要说出来的那句话，口语化、不带表情和 markdown，一个字数上限以内' }
      },
      required: ['text']
    },
    async execute(ctx, args) {
      try {
        const c = resolveConfig();
        const text = String(args?.text ?? '').trim();
        if (!text) return err('要合成的文本为空，请给出要说的一句话');
        const max = Math.max(10, Number(c.maxChars) || DEFAULTS.maxChars);
        if (text.length > max) {
          return err(`文本 ${text.length} 字，超过单条语音上限 ${max} 字。请把内容压成一句 ${max} 字以内的口语再调用本工具；不要拆成多条连发，也不要改用文字回复。`);
        }
        if (typeof fetchFn !== 'function') {
          return err('缺少网络能力（web_fetch 权限未声明），无法调用语音服务。');
        }

        if (c.notifyStart !== false) {
          const hint = '🎙 正在合成语音，稍等…';
          try {
            await ctx.sender.sendTextBatch(ctx.chatKey, [hint]);
            ctx.session?.sent?.push({ type: 'text', text: hint, at: nowText() });
          } catch (e) {
            api.warn(`进度提示没发出去（不影响合成）：${e.message}`);
          }
        }

        const { wav, jobId, mode, control, started, elapsed } = await synthesize(c, text);
        if (started) api.log('本轮自动拉起了语音服务');
        pruneOutputs(c);

        await ctx.sender.sendMedia(ctx.chatKey, [{ type: 'record', data: { file: wav } }], {
          label: '[语音]',
          dedupeKey: `tts:${jobId}`
        });
        ctx.session?.sent?.push({ type: 'voice', text: '[语音]', at: nowText() });
        try { ctx.emit?.('session-update', ctx.session?.id); } catch { /* 上报失败不影响已发出的语音 */ }

        const secs = Math.round(elapsed * 10) / 10;
        api.log(`合成并发送语音 ${text.length} 字，用时 ${secs}s（${mode}${control ? `｜提示：${control}` : ''}）`);
        return ok({
          sent: true,
          elapsed_sec: secs,
          chars: text.length,
          mode,
          style_hint: control,
          file: wav,
          note: '语音已发出。不要再用文字把这句复述一遍；还有补充内容就等它播完后用一句话简短说。'
        });
      } catch (error) {
        return err(error?.message ?? String(error));
      }
    }
  });
}
