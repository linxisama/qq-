// 梗百科（meme-wiki）—— 把「查梗」直接接到垂直源，绕开通用搜索引擎的噪音。
//
// ── 为什么需要它 ──────────────────────────────────────────────────────────
// 本机 webSearch.provider = "deepseek"，走的是 DeepSeek 自家的联网搜索：
// 黑盒 —— 不能限定站点、不能指定引擎。问「这啥梗」时它返回通用网页结果，
// 梗的准确含义常被稀释在一堆无关页面里。
//
// 而萌娘百科（ACG / 网络梗最权威的 wiki）本身有**可匿名调用**的 API：
//   action=opensearch              按关键词找到词条标题
//   action=query&prop=extracts     取整个词条的纯文本正文
// 本技能把这两步串成一条工具，只把「正文摘要」交给模型。
//
// ── 实测（2026-10-11，本机直连）哪些路能用 ────────────────────────────────
//   ✅ zh.moegirl.org.cn  action=opensearch                      813ms
//   ✅ zh.moegirl.org.cn  action=query&prop=extracts   1303ms / 122KB   ← 关键
//   ✅ moegirl.uk         action=opensearch                     1104ms   ← 后备镜像
//   ❌ action=parse / prop=revisions / index.php?action=raw → "Unauthorized API call"
//   ❌ /rest.php/v1/search/page                             → Cloudflare "Just a moment"
//   ❌ 百度百科 / 百度贴吧 403（安全验证）｜微博热搜 403｜知乎 400
//   ❌ 中文维基 / THBWiki 超时｜小鸡词典证书过期（已停运）
//   ⚠️ B站视频搜索偶发 412 风控，所以本技能只用 B站的**热搜榜**与**热门榜**（实测稳定）
// 结论：只依赖上面那三条能用的路，连不上的不做无谓重试。
//
// ── 为什么是技能（skills/）而不是插件（plugins/） ──────────────────────────
// 它要注册**模型可见的工具** —— 加载器只把 registerTool 注册的工具放进 function 列表。
// 「什么时候该查梗」没有能写死的触发条件，只能由模型判断，所以属于技能。
//
// ── 截断是必需的，不是优化 ────────────────────────────────────────────────
// 实测「原神/用语与梗」一个词条的正文就有 12 万字。不截断的话，一次工具调用
// 能把上下文直接塞满（既贵又会让模型抓不住重点）。所以默认只取前 1000 字。
//
// ⚠️ 本文件在 resources/app 里，应用自动更新会覆盖。本技能不写任何状态文件，
//    覆盖后重装即可（技能清单与代码都在，没有需要保留的数据）。
//
// ⚠️ 顺带一提：QQ Agent 的转发展开里有 body.slice(0, 200) 这类"按字符数截断"，
//    会把 emoji 的代理对从中间切开，产生孤立代理项 → API 400 整轮失败
//    （已另修）。这里凡是要截断文本，一律用下面的 safeSlice()。

const HOSTS = ['zh.moegirl.org.cn', 'moegirl.uk'];   // 主站 → 镜像，主站抽风时自动换

const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
  + '(KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36';

const BILI_HEADERS = {
  'user-agent': UA,
  referer: 'https://www.bilibili.com/',
  accept: 'application/json, text/plain, */*',
  'accept-language': 'zh-CN,zh;q=0.9',
};

let cfg = () => ({});
const clamp = (n, lo, hi) => Math.min(hi, Math.max(lo, Math.round(Number(n) || lo)));

/**
 * 代理对安全截断。按字符数硬切会把 emoji 的两个 UTF-16 代理项切开，
 * 剩下"半个字符"（孤立代理项）—— DeepSeek 的 serde_json 会因此报
 * "unexpected end of hex escape" 并让**整轮请求**失败。所以宁可少一个字。
 */
function safeSlice(s, n) {
  const t = String(s ?? '');
  if (t.length <= n) return t;
  return t.slice(0, n).replace(/[\uD800-\uDBFF]$/, '');
}

/**
 * 把群友的自然语言问法削成词条名。
 * 「鸡你太美是什么梗？」→「鸡你太美」；「原神的梗」→「原神」
 * 不做这一步的话，opensearch 拿整句话去匹配，命中率会明显下降。
 */
function cleanTerm(raw) {
  let t = String(raw ?? '').trim();
  // 反复剥离直到稳定 —— 单趟处理不了「「尊嘟假嘟」啥意思」这种：
  // 末尾的「啥意思」去掉之后，才会露出被引号包住的两端。
  for (let i = 0; i < 4; i++) {
    const before = t;
    t = t.replace(/^[「『"'“”‘’【\[（(]+/, '').replace(/[」』"'“”‘’】\]）)]+$/, '').trim();
    t = t.replace(/[?？。！!，,、；;~～\s]+$/g, '');
    t = t.replace(/(是什么梗|是啥梗|什么梗|啥梗|什么意思|是啥意思|啥意思|这个梗|那个梗|的梗|梗是什么)$/g, '').trim();
    if (t === before) break;
  }
  return t || String(raw ?? '').trim();
}

async function getJson(url, timeoutMs, headers = {}) {
  const res = await fetch(url, {
    headers: {
      'user-agent': UA,
      accept: 'application/json, text/plain, */*',
      'accept-language': 'zh-CN,zh;q=0.9',
      ...headers,
    },
    signal: AbortSignal.timeout(timeoutMs),
  });
  const text = await res.text();
  let json;
  try { json = JSON.parse(text); } catch {
    throw new Error(`返回不是 JSON（HTTP ${res.status}）：${text.slice(0, 80).replace(/\s+/g, ' ')}`);
  }
  // 萌娘百科会把「这个 action 不给匿名用」包在 HTTP 200 里返回，必须显式识别
  if (json?.error) throw new Error(`${json.error.code || 'api-error'}：${json.error.info || ''}`);
  return json;
}

/* ── 萌娘百科：找词条 ─────────────────────────────────────────────────── */

/**
 * action=opensearch → [查询词, [标题...], [描述...], [链接...]]
 * 它是唯一可匿名调用的"搜索"入口（list=search 与 action=parse 都被拒）。
 */
async function openSearch(host, term, limit, timeoutMs) {
  const url = `https://${host}/api.php?action=opensearch`
    + `&search=${encodeURIComponent(term)}&limit=${clamp(limit, 1, 10)}&format=json`;
  const j = await getJson(url, timeoutMs);
  const titles = Array.isArray(j?.[1]) ? j[1] : [];
  const urls = Array.isArray(j?.[3]) ? j[3] : [];
  return titles.map((t, i) => ({
    title: String(t),
    url: String(urls[i] || `https://${host}/wiki/${encodeURIComponent(String(t))}`),
  }));
}

/* ── 萌娘百科：取正文 ─────────────────────────────────────────────────── */

/**
 * action=query&prop=extracts&explaintext=1 → 词条纯文本正文（已去 wiki 标记）。
 * formatversion=2 让 pages 变成数组（v1 是对象），处理起来更直白。
 */
async function extractText(host, titles, timeoutMs) {
  const url = `https://${host}/api.php?action=query&prop=extracts&explaintext=1`
    + `&exlimit=max`   // ⚠️ 必须显式给：prop=extracts 的默认 exlimit=1，只返回第一个词条的正文
    + `&redirects=1&format=json&formatversion=2`
    + `&titles=${encodeURIComponent(titles.join('|'))}`;
  const j = await getJson(url, timeoutMs);
  const pages = Array.isArray(j?.query?.pages) ? j.query.pages : [];
  return pages
    .filter((p) => p && !p.missing && p.extract)
    .map((p) => ({ title: String(p.title || ''), text: String(p.extract) }));
}

/** 找词条并取正文；主站失败自动换镜像。返回 { host, entries } 或抛错。 */
async function lookup(term, { maxEntries, summaryChars, timeoutMs }) {
  const errors = [];
  for (const host of HOSTS) {
    let hits = [];
    try {
      hits = await openSearch(host, term, Math.max(3, maxEntries), timeoutMs);
    } catch (error) {
      errors.push(`${host} 找词条失败：${error?.message ?? error}`);
      continue;
    }
    if (!hits.length) { errors.push(`${host} 没有匹配的词条`); continue; }

    // 只取前 N 个词条的正文（第一个通常最相关，正文也最长）
    const picked = hits.slice(0, clamp(maxEntries, 1, 3));
    let texts = [];
    try {
      texts = await extractText(host, picked.map((h) => h.title), timeoutMs);
    } catch (error) {
      errors.push(`${host} 取正文失败：${error?.message ?? error}`);
      // 正文取不到时，至少把标题还给模型（标题本身常常就说明了是什么）
      return { host, entries: picked.map((h) => ({ title: h.title, url: h.url, text: '' })), titlesOnly: true };
    }
    // 标题匹配要容忍重定向与下划线：请求「丁真」时返回的 title 可能已被规范化，
    // 直接按原字符串查会落空 —— 表现为"找到了词条，但正文 0 字"。
    const norm = (s) => String(s ?? '').replace(/_/g, ' ').trim().toLowerCase();
    const byTitle = new Map(texts.map((t) => [norm(t.title), t.text]));
    const entries = picked.map((h) => ({
      title: h.title,
      url: h.url,
      // 兜底：只请求了一个词条、也只回来一个页面时，直接用那一个，不必纠结标题是否完全一致
      text: safeSlice(
        byTitle.get(norm(h.title))
        ?? (picked.length === 1 && texts.length === 1 ? texts[0].text : '')
        ?? '',
        summaryChars),
      more: hits.length > picked.length ? hits.slice(picked.length, picked.length + 5).map((x) => x.title) : [],
    }));
    return { host, entries, titlesOnly: false };
  }
  throw new Error(errors.join('；') || '萌娘百科没有响应');
}

/* ── B站：当下热点 ────────────────────────────────────────────────────── */

/** 热搜榜（api.bilibili.com/x/web-interface/search/square） */
async function biliHotSearch(limit, timeoutMs) {
  const j = await getJson(
    'https://api.bilibili.com/x/web-interface/search/square?limit=' + clamp(limit, 1, 30),
    timeoutMs, BILI_HEADERS);
  const list = j?.data?.trending?.list || [];
  return list.map((x) => String(x.keyword || x.show_name || '')).filter(Boolean);
}

/** 热门视频榜（api.bilibili.com/x/web-interface/popular） */
async function biliPopular(limit, timeoutMs) {
  const j = await getJson(
    `https://api.bilibili.com/x/web-interface/popular?ps=${clamp(limit, 1, 20)}&pn=1`,
    timeoutMs, BILI_HEADERS);
  const list = j?.data?.list || [];
  return list.map((x) => ({
    title: String(x.title || ''),
    up: String(x.owner?.name || ''),
    bvid: String(x.bvid || ''),
    view: Number(x.stat?.view || 0),
  })).filter((x) => x.title);
}

/* ── 工具注册 ─────────────────────────────────────────────────────────── */

export function setup(api) {
  if (typeof api?.config === 'function') {
    const getCfg = api.config;
    cfg = () => { try { return getCfg() || {}; } catch { return {}; } };
  }
  if (typeof api?.registerTool !== 'function') return;

  const opts = () => {
    const c = cfg() || {};
    return {
      maxEntries: clamp(c.maxEntries ?? 2, 1, 3),
      summaryChars: clamp(c.summaryChars ?? 1000, 200, 4000),
      hotLimit: clamp(c.hotLimit ?? 12, 3, 30),
      timeoutMs: clamp(c.timeoutMs ?? 15000, 3000, 60000),
    };
  };

  api.registerTool({
    id: 'wiki',
    name: '查梗百科',
    description: '查一个梗/网络词/二创梗到底是什么意思。直连萌娘百科（ACG 与网络梗最权威的 wiki），返回词条正文摘要 —— 比其他搜索更准、不受通用搜索结果干扰。'
      + '用法：wiki("鸡你太美")、wiki("尊嘟假嘟")、wiki("原神 用语与梗")。传梗本身即可，不用写成问句。'
      + '本地梗库（查网络梗）没有命中时优先用它。',
    category: 'knowledge',
    icon: '📖',
    parameters: {
      type: 'object',
      properties: {
        term: { type: 'string', description: '要查的梗或词，例如「鸡你太美」「尊嘟假嘟」「丁真」' },
      },
      required: ['term'],
    },
    async execute(_ctx, args) {
      const o = opts();
      const raw = String(args?.term ?? '').trim();
      if (!raw) return { content: 'term 不能为空。', isError: true };
      const term = cleanTerm(raw);

      let result;
      try {
        result = await lookup(term, o);
      } catch (error) {
        return {
          content: `梗百科没查到「${term}」：${String(error?.message ?? error).slice(0, 200)}`
            + '\n（萌娘百科以 ACG/二次元梗为主，三次元时事梗可能没有 —— 可以先试「当下热梗」看它是不是热点，'
            + '仍然查不到就如实说「这梗我不太确定」，别硬猜。）',
          isError: true,
        };
      }

      const head = `梗百科（${result.host}）查「${term}」：`;
      if (result.titlesOnly) {
        const names = result.entries.map((e) => e.title);
        return {
          content: `${head}\n命中词条：${names.join(' / ')}\n（词条找到了，但正文这次没取到 —— 可以按词条名直接回答，或如实说不太确定，别硬编内容。）`,
        };
      }

      const blocks = result.entries.map((e) => {
        const more = e.more?.length ? `\n（其他相关词条：${e.more.join(' / ')}）` : '';
        const body = e.text
          ? e.text.replace(/\n{2,}/g, '\n').trim()
          : '（这个词条没有正文内容）';
        return `【${e.title}】\n${body}${more}`;
      });

      return {
        content: `${head}\n\n${blocks.join('\n\n')}\n\n`
          + '（以上是萌娘百科词条正文的节选 —— 通用联网搜索已关闭，这就是查梗的权威来源。回答时用你自己的话概括「什么意思 + 什么场合用」，'
          + '别整段念出来，也别报出处——除非有人问。）',
      };
    },
  });

  api.registerTool({
    id: 'hot',
    name: '当下热梗',
    description: '看现在网上在流行什么：B站热搜词 + B站热门视频榜。'
      + '用在「最近有什么新梗」「群里说的这个是不是热点」「接不上话想看看现在大家在聊什么」的场合。'
      + '注意：它给的是**当下热点**，不是某个具体梗的解释——解释某个梗请用「查梗百科」。',
    category: 'knowledge',
    icon: '🔥',
    parameters: { type: 'object', properties: {} },
    async execute() {
      const o = opts();
      const [hot, popular] = await Promise.allSettled([
        biliHotSearch(o.hotLimit, o.timeoutMs),
        biliPopular(Math.min(o.hotLimit, 12), o.timeoutMs),
      ]);

      const lines = [];
      if (hot.status === 'fulfilled' && hot.value.length) {
        lines.push(`【B站热搜】${hot.value.join(' ｜ ')}`);
      } else {
        lines.push(`【B站热搜】取不到（${String(hot.reason?.message ?? hot.reason ?? '未知原因').slice(0, 80)}）`);
      }
      if (popular.status === 'fulfilled' && popular.value.length) {
        const top = popular.value.map((x) => {
          const v = x.view >= 10000 ? `${(x.view / 10000).toFixed(1)}万` : String(x.view);
          return `· ${x.title}（UP：${x.up}，${v} 播放）`;
        });
        lines.push(`【B站热门视频】\n${top.join('\n')}`);
      } else {
        lines.push(`【B站热门视频】取不到（${String(popular.reason?.message ?? popular.reason ?? '未知原因').slice(0, 80)}）`);
      }

      return {
        content: `${lines.join('\n\n')}\n\n（这些是当下的热点，可以直接拿来聊天；`
          + '但要聊具体的梗是什么意思，先用「查梗百科」查清楚，别硬猜。）',
      };
    },
  });

  if (typeof api.log === 'function') {
    api.log('已加载：2 个工具（查梗百科 wiki / 当下热梗 hot，萌娘百科 + B站）');
  }
}

export function available() { return { ok: true }; }

/** 自测用：不注册工具也能直接调这些。 */
export const internals = {
  cleanTerm, safeSlice, openSearch, extractText, lookup, biliHotSearch, biliPopular, HOSTS,
};
