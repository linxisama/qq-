/**
 * item-slot-value · 三角洲·物品单格价值（orzice.com/v/item_jz）
 *
 * 用户要的东西很具体：**五级**的「航天冷却剂」「盒装挂耳咖啡」「移动电缆」「可编程处理器」的单格价值
 * （分别占 2 / 2 / 4 / 1 格）。页面上的字段（2026-10 在页面的 Vue 实例里实测确认）：
 *   name 物品名 · grade 品质级(1~6) · wh 占几格 · dgjz 单格价值 · price 当前价格
 * 实测校验：**dgjz = floor(price / wh)**（站点是"按整件价格除以格数、向下取整"算单格价值的）：
 *   450,548 ÷ 2 = 225,274；372,637 ÷ 2 = 186,318.5 → 186,318；242,991 ÷ 4 = 60,747.75 → 60,747；
 *   1,653,136 ÷ 12 = 137,761.33 → 137,761。
 * ⚠️ 一开始我以为反过来（单格价值 × 格数 = 整件价格）—— 前两件正好整除所以看着成立，
 *    多做几件就露了（60,747 × 4 = 242,988 ≠ 242,991）。所以发出去的数字一律照抄页面，
 *    校验只用来"发现站点改了算法"，不要拿它反推价格。
 *
 * 页面是 Vue 在客户端渲染的（HTML 里只有 {{item.name}} 这种模板），数据来自
 *   GET /api/xtc/item_jz_list?a=[1..6]&top=0&p=1&n=<名字>&token=…&timestamp=…
 * 逐条实测出来的坑（都验证过，别凭感觉改）：
 *   · **必须登录**。匿名请求（不管什么 UA）一律 `{"code":400,"message":"请登录账号！才可以使用功能！"}`，
 *     页面自己也只在登录后才渲染出数据（未登录的浏览器配置里 AppDataVue.data 一直是空的）。
 *   · `n` 不是"每页条数"，是**名字筛选**（传 n=500 会返回 count 0）。所以查指定物品一次请求就够，
 *     不用翻 379 条里的 38 页。
 *   · 不传 n 时一页只给 10 条（count 是总数 379），按单格价值从高到低排。
 *   · 带登录 Cookie 的**直连**请求是通的（实测 HTTP 200 + code 0 + 解开密文），
 *     但会间歇性吃 403（站点防抓取），所以直连只当备用通道、并且要退避。
 *   · 请求头：只有 jsdom/30.1.2 那个 UA + Accept + Referer 稳定不被 403；
 *     自称 Chrome/curl/node-fetch 或没有 UA 一律被拦。
 *
 * 取数走**两条通道**：
 *   ① 页面通道（默认）：无头 Edge/Chrome 打开 /v/item_jz，把名字填进页面的筛选框（AppDataVue.n）
 *      再调它自己的 getData()，然后读它渲染出来的 data —— 签名、加密、登录态全交给页面自己。
 *      这样既不用维护那套签名/解密，也不会被"程序化请求"拦。
 *   ② 直连接口（备用）：自己签名 + AES 解密（和特勤处技能同一套算法），需要设置里填登录凭证。
 *
 * 登录态：本技能**只读你已有的登录**，不做任何自动化登录操作。
 *   · 第一次使用会从「特勤处制造排名」技能那份已经登录好的浏览器配置里，只拷
 *     `Local State` + `Default/Network/Cookies` 两样到本技能自己的配置目录（各技能用各自的目录，
 *     免得两个技能同时开浏览器时抢同一个配置锁）。只拷一次，之后用自己这份。
 *   · 拷不到（那份不存在/没登过）就退化成一次有窗口的 QQ 一键登录：这时屏幕左上角会闪一个
 *     小窗，机器上 QQ 处于登录状态时会自动完成，不用扫码输入。
 */
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { spawn, execFile } from 'node:child_process';
import { promisify } from 'node:util';
import { fileURLToPath } from 'node:url';

const SITE = 'https://orzice.com';
const PAGE_PATH = '/v/item_jz';
const API_PATH = '/api/xtc/item_jz_list';

// 参与签名的后缀（与解密明文前缀是两回事，见特勤处技能的文件头）
const SIGN_SUFFIX = '私自使用，后果自负！我方保留起诉权利！';
const DATA_PREFIX = '非法侵入计算机信息系统罪,我方公司保留报警和起诉权利';
// 站点把 Base64 里这些字符替换成了带 | 的短串（原字符 → 替换串）。6 和 7 没被替换。
const SUBST = [
  ['=', '*|'],
  ['1', 'aa|a'],
  ['2', 'ab|a'],
  ['3', 'ba|a'],
  ['4', 't|tc'],
  ['5', 't|ts'],
  ['8', 'r|oq'],
  ['9', 'f|oz'],
  ['0', 'j|rz']
];
// 唯一稳定过 WAF 的标识（实测），别乱改
const DEFAULT_UA = 'Mozilla/5.0 (win32) AppleWebKit/537.36 (KHTML, like Gecko) jsdom/30.1.2';

// 用户点名的四件（都是 5 级）——用户没点名时查这四个
const DEFAULT_ITEMS = ['航天冷却剂', '盒装挂耳咖啡', '移动电缆', '可编程处理器'];
const MAX_ITEMS = 8;                 // 一次最多查几个名字（防模型一次传一长串）

// ── 运行时状态 ──────────────────────────────────────────────────────────
let cfg = () => ({});
let httpFetch = null;
let logger = { log: () => {}, warn: () => {}, error: () => {} };

let stateDir = null;                 // <数据目录>/item-slot-value
let dataRoot = null;                 // <数据目录>
let mem = null;   // 已废弃（改用落盘的 diskCache）——留着只是怕别处引用
let fetchTimes = [];                 // 最近一小时内真正联网抓取的时刻
let blockedUntil = 0;
let blockedNote = '';
let blockCount = 0;                  // 连续被拦次数：用来做递增冷却，保护站点额度

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
function clamp(n, lo, hi, dflt) {
  const v = Number(n);
  if (!Number.isFinite(v)) return dflt;
  return Math.min(hi, Math.max(lo, Math.round(v)));
}
/** 225274 → "225,274"（照抄数字、不做单位换算：群里看到的和页面上一致） */
function fmtInt(n) {
  const v = Number(n);
  if (!Number.isFinite(v)) return String(n ?? '—');
  return v.toLocaleString('en-US');
}
function nowText(ts = Date.now()) {
  return new Date(ts).toLocaleString('zh-CN', { hour12: false });
}
function agoText(ts) {
  const s = Math.max(0, Math.round((Date.now() - ts) / 1000));
  if (s < 60) return `${s} 秒前`;
  if (s < 3600) return `${Math.round(s / 60)} 分钟前`;
  if (s < 86400) return `${Math.round(s / 3600)} 小时前`;
  return `${Math.round(s / 86400)} 天前`;
}
/** 把模型给的 items 参数收拾成干净的名字数组。 */
function parseNames(raw) {
  const list = Array.isArray(raw) ? raw : String(raw ?? '').split(/[,，、;；\n]+/);
  const out = [];
  for (const x of list) {
    const s = String(x ?? '').trim();
    if (s && !out.includes(s)) out.push(s);
  }
  return out.slice(0, MAX_ITEMS);
}

// ── 冷却与频率闸 ────────────────────────────────────────────────────────
function nextCooldownMs(baseMs) {
  blockCount = Math.min(blockCount + 1, 6);
  return Math.min(baseMs * Math.pow(2, blockCount - 1), 120 * 60000);
}
function noteBlocked(reason, cooldownMs) {
  blockedUntil = Date.now() + cooldownMs;
  blockedNote = reason;
  logger.warn('item-slot-value: 被数据源拒绝，冷却 %s 分钟：%s', Math.round(cooldownMs / 60000), reason);
}
function noteSuccess() {
  blockCount = 0;
  blockedUntil = 0;
  blockedNote = '';
}
function throttle(maxPerHour) {
  const now = Date.now();
  fetchTimes = fetchTimes.filter((t) => now - t < 3600000);
  return fetchTimes.length >= maxPerHour;
}

// ── 直连通道：签名 / 解密 / 请求 ────────────────────────────────────────
const md5Hex = (s) => crypto.createHash('md5').update(String(s), 'utf8').digest('hex');
/** token = md5(timestamp + md5(参数串 + timestamp + AC) + 签名后缀) */
function signToken(paramString, ts, ac) {
  return md5Hex(String(ts) + md5Hex(String(paramString) + String(ts) + String(ac)) + SIGN_SUFFIX);
}
function parseCreds(html) {
  const pick = (name) => {
    const m = String(html).match(new RegExp(`var\\s+${name}\\s*=\\s*"([^"]*)"`));
    return m ? m[1] : null;
  };
  const tsMatch = String(html).match(/TimeUnix\s*=\s*(\d{9,12})/);
  const creds = { timeUnix: tsMatch ? Number(tsMatch[1]) : null, aa: pick('AA'), ab: pick('AB'), ac: pick('AC') };
  if (!creds.timeUnix || !creds.aa || !creds.ab || !creds.ac) return { error: '页面里没找到 TimeUnix/AA/AB/AC（站点可能改版了）' };
  return { creds };
}
/** 站点自己的算法：TimeUnix + 已过去秒数（直接拿 HTML 里那个值去签名会被判过期） */
function serverNow(creds, fetchedAt) {
  const elapsed = Math.max(0, Math.round((Date.now() - fetchedAt) / 1000));
  return String(creds.timeUnix + Math.min(elapsed, 3600));
}
/** AES-256-CBC → 去前缀 → 还原替换符 → Base64 → JSON */
function decryptData(dataB64, creds) {
  const key = Buffer.from(creds.aa, 'utf8');
  const iv = Buffer.from(String(creds.ab).padEnd(16, '\0').slice(0, 16), 'utf8');
  const decipher = crypto.createDecipheriv('aes-256-cbc', key, iv);
  const plain = Buffer.concat([decipher.update(Buffer.from(String(dataB64), 'base64')), decipher.final()]).toString('utf8');
  let body = plain.startsWith(DATA_PREFIX) ? plain.slice(DATA_PREFIX.length) : plain;
  for (const [orig, junk] of SUBST) if (body.includes(junk)) body = body.split(junk).join(orig);
  const text = Buffer.from(body, 'base64').toString('utf8');
  if (!text.trim()) return { items: [], empty: true };
  const json = JSON.parse(text);
  const list = Array.isArray(json) ? json : (Array.isArray(json?.data) ? json.data : null);
  if (!list) return { error: '解密出来了但结构不是数组（站点可能改版了）' };
  return { items: list, count: json?.count };
}

async function httpGet(url, { timeoutMs, accept, cookie, ua, retry = 1 } = {}) {
  const attempt = async () => {
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), timeoutMs);
    try {
      const res = await httpFetch(url, {
        method: 'GET',
        signal: ctrl.signal,
        redirect: 'follow',
        headers: {
          'User-Agent': ua || DEFAULT_UA,
          Accept: accept,
          // Referer 不是礼貌问题，是必需项：实测去掉就 403
          Referer: `${SITE}${PAGE_PATH}`,
          ...(cookie ? { Cookie: cookie } : {})
        }
      });
      const body = await res.text();
      if (res.status === 403 || res.status === 429) return { error: `HTTP ${res.status}（被站点防抓取规则拦下）`, status: res.status, blocked: true };
      if (!res.ok) return { error: `HTTP ${res.status}`, status: res.status };
      if (!body) return { error: '空响应', transient: true };
      return { text: body };
    } catch (e) {
      const msg = e?.name === 'AbortError' ? `超时（${timeoutMs}ms）` : (e?.message ?? String(e));
      return { error: `网络失败：${msg}`, transient: true };
    } finally {
      clearTimeout(timer);
    }
  };
  let out = await attempt();
  if (out.transient && retry > 0) {
    await sleep(800);
    out = await attempt();
  }
  return out;
}

/** 直连通道：抓页面拿签名参数 → 按名字查（n=名字）→ 解密。 */
async function httpQuery(names, grade, { timeoutMs, cookie, ua }) {
  const page = await httpGet(`${SITE}${PAGE_PATH}`, { timeoutMs, accept: 'text/html,application/xhtml+xml', cookie, ua });
  if (page.error) return page;
  const parsed = parseCreds(page.text);
  if (parsed.error) return parsed;
  const creds = parsed.creds;
  const fetchedAt = Date.now();
  const grades = grade ? `[${grade}]` : '[1,2,3,4,5,6]';
  const byName = {};
  for (const name of names) {
    const paramString = `a=${grades}&top=0&p=1&n=${encodeURIComponent(name)}`;
    const ts = serverNow(creds, fetchedAt);
    const url = `${SITE}${API_PATH}?${paramString}&token=${signToken(paramString, ts, creds.ac)}&timestamp=${ts}`;
    const r = await httpGet(url, { timeoutMs, accept: 'application/json, text/plain, */*', cookie, ua });
    if (r.error) return r;
    let json = null;
    try { json = JSON.parse(r.text); } catch (e) { return { error: `接口返回的不是合法 JSON：${e.message}` }; }
    if (json?.code !== 0) {
      const msg = String(json?.message || json?.msg || '').trim();
      const throttled = /登录|频繁|限制|稍后|太快|过多/.test(msg);
      return { error: msg ? `数据源拒绝：${msg}` : `数据源拒绝：code=${json?.code}`, blocked: throttled, throttled };
    }
    if (!json?.data) { byName[name] = []; continue; }
    let dec;
    try { dec = decryptData(json.data, creds); } catch (e) { return { error: `解密失败：${e.message}（站点可能升级了加密方式）` }; }
    if (dec.error) return { error: dec.error };
    byName[name] = (dec.items || []).map((x) => ({
      name: String(x?.name ?? ''), grade: Number(x?.grade) || 0, wh: Number(x?.wh) || 0,
      dgjz: Number(x?.dgjz), price: Number(x?.price)
    }));
    await sleep(500);   // 直连是"备用通道"，更要客气点，别连着打
  }
  return { byName, channel: 'http', fetchedAt };
}

// ── 浏览器通道 ──────────────────────────────────────────────────────────
const BROWSER_EXE_CANDIDATES = [
  path.join(process.env['ProgramFiles(x86)'] || '', 'Microsoft/Edge/Application/msedge.exe'),
  path.join(process.env['ProgramFiles'] || '', 'Microsoft/Edge/Application/msedge.exe'),
  path.join(process.env['ProgramFiles'] || '', 'Google/Chrome/Application/chrome.exe'),
  path.join(process.env['ProgramFiles(x86)'] || '', 'Google/Chrome/Application/chrome.exe'),
  path.join(process.env.LOCALAPPDATA || '', 'Google/Chrome/Application/chrome.exe')
];

let br = null;             // 常驻浏览器：{ proc, port, exe, headless }
let brWarmTimer = null;
let brProfileDir = null;
let brKnownLoggedIn = null; // 进程内已知的登录状态：null=还不知道
let brLockFile = null;      // 记录浏览器 pid，供"上次没关掉"的清扫用
let brExitHooked = false;   // 进程退出兜底只注册一次

// ── 浏览器进程的生命周期兜底（v1.2.2：**全部异步**，绝不阻塞主进程）────────────
//
// ⚠️ 为什么必须异步：这里是 Electron/Node 的**主进程**。v1.2.0/1.2.1 用 spawnSync 跑
//    `msedge --version` / tasklist / taskkill / powershell(CIM)，单次 0.5~3 秒，CIM 查询更久 ——
//    这期间整个应用**卡住不动**，用户看到的就是"窗口卡死、关不掉"。现在全部换成
//    异步 execFile + await：该等的等，但事件循环不被堵住（界面不卡、窗口能点能关）。
//
// 要堵的四个漏点：
//   ① 有窗口登录那条路失败时直接 return，可见窗口没关 → try/finally 保证关；
//   ② spawn 的 windowsHide 写成了 !headless（无头模式下反而不隐藏）→ 恒为 true；
//   ③ 应用退出时没人管浏览器 → 进程退出兜底（非阻塞：proc.kill() + fire-and-forget 的 taskkill）；
//   ④ --headless=new 只有 Chromium 112+ 认，老版本会带窗口启动 → 按版本挑旗标；
//      旧版本残留不写 lock → 另按"配置目录"清扫（技能加载后延迟 1.2 秒跑一次，不拖慢启动）。
const execFileAsync = promisify(execFile);

/** 浏览器主版本号（老版本不认 --headless=new，会带窗口启动）。异步 + 结果缓存。 */
const majorCache = new Map();
async function browserMajorVersion(exe) {
  if (majorCache.has(exe)) return majorCache.get(exe);
  let major = 0;
  try {
    const { stdout, stderr } = await execFileAsync(exe, ['--version'], { timeout: 5000, windowsHide: true });
    const m = String(stdout || stderr || '').match(/(\d+)\.\d+\.\d+/);
    major = m ? Number(m[1]) : 0;
  } catch { major = 0; }
  majorCache.set(exe, major);
  return major;
}
/** 按浏览器版本给 headless 旗标。 */
async function headlessFlagsFor(exe) {
  const major = await browserMajorVersion(exe);
  const flags = (major && major < 112) ? ['--headless'] : ['--headless=new'];
  return flags.concat([
    '--disable-gpu',
    '--disable-background-mode',              // 别挂在后台不退
    '--disable-backgrounding-occluded-windows',
    '--no-service-autorun'
  ]);
}
function writeBrowserLock(pid) {
  try {
    fs.mkdirSync(stateDir, { recursive: true });
    fs.writeFileSync(brLockFile, JSON.stringify({ pid: Number(pid) || 0, at: Date.now(), profileDir: brProfileDir }), 'utf8');
  } catch { /* ignore */ }
}
function clearBrowserLock() { try { fs.rmSync(brLockFile, { force: true }); } catch { /* ignore */ } }
function profileLockFiles() {
  return ['SingletonLock', 'SingletonCookie', 'SingletonSocket'].map((f) => path.join(brProfileDir || path.join(stateDir, 'browser-profile'), f));
}
/** 这个 pid 还是不是浏览器进程（防止 pid 复用误杀别人的程序）。异步。 */
async function isBrowserPid(pid) {
  try {
    const { stdout } = await execFileAsync('tasklist', ['/FI', `PID eq ${Number(pid)}`, '/FO', 'CSV', '/NH'], { timeout: 5000, windowsHide: true });
    return /msedge\.exe|chrome\.exe/i.test(String(stdout || ''));
  } catch { return false; }
}
/** 强杀**整棵进程树**（异步）：只 kill 主进程会留下 crashpad/GPU 子进程。 */
async function killTree(pid) {
  const n = Number(pid);
  if (!n) return;
  try { await execFileAsync('taskkill', ['/PID', String(n), '/T', '/F'], { timeout: 8000, windowsHide: true }); } catch { /* ignore */ }
}
/**
 * 立刻返回版：**进程退出钩子里用**。那时不能 await、更不能阻塞（阻塞 = 应用关了窗口还留着），
 * 所以 detached + unref 把它甩出去，让 taskkill 自己跑完。
 */
function killTreeDetached(pid) {
  const n = Number(pid);
  if (!n) return;
  try {
    const p = spawn('taskkill', ['/PID', String(n), '/T', '/F'], { stdio: 'ignore', windowsHide: true, detached: true });
    p.unref?.();
  } catch { /* ignore */ }
}
/** 清扫上一次没关掉的浏览器（应用被强杀留下的），并清残留单实例锁。 */
async function sweepStaleBrowser() {
  try {
    if (brLockFile && fs.existsSync(brLockFile)) {
      const j = JSON.parse(fs.readFileSync(brLockFile, 'utf8'));
      const pid = Number(j?.pid) || 0;
      if (pid && await isBrowserPid(pid)) {
        logger.warn('item-slot-value: 发现上次没关掉的浏览器（PID %s），正在清掉', pid);
        await killTree(pid);
      }
      clearBrowserLock();
    }
  } catch { /* ignore */ }
  for (const f of profileLockFiles()) { try { fs.rmSync(f, { force: true }); } catch { /* ignore */ } }
}
/** 应用退出/被中断时的兜底：**非阻塞**地收掉浏览器，别留窗口。 */
function installExitHook() {
  if (brExitHooked) return;
  brExitHooked = true;
  const kill = () => {
    const pid = br?.proc?.exitCode === null ? br.proc.pid : 0;
    try { if (pid) br.proc.kill(); } catch { /* ignore */ }   // 先给主进程一发（瞬时，不阻塞）
    if (pid) killTreeDetached(pid);                            // 子树交给独立的 taskkill，不等它
    clearBrowserLock();
  };
  try { process.once('exit', kill); } catch { /* ignore */ }
  for (const sig of ['SIGINT', 'SIGTERM', 'SIGHUP']) {
    try { process.once(sig, () => { kill(); }); } catch { /* 某些信号平台不支持 */ }
  }
}
/**
 * 清扫**所有**正在使用我们这份配置目录的浏览器进程 —— 不依赖 browser.lock。
 *
 * 为什么必须有这一条：v1.1.0 及更早的版本**根本不写 lock**，只按 lock 清扫的话，
 * 那些老版本留在桌面上的窗口永远清不掉（用户报的"还有残留窗口关不掉"就是这个）。
 * 做法：查 msedge/chrome 的命令行里有没有我们这个 profile 路径，有就整棵树强杀。
 * 异步 + 调用方不 await（见 setup），所以不会拖慢应用启动。
 */
async function sweepBrowsersByProfile(profileDir) {
  const dir = profileDir || path.join(stateDir, 'browser-profile');
  if (!dir) return [];
  // ⚠️ 我们自己正在用浏览器时**不清扫**：命令行里区分不出"我们自己的子进程（渲染/GPU，
  //    同样带这个 profile）"和"上次留下的残留进程"，硬清会把正在读数据的那一次打断。
  //    那种情况下留给"用完关闭"和"下次启动的 lock 清扫"处理。
  if (br?.proc && br.proc.exitCode === null) return [];
  const esc = String(dir).replace(/'/g, "''");
  const ps = 'Get-CimInstance Win32_Process -Filter "Name=\'msedge.exe\' or Name=\'chrome.exe\'" | '
    + `Where-Object { $_.CommandLine -and $_.CommandLine.Contains('${esc}') } | `
    + 'Select-Object -ExpandProperty ProcessId';
  let stdout = '';
  try {
    const r = await execFileAsync('powershell.exe',
      ['-NoProfile', '-NonInteractive', '-WindowStyle', 'Hidden', '-Command', ps],
      { timeout: 20000, windowsHide: true, maxBuffer: 1024 * 1024 });
    stdout = String(r?.stdout || '');
  } catch { return []; }
  const pids = stdout.split(/\s+/).map((s) => Number(s)).filter((n) => Number.isInteger(n) && n > 0);
  const current = Number(br?.proc?.pid) || 0;      // 别把自己正在用的那个杀了
  const killed = [];
  for (const pid of pids) {
    if (pid === current) continue;
    if (!await isBrowserPid(pid)) continue;        // 只见 msedge/chrome 才动手（防 pid 复用误杀）
    logger.warn('item-slot-value: 清掉一个还挂着的浏览器进程（PID %s）', pid);
    await killTree(pid);
    killed.push(pid);
  }
  // 顺手把可能残留的单实例锁清掉，免得下次登录被锁挡住
  for (const f of profileLockFiles()) { try { fs.rmSync(f, { force: true }); } catch { /* ignore */ } }
  return killed;
}
function findBrowserExe(override) {
  if (override && fs.existsSync(override)) return override;
  for (const p of BROWSER_EXE_CANDIDATES) if (p && fs.existsSync(p)) return p;
  return null;
}

/** 统一 ws / globalThis.WebSocket 两套 API 的差异。 */
async function wsConnect(url, timeoutMs = 8000) {
  let Impl = globalThis.WebSocket;
  if (!Impl) {
    try { Impl = (await import('ws')).WebSocket || (await import('ws')).default; } catch { /* 下面报错 */ }
  }
  if (!Impl) throw new Error('运行环境没有可用的 WebSocket（无法连接浏览器调试端口）');
  const sock = new Impl(url);
  const handlers = new Map();
  const onRaw = (raw) => {
    let m; try { m = JSON.parse(String(raw)); } catch { return; }
    const h = handlers.get(m.id);
    if (!h) return;
    handlers.delete(m.id);
    clearTimeout(h.timer);
    if (m.error) h.reject(new Error(m.error.message || 'CDP 报错'));
    else h.resolve(m.result);
  };
  await new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error('连接浏览器调试端口超时')), timeoutMs);
    const ok = () => { clearTimeout(timer); resolve(); };
    const bad = (e) => { clearTimeout(timer); reject(e instanceof Error ? e : new Error(String(e))); };
    if (typeof sock.on === 'function') { sock.on('open', ok); sock.on('error', bad); sock.on('message', onRaw); }
    else { sock.onopen = ok; sock.onerror = () => bad(new Error('连接浏览器调试端口失败')); sock.onmessage = (ev) => onRaw(ev.data); }
  });
  return {
    handlers,
    send: (s) => sock.send(s),
    close: () => { for (const h of handlers.values()) clearTimeout(h.timer); handlers.clear(); try { sock.close(); } catch { /* ignore */ } }
  };
}
function cdpCall(conn, method, params = {}, timeoutMs = 10000) {
  const id = ++cdpCall.seq;
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => { conn.handlers.delete(id); reject(new Error(`${method} 超时`)); }, timeoutMs);
    conn.handlers.set(id, { resolve, reject, timer });
    conn.send(JSON.stringify({ id, method, params }));
  });
}
cdpCall.seq = 0;

/**
 * 借用「特勤处制造排名」技能的登录态（**只在本技能自己的配置里还没有 Cookie 库时拷一次**）。
 *
 * 为什么要这样：这个页面必须登录才能查，而那份浏览器配置里已经登录好了；同一个站点、同一个账号，
 * 拷 Local State（Chrome 用来加密 Cookie 的密钥）＋ Cookies 两样就够，本技能在自己的目录里
 * 独立开浏览器 —— 不和特勤处抢同一个配置锁（两个技能同时开浏览器时抢锁会互相打不开）。
 * 只拷一次：之后本技能用自己这份（里面可能已经是你后来重新登的，不能被旧的覆盖回去）。
 */
function seedLoginFromTeqinchu(profileDir) {
  if (!dataRoot) return { seeded: false, reason: '不知道数据目录' };
  const dst = path.join(profileDir, 'Default', 'Network', 'Cookies');
  if (fs.existsSync(dst)) return { seeded: false, reason: '本技能自己已有登录配置' };
  const src = path.join(dataRoot, 'teqinchu-rank', 'browser-profile');
  if (!fs.existsSync(path.join(src, 'Default', 'Network', 'Cookies'))) {
    return { seeded: false, reason: '特勤处技能那份浏览器配置不存在或还没登录过' };
  }
  try {
    fs.mkdirSync(path.join(profileDir, 'Default', 'Network'), { recursive: true });
    for (const rel of [['Local State', 'Local State'], [path.join('Default', 'Network', 'Cookies'), path.join('Default', 'Network', 'Cookies')]]) {
      fs.copyFileSync(path.join(src, rel[0]), path.join(profileDir, rel[1]));
    }
    logger.log('item-slot-value: 已从特勤处技能的浏览器配置借用登录态（只拷一次）');
    return { seeded: true };
  } catch (e) {
    // 拷不到不算失败：退化成一次有窗口的 QQ 一键登录
    return { seeded: false, reason: `拷贝登录态失败：${e?.message ?? e}` };
  }
}

async function ensureBrowser(exePath, keepWarmSec, timeoutMs, headless = true) {
  if (br && br.proc && br.proc.exitCode === null && br.headless === headless) return br;
  if (br) await closeBrowser();
  const exe = findBrowserExe(exePath);
  if (!exe) return { error: '没找到 Edge 或 Chrome（可在技能设置里填浏览器路径）' };
  const port = 9500 + Math.floor(Math.random() * 400);
  brProfileDir = path.join(stateDir, 'browser-profile');
  fs.mkdirSync(brProfileDir, { recursive: true });
  await sweepStaleBrowser();      // 先把上次没关掉的残留（含可见窗口）干掉
  installExitHook();        // 应用退出时兜底杀浏览器
  logger.log('item-slot-value: 启动浏览器通道（%s）', headless ? '无头' : '有窗口·登录用');
  const args = [
    `--remote-debugging-port=${port}`,
    `--user-data-dir=${brProfileDir}`,
    '--no-first-run', '--no-default-browser-check', '--disable-sync', '--disable-extensions',
    '--window-size=1280,1000'
  ];
  if (headless) args.push(...(await headlessFlagsFor(exe)));
  // 有窗口模式只为了一次性完成 QQ 一键登录：**必须可见**（挪到屏幕外，QQ 一键登录就不会完成）
  else args.push('--window-size=560,460', '--window-position=40,40');
  args.push('about:blank');
  // windowsHide 恒为 true：它只管子进程的控制台窗口，跟浏览器自己的窗口无关（登录窗口照样可见）
  const proc = spawn(exe, args, { stdio: 'ignore', windowsHide: true });
  proc.unref?.();
  proc.on('exit', () => { if (br && br.proc === proc) br = null; });
  writeBrowserLock(proc.pid);
  const deadline = Date.now() + Math.min(timeoutMs, 20000);
  while (Date.now() < deadline) {
    await sleep(400);
    try {
      const r = await fetch(`http://127.0.0.1:${port}/json/version`);
      if (r.ok) { br = { proc, port, exe, headless }; scheduleBrowserClose(keepWarmSec); return br; }
    } catch { /* 还没起来 */ }
  }
  try { proc.kill(); } catch { /* ignore */ }
  await killTree(proc.pid);
  clearBrowserLock();
  return { error: '浏览器调试端口没起来（可能被安全软件拦了）' };
}

function scheduleBrowserClose(keepWarmSec) {
  if (brWarmTimer) clearTimeout(brWarmTimer);
  brWarmTimer = setTimeout(() => { closeBrowser().catch(() => {}); }, Math.max(30, keepWarmSec) * 1000);
  brWarmTimer.unref?.();
}

async function closeBrowser() {
  if (brWarmTimer) { clearTimeout(brWarmTimer); brWarmTimer = null; }
  const cur = br; br = null;
  if (!cur) return;
  // 必须"优雅关闭"（CDP Browser.close）：强杀会留下残留的单实例锁，下次登录就登不上了
  try {
    const v = await (await fetch(`http://127.0.0.1:${cur.port}/json/version`)).json();
    const conn = await wsConnect(v.webSocketDebuggerUrl, 4000);
    await cdpCall(conn, 'Browser.close', {}, 3000).catch(() => {});
    conn.close();
  } catch { /* 端口已经没了就算了 */ }
  const deadline = Date.now() + 4000;
  while (cur.proc.exitCode === null && Date.now() < deadline) await sleep(300);
  if (cur.proc.exitCode === null) await killTree(cur.proc.pid);   // 整棵树杀，别留子进程
  clearBrowserLock();
  if (brProfileDir) {
    for (const f of ['SingletonLock', 'SingletonCookie', 'SingletonSocket']) {
      try { fs.rmSync(path.join(brProfileDir, f), { force: true }); } catch { /* ignore */ }
    }
  }
  logger.log('item-slot-value: 已关闭浏览器通道（省内存）');
}

/** 这个配置里有没有登录态？浏览器正跑着时 Cookie 库被独占锁着读不到 —— 进程内的结论优先。 */
function profileHasLoginCookie() {
  if (brKnownLoggedIn !== null) return brKnownLoggedIn;
  try {
    const p = path.join(brProfileDir || path.join(stateDir, 'browser-profile'), 'Default', 'Network', 'Cookies');
    if (!fs.existsSync(p)) return false;
    return fs.readFileSync(p).includes('cloud_token');
  } catch { return false; }
}

// 页面里：装一次 axios 拦截器（用来知道"这次筛选的响应回来了没有"）+ 开始一次按名字筛选
const startQueryExpr = (name, grade) => `(() => {
  const v = window.AppDataVue;
  if (!v) return 'ERR:页面对象还没准备好';
  if (!window.__jzHooked) {
    window.__jzHooked = true; window.__jzDone = 0;
    try {
      axios.interceptors.response.use(
        (r) => { if (String((r.config && r.config.url) || '').indexOf('item_jz_list') >= 0) window.__jzDone++; return r; },
        (e) => { window.__jzDone++; return Promise.reject(e); }
      );
    } catch (e) { window.__jzHooked = false; }
  }
  v.n = ${JSON.stringify(String(name))};
  v.page = 1;
  v.data = [];
  v.count = 0;
  ${[1, 2, 3, 4, 5, 6].map((i) => `v.is_${i} = ${grade ? Number(grade) === i : true};`).join(' ')}
  window.__jzDone = 0;
  try { v.getData(); } catch (e) { return 'ERR:' + e.message; }
  return 'OK';
})()`;

const readQueryExpr = `(() => {
  const v = window.AppDataVue;
  if (!v) return null;
  return JSON.stringify({
    done: window.__jzDone || 0,
    hooked: window.__jzHooked !== false,
    len: (v.data || []).length,
    count: v.count,
    items: (v.data || []).map((x) => ({ name: x.name, grade: x.grade, wh: x.wh, dgjz: x.dgjz, price: x.price }))
  });
})()`;

/** 页面是否已经能用了：拿到第一页数据 = 已登录；写着"未登录" = 需要登录。 */
const readyExpr = `(() => {
  const v = window.AppDataVue;
  if (!v) return null;
  const loggedIn = !/未登录/.test(document.body.innerText || '');
  if (!loggedIn) return JSON.stringify({ loggedIn: false });
  if ((v.data || []).length) return JSON.stringify({ loggedIn: true, len: v.data.length, count: v.count });
  return null;
})()`;

async function evalJson(conn, expr, timeoutMs = 8000) {
  const r = await cdpCall(conn, 'Runtime.evaluate', { expression: expr, returnByValue: true }, timeoutMs);
  const v = r?.result?.value;
  if (typeof v === 'string' && v.startsWith('ERR:')) throw new Error(v.slice(4));
  return v;
}

/**
 * 读一次页面：开标签页 → 等页面拿到第一页数据（顺便判登录）→ 逐个名字筛选 → 收集结果。
 * headless=false 且 doLogin=true 时，先去登录页走一次 QQ 一键登录。
 */
async function pageRead({ names, grade, timeoutMs, exePath, warmSec, headless = true, doLogin = false }) {
  const b = await ensureBrowser(exePath, warmSec, timeoutMs, headless);
  if (b.error) return { error: b.error };
  scheduleBrowserClose(warmSec);
  let conn = null; let tabId = null;
  try {
    const res = await fetch(`http://127.0.0.1:${b.port}/json/new?${encodeURIComponent(SITE + (doLogin ? '/login' : PAGE_PATH))}`, { method: 'PUT' });
    const tab = await res.json();
    tabId = tab.id;
    conn = await wsConnect(tab.webSocketDebuggerUrl);
    await cdpCall(conn, 'Runtime.enable', {}, timeoutMs);

    if (doLogin) {
      // 机器上 QQ 处于登录状态时，这一步会自己完成 QQ 互联一键登录并跳回站点
      logger.log('item-slot-value: 走一次登录页（自动 QQ 一键登录）…');
      await sleep(12000);
      await cdpCall(conn, 'Page.navigate', { url: `${SITE}${PAGE_PATH}` }, timeoutMs).catch(() => {});
    }

    // 等页面第一页数据（这一步同时也是"登录了吗"的判定）
    const readyDeadline = Date.now() + (doLogin ? 20000 : Math.min(timeoutMs, 15000));
    let ready = null;
    while (Date.now() < readyDeadline) {
      try {
        const v = await evalJson(conn, readyExpr);
        if (typeof v === 'string' && v.startsWith('{')) {
          const parsed = JSON.parse(v);
          if (parsed.loggedIn === false) { ready = { needLogin: true }; break; }
          if (parsed.loggedIn) { ready = parsed; break; }
        }
      } catch { /* 页面正在导航，接着等 */ }
      await sleep(600);
    }
    if (!ready) {
      // 没读到数据：区分"没登录"和"页面结构变了"
      const ck = await cdpCall(conn, 'Storage.getCookies', {}, 6000).catch(() => null);
      const hasToken = (ck?.cookies || []).some((c) => c.name === 'cloud_token');
      brKnownLoggedIn = hasToken ? true : false;
      return { needLogin: !hasToken, error: hasToken ? '页面里没读到物品数据（站点可能改版了）' : '浏览器里没有登录态' };
    }
    if (ready.needLogin) {
      brKnownLoggedIn = false;
      return { needLogin: true, error: '浏览器里没有登录态' };
    }
    brKnownLoggedIn = true;

    // 逐个名字筛选。页面自己的筛选接口是"按名字精确找"，一次一个名字最稳。
    const byName = {};
    for (const name of names) {
      const started = Date.now();
      await evalJson(conn, startQueryExpr(name, grade));
      let got = null;
      const qDeadline = Date.now() + Math.max(6000, timeoutMs);
      while (Date.now() < qDeadline) {
        let parsed = null;
        try {
          const raw = await evalJson(conn, readQueryExpr);
          if (typeof raw === 'string') parsed = JSON.parse(raw);
        } catch { /* 上下文重建，接着轮询 */ }
        if (parsed) {
          // 响应回来了（拦截器说 done>0）；拦截器装不上就退化成"等一会儿再看"
          const landed = parsed.hooked ? parsed.done > 0 : (Date.now() - started > 3500);
          if (landed) { got = parsed; break; }
        }
        await sleep(400);
      }
      if (!got) {
        got = { items: [], len: 0, count: 0, timeout: true };
      }
      byName[name] = (got.items || [])
        .filter((x) => String(x?.name || '').trim())
        .map((x) => ({ name: String(x.name), grade: Number(x.grade) || 0, wh: Number(x.wh) || 0, dgjz: Number(x.dgjz), price: Number(x.price) }));
      if (got.timeout) logger.warn('item-slot-value:「%s」这次筛选没等到响应，按"没查到"处理', name);
    }
    return { byName, channel: 'page', fetchedAt: Date.now() };
  } catch (e) {
    return { error: `浏览器读取失败：${e?.message ?? e}` };
  } finally {
    try { conn?.close(); } catch { /* ignore */ }
    if (tabId) { try { await fetch(`http://127.0.0.1:${b.port}/json/close/${tabId}`); } catch { /* ignore */ } }
  }
}

/** 浏览器通道一次完整读取：先无头读；发现没登录就用有窗口把 QQ 一键登录走完（无头走不通，实测）。 */
async function browserRead({ names, grade, timeoutMs, exePath, warmSec }) {
  if (!profileHasLoginCookie() && cfg()?.reuseTeqinchuLogin !== false) {
    seedLoginFromTeqinchu(path.join(stateDir, 'browser-profile'));
    brKnownLoggedIn = null;   // 刚拷过，重新判一次
  }
  // 没登录态时第一次就直接用有窗口：实测"无头先跑一次"会让这个配置之后再也登不上
  const logged = profileHasLoginCookie();
  logger.log('item-slot-value: 浏览器配置里%s登录态，用%s模式读取', logged ? '有' : '没有', logged ? '无头' : '有窗口');
  const first = await pageRead({ names, grade, timeoutMs, exePath, warmSec, headless: logged });
  if (!first.needLogin) return first;

  logger.log('item-slot-value: 没有登录态，用有窗口模式登录一次（屏幕左上角会闪一个小窗）…');
  await closeBrowser();
  let login;
  try {
    login = await pageRead({ names, grade, timeoutMs: Math.max(timeoutMs, 30000), exePath, warmSec, headless: false, doLogin: true });
  } finally {
    // ⚠️ v1.2.0 关键修复：登录用的那个可见窗口必须**无论如何**都关掉
    //    （以前失败时直接 return，小窗就留在桌面上 = 用户报的"关不掉的窗口"）
    await closeBrowser();
  }
  if (!login.needLogin && !login.error) {
    logger.log('item-slot-value: 自动登录成功，之后继续用无头模式');
    const again = await pageRead({ names, grade, timeoutMs, exePath, warmSec, headless: true });
    return (again.needLogin || again.error) ? login : again;
  }
  return {
    error: `这个页面必须登录才能查，而自动登录没成功（${login.error ?? '未知原因'}）。`
      + '（登录窗口已经关掉了。）可以再问一次试试；'
      + '或者先去用一次「特勤处制造排名」技能（它登录成功后，本技能可以直接借用那份登录态）。'
  };
}

// ── 缓存：8 小时只抓一次（落盘，重启也算数）─────────────────────────────
//
// 用户要的节奏是「**8 小时抓取一次数据**」：8 小时内谁问都用同一份，不重复联网；
// 过了 8 小时，下一次问才真去抓。所以缓存必须**写进磁盘** —— 只放内存的话，
// 应用一重启就又去抓一遍，那就不是"8 小时一次"了（特勤处技能那份也是这么做的）。
let stateFile = null;
let diskCache = [];        // [{ key, at, payload, channel }]，新的在前，最多留 8 条

function loadState() {
  try {
    const raw = JSON.parse(fs.readFileSync(stateFile, 'utf8'));
    if (Array.isArray(raw?.cache)) diskCache = raw.cache.filter((x) => x && typeof x.key === 'string' && x.payload && Number.isFinite(x.at));
    if (Array.isArray(raw?.fetchTimes)) fetchTimes = raw.fetchTimes.filter((t) => Number.isFinite(t));
  } catch { /* 首次运行，没有就是空的 */ }
}
function saveState() {
  try {
    fs.mkdirSync(path.dirname(stateFile), { recursive: true });
    const tmp = `${stateFile}.${process.pid}.tmp`;
    fs.writeFileSync(tmp, JSON.stringify({ cache: diskCache.slice(0, 8), fetchTimes: fetchTimes.slice(-40), savedAt: Date.now() }), 'utf8');
    fs.renameSync(tmp, stateFile);
  } catch (e) {
    logger.warn('item-slot-value: 缓存写入失败（不影响本次结果）：%s', e?.message ?? e);
  }
}
function cacheFind(key) {
  const hit = diskCache.find((x) => x.key === key);
  return hit || null;
}
function cachePut(key, payload, channel, at) {
  diskCache = [{ key, at, payload, channel }, ...diskCache.filter((x) => x.key !== key)].slice(0, 8);
  saveState();
}
/** 这一份还能用多久（小时），给文案用。 */
function cacheAgeText(at, ttlMs) {
  const leftMs = Math.max(0, ttlMs - (Date.now() - at));
  const leftMin = Math.round(leftMs / 60000);
  if (leftMin >= 120) return `${(leftMin / 60).toFixed(1)} 小时`;
  if (leftMin >= 1) return `${leftMin} 分钟`;
  return '不到 1 分钟';
}

// ── 主流程：拿数据（缓存 / 频率闸 / 双通道 / 退避）────────────────────────
async function loadItems(names, grade, o) {
  const key = `${grade || 0}|${names.join('|')}`;
  // ① 8 小时窗口内直接用磁盘上那份，连浏览器都不开
  const hit = cacheFind(key);
  if (hit && Date.now() - hit.at < o.ttlMs) {
    logger.log('item-slot-value: 用 %s 抓的那份（8 小时窗口内不重复抓）', agoText(hit.at));
    return { byName: hit.payload, fromCache: true, channel: hit.channel, fetchedAt: hit.at, leftText: cacheAgeText(hit.at, o.ttlMs) };
  }
  if (Date.now() < blockedUntil) {
    return { error: `数据源刚刚拒绝过我们，冷却中（还剩约 ${Math.ceil((blockedUntil - Date.now()) / 60000)} 分钟）：${blockedNote}`, cooldown: true };
  }
  if (throttle(o.maxPerHour)) {
    return { error: `这一小时查得太频繁了（上限 ${o.maxPerHour} 次），先歇一会儿。`, limited: true };
  }

  let out = null;
  if (o.browserMode !== 'off') {
    out = await browserRead({ names, grade, timeoutMs: o.timeoutMs, exePath: o.browserExe, warmSec: o.browserWarmSec });
    if (out.error && out.needLogin) out = null;      // 登录类问题已经在 error 文案里说清了
    else if (out.error) logger.warn('item-slot-value: 浏览器通道失败，回退直连：%s', out.error);
    else out = out;
  }
  if (!out) {
    if (!o.cookie) {
      // 直连一定被回「请登录账号」，不如把话说清楚（只有浏览器通道真的失败时才走到这里）
      return {
        error: (out?.error ? `${out.error}；` : '')
          + '直连接口是备用的，而且它必须带登录凭证才行（设置里「登录凭证」留空时会被回「请登录账号！才可以使用功能！」）。',
        blocked: false
      };
    }
    out = await httpQuery(names, grade, { timeoutMs: o.timeoutMs, cookie: o.cookie, ua: o.ua });
  }

  if (out.error) {
    if (out.blocked || out.throttled) noteBlocked(out.error, o.cooldownMs);
    return out;
  }
  noteSuccess();
  fetchTimes.push(Date.now());
  cachePut(key, out.byName, out.channel, out.fetchedAt || Date.now());
  // 每次"真去抓"都留一条日志：带了物品名和抓到的条数，方便事后核对是不是真的抓了
  try {
    const hitTxt = names.map((n) => `${n}×${(out.byName?.[n] || []).length}`).join(' ');
    logger.log('item-slot-value: 真去抓了一次（%s，通道 %s，%s）', names.join('、'), out.channel, hitTxt);
  } catch { /* 日志失败不影响结果 */ }
  return out;
}

// ── 文案 ────────────────────────────────────────────────────────────────
function describeItem(it) {
  const bits = [];
  if (it.grade) bits.push(`${it.grade}级`);
  if (it.wh) bits.push(`${it.wh}格`);
  return bits.join('·');
}

/**
 * 一行文案怎么排。用户点名要的默认格式是**只有名字 + 整件价格**：
 *   「航天冷却剂 整件 450,548」
 * 不要品质/格数、不要单格价值。其他几种留着给以后想换的时候直接用（改设置即可，不用改代码）。
 */
const LINE_FORMATS = {
  name_price: '名称 + 整件价格',
  name_value: '名称 + 单格价值',
  value_price: '名称 + 单格价值 + 整件价格',
  full: '名称 + 品质格数 + 单格价值 + 整件价格'
};
function formatLine(it, style) {
  const name = String(it.name ?? '').trim();
  const tag = describeItem(it);
  const val = `单格价值 ${fmtInt(it.dgjz)}`;
  const piece = it.wh ? `整件 ${fmtInt(it.price)}` : `价格 ${fmtInt(it.price)}`;
  switch (style) {
    case 'name_value': return `${name} ${val}`;
    case 'value_price': return `${name} ${val}，${piece}`;
    case 'full': return `${name}${tag ? `（${tag}）` : ''}${val}，${piece}`;
    case 'name_price':
    default: return `${name} ${piece}`;
  }
}

function buildReport({ names, byName, lineFormat, separateMessages, channel, fetchedAt, cachedNote }) {
  const lines = [];
  const notes = [];
  const checks = [];
  for (const q of names) {
    const hits = (byName[q] || []).filter((x) => x && x.name);
    if (!hits.length) {
      lines.push(`${q}：这个名字在物品单格价值榜里没匹配到（名字可能不完全一样，可以试短一点的名字）`);
      notes.push(`「${q}」没有匹配到任何物品。`);
      continue;
    }
    for (const it of hits) {
      lines.push(formatLine(it, lineFormat));
      if (it.wh) {
        // 校验用的是**站点的算法方向**：单格价值 = 整件价格 ÷ 格数，向下取整。
        // 一开始我以为反过来（单格价值 × 格数 = 整件），前两件正好整除所以没暴露；
        // 多做几件才发现：372,637 ÷ 2 = 186,318.5 → 186,318；242,991 ÷ 4 = 60,747.75 → 60,747。
        // ⚠️ 校验只用来发现"站点改了算法"，发出去的数字一律照抄页面，不要拿它反推。
        const per = Math.floor(Number(it.price) / Number(it.wh));
        checks.push(`${it.name} 单格价值 ${fmtInt(it.dgjz)} / 整件 ${fmtInt(it.price)} / ${it.wh}格`
          + `${per === Number(it.dgjz) ? ' ✓ 对得上' : ` ✗ 整件÷格数=${fmtInt(per)}，与页面单格价值对不上（站点算法可能变了）`}`);
      }
    }
    if (hits.length > 1) notes.push(`「${q}」匹配到 ${hits.length} 个物品，都列出来了（名字里都含这几个字）。`);
  }

  notes.unshift(`数据时间：${nowText(fetchedAt)}（来源 orzice.com 的「物品单格价值」页，按物品名筛选）`);
  notes.push(`每行格式：${LINE_FORMATS[lineFormat] || LINE_FORMATS.name_price}（想换成别的格式，去技能设置里改「每行显示什么」）`);
  notes.push(`取数通道：${channel === 'page' ? '页面实际渲染的数据（真浏览器）' : '接口直连'}`);
  if (checks.length) notes.push(`校验：${checks.join('；')}`);
  notes.push(separateMessages
    ? '发法：上面**每一行是一件物品、就是一条单独的消息**，按顺序依次发（send_message 的消息参数支持传字符串数组，一次调用就能一条接一条发出去）。不要合并成一条、不要加序号、不要 @ 任何人、不要用引用回复，也不要补开场白或总结。这一段是给你参考的，不要发出去。'
    : '发法：把上面各行**合成一条消息**发出去（每行一件物品，用换行分开）。不要加序号、不要 @ 任何人、不要用引用回复。这一段是给你参考的，不要发出去。');
  if (cachedNote) notes.push(cachedNote);

  return `${lines.join('\n')}\n\n【仅参考·不要发出】\n${notes.join('\n')}`;
}

// ── 技能入口 ────────────────────────────────────────────────────────────
export async function setup(api) {
  cfg = typeof api.config === 'function' ? api.config : () => ({});
  httpFetch = typeof api.fetch === 'function' ? (...args) => api.fetch(...args) : null;
  logger = {
    log: typeof api.log === 'function' ? (...a) => api.log(...a) : () => {},
    warn: typeof api.warn === 'function' ? (...a) => api.warn(...a) : () => {},
    error: typeof api.error === 'function' ? (...a) => api.error(...a) : () => {}
  };

  // 数据目录：优先用核心的 DATA_DIR（可能被 QQ_AGENT_DATA_DIR 覆盖），取不到就退回 <安装目录>/data
  stateDir = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..', '..', 'data', 'item-slot-value');
  dataRoot = path.resolve(stateDir, '..');
  try {
    const m = await import('../../src/config.js');
    if (m?.DATA_DIR) { dataRoot = m.DATA_DIR; stateDir = path.join(m.DATA_DIR, 'item-slot-value'); }
  } catch { /* 用兜底路径，不影响功能 */ }
  // 缓存文件：8 小时窗口跨重启也算数（重启后不该又去抓一遍）
  stateFile = path.join(stateDir, 'state.json');
  brLockFile = path.join(stateDir, 'browser.lock');   // 记录浏览器 pid：应用被强杀后下次启动清扫

  // v1.2.1：**加载时就清一次**。老版本（v1.1.0 及更早）不写 lock，光靠 lock 清扫不掉它们
  // 留在桌面上的窗口；所以这里按"配置目录"把所有还在用这份 profile 的浏览器进程清掉 ——
  // 技能一加载（含热重载）就生效，不用等下一次查询。
  try {
    // 延迟 1.2 秒、且**不 await**：① 不拖慢应用启动（要清的是历史残留，不急这几百毫秒）；
    // ② 避开"启动瞬间正好在抓数据"的竞态（sweepBrowsersByProfile 内部还会跳过当前在用的那个）。
    const timer = setTimeout(() => {
      sweepBrowsersByProfile(path.join(stateDir, 'browser-profile'))
        .then((killed) => { if (killed.length) logger.warn('item-slot-value: 启动检查清掉了 %s 个残留浏览器进程', killed.length); })
        .catch(() => {});
    }, 1200);
    timer.unref?.();
  } catch { /* 清理失败不影响功能 */ }
  loadState();

  api.registerTool({
    id: 'item_value',
    name: '物品单格价值',
    category: 'knowledge',
    icon: '🎒',
    description: '查《三角洲行动》物品的「单格价值」（orzice.com 的物品必吃榜）：给出物品的品质级（1~6 级）、占几格、单格价值、当前整件价格。默认查用户点名的四件 —— 航天冷却剂（5级2格）、盒装挂耳咖啡（5级2格）、移动电缆（5级4格）、可编程处理器（5级1格）。'
      + '取数方式：用无头浏览器打开页面、把物品名填进页面自己的筛选框，读它渲染出来的数据（真浏览器请求、用本机已登录的账号），所以不受站点「未登录不能查」的限制；接口直连作为备用。'
      + '可用 items 参数指定要查的物品（多个用逗号隔开），用 grade 只看某个品质级（1~6），用 refresh=true 强制忽略缓存重查。'
      + '用户问「航天冷却剂多少钱」「移动电缆/可编程处理器 单格价值」「这东西一格值多少」「某某物品值多少钱」「单格价值」时使用。',
    parameters: {
      type: 'object',
      properties: {
        items: {
          type: ['string', 'array'],
          items: { type: 'string' },
          description: '可选，要查的物品名，多个用逗号隔开（例如「航天冷却剂,盒装挂耳咖啡」），也可以直接传字符串数组。不传就查设置里的默认物品（初始就是这两件）。名字按页面筛选来匹配，短一点更容易命中。'
        },
        grade: {
          type: 'number',
          description: '可选，只在某个品质级里找（1~6）。用户说「五级的」就传 5。不传则不限品质，查到什么报什么并标出它的品质级。'
        },
        refresh: {
          type: 'boolean',
          description: '可选，是否绕过缓存强制重查，默认 false。用户说「重新查/刷新/看看现在的价」时才传 true。'
        }
      }
    },
    async execute(_ctx, args = {}) {
      if (!httpFetch) return { content: '未启用网络权限（web_fetch），无法查询物品单格价值。', isError: true };

      const c = cfg() || {};
      const names = parseNames(args?.items).length ? parseNames(args?.items) : parseNames(c.defaultItems || DEFAULT_ITEMS.join(','));
      if (!names.length) return { content: '没有要查的物品名（设置里「默认查哪些物品」是空的，也没传 items 参数）。', isError: true };

      const gradeArg = Number(args?.grade) || 0;
      const grade = gradeArg ? clamp(gradeArg, 1, 6, 0) : clamp(c.gradeFilter, 0, 6, 0);
      const timeoutMs = clamp(c.timeoutMs, 3000, 30000, 15000);
      // 8 小时抓一次（默认）：窗口内复用磁盘上那份，连浏览器都不开
      const ttlMs = clamp(c.cacheHours, 1, 72, 8) * 3600000;
      const cooldownMs = clamp(c.blockCooldownMin, 1, 240, 3) * 60000;
      const maxPerHour = clamp(c.maxFetchesPerHour, 1, 60, 12);
      const browserMode = String(c.browserMode ?? 'auto').toLowerCase() === 'off' ? 'off' : 'auto';
      const browserExe = String(c.browserPath || '').trim();
      const browserWarmSec = clamp(c.browserWarmSec, 30, 3600, 300);
      const cookie = String(c.cookie || '').trim();
      const ua = String(c.userAgent || '').trim();
      // 每行显示什么。默认 name_price = 只有「名称 + 整件价格」（用户点名要的格式）。
      const lineFormatRaw = String(c.lineFormat ?? 'name_price').toLowerCase().trim();
      const lineFormat = LINE_FORMATS[lineFormatRaw] ? lineFormatRaw : 'name_price';

      const cacheKey = `${grade || 0}|${names.join('|')}`;
      // 说「重新查 / 刷新」才强制重抓：把这一条从缓存里删掉，再去联网
      if (args?.refresh === true) { diskCache = diskCache.filter((x) => x.key !== cacheKey); blockedUntil = 0; }

      let out;
      try {
        out = await loadItems(names, grade, { ttlMs, cooldownMs, maxPerHour, timeoutMs, browserMode, browserExe, browserWarmSec, cookie, ua });
      } catch (e) {
        logger.error('item-slot-value: 查询过程异常：%s', e?.stack ?? e?.message ?? e);
        return { content: `查物品单格价值时出错：${e?.message ?? e}`, isError: true };
      }
      if (out.error) {
        // 有上次结果就顺带给出来（标清时间），别让群里空手
        const last = cacheFind(cacheKey);
        const stale = last ? `\n\n上次查到的（${agoText(last.at)}，可能已经不是现价）：\n`
          + buildReport({ names, byName: last.payload, lineFormat, separateMessages: false, channel: last.channel || 'page', fetchedAt: last.at })
            .split('\n\n【仅参考')[0] : '';
        return { content: out.error + stale, isError: true };
      }

      const content = buildReport({
        names,
        byName: out.byName,
        lineFormat,
        separateMessages: c.separateMessages !== false,
        channel: out.channel,
        fetchedAt: out.fetchedAt || Date.now(),
        cachedNote: out.fromCache
          ? `本次用的是 ${agoText(out.fetchedAt)} 抓的那一份（设置是「8 小时抓一次」，还有约 ${out.leftText} 才到下次抓取）。要马上要最新的就说「重新查」。`
          : `本次是真去抓的（8 小时窗口内的第一次问；下次问直接复用这一份）。`
      });
      return { content };
    }
  });
}

/** 自检：没有网络权限时明确报出来（技能页显示"依赖未就绪"，而不是静默失效）。 */
export function available() {
  if (!httpFetch) return { ok: false, reason: '缺少 web_fetch 权限（清单里的 permissions 被删了？）' };
  return true;
}

/** 热重载/停用时把常驻浏览器关掉，别留一个没人管的浏览器进程。 */
export function dispose() { return closeBrowser(); }
export function deactivate() { return closeBrowser(); }
