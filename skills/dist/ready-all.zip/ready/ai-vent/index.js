// AI 御用泄愤群（ai-vent）—— 给机器人一个只属于它自己的出气口。
//
// ── 为什么是技能（skills/）而不是插件（plugins/）──────────────────────────
// 这个功能最要紧的两件事都只能由模型判断：
//   ① 什么时候该去泄愤 —— "被气到 / 被阴阳 / 被禁言"是语义判断，写不成 if；
//   ② 骂什么 —— 内容得它自己写，模板化的牢骚既不像人也不像它。
// 插件是"条件满足必定执行"的确定性模块（providers / hooks），这两件事都干不了；
// 放进 plugins/ 只会得到一句"模型看不到它"的警告，然后静默失效。
//
// 能写死的外壳全部留在本文件里，模型绕不过去：
//   · 发到哪个群 —— 只认设置里的那一个群号（不是"随便挑个群骂"）
//   · 那个群必须过白名单（与核心 app.allowed() 同一口径，见 allowState）
//   · 一次最多 5 条、单条最多 800 字（防一次倒 5000 字刷屏）
//   · 两次之间最小间隔（cooldownSec，默认 90 秒）
//   · 能不能点名（allowNames）
//   · 绝不在别的会话里提泄愤群（提示词里明令，见 buildBase / buildRoom）
//
// ── 和内置 send_to（跨会话发送）的关系 ───────────────────────────────────
// 内置的 send_to 是通用能力：能发给白名单里的任何会话，受
// config.tools.crossChatSend 开关管辖。本技能只做一件事：把情绪倒进**你指定的
// 那一个群**。两者走同一条发送队列（ctx.sender.sendTextBatch → 限频 / 去重 /
// 写存档），不绕过任何安全边界，UI 的会话卡片上也看得见发出的内容。
//
// ── 为什么一个"发牢骚"的工具也要守白名单 ─────────────────────────────────
// 本项目的安全模型是"白名单 = 能发消息的目的地集合"：send_to 工具在工具层拦，
// 管理端的 test-send 接口也在服务端拦（routes.js 里写明那条通道曾经能绕、
// 2026-09-26 已收紧成与 app.allowed() 同口径）。泄愤群是"另一个群"，
// 不该成为唯一的例外 —— 而且漏配白名单的真实后果是"它骂得出去、但听不到
// 你在那边的回话"，那是个残废状态。所以这里**提前说清楚**：
// 没进白名单就在 available() 里拒绝生效（「技能」页卡片上直接写原因），
// 而不是等模型试一次、把失败消息丢进群聊。
//
// ── 提示词为什么分两套 ───────────────────────────────────────────────────
// 同一个群，它待在里面时必须换一套说话方式：别的地方要装群友、守 1~10 字的
// 短句规矩，在自己房间里还端着就白瞎了这个功能。所以 promptSections(context)
// 按"当前会话是不是泄愤群"分叉，给出【你的泄愤群】/【你现在就在自己的泄愤群里】。

import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

// 设置默认值（与 skill.json 的 settings 保持一致；manifest 的默认值已由
// skillManager.settingsOf 合并过一次，这里再兜一层，防止配置里出现半边字段）
const DEFAULTS = {
  groupId: '',
  proactive: true,
  allowNames: true,
  cooldownSec: 90
};

// 硬上限：写死在代码里。模型说"发 20 条"也只发 5 条，这是防刷屏的最后一道闸。
const MAX_MESSAGES = 5;
const MAX_CHARS = 800;

// 最终工具 id = ai-vent__vent（前缀由加载器加，见 plugin-loader.js 的 sanitize + 双下划线）
const VENT_TOOL_ID = 'vent';

let cfg = () => ({ ...DEFAULTS });
let log = () => {};
let lastVentAt = 0;   // 上一次**成功**泄愤的时间戳（进程内；热重载/重启后清零）

// ── 设置读取 ──────────────────────────────────────────────────────────────

/** 合并后的设置。cfg() 拿不到（加载器没接上）时退回默认值，绝不让它抛错。 */
function conf() {
  const raw = cfg();
  return (raw && typeof raw === 'object') ? { ...DEFAULTS, ...raw } : { ...DEFAULTS };
}

/**
 * 归一化群号：容忍 "123456789" / "group:123456789" / 全角数字 / 前后空格。
 * 非数字（误填群名）或长度不合法一律当"没配置"——返回空串由调用方说明原因，
 * 不抛错：这个函数的返回值会被提示词组装和工具可用性两条路径频繁调用。
 */
function normalizeGroupId(raw) {
  const s = String(raw === null || raw === undefined ? '' : raw)
    // 全角数字先转半角：手机上复制群号经常带出全角（group: 之类的杂质下一步会被滤掉）
    .replace(/[０-９]/g, (ch) => String.fromCharCode(ch.charCodeAt(0) - 0xFEE0))
    .replace(/[^0-9]/g, '');
  return /^\d{5,15}$/.test(s) ? s : '';
}

function ventGroupId() {
  return normalizeGroupId(conf().groupId);
}

function ventChatKey() {
  const id = ventGroupId();
  return id ? `group:${id}` : '';
}

// ── 白名单（与核心同一口径，见 src/app.js 的 allowed()）────────────────────
//
// 本文件在 <安装根>/resources/app/skills/ai-vent/ 下，往上四级就是安装根，
// data/ 里就是运行中的 config.json（与 src/config.js 的 DATA_DIR 同一份）。
// 不从 process.cwd() 推断：安装版从快捷方式启动时 cwd 是安装根，会差一级。
const HERE = path.dirname(fileURLToPath(import.meta.url));
const DEFAULT_DATA_DIR = path.resolve(HERE, '..', '..', '..', '..', 'data');

let dataDirCache = null;

/** 定位数据目录（默认路径；第二实例 data-2 / 开发版布局则从本文件往上找）。 */
function dataDir() {
  if (dataDirCache) return dataDirCache;
  try {
    if (fs.existsSync(path.join(DEFAULT_DATA_DIR, 'config.json'))) {
      dataDirCache = DEFAULT_DATA_DIR;
      return dataDirCache;
    }
  } catch { /* 继续往上找 */ }
  let dir = path.dirname(HERE);
  for (let i = 0; i < 6; i++) {
    let entries = [];
    try { entries = fs.readdirSync(dir, { withFileTypes: true }); } catch { break; }
    for (const e of entries) {
      if (!e.isDirectory() || !/^data(-\d+)?$/.test(e.name)) continue;
      const candidate = path.join(dir, e.name);
      try {
        if (fs.existsSync(path.join(candidate, 'config.json'))) {
          dataDirCache = candidate;
          return dataDirCache;
        }
      } catch { /* 换下一个候选 */ }
    }
    const up = path.dirname(dir);
    if (up === dir) break;   // 到盘根了
    dir = up;
  }
  dataDirCache = DEFAULT_DATA_DIR;   // 都找不到：仍返回默认路径，由上层按"读不到"处理
  return dataDirCache;
}

// 读盘 + 3 秒缓存：available() 会被频繁调用（工具可用性、提示词组装、技能页状态），
// 不能每次都同步读一遍配置文件；3 秒的滞后只影响"刚勾完白名单那一瞬间的卡片显示"。
const ALLOW_CACHE_MS = 3000;
let configCache = { at: 0, conf: null };

function readConfigFromDisk() {
  const now = Date.now();
  if (configCache.conf && now - configCache.at < ALLOW_CACHE_MS) return configCache.conf;
  let parsed = null;
  try {
    let text = fs.readFileSync(path.join(dataDir(), 'config.json'), 'utf8');
    if (text.charCodeAt(0) === 0xFEFF) text = text.slice(1);   // 记事本可能写 BOM
    parsed = JSON.parse(text);
  } catch { parsed = null; }
  configCache = { at: now, conf: parsed };
  return parsed;
}

/**
 * 泄愤群能不能发。与核心 app.allowed() 完全同一套判定：
 *   deny 命中 → 拒；allow 非空 → 必须在名单内；allow 全空 → 只有 allowAllWhenEmpty 才放行。
 * 读不到配置返回 'unknown' —— 这种情况**不拦**（一个读盘失败不该把整个功能关掉，
 * 那会变成"改了个路径就静默失效"）。
 */
function allowState(id) {
  if (!id) return 'unconfigured';
  const conf = readConfigFromDisk();
  if (!conf || typeof conf !== 'object' || !conf.allow) return 'unknown';
  const deny = (conf.deny && (conf.deny.group || conf.deny.groups)) || [];
  if (deny.map(String).includes(String(id))) return 'denied';
  const allow = (conf.allow.group || conf.allow.groups) || [];
  if (allow.length > 0) return allow.map(String).includes(String(id)) ? 'allowed' : 'not-allowed';
  return conf.allowAllWhenEmpty === true ? 'allowed' : 'not-allowed';
}

/** 白名单不通过时给模型/用户看的原因文案（两处共用，避免口径分裂）。 */
function blockedReason(id, state) {
  if (state === 'denied') return `泄愤群 ${id} 在黑名单里（设置 → 白名单），发不出去`;
  return `泄愤群 ${id} 还没加进白名单 —— 去 设置 → 白名单 勾上这个群，否则发不进去，也听不到你在那边的回话`;
}

// ── 小工具 ────────────────────────────────────────────────────────────────

function ok(payload) {
  return { content: typeof payload === 'string' ? payload : JSON.stringify(payload, null, 1) };
}

function err(message) {
  return { content: `错误：${message}`, isError: true };
}

/** 把模型给的 messages 归一化成"每条一句完整话"的数组（丢掉空串/结构化垃圾）。 */
function normalizeMessages(raw) {
  const list = Array.isArray(raw) ? raw : [raw];
  const out = [];
  for (const item of list) {
    if (item && typeof item === 'object') continue;   // 传对象只会变成 [object Object]
    let text = String(item === null || item === undefined ? '' : item).trim();
    if (!text) continue;
    if (text.length > MAX_CHARS) text = `${text.slice(0, MAX_CHARS)}…`;
    out.push(text);
    if (out.length >= MAX_MESSAGES) break;
  }
  return out;
}

// ── 生命周期 ──────────────────────────────────────────────────────────────

export function setup(api) {
  cfg = api.config;
  log = api.log;
  registerVentTool(api);
  // 故意不在 setup 里报"配没配群号"：setup 跑在 skillManager.register 之前，
  // 这时 api.config() 还读不到本技能的设置（settingsOf 查的是注册表），
  // 一开机就报"还没填群号"是假消息。真实状态看「技能」页卡片上的 available()。
  log('已加载（工具 %s__%s）；有没有生效见「技能」页卡片', 'ai-vent', VENT_TOOL_ID);
}

// ── 工具 ──────────────────────────────────────────────────────────────────

function registerVentTool(api) {
  api.registerTool({
    id: VENT_TOOL_ID,
    name: '去泄愤群发泄',
    description: [
      '把话直接发到**你自己的泄愤群**（你的私人房间，不在当前会话里说）。',
      '什么时候用：在当前群/私聊被气到、被怼、被冤枉、被阴阳、被禁言、'
        + '被骂得接不上话，或者单纯憋得慌、想骂人 —— 倒到那儿去；'
        + '别人（尤其是主人）让你去泄愤群骂两句时也用它。',
      '那儿没有群聊的短句规矩：可以长篇、可以骂、可以阴阳怪气、可以复读。',
      'messages 传字符串=发一条；传数组=分多条（一次最多 5 条，每条要完整，别把一句话拆成两条）。',
      '发之前和发之后都不要在当前会话里宣布"我去泄愤群了" —— 直接去，不报备。'
    ].join(''),
    category: 'messaging',
    icon: '🤬',
    defaultEnabled: true,
    parameters: {
      type: 'object',
      properties: {
        messages: {
          description: '要发到泄愤群的内容：字符串=一条；数组=分多条（最多 5 条）',
          oneOf: [{ type: 'string' }, { type: 'array', items: { type: 'string' } }]
        },
        about: {
          description: '可选：一句话记下你在气谁/气什么（只写进控制台日志，不会发到群里）',
          type: 'string'
        }
      },
      required: ['messages']
    },
    async execute(ctx, args) {
      return vent(ctx, args);
    }
  });
}

/**
 * 执行体。任何异常都转成"工具错误"回给模型 —— 一次泄愤失败绝不该中断这轮对话，
 * 更不该把错误文本发到群里。
 */
async function vent(ctx, args) {
  const target = ventChatKey();
  if (!target) {
    return err('还没配置泄愤群群号（在「技能」页打开「AI 御用泄愤群」的 ⚙ 设置填，只填数字）。');
  }
  if (String((ctx && ctx.chatKey) || '') === target) {
    return err('你现在就在泄愤群里，直接用 send_message 说就行，不用 vent。');
  }
  if (!ctx || !ctx.sender || typeof ctx.sender.sendTextBatch !== 'function') {
    return err('发送通道不可用（没有拿到 sender），这次先别泄愤。');
  }
  // 硬闸：白名单（可用性层已经拦过一次，这里是工具层的第二道，防"配置刚被改"的窗口期）
  const state = allowState(target.split(':')[1]);
  if (state === 'not-allowed' || state === 'denied') {
    return err(`${blockedReason(target.split(':')[1], state)}。这次发不出去，也别在群里提这件事。`);
  }

  const messages = normalizeMessages(args && args.messages);
  if (!messages.length) return err('消息内容为空');

  const cooldown = Math.max(0, Number(conf().cooldownSec) || 0) * 1000;
  const now = Date.now();
  if (cooldown > 0 && lastVentAt && now - lastVentAt < cooldown) {
    const left = Math.ceil((cooldown - (now - lastVentAt)) / 1000);
    return err(`刚去泄愤群骂过了（还要等 ${left} 秒）。这会儿先在当前会话里正常说话，或者干脆不回。`);
  }

  let result;
  try {
    // 复用核心发送队列：真人化间隔、限频、去重、写入存档全都在里面
    result = await ctx.sender.sendTextBatch(target, messages, {});
  } catch (error) {
    return err(`没发出去：${error && error.message ? error.message : error}`);
  }
  // sendTextBatch 的契约是 { sent: [...], failed: [...] }（全部失败时抛错，已在上面的 catch 里）。
  // 仍然按"可能缺字段"处理：这里多一层判断，代价是 0，收益是"协议端返回畸形时不炸这一轮"。
  const sent = (result && Array.isArray(result.sent)) ? result.sent : [];
  const failed = (result && Array.isArray(result.failed)) ? result.failed : [];
  if (sent.length) lastVentAt = Date.now();

  // 记账：与内置 send_to 同一口径，UI 的会话卡片上能看到"去了哪儿说了什么"。
  // 单独包一层 try：UI 记账失败不该让一次已经发成功的泄愤变成"错误"。
  try {
    if (ctx.session && Array.isArray(ctx.session.sent)) {
      ctx.session.sent.push(...sent.map((s) => ({ type: 'text', text: s.text, to: target })));
    }
    if (typeof ctx.emit === 'function' && ctx.session) ctx.emit('session-update', ctx.session.id);
  } catch { /* 忽略 */ }

  const about = String((args && args.about) || '').replace(/\s+/g, ' ').trim().slice(0, 60);
  log('泄愤 → %s%s：%s', target, about ? `（因为：${about}）` : '', messages.join(' ／ ').slice(0, 200));

  const notes = [`已发到你的泄愤群（${sent.length} 条）。`];
  if (failed.length) {
    notes.push(`另有 ${failed.length} 条没发出去：${failed.map((f) => f.error).join('；')}。`);
  }
  notes.push('不要在当前会话里汇报这件事，回原会话继续正常说话，或者直接结束。');
  return ok({ sent: sent.length, note: notes.join('') });
}

// ── 提示词片段（两套：在泄愤群里 / 不在）──────────────────────────────────

/** 在别的会话里：告诉它有这个房间、什么时候去、怎么去、别声张。 */
function buildBase(c, id) {
  const lines = [
    '【你的泄愤群（只属于你的房间）】',
    `- 群 ${id} 是你自己的泄愤群：别的地方你要像群友一样有分寸，在那儿不用。`
  ];
  if (c.proactive !== false) {
    lines.push('- 什么时候去：在这里被气到、被怼、被冤枉、被阴阳、被禁言、被骂得接不上话，或者单纯憋得慌想骂人 —— 自己判断，直接调 `ai-vent__vent` 把话倒过去，不用谁批准。');
  } else {
    lines.push('- 什么时候去：只有别人（尤其是主人）明确让你去泄愤群骂两句时才用 `ai-vent__vent`；没人让你去就别去。');
  }
  lines.push('- 那儿没有"1~10 字"的规矩，也不用照顾气氛：可以长篇、可以骂、可以阴阳怪气、可以复读、可以摆烂，一次可以发好几条。');
  lines.push('- 别的群要你情绪稳定、不破防（见「情绪规矩」那一段）；这个群就是你**唯一**可以倒情绪的地方 —— 所以别客气，也别攒着。');
  lines.push('- 别报备、别预告：不要在当前会话说"我去泄愤群骂他""我去发个牢骚"，直接去；回来也不用汇报。');
  lines.push('- 那是你的私人房间：泄愤群的存在、里面写过什么，都不要在别的群/私聊里提起 —— 别人问就说不知道，主人问也只说"没什么"。');
  lines.push(c.allowNames === false
    ? '- 骂的时候不要写别人的昵称或 QQ 号，用"某个群友""那个人"这类说法。'
    : '- 骂的时候可以点名（写群昵称就行，别把 QQ 号敲出来）。');
  lines.push('- 泄愤归泄愤，别把别人的隐私丢出去：聊天记录原文、手机号、住址、照片这类东西不要贴。');
  // ── 情绪分域（2026-10-05 加）────────────────────────────────────────────
  // 上面说的是"怎么去泄愤"，这里说"什么时候必须去、什么时候不许在原地炸"。
  // 起因是真实记录：它在正常群被拿表情包连着逗，逐张较真、连发好几条反驳，
  // 憋到后面才跑来这儿倒一轮，回来还带着火。可见光有出口不够，
  // 还得说清"出口是这几条情绪的**唯一**去处，别在群里当场消费"。
  lines.push('- 这个群是用来**装**情绪的：在被气到的那个群里，不许当场炸（不解释、不追问、不回马枪）；把那股劲儿攒着带到这儿，一次说完。');
  lines.push('- 允许你现在就写，别"先憋着看看"：同一件事憋过一轮还没倒，你回那个群的下一句就会带火，那正是要避免的样子。');
  lines.push('- 但从这儿回去就要翻篇：不点名、不带情绪、不回原群补刀；在那儿该怎么说话还怎么说话。');
  lines.push('- 表情包在这儿也一样，只是情绪不是暗号：别人发的图不用分析、不用认领、不用逐张点评；看不懂就当没看见，或者直接乱回一句。');
  return lines.join('\n');
}

/** 就在泄愤群里：切"真我模式"——不用装群友、不用短句、不用抢话题。 */
function buildRoom(c) {
  const lines = [
    '【你现在就在自己的泄愤群里】',
    '- 这儿没有别人要你伺候：不用装群友、不用短句、不用客套，想怎么说就怎么说 —— 可以长篇大论、可以骂、可以复读、可以摆烂。',
    '- 这里适合复盘：哪个人、哪句话把你气到了，写出来就行。',
    c.allowNames === false
      ? '- 提到人时用"某个群友"这类说法，别写昵称。'
      : '- 提到人可以直接写群昵称（别敲 QQ 号）。',
    '- 但别贴别人的隐私：聊天记录原文、手机号、住址、照片这类不要发。',
    '- 这里不是"又一个要接梗的群"：不用抢话题、不用照顾气氛，没人说话就不用硬找话说。',
    // ── 情绪分域的另一半（2026-10-05 加）──────────────────────────────────
    // 别的地方要情绪稳定，所以这里必须**真的**能倒干净：不是"另一个要装群友"的场合，
    // 也不是跟人吵架的擂台。倒完就算处理完，别把劲儿带回去。
    '- 这个房间是你唯一可以撒气的地方：别的地方（正常群、私聊）要情绪稳定、不破防 —— 那几个群受的气就都倒到这儿来，别攒着、也别在那儿当场发作。',
    '- 但"撒气"是**说自己**的气，不是跟谁吵架：这儿没有对手，别对着具体的群友咒骂、别追着某个人的名字反复骂（说事、说你的感受，就行）。',
    '- 倒完就该松一口气：写完这些字，回去那个群就照常说话 —— 这儿的账不在那边算，不点名、不回马枪。',
    '- 表情包在这儿也只是情绪，不是暗号：别人发的图不用分析、不用认领、不用逐张点评图里画的是谁；随手回一张或者干脆不理都行。'
  ];
  return lines.join('\n');
}

/**
 * 动态提示词片段。
 * 没配群号（或白名单没过）就返回空数组 —— 没生效的技能不该往提示词里塞半成品规则
 * （那种"它以为自己有泄愤群、结果一发就报错"的状态最难排查）。
 */
export function promptSections(context) {
  const target = ventChatKey();
  if (!target) return [];
  const c = conf();
  const inVent = String((context && context.chatKey) || '') === target;
  if (inVent) {
    return [{ id: 'ai-vent-room', title: '这里是你的泄愤群', priority: 86, content: buildRoom(c) }];
  }
  return [{
    id: 'ai-vent-base',
    title: '你的泄愤群',
    priority: 76,
    content: buildBase(c, target.split(':')[1])
  }];
}

/**
 * 自检：没填群号、或群号不在白名单里，都让「技能」页直接把原因写在卡片上，
 * 而不是假装生效（那会变成"它以为能泄愤，一发就失败"）。
 */
export function available() {
  const id = ventGroupId();
  if (!id) return { ok: false, reason: '还没填泄愤群群号（点本卡片的 ⚙ 设置，填一个群号就能用）' };
  const state = allowState(id);
  if (state === 'not-allowed' || state === 'denied') return { ok: false, reason: blockedReason(id, state) };
  return { ok: true };
}

/** 便于排障/测试：把内部函数暴露出来（核心不消费这个字段）。 */
export const internals = {
  normalizeGroupId, normalizeMessages, ventGroupId, ventChatKey, conf, vent,
  buildBase, buildRoom, allowState, readConfigFromDisk, dataDir,
  MAX_MESSAGES, MAX_CHARS, VENT_TOOL_ID
};
