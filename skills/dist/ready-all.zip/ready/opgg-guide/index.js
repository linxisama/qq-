// 英雄联盟出装 / 符文 / 海克斯查询（LLM 型 · skills/opgg-guide/）
//
// 只做两个模式（2026-10-22 改版，用户定的）：
//   · 海克斯大乱斗（默认）—— op.gg 的 ARAM: Mayhem
//       /lol/modes/aram-mayhem/<slug>/build   梯队、推荐海克斯、出装、加点
//       /lol/modes/aram-mayhem/<slug>/runes   推荐符文页
//   · 单双排 —— op.gg 的 Ranked Solo/Duo
//       /lol/champions/<slug>/build           胜率/登场/禁用、符文、出装、加点、对位
//
// ⚠️ 海克斯大乱斗目前**没有胜率/登场率数据**（2026-10-22 实测：亚索/布兰德/伊泽瑞尔/金克丝，
//    各版本与地区参数都是 0 个百分比）。op.gg 只给梯队和推荐。等 op.gg 补上数据，
//    这里的 parseStats 会自动读到，排版也会自动带上——不需要改代码，别把"没数据"写死。
//
// 中文名来源：装备/符文/召唤师技能走 Data Dragon（zh_CN）；
//            海克斯走 Riot 的 cherry-augments（default 英文 + zh_cn 中文，按 id 对齐）。
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const DIR = path.dirname(fileURLToPath(import.meta.url));
const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36';
const SITE = 'https://op.gg';

const MODE_META = {
  mayhem: {
    label: '海克斯大乱斗',
    // 海克斯大乱斗开局不选符文（大乱斗模式符文是自动的），所以这里没有 runes 页
    build: (slug) => `/lol/modes/aram-mayhem/${slug}/build`,
  },
  ranked: {
    label: '单双排',
    build: (slug) => `/lol/champions/${slug}/build`,
  },
};

const POSITION_ZH = {
  top: '上单', jungle: '打野', middle: '中单', mid: '中单',
  bottom: '下路', adc: '下路', support: '辅助', utility: '辅助',
};

// 召唤师技能的口语叫法（官方译名有的太书面，群里不这么说）
const SPELL_ZH_OVERRIDE = {
  SummonerSnowball: '雪球', SummonerDot: '点燃', SummonerFlash: '闪现',
  SummonerExhaust: '虚弱', SummonerHeal: '治疗', SummonerBarrier: '屏障',
  SummonerTeleport: '传送', SummonerSmite: '惩戒', SummonerGhost: '疾跑',
  SummonerCleanse: '净化', SummonerBoost: '净化',
};

// 群聊里最常见的外号 → ddragon id。只收真的会有人说出口的，不做穷举。
const ALIASES = {
  // ── 上单 / 战士 ──
  剑魔: 'Aatrox', 暗裔剑魔: 'Aatrox', 亚托克斯: 'Aatrox',
  诺手: 'Darius', 诺克: 'Darius', 洛克: 'Darius', 诺克萨斯之手: 'Darius', 德莱厄斯: 'Darius',
  盖伦: 'Garen', 德玛: 'Garen', 德玛西亚之力: 'Garen', 草丛伦: 'Garen', 大宝剑: 'Garen',
  武器: 'Jax', 武器大师: 'Jax', 贾克斯: 'Jax', 灯神: 'Jax',
  剑姬: 'Fiora', 菲奥娜: 'Fiora', 无双剑姬: 'Fiora',
  刀妹: 'Irelia', 女刀: 'Irelia', 艾瑞莉娅: 'Irelia', 刀锋舞者: 'Irelia',
  锐雯: 'Riven', 瑞文: 'Riven', 放逐之刃: 'Riven', 锐萌萌: 'Riven',
  剑圣: 'MasterYi', 无极剑圣: 'MasterYi', 易大师: 'MasterYi', yi: 'MasterYi',
  蛮王: 'Tryndamere', 蛮子: 'Tryndamere', 泰达米尔: 'Tryndamere',
  猴子: 'MonkeyKing', 悟空: 'MonkeyKing', 孙悟空: 'MonkeyKing', 齐天大圣: 'MonkeyKing', 猴哥: 'MonkeyKing',
  鳄鱼: 'Renekton', 雷克顿: 'Renekton', 荒漠屠夫: 'Renekton',
  狗头: 'Nasus', 内瑟斯: 'Nasus', 沙漠死神: 'Nasus',
  大虫子: 'Chogath', 虫子: 'Chogath', 科加斯: 'Chogath', 虚空恐惧: 'Chogath',
  石头人: 'Malphite', 石头: 'Malphite', 墨菲特: 'Malphite', 熔岩巨兽: 'Malphite', 混分巨兽: 'Malphite',
  铁男: 'Mordekaiser', 莫德凯撒: 'Mordekaiser', 铁铠冥魂: 'Mordekaiser',
  塞恩: 'Sion', 亡灵战神: 'Sion', 老司机: 'Sion',
  炼金: 'Singed', 辛吉德: 'Singed', 炼金术士: 'Singed', 毒王: 'Singed',
  约里克: 'Yorick', 牧魂人: 'Yorick', 掘墓: 'Yorick', 掘墓人: 'Yorick',
  奥拉夫: 'Olaf', 狂战士: 'Olaf', 拉夫: 'Olaf',
  巨魔: 'Trundle', 特朗德尔: 'Trundle', 巨魔之王: 'Trundle',
  乌迪尔: 'Udyr', 兽灵行者: 'Udyr',
  波比: 'Poppy', 圣锤之毅: 'Poppy',
  奎桑提: 'KSante', ksante: 'KSante',
  腕豪: 'Sett', 瑟提: 'Sett',
  克烈: 'Kled', 暴怒骑士: 'Kled',
  安蓓萨: 'Ambessa', 安倍萨: 'Ambessa',
  卡蜜尔: 'Camille', 卡密尔: 'Camille', 青钢影: 'Camille',
  格温: 'Gwen', 灵罗娃娃: 'Gwen',
  奥恩: 'Ornn', 山隐之焰: 'Ornn',
  纳尔: 'Gnar', gnar: 'Gnar',
  慎: 'Shen', 暮光之眼: 'Shen', 肾: 'Shen',
  潘森: 'Pantheon', 战争之王: 'Pantheon', 斯巴达: 'Pantheon',
  厄加特: 'Urgot', 螃蟹: 'Urgot', 无畏战车: 'Urgot',

  // ── 打野 ──
  瞎子: 'LeeSin', 盲僧: 'LeeSin', 李青: 'LeeSin', 盲仔: 'LeeSin',
  赵信: 'XinZhao', 德邦总管: 'XinZhao', 菊花信: 'XinZhao',
  皇子: 'JarvanIV', 嘉文: 'JarvanIV', 嘉文四世: 'JarvanIV', 德玛西亚皇子: 'JarvanIV', j4: 'JarvanIV',
  蜘蛛: 'Elise', 伊莉丝: 'Elise', 蜘蛛女皇: 'Elise',
  豹女: 'Nidalee', 奈德丽: 'Nidalee', 狂野女猎手: 'Nidalee',
  狮子狗: 'Rengar', 雷恩加尔: 'Rengar', 傲之追猎者: 'Rengar',
  螳螂: 'Khazix', 卡兹克: 'Khazix', 虚空掠夺者: 'Khazix',
  挖掘机: 'RekSai', 雷克塞: 'RekSai', 虚空遁地兽: 'RekSai',
  男枪: 'Graves', 格雷福斯: 'Graves', 法外狂徒: 'Graves',
  寡妇: 'Evelynn', 伊芙琳: 'Evelynn',
  人马: 'Hecarim', 赫卡里姆: 'Hecarim', 战争之影: 'Hecarim',
  梦魇: 'Nocturne', 魔腾: 'Nocturne', 永恒梦魇: 'Nocturne',
  稻草人: 'Fiddlesticks', 费德提克: 'Fiddlesticks', 末日使者: 'Fiddlesticks',
  凯隐: 'Kayn', 影流之镰: 'Kayn',
  龙女: 'Shyvana', 希瓦娜: 'Shyvana', 龙血武姬: 'Shyvana',
  千珏: 'Kindred', 千钰: 'Kindred', 永猎双子: 'Kindred',
  岩雀: 'Taliyah', 塔莉垭: 'Taliyah',
  翠神: 'Ivern', 艾翁: 'Ivern',
  妮蔻: 'Neeko', 万花通灵: 'Neeko',
  狼人: 'Warwick', 沃里克: 'Warwick', 嗜血猎手: 'Warwick', 祖安怒兽: 'Warwick', ww: 'Warwick',
  狗熊: 'Volibear', 沃利贝尔: 'Volibear', 雷霆咆哮: 'Volibear',
  蝎子: 'Skarner', 斯卡纳: 'Skarner', 水晶先锋: 'Skarner',
  卑尔维斯: 'Belveth', 虚空女皇: 'Belveth', belveth: 'Belveth',
  佛耶戈: 'Viego', 破败之王: 'Viego',
  莉莉娅: 'Lillia', 鹿女: 'Lillia',
  布蕾尔: 'Briar', 布里尔: 'Briar', briar: 'Briar',
  纳亚菲利: 'Naafiri', 纳菲利: 'Naafiri',
  扎克: 'Zac', 生化魔人: 'Zac',
  猪妹: 'Sejuani', 瑟庄妮: 'Sejuani', 凛冬之怒: 'Sejuani',
  雪人: 'Nunu', 努努: 'Nunu', 雪人骑士: 'Nunu', 威朗普: 'Nunu',
  艾克: 'Ekko', 时间刺客: 'Ekko',
  阿克尚: 'Akshan',
  芮尔: 'Rell', 镕铁少女: 'Rell',

  // ── 中单 ──
  亚索: 'Yasuo', 风男: 'Yasuo', 快乐风男: 'Yasuo', 疾风剑豪: 'Yasuo', 托儿索: 'Yasuo', 索子哥: 'Yasuo',
  永恩: 'Yone', 封魔剑魂: 'Yone',
  劫: 'Zed', 影流之主: 'Zed', 火影: 'Zed', zed: 'Zed',
  阿卡丽: 'Akali', 阿卡莉: 'Akali', 离群之刺: 'Akali',
  卡特: 'Katarina', 卡特琳娜: 'Katarina', 不祥之刃: 'Katarina',
  卡牌: 'TwistedFate', 崔斯特: 'TwistedFate', 卡牌大师: 'TwistedFate', tf: 'TwistedFate',
  发条: 'Orianna', 奥莉安娜: 'Orianna', 发条魔灵: 'Orianna',
  球女: 'Syndra', 辛德拉: 'Syndra', 暗黑元首: 'Syndra',
  火男: 'Brand', 布兰德: 'Brand', 复仇焰魂: 'Brand',
  火女: 'Annie', 安妮: 'Annie', 黑暗之女: 'Annie',
  小法: 'Veigar', 维迦: 'Veigar', 邪恶小法师: 'Veigar',
  大眼: 'Velkoz', 维克兹: 'Velkoz', 虚空之眼: 'Velkoz',
  蚂蚱: 'Malzahar', 玛尔扎哈: 'Malzahar', 马尔扎哈: 'Malzahar', 虚空先知: 'Malzahar',
  小鱼人: 'Fizz', 鱼人: 'Fizz', 菲兹: 'Fizz', 潮汐海灵: 'Fizz',
  吸血鬼: 'Vladimir', 弗拉基米尔: 'Vladimir', 猩红收割者: 'Vladimir',
  死歌: 'Karthus', 卡尔萨斯: 'Karthus', 死亡颂唱者: 'Karthus',
  冰女: 'Lissandra', 丽桑卓: 'Lissandra', 冰霜女巫: 'Lissandra',
  冰鸟: 'Anivia', 艾尼维亚: 'Anivia', 冰晶凤凰: 'Anivia', 凤凰: 'Anivia',
  蛇女: 'Cassiopeia', 卡西奥佩娅: 'Cassiopeia', 魔蛇之拥: 'Cassiopeia',
  沙皇: 'Azir', 阿兹尔: 'Azir', 沙漠皇帝: 'Azir',
  佐伊: 'Zoe', 暮光星灵: 'Zoe',
  维克托: 'Viktor', 三只手: 'Viktor', 机械先驱: 'Viktor',
  狐狸: 'Ahri', 阿狸: 'Ahri', 九尾妖狐: 'Ahri', 九尾: 'Ahri',
  泽拉斯: 'Xerath', 远古巫灵: 'Xerath',
  婕拉: 'Zyra', 荆棘之兴: 'Zyra',
  薇克丝: 'Vex', 愁云使者: 'Vex', vex: 'Vex',
  梅尔: 'Mel', mel: 'Mel',
  慧: 'Hwei', 彗: 'Hwei', 画师: 'Hwei', hwei: 'Hwei',
  基兰: 'Zilean', 时光守护者: 'Zilean', 时光: 'Zilean',
  奥罗拉: 'Aurora', 欧罗拉: 'Aurora', aurora: 'Aurora',
  卡萨丁: 'Kassadin', 虚空行者: 'Kassadin',
  塞拉斯: 'Sylas', 解脱者: 'Sylas',
  奇亚娜: 'Qiyana', 琪亚娜: 'Qiyana', 元素女皇: 'Qiyana',
  泰隆: 'Talon', 男刀: 'Talon', 刀锋之影: 'Talon',

  // ── ADC ──
  薇恩: 'Vayne', 韦恩: 'Vayne', vn: 'Vayne', 暗夜猎手: 'Vayne',
  伊泽瑞尔: 'Ezreal', 伊泽: 'Ezreal', ez: 'Ezreal', 探险家: 'Ezreal', 小黄毛: 'Ezreal', 黄毛: 'Ezreal',
  卡莎: 'Kaisa', 卡沙: 'Kaisa', 虚空之女: 'Kaisa', kaisa: 'Kaisa',
  女枪: 'MissFortune', 厄运小姐: 'MissFortune', 赏金猎人: 'MissFortune', mf: 'MissFortune', 赏金: 'MissFortune',
  女警: 'Caitlyn', 凯特琳: 'Caitlyn', 皮城女警: 'Caitlyn',
  奥巴马: 'Lucian', 卢锡安: 'Lucian', 圣枪游侠: 'Lucian', 卢仙: 'Lucian', 卢西恩: 'Lucian',
  德莱文: 'Draven', 荣耀行刑官: 'Draven',
  小炮: 'Tristana', 崔丝塔娜: 'Tristana', 麦林炮手: 'Tristana',
  轮子妈: 'Sivir', 希维尔: 'Sivir', 战争女神: 'Sivir',
  大嘴: 'KogMaw', 克格莫: 'KogMaw', 深渊巨口: 'KogMaw',
  老鼠: 'Twitch', 图奇: 'Twitch', 瘟疫之源: 'Twitch',
  寒冰: 'Ashe', 艾希: 'Ashe', 冰弓: 'Ashe',
  维鲁斯: 'Varus', 韦鲁斯: 'Varus', 惩戒之箭: 'Varus',
  烬: 'Jhin', 戏命师: 'Jhin',
  金克丝: 'Jinx', 金克斯: 'Jinx', 暴走萝莉: 'Jinx',
  卡莉丝塔: 'Kalista', 复仇之矛: 'Kalista', 滑板鞋: 'Kalista',
  厄斐琉斯: 'Aphelios', 吴亦凡: 'Aphelios', 月男: 'Aphelios', aphelios: 'Aphelios',
  莎弥拉: 'Samira', 莎米拉: 'Samira', 沙漠玫瑰: 'Samira',
  赛娜: 'Senna', 涤魂圣枪: 'Senna',
  泽丽: 'Zeri', 祖安花火: 'Zeri', zeri: 'Zeri',
  斯莫德: 'Smolder', 小火龙: 'Smolder', smolder: 'Smolder',
  尼菈: 'Nilah', 不羁之悦: 'Nilah',
  奎因: 'Quinn', 德玛西亚之翼: 'Quinn',

  // ── 辅助 ──
  锤石: 'Thresh', 魂锁典狱长: 'Thresh',
  机器人: 'Blitzcrank', 机器: 'Blitzcrank', 蒸汽机器人: 'Blitzcrank', 布里茨: 'Blitzcrank',
  牛头: 'Alistar', 牛头人: 'Alistar', 阿利斯塔: 'Alistar', 奶牛: 'Alistar',
  日女: 'Leona', 蕾欧娜: 'Leona', 曙光女神: 'Leona',
  风女: 'Janna', 迦娜: 'Janna', 风暴之怒: 'Janna',
  琴女: 'Sona', 娑娜: 'Sona', 琴瑟仙女: 'Sona', sona: 'Sona',
  星妈: 'Soraka', 索拉卡: 'Soraka', 众星之子: 'Soraka', 奶妈: 'Soraka',
  扇子妈: 'Karma', 卡尔玛: 'Karma', 天启者: 'Karma',
  璐璐: 'Lulu', 露露: 'Lulu', 仙灵女巫: 'Lulu',
  莫甘娜: 'Morgana', 堕落天使: 'Morgana',
  娜美: 'Nami', 唤潮鲛姬: 'Nami',
  布隆: 'Braum', 弗雷尔卓德之心: 'Braum',
  塔姆: 'TahmKench', 蛤蟆: 'TahmKench', 河流之王: 'TahmKench',
  巴德: 'Bard', 星界游神: 'Bard',
  泰坦: 'Nautilus', 诺提勒斯: 'Nautilus', 深海泰坦: 'Nautilus',
  派克: 'Pyke', 血港鬼影: 'Pyke',
  洛: 'Rakan', 幻翎: 'Rakan',
  霞: 'Xayah', 逆羽: 'Xayah',
  悠米: 'Yuumi', 猫: 'Yuumi', 猫咪: 'Yuumi', 猫猫: 'Yuumi', 魔法猫咪: 'Yuumi',
  烈娜塔: 'Renata', 炼金男爵: 'Renata',
  萨勒芬妮: 'Seraphine', 星籁歌姬: 'Seraphine', 酸辣粉: 'Seraphine',
  米利欧: 'Milio',
  塔里克: 'Taric', 宝石: 'Taric', 瓦罗兰之盾: 'Taric',

  // ── 大乱斗 / 竞技场常客 ──
  俄洛伊: 'Illaoi', 俄洛依: 'Illaoi', 海兽祭司: 'Illaoi', 章鱼妈: 'Illaoi', 触手妈: 'Illaoi',
  大发明家: 'Heimerdinger', 黑默丁格: 'Heimerdinger',
  炸弹人: 'Ziggs', 吉格斯: 'Ziggs', 爆破鬼才: 'Ziggs',
  提莫: 'Teemo', 蘑菇: 'Teemo',
  小丑: 'Shaco', 萨科: 'Shaco', 恶魔小丑: 'Shaco',
  龙龟: 'Rammus', 拉莫斯: 'Rammus', 披甲龙龟: 'Rammus',
  大树: 'Maokai', 茂凯: 'Maokai', 扭曲树精: 'Maokai',
  加里奥: 'Galio', 正义巨像: 'Galio',
  蒙多: 'DrMundo', 祖安狂人: 'DrMundo', 蒙多医生: 'DrMundo',
  酒桶: 'Gragas', 古拉加斯: 'Gragas',
};

// ── 运行时状态 ───────────────────────────────────────────────────────────
let fetchImpl = typeof fetch === 'function' ? fetch : null;
let log = () => {};
let warn = () => {};
let getSettings = () => ({});

const pageCache = new Map();   // url -> { ts, text }
let mapsPromise = null;        // Data Dragon 名称表
let augmentsPromise = null;    // 海克斯中文名
let champTable = null;         // champions.json

function settings() {
  const s = getSettings() || {};
  const modeZh = {
    海克斯大乱斗: 'mayhem', 海克斯: 'mayhem', 大乱斗: 'mayhem', 极地大乱斗: 'mayhem',
    单双排: 'ranked', 排位: 'ranked', 峡谷: 'ranked',
  };
  const dm = String(s.defaultMode || 'mayhem');
  return {
    timeoutMs: Math.min(40000, Math.max(4000, Number(s.timeoutMs) || 15000)),
    defaultMode: modeZh[dm] || dm,
    showCounters: s.showCounters !== false,
    cacheMinutes: Math.min(60, Math.max(0, Number(s.cacheMinutes) ?? 10)),
  };
}

function cacheTtl() {
  const m = settings().cacheMinutes;
  return m > 0 ? m * 60 * 1000 : 0;
}

// ── HTTP ────────────────────────────────────────────────────────────────
async function getText(url, { json = false, timeoutMs = 0 } = {}) {
  const ttl = cacheTtl();
  const hit = pageCache.get(url);
  if (ttl > 0 && hit && Date.now() - hit.ts < ttl) return hit.text;

  const ms = timeoutMs || settings().timeoutMs;
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), ms);
  try {
    const res = await fetchImpl(url, {
      signal: ctrl.signal,
      redirect: 'follow',
      headers: {
        'User-Agent': UA,
        'Accept': json ? 'application/json' : 'text/html,application/xhtml+xml',
        'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8',
      },
    });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const text = await res.text();
    if (!text) throw new Error('空响应');
    pageCache.set(url, { ts: Date.now(), text });
    return text;
  } catch (e) {
    const msg = e?.name === 'AbortError' ? `超时（${ms}ms）` : (e?.message ?? String(e));
    throw new Error(msg);
  } finally {
    clearTimeout(timer);
  }
}

// ── HTML 小工具 ──────────────────────────────────────────────────────────
function decodeEntities(s) {
  return String(s ?? '')
    .replace(/&amp;/g, '&').replace(/&#x27;/g, "'").replace(/&#39;/g, "'")
    .replace(/&quot;/g, '"').replace(/&lt;/g, '<').replace(/&gt;/g, '>')
    .replace(/&nbsp;/g, ' ').replace(/&#x2F;/g, '/')
    .replace(/<!--[\s\S]*?-->/g, '');
}

function toText(html) {
  return decodeEntities(String(html ?? '').replace(/<[^>]+>/g, ' ')).replace(/\s+/g, ' ').trim();
}

function cleanPage(html) {
  return String(html ?? '')
    .replace(/<script[\s\S]*?<\/script>/gi, ' ')
    .replace(/<style[\s\S]*?<\/style>/gi, ' ')
    .replace(/<svg[\s\S]*?<\/svg>/gi, ' ');
}

function imgsIn(html) {
  return [...String(html).matchAll(/<img[^>]*?alt="([^"]*)"[^>]*?src="([^"]*)"/gi)].map((m) => {
    const src = decodeEntities(m[2]);
    const mm = src.match(/\/(item|perk|perkStyle|spell|champion|augment|aram-augment)\/([^/.?"]+?)(?:_large)?\.(?:png|webp)/i);
    return { name: decodeEntities(m[1]), kind: mm ? mm[1] : '', id: mm ? mm[2] : '' };
  });
}

function pctsIn(html) {
  return [...String(html).matchAll(/([\d.]+)%/g)].map((m) => Number(m[1]));
}

function parseRow(tr) {
  const cells = [...tr.matchAll(/<td[^>]*>([\s\S]*?)<\/td>/gi)].map((m) => {
    const html = m[1];
    return { icons: imgsIn(html), pcts: pctsIn(html), text: toText(html) };
  });
  const icons = cells.flatMap((c) => c.icons);
  const pcts = cells.flatMap((c) => c.pcts);
  const games = [...tr.matchAll(/>([\d,]+)<!-- --> <!-- -->Games</g)].map((m) => Number(m[1].replace(/,/g, '')));
  return { cells, icons, pcts, games };
}

function parseTables(html) {
  return [...html.matchAll(/<table[\s\S]*?<\/table>/gi)].map((m) => {
    const t = m[0];
    const caption = toText((t.match(/<caption[^>]*>([\s\S]*?)<\/caption>/i) || [, ''])[1]);
    const heads = [...t.matchAll(/<th[^>]*>([\s\S]*?)<\/th>/gi)].map((x) => toText(x[1]));
    const rows = [...t.matchAll(/<tr[^>]*>([\s\S]*?)<\/tr>/gi)]
      .map((x) => parseRow(x[1]))
      .filter((r) => r.icons.length || r.pcts.length);
    return { caption, heads, rows };
  });
}

function tableByCaption(tables, caption) {
  return tables.find((t) => t.caption === caption) || null;
}

/** 按表头名取这一行的百分比；表头数与单元格数对不上时返回 null */
function cellPct(table, row, nameRe) {
  const heads = table?.heads || [];
  const cells = row?.cells || [];
  if (!heads.length || heads.length !== cells.length) return null;
  const i = heads.findIndex((h) => nameRe.test(h));
  if (i < 0) return null;
  return cells[i]?.pcts?.[0] ?? null;
}

// ── 页面解析 ────────────────────────────────────────────────────────────
function parseStats(html) {
  const text = toText(html);
  const num = (label) => {
    const m = text.match(new RegExp(label + '\\s*([\\d.]+)'));
    return m ? Number(m[1]) : null;
  };
  const patch = (text.match(/Patch\s+(\d+\.\d+)/) || [])[1] || '';
  const posRaw = (text.match(/Build for ([A-Za-z]+),/i) || [])[1] || '';
  const tierRaw = text.match(/(\d)\s*Tier/);
  return {
    patch,
    position: POSITION_ZH[posRaw.toLowerCase()] || '',
    tier: tierRaw ? Number(tierRaw[1]) : null,
    winRate: num('Win rate'),
    pickRate: num('Pick rate'),
    banRate: num('Ban rate'),
  };
}

/**
 * 符文页：主系 + 基石 + 副系。
 *
 * 锚点是**第一个基石图标**（/perk/xxxx.png），不是第一个 /perkStyle/ ——
 * 页面顶部有个小挂件单独引用了 perkStyle，从它起算会把主系/副系整个错位。
 * 海克斯大乱斗的符文页前面还有一张「全部符文」选择器大表，所以先用 Keystones
 * 这个标题把起点切掉，只解析推荐卡片。
 */
function parseRunes(html, maps) {
  let body = String(html);
  const anchor = body.indexOf('Keystones');
  if (anchor >= 0) body = body.slice(anchor);

  const re = /alt="([^"]+)"[^>]*src="[^"]*\/(perk|perkStyle)\/(\d+)\.png/gi;
  const all = [...body.matchAll(re)].map((m) => ({ kind: m[2], id: Number(m[3]), name: decodeEntities(m[1]), index: m.index }));
  if (!all.length) return null;
  const keyStones = all.filter((x) => x.kind === 'perk');
  if (!keyStones.length) return null;

  for (const key of keyStones.slice(0, 8)) {
    const before = all.filter((x) => x.kind === 'perkStyle' && x.index < key.index).pop();
    const sub = all.find((x) => x.kind === 'perkStyle' && x.index > key.index);
    if (!before) continue;
    const treeOf = maps?.runeTree;
    if (treeOf && treeOf.size && treeOf.get(key.id) !== before.id) continue;

    const after = body.slice(key.index, key.index + 9000);
    const subIdx = sub ? after.indexOf(`/perkStyle/${sub.id}.png`) : -1;
    const statSeg = subIdx >= 0 ? after.slice(subIdx) : after;
    const pcts = pctsIn(statSeg);
    const games = (statSeg.match(/>([\d,]+)<!-- --> <!-- -->Games</) || [])[1];
    return {
      mainTree: before, keystone: key, subTree: sub || null,
      pickRate: pcts[0] ?? null, winRate: pcts[1] ?? null,
      games: games ? Number(games.replace(/,/g, '')) : null,
    };
  }
  return null;
}

/** 克制/被克制：每条是一个 <li>，名字、胜率、场次都在里面 */
function parseCounters(html) {
  const out = { weak: [], strong: [] };
  for (const [key, label] of [['weak', 'Weak against'], ['strong', 'Strong against']]) {
    const at = html.indexOf(label);
    if (at < 0) continue;
    const seg = html.slice(at, at + 6000);
    for (const m of seg.matchAll(/<li>([\s\S]*?)<\/li>/gi)) {
      if (out[key].length >= 3) break;
      const block = m[1];
      const idm = block.match(/\/champion\/([^/?"]+)\.png/i);
      const altm = block.match(/alt="([^"]+)"[^>]*\/champion\//i);
      const pct = (block.match(/<strong[^>]*>([\d.]+)%<\/strong>/) || [])[1];
      if (!idm && !altm) continue;
      out[key].push({
        id: idm ? decodeEntities(idm[1]) : '',
        name: altm ? decodeEntities(altm[1]) : (idm ? decodeEntities(idm[1]) : ''),
        winRate: pct ? Number(pct) : null,
      });
    }
  }
  return out;
}

function skillLetter(id, champId) {
  let tail = String(id || '');
  const cid = String(champId || '');
  if (cid && tail.toLowerCase().startsWith(cid.toLowerCase())) tail = tail.slice(cid.length);
  const m = tail.match(/^[^A-Za-z]*([QWER])/i) || tail.match(/([QWER])/i);
  return m ? m[1].toUpperCase() : '';
}

function parseSkillOrder(html, champId) {
  const tables = parseTables(html);
  const t = tableByCaption(tables, 'SkillOrder Table');
  if (!t || !t.rows.length) return null;
  const row = t.rows[0];
  // 有的英雄这张表会把同一组技能重复渲染一遍（桌面/移动两套），按出现顺序去重
  const letters = [...new Set(row.icons.map((i) => skillLetter(i.id, champId)).filter(Boolean))].slice(0, 4);
  return {
    order: letters.length ? letters.join(' > ') : '',
    pickRate: row.pcts[0] ?? null,
    winRate: row.pcts[1] ?? null,
    games: row.games[0] ?? null,
  };
}

// ── 名称表 ──────────────────────────────────────────────────────────────
async function loadChampTable() {
  if (champTable) return champTable;
  const raw = JSON.parse(fs.readFileSync(path.join(DIR, 'champions.json'), 'utf8'));
  champTable = raw.champions || [];
  return champTable;
}

function ddragonVersionFrom(html) {
  const m = String(html).match(/meta\/images\/lol\/(\d+\.\d+\.\d+)\//);
  return m ? m[1] : '';
}

/** 把 op.gg 上的英文英雄名/图标名换成中文（对不上就原样返回） */
function champZh({ id = '', name = '' } = {}) {
  const list = champTable || [];
  const key = String(id).toLowerCase();
  const nm = String(name).toLowerCase();
  const hit = list.find((c) => String(c.id).toLowerCase() === key || String(c.slug) === key)
    || list.find((c) => String(c.en).toLowerCase() === nm)
    || list.find((c) => String(c.id).toLowerCase() === nm);
  return hit ? hit.zh : (name || id);
}

async function loadMaps(versionHint) {
  if (mapsPromise) return mapsPromise;
  mapsPromise = (async () => {
    const ver = versionHint || await getText('https://ddragon.leagueoflegends.com/api/versions.json', { json: true })
      .then((t) => JSON.parse(t)[0]).catch(() => '');
    if (!ver) throw new Error('取不到 Data Dragon 版本号');
    const base = `https://ddragon.leagueoflegends.com/cdn/${ver}/data/zh_CN`;
    const [items, runes, spells] = await Promise.all([
      getText(`${base}/item.json`, { json: true }).then(JSON.parse).catch(() => null),
      getText(`${base}/runesReforged.json`, { json: true }).then(JSON.parse).catch(() => null),
      getText(`${base}/summoner.json`, { json: true }).then(JSON.parse).catch(() => null),
    ]);
    const itemName = new Map();
    for (const [id, it] of Object.entries(items?.data || {})) itemName.set(String(id), it.name);

    const runeName = new Map();
    const treeName = new Map();
    const runeTree = new Map();
    for (const tree of runes || []) {
      treeName.set(Number(tree.id), tree.name);
      for (const slot of tree.slots || []) {
        for (const r of slot.runes || []) {
          runeName.set(Number(r.id), r.name);
          runeTree.set(Number(r.id), Number(tree.id));
        }
      }
    }

    const spellName = new Map();
    for (const sp of Object.values(spells?.data || {})) spellName.set(String(sp.id), sp.name);

    return { ver, itemName, runeName, treeName, runeTree, spellName };
  })();
  return mapsPromise;
}

/**
 * 海克斯中文名：Riot 的 cherry-augments 按 id 对齐英文/中文两份。
 * op.gg 用的是图标名（SoulSiphon、UpgradeIE…），所以额外建一份"图标文件名 → 中文"的映射兜底。
 */
async function loadAugments() {
  if (augmentsPromise) return augmentsPromise;
  augmentsPromise = (async () => {
    const base = 'https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global';
    const [enRaw, zhRaw] = await Promise.all([
      getText(`${base}/default/v1/cherry-augments.json`, { json: true }),
      getText(`${base}/zh_cn/v1/cherry-augments.json`, { json: true }),
    ]);
    const en = JSON.parse(enRaw);
    const zh = JSON.parse(zhRaw);
    const zhById = new Map();
    for (const a of zh) zhById.set(String(a.id), a.nameTRA || a.simpleNameTRA || '');
    const byName = new Map();   // 英文名（小写）→ 中文
    const bySlug = new Map();   // 图标文件名（小写）→ 中文
    for (const a of en) {
      const cn = zhById.get(String(a.id));
      if (!cn) continue;
      const nm = String(a.nameTRA || '').toLowerCase();
      if (nm) byName.set(nm, cn);
      const icon = String(a.augmentSmallIconPath || '');
      const slug = path.basename(icon).replace(/_small\.png$/i, '').toLowerCase();
      if (slug && !bySlug.has(slug)) bySlug.set(slug, cn);
    }
    return { byName, bySlug };
  })();
  return augmentsPromise;
}

// ── 英雄名解析 ──────────────────────────────────────────────────────────
/** 剥掉「排位」「怎么出装」这类问法词：模型可能把整句原样塞进 champion */
const NOISE_RE = /(怎么出装|怎么玩|怎么打|怎么带|出装|符文|天赋|加点|装备|海克斯|大乱斗|极地大乱斗|单双排|排位|上分|胜率|攻略|推荐|套路|强度|梯队)/g;

function stripNoise(raw) {
  return String(raw)
    .replace(/^[@\s]+/, '')
    .replace(NOISE_RE, '')
    .replace(/[\s,，。！!？?的]+$/g, '')
    .trim();
}

// 拼音层：专门吃谐音和错字（压缩→亚索、韦恩→薇恩、俄洛依→俄洛伊、卡沙→卡莎）。
// 字表是《通用规范汉字表》8105 字，随技能一起打包，运行时不联网。
let pinyinMap = null;
function loadPinyin() {
  if (!pinyinMap) {
    try { pinyinMap = JSON.parse(fs.readFileSync(path.join(DIR, 'pinyin.json'), 'utf8')); } catch { pinyinMap = {}; }
  }
  return pinyinMap;
}

function pyOf(str) {
  const map = loadPinyin();
  return [...String(str)]
    .map((ch) => map[ch] || (/[a-z0-9]/i.test(ch) ? ch.toLowerCase() : ''))
    .join('');
}

/** 编辑距离≤1 用来吃「yasou」「kaisa」这类手滑拼错 */
function editDist(a, b) {
  if (a === b) return 0;
  if (!a.length || !b.length) return Math.max(a.length, b.length);
  let prev = Array.from({ length: b.length + 1 }, (_, j) => j);
  for (let i = 1; i <= a.length; i += 1) {
    const cur = [i];
    for (let j = 1; j <= b.length; j += 1) {
      cur[j] = Math.min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1));
    }
    prev = cur;
  }
  return prev[b.length];
}

function byPinyin(list, cand) {
  const py = pyOf(cand);
  if (py.length < 3) return [];
  const exact = list.filter((c) => (c.py || pyOf(c.zh)) === py);
  if (exact.length) return exact;
  return list.filter((c) => {
    const target = c.py || pyOf(c.zh);
    return Math.abs(target.length - py.length) <= 1 && editDist(py, target) <= 1;
  });
}

function uniqChamps(arr) {
  const seen = new Set();
  return arr.filter((c) => (seen.has(c.id) ? false : seen.add(c.id)));
}

async function resolveChampion(input) {
  const raw = String(input ?? '').trim();
  if (!raw) return { error: '没给英雄名。' };
  const list = await loadChampTable();
  const tries = [...new Set([stripNoise(raw), raw].filter(Boolean))];

  const exact = new Map();
  for (const c of list) {
    exact.set(c.zh.toLowerCase(), c);
    exact.set(c.en.toLowerCase(), c);
    exact.set(String(c.id).toLowerCase(), c);
    exact.set(String(c.title || '').toLowerCase(), c);
  }
  const aliasKeys = Object.keys(ALIASES).sort((a, b) => b.length - a.length);

  for (const cand of tries) {
    const key = cand.toLowerCase().replace(/[\s'’.·]/g, '');

    // ① 本名 / 英文名 / 称号
    if (exact.has(key)) return { champion: exact.get(key) };

    // ② 外号全等（英文缩写不分大小写：VN / Ez 也认）
    const aliasId = ALIASES[cand] || ALIASES[key];
    if (aliasId) {
      const c = list.find((x) => x.id === aliasId);
      if (c) return { champion: c };
    }

    // ③ 外号被包在句子里（「快乐风男怎么玩」）——按最长外号优先，避免「风男」抢在「快乐风男」前面
    const lowered = cand.toLowerCase();
    const embedded = aliasKeys.find((a) => a.length >= 2 && lowered.includes(a));
    if (embedded) {
      const c = list.find((x) => x.id === ALIASES[embedded]);
      if (c) return { champion: c };
    }

    // ④ 英文缩写：ez → Ezreal（纯字母且≥2 位时才按前缀找）
    if (/^[a-z0-9]{2,}$/.test(key)) {
      const pref = list.filter((c) => String(c.en).toLowerCase().startsWith(key) || String(c.slug).startsWith(key));
      if (pref.length === 1) return { champion: pref[0] };
    }

    // ⑤ 拼音：谐音、错字、用拼音打英文名
    const pyHits = uniqChamps(byPinyin(list, cand));
    if (pyHits.length === 1) return { champion: pyHits[0] };
    if (pyHits.length > 1) {
      return { error: `「${raw}」读音对得上好几个英雄：${pyHits.slice(0, 6).map((c) => `${c.zh}(${c.en})`).join('、')}。说清楚一点？` };
    }

    // ⑥ 中文名包含（「亚索怎么出装」这种没被剥干净的）
    const hits = list.filter((c) => {
      const zh = c.zh.toLowerCase();
      const en = String(c.en).toLowerCase();
      return (zh.length >= 2 && key.includes(zh)) || (en.length >= 3 && key.includes(en)) || (key.length >= 2 && zh.includes(key));
    });
    if (hits.length === 1) return { champion: hits[0] };
    if (hits.length > 1) {
      return { error: `「${raw}」对上了好几个英雄：${hits.slice(0, 6).map((c) => `${c.zh}(${c.en})`).join('、')}。说清楚一点？` };
    }
  }
  return { error: `没认出来「${raw}」是哪个英雄。给中文名（如 亚索）、英文名（Yasuo）、外号（风男/瞎子/章鱼妈）或者拼音（yasuo/ez/vn）都行。` };
}

// ── 数据抽取 ────────────────────────────────────────────────────────────
function spellNames(row, maps) {
  return row.icons.filter((i) => i.kind === 'spell')
    .map((i) => SPELL_ZH_OVERRIDE[i.id] || maps.spellName.get(i.id) || i.name);
}

function itemList(table, maps, limit = 3) {
  if (!table) return [];
  return table.rows.slice(0, limit).map((r) => ({
    items: r.icons.filter((i) => i.kind === 'item').map((i) => maps.itemName.get(i.id) || i.name),
    pickRate: cellPct(table, r, /pick rate/i) ?? r.pcts[0] ?? null,
    winRate: cellPct(table, r, /win rate/i) ?? r.pcts[1] ?? null,
    games: r.games[0] ?? null,
  })).filter((x) => x.items.length);
}

function depthItem(table, maps, limit = 2) {
  if (!table) return [];
  return table.rows.slice(0, limit).map((r) => ({
    item: maps.itemName.get(r.icons[0]?.id) || r.icons[0]?.name || '',
    winRate: cellPct(table, r, /win rate/i) ?? r.pcts[0] ?? null,
  })).filter((x) => x.item);
}

function firstSpells(tables, maps) {
  const t = tableByCaption(tables, 'SummonerSpells Table');
  if (!t || !t.rows.length) return null;
  const row = t.rows[0];
  const names = spellNames(row, maps);
  return names.length ? {
    names,
    pickRate: cellPct(t, row, /pick rate/i) ?? null,
    winRate: cellPct(t, row, /win rate/i) ?? null,
  } : null;
}

/** 海克斯：op.gg 的推荐列表（按推荐顺序），中文名来自 Riot 数据 */
async function parseAugments(clean) {
  let aug = null;
  try { aug = await loadAugments(); } catch { warn('opgg-guide: 海克斯中文名加载失败，用英文名兜底'); }
  const seen = new Set();
  const out = [];
  for (const icon of imgsIn(clean)) {
    if (icon.kind !== 'aram-augment') continue;
    const slug = String(icon.id).toLowerCase();
    if (!slug || seen.has(slug)) continue;
    if (/^generic/i.test(slug)) continue;             // 通用占位图，名字不可靠
    seen.add(slug);
    const zh = aug?.bySlug.get(slug) || aug?.byName.get(String(icon.name).toLowerCase()) || '';
    out.push({ name: zh || icon.name, en: icon.name });
    if (out.length >= 8) break;
  }
  return out;
}

async function parseRanked(html, maps, champ) {
  const clean = cleanPage(html);
  const tables = parseTables(clean);
  return {
    stats: parseStats(clean),
    runes: parseRunes(clean, maps),
    summoners: firstSpells(tables, maps),
    starter: itemList(tableByCaption(tables, 'Items Table'), maps, 2),
    boots: itemList(tableByCaption(tables, 'Boots Table'), maps, 2),
    core: itemList(tableByCaption(tables, 'Builds Table'), maps, 3),
    fourth: depthItem(tableByCaption(tables, 'Depth 4 Items Table'), maps, 2),
    fifth: depthItem(tableByCaption(tables, 'Depth 5 Items Table'), maps, 1),
    skill: parseSkillOrder(clean, champ.id),
    counters: parseCounters(clean),
  };
}

async function parseMayhem(html, maps, champ) {
  const clean = cleanPage(html);
  const tables = parseTables(clean);
  return {
    stats: parseStats(clean),
    augments: await parseAugments(clean),
    summoners: firstSpells(tables, maps),
    starter: itemList(tableByCaption(tables, 'Items Table'), maps, 2),
    boots: itemList(tableByCaption(tables, 'Boots Table'), maps, 2),
    core: itemList(tableByCaption(tables, 'Builds Table'), maps, 3),
    skill: parseSkillOrder(clean, champ.id),
  };
}

// ── 排版 ────────────────────────────────────────────────────────────────
const pct = (v) => (v === null || v === undefined || Number.isNaN(Number(v)) ? '' : `${Number(v).toFixed(2)}%`);
const has = (v) => v !== null && v !== undefined && v !== '';
const fmtN = (n) => (n === null || n === undefined ? '' : Number(n).toLocaleString('en-US'));

function fmtRunes(runes, maps) {
  if (!runes) return '';
  const tree = (t) => (t ? (maps.treeName.get(t.id) || t.name) : '');
  const key = maps.runeName.get(runes.keystone.id) || runes.keystone.name;
  const head = `${tree(runes.mainTree)} · ${key}${runes.subTree ? ` ＋ ${tree(runes.subTree)}` : ''}`;
  const rates = [has(runes.pickRate) ? `登场 ${pct(runes.pickRate)}` : '', has(runes.winRate) ? `胜率 ${pct(runes.winRate)}` : ''].filter(Boolean).join('，');
  const games = runes.games ? `，${fmtN(runes.games)} 场` : '';
  return `符文：${head}${rates ? `（${rates}${games}）` : ''}`;
}

function fmtStatsLine(s) {
  const parts = [pct(s.winRate), pct(s.pickRate), pct(s.banRate)].filter(Boolean);
  return parts.length ? `胜率/登场/禁用：${parts.join(' / ')}` : '';
}

function fmtSummoners(sp) {
  return sp ? `召唤师技能：${sp.names.join(' ＋ ')}${has(sp.pickRate) ? `（${pct(sp.pickRate)}）` : ''}` : '';
}

function fmtItemRows(list, { label, sep = '＋', showWin = true } = {}) {
  if (!list?.length) return '';
  const body = list.map((x) => {
    const nm = (x.items || [x.item]).filter(Boolean).join(sep);
    const bits = [];
    if (has(x.pickRate)) bits.push(pct(x.pickRate));
    if (showWin && has(x.winRate)) bits.push(`胜率 ${pct(x.winRate)}`);
    return `${nm}${bits.length ? `（${bits.join('，')}）` : ''}`;
  }).join('；');
  return `${label}：${body}`;
}

function fmtBlockForMayhem(d, maps, champ) {
  const s = d.stats || {};
  const out = [
    `【${champ.zh} ${champ.en}｜海克斯大乱斗｜op.gg Patch ${s.patch || '?'}${s.tier ? `｜T${s.tier}` : ''}】`,
    fmtStatsLine(s),
    d.augments?.length ? `推荐海克斯：${d.augments.map((a) => a.name).join('、')}` : '',
    fmtSummoners(d.summoners),
    fmtItemRows(d.starter, { label: '起手' }),
    fmtItemRows(d.boots, { label: '鞋子', showWin: false }),
    fmtItemRows(d.core, { label: '核心装', sep: ' → ' }),
    d.skill?.order ? `加点：${d.skill.order}` : '',
  ];
  const block = out.filter(Boolean).join('\n');
  // op.gg 这个模式暂时不公开胜率（新赛季刚开）。有数据时上面会自动出，没数据时说明一句。
  return has(s.winRate) ? block : `${block}\n（op.gg 这个模式暂时没有胜率数据，等它补上）`;
}

function fmtBlockForRanked(d, maps, champ) {
  const s = d.stats || {};
  const out = [
    `【${champ.zh} ${champ.en}${s.position ? `｜${s.position}` : ''}｜单双排｜op.gg Patch ${s.patch || '?'}${s.tier ? `｜T${s.tier}` : ''}】`,
    fmtStatsLine(s),
    fmtRunes(d.runes, maps),
    fmtSummoners(d.summoners),
    fmtItemRows(d.starter, { label: '起手' }),
    fmtItemRows(d.boots, { label: '鞋子', showWin: false }),
    fmtItemRows(d.core, { label: '核心装', sep: ' → ' }),
    d.fourth?.length ? `第四件：${d.fourth.map((x) => `${x.item}${has(x.winRate) ? `（胜率 ${pct(x.winRate)}）` : ''}`).join('；')}` : '',
    d.fifth?.length ? `第五件：${d.fifth.map((x) => `${x.item}${has(x.winRate) ? `（胜率 ${pct(x.winRate)}）` : ''}`).join('；')}` : '',
    d.skill?.order ? `加点：${d.skill.order}${has(d.skill.winRate) ? `（胜率 ${pct(d.skill.winRate)}${d.skill.games ? `，${fmtN(d.skill.games)} 场` : ''}）` : ''}` : '',
  ];
  if (settings().showCounters) {
    const fmt = (arr) => arr.map((x) => `${champZh(x)}${has(x.winRate) ? ` ${pct(x.winRate)}` : ''}`).join('、');
    if (d.counters?.strong?.length) out.push(`强势对位：${fmt(d.counters.strong)}`);
    if (d.counters?.weak?.length) out.push(`吃力对位：${fmt(d.counters.weak)}`);
  }
  return out.filter(Boolean).join('\n');
}

// ── 主流程 ──────────────────────────────────────────────────────────────
/**
 * 从原话里嗅模式：模型偶尔会把「亚索排位」整串塞进 champion 而忘了传 mode，
 * 这里兜一层，保证「亚索排位」一定查单双排。
 */
function modeFromText(text) {
  const t = String(text || '');
  if (/(排位|单双排|上分|峡谷|ranked)/i.test(t)) return 'ranked';
  if (/(大乱斗|海克斯|极地|mayhem)/i.test(t)) return 'mayhem';
  return '';
}

async function buildReport(championArg, modeArg) {
  const s = settings();
  const explicit = ['mayhem', 'ranked'].includes(String(modeArg)) ? String(modeArg) : '';
  // 原话里的模式词优先：它比模型传的参数更接近用户真实意图
  const mode = modeFromText(championArg) || explicit || s.defaultMode;
  const wanted = ['mayhem', 'ranked'].includes(mode) ? mode : 'mayhem';

  const resolved = await resolveChampion(championArg);
  if (resolved.error) return { error: resolved.error };
  const champ = resolved.champion;

  const meta = MODE_META[wanted];
  const targets = [{ key: 'build', url: SITE + meta.build(champ.slug) }];

  const fetched = await Promise.allSettled(targets.map((t) => getText(t.url)));
  const pages = {};
  targets.forEach((t, i) => {
    const r = fetched[i];
    if (r.status === 'fulfilled') pages[t.key] = r.value;
    else warn(`opgg-guide: ${wanted}/${t.key} 抓取失败 ${champ.slug}：${r.reason?.message || r.reason}`);
  });

  if (!pages.build) {
    return { error: `op.gg 暂时抓不到（${champ.zh}·${meta.label}）。可能是网络超时或页面改版，过一会儿再试。` };
  }

  let maps;
  try {
    maps = await loadMaps(ddragonVersionFrom(pages.build));
  } catch (e) {
    warn(`opgg-guide: 名称表加载失败，退回英文名：${e?.message || e}`);
    maps = { treeName: new Map(), runeName: new Map(), runeTree: new Map(), itemName: new Map(), spellName: new Map() };
  }

  try {
    const d = wanted === 'mayhem'
      ? await parseMayhem(pages.build, maps, champ)
      : await parseRanked(pages.build, maps, champ);
    const text = wanted === 'mayhem' ? fmtBlockForMayhem(d, maps, champ) : fmtBlockForRanked(d, maps, champ);
    return { champion: champ, mode: wanted, text, url: targets[0].url };
  } catch (e) {
    warn(`opgg-guide: 解析 ${wanted} 失败：${e?.stack || e}`);
    return { error: `op.gg 页面拿到了但解析不出数据（${champ.zh}·${meta.label}），可能是站点改版了。` };
  }
}

// ── 工具注册 ────────────────────────────────────────────────────────────
export function setup(host) {
  fetchImpl = typeof host?.fetch === 'function' ? (...a) => host.fetch(...a) : (typeof fetch === 'function' ? fetch : null);
  log = host?.log || (() => {});
  warn = host?.warn || (() => {});
  getSettings = typeof host?.config === 'function' ? host.config : () => ({});
  if (!fetchImpl) throw new Error('当前环境没有 fetch');

  host.registerTool({
    id: 'champion_build',
    name: '英雄联盟出装/符文/海克斯（op.gg）',
    description: '查某个英雄联盟英雄在 op.gg 上的当前版本数据。默认查「海克斯大乱斗」（ARAM: Mayhem）：梯队、推荐海克斯（符文强化）、召唤师技能、起手装/鞋子/核心装、加点顺序（这个大乱斗模式不选符文，所以没有符文推荐）。'
      + 'mode=ranked 时查「单双排」：梯队、胜率/登场率/禁用率、符文、召唤师技能、起手装/鞋子/核心装/第四五件、加点、强势与吃力对位。'
      + '当有人 @ 你并给出英雄名（中文名、英文名、外号、谐音甚至拼音都行）时调用；对方说了「排位」「单双排」「上分」就传 mode=ranked，说了「大乱斗」「海克斯」或不提模式就传 mode=mayhem（默认）。'
      + '参数 champion 传原话即可（如 亚索 / 风男 / 压缩 / 韦恩 / vn / ez / 章鱼妈），工具内部自己认。',
    category: 'query',
    icon: '📊',
    parameters: {
      type: 'object',
      properties: {
        champion: { type: 'string', description: '英雄名：中文名（亚索）、英文名（Yasuo）、外号（风男/瞎子/章鱼妈）、谐音或拼音（压缩/韦恩/yasuo/ez/vn）' },
        mode: {
          type: 'string',
          enum: ['mayhem', 'ranked'],
          description: 'mayhem=海克斯大乱斗（默认）；ranked=单双排（对方明确说排位/单双排/上分时才用）',
        },
      },
      required: ['champion'],
    },
    async execute(ctx, args) {
      try {
        const r = await buildReport(args?.champion, args?.mode);
        if (r.error) return { content: r.error, isError: true };
        log(`opgg-guide: ${r.champion.zh} ${r.mode} 查询完成`);
        return { content: r.text + '\n（把上面数据用自己的话讲给群友，别整段照贴；没给的项就别编。）' };
      } catch (e) {
        warn(`opgg-guide 异常：${e?.stack || e}`);
        return { content: `查 op.gg 出错了：${e?.message || e}。过一会儿再试，或先看看是不是网络问题。`, isError: true };
      }
    },
  });

  log('英雄联盟出装查询已加载（op.gg：海克斯大乱斗为默认，单双排需明说）');
}

export function available() {
  if (!fetchImpl) return { ok: false, reason: '当前环境没有 fetch' };
  return true;
}

export const internals = {
  resolveChampion, parseStats, parseRunes, parseTables, parseSkillOrder, parseCounters,
  buildReport, cleanPage, toText, cellPct, skillLetter, parseAugments,
};
