import path from 'node:path';
import { loadHost, callModel } from './lib/host.js';
import { DEFAULT_PROMPTS, pickPrompt, fillPrompt, focusVars } from './lib/prompts.js';
import { collectMessages, computeStats, formatMessagesForLLM, formatRange, resolveWindow, splitList } from './lib/stats.js';
import { parseStructured, normalizeTopics, normalizeTitles, normalizeQuotes, normalizePersona } from './lib/parse.js';
import { buildReportHtml, buildPersonaHtml, buildTextReport, renderReportImage } from './lib/render.js';
import { PersonaStore } from './lib/persona-store.js';

// 梦羽的插件包-群分析和用户画像
//
// 原插件自己实现、而 QQ-agent 已经内置的部分，这里一律复用：
//   · 消息监听 / 入库 / 过期清理  → ctx.store（核心消息存档）
//   · 模型选择 / Key / 重试降级   → 核心 llm.js（设置页的主模型 + 备选模型 + 账号池）
//   · 自然语言解析 + 分析后对话    → 主模型本身（把意图填进工具参数，拿结果接着聊）
//   · 发消息 / 发图 / 限流去重     → ctx.sender
//   · 对群友的长期印象            → ctx.memory（喂给画像作参考）
// 插件只保留真正的增量：统计口径、三段分析提示词、报告图渲染、跨群画像。

let cfg = () => ({});
let log = () => {};
const cache = new Map();          // key → { at, report }
const running = new Map();        // chatKey → Promise（同群并发合并）
const lastFreshRun = new Map();   // chatKey → ts（冷却）
let personaStore = null;

const num = (v, d) => (Number.isFinite(Number(v)) ? Number(v) : d);

function settings() {
  const c = cfg() || {};
  return {
    outputFormat: c.outputFormat === 'text' ? 'text' : 'image',
    theme: c.theme || 'auto',
    defaultDays: num(c.defaultDays, 1),
    useCalendarDayWindow: c.useCalendarDayWindow !== false,
    maxMessages: num(c.maxMessages, 2000),
    minMessages: num(c.minMessages, 30),
    maxPromptChars: num(c.maxPromptChars, 60000),
    maxUsersInReport: num(c.maxUsersInReport, 10),
    maxTopics: num(c.maxTopics, 5),
    userTitleAnalysis: c.userTitleAnalysis !== false,
    maxUserTitles: num(c.maxUserTitles, 6),
    maxGoldenQuotes: num(c.maxGoldenQuotes, 3),
    cacheMinutes: num(c.cacheMinutes, 5),
    cooldownMinutes: num(c.cooldownMinutes, 2),
    wordsFilter: splitList(c.wordsFilter),
    userFilter: splitList(c.userFilter),
    model: String(c.model ?? '').trim(),
    temperature: num(c.temperature, 1),
    personaUserFilter: splitList(c.personaUserFilter),
    personaOutputFormat: c.personaOutputFormat === 'text' ? 'text' : 'image',
    personaCacheDays: num(c.personaCacheDays, 3),
    personaLookbackDays: num(c.personaLookbackDays, 2),
    personaMaxMessages: num(c.personaMaxMessages, 400),
    personaMinMessages: num(c.personaMinMessages, 20),
    prompts: {
      topic: pickPrompt(c.promptTopic, DEFAULT_PROMPTS.topic),
      userTitles: pickPrompt(c.promptUserTitles, DEFAULT_PROMPTS.userTitles),
      goldenQuotes: pickPrompt(c.promptGoldenQuotes, DEFAULT_PROMPTS.goldenQuotes),
      userPersona: pickPrompt(c.promptUserPersona, DEFAULT_PROMPTS.userPersona)
    }
  };
}

async function dataDir() {
  const host = await loadHost();
  return path.join(host.dataDir, 'group-analysis');
}

async function getPersonaStore() {
  if (!personaStore) personaStore = new PersonaStore(path.join(await dataDir(), 'personas.json'));
  return personaStore;
}

async function resolveGroupName(ctx) {
  const direct = ctx.chatName || ctx.session?.chatName;
  if (direct) return String(direct);
  try {
    const info = await ctx.onebot?.getGroupInfo?.(ctx.chatId);
    if (info?.group_name) return String(info.group_name);
  } catch { /* 拿不到群名就用群号 */ }
  return `群 ${ctx.chatId}`;
}

async function askStructured(prompt, task, s) {
  const raw = await callModel(prompt, { model: s.model, temperature: s.temperature });
  if (!raw) throw new Error(`${task}：模型返回为空`);
  return parseStructured(raw);
}

// ── 群聊分析 ────────────────────────────────────────────────────────────

async function buildReport(ctx, args, s) {
  const window = resolveWindow({
    hours: args.hours,
    startTime: args.start_time,
    endTime: args.end_time,
    defaultDays: s.defaultDays,
    useCalendarDay: s.useCalendarDayWindow
  });

  const messages = collectMessages(ctx.store, ctx.chatKey, {
    start: window.start, end: window.end,
    maxMessages: s.maxMessages, wordsFilter: s.wordsFilter, userFilter: s.userFilter
  });
  if (messages.length < s.minMessages) {
    return { error: `${formatRange(window)} 内只有 ${messages.length} 条可分析的消息，少于设定的最少 ${s.minMessages} 条，没有生成报告。（插件只能看到机器人上线后存档里的消息。）` };
  }

  const focus = {
    query: String(args.query ?? '').trim(),
    keywords: splitList(args.keywords),
    topics: splitList(args.topics),
    nicknames: splitList(args.nicknames),
    timeRangeText: formatRange(window)
  };
  const vars = focusVars(focus);
  const stats = computeStats(messages);
  const transcript = formatMessagesForLLM(messages, { maxChars: s.maxPromptChars, withDate: window.end - window.start > 86_400_000 });

  const userLines = stats.users.slice(0, s.maxUserTitles).map((u) =>
    `- ${u.nickname} (QQ:${u.userId}): 发言${u.messageCount}条, 平均${u.avgChars}字, 表情比例${u.emojiRatio}, 夜间发言比例${u.nightRatio}, 回复比例${u.replyRatio}`
  ).join('\n');

  const jobs = [
    ['热门话题', () => askStructured(fillPrompt(s.prompts.topic, { ...vars, messages: transcript, maxTopics: s.maxTopics }), '话题分析', s).then((d) => normalizeTopics(d, s.maxTopics))],
    ['本群圣经', () => askStructured(fillPrompt(s.prompts.goldenQuotes, { ...vars, messages: transcript, maxGoldenQuotes: s.maxGoldenQuotes }), '金句分析', s).then((d) => normalizeQuotes(d, s.maxGoldenQuotes))]
  ];
  if (s.userTitleAnalysis && userLines) {
    jobs.push(['群友称号', () => askStructured(fillPrompt(s.prompts.userTitles, { ...vars, users: userLines }), '称号分析', s).then((d) => normalizeTitles(d, s.maxUserTitles))]);
  }

  const settled = await Promise.allSettled(jobs.map(([, run]) => run()));
  const failures = [];
  const result = {};
  settled.forEach((r, i) => {
    const [label] = jobs[i];
    if (r.status === 'fulfilled') result[label] = r.value;
    else {
      failures.push(label);
      log(`[group-analysis] ${label}失败：${r.reason?.message ?? r.reason}`);
    }
  });
  if (failures.length === jobs.length) {
    return { error: `模型调用全部失败（${failures.join('、')}），请检查主模型配置或稍后再试。` };
  }

  const focusChips = [...focus.keywords, ...focus.topics, ...focus.nicknames.map((n) => `@${n}`)];
  return {
    report: {
      groupName: await resolveGroupName(ctx),
      window,
      stats,
      maxUsersInReport: s.maxUsersInReport,
      topics: result['热门话题'] ?? [],
      quotes: result['本群圣经'] ?? [],
      titles: result['群友称号'] ?? [],
      failures,
      focusChips
    }
  };
}

function summarizeForModel(report, delivered) {
  const s = report.stats;
  const lines = [];
  lines.push(`群聊分析完成：${report.groupName}，${formatRange(report.window)}`);
  lines.push(`消息 ${s.totalMessages} 条，${s.totalParticipants} 人参与，最活跃 ${s.mostActivePeriod}。`);
  lines.push(`发言最多：${s.users.slice(0, 5).map((u) => `${u.nickname}(${u.messageCount})`).join('、')}`);
  if (report.topics.length) {
    lines.push('话题：');
    report.topics.forEach((t, i) => lines.push(`${i + 1}. ${t.topic} — ${t.detail.replace(/\s+/g, ' ').slice(0, 160)}`));
  }
  if (report.titles.length) lines.push(`称号：${report.titles.map((t) => `${t.name}=${t.title}${t.mbti ? `/${t.mbti}` : ''}`).join('；')}`);
  if (report.quotes.length) lines.push(`金句：${report.quotes.map((q) => `「${q.content.slice(0, 60)}」(${q.sender})`).join('；')}`);
  if (report.failures.length) lines.push(`（${report.failures.join('、')} 生成失败）`);
  lines.push('');
  lines.push(delivered
    ? `完整报告${delivered}已经发到群里了。不要再把报告内容逐条复述；如果用户问了具体问题，就基于上面的结果简短回答，否则一句话点评即可（也可以什么都不说）。`
    : '报告没有自动发出。请用你自己的话把要点简短地告诉用户。');
  return lines.join('\n');
}

function chunkText(text, size = 1500) {
  const parts = [];
  let buf = '';
  for (const para of text.split('\n')) {
    if (buf && buf.length + para.length + 1 > size) {
      parts.push(buf);
      buf = '';
    }
    buf = buf ? `${buf}\n${para}` : para;
  }
  if (buf) parts.push(buf);
  return parts;
}

async function deliver(ctx, report, s, output) {
  if (output === 'none') return '';
  if (output === 'image') {
    try {
      const html = buildReportHtml(report, { theme: s.theme });
      const img = await renderReportImage(html, path.join(await dataDir(), 'reports'), `${ctx.chatId}-${Date.now()}`);
      if (img) {
        await ctx.sender.sendImage(ctx.chatKey, img, { note: '群聊分析报告' });
        return '（图片）';
      }
      log('[group-analysis] 当前环境无法渲染图片（无 Electron / puppeteer），改发文字版');
    } catch (error) {
      log(`[group-analysis] 报告图发送失败，改发文字版：${error?.message ?? error}`);
    }
  }
  await ctx.sender.sendTextBatch(ctx.chatKey, chunkText(buildTextReport(report)));
  return '（文字）';
}

async function runGroupAnalysis(ctx, args = {}) {
  if ((ctx.kind ?? ctx.chatKind) !== 'group') {
    return { content: '群聊分析只能在群里用。', isError: true };
  }
  const s = settings();
  const output = ['image', 'text', 'none'].includes(args.output) ? args.output : s.outputFormat;

  const keyParts = [
    ctx.chatKey,
    Math.round(num(args.hours, 0) * 10),
    String(args.start_time ?? ''), String(args.end_time ?? ''),
    splitList(args.keywords).join(','), splitList(args.topics).join(','),
    splitList(args.nicknames).join(','), String(args.query ?? '').trim()
  ];
  const cacheKey = keyParts.join('|');
  const hit = cache.get(cacheKey);
  const fresh = hit && s.cacheMinutes > 0 && Date.now() - hit.at < s.cacheMinutes * 60_000;

  let report;
  if (fresh) {
    report = hit.report;
  } else {
    const last = lastFreshRun.get(ctx.chatKey) ?? 0;
    const waitMs = s.cooldownMinutes * 60_000 - (Date.now() - last);
    if (running.has(ctx.chatKey)) {
      return { content: '这个群的分析正在进行中，稍等它跑完就好，不要重复调用。', isError: true };
    }
    if (waitMs > 0) {
      return { content: `本群刚分析过，冷却中（还剩约 ${Math.ceil(waitMs / 60_000)} 分钟）。可以先用之前的结果回答。`, isError: true };
    }
    const job = buildReport(ctx, args, s);
    running.set(ctx.chatKey, job);
    let built;
    try {
      built = await job;
    } finally {
      running.delete(ctx.chatKey);
    }
    if (built.error) return { content: built.error, isError: true };
    report = built.report;
    lastFreshRun.set(ctx.chatKey, Date.now());
    if (s.cacheMinutes > 0) cache.set(cacheKey, { at: Date.now(), report });
    for (const [k, v] of cache) if (Date.now() - v.at > s.cacheMinutes * 60_000) cache.delete(k);
  }

  const delivered = await deliver(ctx, report, s, output);
  return { content: summarizeForModel(report, delivered) };
}

// ── 用户画像（跨群） ──────────────────────────────────────────────────────

function findUserInChat(ctx, nickname) {
  const name = String(nickname ?? '').trim().replace(/^@/, '');
  if (!name) return null;
  const recent = ctx.store.recent(ctx.chatKey, { limit: 2000, includeSelf: false }) || [];
  let partial = null;
  for (let i = recent.length - 1; i >= 0; i--) {
    const m = recent[i];
    const n = String(m.senderName ?? '');
    if (n === name) return { userId: String(m.senderId), name: n };
    if (!partial && n.includes(name)) partial = { userId: String(m.senderId), name: n };
  }
  return partial;
}

function gatherUserMessages(store, userId, sinceTs) {
  const out = [];
  for (const chat of store.listChats() || []) {
    // ChatStore.listChats() returns keys ("group:123"), not chat objects.
    // Accept objects too for older/custom store adapters.
    const chatKey = typeof chat === 'string' ? chat : chat?.chatKey;
    if (!String(chatKey ?? '').startsWith('group:')) continue;
    const label = (typeof chat === 'object' && chat?.chatName) || chatKey.slice(6);
    for (const m of store.recent(chatKey, { limit: 1_000_000, includeSelf: false }) || []) {
      if (String(m.senderId) !== userId || m.ts < sinceTs || m.recalled || m.isPoke) continue;
      out.push({ ...m, __groupLabel: label });
    }
  }
  return out.sort((a, b) => a.ts - b.ts);
}

async function describeRoles(ctx, userId) {
  if ((ctx.kind ?? ctx.chatKind) !== 'group') return '（未知）';
  try {
    const info = await ctx.onebot?.getGroupMemberInfo?.(ctx.chatId, userId);
    const role = { owner: '群主', admin: '管理员', member: '群员' }[info?.role] ?? info?.role;
    return [role, info?.title ? `头衔「${info.title}」` : ''].filter(Boolean).join('，') || '（未知）';
  } catch {
    return '（未知）';
  }
}

function impressionOf(ctx, userId) {
  try {
    const rec = ctx.memory?.getMember?.(ctx.chatKey, userId);
    if (!rec) return '（无）';
    const text = typeof rec === 'string' ? rec : JSON.stringify(rec);
    return text.length > 600 ? `${text.slice(0, 600)}…` : text;
  } catch {
    return '（无）';
  }
}

function formatPersona(p, { cached }) {
  const lines = [`用户画像：${p.username} (${p.userId})${cached ? '（缓存）' : ''}，分析于 ${new Date(p.analyzedAt).toLocaleString('zh-CN', { hour12: false })}`];
  if (p.summary) lines.push(`概括：${p.summary}`);
  if (p.keyTraits.length) lines.push(`特质：${p.keyTraits.join('、')}`);
  if (p.interests.length) lines.push(`兴趣：${p.interests.join('、')}`);
  if (p.communicationStyle) lines.push(`说话风格：${p.communicationStyle}`);
  if (p.evidence.length) lines.push(`代表发言：${p.evidence.slice(0, 8).map((e) => `「${e}」`).join(' ')}`);
  lines.push('', '用你自己的语气、简短地把要点告诉用户，别照抄整段，也别念 QQ 号。');
  return lines.join('\n');
}

function personaSummaryForModel(p, { cached, note = '' } = {}) {
  const lines = [`用户画像${cached ? '（缓存）' : ''}图片已发送到当前聊天。`];
  if (p.summary) lines.push(`概括：${p.summary}`);
  if (p.keyTraits.length) lines.push(`特质：${p.keyTraits.join('、')}`);
  if (p.interests.length) lines.push(`兴趣：${p.interests.join('、')}`);
  if (p.communicationStyle) lines.push(`说话风格：${p.communicationStyle}`);
  if (note) lines.push(note);
  lines.push('用户已看到图片，简短补充即可，不要逐项复述整张画像。');
  return lines.join('\n');
}

async function presentPersona(ctx, profile, s, { cached = false, output = s.personaOutputFormat, note = '' } = {}) {
  if (output === 'image') {
    try {
      const safe = (value) => String(value ?? '').replace(/[^a-zA-Z0-9_-]/g, '_').slice(0, 48) || 'chat';
      const html = buildPersonaHtml(profile, { theme: s.theme, lookbackDays: s.personaLookbackDays });
      const img = await renderReportImage(html, path.join(await dataDir(), 'reports'), `${safe(ctx.chatId ?? ctx.chatKey)}-persona-${safe(profile.userId)}-${Date.now()}`);
      if (img) {
        await ctx.sender.sendImage(ctx.chatKey, img, { note: '用户画像' });
        return { content: personaSummaryForModel(profile, { cached, note }) };
      }
      log('[group-analysis] 当前环境无法渲染用户画像图片（需要 Electron 桌面进程或 Puppeteer），改返回文字版');
    } catch (error) {
      log(`[group-analysis] 用户画像图片发送失败，改返回文字版：${error?.message ?? error}`);
    }
  }
  const text = formatPersona(profile, { cached });
  return { content: note ? `${text}\n${note}` : text };
}

async function runUserPersona(ctx, args = {}) {
  const s = settings();
  const output = ['image', 'text', 'none'].includes(args.output) ? args.output : s.personaOutputFormat;
  let userId = String(args.user_id ?? '').replace(/\D/g, '');
  let name = '';
  if (!userId) {
    const found = findUserInChat(ctx, args.nickname);
    if (!found) return { content: `在当前聊天的近期记录里找不到昵称为「${args.nickname ?? ''}」的人，请提供 QQ 号。`, isError: true };
    ({ userId, name } = found);
  }
  if (s.personaUserFilter.includes(userId)) {
    return { content: '这位用户设置了不允许生成画像。', isError: true };
  }

  const store = await getPersonaStore();
  const previous = store.get(userId);
  const ttl = s.personaCacheDays * 86_400_000;
  if (previous && !args.refresh && ttl > 0 && Date.now() - previous.analyzedAt < ttl) {
    return presentPersona(ctx, previous, s, { cached: true, output });
  }

  const since = Date.now() - s.personaLookbackDays * 86_400_000;
  let msgs = gatherUserMessages(ctx.store, userId, since);
  if (msgs.length > s.personaMaxMessages) msgs = msgs.slice(-s.personaMaxMessages);
  if (msgs.length < s.personaMinMessages) {
    if (previous) return presentPersona(ctx, previous, s, {
      cached: true, output,
      note: `最近 ${s.personaLookbackDays} 天只有 ${msgs.length} 条新发言，不足以更新，返回的是上次的画像。`
    });
    return { content: `TA 最近 ${s.personaLookbackDays} 天在各群只有 ${msgs.length} 条发言，少于 ${s.personaMinMessages} 条，信息太少，没法做画像。`, isError: true };
  }
  name = name || String(msgs[msgs.length - 1].senderName || userId);

  const prevText = previous
    ? [previous.summary, `特质：${previous.keyTraits.join('、')}`, `兴趣：${previous.interests.join('、')}`, `风格：${previous.communicationStyle}`].join('\n')
    : '（无历史画像，请从零开始）';
  const prompt = fillPrompt(s.prompts.userPersona, {
    userId, username: name,
    messages: formatMessagesForLLM(msgs, { maxChars: s.maxPromptChars, withDate: true }),
    previousAnalysis: prevText,
    roles: await describeRoles(ctx, userId),
    impression: impressionOf(ctx, userId),
    personaLookbackDays: s.personaLookbackDays
  });

  let parsed;
  try {
    parsed = normalizePersona(await askStructured(prompt, '用户画像', s));
  } catch (error) {
    return { content: `画像生成失败：${error?.message ?? error}`, isError: true };
  }
  if (!parsed) return { content: '画像生成失败：模型没有给出有效内容。', isError: true };

  const profile = { ...parsed, userId, username: name, analyzedAt: Date.now(), messageCount: msgs.length };
  try {
    store.set(userId, profile);
  } catch (error) {
    log(`[group-analysis] 画像缓存写入失败：${error?.message ?? error}`);
  }
  return presentPersona(ctx, profile, s, { cached: false, output });
}

// ── 注册 ────────────────────────────────────────────────────────────────

export function setup(api) {
  cfg = api.config;
  log = (...a) => (api.log ?? console.log)(...a);

  api.registerTool({
    id: 'group_analysis',
    name: '群聊分析',
    category: 'knowledge',
    description: [
      '分析本群一段时间内的聊天记录，生成「群聊日报」：活跃统计、龙王榜、热门话题、群友称号/MBTI、本群圣经（金句），并自动把报告图发到群里。',
      '适用：群友问"今天群里聊了啥""总结一下最近三小时""谁是龙王""这周有什么金句""xx 最近在群里聊什么"等。',
      '把用户关心的点填进参数（时间、关键词、话题、昵称），会让结果更聚焦。只能在群聊中使用；每次调用会消耗多次模型请求，不要为同一个问题重复调用。',
      '返回值是分析要点；报告已经发出时，不要再逐条复述。'
    ].join(''),
    parameters: {
      type: 'object',
      properties: {
        hours: { type: 'number', description: '分析最近多少小时，例如 3、24、72。不填则用默认（通常是今天）。' },
        start_time: { type: 'string', description: '可选，起始时间 "YYYY-MM-DD HH:mm"（本地时间）。填了会优先于 hours。' },
        end_time: { type: 'string', description: '可选，结束时间 "YYYY-MM-DD HH:mm"，默认现在。' },
        keywords: { type: 'array', items: { type: 'string' }, description: '用户关注的关键词/实体，没有就省略。' },
        topics: { type: 'array', items: { type: 'string' }, description: '用户关注的话题领域，没有就省略。' },
        nicknames: { type: 'array', items: { type: 'string' }, description: '用户关注的群友昵称，没有就省略。' },
        query: { type: 'string', description: '用户的原话，帮助聚焦分析。' },
        output: { type: 'string', enum: ['image', 'text', 'none'], description: '报告发送方式；默认按插件设置。只想拿数据自己回答时用 none。' }
      },
    },
    execute: runGroupAnalysis
  });

  api.registerTool({
    id: 'user_persona',
    name: '用户画像',
    category: 'knowledge',
    description: [
      '基于某位群友最近几天在各个群的发言，生成（或读取缓存的）用户画像：性格特质、兴趣、说话风格、代表发言。',
      '适用："分析一下 xx 是什么样的人""xx 的性格""给我做个画像"。提供 QQ 号最准；只有昵称时在当前群的近期记录里按昵称查找。',
      '默认把画像卡片图片发到当前聊天；可传 output="text" 只返回文字，output="none" 只供模型读取。结果会缓存几天，用户明确要求"重新分析/更新"时传 refresh=true。'
    ].join(''),
    parameters: {
      type: 'object',
      properties: {
        user_id: { type: 'string', description: '目标 QQ 号（优先）。' },
        nickname: { type: 'string', description: '没有 QQ 号时，目标在本群的昵称/群名片。' },
        refresh: { type: 'boolean', description: '忽略缓存，强制重新分析。' },
        output: { type: 'string', enum: ['image', 'text', 'none'], description: '输出方式；默认按用户画像输出设置（图片）。' }
      },
    },
    execute: runUserPersona
  });
}

export function deactivate() {
  cache.clear();
  running.clear();
  lastFreshRun.clear();
  personaStore = null;
}
