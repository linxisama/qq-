// B 站 Skill：让模型自己浏览/理解/互动，并把最近见闻动态注入日常对话。
import {
  nav, ranking, searchVideos, videoView, topReplies, aiConclusion, subtitles,
  likeVideo, coinVideo, favoriteVideo, followUp, commentVideo, sendDm,
  readNotes, addNote, markSeen, readBudget, remainingTokens, addBudget, hasAuth
} from './lib/client.js';

function ok(content) {
  addBudget({ tokens: Math.ceil(String(content).length / 2) });
  return { content };
}

function fail(message) {
  return { content: `B站操作失败：${message}`, isError: true };
}

function fmtVideo(v) {
  return `${v.bvid}｜${String(v.title).slice(0, 60)}｜UP:${v.up}｜播放:${v.view}｜时长:${v.duration}`;
}

export function setup(api) {
  api.registerTool({
    id: 'me',
    name: '看B站账号',
    description: '看机器人自己的 B 站登录状态、昵称、UID、硬币数、等级。做互动前想确认账号状态时用。',
    category: 'query',
    icon: '📺',
    defaultEnabled: true,
    parameters: { type: 'object', properties: {} },
    execute: async () => {
      try {
        if (!hasAuth()) return fail('未登录（需要管理员扫码）');
        const d = await nav();
        const b = readBudget();
        return ok(JSON.stringify({
          login: d.isLogin, name: d.uname, mid: d.mid, coins: d.money,
          level: d.level_info?.current_level ?? 0,
          todayTokens: b.tokens, remainingTokens: remainingTokens(),
          todayActions: { like: b.likes, coin: b.coins, comment: b.comments, follow: b.follows, dm: b.dms }
        }));
      } catch (e) { return fail(e.message); }
    }
  });

  api.registerTool({
    id: 'browse',
    name: '逛B站',
    description: '看 B 站排行榜或按关键词搜视频，返回可选的视频列表（bvid/标题/UP/播放量）。想刷视频、找素材、了解最近流行什么时用。',
    category: 'query',
    icon: '🧭',
    defaultEnabled: true,
    parameters: {
      type: 'object',
      properties: {
        mode: { type: 'string', enum: ['ranking', 'search'], description: 'ranking=排行榜，search=按关键词搜。默认 ranking。' },
        keyword: { type: 'string', description: 'mode=search 时的关键词。' },
        limit: { type: 'integer', minimum: 1, maximum: 20, description: '返回几条，默认 8。' }
      }
    },
    execute: async (_ctx, args = {}) => {
      try {
        const limit = Math.min(20, Math.max(1, Number(args?.limit) || 8));
        const list = args?.mode === 'search'
          ? await searchVideos(String(args?.keyword || '').trim(), 1, limit)
          : await ranking(limit);
        if (!list.length) return ok('没找到视频。');
        return ok(list.map(fmtVideo).join('\n'));
      } catch (e) { return fail(e.message); }
    }
  });

  api.registerTool({
    id: 'watch',
    name: '看视频内容',
    description: '理解一个 B 站视频：拉标题/简介/标签/UP/AI总结/字幕节选/高赞评论。想真正“看懂”某个视频、再决定怎么聊或要不要互动时用。',
    category: 'query',
    icon: '👀',
    defaultEnabled: true,
    parameters: {
      type: 'object',
      properties: {
        bvid: { type: 'string', description: '视频 BV 号，如 BV1xx...' }
      },
      required: ['bvid']
    },
    execute: async (_ctx, args = {}) => {
      try {
        const bvid = String(args?.bvid || '').trim();
        if (!/^BV[0-9A-Za-z]+$/.test(bvid)) return fail('bvid 格式不对');
        const v = await videoView(bvid);
        const [comments, conclusion, subtitle] = await Promise.all([
          topReplies(v.aid, 5).catch(() => []),
          aiConclusion(v.bvid, v.cid, v.upMid),
          subtitles(v.bvid, v.cid)
        ]);
        markSeen(bvid);
        const parts = [
          `【视频】${v.title}`,
          `【UP】${v.up}（${v.upMid}）｜播放 ${v.view}｜点赞 ${v.like}｜投币 ${v.coin}｜时长 ${v.duration}s`,
          v.tags?.length ? `【标签】${v.tags.join('、')}` : '',
          v.desc ? `【简介】${String(v.desc).slice(0, 600)}` : '',
          conclusion.summary ? `【AI总结】${conclusion.summary.slice(0, 800)}` : '',
          conclusion.outlines?.length ? `【结构】${conclusion.outlines.slice(0, 8).join(' / ')}` : '',
          subtitle ? `【字幕节选】${subtitle.slice(0, 1200)}` : '',
          comments.length ? `【高赞评论】\n${comments.map((c) => `- ${c.user}（${c.like}赞）：${c.text}`).join('\n')}` : ''
        ].filter(Boolean);
        return ok(parts.join('\n'));
      } catch (e) { return fail(e.message); }
    }
  });

  api.registerTool({
    id: 'like',
    name: '给视频点赞',
    description: '给一个 B 站视频点赞（或取消赞）。觉得视频好、想留个痕迹时用；别刷。',
    category: 'message',
    icon: '👍',
    defaultEnabled: true,
    parameters: {
      type: 'object',
      properties: {
        bvid: { type: 'string', description: '视频 BV 号。' },
        undo: { type: 'boolean', description: 'true=取消赞，默认点赞。' }
      },
      required: ['bvid']
    },
    execute: async (_ctx, args = {}) => {
      try {
        const b = readBudget();
        if (!args?.undo && b.likes >= 8) return fail('今天点赞已经够多了，别再刷了');
        await likeVideo(String(args?.bvid || '').trim(), !args?.undo);
        return ok(args?.undo ? '已取消赞。' : '已点赞。');
      } catch (e) { return fail(e.message); }
    }
  });

  api.registerTool({
    id: 'coin',
    name: '给视频投币',
    description: '给一个 B 站视频投币（1 枚）。硬币很珍贵：只在真的觉得值的时候投，一天最多 3 次。',
    category: 'message',
    icon: '🪙',
    defaultEnabled: true,
    parameters: {
      type: 'object',
      properties: {
        bvid: { type: 'string', description: '视频 BV 号。' }
      },
      required: ['bvid']
    },
    execute: async (_ctx, args = {}) => {
      try {
        const b = readBudget();
        if (b.coins >= 3) return fail('今天投币已经到上限了');
        const me = await nav();
        if ((Number(me.money) || 0) < 1) return fail('账号没有硬币了');
        await coinVideo(String(args?.bvid || '').trim(), 1);
        return ok('已投 1 枚硬币。');
      } catch (e) { return fail(e.message); }
    }
  });

  api.registerTool({
    id: 'favorite',
    name: '收藏视频',
    description: '把一个 B 站视频收藏到默认收藏夹。适合“以后还想再看”的视频，别乱收。',
    category: 'message',
    icon: '⭐',
    defaultEnabled: true,
    parameters: {
      type: 'object',
      properties: {
        bvid: { type: 'string', description: '视频 BV 号。' }
      },
      required: ['bvid']
    },
    execute: async (_ctx, args = {}) => {
      try {
        const v = await videoView(String(args?.bvid || '').trim());
        const folder = await favoriteVideo(v.aid);
        return ok(`已收藏到「${folder}」。`);
      } catch (e) { return fail(e.message); }
    }
  });

  api.registerTool({
    id: 'follow',
    name: '关注UP主',
    description: '关注一个 B 站 UP 主（用 UP 的 mid）。只有真的想持续看他的内容才关注，一天最多 1 个。',
    category: 'message',
    icon: '➕',
    defaultEnabled: true,
    parameters: {
      type: 'object',
      properties: {
        up_mid: { type: 'integer', description: 'UP 主的 mid（数字）。' }
      },
      required: ['up_mid']
    },
    execute: async (_ctx, args = {}) => {
      try {
        const mid = Number(args?.up_mid);
        if (!mid) return fail('up_mid 必须是数字');
        const b = readBudget();
        if (b.follows >= 1) return fail('今天已经关注过 UP 了，别扫荡');
        await followUp(mid);
        return ok(`已关注 ${mid}。`);
      } catch (e) { return fail(e.message); }
    }
  });

  api.registerTool({
    id: 'comment',
    name: '在B站评论',
    description: '在 B 站视频下发一条评论。要像真人、短、有内容，不发广告/引战/敏感内容；一天最多 1 条。',
    category: 'message',
    icon: '💬',
    defaultEnabled: true,
    parameters: {
      type: 'object',
      properties: {
        bvid: { type: 'string', description: '视频 BV 号。' },
        message: { type: 'string', description: '评论内容，1~60 字。' }
      },
      required: ['bvid', 'message']
    },
    execute: async (_ctx, args = {}) => {
      try {
        const msg = String(args?.message || '').trim();
        if (!msg) return fail('评论不能为空');
        if (msg.length > 80) return fail('评论太长了（上限 80 字）');
        const b = readBudget();
        if (b.comments >= 1) return fail('今天已经评论过了');
        const v = await videoView(String(args?.bvid || '').trim());
        await commentVideo(v.aid, msg);
        return ok('评论已发出。');
      } catch (e) { return fail(e.message); }
    }
  });

  api.registerTool({
    id: 'dm',
    name: '给B站用户发私信',
    description: '给一个 B 站用户发私信。只在有明确理由时用（比如回复对方的私信、真的想交流），不群发、不骚扰；一天最多 1 条。',
    category: 'message',
    icon: '✉️',
    defaultEnabled: true,
    parameters: {
      type: 'object',
      properties: {
        uid: { type: 'integer', description: '对方 B 站 UID。' },
        message: { type: 'string', description: '私信内容，短、礼貌。' }
      },
      required: ['uid', 'message']
    },
    execute: async (_ctx, args = {}) => {
      try {
        const msg = String(args?.message || '').trim();
        if (!msg) return fail('私信不能为空');
        if (msg.length > 200) return fail('私信太长了');
        const b = readBudget();
        if (b.dms >= 1) return fail('今天已经发过私信了');
        await sendDm(Number(args?.uid), msg);
        return ok('私信已发出。');
      } catch (e) { return fail(e.message); }
    }
  });

  api.registerTool({
    id: 'notes',
    name: '最近B站见闻',
    description: '看自己最近在 B 站刷到了什么、有什么想法。聊天想自然提起最近看的视频时用。',
    category: 'query',
    icon: '🗒️',
    defaultEnabled: true,
    parameters: {
      type: 'object',
      properties: {
        limit: { type: 'integer', minimum: 1, maximum: 10, description: '看几条，默认 5。' }
      }
    },
    execute: async (_ctx, args = {}) => {
      const list = readNotes(Math.min(10, Math.max(1, Number(args?.limit) || 5)));
      if (!list.length) return ok('最近还没刷到什么。');
      return ok(list.map((n) => `- ${n.date || ''} 《${n.title}》 UP:${n.up || ''}｜${n.takeaway || ''}`).join('\n'));
    }
  });
}

// 动态提示词：把最近见闻塞进系统提示，聊天时自然带出来。
export function promptSections() {
  try {
    const list = readNotes(3).filter((n) => {
      const t = Date.parse(n.at || '');
      return !Number.isFinite(t) || Date.now() - t < 7 * 24 * 3600 * 1000;
    });
    if (!list.length) return [];
    const content = `【最近在B站看到】\n${list.map((n) => `- 《${n.title}》 UP:${n.up || ''}：${n.takeaway || n.reaction || ''}`).join('\n')}\n（聊天时如果自然相关可以提一句，不要每次都提，也不要背稿。）`;
    return [{ id: 'bili-notes', title: 'B站见闻', content, priority: 35 }];
  } catch {
    return [];
  }
}
