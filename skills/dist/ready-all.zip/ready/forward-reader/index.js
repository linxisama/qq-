// 转发记录阅读器（forward-reader）
//
// ── 这个技能解决什么 ──
// 用户的原话：「让 QQ Agent 看到转发的聊天记录内的内容」。
// 实测（读了 data/messages 里的真实存档 + 直接打协议端接口）发现三个具体缺口：
//   · 机器人回「看不了」：转发展开失败时存档里只剩占位符 [合并转发聊天记录]；
//   · 套娃看不到：内置只展开一层，转发里的转发又是占位符（实测嵌套 id 其实可查）；
//   · 图片看不到：图片只有 [图片] 占位，模型不知道里面有什么；
//   另外还实测出「转发里的 QQ 号不可信」（见 lib/forward.js 文件头）。
//
// ── 为什么是技能（skills/）而不是插件（plugins/）──
// 「看懂转发内容」必须经过模型理解、由模型判断要不要接话 —— 属于"要动脑子"的一类，
// 按开发规范应做成技能。插件适合"命中规则就固定执行、不过模型"的确定性逻辑
// （比如开播提醒、链接转发）。
//
// ── 自动是怎么做到的（本技能的关键）──
// 技能钩子里拿不到 ctx.onebot（框架只给工具执行上下文），所以钩子无法直接调协议端。
// 这里改成向**本机协议端**发 HTTP（lib/bridge.js，地址与 token 自动从 data/config.json
// 读），于是能在 `before-context` 阶段——也就是提示词组装**之前**——把转发就地展开、
// 写回消息存档。等提示词拼出来时，模型看到的就是展开后的普通消息，
// 它自然会像处理普通群聊一样判断要不要接话，不需要用户开口、也不会多触发一次回复。
//
// 写回存档用的 ctx.store.updateByMid 与内置 read_forward 工具是同一个 API，
// 一次展开永久有效（存档页、金句墙、后续几轮都能直接读到内容）。

let log = () => {};
let cfg = () => ({});
let fetchImpl = null;

let libsPromise = null;
let F = null;   // lib/forward.js
let B = null;   // lib/bridge.js

/** 已经成功展开过的 chatKey#mid（避免同一轮/连续几轮重复打协议端）。 */
const expandedOk = new Set();
const EXPANDED_CACHE_MAX = 800;

/** 本次运行的结果，供 before-llm-messages 注入提示（key = sessionId）。 */
const runNotes = new Map();
const RUN_NOTES_MAX = 50;

/** 最近一次运行时视觉能力是否可用（before-context 先跑，工具执行时用得上）。 */
let visionEnabled = true;

function ok(payload) {
  return { content: typeof payload === 'string' ? payload : JSON.stringify(payload, null, 1) };
}
function err(message) { return { content: `错误：${message}`, isError: true }; }

/**
 * lib 必须用带时间戳的动态 import。
 * 静态 import 的 URL 不带 query，热重载时框架只换掉 index.js 自己，
 * lib 会一直命中第一次加载的旧模块（qzone 技能踩过这个坑：改了规则、重载后没生效）。
 */
function loadLibs() {
  if (!libsPromise) {
    libsPromise = Promise.all([
      import(`./lib/forward.js?t=${Date.now()}`),
      import(`./lib/bridge.js?t=${Date.now()}`)
    ]).then(([forwardMod, bridgeMod]) => ({ F: forwardMod, B: bridgeMod }))
      .catch((error) => { libsPromise = null; throw error; });
  }
  return libsPromise;
}

function num(key, fallback, min, max) {
  const n = Number(cfg()[key]);
  if (!Number.isFinite(n)) return fallback;
  return Math.min(Math.max(n, min), max);
}

function expandOptions() {
  return {
    maxDepth: num('maxDepth', 2, 1, 3),
    maxNodes: num('maxNodes', 60, 1, 500),
    maxChars: num('maxChars', 9000, 200, 60000)
  };
}

function endpointOptions() {
  return {
    url: String(cfg().onebotHttpUrl ?? '').trim(),
    token: String(cfg().onebotAccessToken ?? '').trim(),
    fetchImpl
  };
}

/**
 * 取节点。顶层用 message_id，嵌套用 forward 段里的 id（协议端是同一个参数名）。
 *
 * 两条路：
 *   · 有 ctx.onebot（工具执行上下文）→ 直接用框架已鉴权的客户端，最稳；
 *   · 没有（钩子上下文）→ 走本机 HTTP（lib/bridge.js）。
 */
function makeGetNodes(ctx, timeoutMs) {
  const ob = ctx?.onebot;
  if (ob && typeof ob.call === 'function') {
    return (id) => ob.call('get_forward_msg', { message_id: id });
  }
  return (id) => B.callOneBot('get_forward_msg', { message_id: id }, {
    ...endpointOptions(),
    timeoutMs: timeoutMs ?? num('timeoutMs', 8000, 2000, 20000)
  });
}

const IMAGE_MIME = (buf) => {
  if (!buf || buf.length < 12) return 'image/jpeg';
  if (buf[0] === 0x89 && buf[1] === 0x50) return 'image/png';
  if (buf[0] === 0xff && buf[1] === 0xd8) return 'image/jpeg';
  if (buf.toString('ascii', 0, 6) === 'GIF87a' || buf.toString('ascii', 0, 6) === 'GIF89a') return 'image/gif';
  if (buf.toString('ascii', 0, 8) === 'RIFF' && buf.toString('ascii', 8, 12) === 'WEBP') return 'image/webp';
  return 'image/jpeg';
};

const MAX_IMAGE_BYTES = 2.5 * 1024 * 1024;

/** 把转发里的图片下载成 data URL（视觉模型直接能看的那种）。 */
async function imageToDataUrl(url) {
  const doFetch = fetchImpl || globalThis.fetch;
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), 15000);
  try {
    const res = await doFetch(url, {
      headers: { 'User-Agent': 'Mozilla/5.0', Accept: 'image/*,*/*;q=0.8' },
      signal: ctrl.signal
    });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const buf = Buffer.from(await res.arrayBuffer());
    if (!buf.length) throw new Error('图片内容为空');
    if (buf.length > MAX_IMAGE_BYTES) throw new Error(`图片太大（${(buf.length / 1024 / 1024).toFixed(1)}MB）`);
    return `data:${IMAGE_MIME(buf)};base64,${buf.toString('base64')}`;
  } finally {
    clearTimeout(timer);
  }
}

/** 找本轮/最近一条可读的转发消息的 message_id。 */
function pickMessageId(ctx, arg) {
  const raw = String(arg ?? '').trim();
  if (raw) return raw;
  let recent = [];
  try { recent = ctx?.store?.recent?.(ctx.chatKey, { limit: 40 }) ?? []; } catch { recent = []; }
  for (let i = recent.length - 1; i >= 0; i -= 1) {
    const m = recent[i];
    if (m?.mid != null && F.looksLikeForward(m.text)) return String(m.mid);
  }
  return null;
}

export async function setup(api) {
  cfg = api.config;
  log = api.log || (() => {});
  fetchImpl = typeof api.fetch === 'function' ? api.fetch : null;
  const libs = await loadLibs();
  F = libs.F;
  B = libs.B;

  api.registerTool({
    id: 'forward_read',
    name: '读转发记录',
    description: '完整读取一条「合并转发聊天记录」：把套娃转发一起展开（默认 2 层），比上下文里那份更全，还能把转发里的图片直接给你看。用法：messageId 填那条转发消息前的 #数字（省略 = 最近一条转发）。上下文里出现 [合并转发聊天记录] / [转发消息 …] / 「…（还有 N 条未展开）」，或者想看转发里的图片时用它。转发节点里的人只保证昵称，QQ 号不可信，别用来 @ 人或记印象。',
    category: 'query',
    icon: '📨',
    parameters: {
      type: 'object',
      properties: {
        messageId: { type: ['integer', 'string'], description: '转发消息自己的 QQ 消息 id（聊天记录里的 #数字，可能为负数）。省略则自动取最近一条转发。' },
        depth: { type: 'integer', description: '往下钻几层套娃转发，1~3，默认用设置里的值（2）。' },
        includeImages: { type: 'boolean', description: '是否把转发里的图片一起返回给你看。默认按设置里的张数上限；传 false = 只要文字。' }
      }
    },
    async execute(ctx, args) {
      try {
        const mid = pickMessageId(ctx, args?.messageId);
        if (mid == null) {
          return err('这个会话里没找到合并转发的消息（最近 40 条里没有）。可以让用户把那条转发重发一次，或者用 #消息号 指定具体那条。');
        }
        const opts = expandOptions();
        const depth = Number(args?.depth);
        if (Number.isFinite(depth)) opts.maxDepth = Math.min(3, Math.max(1, Math.trunc(depth)));

        let r;
        try {
          r = await F.expandForward(mid, { getNodes: makeGetNodes(ctx), ...opts });
        } catch (error) {
          const raw = String(error?.message ?? error);
          // 协议端明确说"内容没了"时给出人话解释（这是用户最常碰到的一种）
          if (error?.retcode === 100 || /payload is empty|已过期|不存在/.test(raw)) {
            return err(`这条转发（#${mid}）的内容在 QQ 服务端已经取不到了——一般是转发时间太久被清理，或者原消息已被撤回。请如实告诉用户「这条转发的内容已过期，麻烦重发一次」，不要编造内容。`);
          }
          return err(`展开转发失败：${B.humanError(error)}`);
        }
        if (!r?.ok) {
          return err(`这条转发（#${mid}）没能展开：${r?.error || '内容为空'}。如实告诉用户即可，不要编造内容。`);
        }

        // 写回存档：下次谁读这条消息都能直接看到展开后的内容
        try { ctx.store?.updateByMid?.(ctx.chatKey, mid, { text: r.text, appendMedia: r.media || [] }); } catch { /* 存档写失败不影响本次返回 */ }

        const parts = [{
          type: 'text',
          text: `转发记录 #${mid}（共 ${r.totalNodes} 条${r.nestedForwards ? `，含 ${r.nestedForwards} 段嵌套转发` : ''}${r.imageCount ? `，${r.imageCount} 张图片` : ''}）：\n${r.text}`
        }];

        // 图片：直接作为多模态内容给模型看（视觉模型能读懂）
        const wantImages = args?.includeImages !== false && visionEnabled;
        const limit = wantImages ? num('maxImages', 3, 0, 20) : 0;
        const skipped = [];
        let attached = 0;
        for (const img of (r.images || []).slice(0, limit)) {
          if (!img?.url) continue;
          try {
            parts.push({ type: 'image_url', image_url: { url: await imageToDataUrl(img.url) } });
            attached += 1;
          } catch (error) {
            skipped.push(String(error?.message ?? error));
          }
        }
        if (attached) {
          parts[0].text += `\n（下面 ${attached} 张就是这条转发里的图片，直接看图说话。）`;
        } else if (r.imageCount) {
          parts[0].text += `\n（这条转发里有 ${r.imageCount} 张图片，本次没取图；需要的话可以让我再看一次，或用内置的 get_message_images 看 #${mid}。）`;
        }
        if (skipped.length) parts[0].text += `\n（有 ${skipped.length} 张图没取到：${skipped.slice(0, 2).join('；')}）`;
        return { content: parts };
      } catch (error) {
        return err(`读转发失败：${B ? B.humanError(error) : String(error?.message ?? error)}`);
      }
    }
  });

  log('转发记录阅读器已加载');
}

export const hooks = {
  /**
   * 自动展开 —— 本技能的核心。
   * 时机：提示词组装**之前**跑，此时 updateByMid 写回去的内容，模型这一轮就能看到。
   * 约束：只碰"确实还没展开好"的消息；一次最多处理 2 条、每条有超时；
   *      任何失败都静默降级（记日志 + 让模型看到一句解释），绝不影响正常聊天。
   */
  async 'before-context'(ctx) {
    try {
      if (!F || !B) return;
      visionEnabled = ctx?.visionEnabled !== false;
      if (cfg().enabled === false) return;
      if (cfg().autoExpand === false) return;

      const store = ctx?.store;
      const chatKey = ctx?.chatKey;
      const entries = Array.isArray(ctx?.triggerEntries) ? ctx.triggerEntries : [];
      if (!store || !chatKey || !entries.length) return;

      const done = [];
      const failed = [];
      let budget = 2;

      for (const entry of entries) {
        if (budget <= 0) break;
        const mid = entry?.mid;
        if (mid == null) continue;
        const text = String(entry?.text ?? '');
        if (!F.looksLikeForward(text) || !F.needsExpand(text)) continue;   // 已展开好的不动
        const cacheKey = `${chatKey}#${mid}`;
        if (expandedOk.has(cacheKey)) continue;

        budget -= 1;
        try {
          const r = await F.expandForward(mid, { getNodes: makeGetNodes(null), ...expandOptions() });
          if (r?.ok && r.text) {
            try { store.updateByMid(chatKey, mid, { text: r.text, appendMedia: r.media || [] }); } catch { /* 写存档失败不影响本轮提示 */ }
            expandedOk.add(cacheKey);
            if (expandedOk.size > EXPANDED_CACHE_MAX) expandedOk.clear();
            done.push({ mid, imageCount: r.imageCount, nested: r.nestedForwards, totalNodes: r.totalNodes });
            log(`自动展开转发 #${mid}：${r.totalNodes} 条${r.nestedForwards ? `，含 ${r.nestedForwards} 段嵌套` : ''}${r.imageCount ? `，${r.imageCount} 张图` : ''}`);
          } else {
            failed.push({ mid, reason: r?.error || '内容为空' });
          }
        } catch (error) {
          const raw = String(error?.message ?? error);
          const reason = (error?.retcode === 100 || /payload is empty/.test(raw))
            ? 'QQ 服务端已不保留这条转发的内容（转发太久或被撤回）'
            : B.humanError(error);
          failed.push({ mid, reason });
          log(`自动展开转发 #${mid} 失败：${raw}`);
        }
      }

      if (done.length || failed.length) {
        runNotes.set(String(ctx.sessionId ?? ''), { done, failed });
        if (runNotes.size > RUN_NOTES_MAX) {
          const first = runNotes.keys().next();
          if (!first.done) runNotes.delete(first.value);
        }
      }
    } catch (error) {
      log('自动展开流程异常（已忽略，不影响本轮回复）：' + (error?.message ?? error));
    }
  },

  /**
   * 给模型补一句说明。
   * 不注入的话，模型看到 [合并转发通用占位符] 只会回"我看不了"，
   * 看到 [图片] 也不会想到去取图。
   */
  async 'before-llm-messages'(ctx) {
    try {
      const key = String(ctx?.sessionId ?? '');
      const note = runNotes.get(key);
      if (!note) return;
      runNotes.delete(key);

      const messages = Array.isArray(ctx?.messages) ? ctx.messages : null;
      if (!messages?.length) return;
      const showHint = cfg().showImageHint !== false;
      const lines = [];

      for (const d of note.done || []) {
        lines.push(`你刚收到一条合并转发的聊天记录（消息 #${d.mid}），内容已经自动展开在上面了：直接当普通消息读、正常判断要不要接话就行，**不要说"我看不到转发内容"**。`);
        if (d.nested) lines.push(`里面还套着 ${d.nested} 段转发，也已经一并展开。`);
        if (d.imageCount && showHint) {
          lines.push(`这条转发里还有 ${d.imageCount} 张图片：想看就用 get_message_images（messageId 填 ${d.mid}），或者调 forward_read 让它把图片一起给你。`);
        }
      }
      for (const f of note.failed || []) {
        lines.push(`这条合并转发（#${f.mid}）没能展开：${f.reason}。用户问起时照实说明（例如"这条转发在 QQ 服务端已经过期了，麻烦重发一次"），不要编造内容，也不要笼统说"我打不开"。`);
      }
      if (!lines.length) return;

      const nudge = `\n\n[系统提示·转发记录] ${lines.join(' ')}`;
      const last = messages[messages.length - 1];
      if (last && typeof last.content === 'string') last.content += nudge;
      else if (last && Array.isArray(last.content)) last.content.push({ type: 'text', text: nudge });
      else messages.push({ role: 'user', content: nudge });
    } catch (error) {
      log('转发提示注入异常（已忽略）：' + (error?.message ?? error));
    }
  }
};
