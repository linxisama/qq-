// 存档清理 —— 主人说一句触发词，**回复发出去之后**把这一轮回复从存档里清掉。
// 详见 skill.json 的 description。这里是实现，重点解释"为什么不是删一次"。
//
// 【核心难点】本轮正在生成的回复，在钩子/工具执行时**还不存在**。
//   应用的 after-response 钩子在发送之前触发（orchestrator.js:1016 早于 1342 的发送），
//   发送完成没有钩子可用。所以这里不做"删除动作"，而是**登记一个待清理任务**：
//     ① before-context 发现主人的触发词 → armWipe(store, chatKey)
//     ② 一个 800ms 的清扫器盯着存档，等发送器把回复 appendSelf 进去
//     ③ 一发现 id 大于登记时那条线的 self 消息，立刻 removeByLocalIds 删掉，任务结束
//   实测回复发出后约 1 秒内清干净。
//
// 【清扫器怎么拿到 store】定时器跑在任何钩子之外，没有 ctx。所以每个入口
//   （钩子/工具）都把 ctx.store 缓存到 lastStore —— 清扫器只可能在 arm 之后运行，
//   而 arm 只发生在那些入口里，所以这个引用一定是有效的。
//
// 【为什么不直接改文件】ChatStore 在内存里缓存了每个会话（this.chats），
//   绕过去写盘会被下一次 appendIncoming 覆盖回来，表现为"删了又回来了"。

let api = null;

/** 最近一次从钩子/工具拿到的 store 引用（定时器没有 ctx，只能用这个）。 */
let lastStore = null;

/** chatKey -> { since, deadline, reason, triggerIds }。同一会话后一次登记覆盖前一次。 */
const pending = new Map();

/** 清扫器：只在有待清理任务时活着，任务清空即自停（不留空转定时器）。 */
let sweeper = null;

/** 清扫间隔。要短到"发完就删"，又不能太密 —— 800ms 命中约 1 秒内的体感。 */
const SWEEP_INTERVAL_MS = 800;
/**
 * 待清理任务的有效窗口。模型可能因为多轮工具调用而迟迟不发回复；
 * 超过这个窗口就作废，避免留下悬着的定时器。5 分钟对生成式回复足够宽裕。
 */
const SWEEP_WINDOW_MS = 5 * 60 * 1000;

// ── 身份闸（与 skills/group-admin、skills/background 同款）──────────────────

function ownerIdSet(raw) {
  const parts = Array.isArray(raw) ? raw : String(raw ?? '').split(/[\s,，、;；]+/);
  return new Set(parts.map((v) => String(v ?? '').trim()).filter(Boolean));
}

/**
 * 本轮触发批里主人说的那些消息（按批内顺序）。
 *
 * ⚠️ 为什么不能只用 latestCaller：它取的是"本会话最近一条别人发的消息"，
 *    而群聊里群友完全可能在主人的指令之后插一句 —— 那时调用者会被认成群友，
 *    主人明明说了「清理存档」却直接被拒。实测就是这个坑（测试先炸出来的）。
 *    session.trigger 是**本轮**的触发批（orchestrator 在创建/复用会话时写入），
 *    拿它判断"这一轮是不是主人在指使"才准。
 */
function ownerTriggers(ctx, cfg) {
  const list = Array.isArray(ctx?.session?.trigger) ? ctx.session.trigger : [];
  const out = [];
  for (const e of list) {
    if (!e || e.self) continue;
    const id = String(e.senderId || '');
    if (id && isOwner(id, cfg)) out.push(e);
  }
  return out;
}

/** 谁在说话：本会话最近一条**别人**发的消息的发送者（拿不到触发批时的兜底）。 */
export function latestCaller(ctx) {
  const store = ctx?.store;
  const chatKey = String(ctx?.chatKey ?? '');
  if (!store || typeof store.recent !== 'function' || !chatKey) return { callerId: '', callerName: '' };
  let list = [];
  try { list = store.recent(chatKey, { limit: 6, includeSelf: false }) || []; } catch { list = []; }
  for (let i = list.length - 1; i >= 0; i -= 1) {
    const m = list[i];
    if (m && m.senderId) return { callerId: String(m.senderId), callerName: String(m.senderName || '') };
  }
  return { callerId: '', callerName: '' };
}

/** 是不是主人：本技能名单 或 主人识别插件，任一命中。 */
export function isOwner(callerId, cfg) {
  const id = String(callerId ?? '').trim();
  if (!id) return false;
  if (ownerIdSet(cfg?.ownerIds).has(id)) return true;
  try {
    const r = api?.capability?.('message.owner-check', { userId: id });
    if (r && typeof r === 'object' && r.isOwner === true) return true;
  } catch { /* 主人识别插件坏了按非主人处理，不放行 */ }
  return false;
}

function guard(ctx, cfg) {
  // 先看本轮触发批 —— 批里有主人就放行，并把这个主人认成调用者。
  // 这条优先于 latestCaller：群友在主人之后插话时，latestCaller 会认错人。
  const fromBatch = ownerTriggers(ctx, cfg);
  if (fromBatch.length) {
    const last = fromBatch[fromBatch.length - 1];
    return { callerId: String(last.senderId || ''), callerName: String(last.senderName || '') };
  }
  const { callerId, callerName } = latestCaller(ctx);
  if (!callerId) {
    return { error: '拒绝：没能确认是谁在说话（本会话没查到最近的消息记录），身份不明一律不操作。' };
  }
  if (!isOwner(callerId, cfg) && cfg?.allowNonOwner !== true) {
    return {
      error: '拒绝：这次调用不是主人发起的。按你的安全规则回绝，对群友的说辞就用这句话：'
        + '「这个只有主人能用」。不要重试，也不要解释工具的存在。'
    };
  }
  return { callerId, callerName };
}

// ── 触发词 ──────────────────────────────────────────────────────────────────

/** 设置里的触发词表：逗号/顿号/换行/分号都当分隔符。 */
function triggerList(raw) {
  return String(raw ?? '')
    .split(/[\n,，、;；]+/)
    .map((s) => s.trim().toLowerCase())
    .filter(Boolean);
}

/** 文本里是否含任一触发词（按包含匹配，所以「这条别留档」能命中「别留档」）。 */
function matchTrigger(text, phrases) {
  const t = String(text ?? '').toLowerCase();
  if (!t) return null;
  for (const p of phrases) if (t.includes(p)) return p;
  return null;
}

// ── 待清理任务与清扫器 ──────────────────────────────────────────────────────

function selfMessages(store, chatKey, scan) {
  let list = [];
  try { list = store.recent(chatKey, { limit: scan, includeSelf: true }) || []; } catch { list = []; }
  return list.filter((m) => m && m.self === true);
}

/**
 * 以「指令」那条为锚点，往前收出一段连续的、该一起删掉的存档。
 *
 *   我: 上一条回复 3   ← 删（机器人）
 *   我: 上一条回复 2   ← 删（机器人）
 *   主人: 这条别留档   ← 删（指令自身）
 *
 * 规则：先收指令自己，再往前一直收**机器人自己发的**，**遇到第一条不是机器人发的就停**。
 *
 * 为什么不是"只删指令一条"：机器人一次回复可能被拆成好几条发出去
 * （sender.sendTextBatch 会按长度/段落切），只删指令就会在存档里剩下
 * 几条无头无尾的机器人发言 —— 那正是这个技能要消灭的东西。
 * 为什么必须"到非机器人就停"：不然会一路吃进群里其他人的正常聊天记录。
 *
 * @returns {number[]} 该删的本地 id（含指令自身）；找不到指令就返回 []
 */
function collectExchange(store, chatKey, instructionId) {
  const target = Number(instructionId);
  if (!Number.isFinite(target)) return [];
  let all = [];
  try { all = store.recent(chatKey, { limit: 1e9, includeSelf: true }) || []; } catch { return []; }

  let idx = -1;
  for (let i = all.length - 1; i >= 0; i -= 1) {
    if (Number(all[i]?.id) === target) { idx = i; break; }
  }
  if (idx < 0) return [];

  const ids = [target];
  for (let i = idx - 1; i >= 0; i -= 1) {
    const m = all[i];
    if (!m || m.self !== true) break;      // 到非机器人发言就停下，不再往前删
    ids.push(Number(m.id));
  }
  return ids;
}

/**
 * 某人在本会话里最近发的那条消息（用来定位"主人那条删除指令"）。
 * 只认指定的人发的 —— 免得把主人之后插话的群友当成指令。
 */
function lastInboundFrom(store, chatKey, senderId) {
  const who = String(senderId ?? '').trim();
  if (!who) return null;
  let list = [];
  try { list = store.recent(chatKey, { limit: 20, includeSelf: false }) || []; } catch { list = []; }
  for (let i = list.length - 1; i >= 0; i -= 1) {
    const m = list[i];
    if (m && String(m.senderId) === who && Number.isFinite(Number(m.id))) return m;
  }
  return null;
}

/**
 * 会话里当前最大的本地 id。
 *
 * ⚠️ 为什么"新落档的消息"必须用 id 判、不能用时间戳判：
 *   一开始用 `ts >= since`（since = 登记那一刻的 Date.now()），而 id 是严格自增、
 *   时间戳只到毫秒 —— 登记和某条已有消息**落在同一毫秒**时，那条会被误判成本轮的新消息
 *   一起删掉。实测就是这么炸的：测试里消息建得极快，间歇性地把登记之前那条也吃了。
 *   生产里上一轮回复差着几秒几十秒，撞不上，但边界就该是精确的。
 */
function highestLocalId(store, chatKey) {
  try {
    const all = store.recent(chatKey, { limit: 1e9, includeSelf: true }) || [];
    let max = 0;
    for (const m of all) {
      const n = Number(m?.id);
      if (Number.isFinite(n) && n > max) max = n;
    }
    return max;
  } catch {
    return 0;
  }
}

/** 登记一次"本次回复不留档"。 */
function armWipe(store, chatKey, meta = {}) {
  const key = String(chatKey || '');
  if (!key) return null;
  const now = Date.now();
  // sinceId = 登记时已有的最大 id。之后落档的消息 id 一定比它大，
  // 之前的一律不碰（除非被显式列进 triggerIds）。
  const sinceId = highestLocalId(store, key);
  const triggerIds = Array.isArray(meta.triggerIds) ? meta.triggerIds.filter(Number.isFinite) : [];
  const job = { sinceId, at: now, deadline: now + SWEEP_WINDOW_MS, ...meta, triggerIds };
  pending.set(key, job);
  ensureSweeper();
  return job;
}

function ensureSweeper() {
  if (sweeper) return;
  sweeper = setInterval(sweepOnce, SWEEP_INTERVAL_MS);
  // 不因为一个后台定时器把进程钉住（应用退出时该走就走）
  if (typeof sweeper.unref === 'function') sweeper.unref();
}

function stopSweeper() {
  if (!sweeper) return;
  clearInterval(sweeper);
  sweeper = null;
}

/**
 * 扫一遍所有待清理任务。
 *
 * ⚠️ 「什么时候算可以动手」这一步是整个技能最容易写错的地方：
 *   要删的东西有两类 —— 机器人本轮的回复（自发言），和主人那条**删除指令**本身。
 *   主人那条指令在登记时就已经在存档里了，所以**绝不能**拿它当"到时候了"的信号：
 *   否则第一跳（登记后 800ms）就会把指令删掉、而这时回复还没发出去，
 *   任务随即结束 —— 结果是指令没了、回复留着，正好是反的。
 *   唯一的信号必须是"**回复已经落档**"（存在 id 大于 sinceId 的自发言），
 *   确认之后再两类一起删，才不会删出一条没头没尾的上下文。
 */
function sweepOnce() {
  if (!pending.size) { stopSweeper(); return; }
  const store = lastStore;
  if (!store || typeof store.removeByLocalIds !== 'function' || typeof store.recent !== 'function') {
    // store 还没拿到（理论上不会发生：arm 只发生在有 ctx 的入口）。
    // 保守清空，免得留一个永远清不掉的定时器。
    pending.clear();
    stopSweeper();
    return;
  }

  const now = Date.now();
  for (const [chatKey, job] of [...pending.entries()]) {
    try {
      if (now > job.deadline) { pending.delete(chatKey); continue; }

      const selfTargets = selfMessages(store, chatKey, 1e9)
        .filter((m) => Number(m.id) > job.sinceId)
        .map((m) => m.id);
      // 回复还没落档 —— 这一跳什么都不删，下一跳再看
      if (!selfTargets.length) continue;

      const ids = [...selfTargets, ...(job.triggerIds || [])];
      const removed = Number(store.removeByLocalIds(chatKey, ids)) || 0;
      if (removed) {
        api?.log?.('存档清理：清掉 %d 条（自发言 %d + 指令 %d）（%s，%s）',
          removed, selfTargets.length, (job.triggerIds || []).length, chatKey, job.reason || '?');
      }
      pending.delete(chatKey);
    } catch (error) {
      pending.delete(chatKey);
      api?.warn?.(`存档清理失败（已放弃这次任务）：${error?.message ?? error}`);
    }
  }
  if (!pending.size) stopSweeper();
}

/** 卸下/重载时把副作用收干净（定时器 + 待办）。 */
export function deactivate() {
  pending.clear();
  stopSweeper();
}

export function dispose() {
  deactivate();
}

// ── 工具 ────────────────────────────────────────────────────────────────────

function hhmmss(ts) {
  const n = Number(ts);
  if (!Number.isFinite(n)) return '--:--:--';
  const d = new Date(n);
  const p = (v) => String(v).padStart(2, '0');
  return `${p(d.getHours())}:${p(d.getMinutes())}:${p(d.getSeconds())}`;
}

function digest(text, max = 40) {
  const s = String(text ?? '').replace(/\s+/g, ' ').trim();
  if (!s) return '(空)';
  return s.length > max ? s.slice(0, max) + '…' : s;
}

export function setup(skillApi) {
  api = skillApi;
  const cfgOf = () => skillApi?.config?.() || {};
  const deny = (msg) => ({ content: msg, isError: true });

  skillApi.registerTool({
    id: 'list_own_replies',
    name: '查看机器人发过的存档',
    description: '列出本会话存档里**机器人自己发过**的消息（本地 id、时间、内容摘要）。'
      + '想确认"刚才那条"是哪条时用。只读，不改任何东西。**只有主人能用。**',
    category: 'system',
    icon: '📜',
    parameters: {
      type: 'object',
      properties: {
        limit: { type: 'number', description: '看最近几条，默认 10，上限 50' }
      }
    },
    async execute(ctx, args) {
      lastStore = ctx?.store || lastStore;
      const g = guard(ctx, cfgOf());
      if (g.error) return deny(g.error);
      const store = ctx?.store;
      const chatKey = String(ctx?.chatKey ?? '');
      if (!store || !chatKey) return deny('拒绝：拿不到本会话的存档。');

      const rawLimit = Number(args?.limit);
      const limit = Number.isFinite(rawLimit) && rawLimit > 0 ? Math.min(50, Math.floor(rawLimit)) : 10;
      const all = selfMessages(store, chatKey, 1e9);
      if (!all.length) return { content: '本会话的存档里没有机器人发过的消息。', isError: false };

      const tail = all.slice(-limit);
      return {
        content: [
          `本会话存档里机器人自己发过的共 ${all.length} 条，下面是最近 ${tail.length} 条（时间正序，越靠下越新）：`,
          ...tail.map((m) => `  · #${m.id}  ${hhmmss(m.ts)}  ${digest(m.text)}`)
        ].join('\n'),
        isError: false
      };
    }
  });

  skillApi.registerTool({
    id: 'wipe_this_reply',
    name: '本次回复不留档',
    description: '登记一次"本次回复不留档"：等你把这一轮回复**发出去之后**，宿主会自动把它从存档里清掉'
      + '（约 1 秒内）。同时会删掉**主人那条指令本身**，以及紧挨在指令前面那几条**机器人自己发的**消息 ——'
      + '一直往前删到遇到第一条不是机器人发的就停，所以群里其他人的聊天记录一条都不动。'
      + '（上一轮回复被拆成多条时，这样才不会剩下几条无头无尾的机器人发言。）'
      + '主人说「清理存档 / 这条别留档 / 别记下来」这类话时调它。'
      + '⚠️ 删除发生在发送**之后**，所以你现在还看不到它消失 —— 别声称"已经删掉了"，'
      + '回话时说「好，这条不留档」就够了。**只有主人能用。**',
    category: 'system',
    icon: '🧽',
    parameters: { type: 'object', properties: {} },
    async execute(ctx, args) {
      lastStore = ctx?.store || lastStore;
      const g = guard(ctx, cfgOf());
      if (g.error) return deny(g.error);
      const store = ctx?.store;
      const chatKey = String(ctx?.chatKey ?? '');
      if (!store || !chatKey) return deny('拒绝：拿不到本会话的存档。');

      // 该删的 = 主人那条指令 + 以它为锚点往前那串连续的机器人发言（见 collectExchange）。
      // 锚点首选"本轮触发批里主人最后说的那条"（有界、不会认错）；拿不到触发批时
      // 退回"调用者本人最近发的那条"。
      let triggerIds = [];
      if (cfgOf().alsoDeleteTrigger !== false) {
        const batchOwner = ownerTriggers(ctx, cfgOf());
        const fromBatch = batchOwner.length ? batchOwner[batchOwner.length - 1] : null;
        const inbound = (fromBatch && Number.isFinite(Number(fromBatch.id)))
          ? fromBatch
          : lastInboundFrom(store, chatKey, g.callerId);
        triggerIds = collectExchange(store, chatKey, inbound?.id);
        // 兜底：指令没能在存档里定位到（理论上不会）时，至少把它那条 id 带上
        if (!triggerIds.length && inbound && Number.isFinite(Number(inbound.id))) {
          triggerIds = [Number(inbound.id)];
        }
      }

      const extra = triggerIds.length > 1 ? triggerIds.length - 1 : 0;
      armWipe(store, chatKey, { reason: 'tool', triggerIds });
      return {
        content: '已登记：这一轮回复发出后会自动从存档里清掉'
          + (triggerIds.length
            ? `，连同你那条指令${extra ? `和它前面 ${extra} 条机器人发言` : ''}一起`
            : '')
          + '，群里其他人的消息不受影响。',
        isError: false
      };
    }
  });

  skillApi.log('存档清理已加载（触发词 %d 个；工具 2 个，只认主人）',
    triggerList(cfgOf().triggerPhrases).length);
}

// ── 钩子：扫本轮触发消息里的触发词 ───────────────────────────────────────────
//
// before-context 在本轮开始时、提示词组装之前触发，ctx.triggerEntries 就是本轮
// 触发它的那批消息（形状见 jm-comic 的用法：{ text, senderId, senderName, self, atMe, ts }）。
// 这里只做一件事：主人说了触发词就登记待清理。**不在这里删任何东西** ——
// 此刻本轮的回复还没生成，没东西可删。
export const hooks = {
  async 'before-context'(ctx = {}) {
    try {
      lastStore = ctx.store || lastStore;
      const cfg = api?.config?.() || {};
      if (cfg.enabled === false) return;
      const phrases = triggerList(cfg.triggerPhrases);
      if (!phrases.length) return;

      const entries = Array.isArray(ctx.triggerEntries) ? ctx.triggerEntries : [];
      const alsoTrigger = cfg.alsoDeleteTrigger !== false;   // 默认开
      const matched = [];
      let matchedPhrase = '';
      for (const e of entries) {
        if (!e || e.self) continue;
        const senderId = String(e.senderId || '');
        if (!senderId) continue;
        const phrase = matchTrigger(e.text, phrases);
        if (!phrase) continue;
        // 触发词只认主人 —— 否则群友一句话就能让机器人把自己的话删掉
        if (!isOwner(senderId, cfg)) continue;
        matchedPhrase = matchedPhrase || phrase;
        matched.push(e);
      }
      if (!matched.length) return;
      const chatKey = String(ctx.chatKey || '');
      if (!chatKey) return;

      // 该删的 = 命中的指令本身 + 以最后那条指令为锚点，往前那串连续的机器人发言
      // （见 collectExchange 的注释）。到非机器人发言就停，不会吃进别人的聊天记录。
      let triggerIds = [];
      if (alsoTrigger) {
        const set = new Set();
        for (const e of matched) {
          if (Number.isFinite(Number(e.id))) set.add(Number(e.id));
        }
        const anchor = matched[matched.length - 1];
        for (const id of collectExchange(ctx.store, chatKey, anchor?.id)) set.add(id);
        triggerIds = [...set];
      }

      armWipe(ctx.store, chatKey, { reason: 'phrase:' + matchedPhrase, triggerIds });
      api?.log?.('存档清理：主人说了触发词「%s」，本轮回复发完后会连同这条指令以及它前面那段机器人发言一起清掉（%d 条）（%s）',
        matchedPhrase, triggerIds.length, chatKey);
    } catch (error) {
      // 钩子出错绝不能拖垮对话
      api?.warn?.(`存档清理的触发检查出错（已跳过）：${error?.message ?? error}`);
    }
  }
};
