# limbus-wiki · 边狱公司中文维基查询

群友问「浮士德的人格有哪些」「堂吉诃德的 E.G.O」「这个异想体怎么打」时，机器人去
[limbuscompany.huijiwiki.com](https://limbuscompany.huijiwiki.com)（灰机 wiki 的边狱公司中文维基）
搜页面、抓正文，用中文回答。

## 为什么是技能，不是插件

「这个角色强不强」「XX 人格什么效果」是自然语言，检索词和该摘哪段得靠模型判断，
所以放 `skills/`（LLM 型）。

## 数据从哪来

MediaWiki 官方 API（站点是灰机 wiki，接口与 Wikipedia 同构）：

```
搜索：/api.php?action=query&list=search&srsearch=<关键词>&srlimit=6
正文：/api.php?action=parse&page=<标题>&prop=text&redirects=1&disableeditsection=1
```

正文清洗：

- 去掉目录（`#toc`）、脚本、脚注上标、图片；
- 表格转成「键 | 值」，标题转成 `## `；
- 从「导航 / 参考资料 / 注释 / 画廊 / 立绘 / 外部链接」等尾部小节开始截断；
- 超过 `maxChars`（默认 4500 字）再截断。

## Cloudflare 怎么办（这个技能的核心）

整站挂在 Cloudflare 的**交互式验证**后面：普通 Node `fetch` 一律 `403`
（响应头 `cf-mitigated: challenge`），连无头浏览器都过不去；但真实 Chromium 窗口
能自动通过（实测 2~4 秒）。

所以技能按三层处理：

1. **直连**：如果你填了 `cf_clearance`，或站点这阵子放行，直接拿 JSON（最快）；
2. **内置浏览器兜底**：用 QQ Agent 自己的 Electron 开一个**屏幕外** Chromium 窗口，
   加载 API 地址，等验证通过后读 `document.body.innerText`（JSON 会被当纯文本渲染）；
3. **缓存 Cookie**：验证通过后把 `cf_clearance` 记下来，后续直连可以直接复用，
   少开窗口（Cookie 过期后会自动回到第 2 步）。

> 屏幕外窗口 = `x: -30000`、`skipTaskbar: true`、不抢焦点，正常使用时看不到。

## 用法

群里直接问：

> @哦鲸鲸 浮士德的人格有哪些
> @哦鲸鲸 堂吉诃德 E.G.O 什么效果
> @哦鲸鲸 这个异想体怎么打

工具参数二选一：

| 参数 | 用途 |
|---|---|
| `query` | 中文关键词搜索（作品术语直接用中文） |
| `title` | 精确页面标题（从候选列表里拿） |

搜到多个相近页面时返回候选列表，模型挑一个再用 `title` 查第二次。

## 设置项

| 设置 | 默认 | 说明 |
|---|---|---|
| 启用边狱 Wiki 查询 | 开 | 总开关 |
| 每页最多返回多少字 | 4500 | 800~12000，调小省 token |
| 缓存秒数 | 600 | 同一页面正文缓存时长 |
| Cloudflare 拦截时用内置浏览器 | 开 | 关掉后遇到验证直接报错 |
| 浏览器验证超时（秒） | 30 | 等验证通过的最长时间 |
| cf_clearance（可选） | 空 | 从浏览器复制的通行 Cookie，填了可减少开窗口 |

位置：QQ Agent → 设置 → 技能 → 边狱公司Wiki查询。

## 常见问题

- **查询报「内置浏览器 30 秒内没能通过 Cloudflare 验证」**：偶尔 Cloudflare 会要求
  人工点一次验证。可以在浏览器里打开一次 wiki，然后把 `cf_clearance` 填进设置。
- **拿到的是空页面**：该页面可能只有图片/模板，正文确实很少，换个子页面试试。
- **搜不到**：换更准确的叫法（人格全名、E.G.O 全名、异想体名）。
- **响应慢**：首次查询要过验证（约 3~5 秒），之后同页面走缓存；直连 Cookie 生效后更快。

## 声明

- 与 Project Moon / 灰机 wiki 无关，仅供个人娱乐使用
- 只读公开页面，请勿高频批量抓取
- 站点改版或 API 变更可能导致解析失效，需要更新 `index.js`

## 版本

- v1.0.0（2026-10-19）：首版。MediaWiki API + Cloudflare 内置浏览器兜底 + 正文清洗
