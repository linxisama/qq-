// limbus-wiki —— 查询 limbuscompany.huijiwiki.com（边狱公司中文维基 / 灰机 wiki）。
//
// 类型：LLM 型技能（skills/）——registerTool 注册查询工具，由模型判断何时调用。
//
// 站点特性（决定实现方式）：
//   · 灰机 wiki 是 MediaWiki，API 在 /api.php（action=query 搜索、action=parse 取正文）。
//   · 整站挂在 Cloudflare「交互式验证」后面：普通 Node fetch 一律 403（cf-mitigated:
//     challenge），无头浏览器也过不去；但真实 Chromium 窗口能自动通过。
//   · 所以策略是：先直连（若带有效 cf_clearance 或站点放行则最快）→ 失败则用
//     Electron 内置 Chromium 开一个屏幕外窗口加载 API，通过验证后读 document.body.innerText
//     （JSON 会被 Chromium 当纯文本渲染），并把 cf_clearance 缓存下来供后续直连复用。
//
// 实现约定：
//   · 全量内联、零子模块 import（加载器只对入口做缓存击穿）。
//   · 所有异常都捕获成 { isError } 返回，绝不抛出。
//   · 页面缓存默认 10 分钟，避免每次查询都开浏览器。

let api = null;

const SITE = 'https://limbuscompany.huijiwiki.com';
const API = `${SITE}/api.php`;
const TIMEOUT_MS = 15_000;
const CHROME_UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36';
const UA_HEADERS = {
  'User-Agent': CHROME_UA,
  'Accept': 'application/json, text/html;q=0.9, */*;q=0.8',
  'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8'
};

// title -> { at, text }
const pageCache = new Map();
// 浏览器通过验证后拿到的 cf_clearance（后续直连复用）
let cachedCookie = '';

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const doFetch = (url, init) => (api?.fetch || globalThis.fetch)(url, init);

/** 是不是 Cloudflare 的验证页/拦截页。 */
function isChallenge(text) {
  const head = String(text ?? '').slice(0, 4000);
  if (/^\s*[[{]/.test(head)) return false;          // API 正常返回 JSON
  return /请稍候|安全验证|正在进行安全验证|Just a moment|challenge-platform|_cf_chl_opt|Enable JavaScript and cookies/i.test(head);
}

// ── 取文本：直连 → 内置 Chromium ─────────────────────────────────────

async function httpText(url) {
  const cfg = api.config() || {};
  const cookie = String(cfg.cfClearance || cachedCookie || '').trim();
  const headers = { ...UA_HEADERS };
  if (cookie) headers.Cookie = cookie.includes('=') ? cookie : `cf_clearance=${cookie}`;

  try {
    const ac = new AbortController();
    const timer = setTimeout(() => ac.abort(), TIMEOUT_MS);
    try {
      const res = await doFetch(url, { headers, signal: ac.signal });
      const text = await res.text();
      if (res.ok && !isChallenge(text)) return text;
      api?.warn?.(`直连被 Cloudflare 拦截（HTTP ${res.status}），改用内置浏览器`);
    } finally {
      clearTimeout(timer);
    }
  } catch (error) {
    api?.warn?.(`直连失败：${error?.message ?? error}，改用内置浏览器`);
  }

  return fetchViaBrowser(url);
}

/** 用 Electron 的 Chromium 开一个屏幕外窗口加载 URL，等 Cloudflare 验证通过后读正文。 */
async function fetchViaBrowser(url) {
  const cfg = api.config() || {};
  if (cfg.browserFallback === false) {
    throw new Error('站点被 Cloudflare 拦截，且浏览器兜底已关闭');
  }

  let BrowserWindow = null;
  try {
    const electron = await import('electron');
    BrowserWindow = electron?.BrowserWindow;
  } catch {
    throw new Error('站点被 Cloudflare 拦截；当前运行环境不是 Electron，无法用内置浏览器绕过');
  }
  if (!BrowserWindow) throw new Error('站点被 Cloudflare 拦截；拿不到 Electron BrowserWindow');

  const waitMs = Math.max(8000, Math.min(60000, Number(cfg.browserTimeoutSec ?? 30) * 1000));
  const win = new BrowserWindow({
    show: true,
    x: -30000,
    y: -30000,
    width: 1100,
    height: 820,
    skipTaskbar: true,
    focusable: false,
    webPreferences: {
      sandbox: true,
      contextIsolation: true,
      backgroundThrottling: false
    }
  });

  try {
    win.webContents.setUserAgent(CHROME_UA);
    win.loadURL(url).catch(() => { /* 验证页/重定向会 reject，忽略 */ });

    const deadline = Date.now() + waitMs;
    let last = '';
    while (Date.now() < deadline) {
      await sleep(1200);
      try {
        last = await win.webContents.executeJavaScript(
          'document.body ? document.body.innerText : ""', true
        );
      } catch { continue; }
      if (last && !isChallenge(last)) {
        // 顺手缓存 cf_clearance，下次直连就能省掉整个浏览器流程
        try {
          const cookies = await win.webContents.session.cookies.get({ url: SITE });
          const cf = cookies.find((c) => c.name === 'cf_clearance');
          if (cf?.value) cachedCookie = `cf_clearance=${cf.value}`;
        } catch { /* cookie 拿不到不影响本次结果 */ }
        return last;
      }
    }
    throw new Error(`内置浏览器 ${Math.round(waitMs / 1000)} 秒内没能通过 Cloudflare 验证（可能需要人工点一次验证）`);
  } finally {
    try { win.destroy(); } catch { /* ignore */ }
  }
}

// ── API ───────────────────────────────────────────────────────────────

function decodeEntities(s) {
  return String(s ?? '')
    .replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/&nbsp;/g, ' ')
    .replace(/&#(\d+);/g, (_, n) => String.fromCharCode(Number(n)));
}

async function apiGet(params) {
  const qs = new URLSearchParams({ format: 'json', ...params });
  const text = await httpText(`${API}?${qs.toString()}`);
  let data;
  try {
    data = JSON.parse(text);
  } catch {
    throw new Error('Wiki 返回的不是 JSON（可能又被风控了）');
  }
  if (data?.error) throw new Error(data.error.info || data.error.code || 'Wiki API 报错');
  return data;
}

async function searchWiki(query) {
  const data = await apiGet({
    action: 'query', list: 'search', srsearch: query, srlimit: '6', srnamespace: '0'
  });
  const hits = data?.query?.search || [];
  return hits.map((h) => ({
    title: String(h.title || ''),
    snippet: htmlToText(h.snippet || '').slice(0, 160)
  }));
}

async function fetchPage(title, maxChars) {
  const data = await apiGet({
    action: 'parse', page: title, prop: 'text', redirects: '1', disableeditsection: '1'
  });
  const resolved = String(data?.parse?.title || title);
  const html = data?.parse?.text?.['*'];
  if (!html) throw new Error(`页面「${title}」没有正文（可能不存在或改版）`);
  const text = condense(htmlToText(html), maxChars);
  if (!text) throw new Error(`页面「${resolved}」解析后为空`);
  return { title: resolved, text };
}

// ── HTML → 文本 ───────────────────────────────────────────────────────

function htmlToText(html) {
  let s = String(html ?? '');
  s = s.replace(/<script[\s\S]*?<\/script>/gi, ' ')
    .replace(/<style[\s\S]*?<\/style>/gi, ' ')
    .replace(/<div[^>]*id="toc"[\s\S]*?<\/ul>\s*<\/div>/gi, ' ')   // 目录
    .replace(/<sup[^>]*class="reference"[\s\S]*?<\/sup>/gi, '')
    .replace(/<img[^>]*>/gi, ' ')
    .replace(/<tr[^>]*>/gi, '\n')
    .replace(/<\/t[dh]>/gi, ' | ')
    .replace(/<\/tr>/gi, '\n')
    .replace(/<h([1-6])[^>]*>/gi, '\n## ')
    .replace(/<\/(p|div|li|h[1-6])>/gi, '\n')
    .replace(/<br\s*\/?>/gi, '\n')
    .replace(/<[^>]+>/g, '');
  s = decodeEntities(s);
  return s.replace(/[ \t\u00a0]+/g, ' ')
    .replace(/ *\| */g, ' | ')
    .replace(/\n[ \t]+/g, '\n')
    .replace(/\n{3,}/g, '\n\n')
    .trim();
}

// 对问答没用的尾部小节（中文站）
const CUT_HEADING = /^## (导航|参考资料|注释|注释与参考|画廊|立绘|外部链接|分类|相关链接|参见|引用|更新历史|站务|模板)(?=\s|$)/im;

function condense(rawText, maxChars) {
  let t = rawText;
  const m = CUT_HEADING.exec(t);
  if (m) t = t.slice(0, m.index);
  t = t.trim();
  if (!t) return '';
  if (t.length > maxChars) t = `${t.slice(0, maxChars)}\n…（正文过长，已截断）`;
  return t;
}

function pageUrl(title) {
  return `${SITE}/wiki/${encodeURIComponent(String(title).replace(/ /g, '_'))}`;
}

// ── 输出 ──────────────────────────────────────────────────────────────

function formatCandidates(query, hits) {
  const lines = [`Wiki 里没有与「${query}」完全对应的页面，搜到这些相近的：`];
  hits.slice(0, 6).forEach((h, i) => {
    lines.push(`${i + 1}. ${h.title}${h.snippet ? ` — ${h.snippet}` : ''}`);
  });
  lines.push('');
  lines.push('挑最匹配的那个，把它的 title 原样传给 limbus-wiki__lookup 的 title 参数再查一次；不要自己编页面名。');
  return lines.join('\n');
}

function formatPage(title, text, query) {
  return [
    `【边狱公司 Wiki】${title}`,
    `页面：${pageUrl(title)}`,
    query ? `（搜索词：${query}）` : '',
    '',
    text,
    '',
    '【发送方式】挑与提问相关的部分，用中文简明回答，用 send_message 发到当前会话并传 atUserId=提问者的 QQ 号；数字/机制照抄页面，不要编造。'
  ].filter(Boolean).join('\n');
}

// ── 工具 ──────────────────────────────────────────────────────────────

export async function setup(skillApi) {
  api = skillApi;

  // 启动时探测一次：Cloudflare 兜底依赖 Electron 主进程的 BrowserWindow。
  // 只 import 不建窗口，失败也只打日志，不影响技能加载。
  try {
    const electron = await import('electron');
    api.log(`Cloudflare 兜底：内置浏览器${electron?.BrowserWindow ? '可用' : '不可用（拿不到 BrowserWindow）'}`);
  } catch (error) {
    api.warn(`Cloudflare 兜底：内置浏览器不可用（${error?.message ?? error}）`);
  }

  api.registerTool({
    id: 'lookup',
    name: '查边狱Wiki',
    category: 'query',
    icon: '🚌',
    description: '查询 limbuscompany.huijiwiki.com（边狱公司中文维基）的页面，返回中文正文。参数二选一：query 传中文关键词搜索（如 浮士德 / 人格 / 异想体 / 堂吉诃德），或 title 传精确页面标题（如 浮士德）。适合群友问边狱巴士的人格、E.G.O、异想体、剧情、机制、代号等资料。',
    parameters: {
      type: 'object',
      additionalProperties: false,
      properties: {
        query: { type: 'string', description: '中文关键词（作品术语直接用中文即可）' },
        title: { type: 'string', description: '精确页面标题（从候选列表里拿到的那个）' }
      }
    },
    async execute(_ctx, args) {
      try {
        const cfg = api.config() || {};
        if (cfg.enabled === false) {
          return { content: '错误：边狱 Wiki 查询技能已被关闭（设置里可重新打开）', isError: true };
        }
        const maxChars = Math.min(12000, Math.max(800, Number(cfg.maxChars ?? 4500) || 4500));
        const ttlMs = Math.max(0, Number(cfg.cacheTtlSec ?? 600)) * 1000;

        const title = String(args?.title ?? '').trim();
        const query = String(args?.query ?? '').trim().slice(0, 60);
        if (!title && !query) {
          return { content: '错误：请提供 query（关键词）或 title（精确页面标题）', isError: true };
        }

        if (title) {
          const cached = pageCache.get(title);
          if (cached && Date.now() - cached.at < ttlMs) {
            return { content: formatPage(cached.title, cached.text, '') };
          }
          const page = await fetchPage(title, maxChars);
          pageCache.set(title, { at: Date.now(), ...page });
          return { content: formatPage(page.title, page.text, '') };
        }

        const hits = await searchWiki(query);
        if (!hits.length) {
          return {
            content: `Wiki 里没搜到「${query}」。可以换个更准确的叫法（人格/角色全名、E.G.O 名、异想体名），或直接告诉提问者没找到。`,
            isError: true
          };
        }

        const lower = query.toLowerCase();
        const exact = hits.find((h) => {
          const last = h.title.split('/').pop().toLowerCase();
          return last === lower || h.title.toLowerCase() === lower;
        });
        const pick = exact || (hits.length === 1 ? hits[0] : null);
        if (!pick) return { content: formatCandidates(query, hits) };

        const cached = pageCache.get(pick.title);
        if (cached && Date.now() - cached.at < ttlMs) {
          return { content: formatPage(cached.title, cached.text, query) };
        }
        const page = await fetchPage(pick.title, maxChars);
        pageCache.set(pick.title, { at: Date.now(), ...page });

        if (pageCache.size > 120) {
          const entries = [...pageCache.entries()].sort((a, b) => a[1].at - b[1].at);
          for (const [k] of entries.slice(0, 60)) pageCache.delete(k);
        }
        return { content: formatPage(page.title, page.text, query) };
      } catch (error) {
        const msg = error?.name === 'AbortError'
          ? `查询超时（${TIMEOUT_MS / 1000} 秒），稍后再试`
          : `查询失败：${error?.message ?? error}`;
        api?.warn?.(msg);
        return { content: `错误：${msg}`, isError: true };
      }
    }
  });

  api.log('已就绪：边狱公司中文维基查询（MediaWiki API + Cloudflare 浏览器兜底）注册完成');
}
