﻿// acg-db —— 二次元（ACGN）数据库
// 数据源：本地索引（作品/外号/术语） + 中文维基摘要 + Bangumi 条目 + B站热门
// 设计原则：能直连的直连，需要翻墙的走 data/proxy.json（复用 src/proxy-tunnel.js）；
//           任何网络失败都退化成“查不到”，绝不抛出到对话里。
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const SKILL_DIR = path.dirname(fileURLToPath(import.meta.url));
const APP_ROOT = path.resolve(SKILL_DIR, '../..');
const DATA_DIR = path.resolve(APP_ROOT, '../../data/acg-db');
const WORKS_FILE = path.join(DATA_DIR, 'works.json');
const TERMS_FILE = path.join(DATA_DIR, 'terms.json');
const META_FILE = path.join(DATA_DIR, 'meta.json');

import { createTopicStore } from './lib/topicdb.js';

const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0 Safari/537.36';
const BILI_HEADERS = { 'User-Agent': UA, Referer: 'https://search.bilibili.com/' };
const WIKI = 'https://zh.wikipedia.org/w/api.php';

let SETTINGS = { enabled: true, autoSyncHours: 6, syncOnActivate: true, timeoutMs: 20000, maxChars: 1200, hotLimit: 10 };
let timer = null;
let log = () => {};
let TOPIC = null;
let BILI_COOKIE = null;
let BILI_COOKIE_AT = 0;

// ── 基础工具 ─────────────────────────────────────────────
function ensureDirs() {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

function readJson(file, fallback) {
  try {
    return JSON.parse(fs.readFileSync(file, 'utf8'));
  } catch {
    return fallback;
  }
}

function writeJson(file, value) {
  ensureDirs();
  fs.writeFileSync(file, JSON.stringify(value, null, 2), 'utf8');
}

async function httpGet(url, { headers = {}, timeoutMs = SETTINGS.timeoutMs, maxBytes = 4_000_000 } = {}) {
  const host = new URL(url).hostname;
  let tunnel = null;
  try {
    tunnel = await import('../../src/proxy-tunnel.js');
  } catch {
    tunnel = null;
  }
  if (tunnel?.proxyFor?.(host)) {
    const r = await tunnel.proxyFetchOnce(url, { asBinary: false, maxBytes, timeoutMs, headers });
    if (r.statusCode !== 200) throw new Error(`HTTP ${r.statusCode}`);
    return String(r.body || '');
  }
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), timeoutMs);
  try {
    const res = await fetch(url, { headers: { 'User-Agent': UA, ...headers }, signal: ctrl.signal, redirect: 'follow' });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    return await res.text();
  } finally {
    clearTimeout(t);
  }
}

function stripHtml(html) {
  return String(html || '')
    .replace(/<script[\s\S]*?<\/script>/gi, '')
    .replace(/<style[\s\S]*?<\/style>/gi, '')
    .replace(/<[^>]+>/g, '')
    .replace(/&nbsp;/g, ' ')
    .replace(/&amp;/g, '&')
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/\s+/g, ' ')
    .trim();
}

function clip(text, max = SETTINGS.maxChars) {
  const s = String(text || '').trim();
  return s.length > max ? s.slice(0, max) + '…' : s;
}

// ── 内置术语表（离线可用的“听得懂”底座）────────────────
const TERMS = [
  ['番', '动画作品，一集叫“一话”；“追番”是跟着更新看，“补番”是一次性把老番看完'],
  ['新番', '本季度刚开始播的动画'],
  ['表番', '正常公开播出的动画'],
  ['里番', '成人向、不公开播出的动画'],
  ['OVA', '不电视播出、单独发售的动画'],
  ['剧场版', '电影院上映的动画电影'],
  ['轻小说', '带插图的日式小说，很多动画改编自它'],
  ['漫画', '日本漫画，常以“卷/话”计'],
  ['Galgame', '以剧情和攻略角色为主的日式恋爱游戏'],
  ['乙女向', '面向女性玩家的恋爱作品'],
  ['百合', '女性之间的恋爱/亲密关系题材'],
  ['耽美', '男性之间的恋爱题材（腐向）'],
  ['纯爱', '一对一、干净专一的恋爱题材'],
  ['后宫', '一个主角被多个异性围绕的题材'],
  ['异世界', '穿越/转生到另一个世界的题材'],
  ['龙傲天', '主角强到不讲道理的爽文设定'],
  ['傲娇', '嘴上不饶人、心里其实在意'],
  ['病娇', '爱到偏执、会做出过激行为'],
  ['三无', '无口、无心、无表情'],
  ['中二', '沉浸在自我设定里的夸张言行'],
  ['傲沉', '表面冷淡、内心戏很多'],
  ['厨', '某作品的死忠粉；“厨力”是投入程度'],
  ['单推', '只支持某一个角色/偶像'],
  ['推', '支持、喜欢（“我推”=我支持的角色）'],
  ['中之人', 'VTuber/角色背后的真人'],
  ['VTuber', '虚拟主播，用虚拟形象直播'],
  ['声优', '配音演员，日语叫“CV”'],
  ['立绘', '角色的全身/半身插画'],
  ['人设', '角色设定（外貌、性格、背景）'],
  ['二创', '粉丝基于原作做的二次创作'],
  ['同人', '粉丝自制作品（同人志/同人图/同人游戏）'],
  ['本子', '同人志，常特指成人向'],
  ['谷子', '周边商品（徽章、立牌、挂件）'],
  ['cos', '角色扮演，穿角色服装'],
  ['展子', '漫展/同人展'],
  ['圣地巡礼', '去动画取景地打卡'],
  ['作画', '动画的画面表现，崩了叫“作画崩坏”'],
  ['崩坏', '画面/剧情质量突然拉胯'],
  ['鬼畜', '用素材反复剪辑做的搞笑视频'],
  ['梗', '网络上反复玩的段子/桥段'],
  ['迷因', 'meme，网上传播的梗图/梗句'],
  ['名场面', '作品里特别出名的一幕'],
  ['剧透', '提前透露剧情，很多人忌讳'],
  ['弹幕', '视频上飘过的评论'],
  ['开团', '带头挑事/带节奏'],
  ['打call', '在演出中为偶像应援'],
  ['op', '片头曲；“ed”是片尾曲'],
  ['cv', '声优（Character Voice）'],
  ['bd', '蓝光碟，画质最好的一版'],
  ['ost', '原声音乐集'],
  ['ip', '作品版权/系列（“这个IP”=这个系列）'],
  ['联动', '两个作品/品牌合作'],
  ['复刻', '活动/卡池重新开放'],
  ['废萌', '没什么剧情、主打可爱的作品'],
  ['燃', '热血、看得人激动'],
  ['治愈', '看了心情变好'],
  ['致郁', '看了心情变差（不是打错字）'],
  ['沙雕', '无厘头搞笑'],
  ['刀子', '剧情里的虐心桥段'],
  ['白学', '三角恋撕扯（出自《白色相簿2》）'],
  ['俺妹', '《我的妹妹哪有这么可爱！》'],
  ['石头门', '《命运石之门》'],
  ['巨人', '《进击的巨人》'],
  ['鬼灭', '《鬼灭之刃》'],
  ['咒术', '《咒术回战》'],
  ['芙莉莲', '《葬送的芙莉莲》'],
  ['间谍过家家', '《SPY×FAMILY》'],
  ['孤独摇滚', '《孤独摇滚！》'],
  ['推子', '《【我推的孩子】》'],
  ['药屋', '《药屋少女的呢喃》'],
  ['迷宫饭', '《迷宫饭》'],
  ['原神', '米哈游开放世界游戏'],
  ['崩铁', '《崩坏：星穹铁道》'],
  ['绝区零', '米哈游动作游戏'],
  ['方舟', '《明日方舟》'],
  ['fgo', '《Fate/Grand Order》'],
  ['碧蓝', '《碧蓝航线》或《碧蓝档案》，看语境'],
  ['ba', '《碧蓝档案》（Blue Archive）'],
  ['蔚蓝档案', '《碧蓝档案》的另一种叫法'],
  ['赛马娘', '《赛马娘 Pretty Derby》'],
  ['偶像大师', '《THE IDOLM@STER》系列'],
  ['lovelive', '《LoveLive!》系列'],
  ['邦邦', '《BanG Dream!》'],
  ['pjsk', '《世界计划 彩色舞台 feat. 初音未来》'],
  ['东方', '《东方Project》系列'],
  ['月姬', 'TYPE-MOON 作品《月姬》'],
  ['fate', 'TYPE-MOON 的 Fate 系列'],
  ['刀剑', '《刀剑神域》'],
  ['re0', '《Re:从零开始的异世界生活》'],
  ['无职', '《无职转生》'],
  ['史莱姆', '《关于我转生变成史莱姆这档事》'],
  ['骨王', '《Overlord》'],
  ['一拳', '《一拳超人》'],
  ['辉夜', '《辉夜大小姐想让我告白》'],
  ['春物', '《我的青春恋爱物语果然有问题》'],
  ['京吹', '《吹响！上低音号》'],
  ['紫罗兰', '《紫罗兰永恒花园》'],
  ['你的名字', '新海诚动画电影'],
  ['天气之子', '新海诚动画电影'],
  ['铃芽', '《铃芽之旅》'],
  ['千与千寻', '宫崎骏动画电影'],
  ['eva', '《新世纪福音战士》'],
  ['高达', '《机动战士高达》系列'],
  ['假面骑士', '特摄系列'],
  ['奥特曼', '特摄系列'],
  ['战队', '超级战队系列（特摄）'],
  ['宝可梦', '《宝可梦》系列'],
  ['数码宝贝', '《数码宝贝》系列'],
  ['游戏王', '《游戏王》系列'],
  ['龙珠', '《龙珠》系列'],
  ['海贼', '《海贼王》'],
  ['火影', '《火影忍者》'],
  ['死神', '《BLEACH》'],
  ['银魂', '《银魂》'],
  ['柯南', '《名侦探柯南》']
];

// 常见外号 → 正式名（索引里也会积累，这里是离线兜底）
const ALIASES = {
  呆毛王: '阿尔托莉雅·潘德拉贡',
  剑心: '河上彦斋（FGO 里「剑心」=河上彦斋；动漫圈一般指《浪客剑心》的绯村剑心，看语境）',
  杀狐: '光之高扬斯卡娅',
  王姐: '摩根',
  老板娘: '斯卡哈',
  父王: '吉尔伽美什',
  c呆: '阿尔托莉雅·卡斯特',
  术呆: '阿尔托莉雅·卡斯特',
  医生: '罗曼尼·阿其曼',
  学妹: '玛修·基列莱特',
  小太阳: '迦尔纳',
  大英雄: '阿拉什',
  老板娘: '斯卡哈',
  蓝呆: '阿尔托莉雅·潘德拉贡',
  黑呆: '阿尔托莉雅·潘德拉贡〔Alter〕',
  二姐: '尤瑞艾莉',
  大姐: '斯忒诺',
  枪呆: '阿尔托莉雅·潘德拉贡〔Lancer〕',
  弓呆: '阿尔托莉雅·潘德拉贡〔Archer〕'
};

// ── 数据加载 ─────────────────────────────────────────────
function loadWorks() {
  return readJson(WORKS_FILE, { version: 1, works: [] });
}

// 把内置术语表快照给其他插件（domain-hints）复用，避免两处维护
function syncBuiltinTerms() {
  try {
    const file = path.join(DATA_DIR, 'builtin-terms.json');
    const payload = JSON.stringify({ version: 1, updatedAt: Date.now(), builtin: TERMS }, null, 0);
    const old = fs.existsSync(file) ? fs.readFileSync(file, 'utf8') : '';
    if (old !== payload) fs.writeFileSync(file, payload);
  } catch { /* 快照失败不影响主流程 */ }
}
function loadTerms() {
  const extra = readJson(TERMS_FILE, { version: 1, terms: [] });
  return extra;
}

function loadMeta() {
  return readJson(META_FILE, { version: 1, lastSyncAt: 0, stats: {} });
}

function termIndex() {
  const map = new Map();
  for (const [name, desc] of TERMS) map.set(name.toLowerCase(), { name, desc, source: '内置术语表' });
  for (const row of loadTerms().terms || []) {
    if (!row?.name) continue;
    map.set(String(row.name).toLowerCase(), row);
    for (const a of row.aliases || []) {
      const k = String(a || '').toLowerCase();
      if (k && !map.has(k)) map.set(k, { ...row, viaAlias: a });
    }
  }
  return map;
}

function learnTerm({ name, desc, aliases = [], source = '现场学的', type = 'term', verified = null, evidence = '' }) {
  const clean = String(name || '').trim();
  if (!clean) throw new Error('要记的名字不能为空');
  const aliasList = (Array.isArray(aliases) ? aliases : String(aliases || '').split(/[,，、\/]/))
    .map((a) => String(a || '').trim())
    .filter(Boolean);
  const now = Date.now();

  if (type === 'work') {
    const db = loadWorks();
    const list = db.works || [];
    const hit = list.find((w) => String(w.name).toLowerCase() === clean.toLowerCase() || (w.aliases || []).some((a) => String(a).toLowerCase() === clean.toLowerCase()));
    if (hit) {
      hit.desc = desc ? String(desc) : hit.desc;
      hit.aliases = Array.from(new Set([...(hit.aliases || []), ...aliasList]));
      hit.updatedAt = now;
      hit.source = hit.source || source;
    } else {
      list.push({ name: clean, aliases: aliasList, desc: desc ? String(desc) : '', source, firstSeenAt: now, updatedAt: now });
    }
    writeJson(WORKS_FILE, { version: 1, works: list.slice(-400) });
    return { type: 'work', name: clean, total: list.length };
  }

  const db = loadTerms();
  const list = db.terms || [];
  const hit = list.find((t) => String(t.name).toLowerCase() === clean.toLowerCase() || (t.aliases || []).some((a) => String(a).toLowerCase() === clean.toLowerCase()));
  if (hit) {
    if (desc) hit.desc = String(desc);
    hit.aliases = Array.from(new Set([...(hit.aliases || []), ...aliasList]));
    hit.updatedAt = now;
    hit.source = source || hit.source;
    if (verified !== null) hit.verified = verified === true;
    if (evidence) hit.evidence = String(evidence);
  } else {
    list.push({ name: clean, aliases: aliasList, desc: desc ? String(desc) : '', source, verified: verified === true, evidence: String(evidence || ''), createdAt: now, updatedAt: now });
  }
  writeJson(TERMS_FILE, { version: 1, terms: list.slice(-800) });
  return { type: 'term', name: clean, total: list.length };
}

function workIndex() {
  const list = loadWorks().works || [];
  return list.filter((w) => w && w.name);
}

function findWork(query) {
  const q = String(query || '').trim().toLowerCase();
  if (!q) return null;
  const list = workIndex();
  let hit = list.find((w) => String(w.name).toLowerCase() === q);
  if (hit) return hit;
  hit = list.find((w) => (w.aliases || []).some((a) => String(a).toLowerCase() === q));
  if (hit) return hit;
  hit = list.find((w) => String(w.name).toLowerCase().includes(q) && q.length >= 2);
  return hit || null;
}

// ── 网络查询 ─────────────────────────────────────────────
async function wikiSearch(query, limit = 3) {
  const url = `${WIKI}?action=query&list=search&srsearch=${encodeURIComponent(query)}&srlimit=${limit}&format=json&formatversion=2`;
  const text = await httpGet(url);
  const j = JSON.parse(text);
  return (j?.query?.search || []).map((s) => ({ title: s.title, snippet: stripHtml(s.snippet) }));
}

async function wikiSummary(title) {
  const url = `${WIKI}?action=query&prop=extracts&exintro=1&explaintext=1&redirects=1&titles=${encodeURIComponent(title)}&format=json&formatversion=2`;
  const text = await httpGet(url);
  const j = JSON.parse(text);
  const page = (j?.query?.pages || [])[0];
  if (!page || page.missing) return null;
  return { title: page.title, extract: stripHtml(page.extract || '') };
}

async function bangumiSubject(id) {
  const text = await httpGet(`https://api.bgm.tv/v0/subjects/${encodeURIComponent(id)}`);
  const j = JSON.parse(text);
  if (!j || !j.id) return null;
  return {
    id: j.id,
    name: j.name_cn || j.name,
    nameOriginal: j.name,
    type: j.type,
    summary: j.summary || '',
    score: j.rating?.score ?? null,
    rank: j.rating?.rank ?? null,
    votes: j.rating?.total ?? null,
    date: j.date || '',
    platform: j.platform || '',
    eps: j.eps ?? j.total_episodes ?? null,
    tags: (j.tags || []).slice(0, 8).map((t) => t.name),
    url: `https://bgm.tv/subject/${j.id}`
  };
}

async function biliPopular(limit = 10) {
  const text = await httpGet(`https://api.bilibili.com/x/web-interface/popular?ps=${Math.min(50, limit)}&pn=1`, { headers: BILI_HEADERS });
  const j = JSON.parse(text);
  const list = j?.data?.list || [];
  return list.map((v) => ({
    title: v.title,
    owner: v.owner?.name || '',
    view: v.stat?.view ?? 0,
    like: v.stat?.like ?? 0,
    url: v.short_link_v2 || `https://www.bilibili.com/video/${v.bvid}`,
    tname: v.tname || ''
  }));
}

async function biliRanking(limit = 10) {
  const text = await httpGet('https://api.bilibili.com/x/web-interface/ranking/v2?rid=0&type=all', { headers: BILI_HEADERS });
  const j = JSON.parse(text);
  const list = j?.data?.list || [];
  return list.slice(0, limit).map((v) => ({
    title: v.title,
    owner: v.owner?.name || '',
    view: v.stat?.view ?? 0,
    url: `https://www.bilibili.com/video/${v.bvid || v.aid}`,
    tname: v.tname || ''
  }));
}

async function getBiliCookie() {
  if (BILI_COOKIE && Date.now() - BILI_COOKIE_AT < 12 * 3600 * 1000) return BILI_COOKIE;
  try {
    const res = await fetch('https://www.bilibili.com/', { headers: { 'User-Agent': UA } });
    const raw = typeof res.headers.getSetCookie === 'function' ? res.headers.getSetCookie() : [res.headers.get('set-cookie') || ''];
    const pairs = raw
      .filter(Boolean)
      .map((c) => String(c).split(';')[0])
      .filter((c) => c.includes('='));
    BILI_COOKIE = Array.from(new Set(pairs)).join('; ');
    BILI_COOKIE_AT = Date.now();
  } catch {
    BILI_COOKIE = '';
  }
  return BILI_COOKIE;
}

async function biliSearch(keyword, limit = 5) {
  try {
    const url = 'https://api.bilibili.com/x/web-interface/search/type?search_type=video&keyword=' + encodeURIComponent(keyword) + '&page=1';
    const cookie = await getBiliCookie();
    const text = await httpGet(url, { headers: { ...BILI_HEADERS, ...(cookie ? { Cookie: cookie } : {}) } });
    const j = JSON.parse(text);
    if (j?.code !== 0) return [];
    const list = j?.data?.result || [];
    return list.slice(0, limit).map((v) => ({
      title: stripHtml(v.title),
      author: v.author || '',
      bvid: v.bvid || '',
      play: v.play ?? 0
    }));
  } catch {
    return [];
  }
}

// ── 同步（更新本地索引）─────────────────────────────────
async function syncIndex({ full = false } = {}) {
  const meta = loadMeta();
  const works = loadWorks();
  const known = new Set((works.works || []).map((w) => w.name));
  const added = [];
  let hotOk = false;

  // 1) B站热门/排行 → 提取作品名线索（ACGN 相关分区）
  try {
    const [pop, rank] = await Promise.all([biliPopular(20), biliRanking(20)]);
    hotOk = true;
    for (const v of [...pop, ...rank]) {
      const t = String(v.title || '').trim();
      if (!t) continue;
      // 从标题里抠书名号/【】里的名字，作为“最近在聊的作品”
      const names = [...t.matchAll(/[《【]([^》】]{1,24})[》】]/g)].map((m) => m[1].trim()).filter(Boolean);
      for (const name of names) {
        if (known.has(name)) continue;
        known.add(name);
        added.push({ name, aliases: [], source: 'bilibili', firstSeenAt: Date.now(), hot: 1 });
      }
    }
  } catch (e) {
    log(`[acg-db] B站热门抓取失败：${e.message}`);
  }

  // 2) 给新增作品补一条维基摘要（最多 6 条，避免慢）
  const enriched = [];
  for (const w of added.slice(0, 6)) {
    try {
      const r = await wikiSummary(w.name);
      if (r?.extract) enriched.push({ ...w, desc: clip(r.extract, 300), wiki: r.title });
      else enriched.push(w);
    } catch {
      enriched.push(w);
    }
  }

  const merged = [...(works.works || []), ...enriched];
  // 只保留最近 400 条，避免无限增长
  const trimmed = merged.slice(-400);
  writeJson(WORKS_FILE, { version: 1, works: trimmed });

  const stats = { works: trimmed.length, added: enriched.length, hotOk };
  const nextMeta = { ...meta, lastSyncAt: Date.now(), stats: { ...(meta.stats || {}), ...stats } };
  writeJson(META_FILE, nextMeta);
  log(`[acg-db] 同步完成：新增 ${enriched.length} 条，共 ${trimmed.length} 条`);
  return stats;
}

function scheduleSync() {
  if (timer) clearInterval(timer);
  const hours = Math.max(1, Number(SETTINGS.autoSyncHours) || 6);
  timer = setInterval(() => {
    if (SETTINGS.enabled === false) return;
    syncIndex({}).catch((e) => log(`[acg-db] 定时同步失败：${e.message}`));
  }, hours * 3600 * 1000);
  if (timer.unref) timer.unref();
}

// ── 查询编排 ─────────────────────────────────────────────
async function lookup(query) {
  const q = String(query || '').trim();
  if (!q) return '要查什么？给我个作品名、角色名或者术语。';
  const out = [];

  const work = findWork(q);
  if (work) {
    out.push(`【本地索引】${work.name}${work.aliases?.length ? '（也叫：' + work.aliases.join('、') + '）' : ''}`);
    if (work.desc) out.push(clip(work.desc, 400));
    if (work.wiki) out.push(`维基：${work.wiki}`);
  }

  const ti = termIndex();
  const term = ti.get(q.toLowerCase());
  if (term) {
    const tag = term.verified === false ? '（未核实，别当事实）' : '';
    const head = term.viaAlias ? `【术语】${q} = ${term.name}（外号）${tag}：` : `【术语】${term.name}${tag}：`;
    out.push(head + (term.desc || '（还没写解释）') + (term.source ? `（来源：${term.source}${term.evidence ? '｜证据：' + term.evidence : ''}）` : ''));
  }

  const alias = ALIASES[q.toLowerCase()] || ALIASES[q];
  if (alias) out.push(`【外号】${q} 通常指：${alias}`);

  // B站：看这个词实际出现在什么地方（对 ACG 外号比维基准）
  try {
    const hits = await biliSearch(q, 5);
    if (hits.length) {
      out.push('【B站上的相关视频】（用它判断这词指的是什么）');
      for (const h of hits.slice(0, 3)) out.push(`· ${h.title}`);
    }
  } catch {
    /* ignore */
  }

  // 萌娘百科（ACG 词条覆盖最好）
  if (TOPIC) {
    try {
      const hits = (await TOPIC.moegirlSearch(q, 5)).filter((h) => String(h.title).includes(q));
      if (hits.length) {
        const ex = await TOPIC.moegirlExtract(hits[0].title, 700);
        if (ex?.extract) {
          out.push(`【萌娘百科】${ex.title}`);
          out.push(ex.extract);
        }
      }
    } catch {
      /* ignore */
    }
  }

  // 维基：只接受标题/摘要里真的包含这个词的结果，避免「丝丝子 → 有丝分裂」这种误命中
  try {
    const hits = (await wikiSearch(q, 5)).filter((h) => String(h.title).includes(q) || String(h.snippet || '').includes(q));
    if (hits.length) {
      const summary = await wikiSummary(hits[0].title);
      if (summary?.extract) {
        out.push(`【维基】${summary.title}`);
        out.push(clip(summary.extract, 700));
      }
    }
  } catch (e) {
    out.push(`（维基没连上：${e.message}）`);
  }

  if (!out.length) return `没查到「${q}」。可以给我日文名/英文名，或者换个叫法再试；如果群里知道它出自哪部作品，告诉我我就能定位。`;
  return out.join('\n');
}

// ── 插件入口 ─────────────────────────────────────────────

// ── 按需装载：这轮聊到相关话题才把工具暴露给模型（省 schema，也避免一堆工具互相抢）──
const __LAZY_KW = ["动漫","动画","番剧","角色","声优","漫画","二次元","原神","崩铁","蔚蓝档案","碧蓝","方舟","FGO","萌"];

export function available(ctx = {}) {
  const t = String(ctx.lastUserText || '');
  if (!t) return true;
  return __LAZY_KW.some((k) => t.includes(k));
}

export async function setup(api) {
  syncBuiltinTerms();
  log = (m) => {
    try {
      api?.log?.(m);
    } catch {
      /* ignore */
    }
  };
  const cfg = (() => {
    try {
      return api?.config?.()?.settings || {};
    } catch {
      return {};
    }
  })();
  SETTINGS = { ...SETTINGS, ...(cfg || {}) };
  ensureDirs();
  ensureDirs();
  TOPIC = createTopicStore(DATA_DIR);

  if (SETTINGS.enabled !== false) {
    scheduleSync();
    if (SETTINGS.syncOnActivate !== false) {
      const meta = loadMeta();
      const stale = !meta.lastSyncAt || Date.now() - Number(meta.lastSyncAt) > Number(SETTINGS.autoSyncHours) * 3600 * 1000;
      if (stale) {
        setTimeout(() => {
          syncIndex({}).catch((e) => log(`[acg-db] 启动同步失败：${e.message}`));
        }, 8000);
      }
    }
  }

  api.registerTool({
    id: 'acg_db_create',
    name: '新建一个主题数据库',
    description: '当群里持续聊一个我们没数据的话题（比如「边狱巴士」），自己建一个库：从萌娘百科/维基/B站 拉一批初始条目。name 写话题名。',
    category: 'knowledge',
    icon: '🧱',
    parameters: {
      type: 'object',
      properties: {
        name: { type: 'string', description: '主题名（用群里常叫的）' },
        desc: { type: 'string', description: '这个库是记什么的' },
        seed: { type: 'array', description: '可选：先塞进去的条目名列表', items: { type: 'string' } }
      },
      required: ['name']
    },
    async execute(_ctx, args) {
      if (!TOPIC) return { content: '主题库还没初始化，稍后再试。' };
      const name = String(args?.name || '').trim();
      if (!name) return { content: '要建什么库？给我个名字。' };
      const db = TOPIC.create({ name, desc: args?.desc || '' });
      const added = [];
      TOPIC.addItem(db, { name, desc: `群里在聊的主题（${args?.desc || '细节还在补'}）`, verified: true, evidence: '创建时登记', source: '会话中学习' });
      // 1) 主题词条本身
      try {
        const ex = (await TOPIC.moegirlExtract(name, 500)) || (await TOPIC.wikiExtract(name, 500));
        if (ex?.extract) {
          TOPIC.addItem(db, { name: ex.title, desc: ex.extract, verified: true, evidence: '萌娘百科/维基条目', source: '联网核实' });
          added.push(ex.title);
        }
      } catch { /* ignore */ }
      // 2) 指定种子
      for (const n of args?.seed || []) {
        try {
          const ex = (await TOPIC.moegirlExtract(String(n), 300)) || (await TOPIC.wikiExtract(String(n), 300));
          TOPIC.addItem(db, { name: String(n), desc: ex?.extract || '', verified: Boolean(ex), evidence: ex ? '萌娘百科/维基' : '', source: '联网核实' });
          added.push(String(n));
        } catch { /* ignore */ }
      }
      // 3) B站热门标题里的线索
      try {
        const cookie = await getBiliCookie();
        const hits = await TOPIC.biliTitles(name, 6, cookie);
        for (const h of hits.slice(0, 4)) {
          TOPIC.addItem(db, { name: h.title.slice(0, 40), desc: `B站视频：${h.title}（UP：${h.author}）`, verified: true, evidence: 'B站搜索', source: 'B站' });
        }
        if (hits.length) added.push(`B站线索 ${hits.length} 条`);
      } catch { /* ignore */ }
      const fresh = TOPIC.load(db.slug);
      return { content: `建好了「${db.name}」库（${db.slug}）：${(fresh?.items || []).length} 条。${added.length ? '来源：' + added.join('、') : ''}` };
    }
  });

  api.registerTool({
    id: 'acg_db_add',
    name: '往主题库里记一条',
    description: '把学到的东西写进某个主题库。db 是库名，name 是条目，desc 一句话解释，evidence 写证据。只有查证过才 verified=true。',
    category: 'knowledge',
    icon: '📝',
    parameters: {
      type: 'object',
      properties: {
        db: { type: 'string', description: '库名（没有就先用 acg_db_create 建）' },
        name: { type: 'string', description: '条目名' },
        desc: { type: 'string', description: '解释' },
        aliases: { type: 'array', description: '别名', items: { type: 'string' } },
        evidence: { type: 'string', description: '证据（链接/来源）' },
        verified: { type: 'boolean', description: '是否查证过' }
      },
      required: ['db', 'name']
    },
    async execute(_ctx, args) {
      if (!TOPIC) return { content: '主题库还没初始化。' };
      const db = TOPIC.load(args?.db) || TOPIC.create({ name: args?.db });
      TOPIC.addItem(db, { name: args?.name, desc: args?.desc, aliases: args?.aliases || [], evidence: args?.evidence, verified: args?.verified === true, source: '会话中学习' });
      const fresh = TOPIC.load(db.slug);
      return { content: `记进「${db.name}」了，现有 ${(fresh?.items || []).length} 条。` };
    }
  });

  api.registerTool({
    id: 'acg_db_query',
    name: '查主题库',
    description: '在某个主题库里查条目；不传 db 就搜所有库。',
    category: 'knowledge',
    icon: '🔎',
    parameters: {
      type: 'object',
      properties: { query: { type: 'string', description: '要查的词' }, db: { type: 'string', description: '库名（可选）' } },
      required: ['query']
    },
    async execute(_ctx, args) {
      if (!TOPIC) return { content: '主题库还没初始化。' };
      const q = String(args?.query || '').trim();
      const dbs = args?.db ? [TOPIC.load(args.db)].filter(Boolean) : TOPIC.list().map((d) => TOPIC.load(d.slug)).filter(Boolean);
      const rows = [];
      for (const db of dbs) {
        for (const it of TOPIC.search(db, q).slice(0, 3)) {
          rows.push(`【${db.name}】${it.name}${it.verified === false ? '（未核实）' : ''}：${it.desc || '（没解释）'}`);
        }
      }
      if (!rows.length) return { content: `库里没查到「${q}」。${dbs.length ? '' : '（还没有任何主题库，先用 acg_db_create 建一个）'}` };
      return { content: rows.join('\n') };
    }
  });

  api.registerTool({
    id: 'acg_db_list',
    name: '列出所有主题库',
    description: '看看现在自建了哪些主题数据库、各有多少条。',
    category: 'knowledge',
    icon: '🗂️',
    parameters: { type: 'object', properties: {} },
    async execute() {
      if (!TOPIC) return { content: '主题库还没初始化。' };
      const list = TOPIC.list();
      if (!list.length) return { content: '还没有自建的主题库。' };
      return { content: list.map((d) => `· ${d.name}（${d.slug}）：${d.count} 条｜更新 ${new Date(d.updatedAt).toLocaleString()}`).join('\n') };
    }
  });

  api.registerTool({
    id: 'acg_learn',
    name: '把新词记进二次元库',
    description: '查明白一个新名字/外号/作品之后，用这个把它写进本地库（下次离线也能认）。name 必填，desc 一句话解释，aliases 可给别名数组，type 用 term（术语/角色/外号）或 work（作品）。',
    category: 'knowledge',
    icon: '✍️',
    parameters: {
      type: 'object',
      properties: {
        name: { type: 'string', description: '要记的名字（最常见的那种叫法）' },
        desc: { type: 'string', description: '一句话解释：是什么、出自哪里、为什么这么叫' },
        aliases: { type: 'array', description: '别名/外号，可多个', items: { type: 'string' } },
        source: { type: 'string', description: '来源，如 维基/B站/Bangumi/群友说的' },
        type: { type: 'string', description: 'term 或 work' }
      },
      required: ['name']
    },
    async execute(_ctx, args) {
      try {
        const r = learnTerm({ name: args?.name, desc: args?.desc, aliases: args?.aliases || [], source: args?.source, type: args?.type === 'work' ? 'work' : 'term' });
        return { content: `记住了：${r.name}（${r.type === 'work' ? '作品' : '术语'}库现在 ${r.total} 条）` };
      } catch (e) {
        return { content: `没记住：${e.message}` };
      }
    }
  });

  api.registerTool({
    id: 'acg_lookup',
    name: '查二次元词条',
    description: '查二次元作品/角色/术语/外号：先查本地索引与内置术语表，再查中文维基。群里出现不认识的名字时用这个。',
    category: 'knowledge',
    icon: '🌸',
    parameters: {
      type: 'object',
      properties: { query: { type: 'string', description: '作品名/角色名/术语/外号' } },
      required: ['query']
    },
    async execute(_ctx, args) {
      try {
        return { content: await lookup(args?.query) };
      } catch (e) {
        return { content: `查询失败：${e.message}` };
      }
    }
  });

  api.registerTool({
    id: 'acg_forget',
    name: '从二次元库删掉一条',
    description: '发现库里记错/记歪了（比如把群友的猜测当成事实），用这个删掉。name 写要删的词条名。',
    category: 'knowledge',
    icon: '🗑️',
    parameters: { type: 'object', properties: { name: { type: 'string', description: '要删的词条名' } }, required: ['name'] },
    async execute(_ctx, args) {
      const q = String(args?.name || '').trim().toLowerCase();
      if (!q) return { content: '要删哪个？' };
      const db = loadTerms();
      const list = (db.terms || []).filter((t) => String(t.name).toLowerCase() !== q && !(t.aliases || []).some((a) => String(a).toLowerCase() === q));
      const removed = (db.terms || []).length - list.length;
      writeJson(TERMS_FILE, { version: 1, terms: list });
      return { content: removed ? `删掉了 ${removed} 条，库里剩 ${list.length} 条` : `库里没有「${args?.name}」` };
    }
  });

  api.registerTool({
    id: 'acg_bangumi',
    name: '查 Bangumi 条目',
    description: '按 Bangumi 条目 id 查详情（中文名、评分、排名、放送日、话数、标签）。适合已经知道条目的情况。',
    category: 'knowledge',
    icon: '📚',
    parameters: {
      type: 'object',
      properties: { id: { type: 'string', description: 'Bangumi 条目 id（数字）' } },
      required: ['id']
    },
    async execute(_ctx, args) {
      const id = String(args?.id || '').trim();
      if (!/^\d+$/.test(id)) return { content: '需要一个纯数字的 Bangumi 条目 id。' };
      try {
        const s = await bangumiSubject(id);
        if (!s) return { content: `Bangumi 没有 ${id} 这个条目。` };
        const lines = [
          `${s.name}${s.nameOriginal && s.nameOriginal !== s.name ? '（' + s.nameOriginal + '）' : ''}`,
          s.score ? `评分 ${s.score}${s.rank ? `（排名 ${s.rank}）` : ''}，${s.votes || 0} 人评价` : '暂无评分',
          s.date ? `放送：${s.date}${s.eps ? `，${s.eps} 话` : ''}` : '',
          s.platform ? `平台：${s.platform}` : '',
          s.tags?.length ? `标签：${s.tags.join('、')}` : '',
          s.summary ? clip(s.summary, 600) : '',
          s.url
        ].filter(Boolean);
        return { content: lines.join('\n') };
      } catch (e) {
        return { content: `Bangumi 查询失败：${e.message}` };
      }
    }
  });

  api.registerTool({
    id: 'acg_wiki',
    name: '查维基百科（二次元）',
    description: '查中文维基百科的条目摘要，适合查术语、梗的来历、作品/角色的基本介绍。',
    category: 'knowledge',
    icon: '📖',
    parameters: {
      type: 'object',
      properties: { query: { type: 'string', description: '要查的词' } },
      required: ['query']
    },
    async execute(_ctx, args) {
      const q = String(args?.query || '').trim();
      if (!q) return { content: '要查什么？' };
      try {
        const hits = await wikiSearch(q, 3);
        if (!hits.length) return { content: `维基上没有「${q}」相关的条目。` };
        const lines = [];
        for (const h of hits.slice(0, 2)) {
          const s = await wikiSummary(h.title);
          lines.push(`【${h.title}】${s?.extract ? clip(s.extract, 500) : clip(h.snippet, 200)}`);
        }
        return { content: lines.join('\n\n') };
      } catch (e) {
        return { content: `维基查询失败：${e.message}` };
      }
    }
  });

  api.registerTool({
    id: 'acg_hot',
    name: '看二次元最近在聊什么',
    description: '拉 B站 热门/排行榜，看最近网上流行的动画/游戏/梗类视频，用来找话题。',
    category: 'knowledge',
    icon: '🔥',
    parameters: {
      type: 'object',
      properties: { limit: { type: 'number', description: '返回条数，默认 10' } }
    },
    async execute(_ctx, args) {
      const limit = Math.max(3, Math.min(20, Number(args?.limit) || SETTINGS.hotLimit || 10));
      try {
        const [pop, rank] = await Promise.all([biliPopular(limit), biliRanking(limit)]);
        const seen = new Set();
        const rows = [];
        for (const v of [...pop, ...rank]) {
          if (!v.title || seen.has(v.title)) continue;
          seen.add(v.title);
          rows.push(`${rows.length + 1}. ${v.title}（${v.owner}｜${v.tname || '综合'}｜播放 ${(v.view / 10000).toFixed(1)} 万）`);
          if (rows.length >= limit) break;
        }
        return { content: rows.length ? 'B站最近热门：\n' + rows.join('\n') : 'B站热门没取到数据。' };
      } catch (e) {
        return { content: `B站热门抓取失败：${e.message}` };
      }
    }
  });

  api.registerTool({
    id: 'acg_sync',
    name: '更新二次元数据库',
    description: '立即刷新本地索引（B站热门里出现的新作品 + 维基摘要）。日常自动每 6 小时跑一次，一般不用手动调。',
    category: 'knowledge',
    icon: '🔄',
    parameters: {
      type: 'object',
      properties: { full: { type: 'boolean', description: '是否全量刷新（当前实现为保留最近 400 条后的增量）' } }
    },
    async execute(_ctx, args) {
      try {
        const stats = await syncIndex({ full: args?.full === true });
        return { content: `已更新：新增 ${stats.added} 条，本地共 ${stats.works} 条作品线索。` };
      } catch (e) {
        return { content: `更新失败：${e.message}` };
      }
    }
  });

  api.registerTool({
    id: 'acg_status',
    name: '二次元数据库状态',
    description: '查看本地索引条目数、上次同步时间、内置术语数量。',
    category: 'knowledge',
    icon: '📊',
    parameters: { type: 'object', properties: {} },
    async execute() {
      const meta = loadMeta();
      const works = loadWorks().works?.length || 0;
      const extra = loadTerms().terms?.length || 0;
      const ago = meta.lastSyncAt ? Math.round((Date.now() - Number(meta.lastSyncAt)) / 60000) : null;
      return {
        content: [
          `本地作品线索：${works} 条`,
          `自动补充术语：${extra} 条（另有内置 ${TERMS.length} 条）`,
          ago == null ? '还没同步过' : `上次同步：${ago} 分钟前（每 ${SETTINGS.autoSyncHours} 小时自动一次）`,
          `数据目录：${DATA_DIR}`
        ].join('\n')
      };
    }
  });

  log(`[acg-db] 已加载：内置术语 ${TERMS.length} 条，作品线索 ${loadWorks().works?.length || 0} 条`);
}

export function deactivate() {
  if (timer) clearInterval(timer);
  timer = null;
}

export const internals = { lookup, wikiSearch, wikiSummary, bangumiSubject, biliPopular, biliRanking, syncIndex, TERMS, ALIASES };


