// 逃离塔科夫中文 Wiki 查询（eftarkov v1.0.0）
//
// ── 数据来源与合规 ──────────────────────────────────────────────────────
// 站点：https://www.eftarkov.com   （非 MediaWiki，自建 CMS）
// ★ 只抓**公开页面**，不碰 /api/ —— 站点 robots.txt 明确写了 `Disallow: /api/`，
//   所以即使它存在 API 也不用。抓的是 /search、/item/<id>、/task/<id>。
//
// ── 模式（最重要的一条，别搞错）─────────────────────────────────────────
// 塔科夫的 PVE / PVP / 赛季数据**完全不同**（实测 LEDX 跳蚤价：
//   PVP 589,999 ₽ vs PVE 980,000 ₽，差近一倍）。用户要的是 **PVE**。
// 站点用 **cookie `tarkov_mode`** 区分，前端切换代码见 site.js：
//   document.cookie = 'tarkov_mode=' + mode + ';path=/;max-age=31536000;samesite=lax'
// 服务端渲染时就按这个 cookie 选数据 ⇒ 请求时带上 Cookie 即可拿到 PVE。
// ⚠️ 不要试图用 ?mode=pve 之类的查询参数 —— 实测无效，只有 cookie 有用。
//
// ── 页面结构（2026-10-16 实测）──────────────────────────────────────────
//   · 正文全在 <main> 里；外层导航菜单有 78KB，必须排除
//   · 正文里会内嵌 <style>（形如 .ammo-pen-very-low{...}），必须剥掉
//   · 物品页 /item/<id>：h1=中文名、紧随其后的 <p>=英文名，
//       然后是 重量/占用格数/跳蚤解锁等级/商人购买/任务需求/藏身处需求/任务奖励/
//       出售给商人/跳蚤市场(基准价·报价数·当前价·单格价值·24h 均/低/高·更新时间)/
//       商人交易配方
//   · 任务页 /task/<id>：商人+地图+等级、任务目标、任务攻略、完成/失败对话；
//       地点图片在 <main> 内的 /uploads/infoImg/*.webp
//
// ── 设计要点 ────────────────────────────────────────────────────────────
// 1) 输出走"精简摘要"（用户 2026-10-16 选定 B 方案）：物品给
//    名称 / 跳蚤解锁等级 / 任务需求 / 跳蚤当前价格+更新时间；任务给
//    商人·地图·等级 / 任务目标 / 地点图片。**不要把整个 <main> 倒出来。**
// 2) 搜索用 `/search?q=<词>`，支持中文（实测「显卡」「比特币」「布洛芬」都能中）。
// 3) 工具自己发消息（与 steam-deals 同款契约）：调完不要再调 send_message。
// 4) 闸门与 steam-deals 一致：只在私聊或被点名时给。

import { setSkillConfig } from '../../src/skills/config.js'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import { spawn } from 'node:child_process'

const SKILL_ID = 'eftarkov'

const BASE = 'https://www.eftarkov.com'
const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Safari/537.36'

/** 用户要 PVE 数据；允许设置里改，但默认必须是 pve。 */
const DEFAULT_MODE = 'pve'

let cfgOf = () => ({})
let log = () => {}

/* ══════════════════════════════════════════════════════════════════════
   网络与解析
   ══════════════════════════════════════════════════════════════════════ */

function modeOf(cfg) {
  const m = String(cfg?.mode || DEFAULT_MODE).toLowerCase()
  return ['pve', 'pvp', 'season'].includes(m) ? m : DEFAULT_MODE
}

async function fetchPage(pathname, mode, timeoutMs = 25000) {
  const url = pathname.startsWith('http') ? pathname : BASE + pathname
  const r = await fetch(url, {
    headers: {
      'User-Agent': UA,
      'Accept-Language': 'zh-CN,zh;q=0.9',
      // ★ 模式就靠这个 cookie，见文件头说明
      Cookie: `tarkov_mode=${mode}`
    },
    signal: AbortSignal.timeout(timeoutMs)
  })
  if (!r.ok) throw new Error(`HTTP ${r.status}`)
  return r.text()
}

function mainHtml(html) {
  const m = /<main[^>]*>([\s\S]*?)<\/main>/i.exec(html)
  return m ? m[1] : ''
}

/** 取出 <main> 里的纯文本（剥掉 script/style/标签），并压掉空白。 */
function mainText(html) {
  const scoped = mainHtml(html) || html
  return String(scoped)
    .replace(/<script[\s\S]*?<\/script>/gi, ' ')
    .replace(/<style[\s\S]*?<\/style>/gi, ' ')   // 页面内嵌 CSS，不剥会混进正文
    .replace(/<[^>]+>/g, ' ')
    .replace(/&nbsp;/g, ' ')
    .replace(/&amp;/g, '&')
    .replace(/&#0?39;|&apos;/g, "'")
    .replace(/&quot;/g, '"')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/\s+/g, ' ')
    .trim()
}

/** 搜索结果里的条目链接（按类型分开，便于分别处理）。 */
function searchHits(html) {
  const grab = (kind) => [...new Set([...html.matchAll(new RegExp(`href="(/${kind}/[^"?#]+)"`, 'g'))].map((m) => m[1]))]
  return { items: grab('item'), tasks: grab('task'), traders: grab('trader'), maps: grab('map') }
}

/**
 * 把口语化的查询词清洗成站点能搜到的形式，并给出**多个候选查询词**（按优先级）。
 *
 * 为什么要做（2026-10-16 实测）：
 *   · 站点的搜索只匹配**物品名**，不做语义理解 —— 「5.56的穿甲弹」「m4用的子弹」
 *     这类问法直接 0 结果。
 *   · **前缀数量会干扰搜索**：用户说「100发855a1弹药包」→ 0 结果；
 *     去掉「100发」后「855a1弹药包」→ 正确命中「5.56x45mm M855A1 弹药包（50发装）」。
 *     因为真实名称里写的是「50发装」，前面多一个数字就让匹配失败。
 *   · 所以策略是**依次降级重试**，原始词优先（精确名永远最先试）。
 *
 * @param {string} q 原始查询
 * @returns {string[]} 候选查询词，已去重、保序
 */
function searchCandidates(q) {
  const raw = String(q ?? '').trim()
  if (!raw) return []
  const out = [raw]
  const push = (s) => { const t = String(s).trim(); if (t && !out.includes(t)) out.push(t) }

  // ① 去掉开头的数量修饰：「100发855a1弹药包」→「855a1弹药包」
  push(raw.replace(/^[\d,]+\s*(发|个|枚|颗|箱|包|盒|支|把|张|件)\s*/i, ''))

  // ② 去掉尾巴上的数量修饰：「855a1弹药包100发」→「855a1弹药包」
  push(raw.replace(/\s*[\d,]+\s*(发|个|枚|颗|箱|包|盒|支|把|张|件)\s*$/i, ''))

  // ③ 去掉口语化的疑问/描述尾巴：「5.56的穿甲弹药是什么」→「5.56的穿甲弹」
  //    实测要覆盖的问法（没覆盖时整句搜不到）：
  //      「doxed 任务怎么做」「M995多少钱」「斩草除根要什么」「XX有什么要求」
  const stripped = raw.replace(
    /[\s，,。.]*(是什么|有什么要求|要什么|有什么|怎么做|怎么获得|在哪做|在哪儿|在哪|哪里|多少个|几个|多少|多少钱|价格|怎么样|介绍一下|查一下|看看|给我看|想知道)[？?！!。\s]*$/g,
    ''
  )
  push(stripped)
  // 兜底：从右往左再剥一次（「斩草除根要什么材料」这类连续两个尾缀）
  if (stripped !== raw) push(stripped.replace(/[\s，,。.]*(是什么|要什么|有什么|多少|在哪|怎么做)[？?！!。\s]*$/g, ''))

  // ④ 口语化 → 取里面最像型号的片段。
  //    只保留「含数字的」或「≥3 个字母的」token，并**丢掉纯数字**
  //    —— 「100发855a1弹药包」里的 "100" 是没用的干扰项（实测搜它也没意义），
  //    真正有用的是 "855a1"。这样能少一次无用请求。
  const tokens = (raw.match(/[A-Za-z]*\d[\w.]*|[A-Za-z]{2,}/g) || [])
    .filter((t) => !/^[\d.]+$/.test(t) && (/\d/.test(t) || t.length >= 3))
  // 含数字的型号（855a1 / M995 / 7N40）比纯字母词更可能是真正要查的东西，排在前面
  tokens.sort((a, b) => (/\d/.test(b) ? 1 : 0) - (/\d/.test(a) ? 1 : 0))
  for (const t of tokens) push(t)

  // ⑤ 去掉口径前缀「5.56 M995」→「M995」（实测「5.56 M995」原样搜不到）
  const tail = /[\d.]+\s+([A-Za-z]+\d+[\w]*)\s*$/.exec(raw)
  if (tail) push(tail[1])

  return out.slice(0, 6)
}

/** 序列化候选用（日志里好看一点）。 */
const fmtCands = (arr) => arr.map((s) => `「${s}」`).join(' → ')

const num = (t, re) => {
  const m = re.exec(t)
  return m ? String(m[1]).trim() : ''
}

/* ══════════════════════════════════════════════════════════════════════
   「出售给商人」与「商人交易配方」解析（用户 2026-10-16 要求新增）
   ══════════════════════════════════════════════════════════════════════ */

/** 单元格去标签（剥掉 <img>，因为用户要「只要文字不要图」）。 */
const cleanCell = (h) => String(h).replace(/<img[^>]*>/gi, ' ').replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim()

/**
 * 出售给商人的价格表 → [{ name:'Therapist', price:'100,980 ₽' }]
 *
 * ⚠️ 必须按 HTML 结构解析，**不要在扁平文本上做正则** —— 实测踩过两个坑：
 *   1) 「竞技场裁判」「BTR司机」这类名字让「名字 价格」的正则切不干净
 *   2) 配方表里也有「材料成本 572,409₽」，扁平正则会把它当商人价格抓进来
 *      （实体比特币就这样串出过一长串垃圾）
 * 页面结构：<img alt="Therapist"> … <span>100,980 ₽</span>
 */
function parseTraders(inner) {
  const i = inner.indexOf('出售给商人')
  if (i < 0) return []
  const after = inner.slice(i)
  const pm = after.indexOf('跳蚤市场')
  const seg = pm > 0 ? after.slice(0, pm) : after.slice(0, 4000)
  const out = []
  const seen = new Set()
  for (const m of seg.matchAll(/<img[^>]+alt="([^"]+)"[^>]*>([\s\S]*?)<\/div>\s*<\/div>/g)) {
    const name = String(m[1]).trim()
    if (!/^[A-Za-z\u4e00-\u9fff][A-Za-z\u4e00-\u9fff\s()-]{1,20}$/.test(name)) continue
    const prices = m[2].match(/[\d,]+(?:\.\d+)?\s*(?:₽|\$|€)/g)
    const price = prices ? prices[prices.length - 1] : ''
    if (!price || seen.has(name)) continue
    seen.add(name)
    out.push({ name, price: price.replace(/\s+/g, ' ').trim() })
  }
  return out
}

/**
 * 商人交易配方（is-barter 表）→ 只要文字，不要图、不要价格。
 *
 * ⚠️ 材料名必须从 <a> 里取，**不能从扁平文本正则** —— 实测「GP币 ×156」
 *    会被带数字的物品名（5.56x45 / M4A1）干扰，退化成「1 ×599」。
 *    结构：<a href="/item/xx">名字 <span>×156</span></a>
 */
function parseBarter(inner) {
  const wrap = /item-recipe-table-wrap([\s\S]*?)<\/table>/i.exec(inner)
  if (!wrap) return []
  const body = /<tbody[^>]*>([\s\S]*?)<\/tbody>/i.exec(wrap[1])
  if (!body) return []
  const rows = [...body[1].matchAll(/<tr[^>]*>([\s\S]*?)<\/tr>/gi)].map((m) => m[1])
  const out = []
  for (const row of rows) {
    const cells = [...row.matchAll(/<td[^>]*>([\s\S]*?)<\/td>/gi)].map((m) => m[1])
    if (cells.length < 6) continue

    // 交换物（第 0 格）
    const targetA = /<a[^>]*>([\s\S]*?)<\/a>/.exec(cells[0])
    let target = targetA ? cleanCell(targetA[1]) : cleanCell(cells[0])
    target = target.replace(/×\s*\d+/, '').replace(/\s{2,}/g, ' ').trim()

    // 所需材料（第 1 格）：可能多个 <a>
    const mats = [...cells[1].matchAll(/<a[^>]*>([\s\S]*?)<\/a>/g)]
      .map((m) => cleanCell(m[1]).replace(/(×\d+)\s*$/, ' $1').replace(/\s+/g, ' ').trim())
      .filter(Boolean)
    if (!target || !mats.length) continue

    out.push({
      target,
      mats: [...new Set(mats)].join(' + '),
      trader: cleanCell(cells[2]),
      level: cleanCell(cells[3])
    })
  }
  return out
}

/**
 * 商人购买解析（用户 2026-10-16 用 7N40 给的字段口径）：
 *   商人购买：Prapor LL4 60/1,224 ₽（致命校准）
 *             ↑商人  ↑好感度 ↑每次刷新可买数 / 单发价  ↑前置解锁任务
 *
 * 页面结构（实测 7N40）：
 *   「商人购买」后面可能跟一个前置任务链接（带锁图标的 🔒）：
 *     <a href="/task/xxx" title="致命校准">🔒致命校准</a>
 *   然后是一个 flex 行：<span>Prapor LL4</span><span>60 / 1,224 ₽</span>
 *   ⚠️ 前置任务用的是 title 属性里的名字，链接文字带 🔒 前缀，别直接取文字。
 *
 * @returns {{quest:string, offers:Array<{trader:string,level:string,qty:string,price:string}>}|null}
 */
function parseBuy(inner) {
  const i = inner.indexOf('商人购买')
  if (i < 0) return null
  // 该区块到下一个标题（护甲穿透表 / style / 出售给商人）为止
  const after = inner.slice(i)
  const stop = ['ammo-pen-very-low', '出售给商人', '跳蚤市场', 'comments', '<table'].reduce((acc, k) => {
    const j = after.indexOf(k)
    return j > 0 && (acc < 0 || j < acc) ? j : acc
  }, -1)
  const seg = after.slice(0, stop > 0 ? stop : 2500)

  if (/没有商人出售此物品/.test(seg)) return { quest: '', offers: [] }

  // 前置解锁任务：优先取 title 属性（干净），退回链接文字并剥掉锁图标
  let quest = ''
  const qm = /<a[^>]+title="([^"]+)"[^>]*>[\s\S]*?<\/a>/.exec(seg)
  if (qm) quest = String(qm[1]).trim()
  else {
    const qm2 = /<a[^>]*>\s*(?:🔒)?\s*([^<]+)<\/a>/.exec(seg)
    if (qm2) quest = String(qm2[1]).trim()
  }

  // 商人报价行：<span>名字 LLx</span><span>数量 / 价格</span>
  const offers = []
  for (const m of seg.matchAll(/<span[^>]*>([^<]*?LL\d+[^<]*?)<\/span>\s*<span[^>]*>([^<]*?\/[^<]*?)<\/span>/g)) {
    const left = cleanCell(m[1])
    const right = cleanCell(m[2])
    const tm = /^(.+?)\s+LL(\d+)$/.exec(left)
    const pm = /^([\d,]+)\s*\/\s*([\d,]+(?:\.\d+)?\s*(?:₽|\$|€)?)$/.exec(right)
    if (!tm) continue
    offers.push({
      trader: tm[1].trim(),
      level: `LL${tm[2]}`,
      qty: pm ? pm[1] : right,
      price: pm ? pm[2] : ''
    })
  }
  return { quest, offers }
}

/**
 * 子弹专用属性解析。
 *
 * 为什么单独做：子弹的属性跟普通物品**完全不同**（实测 M995）——
 * 普通物品给「重量/价格/配方」，而查子弹真正要看的是
 * 「肉伤/甲伤/穿透/弹速」和「对各级护甲的穿透等级与真实伤害」。
 * 原来的卡片对子弹只能显示价格和跳蚤等级，等于没用。
 *
 * 页面上子弹有两块特殊数据：
 *  ① 护甲穿透表（<table>）：表头 1级..6级，表体一行是穿透等级（很高/低…）
 *  ② 一排纯文本：肉伤/甲伤/穿透/精度/后座/口径/弹片数量/最大堆叠/子弹速度/
 *     跳弹概率/哑火概率/卡壳概率/碎蛋概率/小出血/大出血/是否为曳光弹，
 *     以及「本子弹对护甲穿透减伤后的真实伤害 2级甲 3级甲 4级甲 5级甲 6级甲 42.0 42.0 …」
 */
function parseAmmo(inner, raw) {
  // 不是子弹页就没有「肉伤」这个字段，直接退出
  if (!/肉伤/.test(raw)) return null

  const n = (re) => { const m = re.exec(raw); return m ? String(m[1]).trim() : '' }

  // 子弹页的跳蚤等级原文可能是「无法上架跳蚤市场」而不是数字（实测 M995/M855A1）。
  // 原来的 /跳蚤解锁等级\s*(\d+|无)/ 会抓到「无」或空，显示成含糊的「无」。
  const fleaLockRaw = n(/跳蚤解锁等级\s*(无法上架跳蚤市场|\d+|无)/)

  // ① 护甲穿透等级表：表头 6 个等级、表体一行判定
  let penLevels = []
  const tbl = /<table[\s\S]*?<\/table>/i.exec(inner)
  if (tbl) {
    const heads = [...tbl[0].matchAll(/<th[^>]*>([\s\S]*?)<\/th>/gi)].map((m) => cleanCell(m[1]))
    const bodyCells = [...tbl[0].matchAll(/<td[^>]*>([\s\S]*?)<\/td>/gi)].map((m) => cleanCell(m[1]))
    if (heads.length && bodyCells.length) {
      penLevels = heads.map((h, i) => ({ lv: h, pen: bodyCells[i] || '' }))
    }
  }

  // ② 对各级护甲的真实伤害：表头「2级甲 … 6级甲」后面跟一串数字
  const dmgRow = /本子弹对护甲穿透减伤后的真实伤害([\s\S]*)$/.exec(raw)
  let realDmg = []
  if (dmgRow) {
    const seg = dmgRow[1]
    const lvs = [...seg.matchAll(/([1-6])级甲/g)].map((m) => `${m[1]}级`)
    const nums = [...seg.matchAll(/(\d+\.\d+)/g)].map((m) => m[1])
    realDmg = lvs.map((lv, i) => ({ lv, dmg: nums[i] || '' }))
  }

  return {
    flesh: n(/肉伤\s*([\d.]+)/),
    armor: n(/甲伤\s*([\d.]+)/),
    pen: n(/穿透\s*([\d.]+)/),
    speed: n(/子弹速度\s*([\d.]+)/),
    acc: n(/精度\s*([+\-]?[\d.]+%)/),
    recoil: n(/后座\s*([+\-]?[\d.]+%)/),
    frags: n(/弹片数量\s*([\d.]+)/),
    stack: n(/最大堆叠\s*([\d.]+)/),
    caliber: n(/口径\s*(Caliber[\w]+)/),
    ricochet: n(/跳弹概率\s*([+\-]?[\d.]+%)/),
    misfire: n(/哑火概率\s*([+\-]?[\d.]+%)/),
    jam: n(/卡壳概率\s*([+\-]?[\d.]+%)/),
    frag: n(/碎蛋概率\s*([+\-]?[\d.]+%)/),
    penLevels,
    realDmg,
    fleaLockRaw,
    buy: parseBuy(inner)
  }
}

/* ══════════════════════════════════════════════════════════════════════
   物品解析
   ══════════════════════════════════════════════════════════════════════ */

/**
 * 解析物品页，返回用户选定的字段（B 方案）。
 * 用户明确要：名称、跳蚤解锁等级、任务需求、跳蚤市场当前价格、更新时间。
 */
export function parseItem(html, pathname) {
  const raw = mainText(html)
  const inner = mainHtml(html)
  const h1 = /<h1[^>]*>([\s\S]*?)<\/h1>/i.exec(inner)
  const name = h1 ? h1[1].replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim() : ''

  // 英文名：h1 之后紧跟的那个非空 <p>（实测结构如此）
  const enMatch = /<\/h1>[\s\S]{0,400}?<p[^>]*>([\s\S]*?)<\/p>/i.exec(inner)
  const enName = enMatch ? enMatch[1].replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim() : ''

  // 任务需求段：截到下一个段落标题之前
  let taskNeeds = ''
  const tn = /任务需求([\s\S]*?)(?=藏身处升级需求|任务奖励|出售给商人|跳蚤市场|$)/.exec(raw)
  // 页面里这段以「·」开头（形如「· 新手上路 可选 战局中 × 3」），去掉开头的分隔符
  if (tn) taskNeeds = tn[1].trim().replace(/^[·•・]\s*/, '').slice(0, 300)

  const fleaPrice = num(raw, /跳蚤市场当前价格\s*([\d,]+\s*₽)/)

  return {
    name,
    enName,
    weight: num(raw, /重量\s*([\d.]+\s*kg)/),
    slots: num(raw, /占用格数\s*([\d]+\s*x\s*[\d]+)/),
    fleaLevel: num(raw, /跳蚤解锁等级\s*(\d+|无)/),
    taskNeeds,
    fleaBase: num(raw, /基准价格\s*([\d,]+\s*₽)/),
    fleaCount: num(raw, /跳蚤当前报价数量\s*([\d]+\s*个)/),
    fleaPrice,
    fleaPerSlot: num(raw, /物品单格价值\s*([\d,]+\s*₽)/),
    avg24h: num(raw, /24小时平均价格\s*([\d,]+\s*₽)/),
    low24h: num(raw, /24小时最低价格\s*([\d,]+\s*₽)/),
    high24h: num(raw, /24小时最高价格\s*([\d,]+\s*₽)/),
    updatedAt: num(raw, /更新时间\s*([\d]{4}-[\d]{2}-[\d]{2}\s+[\d:]+)/),
    noTraderBuy: /没有商人出售此物品/.test(raw),
    // 「跳蚤解锁等级 无」且没有报价 = 这东西根本上不了跳蚤（如实体比特币）
    fleaForbidden: /跳蚤解锁等级\s*无/.test(raw) && !fleaPrice,
    traders: parseTraders(inner),
    barter: parseBarter(inner),
    ammo: parseAmmo(inner, raw),
    url: BASE + pathname
  }
}

/** 物品渲染成"精简摘要"（B 方案）。 */
/**
 * 渲染成用户指定的卡片格式（2026-10-16 定稿）：
 *   🎯 显示卡
 *   ⚖️ 0.6 kg · 2x1
 *   🔓 跳蚤解锁等级：40 级
 *   📊 基准价格：198,000 ₽
 *   💰 出售商人：Therapist 100,980 ₽、Mechanic 89,100 ₽、…
 *   💵 跳蚤 当前 699,000 ₽ · 54 个在售
 *   📈 24h 均价：698,382 ₽（500,000 ₽ ~ 820,000 ₽）
 *   🕒 更新于 2026-10-16 18:08:08｜PVE 数据
 *   📋 任务需求：…
 *   🔧 商人交易配方：
 *   · GP币 ×156 → 显示卡｜竞技场裁判 LL4
 *
 * 用户两次要求（2026-10-16）：
 *   ① 「最前面带个图标」—— 每行都要有，不要出现光秃秃的文字行
 *   ② 「数据来源另起一行放在最后一行」—— 不能跟别的文字挤在同一行
 *
 * ⚠️ 用「标签：值」而不是空格对齐 —— QQ 字体非等宽，补空格反而更乱。
 */
export function renderItem(it, mode) {
  // 子弹走专用卡片：属性字段完全不同（肉伤/穿透/护甲判定），
  // 用普通卡片只能显示出价格，等于没用。
  if (it.ammo) return renderAmmo(it, mode)

  const lines = []

  // 标题行：中文名，英文名放括号里（跟原名不同才加）
  const title = it.enName && it.enName !== it.name ? `${it.name}（${it.enName}）` : it.name
  lines.push(`🎯 ${title || '(未知物品)'}`)

  // ── 规格
  const spec = []
  if (it.weight) spec.push(it.weight)
  if (it.slots) spec.push(it.slots.replace(/\s+/g, ''))
  if (spec.length) lines.push(`⚖️ ${spec.join(' · ')}`)

  // ── 解锁与基准价
  if (it.fleaLevel) lines.push(`🔓 跳蚤解锁等级：${it.fleaLevel}${/^\d+$/.test(it.fleaLevel) ? ' 级' : ''}`)
  if (it.fleaBase) lines.push(`📊 基准价格：${it.fleaBase}`)

  // ── 价格
  if (it.traders && it.traders.length) {
    lines.push('💰 出售商人：' + it.traders.map((t) => `${t.name} ${t.price}`).join('、'))
  }
  if (it.fleaPrice) {
    lines.push(`💵 跳蚤 当前 ${it.fleaPrice}${it.fleaCount ? ` · ${it.fleaCount}在售` : ''}`)
  } else if (it.fleaForbidden) {
    lines.push('💵 跳蚤 该物品不能上跳蚤市场')
  } else {
    lines.push('💵 跳蚤 暂无报价')
  }
  if (it.avg24h) lines.push(`📈 24h 均价：${it.avg24h}（${it.low24h || '—'} ~ ${it.high24h || '—'}）`)
  if (it.updatedAt) lines.push(`🕒 更新于 ${it.updatedAt}｜${mode.toUpperCase()} 数据`)

  // ── 任务需求
  if (it.taskNeeds) lines.push(`📋 任务需求：${it.taskNeeds}`)

  // ── 商人交易配方（只要文字，不要图、不要价格）
  if (it.barter && it.barter.length) {
    lines.push('🔧 商人交易配方：')
    for (const b of it.barter.slice(0, 5)) {
      lines.push(`▸ ${b.mats} → ${b.target}｜${b.trader}${b.level ? ' ' + b.level : ''}`)
    }
    if (it.barter.length > 5) lines.push(`▸ …另有 ${it.barter.length - 5} 条`)
  }

  return lines.join('\n')
}

/**
 * 子弹专用卡片（用户实测 M995 后要求补上这些字段）。
 * 格式：
 *   🎯 5.56x45毫米 M995
 *   ⚖️ 0.012 kg · 1x1
 *   🔓 跳蚤解锁等级：无法上架跳蚤市场
 *   💥 肉伤 42 · 甲伤 52 · 穿透 53
 *   🎯 精度 -7% · 后座 +8% · 弹片 1 · 堆叠 80
 *   🚀 弹速 1013 m/s · 口径 556x45NATO
 *   🛡️ 穿透等级：1级很高 · 2级很高 · … · 6级低
 *   💢 真实伤害：2级42.0 · 3级42.0 · … · 6级30.7   （对护甲穿透减伤后）
 *   ⚠️ 跳弹+36% · 哑火+18.34% · 卡壳+8.7% · 碎蛋+42%
 *   💰 出售商人：…
 *   🕒 更新于 …｜PVE 数据
 *   数据来源：eftarkov.com
 */
export function renderAmmo(it, mode) {
  const a = it.ammo
  const lines = []

  const title = it.enName && it.enName !== it.name ? `${it.name}（${it.enName}）` : it.name
  lines.push(`🎯 ${title || '(未知子弹)'}`)

  const spec = []
  if (it.weight) spec.push(it.weight)
  if (it.slots) spec.push(it.slots.replace(/\s+/g, ''))
  if (spec.length) lines.push(`⚖️ ${spec.join(' · ')}`)
  if (it.fleaLevel || a.fleaLockRaw) {
    const lv = a.fleaLockRaw || it.fleaLevel
    lines.push(`🔓 跳蚤解锁等级：${/^\d+$/.test(lv) ? lv + ' 级' : lv}`)
  }

  // 核心三围
  const core = []
  if (a.flesh) core.push(`肉伤 ${a.flesh}`)
  if (a.armor) core.push(`甲伤 ${a.armor}`)
  if (a.pen) core.push(`穿透 ${a.pen}`)
  if (core.length) lines.push(`💥 ${core.join(' · ')}`)

  const perf = []
  if (a.acc) perf.push(`精度 ${a.acc}`)
  if (a.recoil) perf.push(`后座 ${a.recoil}`)
  if (a.frags) perf.push(`弹片 ${a.frags}`)
  if (a.stack) perf.push(`堆叠 ${a.stack}`)
  if (perf.length) lines.push(`🎯 ${perf.join(' · ')}`)

  const ball = []
  if (a.speed) ball.push(`弹速 ${a.speed} m/s`)
  if (a.caliber) ball.push(`口径 ${a.caliber.replace(/^Caliber/, '')}`)
  if (ball.length) lines.push(`🚀 ${ball.join(' · ')}`)

  // 对各级护甲的穿透等级（很短，一行放得下）
  if (a.penLevels && a.penLevels.length) {
    lines.push(`🛡️ 穿透等级：${a.penLevels.map((p) => `${p.lv}${p.pen}`).join(' · ')}`)
  }
  // 减伤后的真实伤害
  if (a.realDmg && a.realDmg.length) {
    lines.push(`💢 真实伤害：${a.realDmg.map((r) => `${r.lv} ${r.dmg}`).join(' · ')}`)
  }

  const risk = []
  if (a.ricochet) risk.push(`跳弹 ${a.ricochet}`)
  if (a.misfire) risk.push(`哑火 ${a.misfire}`)
  if (a.jam) risk.push(`卡壳 ${a.jam}`)
  if (a.frag) risk.push(`碎蛋 ${a.frag}`)
  if (risk.length) lines.push(`⚠️ ${risk.join(' · ')}`)

  // 价格
  // 商人购买（用户 2026-10-16 给的格式）：
  //   商人购买：Prapor LL4 60/1,224 ₽（致命校准）
  //   多个商人就并列；没有前置任务就不加括号
  if (a.buy && a.buy.offers && a.buy.offers.length) {
    const parts = a.buy.offers.map((o) => `${o.trader} ${o.level} ${o.qty}/${o.price}`)
    const q = a.buy.quest ? `（${a.buy.quest}）` : ''
    lines.push(`🛒 商人购买：${parts.join('、')}${q}`)
    // 图例：群里的人不一定懂 LL4 与「60/1,224」的读法，一行说清
    lines.push('　（LL=好感度等级，数量/单价，括号内为前置解锁任务）')
  } else if (a.buy && a.buy.offers && !a.buy.offers.length) {
    lines.push('🛒 商人购买：没有商人出售此物品')
  }
  if (it.traders && it.traders.length) {
    lines.push('💰 出售商人：' + it.traders.map((t) => `${t.name} ${t.price}`).join('、'))
  }
  // ⚠️ 这里**故意不显示「💵 跳蚤 …」那一行**（用户 2026-10-16 要求删掉）：
  //    实测所有子弹的「跳蚤解锁等级」恒为「无法上架跳蚤市场」，永远不会有跳蚤价，
  //    那行只会永远显示「该物品不能上跳蚤市场」，是无意义的噪音。
  //    （弹药包/弹匣没有「肉伤」字段，本来就走普通卡片，不受影响。）
  if (it.updatedAt) lines.push(`🕒 更新于 ${it.updatedAt}｜${mode.toUpperCase()} 数据`)

  if (it.taskNeeds) lines.push(`📋 任务需求：${it.taskNeeds}`)

  return lines.join('\n')
}

/* ══════════════════════════════════════════════════════════════════════
   任务解析
   ══════════════════════════════════════════════════════════════════════ */

/** 解析任务页：商人/地图/等级、任务目标、地点图片。 */
/**
 * 剥掉任务页里「互动地图预览」带出来的界面文字。
 *
 * 实测（顺利搬迁）：每个地图预览都会往任务目标里插一段
 *   「在互动地图上查看位置 1层 − 100% +」
 * 用户明确要求去掉 —— 我们发的是纯文本，没法用站点的互动地图，
 * 留着只是噪音。
 */
function stripMapUi(s) {
  return String(s ?? '')
    .replace(/在互动地图上查看位置/g, ' ')
    .replace(/\d+层/g, ' ')          // 楼层标签（1层 / 2层…）
    .replace(/\d{1,3}%/g, ' ')       // 缩放比例
    .replace(/[−–—]\s*\+/g, ' ')     // 缩放按钮「− … +」
    .replace(/\s+/g, ' ')
    .trim()
}


/** 去掉 <style>/<script>，否则区块正则会捞到 CSS（踩过一次：地图抽到 0 个）。 */
function dropStyleScript(s) {
  return String(s ?? '')
    .replace(/<style[\s\S]*?<\/style>/gi, ' ')
    .replace(/<script[\s\S]*?<\/script>/gi, ' ')
}

/**
 * 逐条抽「任务目标」。
 * 页面结构（实测，很规整）：
 *   <h2>…任务目标</h2>
 *   <ul><li><span class="task-objective-index">1</span><div>正文</div></li>…</ul>
 * @returns {Array<{idx:string,text:string}>}
 */
function parseGoals(inner) {
  const block = /任务目标[\s\S]*?<ul[^>]*>([\s\S]*?)<\/ul>/i.exec(dropStyleScript(inner))
  if (!block) return []
  const out = []
  for (const m of block[1].matchAll(/<li[^>]*>([\s\S]*?)<\/li>/gi)) {
    const idx = ((/task-objective-index[^>]*>([^<]*)</.exec(m[1]) || [])[1] || '').trim()
    const body = m[1].replace(/<span[^>]*task-objective-index[\s\S]*?<\/span>/i, '')
    const text = cleanCell(body)
    if (text) out.push({ idx: idx || String(out.length + 1), text })
  }
  return out
}

/**
 * 逐条抽「物品需求」（进图要带什么、去哪买）。
 *   <div class="task-use-item-requirements"><h2>…物品需求</h2>
 *     <div class="task-required-item">…<a href="/item/xxx">名字</a> ×3 商人 LL1 …
 */

/**
 * 逐条抽「任务攻略」（★ 用户 2026-10-16 指出：攻略不是独立段落，而是和互动地图绑在一起）。
 *
 * 页面结构（实测「敲诈者」）：
 *   <section class="task-og-section"><div class="task-og-list">
 *     <article class="task-og-card">
 *       <div class="task-og-head"><span class="task-og-index">1</span>
 *         <div class="task-og-name">在海关找到信使的尸体</div></div>
 *       <div class="task-og-map-preview" data-map-width=… data-map-height=…>
 *         <img class="task-og-map-image" src="/assets/maps/<id>/1.svg">
 *         <span class="task-og-map-marker" data-marker-x=… data-marker-y=…>
 *         <span class="task-og-floor">1层</span></div>
 *       <div class="task-og-desc">需要先在信使的尸体里摸一把未知钥匙…</div>   ← ★ 攻略正文
 *       <div class="task-og-images rich-guide-content"><img …></div>
 *     </article>…
 *
 * ⚠️ 别再用 rich-guide-content 判断"有没有攻略" —— 那只是**图片容器**，
 *    文字在 task-og-desc 里。我一开始只看 rich-guide-content，于是误判成"没有攻略"。
 */
function parseOgCards(inner) {
  const src0 = dropStyleScript(inner)
  const sec = /<section[^>]*task-og-section[\s\S]*?(?=<\/section>|$)/i.exec(src0)
  if (!sec) return []
  const out = []
  const cards = [...sec[0].matchAll(/<article[^>]*task-og-card[^>]*>([\s\S]*?)(?=<article[^>]*task-og-card|$)/gi)]
  for (const m of cards) {
    const seg = m[1]
    const name = cleanCell((/task-og-name"[^>]*>([\s\S]*?)<\/div>/.exec(seg) || [])[1] || '')
    const desc = cleanCell((/task-og-desc"[^>]*>([\s\S]*?)<\/div>/.exec(seg) || [])[1] || '')
    const idx = ((/task-og-index"[^>]*>([^<]*)</.exec(seg) || [])[1] || '').trim()
    const svgRaw = (/<img[^>]+class="[^"]*task-og-map-image[^"]*"[^>]+src="([^"]+)"/.exec(seg)
      || /<img[^>]+src="([^"]*\/assets\/maps\/[^"]+)"/.exec(seg) || [])[1] || ''
    const mx = Number((/data-marker-x="([\d.]+)"/.exec(seg) || [])[1])
    const my = Number((/data-marker-y="([\d.]+)"/.exec(seg) || [])[1])
    const floor = ((/task-og-floor">([^<]*)</.exec(seg) || [])[1] || '').trim()
    const imgs = [...seg.matchAll(/<img[^>]+src="([^"]*\/uploads\/infoImg\/[^"]+)"/g)].map((x) => x[1])
    if (!name && !desc) continue
    out.push({
      idx: idx || String(out.length + 1),
      name,
      desc,
      floor,
      markerX: Number.isFinite(mx) ? mx : null,
      markerY: Number.isFinite(my) ? my : null,
      svg: svgRaw ? (svgRaw.startsWith('http') ? svgRaw : BASE + svgRaw) : '',
      images: imgs.map((u) => (u.startsWith('https://') ? u : BASE + u))
    })
  }
  return out
}

/**
 * 抽任务页里**全部**物品清单条目，并按「它前面最近的那个标题」归类。
 *
 * 为什么不用「按容器 class 切区块 + 区块内找条目」——
 *   实测「钥匙需求」区块的下一个标题就是「物品收集」，两个区块的 HTML 相邻，
 *   用非贪婪 + lookahead 划边界时钥匙那段会把物品收集的条目一起捞进来
 *   （0048号保险文件夹同时出现在两段里就是这么来的）。
 *   改成「一次扫全页、按最近的标题归属」就不存在边界问题。
 *
 * 页面结构：
 *   <div class="task-key-requirements">  <h2>钥匙需求</h2>   …task-required-item…
 *   <div class="task-item-requirements"> <h2>物品收集</h2>   …task-required-item…
 *   <div class="task-use-item-requirements"> <h2>物品需求</h2> …task-required-item…
 *   每条：<a class="task-required-item-name">名字 ×N</a>
 *        <span class="task-required-item-type">任务物品</span>
 *        <span class="task-required-item-fir">战局中</span>
 *
 * @returns {{key:Array,collect:Array,use:Array}}
 */
function parseAllItemLists(inner) {
  const src = dropStyleScript(inner)
  // 标题位置（只要 钥匙需求 / 物品收集 / 物品需求 这三个）
  const heads = []
  for (const m of src.matchAll(/<h2[^>]*>([\s\S]*?)<\/h2>/gi)) {
    const t = cleanCell(m[1])
    if (/钥匙需求|物品收集|物品需求/.test(t)) heads.push({ at: m.index, kind: t })
  }
  const buckets = { key: [], collect: [], use: [] }
  if (!heads.length) return buckets

  const segs = []
  heads.forEach((h, i) => segs.push({ kind: h.kind, from: h.at, to: i + 1 < heads.length ? heads[i + 1].at : src.length }))

  for (const seg of segs) {
    const body = src.slice(seg.from, seg.to)
    const target = /钥匙/.test(seg.kind) ? buckets.key : /收集/.test(seg.kind) ? buckets.collect : buckets.use
    for (const m of body.matchAll(/<div class="task-required-item"[^>]*>([\s\S]*?)(?=<div class="task-required-item"|<h2|$)/gi)) {
      const s2 = m[1]
      const href = (/<a[^>]+href="(\/item\/[^"]+)"/.exec(s2) || [])[1] || ''
      const nm = cleanCell((/task-required-item-name"[^>]*>([\s\S]*?)<\/a>/.exec(s2) || [])[1] || '')
        .replace(/\s*[Xx×]\s*(\d+)/g, ' ×$1')
      if (!nm) continue
      const tags = [...s2.matchAll(/<span[^>]*class="task-required-item-(?:type|fir)"[^>]*>([\s\S]*?)<\/span>/g)]
        .map((x) => cleanCell(x[1])).filter(Boolean)
      // 商人报价也当标签（那格常是「Therapist LL1」）
      for (const mm of s2.matchAll(/>([A-Za-z\u4e00-\u9fff]{2,20})\s+LL(\d)</g)) {
        const tg = `${mm[1]} LL${mm[2]}`
        if (!tags.includes(tg)) tags.push(tg)
      }
      if (target.some((x) => x.name === nm)) continue   // 去重
      target.push({ name: nm.slice(0, 120), tags, href: href ? BASE + href : '' })
    }
  }
  return buckets
}

/**
 * 抽「奖励」（商人好感 / 经验值 / 游戏币 …）。
 * ⚠️ 边界必须卡在 <div id="task-comments"> 之前 —— 不卡会把评论区文字
 *    （「评论 还没有人喵，下面请你简单喵两句」）一起吞进最后一个奖励值里。
 */
function parseRewards(inner) {
  const seg = /task-rewards-card([\s\S]*?)(?=<div id="task-comments"|<\/aside>|<\/main>|$)/i.exec(dropStyleScript(inner))
  if (!seg) return []
  const out = []
  for (const m of seg[1].matchAll(/task-reward-group"[^>]*>([\s\S]*?)(?=<div class="[^"]*task-reward-group|$)/gi)) {
    const label = cleanCell((/<div[^>]*>\s*<i[^>]*><\/i>\s*([^<]+)</.exec(m[1]) || [])[1] || '')
    const body = cleanCell(m[1].replace(/<i[^>]*><\/i>/g, ' '))
      .replace(label, '').replace(/^\s*奖励\s*/, '').trim()
    if (body) out.push({ label: label.trim(), value: body.slice(0, 80) })
  }
  return out
}

export function parseTask(html, pathname) {
  const raw = mainText(html)
  const inner = mainHtml(html)
  const h1 = /<h1[^>]*>([\s\S]*?)<\/h1>/i.exec(inner)
  const name = h1 ? h1[1].replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim() : ''

  // 任务页开头形如：「Mechanic 中心区 等级 1+ Doxed Doxed Hey.As I understand...」
  //   = 商人 + 地图 + 等级 + 中文名 + 英文名 + 描述
  // ⚠️ 不能用 ^ 锚定（正文前可能有空白/多行，实测匹配不到），直接从「等级」往回取一段。
  const trader = /([A-Za-z\u4e00-\u9fff]+)\s+([^\s]+)\s+等级\s+([\d]+\+|\d+)/.exec(raw)

  // 地点图片（实测在 /uploads/infoImg/ 下，webp）
  const imgs = [...new Set([...inner.matchAll(/<img[^>]+src="([^"]*\/uploads\/infoImg\/[^"]+)"/g)].map((m) => m[1]))]

  const ogCards = parseOgCards(inner)
  const itemLists = parseAllItemLists(inner)

  return {
    name,
    trader: trader ? trader[1] : '',
    map: trader ? trader[2] : '',
    level: trader ? trader[3] : '',
    goals: parseGoals(inner),                       // 任务要求（结构化逐条）
    ogCards,                                        // ★ 攻略：每条 = 目标名 + 攻略正文 + 地图
    keyItems: itemLists.key,
    collectItems: itemLists.collect,
    useItems: itemLists.use,
    rewards: parseRewards(inner),
    images: imgs.map((u) => (u.startsWith('https://') ? u : BASE + u)),
    maps: ogCards.filter((c) => c.svg).map((c) => ({
      svg: c.svg, markerX: c.markerX, markerY: c.markerY, floor: c.floor, name: c.name
    })),
    url: BASE + pathname
  }
}

const CIRCLED = ['①', '②', '③', '④', '⑤', '⑥', '⑦', '⑧', '⑨', '⑩', '⑪', '⑫']

/**
 * 任务卡片渲染（用户 2026-10-16 指定）：
 *   📜 敬献者
 *   📍 商人 Skier · 地图 海关 · 等级 1+
 *   🎯 任务要求：
 *   　① 在海关找到信使的尸体
 *   　② 在海关找到并获取被藏匿的高价值货物
 *   📦 需要物品：
 *   　▪ 0048号保险文件夹 ×1（未知钥匙）
 *   📖 任务攻略：
 *   　1. 先摸尸体拿未知钥匙…
 *
 * ★ 用户明确要求：① 每条逐条另起一行；② 任务目标与攻略用**不同**的记号区分。
 *   任务目标用带圈的 ①②③，攻略用 1. 2. 3.，物品用 ▪ —— 三者在视觉上不会混。
 */
export function renderTask(t) {
  const lines = [`📜 ${t.name}`]
  const meta = []
  if (t.trader) meta.push(`商人 ${t.trader}`)
  if (t.map) meta.push(`地图 ${t.map}`)
  if (t.level) meta.push(`等级 ${t.level}`)
  if (meta.length) lines.push(`📍 ${meta.join(' · ')}`)

  // 任务要求：逐条一行，带圈序号
  const goals = Array.isArray(t.goals) ? t.goals : []
  if (goals.length) {
    lines.push('🎯 任务要求：')
    goals.slice(0, 12).forEach((g, i) => {
      lines.push(`　${CIRCLED[i] || (i + 1) + '.'} ${g.text}`)
    })
  }

  // 钥匙需求 / 物品收集 / 物品需求：逐条一行，方点
  const itemGroups = [
    ['🔑 钥匙需求', t.keyItems],
    ['📦 物品收集', t.collectItems],
    ['📦 需要物品', t.useItems]
  ]
  for (const [title, arr] of itemGroups) {
    const list = Array.isArray(arr) ? arr : []
    if (!list.length) continue
    lines.push(`${title}：`)
    list.slice(0, 8).forEach((n) => {
      const tag = n.tags && n.tags.length ? `（${n.tags.join(' · ')}）` : ''
      lines.push(`　▪ ${n.name}${tag}`)
    })
  }

  // ★ 任务攻略：与互动地图绑在一起，逐条是「目标名 + 攻略正文」。
  //   序号用「1. 2. 3.」与任务要求的圈号 ①②③ 明确区分开（用户要求）。
  const cards = (Array.isArray(t.ogCards) ? t.ogCards : []).filter((c) => c.desc)
  if (cards.length) {
    lines.push('📖 任务攻略：')
    cards.slice(0, 8).forEach((c, i) => {
      lines.push(`　${i + 1}. ${c.name}`)
      lines.push(`　　 ${c.desc}`)
    })
  }

  // 奖励
  const rw = Array.isArray(t.rewards) ? t.rewards : []
  if (rw.length) {
    lines.push('🎁 奖励：')
    rw.slice(0, 6).forEach((r) => lines.push(`　▪ ${r.label ? r.label + ' ' : ''}${r.value}`))
  }

  if (t.maps && t.maps.length) lines.push(`🗺️ 附 ${t.maps.length} 张目标位置地图`)
  if (t.images.length) lines.push(`🖼️ 附 ${t.images.length} 张地点示意图`)
  return lines.join('\n')
}

/** 目标点图标：优先用站点自己的 /uploads/mapIcon/quest_objective.png，
 *  拿不到就退回一个内嵌的红圈十字 SVG（保证图上一定有标记）。 */
let MARKER_DATA_URI = null
const FALLBACK_MARKER = 'data:image/svg+xml;base64,' + Buffer.from(
  '<svg xmlns="http://www.w3.org/2000/svg" width="30" height="30">'
  + '<circle cx="15" cy="15" r="11" fill="none" stroke="#ff2d2d" stroke-width="4"/>'
  + '<circle cx="15" cy="15" r="3" fill="#ff2d2d"/></svg>'
).toString('base64')

async function markerDataUri() {
  if (MARKER_DATA_URI) return MARKER_DATA_URI
  try {
    const r = await fetch(BASE + '/uploads/mapIcon/quest_objective.png', {
      headers: { 'User-Agent': UA, Referer: BASE + '/' }, signal: AbortSignal.timeout(15000)
    })
    if (r.ok) {
      const buf = Buffer.from(await r.arrayBuffer())
      if (buf.length && buf.length < 200 * 1024) {
        MARKER_DATA_URI = 'data:image/png;base64,' + buf.toString('base64')
        return MARKER_DATA_URI
      }
    }
  } catch { /* 用兜底 */ }
  MARKER_DATA_URI = FALLBACK_MARKER
  return MARKER_DATA_URI
}

/**
 * 清理本技能产生的临时图片，避免长期占用磁盘（用户 2026-10-16 提出）。
 *
 * 为什么要清理：地图 PNG 与地点图都是先落到系统临时目录、再把**本地路径**交给
 * 发送通道去读。发完不能立刻删（发送是异步的，删早了会发不出去），所以之前是
 * **纯累积** —— 实测一次测试就留下 3 个 PNG(310KB) + 2 个 webp(1.7MB)。
 *
 * 策略（三重保险，任一触发就停）：
 *   · 只删「最后修改时间超过 keepMs」的文件（默认 30 分钟，绝不会碰到正在发的）
 *   · 每轮最多删 maxDelete 个文件
 *   · 总量低于 minKeepBytes 时不动手（避免只留几百 KB 就白跑一趟）
 * 整体在一个 try 里，任何异常都不影响主流程。
 */
function cleanupTempFiles({ keepMs = 30 * 60 * 1000, maxDelete = 200, minKeepBytes = 2 * 1024 * 1024 } = {}) {
  try {
    const dirs = [
      path.join(os.tmpdir(), 'qqa-eftarkov'),
      path.join(os.tmpdir(), 'qqa-eftarkov-map')
    ]
    const now = Date.now()
    for (const dir of dirs) {
      let entries = []
      try { entries = fs.readdirSync(dir) } catch { continue }
      const files = []
      let total = 0
      for (const name of entries) {
        const p = path.join(dir, name)
        try {
          const st = fs.statSync(p)
          if (!st.isFile()) continue
          files.push({ p, mtime: st.mtimeMs, size: st.size })
          total += st.size
        } catch { /* 跳过 */ }
      }
      if (total < minKeepBytes) continue
      // 旧的先删
      files.sort((a, b) => a.mtime - b.mtime)
      let deleted = 0
      for (const f of files) {
        if (deleted >= maxDelete) break
        if (now - f.mtime < keepMs) break        // 后面的都更新，直接停
        try { fs.unlinkSync(f.p); deleted++ } catch { /* 跳过 */ }
      }
      if (deleted) log(`清理临时图片：删除 ${deleted} 个（${dir}）`)
    }
  } catch { /* 清理失败绝不影响主流程 */ }
}

/**
 * 把站点的地图 SVG 渲染成一张**带目标标记的 PNG**（用户要求「把这个静态地图输出出来」）。
 *
 * 为什么要绕这一圈：站点地图是 SVG（实测灯塔图 187KB gzip / 693KB 解压、1145 个 path），
 * 而 QQ 发不了 SVG，所以必须转成位图。本机没有 ImageMagick / rsvg-convert / inkscape，
 * **但装了 Edge**，于是用 `msedge --headless --screenshot` 渲染一个自建 HTML 来出图。
 *
 * 出图策略：不整张发（灯塔图 1100×1700，整张缩放后标记点太小看不清），
 * 而是**以标记为中心裁一块** —— 外面套一个固定尺寸的视口，靠 transform 把
 * 标记点平移到视口正中。
 *
 * ⚠️ 坐标 1:1：实测 map.sv 的 viewBox 宽高与 data-map-width/height 相同，
 *    所以标记的 data-marker-x/y 可直接当 SVG 用户单位用，不需要换算。
 *
 * @returns {Promise<string|null>} PNG 本地路径；失败返回 null（不影响文字部分）
 */
async function renderMapPng(map, opts = {}) {

  // 出图尺寸：宽度固定，**高度按图片宽高比算**（不能固定高度，见下面 #vp 的注释）。
  const VW = 660          // 视口宽
  const VH_MAX = 760      // 视口高上限（极高的图如 1100×1700 灯塔图会撞到这个上限）
  const EDGE = [
    'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe',
    'C:\\Program Files\\Microsoft\\Edge\\Application\\msedge.exe'
  ].find((p) => { try { return fs.existsSync(p) } catch { return false } })
  if (!EDGE) return null

  const dir = path.join(os.tmpdir(), 'qqa-eftarkov-map')
  fs.mkdirSync(dir, { recursive: true })
  const stamp = `${Date.now()}-${Math.random().toString(36).slice(2, 7)}`
  const htmlFile = path.join(dir, `m-${stamp}.html`)
  const pngFile = path.join(dir, `m-${stamp}.png`)
  const svgFile = path.join(dir, `s-${stamp}.svg`)

  // 先把 SVG 拉到本地：file:// 页面直接引用远程 https 图会被拦（跨源 + 断网风险），
  // 本地同目录引用最稳。
  const r = await fetch(map.svg, {
    headers: { 'User-Agent': UA, Referer: BASE + '/' },
    signal: AbortSignal.timeout(40000)
  })
  if (!r.ok) return null
  const svg = await r.text()
  fs.writeFileSync(svgFile, svg, 'utf8')

  // 从 SVG 自己读宽高/viewBox，比用 data-map-* 更可靠
  const vb = /viewBox="([\d.\-\s]+)"/.exec(svg)
  const w = Number((/width="([\d.]+)"/.exec(svg) || [])[1]) || (vb ? Number(vb[1].trim().split(/\s+/)[2]) : 1100)
  const h = Number((/height="([\d.]+)"/.exec(svg) || [])[1]) || (vb ? Number(vb[1].trim().split(/\s+/)[3]) : 1700)

  const mx = Number.isFinite(map.markerX) ? map.markerX : w / 2
  const my = Number.isFinite(map.markerY) ? map.markerY : h / 2
  // 用百分比定位标记，天然适配任何图幅（不用把 SVG 缩放到像素再算）
  const leftPct = (mx / w) * 100
  const topPct = (my / h) * 100

  // ★ 视口尺寸**必须等于图片本身的宽高比**，否则标记会错位（用户 2026-10-16 抓到的问题）。
  //   之前的写法是视口固定 660×620 + `object-fit:contain`：2400×1200 的海关图被缩到
  //   660×330 居中，上下留黑边；而标记的 `left/top` 百分比算的是**视口盒子**，
  //   不是图片实际渲染区域 ⇒ 标记跑到图上别的位置去了。
  //   现在让视口跟着图幅走（宽固定、高按比例算），图正好铺满，百分比即图上真实位置。
  //   同时把 object-fit 换成 fill —— 盒子比例已经和图一致，fill 不会变形。
  const boxW = VW
  let boxH = Math.max(200, Math.round((boxW * h) / w))
  const boxCapped = boxH > VH_MAX
  if (boxCapped) boxH = VH_MAX   // 极高的图（如 1100×1700 灯塔）限制高度，但仍保持整图可见

  const markerUri = await markerDataUri()

  const page = `<!doctype html><html><head><meta charset="utf-8"><style>
html,body{margin:0;padding:0;background:#101010;overflow:hidden}
/* 视口宽高比 = 图片宽高比 ⇒ 标记百分比与图片像素一一对应，不会错位 */
#vp{position:relative;width:${boxW}px;height:${boxH}px;overflow:hidden;background:#101010}
img.map{position:absolute;left:0;top:0;width:100%;height:100%;object-fit:fill;display:block}
.mk{position:absolute;left:${leftPct}%;top:${topPct}%;transform:translate(-50%,-50%);
    width:38px;height:38px;z-index:5;pointer-events:none;
    filter:drop-shadow(0 0 5px #000) drop-shadow(0 0 3px #fff)}
/* 外圈再套一个半透明红环，让目标点在整张地图上一眼可见 */
.ring{position:absolute;left:${leftPct}%;top:${topPct}%;transform:translate(-50%,-50%);
      width:56px;height:56px;border-radius:50%;border:3px solid rgba(255,45,45,.85);
      box-shadow:0 0 12px rgba(255,45,45,.6);z-index:4;pointer-events:none}
.tag{position:absolute;left:8px;bottom:8px;color:#fff;background:rgba(0,0,0,.75);
     font:14px/1.4 "Microsoft YaHei",sans-serif;padding:5px 10px;border-radius:6px;z-index:9}
</style></head><body>
<div id="vp">
  <img class="map" src="./${path.basename(svgFile)}" alt="">
  <div class="ring"></div>
  <img class="mk" src="${markerUri}" alt="">
  <div class="tag">${String(map.mapName || '').replace(/[<>&]/g, '')}${map.floor ? ' · ' + map.floor : ''}</div>
</div>
</body></html>`
  fs.writeFileSync(htmlFile, page, 'utf8')

  const budget = Math.max(15000, Number(opts.timeoutMs) || 45000)
  await new Promise((resolve) => {
    const p = spawn(EDGE, [
      '--headless', '--disable-gpu', '--no-sandbox', '--hide-scrollbars',
      '--disable-extensions', '--disable-background-networking',
      `--window-size=${boxW},${boxH}`,
      `--screenshot=${pngFile}`,
      'file:///' + htmlFile.replace(/\\/g, '/')
    ], { windowsHide: true, stdio: 'ignore' })
    const t = setTimeout(() => { try { p.kill() } catch { /* 已退出 */ } resolve() }, budget)
    p.on('exit', () => { clearTimeout(t); resolve() })
    p.on('error', () => { clearTimeout(t); resolve() })
  })

  let ok = false
  try { ok = fs.existsSync(pngFile) && fs.statSync(pngFile).size > 2000 } catch { ok = false }
  // 清理中间文件（保留 PNG）
  for (const f of [htmlFile, svgFile]) { try { fs.unlinkSync(f) } catch { /* 忽略 */ } }
  return ok ? pngFile : null
}

/* ══════════════════════════════════════════════════════════════════════
   触发闸门
   ══════════════════════════════════════════════════════════════════════ */

/**
 * 只有**被 @（艾特）**才允许查塔科夫；关键词呼出、随机插嘴一律拒绝。
 * 用户 2026-10-16 明确要求：「只有 @ai 的时候才会触发塔科夫查询工具，
 * 单纯群聊提到或者关键词呼出 ai 不会触发工具」。
 *
 * ⚠️ 判定必须用 `contextReason`，**不能用 tier === 1** —— 因为「拍一拍」
 *    也是 tier=1（见 prompt.js：pokeMe 返回 { tier: 1, reason: '拍了拍我' }），
 *    用 tier 判断会把拍一拍也放进来，与用户要求不符。
 * reverse 依赖：orchestrator.js:853-855 把 resolveContextTier 的结果写进
 *    session.contextTier / contextLimit / contextReason，技能拿到的就是这份。
 *
 * 各场景的 reason（实测）：
 *   被 @        → tier=1  reason='被艾特'      ✅ 放行
 *   关键词命中   → tier=2  reason='关键词命中'   ❌ 拒绝
 *   拍一拍      → tier=1  reason='拍了拍我'     ❌ 拒绝（用户只说了 @）
 *   随机插嘴     → tier=3  reason='随机命中(x%)' ❌ 拒绝
 *   私聊        → tier=4  reason='私聊消息'      ✅ 放行（1v1 无 @ 机制）
 */
function gate(ctx, cfg) {
  // 私聊恒放行：1v1 本来就等于在跟机器人说话，没有 @ 机制
  if (ctx?.kind === 'private') return ''

  // 总开关（默认已开；这里只是给一个后路）
  if (cfg?.mentionOnly === false) return ''

  const tier = Number(ctx?.session?.contextTier)
  const reason = String(ctx?.session?.contextReason || '')

  // 拿不到档位信息时不硬拦，交给提示词约束（与 steam-deals 同口径）
  if (!Number.isFinite(tier)) return ''

  // 只认「被艾特」
  if (reason === '被艾特') return ''
  // 老存档可能没有 reason：退回到 tier===1（会连带放行拍一拍，但比全拒更安全）
  if (!reason && tier === 1) return ''

  return `这次在群里**没有被 @**（档位 ${tier}，触发原因「${reason || '未知'}」）。`
    + '塔科夫资料只在用户**主动 @ 机器人**时才给，关键词被提到、被拍一拍、随机插嘴都不给。'
    + '把这条当作没发生：**不要发任何塔科夫内容、不要解释为什么不说、也不要提这件事**，正常聊别的就行。'
}

/**
 * 下载图片到本地临时文件（发送通道要本地路径）。
 * ⚠️ 站点图片可直连（实测 webp 1006KB HTTP 200），带 Referer 更稳。
 * 过大的图不发（避免拖慢发送、也避免 base64 爆掉）。
 */
async function downloadImage(url, refererPath) {
  const r = await fetch(url, {
    headers: { 'User-Agent': UA, 'Referer': BASE + (refererPath || '/') },
    signal: AbortSignal.timeout(30000)
  })
  if (!r.ok) return null
  const buf = Buffer.from(await r.arrayBuffer())
  if (buf.length > 6 * 1024 * 1024) return null
  const ext = /\.png$/i.test(url) ? 'png' : /\.jpe?g$/i.test(url) ? 'jpg' : 'webp'
  const dir = path.join(os.tmpdir(), 'qqa-eftarkov')
  fs.mkdirSync(dir, { recursive: true })
  const file = path.join(dir, `eft-${Date.now()}-${Math.random().toString(36).slice(2, 8)}.${ext}`)
  fs.writeFileSync(file, buf)
  return file
}

/* ══════════════════════════════════════════════════════════════════════
   技能契约
   ══════════════════════════════════════════════════════════════════════ */

export function setup(api) {
  cfgOf = () => (api.config && typeof api.config === 'function' ? (api.config() || {}) : {})
  log = (...a) => { try { api.log(...a) } catch { /* 日志失败不影响主流程 */ } }

  /* ── 工具一：查物品 ───────────────────────────────────────────────── */
  api.registerTool({
    id: 'item',
    name: '查塔科夫物品',
    description:
      '查《逃离塔科夫》某件物品的资料：名称、重量、占用格数、跳蚤解锁等级、基准价格、'
      + '出售商人价格、跳蚤市场当前价格与更新时间、任务需求、商人交易配方。'
      + '**默认用 PVE 数据**（PVE/PVP 价格差很多，别混）。'
      + '★ **只有被 @ 之后**，用户只发一个物品名就直接调本工具（拍一拍、关键词呼出都不行）：'
      + '「@机器人 ledx」「@机器人 显卡」「@机器人 比特币」这种没有任何修饰词的裸名字，'
      + '一律当成"查这件物品"，**不要反问"你想查什么"、也不要只回一句闲聊**。'
      + '带修饰词当然也调：「XX 多少钱」「XX 跳蚤价多少」「XX 有什么用」「XX 要什么任务」。'
      + '支持中文名（显卡 / 比特币 / 布洛芬 / LEDX）或英文名。'
      + '⚠️ 这个工具**自己发消息**：调完不要再调 send_message，直接结束这一轮。'
      + '返回第一行是 status：ok=已发出 / no-target=群里没被点名 / error=失败。',
    category: 'utility',
    icon: '🎯',
    parameters: {
      type: 'object',
      properties: {
        name: { type: 'string', description: '物品名，中文或英文都行，例如「显卡」「LEDX」「布洛芬」「比特币」。' }
      },
      required: ['name']
    },

    async execute(ctx, args) {
      const cfg = cfgOf()
      const deny = gate(ctx, cfg)
      if (deny) return { content: `status: no-target\n${deny}`, isError: true }

      const want = String(args?.name ?? '').trim()
      if (!want) return { content: 'status: error\n没有给物品名。请直接问用户要查哪件物品。', isError: true }

      const sender = ctx?.sender
      const chatKey = String(ctx?.chatKey || '')
      if (!sender || !chatKey) return { content: 'status: error\n拿不到发送通道，这条没发出去。', isError: true }

      cleanupTempFiles()   // 顺手清掉过期的临时图片（阈值见函数注释）
      const mode = modeOf(cfg)
      // ★ 多候选降级重试：站点的搜索只匹配物品名、不做语义理解，而且**前缀数量
      //   会干扰**（「100发855a1弹药包」搜不到，去掉「100发」才行）。所以按
      //   searchCandidates 给出的候选依次重试，原始词永远第一个试。
      const cands = searchCandidates(want)
      let path = '', html = '', usedQuery = want, allHits = []
      try {
        for (const q of cands) {
          const sHtml = await fetchPage(`/search?q=${encodeURIComponent(q)}`, mode)
          const hits = searchHits(sHtml).items
          if (hits.length) {
            allHits = hits
            path = hits[0]
            usedQuery = q
            if (q !== want) log(`查「${want}」原词没结果，改用「${q}」命中`)
            break
          }
        }
        if (!path) {
          log(`查「${want}」全部候选都没结果（${fmtCands(cands)}）`)
          return {
            content: `status: error\n在塔科夫 Wiki 没搜到「${want}」（试过：${cands.join(' / ')}）。`
              + '请如实告诉用户没找到，建议他给出**接近游戏内的物品名**'
              + '（如果是子弹/弹药包，用「型号 + 弹药包」这种写法，例如「M855A1弹药包」），'
              + '**不要自己编价格**。',
            isError: true
          }
        }
        html = await fetchPage(path, mode)
      } catch (e) {
        const msg = String(e?.message ?? e).slice(0, 150)
        log(`查物品失败：${msg}`)
        return { content: `status: error\n查「${want}」失败：${msg}。稍后再试。`, isError: true }
      }

      const it = parseItem(html, path)
      const text = renderItem(it, mode)

      const segs = [{ type: 'text', data: { text } }]
      if (cfg.showImage !== false) {
        try {
          const icon = [...mainHtml(html).matchAll(/<img[^>]+src="([^"]*\/uploads\/(?:item|items)\/[^"]+)"/g)].map((m) => m[1])[0]
          if (icon) {
            const file = await downloadImage(icon.startsWith('http') ? icon : BASE + icon, path)
            if (file) segs.push({ type: 'image', data: { file } })
          }
        } catch { /* 图失败不影响文字 */ }
      }
      // ★ 数据来源必须**独立成最后一行**（用户 2026-10-16 要求）。
      //   原来是用一个单独的 text 段，实测发出去会被 QQ 并到上一行末尾
      //   （「…利润保留 × 30数据来源: eftarkov.com」）。改成拼进正文尾部加换行，
      //   这样无论有没有图片都保证在最后一行、且独占一行。
      const lastText = `\n数据来源：eftarkov.com`
      const firstTextSeg = segs.find((s) => s.type === 'text')
      if (firstTextSeg) firstTextSeg.data.text = `${text}${lastText}`
      else segs.push({ type: 'text', data: { text: lastText.trim() } })

      try {
        if (typeof sender.sendMedia === 'function') {
          await sender.sendMedia(chatKey, segs, { label: '塔科夫物品' })
        } else if (typeof sender.sendTextBatch === 'function') {
          await sender.sendTextBatch(chatKey, [text], {})
        } else {
          return { content: 'status: error\n发送通道不支持发送。', isError: true }
        }
        log(`已发送物品：${it.name}（${mode}）`)
        // 如果这次结果里有别的候选，把它们的 id 附上 —— 万一取的不是用户想的那件，
        // 模型至少知道「还有别的可能」，用户追问时能对上（不额外请求，零成本）。
        const others = allHits.slice(1, 4)
        const altNote = others.length
          ? `\n搜索还有其它候选（id）：${others.map((u) => u.split('/').pop()).join(' / ')}`
            + '。如果用户说「不是这个」，让他给更完整的名字。'
          : ''
        const retryNote = usedQuery !== want ? `\n（原词「${want}」搜不到，实际按「${usedQuery}」查的）` : ''
        return {
          content: `status: ok\n已发出「${it.name}」的资料（${mode.toUpperCase()}）。${retryNote}${altNote}`
            + '不要再用 send_message 复述，直接结束这一轮。'
        }
      } catch (e) {
        return { content: `status: error\n发送失败：${String(e?.message ?? e).slice(0, 120)}`, isError: true }
      }
    }
  })

  /* ── 工具二：查任务（含地点图片） ─────────────────────────────────── */
  api.registerTool({
    id: 'task',
    name: '查塔科夫任务',
    description:
      '查《逃离塔科夫》某个任务的**任务要求（任务目标）**、**目标位置地图**和**地点图片**。'
      + '★ **只有被 @ 之后**，用户只发一个任务名就直接调本工具（拍一拍、关键词呼出都不行）：'
      + '「@机器人 Doxed」「@机器人 棋留一着」这种裸名字一律当成"查这个任务"，'
      + '**不要反问他想要什么**。'
      + '带修饰词当然也调：「XX 任务怎么做」「XX 任务要求」「XX 任务地点在哪」。'
      + '支持中文名（棋留一着 / 斩草除根）或英文名（Doxed / Side Hustle）。'
      + '会把站点的**目标位置地图（在图上标出目标点）**和地点示意图一起发给用户。'
      + '⚠️ 这个工具**自己发消息**：调完不要再调 send_message，直接结束这一轮。'
      + '返回第一行是 status：ok=已发出 / no-target=群里没被点名 / error=失败。',
    category: 'utility',
    icon: '📜',
    parameters: {
      type: 'object',
      properties: {
        name: { type: 'string', description: '任务名，中文或英文都行，例如「棋留一着」「Doxed」。' }
      },
      required: ['name']
    },

    async execute(ctx, args) {
      const cfg = cfgOf()
      const deny = gate(ctx, cfg)
      if (deny) return { content: `status: no-target\n${deny}`, isError: true }

      const want = String(args?.name ?? '').trim()
      if (!want) return { content: 'status: error\n没有给任务名，请直接问用户。', isError: true }

      const sender = ctx?.sender
      const chatKey = String(ctx?.chatKey || '')
      if (!sender || !chatKey) return { content: 'status: error\n拿不到发送通道。', isError: true }

      cleanupTempFiles()   // 顺手清掉过期的临时图片（阈值见函数注释）
      const mode = modeOf(cfg)
      // 与物品工具同款：多候选降级重试
      const cands = searchCandidates(want)
      let path = '', html = '', usedQuery = want
      try {
        for (const q of cands) {
          const sHtml = await fetchPage(`/search?q=${encodeURIComponent(q)}`, mode)
          const hits = searchHits(sHtml).tasks
          if (hits.length) {
            path = hits[0]
            usedQuery = q
            if (q !== want) log(`查任务「${want}」原词没结果，改用「${q}」命中`)
            break
          }
        }
        if (!path) {
          return {
            content: `status: error\n没搜到「${want}」这个任务（试过：${cands.join(' / ')}）。`
              + '如实告诉用户没找到，建议他给出接近游戏内的任务名，**不要自己编任务内容**。',
            isError: true
          }
        }
        html = await fetchPage(path, mode)
      } catch (e) {
        return { content: `status: error\n查任务「${want}」失败：${String(e?.message ?? e).slice(0, 120)}`, isError: true }
      }

      const t = parseTask(html, path)
      const text = renderTask(t)

      const segs = [{ type: 'text', data: { text } }]
      // ① 目标位置地图（用户要求输出这个）：把站点 SVG 渲染成带标记的 PNG。
      //    ⚠️ 每张地图都要跑一次 Edge headless，比较慢（数秒），所以：
      //       · 用 maxTaskMaps 限制数量（默认 2）
      //       · 整段有总预算，超时就放弃地图、只发文字与地点图（不能因为它把消息拖死）
      const maxMaps = Math.min(3, Math.max(0, Number(cfg.maxTaskMaps ?? 2) || 0))
      let sentMaps = 0
      if (maxMaps && t.maps && t.maps.length) {
        const deadline = Date.now() + Math.max(10000, Number(cfg.mapBudgetMs ?? 60000) || 60000)
        for (const m of t.maps.slice(0, maxMaps)) {
          if (Date.now() > deadline) { log('地图渲染超预算，剩余地图跳过'); break }
          try {
            const png = await renderMapPng({ ...m, mapName: t.map || '' }, {
              timeoutMs: Math.max(8000, deadline - Date.now())
            })
            if (png) { segs.push({ type: 'image', data: { file: png } }); sentMaps++ }
            else log(`地图渲染未出图：${m.svg}`)
          } catch (e) {
            log(`地图渲染异常：${String(e?.message ?? e).slice(0, 100)}`)
          }
        }
      }
      // 地点图片：最多发 maxTaskImages 张（默认 4，避免刷屏与占带宽）
      const maxImg = Math.min(8, Math.max(0, Number(cfg.maxTaskImages ?? 4) || 0))
      let sentImgs = 0
      for (const u of t.images.slice(0, maxImg)) {
        try {
          const file = await downloadImage(u, path)
          if (file) { segs.push({ type: 'image', data: { file } }); sentImgs++ }
        } catch { /* 单张失败跳过 */ }
      }
      // 同物品工具：数据来源拼进正文尾部，保证独立成最后一行
      segs[0].data.text = `${text}\n数据来源：eftarkov.com`

      try {
        if (typeof sender.sendMedia === 'function') {
          await sender.sendMedia(chatKey, segs, { label: '塔科夫任务' })
        } else if (typeof sender.sendTextBatch === 'function') {
          await sender.sendTextBatch(chatKey, [text], {})
        } else {
          return { content: 'status: error\n发送通道不支持发送。', isError: true }
        }
        log(`已发送任务：${t.name}（${mode}，地图 ${sentMaps} 张，地点图 ${sentImgs} 张）`)
        const mapNote = sentMaps ? `、${sentMaps} 张目标位置地图` : ''
        const retryNote = usedQuery !== want ? `\n（原词「${want}」搜不到，实际按「${usedQuery}」查的）` : ''
        return {
          content: `status: ok\n已发出任务「${t.name}」的要求${mapNote}与 ${sentImgs} 张地点图片。${retryNote}`
            + '不要再用 send_message 复述，直接结束这一轮。'
        }
      } catch (e) {
        return { content: `status: error\n发送失败：${String(e?.message ?? e).slice(0, 120)}`, isError: true }
      }
    }
  })

  /* ── 工具三：切换 PVE / PVP（数据源模式） ─────────────────────────── */
  api.registerTool({
    id: 'mode',
    name: '切换塔科夫数据模式',
    description:
      '切换塔科夫资料用的是 PVE 还是 PVP 数据。**默认 PVE**。'
      + '用户说「用 PVP 的」「切回 PVE」时调用。留空则只查询当前模式。'
      + '⚠️ PVE 与 PVP 的价格完全不同，不要混用。',
    category: 'utility',
    icon: '🔀',
    parameters: {
      type: 'object',
      properties: {
        mode: { type: 'string', description: '目标模式：pve / pvp / season。留空=只查询当前设置。' }
      },
      required: []
    },

    async execute(ctx, args) {
      const cfg = cfgOf()
      const input = String(args?.mode ?? '').trim().toLowerCase()

      if (!input) {
        return { content: `当前塔科夫数据模式：${modeOf(cfg).toUpperCase()}。要换就说「用 PVP 数据」。` }
      }
      if (!['pve', 'pvp', 'season'].includes(input)) {
        return { content: `认不出「${input}」。只能是 pve / pvp / season。`, isError: true }
      }

      let after = null
      try { after = setSkillConfig(SKILL_ID, { mode: input }) } catch (e) {
        log(`写入模式失败：${String(e?.message || e).slice(0, 100)}`)
      }
      if (String(after?.mode || '').toLowerCase() !== input) {
        return { content: `设置没写进去（当前仍是 ${modeOf(cfg).toUpperCase()}）。`, isError: true }
      }
      return { content: `已把塔科夫数据模式换成 ${input.toUpperCase()}。之后查物品都按这个模式。` }
    }
  })

  log(`${SKILL_ID} 已就绪（工具：${SKILL_ID}__item / ${SKILL_ID}__task / ${SKILL_ID}__mode，默认 PVE）`)
}

export function available() {
  return true
}

export function dispose() {
  cfgOf = () => ({})
  log = () => {}
}

export const internals = { gate, parseItem, parseTask, renderItem, renderTask, renderAmmo, parseAmmo, searchCandidates, renderMapPng, cleanupTempFiles, parseGoals, parseOgCards, parseAllItemLists, parseRewards, stripMapUi, mainText, mainHtml, searchHits }
