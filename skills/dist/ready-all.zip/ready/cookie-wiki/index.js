// 曲奇☆百科（cookie-wiki）—— LLM 型技能，放 skills/。
//
// ── 为什么是技能，不是插件 ───────────────────────────────────────────────
//   判据只有一条：规则能不能写死。
//   「这条消息是不是在问曲奇☆/东方」「该不该查」「查回来怎么给看法」——
//   三件事都得读懂人话，写不成 if/else。所以判断权留在模型手里：
//   registerTool 给模型一把「查百科」的尺子 + 提示词片段告诉它什么时候用。
//   做成 plugins/ 的确定性钩子，就只能变成「见关键词就抓网页」的死工具。
//
// ── 站点现状（2026-10 实测）───────────────────────────────────────────────
//   · cookie.wiki（中文主站）整站 502，nginx 在、后端不在；
//   · cookiewiki.org（英文 Cookie Wiki）正常，MediaWiki 1.44，接口可用；
//   · cookie.fandom.com / moegirl.uk 从本机 DNS 解析失败。
//   所以这里做「主站 → 备用站 → 再兜底」的顺序访问，并且**记住谁挂了**：
//   主站 502 之后 5 分钟内不再重试，免得每条消息都白等 8 秒超时。
//
// ── 踩坑备忘 ─────────────────────────────────────────────────────────────
//   · 只有清单里声明了 permissions: ["web_fetch"]，api.fetch 才是真 fetch；
//     否则它是个永远 reject 的假函数 —— 表现为「工具能调，但每次都失败」。
//   · 条目正文走 action=parse 拿 HTML 再转纯文本（两个站都支持）；
//     不能用 prop=extracts —— 那是 TextExtracts 扩展，cookiewiki.org 没装，
//     会返回 "Unrecognized value for parameter prop" 而不是正文。
//   · disabletoc / disableeditsection / disablelimitreport 三个参数必须带上：
//     不带的话正文里会混进目录树和满屏的「edit」，白吃 token。
//   · 工具返回值直接进模型上下文，所以输出要「够答一条消息」而不是「整篇条目」。
//     默认截 1200 字，按配置可调。

const DEFAULTS = {
  maxChars: 1200,
  siteUrl: 'https://cookie.wiki',
  fallbackUrl: 'https://cookiewiki.org'
};

const TIMEOUT_MS = 6000;        // 单次请求上限（主站半死不活时别把回复拖到十几秒）
const DEAD_MS = 5 * 60 * 1000;  // 站点挂了之后多久再试
const CACHE_MS = 10 * 60 * 1000;
const UA = 'QQAgent-CookieWikiSkill/1.0 (+https://cookie.wiki)';

let cfg = () => ({});
let log = () => {};
let warn = () => {};

const deadUntil = new Map();  // base -> 时间戳
const cache = new Map();      // 查询键 -> { at, content }

export function setup(api) {
  cfg = typeof api.config === 'function' ? api.config : () => ({});
  log = api.log || (() => {});
  warn = api.warn || (() => {});

  const c = { ...DEFAULTS, ...(cfg() || {}) };
  log(`曲奇☆百科已加载｜主站 ${c.siteUrl}｜备用 ${c.fallbackUrl}`);

  api.registerTool({
    id: 'wiki_lookup',
    name: '查曲奇☆百科',
    description: '在 Cookie☆ Wiki（曲奇☆百科）里查一个词条，返回条目正文和链接。'
      + '什么时候用：群友聊到曲奇☆（Cookie☆ / クッキー☆ / 饼）相关的人物、语音剧、二创、梗，'
      + '或者拿东方 Project 的角色/设定来问，而你对具体细节没把握时先查一下再答。'
      + '关键词优先用罗马音代称或条目本名：NYN、RU、MGR、HZN、BNKRG、Cookie☆OG、曲奇。'
      + '站内这些代称就是条目名，会自动跳到本名条目——注意 RU 是 Reu、MGR 是 Meguru，别想当然。'
      + '返回的是百科原文，不是结论：你要根据它自己组织一句有态度的回答，不要原样贴给群友，回答里也继续用代称而不是汉字译名。'
      + '东方本体的基础设定（角色是谁、作品是哪作）不查也能答，别为了小事调工具。',
    category: 'knowledge',
    icon: '🍪',
    defaultEnabled: true,
    parameters: {
      type: 'object',
      properties: {
        query: {
          type: 'string',
          description: '要查的词。名词越短越准：角色名、语音剧名、术语原名，别把整句话塞进来。'
        },
        page: {
          type: 'string',
          description: '已经知道确切条目名时直接填，跳过搜索（可选）。比如 "Cookie☆OG"、"Nyon"。'
        }
      },
      required: ['query']
    },
    async execute(ctx, args) {
      const query = String(args?.query ?? '').trim();
      const page = String(args?.page ?? '').trim();
      if (!query && !page) return fail('没有拿到要查的词：把关键词放进 query。');

      const conf = { ...DEFAULTS, ...(cfg() || {}) };
      try {
        const content = await lookup(query || page, page, conf);
        return { content };
      } catch (error) {
        warn('查询失败', error);
        return {
          content: `查询失败：${error?.message ?? error}。这次没拿到资料，别硬编百科内容——`
            + '可以凭自己的常识说个大概，但要跟对方讲清楚这是凭印象、没查到出处。',
          isError: true
        };
      }
    }
  });
}

// ── 主流程 ────────────────────────────────────────────────────────────────

async function lookup(query, pageHint, conf) {
  const maxChars = clamp(Number(conf.maxChars) || DEFAULTS.maxChars, 300, 4000);
  const key = `${query}\u0000${pageHint}\u0000${maxChars}`;
  const hit = cache.get(key);
  if (hit && Date.now() - hit.at < CACHE_MS) return hit.content;

  const hosts = unique([conf.siteUrl, conf.fallbackUrl, DEFAULTS.fallbackUrl]
    .map(normalizeBase)
    .filter(Boolean));

  const errors = [];
  let responded = false;

  for (const base of hosts) {
    if (isDead(base)) {
      errors.push(`${hostOf(base)} 刚才连不上，已跳过`);
      continue;
    }
    try {
      const out = await searchAndRead(base, query, pageHint, maxChars);
      responded = true;
      if (out) {
        cache.set(key, { at: Date.now(), content: out });
        return out;
      }
      // 站点活着、只是没有这个词条
      errors.push(`${hostOf(base)} 没有这个词条`);
    } catch (error) {
      markDead(base);
      errors.push(`${hostOf(base)}：${error?.message ?? error}`);
    }
  }

  if (!responded) {
    // 一个站都没通 —— 这是真失败，让调用方按 isError 处理
    throw new Error(errors.join('；') || '两个百科站点都连不上');
  }

  const msg = `没查到「${query}」：${errors.join('；')}。\n`
    + '可以换个更短的关键词再试（角色名 / 语音剧名 / 术语原名，日文或英文原文通常更好中），'
    + '或者这条就凭你自己的常识回答，但要说清楚没查到资料。';
  cache.set(key, { at: Date.now(), content: msg });
  return msg;
}

/** 在某个站点上：搜词 → 定条目 → 读正文。查不到返回空串。 */
async function searchAndRead(base, query, pageHint, maxChars) {
  let title = pageHint;
  let usedTerm = pageHint || '';
  let hits = [];

  if (!title) {
    // 中文站挂着的时候，中文词在英文站上一条也搜不到（「曲奇」→ 0 命中，还要白等 1.7 秒）。
    // 所以带中文的词先拿别名搜（曲奇/cookie/クッキー → Cookie☆），没有别名再原样搜。
    const alias = aliasFor(query);
    const hasCJK = /[\u3400-\u9fff\uf900-\ufaff]/.test(query);
    const terms = unique(hasCJK && alias ? [alias, query] : [query, alias]);
    for (const term of terms) {
      const res = await callApi(base, {
        action: 'query',
        list: 'search',
        srsearch: term,
        srlimit: '6',
        format: 'json',
        formatversion: '2',
        utf8: '1'
      });
      hits = Array.isArray(res?.query?.search) ? res.query.search : [];
      if (hits.length) {
        title = pickTitle(hits, term);
        usedTerm = term;
        break;
      }
    }
    if (!title) return '';
  }

  const page = await callApi(base, {
    action: 'parse',
    page: title,
    prop: 'text|displaytitle',
    format: 'json',
    formatversion: '2',
    redirects: '1',
    disabletoc: '1',
    disableeditsection: '1',
    disablelimitreport: '1'
  });

  const html = page?.parse?.text;
  if (!html) return '';

  const realTitle = cleanTitle(page?.parse?.title) || title;
  const body = clip(htmlToText(html), maxChars);
  if (!body) return '';

  const lines = [
    `【Cookie☆ Wiki｜${hostOf(base)}】`,
    `条目：${realTitle}`,
    `链接：${pageUrl(base, realTitle)}`
  ];
  // 用代称查（NYN/RU/MGR）时，条目会跳到本名。把这条对应关系明写出来，
  // 模型才知道「NYN=Nyon、RU=Reu、MGR=Meguru」，回答时不会把代称译回汉字。
  const asked = cleanTitle(usedTerm).toLowerCase();
  if (asked && asked !== realTitle.toLowerCase()) {
    lines.push(`对应：你查的「${cleanTitle(usedTerm)}」→ 本名条目「${realTitle}」`);
  }
  lines.push('', body);

  const others = hits
    .map((h) => cleanTitle(h?.title))
    .filter((t) => t && t !== realTitle)
    .slice(0, 4);
  if (others.length) {
    lines.push('', `相关条目（需要可以再查）：${others.join('、')}`);
  }
  return lines.join('\n');
}

/** 命中里优先取与查询完全同名的条目，否则取第一条。 */
function pickTitle(hits, query) {
  const q = String(query || '').trim().toLowerCase().replace(/\s+/g, ' ');
  const exact = hits.find((h) => cleanTitle(h?.title).toLowerCase().replace(/\s+/g, ' ') === q);
  if (exact) return cleanTitle(exact.title);
  return cleanTitle(hits[0]?.title) || String(query);
}

/**
 * 中文/俗称 → 百科里的条目名。
 * 只在「第一轮什么都没搜到」时用，所以映射写窄一点，别把正常搜索带偏。
 */
const ALIASES = [
  [/(曲奇|餅|饼|cookie|クッキー)/i, 'Cookie☆']
];

function aliasFor(query) {
  const q = String(query ?? '');
  for (const [re, term] of ALIASES) {
    if (re.test(q)) return term;
  }
  return '';
}

// ── HTTP ──────────────────────────────────────────────────────────────────

async function callApi(base, params) {
  const url = `${base}/api.php?${new URLSearchParams(params).toString()}`;
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), TIMEOUT_MS);
  try {
    const res = await apiFetch(url, controller.signal);
    const text = await res.text();
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    try {
      return JSON.parse(text);
    } catch {
      throw new Error('站点返回的不是 JSON（可能被拦截或跳转到了错误页）');
    }
  } catch (error) {
    if (error?.name === 'AbortError') throw new Error(`请求超时（${TIMEOUT_MS}ms）`);
    throw error;
  } finally {
    clearTimeout(timer);
  }
}

/** api.fetch 在未声明 web_fetch 权限时是个永远 reject 的假函数。 */
function apiFetch(url, signal) {
  const impl = typeof globalThis.fetch === 'function' ? globalThis.fetch : null;
  if (!impl) throw new Error('当前运行环境没有 fetch');
  return impl(url, {
    signal,
    headers: { 'user-agent': UA, accept: 'application/json' },
    redirect: 'follow'
  });
}

// ── HTML → 纯文本 ─────────────────────────────────────────────────────────

function htmlToText(html) {
  let s = String(html || '');
  s = s.replace(/<\s*(script|style|noscript)\b[^>]*>[\s\S]*?<\s*\/\s*\1\s*>/gi, ' ');
  s = s.replace(/<!--[\s\S]*?-->/g, ' ');
  // 信息框（Infobox）模板化太重，留着只是噪音
  s = s.replace(/<aside\b[\s\S]*?<\/aside>/gi, ' ');
  // 顶部告示（「本条需要修订」「这是篇 Stub」）都包在 <center> 里：不剥掉会混进正文，
  // 白占 token 还容易让模型以为条目本身在说这些。
  s = s.replace(/<center\b[\s\S]*?<\/center>/gi, ' ');
  s = s.replace(/<\s*(br|hr)\s*\/?\s*>/gi, '\n');
  s = s.replace(/<\s*\/\s*(p|div|li|tr|h[1-6]|blockquote|table|section|dd|dt|ul|ol)\s*>/gi, '\n');
  s = s.replace(/<\s*(td|th)\b[^>]*>/gi, '｜');
  s = s.replace(/<[^>]+>/g, '');
  s = decodeEntities(s);
  s = s.replace(/[ \t\u00a0]+/g, ' ');
  s = s.split('\n')
    .map((line) => line.trim())
    .filter((line) => line && !/^(edit|编辑|［编辑］|\[edit\])$/i.test(line))
    .join('\n');
  return s.replace(/\n{3,}/g, '\n\n').trim();
}

const ENTITIES = { amp: '&', lt: '<', gt: '>', quot: '"', apos: "'", nbsp: ' ' };

function decodeEntities(s) {
  return String(s).replace(/&(#x[0-9a-f]+|#\d+|[a-z]+);/gi, (whole, g) => {
    if (g[0] === '#') {
      const code = g[1] === 'x' || g[1] === 'X'
        ? parseInt(g.slice(2), 16)
        : parseInt(g.slice(1), 10);
      if (!Number.isFinite(code) || code <= 0 || code > 0x10ffff) return whole;
      try { return String.fromCodePoint(code); } catch { return whole; }
    }
    const named = ENTITIES[g.toLowerCase()];
    return named === undefined ? whole : named;
  });
}

/** 按长度截断，尽量切在换行/句号上，避免半句话。 */
function clip(text, max) {
  const s = String(text || '');
  if (s.length <= max) return s;
  const head = s.slice(0, max);
  const cut = Math.max(head.lastIndexOf('\n'), head.lastIndexOf('。'), head.lastIndexOf('. '));
  const body = (cut > max * 0.5 ? head.slice(0, cut) : head).trim();
  return `${body}\n……（后面还有，已截断）`;
}

// ── 小工具 ────────────────────────────────────────────────────────────────

function normalizeBase(value) {
  const s = String(value ?? '').trim().replace(/\/+$/, '');
  if (!s) return '';
  if (!/^https?:\/\//i.test(s)) return `https://${s}`;
  return s;
}

function hostOf(base) {
  try { return new URL(base).host; } catch { return String(base); }
}

function pageUrl(base, title) {
  return `${base}/${encodeURIComponent(String(title).replace(/\s+/g, '_'))}`;
}

function cleanTitle(value) {
  return String(value ?? '').replace(/\s+/g, ' ').trim();
}

function isDead(base) {
  const until = deadUntil.get(base);
  return Boolean(until) && Date.now() < until;
}

function markDead(base) {
  deadUntil.set(base, Date.now() + DEAD_MS);
}

function unique(list) {
  return [...new Set(list.filter(Boolean))];
}

function clamp(n, min, max) {
  return Math.min(max, Math.max(min, n));
}

function fail(message) {
  return { content: `错误：${message}`, isError: true };
}
