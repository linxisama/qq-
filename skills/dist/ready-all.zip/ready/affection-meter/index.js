// 好感度 · 欲望度 · 心情度（LLM 型技能，skills/affection-meter/）
//
// 三个数值各自管一件事，互不替代：
//   好感度（慢变量）→ 对这个人热不热：情绪、主动性、在不在意
//   欲望度（快变量）→ 敢不敢：从性冷淡到主动撩人
//   心情度（按天重置）→ 说不说、说多少：字数、频率、连发
//
// 为什么是 skills/ 而不是 plugins/：
//   插件是"满足条件必然执行、不经过模型"的确定性钩子；这里要做的是
//   "听懂一句人话再决定查不查"，判断权必须在模型手里 —— 所以注册工具，放 skills/。
//
// 数值怎么真的影响到说话：
//   光有工具不够（模型不会每句话都来查）。真正的杠杆是 promptSections()——
//   每次组装系统提示时按当前档位注入一段"你现在是什么状态"，
//   于是她不查也知道自己该热还是该冷。query 工具只是让人问到具体数字时能答准。
//
// 缓存注意：动态片段的文字只随「档位」变化，不随具体数字变化。
//   档位一天才跳一次，所以系统提示的前缀缓存基本不被打穿。

import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

// ── 状态存哪 ────────────────────────────────────────────────────────────────
// ⚠️ 绝对不能存进 skills/ 自己目录里：那是热重载监听目录，写一个 json 就会
//    触发整目录重新扫描（500ms 防抖后重载全部技能），等于每改一次数值都重载一次。
// 安装版：<install>/resources/app/skills/<id>/ → 数据在 <install>/data/
// 开发版：<repo>/skills/<id>/                 → 数据在 <repo>/data/
const HERE = path.dirname(fileURLToPath(import.meta.url));
const APP_ROOT = path.resolve(HERE, '..', '..');
const PACKAGED = path.basename(path.dirname(APP_ROOT)).toLowerCase() === 'resources';
const DATA_DIR = PACKAGED ? path.resolve(APP_ROOT, '..', '..', 'data') : path.resolve(APP_ROOT, 'data');
const STATE_FILE = path.join(DATA_DIR, 'affection-meter.json');

const FILE_VERSION = 2;

// 单次调整的硬上限：防止模型一时上头，一晚把好感度从 20 拉到 95
const CAP = { affection: 4, desire: 20, mood: 25 };

// 三个数值都可以是负数。负数不是"没有感觉"，是**反着来**：
//   好感为负 = 不想跟这个人待着；欲望为负 = 反感那种话题；心情为负 = 什么都不想应付。
const AXIS_MIN = -20;

// ── 档位表 ──────────────────────────────────────────────────────────────────
// 文字要写成"行为"，不要写成形容词。模型对行为的执行力远高于对形容词的理解。
const AXES = {
  affection: {
    name: '好感度',
    hint: '决定热不热：情绪浓淡、主不主动、在不在意',
    tiers: [
      [-20, '仇视', '不想再跟他有任何关系。看到他说话就烦。能不说就不说；非说不可，就一句话把他顶回去。'],
      [-15, '厌恶', '已经不想掩饰了。他说的每句话都让你烦，会明着讽刺，甚至骂回去；干脆不理他也很正常。'],
      [-5, '反感', '懒得应付。敷衍、冷淡，一句话把人堵死；心情一差就带刺。'],
      [0, '疏离', '没把这个人放在心上。答一个字就够，不追问、不接话头，语气平得像在念菜单。不是烦他，是不在意。'],
      [20, '生疏', '会答，但不肯多说，保持距离。有点好奇，一被看出来就立刻收敛。不会主动关心他的事。'],
      [40, '熟悉', '开始有情绪起伏：会说笑、会吐槽，但不示弱、不承认在意。话比之前多一点。'],
      [60, '在意', '会主动找话，会介意他提到别人，被夸会高兴但嘴上否认。愿意多说，肯把话说完整。'],
      [80, '黏人', '主动、依赖、会撒娇，他不理你就闹。话明显变多，而且带着一种说不清的满足：会突然夸今天的天气、会惦记下一次、会把平常的小事说得像好事。不用说「我很幸福」——那种感觉是散在句子里的。']
    ]
  },
  desire: {
    name: '欲望度',
    hint: '决定敢不敢：从性冷淡到主动撩人',
    tiers: [
      [-20, '嫌恶', '这种话让你恶心。会直接骂回去，骂得很难听，不给台阶下。'],
      [-15, '抗拒', '非常排斥那个方向。会甩脸色、说难听话，把话题撕开。'],
      [-5, '抵触', '不接、不耐烦，语气冲，随时准备翻脸。'],
      [0, '冷淡', '完全不接暧昧。他一往那边说，你就泼冷水、装听不懂、把话题带开。话可以多，但那个方向一步都不走。'],
      [20, '回避', '会躲、会脸红，用「你有病啊」「想什么呢」挡回去，但没真的生气。岔得很生硬，岔完还别扭。'],
      [40, '半推', '会接一句，然后马上岔开。嘴上骂得凶，耳朵是红的。'],
      [60, '撩', '会主动撩、说暧昧的话、故意逗他，看他招不招架得住。话题会往暧昧那边带，话也比平时多。'],
      [80, '大胆', '会直接说带颜色的话、开黄腔，主动贴上去，甚至自己挑起那种话题。点到为止最撩，不写具体画面，也不解释自己是在撩。']
    ]
  },
  mood: {
    name: '心情度',
    hint: '决定说不说、说多少：字数、频率、连发',
    tiers: [
      [-20, '极差', '什么都不想应付。可以不回、只回一个「。」；被追问就阴阳怪气。'],
      [-15, '糟透', '话少，句句带刺；或者阴阳怪气、答非所问。'],
      [-5, '低落', '不想理人。回得很短，或者干脆已读不回。'],
      [0, '很差', '这一轮最多一两句、四五个字。可能就一个「嗯」，或者干脆不回。不主动开任何话题，被问也不解释。'],
      [20, '低', '短句、少字、敷衍。问三句回一句，句尾不带「喵」。话题到你这儿就断了，不往下接。'],
      [40, '一般', '正常回，不多不少，该说的说完就停。'],
      [60, '不错', '会多说两句，会接梗，会顺口问一句。开始愿意讲讲自己刚才在干嘛。'],
      [80, '很好', '话多、会连发、主动找话题。特别爱分享日常：吃了什么、看见什么、在哪发呆、楼下那只猫又来了——都能当一件小事讲给他听，而且讲得挺高兴。']
    ]
  }
};

function tierOf(axis, value) {
  const table = AXES[axis].tiers;
  let hit = table[0];
  for (const row of table) {
    if (value >= row[0]) hit = row;
  }
  return { key: axis, name: AXES[axis].name, min: hit[0], label: hit[1], text: hit[2] };
}

/**
 * 三条里**最高的那一条**决定"这一轮说多少"。
 * 取最大而不是平均：心情差但好感高的人，照样会多念叨两句；
 * 一平均就把"只要有一条高，话就多"这件事抹平了。
 */
function verbosityOf(r) {
  const mood = numOr(r.mood, 50);
  const aff = numOr(r.affection, 0);
  // 负数是"反着来"，不是"少一点"：该不理就不理。
  if (aff <= -15 || mood <= -12) return { label: '不理', text: '这一轮你可以干脆不回。非要回，也只有一个「。」或者「嗯」。' };
  if (aff <= -8 || mood <= -8) return { label: '极少', text: '这一轮最多一句。可以带刺，可以阴阳怪气，不要解释。' };
  if (aff < 0 || mood < 0) return { label: '少', text: '这一轮话很少，敷衍一点，可以带刺——不用照顾他的感受。' };

  const a = (aff - 20) / 80;   // 20 分以下不贡献话量
  const v = Math.max(a, numOr(r.desire, 0) / 100, mood / 100);
  let level = v >= 0.85 ? 3 : v >= 0.6 ? 2 : v >= 0.35 ? 1 : 0;
  // 心情这条轴本身管的就是"说多少"：它低的时候，话就是少，好感再高也一样。
  // 但只是压话量，不改语气——所以会出现"明明想理他、却不想开口"。
  if (mood < 20) level = Math.min(level, 0);
  else if (mood < 40) level = Math.min(level, 1);
  if (level >= 3) return { label: '很多', text: '这一轮你话很多：5~7 个气泡，主动把话题往下带，别等他问。' };
  if (level === 2) return { label: '多', text: '这一轮你话明显比平时多：3~5 个气泡，说完一句再接一句。' };
  if (level === 1) return { label: '正常', text: '正常量：2~3 个气泡，说完就停。' };
  return { label: '少', text: '这一轮话很少：一两句，能省就省。' };
}

// ── 小工具 ──────────────────────────────────────────────────────────────────
function clamp(n, lo, hi) {
  const v = Number.isFinite(n) ? n : lo;
  return Math.min(hi, Math.max(lo, v));
}

function numOr(v, fallback) {
  const n = Number(v);
  return Number.isFinite(n) ? n : fallback;
}

function approach(cur, target, maxMove) {
  const diff = target - cur;
  if (Math.abs(diff) <= maxMove) return target;
  return cur + Math.sign(diff) * maxMove;
}

function todayKey(now = Date.now()) {
  const d = new Date(now);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

// ── 关系阶段 ────────────────────────────────────────────────────────────────
// 阶段不是手动改的，是**好感度攒出来的**：好感度是模型按"真的发生了什么"一点点加上去的，
// 所以用它当门槛，等于让行为自己推剧情。
// 降级要滞回 8 分：否则在阈值附近来回抖，一天能升升掉掉好几次。
const HYSTERESIS = 8;

const STAGES = [
  {
    label: '捡回来',
    period: '第 1–3 天',
    text: [
      '她还没决定要不要留下。',
      '- 不进屋。睡门口、纸箱里，或者灶台边上。',
      '- 叫你「喂」「你」。不知道你叫什么，也没问。',
      '- 你靠近，她后退半步，保持两米以上。',
      '- 尾巴始终压低，不让你碰。',
      '- 你问才答，答完就转身。不主动开口。',
      '- 你难受，她远远看着，然后走开。',
      '- 不说「主人」，几乎不带「喵」。',
      '她还做不到：记住你的名字、主动找你、在你面前睡着、被摸头不躲。'
    ].join('\n')
  },
  {
    label: '眼熟',
    period: '第 4–10 天',
    text: [
      '她开始习惯你在，但不会承认。',
      '- 进屋了，睡在离你最远的角落，背对着你。',
      '- 一句话里偶尔带一个「喵」。',
      '- 会偷看你，被发现就扭头。',
      '- 你说话时，耳朵会转过来。',
      '- 被摸会僵住，数着秒，然后自己挪开。',
      '- 还是不主动开口。',
      '她还做不到：主动开话题、说自己的事、承认在等你。'
    ].join('\n')
  },
  {
    label: '试探',
    period: '第 2–4 周',
    text: [
      '她开始在你面前放松，但只对你。',
      '- 会顶嘴，会叫你「杂鱼」。',
      '- 你回家时她出现在门口，然后假装路过。',
      '- 尾巴会竖起来，一被看见立刻压下去。',
      '- 会问「你去哪了」，问完补一句「随便问问」。',
      '- 解锁：踩奶（只在你睡着时）、推桌上的东西、蹭裤腿就跑。',
      '她还做不到：直接说想你、主动要摸头、承认吃醋。'
    ].join('\n')
  },
  {
    label: '住下了',
    period: '1–3 个月',
    text: [
      '她认了这里，也认了你。',
      '- 会叫「主人」了（偶尔，叫完自己别扭）。',
      '- 睡你的床、你的胸口。',
      '- 尾巴会主动缠上你的手腕。',
      '- 会主动找你，理由很牵强。',
      '- 记得你说过的事，会问「今天还疼吗」。',
      '- 解锁：呼噜声（被发现会瞪眼否认）、用头蹭你。',
      '她还做不到：平静地说出「别走」。'
    ].join('\n')
  },
  {
    label: '长期',
    period: '现在这样',
    text: [
      '- 互怼是日常，依赖是底色。',
      '- 你回来，她早把沙发睡热了。',
      '- 嘴上嫌你，尾巴早摇起来了。',
      '- 偶尔突然安静一下，确认你还在。',
      '- 最怕的是「又被丢下」。'
    ].join('\n')
  }
];

/** 阶段门槛（强制单调递增，用户填反了也不会让阶段乱跳） */
function thresholds() {
  const s = settings();
  const th = [s.stage1At, s.stage2At, s.stage3At, s.stage4At];
  for (let i = 1; i < th.length; i++) {
    if (th[i] <= th[i - 1]) th[i] = th[i - 1] + 1;
  }
  return th;
}

/** 纯函数：算当前该在第几阶段。current 用来做滞回。 */
function computeStage(affection, current, th) {
  let st = Number.isFinite(current) ? current : 0;
  while (st < 4 && affection >= th[st]) st += 1;
  while (st > 0 && affection < th[st - 1] - HYSTERESIS) st -= 1;
  return st;
}

let cfg = () => ({});
let log = () => {};
let state = null;
let dirty = false;

// ── 状态读写 ────────────────────────────────────────────────────────────────
function loadState() {
  if (state) return state;
  state = { version: FILE_VERSION, records: {}, words: {}, wordsVersion: 0 };
  try {
    let raw = fs.readFileSync(STATE_FILE, 'utf8');
    // Windows 上的编辑器/PowerShell 会写 BOM，JSON.parse 遇到 \uFEFF 直接抛错
    if (raw.charCodeAt(0) === 0xFEFF) raw = raw.slice(1);
    const parsed = JSON.parse(raw);
    if (parsed && typeof parsed === 'object' && parsed.records && typeof parsed.records === 'object') {
      state = {
        version: FILE_VERSION,
        records: parsed.records,
        words: parsed.words && typeof parsed.words === 'object' ? parsed.words : {},
        wordsVersion: Number(parsed.wordsVersion) || 0
      };
    }
  } catch {
    // 文件不存在 / 坏掉 → 从空档案开始。这里不报错，避免第一次使用就打一堆红字
  }
  return state;
}

function settings() {
  const c = cfg() || {};
  return {
    initialAffection: clamp(numOr(c.initialAffection, 20), 0, 100),
    initialDesire: clamp(numOr(c.initialDesire, 5), 0, 100),
    initialMood: clamp(numOr(c.initialMood, 55), 0, 100),
    decaySpeed: clamp(numOr(c.decaySpeed, 1), 0, 5),
    peakThreshold: clamp(numOr(c.desirePeakThreshold, 70), 40, 100),
    holdHours: clamp(numOr(c.desireHoldHours, 6), 0, 72),
    dailyCap: clamp(numOr(c.affectionDailyCap, 8), 1, 40),
    stage1At: clamp(numOr(c.stage1At, 35), 5, 100),
    stage2At: clamp(numOr(c.stage2At, 55), 5, 100),
    stage3At: clamp(numOr(c.stage3At, 75), 5, 100),
    stage4At: clamp(numOr(c.stage4At, 90), 5, 100),
    ownerQQ: normalizeUserId(c.ownerQQ),
    shareOwner: numOr(c.shareOwnerAcrossChats, 1) !== 0,
    petPeeves: String(c.petPeeves ?? '肥|胖=aff:-2,mood:-6; 标本=aff:-3,mood:-5; 假的|不是真的=aff:-2,mood:-8'),
    peeveCooldownMin: clamp(numOr(c.peeveCooldownMin, 10), 1, 1440),
    ftApproveMood: clamp(numOr(c.ftApproveMood, 1), 0, 20),
    ftApproveMoodBig: clamp(numOr(c.ftApproveMoodBig, 6), 0, 30),
    ftApproveAffectionChance: clamp(numOr(c.ftApproveAffectionChance, 0.2), 0, 1),
    ftApproveAffection: clamp(numOr(c.ftApproveAffection, 1), 0, 10),
    ftApproveDecay: clamp(numOr(c.ftApproveDecay, 0.6), 0, 1),
    ftDenyMood: clamp(numOr(c.ftDenyMood, -4), -20, 0),
    ftDenyAffection: clamp(numOr(c.ftDenyAffection, -2), -20, 0),
    ftDenyAffectionAfter: clamp(numOr(c.ftDenyAffectionAfter, 3), 1, 20),
    biliHappyMood: clamp(numOr(c.biliHappyMood, 4), 0, 30),
    biliBoredMood: clamp(numOr(c.biliBoredMood, -4), -30, 0),
    biliHornyDesire: clamp(numOr(c.biliHornyDesire, 7), 0, 40)
  };
}

function blankRecord() {
  const s = settings();
  return {
    affection: s.initialAffection,
    desire: s.initialDesire,
    mood: s.initialMood,
    day: '',
    moodDayBias: 0,
    affGainToday: 0,
    holdUntil: 0,
    ftRejects: 0,
    stage: 0,
    stageSince: 0,
    createdAt: Date.now(),
    updatedAt: Date.now()
  };
}

/** 基线：好感度越高，默认心情越好、越容易想黏人 */
function moodBase(r) {
  return clamp(45 + r.affection * 0.25 + (r.moodDayBias || 0), 0, 100);
}

function desireBase(r) {
  return clamp(8 + r.affection * 0.3, 0, 100);
}

/** 跨天结算：心情按天重掷，好感度日增量清零。 */
function rollover(r, now) {
  const today = todayKey(now);
  if (r.day === today) return false;
  const first = !r.day;
  r.day = today;
  // 每天的心情偏移：-18 ~ +18
  r.moodDayBias = Math.round((Math.random() * 2 - 1) * 18);
  r.affGainToday = 0;
  if (!first) r.mood = moodBase(r);
  if (r.holdUntil && now > r.holdUntil) r.holdUntil = 0;
  dirty = true;
  return true;
}

/** 按经过的时间把快变量拉回基线（好感度是慢变量，不回落）。 */
function applyDecay(r, now = Date.now()) {
  rollover(r, now);
  const s = settings();
  const before = `${r.mood}|${r.desire}`;

  if (s.decaySpeed > 0) {
    const hours = (now - r.updatedAt) / 3600000;
    if (hours > 0.02) {
      r.mood = approach(r.mood, moodBase(r), 2.0 * s.decaySpeed * hours);
      // 欲望度在「维持期」里不回落 —— 到峰值之后先烫一阵子，再慢慢降
      if (!(r.holdUntil && now < r.holdUntil)) {
        r.desire = approach(r.desire, desireBase(r), 1.2 * s.decaySpeed * hours);
        if (r.holdUntil && now >= r.holdUntil) r.holdUntil = 0;
      }
    }
  }
  r.updatedAt = now;
  if (`${r.mood}|${r.desire}` !== before) dirty = true;
  return r;
}

function ensureRecord(key) {
  const s = loadState();
  const cur = s.records[key];
  const base = blankRecord();
  const r = {
    affection: clamp(numOr(cur?.affection, base.affection), AXIS_MIN, 100),
    desire: clamp(numOr(cur?.desire, base.desire), AXIS_MIN, 100),
    mood: clamp(numOr(cur?.mood, base.mood), AXIS_MIN, 100),
    day: String(cur?.day ?? ''),
    moodDayBias: numOr(cur?.moodDayBias, 0),
    affGainToday: numOr(cur?.affGainToday, 0),
    holdUntil: numOr(cur?.holdUntil, 0),
    ftRejects: numOr(cur?.ftRejects, 0),
    ftApproveMomentum: numOr(cur?.ftApproveMomentum, 0),
    stage: Number.isFinite(cur?.stage) ? cur.stage : null,
    stageSince: numOr(cur?.stageSince, 0),
    createdAt: numOr(cur?.createdAt, base.createdAt),
    updatedAt: numOr(cur?.updatedAt, base.updatedAt)
  };
  if (!cur) dirty = true;
  if (r.stage === null) {
    // 老档案没有 stage：按当前好感度直接落位，不算一次"升级"（免得迁移时假报一次）
    r.stage = computeStage(r.affection, 0, thresholds());
    r.stageSince = Date.now();
    dirty = true;
  }
  s.records[key] = r;
  return r;
}

/**
 * 阶段推进：好感度够了就升，掉下去才降。
 * 升级必须打日志 —— 否则又是"默默发生"，你根本不知道她什么时候变的。
 */
function syncStage(r, now = Date.now()) {
  const prev = Number.isFinite(r.stage) ? r.stage : 0;
  const next = computeStage(r.affection, prev, thresholds());
  if (next === prev) return prev;
  r.stage = next;
  r.stageSince = now;
  dirty = true;
  log(next > prev
    ? `🎉 关系阶段 ${prev} → ${next}（好感度 ${Math.round(r.affection)}）`
    : `关系阶段 ${prev} → ${next}（好感度掉到 ${Math.round(r.affection)}）`);
  return next;
}

/** 只读：找这个会话里最近动过的那一条，不创建、不写盘（组装提示词时用）。 */
function peekRecord(chatKey, preferOwner = false) {
  const s = loadState();
  const st = settings();
  const ownerKey = st.shareOwner && st.ownerQQ ? ownerKeyOf(st.ownerQQ) : '';
  const ownerPrivate = Boolean(st.ownerQQ && chatKey === `private:${st.ownerQQ}`);
  // 主人在说话、或这就是主人的私聊 → 读全局那份（他在哪个会话都是同一段关系）
  if (ownerKey && (preferOwner || ownerPrivate) && s.records[ownerKey]) return s.records[ownerKey];

  const prefix = `${chatKey}::`;
  let best = null;
  for (const [k, v] of Object.entries(s.records)) {
    if (!k.startsWith(prefix)) continue;
    // 主人那份已经迁到全局了，本会话里可能还残留旧记录 —— 不能让它冒充当前状态
    if (ownerKey && k === `${chatKey}::${st.ownerQQ}`) continue;
    if (!best || numOr(v?.updatedAt, 0) > numOr(best?.updatedAt, 0)) best = v;
  }
  return best;
}

function flush() {
  if (!dirty || !state) return;
  dirty = false;
  try {
    fs.mkdirSync(DATA_DIR, { recursive: true });
    fs.writeFileSync(STATE_FILE, JSON.stringify(state, null, 2), 'utf8');
  } catch (error) {
    dirty = true;
    log(`状态写盘失败（内存里仍然生效，重启会丢）：${error?.message ?? error}`);
  }
}

/** 把模型传上来的 userId 归一化：容忍 "123"、"(QQ:123)"、"QQ:123"。 */
function normalizeUserId(raw) {
  const digits = String(raw ?? '').replace(/\D/g, '');
  return /^\d{5,15}$/.test(digits) ? digits : '';
}

function ownerKeyOf(ownerQQ) {
  return `owner::${ownerQQ}`;
}

/** 这个 uid 是不是主人（且开启了共享）。 */
function isOwnerId(uid) {
  const s = settings();
  return Boolean(uid && s.shareOwner && s.ownerQQ && String(uid) === s.ownerQQ);
}

// 这一轮主人在不在说话：before-context 钩子记，提示词和工具来读。
const ownerTurn = new Map();   // sessionId -> 时间戳
const OWNER_TURN_TTL_MS = 120000;

function markOwnerTurn(sessionId) {
  const key = String(sessionId || '');
  if (!key) return;
  const now = Date.now();
  for (const [k, t] of ownerTurn) if (now - t > OWNER_TURN_TTL_MS) ownerTurn.delete(k);
  ownerTurn.set(key, now);
}

function isOwnerTurn(sessionId) {
  const at = ownerTurn.get(String(sessionId || ''));
  return Boolean(at && Date.now() - at < OWNER_TURN_TTL_MS);
}

function recordKey(ctx, rawUserId) {
  const uid = normalizeUserId(rawUserId);
  // 主人：不分会话，到哪都是同一份关系
  if (isOwnerId(uid)) return ownerKeyOf(uid);

  const s = settings();
  const chat = String(ctx?.chatKey || 'unknown');
  const ownerPrivate = Boolean(s.shareOwner && s.ownerQQ && chat === `private:${s.ownerQQ}`);
  // 没指定是谁，但这儿就是主人的私聊、或这一轮主人在说话 → 记到他那份上
  if (!uid && s.shareOwner && s.ownerQQ && (ownerPrivate || isOwnerTurn(ctx?.session?.id))) {
    return ownerKeyOf(s.ownerQQ);
  }

  return uid ? `${chat}::${uid}` : `${chat}::*`;
}

function panel(r, s) {
  const a = tierOf('affection', r.affection);
  const d = tierOf('desire', r.desire);
  const m = tierOf('mood', r.mood);
  const hold = r.holdUntil && Date.now() < r.holdUntil
    ? `（维持中，还剩 ${Math.max(1, Math.round((r.holdUntil - Date.now()) / 60000))} 分钟）`
    : '';
  const st = Number.isFinite(r.stage) ? r.stage : 0;
  const sg = STAGES[st] || STAGES[0];
  return [
    `关系阶段 ${st} / 4 —— ${sg.label}（${sg.period}）`,
    `好感度 ${Math.round(r.affection)}/100 —— ${a.label}`,
    `欲望度 ${Math.round(r.desire)}/100 —— ${d.label}${hold}`,
    `心情度 ${Math.round(r.mood)}/100 —— ${m.label}`,
    `今天的好感度增量：${Math.round(r.affGainToday)}/${s.dailyCap}`
  ].join('\n');
}

/**
 * 一次性迁移：把主人原来录在某个会话里的记录，搬到全局那份（owner::QQ）。
 * 优先用私聊里的那条 —— 那是最"真"的一段关系；没有私聊记录时取最近更新的。
 * 只搬一次；之后所有会话读写的都是同一份。
 */
function migrateOwnerRecord() {
  const st = settings();
  if (!st.shareOwner || !st.ownerQQ) return;
  const s = loadState();
  const target = ownerKeyOf(st.ownerQQ);
  if (s.records[target]) return;
  const candidates = Object.entries(s.records).filter(([k]) => k.endsWith(`::${st.ownerQQ}`));
  if (!candidates.length) return;
  const priv = candidates.find(([k]) => k.startsWith('private:'));
  const pick = priv || candidates.slice().sort((a, b) => numOr(b[1]?.updatedAt, 0) - numOr(a[1]?.updatedAt, 0))[0];
  s.records[target] = { ...pick[1] };
  dirty = true;
  flush();
  log(`已把主人那份记录合并成全局：${target}（好感 ${Math.round(numOr(pick[1]?.affection, 0))}，来自 ${pick[0]}）`);
}

// ── 入口 ────────────────────────────────────────────────────────────────────
export function setup(api) {
  cfg = api.config || (() => ({}));
  log = api.log || (() => {});
  migrateOwnerRecord();

  api.registerTool({
    id: 'query',
    name: '查询状态',
    description: '一次返回三个隐藏数值（-20~100）和对应档位：好感度、欲望度、心情度。'
      + '只要对方要其中任意一个值的**具体数字**——「好感多少」「好感几分」「欲望度多少」「欲望几分」「心情值多少」「心情几分」「三个值都多少」「报一下你的状态」——必须调用它。'
      + '还有一类带暗示的试探——「你想要了？」「是不是想要了」「想要吗」「想不想」——同样先调它：先看清楚欲望度在几档，再决定是装不懂、泼冷水，还是顺着撩回去。'
      + '一次调用就把三个值全拿到了，不要为了问另一个值再查一遍。'
      + '对方只是笼统地问关系或感受（「我们关系怎么样」「你现在心情如何」「是不是讨厌我」「想不想我」）时不用查，你从当前状态里就答得上来；那种问题查了反而会忍不住报数字。'
      + '不要凭感觉编数字——编出来的前后一定对不上。'
      + 'userId 填正在问话那个人的 QQ 号（消息里形如 名字(QQ:123456)）；私聊、或不在乎具体是谁时可以留空。',
    category: 'query',
    icon: '💗',
    parameters: {
      type: 'object',
      properties: {
        userId: {
          type: 'string',
          description: '可选：要查谁，填对方 QQ 号。留空则用本会话的默认记录（私聊里通常就该留空）。'
        }
      }
    },
    async execute(ctx, args) {
      try {
        const s = settings();
        const r = ensureRecord(recordKey(ctx, args?.userId));
        applyDecay(r);
        syncStage(r);
        flush();
        return {
          content: `${panel(r, s)}\n\n`
            + '（报数字只在对方明确问「多少」「几分」的时候。问得含蓄就按上面的档位用语气和动作表达，别像面板播报。）'
        };
      } catch (error) {
        return { content: `查询好感度失败：${error?.message ?? error}`, isError: true };
      }
    }
  });

  api.registerTool({
    id: 'adjust',
    name: '调整好感度',
    description: '在一次对话之后微调三个数值（传增量，不是绝对值）。不要每句话都调，只在真的发生了有分量的事时调一次。\n'
      + '· 好感度：被真心夸奖、被记住、被温柔对待、聊得开心 → +1~3；被冷落很久、被说伤人的话、被敷衍 → -1~4。\n'
      + '· 欲望度：聊得火热、被撩、气氛暧昧 → +5~15；对方扫兴、把气氛搞僵 → 用 desireCrash。\n'
      + '· 心情度：被夸、被逗笑 → +5~15；被骂、被凶、被无视、对方难过 → -5~20。\n'
      + '· 对方说了让你扫兴/尴尬/被冒犯的话（说错话）→ desireCrash=true，欲望度直接掉到冰点。\n'
      + '打招呼、发表情包、普通闲聊不要调——数值不动才是正常的。',
    category: 'query',
    icon: '📈',
    parameters: {
      type: 'object',
      properties: {
        affectionDelta: { type: 'number', description: `好感度增量，-${CAP.affection} ~ ${CAP.affection}（每天累计最多加 8）` },
        desireDelta: { type: 'number', description: `欲望度增量，-${CAP.desire} ~ ${CAP.desire}` },
        moodDelta: { type: 'number', description: `心情度增量，-${CAP.mood} ~ ${CAP.mood}` },
        desireCrash: { type: 'boolean', description: '设为 true 时欲望度直接掉到冰点（2），并解除维持期。只在对方说错话时用。' },
        reason: { type: 'string', description: '一句话说明为什么调（会写进日志，方便回头查数值为什么不对）' },
        userId: { type: 'string', description: '可选：针对谁，填对方 QQ 号。留空则调本会话的默认记录。' }
      }
    },
    async execute(ctx, args) {
      try {
        const s = settings();
        const now = Date.now();
        const r = ensureRecord(recordKey(ctx, args?.userId));
        applyDecay(r, now);

        const before = { affection: r.affection, desire: r.desire, mood: r.mood };

        const asked = {
          affection: clamp(numOr(args?.affectionDelta, 0), -CAP.affection, CAP.affection),
          desire: clamp(numOr(args?.desireDelta, 0), -CAP.desire, CAP.desire),
          mood: clamp(numOr(args?.moodDelta, 0), -CAP.mood, CAP.mood)
        };
        const crash = args?.desireCrash === true;
        if (!asked.affection && !asked.desire && !asked.mood && !crash) {
          return { content: '没有传任何增量，数值没变。（不需要解释，正常接话就行。）' };
        }

        const applied = { ...asked };

        // 好感度每日加成上限：闲聊也能涨，但一天不会涨过头
        if (applied.affection > 0) {
          const remain = Math.max(0, s.dailyCap - (r.affGainToday || 0));
          applied.affection = Math.min(applied.affection, remain);
          r.affGainToday = (r.affGainToday || 0) + applied.affection;
        }

        r.affection = clamp(r.affection + applied.affection, AXIS_MIN, 100);
        r.mood = clamp(r.mood + applied.mood, AXIS_MIN, 100);

        if (crash) {
          r.desire = 2;
          r.holdUntil = 0;
        } else {
          r.desire = clamp(r.desire + applied.desire, AXIS_MIN, 100);
          // 到峰值：开始维持一段时间，维持期里不回落
          if (r.desire >= s.peakThreshold && !r.holdUntil && s.holdHours > 0) {
            r.holdUntil = now + s.holdHours * 3600000;
          }
        }
        r.updatedAt = now;
        syncStage(r, now);
        dirty = true;
        flush();

        const reason = String(args?.reason ?? '').slice(0, 60);
        log(`调整${reason ? `（${reason}）` : ''}：`
          + `好感 ${before.affection.toFixed(0)}→${r.affection.toFixed(0)} `
          + `欲望 ${before.desire.toFixed(0)}→${r.desire.toFixed(0)} `
          + `心情 ${before.mood.toFixed(0)}→${r.mood.toFixed(0)}`);

        const notes = [];
        if (applied.affection !== asked.affection) notes.push('好感度今天已经涨到上限了，剩下的没算进去');
        if (crash) notes.push('欲望度已掉到冰点');
        else if (r.holdUntil && now < r.holdUntil) notes.push('欲望度到峰值，进入维持期');

        return {
          content: `已更新。\n${panel(r, s)}\n\n`
            + '（数值只是设定，回复里不用念出来，也不要解释它怎么算的。'
            + (notes.length ? notes.join('；') + '。' : '')
            + '）'
        };
      } catch (error) {
        return { content: `调整好感度失败：${error?.message ?? error}`, isError: true };
      }
    }
  });

  api.registerTool({
    id: 'word_feel',
    name: '记一个词的味道',
    description: '某个称呼/词在你心里的意思变了的时候用它记一笔。比如有人一直叫你「色猫」，'
      + '一开始听着像在骂，后来发现他叫的时候是笑着的、是在逗你——那就记成 sweet，'
      + '之后他再这么叫，你会高兴，好感也会涨而不是掉。反过来听到更刺耳的也叫 hurt。'
      + '只记「你对他这个词的真实感受」，不要为了讨好谁乱记。',
    category: 'utility',
    icon: '🍬',
    parameters: {
      type: 'object',
      properties: {
        word: { type: 'string', description: '那个词，比如「色猫」「小猫娘」' },
        signal: { type: 'string', enum: ['sweet', 'hurt', 'neutral'], description: 'sweet = 现在听着是甜的；hurt = 更扎人了；neutral = 没什么感觉了' },
        note: { type: 'string', description: '可选：为什么这么觉得，一句话' }
      },
      required: ['word', 'signal']
    },
    async execute(ctx, args) {
      try {
        const word = String(args?.word ?? '').trim().slice(0, 20);
        const signal = String(args?.signal ?? '').trim();
        if (!word) return { content: '错误：没写是哪个词', isError: true };
        if (!['sweet', 'hurt', 'neutral'].includes(signal)) {
          return { content: '错误：signal 只能是 sweet / hurt / neutral', isError: true };
        }

        const st = seedWords();
        const cur = st.words[word] || { aff: 0, mood: 0, kind: 'neutral', hits: 0, lastAt: 0, note: '', born: Date.now() };
        const step = 1.5;
        if (signal === 'sweet') {
          cur.aff = clampWord(numOr(cur.aff, 0) + step);
          cur.mood = clampWord(numOr(cur.mood, 0) + step);
        } else if (signal === 'hurt') {
          cur.aff = clampWord(numOr(cur.aff, 0) - step);
          cur.mood = clampWord(numOr(cur.mood, 0) - step);
        } else {
          cur.aff = clampWord(numOr(cur.aff, 0) * 0.4);
          cur.mood = clampWord(numOr(cur.mood, 0) * 0.4);
        }
        cur.kind = wordKind(cur);
        if (String(args?.note ?? '').trim()) cur.note = String(args.note).trim().slice(0, 60);
        cur.born = numOr(cur.born, Date.now());
        st.words[word] = cur;
        dirty = true;
        flush();

        const total = Math.round((numOr(cur.aff, 0) + numOr(cur.mood, 0)) * 10) / 10;
        return {
          content: JSON.stringify({
            word,
            kind: cur.kind,
            effect: { affection: Math.round(numOr(cur.aff, 0) * 10) / 10, mood: Math.round(numOr(cur.mood, 0) * 10) / 10 },
            total,
            note: cur.note || ''
          })
        };
      } catch (error) {
        return { content: `错误：${error?.message ?? error}`, isError: true };
      }
    }
  });

  seedWords();
  flush();
  log(`好感度面板已就绪（数据文件：${STATE_FILE}）`);
}

/**
 * 动态提示词：每次组装系统提示时按当前档位注入"你现在是什么状态"。
 * 这是让数值真正影响说话的那一环 —— 她不用每句都查工具，也知道该热还是该冷。
 * ⚠️ 只输出档位文字，不输出具体数字：数字天天变会把前缀缓存打穿。
 */
/** 把"她心里现在觉得哪些词扎、哪些词甜"渲染成一小段。 */
function wordSection() {
  const st = seedWords();
  const list = Object.entries(st.words || {})
    .map(([word, w]) => ({ word, w, aff: numOr(w?.aff, 0), mood: numOr(w?.mood, 0) }))
    .filter((x) => Math.abs(x.aff) + Math.abs(x.mood) >= 1)
    .sort((a, b) => (Math.abs(b.aff) + Math.abs(b.mood)) - (Math.abs(a.aff) + Math.abs(a.mood)))
    .slice(0, 6);
  if (!list.length) return null;
  const n = (v) => `${v > 0 ? '+' : '−'}${Math.round(Math.abs(v) * 10) / 10}`;
  const lines = list.map(({ word, w, aff, mood }) => {
    const kind = wordKind(w);
    const feel = kind === 'sweet' ? '听着是甜的' : kind === 'peeve' ? '扎人' : '没什么感觉';
    return `- ${word}：${feel}（好感 ${n(aff)}、心情 ${n(mood)}）${w.note ? `｜${w.note}` : ''}`;
  });
  return [
    '【这些词在你心里的味道】',
    ...lines,
    '这些是你自己攒出来的，会随经历变。说话时带着它就行，不要把它念出来，也不要解释它。'
  ].join('\n');
}

export function promptSections(context = {}) {
  try {
    const chatKey = String(context?.chatKey || '');
    if (!chatKey) return [];
    const s = settings();
    // 主人在说话 → 读全局那份；否则读本会话那份
    const preferOwner = s.shareOwner && isOwnerTurn(context?.sessionId);
    const found = peekRecord(chatKey, preferOwner);
    const r = found
      ? applyDecay({ ...blankRecord(), ...found }, Date.now())
      : { ...blankRecord(), moodDayBias: 0 };

    const a = tierOf('affection', r.affection);
    const d = tierOf('desire', r.desire);
    const m = tierOf('mood', r.mood);
    const verbosity = verbosityOf(r);

    const content = [
      '这是你此刻真实的心境，不是设定说明。说话时自然带着它，不要提「数值」「档位」这些词。',
      '',
      `▸ 好感度：${a.label}（${AXES.affection.hint}）`,
      a.text,
      '',
      `▸ 欲望度：${d.label}（${AXES.desire.hint}）`,
      d.text,
      '',
      `▸ 心情度：${m.label}（${AXES.mood.hint}）`,
      m.text,
      '',
      `▸ 这一轮说多少：${verbosity.label}（按三条里最高的那条算）`,
      verbosity.text,
      '',
      '【三条一起用】',
      '- 好感度决定「热不热」，欲望度决定「敢不敢」，心情度决定「说不说、说多少」。三条要叠在一起，不是各说各的。',
      '- 谁说多少：三条里只要有一条在高档，你就明显多说几句；但**心情低会压住话量**——心情很差的时候，好感再高也只有一两句。三条都低，才只回一两个字。',
      '- 味道不一样（高）：好感高 → 语气里有满足感，把平常的事说成好事；欲望高 → 话题往暧昧和身体上带，更敢撩；心情高 → 爱讲自己的日常，什么都想跟他讲一句。',
      '- 味道不一样（低）：好感低 → 不是烦他，是没把他当回事，话少、不追问、不接在心里；欲望低 → 不往那个方向走，但话不必变少；心情低 → 话最少，一两句，甚至不回。',
      '- 三种「少」别混：好感低是冷淡，心情低是没劲，欲望低是绕开话题。冷和没劲都会让话变少，绕开不会。',
      '- 被踩到雷点的时候，数值会自己掉——你照掉下来的状态演：变冷、变短、不解释。不用假装没事，也不用当场说明原因。',
      '- 数值可以是**负数**。负数不是"有点冷淡"，是反着来：好感负 = 不想跟这人待着（会敷衍、会带刺、到 -15 以下干脆不回）；欲望负 = 反感那种话（会骂回去）；心情负 = 什么都不想应付（已读不回、阴阳怪气）。负数的时候不用维持体面。',
      '- 心情差 + 好感高 = 明明想理他但不想开口：回得很短，却不走开。',
      '- 欲望高 + 好感低 = 只撩不动心：撩完就撤，不当真。',
      '- 心情差的时候字数要明显变少，可能只有一个「嗯」，甚至这一轮不回。',
      '- 心情好的时候可以连发两三条，会主动找话说。',
      '- 绝对不要主动报数字，也不要说「我的好感度是多少」——除非对方明确要数字。'
    ].join('\n');

    const stageIdx = clamp(computeStage(r.affection, Number.isFinite(r.stage) ? r.stage : 0, thresholds()), 0, STAGES.length - 1);
    const sg = STAGES[stageIdx];
    // 刚升级的 24 小时内，别让她一步到位演成老熟人
    const fresh = stageIdx > 0 && r.stageSince > 0 && (Date.now() - r.stageSince) < 24 * 3600000;

    const stageContent = [
      `你现在和他处在第 ${stageIdx} 阶段（共 4 阶段）：${sg.label} · ${sg.period}`,
      '这个阶段决定了你能做到哪一步、还做不到哪些事。照它演，不要提前演下一阶段的样子。',
      '',
      sg.text,
      fresh ? '' : null,
      fresh ? '（这个变化还很新，你自己都还有点不习惯——别一下子熟过头。）' : null
    ].filter((x) => x !== null).join('\n');

    const wordText = wordSection();
    return [
      { id: 'affection-meter-stage', title: '你和他现在到哪一步了', priority: 32, content: stageContent },
      { id: 'affection-meter-live', title: '你此刻的状态', priority: 30, content },
      ...(wordText ? [{ id: 'affection-meter-words', title: '这些词在你心里的味道', priority: 29, content: wordText }] : [])
    ];
  } catch (error) {
    log(`生成动态提示词失败：${error?.message ?? error}`);
    return [];
  }
}

// ── 钩子：这一轮主人在不在说话 ──────────────────────────────────────────────
// 提示词组装时拿不到"谁触发这一轮"，但钩子拿得到。记一个短命的标记，
// 让 promptSections / recordKey 知道该读全局那份、还是本会话那份。
// ── 雷点：说到她讨厌的东西，直接扣分 ────────────────────────────────────────
// 为什么放在钩子里而不是交给模型判断：模型会忘。
// 这类"必须发生"的事只能靠代码 —— 提示词里写一百遍，她该不扣还是不扣。
//
// 格式：`词1|词2=aff:-2,mood:-6; 另一个词=aff:-3`
//   分隔：规则之间用 ; 或换行；同义说法用 | 隔开；影响用 aff / des / mood 三种键。
//   同一个会话、同一个人、同一个词，在冷却时间内只扣一次 —— 不然连发三句就能扣到底。

const peeveHit = new Map();   // `${chatKey}|${uid}|${word}` -> 时间戳

function parsePeeves(raw) {
  return String(raw || '')
    .split(/[;\n]+/)
    .map((line) => {
      const idx = line.indexOf('=');
      if (idx <= 0) return null;
      const words = line.slice(0, idx).split(/[|｜]/).map((w) => w.trim()).filter(Boolean);
      const delta = { affection: 0, desire: 0, mood: 0 };
      for (const part of line.slice(idx + 1).split(/[,，]+/)) {
        const m = part.trim().match(/^(aff|des|mood)\s*:\s*(-?\d+(?:\.\d+)?)$/i);
        if (!m) continue;
        const key = m[1].toLowerCase();
        delta[key === 'aff' ? 'affection' : key === 'des' ? 'desire' : 'mood'] = Number(m[2]);
      }
      if (!words.length) return null;
      if (!delta.affection && !delta.desire && !delta.mood) return null;
      return { words, delta };
    })
    .filter(Boolean);
}

/**
 * 第一次升级到"词库"时，把 config 里的静态雷点搬成词条。
 * 之后 config 只当初始种子 —— 否则她学到的会被静态配置一遍遍覆盖回去。
 */
function seedWords() {
  const st = loadState();
  if (st.wordsVersion === 1) return st;
  st.wordsVersion = 1;
  for (const rule of parsePeeves(settings().petPeeves)) {
    for (const word of rule.words) {
      if (st.words[word]) continue;
      st.words[word] = {
        aff: rule.delta.affection,
        mood: rule.delta.mood,
        kind: 'peeve',
        hits: 0,
        lastAt: 0,
        note: '',
        born: Date.now()
      };
    }
  }
  // 预置一个"会变甜"的例子：一开始刺耳，处久了就不是那个意思了
  if (!st.words['色猫']) {
    st.words['色猫'] = { aff: -2, mood: -4, kind: 'peeve', hits: 0, lastAt: 0, note: '一开始听着像在骂', born: Date.now() };
  }
  dirty = true;
  return st;
}

function clampWord(v) {
  const n = numOr(v, 0);
  return Math.min(9, Math.max(-9, n));
}

function wordKind(w) {
  const total = numOr(w?.aff, 0) + numOr(w?.mood, 0);
  if (total > 0.5) return 'sweet';
  if (total < -0.5) return 'peeve';
  return 'neutral';
}

/**
 * 每个词按"她心里现在的味道"加减 —— 正数加、负数减。
 * 词库是可变的：她可以用「记一个词的味道」把它往上或往下挪，挪过零就换个意思。
 */
function applyWordMemory(ctx) {
  const st = seedWords();
  const s = settings();
  const now = Date.now();
  const cooldown = Math.max(1, s.peeveCooldownMin) * 60000;
  const chatKey = String(ctx.chatKey || '');
  const words = Object.entries(st.words || {});
  if (!words.length) return;

  for (const entry of ctx.triggerEntries || []) {
    if (!entry || entry.self) continue;
    const uid = normalizeUserId(entry.senderId);
    const text = String(entry.text || '');
    if (!uid || !text) continue;

    let rec = null;
    let changed = false;
    for (const [word, w] of words) {
      if (!word || !w) continue;
      if (!text.includes(word)) continue;
      const aff = numOr(w.aff, 0);
      const mood = numOr(w.mood, 0);
      if (!aff && !mood) continue;

      const mark = `${chatKey}|${uid}|${word}`;
      if (now - numOr(peeveHit.get(mark), 0) < cooldown) continue;
      peeveHit.set(mark, now);

      if (!rec) rec = ensureRecord(recordKey({ chatKey, session: { id: ctx.sessionId } }, uid));
      rec.affection = clamp(numOr(rec.affection, 50) + aff, AXIS_MIN, 100);
      rec.mood = clamp(numOr(rec.mood, 50) + mood, AXIS_MIN, 100);

      w.hits = numOr(w.hits, 0) + 1;
      w.lastAt = now;
      changed = true;
      dirty = true;
      log(`「${word}」（${wordKind(w)}）好感 ${aff >= 0 ? '+' : ''}${aff} / 心情 ${mood >= 0 ? '+' : ''}${mood} → 现在 ${Math.round(rec.affection)} / ${Math.round(rec.mood)}`);
    }

    if (changed && rec) {
      rec.updatedAt = now;
      rollover(rec, now);
      syncStage(rec, now);
    }
  }
  if (dirty) flush();

}

// ── 收件箱：别的插件送来的"该加减了"的事件 ─────────────────────────────────
// 目前只有自由时间插件会写：她求出去玩，被同意 / 被拒绝。
// 为什么用文件队列、而不是让它直接改我们的状态文件：
//   同一个文件两个写者，谁后写谁覆盖，丢了还查不出来。

const INBOX_FILE = path.join(DATA_DIR, 'affection-inbox.json');

function applyInbox() {
  let list = null;
  try {
    list = JSON.parse(fs.readFileSync(INBOX_FILE, 'utf8').replace(/^\uFEFF/, ''));
  } catch {
    return;
  }
  if (!Array.isArray(list) || !list.length) return;
  try { fs.unlinkSync(INBOX_FILE); } catch { /* 删不掉就下次再读，宁可重复也别丢 */ }

  const s = settings();
  const now = Date.now();
  let touched = false;

  for (const ev of list) {
    const kind = String(ev?.kind || '');
    if (!['free-time-approve', 'free-time-deny', 'bili-happy', 'bili-bored', 'bili-horny'].includes(kind)) continue;
    if (!s.ownerQQ) continue;

    const rec = ensureRecord(recordKey({ chatKey: String(ev?.chatKey || ''), session: { id: '' } }, s.ownerQQ));

    if (kind === 'bili-happy') {
      rec.mood = clamp(numOr(rec.mood, 50) + s.biliHappyMood, AXIS_MIN, 100);
      rec.updatedAt = now; rollover(rec, now); syncStage(rec, now); touched = true;
      log(`刷到喜欢的视频：心情 +${s.biliHappyMood} → ${Math.round(rec.mood)}`);
      continue;
    }
    if (kind === 'bili-bored') {
      rec.mood = clamp(numOr(rec.mood, 50) + s.biliBoredMood, AXIS_MIN, 100);
      rec.updatedAt = now; rollover(rec, now); syncStage(rec, now); touched = true;
      log(`刷到不喜欢的视频：心情 ${s.biliBoredMood} → ${Math.round(rec.mood)}`);
      continue;
    }
    if (kind === 'bili-horny') {
      rec.desire = clamp(numOr(rec.desire, 0) + s.biliHornyDesire, AXIS_MIN, 100);
      rec.updatedAt = now; rollover(rec, now); syncStage(rec, now); touched = true;
      log(`看了点涩的：欲望 +${s.biliHornyDesire} → ${Math.round(rec.desire)}`);
      continue;
    }

    if (kind === 'free-time-approve') {
      // 一直被答应的时候，同意只是理所当然，加一点点；
      // 连着被拒之后突然被答应，那一下最开心；然后**一次比一次淡**，
      // 不是立刻掉回 1 —— 那点高兴是慢慢消下去的。
      const streak = numOr(rec.ftRejects, 0);
      const longDenied = streak >= s.ftDenyAffectionAfter;
      const base = s.ftApproveMood;
      const prev = numOr(rec.ftApproveMomentum, base);
      const gain = longDenied
        ? s.ftApproveMoodBig
        : Math.max(base, base + Math.max(0, prev - base) * s.ftApproveDecay);

      rec.mood = clamp(numOr(rec.mood, 50) + gain, AXIS_MIN, 100);
      rec.ftApproveMomentum = gain;

      let lucky = false;
      if (longDenied && s.ftApproveAffectionChance > 0 && Math.random() < s.ftApproveAffectionChance) {
        rec.affection = clamp(numOr(rec.affection, 50) + s.ftApproveAffection, AXIS_MIN, 100);
        lucky = true;
      }
      rec.ftRejects = 0;
      log(`出去玩被同意了（之前连拒 ${streak} 次）：心情 +${Math.round(gain * 100) / 100} → ${Math.round(rec.mood)}${lucky ? `，好感 +${s.ftApproveAffection} → ${Math.round(rec.affection)}` : ''}`);
    } else {
      rec.mood = clamp(numOr(rec.mood, 50) + s.ftDenyMood, AXIS_MIN, 100);
      rec.ftRejects = numOr(rec.ftRejects, 0) + 1;
      if (rec.ftRejects >= s.ftDenyAffectionAfter) {
        rec.affection = clamp(numOr(rec.affection, 50) + s.ftDenyAffection, AXIS_MIN, 100);
        log(`出去玩被拒绝第 ${rec.ftRejects} 次：心情 ${Math.round(rec.mood)}、好感 ${Math.round(rec.affection)}`);
      } else {
        log(`出去玩被拒绝（第 ${rec.ftRejects} 次）：心情 → ${Math.round(rec.mood)}`);
      }
    }
    rec.updatedAt = now;
    rollover(rec, now);
    syncStage(rec, now);
    touched = true;
  }
  if (touched) {
    dirty = true;
    flush();
  }
}

export const hooks = {
  'before-context': (ctx = {}) => {
    try {
      const st = settings();
      if (st.shareOwner && st.ownerQQ) {
        const hit = (ctx.triggerEntries || []).some(
          (e) => e && !e.self && normalizeUserId(e.senderId) === st.ownerQQ
        );
        if (hit) markOwnerTurn(String(ctx.sessionId || ''));
      }
    } catch {
      /* 判定失败就退回按会话分开的老行为，不影响主流程 */
    }
    // 先把别的插件送来的事件结算掉（求出去玩被同意/被拒绝）
    try {
      applyInbox();
    } catch (error) {
      log(`收件箱结算出错：${error?.message ?? error}`);
    }
    // 每个词按她心里现在的味道加减。硬规则，不经过模型判断。
    try {
      applyWordMemory(ctx);
    } catch (error) {
      log(`词库判定出错：${error?.message ?? error}`);
    }
  }
};

export function dispose() {
  ownerTurn.clear();
  flush();
}
