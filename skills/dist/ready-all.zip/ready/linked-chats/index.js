// 联动会话记忆：让机器人在「一个私聊 + 最多两个群」之间共享上下文。
//
// 为什么是技能而不是插件：
//   它既要「模型主动回看」（工具 → registerTool，这是技能的定义），
//   又要「不用问就知道」（提示词注入 → promptSections）。插件只有能力/钩子，没有工具，
//   按本项目的目录语义，能注册工具的就该放 skills/。
//
// 数据从哪来：宿主的 before-context 钩子会在组装提示词**之前**执行，并把 store
// （全部会话的消息存档）递进来；我们在这里把「别的联动会话」压成一段摘要，
// 存进模块内存，紧接着 promptSections(context) 被调用时再取出来注入。
// 全程只读存档，不写任何东西，也不额外调用模型。
//
// 隐私边界（重要）：
//   · 只认 settings 里白名单那个 QQ 的私聊 + 指定的群号，别的会话一律不读；
//   · 摘要是「背景」，提示词里明确禁止她主动复述别处的内容、尤其禁止在群里提私聊内容；
//   · 关掉 enabled 就完全静默：不读、不注入、工具也看不到。

const MAX_GROUPS = 2;

const state = {
  api: null,
  // chatKey -> { text, chars, at }   本轮要注入的摘要
  digest: new Map()
};

function readSettings() {
  try {
    return (state.api && state.api.config && state.api.config()) || {};
  } catch {
    return {};
  }
}

function cfgOf() {
  const c = readSettings();
  const num = (v, d, max) => {
    const n = Number(v);
    return Number.isFinite(n) && n > 0 ? Math.min(Math.floor(n), max) : d;
  };
  return {
    enabled: c.enabled !== false,
    whitelistQQ: String(c.whitelistQQ || '').trim(),
    groups: String(c.groupIds || '')
      .split(/[,，;；、\s]+/)
      .map((s) => s.trim())
      .filter((s) => /^\d+$/.test(s))
      .slice(0, MAX_GROUPS),
    maxMessages: num(c.maxMessages, 6, 30),
    maxChars: num(c.maxChars, 700, 3000),
    injectToPrompt: c.injectToPrompt !== false,
    allowToolRead: c.allowToolRead !== false
  };
}

/** 联动的会话 key 列表：私聊 + 最多两个群。 */
function linkedKeys(cfg) {
  const keys = [];
  if (/^\d+$/.test(cfg.whitelistQQ)) keys.push(`private:${cfg.whitelistQQ}`);
  for (const g of cfg.groups) keys.push(`group:${g}`);
  return keys;
}

function isLinked(cfg, chatKey) {
  return linkedKeys(cfg).includes(String(chatKey || ''));
}

function labelOf(chatKey) {
  const [kind, id] = String(chatKey || '').split(':');
  return kind === 'group' ? `群 ${id}` : `私聊 ${id}`;
}

function hhmm(ts) {
  try {
    const d = new Date(Number(ts) || Date.now());
    return `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`;
  } catch {
    return '';
  }
}

function oneLine(text, max) {
  return String(text || '').replace(/\s+/g, ' ').trim().slice(0, max);
}

/** 把「别的联动会话」最近的对话压成一段摘要。 */
function buildDigest(store, cfg, currentKey) {
  const blocks = [];
  for (const key of linkedKeys(cfg)) {
    if (key === currentKey) continue;
    let recent = [];
    try {
      recent = store?.recent?.(key, { limit: cfg.maxMessages, includeSelf: true }) || [];
    } catch { recent = []; }
    if (!recent.length) continue;
    const lines = recent.slice(-cfg.maxMessages).map((m) => {
      const who = m?.self ? '我' : (m?.senderName || m?.senderId || '某人');
      return `${hhmm(m?.ts)} ${who}：${oneLine(m?.text, 50)}`;
    });
    blocks.push(`· ${labelOf(key)}：${lines.join(' ｜ ')}`);
  }
  if (!blocks.length) return '';
  let text = blocks.join('\n');
  if (text.length > cfg.maxChars) text = `${text.slice(0, cfg.maxChars)}…`;
  return text;
}

const RULES = `【联动会话】你和这个人还有几个会话在同时进行。上面这段是**别处**最近聊的内容，用来保持上下文连贯。
- 它是背景，不是你当前这个会话里发生的事；不要把它当成本轮对话的一部分来回应。
- **不要主动复述**别处的对话，也不要说"我看到你在 XX 群说"之类暴露存档的话——自然地用就行。
- **在群里绝对不要提私聊里的具体内容**；私聊里也不要转述群里别人的隐私。
- 拿不准是不是该提，就当不知道。`;

// ── 钩子：提示词组装之前先把摘要算好 ────────────────────────────────────────
export const hooks = {
  'before-context': (ctx) => {
    const cfg = cfgOf();
    if (!cfg.enabled) return;
    const chatKey = String(ctx?.chatKey || '');
    if (!isLinked(cfg, chatKey)) return;
    const text = buildDigest(ctx?.store, cfg, chatKey);
    if (text) state.digest.set(chatKey, { text, chars: text.length, at: Date.now() });
    else state.digest.delete(chatKey);
  }
};

/** 按人、按会话注入：只有联动范围内的会话才带这段。 */
export function promptSections(context) {
  const cfg = cfgOf();
  if (!cfg.enabled || !cfg.injectToPrompt) return [];
  const chatKey = String(context?.chatKey || '');
  if (!isLinked(cfg, chatKey)) return [];
  const d = state.digest.get(chatKey);
  if (!d?.text) return [];
  return [{
    id: 'linked-chats',
    title: '联动会话',
    // ⚠️ 优先级故意压到最低：这段内容每轮都变，排得靠前会把后面所有提示词
    //    的缓存前缀打碎（宿主 prompt.js 里对此有明确警告）。放最后只损失它自己。
    priority: 5,
    content: `${RULES}\n\n【别处最近】\n${d.text}`
  }];
}

export function register(api) {
  state.api = api;

  api.registerTool({
    id: 'read_linked_chat',
    name: '回看联动会话',
    description: '读取联动会话（私聊/群）里更早的消息。当需要知道「刚才在另一个会话里聊了什么」、而自动注入的那几条不够时用。只能读设置里联动的那几个会话。',
    category: 'knowledge',
    icon: '🔗',
    parameters: {
      type: 'object',
      properties: {
        target: { type: 'string', description: '要看哪个会话：填「私聊」「群1」「群2」，或直接填群号/QQ号' },
        limit: { type: 'number', description: '读多少条，默认 20，最多 50' }
      },
      required: ['target']
    },
    async execute(ctx, args) {
      const cfg = cfgOf();
      if (!cfg.enabled) return { content: '联动会话功能已关闭。', isError: true };
      if (!isLinked(cfg, ctx?.chatKey)) return { content: '当前会话不在联动范围内。', isError: true };
      if (!cfg.allowToolRead) return { content: '设置里关掉了「主动回看」。', isError: true };

      const raw = String(args?.target || '').trim();
      const keys = linkedKeys(cfg);
      let key = '';
      if (/^群\s*1$/i.test(raw)) key = keys.find((k) => k.startsWith('group:')) || '';
      else if (/^群\s*2$/i.test(raw)) key = keys.filter((k) => k.startsWith('group:'))[1] || '';
      else if (/^私聊|private/i.test(raw)) key = keys.find((k) => k.startsWith('private:')) || '';
      else if (/^\d+$/.test(raw)) {
        key = keys.includes(`group:${raw}`) ? `group:${raw}`
          : keys.includes(`private:${raw}`) ? `private:${raw}` : '';
      } else if (/^(group|private):\d+$/.test(raw)) {
        key = keys.includes(raw) ? raw : '';
      }
      if (!key) {
        return {
          content: `只能读联动范围内的会话：${keys.map(labelOf).join('、') || '（还没配置）'}。`,
          isError: true
        };
      }

      const limit = Math.max(1, Math.min(50, Number(args?.limit) || 20));
      let recent = [];
      try { recent = ctx.store?.recent?.(key, { limit, includeSelf: true }) || []; } catch { recent = []; }
      if (!recent.length) return { content: `${labelOf(key)} 里没有可读的消息。`, isError: false };

      const lines = recent.map((m) => {
        const who = m?.self ? '我' : `${m?.senderName || m?.senderId || '某人'}`;
        return `${hhmm(m?.ts)} ${who}：${oneLine(m?.text, 100)}`;
      });
      return { content: `${labelOf(key)} 最近 ${lines.length} 条：\n${lines.join('\n')}`, isError: false };
    }
  });

  api.registerTool({
    id: 'linked_status',
    name: '联动状态',
    description: '查看联动会话当前配置和最近一次注入的摘要有多长。用户问「你联动的是哪几个会话」或联动没生效时用来排查。',
    category: 'system',
    icon: '🔍',
    parameters: { type: 'object', properties: {}, required: [] },
    async execute(ctx) {
      const cfg = cfgOf();
      const keys = linkedKeys(cfg);
      const d = state.digest.get(String(ctx?.chatKey || ''));
      return {
        ok: true,
        content: JSON.stringify({
          enabled: cfg.enabled,
          linked: keys.map(labelOf),
          inScope: isLinked(cfg, ctx?.chatKey),
          inject: cfg.injectToPrompt,
          maxMessages: cfg.maxMessages,
          lastDigestChars: d?.chars || 0
        })
      };
    }
  });
}

/** 工具守卫：不在联动范围内时，模型连这两个工具都看不到。 */
export const providers = {
  'tool.guard': (p) => {
    const toolId = String(p?.toolId || '');
    if (!toolId.startsWith('linked-chats__')) return null;
    const cfg = cfgOf();
    if (!cfg.enabled) return { ok: false, reason: '联动会话功能已关闭' };
    const chatKey = String(p?.context?.chatKey || '');
    // 没有 chatKey（工具总览页那种通用上下文）判不了，放行给执行期校验
    if (!chatKey) return null;
    if (!isLinked(cfg, chatKey)) return { ok: false, reason: '当前会话不在联动范围内' };
    return null;
  }
};

export function deactivate() {
  state.digest.clear();
}

export function dispose() {
  state.digest.clear();
}
