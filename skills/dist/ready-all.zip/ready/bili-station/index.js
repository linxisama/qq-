// B 站点歌机（合并版）—— 视频分享 + 语音条点歌，一个插件。
//
// ── 为什么合并 ──────────────────────────────────────────────────────────
// 原来拆成两个技能（skills/bili-share + skills/bili-voice），用户想装一个包同时要
// 两种能力时就得上传/安装两份；而两边的 bili-api.js 是**同一份**（搜索、取流、
// 下载、画质全都共用）。合并后：1 个清单、1 个入口、3 个工具。
//
// ── 怎么做到"零改动"合并的 ─────────────────────────────────────────────
// 两个技能都是"入口 + 同目录模块"的结构，所以整目录原样搬进来：
//   share/  ← 原 skills/bili-share（分享 B 站视频）
//   voice/  ← 原 skills/bili-voice（点歌发语音条）
// 内部相对导入（./bili-api.js）各自成立，业务逻辑一行没改。
// 本文件只做三件事：
//   ① setup 两个模块，让它们各自注册工具（bili_video / bili_search / bili_voice）
//   ② 合并 available()：语音条那条链依赖 ffmpeg
//   ③ 合并 dispose
//
// ⚠️ 子模块必须用「带时间戳的动态 import」（同 qzone / early-finish 的坑）：
//    plugin-loader 只给**入口**加了 ?t=，入口里静态 import 的子模块会被 Node 的
//    ESM 缓存锁住 —— 改了 voice/index.js，"重载"之后跑的还是旧代码。

const BUILD_STAMP = Date.now();
const voice = await import(`./voice/index.js?t=${BUILD_STAMP}`);
const share = await import(`./share/index.js?t=${BUILD_STAMP}`);

let log = () => {};

export async function setup(api) {
  log = typeof api.log === 'function' ? api.log : () => {};
  // 两个模块各注册自己的工具：bili_search / bili_voice / bili_video。
  // 它们的配置都从 api.config() 现读，合并后的 settings 里两边的键都在（无重名）。
  await voice.setup(api);
  await share.setup(api);
  log('[bili] 合并插件就绪：视频分享 + 语音条点歌（3 个工具）');
}

/**
 * 可用性自检。
 *
 * 只有**语音条**那条链需要 ffmpeg（抽音频），视频分享不需要。合并后只能按"更严"的
 * 那条判：没有 ffmpeg 时整个插件显示不可用 —— 这比"视频能用但语音条静默失败"更
 * 好排查。装好 ffmpeg 后无需重启（voice.available() 内部带缓存过期重探）。
 */
export function available() {
  try {
    return typeof voice.available === 'function' ? voice.available() : { ok: true };
  } catch (error) {
    return { ok: false, reason: `自检失败：${error?.message ?? error}` };
  }
}

export function dispose() {
  try { voice.dispose?.(); } catch { /* ignore */ }
  try { share.dispose?.(); } catch { /* ignore */ }
}

/** 给测试/排障用。 */
export const internals = { voice: voice.internals || null, share: share.internals || null };
