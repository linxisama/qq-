// B站点歌（语音条）—— LLM 型技能（skills/）。
//
// 为什么用 B 站当音源：酷狗/网易云的会员歌在接口层就被掐死了（酷狗直接
// 回"需要付费"，网易云带账号拿到的链接下载还会 403，详见之前的实测）。
// B 站是本次唯一"能真下到文件"的路：搜视频 → 取流 → 下 mp4 → ffmpeg 抽音频 → 发语音条。
// 代价是它属于 UP 主上传的 MV/音频，不是官方音源，可能带片头，所以默认跳过开头 15 秒。
//
// ── 两个硬约束 ──────────────────────────────────────────────────────────
// 1. "只在我让他发的时候才发"：工具拆成 bili_search（只搜不发）和 bili_voice（真发），
//    提示词里明确"只说不发"；另有可选 ownerIds，填了就只有主人能点。
// 2. "发完自动清理"：下载的 mp4、抽出的 mp3 在发送成功后立刻删除（autoCleanup，默认开）。
//    注意时机 —— 必须等 sendMedia 返回之后再删：协议端读文件是发送过程的一部分，
//    提前删会把消息发成空壳。
//
// ── 为什么复制一份 bili-api.js 而不是 import 隔壁技能 ────────────────────
// 项目约定每个技能自包含（bili-share 里那份也是这么来的）。互相 import 的话，
// 隔壁技能被删/改名，这边就静默坏掉，而且 loader 的"每个目录自包含"假设也没了。
//
// ⚠️ 静态 import 会被 Node 的模块缓存钉死（改了不生效），所以走 setup 里的动态
// import + 时间戳 —— 点歌技能当年就踩过这个坑。

import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { pathToFileURL } from 'node:url';
import { spawn, spawnSync } from 'node:child_process';

/** QQ 语音条的硬上限。 */
const HARD_MAX_SECONDS = 60;
/** 标题里出现这些字样 ⇒ 大概率不是原唱（翻奏/教学/整活/片段），要扣分。 */
const BAD_TITLE = /(吉他|指弹|钢琴|尤克里里|小提琴|口琴|二胡|古筝|翻奏|演奏|教学|教程|谱|DJ|remix|伴奏|纯音乐|cover|翻唱|恶搞|鬼畜|混剪|合集|串烧|片段|试听|主播|直播|录播|回放|整活|搞笑|二创|反应|reaction|剪辑|搬运|试唱|挑战|MAD|AMV|手书|AI修复|合唱版|翻跳)/i;
/** 标题里出现这些字样 ⇒ 更像官方/原版投稿，加分（用来找"原唱那一版"）。 */
const GOOD_TITLE = /(原版|原曲|官方|MV|完整版|高清|无损|Hi-?Res|4K|8K)/i;
/** 下载/转码的工作目录（系统临时目录，发完即删）。 */
const WORK_DIR = path.join(os.tmpdir(), 'qq-agent-bili-voice');

let bili = null;      // ./bili-api.js 的导出，setup 里动态 import 填充
let cfg = () => ({});
let log = () => {};

const ok = (payload) => ({ content: JSON.stringify(payload, null, 1) });
const err = (message) => ({ content: String(message), isError: true });
const clamp = (v, min, max) => Math.max(min, Math.min(max, v));

function normalizeText(s) {
  return String(s ?? '').toLowerCase().replace(/[\s\p{P}\p{S}]+/gu, '');
}

// ── ffmpeg 探测 ───────────────────────────────────────────────────────────
// 必须是同步的：available() 是同步接口，技能页靠它显示"为什么不能用"。
// 结果缓存 60 秒 —— 用户装好 ffmpeg 后不用重启应用。
const ffState = { at: 0, ok: false, path: '' };

function ffmpegReady(force = false) {
  if (!force && ffState.at && Date.now() - ffState.at < 60000) return ffState;
  const configured = String(cfg().ffmpegPath ?? '').trim();
  const candidates = configured
    ? [configured]
    : ['ffmpeg', path.join(os.homedir(), 'ffmpeg', 'bin', 'ffmpeg.exe'), 'C:\\ffmpeg\\bin\\ffmpeg.exe'];
  let found = '';
  for (const cmd of candidates) {
    try {
      const r = spawnSync(cmd, ['-version'], { windowsHide: true, timeout: 5000 });
      if (r && r.status === 0) { found = cmd; break; }
    } catch { /* 换下一个候选 */ }
  }
  ffState.at = Date.now();
  ffState.ok = Boolean(found);
  ffState.path = found;
  return ffState;
}

/** 技能可用性：没有 ffmpeg 就明说，而不是等到点歌时静默失败。 */
export function available() {
  const st = ffmpegReady();
  if (!st.ok) {
    return { ok: false, reason: '没找到 ffmpeg：B 站的音源是 mp4，没有它就抽不出音频（装一个或在本技能设置里填 ffmpegPath）' };
  }
  return { ok: true };
}

/** 调外部命令，只看退出码。 */
function run(cmd, args, timeoutMs = 120000) {
  return new Promise((resolve) => {
    let done = false;
    const finish = (v) => { if (!done) { done = true; resolve(v); } };
    let child;
    try {
      child = spawn(cmd, args, { windowsHide: true });
    } catch (error) {
      return finish({ ok: false, error: String(error?.message ?? error) });
    }
    let stderr = '';
    child.stderr?.on('data', (b) => { stderr = (stderr + String(b)).slice(-1500); });
    child.on('error', (error) => finish({ ok: false, error: String(error?.message ?? error) }));
    const timer = setTimeout(() => {
      try { child.kill(); } catch { /* 已退出 */ }
      finish({ ok: false, error: `超时（${timeoutMs}ms）` });
    }, timeoutMs);
    child.on('close', (code) => { clearTimeout(timer); finish({ ok: code === 0, code, stderr }); });
  });
}

// ── 搜索结果打分 ──────────────────────────────────────────────────────────
// B 站的"搜歌"其实是搜视频：同一首歌会有 MV、4K 修复、翻唱、指弹改编、教学……
// 不打分的话，机器人很可能给你放一段吉他指弹（实测搜《江南》首条就是）。
// 规则（可解释、可预期）：
//   · 关键词按空格拆成 token，标题里命中一个 +3
//   · 多个 token 全中再 +4（歌名+歌手都出现，最像正主）
//   · 标题带翻奏/教学/片段类字样 -8（基本一票否决）
//   · 时长 <60 秒（片花）或 >7 分钟（合集/演唱会）扣分
// 判定：2 个以上 token 时必须全中；分数 <3 视为不可靠，不自动发。

function scoreItem(item, tokens) {
  const title = normalizeText(item.title);
  const hit = tokens.filter((t) => title.includes(t)).length;
  let score = hit * 3;
  if (tokens.length > 1 && hit === tokens.length) score += 4;
  const raw = String(item.title ?? '');
  if (BAD_TITLE.test(raw)) score -= 8;
  // 官方/原版投稿往往标题里带 MV、原版、4K 这些字，给点加分把真原唱抬上来
  if (GOOD_TITLE.test(raw)) score += 2;
  const dur = Number(item.durationSec) || 0;
  if (dur && dur < 60) score -= 6;
  if (dur && dur > 420) score -= 2;
  return { score, hit };
}

function tokensOf(keyword) {
  return String(keyword ?? '').split(/[\s,，、]+/).map(normalizeText).filter(Boolean);
}

function rankItems(items, keywordOrTokens) {
  const tokens = Array.isArray(keywordOrTokens) ? keywordOrTokens : tokensOf(keywordOrTokens);
  return (items || [])
    .map((item) => {
      const { score, hit } = scoreItem(item, tokens);
      const trusted = tokens.length >= 2
        ? hit === tokens.length && score >= 3
        : hit >= 1 && score >= 3;
      return { item, score, trusted };
    })
    .sort((a, b) => b.score - a.score);
}

/**
 * 查什么 —— 这个问题在日文歌上特别要命。
 *
 * 用户说的是中文译名（「千本樱」「恋爱循环」），而 B 站上原版的标题是日文原文
 * （「千本桜」「恋愛サーキュレーション」）。中文搜出来的往往是古筝/钢琴/光遇改编，
 * 实测搜「千本樱」前四条全是改编 —— 打分规则会把它们全判成"不像原唱"然后拒发，
 * 于是用户看到的就是"搜不到原唱"。
 *
 * 所以查询词要**多轮**：
 *   ① 用户原话（含模型自己给的日文原名/罗马音，它比我们懂这个）
 *   ② 原话 + 原版/原曲/MV/完整版 这类后缀 —— 实测「千本樱 原版」第四条就是
 *      初音未来的原版 MV，而裸搜「千本樱」永远看不到它
 * 注意：打分只按**原话**的核心词算，后缀词绝不能参与 "标题必须包含" 的判定，
 * 否则加上「原版」反而会把自己找到的原版判成不合格（第一版就栽在这）。
 */
function buildQueryPlan(keyword, altKeywords) {
  const base = String(keyword ?? '').trim();
  if (!base) return { primary: [], variants: [] };
  const alts = Array.isArray(altKeywords) ? altKeywords : String(altKeywords ?? '').split(/[,，;；|\n]+/);
  const primary = [base];
  for (const a of alts) {
    const s = String(a ?? '').trim();
    if (s) primary.push(s);
  }
  const variants = ['原版', '原曲', 'MV', '完整版'].map((suf) => `${base} ${suf}`);
  const seen = new Set();
  const dedupe = (arr) => arr.filter((q) => {
    const k = normalizeText(q);
    if (!k || seen.has(k)) return false;
    seen.add(k);
    return true;
  });
  return { primary: dedupe(primary).slice(0, 3), variants: dedupe(variants).slice(0, 3) };
}

/**
 * 按计划查询并打分。
 *
 * 分两轮，因为"搜到一条能发的"不等于"搜到了原唱"：
 *   第一轮 = 用户原话 + 模型给的日文原名/别名（最准，先跑）
 *   第二轮 = 只在第一轮没有任何可信结果时才跑「原版/原曲/MV/完整版」这类后缀
 * 早先的版本是"任一查询出现可信结果就停"，结果裸搜「千本樱」时被一条
 * 主播整活视频骗过去，日文原名和"原版"变体压根没跑 —— 所以第一轮必须跑完。
 *
 * 返回 { ranked, tried }；tried 会透给模型，方便它解释"我是怎么找到的"。
 */
async function gatherRanked(keyword, altKeywords, { limit = 5, maxQueries = 5 } = {}) {
  const tokens = tokensOf(keyword);
  const plan = buildQueryPlan(keyword, altKeywords);
  const byBvid = new Map();
  const tried = [];

  const runOne = async (q) => {
    if (tried.length >= maxQueries) return;
    let res = null;
    try {
      res = await bili.searchVideos(q, { limit, log });
    } catch (error) {
      tried.push({ query: q, error: String(error?.message ?? error).slice(0, 80) });
      return;
    }
    if (!res?.ok) { tried.push({ query: q, error: res?.error || '搜索失败' }); return; }
    const items = res.items || [];
    tried.push({ query: q, found: items.length });
    for (const it of items) {
      if (!it?.bvid) continue;
      const prev = byBvid.get(it.bvid);
      // 同一个视频可能被多个查询命中：只记来源，不重复占位
      if (prev) { if (!prev.from.includes(q)) prev.from.push(q); continue; }
      byBvid.set(it.bvid, { item: it, from: [q] });
    }
  };

  const rankNow = () => rankItems([...byBvid.values()].map((v) => v.item), tokens)
    .map((r) => ({ ...r, from: byBvid.get(r.item.bvid)?.from || [] }));

  for (const q of plan.primary) await runOne(q);
  let ranked = rankNow();
  // "有一条能发的" ≠ "找到原唱了"：裸搜中文名时，一条合唱/二创就能拿到 3 分的及格线，
  // 然后日文原名和"原版"变体就再也不会跑。所以判据是**有没有强匹配**（带 MV/原版/高清
  // 标记、或歌名+歌手全中，通常 ≥5 分），不够就继续补后缀查询。
  const strong = () => ranked.some((r) => r.trusted && r.score >= 5);
  if (!strong()) {
    for (const q of plan.variants) {
      await runOne(q);
      ranked = rankNow();
      if (strong()) break;
    }
  }
  return { ranked, tried };
}

// ── 下载 + 抽音频 ─────────────────────────────────────────────────────────

/**
 * 规划要发几段、从哪开始、每段多长。
 *
 *   deliveryMode = 'full'（默认）：整首按 partSeconds 切开，最后一段可能短一点。
 *   deliveryMode = 'clip'        ：只发一段。
 *
 * 为什么要分段：QQ 一条语音条最多 60 秒，整首 4 分钟的歌必然发不完。
 * 段数用 maxParts 兜住 —— 一首 40 分钟的 live 不能真发 40 条把群刷爆。
 */
function planParts(total, opts = {}) {
  const dur = Math.max(1, Math.round(Number(total) || 0));
  const part = clamp(Math.round(Number(opts.partSeconds) || 55), 10, HARD_MAX_SECONDS);
  const maxParts = clamp(Math.round(Number(opts.maxParts) || 10), 1, 30);
  const start = clamp(Math.round(Number(opts.skipIntro) || 0), 0, Math.max(0, dur - 5));
  const available = Math.max(1, dur - start);
  if (String(opts.mode ?? 'full') === 'clip') {
    return { start, partSeconds: Math.min(part, available), count: 1, truncated: false, available };
  }
  let count = Math.ceil(available / part);
  let truncated = false;
  if (count > maxParts) { count = maxParts; truncated = true; }
  // 只有一段时按实际可用的时长算（短歌不该报"55 秒"）
  const partSeconds = count === 1 ? Math.min(part, available) : part;
  return { start, partSeconds, count, truncated, available };
}

// ── 音源：优先 DASH 独立音轨 ───────────────────────────────────────────────
//
// 实测（2026-10-18，匿名、未登录）：
//   · fnval=1 的 360P 单文件 mp4 —— 里面那条 AAC 约 64kbps，且整包 34.9MB；
//   · fnval=16 的 DASH —— 音频单独一条，30280 档 169kbps（实测 114kbps、
//     48kHz 立体声），只要 6.4MB。
// 同一条视频，音源差距接近 3 倍，而下载量只有 1/5 —— 这就是"音质提升空间"的正解。
// 拿不到 DASH（个别视频没有）就退回视频里的音轨，不影响可用性。

const BILI_API = 'https://api.bilibili.com';
const BILI_UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
  + '(KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36';

async function getDashAudio(bvid, cid) {
  const url = `${BILI_API}/x/player/playurl?bvid=${encodeURIComponent(bvid)}&cid=${cid}`
    + '&qn=0&fnval=16&fnver=0&fourk=1';
  try {
    const res = await fetch(url, {
      headers: {
        'user-agent': BILI_UA,
        referer: 'https://www.bilibili.com/',
        accept: 'application/json'
      }
    });
    if (!res.ok) return null;
    const json = await res.json();
    const audios = (json?.data?.dash?.audio || []).slice()
      .sort((a, b) => (Number(b?.bandwidth) || 0) - (Number(a?.bandwidth) || 0));
    const best = audios[0];
    const src = String(best?.baseUrl || best?.base_url || '').trim();
    if (!src) return null;
    return { url: src, id: Number(best.id) || 0, bandwidth: Number(best.bandwidth) || 0 };
  } catch {
    return null;
  }
}

/**
 * 下载并切出音频分段。
 * files 由调用方传入，路径一创建就登记进去 —— 这样"下载成功但转码失败"这种
 * 半途而废的情况也会被清理（原来只在成功返回后才登记，失败就漏文件）。
 * 返回 { parts: [wav 路径...], plan, quality }。
 */
async function buildParts(item, { startSeconds, files } = {}) {
  const info = await bili.fetchVideoInfo(item.bvid);
  const cid = info?.cid || info?.info?.cid;
  if (!cid) throw new Error('拿不到视频 cid（这可能是番剧/受限视频，换一个结果试试）');

  // 体积上限：0（或填错）＝ 不限制。不限制时下载超时也要放宽，
  // 否则大文件会在 60 秒处被 fetch 的 AbortSignal 掐断，表现成"下载请求失败"。
  const rawMB = Math.round(Number(cfg().maxVideoMB));
  const unlimited = !Number.isFinite(rawMB) || rawMB <= 0;
  const maxMB = unlimited ? 0 : clamp(rawMB, 5, 5000);
  const maxBytes = unlimited ? Number.MAX_SAFE_INTEGER : maxMB * 1048576;
  const dlTimeout = unlimited || maxMB > 60 ? 300000 : 120000;

  const st = ffmpegReady();
  if (!st.ok) throw new Error('没找到 ffmpeg，抽不出音频');

  fs.mkdirSync(WORK_DIR, { recursive: true });
  const tag = `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;

  // ① 先试 DASH 独立音轨：音质好、体积小
  let mediaPath = '';
  let quality = '';
  const dash = await getDashAudio(item.bvid, cid);
  if (dash?.url) {
    const audioPath = path.join(WORK_DIR, `${tag}.m4s`);
    if (Array.isArray(files)) files.push(audioPath);
    const dl = await bili.downloadVideo([dash.url], audioPath, { maxBytes, timeoutMs: dlTimeout });
    if (dl?.ok) {
      mediaPath = audioPath;
      quality = `AAC ${Math.round(dash.bandwidth / 1000)}kbps`;
    }
  }

  // ② 退路：走 360P 单文件的音轨（个别视频没有 dash）
  // ⚠️ 语音条场景**固定 360P**：这里下视频只是为了抽里面的音轨，画质对结果没意义，
  //    拉 720P/1080P 只会让下载量翻几倍、更容易撞上限。真正发视频走的是
  //    bili-share 的 bili_video（那边才需要 quality 参数）。
  const VOICE_FALLBACK_QN = 16;   // 16 = 360P
  if (!mediaPath) {
    const play = await bili.getPlayUrl(item.bvid, cid, { qn: VOICE_FALLBACK_QN });
    if (!play?.ok) throw new Error(play?.error || '取流失败');
    if (!unlimited && play.sizeBytes && play.sizeBytes > maxMB * 1048576) {
      throw new Error(`视频有 ${(play.sizeBytes / 1048576).toFixed(0)}MB，超过设置的 ${maxMB}MB 上限（想放这类就在设置里把上限设成 0）`);
    }
    const videoPath = path.join(WORK_DIR, `${tag}.mp4`);
    if (Array.isArray(files)) files.push(videoPath);
    const dl = await bili.downloadVideo(play.urls, videoPath, { maxBytes, timeoutMs: dlTimeout });
    if (!dl?.ok) throw new Error(dl?.error || '下载失败');
    mediaPath = videoPath;
    quality = '360P 视频内音轨';
  }

  const plan = planParts(item.durationSec, {
    partSeconds: cfg().partSeconds ?? cfg().maxSeconds,
    // 模型可以指定起点（"从 1 分 20 秒开始放"），否则用设置里的"跳过开头"
    skipIntro: startSeconds == null ? cfg().skipIntro : startSeconds,
    mode: cfg().deliveryMode,
    maxParts: cfg().maxParts
  });

  // -ss 放在 -i 前面：直接跳到目标位置再解码，比解完整首再切快一个数量级
  const front = ['-hide_banner', '-loglevel', 'error', '-y', '-ss', String(plan.start), '-i', mediaPath];
  // 输出**无损 WAV**（24k 单声道 16bit），不再先压成 32kbps mp3。
  // 原因：协议端拿到文件后还要转一次 SILK，中间压 mp3 等于两次有损 ——
  // 24k 是 SILK 的原生采样率，转成 WAV 不丢信息，体积也就 2.5MB/55 秒，发完即删。
  const encode = ['-vn', '-ac', '1', '-ar', '24000', '-c:a', 'pcm_s16le'];
  const args = plan.count === 1
    ? [...front, '-t', String(plan.partSeconds), ...encode, '-f', 'wav', path.join(WORK_DIR, `${tag}-000.wav`)]
    // 一次 ffmpeg 切多段：比逐段调用快得多，也不会重复解码
    : [...front, ...encode, '-f', 'segment', '-segment_time', String(plan.partSeconds),
      '-reset_timestamps', '1', path.join(WORK_DIR, `${tag}-%03d.wav`)];

  const conv = await run(st.path, args);
  if (!conv.ok) throw new Error(`抽音频失败：${conv.error || conv.code || 'ffmpeg 返回非 0'}`);

  const produced = fs.readdirSync(WORK_DIR)
    .filter((n) => n.startsWith(`${tag}-`) && n.endsWith('.wav'))
    .sort()
    .map((n) => path.join(WORK_DIR, n));
  if (!produced.length) throw new Error('抽音频失败：没有产出文件');
  for (const p of produced) if (Array.isArray(files) && !files.includes(p)) files.push(p);

  // 段数兜底：超过 maxParts 的部分直接丢掉（歌曲太长时会发生）
  const parts = produced.slice(0, plan.count);
  for (const p of produced.slice(plan.count)) { try { fs.unlinkSync(p); } catch { /* 忽略 */ } }
  for (const p of parts) {
    if (!fs.existsSync(p) || fs.statSync(p).size < 1024) throw new Error('抽音频失败：分段文件为空');
  }
  return { parts, plan, quality };
}

/** 删掉本次产生的临时文件；返回实际删掉的个数（另顺手清扫超过 1 小时的残留）。 */
function cleanup(files, { sweep = false } = {}) {
  let removed = 0;
  for (const f of files || []) {
    try {
      if (fs.existsSync(f)) { fs.unlinkSync(f); removed += 1; }
    } catch (error) {
      log(`清理临时文件失败（${path.basename(f)}）：${error?.message ?? error}`);
    }
  }
  if (sweep) {
    // 极端情况（进程崩在发送中途）会留残骸，顺手扫掉一小时前的
    try {
      const cutoff = Date.now() - 3600 * 1000;
      for (const name of fs.readdirSync(WORK_DIR)) {
        const p = path.join(WORK_DIR, name);
        const st = fs.statSync(p);
        if (st.isFile() && st.mtimeMs < cutoff) fs.unlinkSync(p);
      }
    } catch { /* 目录不存在或别的东西在用，忽略 */ }
  }
  return removed;
}

// ── 谁能点歌 ──────────────────────────────────────────────────────────────

/** 从本轮触发消息里找发起人 QQ 号（ctx 没直接给 speaker，走 session.trigger）。 */
function callerId(ctx) {
  const trigger = ctx?.session?.trigger;
  if (!Array.isArray(trigger) || !trigger.length) return '';
  for (let i = trigger.length - 1; i >= 0; i -= 1) {
    const e = trigger[i];
    if (e && !e.self && e.senderId) return String(e.senderId);
  }
  return '';
}

function ownerGate(ctx) {
  const list = String(cfg().ownerIds ?? '')
    .split(/[,，\s;；]+/)
    .map((s) => s.replace(/[^\d]/g, ''))
    .filter(Boolean);
  if (!list.length) return { ok: true };
  const who = callerId(ctx);
  if (!who) return { ok: false, reason: '认不出是谁发的（没拿到发送者 QQ 号）' };
  return list.includes(who)
    ? { ok: true }
    : { ok: false, reason: `这个会话里只有主人能点歌（当前 ${who} 不在名单里）` };
}

// ── 生命周期 ──────────────────────────────────────────────────────────────

export async function setup(api) {
  cfg = api.config;
  log = api.log;
  const stamp = Date.now();
  bili = await import(`./bili-api.js?t=${stamp}`);

  // 启动时清一次上一轮崩掉留下的残骸（正常情况下这里不会有东西）
  cleanup([], { sweep: true });

  // ── 只搜不发 ────────────────────────────────────────────────────────────
  api.registerTool({
    id: 'bili_search',
    name: 'B站搜歌',
    description: '在 B 站搜歌，只返回候选列表，**不会发送任何东西**。对方说"找找/搜一下/有没有"、或者要点歌但歌名模糊、同名版本多时用它。返回里每条带 index、标题、UP 主、时长和 score（越大越像正主；trusted=false 表示怀疑是翻奏/片段）。确认是哪条之后用 bili_voice 发（传 index 或 bvid 即可，不用重搜）。',
    category: 'media',
    icon: '🅱️',
    parameters: {
      type: 'object',
      properties: {
        keyword: { type: 'string', description: '歌名，最好带上歌手（如"晴天 周杰伦"），空格分隔' },
        altKeywords: { type: 'string', description: '可选：这首歌的**日文原名/罗马音/其他译名**，逗号分隔。日文歌务必给（"千本樱"→"千本桜"，"恋爱循环"→"恋愛サーキュレーション"）——B 站上原版标题都是日文，只搜中文名常常只出古筝/钢琴改编' },
        limit: { type: 'integer', description: '返回几条，默认取技能设置（5），最多 10' }
      },
      required: ['keyword']
    },
    async execute(ctx, args) {
      try {
        const keyword = String(args.keyword ?? '').trim();
        if (!keyword) return err('搜索关键词是空的，先告诉我歌名');
        const limit = clamp(Math.round(Number(args.limit) || Number(cfg().maxResults) || 5), 1, 10);
        const { ranked: all, tried } = await gatherRanked(keyword, args.altKeywords, { limit });
        const ranked = all.slice(0, limit);
        if (!ranked.length) {
          return ok({
            found: false,
            tried,
            note: `B 站没搜到「${keyword}」。换个关键词，或者把歌手名一起带上；如果是日文歌，把日文原名也给我（千本樱 → 千本桜）。别编造歌名。`
          });
        }
        const weak = !ranked.some((r) => r.trusted && r.score >= 5);
        const hint = weak && !String(args.altKeywords ?? '').trim()
          ? '注意：这几条可能只是改编/翻唱版（原版没搜出来）。如果这是日文歌或外语歌，把它**原名**带进 altKeywords 再搜一次（千本樱 → 千本桜，恋爱循环 → 恋愛サーキュレーション），命中率会高很多。'
          : '';
        return ok({
          found: true,
          keyword,
          count: ranked.length,
          tried,
          weak,
          songs: ranked.map((r, i) => ({
            index: i + 1,
            bvid: r.item.bvid,
            title: r.item.title,
            author: r.item.author,
            duration: r.item.duration,
            score: r.score,
            trusted: r.trusted,
            matchedBy: r.from?.[0] || '',
            note: r.trusted ? '' : '可能不是原唱（翻奏/片段/合集）'
          })),
          note: '这些只是候选，**还没有发出去**。要发语音条就用 bili_voice（传 index 或 bvid），别用文字念歌单。' + hint
        });
      } catch (error) {
        return err(`搜索出错：${error?.message ?? error}`);
      }
    }
  });

  // ── 搜 + 发语音条 ───────────────────────────────────────────────────────
  api.registerTool({
    id: 'bili_voice',
    name: 'B站点歌发语音条',
    description: '在 B 站搜到那首歌，取流下载、抽音频，按每段 60 秒上限切成多条语音条，把整首依次发到当前会话（4 分钟的歌大概 4~5 条），发完自动删掉下载的文件。**只在对方明确要求"发/放/来一首"时才用**；只是让找一找就别发（用 bili_search）。歌名清楚可以直接传 keyword；已经搜过就用之前返回的 index 或 bvid。一次点一首，不要连发。',
    category: 'media',
    icon: '🎤',
    parameters: {
      type: 'object',
      properties: {
        keyword: { type: 'string', description: '歌名，最好带歌手（如"晴天 周杰伦"）' },
        altKeywords: { type: 'string', description: '可选：日文原名/罗马音/其他译名，逗号分隔。日文歌务必给（"千本樱"→"千本桜"，"恋爱循环"→"恋愛サーキュレーション"）——B 站上原版标题都是日文，只搜中文名常常只出改编版' },
        index: { type: 'integer', description: '用最近一次 bili_search 结果里的第几条（从 1 开始）' },
        bvid: { type: 'string', description: 'B 站视频号（bili_search 返回的那个），最精确' },
        startSeconds: { type: 'integer', description: '可选：从第几秒开始截（覆盖默认的"跳过开头"，对方说"从 1 分 20 秒那段"时用）' }
      }
    },
    async execute(ctx, args) {
      const gate = ownerGate(ctx);
      if (!gate.ok) return err(`没发：${gate.reason}。可以只搜不发，或者直接说明这里不接别人的点歌。`);

      let built = null;
      let sentParts = 0;      // 已经发出去的段数（中途失败要如实报）
      const tempFiles = [];   // 一创建就登记，失败路径也能清干净
      let result;
      try {
        const keyword = String(args.keyword ?? '').trim();
        if (!keyword) return err('要给歌名（keyword）');

        const limit = clamp(Math.round(Number(cfg().maxResults) || 5), 1, 10);
        const { ranked } = await gatherRanked(keyword, args.altKeywords, { limit });
        if (!ranked.length) {
          return ok({ delivered: false, note: `B 站没搜到「${keyword}」。换个关键词再试，或者如实说没找到；别编造。` });
        }

        // 指定了 bvid / index 就用它，否则取打分最高的一条
        const wantedBvid = String(args.bvid ?? '').trim();
        const idx = Number(args.index) || 0;
        let picked = null;
        if (wantedBvid) picked = ranked.find((r) => r.item.bvid === wantedBvid) || { item: { bvid: wantedBvid }, trusted: true, score: -1 };
        else if (idx >= 1 && ranked[idx - 1]) picked = ranked[idx - 1];
        else picked = ranked[0];

        if (!picked.trusted) {
          // 分数太低 = 疑似翻奏/片段/合集。宁可不发，也不能把指弹当成原唱发出去。
          const top = ranked.slice(0, 3).map((r, i) => `${i + 1}. ${r.item.title}（${r.item.author}）`).join('；');
          return err(`没发：搜「${keyword}」出来的都不太像原唱（可能是翻奏/片段/合集）——${top}。`
            + '如果是日文歌，把日文原名带上再试一次（千本樱 → 千本桜，恋爱循环 → 恋愛サーキュレーション）；'
            + '否则换个关键词，或者先跟对方确认要哪个版本。');
        }

        built = await buildParts(picked.item, { startSeconds: args.startSeconds, files: tempFiles });
        const total = built.parts.length;
        const name = picked.item.title.slice(0, 24);

        // 一段一条，按顺序发。某一段失败就停下 —— 已经发出去的不回滚，
        // 但要如实告诉模型发了几个、卡在第几个。
        for (let i = 0; i < total; i += 1) {
          await ctx.sender.sendMedia(
            ctx.chatKey,
            [{ type: 'record', data: { file: pathToFileURL(built.parts[i]).href } }],
            {
              label: total > 1 ? `[语音:${name} ${i + 1}/${total}]` : `[语音:${name}]`,
              dedupeKey: `bili-voice:${picked.item.bvid}:${built.plan.start}:${i}`
            }
          );
          sentParts = i + 1;
        }

        try {
          ctx.session?.sent?.push({ type: 'voice', text: `[语音:${name} ×${total}]`, delivered: 'voice' });
          ctx.emit?.('session-update', ctx.session?.id);
        } catch { /* 留档失败不影响已发出的消息 */ }

        const truncatedNote = built.plan.truncated
          ? `（这首歌太长，按设置只发了前 ${total} 段，没放完）`
          : '';
        result = ok({
          delivered: 'voice',
          title: picked.item.title,
          author: picked.item.author,
          bvid: picked.item.bvid,
          parts: total,
          partSeconds: built.plan.partSeconds,
          from: `${built.plan.start}s`,
          quality: built.quality,
          score: picked.score,
          note: total > 1
            ? `整首歌已分成 ${total} 条语音条依次发出（每条约 ${built.plan.partSeconds} 秒，从第 ${built.plan.start} 秒开始）${truncatedNote}。用一句话带过就行（比如「整首给你发过去了，分了几条」），不要逐条点评、不要复述歌词、不要贴 B 站链接。`
            : `语音条已发出（${built.plan.partSeconds} 秒，从第 ${built.plan.start} 秒开始）。用一句话带过就行，不要复述歌词、不要贴 B 站链接、也不用解释是怎么弄出来的。`
        });
      } catch (error) {
        result = sentParts > 0
          ? err(`发到第 ${sentParts + 1} 段时出错了：${error?.message ?? error}（前面 ${sentParts} 段已经发出去了，别当没发过）`)
          : err(`没发成：${error?.message ?? error}。如实告诉对方，不要假装发了。`);
      } finally {
        // 自动清理：发送成功、发送失败、下载到一半失败 —— 一律删。
        // 时机是"发送结束之后"：协议端读文件属于发送过程的一部分，提前删会发成空壳。
        if (tempFiles.length) {
          if (cfg().autoCleanup !== false) {
            const removed = cleanup(tempFiles, { sweep: true });
            log(`已清理临时文件 ${removed}/${tempFiles.length} 个`);
          } else {
            log(`autoCleanup 已关闭，文件留在：${tempFiles.join(', ')}`);
          }
        }
      }
      return result;
    }
  });
}

/** 纯函数导出，只给离线自测用（加载器不消费它）。 */
export const internals = { planParts, scoreItem, rankItems, cleanup, normalizeText };
