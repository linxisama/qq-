// 预算食谱（budget-recipe）。
//
// ── 为什么是技能（skills/）而不是插件（plugins/） ──────────────────────────
// 「50 块三个人、微辣，吃什么」这种请求，触发条件写在人话里，菜谱还得现编 ——
// 没有一条规则能写死成 if。插件是"条件满足必跑"，放这里就会静默失效。
// 所以做成技能：注册工具进模型的 function 列表，什么时候用由模型自己判断。
//
// ── 它真正解决的问题：别让模型心算 ────────────────────────────────────────
// 让模型裸算预算，几乎必然出这几种错：
//   · 三个人按一个人的量买（克数拍脑袋）
//   · 每一项价格都"合理"，加起来超预算 20 块
//   · 预算 50 却推荐牛腩，或者预算 200 还只给土豆白菜
// 所以这里把**算钱和算量**交给代码：按人均预算分档 → 每类食材给一个不许超的
// 上限 → 按人数换算成斤两 → 给一份便宜好用的选品参考。模型只负责按底稿写清单
// 和做法。数字是算出来的，不是编出来的。
//
// ── 输出为什么要写得这么"像底稿" ──────────────────────────────────────────
// 工具结果会原样进模型上下文。写成给人看的成品清单，模型会照抄一份（还会抄错行）；
// 写成"钱怎么分 / 买多少 / 怎么配 / 不要超"的约束，模型才会按约束自己写。
//
// ⚠️ 价格是各地菜场的参考区间（2025 年前后的常见水平），不是报价。提示词里要求
//    模型一律说"参考价、各地有浮动"，避免在群里报一个精确到分的假价格。
//
// ⚠️ 本文件在 resources/app 里，应用自动更新会覆盖；装回来即可。技能不写任何
//    运行期文件，所以没有数据目录要操心。

/** 配置读取器（setup 时由 api.config 注入，默认空对象）。 */
let cfg = () => ({});

/* ── 常量：预算档位 ──────────────────────────────────────────────────────── */

/**
 * 人均预算分档。ratios 是"可用预算"（预算的 95%，留 5% 机动）的分配比例，
 * grams 是**每人每天**的参考净重（生重）：
 *   staple 主食生重 / protein 肉蛋豆净重 / veg 蔬菜净重
 * 档位越低，主食占比越高、蛋白越少 —— 这是省钱菜谱的真实结构，不是拍脑袋。
 */
const TIERS = [
  {
    max: 6,
    label: '极紧',
    ratios: { protein: 0.30, veg: 0.20, staple: 0.35, seasoning: 0.05, extra: 0.10 },
    grams: { staple: 110, protein: 80, veg: 150 },
    tip: '这个预算做不了几荤几素，走「主食管饱 + 蛋/豆腐补蛋白 + 一个大锅菜」最实在。',
  },
  {
    max: 12,
    label: '偏紧',
    ratios: { protein: 0.35, veg: 0.20, staple: 0.28, seasoning: 0.05, extra: 0.12 },
    grams: { staple: 110, protein: 100, veg: 180 },
    tip: '一荤一素刚好，荤菜选鸡蛋、豆腐、鸡腿这类便宜的，量给足就不寒酸。',
  },
  {
    max: 20,
    label: '适中',
    ratios: { protein: 0.40, veg: 0.20, staple: 0.22, seasoning: 0.05, extra: 0.13 },
    grams: { staple: 115, protein: 120, veg: 200 },
    tip: '一荤一素一汤的标准配置，荤菜可以有一次真肉（五花、里脊、鸡腿）。',
  },
  {
    max: 35,
    label: '宽裕',
    ratios: { protein: 0.42, veg: 0.20, staple: 0.18, seasoning: 0.05, extra: 0.15 },
    grams: { staple: 110, protein: 130, veg: 220 },
    tip: '一荤一素一汤，荤菜能上鱼或牛肉，再加个凉拌。',
  },
  {
    max: 60,
    label: '充足',
    ratios: { protein: 0.42, veg: 0.20, staple: 0.15, seasoning: 0.05, extra: 0.18 },
    grams: { staple: 110, protein: 140, veg: 230 },
    tip: '两荤一素一汤没问题，海鲜也能搭一样。',
  },
  {
    max: Infinity,
    label: '随便吃',
    ratios: { protein: 0.45, veg: 0.18, staple: 0.12, seasoning: 0.05, extra: 0.20 },
    grams: { staple: 100, protein: 150, veg: 240 },
    tip: '预算已经不是限制了，按想吃的来；提醒一句别点太多、剩菜不划算。',
  },
];

/** 忌口 → 食材标签。只在 avoid 字段里匹配，不拿口味去误杀。 */
const AVOID_GROUPS = [
  { keys: ['牛'], tags: ['牛肉'] },
  { keys: ['羊'], tags: ['羊肉'] },
  { keys: ['猪', '五花', '里脊', '排骨', '肉末'], tags: ['猪肉'] },
  { keys: ['鸡'], tags: ['鸡肉'] },
  { keys: ['鸭'], tags: ['鸭肉'] },
  { keys: ['海鲜', '虾', '鱼', '蟹', '贝', '蛤', '鱿鱼'], tags: ['海鲜', '鱼', '虾'] },
  { keys: ['蛋', '鸡蛋'], tags: ['蛋'] },
  { keys: ['奶', '牛奶'], tags: ['奶'] },
  { keys: ['香菜'], tags: ['香菜'] },
  { keys: ['内脏', '肝', '肠'], tags: ['内脏'] },
  { keys: ['辣', '辣椒'], tags: ['辣'] },
];

/**
 * 食材库：name / tags / price（元 / 500g 或按 unit）/ note。
 * 价格取"菜市场中等品质"的区间，一线城市普遍上浮，所以提示词要求说参考价。
 */
const CATALOG = {
  protein: [
    { name: '鸡蛋', tags: ['蛋'], price: [5, 7], note: '约 8~10 个/斤，单个 0.6~0.9 元' },
    { name: '北豆腐', tags: ['豆制品'], price: [2.5, 4], note: '一盒约 1 斤，最便宜的蛋白' },
    { name: '豆干', tags: ['豆制品'], price: [5, 8] },
    { name: '鸡胸肉', tags: ['鸡肉'], price: [6, 9], note: '纯肉、不出水，按重量算最划算' },
    { name: '鸡腿（琵琶腿）', tags: ['鸡肉'], price: [8, 12], note: '带骨，出肉率约七成' },
    { name: '鸭腿', tags: ['鸭肉'], price: [8, 12] },
    { name: '猪肉末', tags: ['猪肉'], price: [11, 15], note: '炒菜、做馅都省' },
    { name: '五花肉', tags: ['猪肉'], price: [13, 18] },
    { name: '猪里脊', tags: ['猪肉'], price: [14, 20] },
    { name: '鸡翅中', tags: ['鸡肉'], price: [18, 24] },
    { name: '鲈鱼', tags: ['海鲜', '鱼'], price: [18, 26], note: '整条，杀好按条算' },
    { name: '冻虾仁', tags: ['海鲜', '虾'], price: [25, 35] },
    { name: '牛腩', tags: ['牛肉'], price: [32, 42] },
  ],
  veg: [
    { name: '大白菜', tags: [], price: [1.5, 3] },
    { name: '土豆', tags: [], price: [2, 3.5], note: '顶饿，和肉一起炖最省' },
    { name: '胡萝卜', tags: [], price: [2, 3.5] },
    { name: '洋葱', tags: [], price: [2, 3.5] },
    { name: '绿豆芽', tags: [], price: [2, 3] },
    { name: '冬瓜', tags: [], price: [2, 3], note: '做汤很省' },
    { name: '黄瓜', tags: [], price: [2.5, 5] },
    { name: '小油菜', tags: [], price: [2, 4] },
    { name: '西红柿', tags: [], price: [3, 6], note: '蛋花汤、番茄炒蛋的底' },
    { name: '青椒', tags: [], price: [3, 5] },
    { name: '茄子', tags: [], price: [3, 5] },
    { name: '西葫芦', tags: [], price: [3, 5] },
    { name: '生菜', tags: [], price: [3, 5] },
    { name: '芹菜', tags: [], price: [3, 5] },
    { name: '豆角', tags: [], price: [5, 8] },
    { name: '平菇', tags: [], price: [5, 8] },
    { name: '香菇', tags: [], price: [7, 10] },
  ],
  staple: [
    { name: '大米', tags: [], price: [2.5, 3.5] },
    { name: '面粉', tags: [], price: [3, 4.5] },
    { name: '馒头（现成）', tags: [], price: [4, 6], note: '约 4~5 个/斤，省火' },
    { name: '挂面', tags: [], price: [4, 6] },
    { name: '鲜玉米', tags: [], price: [2, 3], unit: '根' },
    { name: '红薯', tags: [], price: [2.5, 4] },
    { name: '年糕', tags: [], price: [5, 7] },
    { name: '粉丝', tags: [], price: [6, 9] },
  ],
  seasoning: [
    { name: '盐', tags: [], price: [2, 3] },
    { name: '白糖', tags: [], price: [4, 6] },
    { name: '淀粉', tags: [], price: [4, 6] },
    { name: '香醋', tags: [], price: [5, 8] },
    { name: '生抽', tags: [], price: [6, 10] },
    { name: '食用油', tags: [], price: [8, 12], note: '按 500ml 算' },
    { name: '豆瓣酱', tags: ['辣'], price: [8, 12] },
    { name: '小葱', tags: [], price: [3, 6], unit: '把' },
    { name: '大蒜', tags: [], price: [6, 10] },
    { name: '生姜', tags: [], price: [6, 10] },
    { name: '干辣椒', tags: ['辣'], price: [15, 25], note: '论两买，一次几块钱' },
    { name: '花椒', tags: ['辣'], price: [25, 40], note: '论两买，一次几块钱' },
  ],
};

/* ── 小工具 ─────────────────────────────────────────────────────────────── */

/** 从 "50元" / "50块" / "3人" 这类输入里取数。取不到返回 0。 */
function toNumber(value) {
  const m = String(value ?? '').match(/-?\d+(?:\.\d+)?/);
  return m ? Number(m[0]) : 0;
}

/** 向下取到 0.5 元，避免算出 "16.333 元" 这种不能照着买的数。 */
function halfYuan(n) {
  const v = Number(n);
  if (!Number.isFinite(v) || v <= 0) return 0;
  return Math.floor(v * 2) / 2;
}

function yuan(n) {
  const v = Math.round(Number(n) * 10) / 10;
  return Number.isInteger(v) ? String(v) : v.toFixed(1);
}

/** 克 → 斤（菜场按斤买，家里按克做）。 */
function jin(grams) {
  return (Math.max(0, Number(grams) || 0) / 500).toFixed(1);
}

function tierOf(perPerson) {
  return TIERS.find((t) => perPerson <= t.max) || TIERS[TIERS.length - 1];
}

/* ── 忌口与口味 ─────────────────────────────────────────────────────────── */

function splitTokens(raw) {
  return String(raw ?? '')
    .split(/[,，、;；/|+＋\s]+/)
    .map((s) => s.trim())
    .map((s) => s.replace(/^(不吃|不要|不能吃|别放|忌口|过敏|除了|受不了)/, '').trim())
    .filter(Boolean);
}

/** 忌口词 → 要排除的标签集合 + 是否素食。 */
function avoidRules(avoidRaw) {
  const tokens = splitTokens(avoidRaw);
  const tags = new Set();
  let vegan = false;
  let veganStrict = false;
  for (const t of tokens) {
    if (/纯素|全素|全斋|净素/.test(t)) { vegan = true; veganStrict = true; }
    else if (/素|斋|不吃肉|不吃荤/.test(t)) vegan = true;
    for (const g of AVOID_GROUPS) {
      if (g.keys.some((k) => t.includes(k) || k.includes(t))) g.tags.forEach((x) => tags.add(x));
    }
  }
  // 素食：把肉、海鲜全排掉；纯素连蛋奶一起排
  if (vegan) ['猪肉', '鸡肉', '鸭肉', '牛肉', '羊肉', '海鲜', '鱼', '虾'].forEach((x) => tags.add(x));
  return { tokens, tags, vegan, veganStrict };
}

/** 食材是否被忌口排除。 */
function isExcluded(item, avoid) {
  if (!avoid.tags.size) return false;
  if (item.tags.some((t) => avoid.tags.has(t))) return true;
  if (avoid.veganStrict && item.tags.includes('蛋')) return true;
  if (avoid.veganStrict && item.tags.includes('奶')) return true;
  return false;
}

/**
 * 口味 → 具体调味动作。给的是"下锅怎么做"，不是形容词 ——
 * 模型拿到「微辣」会写成"放点辣椒"，拿到"整根干辣椒提香、出锅捞掉"才会写对。
 */
function tasteAdvice(tasteRaw, avoid) {
  const t = String(tasteRaw ?? '').trim();
  const noChiliByAvoid = [...avoid.tags].includes('辣');

  const pick = (label, notes) => ({ label, notes });
  if (!t) return pick('家常', ['葱姜蒜 + 生抽打底，咸淡用盐调，别靠酱油堆咸']);
  // 「不辣」是口味而不是忌口，标签别写成「按忌口」，否则群友会觉得机器人在自作主张。
  if (/不辣|不要辣|不吃辣|一点辣都不|完全不吃辣/.test(t)) {
    return pick('不辣', ['不放任何辣椒、辣酱，用葱姜蒜和生抽提味', '想要「辣」的那种香气可以用白胡椒代替']);
  }
  if (noChiliByAvoid && /辣/.test(t)) {
    return pick(`${t}（忌口：不放辣）`, ['按忌口不放辣椒和辣酱，靠葱姜蒜、生抽提香', '如果是别人点的菜，提醒一句「这道别放辣」']);
  }

  if (/特辣|爆辣|变态辣|重辣/.test(t)) return pick(t, ['干辣椒 + 小米辣 + 一勺辣椒面，热油泼香', '配一道解辣的汤或凉菜，不然吃不下']);
  if (/中辣|香辣/.test(t)) return pick(t, ['干辣椒 4~6 个 + 花椒十来粒，小火焙香再下菜', '别放小米辣，辣度更稳、不容易翻车']);
  if (/微辣/.test(t)) return pick(t, ['豆瓣酱半勺或干辣椒 2~3 个提香', '辣椒整根放、出锅前捞掉，不吃辣的人也能吃']);
  if (/麻辣/.test(t)) return pick(t, ['花椒先下锅焙香，再下干辣椒，麻在前辣在后']);
  if (/清淡|不辣|少油|少盐/.test(t)) return pick(t, ['白灼、清蒸、炖，盐 + 生抽 + 葱姜就够', '油减到平时一半，出锅前再调味']);
  if (/酸甜|糖醋|番茄|茄汁/.test(t)) return pick(t, ['番茄打底，糖提鲜，醋最后放（早了不酸）', '糖醋菜先炸后裹汁，油别省太多']);
  if (/咖喱/.test(t)) return pick(t, ['咖喱块 2~3 小块，配土豆洋葱最省', '咖喱要小火化开，别大火糊底']);
  if (/蒜香|蒜蓉/.test(t)) return pick(t, ['蒜末分两次：一半爆香，一半出锅前放', '蒜蓉配绿叶菜、粉丝都好吃']);
  if (/咸鲜|家常|下饭|重口/.test(t)) return pick(t, ['葱姜蒜 + 生抽打底，咸淡用盐调', '重口可以加一勺豆瓣酱，但别再放盐']);
  if (/减脂|健身|低卡|低脂/.test(t)) return pick(t, ['少油少盐，蛋白质用水煮或煎，别油炸', '主食换一半粗粮，菜量给足才不饿']);
  if (/儿童|小孩|孩子|宝宝/.test(t)) return pick(t, ['不辣、少盐，菜切小块', '不放花椒和整颗辣椒，避免呛到']);
  return pick(t, [`按「${t}」来：先用葱姜蒜打底，再用生抽、盐、糖调到自己想要的味道`]);
}

/* ── 选品 ───────────────────────────────────────────────────────────────── */

function mid(price) {
  const [lo, hi] = Array.isArray(price) ? price : [0, 0];
  return (Number(lo) + Number(hi)) / 2 || 0;
}

function fmtPrice(item) {
  const [lo, hi] = item.price;
  const unit = item.unit ? `/${item.unit}` : '/500g';
  return `${item.name} ${lo}–${hi}${unit === '/500g' ? '' : unit}${item.note ? `（${item.note}）` : ''}`;
}

function suggestItems(kind, avoid, limit) {
  const list = (CATALOG[kind] || []).filter((it) => !isExcluded(it, avoid));
  return list.slice(0, Math.max(1, limit));
}

/* ── 主流程：算一份底稿 ─────────────────────────────────────────────────── */

/**
 * @param {{budget:number, people:number, taste?:string, avoid?:string, dishes?:number, settings?:object}} input
 * @returns {{ok:boolean, text:string}}
 */
export function buildPlan(input = {}) {
  const settings = input.settings || {};
  const budget = toNumber(input.budget);
  // ⚠️ 先拿原始值判空，再夹到 >=1。反过来写的话「没传人数」会被 Math.max(1, 0)
  //    悄悄补成 1 人 —— 三人份的菜算成一人份，清单直接少买一半，而且不报错。
  const peopleValue = toNumber(input.people);
  if (!(budget > 0)) {
    return { ok: false, text: '缺预算：问一句「准备花多少钱」，别自己假设。' };
  }
  if (!(peopleValue > 0)) {
    return { ok: false, text: '缺人数：问一句「几个人吃」，别自己假设。' };
  }
  const people = Math.max(1, Math.round(peopleValue));

  const perPerson = budget / people;
  const tier = tierOf(perPerson);
  const avoid = avoidRules(input.avoid);
  const taste = tasteAdvice(input.taste || settings.defaultTaste || '家常', avoid);
  const showPrice = settings.showPriceRange !== false;
  const maxItems = Math.min(8, Math.max(1, Math.round(toNumber(settings.maxItemsPerCategory)) || 5));

  // 可用预算 = 95%，向下取 0.5；剩下的当机动（称重、找零、临时加个葱）
  const spendCap = halfYuan(budget * 0.95);
  const amounts = {
    protein: halfYuan(spendCap * tier.ratios.protein),
    veg: halfYuan(spendCap * tier.ratios.veg),
    staple: halfYuan(spendCap * tier.ratios.staple),
    seasoning: halfYuan(spendCap * tier.ratios.seasoning),
  };
  const used = Object.values(amounts).reduce((a, b) => a + b, 0);
  amounts.extra = Math.max(0, Math.round((spendCap - used) * 10) / 10);
  const buffer = Math.max(0, Math.round((budget - spendCap) * 10) / 10);

  const stapleG = tier.grams.staple * people;
  const proteinG = tier.grams.protein * people;
  const vegG = tier.grams.veg * people;
  const oilG = 15 * people;
  const saltG = 5 * people;

  const dishCount = Math.min(5, Math.max(2,
    Math.round(toNumber(input.dishes)) >= 2 ? Math.round(toNumber(input.dishes))
      : people <= 2 ? 2 : people <= 4 ? 3 : people <= 6 ? 4 : 5));
  const dishPlan = people <= 2
    ? '一荤 + 一素（人少别做汤，浪费火和料）'
    : people <= 4
      ? '一荤 + 一素 + 一汤'
      : `一荤 + 一素 + 一汤 + 一道顶饱的（人多，${dishCount} 道、分两批炒）`;

  const lines = [];
  lines.push(`【预算食谱·计算底稿】预算 ${yuan(budget)} 元 ｜ ${people} 人 ｜ 口味：${taste.label}`
    + (avoid.tokens.length ? ` ｜ 忌口：${avoid.tokens.join('、')}` : ''));
  lines.push(`人均 ${yuan(perPerson)} 元 → 档位「${tier.label}」`);
  lines.push('');
  lines.push(`一、钱怎么分（合计 ${yuan(spendCap)} 元，另留 ${yuan(buffer)} 元机动）`);
  lines.push(`· 肉蛋豆 ${yuan(amounts.protein)} 元`);
  lines.push(`· 蔬菜 ${yuan(amounts.veg)} 元`);
  lines.push(`· 主食 ${yuan(amounts.staple)} 元`);
  lines.push(`· 调味 ${yuan(amounts.seasoning)} 元（只补家里缺的，别整瓶买）`);
  lines.push(`· 水果/饮品 ${yuan(amounts.extra)} 元（可砍，超预算先砍它）`);
  lines.push(`分配思路：${tier.tip}`);
  lines.push('');
  lines.push(`二、买多少（${people} 人份）`);
  lines.push(`· 主食：生米/面约 ${jin(stapleG)} 斤（${Math.round(stapleG)} 克，米饭约 ${people * 2} 小碗）`);
  lines.push(`· 肉蛋豆：净重约 ${jin(proteinG)} 斤（${Math.round(proteinG)} 克，带骨带壳的要多买三成）`);
  // 钱和量会打架：极紧预算下 4 个人只有 2 块钱蛋白，按"建议 320 克"写就是骗人。
  // 这里按最便宜的可用食材折算"最多买得起多少"，差多少如实说，别让模型硬凑数字。
  const cheapProtein = [...(CATALOG.protein || [])]
    .filter((it) => !isExcluded(it, avoid))
    .sort((a, b) => mid(a.price) - mid(b.price))[0];
  if (cheapProtein) {
    const needMoney = (proteinG / 500) * mid(cheapProtein.price);
    if (amounts.protein < needMoney * 0.75) {
      const canBuy = jin((amounts.protein / mid(cheapProtein.price)) * 500);
      lines.push(`  ↳ 但按这个预算只买得起约 ${canBuy} 斤${cheapProtein.name}，达不到建议量；`
        + '如实说蛋白偏少，用主食和青菜补，别把数量写成买不起的。');
    }
  }
  lines.push(`· 蔬菜：约 ${jin(vegG)} 斤（${Math.round(vegG)} 克）`);
  lines.push(`· 油盐：按平时用量，油约 ${Math.round(oilG)} 克、盐 ${Math.round(saltG)} 克`);
  lines.push('');
  lines.push('三、菜怎么配');
  lines.push(`· ${people} 人建议 ${dishCount} 道：${dishPlan}`);
  lines.push(`· 口味「${taste.label}」：${taste.notes.join('；')}`);
  // 荤素建议按**人均**蛋白预算判，不按总额：8 人 30 元和 2 人 30 元完全是两回事。
  const proteinPerPerson = amounts.protein / people;
  if (avoid.vegan) {
    lines.push(`· 素食：蛋白靠豆腐、豆干、豆皮${avoid.veganStrict ? '（纯素不放蛋）' : '和鸡蛋'}，量给足，别只炒青菜`);
  } else if (proteinPerPerson >= 8) {
    lines.push('· 蛋白够宽裕：一荤用真肉（鸡腿/五花/鱼任选），另用蛋或豆腐补一道，别全压在一种上');
  } else if (proteinPerPerson >= 4) {
    lines.push('· 蛋白偏紧：荤菜用鸡蛋 + 少量肉丝/肉末，配豆腐撑量，比整块肉划算');
  } else {
    lines.push('· 蛋白很紧：主力用鸡蛋和豆腐，肉只当调味（切丝或剁末），青菜和主食给足');
  }
  if (perPerson < 4) {
    lines.push('· 预算偏紧：先保主食和蛋白，水果饮品可以不要，别为了"丰盛"点贵菜');
  }
  lines.push('');
  lines.push('四、便宜好用的选品（参考价，元/500g，各地有浮动）');
  const groups = [
    ['肉蛋豆', 'protein'],
    ['蔬菜', 'veg'],
    ['主食', 'staple'],
    ['调味', 'seasoning'],
  ];
  for (const [label, key] of groups) {
    const items = suggestItems(key, avoid, maxItems);
    if (!items.length) continue;
    lines.push(`· ${label}：${showPrice ? items.map(fmtPrice).join('、') : items.map((i) => i.name).join('、')}`);
  }
  if (avoid.tokens.length) {
    lines.push(`（已按忌口「${avoid.tokens.join('、')}」排除相关食材，写清单时别再加回来）`);
  }
  lines.push('');
  lines.push('五、写清单时的硬要求');
  lines.push('1. 每项写「名称 + 数量（斤/个/把）+ 参考价」，同类的钱加起来不许超上面给的上限。');
  lines.push(`2. 清单结尾写合计，并说明没超过 ${yuan(budget)} 元预算；按上面五类的上限加总来核对。`);
  lines.push('3. 数量照上面给的斤两写，别按一个人的量写。');
  lines.push('4. 菜谱只用清单里的食材；调味写「家里有就用」，别要求买一堆用一次的调料。');
  lines.push('5. 发送用 send_message：清单一条、做法一条；纯文本，用 · 和 1) 2) 排版，不要 Markdown 表格和加粗。');

  return { ok: true, text: lines.join('\n') };
}

/* ── 入口 ───────────────────────────────────────────────────────────────── */

export function setup(api) {
  cfg = api.config;

  api.registerTool({
    id: 'plan',
    name: '预算食谱',
    description: '按预算、人数、口味算一份买菜底稿：每类食材能花多少钱、要买多少斤、菜怎么配、哪些食材便宜好用，还会自动排除忌口。'
      + '群友给出「X 元、Y 人、口味」并要买菜清单或菜谱时，**先调用它**再照着底稿写，不要自己心算预算（心算必超支）。'
      + '参数：budget 预算（元）、people 人数、taste 口味（微辣/中辣/清淡/酸甜/咖喱/减脂…）、'
      + 'avoid 忌口（不吃牛肉、不吃海鲜、吃素、小孩吃…）、dishes 想几道菜（可选）。',
    // ⚠️ category 必须是 tool-registry 的 CATEGORY_META 里那 8 类之一。
    // 写成 'utility' 能加载、能进模型工具表，但设置页「工具与技能」只渲染那 8 类，
    // 这个工具会**没有卡片**（既看不到也关不掉）—— 归类到 knowledge 最贴。
    category: 'knowledge',
    icon: '🛒',
    parameters: {
      type: 'object',
      properties: {
        budget: {
          type: 'number',
          description: '总预算，单位元。例如「50元」传 50，不要传「50元」这种字符串。',
        },
        people: {
          type: 'number',
          description: '吃饭的人数。例如「3人」传 3。',
        },
        taste: {
          type: 'string',
          description: '口味要求，例如「微辣」「不辣」「清淡」「酸甜」「家常」「减脂」。没说就留空，会按设置里的默认口味算。',
        },
        avoid: {
          type: 'string',
          description: '忌口，用逗号分隔，例如「不吃牛肉,不吃海鲜」「吃素」「孩子吃，不辣」。没有就留空。',
        },
        dishes: {
          type: 'number',
          description: '可选：想做几道菜。不填就按人数自动给（2~5 道）。',
        },
      },
      required: ['budget', 'people'],
    },
    async execute(_ctx, args) {
      const settings = cfg() || {};
      const plan = buildPlan({
        budget: args?.budget,
        people: args?.people,
        taste: args?.taste,
        avoid: args?.avoid,
        dishes: args?.dishes,
        settings,
      });
      if (!plan.ok) {
        return {
          content: `${plan.text}\n（先把这一项问清楚再算，不要自己替他定预算或人数。）`,
          isError: true,
        };
      }
      return { content: plan.text };
    },
  });
}

export function available() { return { ok: true }; }

/** 自测用：不启动机器人也能直接调这些函数。 */
export const internals = {
  buildPlan,
  tierOf,
  tasteAdvice,
  avoidRules,
  splitTokens,
  catalog: CATALOG,
  tiers: TIERS,
};
