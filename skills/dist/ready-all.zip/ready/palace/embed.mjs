/**
 * palace/embed.mjs —— 向量模型接入层（三种后端 + 自主部署）
 *
 *   hash   零依赖的 512 维哈希向量（字/词 bigram 哈希 + L2 归一化）。永远可用，用来兜底。
 *   local  本地 transformers.js + Xenova/bge-small-zh-v1.5（q8，512 维，中文效果好）。
 *          可以「自主部署」：自动 npm install 到 <DATA_DIR>/models，再自动下载模型权重到
 *          <DATA_DIR>/models/cache（首次会联网，之后完全离线）。
 *   openai 任何 OpenAI 兼容的 /v1/embeddings（apigoto、ollama、LM Studio、智谱……）。
 *          密钥只从环境变量读，绝不写进任何 json。
 *
 * 设计原则：
 *  - 任何一步失败都不抛给调用方，只把错误记进 status().error，检索自动退回关键词排序；
 *  - 模型权重 / npm 包都放在 data 目录，覆盖安装插件不会丢；
 *  - 维度写进 meta，检索时维度不一致的直接跳过（不会静默算错分）。
 */
import fs from 'node:fs';
import path from 'node:path';
import { createRequire } from 'node:module';
import { pathToFileURL } from 'node:url';
import { spawn } from 'node:child_process';

export const HASH_DIMS = 512;
export const DEFAULT_LOCAL_MODEL = 'Xenova/bge-small-zh-v1.5';
export const BACKENDS = ['hash', 'local', 'openai'];

/** 本机可能已经装好 transformers.js 的位置（DSH 那边装过就白捡） */
function transformersCandidates(modelsDir) {
  const out = [];
  if (process.env.PALACE_TRANSFORMERS) out.push(process.env.PALACE_TRANSFORMERS);
  out.push(path.join(modelsDir, 'node_modules', '@huggingface', 'transformers'));
  const dshHome = process.env.DSH_HOME || path.join(process.env.USERPROFILE || '', '.dsh');
  out.push(path.join(dshHome, 'profiles', 'desktop', 'node_modules', '@huggingface', 'transformers'));
  out.push(path.join(dshHome, 'profiles', 'web', 'node_modules', '@huggingface', 'transformers'));
  out.push(path.join(process.env.APPDATA || '', 'npm', 'node_modules', '@huggingface', 'transformers'));
  return out;
}

/** 把一个包目录解析成可 import 的入口文件 URL */
function resolvePackageEntry(pkgDir) {
  try {
    const pkgJson = JSON.parse(fs.readFileSync(path.join(pkgDir, 'package.json'), 'utf8'));
    const req = createRequire(path.join(pkgDir, 'package.json'));
    const tries = [];
    if (pkgJson.exports && typeof pkgJson.exports === 'object') {
      const root = pkgJson.exports['.'] || pkgJson.exports;
      for (const key of ['import', 'module', 'node', 'default', 'require']) {
        const v = typeof root === 'string' ? root : root?.[key];
        if (typeof v === 'string') tries.push(v);
      }
    }
    if (typeof pkgJson.module === 'string') tries.push(pkgJson.module);
    if (typeof pkgJson.main === 'string') tries.push(pkgJson.main);
    for (const rel of tries) {
      const abs = path.resolve(pkgDir, rel);
      if (fs.existsSync(abs)) return pathToFileURL(abs).href;
    }
    const resolved = req.resolve('@huggingface/transformers');
    return pathToFileURL(resolved).href;
  } catch (error) {
    return '';
  }
}

/* ───────────── hash 后端：零依赖 ───────────── */

function tokenize(text) {
  const s = String(text || '').toLowerCase();
  const tokens = [];
  for (const word of s.match(/[a-z0-9_]+/g) || []) tokens.push(word);
  const cjk = s.replace(/[^\u4e00-\u9fff]+/g, ' ');
  for (const run of cjk.split(/\s+/)) {
    if (!run) continue;
    for (let i = 0; i < run.length; i += 1) {
      tokens.push(run[i]);
      if (i + 1 < run.length) tokens.push(run.slice(i, i + 2));
    }
  }
  return tokens;
}

function hash32(str, seed) {
  let h = seed >>> 0;
  for (let i = 0; i < str.length; i += 1) {
    h ^= str.charCodeAt(i);
    h = Math.imul(h, 16777619) >>> 0;
  }
  return h >>> 0;
}

export function hashVector(text, dims = HASH_DIMS) {
  const vec = new Float32Array(dims);
  const tokens = tokenize(text);
  for (const token of tokens) {
    const h = hash32(token, 2166136261);
    const idx = h % dims;
    const sign = (h >>> 31) & 1 ? -1 : 1;
    vec[idx] += sign * (1 + Math.min(3, token.length - 1) * 0.5);
  }
  let norm = 0;
  for (let i = 0; i < dims; i += 1) norm += vec[i] * vec[i];
  norm = Math.sqrt(norm) || 1;
  for (let i = 0; i < dims; i += 1) vec[i] /= norm;
  return vec;
}

/* ───────────── 工厂 ───────────── */

export function createEmbedder({ dataDir, log = () => {} }) {
  const modelsDir = path.join(dataDir, 'models');
  const cacheDir = path.join(modelsDir, 'cache');
  const configFile = path.join(dataDir, 'embed.json');

  const state = {
    backend: 'hash',
    model: DEFAULT_LOCAL_MODEL,
    endpoint: 'https://api.openai.com/v1',
    apiKeyEnv: 'OPENAI_API_KEY',
    dims: HASH_DIMS,
    ready: false,
    loading: false,
    lastError: '',
    transformersPath: '',
    installed: false,
    modelCached: false,
    progress: ''
  };

  function persist() {
    try {
      fs.mkdirSync(dataDir, { recursive: true });
      fs.writeFileSync(configFile, JSON.stringify({
        backend: state.backend,
        model: state.model,
        endpoint: state.endpoint,
        apiKeyEnv: state.apiKeyEnv
      }, null, 2), 'utf8');
    } catch (error) {
      log('warn', `写入 embed.json 失败：${error.message}`);
    }
  }

  function loadConfig() {
    try {
      if (!fs.existsSync(configFile)) return;
      const raw = JSON.parse(fs.readFileSync(configFile, 'utf8'));
      if (BACKENDS.includes(raw.backend)) state.backend = raw.backend;
      if (typeof raw.model === 'string' && raw.model.trim()) state.model = raw.model.trim();
      if (typeof raw.endpoint === 'string' && raw.endpoint.trim()) state.endpoint = raw.endpoint.trim().replace(/\/+$/, '');
      if (typeof raw.apiKeyEnv === 'string' && raw.apiKeyEnv.trim()) state.apiKeyEnv = raw.apiKeyEnv.trim();
    } catch (error) {
      log('warn', `读取 embed.json 失败：${error.message}`);
    }
  }

  function configure(patch = {}) {
    if (patch.backend && BACKENDS.includes(patch.backend)) state.backend = patch.backend;
    if (typeof patch.model === 'string' && patch.model.trim()) state.model = patch.model.trim();
    if (typeof patch.endpoint === 'string' && patch.endpoint.trim()) state.endpoint = patch.endpoint.trim().replace(/\/+$/, '');
    if (typeof patch.apiKeyEnv === 'string') state.apiKeyEnv = patch.apiKeyEnv.trim() || state.apiKeyEnv;
    state.ready = false;
    extractor = null;
    persist();
    return status();
  }

  /* ── local 后端 ── */

  let extractor = null;
  let transformersEntry = '';

  function findTransformers() {
    for (const dir of transformersCandidates(modelsDir)) {
      if (!fs.existsSync(path.join(dir, 'package.json'))) continue;
      const entry = resolvePackageEntry(dir);
      if (entry) return { dir, entry };
    }
    return null;
  }

  async function loadLocal() {
    if (extractor) return true;
    const found = findTransformers();
    if (!found) {
      state.lastError = '找不到 transformers.js（可以点「自主部署」自动安装，或设置环境变量 PALACE_TRANSFORMERS）';
      return false;
    }
    transformersEntry = found.entry;
    state.transformersPath = found.dir;
    state.progress = '正在加载推理引擎…';
    const mod = await import(found.entry);
    const env = mod.env || {};
    try {
      env.cacheDir = cacheDir;
      env.allowRemoteModels = true;
      env.allowLocalModels = true;
      // 国内直连 huggingface.co 经常超时：默认走镜像，可用 PALACE_HF_ENDPOINT / HF_ENDPOINT 覆盖
      const mirror = (process.env.PALACE_HF_ENDPOINT || process.env.HF_ENDPOINT || 'https://hf-mirror.com').replace(/\/+$/, '');
      if (typeof env.remoteHost === 'string' || 'remoteHost' in env) env.remoteHost = mirror;
      env.remoteHost = mirror;
      // onnxruntime-node 在 Windows 上默认多线程会偶发卡死，限制成 1 更稳
      if (env.backends?.onnx?.wasm) env.backends.onnx.wasm.numThreads = 1;
    } catch { /* env 是只读快照时忽略 */ }
    fs.mkdirSync(cacheDir, { recursive: true });
    state.progress = `正在加载模型 ${state.model}（首次会下载权重）…`;
    extractor = await mod.pipeline('feature-extraction', state.model, { dtype: 'q8', cache_dir: cacheDir });
    state.progress = '';
    state.dims = 512;
    return true;
  }

  async function embedLocal(texts) {
    const out = await extractor(texts, { pooling: 'cls', normalize: true });
    const list = typeof out.tolist === 'function' ? out.tolist() : out;
    return list.map((row) => Float32Array.from(row));
  }

  /* ── openai 兼容后端 ── */

  async function embedOpenAI(texts) {
    const key = process.env[state.apiKeyEnv] || '';
    if (!key) throw new Error(`环境变量 ${state.apiKeyEnv} 为空（密钥只从环境变量读，不落盘）`);
    const res = await fetch(`${state.endpoint}/embeddings`, {
      method: 'POST',
      headers: { 'content-type': 'application/json', authorization: `Bearer ${key}` },
      body: JSON.stringify({ model: state.model, input: texts })
    });
    if (!res.ok) throw new Error(`embedding HTTP ${res.status}: ${(await res.text()).slice(0, 200)}`);
    const json = await res.json();
    const rows = (json.data || []).sort((a, b) => a.index - b.index);
    return rows.map((r) => Float32Array.from(r.embedding || []));
  }

  /* ── 统一入口 ── */

  async function ensure() {
    if (state.backend === 'hash') {
      state.dims = HASH_DIMS;
      state.ready = true;
      state.lastError = '';
      return true;
    }
    if (state.ready) return true;
    if (state.loading) {
      while (state.loading) await new Promise((r) => setTimeout(r, 120));
      return state.ready;
    }
    state.loading = true;
    try {
      if (state.backend === 'local') {
        const ok = await loadLocal();
        if (!ok) return false;
        const probe = await embedLocal(['维度探测']);
        state.dims = probe[0]?.length || 512;
      } else {
        const probe = await embedOpenAI(['维度探测']);
        state.dims = probe[0]?.length || 1536;
      }
      state.ready = true;
      state.lastError = '';
      log('info', `向量后端就绪：${state.backend} / ${state.model}（${state.dims} 维）`);
      return true;
    } catch (error) {
      state.ready = false;
      state.lastError = String(error?.message || error);
      state.progress = '';
      log('warn', `向量后端不可用（检索退回关键词排序）：${state.lastError}`);
      return false;
    } finally {
      state.loading = false;
    }
  }

  async function embedBatch(texts) {
    const list = (Array.isArray(texts) ? texts : [texts]).map((t) => String(t || '').slice(0, 2000));
    if (!list.length) return [];
    if (state.backend === 'hash') return list.map((t) => hashVector(t));
    const ok = await ensure();
    if (!ok) return list.map((t) => hashVector(t));
    try {
      if (state.backend === 'local') return await embedLocal(list);
      return await embedOpenAI(list);
    } catch (error) {
      state.lastError = String(error?.message || error);
      log('warn', `向量计算失败，本条退回哈希向量：${state.lastError}`);
      return list.map((t) => hashVector(t));
    }
  }

  /* ── 自主部署 ── */

  function npmBin() {
    const nodeDir = path.dirname(process.execPath);
    for (const name of ['npm.cmd', 'npm']) {
      const p = path.join(nodeDir, name);
      if (fs.existsSync(p)) return p;
    }
    return process.platform === 'win32' ? 'npm.cmd' : 'npm';
  }

  async function installTransformers(onProgress = () => {}) {
    fs.mkdirSync(modelsDir, { recursive: true });
    const pkgFile = path.join(modelsDir, 'package.json');
    if (!fs.existsSync(pkgFile)) {
      fs.writeFileSync(pkgFile, JSON.stringify({ name: 'palace-models', private: true, version: '1.0.0' }, null, 2), 'utf8');
    }
    onProgress('正在安装 @huggingface/transformers（约 60MB，视网速几分钟）…');
    const npm = npmBin();
    state.progress = 'npm install @huggingface/transformers …';
    await new Promise((resolve, reject) => {
      const child = spawn(npm, ['install', '@huggingface/transformers', '--no-audit', '--no-fund', '--loglevel=error'], {
        cwd: modelsDir,
        env: { ...process.env, npm_config_update_notifier: 'false' },
        windowsHide: true,
        stdio: ['ignore', 'pipe', 'pipe']
      });
      let tail = '';
      const collect = (buf) => { tail = (tail + buf.toString()).slice(-400); };
      child.stdout?.on('data', collect);
      child.stderr?.on('data', collect);
      child.on('exit', (code) => {
        state.progress = '';
        if (code === 0) resolve();
        else reject(new Error(`npm install 退出码 ${code}：${tail.trim().slice(-200)}`));
      });
      child.on('error', reject);
    });
    state.installed = true;
    onProgress('依赖装好了，开始加载模型…');
    extractor = null;
    state.ready = false;
    const ok = await ensure();
    if (!ok) throw new Error(state.lastError || '模型加载失败');
    onProgress(`部署完成：${state.model}（${state.dims} 维）`);
    return status();
  }

  async function setup({ install = true, onProgress = () => {} } = {}) {
    if (state.backend === 'hash') {
      const ok = await ensure();
      return { ...status(), ready: ok };
    }
    if (state.backend === 'openai') {
      const ok = await ensure();
      return { ...status(), ready: ok };
    }
    const found = findTransformers();
    if (!found && !install) throw new Error('本机没有 transformers.js，需要先自主部署（install=true）');
    if (!found) return installTransformers(onProgress);
    const ok = await ensure();
    return { ...status(), ready: ok };
  }

  function status() {
    let modelCached = false;
    try {
      const root = path.join(cacheDir);
      if (fs.existsSync(root)) {
        const stack = [root];
        while (stack.length) {
          const dir = stack.pop();
          for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
            const p = path.join(dir, entry.name);
            if (entry.isDirectory()) stack.push(p);
            else if (/\.onnx$/i.test(entry.name)) { modelCached = true; stack.length = 0; break; }
          }
        }
      }
    } catch { /* 忽略 */ }
    return {
      backend: state.backend,
      model: state.model,
      dims: state.dims,
      ready: state.ready,
      loading: state.loading,
      error: state.lastError,
      progress: state.progress,
      endpoint: state.backend === 'openai' ? state.endpoint : '',
      apiKeyEnv: state.backend === 'openai' ? state.apiKeyEnv : '',
      apiKeyPresent: state.backend === 'openai' ? Boolean(process.env[state.apiKeyEnv]) : false,
      transformersPath: state.transformersPath,
      installed: Boolean(findTransformers()),
      modelCached: modelCached || state.backend === 'hash',
      modelsDir,
      cacheDir
    };
  }

  loadConfig();
  if (state.backend === 'hash') {
    state.ready = true;
    state.dims = HASH_DIMS;
  }

  return { configure, ensure, embedBatch, setup, status, hashVector, paths: { modelsDir, cacheDir, configFile } };
}

/* ───────────── Float32 ↔ BLOB ───────────── */

export function vecToBlob(vec) {
  const f32 = vec instanceof Float32Array ? vec : Float32Array.from(vec);
  return Buffer.from(f32.buffer, f32.byteOffset, f32.byteLength);
}

export function blobToVec(blob) {
  if (!blob) return null;
  const buf = Buffer.isBuffer(blob) ? blob : Buffer.from(blob);
  if (!buf.byteLength || buf.byteLength % 4 !== 0) return null;
  return new Float32Array(buf.buffer.slice(buf.byteOffset, buf.byteOffset + buf.byteLength));
}

export function cosine(a, b) {
  if (!a || !b || a.length !== b.length) return 0;
  let dot = 0;
  let na = 0;
  let nb = 0;
  for (let i = 0; i < a.length; i += 1) {
    dot += a[i] * b[i];
    na += a[i] * a[i];
    nb += b[i] * b[i];
  }
  if (!na || !nb) return 0;
  return dot / (Math.sqrt(na) * Math.sqrt(nb));
}
