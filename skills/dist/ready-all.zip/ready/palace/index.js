/**
 * 记忆宫殿（palace）—— 洛版 QQ Agent 插件
 *
 * 结构：
 *   index.js   本文件：注册 19 个 palace_* 工具 + 自动召回注入 + 托管 sidecar
 *   service.mjs sidecar：Node 22.5+ 进程，用 node:sqlite 打开与 DSH 完全同构的库
 *   skill.json  清单/设置项/提示词段
 *
 * 为什么要有 sidecar：洛版内核跑在 Electron 33（Node 20），没有 node:sqlite；
 * 而记忆宫殿用的 SQLite（FTS5 / 复习调度 / 事实链）必须 Node 22.5+ 才能直接读。
 * 数据文件与 DSH 的 engram 库**格式完全一致**，DSH 的 .db 拷过来就能用。
 */

import fs from 'node:fs';
import path from 'node:path';
import { spawn, spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const APP_ROOT = path.resolve(HERE, '..', '..');
const SERVICE_FILE = path.join(HERE, 'service.mjs');
const DATA_DIR = process.env.QQ_AGENT_DATA_DIR
  ? path.resolve(process.env.QQ_AGENT_DATA_DIR)
  : path.resolve(APP_ROOT, '..', '..', 'data');

const DEFAULTS = {
  serviceUrl: 'http://127.0.0.1:3401',
  nodePath: '',
  dbDir: '',
  autoStart: true,
  inject: true,
  injectChars: 2000,
  recallLimit: 5,
  scope: 'all',
  timeoutMs: 20000,
  // 向量检索（自主部署）：local = sidecar 里跑 transformers.js 本地模型（离线可用）
  // endpoint = 接任意 OpenAI 兼容的 /v1/embeddings；off = 只用关键词+bigram
  embedBackend: 'local',
  embedModel: 'Xenova/bge-small-zh-v1.5',
  embedEndpoint: '',
  embedApiKeyEnv: '',
  hfEndpoint: 'https://huggingface.co',
  httpProxy: ''
};

let apiRef = null;
let settingsRef = { ...DEFAULTS };
let child = null;
let starting = null;
let lastInject = { at: 0, chars: 0, hits: 0, error: '' };
const injectLog = [];   // 最近 10 次召回，给面板看"它在拿什么记忆回答"

function settings() {
  if (!apiRef) return settingsRef;
  try {
    const live = apiRef.config() || {};
    settingsRef = { ...DEFAULTS, ...live };
  } catch { /* 读不到就用上一次的 */ }
  return settingsRef;
}

function log(level, message, detail) {
  const line = `[palace] ${message}${detail ? ' ' + (typeof detail === 'string' ? detail : JSON.stringify(detail)) : ''}`;
  try {
    if (level === 'error') apiRef?.error?.(line);
    else if (level === 'warn') apiRef?.warn?.(line);
    else apiRef?.log?.(line);
  } catch { /* 日志失败不影响主流程 */ }
}

/* ────────────────────── Node 发现 & sidecar 托管 ────────────────────── */

function versionOk(bin) {
  try {
    const out = spawnSync(bin, ['-v'], { encoding: 'utf8', timeout: 4000, windowsHide: true });
    if (out.status !== 0) return false;
    const m = /v(\d+)\.(\d+)\./.exec(String(out.stdout || '').trim());
    if (!m) return false;
    const major = Number(m[1]);
    const minor = Number(m[2]);
    return major > 22 || (major === 22 && minor >= 5);
  } catch {
    return false;
  }
}

function findNode() {
  const s = settings();
  const candidates = [
    s.nodePath,
    process.env.PALACE_NODE,
    process.env.QQ_AGENT_NODE,
    'C:\\Users\\Administrator\\.local\\node-v24.22.0\\node.exe',
    'C:\\Users\\Administrator\\.dsh\\dsh-runtimes\\dsh-primary-runtime\\dependencies\\node\\bin\\node.exe',
    'C:\\Program Files\\nodejs\\node.exe',
    'node'
  ].filter(Boolean);
  for (const bin of candidates) {
    if (bin !== 'node' && !fs.existsSync(bin)) continue;
    if (versionOk(bin)) return bin;
  }
  return '';
}

function dbDir() {
  const s = settings();
  return s.dbDir ? path.resolve(s.dbDir) : path.join(DATA_DIR, 'palace', 'db');
}

async function health(url, timeoutMs = 900) {
  try {
    const res = await fetch(`${url.replace(/\/$/, '')}/health`, { signal: AbortSignal.timeout(timeoutMs) });
    if (!res.ok) return null;
    const json = await res.json();
    return json?.ok ? json.value : null;
  } catch {
    return null;
  }
}

/**
 * 找系统代理（Windows 注册表 → 环境变量）。
 *
 * 为什么需要：本地向量模型第一次要把权重从 HuggingFace 拉下来（几十 MB）。
 * 这台机器上 node 直连 huggingface.co 会 Connect Timeout，而走系统代理是通的；
 * transformers.js 用 undici 的 fetch，只有设置了 NODE_USE_ENV_PROXY=1 +
 * HTTPS_PROXY 才会走代理，所以必须在**拉起 sidecar 时**就把环境变量传进去。
 */
let proxyCache = null;
function systemProxy() {
  if (proxyCache !== null) return proxyCache;
  proxyCache = '';
  const fromEnv = String(process.env.HTTPS_PROXY || process.env.https_proxy || process.env.HTTP_PROXY || process.env.http_proxy || '').trim();
  if (fromEnv) {
    proxyCache = fromEnv;
    return proxyCache;
  }
  if (process.platform !== 'win32') return proxyCache;
  try {
    const key = 'HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Internet Settings';
    const out = spawnSync('reg', ['query', key], { encoding: 'utf8', timeout: 4000, windowsHide: true });
    const text = String(out.stdout || '');
    const enabled = /ProxyEnable\s+REG_DWORD\s+0x1/i.test(text);
    const server = /ProxyServer\s+REG_SZ\s+([^\r\n]+)/i.exec(text);
    if (enabled && server) {
      const raw = server[1].trim();
      const hostPort = raw.includes('=') ? (/https=([^;\s]+)/i.exec(raw)?.[1] || /http=([^;\s]+)/i.exec(raw)?.[1] || '') : raw;
      if (hostPort) proxyCache = /^[a-z]+:\/\//i.test(hostPort) ? hostPort : `http://${hostPort}`;
    }
  } catch { /* 读不到就当没代理 */ }
  return proxyCache;
}

function embedEnv() {
  const s = settings();
  const env = {
    PALACE_EMBED_BACKEND: s.embedBackend || 'local',
    PALACE_EMBED_MODEL: s.embedModel || '',
    PALACE_EMBED_ENDPOINT: s.embedEndpoint || '',
    PALACE_EMBED_API_KEY_ENV: s.embedApiKeyEnv || '',
    PALACE_HF_ENDPOINT: s.hfEndpoint || 'https://huggingface.co'
  };
  const proxy = String(s.httpProxy || '').trim() || systemProxy();
  if (proxy) {
    env.NODE_USE_ENV_PROXY = '1';
    env.HTTPS_PROXY = proxy;
    env.HTTP_PROXY = proxy;
    env.https_proxy = proxy;
    env.http_proxy = proxy;
  }
  return env;
}

async function ensureService() {
  const s = settings();
  const url = s.serviceUrl;
  if (await health(url)) return url;
  if (!s.autoStart) throw new Error(`记忆宫殿服务没在跑（${url}），而且设置里关掉了自动拉起`);
  if (starting) {
    await starting;
    return url;
  }
  starting = (async () => {
    const node = findNode();
    if (!node) throw new Error('找不到 Node 22.5+ 可执行文件（node:sqlite 需要它）。请在插件设置里填「Node 路径」。');
    if (!fs.existsSync(SERVICE_FILE)) throw new Error(`sidecar 文件缺失：${SERVICE_FILE}`);
    const port = Number(new URL(url).port || 3401);
    const dir = dbDir();
    fs.mkdirSync(dir, { recursive: true });
    log('info', `拉起 sidecar：${node} · 端口 ${port} · 库 ${dir}`);
    child = spawn(node, [SERVICE_FILE], {
      env: { ...process.env, PALACE_DB_DIR: dir, PALACE_PORT: String(port), PALACE_HOST: '127.0.0.1', PALACE_TOKEN: '', ...embedEnv() },
      stdio: 'ignore',
      windowsHide: true,
      detached: false
    });
    child.on('exit', (code, signal) => {
      log('warn', `sidecar 退出 code=${code} signal=${signal || ''}`);
      child = null;
    });
    child.on('error', (error) => log('error', 'sidecar 启动失败', error.message));
    const deadline = Date.now() + 12000;
    while (Date.now() < deadline) {
      await new Promise((r) => setTimeout(r, 400));
      if (await health(url)) return url;
    }
    throw new Error(`sidecar 12 秒内没起来（端口 ${port}，库 ${dir}）`);
  })();
  try {
    return await starting;
  } finally {
    starting = null;
  }
}

async function rpc(op, args = {}) {
  const s = settings();
  const url = await ensureService();
  let res;
  try {
    res = await fetch(`${url.replace(/\/$/, '')}/rpc`, {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ op, args }),
      signal: AbortSignal.timeout(Math.max(2000, Number(s.timeoutMs) || 20000))
    });
  } catch (error) {
    throw new Error(`连不上记忆宫殿服务（${url}）：${error.message}`);
  }
  let json;
  try {
    json = await res.json();
  } catch {
    throw new Error(`记忆宫殿返回了非 JSON（HTTP ${res.status}）`);
  }
  lastHealthyAt = Date.now();
  if (!json.ok) {
    const err = json.error || {};
    const code = err.code ? `（${err.code}）` : '';
    throw new Error(`${err.message || '记忆宫殿调用失败'}${code}`);
  }
  return json.value;
}

/* ────────────────────── 工具定义 ────────────────────── */

const S = (text) => ({ type: 'string', description: text });
const N = (text) => ({ type: 'number', description: text });
const B = (text) => ({ type: 'boolean', description: text });

const TOOLS = [
  {
    id: 'save',
    description: '把一条长期记忆写进记忆宫殿（一句话一条）。kind 选 fact/preference/decision/episode/skill；重复内容会自动并入旧条目。可给门牌 placard、关联实体 entities，或一次传 items 批量（≤10）。',
    parameters: {
      type: 'object',
      properties: {
        content: S('一句话记忆正文（完整、自含，不要写"如上"这类指代）'),
        kind: { type: 'string', enum: ['fact', 'preference', 'decision', 'episode', 'skill'], description: '记忆种类' },
        importance: N('重要性 0-1，默认 0.55'),
        placard: S('门牌：4-30 字、带日期锚点的短铭牌，便于日后辨认'),
        entities: { type: 'array', items: { type: 'string' }, description: '涉及的人/项目/工具名' },
        items: { type: 'array', items: { type: 'object' }, description: '批量写入，每项 {content,kind,importance,placard,entities}' }
      }
    },
    run: (args) => rpc('save', { ...args, scope: args.scope || 'user' })
  },
  {
    id: 'search',
    description: '语义+关键词混合检索记忆。返回 hits（含 ref 与 id）和 batchId；下一步必须用 palace_assess 判定证据是否够，再作答。',
    parameters: {
      type: 'object',
      properties: {
        query: S('要查什么（自然语言即可）'),
        limit: N('返回条数，默认 8（最大 30）'),
        scope: S('all / user / shared / project-qq'),
        room: S('只查某个房间（如 fact、preference、episode）')
      },
      required: ['query']
    },
    run: (args) => rpc('search', { ...args, scope: args.scope || settings().scope || 'all' })
  },
  {
    id: 'assess',
    description: '证据门：检索之后、作答之前，判定检索结果够不够。sufficient=true 必须同时满足：你声称充足 + 至少引用一条本批次的 ref + nextStrategy="answer"。伪造 ref 会被拒。',
    parameters: {
      type: 'object',
      properties: {
        batchId: S('palace_search 返回的 batchId'),
        sufficient: B('证据是否足以回答'),
        evidenceRefs: { type: 'array', items: { type: 'string' }, description: '本批次里的 ref，最多 8 条' },
        missing: S('缺什么维度的信息（≤160 字）'),
        nextStrategy: { type: 'string', enum: ['answer', 'search_keyword', 'search_room', 'search_timeline', 'ask_user', 'stop'] }
      },
      required: ['batchId', 'sufficient']
    },
    run: (args) => rpc('assess', args)
  },
  {
    id: 'examine',
    description: '按 id 取记忆全文（含房间/门牌/实体/相关事实）。只对已经拿到的 id 用，别盲查。',
    parameters: { type: 'object', properties: { ids: { type: 'array', items: { type: 'string' }, description: '最多 16 个 id' } }, required: ['ids'] },
    run: (args) => rpc('examine', args)
  },
  {
    id: 'update',
    description: '修正一条记忆：写入新内容并保留修订链（旧版本不会丢）。',
    parameters: {
      type: 'object',
      properties: { id: S('要改的记忆 id'), content: S('修正后的完整正文'), kind: S('可选：顺带改种类'), placard: S('可选：换门牌') },
      required: ['id', 'content']
    },
    run: (args) => rpc('update', args)
  },
  {
    id: 'forget',
    description: '闭馆（软删）：必须先想清楚三问再调——为什么关、影响谁、还有用吗。',
    parameters: {
      type: 'object',
      properties: { id: S('条目 id'), reason: S('为什么关'), affects: S('影响哪些条目/人/项目'), stillUseful: S('遗留价值：怎么考古/回滚') },
      required: ['id', 'reason', 'affects', 'stillUseful']
    },
    run: (args) => rpc('forget', args)
  },
  {
    id: 'report',
    description: '回报一条记忆的使用效果（success/failure），或传 grade:0-5 做复习自评（SM-2 会算下次复习时间）。',
    parameters: {
      type: 'object',
      properties: { id: S('条目 id'), outcome: { type: 'string', enum: ['success', 'failure'] }, grade: N('回忆质量 0-5（与 outcome 二选一）') },
      required: ['id']
    },
    run: (args) => rpc('report', args)
  },
  {
    id: 'review_queue',
    description: '今日待回忆队列：只给房间与门牌线索，不给正文（先自己回想，再用 palace_review 揭示）。',
    parameters: { type: 'object', properties: { limit: N('最多几条，默认 10') } },
    run: (args) => rpc('review_queue', args)
  },
  {
    id: 'review',
    description: '审计一条记忆：全文、房间、实体、修订史、事实链、关联边和最近操作。',
    parameters: { type: 'object', properties: { id: S('条目 id') }, required: ['id'] },
    run: (args) => rpc('review', args)
  },
  {
    id: 'facts',
    description: '实体事实链：查询时给 entity 或 entityId（可选 asOf 看当时、includeInvalid 展开全链）；写入时传 facts 数组，每项 {entity 或 entityId, content, replaces?}——修正旧事实用 replaces，不要另存矛盾事实。',
    parameters: {
      type: 'object',
      properties: {
        entity: S('实体名'),
        entityId: S('实体 id（优先）'),
        asOf: S('时点回看：ISO 日期或毫秒时间戳'),
        includeInvalid: B('true = 连已失效的事实一起看'),
        limit: N('返回条数，默认 20'),
        facts: { type: 'array', items: { type: 'object' }, description: '写入模式：每项 {entity|entityId, content, replaces?}' }
      }
    },
    run: (args) => rpc('facts', args)
  },
  {
    id: 'neighbors',
    description: '走廊漫步：从一条记忆出发，走 1-3 跳关联边，看附近还有什么。',
    parameters: { type: 'object', properties: { id: S('起点 id'), depth: N('跳数 1-3，默认 1') }, required: ['id'] },
    run: (args) => rpc('neighbors', args)
  },
  {
    id: 'timeline',
    description: '按时间倒序浏览记忆（可按主题/日期过滤），order="tour" 改为按固定巡游路线走。',
    parameters: {
      type: 'object',
      properties: { since: N('起始时间戳'), until: N('结束时间戳'), topic: S('主题子串'), limit: N('条数，默认 20'), order: { type: 'string', enum: ['time', 'tour'] } }
    },
    run: (args) => rpc('timeline', args)
  },
  {
    id: 'episode_timeline',
    description: 'episode 情景记忆时间线：按来源会话分组，适合回答"那天/那段时间我们做了什么"。',
    parameters: { type: 'object', properties: { since: N('起始时间戳'), until: N('结束时间戳'), sessionId: S('只看某个会话'), limit: N('条数，默认 100') } },
    run: (args) => rpc('episode_timeline', args)
  },
  {
    id: 'tour',
    description: '记忆导览：mode="fixed" 沿固定桩位路线走全宫；mode="thematic"（默认）按主题规划几站。',
    parameters: {
      type: 'object',
      properties: { mode: { type: 'string', enum: ['fixed', 'thematic'] }, query: S('thematic 模式的主题'), maxStops: N('最多几站，默认 6（fixed 为 20）') }
    },
    run: (args) => rpc('tour', args)
  },
  {
    id: 'stats',
    description: '记忆库统计：条目数、状态/种类分布、房间目录（房名+桩位+最新门牌）、事实/实体/日志数量、待复习数。',
    parameters: { type: 'object', properties: {} },
    run: () => rpc('stats', {})
  },
  {
    id: 'audit_forgotten',
    description: '闭馆考古：列出已归档条目和它们的墓志铭，复核过去的遗忘是否得当。',
    parameters: { type: 'object', properties: { limit: N('条数，默认 20') } },
    run: (args) => rpc('audit_forgotten', args)
  },
  {
    id: 'profile',
    description: '会话开头注入的画像（curated block）：action=view 查看/版本；action=edit 编辑（带 expectedVersion 防冲突）；action=rollback 回滚到某个版本。',
    parameters: {
      type: 'object',
      properties: {
        action: { type: 'string', enum: ['view', 'edit', 'rollback'] },
        content: S('edit 时的新画像全文'),
        expectedVersion: N('edit 时的乐观锁版本'),
        toVersion: N('rollback 的目标版本'),
        scope: S('默认 user')
      },
      required: ['action']
    },
    run: (args) => rpc('profile', { scope: 'user', ...args })
  },
  {
    id: 'export',
    description: '导出记忆库（json 或 markdown 文件，落在 <数据目录>/palace/exports）。redactedView=true 输出脱敏预览。',
    parameters: {
      type: 'object',
      properties: { format: { type: 'string', enum: ['json', 'markdown'] }, redactedView: B('true = 脱敏 + 截断预览') }
    },
    run: (args) => rpc('export', args)
  }
];

/* ────────────────────── 钩子：自动召回 ────────────────────── */

function lastUserText(messages) {
  for (let i = messages.length - 1; i >= 0; i--) {
    const m = messages[i];
    if (m?.role !== 'user') continue;
    const content = m.content;
    if (typeof content === 'string') return content;
    if (Array.isArray(content)) {
      return content.filter((p) => p?.type === 'text').map((p) => p.text).join(' ').trim();
    }
  }
  return '';
}

TOOLS.push({
  id: 'vector',
  description: '向量检索维护：status 看当前后端/模型/覆盖率；configure 切换后端（local 本地模型 / endpoint OpenAI 兼容 / off 关掉）；setup 现在就把模型下下来（首次几十 MB，走系统代理）；reindex 把还没向量化的记忆补上（可反复调，一次 40 条以内不会超时）。',
  parameters: {
    type: 'object',
    properties: {
      action: { type: 'string', enum: ['status', 'configure', 'setup', 'reindex'], description: '要做什么' },
      backend: { type: 'string', enum: ['local', 'endpoint', 'off'], description: 'configure 时必填' },
      model: S('local 后端的模型 id，默认 Xenova/bge-small-zh-v1.5'),
      endpoint: S('endpoint 后端的 /v1/embeddings 地址'),
      apiKeyEnv: S('endpoint 后端读哪个环境变量里的 key，如 OPENAI_API_KEY'),
      warm: B('configure 时顺手把模型拉起来（默认 true）'),
      maxNodes: N('reindex 单次处理的条数（默认 40）')
    },
    required: ['action']
  },
  run: async (args) => {
    const action = String(args.action || 'status');
    if (action === 'status') return rpc('embed_status');
    if (action === 'configure' || action === 'setup') {
      const value = await rpc('embed_configure', {
        backend: args.backend || settings().embedBackend || 'local',
        model: args.model || settings().embedModel || '',
        endpoint: args.endpoint ?? settings().embedEndpoint ?? '',
        apiKeyEnv: args.apiKeyEnv ?? settings().embedApiKeyEnv ?? '',
        warm: args.warm !== false || action === 'setup'
      });
      return value;
    }
    let processed = 0;
    let rounds = 0;
    let last = null;
    while (rounds++ < 30 && processed < 400) {
      last = await rpc('reindex', { maxNodes: Math.max(1, Math.min(80, Number(args.maxNodes) || 40)) });
      processed += Number(last.processed || 0);
      if (last.done) break;
      if (!last.processed && !last.failed) break;
    }
    return { ...last, processedTotal: processed, rounds };
  }
});

TOOLS.push({
  id: 'panel',
  description: '打开记忆宫殿界面（只读面板：房间总览、画像、今日复习、最近记忆、检索与向量状态）。返回界面 URL，同时刷新面板数据。',
  parameters: { type: 'object', properties: { refresh: B('true = 先重算一份最新快照再返回 URL') } },
  run: async (args) => {
    if (args.refresh !== false) await refreshSnapshot('tool');
    const rel = 'panel/index.html';
    const url = apiRef?.panel?.url?.(rel) || '';
    return { url, page: rel, hint: '这个地址是控制台同源的只读页面（/plugin-panel/palace/panel/index.html），也可以在设置弹窗里点「打开记忆宫殿」。' };
  }
});

TOOLS.push({
  id: 'distill',
  description: '蒸馏整理：把同一个房间里反复出现的几条近义记忆合并成一条更高层的规律，旧条目软归档（保留取代链，可在「房间」面板里看到）。默认只出候选（dry-run），apply:true 才真正写库 —— 记忆写坏比漏写更麻烦。',
  parameters: {
    type: 'object',
    properties: {
      scope: { type: 'string', description: 'user / shared / project-xxx / all（默认跟随插件设置）' },
      minSize: N('一簇至少要几条才算（默认 3，范围 2~8）'),
      threshold: N('相似度阈值 0.4~0.92（默认 0.62，越小合并越激进）'),
      apply: B('true = 真正写库；默认 false 只返回候选，先看一眼再决定')
    }
  },
  run: async (args) => rpc('distill', {
    scope: args.scope || settings().scope || 'all',
    minSize: args.minSize,
    threshold: args.threshold,
    apply: args.apply === true
  })
});

TOOLS.push({
  id: 'reflect',
  description: '信念巩固：同一个房间里反复出现的说法，提炼成一条带证据数的信念写进 observations（「画像」页可见，检索时会作为高优先线索）。默认直接写；apply:false 只看候选。',
  parameters: {
    type: 'object',
    properties: {
      scope: { type: 'string', description: 'user / shared / project-xxx / all' },
      minEvidence: N('至少几条证据才成信念（默认 2，范围 2~6）'),
      apply: B('false = 只出候选，不写库（默认写）')
    }
  },
  run: async (args) => rpc('reflect', {
    scope: args.scope || settings().scope || 'all',
    minEvidence: args.minEvidence,
    apply: args.apply !== false
  })
});

TOOLS.push({
  id: 'ingest',
  description: '历史回填扫描：把 data/messages 里的聊天记录抽成一段材料交给你提炼（默认每个聊天最近 80 条、最多 4 个聊天）。它**不直接写库** —— 原始闲聊不是记忆，你读完要点后用 palace_save 逐条写进去，一次 3~8 条足够。',
  parameters: {
    type: 'object',
    properties: {
      limit: N('每个聊天取最近多少条（默认 80，范围 10~400）'),
      maxChars: N('整段材料最多多少字（默认 6000）'),
      chats: N('最多看几个聊天（默认 4）')
    }
  },
  run: async (args) => rpc('ingest_scan', {
    dir: path.join(DATA_DIR, 'messages'),
    limit: args.limit,
    maxChars: args.maxChars,
    chats: args.chats
  })
});

/* ────────────────────── 面板快照 ────────────────────── */
// 插件页面只能读 storage.json（见 src/skills/panel.js 的契约），所以把要展示的东西
// 汇总成一个对象写进 api.storage 的 'panel' 键；页面同时会直连 sidecar 做实时检索。

let snapshotTimer = null;
let snapshotBusy = false;
let lastSnapshotAt = 0;

async function buildSnapshot() {
  const s = settings();
  const safe = async (op, args) => {
    try { return await rpc(op, args); } catch (error) { return { __error: String(error?.message || error) }; }
  };
  const [stats, queue, timeline, profile, embed, beliefs, tours] = await Promise.all([
    safe('stats', { scope: 'all' }),
    safe('review_queue', { limit: 12, scope: 'all' }),
    safe('timeline', { limit: 40, scope: 'all' }),
    safe('profile', { action: 'view', scope: 'user' }),
    safe('embed_status'),
    safe('beliefs', { limit: 12, scope: 'all' }),
    safe('tour', { mode: 'fixed', maxStops: 8, scope: 'all' })
  ]);
  const block = profile && !profile.__error ? (profile.block || null) : null;
  return {
    at: Date.now(),
    version: 2,
    serviceUrl: s.serviceUrl,
    dbDir: dbDir(),
    node: findNode(),
    settings: {
      inject: s.inject, injectChars: s.injectChars, recallLimit: s.recallLimit, scope: s.scope,
      embedBackend: s.embedBackend, embedModel: s.embedModel, embedEndpoint: s.embedEndpoint,
      hfEndpoint: s.hfEndpoint,
      proxy: String(s.httpProxy || '').trim() || systemProxy(),
      proxySource: String(s.httpProxy || '').trim() ? 'settings' : (systemProxy() ? 'system' : 'none')
    },
    stats: stats?.__error ? { error: stats.__error } : stats,
    queue: queue?.__error ? { error: queue.__error } : queue,
    timeline: timeline?.__error ? { error: timeline.__error } : timeline,
    tour: tours?.__error ? { error: tours.__error } : tours,
    profile: block ? { content: String(block.content || ''), version: block.version ?? null, updatedAt: block.updatedAt ?? null } : null,
    profileVersions: profile && !profile.__error ? (profile.versions || []).length : 0,
    embed: embed?.__error ? { error: embed.__error } : embed,
    beliefs: beliefs && !beliefs.__error ? beliefs : null,
    lastInject,
    injectLog: injectLog.slice(-10),
    toolIds: TOOLS.map((x) => x.id)
  };
}

async function refreshSnapshot(reason = 'auto') {
  if (!apiRef || snapshotBusy) return null;
  snapshotBusy = true;
  try {
    const snapshot = await buildSnapshot();
    apiRef.storage.set('panel', snapshot);
    lastSnapshotAt = snapshot.at;
    void reason;
    return snapshot;
  } catch (error) {
    log('warn', '面板快照写入失败', error?.message || String(error));
    return null;
  } finally {
    snapshotBusy = false;
  }
}

let lastHealthyAt = 0;
function health0() {
  // 定时刷新只在"最近一次 RPC 成功过、且两次快照之间没有闲置很久"时进行，
  // 这样即使用户关掉了面板，也不会每分钟白起一个 sidecar。
  return lastHealthyAt > 0 && Date.now() - lastHealthyAt < 10 * 60 * 1000;
}

function scheduleSnapshot(reason = 'auto') {
  if (snapshotTimer) return;
  snapshotTimer = setTimeout(() => {
    snapshotTimer = null;
    void refreshSnapshot(reason);
  }, 3000);
  snapshotTimer.unref?.();
}

export const hooks = {
  async 'before-llm-messages'(payload, context = {}) {
    const s = settings();
    if (!s.inject) return;
    const messages = payload?.messages;
    if (!Array.isArray(messages) || !messages.length) return;
    let text = lastUserText(messages).trim();
    if (!text || text.startsWith('/')) return;
    if (text.length > 400) text = text.slice(0, 400);
    try {
      const value = await rpc('context', {
        query: text,
        limit: Number(s.recallLimit) || 5,
        injectChars: Number(s.injectChars) || 2000,
        scope: s.scope || 'all'
      });
      const block = String(value?.text || '').trim();
      if (!block) {
        lastInject = { at: Date.now(), chars: 0, hits: 0, error: '' };
        return;
      }
      const head = messages[0];
      if (head?.role === 'system' && typeof head.content === 'string') {
        head.content = `${head.content}\n\n【记忆宫殿（自动召回，只是线索，引用前用 palace_examine / palace_search 核对）】\n${block}`;
      } else {
        messages.unshift({ role: 'system', content: `【记忆宫殿（自动召回）】\n${block}` });
      }
      lastInject = { at: Date.now(), chars: block.length, hits: Array.isArray(value?.hits) ? value.hits.length : 0, error: '' };
      injectLog.push({
        at: lastInject.at,
        chat: String(context?.chatKey || ''),
        query: text.slice(0, 40),
        chars: block.length,
        hits: Array.isArray(value?.hits) ? value.hits.map((h) => ({ ref: h.ref, room: h.room, score: h.score })).slice(0, 6) : []
      });
      while (injectLog.length > 10) injectLog.shift();
      if (context?.chatKey) log('info', `注入记忆 ${block.length} 字 / ${lastInject.hits} 条 → ${context.chatKey}`);
      scheduleSnapshot('inject');
    } catch (error) {
      lastInject = { at: Date.now(), chars: 0, hits: 0, error: String(error?.message || error) };
      log('warn', '自动召回失败（不阻塞回复）', error?.message || String(error));
    }
  },

  async 'after-response'(payload) {
    // 只做轻量观察：把最近的记忆状态记在内存里，供工具返回的诊断信息使用
    if (!payload?.response) return;
  }
};

/* ────────────────────── 启动 ────────────────────── */

export function setup(api) {
  apiRef = api;
  settingsRef = { ...DEFAULTS, ...(api.config() || {}) };

  for (const tool of TOOLS) {
    api.registerTool({
      id: tool.id,
      name: `记忆宫殿 · ${tool.id}`,
      description: tool.description,
      category: 'memory',
      parameters: tool.parameters,
      execute: async (ctx, args) => {
        try {
          const value = await tool.run(args || {}, ctx || {});
          if (tool.id !== 'panel') scheduleSnapshot(`tool:${tool.id}`);
          return { content: JSON.stringify(value, null, 2) };
        } catch (error) {
          return { content: `记忆宫殿调用失败：${error?.message || error}`, isError: true };
        }
      }
    });
  }

  log('info', `已注册 ${TOOLS.length} 个工具 · 服务 ${settings().serviceUrl} · 库 ${dbDir()}`);

  // 面板靠轮询 storage.json 自更新：这里每 60 秒重算一次快照（没在用时几乎无开销）
  if (!globalThis.__palaceSnapshotTimer) {
    globalThis.__palaceSnapshotTimer = setInterval(() => {
      if (!health0()) return;
      void refreshSnapshot('interval');
    }, 60000);
    globalThis.__palaceSnapshotTimer.unref?.();
  }

  // 预热：后台把 sidecar 拉起来（失败也不影响启动）
  if (settings().autoStart) {
    ensureService()
      .then(async () => {
        log('info', 'sidecar 就绪');
        await refreshSnapshot('boot');
        log('info', `面板快照已写入（${Math.round(JSON.stringify(apiRef?.storage?.get?.('panel') || {}).length / 1024)}KB）`);
      })
      .catch((error) => log('warn', 'sidecar 预热失败', error?.message || String(error)));
  }
}

export function deactivate() {
  if (child && !child.killed) {
    try { child.kill(); } catch { /* ignore */ }
    child = null;
  }
}

export const info = () => ({
  ...settings(),
  lastInject,
  node: findNode(),
  dbDir: dbDir(),
  proxy: systemProxy(),
  lastSnapshotAt,
  panelUrl: apiRef?.panel?.url?.('panel/index.html') || ''
});
