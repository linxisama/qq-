/**
 * 记忆宫殿面板（只读）。
 *
 * 数据通道就是 src/skills/panel.js 里约定的那一个：相对路径 `../@data/storage.json`
 * （= <DATA_DIR>/plugin-data/palace/storage.json），插件主进程在每次工具调用 / 每次
 * 自动召回之后会刷新里面的 `panel` 键。页面不写任何东西，也不会去直连 sidecar
 * —— 面板的 CSP 是 `connect-src 'self'`，跨端口请求会被浏览器挡掉。
 *
 * 所以这个页面只做三件事：把快照画出来、每 15 秒重读一次、把错误老实显示在界面上。
 */

const DATA_URL = '../@data/storage.json';
const REFRESH_MS = 15000;

const state = {
  snapshot: null,
  tab: 'overview',
  room: '',
  kind: '',
  query: '',
  error: '',
  updatedAt: 0
};

const $ = (sel, root = document) => root.querySelector(sel);
const main = $('#main');
const chips = $('#chips');
const updated = $('#updated');

/* ────────────────────────── 小工具 ────────────────────────── */

function el(tag, opts = {}, children = []) {
  const node = document.createElement(tag);
  if (opts.class) node.className = opts.class;
  if (opts.text != null) node.textContent = String(opts.text);
  if (opts.title) node.title = String(opts.title);
  if (opts.onclick) node.addEventListener('click', opts.onclick);
  if (opts.attrs) for (const [k, v] of Object.entries(opts.attrs)) node.setAttribute(k, String(v));
  for (const child of [].concat(children)) if (child) node.appendChild(child);
  return node;
}

function fmtTime(ms) {
  if (!ms) return '—';
  const d = new Date(Number(ms));
  if (Number.isNaN(d.getTime())) return '—';
  const pad = (n) => String(n).padStart(2, '0');
  return `${d.getMonth() + 1}-${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}`;
}

function ago(ms) {
  if (!ms) return '—';
  const diff = Date.now() - Number(ms);
  if (diff < 0) return '刚刚';
  const min = Math.floor(diff / 60000);
  if (min < 1) return '刚刚';
  if (min < 60) return `${min} 分钟前`;
  const h = Math.floor(min / 60);
  if (h < 24) return `${h} 小时前`;
  return `${Math.floor(h / 24)} 天前`;
}

function pct(n) {
  const v = Number(n);
  return Number.isFinite(v) ? Math.max(0, Math.min(100, Math.round(v))) : 0;
}

function bar(percent) {
  const wrap = el('div', { class: 'bar' });
  const fill = el('i');
  fill.style.width = `${pct(percent)}%`;      // CSP 的 style-src 允许 JS 设 style
  wrap.appendChild(fill);
  return wrap;
}

function card(title, body, extraClass = '') {
  const c = el('section', { class: `card ${extraClass}`.trim() });
  if (title) c.appendChild(el('h3', { text: title }));
  c.appendChild(body);
  return c;
}

function empty(text) {
  return el('div', { class: 'empty', text });
}

/* ────────────────────────── 读取快照 ────────────────────────── */

async function loadSnapshot() {
  try {
    const res = await fetch(`${DATA_URL}?t=${Date.now()}`, { cache: 'no-store' });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const all = await res.json();
    const snap = all && typeof all === 'object' ? all.panel : null;
    if (!snap) throw new Error('快照还没生成（先在 QQ 里用一次记忆工具，或等插件预热完成）');
    state.snapshot = snap;
    state.error = '';
    state.updatedAt = Date.now();
  } catch (error) {
    state.error = String(error && error.message ? error.message : error);
  }
  render();
}

/* ────────────────────────── 渲染：头部 ────────────────────────── */

function renderChips(snap) {
  chips.textContent = '';
  if (!snap) {
    chips.appendChild(el('span', { class: 'chip bad', text: '快照不可用' }));
    return;
  }
  const totals = (snap.stats && snap.stats.totals) || {};
  const embed = snap.embed || {};
  const coverage = Number(embed.coverage ? (embed.coverage.percent ?? embed.coverage) : (embed.percent ?? 0));
  const serviceOk = snap.stats && !snap.stats.error;

  chips.appendChild(el('span', {
    class: `chip ${serviceOk ? 'ok' : 'bad'}`,
    text: serviceOk ? '服务在线' : '服务离线'
  }));
  chips.appendChild(el('span', { class: 'chip', text: '记忆 ', }, [
    el('b', { text: String(totals.nodes ?? (snap.timeline && snap.timeline.count) ?? 0) })
  ]));
  chips.appendChild(el('span', { class: 'chip', text: '事实 ' }, [el('b', { text: String(totals.facts ?? 0) })]));
  chips.appendChild(el('span', { class: 'chip', text: '实体 ' }, [el('b', { text: String(totals.entities ?? 0) })]));
  chips.appendChild(el('span', { class: 'chip', text: '待复习 ' }, [el('b', { text: String(totals.reviewDue ?? 0) })]));

  const backend = String(embed.backend || 'off');
  const embedChip = el('span', {
    class: `chip ${embed.error ? 'bad' : (backend === 'off' ? 'warn' : 'ok')}`,
    text: `向量 ${backend}${embed.model ? ` · ${String(embed.model).split('/').pop()}` : ''}${Number.isFinite(coverage) && coverage > 0 ? ` · ${pct(coverage)}%` : ''}`
  });
  if (embed.error) embedChip.title = String(embed.error);
  chips.appendChild(embedChip);

  if (snap.settings && snap.settings.inject === false) {
    chips.appendChild(el('span', { class: 'chip warn', text: '自动注入已关' }));
  }
}

/* ────────────────────────── 渲染：各页 ────────────────────────── */

function renderOverview(snap) {
  const frag = document.createDocumentFragment();
  const totals = (snap.stats && snap.stats.totals) || {};

  frag.appendChild(el('div', { class: 'grid g4' }, [
    metricCard('记忆', totals.nodes ?? 0, '条'),
    metricCard('事实', totals.facts ?? 0, '条'),
    metricCard('实体', totals.entities ?? 0, '个'),
    metricCard('今日待复习', totals.reviewDue ?? 0, '条'),
    metricCard('操作日志', totals.opLog ?? 0, '条'),
    metricCard('平均置信', Number(snap.stats && snap.stats.avgConfidence || 0).toFixed(2), ''),
    metricCard('最近召回', snap.lastInject && snap.lastInject.at ? ago(snap.lastInject.at) : '—', ''),
    metricCard('注入字数', snap.lastInject ? snap.lastInject.chars : 0, '字')
  ]));

  // 分布（按种类）：sidecar 返回的是 [{kind, c}]，不是对象
  const rawKind = (snap.stats && snap.stats.byKind) || [];
  const kindEntries = (Array.isArray(rawKind) ? rawKind : Object.entries(rawKind).map(([kind, c]) => ({ kind, c })))
    .map((row) => ({ kind: String(row.kind || '?'), c: Number(row.c ?? row.count ?? 0) }))
    .filter((row) => row.c > 0)
    .sort((a, b) => b.c - a.c);
  if (kindEntries.length) {
    const max = Math.max(...kindEntries.map((row) => row.c), 1);
    const bars = el('div', { class: 'bars' });
    for (const row of kindEntries) {
      bars.appendChild(el('div', { class: 'row' }, [
        el('span', { class: 'muted', text: row.kind }),
        bar((row.c / max) * 100),
        el('span', { class: 'num', text: String(row.c) })
      ]));
    }
    frag.appendChild(card('记忆分布（按种类 · 全库）', bars));
  }

  const perScope = (snap.stats && snap.stats.perScope) || [];
  if (perScope.length) {
    const table = el('table');
    table.appendChild(el('thead', {}, [
      el('tr', {}, [
        el('th', { text: '库' }), el('th', { text: '记忆' }), el('th', { text: '事实' }),
        el('th', { text: '实体' }), el('th', { text: '待复习' })
      ])
    ]));
    const tbody = el('tbody');
    for (const row of perScope) {
      tbody.appendChild(el('tr', {}, [
        el('td', { class: 'mono', text: String(row.file || row.scope || '') }),
        el('td', { class: 'num', text: String(row.nodes ?? 0) }),
        el('td', { class: 'num', text: String(row.facts ?? 0) }),
        el('td', { class: 'num', text: String(row.entities ?? 0) }),
        el('td', { class: 'num', text: String(row.reviewDue ?? 0) })
      ]));
    }
    table.appendChild(tbody);
    frag.appendChild(card('分库统计', table));
  }

  // 最近召回
  const log = Array.isArray(snap.injectLog) ? snap.injectLog.slice().reverse() : [];
  const list = el('div', { class: 'list' });
  if (!log.length) list.appendChild(empty('还没有召回记录（聊两句就会有了）'));
  for (const item of log.slice(0, 8)) {
    list.appendChild(el('div', { class: 'mem' }, [
      el('div', { class: 'meta' }, [
        el('span', { class: 'tag', text: ago(item.at) }),
        el('span', { class: 'tag', text: String(item.chat || '未知会话') }),
        el('span', { class: 'tag', text: `${item.chars || 0} 字` })
      ]),
      el('div', { class: 'body', text: `「${String(item.query || '')}」` }),
      el('div', { class: 'meta' }, (item.hits || []).map((h) => el('span', { class: 'tag k-room', text: `${h.room || '?'} ${Number(h.score || 0).toFixed(2)}` })))
    ]));
  }
  frag.appendChild(card('最近召回', list));

  return frag;
}

function metricCard(label, value, unit) {
  return card(label, el('div', {}, [
    el('div', { class: 'metric', text: String(value) }, unit ? [el('small', { text: unit })] : [])
  ]));
}

function renderRooms(snap) {
  const rooms = (snap.stats && snap.stats.rooms) || [];
  if (!rooms.length) return empty('还没有房间（写第一条记忆就会开房）');
  const grid = el('div', { class: 'room-grid' });
  for (const room of rooms) {
    const name = String(room.room || room.name || '未命名');
    const count = Number(room.slots ?? room.nodes ?? room.count ?? 0);
    const latest = String(room.latest || '');
    const cell = el('div', {
      class: 'room',
      title: latest ? `最近一条：${latest}` : `只看 ${name} 房间的记忆`,
      onclick: () => { state.room = name; state.tab = 'memories'; render(); }
    }, [
      el('div', { class: 'n', text: String(count) }),
      el('div', { class: 'k', text: name })
    ]);
    if (latest) cell.appendChild(el('div', { class: 'k', text: latest.slice(0, 18) }));
    grid.appendChild(cell);
  }
  const body = document.createDocumentFragment();
  body.appendChild(el('p', { class: 'muted', text: '房间按记忆种类分；每房 9 个桩位，满了会溢出成同名前缀的扩展房（如 fact-2）。点一间房看里面的记忆。' }));
  body.appendChild(grid);
  return body;
}

function renderMemories(snap) {
  const items = (snap.timeline && Array.isArray(snap.timeline.items)) ? snap.timeline.items.slice() : [];
  const kinds = Array.from(new Set(items.map((x) => String(x.kind || '')).filter(Boolean))).sort();
  const rooms = Array.from(new Set(items.map((x) => String(x.room || '')).filter(Boolean))).sort();

  const toolbar = el('div', { class: 'toolbar' });
  const search = el('input', { attrs: { type: 'search', placeholder: '在最近 40 条里搜…' } });
  search.value = state.query;
  search.addEventListener('input', () => { state.query = search.value; render(); });
  toolbar.appendChild(search);

  const kindSel = el('select');
  kindSel.appendChild(el('option', { text: '全部种类', attrs: { value: '' } }));
  for (const k of kinds) kindSel.appendChild(el('option', { text: k, attrs: { value: k } }));
  kindSel.value = state.kind;
  kindSel.addEventListener('change', () => { state.kind = kindSel.value; render(); });
  toolbar.appendChild(kindSel);

  const roomSel = el('select');
  roomSel.appendChild(el('option', { text: '全部房间', attrs: { value: '' } }));
  for (const r of rooms) roomSel.appendChild(el('option', { text: r, attrs: { value: r } }));
  roomSel.value = state.room;
  roomSel.addEventListener('change', () => { state.room = roomSel.value; render(); });
  toolbar.appendChild(roomSel);

  if (state.room || state.kind || state.query) {
    toolbar.appendChild(el('button', {
      class: 'btn', text: '清空筛选',
      onclick: () => { state.room = ''; state.kind = ''; state.query = ''; render(); }
    }));
  }
  toolbar.appendChild(el('span', { class: 'muted', text: `共 ${items.length} 条（快照只带最近 40 条）` }));

  const filtered = items.filter((m) => {
    if (state.kind && String(m.kind) !== state.kind) return false;
    if (state.room && String(m.room) !== state.room) return false;
    if (state.query) {
      const q = state.query.toLowerCase();
      const hay = `${m.content || ''} ${m.placard || ''} ${m.room || ''}`.toLowerCase();
      if (!hay.includes(q)) return false;
    }
    return true;
  });

  const frag = document.createDocumentFragment();
  frag.appendChild(toolbar);

  if (!filtered.length) {
    frag.appendChild(empty('这组筛选下没有记忆'));
    return frag;
  }

  const list = el('div', { class: 'list scroll' });
  for (const m of filtered) {
    const meta = el('div', { class: 'meta' }, [
      el('span', { class: 'tag k-kind', text: String(m.kind || '?') }),
      el('span', { class: 'tag k-room', text: `${m.room || '?'}${m.slot != null ? '#' + m.slot : ''}` }),
      el('span', { class: 'tag', text: `重要 ${Number(m.importance ?? 0).toFixed(2)}` }),
      el('span', { class: 'tag', text: `置信 ${Number(m.confidence ?? 0).toFixed(2)}` }),
      el('span', { class: 'tag', text: `用过 ${Number(m.accessCount ?? 0)} 次` }),
      el('span', { class: 'tag', text: fmtTime(m.createdAt) })
    ]);
    list.appendChild(el('div', { class: 'mem' }, [
      meta,
      el('div', { class: 'body', text: String(m.content || '') }),
      m.placard ? el('div', { class: 'muted', text: `门牌：${m.placard}` }) : null
    ]));
  }
  frag.appendChild(list);
  return frag;
}

function renderProfile(snap) {
  const frag = document.createDocumentFragment();
  const p = snap.profile;
  if (!p || !p.content) {
    frag.appendChild(empty('还没有画像。在 QQ 里让小鲸鱼「编辑画像」，或者写几条关于你的偏好/事实，它会被整理进来。'));
  } else {
    frag.appendChild(card(`画像（v${p.version ?? '?'} · ${ago(p.updatedAt)}）`, el('div', { class: 'profile-body', text: p.content })));
    frag.appendChild(el('p', { class: 'muted', text: `历史版本 ${snap.profileVersions || 0} 个。画像每次生成回复都会作为最高优先层注入；要改就在 QQ 里说，改之前会做版本保护。` }));
  }
  return frag;
}

function renderBeliefs(snap) {
  const beliefs = snap.beliefs;
  const items = Array.isArray(beliefs && beliefs.items) ? beliefs.items : [];
  if (!items.length) {
    return empty('还没有信念。在 QQ 里说「巩固一下记忆」（palace_reflect），反复出现的几条会被提炼成一条带证据数的信念。');
  }
  const list = el('div', { class: 'list scroll' });
  for (const item of items) {
    list.appendChild(el('div', { class: 'mem' }, [
      el('div', { class: 'meta' }, [
        el('span', { class: 'tag k-room', text: String(item.scope || '?') }),
        el('span', { class: 'tag', text: '证据 ' + String(item.proof == null ? '?' : item.proof) + ' 条' }),
        item.updatedAt ? el('span', { class: 'tag', text: ago(item.updatedAt) }) : null
      ]),
      el('div', { class: 'body', text: String(item.belief || '') })
    ]));
  }
  return list;
}

function renderReview(snap) {
  const queue = snap.queue || {};
  const items = Array.isArray(queue.items) ? queue.items : [];
  const frag = document.createDocumentFragment();
  frag.appendChild(el('p', { class: 'muted', text: `今日 ${queue.count ?? items.length} 条到期待复习。间隔重复只给线索引子，不给正文——先回想，再对照。复习自评在 QQ 里用 palace_report 传 grade 0-5。` }));
  if (!items.length) {
    frag.appendChild(empty('今天没有到期的记忆'));
    return frag;
  }
  const list = el('div', { class: 'list scroll' });
  for (const item of items) {
    list.appendChild(el('div', { class: 'mem' }, [
      el('div', { class: 'meta' }, [
        el('span', { class: 'tag k-kind', text: String(item.kind || '?') }),
        el('span', { class: 'tag k-room', text: String(item.room || '?') }),
        item.nextReviewAt ? el('span', { class: 'tag', text: `到期 ${fmtTime(item.nextReviewAt)}` }) : null,
        item.due ? el('span', { class: 'tag', text: `逾期 ${item.due} 天` }) : null
      ]),
      el('div', { class: 'body', text: String(item.placard || item.clue || item.content || '（只有坐标线索）') })
    ]));
  }
  frag.appendChild(list);
  return frag;
}

function renderVector(snap) {
  const embed = snap.embed || {};
  const settings = snap.settings || {};
  const frag = document.createDocumentFragment();

  const coverage = Number(embed.coverage ? (embed.coverage.percent ?? 0) : 0);
  const head = el('div', {}, [
    el('div', { class: 'metric', text: `${pct(coverage)}%`, }, [el('small', { text: ' 已向量化' })]),
    bar(coverage),
    el('p', { class: 'muted', text: embed.coverage ? `${embed.coverage.withVec ?? 0} / ${embed.coverage.total ?? 0} 条` : '（覆盖率未知）' })
  ]);
  frag.appendChild(card('覆盖情况', head));

  const kv = el('dl', { class: 'kv' });
  const add = (k, v) => { kv.appendChild(el('dt', { text: k })); kv.appendChild(el('dd', { text: v == null || v === '' ? '—' : String(v) })); };
  add('后端', embed.backend);
  add('模型', embed.model);
  add('维度', embed.dims);
  add('就绪', embed.ready ? '是' : (embed.loading ? '加载中' : '否'));
  add('模型已缓存', embed.modelCached ? '是' : '否');
  add('依赖已安装', embed.installed ? '是' : '否');
  if (embed.error) add('错误', embed.error);
  add('模型目录', embed.modelsDir);
  add('推理依赖', embed.transformersPath);
  frag.appendChild(card('向量状态', kv));

  const cfg = el('dl', { class: 'kv' });
  const add2 = (k, v) => { cfg.appendChild(el('dt', { text: k })); cfg.appendChild(el('dd', { text: v == null || v === '' ? '—' : String(v) })); };
  add2('插件设置 · 后端', settings.embedBackend);
  add2('插件设置 · 模型', settings.embedModel);
  add2('插件设置 · endpoint', settings.embedEndpoint);
  add2('插件设置 · 下载源', settings.hfEndpoint);
  add2('下载代理', settings.proxy ? `${settings.proxy}（${settings.proxySource}）` : '无');
  frag.appendChild(card('配置来源', cfg));

  frag.appendChild(el('p', { class: 'muted', text:
    '怎么改：① 设置 → 插件 → 记忆宫殿 → ⚙ 里改「向量后端 / 本地模型 / API 地址 / 下载源 / 下载代理」，改完重启插件生效；'
    + '② 或者在 QQ 里让模型调 palace_vector（action=configure / setup / reindex）。'
    + '本地模型第一次要下几十 MB 权重，走「下载代理」；下完就完全离线。'
    + 'endpoint 后端支持任何 OpenAI 兼容的 /v1/embeddings（key 从环境变量读，不落库）。' }));

  return frag;
}

function renderAbout(snap) {
  const kv = el('dl', { class: 'kv' });
  const add = (k, v) => { kv.appendChild(el('dt', { text: k })); kv.appendChild(el('dd', { text: v == null || v === '' ? '—' : String(v) })); };
  add('服务地址', snap.serviceUrl);
  add('数据库目录', snap.dbDir);
  add('Sidecar Node', snap.node);
  add('快照时间', fmtTime(snap.at));
  add('工具数量', (snap.toolIds || []).length);
  add('自动注入', snap.settings && snap.settings.inject ? `开（${snap.settings.injectChars} 字 / ${snap.settings.recallLimit} 条）` : '关');

  const tools = el('div', { class: 'meta' });
  for (const id of snap.toolIds || []) tools.appendChild(el('span', { class: 'pill', text: `palace_${id}` }));

  const frag = document.createDocumentFragment();
  frag.appendChild(card('运行时', kv));
  frag.appendChild(card('注册的工具', tools));
  frag.appendChild(el('p', { class: 'muted', text: '这个面板是只读的：所有写操作（记记忆、改画像、复习自评、换向量后端）都在 QQ 对话里由模板工具完成，面板只负责把状态摊开给你看。' }));
  return frag;
}

/* ────────────────────────── 主渲染 ────────────────────────── */

function render() {
  const snap = state.snapshot;
  renderChips(snap);
  updated.textContent = state.updatedAt ? `更新于 ${fmtTime(state.updatedAt)}` : '';

  for (const btn of document.querySelectorAll('.tab')) {
    btn.classList.toggle('is-on', btn.dataset.tab === state.tab);
  }

  main.textContent = '';

  if (state.error && !snap) {
    main.appendChild(card('读不到快照', el('div', {}, [
      el('p', { class: 'err', text: state.error }),
      el('p', { class: 'muted', text: '插件预热完成后会自动生成；也可以先在 QQ 里让它随便记一条，或点右上角刷新。' })
    ])));
    return;
  }

  if (state.error) {
    main.appendChild(el('p', { class: 'err', text: `上次刷新失败：${state.error}` }));
  }

  let body;
  if (state.tab === 'overview') body = renderOverview(snap);
  else if (state.tab === 'rooms') body = renderRooms(snap);
  else if (state.tab === 'memories') body = renderMemories(snap);
  else if (state.tab === 'profile') { body = el('div'); body.appendChild(renderProfile(snap)); body.appendChild(el('h3', { class: 'sec-title', text: '信念（反复出现的规律 + 证据数）' })); body.appendChild(renderBeliefs(snap)); }
  else if (state.tab === 'review') body = renderReview(snap);
  else if (state.tab === 'vector') body = renderVector(snap);
  else body = renderAbout(snap);

  main.appendChild(body);
}

/* ────────────────────────── 事件 ────────────────────────── */

const TABS = ['overview', 'rooms', 'memories', 'profile', 'review', 'vector', 'about'];

// 支持深链：…/panel/index.html#vector 直接落在对应页（也方便截图与排查）
function applyHash() {
  const want = String(location.hash || '').replace(/^#/, '');
  if (TABS.includes(want)) state.tab = want;
}

document.addEventListener('click', (event) => {
  const tab = event.target && event.target.closest ? event.target.closest('.tab') : null;
  if (tab && tab.dataset.tab) {
    state.tab = tab.dataset.tab;
    if (location.hash !== `#${state.tab}`) {
      history.replaceState(null, '', `#${state.tab}`);
    }
    render();
  }
});

window.addEventListener('hashchange', () => { applyHash(); render(); });

$('#refresh').addEventListener('click', () => { void loadSnapshot(); });

applyHash();
void loadSnapshot();
setInterval(() => { void loadSnapshot(); }, REFRESH_MS);
