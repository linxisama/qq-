#!/usr/bin/env node
/**
 * 记忆宫殿 sidecar 服务（QQ Agent 版）
 *
 * 为什么是 sidecar：洛版的 Electron 33 跑 Node 20，没有 `node:sqlite`；
 * 而 DSH 的记忆宫殿用的是 SQLite（FTS5 + 复习调度 + 事实链）。为了**原样复用
 * 同一套表结构**（这样 DSH 的 .db 可以直接搬过来，不需要任何转换），
 * 这里用一个 Node 22.5+ 的进程把数据库打开，对上暴露一个很窄的 HTTP JSON 接口，
 * 由 `plugins/palace/index.js` 在本进程里调用。
 *
 * 环境变量：
 *   PALACE_DB_DIR   数据库目录（默认 <插件基> /../../../data/palace/db）
 *   PALACE_PORT     监听端口（默认 3401）
 *   PALACE_TOKEN    可选的共享令牌（请求头 x-palace-token）
 *   PALACE_HOST     默认 127.0.0.1
 *
 * 接口：GET /health、POST /rpc { op, args } → { ok, value } | { ok:false, error }
 */

import http from 'node:http';
import path from 'node:path';
import fs from 'node:fs';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { createEmbedder, blobToVec, cosine, vecToBlob } from './embed.mjs';

let DatabaseSync;
try {
  ({ DatabaseSync } = await import('node:sqlite'));
} catch (error) {
  console.error('[palace] 这个 Node 没有 node:sqlite（需要 22.5+）：' + error.message);
  process.exit(2);
}

const HERE = path.dirname(fileURLToPath(import.meta.url));
const DB_DIR = process.env.PALACE_DB_DIR
  ? path.resolve(process.env.PALACE_DB_DIR)
  : path.resolve(process.env.QQ_AGENT_DATA_DIR || path.join(HERE, '..', '..', '..', '..', 'data'), 'palace', 'db');
const PORT = Number(process.env.PALACE_PORT || 3401);
const HOST = process.env.PALACE_HOST || '127.0.0.1';
const TOKEN = process.env.PALACE_TOKEN || '';

/* ── 向量后端（三种：hash / local / openai 兼容） ── */
const DATA_DIR = path.dirname(DB_DIR);
const log = (level, msg) => console.log(`[palace:${level}] ${msg}`);
const embedder = createEmbedder({ dataDir: DATA_DIR, log });
const EMBED_READY = process.env.PALACE_EMBED !== 'off';

fs.mkdirSync(DB_DIR, { recursive: true });

const DAY = 86400000;
const now = () => Date.now();
const uid = () => crypto.randomUUID();
const clamp = (n, lo, hi) => Math.max(lo, Math.min(hi, Number(n)));

/* ────────────────────────────── 数据库注册 ────────────────────────────── */

const ROOM_CAPACITY = 9;

const SCHEMA = [
  `CREATE TABLE IF NOT EXISTS meta ("key" TEXT PRIMARY KEY, value TEXT NOT NULL)`,
  `CREATE TABLE IF NOT EXISTS nodes (id TEXT PRIMARY KEY, scope TEXT NOT NULL, kind TEXT NOT NULL, content TEXT NOT NULL,
     importance REAL NOT NULL, confidence REAL NOT NULL, status TEXT NOT NULL, created_at INTEGER NOT NULL,
     last_accessed_at INTEGER NOT NULL, access_count INTEGER NOT NULL, source_session_id TEXT, source_round INTEGER,
     source_seq INTEGER, embedding BLOB, outcome TEXT, imagery_json TEXT, slot_room TEXT, slot_index INTEGER,
     imagery_score REAL, next_review_at INTEGER, ease_factor REAL, interval_days REAL, review_reps INTEGER DEFAULT 0)`,
  `CREATE TABLE IF NOT EXISTS edges (from_id TEXT NOT NULL, to_id TEXT NOT NULL, type TEXT NOT NULL,
     created_at INTEGER NOT NULL, PRIMARY KEY (from_id, to_id, type))`,
  `CREATE TABLE IF NOT EXISTS entities (id TEXT PRIMARY KEY, name TEXT NOT NULL, kind TEXT NOT NULL,
     aliases_json TEXT NOT NULL DEFAULT '[]', created_at INTEGER NOT NULL, updated_at INTEGER NOT NULL)`,
  `CREATE TABLE IF NOT EXISTS node_entities (node_id TEXT NOT NULL, entity_id TEXT NOT NULL, PRIMARY KEY (node_id, entity_id))`,
  `CREATE TABLE IF NOT EXISTS facts (id TEXT PRIMARY KEY, entity_id TEXT NOT NULL, content TEXT NOT NULL,
     valid_at INTEGER NOT NULL, invalid_at INTEGER, replaced_by TEXT, source_node_id TEXT,
     created_at INTEGER NOT NULL, updated_at INTEGER NOT NULL)`,
  `CREATE TABLE IF NOT EXISTS observations (id TEXT PRIMARY KEY, scope TEXT NOT NULL, belief TEXT NOT NULL,
     status TEXT NOT NULL, sources_json TEXT NOT NULL, proof_count INTEGER NOT NULL, embedding BLOB,
     created_at INTEGER NOT NULL, updated_at INTEGER NOT NULL, last_validated_at INTEGER NOT NULL)`,
  `CREATE TABLE IF NOT EXISTS op_log (seq INTEGER PRIMARY KEY AUTOINCREMENT, at INTEGER NOT NULL, op TEXT NOT NULL,
     target_id TEXT NOT NULL, detail TEXT)`,
  `CREATE TABLE IF NOT EXISTS nodes_revisions (node_id TEXT NOT NULL, content TEXT NOT NULL, kind TEXT NOT NULL,
     importance REAL NOT NULL, superseded_at INTEGER NOT NULL)`,
  `CREATE TABLE IF NOT EXISTS tour_routes (position INTEGER PRIMARY KEY, node_id TEXT NOT NULL)`,
  `CREATE TABLE IF NOT EXISTS profile_blocks (scope TEXT PRIMARY KEY, content TEXT NOT NULL, version INTEGER NOT NULL, updated_at INTEGER NOT NULL)`,
  `CREATE TABLE IF NOT EXISTS profile_block_versions (scope TEXT NOT NULL, version INTEGER NOT NULL, content TEXT NOT NULL,
     source TEXT NOT NULL, at INTEGER NOT NULL, PRIMARY KEY (scope, version))`,
  `CREATE TABLE IF NOT EXISTS session_summaries (session_id TEXT PRIMARY KEY, summary TEXT NOT NULL, updated_at INTEGER NOT NULL)`,
  `CREATE VIRTUAL TABLE IF NOT EXISTS nodes_fts USING fts5(node_id UNINDEXED, content, tokenize='unicode61')`,
  `CREATE INDEX IF NOT EXISTS nodes_scope_status ON nodes (scope, status)`,
  `CREATE INDEX IF NOT EXISTS nodes_kind_created ON nodes (kind, created_at)`,
  `CREATE INDEX IF NOT EXISTS nodes_review_due ON nodes (next_review_at)`,
  `CREATE INDEX IF NOT EXISTS nodes_slot ON nodes (slot_room, slot_index)`,
  `CREATE INDEX IF NOT EXISTS nodes_session_created ON nodes (source_session_id, created_at)`,
  `CREATE INDEX IF NOT EXISTS facts_entity ON facts (entity_id)`,
  `CREATE INDEX IF NOT EXISTS entities_name ON entities (name)`,
  `CREATE INDEX IF NOT EXISTS node_entities_entity ON node_entities (entity_id)`,
  `CREATE INDEX IF NOT EXISTS observations_status ON observations (status, proof_count, updated_at)`
];

/** scope 名 → 文件名：user / shared / project-<hash> */
function fileFor(scope) {
  if (scope === 'user') return path.join(DB_DIR, 'user.db');
  if (scope === 'shared') return path.join(DB_DIR, 'shared.db');
  if (scope === 'qq') return biggestProjectFile();
  if (scope.startsWith('project-')) {
    const safe = scope.replace(/[^a-z0-9-]/gi, '');
    const file = path.join(DB_DIR, `${safe}.db`);
    if (safe === 'project-qq' && !fs.existsSync(file)) return biggestProjectFile();
    return file;
  }
  return path.join(DB_DIR, 'user.db');
}

/** scope 'qq' 的落点：节点最多的那个 project 库（避免复制文件导致检索重复） */
let biggestProjectCache = { at: 0, file: '' };
function biggestProjectFile() {
  if (Date.now() - biggestProjectCache.at < 60000 && biggestProjectCache.file) return biggestProjectCache.file;
  let best = '';
  let bestCount = -1;
  for (const f of fs.readdirSync(DB_DIR)) {
    if (!/^project-[a-z0-9-]+\.db$/i.test(f)) continue;
    if (/^project-qq\.db$/i.test(f)) continue;
    let count = 0;
    try {
      const handle = new DatabaseSync(path.join(DB_DIR, f), { readOnly: true });
      count = handle.prepare("SELECT COUNT(*) c FROM nodes WHERE status = 'active'").get().c;
      handle.close();
    } catch { count = 0; }
    if (count > bestCount) { bestCount = count; best = path.join(DB_DIR, f); }
  }
  biggestProjectCache = { at: Date.now(), file: best || path.join(DB_DIR, 'user.db') };
  return biggestProjectCache.file;
}

const open = new Map();

function db(scope = 'user') {
  const file = fileFor(scope);
  const hit = open.get(file);
  if (hit) return hit;
  const fresh = !fs.existsSync(file);
  const handle = new DatabaseSync(file);
  handle.exec('PRAGMA journal_mode = WAL');
  handle.exec('PRAGMA busy_timeout = 4000');
  if (fresh) for (const sql of SCHEMA) handle.exec(sql);
  try {
    handle.prepare('SELECT 1 FROM meta LIMIT 1').get();
  } catch {
    for (const sql of SCHEMA) handle.exec(sql);
  }
  // `key` 是 SQLite 的关键字，列名必须加引号，否则报 near "=": syntax error
  const meta = handle.prepare('SELECT value FROM meta WHERE "key" = ?').get('schema_version');
  if (!meta) handle.prepare('INSERT OR REPLACE INTO meta ("key", value) VALUES (?, ?)').run('schema_version', '13');
  const entry = { scope, file, db: handle };
  open.set(file, entry);
  return entry;
}

function scopeList() {
  const list = ['user', 'shared'];
  for (const f of fs.readdirSync(DB_DIR)) {
    if (!f.endsWith('.db')) continue;
    if (f === 'user.db' || f === 'shared.db') continue;
    if (/^project-[a-z0-9-]+\.db$/i.test(f)) list.push(f.replace(/\.db$/, ''));
  }
  return list;
}

/* ────────────────────────────── 小工具 ────────────────────────────── */

function logOp(handle, op, targetId, detail) {
  try {
    handle.prepare('INSERT INTO op_log (at, op, target_id, detail) VALUES (?, ?, ?, ?)').run(now(), op, String(targetId || ''), detail === undefined ? null : String(detail).slice(0, 20000));
  } catch { /* 日志失败不影响主流程 */ }
}

function bigrams(text) {
  const cleaned = String(text || '').toLowerCase().replace(/[\s\p{P}\p{S}]+/gu, ' ');
  const out = new Set();
  for (const chunk of cleaned.split(' ')) {
    if (!chunk) continue;
    if (chunk.length === 1) out.add(chunk);
    for (let i = 0; i + 1 < chunk.length; i++) out.add(chunk.slice(i, i + 2));
  }
  return [...out];
}

function similarity(a, b) {
  const A = new Set(bigrams(a));
  const B = new Set(bigrams(b));
  if (!A.size || !B.size) return 0;
  let inter = 0;
  for (const g of A) if (B.has(g)) inter++;
  return inter / (A.size + B.size - inter);
}

function ftsUpsert(handle, id, content) {
  try {
    handle.prepare('DELETE FROM nodes_fts WHERE node_id = ?').run(id);
    handle.prepare('INSERT INTO nodes_fts (node_id, content) VALUES (?, ?)').run(id, content);
  } catch { /* 没有 fts 也能跑，检索会退化成 bigram 扫描 */ }
}

function assignSlot(handle, kind) {
  const room = String(kind || 'fact');
  let index = 0;
  for (;;) {
    const name = index === 0 ? room : `${room}-${index + 1}`;
    const used = handle.prepare('SELECT COUNT(*) c FROM nodes WHERE slot_room = ?').get(name).c;
    if (used < ROOM_CAPACITY) {
      const next = handle.prepare('SELECT COALESCE(MAX(slot_index), 0) + 1 n FROM nodes WHERE slot_room = ?').get(name).n;
      return { room: name, index: next };
    }
    index++;
    if (index > 99) return { room, index: 1 };
  }
}

function routeAppend(handle, nodeId) {
  try {
    const pos = handle.prepare('SELECT COALESCE(MAX(position), -1) + 1 p FROM tour_routes').get().p;
    handle.prepare('INSERT OR REPLACE INTO tour_routes (position, node_id) VALUES (?, ?)').run(pos, nodeId);
  } catch { /* 路线表不存在就算了 */ }
}

function placardOf(row) {
  try {
    const img = row.imagery_json ? JSON.parse(row.imagery_json) : null;
    return img?.placard || img?.caption || '';
  } catch {
    return '';
  }
}

function shape(row) {
  return {
    id: row.id,
    scope: row.scope,
    kind: row.kind,
    content: row.content,
    importance: row.importance,
    confidence: row.confidence,
    status: row.status,
    room: row.slot_room,
    slot: row.slot_index,
    placard: placardOf(row),
    createdAt: row.created_at,
    lastAccessedAt: row.last_accessed_at,
    accessCount: row.access_count,
    nextReviewAt: row.next_review_at,
    easeFactor: row.ease_factor,
    intervalDays: row.interval_days,
    reviewReps: row.review_reps,
    sessionId: row.source_session_id,
    round: row.source_round,
    seq: row.source_seq
  };
}

function entitiesOf(handle, nodeId) {
  return handle.prepare(
    `SELECT e.id, e.name, e.kind FROM node_entities ne JOIN entities e ON e.id = ne.entity_id WHERE ne.node_id = ?`
  ).all(nodeId);
}

function keywordScore(row, query) {
  const q = String(query || '').trim().toLowerCase();
  if (!q) return 0;
  const grams = bigrams(q);
  const content = String(row.content || '').toLowerCase();
  let hit = 0;
  for (const g of grams) if (content.includes(g)) hit++;
  let kw = grams.length ? hit / grams.length : 0;
  if (content.includes(q)) kw = Math.max(kw, 0.95);
  const placard = placardOf(row).toLowerCase();
  if (placard && placard.includes(q)) kw = Math.max(kw, 0.8);
  return kw;
}

function rankScore(row, query, weights, sim = null) {
  const kw = keywordScore(row, query);
  const ageDays = Math.max(0, (now() - (row.last_accessed_at || row.created_at)) / DAY);
  const recency = Math.exp(-ageDays / 30);
  const proof = Math.min(1, Math.log1p(row.access_count || 0) / 3);
  const vectorPart = sim == null ? 0 : 1.1 * Math.max(0, sim);
  return (
    weights.keyword * kw +
    vectorPart +
    weights.recency * recency +
    weights.proof * proof +
    0.3 * (row.importance || 0.5) +
    0.2 * (row.confidence || 0.3)
  );
}

function reinforce(handle, row, delta = 0.02) {
  const confidence = clamp((row.confidence || 0.3) + delta, 0, 1);
  handle.prepare('UPDATE nodes SET confidence = ?, access_count = access_count + 1, last_accessed_at = ? WHERE id = ?')
    .run(confidence, now(), row.id);
}

function entitiesByName(handle, name) {
  return handle.prepare('SELECT * FROM entities WHERE name = ? OR aliases_json LIKE ?').all(name, `%${name}%`);
}

function upsertEntity(handle, name, kind = 'other') {
  const clean = String(name || '').trim();
  if (!clean) return null;
  const hit = entitiesByName(handle, clean);
  const exact = hit.find((e) => e.name === clean);
  if (exact) return exact;
  const id = uid();
  handle.prepare('INSERT INTO entities (id, name, kind, aliases_json, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?)')
    .run(id, clean, kind || 'other', '[]', now(), now());
  return { id, name: clean, kind: kind || 'other' };
}

/* ────────────────────────────── 业务操作 ────────────────────────────── */

const KINDS = ['fact', 'preference', 'decision', 'episode', 'skill'];

function inferKind(text) {
  const t = String(text || '');
  if (/^(我)?(决定|选择|改用|换成|不再|以后都)/.test(t) || /决定|方案是|采用/.test(t) && t.length < 80) return 'decision';
  if (/喜欢|偏好|讨厌|习惯|更愿意/.test(t)) return 'preference';
  if (/今天|昨天|刚才|那次|当时|后来|然后/.test(t)) return 'episode';
  if (/怎么做|步骤|办法|技巧|流程/.test(t)) return 'skill';
  return 'fact';
}

async function opSave(handle, args) {
  const items = Array.isArray(args.items) ? args.items : [{ content: args.content, kind: args.kind, importance: args.importance, placard: args.placard, entities: args.entities }];
  const results = [];
  for (const raw of items.slice(0, 10)) {
    const content = String(raw?.content || '').trim();
    if (content.length < 2) { results.push({ ok: false, error: '内容太短' }); continue; }
    const kind = KINDS.includes(raw?.kind) ? raw.kind : inferKind(content);
    const importance = clamp(raw?.importance ?? 0.55, 0, 1);
    // 向量：能算就先算，算不出来也不影响保存
    let vec = null;
    if (EMBED_READY) {
      try { vec = (await embedder.embedBatch([content]))?.[0] || null; } catch { vec = null; }
    }
    const existing = handle.prepare("SELECT * FROM nodes WHERE status = 'active' AND kind = ? ORDER BY created_at DESC LIMIT 200").all(kind);
    let best = null;
    let bestSim = 0;
    for (const row of existing) {
      let sim = similarity(content, row.content);
      if (vec) {
        const other = blobToVec(row.embedding);
        if (other && other.length === vec.length) sim = Math.max(sim, cosine(vec, other));
      }
      if (sim > bestSim) { bestSim = sim; best = row; }
    }
    if (best && bestSim >= 0.82) {
      // 复述并入：强化已有条目，不新建
      const merged = String(best.content).length >= content.length ? best.content : content;
      handle.prepare('UPDATE nodes SET content = ?, confidence = ?, importance = ?, access_count = access_count + 1, last_accessed_at = ? WHERE id = ?')
        .run(merged, clamp((best.confidence || 0.3) + 0.05, 0, 1), Math.max(best.importance || 0, importance), now(), best.id);
      ftsUpsert(handle, best.id, merged);
      logOp(handle, 'save-merge', best.id, JSON.stringify({ sim: Number(bestSim.toFixed(3)), content: content.slice(0, 160) }));
      results.push({ ok: true, disposition: 'merge', id: best.id, mergedInto: best.id, similarity: Number(bestSim.toFixed(3)) });
      continue;
    }
    const id = uid();
    const slot = assignSlot(handle, kind);
    const imagery = raw?.placard ? JSON.stringify({ placard: String(raw.placard).slice(0, 40) }) : null;
    const created = now();
    handle.prepare(
      `INSERT INTO nodes (id, scope, kind, content, importance, confidence, status, created_at, last_accessed_at,
        access_count, source_session_id, source_round, source_seq, embedding, imagery_json, slot_room, slot_index,
        next_review_at, ease_factor, interval_days, review_reps)
       VALUES (?, ?, ?, ?, ?, ?, 'active', ?, ?, 0, ?, ?, ?, ?, ?, ?, ?, ?, 2.5, 1, 0)`
    ).run(id, args.scope || 'user', kind, content, importance, 0.3, created, created,
      args.sessionId || null, Number.isFinite(args.round) ? args.round : null, Number.isFinite(args.seq) ? args.seq : null,
      vec ? vecToBlob(vec) : null, imagery, slot.room, slot.index, created + DAY);
    ftsUpsert(handle, id, content);
    routeAppend(handle, id);
    const mentions = Array.isArray(raw?.entities) ? raw.entities.slice(0, 10) : [];
    for (const m of mentions) {
      const name = typeof m === 'string' ? m : m?.name;
      const kindOf = typeof m === 'string' ? 'other' : m?.kind || 'other';
      const entity = upsertEntity(handle, name, kindOf);
      if (!entity) continue;
      try { handle.prepare('INSERT OR IGNORE INTO node_entities (node_id, entity_id) VALUES (?, ?)').run(id, entity.id); } catch { }
    }
    logOp(handle, 'save', id, JSON.stringify({ kind, room: slot.room, slot: slot.index, content: content.slice(0, 160) }));
    results.push({ ok: true, disposition: 'accept', id, room: slot.room, slot: slot.index, kind });
  }
  return { count: results.filter((r) => r.ok).length, items: results };
}

const batches = new Map();

async function opSearch(handle, args) {
  const scopes = args.scope === 'all' || !args.scope ? scopeList() : [String(args.scope)];
  const limit = clamp(args.limit ?? 8, 1, 30);
  const weights = { keyword: 1, recency: 0.2, proof: 0.1 };
  // 有向量后端就算一次查询向量；失败就退回纯关键词排序（不影响可用性）
  let queryVec = null;
  if (args.query && EMBED_READY) {
    try {
      const vecs = await embedder.embedBatch([args.query]);
      queryVec = vecs?.[0] || null;
    } catch { queryVec = null; }
  }
  const candidates = [];
  for (const scope of scopes) {
    let entry;
    try { entry = db(scope); } catch { continue; }
    const rows = args.room
      ? entry.db.prepare("SELECT * FROM nodes WHERE status = 'active' AND slot_room LIKE ? ").all(`${args.room}%`)
      : entry.db.prepare("SELECT * FROM nodes WHERE status = 'active'").all();
    for (const row of rows) candidates.push({ row, scope, handle: entry.db });
  }
  const scored = candidates
    .map((c) => {
      let sim = null;
      if (queryVec) {
        const vec = blobToVec(c.row.embedding);
        if (vec && vec.length === queryVec.length) sim = cosine(queryVec, vec);
      }
      return { ...c, sim, score: rankScore(c.row, args.query, weights, sim) };
    })
    .sort((a, b) => b.score - a.score);
  // 有关键词时必须"有点关系"：关键词覆盖 ≥ 0.12，或向量余弦 ≥ 0.45 —— 否则宁可返回空，不要硬凑
  const filtered = args.query
    ? scored.filter((c) => keywordScore(c.row, args.query) >= 0.12 || (c.sim != null && c.sim >= 0.45))
    : scored;
  // 跨库去重：同一条记忆可能同时存在于 user 与 project 库（迁移时被复制过），只留分数最高的那份
  const seenContent = new Set();
  const deduped = filtered.filter((c) => {
    const key = String(c.row.content || '').replace(/\s+/g, '').slice(0, 80);
    if (seenContent.has(key)) return false;
    seenContent.add(key);
    return true;
  });
  const picked = deduped.slice(0, limit);  const batchId = `b${Date.now().toString(36)}${Math.floor(Math.random() * 1e3)}`;
  const refs = [];
  const hits = picked.map((c, i) => {
    const ref = `r${i + 1}`;
    refs.push({ ref, id: c.row.id, scope: c.scope });
    reinforce(c.handle, c.row);
    const neighbors = [];
    if (i < 5) {
      const group = String(c.row.slot_room || '').replace(/-\d+$/, '');
      const near = c.handle.prepare("SELECT id, slot_room, slot_index, content FROM nodes WHERE status='active' AND slot_room LIKE ? AND id != ? ORDER BY ABS(COALESCE(slot_index,0) - ?) LIMIT 2").all(`${group}%`, c.row.id, c.row.slot_index || 0);
      for (const n of near) neighbors.push({ id: n.id, room: n.slot_room, slot: n.slot_index, hint: String(n.content).slice(0, 24) });
    }
    return {
      ref,
      scope: c.scope,
      ...shape(c.row),
      score: Number(c.score.toFixed(3)),
      similarity: c.sim == null ? null : Number(c.sim.toFixed(3)),
      entities: entitiesOf(c.handle, c.row.id).map((e) => e.name),
      neighbors
    };
  });
  batches.set(batchId, { at: now(), refs, sessionId: args.sessionId || null });
  if (batches.size > 40) batches.delete(batches.keys().next().value);
  logOp(handle, 'search', 'QUERY', JSON.stringify({ query: String(args.query || '').slice(0, 120), hits: hits.length, batchId }));
  return { batchId, count: hits.length, hits };
}

function opAssess(handle, args) {
  const batch = batches.get(String(args.batchId || ''));
  if (!batch) return { ok: false, error: '批次不存在或已过期，请重新检索' };
  const valid = new Set(batch.refs.map((r) => r.ref));
  const given = (Array.isArray(args.evidenceRefs) ? args.evidenceRefs : []).map(String);
  const rejected = given.filter((r) => !valid.has(r));
  const usable = given.filter((r) => valid.has(r));
  const sufficient = args.sufficient === true && usable.length > 0 && args.nextStrategy === 'answer';
  logOp(handle, 'assess', String(args.batchId), JSON.stringify({ sufficient, usable, rejected, missing: args.missing || '' }));
  return {
    sufficient,
    usable,
    rejected,
    missing: args.missing || '',
    nextStrategy: sufficient ? 'answer' : args.nextStrategy || 'search_keyword',
    note: sufficient ? '证据够用，可以作答' : '判定为不足：继续检索或换关键词（sufficient 需要「声称充足 + 至少一条本批次证据 + nextStrategy=answer」三者齐备）'
  };
}

function opExamine(handle, args) {
  const ids = (Array.isArray(args.ids) ? args.ids : [args.id]).filter(Boolean).slice(0, 16);
  const out = [];
  for (const id of ids) {
    const row = handle.prepare('SELECT * FROM nodes WHERE id = ?').get(String(id));
    if (!row) { out.push({ id, missing: true }); continue; }
    const facts = handle.prepare(
      `SELECT f.* FROM facts f JOIN node_entities ne ON ne.entity_id = f.entity_id WHERE ne.node_id = ? ORDER BY f.created_at DESC LIMIT 10`
    ).all(row.id);
    out.push({ ...shape(row), entities: entitiesOf(handle, row.id), facts: facts.map((f) => ({ id: f.id, content: f.content, validAt: f.valid_at, invalidAt: f.invalid_at, replacedBy: f.replaced_by })) });
  }
  return { items: out };
}

function opUpdate(handle, args) {
  const row = handle.prepare('SELECT * FROM nodes WHERE id = ?').get(String(args.id || ''));
  if (!row) return { ok: false, error: '条目不存在' };
  const content = String(args.content || '').trim();
  if (!content) return { ok: false, error: 'content 不能为空' };
  const kind = KINDS.includes(args.kind) ? args.kind : row.kind;
  handle.prepare('INSERT INTO nodes_revisions (node_id, content, kind, importance, superseded_at) VALUES (?, ?, ?, ?, ?)')
    .run(row.id, row.content, row.kind, row.importance, now());
  const imagery = args.placard ? JSON.stringify({ placard: String(args.placard).slice(0, 40) }) : row.imagery_json;
  handle.prepare('UPDATE nodes SET content = ?, kind = ?, imagery_json = ?, confidence = ? WHERE id = ?')
    .run(content, kind, imagery, clamp((row.confidence || 0.3) + 0.05, 0, 1), row.id);
  ftsUpsert(handle, row.id, content);
  try {
    handle.prepare("INSERT OR REPLACE INTO edges (from_id, to_id, type, created_at) VALUES (?, ?, 'supersedes', ?)").run(uid(), row.id, now());
  } catch { }
  logOp(handle, 'update', row.id, JSON.stringify({ before: row.content.slice(0, 120), after: content.slice(0, 120) }));
  return { ok: true, id: row.id, supersedes: true };
}

function opForget(handle, args) {
  const row = handle.prepare('SELECT * FROM nodes WHERE id = ?').get(String(args.id || ''));
  if (!row) return { ok: false, error: '条目不存在' };
  const epitaph = { reason: String(args.reason || ''), affects: String(args.affects || ''), stillUseful: String(args.stillUseful || ''), at: now() };
  handle.prepare("UPDATE nodes SET status = 'archived' WHERE id = ?").run(row.id);
  logOp(handle, 'forget', row.id, JSON.stringify(epitaph));
  return { ok: true, id: row.id, status: 'archived', epitaph };
}

function opReport(handle, args) {
  const row = handle.prepare('SELECT * FROM nodes WHERE id = ?').get(String(args.id || ''));
  if (!row) return { ok: false, error: '条目不存在' };
  const grade = Number.isFinite(args.grade) ? clamp(args.grade, 0, 5) : null;
  let outcome = row.outcome || null;
  let confidence = row.confidence || 0.3;
  let ease = row.ease_factor || 2.5;
  let interval = row.interval_days || 1;
  let reps = row.review_reps || 0;
  if (grade !== null) {
    if (grade >= 3) {
      ease = clamp(ease + 0.1 - (5 - grade) * (0.08 + (5 - grade) * 0.02), 1.3, 2.8);
      reps += 1;
      interval = reps === 1 ? 1 : reps === 2 ? 6 : Math.round(interval * ease);
      confidence = clamp(confidence + 0.05, 0, 1);
    } else {
      reps = 0;
      interval = 1;
      ease = clamp(ease - 0.2, 1.3, 2.8);
      confidence = clamp(confidence - 0.1, 0, 1);
    }
    const next = now() + interval * DAY;
    handle.prepare('UPDATE nodes SET confidence = ?, ease_factor = ?, interval_days = ?, review_reps = ?, next_review_at = ?, last_accessed_at = ? WHERE id = ?')
      .run(confidence, ease, interval, reps, next, now(), row.id);
    logOp(handle, 'review-grade', row.id, JSON.stringify({ grade, reps, interval, ease: Number(ease.toFixed(2)) }));
    return { ok: true, id: row.id, grade, reps, intervalDays: interval, easeFactor: Number(ease.toFixed(2)), nextReviewAt: next };
  }
  if (args.outcome === 'success') { confidence = clamp(confidence + 0.05, 0, 1); outcome = 'success'; }
  else if (args.outcome === 'failure') { confidence = clamp(confidence - 0.1, 0, 1); outcome = 'failure'; }
  handle.prepare('UPDATE nodes SET confidence = ?, outcome = ? WHERE id = ?').run(confidence, outcome, row.id);
  logOp(handle, 'report', row.id, JSON.stringify({ outcome: args.outcome || null, confidence: Number(confidence.toFixed(2)) }));
  return { ok: true, id: row.id, outcome, confidence: Number(confidence.toFixed(2)) };
}

function opReviewQueue(handle, args) {
  const limit = clamp(args.limit ?? 10, 1, 50);
  const rows = handle.prepare("SELECT * FROM nodes WHERE status = 'active' AND next_review_at IS NOT NULL AND next_review_at <= ? ORDER BY next_review_at ASC LIMIT ?").all(now(), limit);
  return {
    count: rows.length,
    items: rows.map((r) => ({
      id: r.id,
      ref: `${r.slot_room}#${r.slot_index}`,
      room: r.slot_room,
      slot: r.slot_index,
      placard: placardOf(r),
      kind: r.kind,
      overdueDays: r.next_review_at ? Math.max(0, Math.floor((now() - r.next_review_at) / DAY)) : 0,
      hint: `${placardOf(r) ? `「${placardOf(r)}」` : ''}房间「${r.slot_room}」第 ${r.slot_index} 桩 · ${r.kind}`
    }))
  };
}

function opReview(handle, args) {
  const row = handle.prepare('SELECT * FROM nodes WHERE id = ?').get(String(args.id || ''));
  if (!row) return { ok: false, error: '条目不存在' };
  const revisions = handle.prepare('SELECT * FROM nodes_revisions WHERE node_id = ? ORDER BY superseded_at DESC LIMIT 10').all(row.id);
  const edges = handle.prepare('SELECT * FROM edges WHERE from_id = ? OR to_id = ? LIMIT 40').all(row.id, row.id);
  const ops = handle.prepare('SELECT * FROM op_log WHERE target_id = ? ORDER BY seq DESC LIMIT 20').all(row.id);
  const facts = handle.prepare(
    `SELECT f.* FROM facts f JOIN node_entities ne ON ne.entity_id = f.entity_id WHERE ne.node_id = ? ORDER BY f.created_at DESC LIMIT 10`
  ).all(row.id);
  return {
    node: shape(row),
    entities: entitiesOf(handle, row.id),
    revisions: revisions.map((r) => ({ content: r.content, kind: r.kind, importance: r.importance, supersededAt: r.superseded_at })),
    edges,
    facts,
    ops: ops.map((o) => ({ at: o.at, op: o.op, detail: String(o.detail || '').slice(0, 400) }))
  };
}

function opFacts(handle, args) {
  if (Array.isArray(args.facts)) {
    const results = [];
    for (const raw of args.facts.slice(0, 50)) {
      const content = String(raw?.content || '').trim();
      if (!content) { results.push({ ok: false, error: 'content 为空' }); continue; }
      let entityId = raw?.entityId ? String(raw.entityId) : null;
      if (!entityId) {
        const name = String(raw?.entity || '').trim();
        if (!name) { results.push({ ok: false, error: '缺 entity 或 entityId' }); continue; }
        const found = entitiesByName(handle, name);
        entityId = found[0]?.id || upsertEntity(handle, name, 'other')?.id || null;
      }
      if (!entityId) { results.push({ ok: false, error: '实体不存在且无法创建' }); continue; }
      const id = uid();
      const at = now();
      handle.prepare('INSERT INTO facts (id, entity_id, content, valid_at, invalid_at, replaced_by, source_node_id, created_at, updated_at) VALUES (?, ?, ?, ?, NULL, NULL, ?, ?, ?)')
        .run(id, entityId, content, at, args.sourceNodeId || null, at, at);
      let replaced = null;
      if (raw?.replaces) {
        const old = handle.prepare('SELECT * FROM facts WHERE id = ?').get(String(raw.replaces));
        if (old) {
          handle.prepare('UPDATE facts SET invalid_at = ?, replaced_by = ?, updated_at = ? WHERE id = ?').run(at, id, at, old.id);
          replaced = old.id;
        }
      }
      logOp(handle, 'fact-write', id, JSON.stringify({ entityId, replaces: replaced }));
      results.push({ ok: true, id, entityId, replaces: replaced });
    }
    return { count: results.filter((r) => r.ok).length, items: results };
  }
  const entityId = args.entityId ? String(args.entityId) : null;
  const name = args.entity ? String(args.entity) : '';
  let resolved = entityId;
  let candidates = [];
  if (!resolved && name) {
    const found = entitiesByName(handle, name);
    const exact = found.find((e) => e.name === name);
    candidates = found.map((e) => ({ id: e.id, name: e.name, kind: e.kind }));
    resolved = exact?.id || null;
  }
  if (!resolved) return { entity: name || null, found: false, candidates };
  const clauses = ['entity_id = ?'];
  const params = [resolved];
  if (!args.includeInvalid) clauses.push('invalid_at IS NULL');
  if (args.asOf) { clauses.push('valid_at <= ?'); params.push(Number(args.asOf)); clauses.push('(invalid_at IS NULL OR invalid_at > ?)'); params.push(Number(args.asOf)); }
  const rows = handle.prepare(`SELECT * FROM facts WHERE ${clauses.join(' AND ')} ORDER BY created_at DESC LIMIT ?`).all(...params, clamp(args.limit ?? 20, 1, 100));
  const entity = handle.prepare('SELECT * FROM entities WHERE id = ?').get(resolved);
  return { entity: entity ? { id: entity.id, name: entity.name, kind: entity.kind } : null, found: true, count: rows.length, facts: rows.map((f) => ({ id: f.id, content: f.content, validAt: f.valid_at, invalidAt: f.invalid_at, replacedBy: f.replaced_by })) };
}

function opNeighbors(handle, args) {
  const depth = clamp(args.depth ?? 1, 1, 3);
  const seen = new Set([String(args.id)]);
  let frontier = [String(args.id)];
  const out = [];
  for (let d = 0; d < depth; d++) {
    const next = [];
    for (const id of frontier) {
      const rows = handle.prepare('SELECT from_id, to_id, type FROM edges WHERE from_id = ? OR to_id = ?').all(id, id);
      for (const e of rows) {
        const other = e.from_id === id ? e.to_id : e.from_id;
        if (seen.has(other)) continue;
        seen.add(other);
        const row = handle.prepare('SELECT * FROM nodes WHERE id = ?').get(other);
        if (!row) continue;
        out.push({ hop: d + 1, type: e.type, ...shape(row), content: String(row.content).slice(0, 120) });
        next.push(other);
      }
    }
    frontier = next;
    if (!frontier.length) break;
  }
  return { count: out.length, items: out };
}

function opTimeline(handle, args) {
  const limit = clamp(args.limit ?? 20, 1, 100);
  if (args.order === 'tour') {
    const rows = handle.prepare(
      `SELECT n.*, r.position FROM tour_routes r JOIN nodes n ON n.id = r.node_id WHERE n.status = 'active' ORDER BY r.position ASC LIMIT ?`
    ).all(limit);
    return { order: 'tour', count: rows.length, items: rows.map((r) => ({ ...shape(r), tourPosition: r.position })) };
  }
  const clauses = ["status = 'active'"];
  const params = [];
  if (args.since) { clauses.push('created_at >= ?'); params.push(Number(args.since)); }
  if (args.until) { clauses.push('created_at <= ?'); params.push(Number(args.until)); }
  if (args.topic) { clauses.push('content LIKE ?'); params.push(`%${args.topic}%`); }
  const rows = handle.prepare(`SELECT * FROM nodes WHERE ${clauses.join(' AND ')} ORDER BY created_at DESC LIMIT ?`).all(...params, limit);
  return { order: 'time', count: rows.length, items: rows.map((r) => ({ ...shape(r), content: String(r.content).slice(0, 200) })) };
}

function opTour(handle, args) {
  const mode = args.mode === 'fixed' ? 'fixed' : 'thematic';
  const max = clamp(args.maxStops ?? (mode === 'fixed' ? 20 : 6), 3, 30);
  if (mode === 'fixed') {
    const rows = handle.prepare(`SELECT n.*, r.position FROM tour_routes r JOIN nodes n ON n.id = r.node_id WHERE n.status = 'active' ORDER BY r.position ASC LIMIT ?`).all(max);
    return { mode, stops: rows.map((r) => ({ position: r.position, id: r.id, room: r.slot_room, slot: r.slot_index, placard: placardOf(r), content: String(r.content).slice(0, 160) })) };
  }
  const q = String(args.query || '').trim();
  const rows = handle.prepare("SELECT * FROM nodes WHERE status = 'active'").all();
  const scored = rows.map((r) => ({ r, s: rankScore(r, q, { keyword: 1, recency: 0.2, proof: 0.1 }) })).sort((a, b) => b.s - a.s).slice(0, max);
  return { mode, query: q, stops: scored.map((x, i) => ({ position: i, id: x.r.id, room: x.r.slot_room, slot: x.r.slot_index, placard: placardOf(x.r), content: String(x.r.content).slice(0, 160), score: Number(x.s.toFixed(3)) })) };
}

function opStats(handle, args) {
  const wantAll = !args.scope || args.scope === 'all';
  const scopes = wantAll ? ['user', 'shared', ...scopeList().filter((s) => s.startsWith('project-'))] : [String(args.scope)];
  const unique = [...new Set(scopes)];
  const perScope = [];
  const totals = { nodes: 0, active: 0, archived: 0, facts: 0, entities: 0, edges: 0, opLog: 0, reviewDue: 0 };
  for (const scope of unique) {
    let entry;
    try { entry = db(scope); } catch { continue; }
    const h = entry.db;
    const row = {
      scope,
      file: path.basename(entry.file),
      nodes: h.prepare('SELECT COUNT(*) c FROM nodes').get().c,
      active: h.prepare("SELECT COUNT(*) c FROM nodes WHERE status = 'active'").get().c,
      archived: h.prepare("SELECT COUNT(*) c FROM nodes WHERE status = 'archived'").get().c,
      facts: h.prepare('SELECT COUNT(*) c FROM facts').get().c,
      entities: h.prepare('SELECT COUNT(*) c FROM entities').get().c,
      edges: h.prepare('SELECT COUNT(*) c FROM edges').get().c,
      opLog: h.prepare('SELECT COUNT(*) c FROM op_log').get().c,
      reviewDue: h.prepare("SELECT COUNT(*) c FROM nodes WHERE status='active' AND next_review_at IS NOT NULL AND next_review_at <= ?").get(now()).c
    };
    perScope.push(row);
    totals.nodes += row.nodes;
    totals.active += row.active;
    totals.archived += row.archived;
    totals.facts += row.facts;
    totals.entities += row.entities;
    totals.edges += row.edges;
    totals.opLog += row.opLog;
    totals.reviewDue += row.reviewDue;
  }
  const home = wantAll ? db('user').db : handle;
  // ⚠️ scope=all 时这些"分布"必须跨库求和：只用 user.db 会让人以为整座宫殿只有那几十条。
  const handles = wantAll
    ? unique.map((s) => { try { return db(s).db; } catch { return null; } }).filter(Boolean)
    : [handle];
  const byKindMap = new Map();
  const byStatusMap = new Map();
  const roomMap = new Map();
  let confSum = 0;
  let confCount = 0;
  for (const h of handles) {
    for (const r of h.prepare('SELECT kind, COUNT(*) c FROM nodes GROUP BY kind').all()) {
      byKindMap.set(r.kind, (byKindMap.get(r.kind) || 0) + Number(r.c || 0));
    }
    for (const r of h.prepare('SELECT status, COUNT(*) c FROM nodes GROUP BY status').all()) {
      byStatusMap.set(r.status, (byStatusMap.get(r.status) || 0) + Number(r.c || 0));
    }
    for (const r of h.prepare('SELECT slot_room, COUNT(*) c FROM nodes GROUP BY slot_room').all()) {
      roomMap.set(r.slot_room, (roomMap.get(r.slot_room) || 0) + Number(r.c || 0));
    }
    const row = h.prepare("SELECT SUM(confidence) s, COUNT(*) c FROM nodes WHERE status = 'active'").get();
    if (row && row.c) {
      confSum += Number(row.s || 0);
      confCount += Number(row.c || 0);
    }
  }
  const byKind = [...byKindMap.entries()].map(([kind, c]) => ({ kind, c })).sort((a, b) => b.c - a.c);
  const byStatus = [...byStatusMap.entries()].map(([status, c]) => ({ status, c }));
  const avgConfidence = confCount ? confSum / confCount : 0;
  const latest = [...roomMap.keys()].sort().map((room) => {
    let latestText = '';
    for (const h of handles) {
      const row = h.prepare('SELECT * FROM nodes WHERE slot_room = ? ORDER BY created_at DESC LIMIT 1').get(room);
      if (row) {
        latestText = placardOf(row) || String(row.content).slice(0, 24);
        break;
      }
    }
    return { room, slots: roomMap.get(room) || 0, latest: latestText };
  });
  return {
    scope: wantAll ? 'all' : unique[0],
    dbDir: DB_DIR,
    nodes: wantAll ? totals.nodes : home.prepare('SELECT COUNT(*) c FROM nodes').get().c,
    totals: wantAll ? totals : undefined,
    perScope,
    byStatus,
    byKind,
    rooms: latest,
    avgConfidence: Number(avgConfidence.toFixed(3)),
    edges: wantAll ? totals.edges : home.prepare('SELECT COUNT(*) c FROM edges').get().c,
    facts: wantAll ? totals.facts : home.prepare('SELECT COUNT(*) c FROM facts').get().c,
    entities: wantAll ? totals.entities : home.prepare('SELECT COUNT(*) c FROM entities').get().c,
    opLog: wantAll ? totals.opLog : home.prepare('SELECT COUNT(*) c FROM op_log').get().c,
    reviewDue: wantAll
      ? totals.reviewDue
      : home.prepare("SELECT COUNT(*) c FROM nodes WHERE status='active' AND next_review_at IS NOT NULL AND next_review_at <= ?").get(now()).c
  };
}

function opAuditForgotten(handle, args) {
  const limit = clamp(args.limit ?? 20, 1, 100);
  const rows = handle.prepare("SELECT * FROM nodes WHERE status = 'archived' ORDER BY last_accessed_at DESC LIMIT ?").all(limit);
  return {
    count: rows.length,
    items: rows.map((r) => {
      const op = handle.prepare("SELECT * FROM op_log WHERE target_id = ? AND op = 'forget' ORDER BY seq DESC LIMIT 1").get(r.id);
      let epitaph = null;
      try { epitaph = op?.detail ? JSON.parse(op.detail) : null; } catch { epitaph = null; }
      return { id: r.id, room: r.slot_room, slot: r.slot_index, content: String(r.content).slice(0, 120), epitaph };
    })
  };
}

function opProfile(handle, args) {
  const scope = args.scope || 'user';
  if (args.action === 'view') {
    const row = handle.prepare('SELECT * FROM profile_blocks WHERE scope = ?').get(scope);
    const versions = handle.prepare('SELECT version, source, at, content FROM profile_block_versions WHERE scope = ? ORDER BY version DESC LIMIT 10').all(scope);
    return { scope, block: row ? { content: row.content, version: row.version, updatedAt: row.updated_at } : null, versions };
  }
  if (args.action === 'edit') {
    const content = String(args.content || '');
    if (!content.trim()) return { ok: false, error: 'content 为空' };
    const row = handle.prepare('SELECT * FROM profile_blocks WHERE scope = ?').get(scope);
    const expected = Number.isFinite(args.expectedVersion) ? Number(args.expectedVersion) : null;
    if (row && expected !== null && expected !== row.version) return { ok: false, error: `版本冲突：当前是 v${row.version}` };
    const version = (row?.version || 0) + 1;
    handle.prepare('INSERT OR REPLACE INTO profile_blocks (scope, content, version, updated_at) VALUES (?, ?, ?, ?)').run(scope, content, version, now());
    handle.prepare('INSERT INTO profile_block_versions (scope, version, content, source, at) VALUES (?, ?, ?, ?, ?)').run(scope, version, content, 'edit', now());
    logOp(handle, 'profile-edit', scope, JSON.stringify({ version }));
    return { ok: true, scope, version };
  }
  if (args.action === 'rollback') {
    const target = Number(args.toVersion);
    const row = handle.prepare('SELECT * FROM profile_block_versions WHERE scope = ? AND version = ?').get(scope, target);
    if (!row) return { ok: false, error: '版本不存在' };
    const current = handle.prepare('SELECT * FROM profile_blocks WHERE scope = ?').get(scope);
    const version = (current?.version || 0) + 1;
    handle.prepare('INSERT OR REPLACE INTO profile_blocks (scope, content, version, updated_at) VALUES (?, ?, ?, ?)').run(scope, row.content, version, now());
    handle.prepare('INSERT INTO profile_block_versions (scope, version, content, source, at) VALUES (?, ?, ?, ?, ?)').run(scope, version, row.content, `rollback:v${target}`, now());
    logOp(handle, 'profile-rollback', scope, JSON.stringify({ from: version, to: target }));
    return { ok: true, scope, version };
  }
  return { ok: false, error: 'action 只能是 view / edit / rollback' };
}

function opEpisodeTimeline(handle, args) {
  const clauses = ["status = 'active'", "kind = 'episode'"];
  const params = [];
  if (args.since) { clauses.push('created_at >= ?'); params.push(Number(args.since)); }
  if (args.until) { clauses.push('created_at <= ?'); params.push(Number(args.until)); }
  if (args.sessionId) { clauses.push('source_session_id = ?'); params.push(String(args.sessionId)); }
  const rows = handle.prepare(`SELECT * FROM nodes WHERE ${clauses.join(' AND ')} ORDER BY source_session_id, created_at ASC LIMIT ?`).all(...params, clamp(args.limit ?? 100, 1, 200));
  const groups = new Map();
  for (const r of rows) {
    const key = r.source_session_id || '(未知会话)';
    if (!groups.has(key)) groups.set(key, []);
    groups.get(key).push({ id: r.id, at: r.created_at, content: String(r.content).slice(0, 200), room: r.slot_room, slot: r.slot_index });
  }
  const summaries = handle.prepare('SELECT session_id, summary FROM session_summaries').all();
  const summaryMap = new Map(summaries.map((s) => [s.session_id, s.summary]));
  const out = [...groups.entries()].map(([sessionId, items]) => ({ sessionId, summary: summaryMap.get(sessionId) || '', count: items.length, items }));
  out.sort((a, b) => (b.items.at(-1)?.at || 0) - (a.items.at(-1)?.at || 0));
  return { count: rows.length, groups: out };
}

function opExport(handle, args) {
  const rows = handle.prepare("SELECT * FROM nodes WHERE status != 'dropped' ORDER BY created_at ASC").all();
  const facts = handle.prepare('SELECT * FROM facts ORDER BY created_at ASC').all();
  const entities = handle.prepare('SELECT * FROM entities ORDER BY created_at ASC').all();
  const edges = handle.prepare('SELECT * FROM edges').all();
  const redacted = args.redactedView === true;
  const clean = (text) => {
    const t = String(text || '');
    if (!redacted) return t;
    return t.replace(/[A-Za-z]:\\[^\s"']+/g, '<路径>').replace(/[0-9]{6,}/g, '<数字>').slice(0, 40);
  };
  const payload = {
    exportedAt: now(),
    schema: 13,
    redacted,
    nodes: rows.map((r) => ({ ...shape(r), content: clean(r.content) })),
    entities,
    facts: facts.map((f) => ({ ...f, content: clean(f.content) })),
    edges
  };
  const outDir = path.resolve(DB_DIR, '..', 'exports');
  fs.mkdirSync(outDir, { recursive: true });
  const stamp = new Date().toISOString().replace(/[:.]/g, '-');
  if (String(args.format || 'json') === 'markdown') {
    const file = path.join(outDir, `palace-${stamp}.md`);
    const lines = [`# 记忆宫殿导出 ${new Date().toLocaleString('zh-CN')}`, ''];
    for (const n of payload.nodes) {
      lines.push(`## ${n.room} · ${n.slot} · ${n.kind}`);
      lines.push(`- id: ${n.id}`);
      if (n.placard) lines.push(`- 门牌: ${n.placard}`);
      lines.push('', n.content, '');
    }
    fs.writeFileSync(file, lines.join('\n'), 'utf8');
    return { ok: true, format: 'markdown', file, nodes: payload.nodes.length };
  }
  const file = path.join(outDir, `palace-${stamp}.json`);
  fs.writeFileSync(file, JSON.stringify(payload, null, 2), 'utf8');
  return { ok: true, format: 'json', file, nodes: payload.nodes.length, entities: entities.length, facts: facts.length };
}

async function opContext(handle, args) {
  const limit = clamp(args.limit ?? 5, 0, 12);
  const budget = clamp(args.injectChars ?? 2000, 200, 8000);
  const profileRow = handle.prepare("SELECT * FROM profile_blocks WHERE scope = 'user'").get();
  const items = limit > 0 ? (await opSearch(handle, { query: args.query || '', scope: args.scope || 'all', limit })).hits : [];
  const lines = [];
  let used = 0;
  if (profileRow) {
    const head = `【画像】${String(profileRow.content).trim()}`;
    lines.push(head.slice(0, 600));
    used += Math.min(head.length, 600);
  }
  for (const hit of items) {
    const line = `· [${hit.room}#${hit.slot}${hit.placard ? ` · ${hit.placard}` : ''}] ${String(hit.content).replace(/\s+/g, ' ').slice(0, 160)}`;
    if (used + line.length > budget) break;
    lines.push(line);
    used += line.length;
  }
  return { text: lines.join('\n'), chars: used, hits: items.map((i) => ({ id: i.id, room: i.room, slot: i.slot, score: i.score })) };
}

/* ────────────────────────────── 向量模型 ────────────────────────────── */

function embeddingCoverage() {
  const rows = [];
  let total = 0;
  let withVec = 0;
  for (const scope of scopeList()) {
    let entry;
    try { entry = db(scope); } catch { continue; }
    const t = entry.db.prepare("SELECT COUNT(*) c FROM nodes WHERE status = 'active'").get().c;
    const v = entry.db.prepare("SELECT COUNT(*) c FROM nodes WHERE status = 'active' AND embedding IS NOT NULL").get().c;
    total += t; withVec += v;
    rows.push({ scope, nodes: t, vectors: v });
  }
  return { total, withVec, percent: total ? Math.round((withVec / total) * 100) : 0, perScope: rows };
}

async function opEmbedStatus() {
  const s = embedder.status();
  return { ...s, coverage: embeddingCoverage() };
}

async function opEmbedConfigure(handle, args) {
  const patch = {
    backend: args.backend,
    model: args.model,
    endpoint: args.endpoint,
    apiKeyEnv: args.apiKeyEnv
  };
  const status = embedder.configure(patch);
  if (args.warm !== false) await embedder.ensure();
  return { ...embedder.status(), applied: status.backend, coverage: embeddingCoverage() };
}

let setupTask = null;
async function opEmbedSetup(handle, args) {
  if (setupTask) return { started: true, running: true, status: embedder.status() };
  const install = args.install !== false;
  setupTask = (async () => {
    try {
      await embedder.setup({ install, onProgress: (msg) => log('info', msg) });
    } catch (error) {
      log('warn', `自主部署失败：${error.message}`);
    } finally {
      setupTask = null;
    }
  })();
  return { started: true, running: true, backend: embedder.status().backend };
}

async function opReindex(handle, args) {
  const maxNodes = clamp(args.maxNodes ?? 64, 1, 400);
  const scopeArg = args.scope && args.scope !== 'all' ? String(args.scope) : '';
  const scopes = scopeArg ? [scopeArg] : scopeList();
  let processed = 0;
  let failed = 0;
  for (const scope of scopes) {
    if (processed >= maxNodes) break;
    let entry;
    try { entry = db(scope); } catch { continue; }
    const rows = entry.db.prepare("SELECT id, content FROM nodes WHERE status = 'active' AND embedding IS NULL LIMIT ?").all(maxNodes - processed);
    if (!rows.length) continue;
    const vecs = await embedder.embedBatch(rows.map((r) => r.content));
    const upd = entry.db.prepare('UPDATE nodes SET embedding = ? WHERE id = ?');
    for (let i = 0; i < rows.length; i += 1) {
      if (!vecs[i]) { failed += 1; continue; }
      upd.run(vecToBlob(vecs[i]), rows[i].id);
      processed += 1;
    }
  }
  return { processed, failed, coverage: embeddingCoverage(), done: embeddingCoverage().withVec >= embeddingCoverage().total };
}

/* ───────────── 蒸馏 / 信念巩固 / 历史回填（与 DSH engram 对齐的三个整理动作）───────────── */

// 房间归类：slot_room 带溢出后缀（fact-2 / fact-3 …），归并到同一个「房间」看
function roomOf(row) {
  return String(row.slot_room || row.kind || 'fact').replace(/-\d+$/, '');
}

function round3(value) {
  return Number((Number(value) || 0).toFixed(3));
}

function pickRepresentative(members) {
  let best = members[0];
  for (const row of members) {
    if (String(row.content).length > String(best.content).length) best = row;
  }
  return best;
}

// 同一房间里把「几乎在说一件事」的几条聚成一簇（bigram 相似度，不依赖向量）
function clusterRows(list, threshold, minSize) {
  const used = new Set();
  const clusters = [];
  for (const row of list) {
    if (used.has(row.id)) continue;
    used.add(row.id);
    const members = [row];
    for (const other of list) {
      if (used.has(other.id)) continue;
      if (similarity(row.content, other.content) >= threshold) {
        used.add(other.id);
        members.push(other);
      }
    }
    if (members.length >= minSize) clusters.push(members);
  }
  return clusters;
}

/**
 * 蒸馏：把同房间的一簇近义条目合并成一条更高层的规律，旧条目软归档。
 * 默认 dry-run（只出候选），apply:true 才写库 —— 记忆写坏比漏写更麻烦。
 */
async function opDistill(handle, args) {
  const scopes = args.scope === 'all' || !args.scope ? scopeList() : [String(args.scope)];
  const minSize = clamp(args.minSize ?? 3, 2, 8);
  const threshold = clamp(args.threshold ?? 0.62, 0.4, 0.92);
  const apply = args.apply === true;
  const items = [];

  for (const scope of scopes) {
    const entry = db(scope);
    if (!entry) continue;
    const h = entry.db;
    const rows = h.prepare("SELECT * FROM nodes WHERE status = 'active' ORDER BY created_at DESC LIMIT 800").all();
    const byRoom = new Map();
    for (const row of rows) {
      const room = roomOf(row);
      if (!byRoom.has(room)) byRoom.set(room, []);
      byRoom.get(room).push(row);
    }

    for (const [room, list] of byRoom) {
      if (list.length < minSize) continue;
      for (const members of clusterRows(list, threshold, minSize)) {
        const rep = pickRepresentative(members);
        const confSum = members.reduce((sum, m) => sum + (Number(m.confidence) || 0), 0);
        const content = `蒸馏：${String(rep.content).slice(0, 400)}`;
        const item = {
          scope,
          room,
          size: members.length,
          refs: members.map((m) => m.id),
          merged: String(rep.content).slice(0, 400),
          avgConfidence: round3(confSum / members.length)
        };

        if (apply) {
          const id = uid();
          const kind = KINDS.includes(rep.kind) ? rep.kind : 'fact';
          const slot = assignSlot(h, kind);
          const created = now();
          let vec = null;
          if (EMBED_READY) {
            try { vec = (await embedder.embedBatch([content]))?.[0] || null; } catch { vec = null; }
          }
          const confidence = Math.min(0.95, item.avgConfidence + 0.05);
          const importance = Math.max(...members.map((m) => Number(m.importance) || 0));
          h.prepare(
            `INSERT INTO nodes (id, scope, kind, content, importance, confidence, status, created_at, last_accessed_at,
              access_count, source_session_id, source_round, source_seq, embedding, imagery_json, slot_room, slot_index,
              next_review_at, ease_factor, interval_days, review_reps)
             VALUES (?, ?, ?, ?, ?, ?, 'active', ?, ?, 0, ?, NULL, NULL, ?, ?, ?, ?, ?, 2.5, 1, 0)`
          ).run(id, scope, kind, content, importance, confidence, created, created,
            `distill:${room}`, vec ? vecToBlob(vec) : null,
            JSON.stringify({ distilledFrom: item.refs, room }), slot.room, slot.index, created + DAY);
          ftsUpsert(h, id, content);
          routeAppend(h, id);
          for (const member of members) {
            h.prepare("UPDATE nodes SET status = 'superseded' WHERE id = ?").run(member.id);
            try {
              h.prepare('INSERT OR IGNORE INTO edges (from_id, to_id, type, created_at) VALUES (?, ?, ?, ?)')
                .run(id, member.id, 'supersedes', created);
            } catch { /* edges 是加分项，失败不影响归档 */ }
            try {
              h.prepare('INSERT INTO nodes_revisions (node_id, content, kind, importance, superseded_at) VALUES (?, ?, ?, ?, ?)')
                .run(member.id, member.content, member.kind, member.importance, created);
            } catch { /* 旧库可能没有这张表 */ }
          }
          logOp(h, 'distill', id, JSON.stringify({ room, size: members.length, refs: item.refs }));
          item.newId = id;
          item.roomAfter = slot.room;
        }
        items.push(item);
      }
    }
  }

  return { applied: apply, count: items.length, items: items.slice(0, 20) };
}

/**
 * 信念巩固：同一房间里反复出现的说法 → 一条带证据数的信念（observations 表）。
 * 默认写入（DSH 的 reflect 也是直接落信念）；apply:false 只出候选。
 */
async function opReflect(handle, args) {
  const scopes = args.scope === 'all' || !args.scope ? scopeList() : [String(args.scope)];
  const minEvidence = clamp(args.minEvidence ?? 2, 2, 6);
  const apply = args.apply !== false;
  const items = [];

  for (const scope of scopes) {
    const entry = db(scope);
    if (!entry) continue;
    const h = entry.db;
    const rows = h.prepare("SELECT * FROM nodes WHERE status = 'active' ORDER BY importance DESC, created_at DESC LIMIT 600").all();
    const byRoom = new Map();
    for (const row of rows) {
      const room = roomOf(row);
      if (!byRoom.has(room)) byRoom.set(room, []);
      byRoom.get(room).push(row);
    }

    for (const [room, list] of byRoom) {
      if (list.length < minEvidence) continue;
      for (const members of clusterRows(list, 0.5, minEvidence)) {
        const rep = pickRepresentative(members);
        const belief = String(rep.content).slice(0, 200);
        const proof = members.length;
        const item = { scope, room, belief, evidence: proof, refs: members.map((m) => m.id) };
        if (apply) {
          const id = uid();
          const at = now();
          h.prepare(
            `INSERT INTO observations (id, scope, belief, status, sources_json, proof_count, embedding, created_at, updated_at, last_validated_at)
             VALUES (?, ?, ?, 'active', ?, ?, NULL, ?, ?, ?)`
          ).run(id, scope, belief, JSON.stringify(item.refs), proof, at, at, at);
          logOp(h, 'reflect', id, JSON.stringify({ room, proof }));
          item.beliefId = id;
        }
        items.push(item);
      }
    }
  }

  return { applied: apply, count: items.length, items: items.slice(0, 20) };
}

/**
 * 历史回填扫描：把 data/messages 里的聊天记录抽成一段材料，交回模型去提炼。
 * 这里刻意**不直接写库** —— 原始对话不是记忆，必须过一次提炼（模型读完再 palace_save）。
 */
async function opIngestScan(handle, args) {
  const dir = String(args.dir || '').trim();
  if (!dir || !fs.existsSync(dir)) return { ok: false, error: `找不到消息目录：${dir || '（未传 dir）'}` };
  const limitPerChat = clamp(args.limit ?? 80, 10, 400);
  const maxChars = clamp(args.maxChars ?? 6000, 500, 20000);
  let files = [];
  try {
    files = fs.readdirSync(dir).filter((name) => name.endsWith('.json'));
  } catch (error) {
    return { ok: false, error: `读目录失败：${error.message}` };
  }

  const chats = [];
  for (const name of files.slice(0, 8)) {
    let data = null;
    try { data = JSON.parse(fs.readFileSync(path.join(dir, name), 'utf8')); } catch { continue; }
    const messages = Array.isArray(data?.messages) ? data.messages : [];
    if (!messages.length) continue;
    const picked = messages
      .slice(-limitPerChat)
      .filter((m) => String(m?.text || '').trim().length >= 2 && !String(m.text).startsWith('/'));
    if (!picked.length) continue;
    const lines = picked.map((m) => {
      const who = m.self ? '我' : String(m.senderName || m.senderId || '某人').slice(0, 14);
      return `${who}：${String(m.text).replace(/\s+/g, ' ').slice(0, 200)}`;
    });
    chats.push({
      chatKey: String(data.chatKey || name.replace(/\.json$/, '')),
      count: picked.length,
      text: lines.join('\n')
    });
  }

  let digest = '';
  for (const chat of chats) {
    const head = `\n### ${chat.chatKey}（最近 ${chat.count} 条）\n`;
    const room = maxChars - digest.length - head.length;
    if (room <= 120) break;
    digest += head + (chat.text.length > room ? `${chat.text.slice(0, room)}\n…（截断）` : chat.text);
  }

  return {
    ok: true,
    dir,
    chars: digest.length,
    chats: chats.map((c) => ({ chatKey: c.chatKey, count: c.count })),
    digest,
    hint: '把材料提炼成若干条 palace_save（kind 用 fact / preference / decision / episode），每条一句话、带当事人与时间锚点；不要照抄原文，也不要把一次性闲聊写进长期记忆。'
  };
}

// 信念列表（observations 表）：palace_reflect 写进来的东西，面板「画像」页要展示
function opBeliefs(handle, args) {
  const scopes = args.scope === 'all' || !args.scope ? scopeList() : [String(args.scope)];
  const limit = clamp(args.limit ?? 20, 1, 100);
  const items = [];
  for (const scope of scopes) {
    const entry = db(scope);
    if (!entry) continue;
    let rows = [];
    try {
      rows = entry.db.prepare("SELECT id, scope, belief, proof_count, created_at, updated_at FROM observations WHERE status = 'active' ORDER BY proof_count DESC, updated_at DESC LIMIT ?").all(limit);
    } catch { rows = []; }
    for (const row of rows) {
      items.push({ id: row.id, scope: row.scope, belief: row.belief, proof: row.proof_count, updatedAt: row.updated_at });
    }
  }
  items.sort((a, b) => (b.proof - a.proof) || (b.updatedAt - a.updatedAt));
  return { count: items.length, items: items.slice(0, limit) };
}

const OPS = {
  save: opSave,
  search: opSearch,
  embed_status: opEmbedStatus,
  embed_configure: opEmbedConfigure,
  embed_setup: opEmbedSetup,
  reindex: opReindex,
  assess: opAssess,
  examine: opExamine,
  update: opUpdate,
  forget: opForget,
  report: opReport,
  review_queue: opReviewQueue,
  review: opReview,
  facts: opFacts,
  neighbors: opNeighbors,
  timeline: opTimeline,
  tour: opTour,
  stats: opStats,
  audit_forgotten: opAuditForgotten,
  profile: opProfile,
  episode_timeline: opEpisodeTimeline,
  export: opExport,
  context: opContext,
  distill: opDistill,
  reflect: opReflect,
  ingest_scan: opIngestScan,
  beliefs: opBeliefs
};

/* ────────────────────────────── HTTP ────────────────────────────── */

// CORS：插件界面（panel/index.html，跑在控制台同源 iframe 里）需要直接调这个服务，
// 所以本机回环服务上放开来源限制；服务只 bind 127.0.0.1，不对外网开放。
const CORS = {
  'access-control-allow-origin': '*',
  'access-control-allow-headers': 'content-type,x-palace-token',
  'access-control-allow-methods': 'GET,POST,OPTIONS',
  'access-control-max-age': '600'
};

function send(res, code, obj) {
  const body = JSON.stringify(obj);
  res.writeHead(code, {
    'content-type': 'application/json; charset=utf-8',
    'content-length': Buffer.byteLength(body),
    'cache-control': 'no-store',
    ...CORS
  });
  res.end(body);
}

const server = http.createServer((req, res) => {
  if (req.method === 'OPTIONS') {
    res.writeHead(204, CORS);
    return res.end();
  }
  if (TOKEN && req.headers['x-palace-token'] !== TOKEN) return send(res, 401, { ok: false, error: { code: 'unauthorized', message: '缺少或错误的 x-palace-token' } });
  if (req.method === 'GET' && req.url.startsWith('/health')) {
    const s = embedder.status();
    return send(res, 200, {
      ok: true,
      value: {
        pid: process.pid,
        dbDir: DB_DIR,
        scopes: scopeList(),
        node: process.version,
        embed: { backend: s.backend, model: s.model, dims: s.dims, ready: s.ready, error: s.error, progress: s.progress },
        coverage: embeddingCoverage()
      }
    });
  }
  if (req.method !== 'POST' || !req.url.startsWith('/rpc')) return send(res, 404, { ok: false, error: { code: 'not-found', message: '只支持 GET /health 与 POST /rpc' } });
  let raw = '';
  req.setEncoding('utf8');
  req.on('data', (chunk) => { raw += chunk; if (raw.length > 4e6) req.destroy(); });
  req.on('end', () => {
    let body;
    try { body = raw ? JSON.parse(raw) : {}; } catch (error) { return send(res, 400, { ok: false, error: { code: 'bad-json', message: error.message } }); }
    const op = String(body.op || '');
    const fn = OPS[op];
    if (!fn) return send(res, 404, { ok: false, error: { code: 'unknown-op', message: `未知操作：${op}` } });
    const scope = body.args?.scope && body.args.scope !== 'all' ? String(body.args.scope) : 'user';
    (async () => {
      try {
        const entry = db(scope);
        const value = await fn(entry.db, body.args || {});
        return send(res, 200, { ok: true, value });
      } catch (error) {
        console.error(`[palace] ${op} 失败:`, error);
        return send(res, 500, { ok: false, error: { code: 'op-failed', message: String(error?.message || error) } });
      }
    })();
  });
});

server.listen(PORT, HOST, () => {
  console.log(`[palace] 记忆宫殿服务已启动 http://${HOST}:${PORT} · db=${DB_DIR} · node=${process.version} · scopes=${scopeList().join(',')}`);
});

for (const sig of ['SIGINT', 'SIGTERM']) {
  process.on(sig, () => {
    server.close(() => {
      for (const entry of open.values()) { try { entry.db.close(); } catch { } }
      process.exit(0);
    });
  });
}
