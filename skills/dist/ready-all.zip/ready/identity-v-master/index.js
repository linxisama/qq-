// 第五人格大师（identity-v-master v1.0.0）—— LLM 型技能（skills/）
//
// 组成：
//   ① 内置资料库 kb/*.md：机制术语 / 打法博弈 / 主播选手 / 梗与串词 —— 离线、秒回
//   ② 三个工具：lookup（查资料）、streamer（查主播/选手）、meme（按场景找梗）
//   ③ 提示词片段：告诉模型什么时候切进"第五人格老玩家"模式、怎么说话
//   ④ 触发闸门：settings.triggerMode 决定本轮工具与提示词是否生效
//
// 对齐 loader / tool-registry 的硬约束：
//   · 工具 id 只用 [a-zA-Z0-9_-]（注册后自动变成 identity-v-master__xxx）
//   · 配置在执行时用 cfg() 读，不在 setup 时快照
//   · 所有失败路径 return { content, isError: true }，不把异常抛给上层
//   · 子模块会被 ESM 缓存住，所以读盘逻辑全部放在本入口文件里

import fs from 'node:fs'
import path from 'node:path'
import { fileURLToPath } from 'node:url'

const SKILL_ID = 'identity-v-master'
const KB_DIR = path.join(path.dirname(fileURLToPath(import.meta.url)), 'kb')

const KB_FILES = {
  mechanics: 'mechanics.md',
  strategies: 'strategies.md',
  streamers: 'streamers.md',
  memes: 'memes.md'
}
const KB_LABELS = {
  mechanics: '机制与术语',
  strategies: '打法与博弈',
  streamers: '主播与赛事',
  memes: '梗与串词'
}

let cfg = () => ({})
let log = () => {}

// ── 配置读取 ────────────────────────────────────────────────────────────────

function conf() {
  try {
    const c = cfg()
    return c && typeof c === 'object' ? c : {}
  } catch {
    return {}
  }
}

function clampInt(value, min, max, fallback) {
  const n = Math.round(Number(value))
  if (!Number.isFinite(n)) return fallback
  return Math.min(max, Math.max(min, n))
}

// ── 资料库：读盘 + 解析 + 检索 ──────────────────────────────────────────────

let cache = { stamp: '', sections: [] }

function stampOf() {
  const parts = []
  for (const key of Object.keys(KB_FILES)) {
    try {
      const st = fs.statSync(path.join(KB_DIR, KB_FILES[key]))
      parts.push(`${key}:${st.size}:${st.mtimeMs}`)
    } catch {
      parts.push(`${key}:0`)
    }
  }
  return parts.join('|')
}

function makeSection(file, title, body) {
  return {
    file,
    label: KB_LABELS[file] || file,
    title,
    body,
    hayTitle: title.toLowerCase(),
    hay: `${title}\n${body}`.toLowerCase()
  }
}

/** 把一个 md 文件按 `## 标题` 切成段落。没有 `##` 时整篇算一段。 */
function parseSections(file, text, fallbackTitle) {
  const raw = String(text ?? '')
  const out = []
  const parts = raw.split(/\r?\n(?=##\s+)/)
  for (const part of parts) {
    const m = part.match(/^##\s+(.+?)\s*$/m)
    if (!m) continue
    const title = m[1].trim()
    const body = part.slice(part.indexOf(m[0]) + m[0].length).trim()
    if (!title || !body) continue
    out.push(makeSection(file, title, body))
  }
  if (!out.length) {
    const body = raw.replace(/^#\s+.+$/m, '').trim()
    if (body) out.push(makeSection(file, fallbackTitle, body))
  }
  return out
}

/** 用户自己在设置里补的内容，按同样格式并进资料库。 */
function extraSections(c) {
  const out = []
  const add = (file, text, fallbackTitle) => {
    const raw = String(text ?? '').trim()
    if (!raw) return
    // 「## 标题」分段优先，否则按行拆成一条条小段（每行一个知识点）
    if (/^##\s+/m.test(raw)) {
      out.push(...parseSections(file, raw, fallbackTitle))
      return
    }
    for (const line of raw.split(/\r?\n/)) {
      const s = line.trim().replace(/^[-*]\s*/, '')
      if (!s) continue
      const idx = s.search(/[：:]/)
      const title = idx > 0 ? s.slice(0, idx).trim() : s.slice(0, 18)
      const body = idx > 0 ? s.slice(idx + 1).trim() : s
      if (title && body) out.push(makeSection(file, title, body))
    }
  }
  add('streamers', c.extraStreamers, '补充的主播资料')
  add('memes', c.extraMemes, '补充的梗')
  return out
}

function loadKb() {
  const stamp = stampOf()
  if (stamp === cache.stamp) return cache.sections
  const sections = []
  for (const key of Object.keys(KB_FILES)) {
    try {
      const text = fs.readFileSync(path.join(KB_DIR, KB_FILES[key]), 'utf8')
      sections.push(...parseSections(key, text, KB_LABELS[key] || key))
    } catch {
      // 单个文件缺失不影响其它文件
    }
  }
  cache = { stamp, sections }
  return sections
}

/**
 * 中文按二元组切，英文按词切 —— 够用且不需要分词库。
 *
 * 停用词是必须的：长问句里「什么/怎么/东西/时候」这类虚词几乎必然出现在某段正文里，
 * 不滤掉就会凑够分数、把不相关的段落顶上来（用户看到的就是答非所问）。
 */
const STOP_WORDS = new Set([
  '什么', '怎么', '怎样', '为什么', '如何', '多少', '哪里', '哪个', '哪些',
  '时候', '可以', '这个', '那个', '一下', '还是', '就是', '没有', '一个',
  '我们', '你们', '他们', '知道', '东西', '完全', '存在', '其实', '因为',
  '所以', '但是', '如果', '然后', '现在', '已经', '不是', '这么', '那么',
  '真的', '感觉', '觉得', '应该', '可能', '有没有', '是不是', '能不能',
  '的时', '在的', '的东', '是不', '不是', '了', '吗', '呢', '吧', '啊'
])

function tokensOf(query) {
  const s = String(query ?? '').toLowerCase().trim()
  if (!s) return []
  const out = new Set()
  for (const w of s.split(/[\s,，、。;；:：!！?？/\\|]+/)) {
    if (w.length >= 2 && !STOP_WORDS.has(w)) out.add(w)
  }
  const cjk = s.replace(/[^\u4e00-\u9fa5]/g, ' ')
  for (const chunk of cjk.split(/\s+/)) {
    if (!chunk) continue
    if (chunk.length > 1 && chunk.length <= 3 && !STOP_WORDS.has(chunk)) out.add(chunk)
    if (chunk.length > 3) {
      for (let i = 0; i < chunk.length - 1; i += 1) {
        const bg = chunk.slice(i, i + 2)
        if (!STOP_WORDS.has(bg)) out.add(bg)
      }
    }
  }
  return [...out].filter((t) => t && t.length >= 2)
}

function scoreOf(sec, queryLower, toks) {
  let score = 0
  if (queryLower && sec.hayTitle.includes(queryLower)) score += 60
  if (queryLower && sec.hay.includes(queryLower)) score += 18
  for (const t of toks) {
    if (sec.hayTitle.includes(t)) score += 10
    else if (sec.hay.includes(t)) score += 3
  }
  return score
}

/**
 * 检索资料库。
 * @param {string} query
 * @param {{ files?: string[], limit?: number }} options
 */
function searchKb(query, options = {}) {
  const c = conf()
  const all = loadKb().concat(extraSections(c))
  const files = Array.isArray(options.files) && options.files.length ? options.files : null
  const pool = files ? all.filter((s) => files.includes(s.file)) : all
  const q = String(query ?? '').trim()
  if (!q) return { hits: [], pool }
  const toks = tokensOf(q)
  const ql = q.toLowerCase()
  // 门槛不能是 0：长句里总有一两个二元组碰巧出现在某段正文里，命中这种
  // "零散撞词" 的段落跑偏得比不命中还糟（会答非所问）。整串命中正文有 18 分，
  // 一个关键词命中标题有 10 分 —— 6 分刚好挡住「只撞到一处正文」的噪声。
  const minScore = Number.isFinite(Number(options.minScore)) ? Number(options.minScore) : 6
  const scored = []
  for (const sec of pool) {
    const score = scoreOf(sec, ql, toks)
    if (score >= minScore) scored.push({ sec, score })
  }
  scored.sort((a, b) => b.score - a.score)
  const limit = clampInt(options.limit, 1, 8, 3)
  return { hits: scored.slice(0, limit).map((x) => x.sec), pool }
}

function renderHits(hits, c, opts = {}) {
  const cap = clampInt(opts.maxChars ?? c.maxChars, 600, 4000, 1800)
  const showSource = c.includeSource === true
  const blocks = []
  let used = 0
  for (const h of hits) {
    const head = `【${h.title}】`
    let block = `${head}\n${h.body}`
    if (used + block.length > cap) {
      const room = cap - used - head.length - 24
      if (room < 120) break
      block = `${head}\n${h.body.slice(0, room)}…`
    }
    used += block.length
    blocks.push(showSource ? `${block}\n（资料段：${h.label}）` : block)
    if (used >= cap - 80) break
  }
  return { text: blocks.join('\n\n'), truncated: used >= cap - 80 }
}

/** 没查到时给模型一份"有什么可查"的清单，避免它直接开始编。 */
function titleList(pool, files) {
  const wanted = files ? pool.filter((s) => files.includes(s.file)) : pool
  const seen = new Set()
  const titles = []
  for (const s of wanted) {
    if (seen.has(s.title)) continue
    seen.add(s.title)
    titles.push(s.title)
    if (titles.length >= 12) break
  }
  return titles
}

const NO_KB_HINT = '资料库文件读不到（kb/*.md 缺失）。只能按你的常识作答，并说明"内置资料可能不全"，不要编造具体数据。'

// ── 触发闸门 ────────────────────────────────────────────────────────────────
//
// 两道确定性闸门，都由核心代码触发，模型绕不过去：
//   ① providers['tool.guard']：本轮没被叫到/没聊到时就否决三个工具
//   ② promptSections(ctx)：本轮不生效就不注入提示词，顺带省 token
// 状态来自 hooks['before-context'] 在本轮开始时记下的性质。

const MODES = ['被@或戳一戳时', '聊到第五人格时', '总是']
const DEFAULT_MODE = MODES[1]
const FLAG_TTL_MS = 10 * 60 * 1000
const MAX_FLAGS = 300

const flags = new Map() // sessionId -> { addressed, topic, at }
const lastAddressedAt = new Map() // chatKey -> ts
const selfIds = { id: '', nickname: '', botName: '' }

const TOPIC_WORDS = [
  '第五人格', '第五', '庄园', '求生者', '监管者', '密码机', '狂欢之椅', '狂欢椅',
  '修机', '压机', '溜鬼', '板区', '地窖', '一刀斩', '联合狩猎', '殿堂级',
  '卡半救', '大心脏', '双弹', '搏命', 'ob位', '守椅', '秒倒', '压好密码机',
  '恐惧震慑', '守尸', '贴门', 'idv'
]

function normalizeMode(value) {
  const v = String(value ?? '').trim()
  if (!v) return DEFAULT_MODE
  if (MODES.includes(v)) return v
  if (/总是|全部|always|any/i.test(v)) return MODES[2]
  if (/聊到|话题|topic|关键词/i.test(v)) return MODES[1]
  return MODES[0]
}

function learnSelf(ctx) {
  try {
    if (ctx?.selfId) selfIds.id = String(ctx.selfId)
    if (ctx?.selfNickname) selfIds.nickname = String(ctx.selfNickname)
    if (ctx?.botName) selfIds.botName = String(ctx.botName)
  } catch { /* 记不到就算了 */ }
}

function entryAddressesBot(entry) {
  if (!entry || typeof entry !== 'object') return false
  if (entry.atMe === true) return true
  if (entry.atMe !== false) {
    const text = String(entry.text ?? '')
    if (selfIds.id && text.includes(`[CQ:at,qq=${selfIds.id}]`)) return true
    for (const name of [selfIds.nickname, selfIds.botName]) {
      const n = String(name ?? '').trim()
      if (n && text.includes(`@${n}`)) return true
    }
  }
  if (entry.isPoke && /拍了拍\s*我/.test(String(entry.text ?? ''))) return true
  const reply = entry.reply
  if (reply && typeof reply === 'object') {
    if (reply.self === true) return true
    const rid = String(reply.senderId ?? '')
    if (rid === 'self' || (selfIds.id && rid === selfIds.id)) return true
  }
  return false
}

function textHasTopic(text) {
  const t = String(text ?? '')
  if (!t) return false
  const low = t.toLowerCase()
  for (const w of TOPIC_WORDS) {
    if (w === w.toLowerCase()) {
      if (low.includes(w)) return true
    } else if (t.includes(w)) return true
  }
  return false
}

function rememberTurn(ctx, info = {}) {
  const sid = String(ctx?.sessionId ?? '').trim()
  const now = Date.now()
  if (sid) {
    flags.set(sid, { addressed: Boolean(info.addressed), topic: Boolean(info.topic), at: now })
    if (flags.size > MAX_FLAGS) {
      for (const [key, value] of flags) {
        if (now - value.at > FLAG_TTL_MS) flags.delete(key)
      }
      while (flags.size > MAX_FLAGS) {
        const oldest = flags.keys().next().value
        if (oldest === undefined) break
        flags.delete(oldest)
      }
    }
  }
  if (info.addressed) {
    const ck = String(ctx?.chatKey ?? '').trim()
    if (ck) lastAddressedAt.set(ck, now)
  }
}

function flagOf(ctx) {
  const sid = String(ctx?.sessionId ?? '').trim()
  if (!sid) return null
  const hit = flags.get(sid)
  if (!hit) return null
  if (Date.now() - hit.at > FLAG_TTL_MS) {
    flags.delete(sid)
    return null
  }
  return hit
}

/**
 * 本轮允不允许启用（工具 + 提示词共用）。
 * @returns {{allow:boolean, why:string, unknown?:boolean}}
 */
function decide(ctx) {
  const c = conf()
  const mode = normalizeMode(c.triggerMode)
  const kind = String(ctx?.kind ?? '')
  const chatKey = String(ctx?.chatKey ?? '')

  if (mode === MODES[2]) return { allow: true, why: '设置为总是启用' }
  if (kind === 'private') return { allow: true, why: '私聊直接对话' }

  const graceRaw = Number(c.graceMinutes)
  const graceMs = (Number.isFinite(graceRaw) ? Math.max(0, graceRaw) : 5) * 60000
  const lastAt = chatKey ? (lastAddressedAt.get(chatKey) || 0) : 0
  const inGrace = graceMs > 0 && lastAt > 0 && Date.now() - lastAt < graceMs

  const flag = flagOf(ctx)
  if (flag) {
    if (flag.addressed) return { allow: true, why: '本轮被叫到' }
    if (mode === MODES[1] && flag.topic) return { allow: true, why: '本轮聊到第五人格' }
    if (inGrace) return { allow: true, why: `上次被叫到后 ${Math.round((Date.now() - lastAt) / 1000)} 秒内` }
    return {
      allow: false,
      why: mode === MODES[1]
        ? '本轮既没被叫到、也没聊到第五人格相关内容'
        : '本轮没有被 @ 或戳一戳（可在设置里改成"聊到第五人格时"或"总是"）'
    }
  }

  // 拿不到本轮信息（控制台预览、工具页列举）→ 放行，否则界面会显示成"工具不可用"，像技能坏了
  if (inGrace) return { allow: true, why: '上次被叫到后不久', unknown: true }
  return { allow: true, why: '没有本轮触发信息（放行）', unknown: true }
}

// ── 提示词 ──────────────────────────────────────────────────────────────────

function guideText(c) {
  const intensity = c.memeIntensity === '收敛' ? '收敛' : c.memeIntensity === '放飞' ? '放飞' : '正常'
  const memeLine = intensity === '收敛'
    ? '5) 玩梗收敛点：只在别人明显抛梗时接一句，其余正经答。'
    : intensity === '放飞'
      ? '5) 敢玩梗敢串：气氛到了可以接梗、可以阴阳两句、可以当串子，但别连着串、别刷屏、别对认真提问的人串。'
      : '5) 一句梗 + 一句干货：气氛到了接个梗，但别让整条回复只剩梗。'
  return [
    '本轮群里聊到了《第五人格》。按玩了很多年的老玩家的水准接话：',
    '1) 先查再答：术语、机制、板区博弈、压机流程、救人时机、主播/选手归属、比赛梗的出处，先用 lookup / streamer / meme 查资料库再组织答案。资料库里没有的就说记不清，绝不硬编数值、选手归属和比赛细节。',
    '2) 主播和赛事是敏感区：只聊公开的东西（在哪个队、打过什么比赛、什么风格）。不编黑料、恩怨、私生活，不替人吹或踩，别用牌子判断谁强谁菜。',
    '3) 用圈内口径说话：修机、压机、溜鬼、板区、卡半救、一刀斩、贴门、OB、打团。不要把别的游戏的叫法硬套上来。',
    '4) 像群友不像客服：先给结论再给理由，一般 1~3 句；真被问攻略可以展开，但别铺 Markdown 表格、也别每次都念资料出处。',
    memeLine,
    '6) 读空气：对方明显在认真问、或是不熟的人，就把梗收起来；吵架、站队、带节奏一律不接。',
    '7) 像「兑勾」这种拿不准来历的圈内词，按语境用就行，别去解释词源。没聊到第五就别主动往这上面扯。'
  ].join('\n')
}

// ── 入口 ────────────────────────────────────────────────────────────────────

export function setup(api) {
  cfg = () => api.config()
  log = (...args) => { try { api.log(...args) } catch { /* ignore */ } }

  // ── 工具 1：查资料库 ──────────────────────────────────────────────────────
  api.registerTool({
    id: 'lookup',
    name: '第五人格资料检索',
    description:
      '检索内置的《第五人格》资料库，返回最相关的段落。资料库四块：机制与术语（mechanics：修机/压机/'
      + '溜鬼/救人/开门战/天赋/牌子）、打法与博弈（strategies：板区怎么打、最后一台机怎么压、救人时机、'
      + '联合狩猎）、主播与赛事（streamers：IVL 战队选手、解说、比赛梗出处）、梗与串词（memes）。'
      + '凡是问到第五人格的玩法、术语、机制、该怎么做，先查这里再回答，不要凭印象编。'
      + '返回第一行是 status：ok=查到了 / empty=没查到（那就别硬编）/ error=出错。',
    category: 'knowledge',
    icon: '📖',
    parameters: {
      type: 'object',
      properties: {
        query: {
          type: 'string',
          description: '要查的内容或关键词，用圈内说法效果最好，例如「压机」「卡半救」「板区博弈」「一刀斩」「联合打团」。'
        },
        topic: {
          type: 'string',
          enum: ['auto', 'mechanics', 'strategies', 'streamers', 'memes'],
          description: '限定只查某一块资料，不填或 auto 表示全都查。问术语机制用 mechanics，问怎么打用 strategies，问主播用 streamers，找梗用 memes。'
        },
        maxChars: {
          type: 'integer',
          description: '返回字数上限，600~4000，不填用设置里的默认值。'
        }
      },
      required: ['query']
    },
    async execute(_ctx, args) {
      const c = conf()
      const query = String(args?.query ?? '').trim()
      if (!query) {
        return { content: 'status: error\n缺少 query 参数：要查什么？例如「压机」「卡半救」「板区博弈」。', isError: true }
      }
      try {
        const topic = String(args?.topic ?? 'auto')
        const files = topic && topic !== 'auto' && KB_FILES[topic] ? [topic] : null
        const { hits, pool } = searchKb(query, { files, limit: 3 })
        if (!hits.length) {
          if (!pool.length) return { content: `status: error\n${NO_KB_HINT}`, isError: true }
          const titles = titleList(pool, files)
          return {
            content: `status: empty\n资料库里没有直接命中「${query}」。\n`
              + `别再猜了，可以换个说法再查一次，或者从这些已有条目里挑：${titles.join('、')}。\n`
              + '如果确实没有，就直说记不清，不要编造。'
          }
        }
        const { text, truncated } = renderHits(hits, c, { maxChars: args?.maxChars })
        return {
          content: `status: ok\n${text}${truncated ? '\n（资料已截断，需要更细可以换更具体的关键词再查一次。）' : ''}`
        }
      } catch (error) {
        return { content: `status: error\n查资料失败：${error?.message ?? error}`, isError: true }
      }
    }
  })

  // ── 工具 2：查主播 / 选手 ────────────────────────────────────────────────
  api.registerTool({
    id: 'streamer',
    name: '查主播与职业选手',
    description:
      '查某个第五人格主播、职业选手、解说属于哪个队 / 什么来头 / 有什么公开的比赛梗。'
      + '当群友提到具体的人名并问「他是谁」「哪个队的」「职业的还是主播」「他和谁一队」时用它。'
      + '查不到就老实说查不到——绝对不要编造某人的牌子、荣誉、黑料、恩怨或私生活。',
    category: 'knowledge',
    icon: '🎙️',
    parameters: {
      type: 'object',
      properties: {
        name: {
          type: 'string',
          description: '人名或 ID，例如「东玄」「487」「大猫」「零之启」。'
        }
      },
      required: ['name']
    },
    async execute(_ctx, args) {
      const c = conf()
      const name = String(args?.name ?? '').trim()
      if (!name) return { content: 'status: error\n缺少 name 参数：要查谁？', isError: true }
      try {
        const { hits, pool } = searchKb(name, { files: ['streamers', 'memes'], limit: 3 })
        if (!hits.length) {
          if (!pool.length) return { content: `status: error\n${NO_KB_HINT}`, isError: true }
          return {
            content: `status: empty\n资料库里没有「${name}」的条目。\n`
              + '不要编造他的战队、牌子、荣誉或关系。可以说"印象不深/不确定"，'
              + '或者只聊能确定的公开比赛表现；也可以让群友自己去查。'
          }
        }
        const { text } = renderHits(hits, c, { maxChars: args?.maxChars })
        return {
          content: `status: ok\n${text}\n\n（名单会过时：转会、退役、改名都很常见。拿不准就用不确定的语气，别把旧的当现在的。）`
        }
      } catch (error) {
        return { content: `status: error\n查主播资料失败：${error?.message ?? error}`, isError: true }
      }
    }
  })

  // ── 工具 3：按场景找梗 ───────────────────────────────────────────────────
  api.registerTool({
    id: 'meme',
    name: '找第五人格的梗',
    description:
      '按场景取几条《第五人格》圈里现成的梗、外号、口头禅或串词，用来接话。'
      + '场景例如：联合打团、板区遛鬼、救人守椅、开门战压机、秒倒下饭、角色外号。'
      + '返回的是语气参考，不是必须照抄的台词；挑一两句用，别整段刷，也别对认真提问的人串。',
    category: 'knowledge',
    icon: '😏',
    parameters: {
      type: 'object',
      properties: {
        scene: {
          type: 'string',
          description: '使用场景或关键词，例如「联合打团」「板区」「救人」「一刀斩」「秒倒」「红蝶外号」。'
        },
        count: {
          type: 'integer',
          description: '要几条，1~5，默认 2。'
        }
      },
      required: ['scene']
    },
    async execute(_ctx, args) {
      const c = conf()
      const scene = String(args?.scene ?? '').trim()
      if (!scene) return { content: 'status: error\n缺少 scene 参数：什么场景？例如「联合打团」「救人」。', isError: true }
      try {
        const limit = clampInt(args?.count, 1, 5, 2)
        let { hits, pool } = searchKb(scene, { files: ['memes'], limit })
        if (!hits.length) {
          // 梗库里没有就直接说没有，别让模型自己现编一个 "梗" 出来
          return {
            content: `status: empty\n梗库里没有和「${scene}」对得上的段子。\n`
              + '可以用……算了，别硬造梗；正常接话就好，或者用一个通用说法。'
          }
        }
        const { text } = renderHits(hits, c, { maxChars: args?.maxChars })
        return {
          content: `status: ok\n${text}\n\n（挑一两句贴当下语境的用，别整段刷；对方在认真问就先把问题答了。）`
        }
      } catch (error) {
        return { content: `status: error\n找梗失败：${error?.message ?? error}`, isError: true }
      }
    }
  })
}

/** 自检必须同步；资料库缺失也能启动（只是答不了细节）。 */
export function available() {
  return true
}

// ── 钩子：记下本轮的性质 ────────────────────────────────────────────────────

export const hooks = {
  'before-context': (ctx) => {
    try {
      const entries = Array.isArray(ctx?.triggerEntries) ? ctx.triggerEntries : []
      learnSelf(ctx)
      const addressed = entries.some((e) => entryAddressesBot(e))
      const text = entries
        .map((e) => `${e?.text ?? ''} ${Array.isArray(e?.atNames) ? e.atNames.join(' ') : ''}`)
        .join('\n')
      const topic = textHasTopic(text)
      rememberTurn(ctx, { addressed, topic })
      if (addressed || topic) {
        log(`闸门：${ctx?.chatKey ?? '?'} 本轮 ${addressed ? '被叫到' : ''}${addressed && topic ? ' + ' : ''}${topic ? '聊到第五' : ''}`)
      }
    } catch {
      // 钩子失败绝不影响主流程（最坏情况是本轮按"没有触发信息"放行）
    }
  }
}

/** 动态提示词：只有闸门放行时才注入。 */
export function promptSections(ctx) {
  try {
    const verdict = decide(ctx || {})
    if (!verdict.allow) return []
    return [{
      id: 'identity-v-master-guide',
      title: '第五人格',
      priority: 45,
      content: guideText(conf())
    }]
  } catch {
    return []
  }
}

export const providers = {
  // 本轮不生效时直接否决本技能的工具（返回 {ok:false} 即否决）
  'tool.guard': ({ toolId, context }) => {
    if (!String(toolId ?? '').startsWith(`${SKILL_ID}__`)) return null // 不归我管
    try {
      const verdict = decide(context || {})
      if (verdict.allow) return null
      return { ok: false, reason: `第五人格大师：${verdict.why}` }
    } catch {
      return null
    }
  }
}

/** 卸载时清掉闸门状态（热重载不残留）。 */
export function dispose() {
  flags.clear()
  lastAddressedAt.clear()
}

// 排障用（不参与加载逻辑）
export const __test = { searchKb, decide, rememberTurn, textHasTopic, guideText, loadKb }
