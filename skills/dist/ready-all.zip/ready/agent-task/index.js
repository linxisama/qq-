// 远程任务 —— 把 QQ 当遥控器，调 Cherry Studio 的模型 + MCP 工具实际执行
//
// 为什么这么搭：
//   Cherry Studio 的 HTTP API 里**没有**开箱的 agent 端点，只有两类零件：
//     · /v1/messages        模型（Anthropic 协议，支持 tool_use）
//     · /v1/mcps/{id}/mcp   工具（11 个 MCP 服务器，可直接调用）
//   所以这里自己拼一个 agent 循环：
//     模型 → 返回 tool_use → 执行（MCP 或本地）→ tool_result 回灌 → 再问，直到不再调工具
//   实测这一圈是通的（模型返回 tool_use、MCP 执行出结果、回灌后给出最终答复）。
//
// 两个关键设计：
//   1. 沙箱碰不到宿主机磁盘，所以群友发的文件由技能读好后**以文本/base64 注入上下文**，
//      并额外提供一个 read_qq_file 工具让 agent 按需取用。
//   2. 成品怎么回到 QQ：额外提供 deliver_file 工具，agent 把文件名 + base64 交上来，
//      技能落盘后走 OneBot 上传。这样"产出文件"这件事有了明确通道。

import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const TEXT_EXT = new Set(['.txt', '.md', '.csv', '.json', '.jsonl', '.log', '.xml', '.yaml', '.yml',
  '.ini', '.cfg', '.py', '.js', '.mjs', '.ts', '.java', '.c', '.cpp', '.h', '.go', '.rs', '.rb',
  '.php', '.sh', '.bat', '.ps1', '.sql', '.html', '.htm', '.css']);

let cfg = () => ({});
let fetchImpl = null;

function dataDir() {
  const base = process.env.QQ_AGENT_DATA_DIR
    || path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..', '..', '..', '..', 'data');
  return path.join(base, 'agent-task');
}

// ── 排障日志 ────────────────────────────────────────────────────────
//
// 为什么不用 api.log：它最终是 console.log('[skill:xxx]', ...)，而打包后的
// Electron GUI 应用**没有控制台** —— 这些输出哪儿都不去。实测在日志文件里
// 搜 "[skill:" 是 0 条，技能里的 log 全是写给空气看的。
//
// 一个从 QQ 异步触发的技能，出问题时没有任何可观测性，只能靠猜。
// 所以自己落盘：出问题第一时间能回答"它到底有没有被调用、死在哪一步"。
const TRACE_MAX = 512 * 1024;

function trace(...parts) {
  try {
    const dir = dataDir();
    fs.mkdirSync(dir, { recursive: true });
    const f = path.join(dir, 'trace.log');
    try {
      if (fs.statSync(f).size > TRACE_MAX) fs.renameSync(f, f + '.1');
    } catch { /* 首次运行没有这个文件，正常 */ }
    const line = new Date().toISOString().slice(11, 19) + ' '
      + parts.map((p) => (typeof p === 'string' ? p : JSON.stringify(p))).join(' ') + '\n';
    fs.appendFileSync(f, line, 'utf8');
  } catch { /* 记日志失败绝不能影响主流程 */ }
}

function safeName(s) {
  return String(s || 'file').replace(/[^\w一-鿿.()-]/g, '_').slice(0, 80) || 'file';
}

function extOf(name) {
  const l = String(name).toLowerCase();
  if (l.endsWith('.tar.gz')) return '.tar.gz';
  return path.extname(l);
}

/**
 * 列表型设置必须兼容**两种形态**。
 *
 * 设置界面在用户编辑过之后，会把数组存成字符串。实测证据：
 *   file-task 的 allowedUsers 是真正的数组 —— 因为它是我直接写进 config.json 的，
 *   从没过过界面；agent-task 的同一个字段被用户在界面上改过一次后，
 *   就变成了字符串 "123456789"。
 *
 * 而 `Array.isArray(x) ? x : []` 遇到字符串会**静默**得到空列表：
 * 名单变空、白名单失效、hostRoots 归零 —— 功能全废，还一声不吭。
 * 所以两种都收：数组直接用，字符串按逗号/换行/顿号拆开。
 */
function toStringList(v) {
  if (Array.isArray(v)) return v.map((x) => String(x ?? '').trim()).filter(Boolean);
  return String(v ?? '').split(/[,，;；、\r\n]+/).map((s) => s.trim()).filter(Boolean);
}

/** 同上，但元素是对象（backends）。字符串形态下按行拆，每行当一段 JSON 解析。 */
function toObjectList(v) {
  const raw = Array.isArray(v) ? v : String(v ?? '').split(/\r?\n/).map((s) => s.trim()).filter(Boolean);
  const out = [];
  for (const it of raw) {
    if (it && typeof it === 'object') { out.push(it); continue; }
    const s = String(it ?? '').trim();
    if (!s) continue;
    try {
      const p = JSON.parse(s);
      if (p && typeof p === 'object') out.push(p);
    } catch { /* 不是合法 JSON 就跳过，报错时会在「已配置的」列表里体现出来 */ }
  }
  return out;
}

// ── 权限 ────────────────────────────────────────────────────────────
function resolveUserId(ctx, explicit) {
  const e = String(explicit ?? '').trim();
  if (/^\d{5,12}$/.test(e)) return e;
  try {
    const msgs = ctx.store?.recent?.(ctx.chatKey, { limit: 30, includeSelf: false }) || [];
    if (!msgs.length) return '';
    const sorted = [...msgs].sort((a, b) => (Number(a.ts) || 0) - (Number(b.ts) || 0));
    const atMe = [...sorted].reverse().find((m) => m.atMe === true && m.senderId);
    if (atMe) return String(atMe.senderId);
    return String([...sorted].reverse().find((m) => m.senderId)?.senderId ?? '');
  } catch { return ''; }
}

function checkAllowed(c, userId) {
  if (c.allowAll === true) return { ok: true };
  const list = toStringList(c.allowedUsers);
  if (!list.length) return { ok: false, reason: '还没配置允许使用的 QQ 号，且未开启「允许所有人」' };
  if (!userId) return { ok: false, reason: '没能确认你的 QQ 号' };
  if (!list.includes(userId)) return { ok: false, reason: `你的 QQ 号 ${userId} 不在允许名单里` };
  return { ok: true };
}

// ── 取群友发的文件 ──────────────────────────────────────────────────
const fileMsgRe = /^\[文件(.+?)\]$/;

/**
 * 顺着「引用」回溯被引用的文件。
 *
 * 群友常见用法是"引用那条文件消息 + 说一句要求"，而不是重发文件。
 * 但核心的 resolveReply 把引用渲染成 `[引用 某某：...]` 后**丢掉了原消息 id**，
 * 且 file 段只渲染成字面的 `[file]` —— 既没文件名也没溯源依据。
 * 引用段自身带 d.id，所以这里自己把链补回来，不用改核心代码。
 */
async function collectQuotedFiles(ctx, known) {
  const out = [];
  let msgs;
  try { msgs = ctx.store?.recent?.(ctx.chatKey, { limit: 15, includeSelf: false }) || []; }
  catch { return out; }
  if (!msgs.length) return out;
  for (const m of [...msgs].slice(-5).reverse()) {
    if (!m.mid) continue;
    try {
      const raw = await ctx.onebot.call('get_msg', { message_id: m.mid });
      const segs = raw?.message || raw?.data?.message || [];
      const quotedId = segs.find((s) => s.type === 'reply')?.data?.id;
      if (!quotedId) continue;
      if (known.some((f) => String(f.mid) === String(quotedId))) continue;
      if (out.some((f) => String(f.mid) === String(quotedId))) continue;
      const q = await ctx.onebot.call('get_msg', { message_id: quotedId });
      const fseg = (q?.message || q?.data?.message || []).find((s) => s.type === 'file');
      if (!fseg) continue;
      out.push({
        mid: quotedId,
        name: fseg.data?.name || fseg.data?.file || '引用里的文件',
        ts: (Number(q?.time) || 0) * 1000 || Date.now(),
        fromQuote: true
      });
    } catch { /* 单条失败跳过 */ }
  }
  return out;
}

/**
 * 收集最近群友发的文件。
 *
 * ⚠️ 这里踩过两次坑，都不是"边界条件"，是直接让功能全废：
 *
 *   1. 【顺序】原先是"取机器人上次发言之后的文件"。但本技能会先发一条预估时间的
 *      提示，那条提示本身就是一次 self 发言 —— 等再去收集时，边界已经越过文件了，
 *      结果恒为空。**必须先收集、后发提示。**
 *   2. 【判据太严】"上次发言之后"这个边界在真实用法下也不成立：用户常常是
 *      「先发文件 → 再单独发一句要求」，文件落在上一波里，照样收不到。
 *
 *   所以改成**时间窗口**：取最近 10 分钟内、非机器人自己发的文件消息。
 *   多条时按时间排序取最近 10 个，正好覆盖"一口气发几个文件再提要求"的节奏。
 */
const FILE_WINDOW_MS = 10 * 60 * 1000;

function collectRecentFiles(ctx) {
  let msgs;
  try { msgs = ctx.store?.recent?.(ctx.chatKey, { limit: 60, includeSelf: true }) || []; }
  catch { return []; }
  const cutoff = Date.now() - FILE_WINDOW_MS;
  const out = [];
  for (const m of msgs) {
    if (m.self) continue;
    const t = Number(m.ts) || 0;
    if (t < cutoff) continue;
    const mm = fileMsgRe.exec(String(m.text || '').trim());
    if (mm && m.mid) out.push({ mid: m.mid, name: mm[1] || '未知文件', ts: t });
  }
  return out.sort((a, b) => a.ts - b.ts).slice(-10);
}

async function downloadQQFile(ctx, info, timeoutMs) {
  const msg = await ctx.onebot.call('get_msg', { message_id: info.mid });
  const seg = (msg?.message || msg?.data?.message || []).find((s) => s.type === 'file');
  if (!seg) throw new Error(`「${info.name}」没有找到文件段（可能已被 QQ 清理）`);
  const d = seg.data || {};
  const name = String(d.name || d.file || info.name || 'file');
  let url = String(d.url || '').trim();
  if (!url) {
    const isGroup = String(ctx.chatKey).startsWith('group:');
    const action = isGroup ? 'get_group_file_url' : 'get_private_file_url';
    const params = isGroup
      ? { group_id: Number(ctx.chatId), file_id: d.file_id }
      : { user_id: Number(ctx.chatId), file_id: d.file_id };
    const r = await ctx.onebot.call(action, params);
    url = String(r?.url || r?.data?.url || '').trim();
  }
  if (!url) throw new Error(`拿不到「${name}」的下载地址`);
  const resp = await fetchImpl(url, { signal: AbortSignal.timeout(Math.min(60000, timeoutMs)) });
  if (!resp.ok) throw new Error(`下载「${name}」失败 HTTP ${resp.status}`);
  const buf = Buffer.from(await resp.arrayBuffer());
  if (!buf.length) throw new Error(`「${name}」是空文件`);
  return { name, buffer: buf, size: buf.length };
}

async function uploadFile(ctx, localPath, displayName) {
  const isGroup = String(ctx.chatKey).startsWith('group:');
  const action = isGroup ? 'upload_group_file' : 'upload_private_file';
  const params = isGroup
    ? { group_id: Number(ctx.chatId), file: localPath, name: displayName, folder: '/' }
    : { user_id: Number(ctx.chatId), file: localPath, name: displayName };
  return ctx.onebot.call(action, params);
}

// ── Cherry Studio：MCP 工具清单 ─────────────────────────────────────
const AUTOPICK = ['python', 'filesystem', 'fetch', 'sequentialthinking'];

async function listMcpTools(base, key, wanted, log) {
  const H = { 'x-api-key': key, accept: 'application/json, text/event-stream' };
  const res = await fetchImpl(base + '/v1/mcps/', { headers: H, signal: AbortSignal.timeout(15000) });
  const raw = await res.json();
  const servers = raw.data || raw.servers || (Array.isArray(raw) ? raw : []);

  const pick = (s) => {
    if (Array.isArray(wanted) && wanted.length) {
      return wanted.some((w) => String(s.name || '').includes(w) || s.id === w);
    }
    return AUTOPICK.some((w) => String(s.name || '').includes(w));
  };

  const tools = [];
  const byName = new Map();
  for (const s of servers) {
    const sid = s.id || s.server_id;
    if (!sid || !pick(s)) continue;
    let j;
    try {
      const r = await fetchImpl(`${base}/v1/mcps/${sid}`, { headers: H, signal: AbortSignal.timeout(10000) });
      j = await r.json();
    } catch { continue; }
    for (const t of (j.tools || [])) {
      // 跨服务器重名时加服务器前缀，避免模型调错
      let name = t.name;
      if (byName.has(name)) {
        const pre = String(s.name || '').replace(/^@cherry\//, '').replace(/[^a-zA-Z0-9]/g, '_');
        name = `${pre}_${t.name}`;
      }
      byName.set(name, { serverId: sid, serverName: s.name, rawName: t.name });
      tools.push({
        name,
        description: String(t.description || '').slice(0, 900),
        input_schema: t.inputSchema || t.input_schema || { type: 'object', properties: {} }
      });
    }
  }
  log?.(`MCP 工具 ${tools.length} 个，来自 ${new Set([...byName.values()].map((v) => v.serverName)).size} 个服务器`);
  return { tools, byName };
}

async function callMcpTool(base, key, entry, args, timeoutMs) {
  const H = { 'x-api-key': key, 'content-type': 'application/json', accept: 'application/json, text/event-stream' };
  const r = await fetchImpl(`${base}/v1/mcps/${entry.serverId}/mcp`, {
    method: 'POST', headers: H,
    body: JSON.stringify({ jsonrpc: '2.0', id: 1, method: 'tools/call', params: { name: entry.rawName, arguments: args || {} } }),
    signal: AbortSignal.timeout(timeoutMs)
  });
  const raw = await r.text();
  const m = /data:\s*(\{[\s\S]*\})/.exec(raw);
  let j;
  try { j = JSON.parse(m ? m[1] : raw); } catch { throw new Error('MCP 返回无法解析：' + raw.slice(0, 160)); }
  if (j.error) throw new Error(String(j.error.message || '').slice(0, 250));
  const c = j?.result?.content;
  let text = Array.isArray(c) ? c.map((x) => x.text || '').join('\n') : String(j?.result ?? '');
  if (j?.result?.isError) throw new Error('工具执行失败：' + text.slice(0, 200));
  // 剥掉 micropip 之类的进度噪声（实测会顶在结果最前面）
  return text.split('\n').filter((l) => {
    const s = l.trim();
    return !(/^Loading([\s,].*)?$/.test(s) || /^Loaded([\s,].*)?$/.test(s)
      || /micropip already loaded/i.test(s) || /^No new packages to load$/i.test(s));
  }).join('\n').replace(/^\n+/, '');
}

// ── 模型调用 ────────────────────────────────────────────────────────
async function callModel(base, key, model, tools, messages, timeoutMs) {
  const r = await fetchImpl(`${base}/v1/messages`, {
    method: 'POST',
    headers: { 'x-api-key': key, 'anthropic-version': '2023-06-01', 'content-type': 'application/json' },
    body: JSON.stringify({ model, max_tokens: 8000, tools, messages }),
    signal: AbortSignal.timeout(timeoutMs)
  });
  const raw = await r.text();
  if (!r.ok) throw new Error(`模型调用失败 HTTP ${r.status}：${raw.slice(0, 200)}`);
  const j = JSON.parse(raw);
  return { blocks: j.content || [], stop: j.stop_reason, usage: j.usage };
}

// ── AI 后端注册表 ───────────────────────────────────────────────────
//
// 除了内置的 Cherry，用户还能自己接别的 AI 工具。三种类型：
//   cherry  内置：Cherry 的模型 + MCP 工具循环（能力最全，默认）
//   cli     跑任意命令行 AI：codex / claude / aider / ollama / 自写脚本…
//   openai  任意 OpenAI 兼容端点（中转站、本地网关、Ollama 的 /v1…）
//
// cli 的做法：建临时目录 → 把群友发的文件放进去 → CLI 在里面干活 →
// 扫出这次新产生的文件 → 发回 QQ。这样 CLI 写的文件天然能交付。
function resolveBackend(c, wantedId) {
  const list = toObjectList(c.backends);
  const id = String(wantedId || c.defaultBackend || 'cherry').trim();
  if (id && id !== 'cherry') {
    const hit = list.find((b) => String(b?.id || '').trim() === id);
    if (hit) return normalizeBackend(hit);
    return { id, type: '', error: `没有名为「${id}」的后端。已配置的：cherry${list.map((b) => (b?.id ? '、' + b.id : '')).join('')}` };
  }
  return {
    id: 'cherry', type: 'cherry',
    baseUrl: String(c.cherryBaseUrl || 'http://127.0.0.1:23333').trim(),
    apiKey: String(c.cherryApiKey || '').trim(),
    model: String(c.model || 'deepseek:deepseek-v4-flash').trim()
  };
}

function normalizeBackend(b) {
  const id = String(b?.id || '').trim() || 'unnamed';
  const type = String(b?.type || 'cli').trim().toLowerCase();
  const out = { id, type };
  if (type === 'cli') {
    out.command = String(b.command || '').trim();
    out.timeoutMs = Math.min(900000, Math.max(10000, Number(b.timeoutMs) || 300000));
    let env = b.env;
    if (typeof env === 'string' && env.trim()) {
      try { env = JSON.parse(env); } catch { env = {}; }
    }
    out.env = (env && typeof env === 'object') ? env : {};
  } else if (type === 'openai' || type === 'cherry') {
    out.baseUrl = String(b.baseUrl || '').trim().replace(/\/+$/, '');
    out.apiKey = String(b.apiKey || '').trim();
    out.model = String(b.model || '').trim();
  } else {
    out.error = `不认识的后端类型「${type}」，只支持 cli / openai / cherry`;
  }
  return out;
}

/** 跑命令行后端：临时目录 + 文件就位 + 扫成品 */
function runCliBackend(backend, taskPrompt, files) {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'qqagent-cli-'));
  const staged = [];
  for (const f of files) {
    const n = safeName(f.name);
    fs.writeFileSync(path.join(dir, n), f.buffer);
    staged.push(n);
  }

  // 提示词怎么给：命令里有 {prompt} 就内联（shell 引号包好）；
  // 有 {promptFile} 就写进文件传路径（提示词很长/含特殊字符时更稳）；都没有则走 stdin。
  const promptFile = path.join(dir, '__task.txt');
  fs.writeFileSync(promptFile, taskPrompt, 'utf8');
  const quoted = `"${taskPrompt.replace(/"/g, '\\"').replace(/[\r\n]+/g, ' ')}"`;

  let cmd = backend.command;
  let stdinInput = '';
  if (cmd.includes('{promptFile}')) cmd = cmd.replace(/\{promptFile\}/g, `"${promptFile}"`);
  else if (cmd.includes('{prompt}')) cmd = cmd.replace(/\{prompt\}/g, quoted);
  else stdinInput = taskPrompt;

  return new Promise((resolve) => {
    let child;
    try {
      child = spawn(cmd, { cwd: dir, shell: true, windowsHide: true, env: { ...process.env, ...backend.env } });
    } catch (e) {
      return resolve({ error: `启动失败：${String(e?.message || e)}`, dir, staged, produced: [] });
    }
    let stdout = '', stderr = '';
    child.stdout.on('data', (d) => { stdout += d; });
    child.stderr.on('data', (d) => { stderr += d; });
    try { if (stdinInput) child.stdin.write(stdinInput); child.stdin.end(); } catch { /* 有的 CLI 不读 stdin */ }
    const timer = setTimeout(() => { try { child.kill(); } catch { /* 已退出 */ } }, backend.timeoutMs);
    child.on('error', (e) => { clearTimeout(timer); resolve({ error: String(e?.message || e), dir, staged, produced: [] }); });
    child.on('close', (code) => {
      clearTimeout(timer);
      // 扫这次新出现的文件（排除自己放进去的输入和提示词）
      let produced = [];
      try {
        produced = fs.readdirSync(dir)
          .filter((n) => !staged.includes(n) && n !== '__task.txt')
          .map((n) => ({ name: n, path: path.join(dir, n) }))
          .filter((x) => { try { return fs.statSync(x.path).isFile(); } catch { return false; } });
      } catch { /* 目录读不到就算了 */ }
      resolve({ code, stdout, stderr, dir, staged, produced });
    });
  });
}

/** 跑 OpenAI 兼容端点（非 Cherry 协议） */
async function runOpenAiBackend(backend, prompt, opt) {
  const r = await fetchImpl(`${backend.baseUrl}/chat/completions`, {
    method: 'POST',
    headers: {
      'content-type': 'application/json',
      ...(backend.apiKey ? { authorization: `Bearer ${backend.apiKey}` } : {})
    },
    body: JSON.stringify({ model: backend.model, messages: [{ role: 'user', content: prompt }] }),
    signal: AbortSignal.timeout(opt.timeoutMs)
  });
  const raw = await r.text();
  if (!r.ok) throw new Error(`HTTP ${r.status}：${raw.slice(0, 200)}`);
  const j = JSON.parse(raw);
  const text = j?.choices?.[0]?.message?.content || '';
  if (!text) throw new Error('后端没有返回内容');
  return text;
}

// ── 本机操作（可选功能） ────────────────────────────────────────────
//
// 为什么不用 Cherry 自带的 @cherry/filesystem：
//   它被死锁在一个 workspace root 里 —— 实测默认根是 D:\Users\username\Desktop，
//   连 E:\ 都进不去，直接报 "Path is outside the configured workspace root: E:\"。
//   而"操作电脑"必须能碰任意盘，所以这条路走不通。
//
//   改成由**技能自己**在 QQ Agent 进程里执行。这个进程本来就跑在用户机器上，
//   有完整的文件系统权限，不需要借道任何沙箱。
//
// 安全设计：三层闸门，默认全关
//   1. hostRoots 为空  → 连 host 工具都不注册，模型根本看不到
//   2. hostRoots 非空  → 但每个路径都必须落在这些根里，防 ../ 越界
//   3. 删文件 / 跑命令  → 各自还要 hostAllowDelete / hostAllowShell，默认都关

const HOST_BASIC = ['ls', 'read', 'write', 'mkdir', 'move', 'copy', 'info'];

function hostRootsOf(c) {
  return toStringList(c.hostRoots)
    .map((p) => {
      const abs = path.resolve(p);
      return abs.endsWith(path.sep) ? abs : abs + path.sep;
    });
}

/**
 * 把模型给的路径落成绝对路径，并校验它在允许范围内。
 *
 * 校验用的是"补一个结尾分隔符再比前缀"，这样 E:\foobar 不会因为
 * 前缀匹配而被误判成在 E:\foo 里面 —— 少一个分隔符就是另一个目录。
 */
function hostResolve(p, roots) {
  let s = String(p || '').trim();
  if (!s) throw new Error('缺少 path');
  if (!path.isAbsolute(s)) s = path.join(roots[0], s);
  const abs = path.resolve(s);
  const al = (abs.endsWith(path.sep) ? abs : abs + path.sep).toLowerCase();
  if (!roots.some((r) => al.startsWith(r.toLowerCase()))) {
    throw new Error(`路径不在允许范围内。只能操作：${roots.join('、')}`);
  }
  return abs;
}

/**
 * 解 Windows 控制台输出。
 *
 * 无脑 Buffer → utf8 会毁掉中文：中文 Windows 的控制台默认代码页是 GBK(936)，
 * 实测 powershell 吐回来的文件名成了 "�˱�������_��ϸ��_"，
 * 模型只能靠 MD5 去猜哪个文件是对的 —— 文件名比对这种事本来就不该靠猜。
 *
 * 做法：先当 UTF-8 解，出现替换字符就退回 GBK。
 */
function decodeConsole(buf) {
  if (!buf || !buf.length) return '';
  const utf8 = buf.toString('utf8');
  if (!utf8.includes('�')) return utf8;
  try {
    return new TextDecoder('gbk').decode(buf);
  } catch {
    return utf8;   // 运行环境没带 gbk 解码器，只能将就
  }
}

function fmtSize(n) {
  if (n < 1024) return n + ' B';
  if (n < 1048576) return (n / 1024).toFixed(1) + ' KB';
  if (n < 1073741824) return (n / 1048576).toFixed(1) + ' MB';
  return (n / 1073741824).toFixed(2) + ' GB';
}

function hostToolDef(roots, c) {
  const actions = [...HOST_BASIC];
  if (c.hostAllowDelete === true) actions.push('delete');
  if (c.hostAllowShell === true) actions.push('run');
  return {
    name: 'host',
    description:
      '★ 操作**这台电脑的真实文件系统**（不是沙箱）——建文件夹、读写文件、移动复制、列目录都在这里做。'
      + `只能在这些目录内操作：${roots.join('、')}。`
      + `action 可选：${actions.join(' / ')}。`
      + '建文件夹用 mkdir，例如 {"action":"mkdir","path":"D:\\\\归档"}。'
      + (c.hostAllowShell === true ? '' : '本机没有开放 run（执行命令）权限。')
      + (c.hostAllowDelete === true ? '' : '本机没有开放 delete（删除）权限。'),
    input_schema: {
      type: 'object',
      properties: {
        action: { type: 'string', enum: actions, description: '要做的操作。' },
        path: { type: 'string', description: '目标路径，绝对路径最稳，例如 D:\\归档。' },
        to: { type: 'string', description: 'move / copy 的目标路径。' },
        content: { type: 'string', description: 'write 时写入的文本内容。' },
        command: { type: 'string', description: 'run 要执行的命令。' },
        timeout_ms: { type: 'number', description: 'run 的超时毫秒，默认 60000。' }
      },
      required: ['action']
    }
  };
}

async function runHostAction(a, roots, c) {
  const action = String(a?.action || '').trim();
  const known = [...HOST_BASIC, 'delete', 'run'];
  if (!known.includes(action)) {
    throw new Error(`不认识的 action「${action}」。可用：${known.join(' / ')}`);
  }

  // run 的 path 是工作目录（可选），其余动作的 path 是操作目标（必填）
  let target = null;
  if (action !== 'run') target = hostResolve(a?.path, roots);

  if (action === 'ls') {
    if (!fs.existsSync(target)) return `「${target}」不存在。`;
    if (!fs.statSync(target).isDirectory()) return `「${target}」不是目录。`;
    const ents = fs.readdirSync(target, { withFileTypes: true })
      .map((d) => {
        let size = 0;
        try { if (d.isFile()) size = fs.statSync(path.join(target, d.name)).size; } catch { /* 读不到算 0 */ }
        return { name: d.name, dir: d.isDirectory(), size };
      })
      .sort((x, y) => (x.dir === y.dir ? x.name.localeCompare(y.name) : x.dir ? -1 : 1));
    if (!ents.length) return `目录 ${target} 是空的。`;
    const shown = ents.slice(0, 200);
    return `目录 ${target}（共 ${ents.length} 项${ents.length > 200 ? '，只列前 200' : ''}）：\n`
      + shown.map((e) => `${e.dir ? '[目录]' : '      '} ${e.name}${e.dir ? '' : '  ' + fmtSize(e.size)}`).join('\n');
  }

  if (action === 'info') {
    if (!fs.existsSync(target)) return `「${target}」不存在。`;
    const st = fs.statSync(target);
    return `${target}\n类型：${st.isDirectory() ? '目录' : '文件'}\n大小：${fmtSize(st.size)}`
      + `\n修改时间：${st.mtime.toLocaleString('zh-CN')}`;
  }

  if (action === 'read') {
    if (!fs.existsSync(target)) return `「${target}」不存在。`;
    const buf = fs.readFileSync(target);
    if (buf.subarray(0, 8000).includes(0)) return `「${path.basename(target)}」是二进制文件（${fmtSize(buf.length)}），没法按文本读。`;
    const txt = buf.toString('utf8');
    return txt.length > 200000 ? txt.slice(0, 200000) + `\n\n（已截断，原文 ${txt.length} 字）` : txt;
  }

  if (action === 'write') {
    const content = String(a?.content ?? '');
    if (Buffer.byteLength(content) > 2097152) throw new Error('write 内容超过 2 MB，改用别的办法');
    fs.mkdirSync(path.dirname(target), { recursive: true });
    fs.writeFileSync(target, content, 'utf8');
    return `已写入 ${target}（${fmtSize(Buffer.byteLength(content))}）。`;
  }

  if (action === 'mkdir') {
    if (fs.existsSync(target)) return `「${target}」已经存在${fs.statSync(target).isDirectory() ? '，是文件夹' : '，但它是个文件'}。`;
    fs.mkdirSync(target, { recursive: true });
    return `已创建文件夹 ${target}。`;
  }

  if (action === 'move' || action === 'copy') {
    if (!a?.to) throw new Error(`${action} 需要 to 参数`);
    if (!fs.existsSync(target)) return `「${target}」不存在，没法${action === 'copy' ? '复制' : '移动'}。`;
    const dest = hostResolve(a.to, roots);
    fs.mkdirSync(path.dirname(dest), { recursive: true });
    if (action === 'copy') {
      fs.cpSync(target, dest, { recursive: true, force: true });
      return `已复制 ${target} → ${dest}。`;
    }
    try {
      fs.renameSync(target, dest);
    } catch {
      // 跨盘 rename 会失败，退化成复制 + 删源
      fs.cpSync(target, dest, { recursive: true, force: true });
      fs.rmSync(target, { recursive: true, force: true });
    }
    return `已移动 ${target} → ${dest}。`;
  }

  if (action === 'delete') {
    if (c.hostAllowDelete !== true) throw new Error('管理员没有开启删除权限（hostAllowDelete）。');
    const al = (target.endsWith(path.sep) ? target : target + path.sep).toLowerCase();
    if (roots.some((r) => al === r.toLowerCase())) throw new Error('不能删除允许范围的根目录本身。');
    if (!fs.existsSync(target)) return `「${target}」本来就不存在。`;
    const wasDir = fs.statSync(target).isDirectory();
    fs.rmSync(target, { recursive: true, force: true });
    return `已删除${wasDir ? '目录' : '文件'} ${target}。`;
  }

  // run
  if (c.hostAllowShell !== true) throw new Error('管理员没有开启执行命令的权限（hostAllowShell）。');
  const cmd = String(a?.command || '').trim();
  if (!cmd) throw new Error('run 需要 command 参数');
  let cwd = roots[0];
  if (a?.path) {
    try {
      const p = hostResolve(a.path, roots);
      if (fs.existsSync(p) && fs.statSync(p).isDirectory()) cwd = p;
    } catch { /* 给的目录不合法就用根目录 */ }
  }
  const ms = Math.min(300000, Math.max(3000, Number(a?.timeout_ms) || 60000));
  const r = await new Promise((resolve) => {
    let child;
    try { child = spawn(cmd, { cwd, shell: true, windowsHide: true, env: process.env }); }
    catch (e) { return resolve({ error: String(e?.message || e) }); }
    // 收 Buffer 而不是直接拼字符串：中途拼就锁死了按 utf8 解，中文必乱，
    // 必须等收完拿到完整字节再决定用哪种编码解。
    const outBufs = [], errBufs = [];
    child.stdout.on('data', (d) => outBufs.push(d));
    child.stderr.on('data', (d) => errBufs.push(d));
    const timer = setTimeout(() => { try { child.kill(); } catch { /* 已退出 */ } }, ms);
    child.on('error', (e) => { clearTimeout(timer); resolve({ error: String(e?.message || e) }); });
    child.on('close', (code) => {
      clearTimeout(timer);
      resolve({
        code,
        out: decodeConsole(Buffer.concat(outBufs)),
        err: decodeConsole(Buffer.concat(errBufs))
      });
    });
  });
  if (r.error) throw new Error('启动失败：' + r.error);
  const body = [r.out, r.err].filter(Boolean).join('\n').trim().slice(-8000);
  return `命令执行完毕（退出码 ${r.code}，工作目录 ${cwd}）\n${body || '（无输出）'}`;
}

// ── 工具注册 ────────────────────────────────────────────────────────
export function setup(api) {
  cfg = api.config;
  fetchImpl = typeof api.fetch === 'function' ? (...a) => api.fetch(...a) : globalThis.fetch;
  api.log('远程任务技能已注册');

  api.registerTool({
    id: 'agent_task',
    name: '远程任务',
    description:
      '把任务交给外部 agent 实际执行：它能跑代码、读写文件、抓网页、生成新文件，完成后把成品文件发回当前会话。'
      + '当群友的要求需要**真正动手做**（写/运行代码、转换或处理文件、生成文件、批量整理）而不只是聊天时调用。'
      + '如果管理员开放了本机操作，它还能**直接操作这台电脑**（在指定目录里建文件夹、整理/改名/移动文件等）——'
      + '群友说「在 E 盘建个文件夹叫 XX」「把这些文件按日期归类」这类要求，也交给它。'
      + '⚠️ 对方只是闲聊、或只发了文件还没提要求时，不要调用。'
      + '⚠️ 遇到你自己做不到的事（写代码、格式转换、动电脑上的文件），先想这个工具能不能做。'
      + '必须先传 userId（对方的 QQ 号）。',
    category: 'knowledge',
    icon: '🤖',
    parameters: {
      type: 'object',
      properties: {
        instruction: {
          type: 'string',
          description: '要 agent 完成的任务，照对方的原话填完整，例如「把这个 PDF 转成 Word」「写个脚本统计这个 csv 每个月的总额，结果存成 xlsx」。'
        },
        userId: {
          type: 'string',
          description: '下任务那个人的 QQ 号，从上下文消息里的 (QQ:数字) 取。用于权限校验。'
        },
        backend: {
          type: 'string',
          description: '用哪个 AI 后端。不传就用设置里的默认后端。只有当对方点名要用某个工具（如「用 codex 做」「拿 claude 写」）时才传。'
        }
      },
      required: ['instruction']
    },
    async execute(ctx, args) {
      const c = cfg() || {};
      const opt = {
        base: String(c.cherryBaseUrl || 'http://127.0.0.1:23333').trim().replace(/\/+$/, ''),
        key: String(c.cherryApiKey || '').trim(),
        model: String(c.model || 'deepseek:deepseek-v4-flash').trim(),
        mcpServers: toStringList(c.mcpServers),
        maxRounds: Math.min(40, Math.max(1, Number(c.maxRounds) || 25)),
        timeoutMs: Math.min(600000, Math.max(30000, Number(c.timeoutMs) || 300000)),
        maxFileSizeMb: Math.max(1, Number(c.maxFileSizeMb) || 20),
        notifyEta: c.notifyEta !== false
      };

      const instruction = String(args?.instruction ?? '').trim();
      trace('=== 收到任务 ===', 'chat=' + ctx.chatKey, 'instruction=' + instruction.slice(0, 300));
      // 把原始配置形态也记下来：这一栏曾经出过"界面把数组存成字符串"的坑，
      // 光看报错看不出来，必须能一眼看到配置到底长什么样。
      trace('配置形态：', 'hostRoots=' + JSON.stringify(c.hostRoots),
        'allowedUsers=' + JSON.stringify(c.allowedUsers),
        'allowAll=' + JSON.stringify(c.allowAll),
        'defaultBackend=' + JSON.stringify(c.defaultBackend));
      if (!instruction) { trace('中止：instruction 为空'); return { content: '缺少 instruction：请说明要做什么。', isError: true }; }

      const userId = resolveUserId(ctx, args?.userId);
      const allowed = checkAllowed(c, userId);
      trace('权限：模型传的 userId=' + JSON.stringify(args?.userId ?? null) + ' 解析出=' + JSON.stringify(userId)
        + ' → ' + (allowed.ok ? '通过' : '拒绝（' + allowed.reason + '）'));
      if (!allowed.ok) return { content: `没有权限下任务：${allowed.reason}。`, isError: true };
      if (!opt.key) { trace('中止：cherryApiKey 没配'); return { content: 'Cherry Studio 的 API Key 还没配（技能设置里的 cherryApiKey）。', isError: true }; }

      // 含糊指令防护：只拦"明显没说要干什么"的，别误伤正常请求。
      //
      // 第一版写成"必须含某个动作词"，实测立刻误伤——「把这句话原样存下来」「列出工作目录」
      // 这种清清楚楚的指令因为词表里没收录对应动词就被拦了。白名单必然漏，除非把动词表写到无穷大。
      // 所以改成**黑名单**：只有整句就是一句含糊话时才拦。
      const VAGUE_RE = /^(帮我|请|你)?(来|去)?(看看|看一下|看下|瞅瞅|瞧瞧|看看这个|看看这个文件|看下这个|处理一下|帮我处理|弄一下|搞一下|弄弄|处理下|这个怎么办|怎么办|咋办|搞一下这个|弄一下这个|看看咋办)[吧呗呀啊哦。！？~…\s]*$/;
      const bare = instruction.replace(/[\s。，,.！!？?~…、]/g, '');
      const tooShort = bare.length <= 4;
      if (VAGUE_RE.test(bare) || tooShort) {
        trace('中止：判定为含糊指令 —', JSON.stringify(instruction));
        return {
          content: '指令太含糊，已放弃执行。对方没说清要做什么（例如只说了「帮我看看」「处理一下」）。'
            + '请先用一句话问清楚他要什么（例如「要我帮你把这份 PDF 转成 Word，还是先总结一下内容？」），'
            + '等他答了再调这个工具，并把他的原话填进 instruction。',
          isError: true
        };
      }

      const t0 = Date.now();

      // ① 收集群友发的文件 —— 必须**在发提示之前**做。
      //    发提示会落一条 self 发言，若收集逻辑依赖"上次发言之后"，边界就被推过去了。
      const incoming = [];
      const qqFiles = new Map();   // 文件名 → {buffer, size}
      try {
        const direct = collectRecentFiles(ctx);
        let quoted = [];
        try { quoted = await collectQuotedFiles(ctx, direct); } catch { /* 回溯失败不影响直发的那批 */ }
        for (const f of [...direct, ...quoted]) {
          const one = await downloadQQFile(ctx, f, opt.timeoutMs);
          incoming.push({ name: one.name, size: one.size, fromQuote: !!f.fromQuote });
          qqFiles.set(one.name, one);
        }
      } catch (e) {
        return { content: `取群友发的文件时失败：${String(e?.message || e).slice(0, 200)}`, isError: true };
      }

      // ② 提示（放在收集之后）
      if (opt.notifyEta) {
        try {
          // 措辞不能写「收到 N 个文件」——文件是 10 分钟窗口捞来的，未必跟这次请求有关。
          // 实测：「建个文件夹」也提示了「收到 1 个文件」，而那个文件根本没被用到，误导人。
          await ctx.sender.sendTextBatch(ctx.chatKey, [
            incoming.length
              ? `收到，手边有 ${incoming.length} 个文件可以用，正在交给执行端处理，大概要 1~2 分钟~`
              : '收到，正在交给执行端处理，大概要 1~2 分钟~'
          ]);
        } catch { /* 预告失败不挡正事 */ }
      }

      // ②.5 后端分流：非 Cherry 的后端不走 agent 循环，直接一次调用
      const backend = resolveBackend(c, args?.backend);
      if (backend.error) return { content: backend.error, isError: true };

      if (backend.type !== 'cherry') {
        const t1 = Date.now();
        // 给后端一份自包含的任务说明：它看不到聊天记录，也不知道文件在哪
        const brief = [`# 任务\n${instruction}`];
        if (incoming.length) {
          brief.push(`\n# 可用文件\n` + incoming.map((f) => `- ${f.name}（${(f.size / 1024).toFixed(1)} KB）`).join('\n'));
          if (backend.type !== 'cli') {
            // 非 CLI 后端没有工作目录，只能把文本文件内容内联
            for (const [n, f] of qqFiles) {
              if (TEXT_EXT.has(extOf(n)) && f.size < 20000) {
                brief.push(`\n----- ${n} -----\n${f.buffer.toString('utf8')}`);
              }
            }
          }
        }
        brief.push('\n完成后简要说明你做了什么。');
        const taskPrompt = brief.join('\n');

        try {
          if (backend.type === 'cli') {
            const res = await runCliBackend(backend, taskPrompt, [...qqFiles.values()]);
            if (res.error) return { content: `后端「${backend.id}」执行失败：${res.error}`, isError: true };

            // CLI 写出的文件就是成品，逐个发回
            const sent = [];
            for (const p of res.produced) {
              try {
                await uploadFile(ctx, p.path, p.name);
                sent.push(p.name);
              } catch { /* 单个失败不影响其余 */ }
            }
            const tail = (res.stdout || res.stderr || '').trim().slice(-1500);
            const secs = Math.round((Date.now() - t1) / 1000);
            return {
              content: `后端「${backend.id}」执行完毕（退出码 ${res.code ?? '?'}，用时 ${secs} 秒）。\n`
                + (sent.length ? `已发回 ${sent.length} 个文件：${sent.join('、')}。\n` : '没有产生新文件。\n')
                + (tail ? `\n它的输出（末尾部分）：\n${tail}\n` : '')
                + '\n请用你自己的话简短转告群友，不要复述日志。'
            };
          }

          // openai / 其它 HTTP 后端
          const answer = await runOpenAiBackend(backend, taskPrompt, opt);
          const secs = Math.round((Date.now() - t1) / 1000);
          return {
            content: `后端「${backend.id}」返回结果（用时 ${secs} 秒）：\n\n${answer.slice(0, 6000)}\n\n`
              + '请用你自己的话简短转告群友。注意：这个后端只能给文字答复，不能产出文件。'
          };
        } catch (e) {
          return { content: `后端「${backend.id}」执行失败：${String(e?.message || e).slice(0, 250)}`, isError: true };
        }
      }

      // ② MCP 工具 + 两个技能自己的工具
      let mcp;
      try {
        mcp = await listMcpTools(opt.base, opt.key, opt.mcpServers, api.log);
      } catch (e) {
        trace('中止：连不上 Cherry MCP —', String(e?.message || e));
        return { content: `连不上 Cherry Studio 的 MCP（${String(e?.message || e).slice(0, 150)}）。确认它在运行、Key 正确。`, isError: true };
      }
      if (!mcp.tools.length) {
        trace('中止：MCP 一个工具都没有');
        return { content: '没有可用的 MCP 工具（检查技能设置里的 mcpServers，或 Cherry Studio 是否装了 MCP）。', isError: true };
      }

      // 找出 python 执行工具（MCP 的 python_execute），供 python_with_file 复用
      const pyEntry = [...mcp.byName.values()].find((v) => v.rawName === 'python_execute');

      const deliverables = [];
      const fileHint = qqFiles.size ? `当前可用的输入文件：${[...qqFiles.keys()].join('、')}。` : '当前没有输入文件。';
      const clientTools = [
        {
          name: 'python_run',
          description:
            '在 Python 沙箱里跑代码做分析或探查，返回 print() 的输出。'
            + '传了 file_name 时，代码里可直接用变量 DATA（该文件的 base64），先 base64.b64decode(DATA) 拿字节。'
            + '库：内置 zipfile/gzip/csv/json/hashlib/re 等；PDF 装 pypdf、Word 装 python-docx、Excel 装 openpyxl（micropip，已验证可用）。'
            + fileHint,
          input_schema: {
            type: 'object',
            properties: {
              code: { type: 'string', description: 'Python 代码。' },
              file_name: { type: 'string', description: '可选。要用某个输入文件时填它的文件名（代码里就是 DATA）。' }
            },
            required: ['code']
          }
        },
        {
          name: 'deliver',
          description:
            '★ 生成成品文件并发给用户 —— **交付就用它**。'
            + '你的代码负责把成品字节构造出来；**代码的最后一行必须是 print(base64.b64encode(数据).decode())**，'
            + '技能会取这一行解码后保存并发送。'
            + '关键：文件字节**不经过你**，所以多大的成品都能交付，你也不需要看到 base64。'
            + '传了 file_name 时，代码里可直接用变量 DATA（输入文件的 base64）。'
            + fileHint,
          input_schema: {
            type: 'object',
            properties: {
              artifact_name: { type: 'string', description: '要发给用户的成品文件名，含扩展名，例如 永夜物语.docx' },
              code: { type: 'string', description: 'Python 代码，负责构造成品，末行 print(base64.b64encode(数据).decode())。' },
              file_name: { type: 'string', description: '可选。需要读输入文件时填它的文件名。' }
            },
            required: ['artifact_name', 'code']
          }
        }
      ];
      // 本机操作工具：只有配了 hostRoots 才注册，否则模型连"有这回事"都不知道
      const hostRoots = hostRootsOf(c);
      if (hostRoots.length) {
        clientTools.push(hostToolDef(hostRoots, c));
        trace('本机操作已开放：' + hostRoots.join('、')
          + (c.hostAllowShell === true ? '（含命令执行）' : '')
          + (c.hostAllowDelete === true ? '（含删除）' : ''));
        api.log?.('已开放本机操作，范围：' + hostRoots.join('、')
          + (c.hostAllowShell === true ? '（含命令执行）' : '')
          + (c.hostAllowDelete === true ? '（含删除）' : ''));
      }

      const tools = [...clientTools, ...mcp.tools];
      const log = api.log || (() => {});

      // ③ 初始上下文
      const lines = [`【用户的请求】\n${instruction}`];
      if (incoming.length) {
        lines.push(`\n【用户在 QQ 里发来的文件】\n` + incoming.map((f) => `- ${f.name}（${(f.size / 1024).toFixed(1)} KB）`).join('\n'));
        // 小文本文件直接内联，省一轮工具调用
        for (const [n, f] of qqFiles) {
          if (TEXT_EXT.has(extOf(n)) && f.size < 20000) {
            lines.push(`\n----- ${n} 的内容 -----\n${f.buffer.toString('utf8')}`);
          }
        }
        lines.push('\n处理文件用 python_run（传 file_name，代码里直接用变量 DATA，不要自己传文件内容）。');
      } else {
        lines.push('\n（用户这次没有发文件。需要跑代码就用可用的 Python 工具。）');
      }
      const execRules = [
        '',
        '【执行要求 —— 请认真读，违反会导致任务白做】',
        `1. 你只有 ${opt.maxRounds} 轮工具调用。用完就强制结束，成品发不出去。`,
        '   **前 3 轮内必须动手产出**，不要反复探查、不要调参优化。',
        '2. 标准是「能用」，不是「完美」。绝对不要把时间花在这类事情上：',
        '   · 逐页分析坐标/字号去还原原始排版',
        '   · 尝试调阈值/启发式让分段更准',
        '   · 反复验证同一个结果',
        '   拿不准就用最简单直接的做法，先把成品交出去。',
        '3. 产出成品用 deliver 工具：你写代码构造成品，代码**末行必须** print(base64.b64encode(数据).decode())。',
        '   技能会自己取走字节发给用户，你不需要（也拿不到）看到成品内容。',
        '4. 典型做法（PDF→Word 为例）：pypdf 抽每页文字 → 按空行/短行简单分段 → python-docx 写入 → deliver。',
        '   三五轮就该做完。',
        '5. 做完就停，用中文简要说明你做了什么。'
      ];
      if (hostRoots.length) {
        execRules.push(
          '6. 要动**本机的文件夹和文件**（建目录、整理、改名、移动），用 host 工具做，一两轮就够，'
          + '做完直接说明结果，**不需要 deliver**（deliver 是发文件给群友用的，本机操作不发文件）。',
          '7. ⚠️ 别用 Cherry 自带的 filesystem 工具（ls/read/write/glob 那些）——它被锁在别的目录，'
          + '碰你要操作的地方只会报 outside the configured workspace root。本机操作一律走 host。'
        );
      }
      lines.push(execRules.join('\n'));

      const messages = [{ role: 'user', content: lines.join('\n') }];

      // ④ agent 循环
      let rounds = 0;
      let finalText = '';
      const transcript = [];
      const deadline = Date.now() + opt.timeoutMs;

      while (rounds < opt.maxRounds) {
        if (Date.now() > deadline) { finalText += '\n（达到总超时，已中止）'; break; }
        rounds++;
        let res;
        try {
          res = await callModel(opt.base, opt.key, opt.model, tools, messages,
            Math.max(15000, Math.min(120000, deadline - Date.now())));
        } catch (e) {
          return { content: `模型调用失败：${String(e?.message || e).slice(0, 200)}`, isError: true };
        }

        const toolUses = res.blocks.filter((b) => b.type === 'tool_use');
        const texts = res.blocks.filter((b) => b.type === 'text').map((b) => b.text).filter(Boolean);
        if (texts.length) finalText = texts.join('\n');

        const roundDesc = `轮 ${rounds}/${opt.maxRounds}：`
          + (toolUses.length ? toolUses.map((t) => `${t.name}(${JSON.stringify(t.input || {}).slice(0, 120)})`).join(' | ') : '（无工具调用，结束）');
        log(roundDesc);
        trace(roundDesc);

        if (!toolUses.length) break;   // 不再调工具 = 完成

        messages.push({ role: 'assistant', content: res.blocks });
        const results = [];
        for (const tu of toolUses) {
          const label = `${tu.name}(${JSON.stringify(tu.input || {}).slice(0, 70)})`;
          let out;
          try {
            if (tu.name === 'python_run' || tu.name === 'deliver') {
              const code = String(tu.input?.code || '');
              if (!code.trim()) throw new Error('code 不能为空');
              if (!pyEntry) throw new Error('Cherry Studio 里没有可用的 python_execute 工具');

              // 需要输入文件时，把文件字节注入沙箱，**不经过模型上下文**
              let full = code;
              const want = String(tu.input?.file_name ?? '').trim();
              if (want) {
                const hit = qqFiles.get(want) || [...qqFiles.entries()].find(([k]) => k.includes(want))?.[1];
                if (!hit) throw new Error(`没有名为「${want}」的文件。可用的：${[...qqFiles.keys()].join('、') || '（无）'}`);
                full = `DATA = ${JSON.stringify(hit.buffer.toString('base64'))}\n${code}`;
              }
              const pyOut = await callMcpTool(opt.base, opt.key, pyEntry, { code: full },
                Math.max(30000, Math.min(180000, deadline - Date.now())));

              if (tu.name === 'python_run') {
                out = pyOut;
              } else {
                // deliver：取代码末行作为成品字节。
                // ★ 这样做是为了让成品**不经过模型** —— 早先让模型把 base64 抄进参数，
                //   十几万字符的成品它抄不动，于是陷入"反复确认、就是不肯交付"。
                const lines = String(pyOut).trim().split('\n').map((s) => s.trim()).filter(Boolean);
                const b64 = lines[lines.length - 1] || '';
                if (!/^[A-Za-z0-9+/=]+$/.test(b64)) {
                  throw new Error('交付失败：代码末行没有输出合法 base64。末行内容：' + b64.slice(0, 100));
                }
                const buf = Buffer.from(b64, 'base64');
                if (!buf.length) throw new Error('交付失败：解码后是空的');
                if (buf.length > opt.maxFileSizeMb * 1024 * 1024) {
                  throw new Error(`成品 ${(buf.length / 1024 / 1024).toFixed(1)} MB 超过 ${opt.maxFileSizeMb} MB 上限`);
                }
                const nm = safeName(tu.input?.artifact_name || 'artifact');
                const dir = path.join(dataDir(), 'delivered');
                fs.mkdirSync(dir, { recursive: true });
                const p = path.join(dir, `${Date.now()}_${nm}`);
                fs.writeFileSync(p, buf);
                deliverables.push({ name: nm, path: p, size: buf.length });
                out = `已交付「${nm}」（${(buf.length / 1024).toFixed(1)} KB），会自动发给用户。`;
              }
            } else if (tu.name === 'host') {
              // 没配 hostRoots 时工具压根没注册，但模型可能凭印象硬编一个出来，
              // 那会走到空 roots 的校验里报出半截消息。在入口就挡掉。
              if (!hostRoots.length) throw new Error('本机操作没有开放（管理员要在技能设置里填「允许操作的目录」）。');
              out = await runHostAction(tu.input, hostRoots, c);
            } else {
              const entry = mcp.byName.get(tu.name);
              if (!entry) throw new Error(`未知工具 ${tu.name}`);
              out = await callMcpTool(opt.base, opt.key, entry, tu.input, Math.max(30000, Math.min(180000, deadline - Date.now())));
            }
          } catch (e) {
            out = '出错：' + String(e?.message || e).slice(0, 300);
          }
          log(`  ↳ ${String(out).replace(/\s+/g, ' ').slice(0, 220)}`);
          trace('  ↳ ' + String(out).replace(/\s+/g, ' ').slice(0, 300));
          transcript.push({ tool: label, out: String(out).slice(0, 200) });

          // 预算警告：模型对自己还能跑几轮没有概念，会一直"再确认一下"直到轮数耗尽、
          // 成品发不出去。实测一个 191 页 PDF 就这样连着 22 轮做坐标级排版分析。
          // 把剩余轮数直接怼到工具结果里，它才会收手。
          const remaining = opt.maxRounds - rounds;
          let body = String(out).slice(0, 60000);
          // 预算警告必须**分任务类型**。本机操作类任务不需要 deliver，
          // 一律喊"立刻用 deliver 交成品"会把模型带偏——它会真去调 deliver 交个空壳。
          if (tu.name === 'host') {
            if (remaining <= 2) body += `\n\n⚠️ 只剩 ${remaining} 轮。本机操作做完就直接说明结果，**不需要 deliver**。`;
          } else if (remaining <= 3) {
            body += `\n\n⚠️ 只剩 ${remaining} 轮工具调用！**立刻**用 deliver 把成品交出来，不要再做任何分析或检查。`;
          } else if (remaining <= 6) {
            body += `\n\n（还剩 ${remaining} 轮。请现在就开始产出成品，不要再深入分析。）`;
          }
          results.push({ type: 'tool_result', tool_use_id: tu.id, content: body });
        }
        messages.push({ role: 'user', content: results });
      }

      // ⑤ 交付成品
      const sent = [];
      for (const d of deliverables) {
        try {
          await uploadFile(ctx, d.path, d.name);
          sent.push(d);
        } catch (e) {
          sent.push({ ...d, failed: String(e?.message || e).slice(0, 100) });
        }
      }

      const secs = Math.round((Date.now() - t0) / 1000);
      const okFiles = sent.filter((s) => !s.failed);
      const badFiles = sent.filter((s) => s.failed);

      let content = `任务执行完毕（${rounds} 轮工具调用，用时 ${secs} 秒）。\n\n`;
      content += finalText ? `执行端给出的说明：\n${finalText.slice(0, 3000)}\n\n` : '';
      if (okFiles.length) content += `已交付 ${okFiles.length} 个文件：${okFiles.map((f) => `${f.name}（${(f.size / 1024).toFixed(1)} KB）`).join('、')}。\n`;
      if (badFiles.length) content += `以下文件发送失败：${badFiles.map((f) => f.name).join('、')}。\n`;
      if (!okFiles.length && !finalText) content += '执行端没有返回可用结果或成品。\n';
      content += '\n请用你自己的话把这个结果简短转告群友，不要复述执行过程或工具调用细节。';

      trace('=== 结束 ===', `${rounds} 轮 / ${secs}s`, '交付 ' + okFiles.length + ' 个文件');
      return { content };
    }
  });
}

export function available() {
  return true;
}
