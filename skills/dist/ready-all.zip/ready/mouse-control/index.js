// 鼠标操控（mouse-control）—— 本地自制技能
//
// 用途：主人从聊天里操控机器人所在 Windows 电脑的鼠标指针 ——
//   移动、左键/右键/中键单击、双击、按住拖动、滚轮滚动。
//
// ── 为什么是 skills/ 而不是 plugins/ ─────────────────────────────────────
//   「点什么、在哪点、什么时候点」取决于对话语义和屏幕画面，规则写不死，
//   必须由模型理解后调用工具 —— 正是 LLM 型技能的语义。
//   接入 LLM 只有 registerTool 一条路（src/plugin-loader.js §0），所以放 skills/。
//
// ── 安全设计（沿用 plugins/pc-control 的成熟方案）─────────────────────────
//   ① 主人判定：ownerIds 配置优先，否则问「主人识别」能力；
//      两者都没配时**完全不动作**（防止任何陌生人操控宿主电脑）。
//   ② 触发范围：scope=private（默认，仅主人私聊）| all（+ 群里主人发言）。
//      且工具 execute 时二次校验触发者身份 —— 模型被话术忽悠调了工具也没用。
//   ③ 限频：每小时最多 maxPerHour 次（默认 15）。
//   ④ 审计：每次执行记 谁/何时/什么/结果 到 data/mouse-control-audit.log。
//   ⚠️ 审计日志写核心数据目录（DATA_DIR），绝不写进 skills/ 自己的目录 ——
//      插件目录内任何写入都会触发热重载监视器全量重扫（health-data.json 教训）。
//
// ── 实现载体 ─────────────────────────────────────────────────────────────
//   PowerShell + user32.dll（SetCursorPos / mouse_event / GetCursorPos）。
//   每次 Add-Type 一次性编译，单次执行约几百毫秒，够用且零依赖。
//   坐标一律**物理像素**：脚本开头 SetProcessDPIAware()，避免缩放（125%/150%）
//   环境下"模型按截图估的坐标"和"实际指针位置"错位。

import fs from 'node:fs';
import path from 'node:path';
import { execFile } from 'node:child_process';
import { DATA_DIR } from '../../src/config.js';

const ID = 'mouse-control';

let cfg = () => ({});
let log = (...a) => {};

// ── 主人判定（与 pc-control / 表情收藏同源）────────────────────────────────
let apiRef = null;
function makeOwnerChecker() {
  const explicit = String(cfg().ownerIds || '').split(/[,，;；\s]+/).map((s) => s.trim()).filter(Boolean);
  if (explicit.length) return (uid) => explicit.includes(String(uid));
  const cap = apiRef?.capability;
  if (typeof cap !== 'function') return null;
  return (uid) => {
    let r;
    try { r = cap('message.owner-check', { userId: Number(uid) || uid }); } catch { return false; }
    return !!r && typeof r.then !== 'function' && r.isOwner === true;
  };
}

/** 触发范围闸：scope=private 时只允许私聊。返回 null=放行，否则为拒绝理由。 */
function scopeGate(ctxLike) {
  const kind = ctxLike?.kind || ctxLike?.chatKey?.split(':')[0] || '';
  if (String(cfg().scope || 'private') === 'private' && kind !== 'private') {
    return '当前触发范围为「仅主人私聊」（可在技能设置里改为 all）';
  }
  return null;
}

// ── 审计 + 限频 ───────────────────────────────────────────────────────────
function auditFile() {
  return path.join(DATA_DIR || path.join(process.cwd(), 'data'), `${ID}-audit.log`);
}
function audit(chatKey, uid, action, result) {
  try {
    if (cfg().audit === false) return;
    const f = auditFile();
    const line = `${new Date().toISOString()} ${chatKey} ${uid || '?'} ${action} => ${String(result).slice(0, 200)}\n`;
    try {
      if (fs.existsSync(f) && fs.statSync(f).size > 2 * 1048576) fs.renameSync(f, f.replace(/\.log$/, '.old'));
    } catch { /* 轮转失败不影响主流程 */ }
    fs.appendFileSync(f, line, 'utf8');
  } catch { /* 审计失败绝不影响执行 */ }
}

const execTimes = [];
function rateLimited() {
  const now = Date.now();
  while (execTimes.length && now - execTimes[0] > 3600000) execTimes.shift();
  const max = Math.max(1, Number(cfg().maxPerHour) || 15);
  if (execTimes.length >= max) return true;
  execTimes.push(now);
  return false;
}

/** 工具执行者身份闸：触发批里最后一条用户消息必须是主人，且通过范围闸。 */
function toolGate(ctx, toolName) {
  const scopeRej = scopeGate(ctx);
  if (scopeRej) return { ok: false, why: scopeRej };
  const entries = ctx?.session?.trigger || ctx?.session?.triggerEntries || [];
  const last = Array.isArray(entries) && entries.length ? entries[entries.length - 1] : null;
  const uid = String(last?.senderId ?? '').trim();
  if (!uid) return { ok: false, why: '无法识别触发者（主动运行不接受鼠标操控）' };
  const isOwner = makeOwnerChecker();
  if (!isOwner || !isOwner(uid)) return { ok: false, why: '只有主人可以使用鼠标操控（如果主人身份没配置过，请在技能设置里填主人QQ号）' };
  if (rateLimited()) return { ok: false, why: '请求太频繁，稍后再试' };
  audit(ctx?.chatKey || '?', uid, 'tool:' + toolName, '授权通过');
  return { ok: true, uid };
}

// ── PowerShell 执行器 ─────────────────────────────────────────────────────
function runPS(script, timeoutMs = 15000) {
  return new Promise((resolve) => {
    // [Console]::OutputEncoding=UTF8：Windows PowerShell 5.1 默认按 GBK 输出，中文会乱码
    execFile('powershell.exe',
      ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-Command', '[Console]::OutputEncoding=[System.Text.Encoding]::UTF8\n' + script],
      { timeout: timeoutMs, windowsHide: true, maxBuffer: 4 * 1048576, encoding: 'utf8' },
      (error, stdout) => resolve({ ok: !error, out: String(stdout || '').trim(), err: error?.message || '' }));
  });
}

// user32 P/Invoke 公共头（单引号 here-string，不插值）
const PS_HEAD = `
$ErrorActionPreference = 'Stop'
if (-not ('MC' -as [type])) {
Add-Type -TypeDefinition @'
using System;using System.Runtime.InteropServices;
public class MC {
  [DllImport("user32.dll")] public static extern bool SetProcessDPIAware();
  [DllImport("user32.dll")] public static extern bool SetCursorPos(int X, int Y);
  [DllImport("user32.dll")] public static extern void mouse_event(uint dwFlags, uint dx, uint dy, uint dwData, UIntPtr dwExtraInfo);
  [DllImport("user32.dll")] public static extern bool GetCursorPos(out POINT p);
  [StructLayout(LayoutKind.Sequential)] public struct POINT { public int X; public int Y; }
}
'@
}
[MC]::SetProcessDPIAware() | Out-Null
Add-Type -AssemblyName System.Windows.Forms
$b = [System.Windows.Forms.Screen]::PrimaryScreen.Bounds
function Clamp([int]$v, [int]$max) { if ($v -lt 0) { return 0 }; if ($v -ge $max) { return $max - 1 }; return $v }
`;

// mouse_event 按钮标志（十进制）：LEFTDOWN=2 LEFTUP=4 RIGHTDOWN=8 RIGHTUP=16 MIDDLEDOWN=32 MIDDLEUP=64 WHEEL=2048 HWHEEL=4096
const BTN = {
  left: { down: 2, up: 4 },
  right: { down: 8, up: 16 },
  middle: { down: 32, up: 64 }
};

/** 校验整数参数，返回 { ok, value } */
function asInt(v, lo, hi, fallback = null) {
  const n = Math.round(Number(v));
  if (!Number.isFinite(n)) return fallback === null ? { ok: false, value: 0 } : { ok: true, value: fallback };
  return { ok: true, value: Math.max(lo, Math.min(hi, n)) };
}

// ── 能力实现 ──────────────────────────────────────────────────────────────
async function capPosition() {
  const r = await runPS(PS_HEAD + `
$p = New-Object 'MC+POINT'
[MC]::GetCursorPos([ref]$p) | Out-Null
Write-Output ("{0},{1},{2},{3}" -f $p.X, $p.Y, $b.Width, $b.Height)
`);
  if (!r.ok || !r.out) return { err: '查询失败：' + (r.err || 'PowerShell 无输出') };
  const [x, y, w, h] = r.out.split(',').map((n) => parseInt(n, 10));
  if (!Number.isFinite(w) || w <= 0) return { err: '查询失败：拿不到屏幕尺寸' };
  return { x: x || 0, y: y || 0, screenW: w, screenH: h };
}

async function capMove(x, y) {
  const r = await runPS(PS_HEAD + `
$x = Clamp ${x} $b.Width
$y = Clamp ${y} $b.Height
[MC]::SetCursorPos($x, $y) | Out-Null
Start-Sleep -Milliseconds 60
$p = New-Object 'MC+POINT'
[MC]::GetCursorPos([ref]$p) | Out-Null
Write-Output ("{0},{1}" -f $p.X, $p.Y)
`);
  if (!r.ok) return { err: '移动失败：' + r.err };
  const [fx, fy] = r.out.split(',').map((n) => parseInt(n, 10));
  return { x: fx, y: fy };
}

async function capClick(x, y, button = 'left', double = false) {
  const btn = BTN[button];
  if (!btn) return { err: `不支持的按键：${button}（只支持 left/right/middle）` };
  const clickPair = `[MC]::mouse_event(${btn.down},0,0,0,[UIntPtr]::Zero); Start-Sleep -Milliseconds 45; [MC]::mouse_event(${btn.up},0,0,0,[UIntPtr]::Zero)`;
  const body = double
    ? `${clickPair}; Start-Sleep -Milliseconds 90; ${clickPair}`
    : clickPair;
  const r = await runPS(PS_HEAD + `
$x = Clamp ${x} $b.Width
$y = Clamp ${y} $b.Height
[MC]::SetCursorPos($x, $y) | Out-Null
Start-Sleep -Milliseconds 90
${body}
Write-Output done
`, 20000);
  if (!r.ok || !r.out) return { err: '点击失败：' + (r.err || '无输出') };
  return { ok: true };
}

async function capDrag(fx, fy, tx, ty) {
  const r = await runPS(PS_HEAD + `
$fx = Clamp ${fx} $b.Width
$fy = Clamp ${fy} $b.Height
$tx = Clamp ${tx} $b.Width
$ty = Clamp ${ty} $b.Height
[MC]::SetCursorPos($fx, $fy) | Out-Null
Start-Sleep -Milliseconds 140
[MC]::mouse_event(2,0,0,0,[UIntPtr]::Zero)
Start-Sleep -Milliseconds 120
$steps = 24
for ($i = 1; $i -le $steps; $i++) {
  $x = [int]($fx + ($tx - $fx) * $i / $steps)
  $y = [int]($fy + ($ty - $fy) * $i / $steps)
  [MC]::SetCursorPos($x, $y) | Out-Null
  Start-Sleep -Milliseconds 16
}
Start-Sleep -Milliseconds 120
[MC]::mouse_event(4,0,0,0,[UIntPtr]::Zero)
Write-Output done
`, 30000);
  if (!r.ok || !r.out) return { err: '拖动失败：' + (r.err || '无输出') };
  return { ok: true };
}

async function capScroll(notches, direction = 'vertical') {
  const flag = direction === 'horizontal' ? 4096 : 2048;
  // 垂直：正数=向上滚，负数=向下滚（wheel delta 120/格）
  const delta = Math.round(notches) * 120;
  const r = await runPS(PS_HEAD + `
[MC]::mouse_event(${flag},0,0,${delta},[UIntPtr]::Zero)
Start-Sleep -Milliseconds 80
Write-Output done
`);
  if (!r.ok || !r.out) return { err: '滚动失败：' + (r.err || '无输出') };
  return { ok: true };
}

// ── 工具注册 ──────────────────────────────────────────────────────────────
const OWNER_ONLY = '只有主人可以要求这个操作，其他人的请求要拒绝。';

export function setup(api) {
  cfg = () => (typeof api?.config === 'function' ? (api.config() || {}) : {});
  log = (...a) => api.log?.(...a);
  apiRef = api;

  const gate = (ctx, toolName) => {
    const g = toolGate(ctx, toolName);
    return g.ok ? null : g.why;
  };

  api.registerTool({
    id: 'position',
    name: '鼠标位置查询',
    description: `查询机器人所在 Windows 电脑鼠标指针的当前坐标和屏幕分辨率（物理像素，左上角为 0,0）。执行任何鼠标操作前先调它拿屏幕宽高，好把截图坐标换算成屏幕坐标。${OWNER_ONLY}`,
    category: 'system',
    icon: '🖱',
    parameters: { type: 'object', properties: {} },
    async execute(ctx) {
      const rej = gate(ctx, 'position');
      if (rej) return { content: rej, isError: true };
      const r = await capPosition();
      if (r.err) return { content: r.err, isError: true };
      return { content: `当前鼠标位置：(${r.x}, ${r.y})。屏幕分辨率：${r.screenW} × ${r.screenH}（物理像素）。` };
    }
  });

  api.registerTool({
    id: 'move',
    name: '移动鼠标',
    description: `把机器人所在电脑的鼠标指针移动到指定坐标（物理像素，左上角 0,0）。只移动不点击。${OWNER_ONLY}`,
    category: 'system',
    icon: '🖱',
    parameters: {
      type: 'object',
      properties: {
        x: { type: 'integer', description: '目标横坐标（物理像素）' },
        y: { type: 'integer', description: '目标纵坐标（物理像素）' }
      },
      required: ['x', 'y']
    },
    async execute(ctx, args) {
      const rej = gate(ctx, 'move');
      if (rej) return { content: rej, isError: true };
      const px = asInt(args?.x, 0, 32767);
      const py = asInt(args?.y, 0, 32767);
      if (!px.ok || !py.ok) return { content: '坐标必须是数字', isError: true };
      const r = await capMove(px.value, py.value);
      if (r.err) return { content: r.err, isError: true };
      return { content: `已把鼠标移到 (${r.x}, ${r.y})。` };
    }
  });

  api.registerTool({
    id: 'click',
    name: '鼠标点击',
    description: `在机器人所在电脑的指定坐标点击鼠标（会先把指针移过去再点）。button 选 left/right/middle；double=true 表示双击。点击前先想清楚目标坐标（结合屏幕截图换算）。高危点击（删除、发送、支付、确认弹窗）必须先征得主人同意。${OWNER_ONLY}`,
    category: 'system',
    icon: '👆',
    parameters: {
      type: 'object',
      properties: {
        x: { type: 'integer', description: '目标横坐标（物理像素）' },
        y: { type: 'integer', description: '目标纵坐标（物理像素）' },
        button: { type: 'string', enum: ['left', 'right', 'middle'], description: '点哪个键，默认 left（左键）' },
        double: { type: 'boolean', description: 'true=双击，默认 false（单击）' }
      },
      required: ['x', 'y']
    },
    async execute(ctx, args) {
      const rej = gate(ctx, 'click');
      if (rej) return { content: rej, isError: true };
      const px = asInt(args?.x, 0, 32767);
      const py = asInt(args?.y, 0, 32767);
      if (!px.ok || !py.ok) return { content: '坐标必须是数字', isError: true };
      const button = ['left', 'right', 'middle'].includes(String(args?.button)) ? String(args.button) : 'left';
      const dbl = args?.double === true;
      const r = await capClick(px.value, py.value, button, dbl);
      if (r.err) return { content: r.err, isError: true };
      const bn = button === 'left' ? '左键' : button === 'right' ? '右键' : '中键';
      return { content: `已在 (${px.value}, ${py.value}) ${dbl ? '双击' : '单击'}${bn}。` };
    }
  });

  api.registerTool({
    id: 'drag',
    name: '鼠标拖动',
    description: `在机器人所在电脑上按住鼠标左键，从起点坐标平滑拖到终点坐标再松开（用于拖窗口、拖文件、框选等）。${OWNER_ONLY}`,
    category: 'system',
    icon: '✊',
    parameters: {
      type: 'object',
      properties: {
        fromX: { type: 'integer', description: '起点横坐标（物理像素）' },
        fromY: { type: 'integer', description: '起点纵坐标（物理像素）' },
        toX: { type: 'integer', description: '终点横坐标（物理像素）' },
        toY: { type: 'integer', description: '终点纵坐标（物理像素）' }
      },
      required: ['fromX', 'fromY', 'toX', 'toY']
    },
    async execute(ctx, args) {
      const rej = gate(ctx, 'drag');
      if (rej) return { content: rej, isError: true };
      const p = ['fromX', 'fromY', 'toX', 'toY'].map((k) => asInt(args?.[k], 0, 32767));
      if (p.some((v) => !v.ok)) return { content: '坐标必须是数字', isError: true };
      const r = await capDrag(p[0].value, p[1].value, p[2].value, p[3].value);
      if (r.err) return { content: r.err, isError: true };
      return { content: `已从 (${p[0].value}, ${p[1].value}) 拖动到 (${p[2].value}, ${p[3].value})。` };
    }
  });

  api.registerTool({
    id: 'scroll',
    name: '鼠标滚轮',
    description: `在机器人所在电脑上滚动鼠标滚轮。notches 正数=向上滚，负数=向下滚，一格约 3 行内容；direction 填 horizontal 是横向滚动（正数=向右）。${OWNER_ONLY}`,
    category: 'system',
    icon: '🔄',
    parameters: {
      type: 'object',
      properties: {
        notches: { type: 'integer', description: '滚几格；正数向上/向右，负数向下/向左' },
        direction: { type: 'string', enum: ['vertical', 'horizontal'], description: 'vertical=纵向（默认），horizontal=横向' }
      },
      required: ['notches']
    },
    async execute(ctx, args) {
      const rej = gate(ctx, 'scroll');
      if (rej) return { content: rej, isError: true };
      const n = asInt(args?.notches, -20, 20);
      if (!n.ok) return { content: 'notches 必须是数字（-20 ~ 20）', isError: true };
      if (!n.value) return { content: 'notches 是 0，等于没滚', isError: true };
      const dir = args?.direction === 'horizontal' ? 'horizontal' : 'vertical';
      const r = await capScroll(n.value, dir);
      if (r.err) return { content: r.err, isError: true };
      const d = dir === 'horizontal' ? (n.value > 0 ? '向右' : '向左') : (n.value > 0 ? '向上' : '向下');
      return { content: `已${d}滚动 ${Math.abs(n.value)} 格。` };
    }
  });

  log('鼠标操控已加载（触发范围：%s；主人判定：%s）',
    cfg().scope === 'all' ? '私聊+群' : '仅主人私聊',
    String(cfg().ownerIds || '').trim() ? 'ownerIds 配置' : '主人识别能力（未配置则不动作）');
}

export function deactivate() { /* 无长驻资源 */ }
export function dispose() { /* 无长驻资源 */ }

export const internals = { makeOwnerChecker, scopeGate, toolGate, capPosition, capMove, capClick, capDrag, capScroll, asInt, PS_HEAD, BTN };
