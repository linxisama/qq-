// 发言强制走 send_message（force-send）—— 纯提示词型 Skill。
//
// 本 Skill 不需要任何工具或钩子：功能全部在 skill.json 的 prompt.sections 里。
// 留这个入口只是满足加载器的要求（Skill 必须导出 setup/register/hooks/providers/activate）。
//
// 它解决的问题（实测证据）：
//   模型有时返回 finish_reason=stop，把要说的话写在正文 content 里，却不调用
//   send_message。按设计正文不会发到 QQ，而兜底的 reply-safety 插件又没装，
//   于是整轮静默（session 状态 noreply，用户看到"思考完什么都不发"）。
//   这里用最高优先级（95，仅次于核心安全规则）的提示词常量把这条协议钉死。

export function setup(api) {
  api?.log?.('发言强制规则已注入（正文不发送，必须 send_message）');
}
