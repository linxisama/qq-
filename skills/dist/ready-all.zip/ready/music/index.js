// 点歌技能（LLM 型）：搜索并发送音乐分享卡片。
//
// 为什么做成技能而不是改核心：这是上一版（v0.3.0 手工补丁）里直接改
// tools.js / sender.js / onebot.js / app.js 加进去的功能，每次核心升级都会丢。
// 迁到 Skill 体系后，核心升级不再影响它 —— 这也是 Skill 系统存在的意义。
//
// 三个工具：
//   send_music       搜歌 + 发卡片 + 归档
//   get_music_links  查本会话归档过的音乐链接
//   get_lyrics       查歌词
//
// 发送一律走 ctx.sender.sendMedia()：它自带每会话串行、限频、去重、留档四道保护，
// 绕过去直调 onebot.sendSegments 会导致"媒体把文字配额吃光"和"下次运行忘了自己发过"。
//
// ── 卡片发送链路（v1.1.0 重写，修「发送者版本过低」残卡）──────────────────
// 旧版拼好 music 段就发，签名是否成功全凭协议端 -- 协议端签名失败会退一张
// QQ 拒渲染的本地残卡，群里显示「发送者版本过低，无法展示内容」，而机器人侧
// 零报错。新版流程（见 deliverMusic）：
//   搜歌 → 技能自己调签名服务并验证响应（lib/sign.js）→ 成功：发预签名 JSON 段
//   （协议端对 json 段原样透传，不再二次签名）→ 失败：自动降级「封面图+链接」。
// 顺带修复：QQ 搜歌旧接口 HTTP 500 已死，lib/search.js 换 musicu.fcg。

// lib 模块句柄：在 setup() 里动态 import 填充 —— 为什么不用静态 import 见 setup 的注释。
let libSearch = null;   // ./lib/search.js 的导出（searchMusic / getLyrics / fetchNetEaseCover / setFetch）
let libSign = null;     // ./lib/sign.js 的导出（signMusicCard）
let store = null;       // MusicStore 实例（全程文件落盘，无内存状态，重载实例化无损失）

let cfg = () => ({});

// 默认签名服务（2026-09-30 实测可用，详见 candidateMusicPayloads 与 安装说明）。
// 可在技能设置 signService 里替换；支持写多个地址（空格/换行分隔），按顺序容错。
// 星之阁（ss.xingzhige.com）已于 2026-08-04 永久关停，不再作为默认。
const DEFAULT_SIGN_URL = 'http://106.55.0.102:10087/';

function ok(payload) { return { content: JSON.stringify(payload, null, 1) }; }
function err(message) { return { content: String(message), isError: true }; }

/**
 * 卡片全字段：签名服务拿这些字段生成卡片（跳转/音频/歌名/歌手/封面一个都不能少）。
 * ⚠️ 实测（yibai，2026-09-30）：只给 {type,id} 会退化成 tuwen 图片卡 —— 必须
 * 带全 url/audio/title/content/image 才得到音乐卡。content 映射为卡片的歌手行。
 */
function fullMusicFields(song) {
  const name = String(song?.name ?? '').trim() || '音乐';
  const singer = String(song?.singer ?? '').trim();
  return {
    url: String(song?.jumpUrl ?? ''),
    // QQ 音乐拿不到外链（audioUrl 为空串），退回用跳转链接兜底 —— 点开仍能到歌曲页
    audio: String(song?.audioUrl || song?.jumpUrl || ''),
    title: name,
    content: singer || (song?.platform === 'qq' ? 'QQ音乐' : '网易云音乐'),
    image: String(song?.cover ?? '')
  };
}

/**
 * 平台原生类型 payload：{type:'163'} 让签名服务产出网易云官方卡片
 * （appid 100495085、标「网易云音乐」，即用户截图里那种），QQ 音乐原生为 'qq'
 * （appid 100497308）。与旧版 {type:'163', id} 的区别：带上全字段，
 * 只给 id 的裸形态已被服务端关闭或退化为图片卡。
 */
function typedMusicPayload(song) {
  const type = String(song?.platform ?? '') === 'netease' ? '163' : 'qq';
  return { type, ...fullMusicFields(song) };
}

/** 自定义卡片 payload：两个平台通用，卡片标「QQ音乐」（签名服务对 custom 统一用 QQ appid）。 */
function customMusicPayload(song) {
  return { type: 'custom', ...fullMusicFields(song) };
}

/**
 * 按配置与平台列出**候选 payload**（按优先级排序），交给 deliverMusic 逐个试签名。
 *
 * 与旧版 pickMusicSegment 的区别：旧版拼好段就发，签名服务挂了协议端会退残卡
 * （群里显示「发送者版本过低」）；新版每个 payload 都先经 lib/sign.js 自行签名
 * 验证，签名成功才发，失败自动降级，残卡从此发不出去。
 *
 * 封面必须在**构造任何 payload 之前**补齐（2026-09-30 实测修复）：网易云搜索接口
 * 不返回封面，之前补封面写在原生 payload 之后，而原生卡片签名几乎总是一次成功，
 * 队列走不到 custom —— 补回来的封面永远用不上，卡片只剩网易云 App 图标。
 * 实测 yibai 对 163 原生卡会透传 image 到 meta.music.preview，带图即出真封面。
 *
 * cardMode 配置语义（默认 "auto"）：
 *   "auto"   = 网易云：原生 163 全字段（官方网易云卡片）→ 自定义；QQ 音乐：直接自定义
 *              （{type:'qq', id} 裸格式已被签名服务关闭，只试全字段原生没意义）
 *   "custom" = 两个平台都走自定义卡片（网易云的卡片会标成「QQ音乐」—— 签名服务
 *              对 custom 统一用 QQ 音乐的 appid，这是平台事实）
 *   "native" = 两个平台都先试平台原生，失败再退自定义
 */
async function candidateMusicPayloads(song) {
  const mode = String(cfg().cardMode ?? '').trim();
  const isNetease = String(song?.platform ?? '') === 'netease';
  const out = [];
  // 搜索接口没给图就 best-effort 补一次详情请求（网易云；QQ 搜索自带封面直链），
  // 失败返回空串照常签名，由签名服务/QQ 出兜底图。
  if (isNetease && !String(song?.cover ?? '').trim()) {
    song.cover = await libSearch.fetchNetEaseCover(song.id);
  }
  if (mode === 'custom') {
    out.push(customMusicPayload(song));
    return out;
  }
  const native = typedMusicPayload(song);
  if (mode === 'native' || (isNetease && (!mode || mode === 'auto'))) {
    out.push(native);
  }
  out.push(customMusicPayload(song));
  return out;
}

/**
 * 发送一首歌：签名成功 → 预签名 JSON 卡片；全部签名失败 → 封面图 + 链接降级。
 *
 * 为什么不让协议端自己签名：协议端对 music 段的失败处理是"退本地残卡"，
 * QQ 客户端拒渲染，群里显示「发送者版本过低，无法展示内容」，而机器人侧
 * 零报错（2026-09-30 实测确认）。技能先签名再发，等于把"发不发"的决定权
 * 拿回自己手里 —— 验证不过就不发卡片，改发永远能显示的链接。
 *
 * 签名服务可配多个（signService 设置里空格/换行分隔）：按顺序试，谁的验证
 * 先过用谁的；加总耗时超过预算就放弃卡片走降级，避免点歌卡住半分钟。
 *
 * @returns {{ delivered: 'card'|'link', via?: string, reason?: string }}
 */
async function deliverMusic(ctx, song) {
  const payloads = await candidateMusicPayloads(song);
  const services = String(cfg().signService ?? '').trim()
    .split(/[\s,;，；]+/).filter(Boolean);
  if (!services.length) services.push(DEFAULT_SIGN_URL);
  const deadline = Date.now() + 12000;   // 卡片尝试总预算：超时转降级，不拖着会话
  let lastSignError = '';
  outer:
  for (const payload of payloads) {
    for (const service of services) {
      if (Date.now() > deadline) break outer;
      try {
        const ark = await libSign.signMusicCard(payload, service);
        // 预签名 JSON 段：协议端对 json 段只做"是合法 JSON 对象"校验后原样透传，
        // 不会再走自己的签名/回退路径 —— 我们签好的是什么，群里看到的就是什么。
        await ctx.sender.sendMedia(ctx.chatKey, [{ type: 'json', data: { data: JSON.stringify(ark) } }], {
          label: `[音乐:${song.name}]`,
          dedupeKey: `music:${song.platform}:${song.id || song.mid}`
        });
        return { delivered: 'card', via: payload.type };
      } catch (error) {
        lastSignError = String(error?.message ?? error);
      }
    }
  }
  // ── 降级：封面图 + 文字链接（图发不出再退纯文本）─────────────────────────
  // 链接在 QQ 里是可点的；封面图让它至少看起来像"分享了一首歌"。
  // 群里永远不会出现残卡 —— 这比"发出去了但显示版本过低"体验好得多。
  const lines = [`🎵 ${song.name} - ${song.singer}`, String(song.jumpUrl ?? '')].filter(Boolean).join('\n');
  const dedupe = { label: `[音乐:${song.name}]`, dedupeKey: `music:${song.platform}:${song.id || song.mid}` };
  if (String(song.cover ?? '').trim()) {
    try {
      await ctx.sender.sendMedia(ctx.chatKey, [
        { type: 'image', data: { file: song.cover } },
        { type: 'text', data: { text: lines } }
      ], dedupe);
      return { delivered: 'link', reason: lastSignError };
    } catch { /* 图挂了 → 纯文本再试一次 */ }
  }
  await ctx.sender.sendMedia(ctx.chatKey, [{ type: 'text', data: { text: lines } }], dedupe);
  return { delivered: 'link', reason: lastSignError };
}

export async function setup(api) {
  cfg = api.config;
  // ⚠️ 热重载的关键坑（2026-09-30 实测）：加载器只对入口 index.js 做 ?t= 缓存穿透，
  // 静态 import 的 lib/*.js 会命中 Node 的模块 URL 缓存 —— 改 lib 文件不重启进程
  // 就永远拿旧模块，表现为"报缺少导出/改了不生效，沿用旧版本"。这里全部走
  // 动态 import + 时间戳：lib 目录里任何文件的保存都能真正生效。
  const stamp = Date.now();
  [libSearch, libSign] = await Promise.all([
    import(`./lib/search.js?t=${stamp}`),
    import(`./lib/sign.js?t=${stamp}`)
  ]);
  // fetch 受 skill.json 的 "permissions": ["web_fetch"] 门禁
  libSearch.setFetch(api.fetch);
  const { MusicStore } = await import(`./lib/store.js?t=${stamp}`);
  store = new MusicStore();

  api.registerTool({
    id: 'send_music',
    name: '点歌',
    description: '点歌：搜歌并发一张音乐分享卡片到当前会话。keyword 必须来自本次消息里用户说的歌名（可带歌手），剥掉"我想听/来首/放个"这类指令词做最小提炼，不要添加用户没提的内容；不要拿上下文里"之前发过的歌"顶替——用户说"刚才那首"也按歌名重新搜，不重发旧卡片。收到点歌请求立即发卡片再回应对话，先歌后话。用户只说了"我要听歌"而没给歌名时，自己从当前聊天上下文挑一首合适的去搜，不要反过来追问歌名。搜不到就如实说没找到并请用户换个关键词，绝不编造歌名。不被要求就不要主动发；一次最多一首。',
    category: 'media',
    icon: '🎵',
    parameters: {
      type: 'object',
      properties: {
        keyword: { type: 'string', description: '歌名，可带歌手（如"晴天 周杰伦"），用空格分隔' },
        platform: { type: 'string', description: "可选：'netease' 或 'qq' 强制指定平台；不传 = 自动（网易云优先，该歌手曲库不在网易云时自动换 QQ 音乐）" }
      },
      required: ['keyword']
    },
    async execute(ctx, args) {
      try {
        const keyword = String(args.keyword ?? '').trim();
        if (!keyword) return err('搜索关键词为空，请给出歌名');
        const asked = String(args.platform ?? '').trim();
        const configured = String(cfg().defaultPlatform ?? 'auto').trim();
        const platform = asked === 'netease' || asked === 'qq'
          ? asked
          : (configured === 'netease' || configured === 'qq' ? configured : 'auto');
        const limit = Math.max(1, Math.min(10, Number(cfg().maxResults) || 5));

        const result = await libSearch.searchMusic(keyword, { platform, limit });
        if (!result.songs.length) {
          const why = result.errors?.length ? `（${result.errors.join('；')}）` : '';
          return ok({
            found: false,
            note: `没搜到与「${keyword}」匹配的歌${why}。换个关键词再试一次，或请用户确认歌名；不要编造歌曲。`
          });
        }

        const song = result.songs[0];
        // 网易云 VIP 歌：填了 neteaseCookie（控制台「点歌」设置）就先用自己账号的
        // 会员权限换完整音源，再走签名 —— 不依赖本地代理，yibai 兜底路径同样有效。
        // 免费歌不换：公开外链本来就完整。
        let vipFullAudio = false;
        if (result.platform === 'netease' && song.vip) {
          const musicU = String(cfg().neteaseCookie ?? '').trim();
          if (musicU) {
            const full = await libSearch.resolveNetEaseAudio(song.id, musicU);
            if (full) {
              song.audioUrl = full;
              vipFullAudio = true;
            }
          }
        }
        // 发送链路见 deliverMusic：签名成功发预签名 JSON 卡片，失败自动降级封面图+链接。
        // 两种结果都归档、都让模型知道实情，模型才能对群友如实交代。
        const delivery = await deliverMusic(ctx, song);

        // 归档链接：聊天存档里只有 [音乐:歌名] 这行文字，链接是查歌词/再分享的唯一来源
        let archived = false;
        if (cfg().archive !== false && store) {
          archived = !!store.record(ctx.chatKey, song);
        }
        ctx.session?.sent?.push({ type: 'music', text: `[音乐:${song.name}]`, delivered: delivery.delivered });
        ctx.emit?.('session-update', ctx.session?.id);

        // 候选里还有别的版本时提示一句，便于用户说"要另一个版本"时模型知道
        const others = result.songs.slice(1, 4).map((s) => `${s.name} - ${s.singer}`);
        const note = delivery.delivered === 'card'
          ? ['卡片已发出。不要用文字复述歌名/歌手，继续对话或直接结束。']
          : [`音乐卡片签名服务这会儿不可用（${delivery.reason}），已自动改为发「封面图+链接」。回复时按发了链接来说（如"卡片服务故障，先甩个链接"），绝不要声称发出了可点开播放的音乐卡片。`];
        // VIP 歌提示按实际结果如实说：换成功 / Cookie 失效 / 未配置，三种措辞。
        if (song.vip) {
          if (vipFullAudio) {
            note.push('（这首歌是 VIP 歌曲，已用设置的网易云会员账号换成完整音源，卡片可直接完整播放。）');
          } else if (result.platform === 'netease' && String(cfg().neteaseCookie ?? '').trim()) {
            note.push('（这首歌是 VIP 歌曲：设置的网易云会员账号没能取到完整音源（Cookie 可能已失效，或该歌不在会员权益内），卡片里只有 30~60 秒试听。可如实轻描淡写带过。）');
          } else {
            note.push('（这首歌是平台 VIP 歌曲，卡片里的播放链接通常只能试听 30~60 秒，完整收听需要群友自己的 VIP。可如实轻描淡写带过，不要装作能完整播放。）');
          }
        }
        if (result.errors?.length) note.push(`（提示：${result.errors.join('；')}）`);
        if (others.length) note.push(`（同查询下的其他候选：${others.join('；')}）`);
        return ok({
          delivered: delivery.delivered,
          platform: result.platform,
          name: song.name,
          singer: song.singer,
          archived,
          note: note.join('')
        });
      } catch (error) {
        return err(error?.message ?? error);
      }
    }
  });

  api.registerTool({
    id: 'get_music_links',
    name: '查音乐链接',
    description: '查本会话归档过的音乐分享链接（机器人点过的）。群友说"刚才那首""上一首"或要"再发一次"时用它拿到链接；拿到 jumpUrl 后可用 web_fetch 抓歌曲页详情。记录里确实没有就如实说没归档过（可能发在归档功能上线之前），不要编造链接。',
    category: 'media',
    icon: '🔗',
    parameters: {
      type: 'object',
      properties: {
        query: { type: 'string', description: '可选：按歌名/歌手模糊过滤' },
        limit: { type: 'integer', description: '返回条数，默认 5，最多 20' }
      }
    },
    async execute(ctx, args) {
      try {
        if (!store) return err('音乐归档未启用');
        const limit = Math.max(1, Math.min(20, Number(args.limit) || 5));
        const query = String(args.query ?? '').trim();
        // 先看本会话；本会话没命中且带了 query 时跨会话找同名歌（可能是别的群点过的）
        let items = store.recent({ chatKey: ctx.chatKey, query, limit });
        let crossChat = false;
        if (!items.length && query) {
          items = store.recent({ query, limit });
          crossChat = items.length > 0;
        }
        if (!items.length) {
          return ok({
            count: 0,
            musics: [],
            note: query
              ? `本会话和归档里都没有「${query}」的记录（可能是发在归档功能上线之前）。不要编造链接。`
              : '本会话还没有归档过音乐卡片。'
          });
        }
        return ok({
          count: items.length,
          crossChat,
          musics: items.map((e) => ({
            name: e.name,
            singer: e.singer,
            platform: e.platform,
            jumpUrl: e.jumpUrl || '（该条没有链接）',
            time: new Date(e.ts).toLocaleString('zh-CN', { hour12: false })
          })),
          note: crossChat ? '（本会话没有，以下是其他会话归档的同名记录）' : ''
        });
      } catch (error) {
        return err(error?.message ?? error);
      }
    }
  });

  api.registerTool({
    id: 'get_lyrics',
    name: '查歌词',
    description: '查歌词。不传 name 时取本会话最近一条音乐记录；传 name 时先在归档里找，找不到就按名字直接搜。返回的是已去时间轴的纯文本。引用其中一两句就够了，不要整段刷屏。拿不到（纯音乐/版权受限）就如实说，绝不编造歌词。',
    category: 'media',
    icon: '🎼',
    parameters: {
      type: 'object',
      properties: {
        name: { type: 'string', description: '歌名（可选；不传 = 本会话最近一首）' },
        singer: { type: 'string', description: '歌手（可选，提高命中率）' }
      }
    },
    async execute(ctx, args) {
      try {
        const name = String(args.name ?? '').trim();
        const singer = String(args.singer ?? '').trim();
        let target = { name, singer, jumpUrl: '' };
        if (!name) {
          if (!store) return err('音乐归档未启用，直接告诉我歌名我再查');
          const last = store.recent({ chatKey: ctx.chatKey, limit: 1 })[0];
          if (!last) return err('本会话还没有音乐记录，告诉我歌名我再查');
          target = { name: last.name, singer: last.singer, jumpUrl: last.jumpUrl };
        } else if (!singer && store) {
          // 归档里能对上歌名就拿它的 jumpUrl（直接按平台 id 取歌词，最准）
          const hit = store.recent({ chatKey: ctx.chatKey, query: name, limit: 1 })[0]
            || store.recent({ query: name, limit: 1 })[0];
          if (hit) target = { name: hit.name, singer: hit.singer || singer, jumpUrl: hit.jumpUrl };
        }
        const r = await libSearch.getLyrics(target);
        const lyrics = String(r.lyrics ?? '');
        const truncated = lyrics.length > 4000;
        return ok({
          platform: r.platform,
          name: target.name,
          singer: target.singer,
          truncated,
          lyrics: truncated ? lyrics.slice(0, 4000) : lyrics,
          note: '引用一两句就够了，不要整段贴出来。'
        });
      } catch (error) {
        return err(`拿不到歌词：${error?.message ?? error}。如实告诉用户，不要编造歌词。`);
      }
    }
  });
}
