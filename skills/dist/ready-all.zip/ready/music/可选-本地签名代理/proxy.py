"""
音乐签名中间层 v5 —— yibai 中转版

链路：点歌技能 / NapCat / RedReply → 本代理 → yibai 音卡签名（POST JSON）→ 裸 Ark JSON

相对 v4（CZ 版）的变化：
- 上游固定 yibai（http://106.55.0.102:10087/，免费公共服务），去掉 CZ 的
  key/type/desc 参数拼装和 GET+表单双重尝试逻辑——yibai 只收 POST JSON。
- 响应统一解成「裸 Ark JSON」再返回，兼容三种形态：
    1) 裸 Ark 对象
    2) 双重编码：HTTP body 是 JSON 字符串，里面再装一份 Ark 文本（yibai 实测形态）
    3) {code:200, data:{...Ark}} 包装（聚合站常见，留作日后换上游的余量）
- image（封面）不再列为必填：封面缺失照常签名，由上游/QQ 决定兜底图。
- type 透传（163/qq/custom），保留网易云官方卡片能力；其余值一律按 custom 处理。
- DEBUG_RAW 默认关闭（排查协议问题时设 MUSIC_PROXY_DEBUG=1 打开全量日志）。
- 同 payload 签名结果内存缓存 10 分钟（LRU，上限 200 条），削上游偶发抖动。
- RedReply GET 协议分支原样保留。

网易云 VIP 音源升级（可选）：
- 配置自己的网易云账号后（MUSIC_U cookie），卡片里网易云歌曲的音频地址会先升级
  成该账号有权播放的完整音源——VIP 歌不再只有 30~60 秒试听。这是用账号自己的
  会员权限调网易云官方播放接口，无权限/cookie 失效时自动保留原外链，不影响出卡。
- 配置方式（二选一，推荐文件，改完即生效不用重启）：
    1. 本目录下新建 netease.cookie.txt，内容只写 MUSIC_U 的值
    2. 环境变量 NETEASE_MUSIC_U
- 获取 MUSIC_U：浏览器登录 music.163.com → F12 → 应用/Application →
  Cookie → https://music.163.com → 复制名为 MUSIC_U 的值（一长串十六进制）。
"""

from __future__ import annotations

import json
import os
import re
import threading
import time
from collections import OrderedDict
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Any
from urllib.error import HTTPError, URLError
from urllib.parse import parse_qs, urlencode, urlparse
from urllib.request import Request, urlopen


VERSION = "2026-09-30-music-sign-proxy-v5-yibai-relay"

HOST = os.environ.get("MUSIC_PROXY_HOST", "127.0.0.1")
PORT = int(os.environ.get("MUSIC_PROXY_PORT", "4567"))

UPSTREAM_URL = os.environ.get("SIGN_UPSTREAM_URL", "http://106.55.0.102:10087/")
UPSTREAM_TIMEOUT = float(os.environ.get("SIGN_UPSTREAM_TIMEOUT", "5"))
UPSTREAM_RETRIES = int(os.environ.get("SIGN_UPSTREAM_RETRIES", "1"))

CACHE_TTL = float(os.environ.get("SIGN_CACHE_TTL", "600"))
CACHE_MAX = int(os.environ.get("SIGN_CACHE_MAX", "200"))

# ── 网易云 VIP 音源升级 ──
NETEASE_COOKIE_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "netease.cookie.txt")
NETEASE_MUSIC_U = os.environ.get("NETEASE_MUSIC_U", "")
NETEASE_SONG_ID_RE = re.compile(r"[?&]id=(\d+)")

SIGN_PATHS = {"/", "/music_card/card", "/api/music/sign", "/sign"}
HEALTH_PATHS = {"/health", "/healthz"}

# 开启后记录完整原始请求，排查不同 OneBot 实现。默认关。
DEBUG_RAW = os.environ.get("MUSIC_PROXY_DEBUG", "0").lower() not in {"0", "false", "off", "no"}

ARK_APP_RE = re.compile(r"^com\.tencent\.music")
KNOWN_MUSIC_TYPES = {"163", "qq", "custom"}

_cache_lock = threading.Lock()
_cache: "OrderedDict[str, tuple[Any, float]]" = OrderedDict()
_cache_hits = 0


def log(message: str) -> None:
	now = time.strftime("%Y-%m-%d %H:%M:%S")
	print(f"[{now}] {message}", flush=True)


def scalar(value: Any, default: str = "") -> str:
	if value is None:
		return default
	if isinstance(value, list):
		return scalar(value[0] if value else "", default)
	if isinstance(value, (dict, tuple)):
		return default
	return str(value).strip()


def flatten_query(data: dict[str, list[str]]) -> dict[str, str]:
	return {key: scalar(value) for key, value in data.items()}


def read_chunked_body(handler: BaseHTTPRequestHandler) -> bytes:
	"""
	手动读取 HTTP/1.1 chunked request body。
	BaseHTTPRequestHandler 不会自动帮我们解 chunked。
	"""
	chunks: list[bytes] = []

	while True:
		line = handler.rfile.readline()
		if not line:
			raise ValueError("chunked 请求体提前结束")

		size_line = line.strip().split(b";", 1)[0]
		if not size_line:
			continue

		try:
			size = int(size_line, 16)
		except ValueError as error:
			raise ValueError(f"非法 chunk size: {size_line!r}") from error

		if size == 0:
			# 消费 trailer headers，直到空行。
			while True:
				trailer = handler.rfile.readline()
				if trailer in (b"\r\n", b"\n", b""):
					break
			break

		chunk = handler.rfile.read(size)
		if len(chunk) != size:
			raise ValueError(f"chunk 数据不完整: 期望 {size}，实际 {len(chunk)}")

		chunks.append(chunk)

		# 每个 chunk 后面必须有 CRLF。
		crlf = handler.rfile.read(2)
		if crlf not in (b"\r\n", b"\n"):
			raise ValueError(f"chunk 结束符异常: {crlf!r}")

	return b"".join(chunks)


def read_request_body(handler: BaseHTTPRequestHandler) -> bytes:
	transfer_encoding = (handler.headers.get("Transfer-Encoding") or "").lower()

	if "chunked" in transfer_encoding:
		return read_chunked_body(handler)

	content_length = handler.headers.get("Content-Length")
	if content_length:
		try:
			length = int(content_length)
		except ValueError as error:
			raise ValueError(f"非法 Content-Length: {content_length!r}") from error

		if length > 0:
			return handler.rfile.read(length)

	return b""


def recursively_collect(obj: Any, out: dict[str, Any], depth: int = 0) -> None:
	"""
	兼容这些形式：
	{url,audio,...}
	{"data": {url,audio,...}}
	{"params": {...}}
	{"message": [{"type":"music","data": {...}}]}
	某字段本身又是 JSON 字符串。
	"""
	if depth > 8:
		return

	if isinstance(obj, dict):
		# 优先保留第一次找到的有效值。
		for key, value in obj.items():
			if key in {"type", "url", "audio", "title", "singer", "content", "desc",
					   "image", "song", "jump", "cover", "format"}:
				if key not in out or not scalar(out.get(key)):
					out[key] = value

		for value in obj.values():
			recursively_collect(value, out, depth + 1)
		return

	if isinstance(obj, list):
		for value in obj:
			recursively_collect(value, out, depth + 1)
		return

	if isinstance(obj, str):
		value = obj.strip()
		if len(value) >= 2 and value[0] in "[{" and value[-1] in "]}":
			try:
				recursively_collect(json.loads(value), out, depth + 1)
			except json.JSONDecodeError:
				pass


def parse_body_bytes(raw: bytes, content_type: str) -> dict[str, Any]:
	if not raw:
		return {}

	decoded = raw.decode("utf-8-sig", errors="replace").strip()
	if not decoded:
		return {}

	# JSON，无论 Content-Type 是否存在。
	if "application/json" in content_type or decoded.startswith("{") or decoded.startswith("["):
		try:
			obj = json.loads(decoded)
			result: dict[str, Any] = {}
			recursively_collect(obj, result)
			return result
		except json.JSONDecodeError:
			# 后续继续尝试 form。
			pass

	# x-www-form-urlencoded。
	form = flatten_query(parse_qs(decoded, keep_blank_values=True))

	# 如果整个 JSON 被塞进某一个 form 字段，再递归拆。
	result: dict[str, Any] = dict(form)
	for value in list(form.values()):
		recursively_collect(value, result)

	return result


def parse_request_data(handler: BaseHTTPRequestHandler) -> tuple[dict[str, Any], bytes]:
	parsed = urlparse(handler.path)

	# Query
	data: dict[str, Any] = flatten_query(
		parse_qs(parsed.query, keep_blank_values=True)
	)

	raw = b""

	if handler.command in {"POST", "PUT", "PATCH"}:
		raw = read_request_body(handler)
		content_type = (handler.headers.get("Content-Type") or "").lower()
		body_data = parse_body_bytes(raw, content_type)

		# body 优先于 query。
		data.update(body_data)

	# 最后再递归一次，兼容 query 中嵌套 JSON。
	normalized: dict[str, Any] = {}
	recursively_collect(data, normalized)

	# 如果递归没有找到，保留原字段。
	for key, value in data.items():
		normalized.setdefault(key, value)

	return normalized, raw


def translate_to_yibai(source: dict[str, Any]) -> tuple[str, dict[str, str]]:
	"""
	同时兼容两种客户端协议，统一转成 yibai 的字段：

	yibai: type(163/qq/custom) / url=跳转 / audio=音频直链 / title=歌名
	       / content=歌手行 / image=封面

	1. NapCat / 点歌技能 custom music:
	   url=跳转地址, audio=音乐直链, title=歌名,
	   singer/content=歌手, image=封面, type=163/qq/custom
	2. RedReply onebot11.rs deal_music_segment():
	   url=音乐直链, song=歌名, singer=歌手, cover=封面,
	   jump=跳转地址, format=平台
	"""
	is_redreply = any(
		scalar(source.get(key))
		for key in ("song", "cover", "jump")
	)

	if is_redreply:
		# RedReply 的 url 实际是音频地址，jump 才是跳转地址。
		audio = scalar(source.get("audio") or source.get("url"))
		jump_url = scalar(source.get("jump") or source.get("url"))
		title = scalar(source.get("song") or source.get("title"))
		content = scalar(
			source.get("singer")
			or source.get("content")
			or source.get("desc")
		)
		image = scalar(source.get("cover") or source.get("image"))
		protocol = "RedReply"
	else:
		jump_url = scalar(source.get("url") or source.get("jump"))
		audio = scalar(source.get("audio"))
		title = scalar(source.get("title") or source.get("song"))
		content = scalar(
			source.get("singer")
			or source.get("content")
			or source.get("desc")
		)
		image = scalar(source.get("image") or source.get("cover"))
		protocol = "NapCat"

	missing = [
		name
		for name, value in (
			("url/jump", jump_url),
			("audio", audio),
			("title/song", title),
		)
		if not value
	]

	if missing:
		raise ValueError(
			f"{protocol} 请求缺少参数: "
			+ ", ".join(missing)
			+ "；收到字段="
			+ ",".join(sorted(source.keys()))
		)

	music_type = scalar(source.get("type")).lower()
	if music_type not in KNOWN_MUSIC_TYPES:
		music_type = "custom"

	log(
		f"识别协议={protocol} | "
		f"原format={scalar(source.get('format')) or '-'} | "
		f"type={music_type} | "
		f"image={'有' if image else '无'}"
	)

	return protocol, {
		"type": music_type,
		"url": jump_url,
		"audio": audio,
		"title": title,
		"content": content,
		"image": image,
	}


def looks_like_music_ark(obj: Any) -> bool:
	if not isinstance(obj, dict):
		return False
	if "app" not in obj:
		return False
	if not ("prompt" in obj or "meta" in obj):
		return False
	app = str(obj.get("app") or "")
	if ARK_APP_RE.match(app):
		return True
	if app == "com.tencent.structmsg" and str(obj.get("view", "")).lower() == "music":
		return True
	return False


def parse_deep(text: str) -> Any:
	"""把响应文本一路解析到对象（最多 3 层 JSON 字符串），失败返回 None。"""
	cur = str(text or "").strip()
	if not cur:
		return None
	for _ in range(3):
		try:
			cur = json.loads(cur)
		except (json.JSONDecodeError, ValueError):
			return cur if isinstance(cur, dict) else None
		if not isinstance(cur, str):
			return cur
	return None


def extract_ark(body_text: str) -> dict[str, Any]:
	"""从上游响应提取裸 Ark；错误形态转成带原因的异常。"""
	parsed = parse_deep(body_text)

	if looks_like_music_ark(parsed):
		return parsed

	if isinstance(parsed, dict):
		if looks_like_music_ark(parsed.get("data")):
			return parsed["data"]
		if parsed.get("ok") is False or "error" in parsed:
			raise RuntimeError(
				f"上游返回错误: {str(parsed.get('error') or parsed)[:200]}"
			)
		raise RuntimeError(
			f"上游返回的不是可用音乐卡片 (app={parsed.get('app', '?')})"
		)

	raise RuntimeError(f"上游返回无法解析: {str(body_text)[:120] or '空响应'}")


def cache_get(key: str) -> Any | None:
	global _cache_hits
	now = time.time()
	with _cache_lock:
		item = _cache.get(key)
		if item is None:
			return None
		value, ts = item
		if now - ts > CACHE_TTL:
			_cache.pop(key, None)
			return None
		_cache.move_to_end(key)
		_cache_hits += 1
		return value


def cache_put(key: str, value: Any) -> None:
	with _cache_lock:
		_cache[key] = (value, time.time())
		_cache.move_to_end(key)
		while len(_cache) > CACHE_MAX:
			_cache.popitem(last=False)


_cookie_state = {"mtime": None, "music_u": ""}


def load_netease_cookie() -> str:
    """
    读网易云账号凭证（MUSIC_U）。环境变量优先；否则读 netease.cookie.txt，
    按文件 mtime 热加载——改文件立即生效，不用重启代理。
    """
    if NETEASE_MUSIC_U:
        return NETEASE_MUSIC_U.strip()
    try:
        mtime = os.path.getmtime(NETEASE_COOKIE_PATH)
    except OSError:
        if _cookie_state["mtime"] is not None:
            _cookie_state.update(mtime=None, music_u="")
        return ""
    if _cookie_state["mtime"] != mtime:
        try:
            with open(NETEASE_COOKIE_PATH, "r", encoding="utf-8-sig") as f:
                text = f.read().strip()
        except OSError:
            return ""
        # 允许把 "MUSIC_U=xxxx" 整行粘进来
        if text.upper().startswith("MUSIC_U="):
            text = text[len("MUSIC_U="):].strip()
        _cookie_state.update(mtime=mtime, music_u=text)
        log(f"网易云账号已加载（MUSIC_U 长度={len(text)}）")
    return _cookie_state["music_u"]


def netease_song_id(audio_url: str) -> str:
    """从网易云链接（外链 outer/url 或歌曲页 /song?id=）提取歌曲 id。"""
    if "music.163.com" not in audio_url:
        return ""
    match = NETEASE_SONG_ID_RE.search(audio_url)
    return match.group(1) if match else ""


def upgrade_netease_audio(payload: dict[str, str]) -> bool:
    """
    把卡片里网易云歌曲的音频地址升级成账号可播的完整音源（VIP 歌不再试听）。

    用账号自己的权限调网易云官方播放接口 /api/song/enhance/player/url；
    失败（未配置/cookie 失效/无权限/仍为试听）一律返回 False 并保留原链接，
    绝不因升级失败而阻塞签名。
    """
    music_u = load_netease_cookie()
    if not music_u:
        return False

    song_id = netease_song_id(payload["audio"])
    if not song_id:
        return False

    cache_key = f"netease-audio:{song_id}"
    cached = cache_get(cache_key)
    if isinstance(cached, str) and cached:
        payload["audio"] = cached
        return True

    api = "https://music.163.com/api/song/enhance/player/url"
    request_url = api + "?" + urlencode({"ids": f"[{song_id}]", "br": "320000"})
    headers = {
        "Cookie": f"MUSIC_U={music_u}",
        "Referer": "https://music.163.com",
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0 Safari/537.36",
    }

    try:
        with urlopen(Request(request_url, headers=headers, method="GET"), timeout=UPSTREAM_TIMEOUT) as response:
            data = json.loads(response.read().decode("utf-8", errors="replace"))
    except (HTTPError, URLError, OSError, ValueError) as error:
        log(f"网易云音源升级失败（保留原链接）: {error}")
        return False

    if data.get("code") != 200:
        log(f"网易云音源升级失败（保留原链接）: code={data.get('code')}（MUSIC_U 可能已失效）")
        return False

    items = data.get("data")
    item = items[0] if isinstance(items, list) and items else {}
    url = str(item.get("url") or "")
    if not url:
        log("网易云音源升级失败（保留原链接）: 账号无该歌曲播放权限（url 为空）")
        return False
    if item.get("freeTrialInfo"):
        log("网易云音源升级失败（保留原链接）: 账号对该歌不享 VIP 权益，返回的仍是试听")
        return False

    if url.startswith("http://"):
        url = "https://" + url[len("http://"):]
    payload["audio"] = url
    cache_put(cache_key, url)
    log(f"网易云音源升级成功 | id={song_id} | br={item.get('br')} | type={item.get('type')}")
    return True


def call_upstream(payload: dict[str, str]) -> dict[str, Any]:
	"""POST JSON 调 yibai，带瞬时故障重试，返回验证过的裸 Ark。"""
	body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
	headers = {
		"Content-Type": "application/json; charset=utf-8",
		"Accept": "application/json",
		"User-Agent": "MusicSignProxy/5.0",
	}

	errors: list[str] = []

	for attempt in range(UPSTREAM_RETRIES + 1):
		if attempt > 0:
			time.sleep(0.6)
		try:
			with urlopen(
				Request(UPSTREAM_URL, data=body, headers=headers, method="POST"),
				timeout=UPSTREAM_TIMEOUT,
			) as response:
				text = response.read().decode("utf-8-sig", errors="replace").strip()

			if not text:
				errors.append("空响应（服务可能已失效）")
				continue

			return extract_ark(text)

		except HTTPError as error:
			detail = error.read().decode("utf-8", errors="replace")[:200]
			errors.append(f"HTTP {error.code}: {detail}")
		except (URLError, OSError, RuntimeError, ValueError) as error:
			errors.append(str(error))

	raise RuntimeError("；".join(errors) or "上游调用失败")


class MusicSignHandler(BaseHTTPRequestHandler):
	server_version = "MusicSignProxy/5.0"
	protocol_version = "HTTP/1.1"

	def log_message(self, fmt: str, *args: Any) -> None:
		log(f"{self.client_address[0]} {fmt % args}")

	def send_json(self, status: int, payload: Any) -> None:
		body = json.dumps(
			payload,
			ensure_ascii=False,
			separators=(",", ":"),
		).encode("utf-8")

		self.send_response(status)
		self.send_header("Content-Type", "application/json; charset=utf-8")
		self.send_header("Content-Length", str(len(body)))
		self.send_header("Cache-Control", "no-store")
		self.send_header("Connection", "close")
		self.end_headers()
		self.wfile.write(body)
		self.close_connection = True

	def do_GET(self) -> None:
		path = urlparse(self.path).path.rstrip("/") or "/"

		if path in HEALTH_PATHS:
			with _cache_lock:
				hits = _cache_hits
				size = len(_cache)
			self.send_json(
				200,
				{
					"ok": True,
					"version": VERSION,
					"service": "music-sign-proxy",
					"upstream": UPSTREAM_URL,
					"netease_account": "已配置" if load_netease_cookie() else "未配置",
					"cache_entries": size,
					"cache_hits": hits,
				},
			)
			return

		self.handle_sign(path)

	def do_POST(self) -> None:
		path = urlparse(self.path).path.rstrip("/") or "/"
		self.handle_sign(path)

	def handle_sign(self, path: str) -> None:
		if path not in SIGN_PATHS:
			self.send_json(404, {"ok": False, "error": "not found"})
			return

		redreply_mode = False

		try:
			source, raw = parse_request_data(self)
			redreply_mode = is_redreply_request(source)

			if DEBUG_RAW:
				log(
					"RAW "
					f"method={self.command} "
					f"path={self.path!r} "
					f"content-type={self.headers.get('Content-Type')!r} "
					f"content-length={self.headers.get('Content-Length')!r} "
					f"transfer-encoding={self.headers.get('Transfer-Encoding')!r}"
				)
				log(
					"RAW BODY="
					+ raw.decode("utf-8", errors="replace")[:3000]
				)
				log(
					"PARSED="
					+ json.dumps(
						source,
						ensure_ascii=False,
						separators=(",", ":"),
					)[:3000]
				)

			protocol, payload = translate_to_yibai(source)

			# 网易云 VIP 音源升级（配置了账号才生效；失败不影响签名）。
			upgraded = upgrade_netease_audio(payload)

			cache_key = json.dumps(payload, sort_keys=True, ensure_ascii=False)

			started = time.time()
			cached = cache_get(cache_key)
			if cached is not None:
				ark = cached
				log(
					f"签名 缓存命中 | title={payload['title']!r} | "
					f"耗时={time.time() - started:.3f}s"
				)
			else:
				ark = call_upstream(payload)
				cache_put(cache_key, ark)
				log(
					f"签名 上游成功 | title={payload['title']!r} | "
					f"音源升级={'是' if upgraded else '否'} | "
					f"app={ark.get('app')} | 耗时={time.time() - started:.3f}s"
				)

			if redreply_mode:
				wrapped = wrap_redreply_success(ark)
				log(
					"返回模式=RedReply "
					"| code=1 "
					f"| message_bytes={len(wrapped['message'].encode('utf-8'))}"
				)
				self.send_json(200, wrapped)
			else:
				# NapCat / 点歌技能：直接返回裸 Ark JSON。
				self.send_json(200, ark)

		except ValueError as error:
			log(f"请求参数错误: {error}")
			if redreply_mode:
				self.send_json(200, wrap_redreply_error(str(error)))
			else:
				self.send_json(400, {"ok": False, "error": str(error)})
		except Exception as error:
			log(f"签名失败: {error}")
			if redreply_mode:
				self.send_json(200, wrap_redreply_error(str(error)))
			else:
				self.send_json(502, {"ok": False, "error": str(error)})


def is_redreply_request(source: dict[str, Any]) -> bool:
	"""RedReply 固定 GET 协议：url/song/singer/cover/jump/format=bilibili。"""
	return any(
		scalar(source.get(key))
		for key in ("song", "cover", "jump")
	)


def wrap_redreply_success(payload: dict[str, Any]) -> dict[str, str]:
	"""
	RedReply onebot11.rs 要求：
	- code 读取后必须等于 "1"
	- message 必须是字符串，不是对象
	"""
	return {
		"code": "1",
		"message": json.dumps(
			payload,
			ensure_ascii=False,
			separators=(",", ":"),
		),
	}


def wrap_redreply_error(message: str) -> dict[str, str]:
	return {
		"code": "0",
		"message": str(message),
	}


def main() -> None:
	server = ThreadingHTTPServer((HOST, PORT), MusicSignHandler)

	log(
		f"{VERSION} 已启动: "
		f"http://{HOST}:{PORT}/music_card/card"
	)
	log(f"上游: {UPSTREAM_URL} | 缓存TTL={CACHE_TTL:.0f}s | 调试={'开' if DEBUG_RAW else '关'}")
	log(
		"网易云账号: "
		+ ("已配置（VIP 音源升级开启）" if load_netease_cookie() else "未配置（VIP 歌只能试听；配置方法见文件头注释）")
	)

	try:
		server.serve_forever()
	except KeyboardInterrupt:
		pass
	finally:
		server.server_close()


if __name__ == "__main__":
	main()
