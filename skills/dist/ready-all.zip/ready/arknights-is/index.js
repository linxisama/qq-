// 明日方舟集成战略大师（LLM 型技能 · skills/arknights-is/）
//
// 目标：让机器人长期记住明日方舟集成战略（肉鸽）的打法 —— 开局、运营、鬼图、
// 分队、结局 —— 并且这些知识会随群聊和主人的纠正而更新。
//
// 为什么是技能（skills/）而不是插件（plugins/）：
//   要不要接话、这句话算不算"新打法"、该不该质疑群友，都必须由模型判断，
//   没有固定的触发条件。插件是"满足条件必然执行"，做不了这种判断。
//
// ── 知识存哪 ────────────────────────────────────────────────────────────
//   data/arknights-is/knowledge.json
//   · 放数据目录而不是技能目录：App 升级/重装会覆盖 resources/app/skills/，
//     知识库放那儿会被清掉；data/ 是用户数据，升级不动。
//   · seed.json 是出厂骨架，只在第一次运行时复制一份，之后改的都是副本。
//
// ── 可信度分级（辩论与"主人的话是权威"的落点）──────────────────────────
//   source=seed      内置骨架        credibility=normal/unverified
//   source=member    群友说的        credibility=unverified（默认）
//   source=owner     主人说的        credibility=authoritative
//   提示词里要求：群友的说法可以辩，主人的结论直接采纳并覆盖旧内容。
//
// ⚠️ 本技能只读写自己的知识库文件，不发消息、不调模型、不碰 QQ 接口。
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { getConfig, DATA_DIR } from '../../src/config.js';
import { setSkillConfig } from '../../src/skills/config.js';

const SKILL_DIR = path.dirname(fileURLToPath(import.meta.url));
const SEED_FILE = path.join(SKILL_DIR, 'seed.json');
const KB_DIR = path.join(DATA_DIR, 'arknights-is');
const KB_FILE = path.join(KB_DIR, 'knowledge.json');

const QQ_RE = /^\d{5,15}$/;
const MAX_ENTRIES = 5000;          // 知识库总条数上限，防失控
const MAX_CONTENT = 8000;          // 单条内容上限（字符）
const MAX_IMPORT = 60000;          // 单次导入上限（字符）
const MAX_IMPORT_SECTIONS = 60;     // 单次导入最多拆成多少条

/** 主题表：id / 正式名 / 别名（用于口语匹配）。与 seed.json 保持一致。 */
export const THEMES = [
  { id: 'is1', name: '刻俄柏的灰蕈迷境', aliases: ['灰蕈迷境', '刻俄柏', 'IS1'] },
  { id: 'is2', name: '傀影与猩红孤钻', aliases: ['猩红孤钻', '傀影', 'IS2'] },
  { id: 'is3', name: '水月与深蓝之树', aliases: ['深蓝之树', '水月', 'IS3'] },
  { id: 'is4', name: '探索者的银凇止境', aliases: ['银凇止境', '萨米', 'IS4'] },
  { id: 'is5', name: '萨卡兹的无终奇语', aliases: ['无终奇语', '萨卡兹', 'IS5'] },
  { id: 'is6', name: '岁的界园志异', aliases: ['界园', '岁', 'IS6'] },
  { id: 'is7', name: '沉沦者的黑流树海', aliases: ['黑流树海', '沉沦者', 'IS7'] }
];

const KINDS = new Set(['theme', 'squad', 'start', 'route', 'ghost', 'ending', 'pick', 'note', 'doc']);

let cfg = () => ({});
let log = () => {};
let warn = () => {};
let cache = null;                  // { mtimeMs, size, data }

// ── 小工具 ──────────────────────────────────────────────────────────────

const nowIso = () => new Date().toISOString();
const clamp = (n, lo, hi) => Math.min(hi, Math.max(lo, n));

/** 归一化：去掉空白/标点/大小写差异，便于"萨米 开局"这类口语匹配。 */
function norm(s) {
  return String(s ?? '')
    .toLowerCase()
    .replace(/[\s\-_·.。，,、:：;；!！?？()（）【】\[\]"'“”‘’/\\|]/g, '');
}

function splitTerms(query) {
  const raw = String(query ?? '').trim();
  if (!raw) return [];
  const parts = raw.split(/[\s,，、;；/]+/).filter(Boolean);
  const out = parts.map((p) => p.toLowerCase());
  if (parts.length > 1) out.push(raw.toLowerCase());
  return [...new Set(out)];
}

/** 把口语里的主题名/编号解析成 {id, name}；认不出就走"通用"。 */
export function resolveTheme(value) {
  const s = norm(value);
  if (!s) return { id: 'general', name: '通用' };
  const direct = THEMES.find((t) => norm(t.id) === s || norm(t.name) === s
    || (t.aliases || []).some((a) => norm(a) === s));
  if (direct) return { id: direct.id, name: direct.name };
  const fuzzy = THEMES.find((t) => norm(t.name).includes(s) || s.includes(norm(t.name))
    || (t.aliases || []).some((a) => norm(a).includes(s) || s.includes(norm(a))));
  return fuzzy ? { id: fuzzy.id, name: fuzzy.name } : { id: 'general', name: '通用' };
}

// ── 知识库读写 ──────────────────────────────────────────────────────────

function ensureDir() {
  try { fs.mkdirSync(KB_DIR, { recursive: true }); } catch { /* 下面写文件时会再报 */ }
}

function readSeed() {
  try {
    const raw = JSON.parse(fs.readFileSync(SEED_FILE, 'utf8'));
    if (raw && Array.isArray(raw.entries)) return raw;
  } catch (error) {
    warn('seed.json 读取失败：', error?.message ?? error);
  }
  return { version: 1, entries: [] };
}

function writeRaw(data) {
  ensureDir();
  const tmp = `${KB_FILE}.tmp`;
  fs.writeFileSync(tmp, JSON.stringify(data, null, 2), 'utf8');
  fs.renameSync(tmp, KB_FILE);   // Windows 上也是覆盖式重命名
  cache = null;
}

/** 出厂条目清洗：去掉外链、来源统一写“本地”——这个项目只用本地数据。 */
function sanitizeSeedEntry(raw) {
  const { ref, ...rest } = raw || {};
  return { ...rest, author: '本地' };
}

/** 首次运行时把 seed.json 复制成可编辑的 knowledge.json。 */
function ensureKb() {
  ensureDir();
  const seed = readSeed();
  const seedEntries = (seed.entries || []).map(sanitizeSeedEntry);
  const seedVersion = Number(seed.version) || 1;

  if (!fs.existsSync(KB_FILE)) {
    const data = {
      version: seedVersion,
      seedVersion,
      installedAt: nowIso(),
      updatedAt: nowIso(),
      entries: seedEntries
    };
    writeRaw(data);
    log(`知识库已初始化：${data.entries.length} 条（${KB_FILE}）`);
    return;
  }

  // 出厂数据升级：seed 版本变高时，只替换 source=seed 的条目，
  // 保留 AI / 主人后来补充的内容 —— 升级不能把聊天里学到的打法冲掉。
  try {
    const cur = JSON.parse(fs.readFileSync(KB_FILE, 'utf8'));
    const curVer = Number(cur.seedVersion || cur.version || 0);
    const entries = Array.isArray(cur.entries) ? cur.entries : [];
    if (seedVersion > curVer) {
      const kept = entries.filter((e) => e && e.source !== 'seed');
      const data = {
        ...cur,
        version: seedVersion,
        seedVersion,
        updatedAt: nowIso(),
        entries: [...seedEntries, ...kept]
      };
      writeRaw(data);
      log(`知识库已升级到 seed v${seedVersion}：${seedEntries.length} 条内置 + ${kept.length} 条自建`);
    }
  } catch (error) {
    warn('知识库升级检查失败：', error?.message ?? error);
  }
}

function readKb() {
  ensureKb();
  try {
    const st = fs.statSync(KB_FILE);
    if (cache && cache.mtimeMs === st.mtimeMs && cache.size === st.size) return cache.data;
    const data = JSON.parse(fs.readFileSync(KB_FILE, 'utf8'));
    if (!Array.isArray(data.entries)) data.entries = [];
    cache = { mtimeMs: st.mtimeMs, size: st.size, data };
    return data;
  } catch (error) {
    warn('知识库读取失败：', error?.message ?? error);
    return { version: 1, entries: [] };
  }
}

function saveKb(data) {
  data.updatedAt = nowIso();
  if (data.entries.length > MAX_ENTRIES) data.entries = data.entries.slice(-MAX_ENTRIES);
  writeRaw(data);
}

// ── 主人识别（只按 QQ 号，和 owner-identity 同一口径）────────────────────

export function ownerIds() {
  const conf = cfg() || {};
  const direct = String(conf.ownerQq ?? '').trim();
  if (QQ_RE.test(direct)) return [direct];
  try {
    const c = getConfig() || {};
    const raw = [
      c.skills?.['owner-console']?.ownerQq,
      c.skills?.['owner-identity']?.ids
    ];
    const ids = raw
      .flatMap((v) => (Array.isArray(v) ? v : String(v ?? '').split(/[,，;；\s]+/)))
      .map((x) => String(x).trim())
      .filter((x) => QQ_RE.test(x));
    return [...new Set(ids)];
  } catch {
    return [];
  }
}

/** 当前这批消息里最后一个说话的人（工具调用时"刚说话的人"）。 */
function currentSpeaker(ctx) {
  try {
    const recent = ctx?.store?.recent?.(ctx.chatKey, { limit: 8, includeSelf: false }) || [];
    for (let i = recent.length - 1; i >= 0; i--) {
      const m = recent[i];
      if (m && !m.self && m.senderId) {
        return { id: String(m.senderId), name: String(m.senderName || '') };
      }
    }
  } catch { /* 拿不到就退回私聊推断 */ }
  if (ctx?.kind === 'private' && ctx?.chatId) {
    return { id: String(ctx.chatId), name: '' };
  }
  return { id: '', name: '' };
}

// ── 档位 / 常驻群 / 黑话 ────────────────────────────────────────────────

/** 当前档位：听话 / 正常 / 叛逆（默认正常）。 */
function stance() {
  const v = String(cfg()?.stance || '正常').trim();
  return ['听话', '正常', '叛逆'].includes(v) ? v : '正常';
}

/** 常驻群号列表：填了群号就一直按“常驻群”处理。 */
function alwaysOnGroups() {
  return String(cfg()?.alwaysOnGroups || '')
    .split(/[,，;；\s]+/)
    .map((s) => s.trim())
    .filter((s) => /^\d{5,15}$/.test(s));
}

/** 当前会话是不是常驻群。 */
function isAlwaysOnChat(ctx) {
  const list = alwaysOnGroups();
  if (!list.length) return false;
  const m = /^(?:group|private):(\d+)$/.exec(String(ctx?.chatKey || ''));
  if (m) return list.includes(m[1]);
  return ctx?.kind === 'group' && list.includes(String(ctx?.chatId || ''));
}

/** 称谓表：一行一条「称谓=正式名」。 */
function aliasPairs() {
  return String(cfg()?.aliases || '')
    .split(/[\n;；]+/)
    .map((s) => s.trim())
    .filter(Boolean)
    .map((line) => {
      const parts = line.split(/[=＝→:：]/).map((s) => s.trim());
      return parts[0] && parts[1] ? { alias: parts[0], canonical: parts[1] } : null;
    })
    .filter(Boolean);
}

/** 把查询里的黑话展开成正式名，检索时一并命中。 */
function expandQuery(query) {
  const q = String(query || '');
  const hits = aliasPairs().filter((p) => q.includes(p.alias)).map((p) => p.canonical);
  return hits.length ? `${q} ${hits.join(' ')}` : q;
}

/** 档位对应的行为规则，每轮注入提示词。 */
function stanceSection() {
  const s = stance();
  const text = {
    听话: '当前档位：听话。群友提供的集成战略信息，只要不和知识库冲突就直接采纳并记下；有冲突的，在聊天里问一句确认后再采纳，别抬杠。',
    正常: '当前档位：正常。群友提供的新内容照收并记下；知识库里已有的条目只做补充，不推翻、不改写。遇到不同说法先并列放着，不辩论。',
    叛逆: '当前档位：叛逆。默认怀疑群友的观点：先追问依据、拿知识库对照，再想办法说服对方改变看法；可以嘴欠，但别吵架、别刷屏。'
  }[s];
  return { id: 'arknights-is-stance', title: '集成战略·档位', priority: 61, content: `${text}主人的话永远例外，直接采纳。` };
}

// ── 检索 ────────────────────────────────────────────────────────────────

function scoreEntry(e, terms, themeId) {
  let score = 0;
  if (themeId) {
    if (e.theme !== themeId) return -1;
    score += 3;
  }
  const title = String(e.title || '').toLowerCase();
  const content = String(e.content || '').toLowerCase();
  const themeName = String(e.themeName || '').toLowerCase();
  const tags = (e.tags || []).map((t) => String(t).toLowerCase());
  for (const t of terms) {
    if (!t) continue;
    if (title.includes(t)) score += 8;
    if (tags.some((tag) => tag.includes(t))) score += 4;
    if (themeName.includes(t)) score += 3;
    if (content.includes(t)) score += 2;
  }
  if (terms.length === 0) score += 1;              // 只按主题查：全都要
  if (e.credibility === 'authoritative') score += 1.5;
  return score;
}

function pickEntries(kb, { query, theme, limit }) {
  const themeInfo = resolveTheme(theme);
  const themeId = theme ? themeInfo.id : '';
  const terms = splitTerms(query);
  const scored = kb.entries
    .map((e) => ({ e, s: scoreEntry(e, terms, themeId) }))
    .filter((x) => x.s > 0)
    .sort((a, b) => b.s - a.s)
    .slice(0, limit)
    .map((x) => x.e);
  return { themeInfo, entries: scored };
}

function viewEntry(e) {
  const content = String(e.content || '');
  return {
    id: e.id,
    title: e.title,
    theme: e.theme,
    themeName: e.themeName,
    kind: e.kind,
    credibility: e.credibility,
    source: e.source,
    author: e.author || '',
    updatedAt: e.updatedAt,
    content: content.length > 1200 ? `${content.slice(0, 1200)}…` : content
  };
}

// ── 工具返回 ────────────────────────────────────────────────────────────

function ok(payload) { return { content: JSON.stringify(payload, null, 1) }; }
function err(message) { return { content: String(message), isError: true }; }

// ── 工具 ────────────────────────────────────────────────────────────────

function registerTools(api) {
  // 1) 查知识库
  api.registerTool({
    id: 'recall',
    name: '集成战略·查知识库',
    description: '检索自己的集成战略知识库（开局、运营、鬼图、分队、结局、藏品）。回答集成战略问题前先调用它；'
      + 'query 可以是一句话或几个关键词，theme 可选（is1~is7 或主题名）。',
    category: 'knowledge',
    icon: '🎲',
    parameters: {
      type: 'object',
      properties: {
        query: { type: 'string', description: '要查什么，例如「萨米 开局 分队」「N15 鬼图怎么打」' },
        theme: { type: 'string', description: '可选，限定主题：is1~is7 或主题名（如 萨卡兹、界园）' },
        limit: { type: 'number', description: '返回条数，默认 6，最多 12' }
      },
      required: ['query']
    },
    async execute(ctx, args) {
      try {
        const kb = readKb();
        const limit = clamp(Number(args?.limit) || Number(cfg()?.maxResults) || 6, 1, 12);
        const { themeInfo, entries } = pickEntries(kb, {
          query: expandQuery(String(args?.query ?? '').trim()),
          theme: String(args?.theme ?? '').trim(),
          limit
        });
        return ok({
          query: String(args?.query ?? ''),
          theme: themeInfo,
          total: kb.entries.length,
          found: entries.length,
          entries: entries.map(viewEntry),
          note: entries.length
            ? '引用时按可信度说话：authoritative 可以直接下结论；unverified 要用「我记得/不太确定」的语气。'
            : '没检索到。如实说没记到，不要编。'
        });
      } catch (error) {
        warn('recall 失败：', error?.stack ?? error);
        return err(`查询知识库失败：${error?.message ?? error}`);
      }
    }
  });

  // 2) 学一条
  api.registerTool({
    id: 'learn',
    name: '集成战略·记一条',
    description: '把一条集成战略知识写进知识库（一句话也可以）。会自动记下是谁提供的；'
      + '与已有条目标题相同时按当前档位处理：听话=采纳覆盖，正常=另存补充，叛逆=记成待辩观点。'
      + '群友说的记为待验证，主人说的记为权威结论。',
    category: 'knowledge',
    icon: '📝',
    parameters: {
      type: 'object',
      properties: {
        title: { type: 'string', description: '标题，写清「主题＋要点」，例如「萨米 三层 鬼图 双快活」' },
        content: { type: 'string', description: '内容，一句话或一小段都行' },
        theme: { type: 'string', description: '可选，所属主题：is1~is7 或主题名；不填按标题猜' },
        kind: { type: 'string', description: '可选类型：theme/squad/start/route/ghost/ending/pick/note/doc，抓位用 pick，默认 note' },
        tags: { type: 'string', description: '可选标签，逗号分隔' }
      },
      required: ['title', 'content']
    },
    async execute(ctx, args) {
      try {
        const title = String(args?.title ?? '').trim().slice(0, 120);
        const content = String(args?.content ?? '').trim().slice(0, MAX_CONTENT);
        if (!title) return err('标题不能为空');
        if (!content) return err('内容不能为空');

        const speaker = currentSpeaker(ctx);
        const owners = ownerIds();
        const isOwner = Boolean(speaker.id) && owners.includes(speaker.id);
        const themeInfo = resolveTheme(args?.theme || title);
        const kind = KINDS.has(String(args?.kind || '')) ? String(args.kind) : 'note';
        const tags = String(args?.tags ?? '')
          .split(/[,，、;；\s]+/).map((t) => t.trim()).filter(Boolean).slice(0, 12);

        const kb = readKb();
        const existing = kb.entries.find((e) => e.theme === themeInfo.id
          && norm(e.title) === norm(title));

        const source = isOwner ? 'owner' : 'member';
        const credibility = isOwner ? 'authoritative' : 'unverified';
        const author = isOwner ? '主人' : (speaker.name || speaker.id || '群友');
        const mode = stance();

        const makeEntry = (t, c, k) => ({
          id: `e-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 6)}`,
          theme: themeInfo.id,
          themeName: themeInfo.name,
          kind: k,
          title: String(t).slice(0, 120),
          content: c,
          tags,
          source,
          credibility,
          author,
          authorQq: speaker.id,
          contributor: author,
          createdAt: nowIso(),
          updatedAt: nowIso()
        });

        let entry;
        let outcome = 'created';

        if (existing && isOwner) {
          existing.content = content;
          existing.tags = tags.length ? tags : existing.tags;
          existing.kind = kind;
          existing.source = source;
          existing.credibility = 'authoritative';
          existing.author = author;
          existing.authorQq = speaker.id;
          existing.contributor = author;
          existing.updatedAt = nowIso();
          entry = existing;
          outcome = 'replaced';
        } else if (existing && mode === '听话') {
          // 听话档：没有冲突就收；有冲突由模型在聊天里确认后再收
          existing.content = content;
          existing.tags = tags.length ? tags : existing.tags;
          existing.kind = kind;
          existing.source = source;
          existing.credibility = 'normal';
          existing.author = author;
          existing.authorQq = speaker.id;
          existing.contributor = author;
          existing.updatedAt = nowIso();
          entry = existing;
          outcome = 'adopted';
        } else if (existing && mode === '叛逆') {
          entry = makeEntry(`${title}（待辩 · ${author}）`, content, kind);
          entry.credibility = 'unverified';
          kb.entries.push(entry);
          outcome = 'disputed';
        } else if (existing) {
          entry = makeEntry(`${title}（补充 · ${author}）`, content, kind);
          kb.entries.push(entry);
          outcome = 'supplement';
        } else {
          entry = makeEntry(title, content, kind);
          kb.entries.push(entry);
        }

        saveKb(kb);
        log(`记了一条：${entry.theme}/${entry.title}（${source}/${outcome}）`);

        return ok({
          saved: true,
          outcome,
          replaced: outcome === 'replaced' || outcome === 'adopted',
          id: entry.id,
          theme: themeInfo,
          title: entry.title,
          source,
          credibility: entry.credibility,
          contributor: author,
          note: {
            replaced: '已按主人的话覆盖为权威结论。回主人一句确认即可。',
            adopted: '已按听话档采纳。回一句「记下了」就行。',
            disputed: '已记为待辩观点（叛逆档）。可以继续和对方辩，但别刷屏。',
            supplement: '已作为补充条目记下（正常档不覆盖原条目）。回一句就行。',
            created: '已记下。回一句「记下了」就行。'
          }[outcome]
        });
      } catch (error) {
        warn('learn 失败：', error?.stack ?? error);
        return err(`写入知识库失败：${error?.message ?? error}`);
      }
    }
  });

  // 3) 整段导入
  api.registerTool({
    id: 'import_doc',
    name: '集成战略·导入文档',
    description: '把一整段攻略/笔记导入知识库。带 # 标题会自动按标题拆成多条，没有标题就存成一条。'
      + '支持粘贴长文；主人导入的按权威处理。',
    category: 'knowledge',
    icon: '📥',
    parameters: {
      type: 'object',
      properties: {
        text: { type: 'string', description: '要导入的正文（可以很长）' },
        title: { type: 'string', description: '可选标题；文档没有 # 标题时用它' },
        theme: { type: 'string', description: '可选主题：is1~is7 或主题名' }
      },
      required: ['text']
    },
    async execute(ctx, args) {
      try {
        let text = String(args?.text ?? '').trim();
        if (!text) return err('内容是空的');
        if (text.length > MAX_IMPORT) {
          text = text.slice(0, MAX_IMPORT);
        }
        const speaker = currentSpeaker(ctx);
        const owners = ownerIds();
        const isOwner = Boolean(speaker.id) && owners.includes(speaker.id);
        const themeInfo = resolveTheme(args?.theme || args?.title || text.slice(0, 40));
        const source = isOwner ? 'owner' : 'member';
        const credibility = isOwner ? 'authoritative' : 'unverified';
        const author = isOwner ? '主人' : (speaker.name || speaker.id || '群友');

        // 按 markdown 标题拆分；没有标题就整段一条
        const sections = [];
        let cur = { title: String(args?.title ?? '').trim(), lines: [] };
        for (const line of text.split(/\r?\n/)) {
          const m = /^#{1,4}\s+(.+?)\s*$/.exec(line.trim());
          if (m) {
            if (cur.lines.join('').trim()) sections.push(cur);
            cur = { title: m[1].trim(), lines: [] };
          } else {
            cur.lines.push(line);
          }
        }
        if (cur.lines.join('').trim()) sections.push(cur);
        if (!sections.length) sections.push({ title: `导入 ${nowIso().slice(0, 10)}`, lines: [text] });
        if (sections.length > MAX_IMPORT_SECTIONS) sections.length = MAX_IMPORT_SECTIONS;

        const kb = readKb();
        let added = 0;
        for (const s of sections) {
          const body = s.lines.join('\n').trim().slice(0, MAX_CONTENT);
          if (!body) continue;
          const title = (s.title || `导入 ${nowIso().slice(0, 10)}`).slice(0, 120);
          const existing = kb.entries.find((e) => e.theme === themeInfo.id
            && norm(e.title) === norm(title));
          if (existing) {
            existing.content = body;
            existing.source = source;
            existing.credibility = credibility;
            existing.author = author;
            existing.authorQq = speaker.id;
            existing.updatedAt = nowIso();
          } else {
            kb.entries.push({
              id: `e-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 6)}`,
              theme: themeInfo.id,
              themeName: themeInfo.name,
              kind: 'doc',
              title,
              content: body,
              tags: [],
              source,
              credibility,
              author,
              authorQq: speaker.id,
              createdAt: nowIso(),
              updatedAt: nowIso()
            });
          }
          added += 1;
        }
        saveKb(kb);
        log(`导入文档：${added} 条（${themeInfo.id}/${source}）`);

        return ok({
          saved: true,
          sections: added,
          theme: themeInfo,
          source,
          credibility,
          note: '导入完成。用一句话告诉对方记了多少条即可，不要复述正文。'
        });
      } catch (error) {
        warn('import_doc 失败：', error?.stack ?? error);
        return err(`导入失败：${error?.message ?? error}`);
      }
    }
  });

  // 4) 记玩家黑话/外号
  api.registerTool({
    id: 'record_alias',
    name: '集成战略·记称谓',
    description: '记录玩家对集成战略事物的黑话/外号，例如「大狗」指的是猎犬proto。'
      + '会写进技能设置里的称谓表，管理员可以在技能设置弹窗里直接改或删。',
    category: 'knowledge',
    icon: '💬',
    parameters: {
      type: 'object',
      properties: {
        alias: { type: 'string', description: '玩家说的外号/黑话' },
        canonical: { type: 'string', description: '对应的正式名，例如 猎犬proto' }
      },
      required: ['alias', 'canonical']
    },
    async execute(ctx, args) {
      try {
        const alias = String(args?.alias ?? '').trim().slice(0, 30);
        const canonical = String(args?.canonical ?? '').trim().slice(0, 60);
        if (!alias || !canonical) return err('称谓和正式名都要填');
        const pairs = aliasPairs().filter((p) => p.alias !== alias);
        pairs.push({ alias, canonical });
        const text = pairs.slice(-200).map((p) => `${p.alias}=${p.canonical}`).join('；');
        setSkillConfig('arknights-is', { aliases: text });
        log(`记称谓：${alias}=${canonical}`);
        return ok({
          saved: true,
          alias,
          canonical,
          total: pairs.length,
          note: '已写进技能设置的称谓表。回一句「记住了」就行。'
        });
      } catch (error) {
        warn('record_alias 失败：', error?.stack ?? error);
        return err(`记录称谓失败：${error?.message ?? error}`);
      }
    }
  });

  // 5) 看收录情况
  api.registerTool({
    id: 'list_topics',
    name: '集成战略·收录清单',
    description: '查看知识库里都收了哪些主题、各多少条、最近更新了什么。有人问「你都记得什么」时用。',
    category: 'knowledge',
    icon: '📚',
    parameters: { type: 'object', properties: {} },
    async execute() {
      try {
        const kb = readKb();
        const counts = {};
        for (const e of kb.entries) counts[e.theme] = (counts[e.theme] || 0) + 1;
        const recent = [...kb.entries]
          .sort((a, b) => String(b.updatedAt || '').localeCompare(String(a.updatedAt || '')))
          .slice(0, 5)
          .map((e) => ({ title: e.title, theme: e.themeName, updatedAt: e.updatedAt }));
        return ok({
          total: kb.entries.length,
          updatedAt: kb.updatedAt,
          themes: THEMES.map((t) => ({ id: t.id, name: t.name, count: counts[t.id] || 0 })),
          general: counts.general || 0,
          recent
        });
      } catch (error) {
        return err(`读取失败：${error?.message ?? error}`);
      }
    }
  });
}

// ── 生命周期 ────────────────────────────────────────────────────────────

export function setup(api) {
  cfg = api.config;
  log = api.log;
  warn = api.warn;
  try { ensureKb(); } catch (error) { warn('初始化知识库失败：', error?.message ?? error); }
  registerTools(api);
  log('集成战略知识库已加载（只读写自己的 knowledge.json）');
}

export function available() { return true; }

/**
 * 联网闸：集成战略相关的问题一律只用本地知识库。
 * 这个项目不联网查 PRTS —— 模型如果自己想到去搜，这里直接拒绝这次调用。
 * 注意：只拦「集成战略/PRTS」这类查询，普通联网（别的话题）不受影响。
 */
const IS_QUERY_RE = /集成战略|肉鸽|黑流树海|树海|界园|萨卡兹|无终奇语|深蓝之树|银凇止境|猩红孤钻|灰蕈迷境|PRTS/i;

export const hooks = {
  'before-tool': ({ toolName, argsRaw } = {}) => {
    const args = String(argsRaw ?? '');
    if (toolName === 'web_fetch' && /prts\.wiki/i.test(args)) {
      return { block: true, reason: '集成战略只用本地知识库，不联网查 PRTS。不知道就直接说没记到。' };
    }
    if (toolName === 'web_search' && IS_QUERY_RE.test(args)) {
      return { block: true, reason: '集成战略只用本地知识库，不联网检索。查不到就说没记到。' };
    }
  }
};

/**
 * 动态提示词：每次请求带一份"收录索引"，模型不用先检索也知道有哪些主题。
 * 控制在几百字以内，避免把上下文吃满。
 */
export function promptSections(context = {}) {
  try {
    const out = [];

    // 档位：每轮都带上，决定“听不听、辩不辩”。
    out.push(stanceSection());

    // 常驻群：在这些群里看到相关话题就主动接，不等点名。
    if (isAlwaysOnChat(context)) {
      out.push({
        id: 'arknights-is-always-on',
        title: '集成战略·常驻群',
        priority: 63,
        content: '【本群常驻】这个群是集成战略常驻群：只要消息里出现集成战略/肉鸽/主题名/分队/藏品/抓位/黑话这类词，就主动接话，并先用 arknights-is__recall 查本地库；不用等人点名。库里没有就说没记到，不许联网搜。'
      });
    }

    // 玩家称谓表：让模型认得出黑话。
    const pairs = aliasPairs();
    if (pairs.length) {
      const list = pairs.slice(0, 40).map((p) => `${p.alias}=${p.canonical}`).join('；');
      out.push({
        id: 'arknights-is-aliases',
        title: '集成战略·玩家称谓',
        priority: 59,
        content: `【玩家称谓】${list}。听到新的外号/黑话，用 arknights-is__record_alias 记下来。`
      });
    }

    const kb = readKb();
    if (kb.entries.length) {
      const counts = {};
      for (const e of kb.entries) counts[e.theme] = (counts[e.theme] || 0) + 1;
      const themes = THEMES
        .map((t) => `${t.id} ${t.name}(${counts[t.id] || 0})`)
        .join('；');
      out.push({
        id: 'arknights-is-index',
        title: '集成战略知识库',
        priority: 55,
        content: `【集成战略知识库】共 ${kb.entries.length} 条（含通用 ${counts.general || 0} 条）。已收录：${themes}。`
          + '需要细节就调 arknights-is__recall 检索；听到新打法用 arknights-is__learn 记下来（抓位用 kind=pick）；别人贴整篇攻略用 arknights-is__import_doc。'
      });
    }

    return out;
  } catch {
    return [];
  }
}

export const internals = { readKb, saveKb, pickEntries, currentSpeaker, ownerIds, resolveTheme };
