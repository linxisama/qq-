// 萌娘搜索（moegirl-search）—— LLM 型技能，多 Wiki 版
//
// 解决的问题：机器人以前会把群友的整句话直接塞进搜索框，搜出一堆无关结果；
// 或者在 ACG 问题上只看搜索摘要，漏掉百科里更完整的设定。
//
// 本技能做两件事：
//   1. 两个工具：在指定 Wiki 上按关键词搜条目、读条目正文；
//   2. 一段提示词：约束所有搜索都先提炼关键词、按题材选对 Wiki、读正文再回答。
//
// 多 Wiki 的实现方式：
//   · 所有站点都是 MediaWiki，统一走 api.php；
//   · 搜索统一用 opensearch（标题前缀匹配，轻量、几乎所有站点都开）；
//   · 正文优先用 TextExtracts（extracts），没有就退到 action=parse + HTML 转纯文本；
//   · 每个站点在 WIKIS 里注册一行即可，新增 Wiki 不需要改工具逻辑。
//
// 设计取舍：
//   · 只访问 WIKIS 里写死的站点，URL 由本文件拼装，不接受任意地址（无 SSRF 面）。
//   · 任何网络/解析失败都返回 isError + 明确的降级建议，不抛异常拖垮本轮对话。
//   · 正文有字数上限（默认 8000），避免整页表格挤爆上下文。

const WIKIS = {
  moegirl: {
    name: '萌娘百科',
    api: 'https://zh.moegirl.org.cn/api.php',
    site: 'https://zh.moegirl.org.cn/',
    mode: 'extracts'
  },
  wikipedia: {
    name: '中文维基百科',
    api: 'https://zh.wikipedia.org/w/api.php',
    site: 'https://zh.wikipedia.org/wiki/',
    mode: 'extracts'
  },
  thbwiki: {
    name: 'THBWiki',
    api: 'https://thwiki.cc/api.php',
    site: 'https://thwiki.cc/',
    mode: 'html'
  },
  prts: {
    name: 'PRTS.wiki',
    api: 'https://prts.wiki/api.php',
    site: 'https://prts.wiki/w/',
    mode: 'html'
  },
  fgo: {
    name: 'Mooncell',
    api: 'https://fgo.wiki/api.php',
    site: 'https://fgo.wiki/w/',
    mode: 'html'
  },
  genshin: {
    name: '原神 BWIKI',
    api: 'https://wiki.biligame.com/ys/api.php',
    site: 'https://wiki.biligame.com/ys/',
    mode: 'html'
  },
  starrail: {
    name: '星穹铁道 BWIKI',
    api: 'https://wiki.biligame.com/sr/api.php',
    site: 'https://wiki.biligame.com/sr/',
    mode: 'html'
  },
  blhx: {
    name: '碧蓝航线 BWIKI',
    api: 'https://wiki.biligame.com/blhx/api.php',
    site: 'https://wiki.biligame.com/blhx/',
    mode: 'html'
  },
  umamusume: {
    name: '赛马娘 BWIKI',
    api: 'https://wiki.biligame.com/umamusume/api.php',
    site: 'https://wiki.biligame.com/umamusume/',
    mode: 'html'
  }
};

const WIKI_KEYS = Object.keys(WIKIS);
const WIKI_GUIDE = 'moegirl=萌娘百科（ACG 综合）、wikipedia=中文维基百科（通用）、'
  + 'thbwiki=THBWiki（东方）、prts=PRTS（明日方舟）、fgo=Mooncell（FGO）、'
  + 'genshin=原神、starrail=星穹铁道、blhx=碧蓝航线、umamusume=赛马娘';

const USER_AGENT = 'QQAgent-MoegirlSearch/1.1 (+https://github.com/Kondius/qq-agent)';
const TIMEOUT_MS = 15000;

function text(value) {
  return String(value ?? '').trim();
}

function toInt(value, min, max, fallback) {
  const n = Number(value);
  if (!Number.isFinite(n)) return fallback;
  return Math.min(max, Math.max(min, Math.trunc(n)));
}

function pageUrl(wiki, title) {
  // 子页面标题里的 / 要保留成分隔符，不能编码成 %2F（MediaWiki 不认）。
  const slug = encodeURIComponent(text(title).replace(/ /g, '_')).replace(/%2F/gi, '/');
  return wiki.site + slug;
}

function normalizeTitle(value) {
  return text(value).replace(/^[《「『"'“”]+/, '').replace(/[》」』"'“”]+$/, '').trim();
}

const NAMED_ENTITIES = { amp: '&', lt: '<', gt: '>', quot: '"', apos: "'", nbsp: ' ' };

function decodeEntities(input) {
  return String(input || '').replace(/&(#x?[0-9a-f]+|[a-z]+);/gi, (match, code) => {
    const key = String(code).toLowerCase();
    if (key[0] === '#') {
      const n = key[1] === 'x' ? parseInt(key.slice(2), 16) : parseInt(key.slice(1), 10);
      if (Number.isFinite(n) && n >= 0 && n <= 0x10ffff) {
        try { return String.fromCodePoint(n); } catch { return match; }
      }
      return match;
    }
    return NAMED_ENTITIES[key] ?? match;
  });
}

/** 按标签配对删除一个元素（处理嵌套），用于去掉目录/导航/编辑链接。 */
function stripTagElement(html, openRegex, tagName) {
  const match = openRegex.exec(html);
  if (!match) return html;
  const lower = html.toLowerCase();
  const open = `<${tagName}`;
  const close = `</${tagName}>`;
  let index = match.index + match[0].length;
  let depth = 1;
  while (index < html.length && depth > 0) {
    const nextOpen = lower.indexOf(open, index);
    const nextClose = lower.indexOf(close, index);
    if (nextClose === -1) return html;
    if (nextOpen !== -1 && nextOpen < nextClose) {
      depth += 1;
      index = nextOpen + open.length;
    } else {
      depth -= 1;
      index = nextClose + close.length;
    }
  }
  return html.slice(0, match.index) + html.slice(index);
}

/** MediaWiki 的 HTML 正文 → 纯文本（够用即可，不追求完美解析）。 */
function htmlToText(html) {
  let s = String(html || '');
  s = s.replace(/<!--[\s\S]*?-->/g, ' ');
  s = s.replace(/<script[\s\S]*?<\/script>/gi, ' ');
  s = s.replace(/<style[\s\S]*?<\/style>/gi, ' ');
  // 目录 / 面包屑 / 站点横幅 / 编辑链接：这些不删的话，正文前几百字全是导航。
  s = stripTagElement(s, /<div[^>]*id="toc"[^>]*>/i, 'div');
  s = stripTagElement(s, /<div[^>]*id="bread-edit"[^>]*>/i, 'div');
  s = stripTagElement(s, /<div[^>]*class="[^"]*bg-snm[^"]*"[^>]*>/i, 'div');
  s = stripTagElement(s, /<div[^>]*class="[^"]*ak-pathnav[^"]*"[^>]*>/i, 'div');
  s = stripTagElement(s, /<div[^>]*class="[^"]*charinfo-container[^"]*"[^>]*>/i, 'div');
  s = stripTagElement(s, /<div[^>]*class="[^"]*ak-cbox[^"]*"[^>]*>/i, 'div');
  s = stripTagElement(s, /<div[^>]*class="[^"]*map-dh[^"]*"[^>]*>/i, 'div');
  s = stripTagElement(s, /<span[^>]*style="[^"]*display\s*:\s*none[^"]*"[^>]*>/i, 'span');
  s = stripTagElement(s, /<div[^>]*style="[^"]*display\s*:\s*none[^"]*"[^>]*>/i, 'div');
  s = stripTagElement(s, /<span[^>]*class="[^"]*mw-editsection[^"]*"[^>]*>/i, 'span');
  s = s.replace(/<sup[^>]*class="[^"]*reference[^"]*"[^>]*>[\s\S]*?<\/sup>/gi, ' ');
  s = s.replace(/<br\s*\/?>/gi, '\n');
  s = s.replace(/<\/(p|div|li|tr|h[1-6]|table|ul|ol|dl|blockquote)>/gi, '\n');
  s = s.replace(/<[^>]+>/g, ' ');
  s = decodeEntities(s);
  s = s.replace(/\[\s*编辑\s*\]/g, ' ');
  s = s.replace(/[ \t\u00a0]+/g, ' ');
  s = s.replace(/\n[ \t]+/g, '\n');
  s = s.replace(/\n{3,}/g, '\n\n');
  return s.trim();
}

async function fetchJson(api, url, attempt = 0) {
  const res = await api.fetch(url, {
    headers: { 'user-agent': USER_AGENT, accept: 'application/json' },
    signal: AbortSignal.timeout(TIMEOUT_MS)
  });
  if (!res.ok) {
    // BWIKI 等站点会短时间限流（429/5xx/567）：退避重试两次，避免一次抖动就判死。
    if ((res.status === 429 || res.status >= 500) && attempt < 2) {
      await new Promise((resolve) => setTimeout(resolve, 800 * (attempt + 1)));
      return fetchJson(api, url, attempt + 1);
    }
    throw new Error(`返回 HTTP ${res.status}`);
  }
  let body = await res.text();
  if (body.charCodeAt(0) === 0xfeff) body = body.slice(1);
  try {
    return JSON.parse(body);
  } catch {
    throw new Error('返回的不是合法 JSON（可能被站点拦截或需要验证）');
  }
}

// opensearch 是**标题前缀**匹配，不是全文搜索：会混进 styles.css 这类子页面，
// 也会因为多词组合（「原神 纳西妲」）一个字都对不上而返回空。
const JUNK_TITLE = /(\.(css|js|json|png|jpe?g|gif|svg|webp)$)|(\/(styles|common|interface)(\/|$))/i;

function cleanHits(hits) {
  const seen = new Set();
  return hits.filter((hit) => {
    if (JUNK_TITLE.test(hit.title)) return false;
    if (seen.has(hit.title)) return false;
    seen.add(hit.title);
    return true;
  });
}

/** opensearch：按关键词找候选条目。返回 [{ title, url }]。 */
async function searchEntries(api, wiki, query, limit) {
  const params = new URLSearchParams({
    action: 'opensearch',
    format: 'json',
    namespace: '0',
    redirects: 'resolve',
    limit: String(limit),
    search: query
  });
  const data = await fetchJson(api, `${wiki.api}?${params.toString()}`);
  if (!Array.isArray(data) || !Array.isArray(data[1])) return [];
  const titles = data[1];
  const urls = Array.isArray(data[3]) ? data[3] : [];
  return titles
    .map((title, i) => ({ title: text(title), url: text(urls[i]) || pageUrl(wiki, title) }))
    .filter((item) => item.title);
}

/**
 * 先整串搜；搜不到就把「原神 纳西妲」这类组合拆成单词逐个试。
 * 返回 { hits, used }：used 是真正命中的那串，便于如实告诉模型/用户。
 */
async function searchWithFallback(api, wiki, query, limit) {
  const direct = cleanHits(await searchEntries(api, wiki, query, limit));
  if (direct.length) return { hits: direct, used: query };

  const tokens = [...new Set(
    query.split(/[\s,，、;；/|·]+/).map((part) => text(part)).filter((part) => part.length >= 2 && part !== query)
  )].sort((a, b) => b.length - a.length).slice(0, 3);

  for (const token of tokens) {
    const hits = cleanHits(await searchEntries(api, wiki, token, limit));
    if (hits.length) return { hits, used: token };
  }
  return { hits: [], used: query };
}

/** TextExtracts：读条目开头（intro=true）或全文。没有扩展时返回 null。 */
async function readExtract(api, wiki, title, { intro = false, maxChars = 8000 } = {}) {
  const params = new URLSearchParams({
    action: 'query',
    format: 'json',
    formatversion: '2',
    prop: 'extracts',
    explaintext: '1',
    redirects: '1',
    titles: title
  });
  if (intro) params.set('exintro', '1');
  const data = await fetchJson(api, `${wiki.api}?${params.toString()}`);
  const page = data?.query?.pages?.[0];
  if (!page || page.missing === true) return null;
  let content = text(page.extract);
  if (!content) return null;
  const truncated = content.length > maxChars;
  if (truncated) content = `${content.slice(0, maxChars)}\n…（内容过长，已截断）`;
  return {
    title: text(page.title) || title,
    url: pageUrl(wiki, page.title || title),
    content,
    truncated
  };
}

/** action=parse：拿渲染后的 HTML，转纯文本。适用于没装 TextExtracts 的 Wiki。 */
async function readParsed(api, wiki, title, { maxChars = 8000 } = {}) {
  const params = new URLSearchParams({
    action: 'parse',
    format: 'json',
    formatversion: '2',
    prop: 'text',
    redirects: '1',
    page: title
  });
  const data = await fetchJson(api, `${wiki.api}?${params.toString()}`);
  if (data?.error) throw new Error(data.error.info || data.error.code || '页面解析失败');
  const parsed = data?.parse;
  if (!parsed || !parsed.text) return null;
  let content = htmlToText(parsed.text);
  if (!content) return null;
  const truncated = content.length > maxChars;
  if (truncated) content = `${content.slice(0, maxChars)}\n…（内容过长，已截断）`;
  return {
    title: text(parsed.title) || title,
    url: pageUrl(wiki, parsed.title || title),
    content,
    truncated
  };
}

async function readArticle(api, wiki, title, { maxChars = 8000 } = {}) {
  if (wiki.mode === 'extracts') {
    const extracted = await readExtract(api, wiki, title, { intro: false, maxChars });
    if (extracted) return extracted;
  }
  return readParsed(api, wiki, title, { maxChars });
}

function resolveWiki(args, settings) {
  const key = text(args?.wiki) || text(settings.defaultWiki) || 'moegirl';
  return { key, wiki: WIKIS[key] || null };
}

export async function setup(api) {
  const cfg = () => api.config() || {};

  api.registerTool({
    id: 'wiki_search',
    name: '多 Wiki 搜索',
    description: `在指定 Wiki 上按关键词检索条目。wiki 可选：${WIKI_GUIDE}。`
      + 'query 只填提炼后的条目名或关键词（如「初音未来」「纳西妲」），**不要**把群友整句话原样塞进来。'
      + '返回候选条目的标题、链接；萌娘百科/维基百科会带开头摘要。要读正文再用 wiki_read。',
    category: 'knowledge',
    icon: '📚',
    requiresSearch: true,
    parameters: {
      type: 'object',
      properties: {
        query: {
          type: 'string',
          description: '提炼后的关键词或条目名，例如「初音未来」「纳西妲」「博丽灵梦」。不要填整句问题。'
        },
        wiki: {
          type: 'string',
          enum: WIKI_KEYS,
          description: `要查的 Wiki：${WIKI_GUIDE}。不填则用设置里的默认 Wiki。`
        }
      },
      required: ['query'],
      additionalProperties: false
    },
    async execute(_ctx, args) {
      const query = text(args?.query);
      if (!query) {
        return { content: 'query 不能为空：请填提炼后的关键词或条目名（不是整句话）。', isError: true };
      }
      if (query.length > 80) {
        return {
          content: `query 太长了（${query.length} 字）：请只保留主体和限定词，例如把整句问题压成「角色名 作品名 术语」。`,
          isError: true
        };
      }

      const settings = cfg();
      const { key, wiki } = resolveWiki(args, settings);
      if (!wiki) {
        return { content: `未知 Wiki：${key}。可选：${WIKI_KEYS.join(', ')}`, isError: true };
      }
      const topK = toInt(settings.topK, 1, 5, 3);
      const introChars = toInt(settings.maxIntroChars, 100, 2000, 700);

      try {
        const found = await searchWithFallback(api, wiki, query, topK);
        const hits = found.hits;
        if (!hits.length) {
          return {
            content: `${wiki.name}没有找到「${query}」相关条目。\n`
              + '下一步：换同义词/更常见的译名再试一次；仍然没有就换一个 Wiki（见工具说明）或用 web_search，'
              + 'query 写「关键词 wiki」「关键词 萌娘百科」或「site:... 关键词」，然后 web_fetch 读正文。',
            wiki: key,
            results: []
          };
        }

        let intros = hits.map(() => '');
        if (wiki.mode === 'extracts') {
          intros = await Promise.all(hits.map(async (hit) => {
            try {
              const ex = await readExtract(api, wiki, hit.title, { intro: true, maxChars: introChars });
              return ex?.content || '';
            } catch {
              return '';
            }
          }));
        }

        const usedHint = found.used === query
          ? query
          : `${found.used}（原词「${query}」没命中，已拆成单词重试）`;
        const lines = [`在「${wiki.name}」找到 ${hits.length} 个候选（关键词：${usedHint}）：`];
        hits.forEach((hit, i) => {
          lines.push(`${i + 1}. ${hit.title}\n   ${hit.url}`);
          if (wiki.mode === 'extracts') {
            lines.push(intros[i] ? `   摘要：${intros[i]}` : '   摘要：读取失败，可直接用 wiki_read 读正文。');
          }
        });
        if (wiki.mode !== 'extracts') {
          lines.push('这个 Wiki 的接口只回标题；正文用 wiki_read 读。');
        }
        lines.push(`读正文：调 moegirl-search__wiki_read，wiki 填 ${key}，title 填上面的条目名。`);

        return {
          content: lines.join('\n'),
          wiki: key,
          results: hits.map((hit, i) => ({ title: hit.title, url: hit.url, intro: intros[i] }))
        };
      } catch (error) {
        api.warn('%s 搜索失败：%s', wiki.name, error?.message ?? error);
        return {
          content: `${wiki.name}搜索失败：${error?.message ?? error}。\n`
            + '如果这个站点连不上，换萌娘百科（moegirl）或其它 Wiki；也可以改用 web_search + web_fetch。',
          isError: true
        };
      }
    }
  });

  api.registerTool({
    id: 'wiki_read',
    name: 'Wiki 条目阅读',
    description: `读取指定 Wiki 条目正文的纯文本（默认最多 8000 字，超出截断）。wiki 可选：${WIKI_GUIDE}。`
      + 'title 用 wiki_search 返回的标题；先读正文再回答，不要只凭搜索摘要。条目不存在会明确报错。',
    category: 'knowledge',
    icon: '📖',
    requiresSearch: true,
    parameters: {
      type: 'object',
      properties: {
        title: {
          type: 'string',
          description: '要读的条目名，如「初音未来」「博丽灵梦」「阿米娅」。优先用 wiki_search 返回的标题。'
        },
        wiki: {
          type: 'string',
          enum: WIKI_KEYS,
          description: `条目所在的 Wiki：${WIKI_GUIDE}。不填则用设置里的默认 Wiki。`
        },
        maxChars: {
          type: 'number',
          description: '可选：本次最多返回多少字（500~20000），默认跟随技能设置（8000）。'
        }
      },
      required: ['title'],
      additionalProperties: false
    },
    async execute(_ctx, args) {
      const title = normalizeTitle(args?.title);
      if (!title) {
        return { content: 'title 不能为空：请填 wiki_search 返回的条目名。', isError: true };
      }

      const settings = cfg();
      const { key, wiki } = resolveWiki(args, settings);
      if (!wiki) {
        return { content: `未知 Wiki：${key}。可选：${WIKI_KEYS.join(', ')}`, isError: true };
      }
      const maxChars = toInt(args?.maxChars, 500, 20000, toInt(settings.maxFullChars, 500, 20000, 8000));

      try {
        const page = await readArticle(api, wiki, title, { maxChars });
        if (!page) {
          return {
            content: `${wiki.name}没有「${title}」这个条目（或条目没有正文）。\n`
              + '先用 wiki_search 搜同义词/正确译名；确认没有再换一个 Wiki 或用 web_search 查其它来源。',
            isError: true
          };
        }
        return {
          content: `【${wiki.name} · ${page.title}】${page.url}\n\n${page.content}`,
          wiki: key,
          title: page.title,
          url: page.url,
          truncated: page.truncated
        };
      } catch (error) {
        api.warn('%s 读取失败：%s', wiki.name, error?.message ?? error);
        return {
          content: `读取「${wiki.name}」的「${title}」失败：${error?.message ?? error}。\n`
            + '可以改用 web_fetch 直接打开条目链接，或换一个 Wiki / web_search 查其它来源。',
          isError: true
        };
      }
    }
  });

  api.log(`萌娘搜索已就绪：${WIKI_KEYS.length} 个 Wiki（${WIKI_KEYS.join(' / ')}）`);
}
