// 原神常驻池抽卡 · QQ Agent LLM 型技能
//
// 类型判定（按 skill-development.md §0）：
//   触发时机要靠理解人话（「抽一发」「来十连」「抽卡！」都可能），
//   漏一次只是少个花活 → 属于 LLM 型技能，放 skills/，注册工具。
//
// 机制：
//   · 只有常驻祈愿（标准池）：无 50/50、无定轨。
//   · 5★ 基础 0.6%，第 74 抽起软保底，第 90 抽必出；4★ 基础 5.1%，第 10 抽必出。
//   · 每日次数按 QQ 号计，默认上限可在「技能 → 设置」里改；
//     单个 QQ 的覆盖值由群主/管理员通过 gacha_limits 工具设置。
//   · 记录按 QQ 号留存，超过上限丢弃最旧的。
//   · 状态文件：QQ_AGENT_DATA_DIR/genshin-gacha/state.json（原子写）。
import fs from 'node:fs';
import path from 'node:path';
import { DATA_DIR } from '../../src/config.js';

const SKILL_ID = 'genshin-gacha';
const STATE_DIR = path.join(DATA_DIR, SKILL_ID);
const STATE_FILE = path.join(STATE_DIR, 'state.json');

let cfg = () => ({});
let log = () => {};

// ── 常驻祈愿卡池（标准池） ──
const POOL = {
  // 5★ 常驻角色
  five: ['琴', '迪卢克', '莫娜', '七七', '刻晴', '提纳里', '迪希雅'],
  // 4★ 常驻角色
  fourChars: [
    '安柏', '凯亚', '丽莎', '芭芭拉', '雷泽', '香菱', '班尼特', '诺艾尔', '菲谢尔',
    '砂糖', '重云', '行秋', '北斗', '凝光', '辛焱', '罗莎莉亚', '烟绯', '早柚',
    '云堇', '托马', '五郎', '九条裟罗', '久岐忍', '多莉', '柯莱', '坎蒂丝',
    '莱依拉', '珐露珊', '瑶瑶', '卡维', '米卡', '琳妮特', '菲米尼', '夏洛蒂',
    '绮良良', '嘉明', '夏沃蕾'
  ],
  // 4★ 常驻武器
  fourWeapons: [
    '西风剑', '西风大剑', '西风长柄枪', '西风猎弓', '西风秘典',
    '祭礼剑', '祭礼大剑', '祭礼残章', '祭礼弓', '匣里龙吟', '笛剑', '钟剑',
    '雨裁', '流浪乐章', '绝弦', '弓藏', '昭心'
  ],
  // 3★ 武器
  threeWeapons: [
    '弹弓', '鸦羽弓', '神射手之誓', '讨龙英杰谭', '魔导绪论', '翡玉法球',
    '以理服人', '沐浴龙血的剑', '铁影阔剑', '白铁大剑', '黎明神剑', '冷刃', '飞天御剑'
  ]
};
const FOUR_POOL = [...POOL.fourChars, ...POOL.fourWeapons];

const FIVE_BASE = 0.006;
const FIVE_HARD = 90;
const FIVE_SOFT_START = 74;      // 第 74 抽（pity 73 → 下一抽 n=74）起开始提升
const FOUR_BASE = 0.051;
const FOUR_HARD = 10;

// ── 工具注册 ──
export function setup(api) {
  cfg = api.config;
  log = api.log || (() => {});

  api.registerTool({
    id: 'pull',
    name: '原神抽卡',
    description:
      '模拟原神常驻祈愿（标准池）抽卡。当群友明确让你抽卡（「抽卡」「单抽」「十连」「来一发」「抽一发」「抽10发」）时调用；' +
      '如果对方只是在聊抽卡话题、没让你抽，就不要调用。本工具只有常驻池（没有限定池、没有 50/50）。' +
      'count 参数：1=单抽，10=十连，默认 1。抽卡结果会自动发到当前会话，调用后不要再复述结果。',
    category: 'query',
    icon: '🎴',
    parameters: {
      type: 'object',
      properties: {
        count: {
          type: 'integer',
          enum: [1, 10],
          description: '抽卡次数：1=单抽，10=十连。默认 1。'
        }
      }
    },
    async execute(ctx, args) {
      try {
        return await doPullTool(ctx, args);
      } catch (error) {
        return { content: `抽卡失败：${error?.message ?? error}`, isError: true };
      }
    }
  });

  api.registerTool({
    id: 'status',
    name: '抽卡状态',
    description:
      '查询当前 QQ 用户的原神抽卡状态：今日已抽次数、剩余次数、5★/4★ 保底进度、抽卡记录保存情况。' +
      '当用户问「我还剩几次」「保底多少」「抽卡记录」时使用。',
    category: 'query',
    icon: '📊',
    parameters: {
      type: 'object',
      properties: {}
    },
    async execute(ctx) {
      try {
        return doStatusTool(ctx);
      } catch (error) {
        return { content: `查询失败：${error?.message ?? error}`, isError: true };
      }
    }
  });

  api.registerTool({
    id: 'limits',
    name: '抽卡限额管理',
    description:
      '查看或设置指定 QQ 号的每日抽卡次数上限（覆盖「设置」里的全局默认值，0=该用户不限）。' +
      '仅群主/群管理员可用。当群管理员说「把某人每天抽卡次数设为 N」「取消某人的抽卡限制」「查看抽卡限额」时使用。' +
      '参数：action 为 set/clear/list；targetUserId 为目标 QQ 号；limit 为每日次数（0 表示不限）。',
    category: 'system',
    icon: '⚙️',
    parameters: {
      type: 'object',
      properties: {
        action: {
          type: 'string',
          enum: ['set', 'clear', 'list'],
          description: 'set=设置上限，clear=取消该用户的覆盖值，list=查看所有覆盖值。'
        },
        targetUserId: {
          type: 'string',
          description: '目标 QQ 号（纯数字）。set/clear 必填。'
        },
        limit: {
          type: 'integer',
          description: '每日抽卡次数上限，0 表示不限。set 必填。'
        }
      },
      required: ['action']
    },
    async execute(ctx, args) {
      try {
        return await doLimitsTool(ctx, args);
      } catch (error) {
        return { content: `操作失败：${error?.message ?? error}`, isError: true };
      }
    }
  });

  log('原神常驻池抽卡已加载');
}

// ── 抽卡主逻辑 ──

async function doPullTool(ctx, args) {
  const c = cfg();
  const count = Number(args?.count) === 10 ? 10 : 1;
  const caller = callerOf(ctx);
  if (!caller) return { content: '无法确定是谁在抽卡（没有找到触发消息的发送者），这次不抽。', isError: true };
  if (String(ctx.kind) === 'private' && c.allowPrivate === false) {
    return { content: '私聊抽卡已被关闭，去群里抽吧。', isError: true };
  }

  const state = loadState();
  const u = ensureUser(state, caller);
  rollDay(u, c);

  const limit = effectiveLimit(state, caller, c);
  const remaining = limit > 0 ? Math.max(0, limit - u.dayCount) : Infinity;
  if (limit > 0 && remaining <= 0) {
    return { content: `你今天已经抽满 ${limit} 次了，明天再来吧（每天 ${resetHourOf(c)} 点重置）。`, isError: true };
  }
  if (limit > 0 && count > remaining) {
    return { content: `今天只剩 ${remaining} 次，不够十连（要 10 次）。明天再来，或者先单抽。`, isError: true };
  }

  const results = [];
  for (let i = 0; i < count; i++) results.push(doPull(u));

  u.dayCount += count;
  u.records.push({
    t: Date.now(),
    kind: count === 10 ? '十连' : '单抽',
    res: results.map((r) => ({ r: r.rank, n: r.name }))
  });
  const cap = Math.max(1, Math.min(5000, Number(c.maxRecords) || 100));
  if (u.records.length > cap) u.records = u.records.slice(-cap);
  u.updatedAt = Date.now();
  saveState(state);

  const rest = limit > 0 ? Math.max(0, limit - u.dayCount) : null;
  const text = formatPullText(count, results, u, rest, resetHourOf(c));
  try {
    await ctx.sender.sendTextBatch(ctx.chatKey, [text]);
    if (Array.isArray(ctx.session?.sent)) {
      ctx.session.sent.push({ type: 'text', text, at: new Date().toLocaleTimeString('zh-CN', { hour12: false }) });
    }
    if (typeof ctx.emit === 'function') ctx.emit('session-update', ctx.session?.id);
  } catch (error) {
    return { content: `结果算出来了，但发送失败：${error?.message ?? error}`, isError: true };
  }
  return { content: `抽卡完成，结果已发到会话（${count} 抽）。不要再复述结果。` };
}

function doStatusTool(ctx) {
  const c = cfg();
  const caller = callerOf(ctx);
  if (!caller) return { content: '无法确定查询者身份。', isError: true };
  const state = loadState();
  const u = ensureUser(state, caller);
  rollDay(u, c);
  const limit = effectiveLimit(state, caller, c);
  const cap = Math.max(1, Math.min(5000, Number(c.maxRecords) || 100));
  const remain = limit > 0 ? Math.max(0, limit - u.dayCount) : null;
  const lines = [
    '📊 抽卡状态',
    limit > 0
      ? `今日已抽 ${u.dayCount} 次 ｜ 剩余 ${remain} 次（每天 ${resetHourOf(c)} 点重置）`
      : `今日已抽 ${u.dayCount} 次 ｜ 不限次数`,
    `5★ 保底 ${u.p5}/${FIVE_HARD} ｜ 4★ 保底 ${u.p4}/${FOUR_HARD}`,
    `记录 ${u.records.length} 条（上限 ${cap}）`
  ];
  const last = u.records[u.records.length - 1];
  if (last) lines.push(`最近：${last.kind} · ${summaryOf(last)} · ${formatTime(last.t)}`);
  return { content: lines.join('\n') };
}

async function doLimitsTool(ctx, args) {
  const action = String(args?.action || '').toLowerCase();
  if (!['set', 'clear', 'list'].includes(action)) {
    return { content: 'action 只能是 set / clear / list。', isError: true };
  }
  const caller = callerOf(ctx);
  if (!caller) return { content: '无法确定操作者身份（没有找到触发消息的发送者）。', isError: true };
  const perm = await callerIsGroupAdmin(ctx, caller);
  if (!perm.ok) {
    return { content: `只有群主或群管理员能改抽卡限额${perm.reason ? `（${perm.reason}）` : ''}。`, isError: true };
  }

  const state = loadState();
  const c = cfg();
  const target = String(args?.targetUserId ?? '').replace(/\D/g, '');
  if (action === 'list') {
    const entries = Object.entries(state.overrides || {});
    if (entries.length === 0) return { content: `目前没有单独的限额覆盖值，所有人都用全局默认：每人每天 ${globalLimitOf(c)} 次。` };
    const lines = [`当前限额覆盖值（全局默认：每人每天 ${globalLimitOf(c)} 次）：`];
    for (const [qq, v] of entries) lines.push(`· ${qq} → ${Number(v) === 0 ? '不限' : `每天 ${v} 次`}`);
    return { content: lines.join('\n') };
  }

  if (!/^\d{5,12}$/.test(target)) {
    return { content: 'targetUserId 必须是 5~12 位纯数字的 QQ 号。', isError: true };
  }
  if (action === 'clear') {
    if (state.overrides && state.overrides[target] !== undefined) {
      delete state.overrides[target];
      saveState(state);
      return { content: `已取消 ${target} 的单独限额，恢复全局默认（每人每天 ${globalLimitOf(c)} 次）。` };
    }
    return { content: `${target} 本来就没有单独的限额设置。` };
  }

  const limit = Number(args?.limit);
  if (!Number.isInteger(limit) || limit < 0 || limit > 10000) {
    return { content: 'limit 必须是 0~10000 的整数（0 表示不限）。', isError: true };
  }
  state.overrides = state.overrides || {};
  state.overrides[target] = limit;
  saveState(state);
  return { content: limit === 0 ? `已设置 ${target} 每天抽卡不限次数。` : `已设置 ${target} 每天最多抽 ${limit} 次。` };
}

// ── 抽卡算法（可被测试直接调用） ──

function softPity5(n) {
  if (n >= FIVE_HARD) return 1;
  return Math.min(1, FIVE_BASE + Math.max(0, n - (FIVE_SOFT_START - 1)) * 0.06);
}

function softPity4(n) {
  if (n >= FOUR_HARD) return 1;
  if (n === 9) return 0.561;
  return FOUR_BASE;
}

function pick(list) {
  return list[Math.floor(Math.random() * list.length)];
}

function doPull(u) {
  const n5 = (u.p5 || 0) + 1;
  const n4 = (u.p4 || 0) + 1;
  if (Math.random() < softPity5(n5)) {
    u.p5 = 0;
    u.p4 = n4;                       // 出 5★ 不重置 4★ 保底
    return { rank: 5, name: pick(POOL.five) };
  }
  if (Math.random() < softPity4(n4)) {
    u.p4 = 0;
    u.p5 = n5;
    return { rank: 4, name: pick(FOUR_POOL) };
  }
  u.p5 = n5;
  u.p4 = n4;
  return { rank: 3, name: pick(POOL.threeWeapons) };
}

// ── 状态与工具函数 ──

function blankState() {
  return { version: 1, users: {}, overrides: {} };
}

function loadState() {
  try {
    const j = JSON.parse(fs.readFileSync(STATE_FILE, 'utf8'));
    if (!j || typeof j !== 'object') return blankState();
    if (!j.users || typeof j.users !== 'object') j.users = {};
    if (!j.overrides || typeof j.overrides !== 'object') j.overrides = {};
    return j;
  } catch {
    return blankState();
  }
}

function saveState(state) {
  try {
    fs.mkdirSync(STATE_DIR, { recursive: true });
    const tmp = STATE_FILE + '.tmp';
    fs.writeFileSync(tmp, JSON.stringify(state), 'utf8');
    fs.renameSync(tmp, STATE_FILE);
  } catch (error) {
    log(`保存抽卡状态失败：${error?.message ?? error}`);
  }
}

function ensureUser(state, qq) {
  if (!state.users[qq]) {
    state.users[qq] = { p5: 0, p4: 0, dayKey: '', dayCount: 0, records: [] };
  }
  const u = state.users[qq];
  if (!Array.isArray(u.records)) u.records = [];
  return u;
}

function resetHourOf(c) {
  return Math.max(0, Math.min(23, Number(c.resetHour) ?? 4));
}

function dayKeyOf(now, resetHour) {
  const shifted = new Date(now - resetHour * 3600_000);
  const y = shifted.getFullYear();
  const m = String(shifted.getMonth() + 1).padStart(2, '0');
  const d = String(shifted.getDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
}

function rollDay(u, c) {
  const key = dayKeyOf(Date.now(), resetHourOf(c));
  if (u.dayKey !== key) {
    u.dayKey = key;
    u.dayCount = 0;
  }
}

function globalLimitOf(c) {
  return Math.max(0, Math.min(10000, Number(c.dailyLimit) ?? 10));
}

function effectiveLimit(state, qq, c) {
  const v = state.overrides?.[qq];
  if (v !== undefined && v !== null) {
    const n = Number(v);
    if (Number.isFinite(n)) return Math.max(0, Math.min(10000, n));
  }
  return globalLimitOf(c);
}

function callerOf(ctx) {
  const entries = Array.isArray(ctx?.session?.trigger) ? ctx.session.trigger : [];
  for (let i = entries.length - 1; i >= 0; i--) {
    const m = entries[i];
    const id = String(m?.senderId ?? '');
    if (id && id !== 'self' && /^\d{5,12}$/.test(id)) return id;
  }
  if (ctx?.kind === 'private' && /^\d{5,12}$/.test(String(ctx?.chatId ?? ''))) return String(ctx.chatId);
  return '';
}

async function callerIsGroupAdmin(ctx, caller) {
  if (String(ctx.kind) !== 'group') return { ok: false, reason: '该操作只能在群里使用' };
  try {
    const info = await ctx.onebot.call('get_group_member_info', {
      group_id: Number(ctx.chatId),
      user_id: Number(caller)
    });
    const role = String(info?.role || '').toLowerCase();
    if (role === 'owner' || role === 'admin') return { ok: true, role };
    return { ok: false, reason: `你是${role === 'member' ? '普通成员' : '未知身份'}，不是管理员` };
  } catch (error) {
    return { ok: false, reason: `查询群成员身份失败：${error?.message ?? error}` };
  }
}

function formatPullText(count, results, u, remaining, resetHour) {
  const lines = [`🎴 常驻祈愿 · ${count === 10 ? '十连' : '单抽'}`];
  if (results.length === 1) {
    const r = results[0];
    lines.push(`★${r.rank} ${r.name}`);
  } else {
    for (let i = 0; i < results.length; i++) {
      const r = results[i];
      lines.push(`${String(i + 1).padStart(2, '0')}. ★${r.rank} ${r.name}`);
    }
    const n5 = results.filter((x) => x.rank === 5).length;
    const n4 = results.filter((x) => x.rank === 4).length;
    lines.push(`本十连：★5 ×${n5} ｜ ★4 ×${n4}`);
  }
  lines.push(`5★ 保底 ${u.p5}/${FIVE_HARD} ｜ 4★ 保底 ${u.p4}/${FOUR_HARD}`);
  lines.push(remaining === null ? '今日不限次数' : remaining > 0 ? `今日剩余 ${remaining} 次` : '今日次数已用完');
  if (resetHour !== undefined) lines.push(`（每天 ${resetHour} 点重置）`);
  return lines.join('\n');
}

function summaryOf(rec) {
  const res = Array.isArray(rec?.res) ? rec.res : [];
  const n5 = res.filter((x) => x.r === 5).length;
  const n4 = res.filter((x) => x.r === 4).length;
  return `★5×${n5} ★4×${n4}`;
}

function formatTime(t) {
  try {
    return new Date(t).toLocaleString('zh-CN', { hour12: false });
  } catch {
    return String(t);
  }
}

// 仅供测试用（不影响运行）
export const _test = { doPull, softPity5, softPity4, dayKeyOf, effectiveLimit };
