// 文档工作台（doc-workshop）
//
// 定位：让机器人用自然语言撰写 / 修改 / 处理文档。
// 归在 skills/（LLM 型）——「什么时候该写文档」完全取决于用户说了什么话，
// 写不成规则，只能由模型理解语义后自己决定，因此唯一的接入方式是 registerTool。
//
// 每一条设计约束都是踩过坑才写上的：
//   1. 文档库落在**数据目录**（QQ_AGENT_DATA_DIR/documents），绝不放 skills/ 或 plugins/。
//      加载器对这两个目录做了 recursive 的 fs.watch —— 在里面写文档会触发
//      "存一次文档 → 全量重扫所有技能"的热重载风暴。
//   2. 所有路径 resolve 之后必须仍在文档库内，挡掉 ../../ 越界读写。
//   3. 编辑走"精准局部修改"，而不是让模型整篇重写 —— 重写全文时最容易把
//      没让动的段落悄悄改掉，这是文档助手最严重的失误。
//   4. 改动前自动留档到 _backups/，误改可回溯。
//   5. 读取带字符数与体积上限：会话上下文有限，整篇长文灌进去只会让模型丢了重点。

import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const HERE = path.dirname(fileURLToPath(import.meta.url));
// skills/<id>/index.js → ../.. = 应用根（resources/app），与核心 config.js 的 ROOT 同源
const APP_ROOT = path.resolve(HERE, '..', '..');

const TEXT_EXT = new Set([
  '.md', '.markdown', '.txt', '.text', '.csv', '.json',
  '.html', '.htm', '.yml', '.yaml', '.log', '.ini'
]);
const CONVERT_TO = new Set(['txt', 'md', 'html', 'json', 'csv']);
const DEFAULT_EXT = '.md';
const MAX_DEPTH = 4;
const BACKUP_DIR = '_backups';

let apiRef = null;

const ok = (payload) => ({
  content: typeof payload === 'string' ? payload : JSON.stringify(payload, null, 1)
});
const err = (message) => ({ content: `错误：${message}`, isError: true });

// ─────────────────────────── 配置与目录 ───────────────────────────

function conf() {
  let raw = {};
  try {
    if (apiRef && typeof apiRef.config === 'function') raw = apiRef.config() || {};
  } catch { raw = {}; }
  const num = (v, dft, lo, hi) => {
    const n = Number(v);
    if (!Number.isFinite(n)) return dft;
    return Math.max(lo, Math.min(hi, Math.round(n)));
  };
  return {
    docDir: String(raw.docDir ?? '').trim(),
    maxReadChars: num(raw.maxReadChars, 6000, 500, 40000),
    maxFileKB: num(raw.maxFileKB, 512, 16, 10240),
    keepBackups: num(raw.keepBackups, 10, 0, 100)
  };
}

/**
 * 数据目录。electron/main.js 在启动时就把权威路径写进了 QQ_AGENT_DATA_DIR
 * （安装版 = 安装目录/data，便携版 = 项目内 data/），技能与核心跑在同一进程里，
 * 读同一个环境变量即可，不必自己猜路径。
 */
function dataDir() {
  const env = String(process.env.QQ_AGENT_DATA_DIR || '').trim();
  if (env) return path.resolve(env);
  return path.join(APP_ROOT, 'data');
}

/** 文档库根目录（惰性创建）。 */
function docRoot() {
  const { docDir } = conf();
  const root = docDir ? path.resolve(docDir) : path.join(dataDir(), 'documents');
  fs.mkdirSync(root, { recursive: true });
  return root;
}

// ─────────────────────────── 路径安全 ───────────────────────────

const BAD_CHARS = /[<>:"|?*\u0000-\u001f]/g;
const RESERVED = /^(con|prn|aux|nul|com[1-9]|lpt[1-9])$/i;

function sanitizeSegment(seg) {
  let s = String(seg).replace(BAD_CHARS, '_').replace(/[. ]+$/, '').trim();
  if (!s) s = '未命名';
  if (RESERVED.test(s)) s = `_${s}`;
  return s.slice(0, 80);
}

/** 把用户/模型给的名字整成文档库内的相对路径（不解析、只净化）。 */
function sanitizeRel(name) {
  const raw = String(name ?? '').trim();
  if (!raw) throw new Error('文档名不能为空');
  const parts = raw.replace(/\\/g, '/').split('/')
    .filter((p) => p && p !== '.');
  if (!parts.length) throw new Error('文档名不能为空');
  if (parts.some((p) => p === '..')) throw new Error('文档名不能包含 ..');
  return parts.map(sanitizeSegment).join('/');
}

/**
 * 名字 → 绝对路径，并强制锁在文档库内。
 * sanitizeRel 已经剥掉了 ..，这里再做一次 resolve 后的包含性校验，
 * 防止符号链接或盘符之类的意外逃逸。
 */
function resolveInside(name) {
  const root = docRoot();
  const rel = sanitizeRel(name);
  const full = path.resolve(root, rel);
  const back = path.relative(root, full);
  if (!back || back.startsWith('..') || path.isAbsolute(back)) {
    throw new Error('路径越界：只能读写文档库内的文件');
  }
  return { root, full, rel: back.replace(/\\/g, '/') };
}

function ensureExt(rel) {
  return path.extname(rel) ? rel : rel + DEFAULT_EXT;
}

function statSize(full) {
  try { return fs.statSync(full).size; } catch { return -1; }
}

function readText(full) {
  const { maxFileKB } = conf();
  let st;
  try { st = fs.statSync(full); }
  catch { throw new Error(`文档不存在：${path.basename(full)}`); }
  if (!st.isFile()) throw new Error('目标不是文件');
  if (st.size > maxFileKB * 1024) {
    throw new Error(`文档 ${(st.size / 1024).toFixed(0)}KB 超过单文件上限 ${maxFileKB}KB（可在技能设置里调大）`);
  }
  let text = fs.readFileSync(full, 'utf8');
  if (text.charCodeAt(0) === 0xFEFF) text = text.slice(1);
  return text;
}

function writeText(full, text) {
  fs.mkdirSync(path.dirname(full), { recursive: true });
  fs.writeFileSync(full, text, 'utf8');
}

/** 改动前留档，返回备份的相对路径（未备份返回 null）。 */
function backupFile(full) {
  const { keepBackups } = conf();
  if (keepBackups <= 0) return null;
  if (!fs.existsSync(full)) return null;
  const root = docRoot();
  const rel = path.relative(root, full).replace(/\\/g, '/');
  const safeRel = rel.replace(/[/\\]/g, '__');
  const dir = path.join(root, BACKUP_DIR);
  // 时间戳必须带毫秒：同一次对话里连续改几处，秒级时间戳会互相覆盖，
  // 备份等于没备（实测就是这样，5 次编辑只剩 1 份）。
  const stamp = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 23);
  let target = path.join(dir, `${safeRel}.${stamp}.bak`);
  try {
    fs.mkdirSync(dir, { recursive: true });
    let n = 1;
    while (fs.existsSync(target)) target = path.join(dir, `${safeRel}.${stamp}-${n++}.bak`);
    fs.copyFileSync(full, target);
    const prefix = `${safeRel}.`;
    const list = fs.readdirSync(dir).filter((f) => f.startsWith(prefix) && f.endsWith('.bak')).sort();
    while (list.length > keepBackups) {
      const victim = list.shift();
      try { fs.unlinkSync(path.join(dir, victim)); } catch { /* 删不掉就算了 */ }
    }
  } catch { return null; }
  return `${BACKUP_DIR}/${path.basename(target)}`;
}

// ─────────────────────────── 文本分析 ───────────────────────────

function countChars(text) {
  // 按"可见字符"粗略统计：中文按字、英文按词更符合直觉，这里统一去空白后计数
  return String(text).replace(/\s+/g, '').length;
}

function parseHeadings(text) {
  const lines = String(text).replace(/\r\n?/g, '\n').split('\n');
  const heads = [];
  let inFence = false;
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    if (/^\s*(```|~~~)/.test(line)) { inFence = !inFence; continue; }
    if (inFence) continue;
    const m = /^(#{1,6})\s+(.+?)\s*#*\s*$/.exec(line);
    if (m) heads.push({ level: m[1].length, title: m[2].trim(), line: i + 1 });
  }
  return heads;
}

/**
 * 按标题定位章节。找不到时返回 near（相近标题列表），
 * 让模型自己纠正，而不是拿一个空结果瞎猜。
 */
function locateSection(text, query) {
  const heads = parseHeadings(text);
  const q = String(query ?? '').trim();
  if (!q) return { section: null, near: heads.map((h) => h.title) };
  if (!heads.length) return { section: null, near: [] };

  let idx = heads.findIndex((h) => h.title === q);
  if (idx < 0) idx = heads.findIndex((h) => h.title.includes(q));
  if (idx < 0) idx = heads.findIndex((h) => q.includes(h.title));
  if (idx < 0) {
    const key = q.replace(/\s+/g, '');
    idx = heads.findIndex((h) => h.title.replace(/\s+/g, '').includes(key));
  }
  if (idx < 0) return { section: null, near: heads.map((h) => h.title) };

  const lines = String(text).replace(/\r\n?/g, '\n').split('\n');
  const cur = heads[idx];
  let endLine = lines.length;
  for (let i = idx + 1; i < heads.length; i++) {
    if (heads[i].level <= cur.level) { endLine = heads[i].line - 1; break; }
  }
  while (endLine > cur.line && lines[endLine - 1].trim() === '') endLine--;
  return {
    section: {
      heading: cur,
      startLine: cur.line,
      endLine,
      body: lines.slice(cur.line, endLine).join('\n')
    },
    near: heads.map((h) => h.title)
  };
}

function outlineTree(heads) {
  return heads.map((h) => ({ level: h.level, title: h.title, line: h.line }));
}

// ─────────────────────────── 格式转换 ───────────────────────────

function mdToPlain(md) {
  let s = String(md ?? '').replace(/\r\n?/g, '\n');
  s = s.replace(/```[a-zA-Z0-9_+-]*\n?([\s\S]*?)```/g, (_, body) => body.replace(/\n+$/, ''));
  s = s.replace(/`([^`\n]+)`/g, '$1');
  s = s.replace(/!\[([^\]]*)\]\(([^)\s]+)\)/g, (_, alt) => alt || '');
  s = s.replace(/\[([^\]]+)\]\(([^)\s]+)\)/g, '$1 ($2)');
  s = s.replace(/\*\*\*([^*]+)\*\*\*/g, '$1')
    .replace(/\*\*([^*]+)\*\*/g, '$1')
    .replace(/(^|[^*])\*([^*\n]+)\*/g, '$1$2')
    .replace(/~~([^~]+)~~/g, '$1')
    .replace(/__([^_]+)__/g, '$1');
  s = s.replace(/^#{1,6}\s+/gm, '');
  s = s.replace(/^>\s?/gm, '');
  s = s.replace(/^\s*[-*+]\s+/gm, '· ');
  s = s.replace(/^\s*\|/gm, '').replace(/\|\s*$/gm, '');
  s = s.replace(/^\s*(:?-{2,}:?\s*)+\|\s*$/gm, '');
  s = s.replace(/^\s*[-=]{3,}\s*$/gm, '');
  s = s.replace(/\n{3,}/g, '\n\n');
  return s.trim();
}

function escapeHtml(s) {
  return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;')
    .replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

function inlineMd(s) {
  let t = escapeHtml(s);
  t = t.replace(/`([^`]+)`/g, '<code>$1</code>');
  t = t.replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>');
  t = t.replace(/(^|[^*])\*([^*\n]+)\*/g, '$1<em>$2</em>');
  t = t.replace(/\[([^\]]+)\]\(([^)\s]+)\)/g, '<a href="$2" rel="noreferrer noopener">$1</a>');
  return t;
}

function mdToHtml(md, title) {
  const lines = String(md).replace(/\r\n?/g, '\n').split('\n');
  const out = [];
  let inCode = false;
  let codeBuf = [];
  let listType = null;
  const closeList = () => { if (listType) { out.push(`</${listType}>`); listType = null; } };

  for (const line of lines) {
    if (/^\s*(```|~~~)/.test(line)) {
      if (inCode) {
        out.push(`<pre><code>${escapeHtml(codeBuf.join('\n'))}</code></pre>`);
        codeBuf = []; inCode = false;
      } else { closeList(); inCode = true; }
      continue;
    }
    if (inCode) { codeBuf.push(line); continue; }
    if (!line.trim()) { closeList(); continue; }

    const h = /^(#{1,6})\s+(.*)$/.exec(line);
    if (h) { closeList(); const lv = h[1].length; out.push(`<h${lv}>${inlineMd(h[2])}</h${lv}>`); continue; }
    if (/^\s*>\s?/.test(line)) { closeList(); out.push(`<blockquote>${inlineMd(line.replace(/^\s*>\s?/, ''))}</blockquote>`); continue; }
    if (/^\s*[-*+]\s+/.test(line)) {
      if (listType !== 'ul') { closeList(); out.push('<ul>'); listType = 'ul'; }
      out.push(`<li>${inlineMd(line.replace(/^\s*[-*+]\s+/, ''))}</li>`); continue;
    }
    if (/^\s*\d+[.)]\s+/.test(line)) {
      if (listType !== 'ol') { closeList(); out.push('<ol>'); listType = 'ol'; }
      out.push(`<li>${inlineMd(line.replace(/^\s*\d+[.)]\s+/, ''))}</li>`); continue;
    }
    if (/^\s*([-*_]\s*){3,}$/.test(line)) { closeList(); out.push('<hr>'); continue; }
    closeList();
    out.push(`<p>${inlineMd(line)}</p>`);
  }
  if (inCode && codeBuf.length) out.push(`<pre><code>${escapeHtml(codeBuf.join('\n'))}</code></pre>`);
  closeList();

  const t = escapeHtml(title || '文档');
  return [
    '<!DOCTYPE html>',
    '<html lang="zh-CN"><head><meta charset="utf-8">',
    `<meta name="viewport" content="width=device-width,initial-scale=1">`,
    `<title>${t}</title>`,
    '<style>',
    'body{max-width:760px;margin:40px auto;padding:0 20px;line-height:1.75;',
    'font-family:-apple-system,"Segoe UI","Microsoft YaHei",sans-serif;color:#1f2328;}',
    'h1,h2,h3{line-height:1.3;margin:1.6em 0 .6em;}',
    'h1{border-bottom:1px solid #e5e7eb;padding-bottom:.3em;}',
    'code{background:#f3f4f6;padding:.15em .35em;border-radius:4px;font-size:.92em;}',
    'pre{background:#f6f8fa;padding:14px;border-radius:8px;overflow:auto;}',
    'pre code{background:none;padding:0;}',
    'blockquote{margin:1em 0;padding:.2em 1em;border-left:4px solid #d0d7de;color:#57606a;}',
    'hr{border:none;border-top:1px solid #e5e7eb;margin:2em 0;}',
    'a{color:#0969da;}',
    '</style></head><body>',
    out.join('\n'),
    '</body></html>'
  ].join('\n');
}

function parseCsv(text) {
  const s = String(text).replace(/^\uFEFF/, '').replace(/\r\n?/g, '\n');
  const rows = [];
  let row = [];
  let field = '';
  let quoted = false;
  let i = 0;
  while (i < s.length) {
    const c = s[i];
    if (quoted) {
      if (c === '"') {
        if (s[i + 1] === '"') { field += '"'; i += 2; continue; }
        quoted = false; i++; continue;
      }
      field += c; i++; continue;
    }
    if (c === '"' && field === '') { quoted = true; i++; continue; }
    if (c === ',') { row.push(field); field = ''; i++; continue; }
    if (c === '\n') { row.push(field); rows.push(row); row = []; field = ''; i++; continue; }
    field += c; i++;
  }
  if (field !== '' || row.length) { row.push(field); rows.push(row); }
  return rows.filter((r) => r.some((x) => String(x).trim() !== ''));
}

function csvCell(v) {
  const s = v === null || v === undefined ? '' : String(v);
  return /[",\n\r]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
}

function toCsv(rows) {
  return rows.map((r) => r.map(csvCell).join(',')).join('\n');
}

function jsonToRows(json) {
  const data = typeof json === 'string' ? JSON.parse(json) : json;
  if (!Array.isArray(data)) {
    if (data && typeof data === 'object') return [Object.keys(data), Object.values(data)];
    throw new Error('JSON 不是数组或对象，无法转成表格');
  }
  const objs = data.filter((x) => x && typeof x === 'object' && !Array.isArray(x));
  if (!objs.length) throw new Error('JSON 数组里没有对象，无法转成表格');
  const keys = [];
  for (const o of objs) for (const k of Object.keys(o)) if (!keys.includes(k)) keys.push(k);
  return [keys, ...objs.map((o) => keys.map((k) => (o[k] === undefined || o[k] === null ? '' : o[k])))];
}

function rowsToJson(rows) {
  if (!rows.length) return '[]';
  const [head, ...body] = rows;
  const out = body.map((r) => {
    const o = {};
    head.forEach((k, i) => { o[String(k).trim() || `列${i + 1}`] = r[i] ?? ''; });
    return o;
  });
  return JSON.stringify(out, null, 2);
}

function rowsToMarkdown(rows) {
  if (!rows.length) return '';
  const [head, ...body] = rows;
  const line = (cells) => `| ${cells.map((c) => String(c ?? '').replace(/\|/g, '\\|')).join(' | ')} |`;
  return [line(head), `| ${head.map(() => '---').join(' | ')} |`, ...body.map(line)].join('\n');
}

/** 执行一次转换：返回 { text, ext }。 */
function convertContent(fromExt, to, content, title) {
  const src = String(fromExt || '').toLowerCase();
  switch (to) {
    case 'txt':
      if (src === '.json') return { text: jsonToRowsSafe(content).map((r) => r.join('\t')).join('\n'), ext: '.txt' };
      if (src === '.csv') return { text: parseCsv(content).map((r) => r.join('\t')).join('\n'), ext: '.txt' };
      return { text: mdToPlain(content), ext: '.txt' };

    case 'html':
      if (src === '.json' || src === '.csv') {
        const rows = src === '.json' ? jsonToRowsSafe(content) : parseCsv(content);
        return { text: mdToHtml(rowsToMarkdown(rows), title), ext: '.html' };
      }
      return { text: mdToHtml(content, title), ext: '.html' };

    case 'json':
      if (src === '.csv') return { text: rowsToJson(parseCsv(content)), ext: '.json' };
      if (src === '.md' || src === '.txt') {
        const rows = mdTableToRows(content);
        if (!rows) throw new Error('这篇文档里没有找到 Markdown 表格，无法转成 JSON');
        return { text: rowsToJson(rows), ext: '.json' };
      }
      return { text: JSON.stringify(JSON.parse(content), null, 2), ext: '.json' };

    case 'csv':
      if (src === '.json') return { text: toCsv(jsonToRows(content)), ext: '.csv' };
      if (src === '.md' || src === '.txt') {
        const rows = mdTableToRows(content);
        if (!rows) throw new Error('这篇文档里没有找到 Markdown 表格，无法转成 CSV');
        return { text: toCsv(rows), ext: '.csv' };
      }
      return { text: toCsv(parseCsv(content)), ext: '.csv' };

    case 'md':
      if (src === '.csv') return { text: rowsToMarkdown(parseCsv(content)), ext: '.md' };
      if (src === '.json') return { text: rowsToMarkdown(jsonToRows(content)), ext: '.md' };
      if (src === '.html' || src === '.htm') {
        const text = content.replace(/<script[\s\S]*?<\/script>/gi, '')
          .replace(/<style[\s\S]*?<\/style>/gi, '')
          .replace(/<br\s*\/?>/gi, '\n').replace(/<\/(p|div|li|h[1-6])>/gi, '\n')
          .replace(/<[^>]+>/g, '')
          .replace(/&nbsp;/g, ' ').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&amp;/g, '&');
        return { text: text.replace(/\n{3,}/g, '\n\n').trim(), ext: '.md' };
      }
      return { text: content, ext: '.md' };

    default:
      throw new Error(`不支持的转换目标：${to}`);
  }
}

function jsonToRowsSafe(content) {
  try { return jsonToRows(content); } catch { return []; }
}

/** 从 Markdown 文本里抽出第一个表格，转成二维数组。 */
function mdTableToRows(md) {
  const lines = String(md).replace(/\r\n?/g, '\n').split('\n');
  const block = [];
  let started = false;
  for (const line of lines) {
    const isRow = /^\s*\|.*\|\s*$/.test(line.trim());
    if (isRow) { started = true; block.push(line.trim()); continue; }
    if (started) break;
  }
  if (block.length < 2) return null;
  const split = (l) => l.replace(/^\|/, '').replace(/\|$/, '')
    .split('|').map((c) => c.trim().replace(/\\\|/g, '|'));
  const head = split(block[0]);
  const body = block.slice(1)
    .filter((l) => !/^\|?[\s:|-]+\|?$/.test(l))
    .map(split);
  return [head, ...body];
}

// ─────────────────────────── 工具实现 ───────────────────────────

function listFiles(root, dir, out, depth) {
  if (depth > MAX_DEPTH) return;
  let entries;
  try { entries = fs.readdirSync(dir, { withFileTypes: true }); } catch { return; }
  for (const e of entries) {
    if (e.name.startsWith('.') || e.name === BACKUP_DIR) continue;
    const full = path.join(dir, e.name);
    if (e.isDirectory()) { listFiles(root, full, out, depth + 1); continue; }
    if (!e.isFile()) continue;
    if (!TEXT_EXT.has(path.extname(e.name).toLowerCase())) continue;
    let st;
    try { st = fs.statSync(full); } catch { continue; }
    out.push({
      path: path.relative(root, full).replace(/\\/g, '/'),
      sizeKB: Math.round(st.size / 1024 * 10) / 10,
      mtime: st.mtime
    });
  }
}

function fmtTime(d) {
  const p = (n) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())} ${p(d.getHours())}:${p(d.getMinutes())}`;
}

export async function setup(api) {
  apiRef = api;

  // ── 1. 列出 / 搜索文档 ────────────────────────────────────────────
  api.registerTool({
    id: 'doc_list',
    name: '列出文档',
    description: '列出文档库里的文档。想知道"有哪些文档""之前那份 XX 在哪"，或按正文关键词找文档时用。改文档前如果不确定文档名，先用这个查。',
    category: 'query',
    icon: '📁',
    parameters: {
      type: 'object',
      properties: {
        keyword: { type: 'string', description: '按文件名/路径模糊筛选（可选）' },
        content: { type: 'string', description: '按正文内容搜索关键词，返回命中文件与命中行（可选）' },
        limit: { type: 'integer', description: '最多返回多少条，默认 50', minimum: 1, maximum: 200 }
      }
    },
    async execute(_ctx, args = {}) {
      try {
        const root = docRoot();
        const limit = Math.max(1, Math.min(200, Number(args.limit) || 50));
        const files = [];
        listFiles(root, root, files, 0);
        files.sort((a, b) => b.mtime - a.mtime);

        const kw = String(args.keyword ?? '').trim().toLowerCase();
        let hits = kw ? files.filter((f) => f.path.toLowerCase().includes(kw)) : files;

        const search = String(args.content ?? '').trim();
        const withContent = [];
        if (search) {
          const needle = search.toLowerCase();
          for (const f of hits.slice(0, 200)) {
            let text = '';
            try { text = readText(path.join(root, f.path)); } catch { continue; }
            const matched = [];
            text.replace(/\r\n?/g, '\n').split('\n').forEach((line, i) => {
              if (matched.length < 3 && line.toLowerCase().includes(needle)) {
                matched.push({ line: i + 1, text: line.trim().slice(0, 120) });
              }
            });
            if (matched.length) withContent.push({ ...f, matched });
          }
          hits = withContent.map(({ matched, ...f }) => f);
        }

        const total = hits.length;
        const shown = hits.slice(0, limit).map((f) => ({
          path: f.path,
          sizeKB: f.sizeKB,
          modified: fmtTime(f.mtime),
          ...(search ? { matched: withContent.find((x) => x.path === f.path)?.matched } : {})
        }));

        return ok({
          root,
          total,
          shown: shown.length,
          files: shown,
          hint: total > shown.length ? `只显示了前 ${shown.length} 篇，可用 keyword 缩小范围。` : undefined,
          empty: total === 0 ? '文档库里没有匹配的文档。要新建就直接用 doc_write。' : undefined
        });
      } catch (error) {
        return err(error?.message ?? error);
      }
    }
  });

  // ── 2. 读取文档 ──────────────────────────────────────────────────
  api.registerTool({
    id: 'doc_read',
    name: '读取文档',
    description: '读取文档正文。**改文档之前必须先读**，不能凭印象改。长文档先用 doc_outline 看结构，再用 heading 只读要改的那一节，避免把整篇灌进上下文。',
    category: 'query',
    icon: '📖',
    parameters: {
      type: 'object',
      properties: {
        name: { type: 'string', description: '文档名（可用 子目录/文件名 的形式）' },
        heading: { type: 'string', description: '只读某一节：填该节标题的文字（可用部分匹配）。与 startLine/endLine 二选一' },
        startLine: { type: 'integer', description: '起始行号，从 1 开始（可选）' },
        endLine: { type: 'integer', description: '结束行号，含该行（可选）' },
        withLineNumbers: { type: 'boolean', description: '是否在每行前显示行号（默认否）' }
      },
      required: ['name']
    },
    async execute(_ctx, args = {}) {
      try {
        const { full, rel } = resolveInside(ensureExt(args.name));
        const text = readText(full);
        const lines = text.replace(/\r\n?/g, '\n').split('\n');
        const total = lines.length;
        const { maxReadChars } = conf();

        let start = 1;
        let end = total;
        let sectionInfo = null;

        if (args.heading) {
          const { section, near } = locateSection(text, args.heading);
          if (!section) {
            return ok({
              name: rel,
              found: false,
              sections: near,
              note: '没有找到这个标题。上面是这篇文档里实际有的标题，请从中选一个再读。'
            });
          }
          start = section.startLine;
          end = section.endLine;
          sectionInfo = { title: section.heading.title, level: section.heading.level };
        } else if (Number(args.startLine) > 0) {
          start = Math.max(1, Math.round(Number(args.startLine)));
          end = Number(args.endLine) > 0 ? Math.round(Number(args.endLine)) : Math.min(total, start + 200);
          end = Math.min(end, total);
          if (end < start) end = start;
        }

        let slice = lines.slice(start - 1, end);
        let body = slice.join('\n');
        let truncated = false;
        if (body.length > maxReadChars) {
          body = body.slice(0, maxReadChars);
          truncated = true;
        }
        if (args.withLineNumbers) {
          body = body.split('\n').map((l, i) => `${start + i}| ${l}`).join('\n');
        }

        return ok({
          name: rel,
          totalLines: total,
          totalChars: countChars(text),
          headings: parseHeadings(text).length,
          range: [start, end],
          truncated,
          content: body,
          note: truncated
            ? `内容超过单次读取上限 ${maxReadChars} 字已截断。请用 heading 只读需要的那一节，或用 startLine/endLine 分段读。`
            : undefined,
          section: sectionInfo ?? undefined
        });
      } catch (error) {
        return err(error?.message ?? error);
      }
    }
  });

  // ── 3. 大纲与统计 ────────────────────────────────────────────────
  api.registerTool({
    id: 'doc_outline',
    name: '查看文档大纲',
    description: '列出文档的标题结构（带行号）和字数/段落统计。长文档开工前先看大纲，再决定读哪一节，比整篇读省得多。',
    category: 'query',
    icon: '🧭',
    parameters: {
      type: 'object',
      properties: {
        name: { type: 'string', description: '文档名' }
      },
      required: ['name']
    },
    async execute(_ctx, args = {}) {
      try {
        const { full, rel } = resolveInside(ensureExt(args.name));
        const text = readText(full);
        const lines = text.replace(/\r\n?/g, '\n').split('\n');
        const heads = parseHeadings(text);
        const nonEmpty = lines.filter((l) => l.trim() !== '').length;
        return ok({
          name: rel,
          totalLines: lines.length,
          paragraphs: nonEmpty,
          chars: countChars(text),
          headings: outlineTree(heads),
          note: heads.length
            ? '用 doc_read 传 heading 只读某一节。'
            : '这篇文档没有 Markdown 标题。可以直接 doc_read 整篇（或按 startLine/endLine 分段）。'
        });
      } catch (error) {
        return err(error?.message ?? error);
      }
    }
  });

  // ── 4. 新建 / 覆盖 / 追加 ─────────────────────────────────────────
  api.registerTool({
    id: 'doc_write',
    name: '写入文档',
    description: '把整理好的正文写进文档库。默认 mode=create：文档已存在会拒绝（防止误覆盖别人正在用的文档）。确实要整篇重写才用 overwrite；只想在末尾加内容用 append。只想改局部请用 doc_edit，不要用 overwrite 重写全文。',
    category: 'utility',
    icon: '✍️',
    parameters: {
      type: 'object',
      properties: {
        name: { type: 'string', description: '文档名，如 会议纪要/2026-10-07.md（不写扩展名默认 .md）' },
        content: { type: 'string', description: '正文内容，Markdown 格式' },
        mode: { type: 'string', enum: ['create', 'overwrite', 'append'], description: 'create=新建（默认，已存在则报错）；overwrite=整篇覆盖；append=追加到末尾' }
      },
      required: ['name', 'content']
    },
    async execute(_ctx, args = {}) {
      try {
        const mode = ['create', 'overwrite', 'append'].includes(args.mode) ? args.mode : 'create';
        const { full, rel } = resolveInside(ensureExt(args.name));
        const body = String(args.content ?? '');
        if (!body.trim() && mode !== 'append') return err('正文是空的，没有内容可写');

        const exists = fs.existsSync(full);
        if (mode === 'create' && exists) {
          return err(`文档「${rel}」已存在。要整篇重写用 mode=overwrite；只改局部请用 doc_edit；只想加内容用 mode=append。`);
        }
        if (mode === 'overwrite') {
          const size = statSize(full);
          if (size > 0) {
            const stripped = mdToPlain(readText(full)).replace(/\s+/g, '').length;
            const next = mdToPlain(body).replace(/\s+/g, '').length;
            // 长文档被整篇覆盖成短文，几乎都是"模型重写全文时丢了内容"，
            // 这是文档助手最有破坏力的失误 —— 宁可拒绝并建议改用 doc_edit。
            if (stripped >= 100 && next < stripped * 0.35) {
              return err(`拒绝对「${rel}」整篇覆盖：原文约 ${stripped} 字，新内容只有约 ${next} 字，疑似内容丢失。如果确实要大幅精简，请改用 doc_edit 逐段修改；确认要清空重写，请先把新内容写全。`);
            }
          }
        }

        const backedUp = exists && mode !== 'create' ? backupFile(full) : null;
        let finalText = body;
        if (mode === 'append' && exists) {
          const old = readText(full);
          finalText = old.replace(/\s*$/, '') + '\n\n' + body.replace(/^\s+/, '');
        }
        writeText(full, finalText);

        return ok({
          name: rel,
          action: mode,
          chars: countChars(finalText),
          lines: finalText.split('\n').length,
          backup: backedUp ?? undefined,
          note: '已保存。回复对方时用一两句话说明写了什么、存在哪，不要把全文再复述一遍。'
        });
      } catch (error) {
        return err(error?.message ?? error);
      }
    }
  });

  // ── 5. 局部编辑 ──────────────────────────────────────────────────
  api.registerTool({
    id: 'doc_edit',
    name: '编辑文档',
    description: '对已有文档做精准局部修改（改文档的默认方式）。op 取值：replace=替换一段文字；append=末尾追加；prepend=开头插入；insertAfterHeading=在某节末尾插入；replaceSection=整节替换；deleteSection=删除整节。会自动留存旧版本到 _backups。',
    category: 'utility',
    icon: '🔧',
    parameters: {
      type: 'object',
      properties: {
        name: { type: 'string', description: '文档名' },
        op: { type: 'string', enum: ['replace', 'append', 'prepend', 'insertAfterHeading', 'replaceSection', 'deleteSection'], description: '操作类型' },
        find: { type: 'string', description: 'op=replace 时要被替换的原文（必须与文档里的文字完全一致，含标点）' },
        replaceWith: { type: 'string', description: 'op=replace 时替换成的新文字；传空字符串表示删除这段' },
        all: { type: 'boolean', description: 'op=replace 时是否替换全部匹配（默认否，只允许唯一匹配，防止误伤）' },
        heading: { type: 'string', description: 'op=insertAfterHeading/replaceSection/deleteSection 时的章节标题' },
        text: { type: 'string', description: 'op=append/prepend/insertAfterHeading/replaceSection 时要写入的内容' }
      },
      required: ['name', 'op']
    },
    async execute(_ctx, args = {}) {
      try {
        const { full, rel } = resolveInside(ensureExt(args.name));
        const original = readText(full);
        // 统一成 \n 再操作：doc_read 返回给模型的就是归一化文本，模型给出的 find
        // 必然按 \n 写；直接在混合行尾的原串上匹配会莫名其妙找不到。最后按原样还原。
        const eol = original.includes('\r\n') ? '\r\n' : '\n';
        let text = original.replace(/\r\n?/g, '\n');
        let detail = '';

        switch (args.op) {
          case 'replace': {
            const find = String(args.find ?? '');
            if (!find) return err('op=replace 必须提供 find（要替换的原文）');
            const idx = text.indexOf(find);
            if (idx < 0) {
              return err(`在「${rel}」里找不到这段原文。请先用 doc_read 确认文字（注意标点、空格、换行必须完全一致），再重试。`);
            }
            const count = text.split(find).length - 1;
            if (count > 1 && args.all !== true) {
              return err(`这段文字在文档里出现了 ${count} 处，无法确定改哪一处。请把 find 写得更长更具体（带上前后文）让它唯一；确实要全部替换就传 all=true。`);
            }
            const to = String(args.replaceWith ?? '');
            text = args.all === true ? text.split(find).join(to) : text.slice(0, idx) + to + text.slice(idx + find.length);
            detail = `替换 ${args.all === true ? count : 1} 处`;
            break;
          }
          case 'append': {
            const body = String(args.text ?? '');
            if (!body.trim()) return err('op=append 必须提供 text');
            text = text.replace(/\s*$/, '') + '\n\n' + body.replace(/^\s+/, '');
            detail = '末尾追加';
            break;
          }
          case 'prepend': {
            const body = String(args.text ?? '');
            if (!body.trim()) return err('op=prepend 必须提供 text');
            text = body.replace(/\s*$/, '') + '\n\n' + text.replace(/^\s+/, '');
            detail = '开头插入';
            break;
          }
          case 'insertAfterHeading': {
            const { section, near } = locateSection(text, args.heading);
            if (!section) {
              return err(`找不到章节「${args.heading}」。这篇文档现有的标题是：${near.join(' / ') || '（无标题）'}`);
            }
            const lines = text.split('\n');
            const at = section.endLine;
            const body = String(args.text ?? '');
            if (!body.trim()) return err('op=insertAfterHeading 必须提供 text');
            lines.splice(at, 0, '', body.replace(/\s*$/, ''));
            text = lines.join('\n');
            detail = `在「${section.heading.title}」末尾插入`;
            break;
          }
          case 'replaceSection': {
            const body = String(args.text ?? '');
            const { section, near } = locateSection(text, args.heading);
            if (!section) {
              return err(`找不到章节「${args.heading}」。这篇文档现有的标题是：${near.join(' / ') || '（无标题）'}`);
            }
            const lines = text.split('\n');
            const head = lines[section.startLine - 1];
            lines.splice(section.startLine - 1, section.endLine - section.startLine + 1, head, '', body.replace(/\s*$/, ''));
            text = lines.join('\n').replace(/\n{3,}/g, '\n\n');
            detail = `整节替换「${section.heading.title}」`;
            break;
          }
          case 'deleteSection': {
            const { section, near } = locateSection(text, args.heading);
            if (!section) {
              return err(`找不到章节「${args.heading}」。这篇文档现有的标题是：${near.join(' / ') || '（无标题）'}`);
            }
            const lines = text.split('\n');
            lines.splice(section.startLine - 1, section.endLine - section.startLine + 1);
            text = lines.join('\n').replace(/\n{3,}/g, '\n\n');
            detail = `删除整节「${section.heading.title}」`;
            break;
          }
          default:
            return err('op 必须是 replace / append / prepend / insertAfterHeading / replaceSection / deleteSection 之一');
        }

        const backup = backupFile(full);
        writeText(full, eol === '\n' ? text : text.replace(/\n/g, eol));
        return ok({
          name: rel,
          op: args.op,
          detail,
          charsBefore: countChars(original),
          charsAfter: countChars(text),
          backup: backup ?? undefined,
          note: '改动已保存。用一两句话说明改了什么即可。'
        });
      } catch (error) {
        return err(error?.message ?? error);
      }
    }
  });

  // ── 6. 格式转换 ──────────────────────────────────────────────────
  api.registerTool({
    id: 'doc_convert',
    name: '转换文档格式',
    description: '把文档转成别的格式：md（Markdown）、txt（纯文本，适合直接发到 QQ）、html（网页，带样式）、json、csv。默认另存为新文档；传 inline=true 则直接把转换结果返回给你（适合"把这篇转成纯文本发我"）。',
    category: 'utility',
    icon: '🔄',
    parameters: {
      type: 'object',
      properties: {
        name: { type: 'string', description: '源文档名' },
        to: { type: 'string', enum: ['txt', 'md', 'html', 'json', 'csv'], description: '目标格式' },
        outputName: { type: 'string', description: '输出的文档名（可选，默认同名换扩展名）' },
        inline: { type: 'boolean', description: 'true=不存文件，直接返回转换后的内容（默认 false，会另存一份）' }
      },
      required: ['name', 'to']
    },
    async execute(_ctx, args = {}) {
      try {
        const to = String(args.to ?? '').toLowerCase().replace(/^\./, '');
        if (!CONVERT_TO.has(to)) return err('to 只能是 txt / md / html / json / csv');

        const { full, rel } = resolveInside(ensureExt(args.name));
        const content = readText(full);
        const fromExt = path.extname(rel).toLowerCase();
        const title = path.basename(rel, path.extname(rel));
        const { text, ext } = convertContent(fromExt, to, content, title);

        if (args.inline === true) {
          const { maxReadChars } = conf();
          return ok({
            name: rel,
            to,
            chars: countChars(text),
            truncated: text.length > maxReadChars,
            content: text.length > maxReadChars ? text.slice(0, maxReadChars) : text
          });
        }

        const outRel = ensureExt(args.outputName
          ? sanitizeRel(args.outputName)
          : rel.replace(/\.[^./\\]+$/, '') + ext);
        const out = resolveInside(outRel);
        if (out.full === full) return err('输出名和源文档是同一个文件，请用 outputName 换个名字，或传其他目标格式。');
        const backedUp = fs.existsSync(out.full) ? backupFile(out.full) : null;
        writeText(out.full, text);

        return ok({
          name: out.rel,
          from: rel,
          to,
          chars: countChars(text),
          backup: backedUp ?? undefined,
          note: '已另存为新文档，原文档未改动。'
        });
      } catch (error) {
        return err(error?.message ?? error);
      }
    }
  });
}
