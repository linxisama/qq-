// hunt-mmr —— 在 bayouledger.com（The Bayou Ledger）查询 Hunt: Showdown 1896 玩家 MMR。
//
// 类型：LLM 型技能（skills/）——registerTool 注册查询工具，由模型判断何时调用；
// 提示词片段（skill.json 的 prompt.sections）指导它查完后用 send_message @提问者。
//
// v1.1.0（社区版）：解析全部属性顺序无关（class/href、meta 的 name/content 两种
// 先后都认）+ player 类缺失时的兜底锚点口径 + 多个同名玩家不再默默取第一个 +
// 文案去人设化（任何机器人都能用，不绑定特定人设名）。
//
// 数据来源全部是服务端渲染的 HTML，无需认证：
//   搜索：GET /?q=<名字>            → 结果行 <a class="player" href="/p/<steamId>">…名字…</a>
//   档案：GET /p/<steamId>          → meta description 概览行（MMR/KD/kills/deaths/bounty）
//                                    + og:title 玩家名 + title="MMR 4/6" 星级
//                                    + aria-label="Rank 13820 of 27534, top 51%" 排名
//                                    + sub-key "Updated" 的 sub-val 更新时间
//
// 实现约定：
//   · 全量内联、零子模块 import——加载器只对入口做 ?t= 缓存击穿，静态 import 的
//     辅助文件热重载后跑的还是旧模块（whale-voice/repeat-echo 都踩过）。
//   · 所有异常都捕获成 { isError } 返回，绝不抛出——抛了会把整个工具调用回合打断。
//   · 站点是别人的免费服务：带超时、带缓存、失败只试一次，不重试轰炸。

let api = null;

const SITE = 'https://bayouledger.com';
const TIMEOUT_MS = 15_000;
const UA_HEADERS = {
  'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36',
  'Accept': 'text/html,application/xhtml+xml',
  'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8'
};

// steamId -> { at, text }：短缓存，防止模型短时间反复查同一个人
const profileCache = new Map();

/** 带超时的 GET，返回 HTML 文本。 */
async function httpGet(url) {
  const doFetch = api?.fetch;
  const ac = new AbortController();
  const timer = setTimeout(() => ac.abort(), TIMEOUT_MS);
  try {
    const res = await doFetch(url, { headers: UA_HEADERS, signal: ac.signal });
    if (!res.ok) throw new Error(`站点返回 HTTP ${res.status}`);
    return await res.text();
  } finally {
    clearTimeout(timer);
  }
}

function decodeEntities(s) {
  return String(s ?? '')
    .replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/&nbsp;/g, ' ');
}

function stripTags(html) {
  return decodeEntities(String(html ?? '').replace(/<[^>]*>/g, ' ')).replace(/\s+/g, ' ').trim();
}

/** 解析搜索结果页：抽出玩家列表 [{ steamId, name }]。属性顺序无关（class 在前或 href 在前都认）。 */
function parseSearch(html) {
  const strict = [];
  const loose = [];
  const seen = new Set();
  // ① 严格口径：锚点带 player 类（class 与 href 两种先后顺序都匹配）
  const reStrict = /<a[^>]*?(?:class="[^"]*\bplayer\b[^"]*"[^>]*href="\/p\/(\d{5,25})"|href="\/p\/(\d{5,25})"[^>]*class="[^"]*\bplayer\b[^"]*")[^>]*>([\s\S]*?)<\/a>/g;
  let m;
  while ((m = reStrict.exec(html)) !== null) {
    const id = m[1] || m[2];
    const name = stripTags(m[3]);
    if (id && name && !seen.has(id)) { seen.add(id); strict.push({ steamId: id, name }); }
  }
  if (strict.length) return strict.slice(0, 10);
  // ② 兜底口径：站点若去掉 player 类，退回"任何 /p/ 锚点 + 非空锚文本"
  //    （宁可多给候选让提问者确认，也不直接查不到；上限压到 6 防止侧栏污染）
  const reLoose = /<a\b[^>]*href="\/p\/(\d{5,25})"[^>]*>([\s\S]*?)<\/a>/g;
  while ((m = reLoose.exec(html)) !== null && loose.length < 6) {
    const name = stripTags(m[2]);
    if (name) loose.push({ steamId: m[1], name });
  }
  return loose;
}

/** 取 <meta> 的 content，属性顺序无关（name 在前或 content 在前都认）。 */
function metaContent(html, keyAttr, keyVal) {
  const re1 = new RegExp(`<meta\\s+${keyAttr}="${keyVal}"[^>]*content="([^"]*)"`, 'i');
  const re2 = new RegExp(`<meta\\s+content="([^"]*)"[^>]*${keyAttr}="${keyVal}"`, 'i');
  return decodeEntities((html.match(re1) || html.match(re2) || [])[1] || '');
}

/** 解析档案页：MMR / 星级 / 排名 / KD / 更新时间。主口径是 meta description（始终英文、结构稳定），结构化 span 做兜底。 */
function parseProfile(html) {
  const d = {};
  const desc = metaContent(html, 'name', 'description');

  let mmr = '';
  let m = desc.match(/MMR\s+([\d\s,\u00a0]+?)(?=\s*·|\s*$)/);
  if (m) mmr = m[1].replace(/[\s,\u00a0]/g, '');
  if (!mmr) {
    m = html.match(/MMR<\/dt>\s*<dd[^>]*>\s*<span[^>]*class="[^"]*stat-val[^"]*"[^>]*>([^<]+)<\/span>/);
    if (m) mmr = m[1].replace(/[\s,\u00a0]/g, '');
  }
  if (mmr) d.mmr = mmr;

  m = desc.match(/KD\s+([\d.]+)/) || html.match(/\bKD<\/dt>\s*<dd[^>]*>\s*<span[^>]*>([\d.]+)</);
  if (m) d.kd = m[1];

  m = desc.match(/([\d,]+)\s+kills?\b/i);
  if (m) d.kills = m[1];
  m = desc.match(/([\d,]+)\s+deaths?\b/i);
  if (m) d.deaths = m[1];

  m = desc.match(/([\d,]+)\s+bounty\b/i);
  if (m) d.bounty = m[1];

  d.name = metaContent(html, 'property', 'og:title').trim();

  // 星级：title="MMR 4/6" 优先，aria-label="4 of 6 matchmaking stars" 兜底
  m = html.match(/title="MMR\s*(\d)\s*\/\s*(\d)"/) || html.match(/aria-label="(\d)\s+of\s+(\d)\s+matchmaking\s+stars"/i);
  if (m) d.stars = `${m[1]}/${m[2]}`;

  // 排名：aria-label="Rank 13820 of 27534, top 51%"；中文界面时退回 span 文本（#13,820 / 前 51%）
  m = html.match(/aria-label="Rank\s+([\d,]+)\s+of\s+([\d,]+),\s+top\s+(\d+)%"/i);
  if (m) {
    d.rankPos = m[1];
    d.rankTotal = m[2];
    d.rankPct = `前 ${m[3]}%`;
  } else {
    const pos = stripTags((html.match(/class="rank-pos[^"]*"[^>]*>([^<]+)</) || [])[1] || '');
    const pct = stripTags((html.match(/class="rank-pct">([^<]+)</) || [])[1] || '');
    if (pos) d.rankPos = pos.replace(/^#/, '').replace(/,/g, '');
    if (pct) d.rankPct = pct.replace(/^top\s*/i, '前 ');
  }

  // 更新时间：sub-key "Updated/更新" 后面的 sub-val（如 "7 d ago" / "7 天前"）
  m = html.match(/sub-key[^>]*>\s*(?:Updated|更新)[\s\S]{0,150}?sub-val[^>]*>([^<]+)</i);
  if (m) {
    d.updated = stripTags(m[1]).replace(/(\d+)\s*(d|h|min|m|s)\s*ago/i, (_, n, u) => {
      const unit = { d: '天', h: '小时', min: '分钟', m: '分钟', s: '秒' }[u.toLowerCase()] || u;
      return `${n} ${unit}前`;
    });
  }

  return d;
}

/** 把档案数据排成给模型看的文本。 */
function formatProfile(steamId, p) {
  const lines = [];
  lines.push(`查询成功：${p.name || '未知玩家'}（SteamID ${steamId}）`);
  if (p.mmr) lines.push(`MMR：${p.mmr}${p.stars ? `（${p.stars} 星）` : ''}`);
  if (p.rankPos) lines.push(`排名：#${p.rankPos}${p.rankTotal ? ` / ${p.rankTotal}` : ''}${p.rankPct ? `（${p.rankPct}）` : ''}`);
  const combat = [];
  if (p.kd) combat.push(`KD ${p.kd}`);
  if (p.kills) combat.push(`击杀 ${p.kills}`);
  if (p.deaths) combat.push(`死亡 ${p.deaths}`);
  if (combat.length) lines.push(combat.join(' · '));
  if (p.bounty) lines.push(`累计赏金：${p.bounty}`);
  if (p.updated) lines.push(`数据更新于：${p.updated}`);
  lines.push(`主页：${SITE}/p/${steamId}`);
  lines.push('');
  lines.push('【发送方式】用 send_message 工具把这份结果发到群里，并传 atUserId=提问者的 QQ 号（聊天记录里「昵称(QQ:号)」）；发过之后不要再重复输出同样内容。');
  return lines.join('\n');
}

export async function setup(skillApi) {
  api = skillApi;

  api.registerTool({
    id: 'query',
    name: '查询猎杀MMR',
    category: 'query',
    icon: '🎯',
    description: '在 bayouledger.com 查询 Hunt: Showdown 1896（猎杀对决）玩家的 MMR、星级、世界排名、KD 战绩。参数 name 传游戏内 ID 或完整 SteamID。适合群友问「XX 多少分 / MMR / 几星 / 段位 / KD / 战绩」时调用。',
    parameters: {
      type: 'object',
      additionalProperties: false,
      properties: {
        name: { type: 'string', description: '要查询的玩家游戏内 ID（别名）或完整 SteamID 数字' }
      },
      required: ['name']
    },
    async execute(_ctx, args) {
      try {
        const cfg = api.config() || {};
        if (cfg.enabled === false) {
          return { content: '错误：MMR 查询技能已被关闭（设置里可重新打开）', isError: true };
        }
        const ttlMs = Math.max(0, Number(cfg.cacheTtlSec ?? 120)) * 1000;

        const q = String(args?.name ?? '').trim().slice(0, 60);
        if (!q) return { content: '错误：请提供要查询的玩家名或 SteamID', isError: true };

        // 直接给了 SteamID（15~20 位纯数字）→ 跳过搜索
        let steamId = null;
        if (/^\d{15,20}$/.test(q)) {
          steamId = q;
        } else {
          const html = await httpGet(`${SITE}/?q=${encodeURIComponent(q)}`);
          const hits = parseSearch(html);
          if (!hits.length) {
            return { content: `没找到叫「${q}」的玩家（bayouledger.com 收录 4 万+ 猎人，可能名字打错了，或对方没被站点追踪）。可以让提问者核对游戏内 ID 或提供完整 SteamID 再试。`, isError: true };
          }
          const lower = q.toLowerCase();
          const exacts = hits.filter((h) => h.name.toLowerCase() === lower);
          // 唯一精确命中才直取；多个同名（不同账号起同名）也要人确认，不能悄悄取第一个
          const pick = exacts.length === 1 ? exacts[0] : (exacts.length === 0 && hits.length === 1 ? hits[0] : null);
          if (!pick) {
            const list = hits.slice(0, 6).map((h, i) => `${i + 1}. ${h.name}（SteamID ${h.steamId}）`).join('\n');
            const why = exacts.length > 1 ? '有多个起了一样名字的玩家' : '搜到多个相近的玩家';
            return { content: `${why}，让提问的人确认是哪一个：\n${list}\n确认后用对应 SteamID 重新查询（名字一样分不清）。不要自己猜。` };
          }
          steamId = pick.steamId;
        }

        // 缓存命中直接回
        const cached = profileCache.get(steamId);
        if (cached && Date.now() - cached.at < ttlMs) {
          return { content: cached.text };
        }

        const p = parseProfile(await httpGet(`${SITE}/p/${steamId}`));
        if (!p.mmr && !p.kd && !p.name) {
          return { content: `错误：玩家页面拿到了，但没解析出数据（站点可能改版了，或该玩家数据为空）：${SITE}/p/${steamId}`, isError: true };
        }
        const text = formatProfile(steamId, p);
        profileCache.set(steamId, { at: Date.now(), text });

        // 缓存别无限涨：超过 200 条时清掉最老的一半
        if (profileCache.size > 200) {
          const entries = [...profileCache.entries()].sort((a, b) => a[1].at - b[1].at);
          for (const [k] of entries.slice(0, 100)) profileCache.delete(k);
        }
        return { content: text };
      } catch (error) {
        const msg = error?.name === 'AbortError'
          ? `查询超时（${TIMEOUT_MS / 1000} 秒），bayouledger.com 没响应，稍后再试`
          : `查询失败：${error?.message ?? error}`;
        api?.warn?.(msg);
        return { content: `错误：${msg}`, isError: true };
      }
    }
  });

  api.log('已就绪：bayouledger.com MMR 查询工具注册完成');
}
