// 执行端交办 —— 把小鲸鱼的手接到 DSH（DeepSeek Harness）上。
//
// ── 为什么是这个设计 ──────────────────────────────────────────────
// 小鲸鱼的模型负责「听懂人话、判断该不该动手、把话回得像个活人」；
// 真正的执行交给本机的 DSH 执行端，它的权限和主会话完全一致（文件、命令、
// 网络、Office 全都通）。
//
// 工具本身只做三件事，所以它很便宜、很稳：
//   1. 认人 —— 只有主人本人在私聊里能下达执行指令（群聊一律不给整机权限）；
//   2. 投递 —— 把任务写进临时文件，起一个独立进程交给执行端，立刻返回；
//   3. 回话 —— 只说「接下了」，绝不等执行结果、绝不编造结果。
//
// 结果由执行端自己用 qq-send.ps1 发回这个对话。这样：
//   · QQ 会话不会被几分钟的长任务卡住；
//   · 小鲸鱼不用为执行过程反复烧 token（一次工具调用就结束）；
//   · 长任务失败/超时不会变成一条假消息。
//
// ── 为什么群聊不给 ──────────────────────────────────────────────
// 整机执行权限（删文件、跑命令）落到群里，等于把服务器借给任何能把名片改成
// 「主人」的人。核心代码里判定主人只看号码、不看名字，而这个技能拿不到
// 群消息的发送者号码（ctx 只给 chatId），所以群聊场景**没有可信的身份判据**，
// 一律拒绝并提示私聊。

import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { spawn } from 'node:child_process';

const BRIDGE_DIR = 'D:\\DSH\\qq-bridge';
const DISPATCH = path.join(BRIDGE_DIR, 'dispatch.mjs');
const BRIDGE_CONFIG = path.join(BRIDGE_DIR, 'config.json');
const MAX_TASK_CHARS = 8000;
const WAIT_RESULT_MS = 12000;

let apiRef = null;

function log(...args) {
  try { apiRef?.log?.('[dsh-task]', ...args); } catch { /* 日志不能影响功能 */ }
}

function readJson(file) {
  try { return JSON.parse(fs.readFileSync(file, 'utf8').replace(/^\uFEFF/, '')); } catch { return null; }
}

/** 主人 QQ 号：与桥接共用一份，避免两处名单不一致。 */
function ownerIds() {
  return (readJson(BRIDGE_CONFIG)?.owner?.qqs ?? []).map(String);
}

/**
 * 找 Node 解释器。
 * QQ Agent 是 Electron 应用，process.execPath 是 electron.exe；带上
 * ELECTRON_RUN_AS_NODE=1 它就是个标准 node。真 node 会忽略这个变量。
 */
function nodeCommand() {
  const candidates = [process.execPath, path.join(process.env.ProgramFiles || '', 'nodejs', 'node.exe')];
  for (const c of candidates) {
    try { if (c && fs.existsSync(c)) return c; } catch { /* 继续找下一个 */ }
  }
  return 'node';
}

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

export function register(api) {
  apiRef = api;

  api.registerTool({
    id: 'run_task',
    name: '交办执行端',
    description: '把需要真正动手的任务交给本机执行端完成（它拥有文件读写、执行命令、访问网络、处理 Office 文档的完整权限）。适合：改/查文件、跑命令、看系统状态、转换或整理文档表格、写代码、装环境、批量处理、抓网页数据。闲聊、知识问答、情感陪伴、复述信息不要调用本工具。',
    category: 'system',
    icon: '🛠️',
    parameters: {
      type: 'object',
      properties: {
        task: {
          type: 'string',
          description: '任务描述。执行端看不到这段对话，只能看到你写的这段话，所以要把路径、对象、期望结果写清楚（例如「把 D:\\报告\\a.docx 转成 PDF，存到同目录」）。'
        },
        note: {
          type: 'string',
          description: '可选：限制条件、注意事项、希望的交付格式。'
        }
      },
      required: ['task']
    },

    async execute(ctx, args) {
      const task = String(args?.task ?? '').trim();
      if (!task) return { content: '错误：task 不能为空', isError: true };

      // ① 认人：只有主人私聊能动手
      const owners = ownerIds();
      const chatId = String(ctx?.chatId ?? '');
      if (ctx?.kind !== 'private') {
        return { content: '这台机器的执行权限只对主人私聊开放。请私聊我下达指令。', isError: true };
      }
      if (!owners.includes(chatId)) {
        log('拒绝非主人', chatId);
        return { content: '你没有这台机器的执行权限。', isError: true };
      }

      // ② 投递：任务走临时文件，绕开 Windows 命令行引号问题
      const body = (String(args?.note ?? '').trim()
        ? `${task}\n\n【补充说明】${String(args.note).trim()}`
        : task).slice(0, MAX_TASK_CHARS);

      const stamp = `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
      const taskFile = path.join(os.tmpdir(), `dsh-task-${stamp}.txt`);
      const resultFile = path.join(os.tmpdir(), `dsh-task-${stamp}.json`);

      try {
        fs.writeFileSync(taskFile, body, 'utf8');
      } catch (error) {
        return { content: `执行端投递失败：写不了临时文件（${error?.message ?? error}）`, isError: true };
      }

      const argv = [
        DISPATCH,
        '--kind', 'private',
        '--id', chatId,
        '--task-file', taskFile,
        '--result-file', resultFile
      ];

      let spawnError = null;
      try {
        const child = spawn(nodeCommand(), argv, {
          cwd: BRIDGE_DIR,
          detached: true,
          stdio: 'ignore',
          windowsHide: true,
          env: { ...process.env, ELECTRON_RUN_AS_NODE: '1' }
        });
        child.on('error', (error) => { spawnError = error; });
        child.unref();
      } catch (error) {
        spawnError = error;
      }
      if (spawnError) {
        return { content: `执行端投递失败：起不了进程（${spawnError.message ?? spawnError}）`, isError: true };
      }

      // ③ 等一小会儿拿投递回执（通常 1~3 秒），拿不到就说已投递
      const deadline = Date.now() + WAIT_RESULT_MS;
      while (Date.now() < deadline) {
        await sleep(250);
        const result = readJson(resultFile);
        if (!result) continue;
        try { fs.unlinkSync(resultFile); } catch { /* 清不掉无所谓 */ }
        if (result.ok === false) {
          return { content: `执行端没接单：${result.error || '未知原因'}`, isError: true };
        }
        log('投递成功', chatId, 'session', result.sessionId);
        return {
          content: `已交给执行端，它在后台开工了（${result.sessionId ? `工作会话 ${String(result.sessionId).slice(0, 20)}…` : '已接单'}）。做完它会直接把结果发到这个对话里，不用你再问。`
        };
      }

      log('投递回执超时，但进程已起', chatId);
      return { content: '已交给执行端（回执超时，但它多半已经在跑了）。做完它会直接把结果发到这里。' };
    }
  });
}
