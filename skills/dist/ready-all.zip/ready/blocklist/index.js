// 黑名单管理（blocklist）
//
// 真正"不读不回复"的执行者是核心：app.js 在消息入口就调用 isGloballyBlocked()，
// 被拉黑的人发来的消息**直接 return** —— 不存档、不建会话、不进提示词，
// 所以模型根本看不到他，也就不可能回复。按群屏蔽（config.blocklist）同理。
//
// 本技能只做"管理"：让主人用一句话增删查。写的是同一份配置，
// 核心每个事件都会重新读配置，所以改完立刻生效，不用重启。
//
// 为什么是技能：什么时候该拉黑、从哪找到对方的 QQ 号，要靠模型理解上下文。

import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

const appRoot = globalThis.__qqAgentRoot
  || path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../..');
const { getConfig, updateConfig } = await import(pathToFileURL(path.join(appRoot, 'src/config.js')).href);
const { getGlobalBlocklist } = await import(pathToFileURL(path.join(appRoot, 'src/community.js')).href);
const { getSkillConfig } = await import(pathToFileURL(path.join(appRoot, 'src/skills/config.js')).href);

const ID = 'blocklist';
const DEFAULTS = { ownerOnly: true, ownerIds: '' };

const settings = () => {
  try { return getSkillConfig(ID, DEFAULTS); } catch { return { ...DEFAULTS }; }
};

const reply = (value, isError = false) => ({
  content: JSON.stringify(value),
  ...(isError ? { isError: true } : {})
});

function splitIds(raw) {
  return String(raw ?? '')
    .split(/[,，;；\s]+/)
    .map((s) => s.trim())
    .filter(Boolean);
}

/** QQ 号：只认 5~12 位数字，避免把昵称/群号写进名单。 */
function qqOf(value) {
  const s = String(value ?? '').trim().replace(/^@/, '').replace(/\s+/g, '');
  return /^\d{5,12}$/.test(s) ? s : '';
}

/** 主人名单：设置 > 主人识别插件的 ids > 白名单里的私聊号。 */
function ownerIds() {
  const explicit = splitIds(settings().ownerIds);
  if (explicit.length) return explicit;
  try {
    const c = getConfig() || {};
    const fromOwnerSkill = splitIds(c.skills?.['owner-identity']?.ids);
    if (fromOwnerSkill.length) return fromOwnerSkill;
    return (c.allow?.private || []).map(String);
  } catch {
    return [];
  }
}

/** 这条消息是谁发的：优先取最近一条存档，私聊退回会话 id。 */
function senderOf(ctx) {
  try {
    // includeSelf:false —— 机器人自己刚回的那条不算，要的是最后一条"人"发的
    const rows = ctx?.store?.recent?.(ctx.chatKey, { limit: 1, includeSelf: false }) || [];
    const last = rows[rows.length - 1];
    if (last?.senderId) return String(last.senderId);
  } catch { /* 拿不到就退回会话 id */ }
  const key = String(ctx?.chatKey || '');
  return key.startsWith('private:') ? key.split(':')[1] : '';
}

function ensureOwner(ctx) {
  if (settings().ownerOnly === false) return null;
  const who = senderOf(ctx);
  const owners = ownerIds();
  if (who && owners.includes(who)) return null;
  return reply({
    ok: false,
    error: `只有主人能改黑名单（当前发言人：${who || '未知'}）`
  }, true);
}

const currentGroups = () => {
  const map = getConfig()?.blocklist;
  return (map && typeof map === 'object') ? { ...map } : {};
};

const currentExemptions = () => splitIds((getConfig()?.communityExemptions || []).join(','));

function writeGlobal(ids) {
  updateConfig({ globalBlocklist: { __replace__: [...new Set(ids.map(String))] } });
}

function writeExemptions(ids) {
  updateConfig({ communityExemptions: { __replace__: [...new Set(ids.map(String))] } });
}

function writeGroups(map) {
  updateConfig({ blocklist: { __replace__: map } });
}

export function setup(api) {
  api.log?.('黑名单管理已加载：拉黑由核心入口直接丢弃（不读、不存、不回）');

  api.registerTool({
    id: 'block_user',
    name: '拉黑一个人',
    description: '把某个 QQ 号加入黑名单，之后他发什么都直接丢弃：不存档、不触发、不回复。默认全局生效（所有群+私聊）；scope=group 只屏蔽当前群。只有主人能执行。',
    category: 'query',
    icon: '🚫',
    parameters: {
      type: 'object',
      properties: {
        qq: { type: 'string', description: '要拉黑的 QQ 号（必须确认过，别猜）' },
        scope: { type: 'string', enum: ['global', 'group'], description: 'global=所有群+私聊（默认）；group=只在某个群' },
        groupId: { type: 'string', description: 'scope=group 时的群号；留空用当前群' },
        reason: { type: 'string', description: '可选：为什么拉黑，方便以后回想' }
      },
      required: ['qq'],
      additionalProperties: false
    },
    execute: async (ctx, args = {}) => {
      const denied = ensureOwner(ctx);
      if (denied) return denied;
      const id = qqOf(args.qq);
      if (!id) return reply({ ok: false, error: `QQ 号看起来不对：${args.qq ?? '(空)'}` }, true);

      if (String(args.scope || 'global') === 'group') {
        const gid = qqOf(args.groupId) || qqOf(String(ctx?.chatKey || '').split(':')[1]);
        if (!gid) return reply({ ok: false, error: '要指定群号（scope=group 时需要）' }, true);
        const map = currentGroups();
        const list = new Set((map[gid] || []).map(String));
        list.add(id);
        map[gid] = [...list];
        writeGroups(map);
        return reply({ ok: true, scope: 'group', groupId: gid, blocked: id, total: list.size, reason: args.reason || '' });
      }

      const ids = new Set(getGlobalBlocklist().map(String));
      ids.add(id);
      writeGlobal([...ids]);
      // 他之前可能在本机豁免名单里，重新拉黑要先把豁免清掉，否则拉不回来
      const exemptions = currentExemptions();
      if (exemptions.includes(id)) writeExemptions(exemptions.filter((x) => x !== id));
      return reply({ ok: true, scope: 'global', blocked: id, total: getGlobalBlocklist().length, reason: args.reason || '' });
    }
  });

  api.registerTool({
    id: 'unblock_user',
    name: '解除拉黑',
    description: '把某个 QQ 号移出黑名单，之后他说话会重新被处理。默认解除全局屏蔽；scope=group 只解除当前群。只有主人能执行。',
    category: 'query',
    icon: '✅',
    parameters: {
      type: 'object',
      properties: {
        qq: { type: 'string', description: '要解除的 QQ 号' },
        scope: { type: 'string', enum: ['global', 'group'], description: 'global=解除全局（默认）；group=只解除某个群' },
        groupId: { type: 'string', description: 'scope=group 时的群号；留空用当前群' }
      },
      required: ['qq'],
      additionalProperties: false
    },
    execute: async (ctx, args = {}) => {
      const denied = ensureOwner(ctx);
      if (denied) return denied;
      const id = qqOf(args.qq);
      if (!id) return reply({ ok: false, error: `QQ 号看起来不对：${args.qq ?? '(空)'}` }, true);

      if (String(args.scope || 'global') === 'group') {
        const gid = qqOf(args.groupId) || qqOf(String(ctx?.chatKey || '').split(':')[1]);
        if (!gid) return reply({ ok: false, error: '要指定群号（scope=group 时需要）' }, true);
        const map = currentGroups();
        const list = (map[gid] || []).map(String).filter((x) => x !== id);
        if (list.length) map[gid] = list;
        else delete map[gid];
        writeGroups(map);
        return reply({ ok: true, scope: 'group', groupId: gid, unblocked: id });
      }

      const before = getGlobalBlocklist().map(String);
      writeGlobal(before.filter((x) => x !== id));
      // 云端名单里可能还有他：写进本机豁免，才能保证本机真的放行
      // （豁免是独立字段，不会被每 5 分钟一次的云端同步覆盖）
      const exemptions = currentExemptions();
      if (!exemptions.includes(id)) writeExemptions([...exemptions, id]);
      return reply({ ok: true, scope: 'global', unblocked: id, still: getGlobalBlocklist().map(String) });
    }
  });

  api.registerTool({
    id: 'list_blocklist',
    name: '查看黑名单',
    description: '列出当前生效的黑名单：全局名单、按群屏蔽的名单、以及本机豁免（被解除但云端仍在拦的号）。',
    category: 'query',
    icon: '📋',
    parameters: { type: 'object', properties: {}, additionalProperties: false },
    execute: async () => {
      const globalIds = getGlobalBlocklist().map(String);
      const groups = Object.entries(currentGroups())
        .filter(([, ids]) => Array.isArray(ids) && ids.length)
        .map(([groupId, ids]) => ({ groupId, ids: ids.map(String) }));
      return reply({
        ok: true,
        global: globalIds,
        groups,
        exemptions: currentExemptions(),
        note: '被拉黑的人发消息会被入口直接丢弃：不存档、不触发、不回复'
      });
    }
  });
}
