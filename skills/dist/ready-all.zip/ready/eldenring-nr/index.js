// 《艾尔登法环 黑夜君临》本地知识库
//
// 设计原则：本地优先、查不到就说查不到、绝不编。
//
// 资料放在三个地方，都能随时用记事本改，**存盘即生效**（按 mtime 自动重读，不需要重启）：
//   1) 数据目录：   <data>/eldenring-nr/kb/*.json      ← 优先级最高；升级不会被覆盖，改这里
//   2) 技能自带：   <技能目录>/kb/*.json               ← 发行包里的默认底稿（市场版靠它自带资料）
//   3) 群友教的新条目：<data>/eldenring-nr/user-added.json
// 同 id 先到先得 → 数据目录在前，所以"你在 data 下的改动"优先于"包里的默认值"。
//
// 词条格式（每项一个对象）：
//   { id, type, category, name, nameEn, aliases[], summary, sections[{title,text}], tags[], sources[], confidence }
// 只有一个硬要求：name 必须有。其余缺失都能容忍（只是检索和展示会弱一点）。
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const SKILL_DIR = path.dirname(fileURLToPath(import.meta.url));
const SKILL_KB = path.join(SKILL_DIR, 'kb');

/**
 * 定位数据目录。
 * Electron 主进程会先把 QQ_AGENT_DATA_DIR 设成「exe 同级的 data/」再加载核心，
 * 所以优先读它；读不到就按安装布局推断，最后取第一个真实存在的目录。
 */
function resolveDataDir() {
  const cands = [
    process.env.QQ_AGENT_DATA_DIR,
    path.resolve(SKILL_DIR, '..', '..', '..', '..', 'data'), // <安装目录>/data
    path.resolve(SKILL_DIR, '..', '..', '..', 'data'),       // resources/app/data
  ].filter(Boolean);
  for (const c of cands) {
    try { if (fs.statSync(c).isDirectory()) return c; } catch { /* 继续试下一个 */ }
  }
  return cands[1] || cands[0];
}

const DATA_DIR = resolveDataDir();
const DATA_KB = path.join(DATA_DIR, 'eldenring-nr', 'kb');
const USER_ADDED = path.join(DATA_DIR, 'eldenring-nr', 'user-added.json');

// ── 载入 ────────────────────────────────────────────────────────────────────

let cache = { at: 0, stamp: '', entries: [] };
const CACHE_MS = 5000;

/** 目录里所有 .json 的 mtime+size 指纹；用来判断要不要重读。 */
function stampOfDirs() {
  const parts = [];
  for (const dir of [SKILL_KB, DATA_KB]) {
    let names = [];
    try { names = fs.readdirSync(dir).filter((n) => n.toLowerCase().endsWith('.json')).sort(); } catch { continue; }
    for (const n of names) {
      try { const s = fs.statSync(path.join(dir, n)); parts.push(`${n}:${s.mtimeMs}:${s.size}`); } catch { /* 忽略 */ }
    }
  }
  try { const s = fs.statSync(USER_ADDED); parts.push(`user-added:${s.mtimeMs}:${s.size}`); } catch { /* 还没教过 */ }
  return parts.join('|');
}

function readArray(file) {
  try {
    const raw = fs.readFileSync(file, 'utf8');
    const data = JSON.parse(raw);
    const list = Array.isArray(data) ? data : (Array.isArray(data?.entries) ? data.entries : null);
    if (!list) return [];
    return list.filter((e) => e && typeof e === 'object' && typeof e.name === 'string' && e.name.trim());
  } catch {
    return []; // 单个文件写坏了不该拖垮整个知识库
  }
}

function loadEntries(force = false) {
  const now = Date.now();
  const stamp = stampOfDirs();
  if (!force && cache.entries.length && stamp === cache.stamp && now - cache.at < CACHE_MS) return cache.entries;

  const out = [];
  const seen = new Set();
  const push = (e, origin) => {
    const id = String(e.id || `${origin}:${e.name}`).trim();
    if (seen.has(id)) return; // 同 id 先到先得：技能自带的底稿优先，用户新增的不覆盖底稿
    seen.add(id);
    out.push({ ...e, _id: id, _origin: origin });
  };

  // 数据目录在前：用户自己的改动优先于发行包里的默认底稿
  for (const dir of [DATA_KB, SKILL_KB]) {
    let names = [];
    try { names = fs.readdirSync(dir).filter((n) => n.toLowerCase().endsWith('.json')).sort(); } catch { continue; }
    for (const n of names) for (const e of readArray(path.join(dir, n))) push(e, n);
  }
  for (const e of readArray(USER_ADDED)) push(e, 'user-added.json');

  cache = { at: now, stamp, entries: out };
  return out;
}

// ── 检索 ────────────────────────────────────────────────────────────────────

const norm = (s) => String(s ?? '').toLowerCase().replace(/\s+/g, '');

/**
 * 检索词拆解，分三档。
 *
 * ⚠️ 踩过一个真坑：只做 **2 字中文滑窗**会产生大量无意义命中——
 * 实测查「黑暗之魂4」（库里没有）时，「黑暗」「之魂」会撞上无关词条的正文，
 * 于是返回一条毫不相干的资料，模型照着答就成了编（人设里写着「不要不懂装懂」，这里更不能喂错）。
 * 现在分档：整句/整名命中(strong) > 3~4 字滑窗(long) > 2 字滑窗(short，仅兜底，必须凑够数量)。
 */
function terms(query) {
  const q = String(query ?? '').trim();
  const full = norm(q);
  const pieces = [];
  for (const piece of q.split(/[\s,，、。;；:：/|!！?？()（）[\]【】"'“”]+/)) {
    const p = norm(piece);
    if (p && p.length >= 2) pieces.push(p);
  }
  const longSet = new Set();
  const shortSet = new Set();
  const cn = q.replace(/[^\u4e00-\u9fa5]+/g, ' ');
  for (const seg of cn.split(/\s+/)) {
    for (let n = 3; n <= 4; n++) {
      for (let i = 0; i + n <= seg.length; i++) longSet.add(seg.slice(i, i + n));
    }
    if (seg.length >= 2) for (let i = 0; i + 2 <= seg.length; i++) shortSet.add(seg.slice(i, i + 2));
  }
  // 英文/数字片段（"gladius"、"1.03"）按长词处理
  for (const p of pieces) if (/[a-z0-9]/i.test(p)) longSet.add(p);
  for (const t of longSet) shortSet.delete(t);
  return { full, long: [...longSet], short: [...shortSet] };
}

function keysOf(e) {
  return [e.name, e.nameEn, ...(Array.isArray(e.aliases) ? e.aliases : []), e._id]
    .filter((x) => typeof x === 'string' && x.trim())
    .map((x) => String(x).trim());
}

function blobOf(e) {
  const secs = Array.isArray(e.sections) ? e.sections : [];
  return norm([e.name, e.nameEn, ...(e.aliases || []), ...(e.tags || []), e.category, e.summary,
    ...secs.map((s) => `${s?.title ?? ''}${s?.text ?? ''}`)].join('\n'));
}

/**
 * 打分。除分数外还返回 strong / longHits / shortHits，由 accept 决定这条该不该认——
 * 宁可说「没查到」，也不要返回不相干的词条。
 */
function scoreOf(e, q, ts) {
  const nq = ts.full;
  const keys = keysOf(e).map(norm).filter((k) => k.length >= 2);
  const blob = blobOf(e);
  let score = 0;
  let strong = 0;
  let longHits = 0;
  let shortHits = 0;

  // ① 整句命中名字/别名（"追踪者怎么玩" 命中 "追踪者"；"Gladius" 命中别名）
  if (nq.length >= 2) {
    for (const k of keys) {
      if (k === nq) { score += 80; strong++; break; }
      if (k.includes(nq) || nq.includes(k)) { score += 60; strong++; break; }
    }
  }
  // ② 3~4 字滑窗命中
  for (const t of ts.long) {
    if (keys.some((k) => k.includes(t))) { score += 25; strong++; continue; }
    if (blob.includes(t)) { score += 8; longHits++; }
  }
  // ③ 2 字滑窗只作兜底，权重很低，且必须凑够数量（见 accept）
  for (const t of ts.short) {
    if (keys.some((k) => k.includes(t))) { score += 12; strong++; continue; }
    if (blob.includes(t)) { score += 2; shortHits++; }
  }
  if (nq.length >= 2 && (e.tags || []).some((tag) => norm(tag).includes(nq))) score += 10;

  const accept = strong > 0 || longHits >= 1 || shortHits >= 3;
  return { score, strong, longHits, shortHits, accept };
}

/** 检索入口：名字/别名命中优先，其次正文命中；不合格的一律不返回。 */
function rank(all, q) {
  const ts = terms(q);
  return all
    .map((e) => ({ e, ...scoreOf(e, q, ts) }))
    .filter((x) => x.accept)
    .sort((a, b) => (b.strong - a.strong) || (b.score - a.score))
    .map((x) => x.e);
}

// ── 展示 ────────────────────────────────────────────────────────────────────

function formatEntry(e, maxChars) {
  const head = `【${e.category || e.type || '词条'}】${e.name}${e.nameEn ? `（${e.nameEn}）` : ''}`;
  const lines = [head];
  if (e.summary) lines.push(`  ${e.summary}`);
  let used = head.length + String(e.summary || '').length;
  for (const s of (Array.isArray(e.sections) ? e.sections : [])) {
    const title = String(s?.title ?? '').trim();
    const text = String(s?.text ?? '').trim();
    if (!text) continue;
    const line = `  · ${title ? title + '：' : ''}${text}`;
    if (used + line.length > maxChars) { lines.push('  · …（本条还有内容，已按长度上限截断；需要细节就针对这个条目再问一次）'); break; }
    lines.push(line);
    used += line.length;
  }
  const meta = [];
  if (Array.isArray(e.sources) && e.sources.length) meta.push(`来源 ${e.sources.slice(0, 2).join(' ')}`);
  if (e.confidence && e.confidence !== 'high') meta.push(`把握度 ${e.confidence}`);
  if (meta.length) lines.push(`  （${meta.join('；')}）`);
  return lines.join('\n');
}

// ── 工具 ────────────────────────────────────────────────────────────────────

let cfg = () => ({});

export function setup(api) {
  cfg = api.config;
  const num = (v, d, lo, hi) => Math.min(hi, Math.max(lo, Number(v) || d));

  api.registerTool({
    id: 'nr_lookup',
    name: '查黑夜君临资料',
    description:
      '查询《艾尔登法环 黑夜君临》(Elden Ring Nightreign) 的本地知识库：夜行者（角色）、夜王（Boss）、遗物与武器、核心机制、版本更新。' +
      '有人问这个游戏里的角色怎么玩、某个 BOSS 怎么打、某个机制是什么、某版本改了什么，就来查这里。' +
      'query 填要查的东西（人名/Boss 名/机制名/版本号都行）。**库里没有的不要编**，老实说库里没收录。',
    category: 'knowledge',
    icon: '🌙',
    parameters: {
      type: 'object',
      properties: {
        query: { type: 'string', description: '要查的关键词，例如"格拉狄乌斯"、"追踪者 推荐"、"缩圈"、"1.03"' },
        category: { type: 'string', description: '可选，限定分类：夜行者 / 夜王 / 遗物 / 武器 / 核心机制 / 版本更新' },
        limit: { type: 'number', description: '最多返回几条，默认用设置里的值' }
      },
      required: ['query']
    },
    async execute(ctx, args) {
      try {
        const c = cfg() || {};
        const maxResults = num(args?.limit ?? c.maxResults, 3, 1, 8);
        const maxChars = num(c.maxCharsPerEntry, 1500, 300, 6000);
        const q = String(args?.query ?? '').trim();
        if (!q) return { content: '缺少 query：告诉我要查什么。', isError: true };

        let all = loadEntries();
        if (!all.length) {
          return { content: `知识库是空的（资料目录：${DATA_KB}）。先把资料 json 放进去，或者让管理员检查目录是否存在。`, isError: true };
        }
        const cat = String(args?.category ?? '').trim();
        if (cat) {
          const filtered = all.filter((e) => String(e.category || '').includes(cat) || String(e.type || '').includes(cat));
          if (filtered.length) all = filtered;
        }

        const ranked = rank(all, q);

        if (!ranked.length) {
          const cats = [...new Set(all.map((e) => e.category || e.type).filter(Boolean))];
          const sample = all.slice(0, 10).map((e) => e.name).join('、');
          return {
            content: `本地知识库里没有和「${q}」相关的内容。\n（收录 ${all.length} 条，分类：${cats.join(' / ') || '无'}；例如：${sample}…）\n` +
              '**不要编造**：老实说没查到，或者换个更具体的名字再查一次（可以用 nr_index 看完整目录）。',
            isError: false
          };
        }

        const picked = ranked.slice(0, maxResults);
        const body = picked.map((e) => formatEntry(e, maxChars)).join('\n\n');
        return {
          content: `${body}\n\n（共收录 ${all.length} 条，以上为相关度最高的 ${picked.length} 条。` +
            '游戏更新频繁，涉及数值或版本的回答请补一句「以游戏内当前版本为准」。）'
        };
      } catch (error) {
        return { content: `查知识库失败：${error?.message ?? error}`, isError: true };
      }
    }
  });

  api.registerTool({
    id: 'nr_index',
    name: '黑夜君临资料目录',
    description:
      '列出《艾尔登法环 黑夜君临》本地知识库里收录了哪些词条（按分类分组，附一句话说明）。' +
      '不确定某个东西库里有没有、或者想给群友报菜单时用它，然后再用 nr_lookup 取细节。',
    category: 'knowledge',
    icon: '📖',
    parameters: {
      type: 'object',
      properties: {
        category: { type: 'string', description: '可选，只看某一类：夜行者 / 夜王 / 遗物 / 武器 / 核心机制 / 版本更新' }
      }
    },
    async execute(ctx, args) {
      try {
        let all = loadEntries();
        if (!all.length) return { content: `知识库是空的（资料目录：${DATA_KB}）。`, isError: true };
        const cat = String(args?.category ?? '').trim();
        if (cat) all = all.filter((e) => `${e.category || ''}${e.type || ''}`.includes(cat));

        const groups = new Map();
        for (const e of all) {
          const key = e.category || e.type || '其他';
          if (!groups.has(key)) groups.set(key, []);
          groups.get(key).push(e);
        }
        const lines = [`《艾尔登法环 黑夜君临》本地知识库目录（共 ${all.length} 条）`];
        for (const [key, list] of groups) {
          lines.push(`\n【${key}】${list.length} 条`);
          for (const e of list) lines.push(`  · ${e.name}${e.nameEn ? `（${e.nameEn}）` : ''}${e.summary ? ' — ' + String(e.summary).slice(0, 60) : ''}`);
        }
        return { content: lines.join('\n') };
      } catch (error) {
        return { content: `读目录失败：${error?.message ?? error}`, isError: true };
      }
    }
  });

  api.registerTool({
    id: 'nr_add',
    name: '收录黑夜君临资料',
    description:
      '把一个新词条收进《艾尔登法环 黑夜君临》知识库（存到数据目录的 user-added.json，升级不会被覆盖）。' +
      '**只在私聊里可用**（群里任何人说都不写盘，避免被随手污染知识库）。' +
      '写进去之前要确保信息是对的：拿不准的宁可先不写。',
    category: 'knowledge',
    icon: '✍️',
    parameters: {
      type: 'object',
      properties: {
        name: { type: 'string', description: '词条名，例如"某某夜王""某遗物词条"' },
        category: { type: 'string', description: '分类：夜行者 / 夜王 / 遗物 / 武器 / 核心机制 / 版本更新' },
        summary: { type: 'string', description: '一句话说明' },
        sections: {
          type: 'array',
          description: '正文分段，每项 { title, text }',
          items: {
            type: 'object',
            properties: { title: { type: 'string' }, text: { type: 'string' } },
            required: ['text']
          }
        },
        aliases: { type: 'array', description: '别名/俗称/英文名，便于以后检索', items: { type: 'string' } },
        source: { type: 'string', description: '信息来源（网址或"群友口述"）' }
      },
      required: ['name']
    },
    async execute(ctx, args) {
      try {
        const c = cfg() || {};
        if (c.allowTeach === false) {
          return { content: '管理员关掉了「允许收录」，这条不写盘。', isError: true };
        }
        // 只在私聊写盘：群里任何人都能触发的话，知识库迟早被污染
        const kind = String(ctx?.kind ?? '');
        if (kind && kind !== 'private') {
          return {
            content: '这个操作只在私聊里可用（在群里我不会往知识库里写东西）。要收录的话让管理员私聊我，或者自己编辑 user-added.json。',
            isError: true
          };
        }
        const name = String(args?.name ?? '').trim();
        if (!name) return { content: '缺少 name。', isError: true };

        const sections = (Array.isArray(args?.sections) ? args.sections : [])
          .map((s) => ({ title: String(s?.title ?? '').trim(), text: String(s?.text ?? '').trim() }))
          .filter((s) => s.text);
        const entry = {
          id: 'user-' + (norm(name).replace(/[^\w\u4e00-\u9fa5-]/g, '').slice(0, 40) || Date.now()),
          type: 'user',
          category: String(args?.category ?? '').trim() || '用户补充',
          name,
          nameEn: '',
          aliases: (Array.isArray(args?.aliases) ? args.aliases : []).map(String).filter(Boolean),
          summary: String(args?.summary ?? '').trim(),
          sections,
          tags: ['用户补充'],
          sources: args?.source ? [String(args.source)] : [],
          confidence: 'medium',
          addedAt: new Date().toISOString()
        };

        fs.mkdirSync(path.dirname(USER_ADDED), { recursive: true });
        let list = [];
        try {
          const d = JSON.parse(fs.readFileSync(USER_ADDED, 'utf8'));
          if (Array.isArray(d)) list = d;
          else if (Array.isArray(d?.entries)) list = d.entries;
        } catch { /* 还没有或写坏了，重建 */ }
        const i = list.findIndex((e) => e && e.id === entry.id);
        if (i >= 0) list[i] = { ...list[i], ...entry };
        else list.push(entry);

        const tmp = `${USER_ADDED}.${process.pid}.tmp`;
        fs.writeFileSync(tmp, JSON.stringify(list, null, 2), 'utf8');
        fs.renameSync(tmp, USER_ADDED);
        loadEntries(true); // 立刻重读，后续查询就能命中
        return { content: `已收录「${name}」（分类：${entry.category}，正文 ${sections.length} 段）。当前用户补充条目共 ${list.length} 条。` };
      } catch (error) {
        return { content: `收录失败：${error?.message ?? error}`, isError: true };
      }
    }
  });
}

/** 状态自检：资料目录、条目数、分类分布。 */
export function available() {
  try {
    const all = loadEntries(true);
    if (!all.length) return { ok: false, reason: `知识库为空（资料目录 ${DATA_KB}）` };
    return true;
  } catch (error) {
    return { ok: false, reason: String(error?.message ?? error) };
  }
}
