// Danbooru 找图（LLM 型技能 · registerTool）—— 2026-10-09 新建
//
// 为什么用它：Pixiv 的搜索接口在匿名下只给「最新优先」，冷门角色常常只有一两张；
// Danbooru 是**按标签的图库**（同一角色动辄几千张），免 API key、免登录，
// 而且支持 `order:score` 直接取高分图。所以它当 Pixiv 找图的**补充源**：
// Pixiv 那边图太少时，pixiv-image-tagsearch 会调本技能的 internals.supplement 补几张。
//
// 实测要点（2026-10-09，本机直连；家里代理在路由器上，不要填本地代理）：
//   · `posts.json` 匿名可用，`only=` 能只取需要的字段；
//   · `rating:general,sensitive`（逗号 = 或）与 `order:score` 匿名下**都生效**
//     （实测 `priestess_(arknights) order:score rating:g,s` 返回 267 / 267 / 221 分）；
//   · **挑图默认随机**：用户要的是"两种（全年龄 + 轻微暗示）都会发、每次随机"，
//     所以只在分数前 N 名（randomPool，默认 24）里等概率抽，而不是永远取前几名
//     —— 老写法每次都发同一批，而且高分那段常年偏 sensitive（见 pickImages）；
//   · **UA 必须带名字**：`danbooru.donmai.us` 对浏览器 UA 一律 403，对
//     `QQAgent-danbooru/1.0 (local QQ bot)` 才 200 —— 同一个帖子实测过两种结果；
//   · `file_url` 是原图（cdn.donmai.us），但图床快慢能差 20 倍（110KB/s ~ 2MB/s，
//     16MB 那张 90 秒都下不完）→ 所以下面按「大图退 sample、失败换下一张候选」写。
//
// 诚实原则：退到「作品标签」捞图时，一定要标注「可能含同作品其他角色」；
// 发的是压缩预览图（原图太大）也要标注 —— 不许把 sample 说成原图。
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';

const API = 'https://danbooru.donmai.us';
const UA = 'QQAgent-danbooru/1.0 (local QQ bot)';
const IMG_EXT = new Set(['.jpg', '.jpeg', '.png', '.gif', '.webp']);
const ONLY = [
  'id', 'score', 'rating', 'file_url', 'large_file_url', 'preview_file_url', 'source', 'pixiv_id',
  'tag_string_artist', 'tag_string_character', 'tag_string_copyright',
  'image_width', 'image_height', 'file_size', 'file_ext', 'md5', 'fav_count',
  'is_deleted', 'is_banned', 'is_pending'
].join(',');

let cfg = () => ({});
let log = () => {};
let warn = () => {};

// ── 数据目录 ────────────────────────────────────────────────────────────
function dataDir() {
  const base = process.env.QQ_AGENT_DATA_DIR
    || path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..', '..', '..', '..', 'data');
  return path.join(base, 'danbooru');
}

function imageDir() {
  const c = cfg() || {};
  return String(c.imageDir || '').trim() || path.join(dataDir(), 'images');
}

function num(v, lo, hi, dflt) {
  const n = Number(v);
  if (!Number.isFinite(n)) return dflt;
  return Math.min(hi, Math.max(lo, Math.round(n)));
}

// ── tag 词典（中文名 / 作品名 → Danbooru 英文标签）──────────────────────
// Danbooru 的标签是英文/罗马字，中文名搜不到东西，所以词典是命中率的关键。
// 首次运行写入下面这份种子；**每一条都经过 Danbooru tags.json 核实过存在**（2026-10-09）。
// 运行时还会自学习：模型在 tag 参数里给了英文标签，就 rememberTag 记下来
// （拉普兰德 就是这么进词典的 —— 模型主动填了 lappland_(arknights)）。
const SEED_DICT = {
  // 明日方舟
  普瑞赛斯: 'priestess_(arknights)',
  阿米娅: 'amiya_(arknights)',
  凯尔希: 'kal\'tsit_(arknights)',
  陈: 'ch\'en_(arknights)',
  能天使: 'exusiai_(arknights)',
  斯卡蒂: 'skadi_(arknights)',
  幽灵鲨: 'specter_(arknights)',
  德克萨斯: 'texas_(arknights)',
  缄默德克萨斯: 'texas_the_omertosa_(arknights)',
  拉普兰德: 'lappland_(arknights)',
  银灰: 'silverash_(arknights)',
  史尔特尔: 'surtr_(arknights)',
  泥岩: 'mudrock_(arknights)',
  风笛: 'bagpipe_(arknights)',
  棘刺: 'thorns_(arknights)',
  山: 'mountain_(arknights)',
  温蒂: 'weedy_(arknights)',
  迷迭香: 'rosmontis_(arknights)',
  令: 'ling_(arknights)',
  年: 'nian_(arknights)',
  夕: 'dusk_(arknights)',
  澄闪: 'goldenglow_(arknights)',
  塞雷娅: 'saria_(arknights)',
  白面鸮: 'ptilopsis_(arknights)',
  华法琳: 'warfarin_(arknights)',
  临光: 'nearl_(arknights)',
  夜莺: 'nightingale_(arknights)',
  推进之王: 'siege_(arknights)',
  明日方舟: 'arknights',
  // 东方
  古明地恋: 'komeiji_koishi',
  博丽灵梦: 'hakurei_reimu',
  芙兰朵露: 'flandre_scarlet',
  十六夜咲夜: 'izayoi_sakuya',
  雾雨魔理沙: 'kirisame_marisa',
  琪露诺: 'cirno',
  东方: 'touhou',
  东方Project: 'touhou',
  // 原神 / 崩坏：星穹铁道
  胡桃: 'hu_tao_(genshin_impact)',
  雷电将军: 'raiden_shogun',
  芙宁娜: 'furina_(genshin_impact)',
  原神: 'genshin_impact',
  三月七: 'march_7th_(honkai:_star_rail)',
  流萤: 'firefly_(honkai:_star_rail)',
  崩坏星穹铁道: 'honkai:_star_rail',
  // 其它常见
  雷姆: 'rem_(re:zero)',
  中野梓: 'nakano_azusa',
  噶呜古拉: 'gawr_gura',
  星街彗星: 'hoshimachi_suisei',
  宝钟玛琳: 'houshou_marine'
};

let tagDict = null;

function tagDictFile() { return path.join(dataDir(), 'tag-dict.json'); }

function loadTagDict() {
  if (tagDict) return tagDict;
  tagDict = {};
  try {
    if (!fs.existsSync(tagDictFile())) {
      tagDict = { ...SEED_DICT };
      saveTagDict();
    } else {
      const raw = JSON.parse(fs.readFileSync(tagDictFile(), 'utf8'));
      if (raw && typeof raw === 'object' && !Array.isArray(raw)) tagDict = raw;
    }
  } catch { tagDict = { ...SEED_DICT }; }
  return tagDict;
}

function saveTagDict() {
  try {
    fs.mkdirSync(dataDir(), { recursive: true });
    fs.writeFileSync(tagDictFile(), JSON.stringify(tagDict, null, 2), 'utf8');
  } catch { /* 词典写不进去不影响本次找图 */ }
}

function rememberTag(name, tag) {
  const n = String(name || '').trim();
  const t = String(tag || '').trim();
  if (!n || !t || n === t) return;
  const d = loadTagDict();
  if (d[n] === t) return;
  d[n] = t;
  saveTagDict();
}

// ── 发过的图索引（避免同一张反复发）─────────────────────────────────────
let ledger = null;

function ledgerFile() { return path.join(dataDir(), 'index.json'); }

function loadLedger() {
  if (ledger) return ledger;
  try {
    const raw = JSON.parse(fs.readFileSync(ledgerFile(), 'utf8'));
    ledger = (raw && typeof raw === 'object' && !Array.isArray(raw)) ? raw : {};
  } catch { ledger = {}; }
  return ledger;
}

function saveLedger() {
  try {
    fs.mkdirSync(dataDir(), { recursive: true });
    const p = ledgerFile();
    fs.writeFileSync(`${p}.tmp`, JSON.stringify(ledger, null, 1), 'utf8');
    fs.renameSync(`${p}.tmp`, p);          // 原子写：崩了也不会留下半截 JSON
  } catch { /* 同上 */ }
}

function hasPost(id) { return Boolean(loadLedger()[String(id)]); }

/**
 * 跨源去重：Danbooru 上很多图就是 Pixiv 的镜像（每个 post 带 `pixiv_id`），
 * 所以"Pixiv 发过的那张 + Danbooru 上同一张画"会让用户看到两张一样的。
 * 这里读一下 Pixiv 技能的索引（同一个 data 目录下的 pixiv/pid-index.json），
 * 发过的 pixiv_id 就跳过。20 秒缓存：同一次运行里 Pixiv 刚发完、这边紧接着补图也能看到。
 */
let pixivSentCache = { at: 0, set: new Set() };

function pixivSentPids() {
  if (Date.now() - pixivSentCache.at < 20000) return pixivSentCache.set;
  const set = new Set();
  try {
    const f = path.join(path.dirname(dataDir()), 'pixiv', 'pid-index.json');
    const j = JSON.parse(fs.readFileSync(f, 'utf8'));
    for (const [k, v] of Object.entries(j || {})) {
      if (v && Number(v.sentCount) > 0) set.add(String(k));
    }
  } catch { /* 没有 Pixiv 索引就算了，不影响找图 */ }
  pixivSentCache = { at: Date.now(), set };
  return set;
}

function pixivSent(p) {
  return Boolean(p?.pixiv_id) && pixivSentPids().has(String(p.pixiv_id));
}

/**
 * 挑图：默认**随机**（从分数最高的一批里等概率抽 want 张），不是永远取前几名。
 * 用户 2026-10-09 明确要求：「两种都会发，随机的」——
 *   · 光按分数取，同一个角色每次都会发同一批图，而且高分那一段常年偏向 sensitive；
 *   · 窗口保证质量（只在分数前 N 名里抽），随机保证每次不一样。
 *
 * balance=true 时会**给两种分级配额**：窗口里全年龄和轻微暗示各占一半再抽。
 * 为什么需要它（实测）：`priestess_(arknights)` 分数前 24 名几乎全是 sensitive，
 * 不平衡的话"两种都发"实际上等于"基本只发 sensitive"。
 */
function pickImages(pool, want, { mode = 'random', poolSize = 24, balance = true } = {}) {
  if (mode === 'top') return pool.slice(0, want);
  const size = Math.max(want, Math.min(pool.length, Math.max(1, poolSize)));
  let window = null;
  if (balance) {
    // 搜索已经排除了 questionable/explicit，所以这里只有 g 和 s 两组
    const g = pool.filter((p) => p.rating === 'g');
    const s = pool.filter((p) => p.rating !== 'g');
    if (g.length && s.length) {
      const half = Math.ceil(size / 2);
      window = [...g.slice(0, half), ...s.slice(0, size - half)];
      if (window.length < size) {
        window = window.concat(pool.filter((p) => !window.includes(p)).slice(0, size - window.length));
      }
    }
  }
  if (!window) window = pool.slice(0, size);
  const bag = [...window];
  const picked = [];
  while (picked.length < want && bag.length) {
    picked.push(bag.splice(Math.floor(Math.random() * bag.length), 1)[0]);
  }
  return picked;
}

function recordPost(post, info = {}) {
  const l = loadLedger();
  const k = String(post.id);
  const prev = l[k] || {};
  l[k] = {
    id: Number(post.id) || post.id,
    file: info.file ?? prev.file ?? '',
    character: info.character ?? prev.character ?? '',
    tag: info.tag ?? prev.tag ?? '',
    artist: String(post.tag_string_artist || '').trim() || prev.artist || '',
    rating: post.rating || prev.rating || '',
    score: Number(post.score) || 0,
    favCount: Number(post.fav_count) || 0,
    source: String(post.source || '').trim() || prev.source || '',
    firstSeen: prev.firstSeen || Date.now(),
    lastSeen: Date.now(),
    sentCount: (prev.sentCount || 0) + 1,
    lastSent: Date.now()
  };
  saveLedger();
}

// ── HTTP ────────────────────────────────────────────────────────────────
function proxyOf(c) {
  const p = String(c?.proxy || '').trim();
  if (!p) return null;
  if (/^socks/i.test(p)) { warn(`设置里的代理是 ${p}，Node 的 fetch 不支持 socks5，本次按直连处理`); return null; }
  return p;
}

async function fetchWith(url, { timeoutMs = 25000, referer = '', binary = false } = {}) {
  // Node 的 fetch 不认 socks5 代理，代理留空时就是直连（本机常态）
  const r = await fetch(url, {
    headers: {
      'User-Agent': UA,
      Accept: binary ? 'image/*,*/*' : 'application/json',
      ...(referer ? { Referer: referer } : {})
    },
    redirect: 'follow',
    signal: AbortSignal.timeout(timeoutMs)
  });
  if (!r.ok) throw new Error(`HTTP ${r.status}`);
  return binary ? Buffer.from(await r.arrayBuffer()) : await r.text();
}

async function fetchJson(url, opt) {
  const text = await fetchWith(url, opt);
  try { return JSON.parse(text); } catch { throw new Error('返回的不是 JSON（可能被限流或需要登录）'); }
}

function sniffKind(buf) {
  const head = buf.subarray(0, 4).toString('hex');
  if (head.startsWith('ffd8')) return 'jpg';
  if (head.startsWith('89504e47')) return 'png';
  if (buf.subarray(0, 3).toString('ascii') === 'GIF') return 'gif';
  if (buf.subarray(8, 12).toString('ascii') === 'WEBP') return 'webp';
  return 'bin';
}

// ── 标签解析 ────────────────────────────────────────────────────────────
function slugify(s) {
  return String(s || '').trim().toLowerCase()
    .replace(/[^a-z0-9]+/g, '_')
    .replace(/^_+|_+$/g, '');
}

/**
 * 找到 Danbooru 上真正存在的标签。
 * 顺序：词典 > 模型给的英文标签 > 用名字模糊查 tags.json > 原名原样试。
 * 返回 { tag, from }，from ∈ dict/model/auto/raw。
 */
async function resolveTag(character, given, { timeoutMs } = {}) {
  const dict = loadTagDict();
  const hit = dict[character];
  if (hit) return { tag: hit, from: 'dict' };
  const g = String(given || '').trim();
  if (g) {
    rememberTag(character, g);
    return { tag: g, from: 'model' };
  }
  const slug = slugify(character);
  // 中文名 slug 化之后是空串（比如「普瑞赛斯」），那就只能靠词典或模型给标签
  if (slug && slug.length >= 2) {
    try {
      const u = `${API}/tags.json?limit=5&search%5Border%5D=count&search%5Bname_matches%5D=`
        + encodeURIComponent(`*${slug}*`);
      const list = await fetchJson(u, { timeoutMs });
      const best = (Array.isArray(list) ? list : [])
        .filter((t) => t && t.name && Number(t.post_count) > 0 && !t.is_deprecated)
        .sort((a, b) => (b.post_count || 0) - (a.post_count || 0))[0];
      if (best) {
        rememberTag(character, best.name);
        return { tag: best.name, from: 'auto', postCount: best.post_count };
      }
    } catch (e) { warn(`模糊查标签失败（${character}）：${e?.message ?? e}`); }
  }
  return { tag: String(character || '').trim(), from: 'raw' };
}

// ── 搜索 ────────────────────────────────────────────────────────────────
function ratingClause(ratings) {
  const r = String(ratings || '').trim().toLowerCase();
  if (!r || r === 'all' || r === 'any') return '';              // 不限（调用方要自己承担风险）
  const names = { g: 'general', s: 'sensitive', q: 'questionable', e: 'explicit' };
  const parts = r.split(/[,\s]+/).map((x) => names[x] || x).filter(Boolean);
  return parts.length ? `rating:${parts.join(',')}` : '';
}

function usable(p) {
  if (!p || p.id === undefined || p.id === null) return false;
  if (p.is_deleted === true || p.is_banned === true) return false;
  const ext = `.${String(p.file_ext || '').toLowerCase()}`;
  if (!IMG_EXT.has(ext)) return false;                           // mp4/zip 之类不在这儿发
  return Boolean(p.file_url || p.large_file_url);
}

async function searchPosts(tag, opt = {}) {
  const { ratings = 'general,sensitive', limit = 100, pages = 1, minScore = 0, timeoutMs = 25000 } = opt;
  const meta = ['order:score', ratingClause(ratings), minScore > 0 ? `score:>=${minScore}` : ''].filter(Boolean);
  const tags = [String(tag || '').trim(), ...meta].filter(Boolean).join(' ');
  const seen = new Set();
  const posts = [];
  let raw = 0;
  for (let page = 1; page <= pages; page += 1) {
    const u = `${API}/posts.json?limit=${limit}&only=${ONLY}&page=${page}&tags=${encodeURIComponent(tags)}`;
    let list;
    try { list = await fetchJson(u, { timeoutMs }); } catch (e) {
      if (!posts.length) throw e;
      warn(`第 ${page} 页拉取失败：${e?.message ?? e}`);
      break;
    }
    if (!Array.isArray(list) || !list.length) break;
    raw += list.length;
    for (const p of list) {
      if (seen.has(String(p?.id))) continue;
      seen.add(String(p?.id));
      if (usable(p)) posts.push(p);
    }
    if (list.length < limit) break;
  }
  posts.sort((a, b) => (Number(b.score) || 0) - (Number(a.score) || 0)
    || (Number(b.fav_count) || 0) - (Number(a.fav_count) || 0));
  return { posts, tags, raw, skipped: raw - posts.length };
}

/**
 * 这张图该下哪个地址 —— 返回**按顺序尝试**的候选列表。
 *
 * 为什么要有顺序（实测 2026-10-09）：cdn.donmai.us 对同一台机器的速度差别极大，
 * 原图实测 110KB/s ~ 2MB/s 都有，16MB 那张 90 秒都没下完。而 sample 只有 70~150KB、
 * 一两秒就到。所以：
 *   · 超过 maxMB（硬上限）→ 只发 sample，不再去碰原图；
 *   · 超过 preferSampleOverMB（默认 8MB）→ 也先发 sample（快、稳，QQ 反正要压）；
 *   · 其它情况 → 先原图，下不动再退 sample（这一步保证"不会因为一张慢图整单失败"）。
 */
function urlChoices(p, { maxMB = 12, preferSampleOverMB = 8 } = {}) {
  const size = Number(p.file_size) || 0;
  const mb = size / 1048576;
  const sample = p.large_file_url || '';
  const original = p.file_url || '';
  const webp = String(p.file_ext || '').toLowerCase() === 'webp';
  if (!original) return sample ? [{ url: sample, sample: true, why: '这个作品没有原图地址' }] : [];
  if (sample && size > maxMB * 1048576) {
    return [{ url: sample, sample: true, why: `原图 ${mb.toFixed(1)}MB 超过 ${maxMB}MB 上限` }];
  }
  if (sample && size > preferSampleOverMB * 1048576) {
    return [{ url: sample, sample: true, why: `原图 ${mb.toFixed(1)}MB 偏大，改发压缩预览图` }];
  }
  if (sample && webp) {
    return [{ url: sample, sample: true, why: 'webp 在 QQ 里有些端不显示' }, { url: original, sample: false, why: '' }];
  }
  return [
    { url: original, sample: false, why: '' },
    ...(sample ? [{ url: sample, sample: true, why: '原图没下下来，退回压缩预览图' }] : [])
  ];
}

// ── 下载 ────────────────────────────────────────────────────────────────
async function downloadTo(url, destDir, { timeoutMs = 25000, name = 'danbooru' } = {}) {
  fs.mkdirSync(destDir, { recursive: true });
  const buf = await fetchWith(url, { timeoutMs, referer: `${API}/`, binary: true });
  if (!buf || buf.length < 512) throw new Error('下到的内容太小，不像图片');
  const kind = sniffKind(buf);
  if (kind === 'bin') throw new Error('下到的不是图片');
  const hash = crypto.createHash('md5').update(buf).digest('hex').slice(0, 10);
  const safe = String(name).replace(/[^\w\u4e00-\u9fff-]/g, '_').slice(0, 24) || 'img';
  const file = path.join(destDir, `${Date.now()}_${safe}_${hash}.${kind}`);
  fs.writeFileSync(file, buf);
  return { file, kind, bytes: buf.length };
}

// ── 信息文本 ────────────────────────────────────────────────────────────
const RATING_CN = { g: '全年龄', s: '轻微暗示', q: '擦边', e: 'R18' };

function compactNum(n) {
  const v = Number(n) || 0;
  if (v < 10000) return String(v);
  return `${(v / 10000).toFixed(v >= 100000 ? 0 : 1).replace(/\.0$/, '')}万`;
}

function formatInfo(p, extra = {}) {
  const artists = String(p.tag_string_artist || '').trim().split(/\s+/).filter(Boolean).slice(0, 3);
  const chars = String(p.tag_string_character || '').trim().split(/\s+/).filter(Boolean).slice(0, 3);
  const bits = [];
  bits.push(`⬆ ${Number(p.score) || 0}`);
  bits.push(`❤ ${compactNum(p.fav_count)}`);
  bits.push(`🔞 ${RATING_CN[p.rating] || p.rating || '未知'}`);
  const lines = [`🏷 ${extra.character || 'Danbooru'}｜${bits.join(' ｜ ')}`];
  const detail = [];
  if (artists.length) detail.push(`🎨 ${artists.join(' / ')}`);
  if (chars.length) detail.push(`👤 ${chars.join(' / ')}`);
  detail.push(`#${p.id}`);
  lines.push(detail.join(' ｜ '));
  lines.push(`🔗 https://danbooru.donmai.us/posts/${p.id}`);
  if (extra.sample && extra.sampleWhy) lines.push(`（发的是压缩预览图：${extra.sampleWhy}）`);
  if (extra.note) lines.push(extra.note);
  return lines.join('\n');
}

// ── 主流程：搜 → 挑 → 下载 → 发 ─────────────────────────────────────────
/**
 * 按标签找图并发到指定会话。
 * @returns { ok, sent:[], failed:[], reusedOld, sampled:[], picked, tag, tags, raw, skipped, posts }
 */
async function sendTagImages(ctx, {
  character = '', tag = '', work = '', count = 1, ratings = '', note = '', label = '[Danbooru]', allowRepostGiven = false
} = {}) {
  const c = cfg() || {};
  const timeoutMs = num(c.timeoutMs, 5000, 120000, 25000);
  const proxy = proxyOf(c);
  const maxMB = num(c.maxMB, 1, 100, 12);
  const limit = num(c.poolLimit, 10, 200, 100);
  const pages = num(c.pages, 1, 5, 1);
  const minScore = num(c.minScore, 0, 99999, 0);
  const chatKey = ctx?.chatKey;
  const want = num(count, 1, 5, num(c.count, 1, 5, 1));

  const resolved = await resolveTag(character, tag, { timeoutMs });
  let useTag = resolved.tag;
  let fellBackToWork = false;
  const r = await searchPosts(useTag, { ratings: ratings || c.ratings || 'general,sensitive', limit, pages, minScore, timeoutMs });

  // 角色标签下一张都没有 → 退到作品标签（会明确标注可能混了别的角色）
  const workTag = String(work || '').trim() || loadTagDict()[work] || '';
  if (!r.posts.length && workTag) {
    const wt = await resolveTag(workTag, workTag, { timeoutMs });
    const r2 = await searchPosts(wt.tag, { ratings: ratings || c.ratings || 'general,sensitive', limit, pages, minScore, timeoutMs });
    if (r2.posts.length) {
      fellBackToWork = true;
      useTag = wt.tag;
      Object.assign(r, r2);
    }
  }

  if (!r.posts.length) {
    return {
      ok: true, empty: true, sent: [], failed: [], candidates: 0, topScore: 0,
      tag: useTag, tags: r.tags, resolvedFrom: resolved.from, raw: r.raw, skipped: r.skipped
    };
  }

  const preferFresh = c.preferFresh !== false;
  // 跨源去重（Pixiv 发过的同一张画，Danbooru 这边也跳过）
  const candidates = preferFresh ? r.posts.filter((p) => !pixivSent(p)) : r.posts;
  const fresh = preferFresh ? candidates.filter((p) => !hasPost(p.id)) : candidates;
  const stale = preferFresh ? candidates.filter((p) => hasPost(p.id)) : [];
  // 硬规则（2026-10-09，用户抱怨"怎么老发重复的图"之后定的）：
  // **只要还有没发过的，就绝不动旧图**；旧图只在 allowRepost 打开时才拿来凑数。
  const allowRepost = allowRepostGiven === true || c.allowRepost === true;
  const useStale = allowRepost && fresh.length < want;
  const pool = useStale ? [...fresh, ...stale] : fresh;
  // 默认随机从高分窗口里抽（见 pickImages 的注释）；想回到"永远取最高分"就把设置改成 top
  const picked = pickImages(pool, want, {
    mode: String(c.pickMode || 'random'),
    poolSize: num(c.randomPool, 1, 100, 24),
    balance: c.balanceRatings !== false
  });
  const reusedOld = picked.some((p) => hasPost(p.id));
  const withheldOld = !allowRepost && fresh.length < want ? stale.length : 0;

  // 全是发过的 → 不重复发，直接告诉调用方（想重发就带 allowRepost=true）
  if (!picked.length) {
    return {
      ok: true, allSent: true, sent: [], failed: [], candidates: candidates.length,
      withheld: withheldOld, tag: useTag, tags: r.tags, topScore: Number(r.posts[0]?.score) || 0,
      resolvedFrom: resolved.from, raw: r.raw, skipped: r.skipped
    };
  }

  const folder = (character || useTag).replace(/[^\w\u4e00-\u9fff-]/g, '_').slice(0, 24) || 'misc';
  const destDir = path.join(imageDir(), folder);
  const sent = [];
  const failed = [];
  const sampled = [];
  const showInfo = c.showInfo !== false;
  const dlTimeoutMs = num(c.downloadTimeoutMs, 5000, 180000, 40000);
  const preferSampleOverMB = num(c.preferSampleOverMB, 0, 100, 8);
  const deadline = Date.now() + num(c.totalTimeoutMs, 15000, 300000, 100000);

  // 逐张试到够数为止：某一张下不动就**顺延到下一个候选**。
  // （实测同一个图床快慢能差 20 倍：110KB/s ~ 2MB/s，16MB 那张 90 秒都没下完。
  //   老写法"挑好了才下载、失败就整单报错"在这种图床上基本等于随机失败。）
  //
  // ⚠️ 2026-10-09 踩过的坑：这里**必须从 picked（随机抽出来的）开始遍历**。
  //    之前直接遍历 pool，而 pool 是按分数排好的 → 随机设置完全空转，
  //    每次发的还是最高分那几张（"随机"形同虚设，是用户发现图老是一样的根因）。
  const queue = [...picked, ...pool.filter((p) => !picked.includes(p))];
  let cursor = 0;
  const maxAttempts = Math.min(queue.length, want + 3);
  while (sent.length < want && cursor < maxAttempts && Date.now() < deadline) {
    const p = queue[cursor++];
    if (!p || sent.some((s) => String(s.id) === String(p.id))) continue;
    let done = false;
    let lastErr = '';
    for (const choice of urlChoices(p, { maxMB, preferSampleOverMB })) {
      try {
        const got = await downloadTo(choice.url, destDir, { timeoutMs: dlTimeoutMs, name: folder });
        if (choice.sample) sampled.push({ id: p.id, why: choice.why, kb: Math.round(got.bytes / 1024) });
        await ctx.sender.sendImage(chatKey, { file: got.file }, { note: `Danbooru ${p.id}` });
        if (showInfo) {
          try {
            await ctx.sender.sendTextBatch(chatKey, [formatInfo(p, {
              character: character || useTag,
              sample: choice.sample,
              sampleWhy: choice.why,
              note: fellBackToWork ? `⚠️ 「${resolved.tag}」没找到图，这批是按作品标签「${useTag}」捞的，可能含同作品其他角色` : ''
            })]);
          } catch { /* 信息发失败不该把「图已经发出去了」变成失败 */ }
        }
        sent.push({
          id: p.id, score: Number(p.score) || 0, rating: p.rating,
          artist: String(p.tag_string_artist || '').trim(), file: got.file,
          sample: choice.sample, kb: Math.round(got.bytes / 1024)
        });
        recordPost(p, { file: got.file, character, tag: useTag });
        done = true;
        break;
      } catch (e) {
        lastErr = String(e?.message ?? e);
        warn(`第 ${p.id} 张（${choice.sample ? '压缩预览图' : '原图'}）没下下来：${lastErr}`);
      }
    }
    if (!done) failed.push({ id: p.id, error: lastErr || '未知错误' });
  }

  if (sent.length) {
    log(`Danbooru 已发 ${sent.length} 张（标签「${useTag}」，候选 ${r.posts.length} 张，最高 ${Number(r.posts[0]?.score) || 0} 分）`);
  }

  return {
    ok: true,
    sent,
    failed,
    sampled,
    reusedOld,
    fellBackToWork,
    tag: useTag,
    resolvedFrom: resolved.from,
    tags: r.tags,
    raw: r.raw,
    skipped: r.skipped,
    candidates: r.posts.length,
    withheldOld,
    topScore: Number(r.posts[0]?.score) || 0,
    label,
    note
  };
}

/** pixiv-image-tagsearch 的「图太少」兜底入口：返回一句给模型看的话 */
async function supplement(ctx, { character, tag, work, count = 2 } = {}) {
  const r = await sendTagImages(ctx, { character, tag, work, count, label: '[Danbooru 补充]' });
  if (r.empty) {
    return { ok: false, sent: 0, reason: 'empty', text: `Danbooru 上也没找到「${character || tag}」的图（查的是 ${r.tags}）` };
  }
  if (r.allSent) {
    return {
      ok: false, sent: 0, reason: 'all-sent',
      text: `Danbooru 上「${character || tag}」的 ${r.candidates} 张图**也都发过了**，不重复发`
    };
  }
  const list = r.sent.map((s) => `#${s.id}（${s.score} 分${s.sample ? '，预览图' : ''}）`).join('、');
  return {
    ok: r.sent.length > 0,
    sent: r.sent.length,
    reason: r.sent.length ? 'sent' : 'download-failed',
    text: `Pixiv 那边图太少，已从 Danbooru 补发 ${r.sent.length} 张（标签「${r.tag}」）：${list}`
      + (r.reusedOld ? '；其中含以前发过的' : '')
      + (r.fellBackToWork ? `；注意是按作品标签「${r.tag}」捞的，可能含同作品其他角色` : '')
  };
}

// ── 工具注册 ────────────────────────────────────────────────────────────
export function setup(api) {
  cfg = api.config;
  log = api.log;
  warn = api.warn;

  const dict = loadTagDict();
  api.log(`Danbooru 找图已注册｜词典 ${Object.keys(dict).length} 条｜发过 ${Object.keys(loadLedger()).length} 张`);

  api.registerTool({
    id: 'danbooru_image_tag',
    name: 'Danbooru 找图（标签检索）',
    description:
      '按角色/作品从 **Danbooru** 找图并发到当前会话：免 API key，候选是 `order:score` 的**高分图**，'
      + '**默认把 general（全年龄）和 sensitive（轻微暗示）两种都算进候选，再从分数最高的一批里随机挑**'
      + '（所以同一个角色每次发的可能不一样），questionable/explicit（擦边/R18）一律不发；'
      + '发完补一条画师/分数/收藏/出处。'
      + '适用：群友说「来张 XX」「找张 XX 的图」；**尤其是 pixiv_image_tag 返回「没搜到」或只搜到一两张的时候，改用它补齐**。'
      + 'character 填角色名（中文也行，技能里有词典）；知道 Danbooru 英文标签就直接填 tag（普瑞赛斯→priestess_(arknights)、阿米娅→amiya_(arknights)）。'
      + '**别自己改分级**：rating 参数一般不用填（默认就是两种都发、随机挑）；对方明确说"只要全年龄"才填 general。'
      + '工具会自己把图和作品信息发到当前会话；你拿到结果后用 send_message 回一句短话即可，别复述分数和链接。'
      + '如果结果里说「退到了作品标签」，必须如实告诉对方「可能混了同作品的其他角色」。',
    category: 'media',
    icon: '📚',
    parameters: {
      type: 'object',
      properties: {
        character: { type: 'string', description: '角色名（或作品名），例如「普瑞赛斯」「阿米娅」「明日方舟」。' },
        tag: { type: 'string', description: '可选：该角色在 Danbooru 的英文标签，例如 priestess_(arknights)。知道就填，能明显提高命中率。' },
        work: { type: 'string', description: '可选：角色所属作品的 Danbooru 标签（例如 arknights）。角色标签下一张都没有时，用它兜底捞同作品的图。' },
        count: { type: 'number', description: '发几张，1~5，默认 1。' },
        allowRepost: {
          type: 'boolean',
          description: '只有在**用户明确要求"再发一遍/重发刚才那些"**时才填 true —— '
            + '默认 false＝发过的图绝不重复发（下次请求会换成没发过的，全都发过了就直说"都发过了"）。'
        },
        rating: {
          type: 'string',
          description: '可选：内容分级，**一般不用填**。不填＝默认 general,sensitive（全年龄 + 轻微暗示两种都发，随机挑）；'
            + '对方明确说"只要全年龄"时才填 general；all＝不限（含擦边/R18，基本不要用）。'
        }
      },
      required: ['character']
    },
    async execute(ctx, args) {
      try {
        const character = String(args?.character ?? '').trim();
        if (!character) return { content: '缺少 character：请告诉我要哪个角色的图。', isError: true };
        const r = await sendTagImages(ctx, {
          character,
          tag: String(args?.tag ?? '').trim(),
          work: String(args?.work ?? '').trim(),
          count: args?.count,
          ratings: String(args?.rating ?? '').trim(),
          allowRepostGiven: args?.allowRepost === true,
          label: '[Danbooru]'
        });

        if (r.allSent) {
          return {
            content: `「${character}」在 Danbooru 上能找到 ${r.candidates} 张（标签 ${r.tag}），但**这些都已经发过了**，`
              + `所以这次没有重复发（默认不重发）。如果用户就是想再看一遍，再调一次并带上 allowRepost=true 即可。`,
            isError: r.candidates === 0
          };
        }
        if (r.empty) {
          return {
            content: `Danbooru 上没找到「${character}」的图（查的是 ${r.tags}，原始返回 ${r.raw} 条、可用 ${r.candidates} 条）。`
              + '可以：① 换个更标准的英文标签再试（tag 参数）；② 填 work 参数用作品标签兜底；③ 让 pixiv_image_tag 那边再试试。'
              + '（只搜全年龄和轻微暗示两档，擦边/R18 不搜 —— 所以也可能出现"这个角色只有擦边图"的情况。）',
            isError: true
          };
        }
        if (!r.sent.length) {
          return { content: `找到 ${r.candidates} 张但都没下载成功（网络或图床问题），稍后再试。`, isError: true };
        }

        const list = r.sent.map((s) => `#${s.id}（${s.score} 分${s.sample ? '，预览图' : ''}）`).join('、');
        return {
          content: `【已发送】${r.sent.length} 张「${character}」的图到会话里了（Danbooru 标签「${r.tag}」，候选 ${r.candidates} 张，最高 ${r.topScore} 分）：${list}。`
            + (r.fellBackToWork ? `【注意】「${character}」这个角色标签下没图，这批是按**作品标签「${r.tag}」**捞的，可能含同作品的其他角色 —— 回话时必须如实说明。` : '')
            + (r.reusedOld ? '其中包含以前发过的图（这个标签下的新图挑得差不多了）。' : '')
            + (r.withheldOld ? `另有 ${r.withheldOld} 张是以前发过的，**这次没有重复发**（默认不重发）。` : '')
            + (r.sent.some((s) => s.sample) ? '部分图发的是压缩预览图（原图超过体积上限），别说是原图。' : '')
            + (r.failed.length ? `另有 ${r.failed.length} 张下载失败。` : '')
            + '图和作品信息都已经发出去了：你只要用 send_message 回一句短话，不要复述分数、标签或链接。',
          isError: false
        };
      } catch (e) {
        warn(`danbooru_image_tag 异常：${e?.stack ?? e}`);
        return { content: `Danbooru 找图出错：${e?.message ?? e}`, isError: true };
      }
    }
  });
}

export function available() { return true; }

export const internals = {
  searchPosts, resolveTag, sendTagImages, supplement, downloadTo, formatInfo,
  ratingClause, urlChoices, pickImages,
  loadTagDict, loadLedger, tagDictFile, ledgerFile, dataDir, imageDir, slugify
};
