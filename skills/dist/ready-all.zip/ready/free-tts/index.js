// 免费语音说话：让机器人把一句话「说出来」，而不只是打字。
//
// 数据流：模型调用 free-tts__say(text, voice?, speed?, pitch?)
//         → 合成 mp3（Edge 神经网络语音 或 百度备用）
//         → ctx.sender.sendMedia() 发一条 record 段 → QQ 里是一颗语音气泡。
//
// ── 两套引擎 ──────────────────────────────────────────────────────────────
//   edge（默认）：微软神经网络语音，14 个中文音色（晓晓/晓伊/云希/云健/方言…），
//                 自然度高、可调语速音调，免费无需 Key。实现见 edge.js。
//   baidu（备用）：百度公开朗读接口，音质一般但极稳定，兜底用。
//   两者都免费；Edge 失败会自动降级到百度，保证"总能说出一句话"。
//
// ── 为什么走 ctx.sender.sendMedia ────────────────────────────────────────
// src/sender.js 明确写着：插件**不得**绕过发送队列直接调 onebot.sendSegments，
// 否则会跳过限频与留档（表现为"媒体把配额吃光后突然发不出话"、重启后重复发）。
// sendMedia 就是为此准备的公共入口，mp3 → silk 的转码由协议端自己做
// （snowluma 的 loadPtt → encodeSilk，自带 ffmpeg 转码）。

import crypto from 'node:crypto';
import { createRequire } from 'node:module';

// ═══════════════════════════════════════════════════════════════════════
// Edge 神经网络语音引擎（内联，原本是 edge.js）
//
// ⚠️ 为什么必须内联：插件加载器热重载走 await import(${entryUrl}?t=)，
//    **只**给入口文件加时间戳破除缓存，内部 import 的其它模块仍命中 ESM 模块缓存。
//    结果就是改了 edge.js 却永远加载旧版本，排查时表现为「明明修好了还报原来的错」。
//    全部放一个文件，时间戳才能覆盖所有代码。
// ═══════════════════════════════════════════════════════════════════════
// Edge TTS 引擎：微软神经网络语音，免费、无需 Key、多音色。
//
// 为什么单独一个文件：这段逻辑是逆向出来的（Sec-MS-GEC v2 签名 + WebSocket 私有协议），
// 独立成模块便于单测与替换，也免得把 free-tts/index.js 撑得太长。
//
// ── 关键实现细节（踩过的坑，别乱改）────────────────────────────────────────
//   ① Sec-MS-GEC-Version 前缀必须是 "2-"，不是 "1-"（写错即 403）
//   ② Sec-MS-GEC 是 v2 格式："<16位CS64十六进制>-<64位SHA256十六进制>"
//      且用的是**非标准 SHA256 变体**（改过初始状态/轮常量），照敲标准 SHA256 会得到
//      格式正确但服务端拒收的 token —— 所以这里逐行移植了官方 drm.py
//   ③ 要念的文字放进 SSML 的 <voice> 里；rate/pitch/volume 用 prosody 控制


const TRUST = '6A5AA1D4EAFF4E9FB37E23D68491D6F4';
const WIN_EPOCH = 11644473600;
const CHROMIUM = '143.0.3650.75';
const MAJOR = CHROMIUM.split('.')[0];
const SEC_VERSION = `2-${CHROMIUM}`;
const WSS_BASE = 'wss://speech.platform.bing.com/consumer/speech/synthesize/readaloud/edge/v1';

// ── 非标准 SHA256 的常量（来自官方 drm.py，改动会导致 token 校验失败）──────────
const SHA_INITIAL = [0x6A09E667, 0xBB67AE85, 0x3C6EF372, 0xA54FF53A, 0x510E527F, 0x9B05688C, 0x1F83D9AB, 0x5BE0CD19];
const SHA_STATE_SEED = [0xFD9FBEA2, 0x91243CE7, 0xBE499094, 0xCD2E1E0A, 0x6C006F49, 0x04BD35AB, 0xFEB0A7E4, 0x03EFFBD2];
const SHA_SCHED = [0xEB24BF9E, 0x1558691F, 0xA0C09EE2, 0x0CFA32BA, 0xA622EE8C, 0xD1DD9491, 0xC0DD25A0, 0xF9E70AB6, 0xF0C31573, 0x7058CE4E, 0x7188E606, 0x00E5AB33, 0xD258B060, 0x72766564];
const SHA_K = [
  0x428A2F98, 0x71374491, 0xB5C0FBCF, 0xE9B5DBA5, 0x3956C25B, 0x59F111F1, 0x923F82A4, 0xAB1C5ED5,
  0xD807AA98, 0x12835B01, 0x243185BE, 0x550C7DC3, 0x72BE5D74, 0x80DEB1FE, 0x9BDC06A7, 0xC19BF174,
  0xE49B69C1, 0xEFBE4786, 0x0FC19DC6, 0x240CA1CC, 0x2DE92C6F, 0x4A7484AA, 0x5CB0A9DC, 0x76F988DA,
  0x983E5152, 0xA831C66D, 0xB00327C8, 0xBF597FC7, 0xC6E00BF3, 0xD5A79147, 0x06CA6351, 0x14292967,
  0x27B70A85, 0x2E1B2138, 0x4D2C6DFC, 0x53380D13, 0x650A7354, 0x766A0ABB, 0x81C2C92E, 0x92722C85,
  0xA2BFE8A1, 0xA81A664B, 0xC24B8B70, 0xC76C51A3, 0xD192E819, 0xD6990624, 0xF40E3585, 0x106AA070,
  0x19A4C116, 0x1E376C08, 0x2748774C, 0x34B0BCB5, 0x391C0CB3, 0x4ED8AA4A, 0x5B9CCA4F, 0x682E6FF3,
  0x748F82EE, 0x78A5636F, 0x84C87814, 0x8CC70208, 0x90BEFFFA, 0xA4506CEB, 0xBEF9A3F7, 0xC67178F2,
];
const SHA_ADJ = 0xC9DC06A7;
const SHA_K_BLOCK = [...SHA_K.slice(0, 14), SHA_ADJ, ...SHA_K.slice(15)];
const SHA_SIGMA0_ADJ = 0x059C0B80;
const SHA_SIGMA1_ADJ = 0x000B92C0;

const CS64_COEF = [
  [0xE82E91B1, 0xB32700D0], [0x44DE24C6, 0x88DFF51D], [0x3BEB65BC, 0x29514038], [0xC89C5933, 0xB328CBDF],
  [0x8D1EC211, 0xD405B4D5], [0x314EF5D5, 0x26E55F3C], [0xE92491B1, 0x607801C6], [0xF0A5B9D5, 0x82B2C1FB],
  [0x06064CF3, 0xFA51A3DA], [0xDA79FA60, 0x207CC464], [0xBED20560, 0x3C3C74F3], [0x89F9C9F8, 0xD2D14B61],
  [0x35FA38C6, 0xBB04A2C1], [0xCB49E3C6, 0xC5626167],
];
const CS64_FACTOR = 0x82893933;
const CS64_ADJ0 = 0xF2F90B1A;
const CS64_ADJ1 = 0x0B1A0000;

const u = (x) => x >>> 0;
const rotr = (x, n) => ((x >>> n) | (x << (32 - n))) >>> 0;
const rol = (x, n) => ((x << n) | (x >>> (32 - n))) >>> 0;
const rol16 = (v) => u((v << 16) | (v >>> 16));
const add = (...xs) => xs.reduce((a, b) => (a + b) >>> 0, 0);
/** JS 的 * 超过 2^53 会丢精度，凡是 u32*u32 一律走 BigInt */
const mul = (x, y) => Number((BigInt(x) * BigInt(y)) & 0xffffffffn);

const S0 = (v) => u(rotr(v, 7) ^ rotr(v, 18) ^ (v >>> 3));
const S1 = (v) => u(rotr(v, 17) ^ rotr(v, 19) ^ (v >>> 10));
const L0 = (v) => u(rotr(v, 2) ^ rotr(v, 13) ^ rotr(v, 22));
const L1 = (v) => u(rotr(v, 6) ^ rotr(v, 11) ^ rotr(v, 25));

function compress(state, words, firstRound = 0) {
  let [a, b, c, d, e, f, g, h] = state.map(u);
  const cst = firstRound === 14 ? SHA_K_BLOCK : SHA_K;
  for (let i = firstRound; i < 64; i++) {
    const t1 = add(h, L1(e), g ^ (e & (f ^ g)), cst[i], words[i]);
    const t2 = add(L0(a), (a & b) | (c & (a | b)));
    h = g; g = f; f = e; e = add(d, t1);
    d = c; c = b; b = a; a = add(t1, t2);
  }
  return [a, b, c, d, e, f, g, h];
}

function expand(words, from = 16) {
  for (let i = from; i < 64; i++) {
    words.push(add(S1(words[i - 2]), words[i - 7], S0(words[i - 15]), words[i - 16]));
  }
}

const initCache = new Map();
function shaInit(prefix7) {
  const key = prefix7.toString('hex');
  if (initCache.has(key)) return initCache.get(key);
  const words = [...Array(14).fill(0), prefix7.readUIntBE(0, 3), prefix7.readUIntBE(3, 4)];
  for (let i = 16; i < 30; i++) {
    let v = SHA_SCHED[i - 16];
    if (i - 2 >= 14) v = add(v, i === 16 ? (S1(words[i - 2]) ^ SHA_SIGMA1_ADJ) : S1(words[i - 2]));
    if (i - 7 >= 14) v = add(v, words[i - 7]);
    if (i - 15 >= 14) v = add(v, i === 29 ? (S0(words[i - 15]) ^ SHA_SIGMA0_ADJ) : S0(words[i - 15]));
    words.push(v);
  }
  words.push(add(S1(words[28]), words[23], S0(words[15]), words[14], SHA_ADJ, -SHA_K[14]));
  expand(words, 31);
  const working = compress(SHA_STATE_SEED, words, 14);
  const out = working.map((x, i) => add(x, SHA_INITIAL[i]));
  initCache.set(key, out);
  return out;
}

function shaDigest(data) {
  const length = 57 + data.length;
  const padLen = ((55 - length) % 64 + 64) % 64;
  const tail = Buffer.concat([data.subarray(7), Buffer.from([0x80]), Buffer.alloc(padLen)]);
  const lenBuf = Buffer.alloc(8);
  lenBuf.writeBigUInt64BE(BigInt(length * 8));
  const padded = Buffer.concat([tail, lenBuf]);
  let state = shaInit(data.subarray(0, 7));
  for (let off = 0; off < padded.length; off += 64) {
    const blk = padded.subarray(off, off + 64);
    const words = [];
    for (let i = 0; i < 16; i++) words.push(blk.readUInt32BE(i * 4));
    expand(words);
    const w = compress(state, words);
    state = w.map((x, i) => add(x, state[i]));
  }
  const out = Buffer.alloc(32);
  state.forEach((v, i) => out.writeUInt32BE(v, i * 4));
  return out;
}

function wordsLe4Even(buf) {
  const padded = Buffer.concat([buf, Buffer.alloc((4 - (buf.length % 4)) % 4)]);
  const w = [];
  for (let i = 0; i < padded.length; i += 4) w.push(padded.readUInt32LE(i));
  if (w.length % 2) w.push(0);
  return w;
}

function cs64(data, digest) {
  const ka = u(digest.readUInt32LE(0) | 1);
  const kb = u(digest.readUInt32LE(4) | 1);
  const factors = [mul(ka, CS64_FACTOR), mul(kb, CS64_FACTOR)];
  const terms = CS64_COEF.map(([coef], i) => mul(coef, factors[i % 2]));
  const offsets = CS64_COEF.map(([, off]) => off);
  const w = wordsLe4Even(Buffer.concat([Buffer.from([0]), data]));
  w.forEach((word, i) => {
    const even = i % 2 === 0;
    let term = mul(word, even ? ka : kb);
    let offset = mul(rol16(word), even ? 0xEF0569FB : 0xC31713DB);
    if (i === 0) {
      term = add(term, mul(CS64_ADJ0, factors[0]));
      offset = add(offset, CS64_ADJ1);
    }
    terms.push(term);
    offsets.push(offset);
  });
  let swapAcc = 0, swapLast = 0, state = 0, acc = 0;
  for (let i = 0; i < terms.length; i += 2) {
    const x = terms[i], y = terms[i + 1];
    let t = rol16(add(offsets[i], x));
    let q = mul(t, 0x76F50F34);
    swapAcc = add(swapAcc, add(mul(rol16(q), 0xC3EFEA97), q));
    t = rol16(add(offsets[i + 1], y));
    q = mul(t, 0x1881CE3C);
    swapLast = add(mul(rol16(q), 0x35BD1EC9), q);
    swapAcc = add(swapAcc, swapLast);

    state = add(mul(state, ka), x);
    state = mul(rol16(state), 0xCF98B111);
    state = mul(rol16(state), 0x87085B9F);
    state = mul(rol16(state), 0x12CEB96D);
    state = mul(rol16(state), 0x257E1D83);
    acc = add(acc, state);
    t = add(mul(state, kb), y);
    t = mul(rol16(t), 0xA27416F5);
    t = mul(rol16(t), 0xD38396FF);
    state = mul(rol16(mul(rol16(t), 0x7C932B89)), 0xBFA49F69);
    acc = add(acc, state);
  }
  return [u(swapLast ^ state), u(swapAcc ^ acc)];
}

/** 生成 Sec-MS-GEC v2 token。unixTimestamp 仅测试时传入。 */
function generateSecMsGecV2(unixTimestamp = null) {
  let ticks = unixTimestamp ?? (Date.now() / 1000);
  ticks += WIN_EPOCH;
  ticks -= ticks % 300;
  ticks *= 1e9 / 100;
  const data = Buffer.from(`${Math.trunc(ticks)}${TRUST}`, 'ascii');
  const digest = shaDigest(data);
  const [c0, c1] = cs64(data, digest);
  const cs = Buffer.alloc(8);
  cs.writeUInt32LE(c0, 0);
  cs.writeUInt32LE(c1, 4);
  return `${cs.toString('hex').toUpperCase()}-${digest.toString('hex').toUpperCase()}`;
}

function wsHeaders() {
  return {
    Pragma: 'no-cache',
    'Cache-Control': 'no-cache',
    Origin: 'chrome-extension://jdiccldimpdaibmpdkjnbmckianbfold',
    'Sec-WebSocket-Version': '13',
    'User-Agent': `Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/${MAJOR}.0.0.0 Safari/537.36 Edg/${MAJOR}.0.0.0`,
    'Accept-Encoding': 'gzip, deflate, br, zstd',
    'Accept-Language': 'en-US,en;q=0.9',
  };
}

/** prosody 数值 → 微软要求的格式：rate/pitch/volume 都是带符号百分比或 Hz */
const pct = (n) => {
  const v = Number(n);
  if (!Number.isFinite(v) || v === 0) return '+0%';
  return `${v > 0 ? '+' : ''}${Math.round(v)}%`;
};
const hz = (n) => {
  const v = Number(n);
  if (!Number.isFinite(v) || v === 0) return '+0Hz';
  return `${v > 0 ? '+' : ''}${Math.round(v)}Hz`;
};

/**
 * 解析可用的 WebSocket 实现。
 *
 * 为什么不能用 globalThis.WebSocket：Node 22 内置的 WebSocket 基于 undici，
 * **不接受自定义 headers**，而 Edge 的握手必须带 Origin / User-Agent 等头，
 * 少一个就是 403。所以优先用 QQ Agent 自带的 ws 库（package.json 里已有
 * ws ^8.18.0，就装在 resources/app/node_modules 下）。
 *
 * 返回 null 表示都拿不到，由调用方报错。
 */
let cachedWsCtor = null;
let wsResolved = false;

function resolveWsCtor() {
  if (wsResolved) return cachedWsCtor;
  wsResolved = true;
  // 从技能目录往上找 node_modules/ws（技能在 resources/app/skills/free-tts/）
  const candidates = [
    // QQ Agent 主进程的依赖目录
    new URL('../../node_modules/ws/index.js', import.meta.url),
  ];
  for (const url of candidates) {
    try {
      const require = createRequire(url);
      const mod = require('ws');
      cachedWsCtor = mod?.default ?? mod;
      if (typeof cachedWsCtor === 'function') return cachedWsCtor;
    } catch { /* 继续试下一个 */ }
  }
  cachedWsCtor = null;
  return cachedWsCtor;
}

/** 尝试把模块取出（ESM 动态 import 兜底）。 */
async function resolveWsCtorAsync() {
  const direct = resolveWsCtor();
  if (direct) return direct;
  for (const url of [
    new URL('../../node_modules/ws/index.js', import.meta.url),
  ]) {
    try {
      const mod = await import(url.href);
      const ctor = mod?.default ?? mod;
      if (typeof ctor === 'function') { cachedWsCtor = ctor; return ctor; }
    } catch { /* ignore */ }
  }
  return null;
}
async function synthesizeEdge(text, {
  voice = 'zh-CN-XiaoxiaoNeural',
  ratePct = 0,
  pitchHz = 0,
  volumePct = 0,
  timeoutMs = 30000,
  wsFactory = null,
} = {}) {
  const url = `${WSS_BASE}?TrustedClientToken=${TRUST}&Sec-MS-GEC=${generateSecMsGecV2()}&Sec-MS-GEC-Version=${SEC_VERSION}`;

  // ws 库必须支持自定义 headers（Node 内置 WebSocket 不支持，会 403）
  let makeWs = wsFactory;
  if (!makeWs) {
    const Ctor = await resolveWsCtorAsync();
    if (!Ctor) {
      throw new Error('找不到可用的 WebSocket 实现（需要 QQ Agent 自带的 ws 库；'
        + 'Node 内置 WebSocket 不支持握手头，无法用于 Edge 语音）');
    }
    makeWs = (u2, o) => new Ctor(u2, o);
  }

  return new Promise((resolve, reject) => {
    let settled = false;
    let timer = null;                     // 先声明：done() 可能在 timer 赋值前被调用
    const done = (fn, val) => {
      if (settled) return;
      settled = true;
      if (timer !== null) clearTimeout(timer);
      fn(val);
    };
    const chunks = [];
    let ws;
    timer = setTimeout(() => {
      try { ws?.close(); } catch {}
      done(reject, new Error(`Edge 语音合成超时（${timeoutMs}ms）`));
    }, timeoutMs);

    try {
      ws = makeWs(url, { headers: wsHeaders() });
    } catch (error) {
      done(reject, new Error(`Edge WebSocket 建立失败：${error?.message ?? error}`));
      return;
    }

    const onOpen = () => {
      const ts = new Date().toString();
      ws.send(`X-Timestamp:${ts}\r\nContent-Type:application/json; charset=utf-8\r\nPath:speech.config\r\n\r\n`
        + JSON.stringify({ context: { synthesis: { audio: { metadataoptions: { sentenceBoundaryEnabled: 'false', wordBoundaryEnabled: 'false' }, outputFormat: 'audio-24khz-48kbitrate-mono-mp3' } } } }));
      const ssml = `<speak version="1.0" xmlns="http://www.w3.org/2001/10/synthesis" xml:lang="zh-CN">`
        + `<voice name="${voice}"><prosody rate="${pct(ratePct)}" pitch="${hz(pitchHz)}" volume="${pct(volumePct)}">`
        + `${escapeXml(text)}</prosody></voice></speak>`;
      ws.send(`X-RequestId:${crypto.randomUUID().replace(/-/g, '')}\r\nContent-Type:application/ssml+xml\r\nX-Timestamp:${ts}Z\r\nPath:ssml\r\n\r\n${ssml}`);
    };

    /**
     * 处理一帧。
     *
     * ⚠️ 不能依赖 ws 库的 isBinary 参数：实测它把所有帧都报成 true（含 turn.start /
     * turn.end 这些文本帧），于是 turn.end 永远匹配不到，表现为「连上了、音频也收到了，
     * 但一直等到超时」。这里改成按 payload 内容判定：
     *   · 二进制音频帧 = 前 2 字节是大端头长度，随后是 X-RequestId/Path 文本头 + 音频
     *   · 控制帧 = 纯 ASCII 文本，含 "Path:" 关键字
     * 判定顺序：先尝试当文本解析（能解析出 Path: 就当文本），否则按二进制音频处理。
     */
    const onFrame = (data, binary) => {
      const buf = Buffer.isBuffer(data) ? data : Buffer.from(data);

      // 先按文本帧判定：Edge 的控制帧都以 "X-RequestId:" 或 "Path:" 开头
      const head = buf.subarray(0, Math.min(buf.length, 64)).toString('latin1');
      const looksLikeText = /^(X-RequestId:|X-Timestamp:|Content-Type:|Path:)/.test(head);
      if (looksLikeText || binary === false) {
        const text = buf.toString('utf8');
        if (text.includes('Path:turn.end')) {
          const out = Buffer.concat(chunks);
          try { ws.close(); } catch {}
          if (!out.length) done(reject, new Error('Edge 返回了结束标记但没有音频数据'));
          else done(resolve, out);
        }
        return;
      }

      // 二进制音频帧：前 2 字节 = 头部长度，跳过它之后是音频
      if (buf.length < 2) return;
      const hl = buf.readUInt16BE(0);
      if (hl > buf.length) return;                 // 头长度异常，丢弃
      const audio = buf.subarray(hl + 2);
      if (audio.length) chunks.push(audio);
    };

    const onError = (e) => {
      const msg = e?.message ?? e?.error?.message ?? String(e);
      done(reject, new Error(`Edge 连接失败：${msg}`));
    };

    // ws 库（Node）与浏览器 WebSocket 的事件接口不同，两种都兼容
    if (typeof ws.on === 'function') {
      ws.on('open', onOpen);
      // ws 的 message 回调带 (data, isBinary)，必须透传 isBinary
      ws.on('message', (data, isBinary) => onFrame(data, isBinary === true || Buffer.isBuffer(data)));
      ws.on('error', onError);
      ws.on('unexpected-response', (_q, res) => {
        done(reject, new Error(`Edge 握手被拒 HTTP ${res?.statusCode}`));
      });
    } else {
      ws.addEventListener('open', onOpen);
      ws.addEventListener('message', (ev) => onFrame(ev.data, typeof ev.data !== 'string'));
      ws.addEventListener('error', onError);
    }
  });
}

function escapeXml(s) {
  return String(s ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&apos;');
}

// ── 官方中文音色表（2026-10 实测 14 个）──────────────────────────────────
// 挑选标准：优先 zh-CN 普通话、音色自然度高的 Neural 系列
const EDGE_VOICES = {
  'xiaoxiao': { id: 'zh-CN-XiaoxiaoNeural', label: '晓晓 · 温暖女声（推荐）', gender: '女' },
  'xiaoyi': { id: 'zh-CN-XiaoyiNeural', label: '晓伊 · 活泼女声', gender: '女' },
  'yunxi': { id: 'zh-CN-YunxiNeural', label: '云希 · 少年男声', gender: '男' },
  'yunjian': { id: 'zh-CN-YunjianNeural', label: '云健 · 沉稳男声', gender: '男' },
  'yunxia': { id: 'zh-CN-YunxiaNeural', label: '云夏 · 少年男声', gender: '男' },
  'yunyang': { id: 'zh-CN-YunyangNeural', label: '云扬 · 播音男声', gender: '男' },
  'xiaobei': { id: 'zh-CN-liaoning-XiaobeiNeural', label: '晓北 · 东北话', gender: '女' },
  'xiaoni': { id: 'zh-CN-shaanxi-XiaoniNeural', label: '晓妮 · 陕西话', gender: '女' },
  'hiugaai': { id: 'zh-HK-HiuGaaiNeural', label: '曉佳 · 粤语女声', gender: '女' },
  'wanlung': { id: 'zh-HK-WanLungNeural', label: '雲龍 · 粤语男声', gender: '男' },
  'hsiaochen': { id: 'zh-TW-HsiaoChenNeural', label: '曉臻 · 台湾女声', gender: '女' },
  'hsiaoyu': { id: 'zh-TW-HsiaoYuNeural', label: '曉雨 · 台湾女声', gender: '女' },
  'yunjhe': { id: 'zh-TW-YunJheNeural', label: '雲哲 · 台湾男声', gender: '男' },
};

/** 英文音色（少量常用） */
const EDGE_EN_VOICES = {
  'emma': { id: 'en-US-EmmaMultilingualNeural', label: 'Emma · 多语女声', gender: '女' },
  'aria': { id: 'en-US-AriaNeural', label: 'Aria · 女声', gender: '女' },
  'guy': { id: 'en-US-GuyNeural', label: 'Guy · 男声', gender: '男' },
  'jenny': { id: 'en-US-JennyNeural', label: 'Jenny · 女声', gender: '女' },
};

// ── 内联结束 ────────────────────────────────────────────────────────────


const DEFAULT_TIMEOUT = 30000;

// ── 百度备用引擎 ─────────────────────────────────────────────────────────
// tts.baidu.com 的 per 音色：实测只有 per=0(女) 与 per=106(男) 能稳定出声，
// 其余编号会报 "failed to cluster verify"；aue=3 必须配 rate=4。
const BAIDU_VOICES = {
  female: { per: 0, label: '度小美 · 女声（机械音，备用）' },
  male: { per: 106, label: '度博文 · 男声（机械音，备用）' },
};

function baiduUrl(text, { per, spd = 5, pit = 5 }) {
  const enc = encodeURIComponent(text);
  return `https://tts.baidu.com/text2audio?tex=${enc}&cuid=baike&lan=ZH&ctp=1&pdt=301`
    + `&vol=9&per=${per}&spd=${spd}&pit=${pit}&aue=3&rate=4`;
}

// ── 运行期依赖 ───────────────────────────────────────────────────────────
let cfg = () => ({});
let log = () => {};
let apiFetch = null;

/**
 * 配置清洗。纯函数。
 */
export function readConfig(raw) {
  const c = raw && typeof raw === 'object' ? raw : {};
  const engine = c.engine === 'baidu' ? 'baidu' : 'edge';

  // 音色：优先用具体 id，其次用别名，最后回落到晓晓
  let voiceId = String(c.voiceId || '').trim();
  const alias = String(c.voice || '').trim();
  if (!voiceId) {
    if (alias && EDGE_VOICES[alias]) voiceId = EDGE_VOICES[alias].id;
    else if (alias && EDGE_EN_VOICES[alias]) voiceId = EDGE_EN_VOICES[alias].id;
    else if (/^[a-z]{2}-[A-Z]{2}-.+Neural$/.test(alias)) voiceId = alias;   // 直接写完整 id
    else voiceId = EDGE_VOICES.xiaoxiao.id;
  }

  const baiduVoice = String(c.baiduVoice || 'female').trim() === 'male' ? 'male' : 'female';
  const maxChars = Math.min(1000, Math.max(20, Math.floor(Number(c.maxChars)) || 150));
  const timeoutMs = Math.min(120000, Math.max(5000, Math.floor(Number(c.timeoutMs)) || DEFAULT_TIMEOUT));

  // 语速：统一用 -50% ~ +100% 表达，两套引擎各自换算
  const speedPct = clamp(Number(c.speedPct) || 0, -50, 100);
  // 音调：-50% ~ +50%（换算成 Hz 给 Edge）
  const pitchPct = clamp(Number(c.pitchPct) || 0, -50, 50);

  return {
    engine, voiceId, baiduVoice, maxChars, timeoutMs, speedPct, pitchPct,
    fallbackToBaidu: c.fallbackToBaidu !== false,
    alsoSendText: c.alsoSendText === true,
  };
}

function clamp(v, lo, hi) {
  return Math.min(hi, Math.max(lo, Number.isFinite(v) ? v : 0));
}

/**
 * 把模型给的 text 洗成"适合念出来"的样子。
 * 去掉 markdown / 表情 / 链接，换行变逗号停顿。
 */
export function normalizeSpeakText(input) {
  let s = String(input ?? '');
  s = s.replace(/```[\s\S]*?```/g, ' ');
  s = s.replace(/`([^`]*)`/g, '$1');
  s = s.replace(/!\[[^\]]*\]\([^)]*\)/g, ' ');
  s = s.replace(/\[([^\]]*)\]\([^)]*\)/g, '$1');
  s = s.replace(/https?:\/\/\S+/gi, '链接');
  s = s.replace(/^\s{0,3}#{1,6}\s*/gm, '');
  s = s.replace(/^\s{0,3}(?:[-*+]|\d+[.)])\s+/gm, '');
  s = s.replace(/[*_~]{1,3}([^*_~]+)[*_~]{1,3}/g, '$1');
  s = s.replace(/[*_~#>|]/g, ' ');
  s = s.replace(/[\r\n]+/g, '，');
  s = s.replace(/[ \t\u3000]+/g, ' ');
  s = s.replace(/，{2,}/g, '，').replace(/^[，、\s]+|[，、\s]+$/g, '');
  return s.trim();
}

/** 短指纹：发送队列去重键。 */
function fingerprint(text) {
  let h = 0x811c9dc5;
  const s = String(text);
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = (h + ((h << 1) + (h << 4) + (h << 7) + (h << 8) + (h << 24))) >>> 0;
  }
  return h.toString(16);
}

function snippet(text, max = 160) {
  const s = String(text ?? '').replace(/\s+/g, ' ').trim();
  return s.length > max ? `${s.slice(0, max)}…` : s;
}

/** 校验是不是音频字节。 */
export function looksLikeAudio(buf) {
  if (!buf || buf.length < 128) return false;
  const b = buf;
  if (b[0] === 0x49 && b[1] === 0x44 && b[2] === 0x33) return true;          // MP3/ID3
  if (b[0] === 0xFF && (b[1] & 0xE0) === 0xE0) return true;                 // MP3 帧
  if (b[0] === 0x52 && b[1] === 0x49 && b[2] === 0x46 && b[3] === 0x46) return true; // RIFF/WAV
  if (b[0] === 0x4F && b[1] === 0x67 && b[2] === 0x67 && b[3] === 0x53) return true; // OggS
  return false;
}

/** 百度引擎合成（备用）。 */
async function synthesizeBaidu(spoken, c) {
  if (typeof apiFetch !== 'function') throw new Error('缺少 fetch（清单里需要声明 web_fetch 权限）');
  const voice = BAIDU_VOICES[c.baiduVoice] || BAIDU_VOICES.female;
  // speedPct(-50..100) → spd(1..15)，5 为正常
  const spd = Math.min(15, Math.max(1, Math.round(5 + c.speedPct / 10)));
  const pit = Math.min(9, Math.max(1, Math.round(5 + c.pitchPct / 12)));
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), c.timeoutMs);
  let res;
  try {
    res = await apiFetch(baiduUrl(spoken, { per: voice.per, spd, pit }), {
      method: 'GET',
      signal: controller.signal,
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36',
        Referer: 'https://www.baidu.com/',
        Accept: 'audio/mpeg,audio/*;q=0.9,*/*;q=0.8',
      },
    });
  } catch (error) {
    clearTimeout(timer);
    if (error?.name === 'AbortError') throw new Error(`百度合成超时（${c.timeoutMs}ms）`);
    throw new Error(`百度请求失败：${error?.message ?? error}`);
  }
  clearTimeout(timer);
  if (!res.ok) throw new Error(`百度返回 HTTP ${res.status}`);
  const buf = Buffer.from(await res.arrayBuffer());
  if (!looksLikeAudio(buf)) {
    throw new Error(`百度返回的不是音频（${buf.length} 字节：${snippet(buf.toString('utf8', 0, 120))}）`);
  }
  return { buf, engine: 'baidu', voiceLabel: BAIDU_VOICES[c.baiduVoice].label };
}

/**
 * 合成语音：按配置选引擎，Edge 失败自动降级百度。
 * @param {object} args { text, voice, speedPct, pitchPct }
 */
export async function synthesize({ text, voice, speedPct, pitchPct } = {}) {
  const c = readConfig(cfg());
  const spoken = normalizeSpeakText(text);
  if (!spoken) throw new Error('要说的内容是空的（去掉表情/markdown 之后什么都没剩下）');
  if (spoken.length > c.maxChars) {
    throw new Error(`这句话太长（${spoken.length} 字，上限 ${c.maxChars} 字）。`
      + '把内容拆成几条短句分别调用，或者改用打字回复——QQ 语音太长会被拒收，念出来也像念稿。');
  }

  // 单句覆盖：模型可临时指定音色/语速/音调
  let vId = c.voiceId;
  if (voice) {
    const key = String(voice).trim();
    if (EDGE_VOICES[key]) vId = EDGE_VOICES[key].id;
    else if (EDGE_EN_VOICES[key]) vId = EDGE_EN_VOICES[key].id;
    else if (/^[a-z]{2}-[A-Z]{2}-.+Neural$/.test(key)) vId = key;
  }
  const ratePct = speedPct !== undefined ? clamp(Number(speedPct) || 0, -50, 100) : c.speedPct;
  const pitchVal = pitchPct !== undefined ? clamp(Number(pitchPct) || 0, -50, 50) : c.pitchPct;

  const attempts = [];
  if (c.engine === 'edge') {
    attempts.push(async () => {
      const buf = await synthesizeEdge(spoken, {
        voice: vId,
        ratePct,
        pitchHz: Math.round((pitchVal / 50) * 100),   // ±50% → ±100Hz
        timeoutMs: c.timeoutMs,
      });
      const known = Object.values(EDGE_VOICES).find((v) => v.id === vId)
        || Object.values(EDGE_EN_VOICES).find((v) => v.id === vId);
      return { buf, engine: 'edge', voiceLabel: known?.label || vId };
    });
  }
  if (c.engine === 'baidu' || (c.engine === 'edge' && c.fallbackToBaidu)) {
    attempts.push(() => synthesizeBaidu(spoken, c));
  }

  const failures = [];
  for (const attempt of attempts) {
    try {
      const out = await attempt();
      if (!looksLikeAudio(out.buf)) throw new Error('合成结果不是有效音频');
      if (failures.length) log(`已降级到「${out.engine}」引擎（原因：${failures.join('；')}）`);
      log(`语音合成完成：${spoken.length} 字，${out.buf.length} 字节，引擎=${out.engine}，音色=${out.voiceLabel}`);
      return { ...out, spoken };
    } catch (error) {
      const msg = String(error?.message ?? error);
      failures.push(msg);
      log(`引擎失败：${msg}`);
    }
  }
  throw new Error(`语音合成全部失败：${failures.join('；')}`);
}

// ── 技能生命周期 ─────────────────────────────────────────────────────────

export function setup(api) {
  cfg = api.config;
  log = api.log || (() => {});
  apiFetch = api.fetch;

  api.registerTool({
    id: 'say',
    name: '用语音说话',
    category: 'media',
    icon: '🔊',
    description: '把一句话用你自己的声音说出来，发成一条真正的QQ语音消息（不是文字）。免费、无需 API Key，支持多种音色（晓晓/晓伊/云希/云健/方言等）。只在用户明确要你用语音，或语音明显比文字更合适时用。一次只适合一两句短话；发完不要再把同一句话用文字发一遍。',
    parameters: {
      type: 'object',
      additionalProperties: false,
      properties: {
        text: { type: 'string', description: '要说出口的话。会被逐字念出来，所以别写表情符号、markdown、括号里的动作描写；一两句、80 字内最好。' },
        voice: {
          type: 'string',
          description: '可选音色别名：xiaoxiao(晓晓·温暖女声,默认) / xiaoyi(晓伊·活泼女声) / yunxi(云希·少年男声) / yunjian(云健·沉稳男声) / yunxia(云夏) / yunyang(云扬·播音腔) / xiaobei(东北话) / xiaoni(陕西话) / hiugaai(粤语女) / wanlung(粤语男) / hsiaochen(台湾女) / yunjhe(台湾男) / emma(英文女) / guy(英文男)。不填用默认音色。',
        },
        speedPct: { type: 'number', description: '可选语速调整，百分比。-50 到 +100，0 为正常。要显得急切就 +20 左右。' },
        pitchPct: { type: 'number', description: '可选音调调整，百分比。-50 到 +50，0 为正常。正数更年轻/尖，负数更低沉。' },
        replyToMessageId: { type: ['integer', 'string'], description: '可选：要引用/回复的消息 id（聊天记录里每条消息前的 #数字）' },
      },
      required: ['text'],
    },
    async execute(ctx, args) {
      try {
        if (!ctx?.chatKey) return { content: '错误：当前环境没有会话上下文，无法发语音', isError: true };
        if (typeof ctx.sender?.sendMedia !== 'function') {
          return { content: '错误：当前环境缺少发送接口（sender.sendMedia），语音没发出去', isError: true };
        }

        const { buf, spoken, engine, voiceLabel } = await synthesize({
          text: args?.text,
          voice: args?.voice,
          speedPct: args?.speedPct,
          pitchPct: args?.pitchPct,
        });

        await ctx.sender.sendMedia(ctx.chatKey, [{ type: 'record', data: { file: `base64://${buf.toString('base64')}` } }], {
          label: `[语音]${spoken.slice(0, 30)}`,
          dedupeKey: `tts:${fingerprint(spoken)}`,
          replyToMessageId: args?.replyToMessageId ?? null,
        });

        if (readConfig(cfg()).alsoSendText) {
          try { await ctx.sender.sendTextBatch(ctx.chatKey, [spoken], {}); }
          catch (error) { log(`语音已发出，但补发的文字失败：${error?.message ?? error}`); }
        }

        try {
          ctx.session?.sent?.push({
            type: 'voice',
            text: `[语音]${spoken.slice(0, 40)}`,
            at: new Date().toLocaleTimeString('zh-CN', { hour12: false }),
          });
          ctx.emit?.('session-update', ctx.session?.id);
        } catch { /* 留痕失败不影响语音已发出的事实 */ }

        return {
          content: `已用语音说出：「${spoken}」（音色：${voiceLabel}，${Math.round(buf.length / 1024)}KB）。`
            + '这条语音已经直接发到会话里了——不要再把同一句话用文字发一遍，也不要向用户汇报"已发送"。',
        };
      } catch (error) {
        const msg = String(error?.message ?? error);
        log(`语音说话失败：${msg}`);
        return { content: `语音发送失败：${msg}。可以改用文字回复，不要立刻重复调用本工具。`, isError: true };
      }
    },
  });

  const c = readConfig(cfg());
  const voiceLabel = Object.values(EDGE_VOICES).find((v) => v.id === c.voiceId)?.label || c.voiceId;
  log(`免费语音说话已注册（引擎=${c.engine}，音色=${voiceLabel}，语速=${c.speedPct}%，音调=${c.pitchPct}%）`);
}

/**
 * 自检：同步返回，只做配置校验（不发网络请求）。
 */
export function available() {
  try {
    const c = readConfig(cfg());
    if (c.engine !== 'edge' && c.engine !== 'baidu') {
      return { ok: false, reason: `语音引擎配置非法：${c.engine}` };
    }
    return { ok: true };
  } catch (error) {
    return { ok: false, reason: `配置读不出来：${error?.message ?? error}` };
  }
}

export const internals = {
  synthesize, readConfig, normalizeSpeakText, looksLikeAudio, fingerprint,
  baiduUrl, generateSecMsGecV2, EDGE_VOICES, EDGE_EN_VOICES,
};
