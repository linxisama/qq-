// B站搜索（bilibili-search v1.0.0）—— 按关键词搜 B 站视频
//
// 思路与实测依据（接口行为已逐条实测，不是照抄文档）：
//   ✅ 可用：GET https://api.bilibili.com/x/web-interface/search/all/v2?keyword=<kw>&page=<n>
//      → HTTP 200 / code:0 / 真实数据；**不需要 WBI 签名、不需要 Cookie、不需要登录**。
//   ❌ 不可用（实测踩过的坑，别改回去）：
//      · x/web-interface/search/type               → HTTP 412 {"code":-412,"request was banned"}
//      · x/web-interface/wbi/search/type           → 200 但 data 只有 {"v_voucher":...}，0 条结果
//      · x/web-interface/wbi/search/all/v2         → 同上，只有风控凭证
//      · 直接抓 search.bilibili.com/all?keyword=   → 返回验证码页，不是搜索结果
//   服务端分页特性（实测）：
//      · 固定每页 20 条，page_size 参数**被忽略**（传 50 仍返回 20）
//      · page=1 是 rank 1–20，page=2 是 rank 21–40，**两页零重叠** → 翻页可靠
//      · numPages 声明 50，但 page=51 仍能返回数据、page=1000 被夹回 51 → 上限 51 页
//      · 同关键词两次请求排序会漂移（seid 每次不同）→ 需要按 bvid 去重
//
// ⚠️ 约定（照抄本机已装技能 bilibili-peek 的写法，别改）：
//   · 不检查响应的 content-type：B 站部分接口（suggest）的 content-type 是 unknown，
//     一律按文本读进来自己解析；fetchJson 同时兼容 JSON 与 JSONP 两种形态。
//   · 工具结果文本以 `status: ok` / `status: error` 开头，模型据此判断成败。
//   · 每个 execute 内部全包 try/catch，失败返回 { content, isError: true }，不要抛出去。
//   · 只用公开只读接口，不发任何需要登录态的请求。

const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
  + '(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36';
const REFERER = 'https://www.bilibili.com/';

const SEARCH_API = 'https://api.bilibili.com/x/web-interface/search/all/v2';
const SUGGEST_API = 'https://s.search.bilibili.com/main/suggest';

/** 服务端固定每页 20 条，page_size 参数无效。 */
const SERVER_PAGE_SIZE = 20;
/** 实测 page=51 仍可用，page=1000 被夹回 51。 */
const MAX_PAGE = 51;

/** 配置在执行时读，不要在 setup 里快照，否则用户改设置后不生效。 */
let cfgOf = () => ({});

/**
 * 把响应体解析成对象，**同时兼容 JSON 和 JSONP**。
 * 为什么要这么做：B 站部分接口（如 s.search.bilibili.com/main/suggest）返回的
 * content-type 是 unknown，实测连抓取工具都认不出类型；这类接口历史上是 JSONP
 * （`callback({...})`）。如果一律用 res.json()，遇到 JSONP 会直接抛错。
 */
function parseMaybeJsonp(text) {
  const t = String(text ?? '').trim();
  if (!t) return null;
  try {
    return JSON.parse(t);
  } catch { /* 不是纯 JSON，往下走 JSONP 分支 */ }
  const start = t.indexOf('{');
  const end = t.lastIndexOf('}');
  if (start !== -1 && end > start) {
    try {
      return JSON.parse(t.slice(start, end + 1));
    } catch { /* 确实解析不了 */ }
  }
  return null;
}

async function fetchJson(url, timeoutMs) {
  const res = await fetch(url, {
    headers: {
      'user-agent': UA,
      referer: REFERER,
      accept: 'application/json, text/plain, */*'
    },
    signal: AbortSignal.timeout(timeoutMs)
  });
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  const json = parseMaybeJsonp(await res.text());
  if (json === null) throw new Error('接口返回的不是可解析的 JSON/JSONP');
  return json;
}

/** 去掉 <em class="keyword"> 高亮标签，并解码 HTML 实体（实测 title 里会出现 &amp;）。 */
function cleanText(v) {
  return String(v ?? '')
    .replace(/<[^>]*>/g, '')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&#0?39;/g, "'")
    .replace(/&nbsp;/g, ' ')
    .replace(/&amp;/g, '&')
    .replace(/\s+/g, ' ')
    .trim();
}

function toInt(v) {
  const n = Number(v);
  return Number.isFinite(n) ? n : 0;
}

/** "1:6" / "1828:2" / "3758:53" → 秒。B 站的秒数不补零，不能按固定宽度切。 */
function durationToSeconds(d) {
  if (typeof d === 'number' && Number.isFinite(d)) return d;
  const parts = String(d ?? '').split(':');
  if (parts.length < 2) return 0;
  let total = 0;
  for (const p of parts) {
    const n = parseInt(p, 10);
    total = total * 60 + (Number.isFinite(n) ? n : 0);
  }
  return total;
}

function fmtDuration(sec) {
  const s = Math.max(0, Number(sec) || 0);
  const m = Math.floor(s / 60);
  const ss = Math.floor(s % 60);
  return `${m}:${String(ss).padStart(2, '0')}`;
}

function fmtCount(n) {
  const v = Number(n) || 0;
  if (v >= 100000000) return `${(v / 100000000).toFixed(1)} 亿`;
  if (v >= 10000) return `${(v / 10000).toFixed(1)} 万`;
  return String(v);
}

function fmtDate(unixSec) {
  const t = toInt(unixSec);
  if (!t) return '(未知)';
  const d = new Date(t * 1000);
  const p = (n) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}`;
}

/**
 * 调 B 站搜索接口，返回规范化结果。
 * @returns {Promise<{ok:boolean, code:number, error?:string, total:number, page:number,
 *   requestedPage:number, next:number, seid:string, items:Array<object>}>}
 */
async function searchBilibili(keyword, page, timeoutMs) {
  const reqPage = Math.min(MAX_PAGE, Math.max(1, Math.floor(Number(page) || 1)));
  const url = `${SEARCH_API}?keyword=${encodeURIComponent(keyword)}&page=${reqPage}`;

  let json;
  try {
    json = await fetchJson(url, timeoutMs);
  } catch (e) {
    const timedOut = e?.name === 'TimeoutError' || e?.name === 'AbortError';
    return {
      ok: false,
      code: -2,
      error: timedOut ? `请求超时（${timeoutMs}ms）` : `网络请求失败：${e?.message ?? e}`,
      total: 0, page: reqPage, requestedPage: reqPage, next: 0, seid: '', items: []
    };
  }

  // 风控 / 错误分支，逐条给可读原因，别让模型看到一堆 JSON
  if (json?.code === -412) {
    return {
      ok: false, code: -412,
      error: '被 B 站风控拦截（request was banned）。通常稍等一会再试即可，频繁搜索会触发。',
      total: 0, page: reqPage, requestedPage: reqPage, next: 0, seid: '', items: []
    };
  }
  if (json?.code !== 0) {
    return {
      ok: false, code: Number(json?.code) || -4,
      error: `B 站接口返回 code=${json?.code} ${json?.message || ''}`.trim(),
      total: 0, page: reqPage, requestedPage: reqPage, next: 0, seid: '', items: []
    };
  }
  if (json?.data?.v_voucher) {
    return {
      ok: false, code: -352,
      error: '触发了 B 站的风控校验（v_voucher），本次搜索没有返回结果。',
      total: 0, page: reqPage, requestedPage: reqPage, next: 0, seid: '', items: []
    };
  }

  const d = json?.data ?? {};
  // result 是「模块数组」，视频在 result_type === 'video' 那个模块里
  const videoModule = (Array.isArray(d.result) ? d.result : [])
    .find((r) => r && r.result_type === 'video');
  const rawList = Array.isArray(videoModule?.data) ? videoModule.data : [];

  const items = rawList
    // 同一模块里还混着直播（live_room），它们没有 bvid，过滤掉
    .filter((it) => it && it.type === 'video' && it.bvid)
    .map((it) => {
      const secs = durationToSeconds(it.duration);
      return {
        bvid: String(it.bvid),
        title: cleanText(it.title),
        author: cleanText(it.author),
        durationText: secs ? fmtDuration(secs) : String(it.duration ?? ''),
        durationSeconds: secs,
        play: toInt(it.play),
        danmaku: toInt(it.danmaku ?? it.video_review),
        like: toInt(it.like),
        pubdate: toInt(it.pubdate),
        pubdateText: fmtDate(it.pubdate),
        typename: cleanText(it.typename),
        description: cleanText(it.description),
        tag: cleanText(it.tag),
        url: `https://www.bilibili.com/video/${it.bvid}`
      };
    });

  return {
    ok: true,
    code: 0,
    total: toInt(d.numResults),
    page: toInt(d.page) || reqPage,
    requestedPage: reqPage,
    next: toInt(d.next),
    seid: String(d.seid ?? ''),
    items,
    hints: collectResponseHints(d)
  };
}

/**
 * 从主搜索响应里白捡两个「换词」线索（实测存在，零额外请求）：
 *   · data.suggest_keyword —— B 站自己给的建议词
 *   · result 里 result_type === 'related_search' 的模块
 */
function collectResponseHints(d) {
  const out = [];
  const sk = cleanText(d?.suggest_keyword);
  if (sk) out.push(sk);
  const mod = (Array.isArray(d?.result) ? d.result : [])
    .find((r) => r && r.result_type === 'related_search');
  for (const it of (Array.isArray(mod?.data) ? mod.data : [])) {
    const v = cleanText(typeof it === 'string' ? it : (it?.keyword ?? it?.value ?? it?.term));
    if (v) out.push(v);
  }
  return out;
}

/** 把多个来源的相关词合并、去重、限量。 */
function mergeTerms(list, limit = 8) {
  const seen = new Set();
  const out = [];
  for (const raw of list) {
    const t = cleanText(raw);
    if (!t || t === '-') continue;
    const k = t.toLowerCase();
    if (seen.has(k)) continue;
    seen.add(k);
    out.push(t);
    if (out.length >= limit) break;
  }
  return out;
}

/**
 * 从原始文本里用正则捞出 suggest 的词条。
 *
 * 为什么必须有这条兜底：suggest 接口的 `name` 字段是 HTML 高亮片段，实测其中含有
 * **未转义的 `&`**（如 `class="suggest_high_light">猫</em>猫`）。JSON.parse 碰到非法转义
 * 会**整个对象解析失败**，于是工具"能用"但永远返回空——静默失效，极难排查。
 * 只取 `value` / `term` 两个干净字段（`name` 带高亮标签，不要）。
 */
function parseTagValues(rawText) {
  const text = String(rawText ?? '');
  const out = [];
  for (const key of ['value', 'term']) {
    const re = new RegExp(`"${key}"\\s*:\\s*"((?:[^"\\\\]|\\\\.)*)"`, 'g');
    let m;
    while ((m = re.exec(text)) !== null) out.push(m[1]);
    if (out.length) break; // value 优先，拿到就不再取 term（两者内容基本重复）
  }
  return out.map((s) => s.replace(/\\u([0-9a-fA-F]{4})/g, (_, h) => String.fromCharCode(parseInt(h, 16)))
    .replace(/\\(.)/g, '$1'));
}

/** 相关搜索词（换关键词时的低成本提示）。失败一律返回空，不影响主流程。 */
async function fetchSuggest(term, timeoutMs) {
  const s = String(term ?? '').trim();
  if (!s) return [];
  const url = `${SUGGEST_API}?term=${encodeURIComponent(s)}`;
  try {
    // 这里不走 fetchJson：该接口的响应体可能因未转义 & 而是**非法 JSON**，
    // 必须拿到原始文本，才有机会走正则兜底。
    const res = await fetch(url, {
      headers: { 'user-agent': UA, referer: REFERER, accept: 'application/json, text/plain, */*' },
      signal: AbortSignal.timeout(timeoutMs)
    });
    if (!res.ok) return [];
    const text = await res.text();

    // ① 正常路径：合法 JSON/JSONP。实测数组在 data.result.tag，不是 data.tag。
    const json = parseMaybeJsonp(text);
    const tags = json?.data?.result?.tag;
    if (Array.isArray(tags)) {
      return mergeTerms(tags.map((t) => (typeof t === 'string' ? t : (t?.value ?? t?.term))));
    }

    // ② 兜底路径：JSON 非法（未转义 &）+ 响应里确实有 tag → 正则捞
    if (/"tag"\s*:/.test(text)) return mergeTerms(parseTagValues(text));
    return [];
  } catch {
    return [];
  }
}

/** 统一把结果渲染成给模型看的文本，所有工具共用。 */
function renderResult({ keyword, page, result, count, suggest = [], maxDescChars = 60 }) {
  const lines = [];

  if (!result.ok) {
    lines.push('status: error');
    lines.push(`搜索失败：${result.error}`);
    if (result.code === -412) {
      lines.push('建议：这是频率风控，不是关键词问题。可以稍等几秒重试，或先改用其他搜索方式。');
    }
    return lines.join('\n');
  }

  if (!result.items.length) {
    lines.push('status: ok');
    lines.push(`关键词「${keyword}」第 ${result.page} 页没有返回任何视频结果。`);
    if (suggest.length) {
      lines.push(`B 站给出的相关搜索词：${suggest.join(' / ')}`);
      lines.push('可以换其中一个更具体的词再搜一次。');
    } else {
      lines.push('换个更具体或更常见的关键词再试一次。');
    }
    return lines.join('\n');
  }

  const shown = result.items.slice(0, count);
  lines.push('status: ok');
  // 注意：接口每页固定 20 条，其中混有「直播」条目（已过滤掉），
  // 所以不要把 items.length 说成「第 X–Y 条」——那不是真实排名，会误导模型。
  lines.push(`关键词「${keyword}」第 ${result.page} 页，共约 ${result.total} 条结果；`
    + `本页取到 ${result.items.length} 条视频，下面是前 ${shown.length} 条：`);
  lines.push('');

  shown.forEach((it, i) => {
    lines.push(`${i + 1}. ${it.title || '(无标题)'}`);
    lines.push(`   UP主：${it.author || '(未知)'}${it.typename ? ` | 分区：${it.typename}` : ''}`);
    lines.push(`   时长：${it.durationText || '?'} | 播放：${fmtCount(it.play)}`
      + ` | 点赞：${fmtCount(it.like)} | 发布：${it.pubdateText}`);
    if (maxDescChars > 0 && it.description && it.description !== '-') {
      const desc = it.description.length > maxDescChars
        ? `${it.description.slice(0, maxDescChars)}…`
        : it.description;
      lines.push(`   简介：${desc}`);
    }
    lines.push(`   链接：${it.url}`);
    lines.push('');
  });

  if (result.items.length > shown.length) {
    lines.push(`（本页还有 ${result.items.length - shown.length} 条未显示。）`);
  }
  lines.push('请根据上面的标题/UP主/时长/播放量判断哪些与用户的问题真正相关，');
  lines.push('挑最像的 2~3 条交给 bilibili-peek__peek 看实际内容后再回复；');
  lines.push('一次没找到相关结果时，用同一个关键词把 page 改成 '
    + `${Math.max(1, result.page + 1)} 再搜接下来 10 条。`);
  return lines.join('\n');
}

export function setup(api) {
  cfgOf = () => (typeof api.config === 'function' ? (api.config() || {}) : {});
  const cfg = () => {
    const raw = cfgOf() || {};
    return {
      count: Math.max(1, Math.min(SERVER_PAGE_SIZE, Math.floor(Number(raw.count) || 10))),
      timeoutMs: Math.max(3000, Math.min(60000, Number(raw.timeoutMs) || 15000)),
      withSuggest: raw.withSuggest !== false,
      maxDescriptionChars: Math.max(0, Math.min(400,
        raw.maxDescriptionChars === undefined ? 60 : Number(raw.maxDescriptionChars) || 0))
    };
  };

  const searchId = api.registerTool({
    id: 'search',
    name: '搜索B站视频',
    description:
      '按关键词在 B 站搜索视频，返回标题、UP主、时长、播放量、发布日期和链接。'
      + '默认返回前 10 条。参数 keyword 必填；page 默认 1，第一次没搜到相关结果时改成 2 '
      + '可以看接下来 10 条。拿到结果后应当挑最像的几条调用 bilibili-peek__peek 确认内容是否真的相关，'
      + '再只把最相关的 1 条链接配自己的话回复；两次都搜不到就说「B站也没搜到」或改用其他搜索方式。'
      + '第一行是 status：ok=搜索成功（可能 0 条结果）/ error=失败（原因在下一行）。',
    category: 'query',
    icon: '🔍',
    parameters: {
      type: 'object',
      properties: {
        keyword: {
          type: 'string',
          description: '搜索关键词，例如「Python 入门教程」。用用户的实际意图词，不要加引号或额外修饰。'
        },
        page: {
          type: ['integer', 'string'],
          description: '第几页，从 1 开始，默认 1。第一次的结果都不相关时改成 2 取接下来 10 条，最多 51。'
        },
        count: {
          type: ['integer', 'string'],
          description: '这次返回几条给模型看，默认 10，范围 1~20。一般不用填。'
        }
      },
      required: ['keyword']
    },

    async execute(ctx, args) {
      try {
        const c = cfg();
        const keyword = String(args?.keyword ?? '').trim();
        if (!keyword) {
          return {
            content: 'status: error\n缺少 keyword 参数：请给出要搜索的关键词。',
            isError: true
          };
        }

        const page = Math.min(MAX_PAGE, Math.max(1, Math.floor(Number(args?.page) || 1)));
        const count = args?.count === undefined || args?.count === ''
          ? c.count
          : Math.max(1, Math.min(SERVER_PAGE_SIZE, Math.floor(Number(args.count) || c.count)));

        const result = await searchBilibili(keyword, page, c.timeoutMs);

        let suggest = [];
        if (result.ok && !result.items.length && c.withSuggest) {
          suggest = mergeTerms([...(result.hints || []), ...await fetchSuggest(keyword, c.timeoutMs)]);
        }

        const content = renderResult({
          keyword,
          page,
          result,
          count,
          suggest,
          maxDescChars: c.maxDescriptionChars
        });
        return { content, isError: !result.ok };
      } catch (e) {
        return { content: `status: error\n搜索 B 站时出错：${e?.message ?? e}`, isError: true };
      }
    }
  });

  const relatedId = api.registerTool({
    id: 'related',
    name: 'B站相关搜索词',
    description:
      '拿 B 站为某个词给出的相关搜索词（搜索建议）。用于第一次搜索没搜到相关内容时换个更准的说法。'
      + '参数 term 是用户原来的说法。只返回词，不返回视频；拿到后应当用其中更合适的一个再调 '
      + 'bilibili-search__search。第一行是 status。',
    category: 'query',
    icon: '💡',
    parameters: {
      type: 'object',
      properties: {
        term: { type: 'string', description: '要查询相关搜索词的原词，例如「周杰伦 演唱会」' }
      },
      required: ['term']
    },

    async execute(ctx, args) {
      try {
        const c = cfg();
        const term = String(args?.term ?? '').trim();
        if (!term) {
          return { content: 'status: error\n缺少 term 参数。', isError: true };
        }
        const tags = await fetchSuggest(term, c.timeoutMs);
        if (!tags.length) {
          return {
            content: `status: ok\nB 站没有为「${term}」给出相关搜索词（接口未返回建议）。`
              + '请换个更常见的说法直接搜索。'
          };
        }
        return {
          content: `status: ok\n「${term}」的相关搜索词：\n`
            + tags.map((t) => `- ${t}`).join('\n')
            + '\n选一个更贴近用户意图的，用 bilibili-search__search 再搜一次。'
        };
      } catch (e) {
        return { content: `status: error\n查相关搜索词失败：${e?.message ?? e}`, isError: true };
      }
    }
  });

  api.log(`已加载，工具：${searchId} / ${relatedId}`);
}

/**
 * 同步自检：本技能只依赖 B 站公开接口，不需要密钥或外部二进制，恒可用。
 * ⚠️ 必须是同步函数（返回 Promise 会被当成"可用"，界面显示生效但实际跑不通）。
 */
export function available() {
  return true;
}

/** 可选回收：本技能没有定时器/长连接，无需清理。工具清理由加载器兜底。 */
export function dispose() {}
