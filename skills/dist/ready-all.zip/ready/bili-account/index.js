/**
 * bili-account —— 登录并操作 B 站账号（LLM 型技能 / skill.json + index.js）
 *
 * 为什么是「技能」而不是「插件」：
 *   「什么时候该点赞/投币/收藏/关注/评论/发动态」取决于群里在聊什么、
 *   用户是不是在叫它做 —— 这是自然语言判断，规则写不死。
 *   所以注册工具交给模型决定；确定性的权限、限额、确认模式在工具内部强制。
 *
 * 安全边界（重要）：
 *   · Cookie/SESSDATA 只保存在本机 data/bili-account/session.json，权限 0600；
 *     日志与工具返回值里不会出现 Cookie。
 *   · 所有写操作都过「开关 + 自动模式 + 每日限额 + 最小间隔 + 去重」五道闸。
 *   · 评论/发动态默认是 confirm 模式（要用户明确同意），可在设置里改成 auto。
 *   · 不绕过 ctx.sender 发消息；登录二维码走发送队列。
 */

import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { createRequire } from 'node:module';
import { fileURLToPath } from 'node:url';

// 技能目录：<app>/skills/bili-account/index.js。自己推导数据目录，不 import 核心模块，
// 这样这个技能目录是自包含的（复制到别的 skills/ 根目录也能跑）。
const APP_ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..', '..');
const PROFILE_ID = /^\d+$/.test(String(process.env.QQ_AGENT_PROFILE ?? '').trim())
  ? String(process.env.QQ_AGENT_PROFILE).trim()
  : '';
const DATA_DIR = process.env.QQ_AGENT_DATA_DIR || path.join(APP_ROOT, `data${PROFILE_ID ? `-${PROFILE_ID}` : ''}`);

const require = createRequire(import.meta.url);
let qrLib = null;
function getQrLib() {
  if (!qrLib) qrLib = require('./lib/qrcode.cjs');
  return qrLib;
}

// 加载器的热重载只给 index.js 加 ?t=...，静态 import 的 ./lib/bili-api.js
// 会被 Node 缓存住 —— 改了 lib 之后旧模块不会重新求值，表现为“新 index 找不到新导出”。
// 这里用同一个 t 做动态 import，让 lib 跟着 index 一起刷新。
const BUST = new URL(import.meta.url).searchParams.get('t') || String(Date.now());
const {
  BiliApiError, randomBuvid3, cookieString, qrGenerate, qrPoll, fetchBuvid,
  nav, navStat, extractVideoRef, resolveVideo, videoInfo, videoState,
  likeVideo, coinVideo, tripleVideo, favFolders, favDeal,
  followUser, postComment, postDynamicText, postDynamicTextV2, deleteDynamic
} = await import(`./lib/bili-api.js?t=${encodeURIComponent(BUST)}`);

const STORE_DIR = path.join(DATA_DIR, 'bili-account');
const SESSION_FILE = path.join(STORE_DIR, 'session.json');
const STATE_FILE = path.join(STORE_DIR, 'state.json');
const NAV_TTL_MS = 60 * 1000;
const DEDUPE_WINDOW_MS = 10 * 60 * 1000;
const HIGH_RISK_DEDUPE_MS = 30 * 60 * 1000;
const LOGIN_POLL_MS = 3000;
const LOGIN_TTL_MS = 175 * 1000;

const state = {
  loginPoll: null,
  navCache: null,
  buvidCache: null,
  writeChain: Promise.resolve()
};

let cfg = () => ({});
let log = () => {};
let warn = () => {};

// ── 配置 ────────────────────────────────────────────────────────────────

function cleanCookie(v) {
  let s = String(v ?? '').trim();
  if (!s || s === '******') return '';
  s = s.replace(/^(SESSDATA|bili_jct|DedeUserID|buvid3)=/i, '');
  if ((s.startsWith('"') && s.endsWith('"')) || (s.startsWith("'") && s.endsWith("'"))) s = s.slice(1, -1);
  return s.trim();
}

function parseHours(raw) {
  const out = new Set();
  for (const part of String(raw || '').split(/[,，\s]+/)) {
    const t = part.trim();
    if (!t) continue;
    const n = Number(t);
    if (Number.isFinite(n) && n >= 0 && n <= 23) out.add(Math.round(n));
  }
  return out;
}

function settings() {
  const c = cfg() || {};
  const bool = (k, d) => (typeof c[k] === 'boolean' ? c[k] : d);
  const num = (k, d) => {
    const n = Number(c[k]);
    return Number.isFinite(n) ? n : d;
  };
  const str = (k, d) => (c[k] === undefined || c[k] === null ? d : String(c[k]));
  const oneOf = (k, allowed, d) => {
    const v = str(k, d);
    return allowed.includes(v) ? v : d;
  };
  const quietHoursText = str('quietHours', '0,1,2,3,4,5,6,7');
  return {
    autonomy: oneOf('autonomy', ['off', 'confirm', 'auto'], 'auto'),
    highRiskAutonomy: oneOf('highRiskAutonomy', ['off', 'confirm', 'auto'], 'confirm'),
    allowLike: bool('allowLike', true),
    allowCoin: bool('allowCoin', true),
    allowFavorite: bool('allowFavorite', true),
    allowFollow: bool('allowFollow', true),
    allowComment: bool('allowComment', true),
    allowDynamic: bool('allowDynamic', true),
    coinCount: Math.max(1, Math.min(2, Math.round(num('coinCount', 1)))),
    favoriteFolderId: str('favoriteFolderId', '').trim(),
    maxWritesPerDay: Math.max(0, Math.round(num('maxWritesPerDay', 30))),
    maxCommentsPerDay: Math.max(0, Math.round(num('maxCommentsPerDay', 5))),
    maxDynamicsPerDay: Math.max(0, Math.round(num('maxDynamicsPerDay', 2))),
    minSecondsBetweenWrites: Math.max(0, Math.round(num('minSecondsBetweenWrites', 8))),
    quietHours: parseHours(quietHoursText),
    quietHoursText,
    qrToPrivate: bool('qrToPrivate', true),
    announceActions: bool('announceActions', false),
    sessdata: cleanCookie(str('sessdata', '')),
    biliJct: cleanCookie(str('biliJct', '')),
    dedeUserId: cleanCookie(str('dedeUserId', '')),
    buvid3: cleanCookie(str('buvid3', ''))
  };
}

function bjHour() {
  return new Date(Date.now() + 8 * 3600 * 1000).getUTCHours();
}

function todayKey() {
  const d = new Date(Date.now() + 8 * 3600 * 1000);
  return `${d.getUTCFullYear()}-${String(d.getUTCMonth() + 1).padStart(2, '0')}-${String(d.getUTCDate()).padStart(2, '0')}`;
}

// ── 文件 ────────────────────────────────────────────────────────────────

function ensureStoreDir() {
  try { fs.mkdirSync(STORE_DIR, { recursive: true }); } catch (e) { warn(`创建数据目录失败：${e?.message ?? e}`); }
}

function readJson(file, fallback) {
  try { return JSON.parse(fs.readFileSync(file, 'utf8')); } catch { return fallback; }
}

function writeJson(file, data) {
  ensureStoreDir();
  fs.writeFileSync(file, JSON.stringify(data, null, 2), { encoding: 'utf8', mode: 0o600 });
}

function loadStoredSession() {
  const raw = readJson(SESSION_FILE, null);
  if (!raw || typeof raw !== 'object') return { version: 1, cookies: {} };
  return { version: 1, ...raw, cookies: (raw.cookies && typeof raw.cookies === 'object') ? raw.cookies : {} };
}

function saveStoredSession(session) {
  writeJson(SESSION_FILE, { version: 1, savedAt: Date.now(), ...session });
}

function clearStoredSession() {
  try { fs.rmSync(SESSION_FILE, { force: true }); } catch (e) { warn(`清除登录态失败：${e?.message ?? e}`); }
}

function loadState() {
  const raw = readJson(STATE_FILE, null);
  const today = todayKey();
  if (!raw || typeof raw !== 'object' || raw.day !== today) {
    return { day: today, writes: 0, comments: 0, dynamics: 0, lastWriteAt: 0, recent: [] };
  }
  return {
    day: today,
    writes: Math.max(0, Number(raw.writes) || 0),
    comments: Math.max(0, Number(raw.comments) || 0),
    dynamics: Math.max(0, Number(raw.dynamics) || 0),
    lastWriteAt: Math.max(0, Number(raw.lastWriteAt) || 0),
    recent: Array.isArray(raw.recent) ? raw.recent : []
  };
}

function saveState(st) {
  writeJson(STATE_FILE, st);
}

// ── 会话 ────────────────────────────────────────────────────────────────

function effectiveSession() {
  const s = settings();
  const stored = loadStoredSession();
  const cookies = { ...(stored.cookies || {}) };

  // 手动 Cookie 覆盖文件；如果手动 SESSDATA 与文件里的不是同一个号，
  // 不要把文件里的旧 bili_jct 混进来（否则 csrf 必然不配套）。
  const manualSess = s.sessdata;
  if (manualSess) {
    if (manualSess !== cookies.SESSDATA && !s.biliJct) delete cookies.bili_jct;
    cookies.SESSDATA = manualSess;
  }
  if (s.biliJct) cookies.bili_jct = s.biliJct;
  if (s.dedeUserId) cookies.DedeUserID = s.dedeUserId;
  if (s.buvid3) cookies.buvid3 = s.buvid3;

  if (state.buvidCache) {
    if (!cookies.buvid3) cookies.buvid3 = state.buvidCache.buvid3;
    if (!cookies.buvid4) cookies.buvid4 = state.buvidCache.buvid4;
  }

  return {
    stored,
    cookies,
    hasLogin: Boolean(String(cookies.SESSDATA || '').trim()),
    hasCsrf: Boolean(String(cookies.bili_jct || '').trim())
  };
}

async function ensureBuvid(session) {
  if (session.cookies.buvid3) {
    state.buvidCache = { buvid3: session.cookies.buvid3, buvid4: session.cookies.buvid4 || '' };
    return;
  }
  try {
    const b = await fetchBuvid(fetch);
    if (b.buvid3) {
      session.cookies.buvid3 = b.buvid3;
      session.cookies.buvid4 = b.buvid4;
      state.buvidCache = { buvid3: b.buvid3, buvid4: b.buvid4 };
      if (session.stored?.cookies && Object.keys(session.stored.cookies).length) {
        session.stored.cookies = { ...session.stored.cookies, buvid3: b.buvid3, buvid4: b.buvid4 };
        saveStoredSession(session.stored);
      }
      return;
    }
  } catch (e) {
    warn(`获取 buvid 失败（用随机值兜底）：${e?.message ?? e}`);
  }
  const b3 = randomBuvid3();
  session.cookies.buvid3 = b3;
  state.buvidCache = { buvid3: b3, buvid4: '' };
}

async function apiAuth() {
  const session = effectiveSession();
  if (!session.hasLogin) throw new BiliApiError(-101, '还没登录 B 站账号');
  await ensureBuvid(session);
  return { ...session, cookie: cookieString(session.cookies) };
}

async function getNav({ force = false } = {}) {
  const session = effectiveSession();
  if (!session.hasLogin) return { loggedIn: false, reason: '还没有登录 B 站账号' };
  await ensureBuvid(session);
  const cookie = cookieString(session.cookies);
  if (!force && state.navCache && state.navCache.cookie === cookie && Date.now() - state.navCache.at < NAV_TTL_MS) {
    return state.navCache.value;
  }
  let payload;
  try {
    payload = await nav(fetch, cookie);
  } catch (e) {
    return { loggedIn: false, reason: friendly(e), error: e };
  }
  if (payload?.code === 0 && payload?.data?.isLogin) {
    const value = { loggedIn: true, data: payload.data, cookie };
    state.navCache = { at: Date.now(), cookie, value };
    if (session.stored?.cookies && Object.keys(session.stored.cookies).length) {
      session.stored.mid = payload.data.mid;
      session.stored.uname = payload.data.uname;
      saveStoredSession(session.stored);
    }
    return value;
  }
  return {
    loggedIn: false,
    reason: payload?.code === -101 ? 'SESSDATA 已失效或未登录' : (payload?.message || '登录状态异常'),
    payload
  };
}

async function requireAccount() {
  const a = await getNav({ force: true });
  if (!a.loggedIn) throw new BiliApiError(-101, a.reason || '还没登录 B 站账号');
  return a;
}

// ── 错误文案 ────────────────────────────────────────────────────────────

const ERROR_TEXT = {
  '-1': 'B站请求失败',
  '-101': '账号未登录或登录已失效，请重新让我扫码登录',
  '-102': '账号被封停',
  '-104': '硬币不足',
  '-111': 'csrf 校验失败（bili_jct 与 SESSDATA 不配套或已过期）',
  '-352': '触发 B 站风控（-352），请稍后再试或换个网络',
  '-400': '请求参数不对',
  '-403': '账号异常，操作被拒绝',
  '-412': '触发 B 站风控（412），请稍后再试',
  '-509': '请求过于频繁',
  '65004': '还没点赞，无法取消',
  '65006': '已经点过赞了',
  '10003': '视频不存在或已删除',
  '11201': '已经收藏过了',
  '11202': '还没收藏，无法取消',
  '11203': '收藏夹已达上限',
  '22001': '不能对自己进行这个操作',
  '22013': '账号已注销，无法操作',
  '22014': '已经关注过这个 UP 主了',
  '34002': '不能给自己投币',
  '34003': '投币数量不合法（只能是 1 或 2）',
  '34004': '投币间隔太短，稍后再试',
  '34005': '这个视频的投币数已达上限',
  '40061': '用户不存在',
  '12002': '评论区已关闭',
  '12015': '需要验证码，暂时无法评论',
  '12016': '评论包含敏感信息，被 B 站拒绝',
  '12025': '评论字数过多',
  '12051': '评论重复，请勿刷屏',
  '12035': '该账号被 UP 主列入评论黑名单',
  '4126021': '账号未绑定手机，无法发布动态',
  '500406': '这条动态不是当前账号的，不能删除'
};

function friendly(e) {
  if (!e) return '未知错误';
  if (Number(e.status) === 412) return ERROR_TEXT['-412'];
  const code = Number(e.code);
  if (ERROR_TEXT[String(code)]) return ERROR_TEXT[String(code)];
  return e.message || String(e);
}

function errorWithCode(e) {
  const text = friendly(e);
  const code = Number(e?.code);
  if (code && !text.includes(String(code))) return `${text}（错误码 ${code}）`;
  return text;
}

// ── 限额 / 闸门 ─────────────────────────────────────────────────────────

function quotaStatus() {
  const st = loadState();
  const s = settings();
  return {
    writes: st.writes,
    maxWrites: s.maxWritesPerDay,
    comments: st.comments,
    maxComments: s.maxCommentsPerDay,
    dynamics: st.dynamics,
    maxDynamics: s.maxDynamicsPerDay,
    lastWriteAt: st.lastWriteAt
  };
}

function isRecent(key, windowMs) {
  const st = loadState();
  const now = Date.now();
  return st.recent.some((r) => r && r.key === key && now - Number(r.at || 0) < windowMs);
}

function markRecent(st, key) {
  const now = Date.now();
  st.recent = [
    ...(st.recent || []).filter((r) => r && now - Number(r.at || 0) < 24 * 3600 * 1000),
    { key, at: now }
  ].slice(-50);
}

function bumpQuota(kind, key) {
  const st = loadState();
  st.writes += 1;
  if (kind === 'comment') st.comments += 1;
  if (kind === 'dynamic') st.dynamics += 1;
  st.lastWriteAt = Date.now();
  if (key) markRecent(st, key);
  saveState(st);
}

/**
 * 写操作闸门。
 * @param {'write'|'comment'|'dynamic'} kind
 * @param {object} s settings()
 * @param {boolean} confirm 用户是否明确同意
 * @param {{highRisk?: boolean}} opts
 */
function gateWrite(kind, s, confirm, opts = {}) {
  const highRisk = opts.highRisk ?? (kind === 'comment' || kind === 'dynamic');
  const mode = highRisk ? s.highRiskAutonomy : s.autonomy;

  if (mode === 'off') {
    return { ok: false, reason: highRisk ? '评论/发动态的自动操作已关闭（高风险操作 = off）' : '自动操作已关闭（自动模式 = off）' };
  }
  if (mode === 'confirm' && confirm !== true) {
    return {
      ok: false,
      reason: highRisk
        ? '这一步会以你的账号公开发言。请先在群里明确问一句并得到同意，再调用（confirm=true）。'
        : '这一步会改动你的 B 站账号。请先得到用户明确同意，再调用（confirm=true）。'
    };
  }
  if (mode === 'auto' && s.quietHours.has(bjHour()) && confirm !== true) {
    return { ok: false, reason: `现在是静默时段（${s.quietHoursText} 点），自动操作暂停；用户明确要求时可以带 confirm=true 执行。` };
  }

  const st = loadState();
  if (s.maxWritesPerDay > 0 && st.writes >= s.maxWritesPerDay) {
    return { ok: false, reason: `今天的写操作已达上限（${st.writes}/${s.maxWritesPerDay}）` };
  }
  if (kind === 'comment' && s.maxCommentsPerDay > 0 && st.comments >= s.maxCommentsPerDay) {
    return { ok: false, reason: `今天的评论已达上限（${st.comments}/${s.maxCommentsPerDay}）` };
  }
  if (kind === 'dynamic' && s.maxDynamicsPerDay > 0 && st.dynamics >= s.maxDynamicsPerDay) {
    return { ok: false, reason: `今天的动态已达上限（${st.dynamics}/${s.maxDynamicsPerDay}）` };
  }

  const gap = Math.max(0, s.minSecondsBetweenWrites) * 1000;
  const wait = st.lastWriteAt ? Math.max(0, gap - (Date.now() - st.lastWriteAt)) : 0;
  if (wait > 12000) return { ok: false, reason: `操作太频繁，请 ${Math.ceil(wait / 1000)} 秒后再试` };
  return { ok: true, wait };
}

function withWriteLock(fn) {
  const run = state.writeChain.then(fn, fn);
  state.writeChain = run.catch(() => {});
  return run;
}

// ── 小工具 ──────────────────────────────────────────────────────────────

function ok(content) { return { content: String(content) }; }
function fail(content) { return { content: String(content), isError: true }; }
function sleep(ms) { return new Promise((r) => setTimeout(r, Math.max(0, ms))); }
function clamp(n, lo, hi) { return Math.min(hi, Math.max(lo, Math.round(Number(n) || 0))); }

function fmtDuration(sec) {
  const s = Math.max(0, Math.round(Number(sec) || 0));
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const ss = s % 60;
  const p = (n) => String(n).padStart(2, '0');
  return h > 0 ? `${h}:${p(m)}:${p(ss)}` : `${m}:${p(ss)}`;
}

function hashText(text) {
  return crypto.createHash('sha256').update(String(text)).digest('hex').slice(0, 16);
}

function pickDefaultFolder(folders) {
  if (!Array.isArray(folders) || !folders.length) return null;
  return folders.find((f) => (Number(f.attr) & 2) === 0) || folders[0];
}

async function sendReceipt(ctx, text) {
  if (!settings().announceActions) return;
  try {
    await ctx.sender.sendTextBatch(ctx.chatKey, [String(text)]);
  } catch (e) {
    warn(`发送操作回执失败：${e?.message ?? e}`);
  }
}

async function myMid(auth) {
  if (auth?.stored?.mid) return Number(auth.stored.mid);
  const a = await requireAccount();
  return Number(a.data.mid);
}

// ── 登录 ────────────────────────────────────────────────────────────────

function makeQrDataUrl(url) {
  const lib = getQrLib();
  let lastError = null;
  for (const level of ['M', 'L']) {
    try {
      const qr = lib(0, level);
      qr.addData(String(url));
      qr.make();
      return qr.createDataURL(8, 32);
    } catch (e) { lastError = e; }
  }
  throw new Error(`二维码生成失败：${lastError?.message ?? lastError}`);
}

function getSenderId(ctx) {
  const entries = Array.isArray(ctx?.session?.trigger) ? ctx.session.trigger : [];
  const hit = entries.find((x) => x && !x.self && x.senderId);
  return hit ? String(hit.senderId) : '';
}

async function sendQr(ctx, dataUrl, text) {
  const s = settings();
  const senderId = getSenderId(ctx);
  const targets = [];
  if (s.qrToPrivate && ctx.kind === 'group' && senderId) targets.push(`private:${senderId}`);
  targets.push(ctx.chatKey);
  let lastError = null;
  for (const key of targets) {
    try {
      await ctx.sender.sendImage(key, { dataUrl }, { note: 'B站登录二维码' });
      await ctx.sender.sendTextBatch(key, [text]);
      return key;
    } catch (e) {
      lastError = e;
      warn(`二维码发送到 ${key} 失败：${e?.message ?? e}`);
    }
  }
  throw new Error(`二维码发送失败：${lastError?.message ?? lastError}`);
}

async function notifyLogin(sender, chatKey, text) {
  try {
    await sender.sendTextBatch(chatKey, [String(text)]);
  } catch (e) {
    warn(`登录状态通知发送失败：${e?.message ?? e}`);
  }
}

async function pollLoginOnce(qrcodeKey) {
  const r = await qrPoll(fetch, qrcodeKey);
  if (r.statusCode === 0) {
    const session = effectiveSession();
    const cookies = { ...session.cookies, ...r.cookies };
    if (!cookies.buvid3) {
      try {
        const b = await fetchBuvid(fetch);
        if (b.buvid3) { cookies.buvid3 = b.buvid3; cookies.buvid4 = b.buvid4; }
      } catch { /* 用随机值兜底 */ }
    }
    if (!cookies.buvid3) cookies.buvid3 = randomBuvid3();

    const stored = { version: 1, cookies, refreshToken: r.refreshToken, savedAt: Date.now() };
    let account = null;
    try {
      const payload = await nav(fetch, cookieString(cookies));
      if (payload?.code === 0 && payload?.data?.isLogin) {
        account = payload.data;
        stored.mid = account.mid;
        stored.uname = account.uname;
      }
    } catch (e) {
      warn(`登录成功但读取账号资料失败：${e?.message ?? e}`);
    }
    saveStoredSession(stored);
    state.navCache = null;
    state.buvidCache = { buvid3: cookies.buvid3, buvid4: cookies.buvid4 || '' };
    return { status: 'success', account, cookies };
  }
  if (r.statusCode === 86090) return { status: 'scanned' };
  if (r.statusCode === 86038) return { status: 'expired' };
  if (r.statusCode === 86101) return { status: 'waiting' };
  return { status: 'error', message: r.message || `扫码状态异常（${r.statusCode}）` };
}

function stopLoginPoll(reason) {
  if (state.loginPoll?.timer) {
    clearInterval(state.loginPoll.timer);
    log(`停止扫码轮询（${reason}）`);
  }
  state.loginPoll = null;
}

function startLoginPoll({ qrcodeKey, chatKey, sender }) {
  stopLoginPoll('restart');
  const started = Date.now();
  let scanned = false;
  let polling = false;
  const timer = setInterval(async () => {
    if (polling) return;
    polling = true;
    try {
      if (Date.now() - started > LOGIN_TTL_MS) {
        stopLoginPoll('expired');
        await notifyLogin(sender, chatKey, '二维码已过期，请重新让我发一张。');
        return;
      }
      const r = await pollLoginOnce(qrcodeKey);
      if (r.status === 'success') {
        stopLoginPoll('success');
        const name = r.account?.uname ? `${r.account.uname}（UID ${r.account.mid}）` : 'B站账号';
        await notifyLogin(sender, chatKey, `登录成功：${name}。现在可以让我点赞、投币、收藏、关注、评论或发动态了。`);
      } else if (r.status === 'scanned' && !scanned) {
        scanned = true;
        await notifyLogin(sender, chatKey, '已扫码，请在手机上点“确认登录”。');
      } else if (r.status === 'expired') {
        stopLoginPoll('expired');
        await notifyLogin(sender, chatKey, '二维码已过期，请重新让我发一张。');
      }
    } catch (e) {
      warn(`扫码轮询失败（稍后重试）：${e?.message ?? e}`);
    } finally {
      polling = false;
    }
  }, LOGIN_POLL_MS);
  state.loginPoll = { timer, qrcodeKey, chatKey, started };
}

async function loginStart(ctx, force) {
  if (settings().sessdata) {
    return fail('技能设置里填了手动 SESSDATA，它会覆盖扫码登录结果。请先在设置里清空 SESSDATA 和 bili_jct，再扫码；或者继续用手动 Cookie。');
  }
  if (!force) {
    const cur = await getNav({ force: true });
    if (cur.loggedIn) {
      return ok(`已经登录：${cur.data.uname}（UID ${cur.data.mid}）。如果要换号，再让我“强制重新登录”。`);
    }
  }
  if (!ctx?.sender?.sendImage || !ctx?.chatKey) return fail('当前会话没有发送通道，发不了二维码。');

  const qr = await qrGenerate(fetch);
  const dataUrl = makeQrDataUrl(qr.url);
  const text = 'B站登录二维码：请用 B 站手机 App 扫码，并在手机上确认。二维码 3 分钟内有效。只给主人扫，别转发。扫完我会自动回你。';
  const chatKey = await sendQr(ctx, dataUrl, text);
  startLoginPoll({ qrcodeKey: qr.qrcode_key, chatKey, sender: ctx.sender });
  return ok(`二维码已经发到${chatKey.startsWith('private:') ? '你的私聊' : '本群'}了。请在 3 分钟内用 B 站 App 扫码并确认；扫完我会自动告诉你结果。`);
}

async function loginCheck() {
  if (state.loginPoll) {
    const r = await pollLoginOnce(state.loginPoll.qrcodeKey);
    if (r.status === 'success') {
      stopLoginPoll('success');
      const name = r.account?.uname ? `${r.account.uname}（UID ${r.account.mid}）` : 'B站账号';
      return ok(`登录成功：${name}。`);
    }
    if (r.status === 'scanned') return ok('已经扫码，但还没在手机上确认。请在 B 站 App 里点“确认登录”。');
    if (r.status === 'waiting') return ok('还没扫码。二维码还在有效期内，请用 B 站 App 扫刚才那张图。');
    if (r.status === 'expired') {
      stopLoginPoll('expired');
      return fail('二维码已过期，请重新让我发一张。');
    }
    return fail(r.message || '扫码状态异常');
  }
  const cur = await getNav({ force: true });
  if (cur.loggedIn) return ok(`已经登录：${cur.data.uname}（UID ${cur.data.mid}）。`);
  return fail(`还没登录：${cur.reason}。先让我发二维码。`);
}

// ── 工具实现 ────────────────────────────────────────────────────────────

async function accountSummary() {
  const cur = await getNav({ force: true });
  if (!cur.loggedIn) {
    return ok(`还没登录 B 站账号（${cur.reason}）。\n先调用 bili_login 让我发二维码，或在技能设置里填手动 Cookie。`);
  }
  const d = cur.data;
  let stat = null;
  try {
    const r = await navStat(fetch, cur.cookie);
    if (r?.code === 0) stat = r.data;
  } catch { /* 统计失败不影响主信息 */ }
  const s = settings();
  const q = quotaStatus();
  const lines = [
    `已登录：${d.uname}（UID ${d.mid}）`,
    `等级：Lv${d.level_info?.current_level ?? '?'}　硬币：${d.money ?? '?'}`,
    stat ? `关注：${stat.following}　粉丝：${stat.follower}　动态：${stat.dynamic_count}` : '',
    `自动模式：${s.autonomy}　高风险（评论/动态）：${s.highRiskAutonomy}`,
    `允许：点赞=${s.allowLike ? '开' : '关'} 投币=${s.allowCoin ? '开' : '关'} 收藏=${s.allowFavorite ? '开' : '关'} 关注=${s.allowFollow ? '开' : '关'} 评论=${s.allowComment ? '开' : '关'} 动态=${s.allowDynamic ? '开' : '关'}`,
    `今日额度：写操作 ${q.writes}/${q.maxWrites}　评论 ${q.comments}/${q.maxComments}　动态 ${q.dynamics}/${q.maxDynamics}`,
    s.quietHours.size ? `静默时段：${[...s.quietHours].sort((a, b) => a - b).join(',')} 点（仅自动模式生效）` : ''
  ].filter(Boolean);
  return ok(lines.join('\n'));
}

async function videoInfoTool(args) {
  const target = String(args?.target ?? '').trim();
  if (!target) return fail('缺少 target：请给 B 站视频链接或 BV 号。');
  const ref = await resolveVideo(fetch, target);
  const session = effectiveSession();
  let cookie = '';
  if (session.hasLogin) {
    await ensureBuvid(session);
    cookie = cookieString(session.cookies);
  }
  const info = await videoInfo(fetch, { ...ref, cookie });
  let st = null;
  if (session.hasLogin) {
    try { st = await videoState(fetch, { aid: info.aid, cookie }); } catch { /* 状态查不到不影响信息 */ }
  }
  const lines = [
    `《${info.title}》`,
    `UP主：${info.author}（UID ${info.mid}）　时长：${fmtDuration(info.duration)}`,
    `播放 ${info.stat.view}　弹幕 ${info.stat.danmaku}　评论 ${info.stat.reply}　点赞 ${info.stat.like}　投币 ${info.stat.coin}　收藏 ${info.stat.favorite}`,
    `链接：${info.url}`,
    st
      ? `你的状态：${st.liked ? '已点赞' : '未点赞'}；${st.coins === null ? '投币状态未知' : `已投 ${st.coins} 枚`}；${st.favored === null ? '收藏状态未知' : (st.favored ? '已收藏' : '未收藏')}`
      : '（还没登录，看不到“我有没有赞过/投过/收藏过”）'
  ];
  return ok(lines.join('\n'));
}

async function favFoldersTool() {
  const a = await requireAccount();
  const folders = await favFolders(fetch, { mid: a.data.mid, cookie: a.cookie });
  if (!folders.length) return ok('你的 B 站账号还没有收藏夹（或者都是私密且接口没返回）。');
  const lines = folders.map((f, i) => `${i + 1}. ${f.title}（id=${f.id}${(Number(f.attr) & 2) === 0 ? '，默认' : ''}，${f.media_count ?? 0} 个视频）`);
  return ok(lines.join('\n'));
}

async function videoActionTool(ctx, args) {
  const target = String(args?.target ?? '').trim();
  const action = String(args?.action ?? '').trim();
  const confirm = args?.confirm === true;
  if (!target) return fail('缺少 target：请给视频链接或 BV 号。');
  const allowed = ['like', 'unlike', 'coin', 'favorite', 'unfavorite', 'triple'];
  if (!allowed.includes(action)) return fail(`action 只能是：${allowed.join(' / ')}`);

  const s = settings();
  const labelMap = {
    like: '点赞', unlike: '取消点赞', coin: '投币', favorite: '收藏', unfavorite: '取消收藏', triple: '一键三连'
  };
  const label = labelMap[action];
  if ((action === 'like' || action === 'unlike') && !s.allowLike) return fail('设置里没开「点赞」，这次不操作。');
  if (action === 'coin' && !s.allowCoin) return fail('设置里没开「投币」，这次不操作。');
  if ((action === 'favorite' || action === 'unfavorite') && !s.allowFavorite) return fail('设置里没开「收藏」，这次不操作。');
  if (action === 'triple' && (!s.allowLike || !s.allowCoin || !s.allowFavorite)) {
    return fail('一键三连需要同时开启「点赞」「投币」「收藏」三个开关。');
  }

  const ref = await resolveVideo(fetch, target);
  const auth = await apiAuth();
  const info = await videoInfo(fetch, { ...ref, cookie: auth.cookie });
  const dedupeKey = `${action}:${info.aid}`;
  const windowMs = action === 'triple' ? HIGH_RISK_DEDUPE_MS : DEDUPE_WINDOW_MS;
  if (isRecent(dedupeKey, windowMs)) return fail(`《${info.title}》刚刚已经${label}过了，这次不重复。`);

  return withWriteLock(async () => {
    const gate = gateWrite('write', s, confirm);
    if (!gate.ok) return fail(gate.reason);
    if (gate.wait) await sleep(gate.wait);
    if (!auth.hasCsrf) return fail('缺少 bili_jct（CSRF），不能做写操作。请在设置里补上，或重新扫码登录。');

    const jct = String(auth.cookies.bili_jct || '').trim();
    const results = [];
    let changed = false;
    let firstError = null;

    const run = async (name, fn, alreadyCodes = []) => {
      try {
        await fn();
        changed = true;
        results.push(`${name}成功`);
      } catch (e) {
        if (alreadyCodes.includes(Number(e?.code))) {
          results.push(`${name}：${friendly(e)}`);
        } else {
          if (!firstError) firstError = e;
          results.push(`${name}失败：${friendly(e)}`);
        }
      }
    };

    if (action === 'like' || action === 'unlike') {
      await run(label, () => likeVideo(fetch, {
        aid: info.aid, like: action === 'like', csrf: jct, cookie: auth.cookie
      }), action === 'like' ? [65006] : [65004]);
    } else if (action === 'coin') {
      const count = clamp(Number(args?.coinCount) || s.coinCount, 1, 2);
      await run(`投币 ${count} 枚`, () => coinVideo(fetch, {
        aid: info.aid, multiply: count, selectLike: 0, csrf: jct, cookie: auth.cookie
      }));
    } else if (action === 'favorite' || action === 'unfavorite') {
      const mid = await myMid(auth);
      const folders = await favFolders(fetch, { mid, cookie: auth.cookie });
      const folderArg = String(args?.folderId || s.favoriteFolderId || '').trim();
      if (action === 'favorite') {
        const folder = folderArg ? folders.find((f) => String(f.id) === folderArg) : pickDefaultFolder(folders);
        if (!folder) return fail('找不到可用的收藏夹。先用 bili_fav_folders 看看有哪些，或在设置里填收藏夹 id。');
        await run(`收藏到「${folder.title}」`, () => favDeal(fetch, {
          aid: info.aid, add: String(folder.id), csrf: jct, cookie: auth.cookie
        }), [11201]);
      } else {
        const all = folders.map((f) => String(f.id)).filter(Boolean).join(',');
        if (!all) return fail('没有收藏夹可取消。');
        await run('取消收藏', () => favDeal(fetch, {
          aid: info.aid, del: all, csrf: jct, cookie: auth.cookie
        }), [11202]);
      }
    } else if (action === 'triple') {
      const count = clamp(Number(args?.coinCount) || s.coinCount, 1, 2);
      const folderArg = String(args?.folderId || s.favoriteFolderId || '').trim();
      if (count === 2 && !folderArg) {
        await run('一键三连', () => tripleVideo(fetch, { aid: info.aid, csrf: jct, cookie: auth.cookie }));
      } else {
        await run('点赞', () => likeVideo(fetch, {
          aid: info.aid, like: true, csrf: jct, cookie: auth.cookie
        }), [65006]);
        await run(`投币 ${count} 枚`, () => coinVideo(fetch, {
          aid: info.aid, multiply: count, selectLike: 0, csrf: jct, cookie: auth.cookie
        }));
        const mid = await myMid(auth);
        const folders = await favFolders(fetch, { mid, cookie: auth.cookie });
        const folder = folderArg ? folders.find((f) => String(f.id) === folderArg) : pickDefaultFolder(folders);
        if (folder) {
          await run(`收藏到「${folder.title}」`, () => favDeal(fetch, {
            aid: info.aid, add: String(folder.id), csrf: jct, cookie: auth.cookie
          }), [11201]);
        } else {
          results.push('收藏跳过：没有可用收藏夹');
        }
      }
    }

    if (changed) bumpQuota('write', dedupeKey);
    const text = `《${info.title}》\n${results.join('\n')}`;
    if (changed) await sendReceipt(ctx, `已处理《${info.title}》：${results.filter((x) => x.includes('成功')).join('；')}`);
    if (firstError && !changed) return fail(`${text}\n${errorWithCode(firstError)}`);
    return ok(text);
  });
}

async function resolveFollowMid(target) {
  const s = String(target ?? '').trim();
  if (!s) throw new BiliApiError(-400, '缺少 target：请给 UP 主 UID、空间链接或 ta 的视频链接。');
  if (/^\d{1,15}$/.test(s)) return Number(s);
  const m = s.match(/space\.bilibili\.com\/(\d+)/) || s.match(/[?&]mid=(\d+)/) || s.match(/^mid[:：](\d+)$/i);
  if (m) return Number(m[1]);
  if (extractVideoRef(s)) {
    const ref = await resolveVideo(fetch, s);
    const info = await videoInfo(fetch, { ...ref });
    if (info.mid) return Number(info.mid);
  }
  throw new BiliApiError(-400, '请给 UP 主的 UID（数字）、空间链接，或 ta 的视频链接。');
}

async function followTool(ctx, args) {
  const target = String(args?.target ?? '').trim();
  const action = String(args?.action ?? '').trim();
  const confirm = args?.confirm === true;
  const follow = action === 'follow';
  if (action !== 'follow' && action !== 'unfollow') return fail('action 只能是 follow 或 unfollow。');
  const s = settings();
  if (!s.allowFollow) return fail('设置里没开「关注/取关」，这次不操作。');
  if (!target) return fail('缺少 target：请给 UP 主 UID、空间链接或视频链接。');

  const fid = await resolveFollowMid(target);
  const cur = await getNav();
  if (cur.loggedIn && Number(cur.data?.mid) === fid) return fail('不能关注/取关自己。');
  const dedupeKey = `follow:${fid}:${follow ? 1 : 0}`;
  if (isRecent(dedupeKey, DEDUPE_WINDOW_MS)) return fail(`刚刚已经${follow ? '关注' : '取关'}过 UID ${fid} 了，这次不重复。`);

  return withWriteLock(async () => {
    const gate = gateWrite('write', s, confirm);
    if (!gate.ok) return fail(gate.reason);
    if (gate.wait) await sleep(gate.wait);
    const auth = await apiAuth();
    if (!auth.hasCsrf) return fail('缺少 bili_jct（CSRF），不能做写操作。请在设置里补上，或重新扫码登录。');
    try {
      await followUser(fetch, {
        fid, follow, csrf: String(auth.cookies.bili_jct || '').trim(), cookie: auth.cookie
      });
      bumpQuota('write', dedupeKey);
      await sendReceipt(ctx, follow ? `已关注 UID ${fid}` : `已取关 UID ${fid}`);
      return ok(follow ? `已关注 UID ${fid}。` : `已取关 UID ${fid}。`);
    } catch (e) {
      if (follow && Number(e?.code) === 22014) return ok(`已经关注过 UID ${fid} 了。`);
      return fail(errorWithCode(e));
    }
  });
}

async function commentTool(ctx, args) {
  const target = String(args?.target ?? '').trim();
  const message = String(args?.message ?? '').trim();
  const confirm = args?.confirm === true;
  const s = settings();
  if (!s.allowComment) return fail('设置里没开「评论」，这次不操作。');
  if (!target) return fail('缺少 target：请给视频链接或 BV 号。');
  if (!message) return fail('评论内容不能为空。');
  if (message.length > 1000) return fail('评论最多 1000 个字符。');

  const ref = await resolveVideo(fetch, target);
  const auth = await apiAuth();
  const info = await videoInfo(fetch, { ...ref, cookie: auth.cookie });
  const dedupeKey = `comment:${info.aid}:${hashText(message)}`;
  if (isRecent(dedupeKey, HIGH_RISK_DEDUPE_MS)) return fail('这条评论刚刚已经发过了，这次不重复。');

  return withWriteLock(async () => {
    const gate = gateWrite('comment', s, confirm);
    if (!gate.ok) return fail(gate.reason);
    if (gate.wait) await sleep(gate.wait);
    if (!auth.hasCsrf) return fail('缺少 bili_jct（CSRF），不能发评论。请在设置里补上，或重新扫码登录。');

    const replyTo = String(args?.replyTo || '').trim();
    const root = String(args?.root || replyTo || '').trim();
    const parent = String(args?.parent || replyTo || '').trim();
    try {
      const payload = await postComment(fetch, {
        aid: info.aid,
        message,
        csrf: String(auth.cookies.bili_jct || '').trim(),
        cookie: auth.cookie,
        root,
        parent
      });
      const rpid = payload?.data?.rpid_str || payload?.data?.rpid || '';
      bumpQuota('comment', dedupeKey);
      await sendReceipt(ctx, `已在《${info.title}》下发评论`);
      return ok(`评论已发出。\n视频：《${info.title}》\n评论 id：${rpid || '未知'}\n链接：${info.url}${rpid ? `#reply${rpid}` : ''}`);
    } catch (e) {
      return fail(errorWithCode(e));
    }
  });
}

async function dynamicTool(ctx, args) {
  const action = String(args?.action ?? 'post').trim();
  const confirm = args?.confirm === true;
  const s = settings();
  if (!s.allowDynamic) return fail('设置里没开「发动态/删动态」，这次不操作。');

  if (action === 'post') {
    const content = String(args?.content ?? '').trim();
    if (!content) return fail('动态内容不能为空。');
    if (content.length > 2000) return fail('动态正文最多 2000 个字符。');
    const dedupeKey = `dynamic:post:${hashText(content)}`;
    if (isRecent(dedupeKey, HIGH_RISK_DEDUPE_MS)) return fail('这条动态刚刚已经发过了，这次不重复。');
    return withWriteLock(async () => {
      const gate = gateWrite('dynamic', s, confirm);
      if (!gate.ok) return fail(gate.reason);
      if (gate.wait) await sleep(gate.wait);
      const auth = await apiAuth();
      if (!auth.hasCsrf) return fail('缺少 bili_jct（CSRF），不能发动态。请在设置里补上，或重新扫码登录。');
      try {
        let payload;
        try {
          payload = await postDynamicText(fetch, {
            content, csrf: String(auth.cookies.bili_jct || '').trim(), cookie: auth.cookie
          });
        } catch (legacyError) {
          // 旧接口失败时用新版接口兜底（两者返回字段不同）。
          try {
            payload = await postDynamicTextV2(fetch, {
              content, csrf: String(auth.cookies.bili_jct || '').trim(), cookie: auth.cookie
            });
          } catch {
            throw legacyError;
          }
        }
        const id = payload?.data?.dynamic_id_str || payload?.data?.dyn_id_str
          || payload?.data?.dynamic_id || payload?.data?.dyn_id || '';
        bumpQuota('dynamic', dedupeKey);
        await sendReceipt(ctx, '已发布一条 B 站动态');
        return ok(`动态已发布。${id ? `\n动态 id：${id}\n链接：https://t.bilibili.com/${id}` : ''}`);
      } catch (e) {
        return fail(errorWithCode(e));
      }
    });
  }

  if (action === 'delete') {
    const dynamicId = String(args?.dynamicId ?? '').trim();
    if (!/^\d+$/.test(dynamicId)) return fail('缺少 dynamicId，或它不是纯数字的动态 id。');
    const dedupeKey = `dynamic:delete:${dynamicId}`;
    return withWriteLock(async () => {
      const gate = gateWrite('write', s, confirm, { highRisk: true });
      if (!gate.ok) return fail(gate.reason);
      if (gate.wait) await sleep(gate.wait);
      const auth = await apiAuth();
      if (!auth.hasCsrf) return fail('缺少 bili_jct（CSRF），不能删动态。请在设置里补上，或重新扫码登录。');
      try {
        await deleteDynamic(fetch, {
          dynamicId, csrf: String(auth.cookies.bili_jct || '').trim(), cookie: auth.cookie
        });
        bumpQuota('write', dedupeKey);
        await sendReceipt(ctx, `已删除动态 ${dynamicId}`);
        return ok(`动态 ${dynamicId} 已删除。`);
      } catch (e) {
        return fail(errorWithCode(e));
      }
    });
  }

  return fail('action 只能是 post 或 delete。');
}

// ── 生命周期 / 注册 ─────────────────────────────────────────────────────

export function setup(api) {
  if (typeof api?.config === 'function') cfg = api.config;
  if (typeof api?.log === 'function') log = api.log;
  if (typeof api?.warn === 'function') warn = api.warn;

  api.registerTool({
    id: 'login',
    name: '登录B站账号（扫码）',
    description: '生成 B 站扫码登录二维码并发到当前会话，然后自动等待扫码结果。当用户说“登录B站”“绑定B站账号”“扫码登录”时使用。已经在登录状态时默认直接返回当前账号；只有用户明确要换号才传 force=true。',
    category: 'system',
    icon: '🔐',
    parameters: {
      type: 'object',
      properties: {
        force: { type: 'boolean', description: '已经登录时是否强制重新扫码换号，默认 false。' }
      }
    },
    async execute(ctx, args) {
      try { return await loginStart(ctx, args?.force === true); }
      catch (e) { return fail(`登录失败：${errorWithCode(e)}`); }
    }
  });

  api.registerTool({
    id: 'login_check',
    name: '检查B站登录结果',
    description: '检查刚才的扫码登录结果，或查询当前 B 站账号登录状态。用户说“扫好了”“登录上了吗”“登录成功没”时使用。',
    category: 'system',
    icon: '✅',
    parameters: { type: 'object', properties: {} },
    async execute() {
      try { return await loginCheck(); }
      catch (e) { return fail(`检查登录失败：${errorWithCode(e)}`); }
    }
  });

  api.registerTool({
    id: 'logout',
    name: '退出B站账号（本机）',
    description: '清除本机保存的 B 站扫码登录态。只影响这个机器人，不会让 B 站网页端退出。用户说“退出B站”“解绑B站账号”时使用。',
    category: 'system',
    icon: '🚪',
    parameters: { type: 'object', properties: {} },
    async execute() {
      stopLoginPoll('logout');
      clearStoredSession();
      state.navCache = null;
      state.buvidCache = null;
      return ok('已清除本机保存的扫码登录态。如果技能设置里还填着手动 SESSDATA/bili_jct，那些仍然生效，需要去设置里清空。');
    }
  });

  api.registerTool({
    id: 'account',
    name: '查询B站账号状态',
    description: '查询当前 B 站账号是否登录、昵称、UID、等级、硬币、关注/粉丝数，以及本技能允许哪些操作和今天还剩多少额度。做任何写操作前先用它确认登录状态。',
    category: 'query',
    icon: '👤',
    parameters: { type: 'object', properties: {} },
    async execute() {
      try { return await accountSummary(); }
      catch (e) { return fail(`查询账号失败：${errorWithCode(e)}`); }
    }
  });

  api.registerTool({
    id: 'video_info',
    name: '查B站视频信息',
    description: '查一个 B 站视频的标题、UP 主、播放/点赞/投币/收藏数，以及当前账号是否赞过、投过、收藏过。当群友发 B 站链接、或你准备对某个视频操作前，先用它看清内容。参数 target 可以是链接、BV 号或 av 号。',
    category: 'query',
    icon: '🎬',
    parameters: {
      type: 'object',
      properties: {
        target: { type: 'string', description: 'B 站视频链接、BV 号（如 BV1xx411c7mD）或 av 号。' }
      },
      required: ['target']
    },
    async execute(_ctx, args) {
      try { return await videoInfoTool(args); }
      catch (e) { return fail(`查视频失败：${errorWithCode(e)}`); }
    }
  });

  api.registerTool({
    id: 'fav_folders',
    name: '查B站收藏夹',
    description: '列出当前 B 站账号的收藏夹（名称、id、是否默认、视频数）。收藏视频前如果用户指定了收藏夹，先用它查 id。',
    category: 'query',
    icon: '📁',
    parameters: { type: 'object', properties: {} },
    async execute() {
      try { return await favFoldersTool(); }
      catch (e) { return fail(`查收藏夹失败：${errorWithCode(e)}`); }
    }
  });

  api.registerTool({
    id: 'video_action',
    name: 'B站视频互动（赞/币/藏/三连）',
    description: '对 B 站视频点赞、取消点赞、投币、收藏、取消收藏或一键三连。当用户明确要求，或自动模式下看到群友分享的视频值得互动时使用。参数 target 是链接/BV 号；action 选 like/unlike/coin/favorite/unfavorite/triple；coinCount 1 或 2；favorite 可传 folderId。写操作受设置开关、每日限额和自动模式约束。',
    category: 'messaging',
    icon: '👍',
    parameters: {
      type: 'object',
      properties: {
        target: { type: 'string', description: 'B 站视频链接、BV 号或 av 号。' },
        action: { type: 'string', enum: ['like', 'unlike', 'coin', 'favorite', 'unfavorite', 'triple'], description: 'like=点赞，unlike=取消赞，coin=投币，favorite=收藏，unfavorite=取消收藏，triple=一键三连。' },
        coinCount: { type: 'integer', description: '投币数量，1 或 2，默认用设置里的值。' },
        folderId: { type: 'string', description: '收藏夹 id（可选）。不填就用默认收藏夹或设置里的收藏夹 id。' },
        confirm: { type: 'boolean', description: '只有用户在当前对话里明确同意这次操作时才传 true；自动模式 auto 下可忽略。' }
      },
      required: ['target', 'action']
    },
    async execute(ctx, args) {
      try { return await videoActionTool(ctx, args); }
      catch (e) { return fail(`视频操作失败：${errorWithCode(e)}`); }
    }
  });

  api.registerTool({
    id: 'follow',
    name: 'B站关注/取关UP主',
    description: '关注或取关一个 B 站 UP 主。当用户明确说“关注这个 UP”“取关他”，或自动模式下你判断值得关注时使用。参数 target 可以是 UP 主 UID（数字）、空间链接，或 ta 的视频链接；action 选 follow/unfollow。',
    category: 'messaging',
    icon: '➕',
    parameters: {
      type: 'object',
      properties: {
        target: { type: 'string', description: 'UP 主 UID、空间链接（space.bilibili.com/数字）或 ta 的视频链接/BV 号。' },
        action: { type: 'string', enum: ['follow', 'unfollow'], description: 'follow=关注，unfollow=取关。' },
        confirm: { type: 'boolean', description: '只有用户明确同意时才传 true；自动模式 auto 下可忽略。' }
      },
      required: ['target', 'action']
    },
    async execute(ctx, args) {
      try { return await followTool(ctx, args); }
      catch (e) { return fail(`关注操作失败：${errorWithCode(e)}`); }
    }
  });

  api.registerTool({
    id: 'comment',
    name: 'B站发评论',
    description: '在 B 站视频下以当前账号发评论或回复评论。只在用户明确要求、或高风险模式允许且内容确实合适时使用。参数 target 是视频链接/BV 号；message 是评论正文（≤1000 字）；replyTo 是要回复的评论 rpid（可选）。这是公开发言，默认需要用户确认。',
    category: 'messaging',
    icon: '💬',
    parameters: {
      type: 'object',
      properties: {
        target: { type: 'string', description: 'B 站视频链接、BV 号或 av 号。' },
        message: { type: 'string', description: '评论正文，最多 1000 字。' },
        replyTo: { type: 'string', description: '要回复的评论 rpid（可选）。' },
        root: { type: 'string', description: '根评论 rpid（回复二级评论时可选）。' },
        parent: { type: 'string', description: '父评论 rpid（回复二级评论时可选）。' },
        confirm: { type: 'boolean', description: '只有用户明确同意发这条评论时才传 true。' }
      },
      required: ['target', 'message']
    },
    async execute(ctx, args) {
      try { return await commentTool(ctx, args); }
      catch (e) { return fail(`发评论失败：${errorWithCode(e)}`); }
    }
  });

  api.registerTool({
    id: 'dynamic',
    name: 'B站发/删动态',
    description: '以当前账号发布纯文本 B 站动态，或删除自己的一条动态。只在用户明确要求、或高风险模式允许且内容确实合适时使用。action=post 时传 content；action=delete 时传 dynamicId。这是公开发言，默认需要用户确认。',
    category: 'messaging',
    icon: '📝',
    parameters: {
      type: 'object',
      properties: {
        action: { type: 'string', enum: ['post', 'delete'], description: 'post=发动态，delete=删动态。' },
        content: { type: 'string', description: '动态正文，最多 2000 字（action=post 时必填）。' },
        dynamicId: { type: 'string', description: '要删除的动态 id（action=delete 时必填）。' },
        confirm: { type: 'boolean', description: '只有用户明确同意时才传 true。' }
      },
      required: ['action']
    },
    async execute(ctx, args) {
      try { return await dynamicTool(ctx, args); }
      catch (e) { return fail(`动态操作失败：${errorWithCode(e)}`); }
    }
  });
}

export function available() {
  return true;
}

export async function deactivate() {
  stopLoginPoll('deactivated');
}

export function dispose() {
  stopLoginPoll('dispose');
}
