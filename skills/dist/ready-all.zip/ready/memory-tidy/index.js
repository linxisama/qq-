// 印象整理：每周提醒一次回头看看对别人的印象还准不准。
// 只负责"提醒"和"记日期"，真正的读写走 core 的 memory_query / memory_append / memory_remove。
import fs from 'node:fs';
import path from 'node:path';

let api = null;

function conf() {
  const c = api?.config?.() || {};
  return {
    enabled: c.enabled !== false,
    dir: String(c.dir || 'data/memory-tidy'),
    everyDays: Math.max(1, Math.min(90, Number(c.everyDays) || 7)),
    maxPerRound: Math.max(1, Math.min(20, Number(c.maxPerRound) || 6))
  };
}

function statePath() {
  const dir = conf().dir;
  const abs = path.isAbsolute(dir) ? dir : path.resolve(process.cwd(), dir);
  return path.join(abs, 'state.json');
}

function readState() {
  try {
    const raw = JSON.parse(fs.readFileSync(statePath(), 'utf8'));
    return { lastTidyAt: Number(raw?.lastTidyAt) || 0, lastNudgeAt: Number(raw?.lastNudgeAt) || 0 };
  } catch {
    return { lastTidyAt: 0, lastNudgeAt: 0 };
  }
}

function writeState(s) {
  const p = statePath();
  fs.mkdirSync(path.dirname(p), { recursive: true });
  fs.writeFileSync(p, JSON.stringify(s, null, 2), 'utf8');
}

function dayKey(ts = Date.now()) {
  const d = new Date(ts);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

function dueInfo() {
  const c = conf();
  const s = readState();
  const everyMs = c.everyDays * 86400000;
  const nextAt = (s.lastTidyAt || 0) + everyMs;
  return { ...s, nextAt, due: Date.now() >= nextAt, daysLeft: Math.max(0, Math.ceil((nextAt - Date.now()) / 86400000)) };
}

export function setup(a) {
  api = a;

  api.registerTool({
    id: 'done',
    name: '整理完了',
    description: '这轮印象整理结束，记下日期，下次从今天起算。',
    category: 'memory',
    icon: '🧽',
    parameters: {
      type: 'object',
      properties: { note: { type: 'string', description: '这轮看了谁、改了什么（一句话，可省略）' } }
    },
    async execute(args) {
      const s = readState();
      s.lastTidyAt = Date.now();
      s.lastNote = String(args?.note || '').slice(0, 200);
      writeState(s);
      const c = conf();
      return { ok: true, note: `记下了，${c.everyDays} 天后再看` };
    }
  });

  api.registerTool({
    id: 'status',
    name: '下次什么时候整理',
    description: '上次整理的时间、还差几天。',
    category: 'memory',
    icon: '📅',
    parameters: { type: 'object', properties: {} },
    async execute() {
      const d = dueInfo();
      const last = d.lastTidyAt ? new Date(d.lastTidyAt).toLocaleString('zh-CN') : '还没整理过';
      return { ok: true, due: d.due, lastTidyAt: d.lastTidyAt, note: `上次整理：${last}；${d.due ? '现在该整理了' : `还差 ${d.daysLeft} 天`}` };
    }
  });
}

export function promptSections() {
  try {
    const c = conf();
    if (!c.enabled) return [];
    const d = dueInfo();
    if (!d.due) return [];
    // 一天最多提醒一次，别变成唠叨
    const today = dayKey();
    if (d.lastNudgeAt && dayKey(d.lastNudgeAt) === today) return [];
    const s = readState();
    s.lastNudgeAt = Date.now();
    writeState(s);
    const last = d.lastTidyAt ? new Date(d.lastTidyAt).toLocaleDateString('zh-CN') : '从来没整理过';
    return [{
      id: 'memory-tidy-nudge',
      title: '',
      priority: 50,
      content: `【该回头看看印象了】上次整理你对他人的印象是 ${last}。挑 ${Math.min(3, c.maxPerRound)} 个最近真聊过的人，用 memory_query 看一下旧印象，变了的用 memory_append 补、过时的用 memory_remove 删；不用跟谁提这件事，做完调 memory-tidy__done 就行。`
    }];
  } catch {
    return [];
  }
}

export function available() {
  return true;
}

export function dispose() {
  api = null;
}

export const internals = { conf, readState, writeState, dueInfo, statePath };
