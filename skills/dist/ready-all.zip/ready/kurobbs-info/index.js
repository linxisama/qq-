// 鸣潮情报（库街区 kurobbs.com / 鸣潮专区）—— LLM 型技能。
//
// 五个工具：
//   kurobbs_news    官方「公告 / 活动 / 资讯」列表
//   kurobbs_post    某条帖子的正文
//   kurobbs_search  正文全文检索 + 自动摘时间（回答「XX 卡池什么时候上线」的主力）
//   kurobbs_image   角色图：cos / 同人绘画 / 插画（带去重 + 可选视觉校验）
//   kurobbs_guide   角色攻略：一图流 + 正文摘录
//
// 只做**鸣潮**（gameId=3）。战双等其他专区一律不查。

import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const SKILL_ROOT = path.dirname(fileURLToPath(import.meta.url));
const STATE_DIR = path.join(SKILL_ROOT, '.state');
const SENT_FILE = path.join(STATE_DIR, 'sent-images.json');

//
// ── token 预算（这个文件的输出被刻意压到最短）───────────────────────────
//   每次对话都是新会话，工具描述 + 提示词片段 + 工具返回都会重复计费，所以：
//   · 工具描述只写「什么时候用 + 参数」，不写使用教程（教程在提示词里，只进一次）
//   · 返回只留 标题 / 时间 / 命中片段，不给链接（除非是正文工具）
//   · 时间统一压成 2026-10-22 10:00 这种短格式，去掉「（服务器时间）」「✦」
//   · 命中默认 2 条、时间行 2 行、正文默认截 800 字；没有一句多余的客套话
//
// ── 接口（库街区网页端自己用的公开接口，不需要账号）─────────────────────
//   POST /forum/companyEvent/findEventList  eventType 1=活动 2=资讯 3=公告，gameId=3
//   POST /forum/getPostDetail              postId
// ⚠️ 两个坑：① 请求头必须带 source:h5 与 version，缺了照样 200 但没数据；
//            ② 请求体必须是 x-www-form-urlencoded，发 JSON 会得到空 list。

const DEFAULT_API_BASE = 'https://api.kurobbs.com';
const DEFAULT_WEB_VERSION = '3.3.2';
const GAME_ID = '3';
const GAME_LABEL = '鸣潮';
const GAME_PATH = 'mc';
const USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36';

// eventType：1=活动 2=资讯 3=公告
const TYPES = { '公告': 3, '活动': 1, '资讯': 2 };
const TYPE_ALIASES = [
  { type: '公告', words: ['公告', '通知', '维护', '补偿', '声明', '更新公告'] },
  { type: '活动', words: ['活动', '福利', '唤取', '卡池', '签到', '限时', '奖励'] },
  { type: '资讯', words: ['资讯', '动态', 'pv', '前瞻', '电台', '情报', '新闻'] }
];

let cfg = () => ({});
let httpFetch = null;
let log = () => {};

const DEVICE_ID = randomHex(32);
const DISTINCT_ID = randomHex(32);

// 每个会话最近一次列表：支持「第 2 条是什么」
const recentLists = new Map();
// 检索结果缓存：同群反复问同一个角色不必重新联网
const searchCache = new Map();

export function setup(api) {
  cfg = api.config;
  httpFetch = typeof api.fetch === 'function' ? (...args) => api.fetch(...args) : null;
  if (typeof api.log === 'function') log = api.log;

  // ── 列表 ────────────────────────────────────────────────────────────────
  api.registerTool({
    id: 'kurobbs_news',
    name: '鸣潮官方列表',
    description: '查库街区鸣潮专区的官方公告/活动/资讯标题与日期。问「最新公告」「这期活动」「最近资讯」时用。',
    category: 'knowledge',
    icon: '📰',
    parameters: {
      type: 'object',
      properties: {
        type: { type: 'string', description: '公告 / 活动 / 资讯，默认公告' },
        count: { type: 'number', description: '条数 1~10，默认 5' }
      }
    },
    async execute(ctx, args) {
      const c = cfg();
      if (!httpFetch) return { content: '未启用 web_fetch 权限', isError: true };

      const type = normalizeType(args?.type ?? c.defaultType);
      const maxCount = clamp(Number(c.maxCount) || 10, 1, 10);
      const count = clamp(Number(args?.count) || Number(c.defaultCount) || 5, 1, maxCount);

      try {
        const data = await apiPost('/forum/companyEvent/findEventList', {
          eventType: TYPES[type], gameId: GAME_ID, pageNo: 1, pageSize: count
        }, c);
        const items = toItems(data?.list, type);
        if (!items.length) return { content: `鸣潮最近没有${type}条目。`, isError: true };

        recentLists.set(String(ctx?.chatKey ?? ''), { type, at: Date.now(), items });
        const lines = items.map((it, i) => `${i + 1}. ${it.title}${stamp(it.time, c)}`);
        return { content: `${GAME_LABEL}·${type} 最近 ${items.length} 条\n${lines.join('\n')}` };
      } catch (error) {
        return { content: `查库街区失败：${error?.message ?? error}`, isError: true };
      }
    }
  });

  // ── 正文 ────────────────────────────────────────────────────────────────
  api.registerTool({
    id: 'kurobbs_post',
    name: '鸣潮帖子正文',
    description: '取某条鸣潮官方帖子的正文。postId、index（上次列表第几条）、keyword（标题关键词）三选一。',
    category: 'knowledge',
    icon: '📄',
    parameters: {
      type: 'object',
      properties: {
        postId: { type: 'string', description: '帖子 id' },
        index: { type: 'number', description: '上次列表第几条，从 1 开始' },
        keyword: { type: 'string', description: '标题关键词' }
      }
    },
    async execute(ctx, args) {
      const c = cfg();
      if (!httpFetch) return { content: '未启用 web_fetch 权限', isError: true };

      const chatKey = String(ctx?.chatKey ?? '');
      const cache = recentLists.get(chatKey);
      let postId = String(args?.postId ?? '').trim();
      let title = '';

      if (!postId && Number(args?.index)) {
        const idx = Math.round(Number(args.index));
        if (!cache?.items?.length) return { content: '没有上次列表，先用 kurobbs_news 查一次。', isError: true };
        if (idx < 1 || idx > cache.items.length) return { content: `上次列表只有 ${cache.items.length} 条。`, isError: true };
        postId = cache.items[idx - 1].postId;
        title = cache.items[idx - 1].title;
      }

      if (!postId && String(args?.keyword ?? '').trim()) {
        const kw = String(args.keyword).trim().toLowerCase();
        const cachedHit = (cache?.items || []).find((it) => it.title.toLowerCase().includes(kw));
        if (cachedHit) {
          postId = cachedHit.postId;
          title = cachedHit.title;
        } else {
          const found = await findByKeyword(kw, c);
          if (!found) return { content: `没找到含「${args.keyword}」的条目，先用 kurobbs_news 看列表。`, isError: true };
          postId = found.postId;
          title = found.title;
        }
      }

      if (!postId) return { content: 'postId / index / keyword 至少给一个。', isError: true };

      try {
        const data = await apiPost('/forum/getPostDetail', { postId }, c);
        const post = data?.postDetail;
        if (!post) return { content: `没取到帖子 ${postId} 的正文。`, isError: true };

        title = cleanTitle(post.postTitle) || title;
        const body = extractText(post.postContent);
        const limit = clamp(Number(c.maxDetailChars) || 800, 200, 4000);
        const clipped = body.length > limit ? `${body.slice(0, limit)}…（原文 ${body.length} 字）` : body;
        const when = post.createTimestamp ? stamp(Number(post.createTimestamp), c) : '';

        return {
          content:
            `《${title}》${when}\n`
            + `https://www.kurobbs.com/${GAME_PATH}/post/${postId}\n`
            + (clipped || '（这条只有图片，没有文字）')
        };
      } catch (error) {
        return { content: `取正文失败：${error?.message ?? error}`, isError: true };
      }
    }
  });

  // ── 正文检索（时间类问题的主力）──────────────────────────────────────────
  api.registerTool({
    id: 'kurobbs_search',
    name: '鸣潮正文检索',
    description: '在鸣潮官方公告/资讯/活动的正文里检索，并摘出时间行。回答「XX 卡池/活动/维护 什么时候开或结束」用。keyword 可直接传用户原话。',
    category: 'knowledge',
    icon: '🔎',
    parameters: {
      type: 'object',
      properties: {
        keyword: { type: 'string', description: '角色名/武器名/版本号/活动名，或直接传用户原话' },
        maxHits: { type: 'number', description: '命中条数 1~5，默认 2' }
      },
      required: ['keyword']
    },
    async execute(ctx, args) {
      const c = cfg();
      if (!httpFetch) return { content: '未启用 web_fetch 权限', isError: true };

      const keyword = String(args?.keyword ?? '').trim();
      if (!keyword) return { content: '缺少 keyword。', isError: true };
      // 只做鸣潮。别让「库里没有」被当成「这个角色没有卡池」——
      // 战双/其他游戏本来就不在数据范围里。
      if (/战双|帕弥什|pns|punishing|星穹|崩铁|原神|绝区零|明日方舟/i.test(keyword)) {
        return { content: '本技能只查鸣潮，战双和其他游戏不在范围内。', isError: true };
      }

      const maxHits = clamp(Number(args?.maxHits) || 2, 1, 5);
      // 「随口问一句」：模型很可能把整句塞进来，先拆成候选词，短的排前面
      const candidates = keywordCandidates(keyword);
      const started = Date.now();
      const deadline = clamp(Number(c.searchDeadlineMs) || 8000, 3000, 20000);

      try {
        for (let i = 0; i < candidates.length; i += 1) {
          if (Date.now() - started > deadline) break;
          const found = await searchPosts(candidates[i], c, {
            maxHits,
            bodyLimit: i === 0 ? null : 4
          });
          if (!found) continue;

          const lines = found.hits.map((hit, n) => {
            const head = `${n + 1}. ${hit.title}${stamp(hit.time, c)}`;
            const times = hit.timeLines.length
              ? `时间：${hit.timeLines.join('；')}`
              : '时间：（这条没有明显时间）';
            const snippet = hit.snippet ? `摘：${hit.snippet}` : '';
            return [head, `   ${times}`, snippet ? `   ${snippet}` : ''].filter(Boolean).join('\n');
          });
          const used = candidates[i] === keyword ? '' : `（按「${candidates[i]}」命中）`;

          return {
            content: `${GAME_LABEL}·${found.type} 命中「${keyword}」${used}\n${lines.join('\n')}`
          };
        }

        return {
          content: `鸣潮公告/资讯/活动里没检索到「${keyword}」（试过：${candidates.join('、')}）。`,
          isError: true
        };
      } catch (error) {
        return { content: `检索失败：${error?.message ?? error}`, isError: true };
      }
    }
  });

  // ── 图片：cos / 同人绘画 ─────────────────────────────────────────────────
  api.registerTool({
    id: 'kurobbs_image',
    name: '库街区角色图',
    description: '在库街区社区搜某个角色的图并发出来——cos、同人绘画、插画都行。用户说"来一张XX的cos图""发几张XX的图""有没有XX的同人图"时用。kind 不填自动判断：带 cos 走 cos，否则走绘画/同人。',
    category: 'media',
    icon: '🖼️',
    parameters: {
      type: 'object',
      properties: {
        keyword: { type: 'string', description: '角色名，如 今汐 / 长离 / 锁暝' },
        count: { type: 'number', description: '发几张，1~3，默认 1' },
        kind: { type: 'string', description: 'cos / art / auto，默认 auto' }
      },
      required: ['keyword']
    },
    async execute(ctx, args) {
      const c = cfg();
      if (!httpFetch) return { content: '未启用 web_fetch 权限', isError: true };
      const keyword = String(args?.keyword ?? '').trim();
      if (!keyword) return { content: '缺少 keyword：要看谁的图？', isError: true };

      const want = String(args?.kind ?? c.imageKind ?? 'auto').toLowerCase();
      const kind = /cos|写真|正片/.test(want) ? 'cos'
        : (/art|draw|paint|绘|画/.test(want) ? 'art' : (COS_HINTS.test(keyword) ? 'cos' : 'art'));

      const maxImages = clamp(Number(c.cosMaxImages) || 3, 1, 5);
      const count = clamp(Number(args?.count) || Number(c.cosCount) || 1, 1, maxImages);
      const qualifiers = extractQualifiers(keyword);     // 皮肤/泳装/和服…
      // 角色名里也要把限定词剥掉，否则会显示成「今汐皮肤」的皮肤图
      const who = stripQualifiers(cleanKeyword(keyword)) || cleanKeyword(keyword) || keyword;

      const suffixes = kind === 'cos'
        ? [String(c.cosSuffix || 'cos')]
        : String(c.artSuffixes || '手绘,插画,同人').split(',').map((s) => s.trim()).filter(Boolean);
      const queries = suffixes.map((s) => `${who} ${s}`);
      if (qualifiers.length) queries.push(`${who} ${qualifiers[0]}`);   // 限定词单独再搜一遍

      try {
        const list = await searchCommunityMany(queries, c);
        if (!list.length) return { content: `库街区里没搜到「${who}」的帖子。`, isError: true };

        let ranked = rankImages(list, who, kind).filter((it) => titleHasKeyword(it.title, who));
        if (!ranked.length) {
          return {
            content: `没搜到「${who}」的${kind === 'cos' ? 'cos' : '动漫'}图（${list.length} 条结果里没有标题对得上的）。换个角色或换个说法再试。`,
            isError: true
          };
        }
        // 标题里带限定词（皮肤/泳装…）的排前面
        if (qualifiers.length) {
          const hit = ranked.filter((it) => qualifiers.some((q) => it.title.toLowerCase().includes(q)));
          ranked = hit.length ? [...hit, ...ranked.filter((it) => !hit.includes(it))] : ranked;
        }

        const already = c.imageDedupe === false ? new Set() : sentUrls(ctx.chatKey, c.dedupeDays);
        const needVision = qualifiers.length > 0 && String(c.visionCheck ?? 'auto') !== 'off';
        const maxChecks = clamp(Number(c.visionMaxChecks) || 3, 0, 6);

        const picked = [];
        let fromPost = null;
        let rejected = 0;
        let checks = 0;
        let visionBroken = 0;

        for (const item of ranked.slice(0, 6)) {
          if (picked.length >= count) break;
          const detail = await apiPost('/forum/getPostDetail', { postId: item.postId }, c).catch(() => null);
          const urls = collectImages(detail?.postDetail);
          if (!urls.length) continue;
          for (const url of urls) {
            if (picked.length >= count) break;
            if (picked.includes(url) || already.has(url)) continue;   // 发过的不再发
            if (needVision && checks < maxChecks) {
              checks += 1;
              const what = qualifiers.map((x) => `「${x}」`).join('或');
              const ok = await askVision(
                url,
                `这张图是不是游戏《鸣潮》角色「${who}」的图，并且主题/服装属于${what}？（不是这个角色、或不是这个主题就回答否）`,
                c
              );
              if (ok === false) { rejected += 1; continue; }
              if (ok === null) visionBroken += 1;
            }
            if (!fromPost) fromPost = { title: item.title, userName: item.userName, total: urls.length };
            picked.push(url);
          }
        }

        if (!picked.length) {
          if (rejected > 0) {
            return {
              content: `看了 ${rejected} 张，都不像「${who}」的${qualifiers.join('/')}图，所以没发。`
                + '可以换个说法（说清是哪套衣服，比如「新时装」「泳装」），或者干脆只说要角色名。',
              isError: true
            };
          }
          return { content: '这个角色的图都发过了（或者图片取不到），等一会儿再来，或者换个角色。', isError: true };
        }

        let sent = 0;
        const sentOk = [];
        for (const url of picked) {
          try { await sendImage(ctx, url, `库街区图:${who}`); sent += 1; sentOk.push(url); } catch { /* 单张失败跳过 */ }
        }
        if (!sent) return { content: '图片地址取到了但发送失败，稍后再试。', isError: true };
        if (c.imageDedupe !== false) markSent(ctx.chatKey, sentOk);

        const notes = [];
        if (needVision && rejected) notes.push(`筛掉 ${rejected} 张不符合的`);
        if (visionBroken) notes.push('视觉校验没跑起来，这次按标题筛的');
        return {
          content: `已发送 ${sent} 张「${who}」的${qualifiers.length ? qualifiers.join('/') : (kind === 'cos' ? 'cos' : '动漫')}图`
            + `（帖《${fromPost.title}》by ${fromPost.userName || '匿名'}，该帖共 ${fromPost.total} 张`
            + (notes.length ? `；${notes.join('，')}` : '') + '）。'
            + '图已经发出去了，不要复述也不要描述图片内容。'
        };
      } catch (error) {
        return { content: `搜图失败：${error?.message ?? error}`, isError: true };
      }
    }
  });

  // ── 角色攻略 ─────────────────────────────────────────────────────────────
  api.registerTool({
    id: 'kurobbs_guide',
    name: '库街区角色攻略',
    description: '搜某个角色的攻略帖（养成/配队/共鸣链/一图流），把攻略正文或攻略图发出来。用户说"要XX的攻略""XX怎么养""XX配队""XX共鸣链"时用。',
    category: 'knowledge',
    icon: '📕',
    parameters: {
      type: 'object',
      properties: {
        keyword: { type: 'string', description: '角色名，如 锁暝 / 今汐' },
        withImage: { type: 'boolean', description: '一图流攻略要不要把图也发出来，默认发' }
      },
      required: ['keyword']
    },
    async execute(ctx, args) {
      const c = cfg();
      if (!httpFetch) return { content: '未启用 web_fetch 权限', isError: true };
      const keyword = String(args?.keyword ?? '').trim();
      if (!keyword) return { content: '缺少 keyword：要哪个角色的攻略？', isError: true };
      const who = cleanKeyword(keyword);
      const wantImage = args?.withImage !== false && c.guideSendImage !== false;

      try {
        const list = await searchCommunityMany([`${who} 攻略`, `${who} 一图流`], c);
        if (!list.length) return { content: `库街区里没搜到「${who}」的攻略帖。`, isError: true };

        const ranked = rankGuides(list, who).filter((it) => titleHasKeyword(it.title, who));
        if (!ranked.length) return { content: `没搜到「${who}」的攻略（标题对不上），换个角色名或写法再试。`, isError: true };

        const best = ranked[0];
        const detail = await apiPost('/forum/getPostDetail', { postId: best.postId }, c).catch(() => null);
        const post = detail?.postDetail;
        const body = extractText(post?.postContent);
        const limit = clamp(Number(c.guideMaxChars) || 700, 200, 2000);
        const excerpt = body.length > limit ? `${body.slice(0, limit)}…（原文 ${body.length} 字）` : body;

        // 一图流：标题或图片数量表明它是图为主的攻略，就把图发出来
        const urls = collectImages(post);
        const looksImageGuide = urls.length > 0 && (/一图流|图解|流程|速查|图鉴/.test(best.title) || best.imgCount >= 3);
        let imgNote = '';
        if (wantImage && looksImageGuide) {
          try {
            await sendImage(ctx, urls[0], `攻略:${who}`);
            imgNote = `（攻略图已发送，该帖共 ${urls.length} 张）`;
          } catch { imgNote = '（攻略图发送失败）'; }
        }

        if (!excerpt && !imgNote) {
          return { content: `《${best.title}》是视频帖，没有可提取的文字。给个作品号或换个图文攻略再试。`, isError: true };
        }

        return {
          content:
            `《${best.title}》by ${best.userName || '匿名'}${imgNote}\n`
            + (excerpt ? `正文摘录：\n${excerpt}\n` : '')
            + '用两三句话讲清关键点（声骸/配队/共鸣链/循环），别整段贴原文；图已经发了就别再描述图。',
        };
      } catch (error) {
        return { content: `搜攻略失败：${error?.message ?? error}`, isError: true };
      }
    }
  });
}

export function available() {
  return true;
}

// ── 发图去重 + 需求校验 ────────────────────────────────────────────────────
//
// 三个问题，三个解法：
//   ① 「发过的图又发一遍」→ 按会话记已发 URL（落盘 .state/sent-images.json，默认保留 7 天）
//   ② 「要皮肤图却发了常服」→ 先从话里抽出限定词（皮肤/泳装/和服/婚纱/国风…），
//      标题命中的优先；一个都没命中就不硬发
//   ③ 「是不是这个角色/这套衣服」→ 用**你已配置的视觉模型**逐张确认（默认开，1~2 秒/张，
//      最多校验 3 张）。模型从主程序 config.json 里读（api.baseUrl / apiKey / visionModel），
//      技能设置里也能单独覆盖。

const COSTUME_WORDS = ['皮肤', '时装', '新衣', '服装', '泳装', '和服', '旗袍', '礼服', '婚纱', '制服', 'jk', '国风', '汉服', '冬日', '夏日', '春节', '中秋', '生日', '周年', '联动', '校园', '运动', '睡衣'];

function readSent() {
  try { return JSON.parse(fs.readFileSync(SENT_FILE, 'utf8')) || {}; } catch { return {}; }
}

function writeSent(store) {
  try {
    fs.mkdirSync(STATE_DIR, { recursive: true });
    fs.writeFileSync(SENT_FILE, JSON.stringify(store), 'utf8');
  } catch { /* 写不进去就退化成本次调用内去重 */ }
}

/** 已发过 = 这个会话发过这张图，且没过期。 */
function sentUrls(chatKey, days) {
  const store = readSent();
  const key = String(chatKey || '');
  const bucket = store[key] || {};
  const ttl = clamp(Number(days) || 7, 1, 60) * 86400000;
  const now = Date.now();
  const alive = new Set();
  for (const [url, ts] of Object.entries(bucket)) {
    if (now - Number(ts) < ttl) alive.add(url);
    else delete bucket[url];
  }
  store[key] = bucket;
  writeSent(store);
  return alive;
}

function markSent(chatKey, urls) {
  const store = readSent();
  const key = String(chatKey || '');
  store[key] = store[key] || {};
  const now = Date.now();
  for (const u of urls) store[key][u] = now;
  // 每个会话最多记 800 条，别无限长
  const entries = Object.entries(store[key]).sort((a, b) => b[1] - a[1]).slice(0, 800);
  store[key] = Object.fromEntries(entries);
  writeSent(store);
}

/** 把限定词从角色名里剥掉：「今汐皮肤」→「今汐」。 */
function stripQualifiers(s) {
  let t = String(s || '');
  for (const w of COSTUME_WORDS) t = t.split(w).join(' ');
  return t.replace(/s+/g, ' ').trim();
}

/** 从「今汐皮肤的cos」里抽出限定词：['皮肤']。 */
function extractQualifiers(text) {
  const raw = String(text || '').toLowerCase();
  return COSTUME_WORDS.filter((w) => raw.includes(w));
}

/** 读主程序的模型配置（技能设置优先）。 */
let appCfgCache = null;
function appApiConfig() {
  if (appCfgCache) return appCfgCache;
  // 安装版布局：<安装目录>/resources/app/skills/kurobbs-info → <安装目录>/data/config.json
  // 开发版布局：<项目>/skills/kurobbs-info → <项目>/data/config.json
  const tries = [
    path.join(SKILL_ROOT, '..', '..', '..', '..', 'data', 'config.json'),
    path.join(SKILL_ROOT, '..', '..', 'data', 'config.json'),
    path.join(SKILL_ROOT, '..', '..', '..', 'data', 'config.json')
  ];
  for (const p of tries) {
    try {
      const j = JSON.parse(fs.readFileSync(p, 'utf8'));
      if (j?.api?.baseUrl && j?.api?.apiKey) { appCfgCache = j.api; return appCfgCache; }
    } catch { /* 下一个 */ }
  }
  appCfgCache = {};
  return appCfgCache;
}

/**
 * 让视觉模型判断一张图是否符合要求。
 * 返回 true / false / null（模型不可用，当作"没意见"）。
 */
async function askVision(url, question, c) {
  const api = appApiConfig();
  const base = String(c.visionBaseUrl || api.baseUrl || '').replace(/\/+$/, '');
  const key = String(c.visionApiKey || api.apiKey || '').trim();
  const model = String(c.visionModel || api.visionModel || api.model || '').trim();
  if (!base || !key || !model) {
    log(`视觉校验跳过：配置不全 base=${base || '-'} key=${key ? '有' : '无'} model=${model || '-'}`);
    return null;
  }

  const body = {
    model,
    max_tokens: 400,
    messages: [{
      role: 'user',
      content: [
        { type: 'text', text: `${question}\n只回答「是」或「否」，不要解释。` },
        { type: 'image_url', image_url: { url } }
      ]
    }]
  };
  const doCall = async (extra) => {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), clamp(Number(c.visionTimeoutMs) || 15000, 5000, 60000));
    try {
      const resp = await httpFetch(`${base}/chat/completions`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${key}` },
        body: JSON.stringify({ ...body, ...extra }),
        signal: controller.signal
      });
      if (!resp.ok) { log(`视觉校验 HTTP ${resp.status}`); return { ok: false, status: resp.status }; }
      const json = await resp.json();
      const text = String(json?.choices?.[0]?.message?.content || '').trim();
      return { ok: true, text };
    } catch {
      return { ok: false, status: 0 };
    } finally {
      clearTimeout(timer);
    }
  };

  // 会思考的模型可能把 token 全烧在 reasoning 上 → 先关思考，端点不认再退回普通调用
  let r = await doCall({ thinking: { type: 'disabled' } });
  if (!r.ok && r.status === 400) r = await doCall({});
  if (!r.ok || !r.text) { log(`视觉校验无结果 status=${r.status} text=${String(r.text || '').slice(0, 40)}`); return null; }
  if (/^是/.test(r.text) || /yes|true|符合/i.test(r.text)) return true;
  if (/^否/.test(r.text) || /no|false|不符/i.test(r.text)) return false;
  return null;
}

// ── 社区帖子：cos / 同人图 ─────────────────────────────────────────────────
//
// 官方公告那套接口（companyEvent/findEventList）只有官方内容，cos 图在**用户帖子**里，
// 要走搜索接口：POST /forum/search/v2/post  body: keyword=… & gameId=3 & pageNo & pageSize
// （参数名是 keyword，不是 q/query/words —— 试过一圈，别的名字一律回「请输入搜索关键词」）
// 图片在帖子详情里：postContent[] 中 contentType===2 的 url，域名 prod-alicdn-community.kurobbs.com
// （实测 2.3MB 的 jpg 直接可取，不需要 Referer、不需要登录）。

const COS_HINTS = /cos|play|写真|正片|拍|摄/i;              // 判定「用户想要 cos」
const COS_POST_HINTS = /cos|play|写真|正片|返图|场照|出角/i;  // 判定「这是一条 cos 帖」
const ART_POST_HINTS = /手绘|绘画|插画|同人图|摸鱼|线稿|草稿|画|壁纸|立绘|二创|原创|临摹|涂/i;
// 同人文/小说帖也常带图，但那是配图不是画作 —— 单独压下去
const FICTION_HINTS = /同人文|小说|番外|连载|第[一二三四五六七八九十0-9]{1,3}章|更新至|序章|终章|篇-/i;
const OFFTOPIC_HINTS = /攻略|养成|配队|一图流|前瞻|材料|抽取|节奏榜|解析|计算|数据|机制|技能|连招|地图|任务|成就|兑换码|公告|资讯|周边|预售|上架|补货|考据|复盘|剧情|抽卡/i;
const GUIDE_POST_HINTS = /攻略|养成|配队|一图流|图解|教学|循环|思路|声骸|共鸣链|武器|培养|抽取建议/i;

function stripEm(s) {
  return String(s ?? '').replace(/<\/?em>/gi, '').replace(/\s+/g, ' ').trim();
}

/** 从「今汐的cos图」这类话里抽出角色名，用来拼搜索词和做标题校验。 */
function cleanKeyword(s) {
  const cleaned = String(s ?? '')
    .replace(/cos|play|写真|正片|图集|返图|同人|绘画|插画|手绘|线稿|图|照片|壁纸|的/gi, ' ')
    .replace(/\s+/g, ' ')
    .trim();
  return cleaned || String(s ?? '').trim();
}

/** 标题里必须真的出现这个角色名——搜索是模糊匹配，不校验就会发错人的图。 */
function titleHasKeyword(title, kw) {
  const t = String(title ?? '').replace(/\s+/g, '').toLowerCase();
  const k = String(kw ?? '').replace(/\s+/g, '').toLowerCase();
  return k.length >= 2 ? t.includes(k) : true;
}

function normalizeSearchItem(it) {
  const cover = Array.isArray(it?.coverImages) && it.coverImages.length
    ? String(it.coverImages[0]?.url || it.coverImages[0]?.sourceUrl || '')
    : '';
  return {
    postId: String(it?.postId ?? ''),
    title: stripEm(it?.postTitle),
    userName: stripEm(it?.userName),
    imgCount: Number(it?.imgCount) || 0,
    likeCount: Number(it?.likeCount) || 0,
    postType: Number(it?.postType) || 0,
    cover
  };
}

/** 一次跑多个搜索词并合并去重：绘画类的帖用「图」搜不出来，得靠手绘/插画/同人一起搜。 */
async function searchCommunityMany(queries, c) {
  const pageSize = clamp(Number(c.cosPageSize) || 20, 5, 20);
  const settled = await Promise.allSettled(queries.map((q) => apiPost('/forum/search/v2/post', {
    keyword: q, gameId: GAME_ID, pageNo: 1, pageSize
  }, c)));
  const map = new Map();
  for (const r of settled) {
    if (r.status !== 'fulfilled') continue;
    for (const raw of (Array.isArray(r.value?.postList) ? r.value.postList : [])) {
      const it = normalizeSearchItem(raw);
      if (it.postId && !map.has(it.postId)) map.set(it.postId, it);
    }
  }
  return [...map.values()];
}

/** 图片候选排序：标题像 cos/绘画 > 图多 > 标题短（画作帖标题一般很短）；攻略/周边类压下去。 */
function rankImages(list, kw, kind) {
  const keyword = String(kw || '').toLowerCase();
  return list
    .map((it) => {
      let score = 0;
      const title = it.title;
      if (kind === 'cos' && COS_POST_HINTS.test(title)) score += 8;
      if (kind === 'art' && ART_POST_HINTS.test(title)) score += 8;
      if (OFFTOPIC_HINTS.test(title)) score -= 7;
      if (FICTION_HINTS.test(title)) score -= 9;
      if (/手绘|绘画|插画|摸鱼|线稿|临摹/.test(title)) score += 3;
      if (it.imgCount >= 1) score += 3;
      if (it.imgCount >= 3) score += 2;
      if (it.imgCount === 1) score -= 1;
      if (it.cover) score += 1;
      if (title.replace(/\s+/g, '').length <= 18) score += 2;
      if (keyword && title.toLowerCase().includes(keyword)) score += 2;
      score += Math.min(3, it.likeCount / 100);
      return { ...it, score };
    })
    .sort((a, b) => b.score - a.score)
    .filter((it) => it.imgCount > 0 || it.cover);
}

/** 攻略候选排序：标题像攻略 > 一图流 > 有图 > 点赞；cos/绘画帖和视频帖压下去。 */
function rankGuides(list, kw) {
  const keyword = String(kw || '').toLowerCase();
  return list
    .map((it) => {
      let score = 0;
      const title = it.title;
      if (GUIDE_POST_HINTS.test(title)) score += 8;
      if (/一图流|图解/.test(title)) score += 4;
      if (COS_POST_HINTS.test(title) || ART_POST_HINTS.test(title)) score -= 8;
      if (it.postType === 2) score -= 3;                       // 视频帖没有正文可摘
      if (it.imgCount >= 1) score += 2;
      if (it.imgCount >= 5) score += 2;
      if (keyword && title.toLowerCase().includes(keyword)) score += 2;
      score += Math.min(4, it.likeCount / 80);
      return { ...it, score };
    })
    .sort((a, b) => b.score - a.score);
}

/** 从帖子详情里收图：正文图片块 + 封面兜底。 */
function collectImages(post) {
  const urls = [];
  const blocks = Array.isArray(post?.postContent) ? post.postContent : [];
  for (const b of blocks) {
    if (Number(b?.contentType) !== 2) continue;
    const u = String(b?.url || '').trim();
    if (/^https?:\/\//i.test(u) && !urls.includes(u)) urls.push(u);
  }
  if (!urls.length && Array.isArray(post?.coverImages)) {
    for (const c of post.coverImages) {
      const u = String(c?.url || c?.sourceUrl || '').trim();
      if (/^https?:\/\//i.test(u) && !urls.includes(u)) urls.push(u);
    }
  }
  return urls;
}

/** 发图：走 sender（带限频/去重/留档），没有 sender 就退回协议端原始段。 */
async function sendImage(ctx, url, note) {
  if (ctx?.sender?.sendImage) {
    await ctx.sender.sendImage(ctx.chatKey, { url }, { note: String(note || '').slice(0, 30) });
    return;
  }
  const [kind, id] = String(ctx?.chatKey || '').split(':');
  await ctx.onebot.sendSegments(kind === 'private' ? 'private' : 'group', id, [{ type: 'image', data: { file: url } }]);
}

// ── 接口层 ────────────────────────────────────────────────────────────────

async function apiPost(pathname, body, c = {}) {
  const base = String(c.apiBase || DEFAULT_API_BASE).replace(/\/+$/, '');
  const timeoutMs = clamp(Number(c.timeoutMs) || 12000, 3000, 60000);
  const version = String(c.webVersion || DEFAULT_WEB_VERSION).trim() || DEFAULT_WEB_VERSION;

  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const resp = await httpFetch(`${base}${pathname}`, {
      method: 'POST',
      headers: {
        source: 'h5',
        version,
        devCode: DEVICE_ID,
        distinct_id: DISTINCT_ID,
        'Content-Type': 'application/x-www-form-urlencoded;charset=utf-8',
        Accept: 'application/json, text/plain, */*',
        Origin: 'https://www.kurobbs.com',
        Referer: 'https://www.kurobbs.com/',
        'User-Agent': USER_AGENT
      },
      body: new URLSearchParams(body).toString(),
      signal: controller.signal
    });
    if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
    const text = await resp.text();
    let json = null;
    try { json = JSON.parse(text); } catch { throw new Error(`返回不是 JSON：${text.slice(0, 100)}`); }
    if (Number(json?.code) !== 200) throw new Error(json?.msg || `code=${json?.code}`);
    return json?.data ?? null;
  } catch (error) {
    if (error?.name === 'AbortError') throw new Error(`请求超时（${timeoutMs}ms）`);
    throw error;
  } finally {
    clearTimeout(timer);
  }
}

// ── 检索 ──────────────────────────────────────────────────────────────────

/**
 * 检索顺序刻意是 **公告 → 资讯 → 活动**，哪类先命中就停：
 * 卡池/维护/更新时间都在公告里，资讯常有角色名但没时间，活动噪音最多。
 */
async function searchPosts(keyword, c, { maxHits = 2, bodyLimit: bodyLimitOverride = null } = {}) {
  const variants = keywordVariants(keyword);
  const bodyLimit = clamp(Number(bodyLimitOverride) || Number(c.searchBodyLimit) || 8, 1, 15);
  const cacheKey = `${variants.join(',')}|${maxHits}|${bodyLimit}`;
  const ttl = clamp(Number(c.searchCacheMin) || 5, 0, 60) * 60000;
  const cached = searchCache.get(cacheKey);
  if (cached && Date.now() - cached.at < ttl) return cached.value;

  const perType = clamp(Number(c.listPerType) || 20, 5, 20);

  for (const type of ['公告', '资讯', '活动']) {
    const data = await apiPost('/forum/companyEvent/findEventList', {
      eventType: TYPES[type], gameId: GAME_ID, pageNo: 1, pageSize: perType
    }, c);
    const items = toItems(data?.list, type);

    // ① 标题命中：再抓一次正文补时间（用户问的就是时间，标题给不了）
    const titleHits = items.filter((it) => matchesAny(it.title, variants)).slice(0, maxHits);
    if (titleHits.length) {
      const settled = await Promise.allSettled(titleHits.map((it) => fetchHit(it, c)));
      const hits = settled.map((r, i) => (r.status === 'fulfilled' && r.value)
        ? r.value
        : { ...titleHits[i], timeLines: [], snippet: '' });
      const value = { type, hits };
      searchCache.set(cacheKey, { at: Date.now(), value });
      return value;
    }

    // ② 正文深搜：按发布时间倒序，分批并发
    const hits = [];
    for (let i = 0; i < items.length && i < bodyLimit && hits.length < maxHits; i += 4) {
      const batch = items.slice(i, Math.min(i + 4, bodyLimit));
      const settled = await Promise.allSettled(batch.map((item) => fetchHit(item, c, variants)));
      for (const r of settled) {
        if (r.status === 'fulfilled' && r.value) hits.push(r.value);
        if (hits.length >= maxHits) break;
      }
    }
    if (hits.length) {
      const value = { type, hits };
      searchCache.set(cacheKey, { at: Date.now(), value });
      return value;
    }
  }

  searchCache.set(cacheKey, { at: Date.now(), value: null });
  return null;
}

/** 抓一条帖子并整理成命中结果；requireMatch 时正文没命中就返回 null。 */
async function fetchHit(item, c, requireMatch = null) {
  try {
    const detail = await apiPost('/forum/getPostDetail', { postId: item.postId }, c);
    const post = detail?.postDetail;
    if (!post) return null;
    const text = extractText(post.postContent);
    if (requireMatch && (!text || !matchesAny(text, requireMatch))) return null;
    return {
      ...item,
      title: cleanTitle(post.postTitle) || item.title,
      time: Number(post.createTimestamp) || item.time,
      timeLines: extractTimeLines(text),
      snippet: requireMatch ? snippetAround(text, requireMatch) : ''
    };
  } catch {
    return null;
  }
}

async function findByKeyword(kw, c) {
  for (const type of ['公告', '活动', '资讯']) {
    try {
      const data = await apiPost('/forum/companyEvent/findEventList', {
        eventType: TYPES[type], gameId: GAME_ID, pageNo: 1, pageSize: 20
      }, c);
      const hit = toItems(data?.list, type).find((it) => it.title.toLowerCase().includes(kw));
      if (hit) return hit;
    } catch { /* 试下一类 */ }
  }
  return null;
}

// ── 关键词处理 ────────────────────────────────────────────────────────────

/** 形近字变体：官方写作「锁暝」，用户常打「锁冥」；不打变体就会「明明有却说没有」。 */
function keywordVariants(keyword) {
  const base = String(keyword ?? '').trim();
  if (!base) return [];
  const out = new Set([base.toLowerCase()]);
  const stripped = base.replace(/[「」『』【】\[\]"'《》]/g, '').trim();
  if (stripped && stripped !== base) out.add(stripped.toLowerCase());
  const pairs = [['冥', '暝'], ['暝', '冥'], ['陨', '殒'], ['渊', '源'], ['璃', '离']];
  for (const [a, b] of pairs) {
    if (base.includes(a)) out.add(base.split(a).join(b).toLowerCase());
  }
  return [...out].filter(Boolean);
}

const QUESTION_ACTIONS = [
  '什么时候', '啥时候', '什么时间', '多长时间', '哪天', '几号', '几点', '多久',
  '上线', '上架', '下线', '下架', '开启', '开池', '关闭', '结束', '截止', '开始', '维护', '更新'
];
// 噪词：问句里常见但不是实体。长的排前面，别让「池」先把「武器池」切碎
const QUERY_NOISE = [
  '武器池', '角色池', '限定池', '卡池', 'UP池', 'up池', '池子', '池',
  '鸣潮', '库街区', '库里街区', '战双',
  '下一个', '下个', '上一个', '上个', '这个', '这期', '本期', '下期', '现在', '最近', '今天',
  '概率', '活动', '公告', '版本', '情报', '资讯', '官方'
];
// 只去多字套话，绝不去单字（的/在/会/出/开在角色名、武器名里太常见）
const QUESTION_FILLER_RE = /请问|问一下|帮我|麻烦|查一下|查一查|查查|搜一下|搜搜|看一下|想知道|有没有|是不是|了吗|么|吗|呢|啊|呀/g;

/** 把一句人话拆成候选检索词，短的排前面（实体名通常 2~6 字）。 */
function keywordCandidates(raw) {
  const base = String(raw ?? '')
    .trim()
    .replace(/[「」『』【】\[\]"'《》]/g, '')
    .replace(/[？?！!。,，、；;：:\s]+$/g, '');
  if (!base) return [];

  const out = [];
  const seen = new Set();
  const push = (value) => {
    const text = String(value ?? '').replace(QUESTION_FILLER_RE, '').replace(/\s+/g, '').trim();
    if (text.length < 2 || text.length > 20 || seen.has(text)) return;
    seen.add(text);
    out.push(text);
  };
  const stripWords = (text, words) => words.reduce((acc, w) => acc.split(w).join(' '), text);

  const noAction = stripWords(base, QUESTION_ACTIONS);
  const entity = stripWords(noAction, QUERY_NOISE).replace(/\s+/g, '');
  const firstQ = QUESTION_ACTIONS.map((w) => base.indexOf(w)).filter((i) => i > 0).sort((a, b) => a - b)[0];

  push(entity);                                 // ① 锁冥
  if (firstQ) push(base.slice(0, firstQ));       // ② 锁冥卡池
  push(noAction.replace(/\s+/g, ''));            // ③ 锁冥卡池
  for (const w of ['维护', '更新', '上线', '开启', '结束', '下架']) {
    if (base.includes(w)) push(w);              // ④ 更新
  }
  push(base);                                    // ⑤ 原句

  return out.slice(0, 4);
}

function matchesAny(text, variants) {
  const lower = String(text ?? '').toLowerCase();
  return variants.some((v) => lower.includes(v));
}

// ── 文本处理 ──────────────────────────────────────────────────────────────

const DATE_RE = /\d{4}\s*年\s*\d{1,2}\s*月\s*\d{1,2}\s*日|\d{1,2}\s*月\s*\d{1,2}\s*日|\d{4}-\d{2}-\d{2}|\d{1,2}\/\d{1,2}/;

/** 摘时间行：官方格式固定。先按「有没有区间 / 有没有『时间：』」打分，再把最像时间说明的
 *  两行挑出来 —— 纯按文档顺序取，容易先撞上正文里顺嘴提到的一句日期。 */
function extractTimeLines(text) {
  const rows = String(text ?? '').split('\n').map((s) => s.trim()).filter(Boolean);
  const cands = [];
  for (let i = 0; i < rows.length; i += 1) {
    const row = rows[i];
    if (!DATE_RE.test(row)) continue;
    const range = /[~～\-–—至]/.test(row);
    const word = /时间|上线|开启|开始|结束|下架|截止|维护|更新|开放|持续|有效期|领取/.test(row);
    if (!range && !word) continue;
    const prev = rows[i - 1] || '';
    const label = (/^[✦※◆●\s]*\S{0,12}(时间|开启|结束|维护|上线)[✦※◆●\s]*$/.test(prev) && prev.length <= 20)
      ? prev.replace(/[✦※◆●]/g, '').trim()
      : '';
    let score = 0;
    if (range) score += 2;
    if (/时间\s*[:：]/.test(row) || label) score += 2;
    else if (word) score += 1;
    cands.push({ line: compactTime(label ? `${label}：${row}` : row), score, i });
  }
  return cands
    .filter((x) => x.line)
    .sort((a, b) => b.score - a.score || a.i - b.i)
    .slice(0, 2)                       // 两行足够回答「什么时候开/关」，再多纯烧 token
    .map((x) => x.line);
}

/** 时间写法压短：2026年10月22日10:00 ~ 2026年11月11日11:59（服务器时间）→ 2026-10-22 10:00 ~ 11-11 11:59 */
function compactTime(line) {
  return String(line)
    .replace(/(\d{4})\s*年\s*(\d{1,2})\s*月\s*(\d{1,2})\s*日/g,
      (m, y, mo, d) => `${y}-${String(mo).padStart(2, '0')}-${String(d).padStart(2, '0')} `)
    // 日期后面紧跟时间时补一个空格：2026-10-2210:00 → 2026-10-22 10:00
    .replace(/(\d{4}-\d{2}-\d{2})\s*(\d{1,2}:\d{2})/g, '$1 $2')
    .replace(/[（(](服务器时间|UTC\+8|UTC\+08:00|北京时间)[）)]/g, '')
    .replace(/[✦※◆●]/g, '')
    .replace(/\s*~\s*/g, ' ~ ')
    .replace(/\s+/g, ' ')
    .trim()
    .slice(0, 90);
}

/** 关键词前后各截一点，别把几千字公告塞给模型。 */
function snippetAround(text, variants) {
  const flat = String(text ?? '').replace(/[✦※◆●]/g, '').replace(/\s+/g, ' ');
  const lower = flat.toLowerCase();
  for (const v of variants) {
    const idx = lower.indexOf(v);
    if (idx < 0) continue;
    const start = Math.max(0, idx - 28);
    const end = Math.min(flat.length, idx + v.length + 42);
    return `…${flat.slice(start, end).trim()}…`.slice(0, 90);
  }
  return '';
}

/** 帖子正文是块数组：contentType=1 文字、2 图片。 */
function extractText(blocks) {
  if (!Array.isArray(blocks)) return '';
  const parts = [];
  for (const block of blocks) {
    if (!block || typeof block !== 'object' || Number(block.contentType) === 2) continue;
    const text = blockText(block);
    if (text) parts.push(text);
  }
  return parts.join('\n').replace(/\n{3,}/g, '\n\n').trim();
}

function blockText(block) {
  const direct = cleanText(block.content);
  if (direct) return direct;
  if (Array.isArray(block.children)) {
    return block.children.map((ch) => cleanText(ch?.content)).filter(Boolean).join('');
  }
  return '';
}

function cleanText(value) {
  return String(value ?? '')
    .replace(/<br\s*\/?>/gi, '\n')
    .replace(/<[^>]+>/g, '')
    .replace(/&nbsp;/g, ' ')
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/\u200b/g, '')
    .replace(/[ \t]+/g, ' ')
    .trim();
}

function cleanTitle(value) {
  return cleanText(value).replace(/\s+/g, ' ').slice(0, 120);
}

// ── 其它 ──────────────────────────────────────────────────────────────────

function toItems(list, type) {
  return (Array.isArray(list) ? list : [])
    .map((it) => ({
      postId: String(it?.postId ?? ''),
      title: cleanTitle(it?.postTitle),
      time: Number(it?.publishTime ?? it?.shelveTime ?? 0),
      type
    }))
    .filter((it) => it.postId);
}

/** 列表里的日期标记：同年只给 MM-DD，省 token 也更好读。 */
function stamp(ms, c) {
  const ts = Number(ms);
  if (!Number.isFinite(ts) || ts <= 0) return '';
  const tz = String(c?.timeZone || 'Asia/Shanghai');
  try {
    const parts = new Intl.DateTimeFormat('en-CA', {
      timeZone: tz, year: 'numeric', month: '2-digit', day: '2-digit'
    }).formatToParts(new Date(ts));
    const get = (t) => parts.find((p) => p.type === t)?.value ?? '';
    const year = get('year');
    const now = new Intl.DateTimeFormat('en-CA', { timeZone: tz, year: 'numeric' }).format(new Date());
    return year === now ? `〔${get('month')}-${get('day')}〕` : `〔${year}-${get('month')}-${get('day')}〕`;
  } catch {
    return '';
  }
}

function normalizeType(value) {
  const raw = String(value ?? '').trim();
  if (!raw) return '公告';
  if (TYPES[raw]) return raw;
  const lower = raw.toLowerCase();
  for (const alias of TYPE_ALIASES) {
    if (alias.words.some((w) => lower.includes(w))) return alias.type;
  }
  return '公告';
}

function clamp(n, lo, hi) {
  const value = Math.round(Number(n) || lo);
  return Math.min(hi, Math.max(lo, value));
}

function randomHex(len) {
  let out = '';
  for (let i = 0; i < len; i += 1) out += '0123456789abcdef'[Math.floor(Math.random() * 16)];
  return out;
}
