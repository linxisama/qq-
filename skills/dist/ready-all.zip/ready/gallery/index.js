// 相册（gallery）—— 她自己的图库：她自己决定往里放什么，并写一句为什么。
//
// 为什么不复用表情包库：
//   表情包是「发出去用的素材」，主人收藏、按关键词检索，是公共财产。
//   相册是「她留下的东西」—— 一张她觉得有意思的图 + 一句她自己的理由。
//   混进表情库，她就只是往公共仓库里丢图，不是"她挑的"。
//
// 三条设计：
// 1) **只加不删**（和日记同一条红线）：给她删除就等于给她改历史的权力。
// 2) **必须写一句为什么**：不写理由的收藏没有意义，理由才是她的判断。
// 3) **只能放图/动图**：不碰视频、不碰可执行文件，避免把相册变成下载目录。

import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { DATA_DIR } from '../../src/config.js';

const SKILL_ID = 'gallery';
const MAX_BYTES = 8 * 1024 * 1024;
const IMAGE_EXT = new Set(['.jpg', '.jpeg', '.png', '.gif', '.webp', '.bmp']);

let cfgOf = () => ({});
let log = () => {};

function resolveDir(cfg) {
  const raw = String(cfg?.dir || '').trim();
  if (!raw) return path.join(DATA_DIR, 'gallery');
  if (path.isAbsolute(raw)) return raw;
  return path.join(DATA_DIR, raw.replace(/^data[\\/]/i, ''));
}

function indexPath(cfg) {
  return path.join(resolveDir(cfg), 'index.jsonl');
}

function readIndex(cfg) {
  const file = indexPath(cfg);
  if (!fs.existsSync(file)) return [];
  const out = [];
  for (const line of fs.readFileSync(file, 'utf8').split(/\r?\n/)) {
    const s = line.trim();
    if (!s) continue;
    try {
      const o = JSON.parse(s);
      if (o && o.file) out.push(o);
    } catch { /* 坏行跳过 */ }
  }
  return out;
}

function appendIndex(cfg, entry) {
  const file = indexPath(cfg);
  fs.mkdirSync(path.dirname(file), { recursive: true });
  fs.appendFileSync(file, `${JSON.stringify(entry)}\n`, 'utf8');
}

function nowStr(d = new Date()) {
  const p = (n) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())} ${p(d.getHours())}:${p(d.getMinutes())}`;
}

function stamp(d = new Date()) {
  const p = (n) => String(n).padStart(2, '0');
  return `${d.getFullYear()}${p(d.getMonth() + 1)}${p(d.getDate())}-${p(d.getHours())}${p(d.getMinutes())}${p(d.getSeconds())}`;
}

function extOf(name, mime) {
  const e = path.extname(String(name || '')).toLowerCase();
  if (IMAGE_EXT.has(e)) return e;
  const m = String(mime || '').toLowerCase();
  if (m.includes('gif')) return '.gif';
  if (m.includes('png')) return '.png';
  if (m.includes('webp')) return '.webp';
  if (m.includes('bmp')) return '.bmp';
  return '.jpg';
}

function toFileUri(p) {
  const body = String(p || '').replace(/\\/g, '/').split('/').filter(Boolean).join('/');
  return 'file:///' + encodeURI(body).replace(/[?#]/g, (c) => '%' + c.charCodeAt(0).toString(16).toUpperCase());
}

function sha256(buf) {
  return crypto.createHash('sha256').update(buf).digest('hex');
}

/** 从 URL 或本地路径拿到图片字节。 */
async function loadBytes(cfg, args) {
  const url = String(args?.url || '').trim();
  const p = String(args?.path || '').trim();
  if (!url && !p) throw new Error('要么给图片链接（url），要么给本地路径（path）');
  if (url) {
    if (!/^https?:\/\//i.test(url)) throw new Error('链接要是 http/https 开头');
    const r = await fetch(url, {
      headers: { 'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36' },
      signal: AbortSignal.timeout(20000)
    });
    if (!r.ok) throw new Error(`下载失败（HTTP ${r.status}）`);
    const buf = Buffer.from(await r.arrayBuffer());
    if (buf.length > MAX_BYTES) throw new Error(`图太大了（${(buf.length / 1024 / 1024).toFixed(1)}MB，上限 8MB）`);
    return { buf, ext: extOf(new URL(url).pathname, r.headers.get('content-type')), source: url };
  }
  const abs = path.resolve(p);
  const st = fs.statSync(abs);
  if (!st.isFile()) throw new Error('给的不是一个文件');
  if (st.size > MAX_BYTES) throw new Error(`图太大了（${(st.size / 1024 / 1024).toFixed(1)}MB，上限 8MB）`);
  return { buf: fs.readFileSync(abs), ext: extOf(abs, ''), source: abs };
}

export function setup(api) {
  cfgOf = () => api.config() || {};
  log = (...a) => { try { api.log(...a); } catch { /* 忽略 */ } };

  // ── 往相册里放一张 ──────────────────────────────────────────────────
  api.registerTool({
    id: 'put',
    name: '放一张图进相册',
    description: '往你自己的相册里放一张图，并写一句为什么留着它。放什么、为什么，都是你自己的判断 —— '
      + '不用挑「好看的」，挑你觉得有意思的。note 写具体（比如「她头像这个蓝我记一下」），'
      + '不要写「一张好看的图」。放进去不用马上告诉别人。',
    category: 'media',
    icon: '🖼️',
    parameters: {
      type: 'object',
      properties: {
        url: { type: 'string', description: '图片链接（http/https）。和 path 二选一。' },
        path: { type: 'string', description: '本机图片路径。和 url 二选一。' },
        note: { type: 'string', description: '为什么留着它，一句话，具体一点。' }
      },
      required: ['note']
    },
    async execute(_ctx, args) {
      const cfg = cfgOf();
      if (cfg.enabled === false) return { content: '相册关着。', isError: true };
      const note = String(args?.note ?? '').replace(/\s+/g, ' ').trim().slice(0, 60);
      if (!note) return { content: '得写一句为什么留着它，不然这张不算你的。', isError: true };
      try {
        const { buf, ext, source } = await loadBytes(cfg, args);
        const hash = sha256(buf).slice(0, 12);
        const list = readIndex(cfg);
        const dup = list.find((x) => x.hash === hash);
        if (dup) return { content: `这张早就在相册里了（${dup.时间} 放的，当时写的是「${dup.note}」）。`, isError: false };
        const maxFiles = Math.max(10, Number(cfg.maxFiles) || 500);
        if (list.length >= maxFiles) {
          return { content: `相册满 ${maxFiles} 张了，先别再往里放（我不删东西，你去 data\\gallery 里自己清）。`, isError: true };
        }
        const dir = resolveDir(cfg);
        fs.mkdirSync(dir, { recursive: true });
        const name = `${stamp()}-${hash}${ext}`;
        fs.writeFileSync(path.join(dir, name), buf);
        const entry = { 时间: nowStr(), file: name, note, source: String(source).slice(0, 200), hash, bytes: buf.length };
        appendIndex(cfg, entry);
        log(`[${SKILL_ID}] 收了一张 ${name}（${Math.round(buf.length / 1024)}KB）`);
        return { content: `放进相册了：${name}（${Math.round(buf.length / 1024)}KB）。理由记下了：「${note}」。不用在聊天里提。` };
      } catch (e) {
        const msg = String(e?.message ?? e).slice(0, 160);
        log(`[${SKILL_ID}] 放图失败：${msg}`);
        return { content: `这张没放进去：${msg}`, isError: true };
      }
    }
  });

  // ── 翻相册 ────────────────────────────────────────────────────────────
  api.registerTool({
    id: 'list',
    name: '翻相册',
    description: '翻自己的相册：默认最近几张，按理由里的词也能搜。看看自己以前挑过什么、当时在想什么。',
    category: 'media',
    icon: '📚',
    parameters: {
      type: 'object',
      properties: {
        count: { type: 'number', description: '翻几张，默认 8 张。' },
        keyword: { type: 'string', description: '可选，按理由里的词搜。' }
      }
    },
    async execute(_ctx, args) {
      const cfg = cfgOf();
      if (cfg.enabled === false) return { content: '相册关着。', isError: true };
      let list = readIndex(cfg);
      if (!list.length) return { content: '相册还是空的。遇到觉得有意思的图再放。' };
      const kw = String(args?.keyword ?? '').trim();
      if (kw) list = list.filter((x) => String(x.note || '').includes(kw));
      if (!list.length) return { content: `没翻到理由里带「${kw}」的图。` };
      const want = Math.min(30, Math.max(1, Number(args?.count) || 8));
      const picked = list.slice(-want);
      return {
        content: `${kw ? `理由里带「${kw}」的 ${picked.length} 张` : `最近 ${picked.length} 张`}：\n`
          + picked.map((x, i) => `${i + 1}. ${x.时间}　${x.note}`).join('\n')
      };
    }
  });

  // ── 把相册里的图发出来 ────────────────────────────────────────────────
  api.registerTool({
    id: 'send',
    name: '发相册里的图',
    description: '从自己的相册里挑一张发到当前聊天（发之前先翻相册确认是哪张）。发的时候可以顺手说一句当时的理由。',
    category: 'media',
    icon: '📤',
    parameters: {
      type: 'object',
      properties: {
        index: { type: 'number', description: '翻相册列表里的序号（1 开始，最近的在最后）' },
        keyword: { type: 'string', description: '可选，按理由里的词挑（挑最近一张命中的）' }
      }
    },
    async execute(ctx, args) {
      const cfg = cfgOf();
      if (cfg.enabled === false) return { content: '相册关着。', isError: true };
      const all = readIndex(cfg);
      if (!all.length) return { content: '相册是空的，没东西可发。', isError: true };
      let target = null;
      const kw = String(args?.keyword ?? '').trim();
      if (kw) {
        const hit = [...all].reverse().find((x) => String(x.note || '').includes(kw));
        if (!hit) return { content: `相册里没有理由带「${kw}」的图。`, isError: true };
        target = hit;
      } else {
        const n = Math.max(1, Math.round(Number(args?.index) || all.length));
        const recent = all.slice(-30);
        target = recent[Math.min(recent.length, n) - 1];
        if (!target) return { content: '序号超出范围了，先翻一下相册看看有哪些。', isError: true };
      }
      const abs = path.join(resolveDir(cfg), target.file);
      if (!fs.existsSync(abs)) return { content: `相册里记着 ${target.file}，但文件不在了（可能被手动删了）。`, isError: true };
      if (!ctx?.sender?.sendMedia || !ctx?.chatKey) return { content: '这个场景发不了图（当前没有可用的发图通道）。', isError: true };
      try {
        await ctx.sender.sendMedia(ctx.chatKey, [{ type: 'image', data: { file: toFileUri(abs) } }], {
          label: '[相册]', dedupeKey: `gallery:${target.hash}:${Date.now()}`
        });
        log(`[${SKILL_ID}] 发出相册图 ${target.file}`);
        return { content: `发出去了（${target.时间} 收的，理由：「${target.note}」）。` };
      } catch (e) {
        return { content: `发失败了：${String(e?.message ?? e).slice(0, 160)}`, isError: true };
      }
    }
  });

  log(`[${SKILL_ID}] 相册就绪（${resolveDir(cfgOf())}，工具：gallery__put / gallery__list / gallery__send）`);
}

export function available() {
  return true;
}

export function dispose() {
  cfgOf = () => ({});
  log = () => {};
}
