// 关键词表情包（LLM 型技能）—— 教学存图 + 触发词字面匹配发图。
//
// ── v1.1.1 改动 ─────────────────────────────────────────────────────────
//   · 修复"群聊不触发"：模型曾误以为"触发词是按群存的"（群里有触发词也不发图）。
//     现在提示词常驻规则 + 每轮触发提醒都明示：表情库是**全局共用一份**，
//     所有群聊/私聊同一套触发词，命中就必须调 meme_send 发图（先发图再回话）。
//   · 触发提醒改为强制指令口吻（严禁只用文字回应而跳过发图），并在钩子命中时记日志。
//   · 加强 meme_send 工具描述：命中触发词是硬性规则，必须调用。
//
// ── v1.1.0 改动 ─────────────────────────────────────────────────────────
//   · 触发规则从"语义相近"改为**触发词字面匹配**：每个表情存 1~5 个触发词
//     （含关键词本身，如"吃大白饭"→ ["吃大白饭", "白饭"]），
//     聊天消息里只要出现任一触发词就发图（"出现白饭或吃大白饭都会触发"）。
//   · 新增 before-llm-messages 钩子：聊天消息命中触发词时在 user 提示词末尾
//     追加一行"立即调 meme_send"的提醒（钩子只改文本、不联网不发图，
//     符合 hooks 约定；真正发图仍走会话内的工具），解决"模型没判断出来、没触发"。
//   · 新增 downloadDir 设置：照片作为独立文件保存到本地（默认
//     data/keyword-meme/images，可填绝对路径改到任意文件夹）。
//
// ── 为什么是 Skill（LLM 型）而不是插件 ──────────────────────────────────
//   教学意图识别和"把消息路由到对应表情"仍需要模型参与；只有 registerTool
//   能把工具挂进模型的 function 列表。插件是固定规则、不经模型，且 hooks
//   拿不到 sender（框架约定 hooks 禁网禁发），发图只能走会话内工具。
//
// ── 安全边界 ─────────────────────────────────────────────────────────────
//   · 数据落盘在 DATA_DIR（data/keyword-meme/），**绝不在技能目录里写文件**：
//     本框架对 skills/ 递归 fs.watch 热重载，自己写自己目录 = 自激回路。
//   · 下载图走 api.fetch（manifest 声明 permissions:["web_fetch"] 才拿得到）。
//     只收 http(s) 直链 + 体积上限 + 魔数校验（png/jpg/gif/webp），HTML 拒绝。
//   · 下载 URL 来自群消息图片段（腾讯图片 CDN），只下载消息媒体里出现的图片。
//   · 发送走工具执行时的 ctx.sender.sendImage：本地文件路径优先，base64 兜底。
//   · 冷却只放内存（热重载清零可接受）；available() 保持同步链。

import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const MODULE_DIR = path.dirname(fileURLToPath(import.meta.url));
const APP_ROOT = path.resolve(MODULE_DIR, '..', '..');              // resources/app
const DATA_ROOT = process.env.QQ_AGENT_DATA_DIR || path.join(APP_ROOT, 'data');
const LIB_DIR = path.join(DATA_ROOT, 'keyword-meme');
const DEFAULT_IMAGES_DIR = path.join(LIB_DIR, 'images');
const LIB_FILE = path.join(LIB_DIR, 'library.json');

const DOWNLOAD_TIMEOUT_MS = 15000;
const KEYWORD_MAX = 32;
const TRIGGER_WORDS_MAX = 8;
// 核心 user prompt 里的分段标记（prompt.js 渲染「【未读信息】」），触发提醒只看这一段
const UNREAD_MARKER = '【未读信息】';
const CORE_SECTION_RE = /\n【(?:记忆|已读信息|新已读信息|未读信息|新加入成员|当前时间|角色设定|表情包|引导说明)/;

let cfg = () => ({});
let log = () => {};
let warn = () => {};
let fetchFn = () => Promise.reject(new Error('本技能没有 fetch 权限（manifest 缺 permissions）'));

/** 发送冷却：chatKey -> 上次发图时间戳（仅内存，热重载清零可接受）。 */
const lastSentAt = new Map();

// ── 存储路径 ───────────────────────────────────────────────────────────────

/** 教学照片保存目录：配置了 downloadDir 用绝对路径，否则用默认目录。 */
function resolveImagesDir() {
  const configured = String(cfg().downloadDir || '').trim();
  return configured ? path.resolve(configured) : DEFAULT_IMAGES_DIR;
}

/** 库里存的 file 可能是相对 LIB_DIR（默认目录）或绝对路径（自定义目录）。 */
function resolveEntryPath(file) {
  return path.isAbsolute(String(file ?? '')) ? String(file) : path.join(LIB_DIR, String(file ?? ''));
}

// ── 表情库读写 ─────────────────────────────────────────────────────────────

function loadLibrary() {
  try {
    if (!fs.existsSync(LIB_FILE)) return { version: 1, entries: {} };
    const parsed = JSON.parse(fs.readFileSync(LIB_FILE, 'utf8'));
    if (parsed && typeof parsed === 'object' && parsed.entries && typeof parsed.entries === 'object') {
      return parsed;
    }
    return { version: 1, entries: {} };
  } catch (e) {
    warn(`表情库读取失败（按空库处理）：${e?.message ?? e}`);
    return { version: 1, entries: {} };
  }
}

/** 原子写库：先写临时文件再 rename，避免半截文件。 */
function saveLibrary(lib) {
  fs.mkdirSync(LIB_DIR, { recursive: true });
  const tmp = `${LIB_FILE}.${process.pid}.tmp`;
  fs.writeFileSync(tmp, JSON.stringify(lib, null, 2), 'utf8');
  fs.renameSync(tmp, LIB_FILE);
}

function sanitizeKeyword(raw) {
  return String(raw ?? '').replace(/\s+/g, '').slice(0, KEYWORD_MAX).trim();
}

/** 关键词转安全文件名（保留中文/字母/数字/连字符，其余替换为 _）。 */
function safeFileNamePart(keyword) {
  return String(keyword ?? '').replace(/[\\/:*?"<>|\s]+/g, '_').slice(0, 40) || 'meme';
}

/**
 * 归一化触发词：以教学者/模型给的为准；没给时兜底 [关键词] + 关键词末两字
 * （"吃大白饭"→["吃大白饭","白饭"]）。关键词永远排在第一个。
 */
function normalizeTriggerWords(keyword, provided) {
  const kw = sanitizeKeyword(keyword);
  const out = [];
  if (Array.isArray(provided)) {
    for (const s of provided) {
      const w = sanitizeKeyword(s);
      if (w && !out.includes(w)) out.push(w);
    }
  }
  if (kw && !out.includes(kw)) out.unshift(kw);
  // 兜底简写：没提供任何触发词时补关键词末两字（吃大白饭 → 白饭）
  if (out.length === 1 && kw.length >= 3) {
    const tail = kw.slice(-2);
    if (tail !== kw && !out.includes(tail)) out.push(tail);
  }
  return out.slice(0, TRIGGER_WORDS_MAX);
}

function detectMime(buf) {
  if (!buf || buf.length < 12) return null;
  if (buf[0] === 0x89 && buf[1] === 0x50 && buf[2] === 0x4e && buf[3] === 0x47) return 'image/png';
  if (buf[0] === 0xff && buf[1] === 0xd8 && buf[2] === 0xff) return 'image/jpeg';
  if (String.fromCharCode(buf[0], buf[1], buf[2], buf[3], buf[4], buf[5]) === 'GIF87a'
    || String.fromCharCode(buf[0], buf[1], buf[2], buf[3], buf[4], buf[5]) === 'GIF89a') return 'image/gif';
  if (buf.toString('ascii', 0, 4) === 'RIFF' && buf.toString('ascii', 8, 12) === 'WEBP') return 'image/webp';
  return null;
}

const MIME_EXT = { 'image/png': 'png', 'image/jpeg': 'jpg', 'image/gif': 'gif', 'image/webp': 'webp' };

/** 从消息存档里找"最近一条带图片的消息"（表情图可能与关键词分两条发）。 */
function pickRecentImage(ctx, keyword, userId) {
  const store = ctx?.store;
  if (!store || typeof store.recent !== 'function') return null;
  let entries;
  try {
    entries = store.recent(ctx.chatKey, { limit: Math.max(1, Number(cfg().scanDepth) || 30), includeSelf: false });
  } catch (e) {
    warn(`读消息存档失败：${e?.message ?? e}`);
    return null;
  }
  if (!Array.isArray(entries) || !entries.length) return null;
  const uid = String(userId ?? '').trim();
  const fallback = [];
  for (let i = entries.length - 1; i >= 0; i--) {
    const m = entries[i];
    if (!m || m.self) continue;
    const media = Array.isArray(m.media) ? m.media : [];
    const img = media.find((x) => x && (x.kind === 'image' || (!x.kind && x.url)) && String(x.url ?? '').startsWith('http'));
    if (!img) continue;
    const item = { url: String(img.url), senderId: String(m.senderId ?? ''), text: String(m.text ?? ''), mid: m.mid ?? null };
    if (uid && item.senderId !== uid) continue;
    if (keyword && item.text.includes(keyword)) return item;
    fallback.push(item);
  }
  return fallback[0] || null;
}

/** 下载图片：只收 http(s)、限体积、魔数验真。 */
async function downloadImage(url, maxBytes) {
  const u = String(url ?? '').trim();
  if (!/^https?:\/\//i.test(u)) throw new Error('图片地址不是 http(s) 直链');
  if (!fetchFn) throw new Error('本技能没有 fetch 权限');
  const res = await fetchFn(u, { signal: AbortSignal.timeout(DOWNLOAD_TIMEOUT_MS) });
  if (!res.ok) throw new Error(`图片下载失败：HTTP ${res.status}`);
  const buffer = Buffer.from(await res.arrayBuffer());
  if (!buffer || !buffer.length) throw new Error('图片内容为空');
  if (buffer.length > maxBytes) {
    throw new Error(`图片 ${(buffer.length / 1048576).toFixed(1)}MB 超过上限 ${(maxBytes / 1048576).toFixed(1)}MB`);
  }
  const mime = detectMime(buffer);
  if (!mime) {
    const head = buffer.subarray(0, 200).toString('utf8').trim().toLowerCase();
    if (head.startsWith('<!doctype html') || head.startsWith('<html')) {
      throw new Error('这个地址返回的是网页（HTML），不是图片');
    }
    throw new Error('返回内容不是 png/jpg/gif/webp 图片');
  }
  return { buffer, ext: MIME_EXT[mime] };
}

/** 字面匹配：文本里出现任一触发词 → 返回命中的表情条目。 */
function findTriggerHit(lib, text) {
  const t = String(text ?? '');
  if (!t) return null;
  const entries = lib?.entries || {};
  for (const [kw, entry] of Object.entries(entries)) {
    const words = Array.isArray(entry.triggerWords) && entry.triggerWords.length ? entry.triggerWords : [kw];
    for (const w of words) {
      if (w && t.includes(w)) return { keyword: kw, entry, word: w };
    }
  }
  return null;
}

function keywordListText(lib) {
  const entries = lib?.entries || {};
  const kws = Object.keys(entries);
  if (!kws.length) return '（表情库还是空的，等群友先教学一个吧）';
  return kws.map((kw) => {
    const words = Array.isArray(entries[kw]?.triggerWords) && entries[kw].triggerWords.length
      ? entries[kw].triggerWords.join('、') : kw;
    return `「${kw}」（触发词：${words}）`;
  }).join('，');
}

// ── 工具实现 ───────────────────────────────────────────────────────────────

/** 教学：保存「关键词↔表情图」，带触发词。 */
async function toolLearn(ctx, args) {
  const keyword = sanitizeKeyword(args?.keyword);
  if (!keyword) {
    return { content: '教学失败：没有可用的关键词。请让教学者把关键词写在表情图下方，或单独发一条文字消息。', isError: true };
  }
  const triggerWords = normalizeTriggerWords(keyword, args?.triggerWords);
  const maxBytes = Math.max(1, Math.min(50, Number(cfg().maxImageMB) || 8)) * 1024 * 1024;
  const hit = pickRecentImage(ctx, keyword, args?.userId);
  if (!hit) {
    return {
      content: '教学失败：在发送者最近的几条消息里没找到配图。请让教学者把表情图和关键词（@机器人）一起发出，再重新教学。',
      isError: true
    };
  }

  let downloaded;
  try {
    downloaded = await downloadImage(hit.url, maxBytes);
  } catch (e) {
    warn(`教学下载失败：${e?.message ?? e}`);
    return { content: `教学失败：${e?.message ?? e}。请让教学者换一张表情图再试。`, isError: true };
  }

  const lib = loadLibrary();
  const old = lib.entries[keyword];
  if (old && old.file) {
    // 同关键词重新教学：替换旧图
    try {
      const oldPath = resolveEntryPath(old.file);
      if (fs.existsSync(oldPath)) fs.unlinkSync(oldPath);
    } catch (e) { /* 旧图清理失败不影响 */ }
  }

  const saveDir = resolveImagesDir();
  fs.mkdirSync(saveDir, { recursive: true });
  const fileName = `${safeFileNamePart(keyword)}-${Date.now()}.${downloaded.ext}`;
  const absPath = path.join(saveDir, fileName);
  fs.writeFileSync(absPath, downloaded.buffer);
  // 默认目录存相对路径（跟库一起好管理）；自定义目录存绝对路径
  const file = saveDir === DEFAULT_IMAGES_DIR
    ? path.relative(LIB_DIR, absPath).replace(/\\/g, '/')
    : absPath;
  lib.entries[keyword] = {
    keyword,
    triggerWords,
    file,
    addedAt: Date.now(),
    addedBy: hit.senderId || ''
  };
  saveLibrary(lib);
  const kb = Math.round(downloaded.buffer.length / 1024);
  log(`已保存表情「${keyword}」（${downloaded.ext}，${kb}KB，触发词：${triggerWords.join('、')}）`);
  return {
    content: `表情库保存成功：关键词「${keyword}」，触发词：${triggerWords.join('、')}（${downloaded.ext}，${kb}KB）。`
      + ` 请在群里自然地说一句「已存好『${keyword}』表情」。`
  };
}

/** 触发：聊天内容命中触发词 → 发出对应表情图。 */
async function toolSend(ctx, args) {
  const text = String(args?.keyword ?? '').trim();
  if (!text) return { content: '缺少关键词。把触发的那条聊天消息原文传进来。', isError: true };

  const lib = loadLibrary();
  const hit = findTriggerHit(lib, text);
  if (!hit) {
    return {
      content: `「${text}」里没有出现任何表情触发词，不满足发图条件。当前表情库：${keywordListText(lib)}`
        + '。不要硬发。',
      isError: true
    };
  }

  const ck = String(ctx.chatKey ?? '');
  const cdSec = Math.max(0, Number(cfg().cooldownSec) || 0);
  if (cdSec > 0) {
    const last = lastSentAt.get(`${ck}:${hit.keyword}`);
    if (last && Date.now() - last < cdSec * 1000) {
      return { content: `「${hit.keyword}」表情刚发过（冷却中），本轮不重复发。` };
    }
  }

  const absPath = resolveEntryPath(hit.entry.file);
  if (!fs.existsSync(absPath)) {
    return { content: `「${hit.keyword}」的图片文件丢失了，建议让教学者重新教学一次。`, isError: true };
  }
  if (!ctx?.sender || typeof ctx.sender.sendImage !== 'function') {
    return { content: '当前环境拿不到发送通道，无法发图。告诉群友表情图存在，让它在聊天里触发一次。', isError: true };
  }

  let b64 = '';
  try {
    b64 = `base64://${fs.readFileSync(absPath).toString('base64')}`;
  } catch (e) {
    return { content: `读取表情图失败：${e?.message ?? e}`, isError: true };
  }

  try {
    await ctx.sender.sendImage(ctx.chatKey, { file: absPath, dataUrl: b64 }, {
      note: `[关键词表情:${hit.keyword}]`,
      replyToMessageId: args?.replyToMessageId ?? null,
      atUserId: args?.atUserId ?? null
    });
  } catch (e) {
    warn(`发送表情「${hit.keyword}」失败：${e?.message ?? e}`);
    return { content: `发送表情失败：${e?.message ?? e}`, isError: true };
  }
  if (cdSec > 0) lastSentAt.set(`${ck}:${hit.keyword}`, Date.now());
  log(`已发出表情「${hit.keyword}」（命中触发词「${hit.word}」）→ ${ck}`);
  return { content: `已发出「${hit.keyword}」表情。可以配一句简短的话（也可以只发图）。` };
}

/** 查询：列出表情库（含触发词）。 */
function toolList() {
  const lib = loadLibrary();
  return { content: `当前表情库：${keywordListText(lib)}` };
}

/** 删除：按关键词移除表情。 */
function toolDelete(ctx, args) {
  const keyword = sanitizeKeyword(args?.keyword);
  if (!keyword) return { content: '删除失败：缺少关键词。', isError: true };
  const lib = loadLibrary();
  const entry = lib.entries[keyword];
  if (!entry) {
    return { content: `表情库里没有「${keyword}」。当前表情库：${keywordListText(lib)}`, isError: true };
  }
  try {
    const p = resolveEntryPath(entry.file);
    if (fs.existsSync(p)) fs.unlinkSync(p);
  } catch (e) { /* 忽略 */ }
  delete lib.entries[keyword];
  saveLibrary(lib);
  log(`已删除表情「${keyword}」`);
  return { content: `已删除「${keyword}」表情。` };
}

// ── 触发提醒钩子（只改文本，不联网不发图，符合 hooks 约定）────────────────

/** 只取 user 提示词的【未读信息】段（到下一个核心段标题为止）。 */
function unreadSegment(messages) {
  const user = (Array.isArray(messages) ? messages : []).find((m) => m && m.role === 'user');
  const content = String(user?.content ?? '');
  const idx = content.indexOf(UNREAD_MARKER);
  if (idx < 0) return '';
  const rest = content.slice(idx);
  const cut = CORE_SECTION_RE.exec(rest.slice(UNREAD_MARKER.length));
  return cut ? rest.slice(0, UNREAD_MARKER.length + cut.index) : rest;
}

/** 未读消息命中触发词时，生成一行"立即调 meme_send"的提醒（强制指令口吻）。 */
function buildTriggerReminder(messages) {
  const seg = unreadSegment(messages);
  if (!seg) return null;
  const hit = findTriggerHit(loadLibrary(), seg);
  if (!hit) return null;
  return `\n【触发提醒·强制指令】本批消息出现了表情触发词「${hit.word}」（对应表情「${hit.keyword}」）。`
    + `表情库是全局共用一份的，所有群聊和私聊都共用同一套触发词，不存在"按群/按会话分开存"。`
    + `规则：命中触发词就必须调用 meme_send 发出该表情——keyword 参数传命中那条消息的原文`
    + `（原样包含 @ 与文字），发完图之后才允许回复文字；除非本轮已经发送过同一个表情，`
    + `否则严禁只用文字回应而跳过发图。仅当这条消息同时带有**新的表情图片**时才是教学，改走 meme_learn 保存。`;
}

export const hooks = {
  'before-llm-messages': (ctx) => {
    const reminder = buildTriggerReminder(ctx?.messages);
    if (!reminder) return;
    const user = (Array.isArray(ctx?.messages) ? ctx.messages : []).find((m) => m && m.role === 'user');
    if (user) {
      user.content = String(user.content ?? '') + reminder;
      try { log(`触发提醒命中：${/「([^」]+)」/.exec(reminder)?.[1] ?? '未知'}`); } catch { /* 日志失败不影响 */ }
    }
  }
};

// ── Skill 生命周期 ─────────────────────────────────────────────────────────

export function setup(api) {
  cfg = api.config;
  log = api.log || (() => {});
  warn = api.warn || (() => {});
  fetchFn = typeof api.fetch === 'function'
    ? api.fetch
    : () => Promise.reject(new Error('本技能没有 fetch 权限（manifest 缺 permissions）'));

  const defs = [
    {
      id: 'meme_learn',
      name: '教学表情',
      description:
        '把一张表情图和一个关键词（含 1~5 个触发词）绑定存进表情库（教学）。'
        + '群友 @机器人 发了一张表情图、图下文字或随后单独一条消息给出关键词时调用。'
        + 'triggerWords 想好常见简写（例：关键词"吃大白饭"→["吃大白饭","白饭"]）。'
        + 'userId 可填教学者的 QQ 号（留空自动找）。',
      category: 'media',
      icon: '📥',
      parameters: {
        type: 'object',
        properties: {
          keyword: { type: 'string', description: '教学者给这个表情定的关键词，例如：吃大白饭、开心、无语' },
          triggerWords: {
            type: 'array',
            items: { type: 'string' },
            description: '触发词列表（1~5 个）：含关键词本身 + 常见简写。例：["吃大白饭","白饭"]'
          },
          userId: { type: 'string', description: '可选：教学者的 QQ 号（消息行首括号里的号码）。留空则自动在最近消息里找配图' }
        },
        required: ['keyword']
      },
      execute: (ctx, args) => toolLearn(ctx, args)
    },
    {
      id: 'meme_send',
      name: '发送表情',
      description:
        '聊天消息里出现某个表情的触发词时，发出对应的表情图。硬性规则：命中触发词就必须调用本工具发图，'
        + '不能只用文字回应。表情库是全局共用一份的，任何群聊/私聊都生效。'
        + 'keyword 参数传触发那条消息的原文（含 @ 照传），工具会校验是否出现触发词，'
        + '出现才发、没出现会拒绝。每次只发最贴合的一张。',
      category: 'media',
      icon: '🖼️',
      parameters: {
        type: 'object',
        properties: {
          keyword: { type: 'string', description: '触发的那条聊天消息的原文（工具会检查其中是否出现触发词）' },
          replyToMessageId: { type: ['integer', 'string'], description: '可选：引用触发的那条消息的 #id' },
          atUserId: { type: ['integer', 'string'], description: '可选：@ 某人（填 QQ 号）' }
        },
        required: ['keyword']
      },
      execute: (ctx, args) => toolSend(ctx, args)
    },
    {
      id: 'meme_list',
      name: '查看表情库',
      description: '列出表情库里已保存的全部关键词和各自触发词。被问到"有什么表情/表情库"时调用。',
      category: 'media',
      icon: '📋',
      parameters: {
        type: 'object',
        properties: {},
        required: []
      },
      execute: () => toolList()
    },
    {
      id: 'meme_delete',
      name: '删除表情',
      description: '按关键词删除表情库里的一个表情（图片文件和条目都删）。只有确定要删时调用。',
      category: 'media',
      icon: '🗑️',
      parameters: {
        type: 'object',
        properties: {
          keyword: { type: 'string', description: '要删除的表情关键词' }
        },
        required: ['keyword']
      },
      execute: (ctx, args) => toolDelete(ctx, args)
    }
  ];
  for (const d of defs) api.registerTool(d);
}

/** 可用性自检：保存目录能不能建/写。必须是同步链。 */
export function available() {
  try {
    fs.mkdirSync(resolveImagesDir(), { recursive: true });
    return { ok: true };
  } catch (e) {
    return { ok: false, reason: `保存目录不可写：${e?.message ?? e}` };
  }
}

/** 排障与测试入口：跑的就是上面那条真实路径。 */
export const internals = {
  sanitizeKeyword, safeFileNamePart, normalizeTriggerWords, detectMime, pickRecentImage,
  downloadImage, findTriggerHit, loadLibrary, saveLibrary, keywordListText,
  resolveImagesDir, resolveEntryPath, unreadSegment, buildTriggerReminder,
  LIB_DIR, DEFAULT_IMAGES_DIR, LIB_FILE
};
