// 学术助手技能 —— 学术翻译和论文润色
//
// 设计要点：
//   1. 调用主模型完成任务，不混入人设提示词（通过独立的 messages 实现）
//   2. 使用严谨的学术风格提示词
//   3. 支持中英互译和论文润色两个功能
//
// 为什么做成技能：
//   - 用户主动请求时触发（"帮我翻译这段""润色一下这段论文"）
//   - 需要 LLM 判断用户意图
//   - 通过 registerTool 让模型自己决定何时调用

import { chatCompletion } from '../../src/llm.js';

let cfg = () => ({});

function ok(payload) { return { content: JSON.stringify(payload, null, 2) }; }
function err(message) { return { content: String(message), isError: true }; }

/**
 * 调用主模型进行学术翻译或润色
 * @param {string} systemPrompt 系统提示词
 * @param {string} userContent 用户输入内容
 * @returns {Promise<string>} 处理结果
 */
async function callAcademicModel(systemPrompt, userContent) {
  const messages = [
    { role: 'system', content: systemPrompt },
    { role: 'user', content: userContent }
  ];

  try {
    const response = await chatCompletion({
      messages,
      tools: null,
      temperature: 0.3,  // 学术任务使用较低温度，保持严谨性
      signal: null,
      overrides: null
    });

    const result = response?.message?.content || '';
    if (!result) {
      throw new Error('模型返回结果为空');
    }
    return result;
  } catch (error) {
    throw new Error(`调用模型失败：${error?.message ?? error}`);
  }
}

/**
 * 检测文本主要语言（简单启发式）
 */
function detectLanguage(text) {
  const chineseChars = (text.match(/[一-龥]/g) || []).length;
  const totalChars = text.length;

  // 如果中文字符占比超过 30%，认为是中文
  return (chineseChars / totalChars) > 0.3 ? 'zh' : 'en';
}

export async function setup(api) {
  cfg = api.config;

  // ============================================================
  // 工具 1：学术翻译（中英互译）
  // ============================================================
  api.registerTool({
    id: 'academic_translate',
    name: '学术翻译',
    description: '学术文本中英互译。自动检测源语言（中文或英文），翻译为另一种语言。保持学术用语规范，准确传达原文含义。适用于论文摘要、文献段落、学术术语等的翻译。用户明确提出翻译需求时调用（如"翻译这段""translate this""帮我翻成英文"）。',
    category: 'productivity',
    icon: '🌐',
    parameters: {
      type: 'object',
      properties: {
        text: {
          type: 'string',
          description: '需要翻译的学术文本（自动检测中英文）'
        },
        targetLang: {
          type: 'string',
          description: '可选：目标语言，"zh"（中文）或"en"（英文）。不指定时自动检测源语言并翻译为另一种语言。',
          enum: ['zh', 'en']
        }
      },
      required: ['text']
    },
    async execute(ctx, args) {
      try {
        const text = String(args.text ?? '').trim();
        if (!text) {
          return err('翻译文本不能为空');
        }

        // 检查长度限制
        const maxLength = Math.max(100, Number(cfg().maxLength) || 5000);
        if (text.length > maxLength) {
          return ok({
            success: false,
            note: `文本过长（${text.length} 字符，限制 ${maxLength}）。请提示用户分段处理，或先处理前 ${maxLength} 字符。`
          });
        }

        // 检测源语言和目标语言
        const detectedLang = detectLanguage(text);
        const targetLang = args.targetLang || (detectedLang === 'zh' ? 'en' : 'zh');

        const isToEnglish = targetLang === 'en';

        // 构建学术翻译系统提示词
        const systemPrompt = isToEnglish
          ? `你是一位专业的学术翻译专家，专门从事中文到英文的学术文献翻译工作。

翻译要求：
1. 准确性：准确传达原文的学术含义，不遗漏关键信息
2. 专业性：使用规范的学术英语表达，符合国际学术期刊标准
3. 流畅性：译文通顺自然，符合英语学术写作习惯
4. 术语：正确使用学科专业术语，保持术语一致性
5. 格式：保持原文的段落结构和逻辑层次

请直接输出翻译结果，不要添加任何解释或说明。`
          : `你是一位专业的学术翻译专家，专门从事英文到中文的学术文献翻译工作。

翻译要求：
1. 准确性：准确传达原文的学术含义，不遗漏关键信息
2. 专业性：使用规范的中文学术表达，符合中文学术写作规范
3. 流畅性：译文通顺自然，符合中文表达习惯
4. 术语：正确翻译学科专业术语，必要时在首次出现时标注英文原词
5. 格式：保持原文的段落结构和逻辑层次

请直接输出翻译结果，不要添加任何解释或说明。`;

        const userContent = `请将以下${detectedLang === 'zh' ? '中文' : '英文'}学术文本翻译为${isToEnglish ? '英文' : '中文'}：

${text}`;

        const translation = await callAcademicModel(systemPrompt, userContent);

        return ok({
          success: true,
          sourceLang: detectedLang,
          targetLang: targetLang,
          originalLength: text.length,
          translatedLength: translation.length,
          translation: translation,
          note: '翻译完成。直接将译文发送给用户，不要复述原文。'
        });

      } catch (error) {
        return err(`翻译失败：${error?.message ?? error}`);
      }
    }
  });

  // ============================================================
  // 工具 2：论文润色
  // ============================================================
  api.registerTool({
    id: 'paper_polish',
    name: '论文润色',
    description: '学术论文润色和改进。检查并优化学术文本的语法、表达、逻辑和学术规范性。适用于论文段落、摘要、引言等需要提升质量的学术写作。自动检测语言（中文或英文）并按相应标准润色。用户明确提出润色需求时调用（如"润色这段""polish this""改进一下表达"）。',
    category: 'productivity',
    icon: '✨',
    parameters: {
      type: 'object',
      properties: {
        text: {
          type: 'string',
          description: '需要润色的学术文本'
        },
        focusAreas: {
          type: 'array',
          description: '可选：重点关注的方面，可包含 "grammar"（语法）、"clarity"（清晰度）、"conciseness"（简洁性）、"academic-tone"（学术语气）、"logic"（逻辑）等。不指定时进行全面润色。',
          items: {
            type: 'string'
          }
        }
      },
      required: ['text']
    },
    async execute(ctx, args) {
      try {
        const text = String(args.text ?? '').trim();
        if (!text) {
          return err('润色文本不能为空');
        }

        // 检查长度限制
        const maxLength = Math.max(100, Number(cfg().maxLength) || 5000);
        if (text.length > maxLength) {
          return ok({
            success: false,
            note: `文本过长（${text.length} 字符，限制 ${maxLength}）。请提示用户分段处理，或先处理前 ${maxLength} 字符。`
          });
        }

        // 检测语言
        const lang = detectLanguage(text);
        const isEnglish = lang === 'en';

        // 处理重点关注领域
        const focusAreas = Array.isArray(args.focusAreas) ? args.focusAreas : [];
        const focusDesc = focusAreas.length > 0
          ? `\n\n特别关注以下方面：${focusAreas.map(a => {
              const map = {
                'grammar': '语法正确性',
                'clarity': '表达清晰度',
                'conciseness': '语言简洁性',
                'academic-tone': '学术语气规范',
                'logic': '逻辑连贯性'
              };
              return map[a] || a;
            }).join('、')}`
          : '';

        // 构建论文润色系统提示词
        const systemPrompt = isEnglish
          ? `你是一位资深的学术论文编辑，专门帮助研究者提升英文学术写作质量。

润色要求：
1. 语法：修正所有语法错误、拼写错误和标点问题
2. 表达：优化句式结构，使表达更清晰、更符合学术规范
3. 简洁：删除冗余表达，使文字更精炼有力
4. 学术性：确保使用恰当的学术词汇和正式语气
5. 逻辑：改善句子和段落间的衔接，增强逻辑连贯性
6. 一致性：保持术语和表达的一致性${focusDesc}

输出格式要求：
- 直接输出润色后的文本
- 在文本后另起一段，简要说明主要修改点（用中文，格式：【修改说明】...）

请对以下文本进行润色。`
          : `你是一位资深的学术论文编辑，专门帮助研究者提升中文学术写作质量。

润色要求：
1. 语法：修正所有语法错误、错别字和标点问题
2. 表达：优化句式结构，使表达更清晰、更符合中文学术规范
3. 简洁：删除冗余表达，使文字更精炼有力
4. 学术性：确保使用恰当的学术词汇和正式语气，避免口语化
5. 逻辑：改善句子和段落间的衔接，增强逻辑连贯性
6. 一致性：保持术语和表达的一致性${focusDesc}

输出格式要求：
- 直接输出润色后的文本
- 在文本后另起一段，简要说明主要修改点（格式：【修改说明】...）

请对以下文本进行润色。`;

        const userContent = text;

        const result = await callAcademicModel(systemPrompt, userContent);

        // 尝试分离润色文本和修改说明
        const parts = result.split(/【修改说明】/);
        const polishedText = parts[0].trim();
        const modifications = parts.length > 1 ? parts[1].trim() : '已完成润色';

        return ok({
          success: true,
          language: lang === 'zh' ? '中文' : '英文',
          originalLength: text.length,
          polishedLength: polishedText.length,
          polishedText: polishedText,
          modifications: modifications,
          note: '润色完成。向用户展示润色后的文本和修改说明。'
        });

      } catch (error) {
        return err(`润色失败：${error?.message ?? error}`);
      }
    }
  });
}
