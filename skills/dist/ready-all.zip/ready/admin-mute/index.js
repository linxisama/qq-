// admin-mute：管理员禁言（LLM 型技能）
//
// 为什么是 skills/：
//   “这句话是不是管理员在下命令、被处理的人到底指谁”必须理解人话，
//   所以判断交给模型（registerTool 进 function 列表）。
//
// 但安全判定**不能**交给模型 —— 模型可能被群里的话术骗。所以代码这一侧硬性核对三件事：
//   1. 管理员QQ号在设置里（manifest.settings.adminQq）
//   2. admin_quote 能在最近的消息里、由管理员本人原话对上（store.recent 里的真实 senderId）
//   3. 机器人自己是群管理员/群主（OneBot get_group_member_info 的 role）
// 任何一条不满足就拒绝执行，并把原因原样返回给模型。
//
// OneBot v11 接口：get_group_member_list / get_group_member_info / set_group_ban

import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

const appRoot = globalThis.__qqAgentRoot
  || path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../..');

const DEFAULTS = {
  adminQq: '',
  muteMinutes: 10,
  maxMuteMinutes: 4320,
  allowUnmute: true,
  quoteWindowMinutes: 10,
  dryRun: false,
  // ── 自主（机器人判断）禁言 ──
  selfMute: true,
  selfMuteMinutes: 3,
  selfMuteCooldownMinutes: 10,
  selfMuteDailyLimit: 5,
  protectedQq: ''
};

const LIMIT = { quote: 120, reason: 60, scan: 60 };

let dataRootCache = null;
async function dataRoot() {
  if (dataRootCache) return dataRootCache;
  let base = path.join(appRoot, 'data');
  try {
    const cfg = await import(pathToFileURL(path.join(appRoot, 'src/config.js')).href);
    if (cfg && typeof cfg.DATA_DIR === 'string' && cfg.DATA_DIR) base = cfg.DATA_DIR;
  } catch {
    // 独立加载/测试时退回 app/data
  }
  dataRootCache = path.join(base, 'admin-mute');
  return dataRootCache;
}

const reply = (value, isError = false) => ({
  content: JSON.stringify(value),
  ...(isError ? { isError: true } : {})
});

const now = () => Date.now();

function clean(value, label, max, { allowEmpty = false } = {}) {
  const s = String(value ?? '')
    .replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/g, '')
    .replace(/\s+/g, ' ')
    .trim();
  if (!s && !allowEmpty) throw new Error(`${label}不能为空`);
  if ([...s].length > max) throw new Error(`${label}太长了（最多 ${max} 字）`);
  return s;
}

function integer(value, fallback, min, max) {
  const n = Number(value);
  if (!Number.isFinite(n)) return fallback;
  return Math.min(max, Math.max(min, Math.floor(n)));
}

/** 设置里的管理员QQ号列表（逗号/空格/换行分隔，只认纯数字）。 */
function adminIds(raw) {
  const list = String(raw ?? '').split(/[,，;；\s]+/).map((s) => s.trim()).filter(Boolean);
  return [...new Set(list.filter((s) => /^\d{5,12}$/.test(s)))];
}

/** 任意“QQ号清单”设置（豁免名单等）：同样的解析规则。 */
function qqList(raw) {
  return adminIds(raw);
}

/** 比对原话用：去掉空白和标点，避免“禁言 他”和“禁言他”对不上。 */
function normalizeForMatch(text) {
  return String(text ?? '')
    .toLowerCase()
    .replace(/[\s\u3000]/g, '')
    .replace(/[，。！？、；：""''（）()《》…—\-_.!?,;:"'`~@#$%^&*+=|\\/<>[\]{}]/g, '');
}

function groupIdOf(ctx) {
  if (String(ctx?.kind) !== 'group') throw new Error('这个功能只能在群里用');
  const id = String(ctx?.chatId ?? '');
  if (!/^\d{5,12}$/.test(id)) throw new Error(`群号不合法：${id}`);
  return id;
}

/** 该会话最近的消息（给“管理员原话”核对用）。 */
function recentMessages(ctx) {
  try {
    const rows = ctx?.store?.recent?.(ctx.chatKey, { limit: LIMIT.scan }) || [];
    return Array.isArray(rows) ? rows : [];
  } catch {
    return [];
  }
}

function audit(file, record) {
  try {
    fs.mkdirSync(path.dirname(file), { recursive: true });
    fs.appendFileSync(file, JSON.stringify({ at: new Date().toISOString(), ...record }) + '\n', 'utf8');
  } catch {
    // 审计失败不影响主流程
  }
}

/** 北京时间下的“今天”，用于自主禁言的每日计数。 */
function dayKey() {
  return new Date(now() + 8 * 3600000).toISOString().slice(0, 10);
}

/**
 * 自主禁言的持久状态：跨重启记住“今天已经忍不住几次了”。
 * 结构：{ day, perGroup: { [groupId]: { count, lastAt } }, targets: { 'gid:uid': ts } }
 */
function readSelfState(file) {
  try {
    const s = JSON.parse(fs.readFileSync(file, 'utf8'));
    if (s && typeof s === 'object') {
      return { day: s.day || '', perGroup: s.perGroup || {}, targets: s.targets || {} };
    }
  } catch {
    // 首次运行 / 文件损坏：从空状态开始
  }
  return { day: '', perGroup: {}, targets: {} };
}

function writeSelfState(file, state) {
  try {
    fs.mkdirSync(path.dirname(file), { recursive: true });
    const tmp = `${file}.tmp`;
    fs.writeFileSync(tmp, JSON.stringify(state, null, 2), 'utf8');
    fs.renameSync(tmp, file);
  } catch {
    // 状态写不进去就让限流退化为内存态，不阻断禁言本身
  }
}

export function setup(api) {
  const cfg = () => ({ ...DEFAULTS, ...(api.config?.() || {}) });
  const lastAction = new Map(); // `${groupId}:${userId}` -> ts，防重复提交

  const admins = () => adminIds(cfg().adminQq);

  /** 机器人自己是不是群管理/群主 —— 不是的话 OneBot 调禁言必然失败。 */
  async function botRole(ctx, groupId) {
    const selfId = String(ctx?.onebot?.selfId ?? ctx?.selfId ?? '');
    if (!/^\d{5,12}$/.test(selfId)) throw new Error('机器人尚未登录');
    const info = await ctx.onebot.call('get_group_member_info', {
      group_id: Number(groupId),
      user_id: Number(selfId),
      no_cache: true
    });
    const role = String(info?.role ?? 'member');
    return { selfId, role };
  }

  async function memberList(ctx, groupId) {
    const rows = await ctx.onebot.call('get_group_member_list', { group_id: Number(groupId) }, 20000);
    if (!Array.isArray(rows)) throw new Error('取群成员列表失败');
    return rows.map((m) => ({
      userId: String(m.user_id),
      name: String(m.card || m.nickname || m.user_id),
      card: String(m.card || ''),
      nickname: String(m.nickname || ''),
      role: String(m.role || 'member'),
      muteUntil: Number(m.shut_up_timestamp || 0) * 1000
    }));
  }

  /** 管理员身份 + 原话核对：必须找到一条“管理员本人 + 最近 + 说过这句”的消息。 */
  function verifyAdminOrder(ctx, quote, groupId) {
    const ids = new Set(admins());
    if (!ids.size) {
      throw new Error('还没有配置管理员QQ号（技能设置 → 管理员禁言 → 管理员QQ号）');
    }
    const c = cfg();
    const windowMs = integer(c.quoteWindowMinutes, 10, 1, 1440) * 60000;
    const needle = normalizeForMatch(quote);
    if (needle.length < 2) throw new Error('admin_quote 太短，请原样抄管理员那句话');
    const rows = recentMessages(ctx);
    const hit = rows
      .slice()
      .reverse()
      .find((m) => ids.has(String(m.senderId ?? ''))
        && now() - Number(m.ts || 0) <= windowMs
        && normalizeForMatch(m.text).includes(needle));
    if (!hit) {
      throw new Error('没有找到这句管理员原话：只认设置里的管理员本人、'
        + `${integer(c.quoteWindowMinutes, 10, 1, 1440)} 分钟内在本群说过的话。请把管理员原话完整传给 admin_quote。`);
    }
    // 否定式防呆：管理员说的是"别禁言他 / 不许把他关掉"时，模型可能只截取"禁言他"
    // 当原话传进来 —— 这类句子一律不执行，宁可漏一次也不要做反。
    const full = normalizeForMatch(hit.text);
    const negated = /(别|不要|不用|不许|不准|禁止)(禁言|封|关|踢|把)/.test(full);
    if (negated && !/解禁|解除/.test(full)) {
      throw new Error('管理员那句话里带否定（别/不许/禁止…），看起来不是真的要禁言，已拒绝执行');
    }
    return { adminId: String(hit.senderId), adminName: String(hit.senderName || hit.senderId), quote: String(hit.text || '') };
  }

  /** 把 target 解析成群成员：支持 QQ 号、群名片、昵称；重名时要求改用QQ号。 */
  function pickTarget(members, raw) {
    const s = clean(raw, '禁言对象', 40);
    if (/^\d{5,12}$/.test(s)) {
      const hit = members.find((m) => m.userId === s);
      if (!hit) throw new Error(`群里找不到 QQ ${s}`);
      return hit;
    }
    const exact = members.filter((m) => m.name === s || m.nickname === s || m.card === s);
    if (exact.length === 1) return exact[0];
    if (exact.length > 1) {
      throw new Error(`「${s}」对应多个人（${exact.map((m) => m.userId).join(' / ')}），请改用QQ号`);
    }
    const partial = members.filter((m) => m.name.includes(s) || (m.nickname && m.nickname.includes(s)));
    if (partial.length === 1) return partial[0];
    if (partial.length > 1) {
      throw new Error(`「${s}」匹配到多个人（${partial.map((m) => `${m.name}(${m.userId})`).join(' / ')}），请改用QQ号`);
    }
    throw new Error(`群里找不到「${s}」，确认一下昵称或直接给QQ号`);
  }

  /**
   * 真正落地一次禁言：去重 → 演练闸 → 调 OneBot → 回读确认 → 审计。
   * 管理员指令和自主禁言共用，差别只在 plan.actor 与前置校验。
   */
  async function applyBan(ctx, { groupId, target, minutes, reason, plan }) {
    const c = cfg();
    const seconds = minutes * 60;
    const key = `${groupId}:${target.userId}:${seconds}:${plan.actor}`;
    const prevAt = lastAction.get(key) || 0;
    if (now() - prevAt < 8000) return { skipped: true };

    if (c.dryRun === true) return { dryRun: true, confirmed: false, readback: null };

    await ctx.onebot.call('set_group_ban', {
      group_id: Number(groupId),
      user_id: Number(target.userId),
      duration: seconds
    }, 20000);
    lastAction.set(key, now());

    // 回读确认：OneBot 返回 ok 不代表真的生效，再查一次成员的 shut_up_timestamp
    let confirmed = false;
    let readback = null;
    try {
      const info = await ctx.onebot.call('get_group_member_info', {
        group_id: Number(groupId),
        user_id: Number(target.userId),
        no_cache: true
      });
      readback = Number(info?.shut_up_timestamp || 0) * 1000;
      confirmed = minutes === 0 ? readback <= now() : readback > now();
    } catch {
      // 回读失败不影响“已提交”的判断，但调用方要在文案里说清楚
    }

    audit(path.join(await dataRoot(), 'audit.jsonl'), {
      groupId,
      userId: target.userId,
      name: target.name,
      minutes,
      seconds,
      reason,
      ...plan,
      confirmed,
      dryRun: false
    });
    return { dryRun: false, confirmed, readback };
  }

  const tools = {
    /** 执行禁言 / 解禁 */
    async mute_member(ctx, args = {}) {
      const groupId = groupIdOf(ctx);
      const c = cfg();
      const order = verifyAdminOrder(ctx, args.admin_quote, groupId);
      const bot = await botRole(ctx, groupId);
      if (bot.role !== 'admin' && bot.role !== 'owner') {
        throw new Error(`机器人不是本群管理员（当前身份：${bot.role}），没法禁言。请先给它管理员。`);
      }
      const members = await memberList(ctx, groupId);
      // 先用“原始数字”挡一道：管理员QQ号可能根本不在成员列表里（还没说话），
      // 走 pickTarget 会变成“群里找不到”，错误信息就答非所问了。
      const rawTarget = clean(args.target, '禁言对象', 40);
      if (/^\d{5,12}$/.test(rawTarget) && admins().includes(rawTarget)) {
        throw new Error('不能禁言管理员本人');
      }
      const target = pickTarget(members, rawTarget);
      if (target.userId === bot.selfId) throw new Error('不能禁言机器人自己');
      if (admins().includes(target.userId)) throw new Error('不能禁言管理员本人');
      if (target.role === 'owner') throw new Error('不能禁言群主');

      const minutes = args.minutes === undefined || args.minutes === null || args.minutes === ''
        ? integer(c.muteMinutes, DEFAULTS.muteMinutes, 1, integer(c.maxMuteMinutes, DEFAULTS.maxMuteMinutes, 1, 43200))
        : integer(args.minutes, integer(c.muteMinutes, DEFAULTS.muteMinutes, 1, 14400), 0, integer(c.maxMuteMinutes, DEFAULTS.maxMuteMinutes, 1, 43200));
      if (minutes === 0 && c.allowUnmute === false) throw new Error('当前设置不允许解除禁言');

      const reason = clean(args.reason, '理由', LIMIT.reason, { allowEmpty: true });
      const result = await applyBan(ctx, {
        groupId,
        target,
        minutes,
        reason,
        plan: { actor: 'admin', adminId: order.adminId, adminName: order.adminName }
      });
      if (result.skipped) {
        return reply({
          ok: true,
          skipped: true,
          userId: target.userId,
          name: target.name,
          message: '同样的操作刚刚已经执行过，重复调用已忽略。'
        });
      }
      return reply({
        ok: true,
        dryRun: result.dryRun,
        groupId,
        userId: target.userId,
        name: target.name,
        minutes,
        seconds: minutes * 60,
        adminId: order.adminId,
        adminName: order.adminName,
        reason,
        confirmed: result.confirmed ?? false,
        readback: result.readback ?? null,
        message: result.dryRun
          ? `演练模式：本该禁言 ${target.name}（${target.userId}）${minutes} 分钟，但没有真的执行。`
          : (minutes === 0
            ? `已解除 ${target.name}（${target.userId}）的禁言${result.confirmed ? '，回读确认已解除' : ''}。`
            : `已禁言 ${target.name}（${target.userId}）${minutes} 分钟${result.confirmed ? '，回读确认生效' : '（接口已接受，回读未确认，可能有延迟）'}。`)
      });
    },

    /**
     * 自主禁言：机器人自己被惹毛了的时候用。
     * 不需要管理员原话，但限流更严（时长上限、冷却、每日次数、豁免名单都在设置里）。
     */
    async mute_for_anger(ctx, args = {}) {
      const groupId = groupIdOf(ctx);
      const c = cfg();
      if (c.selfMute === false) throw new Error('自主禁言已在设置里关闭（只有管理员能指挥禁言）');
      const reason = clean(args.reason, '生气的理由', LIMIT.reason);
      if ([...reason].length < 2) throw new Error('要说清楚为什么生气，理由太短');
      const bot = await botRole(ctx, groupId);
      if (bot.role !== 'admin' && bot.role !== 'owner') {
        throw new Error(`机器人不是本群管理员（当前身份：${bot.role}），没法禁言。请先给它管理员。`);
      }
      const members = await memberList(ctx, groupId);
      const rawTarget = clean(args.target, '禁言对象', 40);
      const protectedIds = new Set([...admins(), ...qqList(c.protectedQq)]);
      if (/^\d{5,12}$/.test(rawTarget) && protectedIds.has(rawTarget)) {
        throw new Error('这个人是管理员或在豁免名单里，不能动');
      }
      const target = pickTarget(members, rawTarget);
      if (target.userId === bot.selfId) throw new Error('不能禁言机器人自己');
      if (protectedIds.has(target.userId)) throw new Error('这个人是管理员或在豁免名单里，不能动');
      if (target.role === 'owner') throw new Error('不能禁言群主');

      const capMinutes = Math.max(1, Math.min(
        integer(c.selfMuteMinutes, DEFAULTS.selfMuteMinutes, 1, 1440),
        integer(c.maxMuteMinutes, DEFAULTS.maxMuteMinutes, 1, 43200)
      ));
      const minutes = integer(args.minutes, capMinutes, 1, capMinutes);
      if (minutes > capMinutes) throw new Error(`自主禁言最长 ${capMinutes} 分钟`);

      // 限流：同一群冷却 + 每天次数上限，状态落盘，重启不重置
      const stateFile = path.join(await dataRoot(), 'self-state.json');
      const state = readSelfState(stateFile);
      if (state.day !== dayKey()) {
        state.day = dayKey();
        state.perGroup = {};
        state.targets = {};
      }
      const stat = state.perGroup[groupId] || { count: 0, lastAt: 0 };
      const cooldownMs = integer(c.selfMuteCooldownMinutes, DEFAULTS.selfMuteCooldownMinutes, 0, 1440) * 60000;
      const waitMs = cooldownMs - (now() - Number(stat.lastAt || 0));
      if (waitMs > 0) {
        throw new Error(`刚自己动过手，再忍 ${Math.ceil(waitMs / 60000)} 分钟（冷却时间可在设置里调）`);
      }
      const dailyLimit = integer(c.selfMuteDailyLimit, DEFAULTS.selfMuteDailyLimit, 1, 100);
      if (Number(stat.count || 0) >= dailyLimit) {
        throw new Error(`今天自主禁言已经用满 ${dailyLimit} 次，剩下的交给管理员`);
      }
      const targetKey = `${groupId}:${target.userId}`;
      if (now() - Number(state.targets[targetKey] || 0) < 30 * 60000) {
        throw new Error('这个人半小时内已经被自主禁言过一次了，别追着关');
      }

      const result = await applyBan(ctx, {
        groupId,
        target,
        minutes,
        reason,
        plan: { actor: 'self' }
      });
      if (result.skipped) {
        return reply({ ok: true, skipped: true, userId: target.userId, name: target.name, message: '刚刚已经处理过，重复调用已忽略。' });
      }
      if (!result.dryRun) {
        state.perGroup[groupId] = { count: Number(stat.count || 0) + 1, lastAt: now() };
        state.targets[targetKey] = now();
        writeSelfState(stateFile, state);
      }
      return reply({
        ok: true,
        dryRun: result.dryRun,
        selfInitiated: true,
        groupId,
        userId: target.userId,
        name: target.name,
        minutes,
        reason,
        remainingToday: Math.max(0, dailyLimit - (Number(stat.count || 0) + (result.dryRun ? 0 : 1))),
        confirmed: result.confirmed ?? false,
        message: result.dryRun
          ? `演练模式：本该把 ${target.name}（${target.userId}）禁言 ${minutes} 分钟，但没有真的执行。`
          : `已禁言 ${target.name}（${target.userId}）${minutes} 分钟${result.confirmed ? '，回读确认生效' : '（接口已接受，回读未确认）'}。说话时别炫耀权限，简单说一句为什么就行。`
      });
    },

    /** 查当前禁言状态（不传 target 就列出所有被禁言的人） */
    async mute_status(ctx, args = {}) {
      const groupId = groupIdOf(ctx);
      const bot = await botRole(ctx, groupId).catch(() => ({ selfId: '', role: 'unknown' }));
      let members;
      try {
        members = await memberList(ctx, groupId);
      } catch (error) {
        return reply({ ok: false, message: `取群成员失败：${error?.message ?? error}` }, true);
      }
      const muted = members.filter((m) => m.muteUntil > now());
      const describe = (m) => ({
        userId: m.userId,
        name: m.name,
        role: m.role,
        remainingMinutes: Math.max(1, Math.round((m.muteUntil - now()) / 60000))
      });

      if (args.target === undefined || args.target === null || String(args.target).trim() === '') {
        return reply({
          ok: true,
          botRole: bot.role,
          admins: admins(),
          mutedCount: muted.length,
          muted: muted.map(describe),
          message: muted.length
            ? `当前有 ${muted.length} 人被禁言：${muted.map((m) => `${m.name}(${describe(m).remainingMinutes}分钟)`).join('、')}`
            : '当前没有被禁言的人。'
        });
      }
      const target = pickTarget(members, args.target);
      const info = describe(target);
      return reply({
        ok: true,
        botRole: bot.role,
        target: info,
        muted: target.muteUntil > now(),
        message: target.muteUntil > now()
          ? `${target.name}（${target.userId}）还剩 ${info.remainingMinutes} 分钟禁言`
          : `${target.name}（${target.userId}）没有被禁言`
      });
    }
  };

  const defs = [
    ['mute_member', '禁言群成员', '管理员明确要求时禁言某人；minutes=0 表示解除禁言。admin_quote 必须原样抄管理员那句原话，代码会核对发送者是不是设置里的管理员。', {
      target: { type: 'string', description: '被处理的群友：QQ号或群名片/昵称' },
      admin_quote: { type: 'string', description: '管理员那句原话，原样抄写，不要改写' },
      minutes: { type: 'integer', description: '禁言分钟数；省略则用设置里的默认时长，0 表示解除禁言' },
      reason: { type: 'string', description: '简短理由，可省略' }
    }, ['target', 'admin_quote']],
    ['mute_status', '查看禁言状态', '查看谁被禁言了、还剩多久，以及机器人自己是不是管理员；也用来确认禁言是否生效。', {
      target: { type: 'string', description: '要查的人：QQ号或昵称；不传则列出所有被禁言的人' }
    }, []],
    ['mute_for_anger', '自己被惹毛时禁言', '机器人自己被冒犯、被辱骂或被反复骚扰时，自主决定禁言对方一小会儿；不需要管理员命令，但有冷却、每日次数上限和豁免名单。', {
      target: { type: 'string', description: '惹到你的那个人：QQ号或群名片/昵称' },
      reason: { type: 'string', description: '你生气的原因，一句话说清（会写进审计日志）' },
      minutes: { type: 'integer', description: '禁言分钟数；省略则用设置里的自主禁言时长，且不会超过上限' }
    }, ['target', 'reason']]
  ];

  for (const [id, name, description, properties, required] of defs) {
    api.registerTool({
      id,
      name,
      description,
      category: 'utility',
      icon: '🔇',
      parameters: {
        type: 'object',
        properties,
        additionalProperties: false,
        ...(required.length ? { required } : {})
      },
      execute: tools[id]
    });
  }

  return tools;
}

/** 动态提示词：把当前设置实时告诉模型，避免它按旧值说话。 */
export function promptSections() {
  return [{
    id: 'admin-mute-live',
    title: '禁言当前设置',
    priority: 75,
    content: '禁言功能的管理员QQ号、默认时长、是否允许解禁、是否允许你自主禁言，都以技能设置为准；'
      + '不确定当前配置时先调用 admin-mute__mute_status，它会返回机器人身份和当前被禁言名单。'
      + '自主禁言（mute_for_anger）受冷却、每日上限和豁免名单限制，被拒绝就接受结果，不要换着法子重试。'
  }];
}
