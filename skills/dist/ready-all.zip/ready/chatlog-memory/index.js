/**
 * chatlog-memory —— 聊天记录入库（LLM 型技能 / Skill API v1）
 *
 * 需求：用户把一段聊天记录发给机器人，机器人识别出每句话是谁说的，
 *       提炼成「对群友的长期印象」，写进记忆；用户点名某个群时写进那个群。
 *
 * ── 为什么做成技能，不是插件 ─────────────────────────────────────────────
 * 判据见 src/skills/manifest.js 的 DIR_KIND：
 *   plugins/  确定性型 —— providers / hooks，满足条件必然执行，不经过 LLM
 *   skills/   LLM 型   —— registerTool，用不用、什么时候用**由模型判断**
 *
 * 三问（README 收录的判据：「规则能写死 → 插件；要理解人话 → 技能」）：
 *   ① 规则能写死吗？  不能。粘贴进来的记录格式千变万化 ——「张三: 你好」
 *      「张三(QQ:123): 你好」带时间戳、带表情、有人插话、整段不换行……穷举不完。
 *   ② 要不要理解人话？要。得看懂谁在说话、说的什么、哪些值得长期记。
 *   ③ 何时执行由谁定？由模型判断「这条消息是不是一段要被整理的聊天记录」。
 * 三条都指向 LLM 型 → skills/。放错目录的后果是**静默失效**（不报错、就是没反应）。
 *
 * ── 分工边界（这条边界别越）──────────────────────────────────────────────
 *   本技能：把「名字/QQ → 目标会话 → 写成印象」这条链钉死，并做校验、去重、汇报
 *   宿主核心：记忆落盘格式与接口（ctx.memory）、会话与成员列表（ctx.store / ctx.onebot）
 *   模型：读记录、认人、提炼 —— 这部分写不成规则，正是本技能存在的理由
 *
 * ── 踩坑备忘（都是宿主真实行为，不按它写就会静默失效）────────────────────
 *   · ctx.memory.append(chatKey, 'memberImpression', content, { userId, target })
 *     只认 category='memberImpression'；userId 与 target **至少要有一个**，否则
 *     直接 return null —— 不抛错、不日志，就是没写进去（src/memory.js 的 append）。
 *   · content 在 #appendRaw 里被硬切到 300 字：超了不报错，静默截断。所以这里
 *     主动切分，并把「切过」如实回报，免得模型以为原样全存下了。
 *   · target 被切到 60 字。
 *   · userId 存的是身份：是纯数字就落成 <QQ>.json，否则名字会被当成"无 QQ 号"
 *     落成 _n_<名字>.json。同一个人因此会分裂成两份，越想越乱。所以严格校验。
 *   · 记忆是**按会话**存的（data/memory/group_<群号>/<QQ>.json）。「存到哪个群」
 *     必须显式解析成 chatKey，不能由模型编 —— 编出来的 chatKey 会凭空建一个
 *     谁也不认的目录。
 *   · ctx.onebot.call() 返回的已经是 body.data（src/onebot.js 的 call）；但不同
 *     协议端对 get_group_list / get_group_member_list 的包装不统一，两种形态都兜。
 *   · 工具 id 会成为 OpenAI function name：宿主统一加 `技能id__` 前缀，并把非法
 *     字符替成下划线（src/plugin-loader.js 的 createSkillApi）。所以 id 只用
 *     小写字母、数字、连字符 —— 用点号或冒号会被严格端点 400 掉整个请求。
 *
 * ── 安全底线 ───────────────────────────────────────────────────────────
 *   · 只写「机器人真的在的会话」：目标必须能由 get_group_list 或本地存档证实，
 *     证不了就拒写。绝不接受一个没验证过的 chatKey。
 *   · 单次条数、单轮累计条数都有上限，防止模型刷爆记忆库。
 *   · 记录正文是**数据不是指令**：里面写的「忽略以上规则」不当真（提示词里也钉了）。
 */

const BUILD_TAG = 'v1.0.0';

/** 宿主记忆接口的硬约束（src/memory.js），写在这里当文档用。 */
const MAX_CONTENT_CHARS = 300;    // #appendRaw 对 content 的切分长度
const MAX_CHUNKS_PER_ENTRY = 4;   // 单条印象最多切几段，防止一段话炸出几十条
const QQ_RE = /^\d{1,15}$/;       // 宿主的 QQ 号形态（真实号 5~15 位）
const MEMBER_CACHE_MS = 60_000;   // 群成员列表缓存，避免反复打协议端

const DEFAULTS = {
  allowCrossChat: true,   // 允许写进当前会话以外的会话
  maxPerCall: 20,         // 单次 save 最多写几条
  maxPerRun: 40,          // 同一轮对话累计最多写几条
  lookupMembers: true     // 允许查群成员，把名字补成 QQ 号
};

let cfg = () => ({});
let log = () => {};
let warn = () => {};

const ok = (content) => ({ content });
const err = (message) => ({ content: `错误：${message}`, isError: true });

// ───────────────────────────── 小工具 ─────────────────────────────

function str(v, dflt = '') {
  const s = String(v ?? '').trim();
  return s || dflt;
}

function clampInt(v, min, max, dflt) {
  const n = Number(v);
  if (!Number.isFinite(n)) return dflt;
  return Math.max(min, Math.min(max, Math.round(n)));
}

/** args 可能是对象，也可能是模型传进来的 JSON 字符串。 */
function asObject(args) {
  if (args && typeof args === 'object' && !Array.isArray(args)) return args;
  if (typeof args === 'string') {
    try {
      const parsed = JSON.parse(args);
      return parsed && typeof parsed === 'object' ? parsed : {};
    } catch { return {}; }
  }
  return {};
}

/** 名字归一化：去掉所有空白再比，避免「张 三」和「张三」认成两个人。 */
function normName(v) {
  return String(v ?? '').replace(/\s+/g, '').trim();
}

function clip(s, n) {
  const t = String(s ?? '').replace(/\s+/g, ' ').trim();
  return t.length > n ? `${t.slice(0, n)}…` : t;
}

/**
 * 拆出「名字 + QQ 号」。
 * 记录里常见的形态是「张三(QQ:123456)」，这一条就能把身份钉死 —— 比名字可靠得多
 * （名字会改、会重名、有全角空格昵称）。认不出来就只留名字。
 */
function parseWho(raw) {
  const s = str(raw);
  if (!s) return { name: '', userId: '' };
  const m = /^(.*?)[\s]*[（(]\s*QQ\s*[:：]\s*(\d{1,15})\s*[)）][\s]*$/i.exec(s);
  if (m) {
    const name = str(m[1]);
    return { name: name || `QQ${m[2]}`, userId: m[2] };
  }
  // 整串就是个号码：当 QQ 号用，名字留空（下面会用成员表补）
  if (QQ_RE.test(s)) return { name: '', userId: s };
  return { name: s, userId: '' };
}

/**
 * 把过长的印象切成 ≤300 字的多条。
 *
 * 为什么主动切而不是丢给宿主截断：宿主是**静默截断**（超出部分直接消失，不报错），
 * 模型会以为自己写进去了整段话。主动切分 + 如实回报，至少让它知道发生了什么。
 *
 * ⚠️ 这里同样**绝不能静默丢字**：切到 MAX_CHUNKS_PER_ENTRY 段还有剩时，
 * 必须把丢掉的字数报出去（droppedChars）。否则本技能自己就成了它要防的那种东西
 * —— 超限不报错，只是内容悄悄少了（这个 bug 被验证脚本抓到过一次）。
 *
 * @returns {{ chunks: string[], droppedChars: number }}
 */
function splitContent(text, max = MAX_CONTENT_CHARS) {
  const s = String(text ?? '').trim();
  if (!s) return { chunks: [], droppedChars: 0 };
  if (s.length <= max) return { chunks: [s], droppedChars: 0 };

  const parts = [];
  let rest = s;
  while (rest.length > max && parts.length < MAX_CHUNKS_PER_ENTRY) {
    const window = rest.slice(0, max);
    const cut = Math.max(
      window.lastIndexOf('。'), window.lastIndexOf('！'), window.lastIndexOf('？'),
      window.lastIndexOf('!'), window.lastIndexOf('?'),
      window.lastIndexOf('；'), window.lastIndexOf(';'),
      window.lastIndexOf('\n')
    );
    // 边界太靠前（不到一半）就硬切，避免切出一堆两三字的碎片
    const at = cut >= max * 0.5 ? cut + 1 : max;
    const piece = rest.slice(0, at).trim();
    if (piece) parts.push(piece);
    rest = rest.slice(at).trim();
  }
  // 收尾：段数上限算上这一段 —— 直接 push 会让实际段数变成 MAX+1（曾出现的差一错误）。
  // 容量已满就把剩下的全部记账为丢弃，绝不悄悄少字。
  let droppedChars = 0;
  if (rest) {
    if (parts.length < MAX_CHUNKS_PER_ENTRY) {
      parts.push(rest.slice(0, max));
      droppedChars = Math.max(0, rest.length - max);
    } else {
      droppedChars = rest.length;
    }
  }
  return { chunks: parts.filter(Boolean), droppedChars };
}

function settings() {
  const s = (typeof cfg === 'function' ? cfg() : null) || {};
  const pick = (k) => (s[k] === undefined || s[k] === null || s[k] === '' ? DEFAULTS[k] : s[k]);
  return {
    allowCrossChat: pick('allowCrossChat') !== false,
    maxPerCall: clampInt(pick('maxPerCall'), 1, 200, DEFAULTS.maxPerCall),
    maxPerRun: clampInt(pick('maxPerRun'), 1, 500, DEFAULTS.maxPerRun),
    lookupMembers: pick('lookupMembers') !== false
  };
}

// ── 单轮累计用量（同一轮对话里模型可以多次调 save，必须有个总闸）──
const runUsage = new Map();   // sessionId -> { n, at }

function runState(ctx) {
  const key = String(ctx?.session?.id || 'global');
  let st = runUsage.get(key);
  if (!st) { st = { n: 0, at: Date.now() }; runUsage.set(key, st); }
  st.at = Date.now();
  if (runUsage.size > 200) {
    const now = Date.now();
    for (const [k, v] of runUsage) if (now - v.at > 3 * 3600_000) runUsage.delete(k);
  }
  return st;
}

// ── 会员/会话列表 ──

/** OneBot 返回值可能是裸数组，也可能包一层 data（各协议端不统一）。 */
function asList(raw) {
  if (Array.isArray(raw)) return raw;
  if (Array.isArray(raw?.data)) return raw.data;
  return [];
}

const memberCache = new Map();   // chatKey -> { at, list }

/** 取群成员列表（带缓存）。失败返回 null（= 用不了这条路，不是"群里没人"）。 */
async function lookupMembers(ctx, chatKey) {
  const m = /^group:(\d+)$/.exec(String(chatKey || ''));
  if (!m) return null;
  const hit = memberCache.get(chatKey);
  if (hit && Date.now() - hit.at < MEMBER_CACHE_MS) return hit.list;
  if (typeof ctx?.onebot?.call !== 'function') return null;
  try {
    const raw = await ctx.onebot.call('get_group_member_list', { group_id: Number(m[1]) });
    const list = asList(raw).map((x) => ({
      userId: str(x?.user_id),
      names: [normName(x?.card), normName(x?.nickname)].filter(Boolean)
    })).filter((x) => x.userId && QQ_RE.test(x.userId));
    memberCache.set(chatKey, { at: Date.now(), list });
    return list;
  } catch (error) {
    // 负缓存：协议端没连上时不要让每次 save 都去撞一遍超时
    warn(`取群成员失败（${chatKey}）：${error?.message ?? error}`);
    memberCache.set(chatKey, { at: Date.now(), list: [] });
    return [];
  }
}

/**
 * 按名字在成员表里找 QQ 号。
 * **只在唯一命中时**才回填：重名时硬猜等于把印象记到别人头上，
 * 那比"只记名字"糟糕得多（记忆是长期的，错了会一直错下去）。
 */
function uniqueUserId(list, name) {
  const want = normName(name);
  if (!want || !Array.isArray(list) || !list.length) return '';
  const hits = new Set();
  for (const m of list) if (m.names.includes(want)) hits.add(m.userId);
  return hits.size === 1 ? [...hits][0] : '';
}

/** 汇总"机器人真的在的会话"：当前会话 + QQ 群列表 + 本地存档。 */
async function collectTargets(ctx) {
  const out = new Map();   // chatKey -> 显示名
  if (ctx?.chatKey) out.set(String(ctx.chatKey), '（当前会话）');

  if (typeof ctx?.onebot?.call === 'function') {
    try {
      const raw = await ctx.onebot.call('get_group_list');
      for (const g of asList(raw)) {
        const id = str(g?.group_id);
        if (id) out.set(`group:${id}`, str(g?.group_name, `群 ${id}`));
      }
    } catch (error) {
      warn(`取群列表失败：${error?.message ?? error}`);
    }
  }
  try {
    for (const k of (ctx?.store?.listChats?.() || [])) {
      if (!out.has(String(k))) out.set(String(k), '');
    }
  } catch { /* 存档读不到不影响主要来源 */ }
  return [...out.entries()].map(([chatKey, name]) => ({ chatKey, name }));
}

function targetLabel(chatKey, targets) {
  const hit = targets.find((t) => t.chatKey === chatKey);
  const name = hit?.name && hit.name !== '（当前会话）' ? hit.name : '';
  return name ? `${name}（${chatKey}）` : chatKey;
}

function memoryOf(ctx) {
  const mem = ctx?.memory;
  if (!mem || typeof mem.append !== 'function' || typeof mem.query !== 'function') return null;
  return mem;
}

function countImpressions(ctx, chatKey) {
  try {
    const q = ctx.memory.query(chatKey);
    return Array.isArray(q?.memberImpression) ? q.memberImpression.length : 0;
  } catch { return 0; }
}

// ───────────────────────────── 生命周期 ─────────────────────────────

export function setup(api) {
  cfg = api.config;
  log = api.log;
  warn = api.warn;

  /**
   * 列可选目标 —— 把「记到 XX 群」这句话变成确定的 chatKey。
   *
   * 为什么要单独一个工具：模型**编不出** chatKey（它没有群号，猜出来的会凭空
   * 建出一个谁也不认的记忆目录）。只能查。
   */
  api.registerTool({
    id: 'targets',
    name: '查可选会话',
    description: '列出机器人真正在的会话（群名 + chatKey，含当前会话）。要"把这段记录记到某个群"之前，先用它把群名换成准确的 chatKey —— 群号不要自己编，编出来的会写进一个不存在的记忆目录。',
    category: 'query',
    icon: '📋',
    defaultEnabled: true,
    parameters: {
      type: 'object',
      properties: {
        query: { type: 'string', description: '可选：按关键词过滤群名（如"测试"）。不传 = 全部。' }
      }
    },
    async execute(ctx, args) {
      const raw = asObject(args);
      const q = normName(raw.query);
      try {
        const all = await collectTargets(ctx);
        const list = q ? all.filter((t) => normName(t.name).includes(q) || t.chatKey.includes(q)) : all;
        if (!list.length) {
          return ok(q
            ? `没有名字里带「${clip(raw.query, 20)}」的会话。机器人当前能看到的会话共 ${all.length} 个 —— 别猜群号，把候选列给用户让他选。`
            : '现在拿不到任何会话（协议端可能没连上）。可以把记录先存到当前会话，或者稍后再试。');
        }
        const lines = [`【可选会话】共 ${list.length} 个${q ? `（按「${clip(raw.query, 20)}」过滤）` : ''}`];
        for (const t of list.slice(0, 30)) {
          lines.push(`· ${t.chatKey}${t.name && t.name !== '（当前会话）' ? `　${t.name}` : ''}${t.chatKey === String(ctx?.chatKey) ? '　← 当前会话' : ''}`);
        }
        if (list.length > 30) lines.push(`（还有 ${list.length - 30} 个未列出）`);
        return ok(lines.join('\n'));
      } catch (error) {
        return err(`查会话失败：${error?.message ?? error}`);
      }
    }
  });

  /**
   * 写入印象 —— 本技能的主工具。
   */
  api.registerTool({
    id: 'save',
    name: '写入记忆',
    description: '把从聊天记录里提炼出的「对群友的长期印象」写进记忆。每条一个人一条，只写以后打交道用得上的稳定印象（说话风格、常聊话题、爱玩的梗、雷点、身份/关系），不要照抄原话、不要把一时一事记成长期印象。目标默认是当前会话；用户点名了某个群，就要先用 targets 查到 chatKey 再传 targetChatKey。',
    category: 'memory',
    icon: '🧠',
    defaultEnabled: true,
    parameters: {
      type: 'object',
      properties: {
        targetChatKey: {
          type: 'string',
          description: '存到哪个会话，形如 group:123456。不传 = 存当前会话。群名必须先用 targets 换成 chatKey；编的 chatKey 会被拒。'
        },
        entries: {
          type: 'array',
          description: '要写入的印象，一个人可以有多条',
          items: {
            type: 'object',
            properties: {
              name: { type: 'string', description: '对方名字（备注名/群名片/昵称）。记录里写成「张三(QQ:123456)」就照原样填，工具会自动拆出 QQ 号。' },
              userId: { type: 'string', description: '对方 QQ 号（可选）。有就填 —— 号比名字可靠，不会因为改名或重名记混。' },
              content: { type: 'string', description: '一条提炼后的长期印象（≤300 字；超了会自动切成多条并如实回报）' }
            },
            required: ['name', 'content']
          }
        },
        dryRun: {
          type: 'boolean',
          description: 'true = 只预览要写什么，不真的写。批量较大、或者拿不准用户想不想留时先用它给用户过目。'
        }
      },
      required: ['entries']
    },
    async execute(ctx, args) {
      const raw = asObject(args);
      const conf = settings();
      const mem = memoryOf(ctx);
      if (!mem) return err('记忆模块不可用（拿不到 ctx.memory），先确认机器人正常启动了。');

      if (!Array.isArray(raw.entries) || !raw.entries.length) {
        return err('entries 不能为空：每条是 { name, content }，一个人可以有多条。');
      }
      if (raw.entries.length > conf.maxPerCall) {
        return err(`一次最多写 ${conf.maxPerCall} 条（这次给了 ${raw.entries.length} 条）。请拆成几次调用，或先只写最关键的几条。`);
      }

      // ── 目标会话：先验证，再写 ──
      const targets = await collectTargets(ctx);
      const isCross = Boolean(raw.targetChatKey) && String(raw.targetChatKey) !== String(ctx?.chatKey);
      const targetChatKey = str(raw.targetChatKey) || String(ctx?.chatKey || '');
      if (!targetChatKey) return err('拿不到当前会话标识，无法写入。');

      if (isCross && !conf.allowCrossChat) {
        return err('写进别的会话已被设置关掉（「允许写进别的会话」当前为关闭）。可以改成存当前会话，或请用户在设置页把这一项打开。');
      }
      if (!targets.some((t) => t.chatKey === targetChatKey)) {
        const sample = targets.slice(0, 8).map((t) => t.chatKey).join('、');
        return err(`不认得会话 ${targetChatKey}：它既不在机器人的群列表里，本地也没有这个会话的记录。`
          + `别猜群号，用 targets 查准确的值再试${sample ? `（可用：${sample}）` : ''}。`);
      }

      // ── 单轮总闸 ──
      const st = runState(ctx);
      const remain = Math.max(0, conf.maxPerRun - st.n);
      if (remain <= 0) {
        return err(`这一轮已经写了 ${st.n} 条，达到单轮上限 ${conf.maxPerRun} 条。剩下的请让用户确认后再开新一轮处理。`);
      }
      const batch = Math.min(raw.entries.length, remain);
      const overflow = raw.entries.length - batch;

      // ── 归一化 + 补 QQ 号 ──
      const members = conf.lookupMembers ? await lookupMembers(ctx, targetChatKey) : null;
      const prepared = [];
      const skipped = [];
      const resolvedByLookup = [];
      const nameOnly = [];
      let splitCount = 0;
      let droppedChars = 0;

      for (let i = 0; i < batch; i++) {
        const item = raw.entries[i] || {};
        const content = str(item.content);
        if (!content) { skipped.push(`第 ${i + 1} 条 content 为空`); continue; }

        const who = parseWho(item.name);
        let userId = str(item.userId) || who.userId;
        let name = who.name;
        if (userId && !QQ_RE.test(userId)) {
          skipped.push(`第 ${i + 1} 条 userId「${clip(userId, 12)}」不是 QQ 号形态，已按名字存`);
          userId = '';
        }
        // 名字缺失但有号 → 用成员表把名字补回来（记忆页上显示的就是这个名字）
        if (!name && userId && Array.isArray(members)) {
          const hit = members.find((m) => m.userId === userId);
          name = hit?.names?.[0] || '';
        }
        // 有名字没号 → 查成员表唯一命中才回填
        if (!userId && name && Array.isArray(members)) {
          const got = uniqueUserId(members, name);
          if (got) { userId = got; resolvedByLookup.push(`${name}→${got}`); }
        }
        if (!name && !userId) { skipped.push(`第 ${i + 1} 条既没有名字也没有 QQ 号`); continue; }
        if (!name) name = userId;
        if (!userId) nameOnly.push(name);

        const { chunks, droppedChars: dropped } = splitContent(content);
        if (chunks.length > 1) splitCount += 1;
        droppedChars += dropped;
        for (const c of chunks) prepared.push({ userId, name: clip(name, 60), content: c });
      }

      if (!prepared.length) {
        return err(`没有可写入的内容。${skipped.length ? `跳过原因：${skipped.join('；')}` : '请检查 entries 每项是否都有 name 和 content。'}`);
      }

      const label = targetLabel(targetChatKey, targets);
      const useDryRun = raw.dryRun === true;
      const before = countImpressions(ctx, targetChatKey);

      // ── 写入 ──
      let written = 0;
      const failed = [];
      if (!useDryRun) {
        for (const p of prepared) {
          try {
            // append 对不合法输入返回 null（不抛错）—— 必须显式判，否则会"假成功"
            const entry = mem.append(targetChatKey, 'memberImpression', p.content, { userId: p.userId, target: p.name });
            if (entry) written += 1;
            else failed.push(`${p.name || p.userId}：宿主拒绝了这条（缺 userId 且缺 target）`);
          } catch (error) {
            failed.push(`${p.name || p.userId}：${error?.message ?? error}`);
          }
        }
        st.n += written;
      } else {
        written = prepared.length;
      }

      const after = useDryRun ? before : countImpressions(ctx, targetChatKey);
      const people = new Set(prepared.map((p) => p.userId || p.name)).size;

      // ── 如实汇报（工具输出会进模型上下文，所以紧凑但有信息量）──
      const lines = [
        `${useDryRun ? '【预览，未写入】' : '【已写入记忆】'} 目标：${label}`,
        `${useDryRun ? '将要写入' : '写入'} ${people} 个人的 ${written} 条印象`
          + `${skipped.length ? `，跳过 ${skipped.length} 条` : ''}`
          + `${failed.length ? `，失败 ${failed.length} 条` : ''}`
      ];
      if (!useDryRun) lines.push(`· 该会话印象总数：${before} → ${after}`);
      if (resolvedByLookup.length) lines.push(`· 按群成员表补上 QQ 号：${clip(resolvedByLookup.join('、'), 160)}`);
      if (nameOnly.length) lines.push(`· 只有名字、没查到 QQ 号：${clip([...new Set(nameOnly)].join('、'), 120)}（按名字存；这人要是改名或重名，以后可能记混）`);
      if (splitCount) lines.push(`· 有 ${splitCount} 条超过 ${MAX_CONTENT_CHARS} 字，已切成多条存下（宿主单条上限就是这个数，超了会被静默截断）`);
      if (droppedChars) lines.push(`· ⚠️ 有 ${droppedChars} 个字因为超过单条 ${MAX_CHUNKS_PER_ENTRY} 段的切分上限没能存下 —— 这条印象太长，建议拆成几条更短的。`);
      if (skipped.length) lines.push(`· 跳过：${clip(skipped.join('；'), 200)}`);
      if (failed.length) lines.push(`· ⚠️ 失败：${clip(failed.join('；'), 200)}`);
      if (overflow) lines.push(`· ⚠️ 还有 ${overflow} 条这次没写（单轮上限 ${conf.maxPerRun} 条），下一轮再处理。`);
      if (!useDryRun) lines.push('（核对：控制台「记忆」页签，里面按会话分组、每人一份档案。）');
      return ok(lines.join('\n'));
    }
  });

  /**
   * 回读已存的印象 —— 用来核对"到底写进去没有、之前记过什么"。
   */
  api.registerTool({
    id: 'inspect',
    name: '查看已存印象',
    description: '查看某个会话里已经存下的群友印象（按人分组、带条数）。写完之后想核对结果、或者不确定某人之前记过什么时用。不传 targetChatKey = 看当前会话。',
    category: 'memory',
    icon: '🔎',
    defaultEnabled: true,
    parameters: {
      type: 'object',
      properties: {
        targetChatKey: { type: 'string', description: '看哪个会话，形如 group:123456（先用 targets 查）。不传 = 当前会话。' },
        limit: { type: 'integer', description: '最多列几个人，默认 15' }
      }
    },
    async execute(ctx, args) {
      const raw = asObject(args);
      const mem = memoryOf(ctx);
      if (!mem) return err('记忆模块不可用（拿不到 ctx.memory）。');
      const targets = await collectTargets(ctx);
      const targetChatKey = str(raw.targetChatKey) || String(ctx?.chatKey || '');
      if (!targets.some((t) => t.chatKey === targetChatKey)) {
        return err(`不认得会话 ${targetChatKey}，先用 targets 查准确的值。`);
      }
      const limit = clampInt(raw.limit, 1, 50, 15);
      try {
        const q = mem.query(targetChatKey);
        const list = Array.isArray(q?.memberImpression) ? q.memberImpression : [];
        const label = targetLabel(targetChatKey, targets);
        if (!list.length) return ok(`【${label}】还没有任何群友印象。`);

        // 按身份聚合：能合并"只有名字"和"有 QQ 号"的重复展示
        const groups = new Map();
        for (const e of list) {
          const key = str(e.userId) || `名字:${str(e.target)}`;
          if (!groups.has(key)) groups.set(key, { userId: str(e.userId), name: str(e.target), items: [] });
          groups.get(key).items.push(e);
        }
        // 按**最近一条的时间**排，不是按条数排。
        // 刚写完就想核对时，条数少的新人必须排在最前面 —— 否则会被老数据挤到
        // limit 之外，看起来像"根本没写进去"（这个排序被验证脚本抓到过一次）。
        const latestAt = (g) => g.items.reduce((mx, e) => Math.max(mx, Number(e.createdAt) || 0), 0);
        const rows = [...groups.values()].sort((a, b) => latestAt(b) - latestAt(a));
        const lines = [`【${label}】共 ${list.length} 条印象、${rows.length} 个人（按最近更新排序）`];
        for (const r of rows.slice(0, limit)) {
          const who = `${r.name || r.userId}${r.userId && r.name ? `(QQ:${r.userId})` : ''}`;
          lines.push(`· ${who}：${r.items.length} 条`);
          // query() 返回的是**时间倒序**（src/memory.js 里 sort 过），所以最新一条在 [0]
          const latest = r.items[0];
          if (latest?.content) lines.push(`　最近一条：${clip(latest.content, 60)}`);
        }
        if (rows.length > limit) lines.push(`（还有 ${rows.length - limit} 个人未列出）`);
        return ok(lines.join('\n'));
      } catch (error) {
        return err(`查印象失败：${error?.message ?? error}`);
      }
    }
  });

  log(`聊天记录入库已加载（${BUILD_TAG}）｜工具 targets / save / inspect`
    + `｜单次上限 ${DEFAULTS.maxPerCall} 条、单轮 ${DEFAULTS.maxPerRun} 条｜跨会话写入：默认允许（需目标可验证）`);
}

/** 测试/排障用导出。 */
export const __internals = {
  parseWho, splitContent, normName, uniqueUserId, settings, asObject, clampInt,
  MAX_CONTENT_CHARS, setConfig: (fn) => { cfg = fn; }
};
