// 群管理指令（LLM 型技能 / skills/）
//
// ── 类型判定：为什么这个必须是「技能」而不是「插件」 ────────────────────────
//   请求是「我提出要求 → 机器人执行」（自然语言、说法千变万化：禁言他 / 让他闭嘴 /
//   把刚才那条撤了 / 谁在群里）。**判断"用户是不是在要求管群"这件事只有模型做得到**，
//   写死关键词必然漏。所以这里必须 registerTool —— 工具进模型的 function 列表，
//   由模型决定什么时候调。
//   （对照：同批交付的 plugins/group-sentinel 做的是"命中违禁词就自动禁言"，
//     那是条件确定型，必须不经过模型，所以放 plugins/。）
//
// ── 依赖的真实接口（都是从本项目源码里核出来的，别凭记忆改）─────────────────
//   set_group_ban   { group_id, user_id, duration }        duration 单位**秒**，0 = 解禁
//   delete_msg      { message_id }                          撤回
//   set_group_kick  { group_id, user_id, reject_add_request }  踢人
//   get_group_member_info { group_id, user_id, no_cache }   返回 role: owner/admin/member
//   get_group_member_list { group_id }                      返回数组，每项含 user_id/nickname/card/role
//
//   ⚠️ ctx.onebot.call 失败时**抛异常**（不是返回 retcode），所以全部包 try/catch，
//      并且失败必须返回 isError —— 让模型看见真实原因，而不是让它以为已经禁好了。

const BUILD_TAG = 'group-admin v1.0.0';

// 成员身份缓存：`${groupId}:${userId}` → { role, checkedAt }
// 同一条指令要连查好几个人（下指令的、被操作的、机器人自己），不缓存会把
// 一次禁言变成四五次 OneBot 往返。5 分钟内身份不会变。
const roleCache = new Map();
const ROLE_CACHE_MS = 5 * 60 * 1000;
const ROLE_CACHE_MAX = 500;

/**
 * 「本轮是谁在指使我」的捕获区。
 *
 * ⚠️ 为什么需要它（真实故障复盘）：
 *   核心交给**工具**的上下文（ctx）里只有 chatKey/kind/chatId/onebot/sender/session…
 *   **没有**"本轮是哪些人说了话"。那份信息只出现在两个地方：
 *     ① 提示词文本里（模型看得见，代码拿不到）；
 *     ② before-tool 钩子的上下文里（triggerEntries，代码能拿到）。
 *   之前这里只靠 ② 之外的东西推断（"本批最后一位发言人"），一旦攒批/别人抢了最后一句，
 *   就拿不到 QQ 号，用户看到的是「无法确认下指令的人是谁」。
 *   现在改成：钩子在工具执行**之前**把说话的人记下来，工具执行时直接取 —— 精确且不依赖模型。
 *   （配套用 before-tool 而不是 before-llm-messages：两者都在同一次运行里，
 *     但只有 before-tool 紧贴着工具执行，能保证读到的就是"这次指令"的那一批人。）
 */
const callerLog = new Map();      // key → { candidates: [{ id, isAdmin }], at }
const CALLER_TTL_MS = 3 * 60 * 1000;
const CALLER_MAX = 200;

export const hooks = {
  /** 记下本轮可能下指令的人（含是否是管理员），供紧接着执行的工具读取。 */
  async 'before-tool'(ctx = {}) {
    try {
      const entries = Array.isArray(ctx.triggerEntries) ? ctx.triggerEntries : [];
      const self = selfId(ctx);
      const seen = new Map();   // id → isAdmin

      const add = (id, isAdmin) => {
        const qq = qqOf(id);
        if (!qq || qq === self) return;
        seen.set(qq, Boolean(seen.get(qq)) || Boolean(isAdmin));
      };
      // 系统上下文里明确给出的调用者（有就是最准的）
      add(ctx.callerId, true);
      add(ctx.userId, false);
      add(ctx.senderId, false);
      // 本批里 @ 了机器人的发言者：最像"在吩咐机器人"
      for (const e of entries) if (e?.atMe === true) add(e.senderId, true);
      // 本批最后一位发言人：被叫到时通常就是他
      const last = entries[entries.length - 1];
      if (last) add(last.senderId, false);

      const candidates = [...seen.entries()].map(([id, isAdmin]) => ({ id, isAdmin }));
      if (!candidates.length) return;

      const key = storeKey(ctx);
      if (key) {
        callerLog.set(key, { candidates, at: Date.now() });
        if (callerLog.size > CALLER_MAX) pruneCallerLog();
      }
    } catch (error) {
      // 钩子只是"帮忙记住"，失败不能让工具执行不了
      warn(`记录指令来源失败：${describeError(error)}`);
    }
  }
};

function storeKey(ctx) {
  const sid = String(ctx?.sessionId || '').trim();
  if (sid) return sid;
  const chat = String(ctx?.chatKey || '').trim();
  return chat ? `chat:${chat}` : '';
}

function pruneCallerLog() {
  const now = Date.now();
  for (const [key, value] of callerLog) {
    if (now - (value?.at || 0) > CALLER_TTL_MS) callerLog.delete(key);
  }
  while (callerLog.size > CALLER_MAX) callerLog.delete(callerLog.keys().next().value);
}

let cfg = () => ({});
let log = () => {};
let warn = () => {};
// 注入的 api 本体也要留着：api.capability / api.hasCapability 是**软依赖**入口，
// 用来问"装没装自动守卫"。只保存 cfg/log/warn 会让后面想用能力时直接 ReferenceError
// （这个错误还会被 try/catch 吞掉，表现成"功能莫名其妙不可用"）。
let api = null;

/** 模型回传的"下指令者 QQ 号"（可选参数，多个别名都认）。 */
function callerOf(args) {
  return qqOf(args?.caller_id ?? args?.callerId ?? args?.operator_id ?? args?.operatorId);
}

/** 工具返回值约定：成功 ok()，失败 fail()（isError 让模型能读到原因并纠正）。 */
const ok = (content) => ({ content: String(content), isError: false });
const fail = (content) => ({ content: String(content), isError: true });

/**
 * 每个群管理工具都带的这个参数：**谁在下这条指令**。
 *
 * 为什么让模型来填：核心交给工具的上下文里没有"本轮是谁在说话"，而聊天记录里
 * 每个人的发言都带 `(QQ:数字)` 后缀 —— 模型看得见，工具看不见，所以让它带回来。
 * 安全上不吃亏：这个号码会被**真去查群身份**，编一个管理员的 QQ 也没用。
 */
const CALLER_PARAM = {
  caller_id: {
    type: ['integer', 'string'],
    description: '下这条指令的人的 QQ 号（从聊天记录里那位发言者的 (QQ:数字) 取，纯数字）。'
      + '用于校验权限，必须是被指令者本人；不要填机器人自己的号。'
  }
};

export function setup(injected) {
  api = injected;
  cfg = injected.config || (() => ({}));
  log = injected.log || (() => {});
  warn = injected.warn || (() => {});

  api.registerTool({
    id: 'mute',
    name: '禁言成员',
    category: 'message',
    icon: '🔇',
    description:
      '禁言（或解除禁言）群里的某个成员。当群主/管理员说「禁言他」「让他闭嘴」「别让他说话了」'
      + '「解禁」「解除禁言」「放他出来」时使用。'
      + '参数 user_id 传对方 QQ 号（不知道 QQ 号时先调 members 或 member_info 查出来）；'
      + 'minutes 传禁言多少分钟，解禁时传 0；caller_id 传下指令那个人的 QQ 号（必填，用来校验权限）。'
      + '注意：机器人必须是群管理员才能禁言；不要对群主/管理员使用（会被 QQ 拒绝）。',
    parameters: {
      type: 'object',
      properties: {
        user_id: { type: ['integer', 'string'], description: '被禁言成员的 QQ 号（纯数字）。' },
        minutes: {
          type: 'integer',
          description: '禁言多少分钟：0 = 解除禁言；不填则用「技能设置」里的默认时长。'
        },
        reason: { type: 'string', description: '可选：一句话说明原因，只记在控制台日志里，不会发到群里。' },
        ...CALLER_PARAM
      },
      required: ['user_id', 'caller_id']
    },
    async execute(ctx, args) {
      const guard = await needGroup(ctx, callerOf(args));
      if (guard.error) return fail(guard.error);
      const { groupId, chatKey } = guard;

      const target = qqOf(args?.user_id);
      if (!target) return fail('没有拿到有效的 QQ 号：请传纯数字的 user_id（可以先查群成员列表）。');
      if (target === selfId(ctx)) return fail('那是机器人自己，不能对自己执行操作。');

      const s = settings();

      // 目标身份：群主/管理员不能禁（QQ 会拒绝，且这是"得罪管理"的经典事故）
      const info = await memberInfo(ctx, groupId, target);
      const role = roleOf(info);
      if (role === 'owner') return fail('对方是群主，禁言群主一定会被 QQ 拒绝，已放弃。');
      if (role === 'admin') return fail('对方是群管理员，机器人没有权限禁言管理员，已放弃（需要群主操作）。');

      // 时长解析：显式 minutes 优先（0 = 解禁），否则用配置默认；全部受上限约束
      const explicit = args?.minutes === undefined || args?.minutes === null || args?.minutes === ''
        ? null
        : Number(args.minutes);
      const minutes = explicit === null ? s.defaultMinutes : clampNum(explicit, 0, s.maxMinutes);
      const seconds = Math.round(minutes * 60);

      if (s.dryRun) {
        return ok(`【演练模式】本该把 ${describeTarget(info, target)} 禁言 ${humanMinutes(seconds)}，没有调用任何接口。`);
      }

      // 机器人自身权限前置检查：说清"为什么不行"比等 QQ 报错强
      const myRole = await myMemberRole(ctx, groupId);
      if (myRole === 'member') {
        return fail(
          '机器人不是本群管理员，没有禁言权限。请把机器人设为群管理员后重试'
          + '（或让群主亲自操作）。'
        );
      }

      try {
        await ctx.onebot.call('set_group_ban', {
          group_id: Number(groupId),
          user_id: Number(target),
          duration: seconds
        });
      } catch (error) {
        warn(`禁言 ${target} 失败：${describeError(error)}`);
        return fail(`禁言失败：${humanizeError(error)}。${permissionHint(error)}`);
      }

      const label = describeTarget(info, target);
      log(`已${seconds > 0 ? '禁言' : '解除禁言'} ${label} ${seconds > 0 ? humanMinutes(seconds) : ''}`
        + `${args?.reason ? `（原因：${String(args.reason).slice(0, 60)}）` : ''}`);

      if (seconds === 0) {
        if (s.announce) await announce(ctx, chatKey, `已解除 ${label} 的禁言。`, target);
        return ok(`已解除 ${label} 的禁言。不要复述细节，一句话告诉群友即可。`);
      }

      if (s.announce) await announce(ctx, chatKey, `已禁言 ${label} ${humanMinutes(seconds)}。`, target);
      return ok(`已禁言 ${label} ${humanMinutes(seconds)}。不要再调用发送类工具重复通知，一句话汇报即可。`);
    }
  });

  api.registerTool({
    id: 'recall',
    name: '撤回消息',
    category: 'message',
    icon: '↩️',
    description:
      '撤回群里的一条消息。当群主/管理员说「撤回」「把刚才那条删了」「撤回他发的那张图」时使用。'
      + 'message_id 传聊天记录里显示的 #数字（也可以直接引用的那条消息 id）；'
      + 'caller_id 传下指令那个人的 QQ 号（必填，用来校验权限）。'
      + '只能撤回机器人是管理员、且消息发出不超过 2 分钟的普通成员消息——超时会失败，如实告诉对方。',
    parameters: {
      type: 'object',
      properties: {
        message_id: { type: ['integer', 'string'], description: '要撤回的消息 id（聊天记录里的 #数字，可能是负数）。' },
        reason: { type: 'string', description: '可选：一句话说明原因，只记日志。' },
        ...CALLER_PARAM
      },
      required: ['message_id', 'caller_id']
    },
    async execute(ctx, args) {
      const guard = await needGroup(ctx, callerOf(args));
      if (guard.error) return fail(guard.error);
      const { groupId } = guard;

      const mid = String(args?.message_id ?? '').trim();
      if (!/^-?\d+$/.test(mid)) return fail('message_id 必须是消息 id（聊天记录里的 #数字）。');

      // 存档里能查到就带上发送人和摘要 —— 方便日志核对撤的是哪条
      let who = '';
      try {
        const entry = ctx.store?.findByMid?.(ctx.chatKey, mid);
        if (entry) who = `（${entry.senderName || entry.senderId || '未知'}：${String(entry.text || '').slice(0, 30)}）`;
      } catch { /* 查不到不影响撤回 */ }

      const s = settings();
      if (s.dryRun) return ok(`【演练模式】本该撤回消息 #${mid}${who}，没有调用任何接口。`);

      const myRole = await myMemberRole(ctx, groupId);
      if (myRole === 'member') {
        return fail('机器人不是本群管理员，撤回不了别人的消息（只能撤回自己发的）。');
      }

      try {
        await ctx.onebot.call('delete_msg', { message_id: Number(mid) });
      } catch (error) {
        warn(`撤回 #${mid} 失败：${describeError(error)}`);
        return fail(
          `撤回失败：${humanizeError(error)}。常见原因：消息发出超过 2 分钟、'
          + '或那条消息属于管理员/群主（QQ 不允许撤回）。`
        );
      }

      log(`已撤回消息 #${mid}${who}`);
      return ok(`已撤回消息 #${mid}。一句话汇报即可，不要解释技术细节。`);
    }
  });

  api.registerTool({
    id: 'kick',
    name: '移出群聊',
    category: 'message',
    icon: '🚪',
    description:
      '把某个成员移出群聊（踢人）。这是不可逆操作：**必须先向提出要求的人复述要踢谁并得到确认**，'
      + '确认后再次调用时把 confirmed 设为 true 才会真的执行。'
      + 'caller_id 传下指令那个人的 QQ 号（必填，用来校验权限）。'
      + '严禁在对方没有明确同意踢人前调用（哪怕他骂人——骂人交给自动守卫或先禁言）。',
    defaultEnabled: true,
    parameters: {
      type: 'object',
      properties: {
        user_id: { type: ['integer', 'string'], description: '要移出群聊的成员 QQ 号（纯数字）。' },
        confirmed: { type: 'boolean', description: '是否已经得到下指令者的明确确认（没确认就别传 true）。' },
        reject_add_request: { type: 'boolean', description: '是否同时拒绝此人再次加群，默认否。' },
        ...CALLER_PARAM
      },
      required: ['user_id', 'caller_id']
    },
    async execute(ctx, args) {
      const guard = await needGroup(ctx, callerOf(args));
      if (guard.error) return fail(guard.error);
      const { groupId, chatKey } = guard;

      const s = settings();
      // 工具级开关：关掉后连调用都拒绝（工具本身也会从模型列表里被移除）
      if (!s.allowKick) return fail('「允许踢人」在技能设置里是关闭的，请让管理员先打开再操作。');

      const target = qqOf(args?.user_id);
      if (!target) return fail('没有拿到有效的 QQ 号。');
      if (target === selfId(ctx)) return fail('那是机器人自己。');

      const info = await memberInfo(ctx, groupId, target);
      const role = roleOf(info);
      if (role === 'owner') return fail('对方是群主，踢不了。');
      if (role === 'admin') return fail('对方是群管理员，机器人权限不足以踢管理员（需要群主操作）。');

      const label = describeTarget(info, target);
      if (args?.confirmed !== true) {
        return fail(
          `还没有确认，已暂停。请先问下指令的人：「确认要把 ${label} 移出本群吗？」`
          + '——得到明确同意后，再调用一次并把 confirmed 设为 true。'
        );
      }

      if (s.dryRun) return ok(`【演练模式】本该把 ${label} 移出群聊，没有调用任何接口。`);

      const myRole = await myMemberRole(ctx, groupId);
      if (myRole === 'member') return fail('机器人不是本群管理员，没有踢人权限。');

      try {
        await ctx.onebot.call('set_group_kick', {
          group_id: Number(groupId),
          user_id: Number(target),
          reject_add_request: args?.reject_add_request === true
        });
      } catch (error) {
        warn(`踢出 ${target} 失败：${describeError(error)}`);
        return fail(`移出群聊失败：${humanizeError(error)}。${permissionHint(error)}`);
      }

      log(`已把 ${label} 移出群聊（群 ${groupId}）`);
      if (s.announce) await announce(ctx, chatKey, `${label} 已被移出群聊。`);
      return ok(`已把 ${label} 移出群聊。一句话汇报即可。`);
    }
  });

  api.registerTool({
    id: 'members',
    name: '查群成员',
    category: 'query',
    icon: '👥',
    description:
      '列出本群成员（含群名片/昵称/身份/QQ 号）。当需要知道"某人 QQ 号是多少""群里有没有叫这个名字的人"'
      + '「谁是管理员」时使用。可用 keyword 过滤名字，避免把几百人的名单全读出来。',
    parameters: {
      type: 'object',
      properties: {
        keyword: { type: 'string', description: '可选：名字/群名片关键字，只返回包含它的成员。' },
        adminsOnly: { type: 'boolean', description: '可选：只列群主和管理员。' },
        limit: { type: 'integer', description: '最多返回多少条，默认 30，上限 100。' }
      }
    },
    async execute(ctx, args) {
      const guard = await needGroup(ctx, callerOf(args));
      if (guard.error) return fail(guard.error);
      const { groupId } = guard;

      let list;
      try {
        list = await ctx.onebot.call('get_group_member_list', { group_id: Number(groupId) });
      } catch (error) {
        return fail(`查群成员失败：${humanizeError(error)}。`);
      }
      const members = Array.isArray(list) ? list : (Array.isArray(list?.data) ? list.data : []);
      if (!members.length) return ok('没查到成员（可能机器人没有权限，或群号不对）。');

      const keyword = String(args?.keyword ?? '').trim().toLowerCase();
      const limit = clampNum(args?.limit, 1, 100, 30);
      const rows = members
        .map((m) => ({
          id: String(m?.user_id ?? ''),
          name: String(m?.card || m?.nickname || ''),
          nick: String(m?.nickname || ''),
          role: roleOf(m)
        }))
        .filter((m) => m.id)
        .filter((m) => (args?.adminsOnly === true ? m.role === 'owner' || m.role === 'admin' : true))
        .filter((m) => (!keyword ? true : `${m.name} ${m.nick} ${m.id}`.toLowerCase().includes(keyword)))
        .slice(0, limit);

      if (!rows.length) return ok(keyword ? `没有名字含「${keyword}」的成员。` : '没有符合条件的成员。');

      const lines = rows.map((m, i) =>
        `${i + 1}. ${roleLabel(m.role)}${m.name || '（无群名片）'}（QQ:${m.id}）`
        + (m.nick && m.nick !== m.name ? ` 昵称：${m.nick}` : '')
      );
      return ok(`本群共 ${members.length} 人，本次列出 ${rows.length} 条：\n${lines.join('\n')}`
        + '\n（要用这些 QQ 号做禁言/踢人时，直接用数字即可。）');
    }
  });

  api.registerTool({
    id: 'member_info',
    name: '查成员身份',
    category: 'query',
    icon: '🔎',
    description:
      '查某个群成员的身份与状态（群主/管理员/普通成员、是否正在被禁言、剩余多久、入群时间、等级）。'
      + '在决定要不要禁言、或群友问「他为什么能发我不能发」时使用。'
      + 'caller_id 传下指令那个人的 QQ 号（必填，用来校验权限）。',
    parameters: {
      type: 'object',
      properties: {
        user_id: { type: ['integer', 'string'], description: '要查的成员 QQ 号（纯数字）。' },
        ...CALLER_PARAM
      },
      required: ['user_id', 'caller_id']
    },
    async execute(ctx, args) {
      const guard = await needGroup(ctx, callerOf(args));
      if (guard.error) return fail(guard.error);
      const { groupId } = guard;

      const target = qqOf(args?.user_id);
      if (!target) return fail('没有拿到有效的 QQ 号。');

      const info = await memberInfo(ctx, groupId, target);
      if (!info) return fail(`查不到 ${target} 的群成员信息（可能不在本群，或机器人没有权限）。`);

      const role = roleOf(info);
      const shutUp = Number(info?.shut_up_timestamp ?? info?.shutUpTimestamp ?? 0);
      const muted = shutUp > 0 && shutUp * 1000 > Date.now();
      const rest = muted ? humanMinutes(Math.round((shutUp * 1000 - Date.now()) / 1000)) : '';

      const parts = [
        `${describeTarget(info, target)}：${roleLabel(role)}`,
        muted ? `当前处于禁言中，还剩约 ${rest}` : '当前没有被禁言'
      ];
      const joinTs = Number(info?.join_time ?? 0);
      if (joinTs > 0) parts.push(`入群时间：${new Date(joinTs * 1000).toLocaleString('zh-CN')}`);
      if (info?.level != null) parts.push(`群等级：${info.level}`);
      return ok(parts.join('；') + '。');
    }
  });

  api.registerTool({
    id: 'clear_offenses',
    name: '清除违规记录',
    category: 'system',
    icon: '🧹',
    description:
      '清除某个成员在「自动守卫」里的累计违规次数（这样他下次违规会从第一次重新算，不会被禁得更久）。'
      + '当管理员说「给他一次机会」「把违规记录清了」「别禁他那么久」时使用。'
      + 'caller_id 传下指令那个人的 QQ 号（必填，用来校验权限）。'
      + '注意：这个工具只改统计，不会解除已经生效的禁言——解禁请用 mute 工具把 minutes 传 0。',
    parameters: {
      type: 'object',
      properties: {
        user_id: { type: ['integer', 'string'], description: '要清除违规记录的成员 QQ 号（纯数字）。' },
        ...CALLER_PARAM
      },
      required: ['user_id', 'caller_id']
    },
    async execute(ctx, args) {
      const guard = await needGroup(ctx, callerOf(args));
      if (guard.error) return fail(guard.error);
      const { groupId } = guard;

      const target = qqOf(args?.user_id);
      if (!target) return fail('没有拿到有效的 QQ 号。');

      // 先确认这人真的在群里，避免"给一个不存在的 QQ 清记录"这种无效操作
      const info = await memberInfo(ctx, groupId, target);
      if (!info) return fail(`查不到 ${target} 的群成员信息，请先确认他是不是本群成员。`);

      const cleared = clearOffenses(groupId, target);
      if (cleared === null) {
        return fail('装好的「群管理·自动守卫」插件没有提供违规记录能力（它可能被关掉了），无法清除记录。');
      }
      log(`已清除 ${target} 的违规统计（群 ${groupId}，原有 ${cleared} 次）`);
      return ok(`已清除 ${describeTarget(info, target)} 的违规次数（原来是 ${cleared} 次）。`
        + '如果他现在正在被禁言且你想放他出来，请再用 mute 工具把 minutes 传 0。');
    }
  });

  log(`群管理指令已加载（${BUILD_TAG}）`);
}

// ══════════════════════════════════════════════════════════════════════════
// 可用性：只在群聊里可用
// ══════════════════════════════════════════════════════════════════════════

/**
 * 自检。私聊里这些工具全是无意义的（禁言/撤回都需要群上下文），
 * 所以私聊时直接判定"不可用"，模型连工具都看不到 —— 由核心按上下文调用本函数。
 */
export function available(context = {}) {
  const kind = String(context?.kind || '');
  if (kind && kind !== 'group') {
    return { ok: false, reason: '群管理工具只在群聊里可用（当前是私聊）' };
  }
  return { ok: true };
}

// ══════════════════════════════════════════════════════════════════════════
// 内部工具
// ══════════════════════════════════════════════════════════════════════════

function settings() {
  const c = cfg() || {};
  const preset = String(c.durationMinutes ?? '10');
  const custom = clampNum(c.customMinutes, 0, 43200, 0);
  const defaultMinutes = preset === 'custom'
    ? custom
    : clampNum(preset, 0, 43200, 10);
  return {
    defaultMinutes,
    maxMinutes: clampNum(c.maxMinutes, 1, 43200, 43200),
    requireAdminCaller: c.requireAdminCaller !== false,
    allowKick: c.allowKick !== false,
    announce: c.announceActions !== false,
    dryRun: c.dryRun === true
  };
}

/**
 * 统一前置校验：必须是群聊、必须有群号、必须能确认「谁是下指令的人」且他有权限。
 *
 * @param {object} ctx         工具上下文（核心给的，**没有**本轮发言人信息）
 * @param {string} callerIdArg 模型从聊天记录里看到并回传的"下指令者 QQ 号"（可选）
 *
 * 判定顺序（拿到就不再往后走）：
 *   ① 本轮**明确 @ 了机器人**的发言者中有管理员/群主 → 放行（最准，不依赖模型）
 *   ② 模型回传的 caller_id（会真去查身份，伪造一个管理员 QQ 是没用的）
 *   ③ 本批最后一位发言人（兜底：机器人被叫到时通常就是他）
 * 都拿不到 → 返回**可操作**的提示（让模型告诉用户"@ 一下我"），而不是原来那句
 * 「无法确认下指令的人是谁（拿不到 QQ 号）」让模型原地打转。
 */
async function needGroup(ctx, callerIdArg) {
  const kind = String(ctx?.kind || '');
  const groupId = String(ctx?.chatId || '');
  if (kind !== 'group') return { error: '这个操作只能在群里做（当前会话不是群聊）。' };
  if (!/^\d+$/.test(groupId)) return { error: '拿不到当前群号，无法执行群管理操作。' };

  const s = settings();
  if (s.requireAdminCaller) {
    const self = selfId(ctx);
    const captured = readCallerLog(ctx);
    const atBot = captured.filter((c) => c.isAdmin && c.id !== self).map((c) => c.id);
    const speakers = captured.filter((c) => c.id !== self).map((c) => c.id);
    const lastSpeaker = speakers.length ? speakers[speakers.length - 1] : '';

    let role = await safeBestRole(ctx, groupId, atBot);
    let source = '被 @ 的发言人';

    if (role !== 'owner' && role !== 'admin') {
      const explicit = qqOf(callerIdArg);
      if (explicit && explicit !== self) {
        role = await safeRole(ctx, groupId, explicit);
        source = '模型回传的 caller_id';
        if (role === 'owner' || role === 'admin') rememberCaller(ctx, explicit, true);
      }
    }
    if (role !== 'owner' && role !== 'admin' && lastSpeaker) {
      role = await safeRole(ctx, groupId, lastSpeaker);
      source = '本批最后一位发言人';
    }

    if (role !== 'owner' && role !== 'admin') {
      const explicit = qqOf(callerIdArg);
      if (explicit) {
        return { error: `${explicit} 在本群既不是群主也不是管理员，我不能听他的去禁言/踢人。`
          + '如果确实是管理员在指挥，请让他在消息里 @ 我一下再下指令。' };
      }
      return {
        error: '我需要先确认是谁在下指令：请让下指令的群主/管理员**在消息里 @ 一下我**'
          + '（或在指令里说明自己的 QQ 号，例如「禁言 30003 十分钟 —— 我是 40004」），我马上执行。'
          + '这一步不能省：否则任何群友都能借我的手去禁言别人。'
      };
    }
    log(`指令来源已确认（依据：${source}，身份：${role}）`);
  }
  return { groupId, chatKey: String(ctx.chatKey || `${kind}:${groupId}`) };
}

/**
 * 钩子（before-tool）记下的候选；顺序即优先级，过期的自动丢弃。
 *
 * 为什么必须有这个"记忆区"：核心交给**工具**的 ctx 里没有本轮发言人信息
 * （只有 chatKey/kind/chatId/onebot/sender/session…），而 before-tool 钩子的
 * 上下文里有 triggerEntries。钩子紧贴在工具执行之前跑，所以把候选存在这里、
 * 工具执行时读出来，就能精确知道"这句话是谁说的"。
 */
function readCallerLog(ctx) {
  const key = storeKey(ctx);
  if (!key) return [];
  const rec = callerLog.get(key);
  if (!rec) return [];
  if (Date.now() - (rec.at || 0) > CALLER_TTL_MS) {
    callerLog.delete(key);
    return [];
  }
  return Array.isArray(rec.candidates) ? rec.candidates : [];
}

/** 把某个 QQ 记为"已确认的下指令者"，供同一会话的后续工具调用复用。 */
function rememberCaller(ctx, id, isAdmin) {
  const key = storeKey(ctx);
  const qq = qqOf(id);
  if (!key || !qq) return;
  const rec = callerLog.get(key) || { candidates: [], at: Date.now() };
  if (!rec.candidates.some((c) => c.id === qq)) rec.candidates.push({ id: qq, isAdmin: Boolean(isAdmin) });
  rec.at = Date.now();
  callerLog.set(key, rec);
}

/** bestRole 的安全壳：查询出错时当作"没权限"，不让异常打断工具。 */
async function safeBestRole(ctx, groupId, ids) {
  if (!Array.isArray(ids) || !ids.length) return 'member';
  try { return await bestRole(ctx, groupId, ids); } catch { return 'member'; }
}

async function safeRole(ctx, groupId, id) {
  const qq = qqOf(id);
  if (!qq) return 'member';
  return safeBestRole(ctx, groupId, [qq]);
}

/** 在候选里找出权限最高的身份（owner > admin > member），带 5 分钟缓存。 */
async function bestRole(ctx, groupId, candidates) {
  const list = candidates
    .map((id) => ({ id, cached: roleCache.get(`${groupId}:${id}`) }))
    .map((x) => (x.cached && Date.now() - x.cached.checkedAt < ROLE_CACHE_MS ? { id: x.id, role: x.cached.role } : null))
    .filter(Boolean);
  for (const hit of list) {
    if (hit.role === 'owner') return 'owner';
    if (hit.role === 'admin') return 'admin';
  }
  const missing = candidates.filter((id) => !list.some((h) => h.id === id));
  const roles = await Promise.all(missing.map(async (id) => {
    const role = roleOf(await memberInfo(ctx, groupId, id));
    roleCache.set(`${groupId}:${id}`, { role, checkedAt: Date.now() });
    return role;
  }));
  const all = [...list.map((h) => h.role), ...roles];
  if (all.includes('owner')) return 'owner';
  if (all.includes('admin')) return 'admin';
  return all.includes('member') ? 'member' : 'unknown';
}

/**
 * 机器人自己的 QQ 号。
 * 优先用核心给的 ctx.selfId，拿不到就退回 onebot 自己的字段 —— 只认 ctx.selfId
 * 会在"selfId 为空"的路径上把权限校验判成失败（表现为所有工具都拒绝执行）。
 */
function selfId(ctx) {
  const candidates = [ctx?.selfId, ctx?.onebot?.selfId, ctx?.onebot?.selfInfo?.user_id];
  for (const c of candidates) {
    const id = qqOf(c);
    if (id) return id;
  }
  return '';
}

async function memberInfo(ctx, groupId, userId) {
  try {
    const info = await ctx.onebot.call('get_group_member_info', {
      group_id: Number(groupId),
      user_id: Number(userId),
      no_cache: true
    });
    return info && typeof info === 'object' ? info : null;
  } catch (error) {
    warn(`查成员信息失败（${groupId}/${userId}）：${describeError(error)}`);
    return null;
  }
}

async function myMemberRole(ctx, groupId) {
  const me = selfId(ctx);
  if (!me) return 'unknown';
  const key = `${groupId}:${me}`;
  const cached = roleCache.get(key);
  if (cached && Date.now() - cached.checkedAt < ROLE_CACHE_MS) return cached.role;
  const role = roleOf(await memberInfo(ctx, groupId, me));
  roleCache.set(key, { role, checkedAt: Date.now() });
  if (roleCache.size > ROLE_CACHE_MAX) {
    roleCache.delete(roleCache.keys().next().value);
  }
  return role;
}

function roleOf(info) {
  if (!info) return 'unknown';
  const role = String(info?.role ?? info?.member_role ?? '').toLowerCase();
  if (role === 'owner' || role === 'admin' || role === 'member') return role;
  return 'unknown';
}

function roleLabel(role) {
  if (role === 'owner') return '【群主】';
  if (role === 'admin') return '【管理员】';
  if (role === 'member') return '';
  return '【身份未知】';
}

function describeTarget(info, userId) {
  const name = String(info?.card || info?.nickname || '').trim();
  return name ? `${name}(QQ:${userId})` : `QQ:${userId}`;
}

/** 清除自动守卫插件里的违规统计；返回原有次数，插件没提供能力时返回 null。 */
function clearOffenses(groupId, userId) {
  try {
    // 软依赖：自动守卫是可选的，没装/被关掉也得能正常报错而不是崩掉
    // （api.capability 的约定：有能力就调用，没有就静默返回 undefined）
    if (process.env.QQAGENT_DEBUG === '1') {
      log(`[DEBUG-clear] capability=${typeof api?.capability} has=${typeof api?.hasCapability === 'function' ? api.hasCapability('moderation.violation-log') : 'n/a'}`);
    }
    if (typeof api?.capability !== 'function') return null;
    if (typeof api.hasCapability === 'function' && !api.hasCapability('moderation.violation-log')) return null;
    const before = api.capability('moderation.violation-log', { groupId, userId });
    if (!before || before.ok !== true) return null;
    const cleared = api.capability('moderation.violation-log', { groupId, userId, action: 'clear' });
    if (!cleared || cleared.ok !== true) return null;
    return Number(before.times) || 0;
  } catch (error) {
    warn(`清除违规记录失败：${describeError(error)}`);
    return null;
  }
}

/** 群里说一句（可 @ 人）。失败只记日志 —— 处理动作本身已经成功，不该因为它报错。 */
async function announce(ctx, chatKey, text, atUserId = null) {
  try {
    if (!text || !ctx?.sender?.sendTextBatch || !chatKey) return;
    // ⚠️ @ 只能走 atUserId 选项：正文里的 [CQ:at,...] 会被 escapeCqText 转义成
    //    字面文本（群里看到的是一串 CQ 码），这是本项目里 @ 人的唯一正确姿势。
    await ctx.sender.sendTextBatch(chatKey, [text], atUserId ? { atUserId: String(atUserId) } : {});
  } catch (error) {
    warn(`发群内通告失败：${describeError(error)}`);
  }
}

function clampNum(value, min, max, fallback) {
  const n = Number(value);
  if (!Number.isFinite(n)) return fallback;
  return Math.max(min, Math.min(max, n));
}

function qqOf(value) {
  const s = String(value ?? '').trim();
  return /^\d{5,15}$/.test(s) ? s : '';
}

function humanMinutes(seconds) {
  const m = Math.max(1, Math.round(Number(seconds) / 60));
  if (m < 60) return `${m} 分钟`;
  const h = Math.floor(m / 60);
  const rest = m % 60;
  if (h < 24) return rest ? `${h} 小时 ${rest} 分钟` : `${h} 小时`;
  const d = Math.floor(h / 24);
  const restH = h % 24;
  return restH ? `${d} 天 ${restH} 小时` : `${d} 天`;
}

function describeError(error) {
  return String(error?.message || error || '未知错误');
}

/** 把协议端错误翻成人话（群里/模型看得懂的那种）。 */
function humanizeError(error) {
  const text = describeError(error);
  if (/timeout|timed out|超时/i.test(text)) return '接口超时了（QQ 侧没在时限内响应）';
  if (/permission|forbidden|权限|not enough|no permission/i.test(text)) return '机器人权限不够';
  if (/network|fetch failed|ECONNREFUSED|ENOTFOUND/i.test(text)) return '连不上协议端';
  if (/retcode/i.test(text)) return 'QQ 拒绝了这次操作';
  return text.slice(0, 120);
}

function permissionHint(error) {
  const text = describeError(error);
  if (/permission|forbidden|权限|retcode/i.test(text)) {
    return '请确认：① 机器人是本群管理员；② 目标不是群主/管理员；③ 操作的是本群成员。';
  }
  return '';
}
