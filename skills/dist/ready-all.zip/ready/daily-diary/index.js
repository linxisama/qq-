// 每日日记（LLM 型 / skills/）
//
// ── 它做什么 ──────────────────────────────────────────────────────────────
// 把某一天的聊天记录整理成一篇日记，存到 data/daily-diary/YYYY-MM-DD.md；
// 第二天这篇日记会自动出现在私聊的提示词里，让机器人"记得昨天发生过什么"。
//
// ── 为什么是技能而不是插件 ────────────────────────────────────────────────
// 项目把扩展分两型（README「扩展」/ src/skills/manifest.js 的 DIR_KIND）：
//   skills/  = LLM 型：注册工具，什么时候用**由模型判断**
//   plugins/ = 确定性型：定时器/钩子/能力，条件满足必然执行
// 最早它是按"每天 23:00 自动写"做的插件（靠定时器）。现在改成**你说写才写** ——
// 触发权交回模型，正是技能的形态；留在 plugins/ 里会变成"没有任何代码会调用它"，
// 而且定时器留着还会背着你写，所以整体搬到 skills/ 并删掉了定时器。
//
// ── 和写日记有关的几个取舍 ────────────────────────────────────────────────
//   · 工具只有两个：write_diary（写）和 read_diary（翻）。没有"到点自动写"。
//   · 写哪一天由参数决定，不传就是今天；写今天时只取到"此刻"，不会把半夜的算进去；
//     写过去的日期则取完整一天。
//   · 消息多时先分段提炼再合并，段数有上限（maxChunks），成本可控。
//   · 默认只把日记注入**私聊**：日记里有各个群的事，注入群聊等于把别处的内容讲给
//     这个群听。要改可以用设置里的 inject。
//   · 所有裁剪都走 clipSafe：宁可少一个字，也不能把 emoji 切成半个（半个 emoji
//     会让上游 JSON 解析直接 400，见 plugins/unicode-guard 的注释）。

import fs from 'node:fs';
import path from 'node:path';
import { DATA_DIR } from '../../src/config.js';
import { chatCompletion } from '../../src/llm.js';

const DIARY_DIR = path.join(DATA_DIR, 'daily-diary');
const MESSAGES_DIR = path.join(DATA_DIR, 'messages');
const NAMES_FILE = path.join(DATA_DIR, 'group-names.json');

const DEFAULTS = {
  enabled: true,
  maxMessages: 800,
  maxInputChars: 8000,
  maxChunks: 4,
  diaryMaxChars: 500,
  inject: 'private',
  maxInjectChars: 600,
  keepDays: 90
};

let api = null;
let log = () => {};
let warn = () => {};

// ── 小工具 ────────────────────────────────────────────────────────────────

const pad2 = (n) => String(n).padStart(2, '0');
const dayKey = (d = new Date()) => `${d.getFullYear()}-${pad2(d.getMonth() + 1)}-${pad2(d.getDate())}`;
const clock = (d) => `${pad2(d.getHours())}:${pad2(d.getMinutes())}`;

/** 截断到 max 个 UTF-16 单元，且不留下半个 emoji。 */
function clipSafe(text, max) {
  const t = String(text ?? '');
  if (t.length <= max) return t;
  let cut = t.slice(0, max);
  if (/[\uD800-\uDBFF]$/.test(cut)) cut = cut.slice(0, -1);
  return cut;
}

function num(value, min, max, fallback) {
  const n = Number(value);
  if (!Number.isFinite(n)) return fallback;
  return Math.min(max, Math.max(min, Math.round(n)));
}

function settings() {
  const raw = (typeof api?.config === 'function' ? api.config() : null) || {};
  const inject = ['private', 'all', 'off'].includes(String(raw.inject)) ? String(raw.inject) : DEFAULTS.inject;
  return {
    enabled: raw.enabled !== false,
    maxMessages: num(raw.maxMessages, 100, 3000, DEFAULTS.maxMessages),
    maxInputChars: num(raw.maxInputChars, 2000, 20000, DEFAULTS.maxInputChars),
    maxChunks: num(raw.maxChunks, 1, 8, DEFAULTS.maxChunks),
    diaryMaxChars: num(raw.diaryMaxChars, 150, 1200, DEFAULTS.diaryMaxChars),
    inject,
    maxInjectChars: num(raw.maxInjectChars, 200, 2000, DEFAULTS.maxInjectChars),
    keepDays: num(raw.keepDays, 7, 3650, DEFAULTS.keepDays)
  };
}

// ── 读某一天的消息 ────────────────────────────────────────────────────────

function loadChatNames() {
  try {
    const parsed = JSON.parse(fs.readFileSync(NAMES_FILE, 'utf8'));
    return parsed && typeof parsed === 'object' ? parsed : {};
  } catch { return {}; }
}

/**
 * 收集某一天的消息，按时间排序。
 * @param {string} day  YYYY-MM-DD
 * @param {object} s    设置
 * @param {number|null} until  截止时间戳（写"今天"时传当前时刻；写过去的日子传 null = 整天）
 */
export function gatherRowsForDay(day, s = settings(), until = null) {
  const start = new Date(`${day}T00:00:00`).getTime();
  if (!Number.isFinite(start)) return [];
  const endTs = Number.isFinite(Number(until)) && until ? Number(until) : start + 86400000 - 1;
  const names = loadChatNames();

  let files = [];
  try { files = fs.readdirSync(MESSAGES_DIR); } catch { return []; }

  const rows = [];
  for (const file of files) {
    const m = /^(group|private)_(\d+)\.json$/.exec(file);
    if (!m) continue;
    const chatKey = `${m[1]}:${m[2]}`;
    let data = null;
    try { data = JSON.parse(fs.readFileSync(path.join(MESSAGES_DIR, file), 'utf8')); } catch { continue; }
    const chatName = String(names[chatKey] || (m[1] === 'group' ? `群${m[2]}` : '私聊')).trim();
    for (const msg of Array.isArray(data?.messages) ? data.messages : []) {
      const ts = Number(msg?.ts) || 0;
      if (ts < start || ts > endTs) continue;
      const text = String(msg?.text ?? '').trim();
      if (!text) continue;
      rows.push({
        ts,
        chatKey,
        chatName,
        self: msg?.self === true,
        sender: String(msg?.senderName || (msg?.self ? '我' : '某人')).trim(),
        text: clipSafe(text, 300)
      });
    }
  }
  rows.sort((a, b) => a.ts - b.ts);
  return rows.length > s.maxMessages ? rows.slice(rows.length - s.maxMessages) : rows;
}

/** 把行渲染成紧凑的记录文本。 */
export function renderRows(rows) {
  return rows.map((r) => {
    const d = new Date(r.ts);
    return `[${clock(d)}] ${r.chatName} ${r.self ? '我' : r.sender}：${r.text}`;
  }).join('\n');
}

/** 按字符上限切段（不切坏 emoji）。 */
export function chunkText(text, maxChars) {
  const lines = String(text || '').split('\n');
  const chunks = [];
  let cur = '';
  for (const line of lines) {
    if (cur && cur.length + line.length + 1 > maxChars) {
      chunks.push(cur);
      cur = '';
    }
    cur = cur ? `${cur}\n${line}` : line;
    while (cur.length > maxChars) {
      const piece = clipSafe(cur, maxChars);
      chunks.push(piece);
      cur = cur.slice(piece.length);
    }
  }
  if (cur) chunks.push(cur);
  return chunks.filter(Boolean);
}

// ── 调模型 ────────────────────────────────────────────────────────────────

async function callModel(messages, maxTokens) {
  const controller = new AbortController();
  const timerId = setTimeout(() => controller.abort(new Error('日记整理超时')), 150000);
  timerId.unref?.();
  try {
    const res = await chatCompletion({
      messages,
      temperature: 0.5,
      maxTokens,
      signal: controller.signal,
      // 日记是归纳任务，不需要思考链，否则预算可能全烧在 reasoning 上
      skillContext: { thinkingMode: 'off', chatKey: '', dailyDiary: true }
    });
    return String(res?.message?.content ?? '').trim();
  } finally {
    clearTimeout(timerId);
  }
}

function stripDecorations(text) {
  let t = String(text || '').trim();
  t = t.replace(/^```[a-z]*\n?/i, '').replace(/```$/, '').trim();
  t = t.replace(/^(日记|今日日记)\s*[：:]\s*/, '');
  return t.trim();
}

async function summarizeChunk(chunk, index, total) {
  const messages = [
    {
      role: 'system',
      content: '你在帮一个 QQ 机器人整理聊天记录。只根据给定内容提炼事实：谁跟谁、聊了什么、有没有待办或没聊完的事。不要评价、不要编造、不要写“这段记录”之类的元话。'
    },
    {
      role: 'user',
      content: `这是当天聊天记录的第 ${index}/${total} 段。用 3~6 条要点写出发生了什么：\n\n${chunk}`
    }
  ];
  const text = await callModel(messages, 400);
  return text || `（第 ${index} 段没有提炼出内容）`;
}

async function composeDiary({ day, rows, chunks, s }) {
  const chatCount = new Set(rows.map((r) => r.chatKey)).size;
  const span = rows.length ? `${clock(new Date(rows[0].ts))}–${clock(new Date(rows[rows.length - 1].ts))}` : '';

  let material;
  if (chunks.length === 1) {
    material = `聊天记录：\n${chunks[0]}`;
  } else {
    const parts = [];
    for (let i = 0; i < chunks.length; i++) {
      parts.push(await summarizeChunk(chunks[i], i + 1, chunks.length));
      await new Promise((r) => setTimeout(r, 300));
    }
    material = `分段提炼：\n${parts.join('\n\n')}`;
  }

  const messages = [
    {
      role: 'system',
      content: '你在给一个 QQ 机器人写它自己的日记，供它以后回忆。只写记录里真实出现过的内容，不知道的不要补；不要逐条复述，按事件/主题归并；不要用 Markdown 标题和列表符号；提到人用昵称。'
    },
    {
      role: 'user',
      content: `日期：${day}。共 ${rows.length} 条消息，来自 ${chatCount} 个会话${span ? `，时间跨度 ${span}` : ''}。\n${material}\n\n请用第一人称写成一篇 ${s.diaryMaxChars} 字以内的日记，像自己回顾这一天：发生了什么、谁说了什么有意思的、有什么没聊完或值得记住的事。`
    }
  ];
  const text = stripDecorations(await callModel(messages, Math.round(s.diaryMaxChars * 2 + 200)));
  return { text, chatCount };
}

// ── 写文件 ────────────────────────────────────────────────────────────────

function diaryPath(day) {
  return path.join(DIARY_DIR, `${day}.md`);
}

function saveDiary(day, { text, rows, chatCount, now }) {
  fs.mkdirSync(DIARY_DIR, { recursive: true });
  const header = `# ${day} 日记\n> 生成于 ${clock(now)} · ${rows.length} 条消息 · ${chatCount} 个会话\n\n`;
  const file = diaryPath(day);
  const tmp = `${file}.tmp`;
  fs.writeFileSync(tmp, header + text + '\n', 'utf8');
  fs.renameSync(tmp, file);
  return file;
}

function listDiaries() {
  try {
    return fs.readdirSync(DIARY_DIR)
      .map((f) => /^(\d{4}-\d{2}-\d{2})\.md$/.exec(f))
      .filter(Boolean)
      .map((m) => m[1])
      .sort();
  } catch { return []; }
}

/** 读取某天的日记正文（去掉标题头）。 */
export function readDiary(day) {
  try {
    const raw = fs.readFileSync(diaryPath(day), 'utf8');
    const lines = raw.split(/\r?\n/);
    let i = 0;
    if (lines[0]?.startsWith('# ')) i = 1;
    if (lines[i]?.startsWith('> ')) i += 1;
    return { found: true, day, text: lines.slice(i).join('\n').trim() };
  } catch {
    return { found: false, day, text: '' };
  }
}

function pruneOld(keepDays, now) {
  const cutoff = now.getTime() - keepDays * 86400000;
  for (const day of listDiaries()) {
    const ts = new Date(`${day}T00:00:00`).getTime();
    if (Number.isFinite(ts) && ts < cutoff) {
      try { fs.unlinkSync(diaryPath(day)); } catch { /* ignore */ }
    }
  }
}

/** 手动写某一天的日记（工具与测试共用）。 */
export async function writeDiary({ day, s = settings(), now = new Date() } = {}) {
  const targetDay = day || dayKey(now);
  const isToday = targetDay === dayKey(now);
  const rows = gatherRowsForDay(targetDay, s, isToday ? now.getTime() : null);
  if (!rows.length) {
    return { ok: false, reason: `${targetDay} 没有任何消息，没什么可写的` };
  }

  const transcript = renderRows(rows);
  let chunks = chunkText(transcript, s.maxInputChars);
  if (chunks.length > s.maxChunks) {
    const head = chunks.slice(0, s.maxChunks - 1);
    const tail = chunks.slice(s.maxChunks - 1).join('\n');
    chunks = [...head, clipSafe(tail, s.maxInputChars * 2) + '\n…（后面还有消息，已省略）'];
  }

  log(`开始写 ${targetDay} 的日记：${rows.length} 条消息，${chunks.length} 段`);
  const { text, chatCount } = await composeDiary({ day: targetDay, rows, chunks, s });
  if (!text) return { ok: false, reason: '模型没有返回日记内容' };

  const file = saveDiary(targetDay, { text: clipSafe(text, s.diaryMaxChars * 2), rows, chatCount, now });
  pruneOld(s.keepDays, now);
  log(`日记已写入：${file}（${rows.length} 条消息 / ${chatCount} 个会话）`);
  return { ok: true, day: targetDay, file, rows: rows.length, chatCount, text };
}

// ── 生命周期 ──────────────────────────────────────────────────────────────

export function setup(a = {}) {
  api = a;
  log = (...args) => { try { a.log?.(...args); } catch { /* ignore */ } };
  warn = (...args) => { try { a.warn?.(...args); } catch { /* ignore */ } };

  // 工具一：写日记（手动触发）
  a.registerTool?.({
    id: 'write_diary',
    name: '写聊天日记',
    category: 'knowledge',
    icon: '📝',
    description:
      '把某一天的聊天记录整理成一篇日记存到本地。**只在群友明确要求时调用**（「写个日记」「记一下今天」「把今天的事整理成日记」「补写昨天的日记」）；'
      + '没人要求时不要主动写，也不要每天定时写。date 不传 = 今天；补写过去某天就传 YYYY-MM-DD。'
      + '写完会把结果存到本地并回一句简短确认；不要在国家/会话里贴出整篇日记，除非对方明确要看。',
    parameters: {
      type: 'object',
      properties: {
        date: { type: 'string', description: '要写的日期 YYYY-MM-DD；不传 = 今天；也可以传 yesterday' }
      }
    },
    async execute(_ctx, args = {}) {
      try {
        const raw = String(args.date ?? '').trim();
        let day;
        if (!raw) day = dayKey(new Date());
        else if (raw === 'today') day = dayKey(new Date());
        else if (raw === 'yesterday') day = dayKey(new Date(Date.now() - 86400000));
        else if (/^\d{4}-\d{2}-\d{2}$/.test(raw)) day = raw;
        else return { content: `日期格式不对：${raw}。请传 YYYY-MM-DD / today / yesterday，或留空（今天）。`, isError: true };

        const s = settings();
        if (!s.enabled) return { content: '「每日日记」在设置里被关掉了，写不了。', isError: true };

        const r = await writeDiary({ day, s });
        if (!r.ok) return { content: r.reason || '写日记失败', isError: true };

        return {
          content: `已经写好 ${r.day} 的日记（${r.rows} 条消息 / ${r.chatCount} 个会话），存在本地。开头是：${clipSafe(r.text, 120)}…\n（对方要看全文再用 read_diary 翻。）`,
          isError: false
        };
      } catch (error) {
        const msg = String(error?.message ?? error);
        warn(`写日记失败：${msg}`);
        return { content: `写日记失败：${msg}`, isError: true };
      }
    }
  });

  // 工具二：翻日记
  a.registerTool?.({
    id: 'read_diary',
    name: '翻日记',
    category: 'knowledge',
    icon: '📔',
    description: '查看某一天的聊天日记（由 write_diary 生成）。date 传 YYYY-MM-DD；不传默认昨天；也可以传 today / yesterday。',
    parameters: {
      type: 'object',
      properties: {
        date: { type: 'string', description: '要查的日期，YYYY-MM-DD；不传默认昨天；today / yesterday 也认' }
      }
    },
    async execute(_ctx, args = {}) {
      try {
        const raw = String(args.date ?? '').trim();
        let day;
        if (!raw) day = dayKey(new Date(Date.now() - 86400000));
        else if (raw === 'today') day = dayKey(new Date());
        else if (raw === 'yesterday') day = dayKey(new Date(Date.now() - 86400000));
        else if (/^\d{4}-\d{2}-\d{2}$/.test(raw)) day = raw;
        else return { content: `日期格式不对：${raw}。请传 YYYY-MM-DD，或不传（默认昨天）。`, isError: true };

        const r = readDiary(day);
        if (r.found) return { content: `【${day} 的日记】\n${clipSafe(r.text, 4000)}`, isError: false };

        const all = listDiaries();
        const tail = all.slice(-7).reverse().join('、');
        return {
          content: `${day} 没有日记。${all.length ? `最近写过的日期：${tail}` : '还没有写过任何日记。'}`,
          isError: true
        };
      } catch (error) {
        return { content: `读日记失败：${error?.message ?? error}`, isError: true };
      }
    }
  });

  log('每日日记已加载：写日记改为手动触发（工具 write_diary / read_diary 已注册）');
}

/**
 * 动态提示词片段：把昨天的日记接进系统提示词。
 * 默认只注入私聊 —— 日记里是各个群的事，注入群聊等于把别处的内容讲给这个群听。
 */
export function promptSections(ctx = {}) {
  try {
    const s = settings();
    if (!s.enabled || s.inject === 'off') return [];
    const kind = String(ctx?.kind || '');
    if (s.inject === 'private' && kind !== 'private') return [];

    const day = dayKey(new Date(Date.now() - 86400000));
    const r = readDiary(day);
    if (!r.found) return [];
    const text = clipSafe(r.text, s.maxInjectChars);
    if (!text.trim()) return [];

    return [{
      id: 'daily-diary',
      title: '',
      priority: 65,
      content: `【昨天的日记（${day}）】\n${text}\n（这是你自己记下的，回忆或接话时可以参考，不要逐句复述。）`
    }];
  } catch { return []; }
}

export function available() {
  return true;
}

export function dispose() {
  api = null;
  log = () => {};
  warn = () => {};
}

export const internals = {
  settings, gatherRowsForDay, renderRows, chunkText, readDiary, listDiaries,
  dayKey, clock, clipSafe, composeDiary, writeDiary
};
