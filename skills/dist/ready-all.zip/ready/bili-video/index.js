// 「看B站视频」—— 把 B站链接的视频下载并抽帧，交给模型看画面
//
// ── 为什么需要它 ────────────────────────────────────────────────────────
// 应用内置的 read_video 只认「消息里带视频媒体段」的视频（QQ 视频消息）。
// 群友/好友往往只发一条 B站 链接，这时 read_video 用不了；模型只能去 web_fetch
// 抓 B站 页面，而那是脚本渲染的页面，抓回来是乱码/无正文 —— 表现就是
// 「标题认出来了，画面一个字都没给我」。本 Skill 补上这条路。
//
// ── 怎么做 ──────────────────────────────────────────────────────────────
// 注册一个工具（LLM 型：由模型决定何时调用，见应用 README 的扩展两型说明）：
//   bili-video__read
//     1. 校验链接（**严格域名白名单**：bilibili.com / b23.tv / bili2233.cn）
//     2. yt-dlp 下载「只要画面」的流到一个临时文件（有 时长/体积 上限）
//     3. ffmpeg 均匀抽 N 帧 → JPEG data URL
//     4. 按应用的媒体契约返回：
//          { content: [ {type:'text'}, {type:'image_url', image_url:{url}} ... ] }
//        orchestrator 会把图片部分作为一条 user 消息补发给模型（orchestrator.js:1175）
//     5. **无论成功失败都删除**临时视频与帧文件（finally）
//
// ── 关于 B站 PCDN（踩过的坑，2026-10）────────────────────────────────────
// B站 会把部分流（尤其 1080p）交给 PCDN 节点分发，域名形如
//   xy116x196x129x37xy.mcdn.bilivideo.cn:8082
// （主机名里那串数字就是节点 IP 的编码）。这些节点从某些网络**完全连不通**，表现为
// yt-dlp 报 "Read timed out" / "RemoteDisconnected('Remote end closed connection')"
// 然后反复重试直到超时 —— 机器人侧看到的就是「读取失败：yt-dlp 下载出错」。
//
// 实测对照（同一个视频，同一台机器）：
//   1080p avc1  → 卡死 10 分钟无进展
//   720p  avc1  → 25.87MB / 8.54MB/s / 3 秒下完
//   360p        → 5.91MB / 2.36MB/s / 2 秒下完
// 说明不是网络不通，而是**高清流落在坏节点上**。而抽帧会把画面缩到 768px 宽，
// 720p 对观看毫无损失 —— 于是默认压到 720p 并逐级降级（见 runTool 里的 ladder）。
//
// ── 能看什么（2026-10 扩展）─────────────────────────────────────────────
//   文字  标题 / UP / 时长 / 播放·弹幕·点赞·评论数 / **简介** / **分P列表** / **章节标题**
//   画面  按固定间隔逐张抽帧（默认每 5 秒一张，长视频自动放宽间隔以控制 token）
//         ＋ **封面**（官方缩放后缀，几十 KB）
//   弹幕  comment.bilibili.com 的 XML 弹幕池（免登录）：总量 + 刷屏高频 + 每个采样时刻
//         附近在刷什么 —— 弹幕经常就是"这一刻画面上发生了什么"的最好注解
//   评论  x/v2/reply/main（热门排序）前若干条，带点赞数
//   字幕  player/v2 → subtitle_url（**实测匿名拿不到轨道**，填了 Cookie 才有）
//   兜底  视频下不下来时（PCDN 等）不再直接报错，改给「封面 + 章节图 + 全部文字」——
//         这条兜底的依据是实测：带章节的视频能拿到每章一张官方配图
//
// ── 安全边界 ────────────────────────────────────────────────────────────
//   · 域名白名单 → 杜绝「让机器人去下载内网地址」的 SSRF 路径
//   · 用 spawn(命令, 参数数组) 而非 shell → 无命令注入
//   · 时长/体积上限 + 超时 → 防单条消息吃满磁盘/时间
//   · 临时文件一律即时清理（另有一个每小时的计划任务兜底清 video-cache）
//
// 依赖：yt-dlp（下载）与 ffmpeg/ffprobe（抽帧）。两者都可只放 PATH，
//       或在本插件的设置里显式填写路径。

import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { spawn } from 'node:child_process';

/** 只允许这些域名（含其子域），其它一律拒绝 —— 这是本插件最重要的安全约束。 */
const ALLOWED_HOST_SUFFIXES = ['bilibili.com', 'b23.tv', 'bili2233.cn'];

/** 自动探测候选路径（用户机器上实际安装的位置；可用设置项覆盖）。 */
const FALLBACK_YTDLP = ['D:\\Tools\\yt-dlp\\yt-dlp.exe'];
const FALLBACK_FFMPEG_DIRS = ['D:\\Tools\\ffmpeg\\bin'];

let cfg = () => ({});
let api = null;

// ── 小工具 ──────────────────────────────────────────────────────────────

/** 跑一个外部命令，收集 stdout（失败/超时返回 null，绝不抛）。 */
function run(cmd, args, timeoutMs = 60000) {
  return new Promise((resolve) => {
    let out = '';
    let err = '';
    let done = false;
    const finish = (v) => { if (!done) { done = true; resolve(v); } };
    let child;
    try {
      child = spawn(cmd, args, { stdio: ['ignore', 'pipe', 'pipe'], windowsHide: true });
    } catch {
      return finish(null);
    }
    const timer = setTimeout(() => { try { child.kill(); } catch { /* ignore */ } finish(null); }, timeoutMs);
    child.stdout.on('data', (d) => { out += d; });
    child.stderr.on('data', (d) => { err += d; });
    child.on('error', () => { clearTimeout(timer); finish(null); });
    child.on('close', (code) => {
      clearTimeout(timer);
      finish({ code, stdout: out, stderr: err });
    });
  });
}

/** 命令是否可直接执行（探测用）。 */
async function usable(cmd) {
  const r = await run(cmd, ['-version'], 8000);
  return Boolean(r && r.code === 0);
}

function firstExisting(paths) {
  for (const p of paths) {
    try { if (p && fs.existsSync(p)) return p; } catch { /* ignore */ }
  }
  return null;
}

/** 定位 yt-dlp：设置 > PATH > 已知位置。 */
async function findYtDlp() {
  const custom = String(cfg()?.ytDlpPath || '').trim();
  if (custom) return fs.existsSync(custom) ? custom : null;
  for (const name of ['yt-dlp', 'yt-dlp.exe']) {
    if (await usable(name)) return name;
  }
  return firstExisting(FALLBACK_YTDLP);
}

/** 定位 ffmpeg / ffprobe：设置里的目录 > PATH > 已知目录。返回可执行名或全路径。 */
async function findFf() {
  const customDir = String(cfg()?.ffmpegPath || '').trim();
  const dirs = customDir ? [customDir] : [];
  for (const name of ['ffmpeg', 'ffmpeg.exe']) if (await usable(name)) {
    return { ffmpeg: name, ffprobe: (await usable('ffprobe')) ? 'ffprobe' : 'ffprobe.exe' };
  }
  for (const d of [...dirs, ...FALLBACK_FFMPEG_DIRS]) {
    const ff = path.join(d, 'ffmpeg.exe');
    const fp = path.join(d, 'ffprobe.exe');
    if (fs.existsSync(ff) && fs.existsSync(fp)) return { ffmpeg: ff, ffprobe: fp };
  }
  return { ffmpeg: null, ffprobe: null };
}

/** 临时目录：优先复用应用的 data/video-cache（已有的每小时清理任务会兜底），否则系统临时目录。 */
function tempDir() {
  const dataDir = String(process.env.QQ_AGENT_DATA_DIR || '').trim();
  const base = dataDir ? path.join(dataDir, 'video-cache') : path.join(os.tmpdir(), 'qq-agent-video');
  try { fs.mkdirSync(base, { recursive: true }); return base; } catch { return os.tmpdir(); }
}

/** 校验链接是否属于白名单域名。返回 { ok, url } 或 { ok:false, reason }。 */
function checkUrl(raw) {
  const s = String(raw || '').trim();
  if (!s) return { ok: false, reason: '没有拿到链接' };
  let u;
  try { u = new URL(s); } catch { return { ok: false, reason: `不是合法的链接：${s}` }; }
  if (u.protocol !== 'http:' && u.protocol !== 'https:') return { ok: false, reason: '只接受 http/https 链接' };
  const host = u.hostname.toLowerCase();
  const hit = ALLOWED_HOST_SUFFIXES.some((d) => host === d || host.endsWith(`.${d}`));
  if (!hit) return { ok: false, reason: `只接受 B站 链接（bilibili.com / b23.tv），收到的是 ${host}` };
  return { ok: true, url: u.toString() };
}

/** 从一段文本里抠出第一个 B站 链接。 */
function pickUrl(text) {
  const m = String(text || '').match(/https?:\/\/[^\s"'<>）)】]+/g) || [];
  for (const candidate of m) {
    const r = checkUrl(candidate.replace(/[.,;，。;]+$/, ''));
    if (r.ok) return r.url;
  }
  return null;
}

// ── B站 数据接口（三个，2026-10 全部实测通过）───────────────────────────
//   1. x/web-interface/view?bvid=      视频信息（cid / aid / 标题 / 时长 / 播放弹幕评论数）
//   2. comment.bilibili.com/<cid>.xml  弹幕池（**无需登录**，实测 116 秒视频返回 168 条）
//   3. x/v2/reply/main?mode=3          热评 20 条
//      ⚠️ 踩过的坑：旧的 x/v2/reply（不带 /main）现在只回 3 条；
//         带 wbi 的 /reply/wbi/main 回 -403「访问权限不足」（要签名）。用 /main 这条路。
const BILI_UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
  + '(KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36';

/** 统一的请求头：UA + Referer，另外带上用户可选配置的 Cookie（填了才有字幕/AI字幕）。 */
function biliHeaders() {
  const h = { 'User-Agent': BILI_UA, Referer: 'https://www.bilibili.com/' };
  const cookie = String(cfg()?.cookie || '').trim();
  if (cookie) h.Cookie = cookie;
  return h;
}

/** 带 B站 头的一次 GET，取文本；失败返回 null（绝不抛）。 */
async function httpText(url, timeoutMs = 12000) {
  const ctl = new AbortController();
  const timer = setTimeout(() => ctl.abort(), timeoutMs);
  try {
    const r = await fetch(url, { headers: biliHeaders(), signal: ctl.signal });
    return await r.text();
  } catch { return null; } finally { clearTimeout(timer); }
}

/**
 * 下载一张图片转成 data URL（封面 / 章节图用）。
 * 超 2MB 直接放弃：封面原本可能几百 KB，别为一张图把上下文吃光。
 */
async function imageToDataUrl(url) {
  const ctl = new AbortController();
  const timer = setTimeout(() => ctl.abort(), 15000);
  try {
    const r = await fetch(url, { headers: biliHeaders(), signal: ctl.signal });
    if (!r.ok) return null;
    const buf = Buffer.from(await r.arrayBuffer());
    if (!buf.length || buf.length > 2 * 1024 * 1024) return null;
    const ct = String(r.headers.get('content-type') || '');
    const fmt = ct.includes('png') ? 'png' : (ct.includes('webp') ? 'webp' : 'jpeg');
    return `data:image/${fmt};base64,${buf.toString('base64')}`;
  } catch { return null; } finally { clearTimeout(timer); }
}

function decodeXml(s) {
  return String(s)
    .replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'").replace(/&amp;/g, '&');
}

/** 从链接或短链里解析 BV 号（b23.tv 需要跟一次跳转；JS 跳转则退回读正文）。 */
async function resolveBvid(url) {
  let hit = /BV[0-9A-Za-z]{10}/.exec(url);
  if (hit) return hit[0];
  let u = url;
  for (let i = 0; i < 5; i++) {
    let r;
    try {
      r = await fetch(u, {
        redirect: 'manual',
        headers: { 'User-Agent': BILI_UA, Referer: 'https://www.bilibili.com/' }
      });
    } catch { return null; }
    const loc = r.headers.get('location');
    if (!loc) {
      // 没有 Location：可能是 JS 跳转，读页面正文找 BV
      try {
        const body = await r.text();
        hit = /BV[0-9A-Za-z]{10}/.exec(body);
        if (hit) return hit[0];
      } catch { /* ignore */ }
      return null;
    }
    u = new URL(loc, u).toString();
    hit = /BV[0-9A-Za-z]{10}/.exec(u);
    if (hit) return hit[0];
  }
  return null;
}

async function fetchVideoInfo(bvid) {
  const txt = await httpText(`https://api.bilibili.com/x/web-interface/view?bvid=${encodeURIComponent(bvid)}`);
  if (!txt) return null;
  try {
    const j = JSON.parse(txt);
    if (j?.code !== 0 || !j.data) return null;
    const d = j.data;
    return {
      bvid,
      cid: d.cid,
      aid: d.aid,
      title: String(d.title || ''),
      up: String(d.owner?.name || ''),
      duration: Number(d.duration) || 0,
      stat: d.stat || {},
      // 简介（UP 写的正文；实测 4 条视频里 3 条有，23~187 字）
      desc: String(d.desc || '').replace(/\s+/g, ' ').trim(),
      // 封面（后面加 @672w_378h_1c.jpg 后缀取官方缩略版，实测返回有效 JPEG、38~53KB）
      pic: String(d.pic || ''),
      // 分P（多P视频必须知道这个：cid 是按 P 来的，只读 p1 会漏掉后面的内容）
      pages: Array.isArray(d.pages)
        ? d.pages.map((p) => ({
          page: Number(p.page) || 0,
          part: String(p.part || ''),
          duration: Number(p.duration) || 0,
          cid: p.cid
        }))
        : []
    };
  } catch { return null; }
}

/** 弹幕（XML，无需登录）→ 按时间排序的 [{t, text, mode}]。 */
async function fetchDanmaku(cid) {
  const xml = await httpText(`https://comment.bilibili.com/${encodeURIComponent(cid)}.xml`, 15000);
  if (!xml) return [];
  const out = [];
  for (const m of xml.matchAll(/<d p="([^"]*)"[^>]*>([\s\S]*?)<\/d>/g)) {
    const parts = String(m[1]).split(',');
    const t = Number(parts[0]);
    const text = decodeXml(m[2]).trim();
    if (Number.isFinite(t) && text) out.push({ t, text, mode: Number(parts[1]) || 0 });
  }
  // ⚠️ XML 里的顺序**不是**按时间的（实测最后一条是 13.7s），必须自己排
  out.sort((a, b) => a.t - b.t);
  return out;
}

/** 热评：优选用 /reply/main（20 条），失败退回旧接口。 */
async function fetchComments(aid, ps = 20) {
  const urls = [
    `https://api.bilibili.com/x/v2/reply/main?type=1&oid=${aid}&mode=3&ps=${ps}&pn=1`,
    `https://api.bilibili.com/x/v2/reply?type=1&oid=${aid}&sort=2&ps=${ps}&pn=1`
  ];
  for (const u of urls) {
    const txt = await httpText(u);
    if (!txt) continue;
    try {
      const j = JSON.parse(txt);
      const list = j?.data?.replies;
      if (j?.code === 0 && Array.isArray(list) && list.length) {
        return list.map((c) => ({
          user: String(c.member?.uname || ''),
          like: Number(c.like) || 0,
          text: String(c.content?.message || '').replace(/\s+/g, ' ').trim()
        })).filter((c) => c.text);
      }
    } catch { /* 换下一个接口 */ }
  }
  return [];
}

/** 从链接里取分P号（?p=3 或 &p=3），没有就当第 1 P。 */
function pickPageNo(url) {
  const m = /[?&]p=(\d+)/.exec(String(url || ''));
  const n = m ? Number(m[1]) : 1;
  return Number.isFinite(n) && n > 0 ? n : 1;
}

/**
 * 视频章节（player/v2 的 view_points 里带 imgUrl 的那些）。
 * 实测：只有**带章节**的视频才有（评测类常见，例如某条 483 秒视频有 5 个章节），
 * 普通视频是 0 条。每章配一张 B站 官方代表图 —— 下载失败时正好拿它当"不下载也能看"的兜底。
 */
async function fetchChapters(bvid, cid) {
  const txt = await httpText(`https://api.bilibili.com/x/player/v2?bvid=${encodeURIComponent(bvid)}&cid=${cid}`);
  if (!txt) return [];
  try {
    const vp = JSON.parse(txt)?.data?.view_points;
    if (!Array.isArray(vp)) return [];
    return vp
      .filter((x) => x && x.imgUrl)
      .map((x) => ({
        from: Number(x.from) || 0,
        to: Number(x.to) || 0,
        title: String(x.content || '').trim(),
        imgUrl: String(x.imgUrl)
      }));
  } catch { return []; }
}

/**
 * 字幕（尽力而为）。⚠️ 实测：**匿名请求 4/4 都拿不到轨道**（need_login_subtitle），
 * 所以这条只有在设置里填了 Cookie（SESSDATA）时才有戏。拿不到就静默跳过，不影响别的功能。
 */
async function fetchSubtitle(bvid, cid) {
  const txt = await httpText(`https://api.bilibili.com/x/player/v2?bvid=${encodeURIComponent(bvid)}&cid=${cid}`);
  if (!txt) return null;
  try {
    const list = JSON.parse(txt)?.data?.subtitle?.subtitles;
    if (!Array.isArray(list) || !list.length) return null;
    const pick = list.find((s) => /zh|ai-zh/i.test(String(s.lan || ''))) || list[0];
    const url = String(pick.subtitle_url || '').replace(/^http:/, 'https:');
    if (!url) return null;
    const body = JSON.parse((await httpText(url, 15000)) || '{}')?.body;
    if (!Array.isArray(body) || !body.length) return null;
    return {
      lan: String(pick.lan_doc || pick.lan || ''),
      text: body.map((b) => String(b.content || '').trim()).filter(Boolean).join(' ')
    };
  } catch { return null; }
}

/**
 * 规划抽帧时间点。
 *   · 默认 **间隔模式**：每 intervalSec 秒一张（"间隔几秒抽一张"）
 *   · 传了 count  → **张数模式**：在 5%~95% 之间等间隔取 count 张
 * 两种模式都受 maxFrames 约束：长视频按固定间隔算会得出上百张，token 会被吃光，
 * 所以超限时**自动放大实际间隔**，并在给模型的文字里说明（免得它以为真是每 5 秒一张）。
 */
function planFrameTimes(durationSec, { intervalSec, maxFrames, count }) {
  const dur = Number(durationSec) > 0 ? Number(durationSec) : 0;
  const cap = Math.max(1, Math.min(30, Math.round(Number(maxFrames) || 20)));

  const n0 = Math.round(Number(count) || 0);
  if (n0 > 0) {
    const n = Math.max(1, Math.min(cap, n0));
    if (!dur) return { times: Array.from({ length: n }, (_, i) => 1 + i * 2), intervalUsed: 0, capped: false, mode: 'count' };
    const times = Array.from({ length: n }, (_, i) =>
      Number((dur * (0.05 + 0.9 * (n === 1 ? 0 : i / (n - 1)))).toFixed(2)));
    return { times, intervalUsed: 0, capped: false, mode: 'count' };
  }

  const iv = Math.max(1, Math.min(600, Number(intervalSec) || 5));
  if (!dur) {
    const n = Math.min(cap, 6);
    return { times: Array.from({ length: n }, (_, i) => 1 + i * iv), intervalUsed: iv, capped: false, mode: 'interval' };
  }
  let n = Math.max(1, Math.floor(dur / iv));
  let used = iv;
  let capped = false;
  if (n > cap) { n = cap; used = dur / cap; capped = true; }
  // 从半个间隔处开始取样：首帧避开黑场/片头
  const times = Array.from({ length: n }, (_, i) => Number(((i + 0.5) * used).toFixed(2)));
  return { times, intervalUsed: Number(used.toFixed(2)), capped, mode: 'interval' };
}

/** 弹幕摘要：总量 + 刷屏高频 + 每个采样时刻附近在刷什么。 */
function summarizeDanmaku(list, times, { topN = 10, perFrame = 3, windowSec = 4 } = {}) {
  const freq = new Map();
  for (const d of list) {
    const k = d.text.slice(0, 30);
    freq.set(k, (freq.get(k) || 0) + 1);
  }
  const top = [...freq.entries()]
    .filter(([, n]) => n >= 2)
    .sort((a, b) => b[1] - a[1])
    .slice(0, topN);
  const near = times.map((t) => ({
    t,
    items: list
      .filter((d) => Math.abs(d.t - t) <= windowSec)
      .slice(0, perFrame)
      .map((d) => d.text.slice(0, 30))
  }));
  return { total: list.length, top, near };
}

/** 抽帧：按给定时间点逐张截取，缩到 maxWidth，返回 data URL。每张读完即删。 */
async function extractFrames(ffmpeg, file, { times, maxWidth, quality }) {
  const w = Math.max(160, Math.round(Number(maxWidth) || 768));
  const q = Math.max(2, Math.min(31, Math.round(Number(quality) || 4)));
  const dir = path.dirname(file);
  const stem = path.basename(file, path.extname(file));

  const frames = [];
  const okTimes = [];
  for (const t of (Array.isArray(times) ? times : [])) {
    const dest = path.join(dir, `${stem}_f${Math.round(t * 1000)}.jpg`);
    // -ss 放在 -i 之前 = 输入定位（快几倍到几十倍）
    const r = await run(ffmpeg, [
      '-y', '-ss', String(t), '-i', file,
      '-frames:v', '1',
      '-vf', `scale='min(${w},iw)':-2`,
      '-q:v', String(q),
      dest
    ], 25000);
    try {
      if (!r || !fs.existsSync(dest)) continue;
      const buf = fs.readFileSync(dest);
      if (buf.length) {
        frames.push(`data:image/jpeg;base64,${buf.toString('base64')}`);
        okTimes.push(t);
      }
    } catch { /* 单帧失败不影响其它帧 */ } finally {
      try { if (fs.existsSync(dest)) fs.unlinkSync(dest); } catch { /* ignore */ }
    }
  }
  return { frames, times: okTimes };
}

// ── 工具本体 ────────────────────────────────────────────────────────────

async function runTool(ctx, args) {
  const settings = cfg() || {};
  const maxDurationSec = Math.max(30, Math.round(Number(settings.maxDurationSec) || 600));

  // 1) 拿到链接：优先显式 url，其次从指定消息里抠
  let rawUrl = String(args?.url || '').trim();
  if (!rawUrl && args?.messageId !== undefined && ctx?.store?.findByMid) {
    try {
      const entry = ctx.store.findByMid(ctx.chatKey, args.messageId);
      if (entry?.text) rawUrl = pickUrl(entry.text) || '';
    } catch { /* 取不到就当没有 */ }
  }
  const checked = checkUrl(rawUrl);
  if (!checked.ok) {
    return { content: `读取失败：${checked.reason}。请把 B站 链接（b23.tv 或 bilibili.com）直接发给我。`, isError: true };
  }
  const url = checked.url;

  // 2) 依赖
  const ytDlp = await findYtDlp();
  if (!ytDlp) {
    return { content: '读取失败：没找到 yt-dlp（下载 B站 视频要用）。可在本插件设置里填写 yt-dlp 的完整路径。', isError: true };
  }
  const { ffmpeg, ffprobe } = await findFf();
  if (!ffmpeg) {
    return { content: '读取失败：没找到 ffmpeg（抽帧要用）。可在本插件设置里填写 ffmpeg 所在目录。', isError: true };
  }

  // 3) 取「视频信息 / 弹幕 / 评论 / 章节 / 字幕 / 封面」——与下载并行跑
  //    信息要先拿到（cid 给弹幕、aid 给评论），拿到后其余请求和下载**同时**进行：
  //    下载本来就要十几秒，这段时间足够这些小 HTTP 请求跑完，不用串行白等。
  const bvid = await resolveBvid(url);
  const info = bvid ? await fetchVideoInfo(bvid) : null;

  // 分P：cid 是**按 P** 的，选错就读错内容。优先用调用方给的 page，其次看链接里的 ?p=N
  const wantPage = Math.max(1, Math.round(Number(args?.page) || pickPageNo(url)));
  const pageObj = info?.pages?.find((p) => p.page === wantPage) || null;
  const cid = pageObj?.cid || info?.cid || 0;
  const multiP = (info?.pages?.length || 0) > 1;
  const pageLabel = multiP
    ? `${pageObj ? pageObj.page : wantPage}/${info.pages.length}`
    : '';

  const wantDanmaku = settings.danmaku !== false;
  const wantComments = settings.comments !== false;
  const wantCover = settings.cover !== false;
  const wantSubtitle = settings.subtitles !== false;
  const topComments = Math.max(1, Math.min(50, Math.round(Number(settings.topComments) || 20)));

  const sideTask = (async () => {
    const [danmaku, comments, chapters, subtitle, cover] = await Promise.all([
      (wantDanmaku && cid) ? fetchDanmaku(cid) : Promise.resolve([]),
      (wantComments && info?.aid) ? fetchComments(info.aid, topComments) : Promise.resolve([]),
      (info && cid) ? fetchChapters(bvid, cid) : Promise.resolve([]),
      (wantSubtitle && info && cid) ? fetchSubtitle(bvid, cid) : Promise.resolve(null),
      // 封面用官方缩放后缀（实测返回有效 JPEG、几十 KB，比原图省得多）
      (wantCover && info?.pic) ? imageToDataUrl(`${info.pic}@672w_378h_1c.jpg`) : Promise.resolve(null)
    ]);
    return { danmaku, comments, chapters, subtitle, cover };
  })();

  // 4) 下载（只要画面轨；带时长上限，超了 yt-dlp 直接拒绝，不浪费带宽）
  //
  // ⚠️ 为什么默认压到 720p 并准备降级阶梯：
  //   B站 的部分流（尤其 1080p）由 PCDN 节点（*.mcdn.bilivideo.cn:8082）提供，那些节点
  //   经常连不通 —— 表现就是 yt-dlp 报 "Read timed out" / "RemoteDisconnected" 然后一直
  //   重试到超时。2026-10 实测同一视频：1080p 卡死十分钟，720p **8.5MB/s 三秒下完**。
  //   而抽帧最终会缩到 768px 宽，720p 完全够用。所以按 720p→更低→任意 逐级降级：
  //   既避开坏节点，又把下载量砍掉一半以上。
  const dir = tempDir();
  const stem = `bili_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 7)}`;
  let videoFile = null;
  try {
    const maxHeight = Math.max(240, Math.round(Number(settings.maxHeight) || 720));
    const baseArgs = [
      '--no-playlist',
      '--no-warnings',
      '--no-progress',
      '--match-filter', `duration<=${maxDurationSec}`,
      '--max-filesize', '200M',
      // 坏 PCDN 节点会"挂着不回"，所以超时压短、重试给足：让它快速失败、换下一档，
      // 而不是在一个坏节点上干等到天荒地老。
      '--socket-timeout', '15',
      '--retries', '3',
      '--fragment-retries', '3'
    ];
    const ladder = [
      `bv*[height<=${maxHeight}][vcodec^=avc1]`,   // 首选 H.264：兼容性最好
      `bv*[height<=${maxHeight}]`,
      'bv*[height<=480]',
      'bv*'                                        // 兜底：任意画质
    ];

    // 整个下载阶段的总预算：逐级重试不能无限拖（每档单独 180s 会拖成十几分钟）
    const deadline = Date.now() + 300000;
    let lastText = '';
    let produced = null;
    let timedOut = false;

    for (let i = 0; i < ladder.length; i++) {
      const remain = deadline - Date.now();
      if (remain < 15000) break;
      // 每档用**独立的输出前缀**：不同画质的 .part 残片绝不能互相续传（会写出坏文件）
      const prefix = `${stem}_a${i}`;
      const attempt = await run(
        ytDlp,
        [...baseArgs, '-f', ladder[i], '-o', path.join(dir, `${prefix}.%(ext)s`), url],
        Math.min(180000, remain)
      );
      lastText = `${attempt?.stdout ?? ''}\n${attempt?.stderr ?? ''}`;
      if (!attempt) timedOut = true;

      if (attempt && attempt.code === 0) {
        const hit = fs.readdirSync(dir).find((f) => f.startsWith(prefix + '.') && !f.endsWith('.part'));
        if (hit) { produced = path.join(dir, hit); break; }
      }

      // 这两类是一票否决：换画质重试没有意义，直接给出准确原因
      if (/does not pass filter|match.?filter/i.test(lastText)) {
        return { content: `读取失败：这条视频超过 ${maxDurationSec} 秒，按设置拒绝下载（可在插件设置里放宽「最长视频时长」）。`, isError: true };
      }
      if (/max-filesize|larger than max/i.test(lastText)) {
        return { content: '读取失败：视频文件超过 200MB 上限，放弃下载。', isError: true };
      }

      // 清理本档残留（.part 等），免得干扰下一档
      for (const f of fs.readdirSync(dir)) {
        if (f.startsWith(prefix + '.')) {
          try { fs.unlinkSync(path.join(dir, f)); } catch { /* ignore */ }
        }
      }
    }

    // 下载失败不再直接报错：封面 / 章节图 / 弹幕 / 评论 / 简介都还在，
    // 比"什么都看不到"强得多（PCDN 是最高频的失败原因）。真正的兜底在下面统一组装。
    let fallbackReason = '';
    if (!produced) {
      if (/mcdn\.bilivideo\.cn|Read timed out|RemoteDisconnected|Connection aborted/i.test(lastText)) {
        fallbackReason = 'B站 的视频节点（PCDN）连不上，720p 与 480p 都试过了';
      } else if (timedOut) {
        fallbackReason = '下载超时（总预算 5 分钟用尽）';
      } else {
        const brief = lastText.split('\n').map((l) => l.trim()).filter((l) => /ERROR|error/i.test(l)).slice(0, 2).join(' / ');
        fallbackReason = `yt-dlp 没下到文件${brief ? `（${brief}）` : ''}`;
      }
    } else {
      videoFile = produced;
    }

    // 5) 时长：优先用视频信息接口的，再用 ffprobe 实测覆盖（更准）
    let durationSec = Number(pageObj?.duration) || Number(info?.duration) || 0;
    let frames = [];
    let times = [];
    let plan = null;
    let wantedInterval = Number(settings.intervalSec) || 5;

    if (videoFile) {
      const probe = await run(ffprobe, [
        '-v', 'quiet', '-print_format', 'json', '-show_format', videoFile
      ], 20000);
      if (probe && probe.code === 0) {
        try {
          const d = Number(JSON.parse(probe.stdout)?.format?.duration) || 0;
          if (d > 0) durationSec = d;
        } catch { /* 用接口给的时长 */ }
      }
      if (durationSec > maxDurationSec) {
        return { content: `读取失败：视频时长 ${Math.round(durationSec)} 秒，超过上限 ${maxDurationSec} 秒。`, isError: true };
      }

      // 6) 规划时间点 → 抽帧。默认「每 intervalSec 秒一张」，受 maxFrames 约束
      const explicitCount = Number(args?.frames) || 0;
      const explicitInterval = Number(args?.interval) || 0;
      wantedInterval = explicitInterval || Number(settings.intervalSec) || 5;
      plan = planFrameTimes(durationSec, {
        intervalSec: wantedInterval,
        maxFrames: settings.maxFrames,
        count: explicitCount
      });
      const got = await extractFrames(ffmpeg, videoFile, {
        times: plan.times,
        maxWidth: settings.maxWidth,
        quality: settings.quality
      });
      frames = got.frames;
      times = got.times;
    }

    // 7) 收并行任务的结果（此时多半早跑完了）
    const { danmaku, comments, chapters, subtitle, cover } = await sideTask;

    // 8) 组装给模型看的文字（设了长度上限，弹幕密集时不能无限长）
    const lines = [];
    if (info) {
      const st = info.stat || {};
      lines.push(`【B站视频】${info.title}`);
      lines.push(`UP：${info.up} ｜ 时长 ${Math.round(durationSec)} 秒`
        + (pageLabel ? ` ｜ 第 ${pageLabel} P` : '')
        + (st.view != null ? ` ｜ 播放 ${st.view}` : '')
        + (st.danmaku != null ? ` ｜ 弹幕 ${st.danmaku}` : '')
        + (st.reply != null ? ` ｜ 评论 ${st.reply}` : '')
        + (st.like != null ? ` ｜ 点赞 ${st.like}` : ''));
      // 简介：UP 写的正文（实测 4 条视频里 3 条有内容）
      if (info.desc) {
        lines.push(`【简介】${info.desc.slice(0, 300)}${info.desc.length > 300 ? '…' : ''}`);
      }
      // 分P列表：多P视频必须让模型知道有哪几 P（否则它以为只有一集）
      if (multiP) {
        lines.push(`【分P】共 ${info.pages.length} 个：` + info.pages.slice(0, 8)
          .map((p) => `P${p.page}《${String(p.part).slice(0, 18)}》${p.duration}s`).join(' ｜ ')
          + (info.pages.length > 8 ? ` …还有 ${info.pages.length - 8} 个` : ''));
        if (pageObj) lines.push(`（本次读的是第 ${pageObj.page} P）`);
      }
      // 章节：时间点 + 标题
      if (chapters.length) {
        lines.push(`【章节】${chapters.map((c) => `${c.title}(${Math.round(c.from)}s)`).join(' ｜ ')}`);
      }
      // 字幕：有的话等于把视频转成了文字（实测匿名拿不到，填了 Cookie 才有）
      if (subtitle?.text) {
        lines.push(`【字幕·${subtitle.lan || '未知语言'}】`
          + `${subtitle.text.slice(0, 1200)}${subtitle.text.length > 1200 ? '…（已截断）' : ''}`);
      }
    } else {
      lines.push(`【B站视频】${bvid || url}（信息接口没取到，画面与文字都可能不全）`);
    }

    // 画面：优先真实抽帧；下载失败时退回「封面 + 章节图」——不下载也能有画面
    const images = [];
    const kinds = [];
    if (cover) {
      images.push(cover);
      kinds.push('1 张封面');
    }
    let chapterImgs = 0;
    for (const ch of chapters) {
      const d = await imageToDataUrl(ch.imgUrl);
      if (d) { images.push(d); chapterImgs++; }
    }
    if (chapterImgs) kinds.push(`${chapterImgs} 张章节图（B站 官方配图，非逐帧）`);
    for (const f of frames) images.push(f);
    if (frames.length) kinds.push(`${frames.length} 张按时间抽出的画面`);

    if (fallbackReason) {
      lines.push('');
      lines.push(`【注意】这条视频**没能下载下来**（${fallbackReason}），所以没有逐帧画面；`
        + `下面给的是${images.length ? '封面/章节图等官方图片' : '纯文本信息'}。`
        + '想要画面细节可以稍后重试，或把插件设置里的「下载画质上限」降到 480。');
    } else if (plan) {
      lines.push('');
      if (plan.mode === 'interval') {
        lines.push(plan.capped
          ? `【画面】共 ${frames.length} 张：按 ${wantedInterval} 秒一张会有太多张，`
            + `已自动放宽到约每 ${plan.intervalUsed} 秒一张（上限 ${frames.length} 张）。`
          : `【画面】共 ${frames.length} 张，约每 ${plan.intervalUsed} 秒一张。`);
      } else {
        lines.push(`【画面】共 ${frames.length} 张（等间隔取样）。`);
      }
      lines.push('（截图之间不是连续画面，帧与帧之间发生的事我看不到）');
    }
    if (kinds.length) lines.push(`【图片顺序】${kinds.join(' → ')}`);

    if (danmaku.length) {
      const perFrame = Math.max(0, Math.min(5, Math.round(Number(settings.danmakuPerFrame ?? 3))));
      const sum = summarizeDanmaku(danmaku, times, { topN: 10, perFrame });
      lines.push('');
      lines.push(`【弹幕】抓到 ${sum.total} 条${info?.stat?.danmaku != null ? `（站内共 ${info.stat.danmaku} 条）` : ''}。`);
      if (sum.top.length) {
        lines.push('刷屏最多的：' + sum.top.map(([t, n]) => `「${t}」×${n}`).join('、'));
      }
      const nearLines = sum.near.filter((x) => x.items.length).map((x) => `  ${Math.round(x.t)}s：${x.items.join(' / ')}`);
      if (nearLines.length) {
        lines.push('各截图时刻附近的弹幕：');
        lines.push(...nearLines);
      }
    } else if (wantDanmaku) {
      lines.push('');
      lines.push('【弹幕】没抓到弹幕（可能作者关了弹幕，或弹幕池暂时不可用）。');
    }

    if (comments.length) {
      const show = Math.max(1, Math.min(12, Math.round(Number(settings.showComments) || 8)));
      lines.push('');
      lines.push(`【热评】前 ${Math.min(show, comments.length)} 条（按热度）：`);
      for (const c of comments.slice(0, show)) {
        lines.push(`  · ${c.user}（${c.like}赞）：${c.text.slice(0, 80)}`);
      }
    } else if (wantComments) {
      lines.push('');
      lines.push('【热评】没抓到评论。');
    }

    // 总长度兜底：弹幕/评论/字幕多的时候这段会长，截断保护模型上下文
    let text = lines.join('\n');
    const MAX_CHARS = 3500;
    if (text.length > MAX_CHARS) text = `${text.slice(0, MAX_CHARS)}\n…（内容过多，已截断）`;

    // 一张图都没有：也不要报"读取失败" —— 简介/分P/章节/弹幕/评论还在，属于"读到了信息"
    if (!images.length) {
      return { content: `${text}\n\n（这次一张画面都没拿到，以上信息来自文本接口。）` };
    }

    // 9) 按应用契约返回：文字 + 图片部分（orchestrator 会把图片补发成一条 user 消息）
    return {
      content: [
        { type: 'text', text },
        ...images.map((u) => ({ type: 'image_url', image_url: { url: u } }))
      ]
    };
  } catch (error) {
    return { content: `读取失败：${error?.message ?? error}`, isError: true };
  } finally {
    // 8) 临时视频一律删除（帧在 extractFrames 里已逐张删掉）
    if (videoFile) {
      try { if (fs.existsSync(videoFile)) fs.unlinkSync(videoFile); } catch { /* ignore */ }
    }
  }
}

// ── 注册 ────────────────────────────────────────────────────────────────

export function setup(skillApi) {
  api = skillApi;
  cfg = skillApi.config;
  skillApi.registerTool({
    id: 'read',
    name: '深读B站视频',
    description: '读取一条 B站（bilibili.com / b23.tv）链接的视频内容，一次给出四类信息：'
      + '① **文字**：标题、UP、时长、播放/弹幕/点赞/评论数、**简介**、**分P列表**、**章节标题**（有的话还有字幕）；'
      + '② **画面**：下载视频后**按固定间隔逐张抽帧**（另附封面；多P视频记得用 page 参数指定第几 P）；'
      + '③ **弹幕**：总量、被刷屏最多的几句、每个采样时刻附近在刷什么；'
      + '④ **热门评论**（带赞数）。'
      + '如果视频下载失败，会自动退回只给封面/章节图 + 全部文字信息（不会什么都不给）。'
      + '注意：只接受 B站 链接；不要改用 web_fetch 抓 B站 页面（脚本渲染，抓回来是乱码）；'
      + '弹幕和评论是观众反应，别当成视频内容本身或事实来源。',
    category: 'media',
    icon: '📺',
    requiresVision: false,
    parameters: {
      type: 'object',
      properties: {
        url: { type: 'string', description: 'B站视频链接（b23.tv 短链或 bilibili.com 视频地址）' },
        messageId: {
          type: ['integer', 'string'],
          description: '可选：聊天记录里那条含链接的消息 id（#数字）。给了它就不必再传 url，会从该消息文本里自动取链接。'
        },
        page: {
          type: ['integer', 'string'],
          description: '可选：多P视频读第几 P（默认 1；链接里带 ?p=3 时会自动用 3）。返回里会列出所有分P。'
        },
        interval: {
          type: ['integer', 'string'],
          description: '可选：每几秒抽一张画面（默认用设置里的值，通常 5 秒）。视频很长时实际间隔会被自动放宽，返回文字里会写明。'
        },
        frames: {
          type: ['integer', 'string'],
          description: '可选：改成"就抽这么多张"的等间隔模式（上限 30）。不传就是按 interval 的间隔模式。'
        }
      }
    },
    execute: runTool
  });
  skillApi.log('看B站视频 已就绪（依赖 yt-dlp 与 ffmpeg，二者可用设置项指定路径）');
}

/** 自检：UI 里能直接看到"为什么不可用"。 */
export async function available() {
  const ytDlp = await findYtDlp();
  const { ffmpeg } = await findFf();
  const missing = [];
  if (!ytDlp) missing.push('yt-dlp');
  if (!ffmpeg) missing.push('ffmpeg');
  if (missing.length) return { ok: false, reason: `缺少 ${missing.join(' 与 ')}（可在插件设置里填写路径）` };
  return { ok: true };
}

/** 暴露给测试用（不影响应用运行）。 */
export const internals = {
  checkUrl, pickUrl, extractFrames, findYtDlp, findFf, runTool,
  resolveBvid, fetchVideoInfo, fetchDanmaku, fetchComments, planFrameTimes, summarizeDanmaku,
  // 2026-10 新增：章节 / 字幕 / 封面 / 分P
  fetchChapters, fetchSubtitle, imageToDataUrl, pickPageNo
};
