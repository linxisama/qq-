// 任天堂 知识库技能：本地结构化库优先，在线百科兜底。
import fs from 'node:fs';

const SKILL_ID = 'nintendo-kb';
const KB_URL = new URL('./kb/nintendo.json', import.meta.url);

const result = (data, isError = false) => ({ content: JSON.stringify(data), ...(isError ? { isError: true } : {}) });

let kbCache = null;
function kb() {
  if (kbCache) return kbCache;
  try {
    kbCache = JSON.parse(fs.readFileSync(KB_URL, 'utf8'));
  } catch (e) {
    kbCache = { entries: [], sources: [], error: String(e?.message ?? e) };
  }
  return kbCache;
}

function norm(s) {
  return String(s ?? '').toLowerCase().replace(/\s+/g, '').trim();
}

// ── 本地检索 ────────────────────────────────────────────────
function scoreEntry(entry, q, rawTokens) {
  const title = norm(entry.title);
  const aliases = (entry.aliases || []).map(norm);
  const tags = (entry.tags || []).map(norm);
  const summary = norm(entry.summary);
  let score = 0;
  if (title === q) score += 120;
  else if (title.includes(q)) score += 70;
  if (aliases.includes(q)) score += 100;
  else if (aliases.some((a) => a.includes(q) || q.includes(a))) score += 60;
  if (tags.includes(q)) score += 45;
  else if (tags.some((t) => q.includes(t) || t.includes(q))) score += 25;
  if (summary.includes(q)) score += 30;
  for (const t of rawTokens) {
    if (t.length < 2) continue;
    if (title.includes(t)) score += 18;
    if (aliases.some((a) => a.includes(t))) score += 14;
    if (tags.some((x) => x.includes(t))) score += 8;
    if (summary.includes(t)) score += 6;
  }
  return score;
}

function searchLocal(query, limit) {
  const q = norm(query);
  if (!q) return [];
  const rawTokens = String(query).toLowerCase().split(/[\s,，、/]+/).filter(Boolean);
  return kb().entries
    .map((e) => ({ entry: e, score: scoreEntry(e, q, rawTokens) }))
    .filter((x) => x.score > 0)
    .sort((a, b) => b.score - a.score)
    .slice(0, limit)
    .map(({ entry, score }) => ({
      id: entry.id,
      title: entry.title,
      summary: entry.summary,
      source: entry.source,
      url: entry.url,
      score
    }));
}

function findEntry(ref) {
  const r = norm(ref);
  if (!r) return null;
  return kb().entries.find((e) => norm(e.id) === r)
    || kb().entries.find((e) => norm(e.title) === r)
    || kb().entries.find((e) => norm(e.title).includes(r) || (e.aliases || []).some((a) => norm(a) === r))
    || null;
}

// ── 在线兜底（多源，允许部分失败）────────────────────────────
function withTimeout(promise, ms) {
  return Promise.race([
    promise,
    new Promise((_, reject) => setTimeout(() => reject(new Error('timeout')), ms))
  ]);
}

function stripTags(html) {
  return String(html ?? '')
    .replace(/<script[\s\S]*?<\/script>/gi, ' ')
    .replace(/<style[\s\S]*?<\/style>/gi, ' ')
    .replace(/<[^>]+>/g, ' ')
    .replace(/&nbsp;/g, ' ')
    .replace(/&amp;/g, '&')
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/\s+/g, ' ')
    .trim();
}

async function httpText(f, url, timeoutMs, headers = {}) {
  const ac = new AbortController();
  const t = setTimeout(() => ac.abort(), timeoutMs);
  try {
    const res = await f(url, {
      method: 'GET',
      headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) qq-agent-kb/1.0', ...headers },
      signal: ac.signal
    });
    const text = await res.text();
    return { ok: res.ok, status: res.status, text };
  } finally { clearTimeout(t); }
}

// 源 1：萌娘百科 MediaWiki API（中文 ACG 向，最常用）
async function fromMoegirl(f, query, timeoutMs) {
  const api = 'https://zh.moegirl.org.cn/api.php';
  const s = await httpText(f, `${api}?action=query&list=search&srsearch=${encodeURIComponent(query)}&srlimit=3&format=json`, timeoutMs);
  if (!s.ok) throw new Error(`moegirl search http ${s.status}`);
  const sj = JSON.parse(s.text);
  const hits = sj?.query?.search || [];
  if (!hits.length) return [];
  const title = hits[0].title;
  const e = await httpText(f, `${api}?action=query&prop=extracts&explaintext=1&exintro=1&redirects=1&titles=${encodeURIComponent(title)}&format=json`, timeoutMs);
  let extract = '';
  if (e.ok) {
    try {
      const ej = JSON.parse(e.text);
      const page = Object.values(ej?.query?.pages || {})[0];
      extract = String(page?.extract || '');
    } catch { /* 摘要失败不致命 */ }
  }
  return [{
    source: '萌娘百科',
    title,
    snippet: extract ? extract.slice(0, 700) : `（萌娘百科有条目「${title}」，但摘要接口没返回内容）`,
    url: `https://zh.moegirl.org.cn/${encodeURIComponent(title)}`
  }];
}

// 源 2：百度百科（HTML meta 摘要）
async function fromBaike(f, query, timeoutMs) {
  const url = `https://baike.baidu.com/item/${encodeURIComponent(query)}`;
  const r = await httpText(f, url, timeoutMs);
  if (!r.ok) throw new Error(`baike http ${r.status}`);
  const m = r.text.match(/<meta[^>]+name=["']description["'][^>]+content=["']([^"']{20,})["']/i);
  const snippet = m ? m[1] : '';
  if (!snippet) return [];
  return [{ source: '百度百科', title: query, snippet: stripTags(snippet).slice(0, 500), url }];
}

// 源 3：Bing 中国站（解析 b_algo 结果块，取标题 + 摘要 + 链接）
async function fromBing(f, query, timeoutMs) {
  const url = `https://cn.bing.com/search?q=${encodeURIComponent(query)}`;
  const r = await httpText(f, url, timeoutMs);
  if (!r.ok) throw new Error(`bing http ${r.status}`);
  const out = [];
  const blocks = String(r.text).split(/<li class="b_algo"/i).slice(1);
  const tokens = String(query).toLowerCase().split(/[\s,，、]+/).filter((t) => t.length >= 2);
  const relevant = (text) => {
    if (!tokens.length) return true;
    const s = String(text).toLowerCase();
    return tokens.some((t) => s.includes(t));
  };
  for (const block of blocks) {
    if (out.length >= 3) break;
    const a = block.match(/<h2[^>]*>[\s\S]*?<a[^>]+href="(https?:\/\/[^"]+)"/i);
    if (!a) continue;
    const titleM = block.match(/<h2[^>]*>([\s\S]*?)<\/h2>/i);
    const pM = block.match(/<p[^>]*>([\s\S]*?)<\/p>/i);
    const title = stripTags(titleM ? titleM[1] : '');
    const snippet = stripTags(pM ? pM[1] : '');
    if (!title) continue;
    // 广告/推广块常常与查询词毫无关系，直接丢弃：宁可查不到，也不喂错料
    if (!relevant(title + ' ' + snippet)) continue;
    out.push({ source: 'Bing', title, snippet: snippet.slice(0, 300) || '（搜索结果无摘要，需点开链接）', url: a[1] });
  }
  return out;
}

const SOURCES = [
  { id: 'moegirl', run: fromMoegirl, budgetMs: 5000 },
  { id: 'baike', run: fromBaike, budgetMs: 4000 },
  { id: 'bing', run: fromBing, budgetMs: 8000 }
];

// 萌娘百科在服务器上时通时断，超时后 10 分钟内不再尝试，避免每次对话都白等。
const breaker = { moegirlDownUntil: 0 };
const BREAKER_MS = 10 * 60 * 1000;

async function searchWeb(f, query, timeoutMs) {
  const attempts = await Promise.all(SOURCES.map(async (s) => {
    if (s.id === 'moegirl' && Date.now() < breaker.moegirlDownUntil) {
      return { source: s.id, ok: false, skipped: true, reason: 'moegirl 最近超时，已熔断 10 分钟', items: [] };
    }
    const budget = Math.min(timeoutMs, s.budgetMs || timeoutMs);
    try {
      const items = await withTimeout(s.run(f, query, budget), budget + 1500);
      if (s.id === 'moegirl') breaker.moegirlDownUntil = 0;
      return { source: s.id, ok: true, items };
    } catch (e) {
      if (s.id === 'moegirl') breaker.moegirlDownUntil = Date.now() + BREAKER_MS;
      return { source: s.id, ok: false, error: String(e?.message ?? e), items: [] };
    }
  }));
  const items = attempts.flatMap((a) => a.items);
  return { attempts, items };
}

// ── 技能注册 ────────────────────────────────────────────────
export function setup(api) {
  const conf = () => (typeof api.config === 'function' ? api.config() : api.config) || {};
  const data = kb();

  api.registerTool({
    id: 'search',
    name: `${'任天堂'}知识检索`,
    category: 'knowledge',
    icon: '📚',
    description: `在本地${'任天堂'}知识库（${(data.entries || []).length} 条：作品、角色、机制、术语、年表等）里检索。回答相关问题时先用它，比联网快且不依赖网络；命中后再按需用 entry 取全文或 wiki 查细节。`,
    parameters: {
      type: 'object',
      required: ['query'],
      properties: {
        query: { type: 'string', description: '关键词，中文或英文都行，例如「真格鱼虎」「Switch 2」「潜行机制」。' },
        limit: { type: 'number', description: '返回条数，默认 5，最多 10。' }
      }
    },
    async execute(_ctx, args = {}) {
      const q = String(args.query ?? '').trim();
      if (!q) return result({ ok: false, error: 'query 不能为空' }, true);
      const limit = Math.min(10, Math.max(1, Number(args.limit) || Number(conf().maxResults) || 5));
      const hits = searchLocal(q, limit);
      if (!hits.length) {
        return result({
          ok: true, query: q, hits: [],
          hint: '本地库没有命中。可以换用更具体的别名再查一次，或直接调 wiki 工具查在线百科。'
        });
      }
      return result({ ok: true, query: q, hits, total: kb().entries.length });
    }
  });

  api.registerTool({
    id: 'entry',
    name: `${'任天堂'}条目详情`,
    category: 'knowledge',
    icon: '📖',
    description: `按 id 或标题取本地${'任天堂'}知识库中某一条的完整内容（含来源与链接）。一般先用 search 拿到 id，再取详情。`,
    parameters: {
      type: 'object',
      required: ['ref'],
      properties: {
        ref: { type: 'string', description: '条目 id（如 "turf-war"）或标题（如 "真格鱼虎"）。' }
      }
    },
    async execute(_ctx, args = {}) {
      const ref = String(args.ref ?? '').trim();
      if (!ref) return result({ ok: false, error: 'ref 不能为空' }, true);
      const e = findEntry(ref);
      if (!e) {
        const near = searchLocal(ref, 3);
        return result({ ok: false, error: 'not_found', ref, maybe: near, hint: '没找到该条目，看看 maybe 里有没有相近的。' }, true);
      }
      return result({ ok: true, entry: e });
    }
  });

  api.registerTool({
    id: 'wiki',
    name: '百科在线查询',
    category: 'knowledge',
    icon: '🌐',
    description: '本地库没覆盖时，实时查网络百科（萌娘百科 / 百度百科 / Bing），返回摘要与链接。网络不稳时可能只返回部分来源；三个源都失败就照实说查不到，不要编。',
    parameters: {
      type: 'object',
      required: ['query'],
      properties: {
        query: { type: 'string', description: '要查的条目名或问题关键词，例如「斯普拉遁3 大型祭典」「塞尔达 王国之泪 发售日」。' }
      }
    },
    async execute(_ctx, args = {}) {
      const q = String(args.query ?? '').trim();
      if (!q) return result({ ok: false, error: 'query 不能为空' }, true);
      const c = conf();
      if (c.wikiEnabled === false) return result({ ok: false, error: 'wiki_disabled', hint: '本技能已关闭在线查询。' }, true);
      const timeoutMs = Math.min(15000, Math.max(3000, Number(c.wikiTimeoutMs) || 8000));
      const f = typeof api.fetch === 'function' ? api.fetch : globalThis.fetch;
      if (typeof f !== 'function') return result({ ok: false, error: 'no_fetch' }, true);

      const { attempts, items } = await searchWeb(f, q, timeoutMs);
      if (!items.length) {
        return result({
          ok: false,
          error: 'all_sources_failed',
          attempts,
          hint: '三个百科源都没拿到内容。照实说没查到，不要凭记忆编具体数据。'
        }, true);
      }
      return result({
        ok: true,
        query: q,
        results: items.slice(0, 4),
        attempts,
        note: '引用时说明来源（萌娘百科/百度百科/Bing），不要把百科摘要当成官方原文。'
      });
    }
  });
}

export const __internals = { searchLocal, findEntry, kb };
export default setup;
