// 音乐角（bili-music）—— 让她自己去 B 站音乐区逛逛，挑一首「在听」。
//
// 为什么不读网易云客户端：
//   主人要的是「自己去扒近期热门」，B 站音乐区排行榜是匿名的公开数据，
//   不登录、不碰她电脑上的播放器，也不会因为客户端没开就失效。
//
// 三条设计红线：
// 1) **她听不到声音**。B 站只能拿到标题/UP 主/简介/热度，
//    所以提示词里明写：被问「好听吗」要说依据（标题、热度、评论），不许装听过。
// 2) **不当电台 DJ**。一次只挑一首，状态存在本地；不会每首歌都发评论。
// 3) **不刷接口**。排行榜有 10 分钟内存缓存，搜索限条数，避免被风控。

import { DATA_DIR } from '../../src/config.js';
import {
  rankMusic,
  searchSongs,
  readState,
  writeState,
  fmtDuration,
  fmtPlay,
  songLink,
} from './lib/bili.js';

const SKILL_ID = 'bili-music';

let cfgOf = () => ({});
let log = () => {};
let cache = { at: 0, list: [] };

function fmtLine(s) {
  return `${s.title} — ${s.up}（${fmtDuration(s.duration)}，${fmtPlay(s.view)}播放）\n${s.link}`;
}

function fmtShort(s) {
  return `《${s.title}》 ${s.up} · ${fmtDuration(s.duration)}`;
}

async function hotList(cfg, force = false) {
  const ttl = Math.max(0, Number(cfg.cacheMinutes) || 10) * 60 * 1000;
  if (!force && cache.list.length && Date.now() - cache.at < ttl) return cache.list;
  const limit = Math.max(3, Math.min(20, Number(cfg.hotLimit) || 8));
  const list = await rankMusic({ limit });
  cache = { at: Date.now(), list };
  return list;
}

export function setup(api) {
  cfgOf = () => api.config() || {};
  log = (...a) => { try { api.log(...a); } catch { /* 忽略 */ } };

  // ── 逛榜单 ────────────────────────────────────────────────────────────
  api.registerTool({
    id: 'hot',
    name: '逛B站音乐区',
    description: '看看 B 站音乐区最近在火什么（翻唱、原创、MV、演奏这些，不含几十分钟的乐评合集）。'
      + '用来挑歌、或者别人问「最近有什么好听的」。注意：你听不到声音，榜单只给你标题、UP 主、热度、时长。'
      + '看完别把整张榜念出来，挑一首说就行。',
    category: 'media',
    icon: '🎵',
    parameters: {
      type: 'object',
      properties: {
        limit: { type: 'number', description: '要几条，默认按设置（一般 8 条）。' }
      }
    },
    async execute(_ctx, args) {
      const cfg = cfgOf();
      if (cfg.enabled === false) return { content: '音乐角关着。', isError: true };
      try {
        const list = await hotList(cfg);
        const n = Math.max(1, Math.min(list.length, Number(args?.limit) || list.length));
        log(`[${SKILL_ID}] 逛榜单 ${n} 条`);
        return {
          content: `B 站音乐区现在排前面的（${n} 条）：\n`
            + list.slice(0, n).map((s, i) => `${i + 1}. ${fmtShort(s)}\n   ${s.link}`).join('\n')
            + '\n（你听不到音频，只知道标题和热度。想挑一首在听就用「挑一首在听」。）'
        };
      } catch (e) {
        const msg = String(e?.message ?? e).slice(0, 150);
        log(`[${SKILL_ID}] 榜单失败：${msg}`);
        return { content: `没扒到榜单：${msg}`, isError: true };
      }
    }
  });

  // ── 搜歌 ──────────────────────────────────────────────────────────────
  api.registerTool({
    id: 'search',
    name: '搜歌',
    description: '在 B 站按歌名搜（比如别人点了一首歌，或者你想起一首）。只返回单曲，几小时的合集会被筛掉。',
    category: 'media',
    icon: '🔎',
    parameters: {
      type: 'object',
      properties: {
        keyword: { type: 'string', description: '歌名或关键词。' },
        limit: { type: 'number', description: '要几条，默认 5 条。' }
      },
      required: ['keyword']
    },
    async execute(_ctx, args) {
      const cfg = cfgOf();
      if (cfg.enabled === false) return { content: '音乐角关着。', isError: true };
      try {
        const limit = Math.max(1, Math.min(10, Number(args?.limit) || Number(cfg.maxSearch) || 5));
        const list = await searchSongs(String(args?.keyword ?? ''), { limit });
        if (!list.length) return { content: `没搜到「${args?.keyword}」。` };
        log(`[${SKILL_ID}] 搜「${args?.keyword}」得 ${list.length} 条`);
        return { content: `搜「${args?.keyword}」：\n` + list.map((s, i) => `${i + 1}. ${fmtShort(s)}\n   ${s.link}`).join('\n') };
      } catch (e) {
        const msg = String(e?.message ?? e).slice(0, 150);
        log(`[${SKILL_ID}] 搜索失败：${msg}`);
        return { content: `没搜成：${msg}`, isError: true };
      }
    }
  });

  // ── 挑一首在听 ────────────────────────────────────────────────────────
  api.registerTool({
    id: 'pick',
    name: '挑一首在听',
    description: '从榜单里挑一首当你「最近在听」的歌，记下来。可以给一首具体的歌名（bvid 或 keyword），不给就随机。'
      + '挑完会记住，之后别人问你在听什么就用「在听什么」。挑歌是你的自由，不用挑最热的。',
    category: 'media',
    icon: '🎧',
    parameters: {
      type: 'object',
      properties: {
        keyword: { type: 'string', description: '可选，指定歌名（会先搜再挑第一首）。' },
        bvid: { type: 'string', description: '可选，直接给 BV 号（榜单里看到的）。' },
        reason: { type: 'string', description: '可选，一句话你为什么挑它（几个字就够）。' }
      }
    },
    async execute(_ctx, args) {
      const cfg = cfgOf();
      if (cfg.enabled === false) return { content: '音乐角关着。', isError: true };
      try {
        let song = null;
        const bvid = String(args?.bvid ?? '').trim();
        const kw = String(args?.keyword ?? '').trim();
        if (bvid) {
          const list = await hotList(cfg);
          song = list.find((s) => s.bvid === bvid) || { bvid, title: '（榜单外的视频）', up: '', view: 0, duration: 0, link: songLink(bvid) };
        } else if (kw) {
          const found = await searchSongs(kw, { limit: 5 });
          if (!found.length) return { content: `没搜到「${kw}」，这首没挑成。`, isError: true };
          song = found[0];
        } else {
          const list = await hotList(cfg, true);
          if (!list.length) return { content: '榜单是空的，这次没挑成。', isError: true };
          const prev = readState(DATA_DIR);
          const pool = list.filter((s) => s.bvid !== prev?.bvid);
          song = pool[Math.floor(Math.random() * pool.length)] || list[0];
        }
        const reason = String(args?.reason ?? '').trim().slice(0, 60);
        writeState(DATA_DIR, { ...song, pickedAt: Date.now(), reason });
        log(`[${SKILL_ID}] 在听：${song.title}`);
        return {
          content: `现在在听：${fmtLine(song)}`
            + (reason ? `\n（你挑它的理由：${reason}）` : '')
            + '\n不用马上告诉别人。有人问起、或者聊到歌的时候再说，一次说一首就够。'
        };
      } catch (e) {
        const msg = String(e?.message ?? e).slice(0, 150);
        log(`[${SKILL_ID}] 挑歌失败：${msg}`);
        return { content: `没挑成：${msg}`, isError: true };
      }
    }
  });

  // ── 在听什么 ──────────────────────────────────────────────────────────
  api.registerTool({
    id: 'now',
    name: '在听什么',
    description: '看看自己现在在听哪首（之前挑的那首）。太久没动就当作没在听。别人问「你在听什么」时用。',
    category: 'media',
    icon: '🎶',
    parameters: { type: 'object', properties: {} },
    async execute() {
      const cfg = cfgOf();
      if (cfg.enabled === false) return { content: '音乐角关着。', isError: true };
      const st = readState(DATA_DIR);
      if (!st?.bvid) return { content: '现在没在听什么。想听就先去榜单挑一首。' };
      const ttl = Math.max(1, Number(cfg.nowTtlHours) || 6) * 3600 * 1000;
      const age = Date.now() - Number(st.pickedAt || 0);
      const ageText = age < 3600 * 1000 ? `${Math.max(1, Math.round(age / 60000))} 分钟前` : `${Math.round(age / 3600000)} 小时前`;
      const stale = age > ttl ? '（有点久了，可以换一首）' : '';
      return {
        content: `在听：${fmtLine(st)}`
          + `\n挑于 ${ageText}${st.reason ? `，当时说「${st.reason}」` : ''}${stale}`
          + '\n记住：你听不到音频，被问好不好听就说你是看标题/热度挑的，别装听过。'
      };
    }
  });

  log(`[${SKILL_ID}] 音乐角就绪（工具：${SKILL_ID}__hot / __search / __pick / __now）`);
}

export function available() {
  return true;
}

export function dispose() {
  cfgOf = () => ({});
  log = () => {};
  cache = { at: 0, list: [] };
}