// 吉他市场查价（LLM 型技能 / skills/）
//
// ── 为什么是技能，不是插件 ─────────────────────────────────────────────────
// 文档 §0 的判据：插件只能提供 providers / hooks，钩子里不能联网、不能发消息；
// 而本功能要做的是「看到群友发的一句话 → 联网查行情 → 把结果发回群里」。
// 这条链路必须由工具执行，所以放 skills/，让模型在识别到「查价 物品名」时调用。
// 硬做成插件会绕不过核心的钩子禁令，只能偷偷改 Orchestrator 原型 —— 文档明确
// 说不要这么干，且热重载/升级后极易静默失效。
//
// ── 数据源 ────────────────────────────────────────────────────────────────
// 行情：ESI（官方，宁静服 The Forge / Jita），免 Key。
//   GET /markets/10000002/orders/?type_id=...
// 物品名：英文先用 Fuzzwork 的 typeid 接口；中文/英文再走 ESI universe/ids；
//   都失败时用 eve.c3q.cc 的静态中文名表兜底（缓存 7 天）。
//   ESI 只认 type_id，所以「名字 → id」这一步是必须的。
//
// ── 输出 ──────────────────────────────────────────────────────────────────
// 直接走 ctx.sender.sendTextBatch（文档硬约束：不得绕过发送队列），
// 默认看 Jita 4-4；4-4 完全无单时自动扩到 Jita 星系并在标题里注明。

import fs from 'node:fs';
import path from 'node:path';
import { DATA_DIR } from '../../src/config.js';

const SKILL_ID = 'jita-market';
const ESI = 'https://esi.evetech.net/latest';
const REGION_ID = 10000002;          // The Forge
const JITA_SYSTEM_ID = 30000142;     // Jita
const JITA_STATION_ID = 60003760;    // Jita IV - Moon 4 - Caldari Navy Assembly Plant
const PLEX_TYPE_ID = 44992;          // PLEX / 伊甸币
const PLEX_REGION_ID = 19000001;     // Global PLEX Market（2025-07 起）
const UA = 'QQ-Agent-JitaMarket/1.0';
const ZH_MAP_URL = 'https://eve.c3q.cc/market/data/typename/zh/';
const TYPEINFO_TTL = 24 * 60 * 60 * 1000;
const ZH_MAP_TTL = 7 * 24 * 60 * 60 * 1000;

const DEFAULTS = {
  topN: 3,
  scope: 'station',
  cacheSeconds: 60,
  timeoutMs: 9000,
  allowPrivate: false,
  cooldownSeconds: 5,
  maxItemLength: 40
};

let log = () => {};
let warn = () => {};
let httpFetch = null;
let itemResolverCapability = null;
let readCfg = () => ({});

const state = {
  orders: new Map(),        // `${typeId}:${scope}` -> { at, value }
  names: new Map(),         // 规范化物品名 -> item
  typeInfo: new Map(),      // typeId -> { at, value }
  lastAt: new Map(),        // chatKey -> ts
  inflight: new Map(),      // `${typeId}:${scope}` -> Promise
  zhMap: null,              // Map<规范化名字, { id, name }>
  zhMapPromise: null
};

// ─────────────────────────────────────────────── 配置 / 小工具
function cfg() {
  try {
    return { ...DEFAULTS, ...(readCfg() || {}) };
  } catch {
    return { ...DEFAULTS };
  }
}

function num(v, fallback) {
  const n = Number(v);
  return Number.isFinite(n) ? n : fallback;
}

function clamp(n, lo, hi) {
  const v = Number(n);
  if (!Number.isFinite(v)) return lo;
  return Math.max(lo, Math.min(hi, Math.round(v)));
}

function normalizeKey(s) {
  return String(s ?? '').normalize('NFKC').replace(/\s+/g, ' ').trim().toLowerCase();
}

function normalizeItem(v) {
  let s = String(v ?? '').normalize('NFKC').trim();
  // 模型偶尔会把完整命令原样塞进 item；这里再剥一次，避免把「查价」当物品名。
  s = s.replace(/^[!！/／]\s*/u, '');
  s = s.replace(/^[\s\[\(（【]*(?:吉他|市场)?\s*(?:查价|估价|价格|多少钱|值多少|ojita|差价|价差)\s*[\s\]）】]*[:：,，、\-]?\s*/iu, '');
  s = s.replace(/\s*(?:的)?(?:查价|估价|价格|多少钱|值多少|ojita|差价|价差)\s*$/iu, '');
  s = s.replace(/^["'“”‘’]+|["'“”‘’]+$/gu, '');
  return s.replace(/\s+/g, ' ').trim();
}

/** 从「伊甸币 x10」「10个伊甸币」「月卡 2个」里抠出显式数量。 */
function extractQuantity(v) {
  let s = String(v ?? '').normalize('NFKC').trim();
  let quantity = 0;

  let m = s.match(/(?:x|×|\*|✕)\s*(\d{1,6})/iu);
  if (m) {
    quantity = Number(m[1]);
    s = s.replace(m[0], ' ');
  }

  if (!quantity) {
    m = s.match(/(\d{1,6})\s*(?:个月(?!卡)|个|件|张|份)/u);
    if (m) {
      quantity = Number(m[1]);
      s = s.replace(m[0], ' ');
    }
  }

  quantity = Number.isFinite(quantity)
    ? Math.max(0, Math.min(1_000_000, Math.floor(quantity)))
    : 0;
  s = s.replace(/\s+/g, ' ').trim();
  return { text: s, quantity };
}

function normalizeScope(v) {
  const s = String(v ?? '').trim().toLowerCase();
  return ['station', 'system', 'region'].includes(s) ? s : 'station';
}

/** PLEX 的常见中英文写法；2025-07 起它不在普通星域市场，必须走全球 PLEX 市场。 */
function isPlexQuery(s) {
  const compact = String(s ?? '').toLowerCase()
    .replace(/[\s_\-·（）()【】\[\]\/\\]+/gu, '');
  return ['伊甸币', 'plex', 'eveplex', '伊甸币plex', 'plex伊甸币', 'eveplex伊甸币'].includes(compact);
}

function humanError(error) {
  const m = String(error?.message ?? error ?? '');
  if (/abort|timeout|timed out|超时/i.test(m)) return '请求超时';
  if (/fetch failed|ENOTFOUND|ECONN|EAI_AGAIN|network/i.test(m)) return '网络连接失败';
  return '接口异常';
}

function fmtQty(v) {
  const n = Number(v);
  if (!Number.isFinite(n)) return '?';
  return n.toLocaleString('en-US', { maximumFractionDigits: 0 });
}

function fmtIsk(v) {
  const n = Number(v);
  if (!Number.isFinite(n)) return '? ISK';
  return `${n.toLocaleString('en-US', { maximumFractionDigits: 2 })} ISK`;
}

function fmtTime(ts) {
  try {
    return new Date(ts).toLocaleString('zh-CN', {
      hour12: false, month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit'
    });
  } catch {
    return new Date(ts).toLocaleTimeString('zh-CN', { hour12: false });
  }
}

async function fetchWithTimeout(url, options = {}, timeoutMs = 9000) {
  if (typeof httpFetch !== 'function') throw new Error('缺少 web_fetch 权限');
  const ms = Math.max(2000, num(timeoutMs, 9000));
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(new Error('请求超时')), ms);
  timer.unref?.();
  try {
    return await httpFetch(url, { ...options, signal: controller.signal });
  } catch (error) {
    if (error?.name === 'AbortError' || /abort|timeout|timed out|超时/i.test(String(error?.message ?? ''))) {
      throw new Error('请求超时');
    }
    throw error;
  } finally {
    clearTimeout(timer);
  }
}

async function fetchJson(url, options = {}, timeoutMs = 9000) {
  const res = await fetchWithTimeout(url, options, timeoutMs);
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  return { data: await res.json(), res };
}

// ─────────────────────────────────────────────── 物品名 → type_id
function buildZhMap(obj) {
  const map = new Map();
  for (const [name, id] of Object.entries(obj || {})) {
    const n = Number(id);
    if (!Number.isInteger(n) || n <= 0) continue;
    const key = normalizeKey(name);
    if (!key || map.has(key)) continue;
    map.set(key, { id: n, name: String(name) });
  }
  return map;
}

function zhMapFile() {
  return path.join(DATA_DIR, SKILL_ID, 'typenames-zh.json');
}

function readZhMapCache() {
  try {
    const raw = JSON.parse(fs.readFileSync(zhMapFile(), 'utf8'));
    if (raw && raw.map && raw.savedAt) return raw;
  } catch { /* 没有缓存或缓存损坏都直接忽略 */ }
  return null;
}

function writeZhMapCache(obj) {
  try {
    fs.mkdirSync(path.dirname(zhMapFile()), { recursive: true });
    fs.writeFileSync(zhMapFile(), JSON.stringify({ savedAt: Date.now(), map: obj }), 'utf8');
  } catch (error) {
    warn(`中文物品名缓存写入失败：${error?.message ?? error}`);
  }
}

async function loadZhMap(timeoutMs) {
  if (state.zhMap) return state.zhMap;
  if (state.zhMapPromise) return state.zhMapPromise;

  state.zhMapPromise = (async () => {
    const cached = readZhMapCache();
    if (cached && Date.now() - Number(cached.savedAt) < ZH_MAP_TTL) {
      const map = buildZhMap(cached.map);
      if (map.size) {
        state.zhMap = map;
        return map;
      }
    }

    try {
      const res = await fetchWithTimeout(ZH_MAP_URL, {
        headers: { accept: '*/*', 'user-agent': UA }
      }, Math.max(6000, num(timeoutMs, 9000)));
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const text = await res.text();
      const eq = text.indexOf('=');
      const json = eq >= 0 ? text.slice(eq + 1) : text;
      const obj = JSON.parse(json);
      const map = buildZhMap(obj);
      if (!map.size) throw new Error('返回的物品名表为空');
      state.zhMap = map;
      writeZhMapCache(obj);
      log(`已加载中文物品名表：${map.size} 条`);
      return map;
    } catch (error) {
      if (cached?.map) {
        const map = buildZhMap(cached.map);
        if (map.size) {
          state.zhMap = map;
          warn(`中文物品名表刷新失败，改用旧缓存：${error?.message ?? error}`);
          return map;
        }
      }
      warn(`中文物品名表加载失败：${error?.message ?? error}`);
      return null;
    } finally {
      state.zhMapPromise = null;
    }
  })();

  return state.zhMapPromise;
}

async function fuzzworkTypeId(name, timeoutMs) {
  try {
    const url = `https://www.fuzzwork.co.uk/api/typeid.php?typename=${encodeURIComponent(name)}`;
    const { data } = await fetchJson(url, {
      headers: { accept: 'application/json', 'user-agent': UA }
    }, timeoutMs);
    const id = Number(data?.typeID);
    return Number.isInteger(id) && id > 0 ? id : 0;
  } catch {
    return 0;
  }
}

async function esiIds(name, lang, timeoutMs) {
  try {
    const url = `${ESI}/universe/ids/?datasource=tranquility&language=${encodeURIComponent(lang)}`;
    const { data } = await fetchJson(url, {
      method: 'POST',
      headers: {
        accept: 'application/json',
        'content-type': 'application/json',
        'user-agent': UA
      },
      body: JSON.stringify([name])
    }, timeoutMs);
    const arr = Array.isArray(data?.inventory_types) ? data.inventory_types : [];
    const hit = arr.find((x) => Number(x?.id) > 0);
    return hit ? { id: Number(hit.id), name: String(hit.name || name) } : null;
  } catch {
    return null;
  }
}

function fuzzyMatches(map, key, limit = 8) {
  if (!map || key.length < 2) return [];
  const out = [];
  const seen = new Set();
  for (const [k, v] of map) {
    if (k === key || seen.has(v.id)) continue;
    const hit = k.includes(key) || (key.length >= 3 && key.includes(k));
    if (!hit) continue;
    out.push(v);
    seen.add(v.id);
    if (out.length >= limit * 3) break;
  }
  out.sort((a, b) => {
    const ak = String(a.name).toLowerCase().startsWith(key) ? 0 : 1;
    const bk = String(b.name).toLowerCase().startsWith(key) ? 0 : 1;
    return ak - bk || String(a.name).length - String(b.name).length;
  });
  return out.slice(0, limit);
}

async function getTypeInfo(id, timeoutMs) {
  const key = String(id);
  const rec = state.typeInfo.get(key);
  if (rec && Date.now() - rec.at < TYPEINFO_TTL) return rec.value;
  try {
    const { data } = await fetchJson(`${ESI}/universe/types/${id}/?datasource=tranquility&language=zh`, {
      headers: { accept: 'application/json', 'user-agent': UA }
    }, timeoutMs);
    const value = {
      id: Number(data?.type_id) || Number(id),
      name: String(data?.name || '').trim()
    };
    state.typeInfo.set(key, { at: Date.now(), value });
    return value;
  } catch {
    return null;
  }
}

/** 先用 eve-item-resolver 插件的严格别名表；没命中再走原来的在线解析。 */
async function parseWithItemPlugin(raw) {
  if (typeof itemResolverCapability !== 'function') return null;
  try {
    const parsed = await itemResolverCapability('eve.item-resolve', { text: raw });
    return parsed && Array.isArray(parsed.matches) ? parsed : null;
  } catch {
    return null;
  }
}

async function resolveType(query, timeoutMs) {
  const raw = String(query ?? '').trim();
  const key = normalizeKey(raw);
  if (!key) return null;
  if (state.names.has(key)) return state.names.get(key);

  // 直接给 type_id 也认
  if (/^\d{1,9}$/u.test(raw)) {
    const id = Number(raw);
    if (!Number.isInteger(id) || id <= 0) return null;
    const info = await getTypeInfo(id, timeoutMs);
    if (!info) return null;
    const item = { id, name: info.name || `Type ${id}`, query: raw };
    state.names.set(key, item);
    return item;
  }

  // 先查 eve-item-resolver 的严格别名表：伊什塔/yst/脑浆/大注入器/lsi/PLEX 等
  // 都在那里一次定死；没命中才继续走下面的在线解析（表外物品）。
  const parsed = await parseWithItemPlugin(raw);
  if (parsed?.matches?.length) {
    if (parsed.matches.length > 1 || parsed.ambiguous) {
      return { ambiguous: parsed.matches.map((m) => ({ id: m.typeId, name: m.name })) };
    }
    const match = parsed.matches[0];
    const info = await getTypeInfo(match.typeId, timeoutMs);
    const display = info?.name || match.name || raw;
    const item = {
      id: match.typeId,
      name: match.typeId === PLEX_TYPE_ID && !String(display).includes('PLEX')
        ? `${display}（PLEX）`
        : display,
      quantity: Number(match.quantity) || 0,
      query: raw
    };
    state.names.set(key, item);
    return item;
  }

  // PLEX/伊甸币单独处理：它的行情不在 The Forge，而在全球 PLEX 市场（19000001）。
  if (isPlexQuery(raw)) {
    const info = await getTypeInfo(PLEX_TYPE_ID, timeoutMs);
    const item = {
      id: PLEX_TYPE_ID,
      name: info?.name ? `${info.name}（PLEX）` : '伊甸币（PLEX）',
      query: raw
    };
    state.names.set(key, item);
    return item;
  }

  const hasCjk = /[\u3400-\u9fff]/u.test(raw);
  let hit = null;

  if (!hasCjk) {
    const id = await fuzzworkTypeId(raw, timeoutMs);
    if (id) hit = { id, name: raw };
  }
  if (!hit) {
    hit = await esiIds(raw, hasCjk ? 'zh' : 'en', timeoutMs);
    if (!hit && hasCjk) hit = await esiIds(raw, 'en', timeoutMs);
  }

  if (!hit) {
    const map = await loadZhMap(timeoutMs);
    if (map) {
      let entry = map.get(key);
      if (!entry) {
        const stripped = key.replace(/(?:蓝图|级)$/u, '');
        if (stripped && stripped !== key) entry = map.get(stripped);
      }
      if (entry) {
        hit = { id: entry.id, name: entry.name };
      } else {
        const candidates = fuzzyMatches(map, key, 8);
        if (candidates.length === 1) hit = { id: candidates[0].id, name: candidates[0].name };
        else if (candidates.length > 1) return { ambiguous: candidates };
      }
    }
  }

  if (!hit) return null;

  const info = await getTypeInfo(hit.id, timeoutMs);
  const display = info?.name || hit.name || raw;
  const item = {
    id: hit.id,
    name: /[A-Za-z]/u.test(raw) && display !== raw ? `${display}（${raw}）` : display,
    query: raw
  };
  state.names.set(key, item);
  return item;
}

function suggestionsFromCache(query) {
  if (!state.zhMap) return [];
  return fuzzyMatches(state.zhMap, normalizeKey(query), 5).map((x) => x.name).filter(Boolean);
}

// ─────────────────────────────────────────────── 行情
async function fetchAllOrders(typeId, timeoutMs, regionId = REGION_ID) {
  const all = [];
  let page = 1;
  let pages = 1;
  while (page <= pages && page <= 10) {
    const url = `${ESI}/markets/${regionId}/orders/?datasource=tranquility&order_type=all&type_id=${typeId}&page=${page}`;
    const res = await fetchWithTimeout(url, {
      headers: { accept: 'application/json', 'user-agent': UA }
    }, timeoutMs);
    if (!res.ok) throw new Error(`市场接口 HTTP ${res.status}`);
    const data = await res.json();
    if (!Array.isArray(data)) throw new Error('市场接口返回格式异常');
    all.push(...data);
    const hp = Number(res.headers.get('x-pages'));
    pages = Number.isFinite(hp) && hp > 0 ? Math.min(10, hp) : 1;
    page += 1;
  }
  return all;
}

function filterOrders(all, scope) {
  return (Array.isArray(all) ? all : []).filter((o) => {
    if (!o || !Number.isFinite(Number(o.price)) || Number(o.price) <= 0) return false;
    if (scope === 'station') return Number(o.location_id) === JITA_STATION_ID;
    if (scope === 'system') return Number(o.system_id) === JITA_SYSTEM_ID;
    return true;
  });
}

async function getScopeData(typeId, scope, conf) {
  const key = `${typeId}:${scope}`;
  const ttl = Math.max(0, num(conf.cacheSeconds, DEFAULTS.cacheSeconds)) * 1000;
  const cached = state.orders.get(key);
  if (cached && ttl > 0 && Date.now() - cached.at < ttl) return cached.value;
  if (state.inflight.has(key)) return state.inflight.get(key);

  const promise = (async () => {
    const regionId = scope === 'plex' ? PLEX_REGION_ID : REGION_ID;
    const all = await fetchAllOrders(typeId, num(conf.timeoutMs, DEFAULTS.timeoutMs), regionId);
    const filtered = filterOrders(all, scope);
    const sells = filtered
      .filter((o) => o.is_buy_order !== true)
      .sort((a, b) => Number(a.price) - Number(b.price) || Number(b.volume_remain) - Number(a.volume_remain));
    const buys = filtered
      .filter((o) => o.is_buy_order === true)
      .sort((a, b) => Number(b.price) - Number(a.price) || Number(b.volume_remain) - Number(a.volume_remain));
    const value = { scope, sells, buys, at: Date.now(), total: filtered.length };
    if (ttl > 0) {
      state.orders.set(key, { at: Date.now(), value });
      if (state.orders.size > 200) {
        const cut = Date.now() - 10 * 60 * 1000;
        for (const [k, v] of state.orders) {
          if (v.at < cut) state.orders.delete(k);
        }
      }
    }
    return value;
  })().finally(() => state.inflight.delete(key));

  state.inflight.set(key, promise);
  return promise;
}

async function getMarket(typeId, scope, conf) {
  // PLEX 不按吉他 4-4/星系查：它有独立的全球市场，订单跨所有空间站。
  if (Number(typeId) === PLEX_TYPE_ID) return getScopeData(typeId, 'plex', conf);

  const primary = await getScopeData(typeId, scope, conf);
  if (scope === 'station' && primary.sells.length === 0 && primary.buys.length === 0) {
    const system = await getScopeData(typeId, 'system', conf);
    if (system.sells.length || system.buys.length) return { ...system, fallbackFrom: 'station' };
  }
  return primary;
}

function orderLine(o, index) {
  const minVolume = Number(o?.min_volume) || 1;
  const minText = minVolume > 1 ? `（起 ${fmtQty(minVolume)}）` : '';
  return `${index + 1}. ${fmtIsk(o.price)} × ${fmtQty(o.volume_remain)}${minText}`;
}

/** 按盘口逐档吃单，算 qty 个的实际总价（不足时返回已成交量）。 */
function totalForQuantity(orders, qty) {
  let remaining = Math.max(0, Math.floor(Number(qty) || 0));
  let total = 0;
  let filled = 0;
  for (const order of orders) {
    if (remaining <= 0) break;
    const available = Math.max(0, Number(order.volume_remain) || 0);
    const take = Math.min(remaining, available);
    if (take <= 0) continue;
    total += take * Number(order.price);
    remaining -= take;
    filled += take;
  }
  return { total, filled, complete: remaining <= 0 };
}

function scopeLabel(scope) {
  if (scope === 'station') return '吉他 4-4';
  if (scope === 'system') return '吉他星系';
  if (scope === 'plex') return '全球 PLEX 市场';
  return 'The Forge 星域';
}

function formatMarket(item, market, conf, totalQuantity = 1) {
  const topN = clamp(conf.topN, 1, 10);
  const qty = Math.max(1, Math.min(1_000_000, Math.floor(Number(totalQuantity) || 1)));
  const sells = market.sells.slice(0, topN);
  const buys = market.buys.slice(0, topN);
  const displayName = qty > 1 ? `${item.name}×${fmtQty(qty)}` : item.name;
  const lines = [`【${displayName}】${scopeLabel(market.scope)} · 宁静服`];

  if (market.fallbackFrom === 'station') {
    lines[0] += '（4-4 无单，已扩到星系）';
  }

  const bestSell = sells.length ? Number(sells[0].price) : 0;
  const bestBuy = buys.length ? Number(buys[0].price) : 0;
  const mid = bestSell > 0 && bestBuy > 0 ? (bestSell + bestBuy) / 2 : 0;

  if (bestSell > 0) {
    lines.push(`卖单最低：${fmtIsk(bestSell)} / 个`);
  } else {
    lines.push('卖单：暂无');
  }

  if (mid > 0) {
    lines.push(`中间价：${fmtIsk(mid)} / 个`);
  }

  if (bestBuy > 0) {
    lines.push(`收单最高：${fmtIsk(bestBuy)} / 个`);
  } else {
    lines.push('收单：暂无');
  }

  if (bestSell > 0 && bestBuy > 0) {
    const diff = bestSell - bestBuy;
    const pct = bestBuy > 0 ? (diff / bestBuy) * 100 : 0;
    lines.push(`价差：${diff < 0 ? '−' : ''}${fmtIsk(Math.abs(diff))} / 个（${pct >= 0 ? '+' : ''}${pct.toFixed(2)}%）`);

    if (qty > 1) {
      const sellFill = totalForQuantity(market.sells, qty);
      const buyFill = totalForQuantity(market.buys, qty);
      const fillText = (fill) => fill.complete
        ? fmtIsk(fill.total)
        : `${fmtIsk(fill.total)}（仅 ${fmtQty(fill.filled)}/${fmtQty(qty)}）`;
      lines.push(`${fmtQty(qty)} 个总价：卖单 ${fillText(sellFill)} / 中间 ${fmtIsk(mid * qty)} / 收单 ${fillText(buyFill)}`);
    }
  } else if (qty > 1 && (bestSell > 0 || bestBuy > 0)) {
    const sellSide = bestSell > 0;
    const fill = totalForQuantity(sellSide ? market.sells : market.buys, qty);
    const fillText = fill.complete
      ? fmtIsk(fill.total)
      : `${fmtIsk(fill.total)}（仅 ${fmtQty(fill.filled)}/${fmtQty(qty)}）`;
    lines.push(`${fmtQty(qty)} 个${sellSide ? '卖单' : '收单'}总价：${fillText}`);
  }

  lines.push('');

  if (sells.length) {
    lines.push(market.sells.length > sells.length
      ? `卖单前 ${sells.length} 笔（共 ${market.sells.length} 笔）`
      : `卖单（共 ${market.sells.length} 笔）`);
    sells.forEach((o, i) => lines.push(orderLine(o, i)));
  }

  if (buys.length) {
    lines.push(market.buys.length > buys.length
      ? `收单前 ${buys.length} 笔（共 ${market.buys.length} 笔）`
      : `收单（共 ${market.buys.length} 笔）`);
    buys.forEach((o, i) => lines.push(orderLine(o, i)));
  }

  if (!sells.length && !buys.length) lines.push('当前没有任何挂单。');

  lines.push('', `数据：ESI（宁静服） · ${fmtTime(market.at)}`);
  return lines.join('\n');
}

// ─────────────────────────────────────────────── 发送
function usageText() {
  return [
    '用法：查价 物品名 [x数量]（估价 / 价格 / 多少钱 / 值多少 / ojita 同义）',
    '例如：查价 伊甸币 x10 / 查价 月卡 / 查价 月卡 x2 / 估价 脑浆 / ojita 伊什塔',
    '月卡 = 500 伊甸币；PLEX 走全球 PLEX 市场，其他物品默认查吉他 4-4。'
  ].join('\n');
}

async function sendReply(ctx, text) {
  if (!ctx?.sender?.sendTextBatch || !ctx?.chatKey) throw new Error('当前环境无法发送消息');
  const trigger = Array.isArray(ctx?.session?.trigger) ? ctx.session.trigger[0] : null;
  const mid = trigger?.mid;
  const options = mid !== undefined && mid !== null && Number.isFinite(Number(mid))
    ? { replyToMessageId: Number(mid) }
    : {};
  return ctx.sender.sendTextBatch(ctx.chatKey, [text], options);
}

function rememberSent(ctx, result) {
  try {
    const sent = Array.isArray(result?.sent) ? result.sent : [];
    if (!sent.length) return;
    ctx.session?.sent?.push(...sent.map((s) => ({ type: 'text', text: s.text, at: s.at })));
    ctx.emit?.('session-update', ctx.session?.id);
  } catch { /* 会话留档失败不影响已发出的消息 */ }
}

async function trySend(ctx, text) {
  try {
    const result = await sendReply(ctx, text);
    rememberSent(ctx, result);
    return true;
  } catch (error) {
    warn(`发送市场结果失败：${error?.message ?? error}`);
    return false;
  }
}

// ─────────────────────────────────────────────── 工具主体
async function doQuery(ctx, args) {
  const conf = cfg();

  if (!ctx?.chatKey || !ctx?.sender?.sendTextBatch) {
    return { content: '错误：当前环境拿不到发送消息的能力，这次查不了。', isError: true };
  }
  if (ctx.kind !== 'group' && conf.allowPrivate !== true) {
    return { content: '这个查询默认只在群里生效。请让群友在群里发送「查价 物品名」。', isError: true };
  }

  const normalized = normalizeItem(args?.item);
  const extracted = extractQuantity(normalized);
  const raw = extracted.text;
  const explicitQuantity = extracted.quantity || 0;
  if (!raw) {
    const sent = await trySend(ctx, usageText());
    return { content: sent ? '已把用法发到群里。不要重复发送。' : '没有物品名，用法提示也没能发出去。' };
  }

  const maxLen = clamp(conf.maxItemLength, 10, 60);
  if (raw.length > maxLen) {
    const sent = await trySend(ctx, `物品名太长了（超过 ${maxLen} 字），请只发物品名，例如：查价 伊什塔级`);
    return { content: sent ? '已提示群友缩短物品名。不要重复发送。' : '物品名太长，提示也没能发出去。' };
  }

  const now = Date.now();
  const cooldown = Math.max(0, num(conf.cooldownSeconds, DEFAULTS.cooldownSeconds)) * 1000;
  const last = state.lastAt.get(ctx.chatKey) || 0;
  if (cooldown > 0 && now - last < cooldown) {
    return { content: '刚刚已经查过并发送了，这次不重复发送。请直接结束本轮。' };
  }
  state.lastAt.set(ctx.chatKey, now);

  const scope = normalizeScope(args?.scope ?? conf.scope);
  let item;
  try {
    item = await resolveType(raw, num(conf.timeoutMs, DEFAULTS.timeoutMs));
  } catch (error) {
    warn(`解析物品名失败：${error?.message ?? error}`);
    const sent = await trySend(ctx, `「${raw}」的物品名解析失败（${humanError(error)}），稍后再试。`);
    return { content: sent ? '已把失败提示发到群里。不要重试，直接结束本轮。' : '解析失败，而且提示也没能发出去。' };
  }

  if (item?.ambiguous) {
    const names = item.ambiguous.slice(0, 5).map((x) => x.name).filter(Boolean);
    const sent = await trySend(ctx, [
      `「${raw}」对应多个物品：`,
      names.join(' / '),
      `请写完整一点，例如：查价 ${names[0] || '伊什塔级'}`
    ].join('\n'));
    return { content: sent ? '已让群友补充更完整的物品名。不要重复发送。' : '没找到唯一物品，提示也没能发出去。' };
  }

  if (!item) {
    const suggestions = suggestionsFromCache(raw);
    const lines = [`没找到「${raw}」。`];
    if (suggestions.length) lines.push(`你是不是想查：${suggestions.join(' / ')}？`);
    lines.push('可以发英文名或更完整的名称，例如：查价 伊什塔级');
    const sent = await trySend(ctx, lines.join('\n'));
    return { content: sent ? '已把「没找到」和建议发到群里。不要重复发送。' : '没找到物品，提示也没能发出去。' };
  }

  let market;
  try {
    market = await getMarket(item.id, scope, conf);
  } catch (error) {
    warn(`查询 ${item.name}（type ${item.id}）行情失败：${error?.message ?? error}`);
    const sent = await trySend(ctx, `「${item.name}」的市场数据暂时拉不到（${humanError(error)}），稍后再试。`);
    return { content: sent ? '已把失败提示发到群里。不要重试，直接结束本轮。' : '行情查询失败，提示也没能发出去。' };
  }

  const baseQuantity = Math.max(1, Number(item.quantity) || 1);
  const totalQuantity = Math.max(1, Math.min(1_000_000, baseQuantity * (explicitQuantity || 1)));
  const text = formatMarket(item, market, conf, totalQuantity);
  const sent = await trySend(ctx, text);
  if (!sent) {
    return { content: '行情查到了，但发送到群里失败。不要重复查询，直接结束本轮。', isError: true };
  }

  const marketName = market.scope === 'plex' ? '全球 PLEX 市场数据' : '吉他市场数据';
  const quantityText = totalQuantity > 1 ? `×${fmtQty(totalQuantity)}` : '';
  return {
    content: `已把「${item.name}${quantityText}」的${marketName}发到群里（卖单 ${market.sells.length} 笔 / 收单 ${market.buys.length} 笔）。`
      + '不要复述价格，也不要再调用 send_message。直接结束本轮。'
  };
}

// ─────────────────────────────────────────────── 入口
export function setup(api) {
  log = typeof api?.log === 'function' ? api.log : () => {};
  warn = typeof api?.warn === 'function' ? api.warn : () => {};
  httpFetch = typeof api?.fetch === 'function' ? api.fetch : null;
  itemResolverCapability = typeof api?.capability === 'function' ? api.capability : null;

  const base = typeof api?.config === 'function' ? api.config : null;
  readCfg = () => {
    try {
      return base ? (base() || {}) : {};
    } catch {
      return {};
    }
  };

  if (!httpFetch) {
    warn('没有拿到网络能力（web_fetch）—— 查询行情会失败。请检查 skill.json 的 permissions。');
  }

  api.registerTool({
    id: 'jita_market',
    name: '吉他市场查价',
    description:
      '查询 EVE Online 宁静服（Tranquility）吉他星系（Jita）的市场卖单、收单、中间价、价差和指定数量的总价，并把结果直接发到当前群。'
      + '当群友发送「查价 物品名」「估价 物品名」「价格 物品名」「多少钱」「值多少」「ojita 物品名」时，必须调用本工具；'
      + '物品名支持中文或英文（如“伊什塔级”“三钛合金”“Ishtar”“Tritanium”）。'
      + '可以带数量：x10 表示 10 个；月卡等于 500 伊甸币，月卡 x2 就是 1000 伊甸币。'
      + 'PLEX（伊甸币）会自动查全球 PLEX 市场。'
      + '工具会自己发送结果，调用成功后不要复述价格，也不要再调用 send_message。'
      + '默认查吉他 4-4 空间站；该站完全无单时会自动扩到整个吉他星系。',
    category: 'query',
    icon: '📈',
    requiresVision: false,
    parameters: {
      type: 'object',
      properties: {
        item: {
          type: 'string',
          description: '要查询的 EVE 物品名，中文或英文，例如“伊什塔级”“三钛合金”“Ishtar”“Tritanium”。可以带数量，例如“伊甸币 x10”“月卡”“月卡 x2”“脑浆”。不要带“查价”“估价”“ojita”等查询词。'
        },
        scope: {
          type: 'string',
          enum: ['station', 'system', 'region'],
          description: '可选查询范围：station=吉他 4-4 空间站（默认）；system=整个吉他星系；region=The Forge 星域。'
        }
      },
      required: ['item']
    },
    async execute(ctx, args) {
      return doQuery(ctx, args);
    }
  });

  log('吉他市场查价已加载：群友发「查价 物品名」即可查询（数据源 ESI，宁静服）');
}

/** 自检必须同步：网络错误在工具执行时再报，不能因为一次断网就把技能判死。 */
export function available() {
  if (typeof httpFetch !== 'function') return { ok: false, reason: '没有拿到 web_fetch 网络权限' };
  return { ok: true };
}

/** 卸载/热重载时清掉内存缓存；磁盘上的中文名表保留，下次直接用。 */
export function dispose() {
  state.orders.clear();
  state.names.clear();
  state.typeInfo.clear();
  state.lastAt.clear();
  state.inflight.clear();
  state.zhMap = null;
  state.zhMapPromise = null;
  itemResolverCapability = null;
}

/** 给排查/测试用的纯函数出口（加载器不消费）。 */
export const internals = {
  normalizeItem,
  normalizeScope,
  fmtIsk,
  formatMarket,
  filterOrders,
  fuzzyMatches,
  resolveType
};
