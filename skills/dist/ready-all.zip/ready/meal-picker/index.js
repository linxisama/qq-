// 今天吃什么 —— LLM 型技能（QQ Agent 规范）
//
// 场景：有人问「午饭吃什么」「晚饭吃什么」，模型调用本技能的 pick_meal 工具，
// 拿到一个从各国美食里随机抽出来的菜名，再按人设口吻发到群里/私聊。
//
// 设计约束（改动前先看）：
//   0) 只从「能正经当一顿饭」的菜里抽，比例固定：正餐（餐馆能点、家里能做）2/3，
//      KFC 这类快餐 1/3。小吃/点心/冷盘不进池子，永远抽不到。
//   1) 菜名只能来自这里的名单 —— 模型只负责组织语言，不负责发明菜品，
//      否则很容易出现「红烧内」「草莓麻婆豆腐」这种不存在的菜。
//   2) 次数按「人 + 餐次 + 自然日」计，跨群共享：午饭和晚饭各有一套额度，
//      今天在 A 群问过，到 B 群接着扣。自然日按 Asia/Shanghai 切，跟用户的作息一致。
//   3) 次数存在内存里，机器人重启（或热重载本文件）后清零。
//      这个功能丢一次计数无所谓，不值得为它往 data/ 里写文件。
//
// 工具返回的是「文本结果」，由模型自己走 send_message 发出去 —— 这样能保留
// 人设的语气（比如顺手 @ 一下提问的人），也符合「回复类功能做成技能」的定位。

// 菜名 + 国家/地区。按权重纯随机抽，不做国家或口味的平衡。
const DISHES = [
  // 中国
  { name: '宫保鸡丁', country: '中国' },
  { name: '麻婆豆腐', country: '中国' },
  { name: '番茄炒蛋', country: '中国' },
  { name: '红烧肉', country: '中国' },
  { name: '鱼香肉丝', country: '中国' },
  { name: '兰州牛肉面', country: '中国' },
  { name: '小笼包', country: '中国' },
  { name: '煲仔饭', country: '中国' },
  { name: '酸菜鱼', country: '中国' },
  { name: '黄焖鸡米饭', country: '中国' },
  { name: '重庆小面', country: '中国' },
  { name: '扬州炒饭', country: '中国' },
  { name: '韭菜猪肉饺子', country: '中国' },
  { name: '螺蛳粉', country: '中国' },
  { name: '热干面', country: '中国' },
  { name: '糖醋排骨', country: '中国' },
  { name: '干锅花菜', country: '中国' },
  { name: '潮汕牛肉火锅', country: '中国' },

  // 日本
  { name: '寿司', country: '日本' },
  { name: '豚骨拉面', country: '日本' },
  { name: '日式咖喱饭', country: '日本' },
  { name: '天妇罗', country: '日本' },
  { name: '鳗鱼饭', country: '日本' },
  { name: '亲子丼', country: '日本' },
  { name: '关东煮', country: '日本' },
  { name: '炸猪排', country: '日本' },
  { name: '乌冬面', country: '日本' },

  // 韩国
  { name: '石锅拌饭', country: '韩国' },
  { name: '部队锅', country: '韩国' },
  { name: '韩式炸鸡', country: '韩国' },
  { name: '韩式冷面', country: '韩国' },
  { name: '韩式烤肉', country: '韩国' },
  { name: '泡菜汤', country: '韩国' },
  { name: '紫菜包饭', country: '韩国' },
  { name: '辣炒年糕', country: '韩国' },

  // 泰国
  { name: '冬阴功汤', country: '泰国' },
  { name: '泰式炒河粉', country: '泰国' },
  { name: '绿咖喱鸡', country: '泰国' },
  { name: '菠萝炒饭', country: '泰国' },
  { name: '泰式烤鸡', country: '泰国' },

  // 越南
  { name: '越南河粉', country: '越南' },
  { name: '越南春卷', country: '越南' },
  { name: '越式法棍三明治', country: '越南' },
  { name: '越式烤肉米线', country: '越南' },

  // 印度
  { name: '黄油咖喱鸡', country: '印度' },
  { name: '印度飞饼', country: '印度' },
  { name: '鹰嘴豆咖喱', country: '印度' },
  { name: '坦都里烤鸡', country: '印度' },
  { name: '印度香饭', country: '印度' },

  // 新加坡 / 马来西亚
  { name: '海南鸡饭', country: '新加坡' },
  { name: '叻沙', country: '新加坡' },
  { name: '肉骨茶', country: '马来西亚' },
  { name: '咖喱鱼头', country: '马来西亚' },
  { name: '沙嗲串', country: '马来西亚' },

  // 意大利
  { name: '肉酱意面', country: '意大利' },
  { name: '玛格丽特披萨', country: '意大利' },
  { name: '千层面', country: '意大利' },
  { name: '米兰烩饭', country: '意大利' },
  { name: '卡邦尼意面', country: '意大利' },

  // 法国
  { name: '法式洋葱汤', country: '法国' },
  { name: '法式可丽饼', country: '法国' },
  { name: '红酒炖牛肉', country: '法国' },
  { name: '法棍三明治', country: '法国' },
  { name: '洛林咸派', country: '法国' },

  // 西班牙
  { name: '西班牙海鲜饭', country: '西班牙' },

  // 墨西哥
  { name: '墨西哥塔可', country: '墨西哥' },
  { name: '墨西哥卷饼', country: '墨西哥' },
  { name: '墨西哥芝士薄饼', country: '墨西哥' },

  // 美国
  { name: '美式汉堡', country: '美国' },
  { name: '美式炸鸡', country: '美国' },
  { name: 'BBQ 肋排', country: '美国' },
  { name: '热狗', country: '美国' },
  { name: '凯撒沙拉', country: '美国' },
  { name: '芝士通心粉', country: '美国' },

  // 土耳其
  { name: '土耳其烤肉', country: '土耳其' },
  { name: '土耳其披萨', country: '土耳其' },
  { name: '鹰嘴豆泥', country: '土耳其' },
  { name: '土耳其烤肉卷', country: '土耳其' },

  // 希腊
  { name: '希腊沙拉', country: '希腊' },
  { name: '穆萨卡', country: '希腊' },
  { name: '希腊烤肉串', country: '希腊' },
  { name: '羊奶酪派', country: '希腊' },

  // 德国
  { name: '德式香肠配酸菜', country: '德国' },
  { name: '德式猪肘', country: '德国' },
  { name: '德式土豆泥', country: '德国' },

  // 英国
  { name: '炸鱼薯条', country: '英国' },
  { name: '牧羊人派', country: '英国' },
  { name: '英式早餐', country: '英国' },

  // 巴西
  { name: '巴西烤肉', country: '巴西' },
  { name: '巴西黑豆炖肉', country: '巴西' },

  // 快餐 / 连锁（会出现在结果里，但权重低于正餐）
  { name: '肯德基吮指原味鸡', country: '美国' },
  { name: '肯德基香辣鸡腿堡', country: '美国' },
  { name: '麦当劳巨无霸', country: '美国' },
  { name: '麦当劳麦辣鸡腿堡', country: '美国' },
  { name: '必胜客超级至尊披萨', country: '美国' },
  { name: '汉堡王皇堡', country: '美国' },
  { name: '赛百味金枪鱼三明治', country: '美国' },
  { name: '塔可钟脆皮塔可', country: '美国' },
  { name: '德克士手枪腿', country: '中国' },
  { name: '华莱士炸鸡', country: '中国' },
  { name: '老乡鸡鸡汤套餐', country: '中国' },
  { name: '沙县拌面', country: '中国' },
  { name: '吉野家牛肉饭', country: '日本' }
];

// 目标比例：正餐 2/3、快餐 1/3。实现方式是「先抽类别，再在类别内均匀抽」——
// 这样比例和两类各有多少道菜无关，不会因为快餐条目少就被稀释。
// 小吃/点心/冷盘已从菜单里删掉，不进池子，永远不会出现。
const MEAL_SHARE = 2 / 3;

// 快餐/连锁（按名字匹配，不用给每条菜单独加字段）
const FAST_DISHES = new Set([
  '肯德基吮指原味鸡', '肯德基香辣鸡腿堡', '麦当劳巨无霸', '麦当劳麦辣鸡腿堡',
  '必胜客超级至尊披萨', '汉堡王皇堡', '赛百味金枪鱼三明治', '塔可钟脆皮塔可',
  '德克士手枪腿', '华莱士炸鸡', '老乡鸡鸡汤套餐', '沙县拌面', '吉野家牛肉饭',
  '热狗'
]);

const MEAL_LABEL = { lunch: '午饭', dinner: '晚饭', any: '这一顿' };
const VALID_MEALS = new Set(['lunch', 'dinner', 'any']);

// 当前技能配置（执行时通过 cfg() 读，保证设置页改了立刻生效）
let cfg = () => ({});
let log = () => {};

// 次数状态：按自然日整体切换，避免为每个用户记日期。
// counts: userId -> 今天已用次数
let dayStamp = '';
let counts = new Map();

function clampInt(value, min, max, fallback) {
  const n = Number(value);
  if (!Number.isFinite(n)) return fallback;
  return Math.max(min, Math.min(max, Math.trunc(n)));
}

/** 自然日（Asia/Shanghai）。en-CA 的日期格式正好是 YYYY-MM-DD。 */
function todayKey() {
  try {
    return new Intl.DateTimeFormat('en-CA', {
      timeZone: 'Asia/Shanghai',
      year: 'numeric',
      month: '2-digit',
      day: '2-digit'
    }).format(new Date());
  } catch {
    const d = new Date();
    const p = (n) => String(n).padStart(2, '0');
    return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}`;
  }
}

/**
 * 没说是午饭还是晚饭时（「今天吃啥」），按北京时间猜：
 * 15 点前算午饭，之后算晚饭。
 */
function currentMeal() {
  try {
    const h = Number(
      new Intl.DateTimeFormat('en-GB', {
        timeZone: 'Asia/Shanghai',
        hour: '2-digit',
        hourCycle: 'h23'
      }).format(new Date())
    );
    return h < 15 ? 'lunch' : 'dinner';
  } catch {
    return new Date().getHours() < 15 ? 'lunch' : 'dinner';
  }
}

/** 抽一道菜：先按 2/3 : 1/3 抽「正餐 / 快餐」类别，再在类别内均匀随机。 */
function pickDish() {
  const mealDishes = DISHES.filter((d) => !FAST_DISHES.has(d.name));
  const fastDishes = DISHES.filter((d) => FAST_DISHES.has(d.name));
  const pool = Math.random() < MEAL_SHARE ? mealDishes : fastDishes;
  if (!pool.length) return DISHES[Math.floor(Math.random() * DISHES.length)];
  return pool[Math.floor(Math.random() * pool.length)];
}

/** 今天这个人还剩几次（不消耗）。meal 区分午饭/晚饭，两套额度分开算。 */
function quotaOf(userId, meal, limit) {
  const today = todayKey();
  if (today !== dayStamp) {
    dayStamp = today;
    counts = new Map();
  }
  const used = counts.get(`${userId}|${meal}`) || 0;
  return { used, max: limit, left: Math.max(0, limit - used) };
}

/** 消耗一次；已经用满则 allowed=false，不再增加计数。 */
function consumeOnce(userId, meal, limit) {
  const q = quotaOf(userId, meal, limit);
  if (q.left <= 0) return { ...q, allowed: false };
  const used = q.used + 1;
  counts.set(`${userId}|${meal}`, used);
  return { used, max: limit, left: limit - used, allowed: true };
}

/**
 * 找出「这次是谁在问」。
 * ctx 本身不带发送者 id，但 ctx.session.trigger 是本轮的触发消息数组
 * （src/orchestrator.js 里 create({ trigger: triggerEntries })），每条带 senderId。
 * 从后往前找最后一条非自己发的消息；私聊兜底用 chatId。
 */
function resolveAsker(ctx) {
  const trigger = Array.isArray(ctx?.session?.trigger) ? ctx.session.trigger : [];
  for (let i = trigger.length - 1; i >= 0; i--) {
    const m = trigger[i];
    const uid = String(m?.senderId ?? '');
    if (m && !m.self && uid && uid !== 'self') {
      return { userId: uid, name: String(m.senderName || '') };
    }
  }
  if (ctx?.kind === 'private' && ctx?.chatId) {
    return { userId: String(ctx.chatId), name: '' };
  }
  // 最后兜底：从存档里找最近一条别人发的消息
  try {
    const recent = ctx?.store?.recent?.(ctx.chatKey, { limit: 10, includeSelf: false }) || [];
    const last = recent[recent.length - 1];
    if (last?.senderId) return { userId: String(last.senderId), name: String(last.senderName || '') };
  } catch {
    /* 读不到就算了，按匿名处理 */
  }
  return { userId: '', name: '' };
}

export function setup(api) {
  cfg = api.config;
  log = api.log || (() => {});

  api.registerTool({
    id: 'pick_meal',
    name: '今天吃什么',
    description:
      '从各国美食里随机抽一道菜（约三分之二是餐馆能点、在家能做的正餐，约三分之一是 KFC 这类快餐），用来回答「午饭吃什么」「晚饭吃什么」「今天吃啥」这类纠结吃什么的问题。' +
      '当有人明确在问这一餐/这一顿吃什么时使用；只是闲聊吃没吃饭、或者已经决定了吃什么，不要调用。' +
      '一次提问只给一个菜名，不要自己加菜或换菜。' +
      '每人每天午饭最多 2 次、晚饭最多 3 次，超限时工具会返回拒绝提示，照提示婉拒即可。' +
      '返回的菜名就是唯一推荐来源，不要自己编菜名或替换成别的菜。',
    category: 'utility',
    icon: '🍽️',
    parameters: {
      type: 'object',
      properties: {
        meal: {
          type: 'string',
          enum: ['lunch', 'dinner', 'any'],
          description: '对方问的是哪一餐：午饭填 lunch，晚饭填 dinner，没说清楚或问「今天吃啥」填 any。'
        }
      }
    },
    async execute(ctx, args) {
      try {
        const c = cfg() || {};
        const requested = VALID_MEALS.has(args?.meal) ? args.meal : 'any';
        const meal = requested === 'any' ? currentMeal() : requested;
        const limit = meal === 'lunch'
          ? clampInt(c.lunchPerDay, 1, 10, 2)
          : clampInt(c.dinnerPerDay, 1, 10, 3);
        const asker = resolveAsker(ctx);
        const userId = asker.userId || 'anonymous';

        const quota = consumeOnce(userId, meal, limit);
        if (!quota.allowed) {
          const who = asker.name || '这个人';
          log('次数用尽：%s（%s %s）', userId, meal, todayKey());
          return {
            content:
              `${who}今天${MEAL_LABEL[meal]}的 ${limit} 次推荐已经用完了（每人每天${MEAL_LABEL[meal]}限 ${limit} 次），本次不能再给。` +
              '请用自然、不伤人的语气婉拒，建议明天再问或者自己看看外卖软件；' +
              '不要推荐任何菜名，也不要把之前推荐过的菜再报一遍。'
          };
        }

        const dish = pickDish();
        const showCountry = c.showCountry !== false;
        const label = `${dish.name}${showCountry ? `（${dish.country}）` : ''}`;
        log('推荐 %s 给 %s（%s 第 %d/%d 次）', dish.name, userId, meal, quota.used, limit);

        const lead = asker.name ? `「${asker.name}」的${MEAL_LABEL[meal]}推荐` : `${MEAL_LABEL[meal]}推荐`;
        return {
          content:
            `${lead}：${label}\n` +
            `（今天还剩 ${quota.left} 次机会）`
        };
      } catch (error) {
        return { content: `挑菜失败：${error?.message ?? error}`, isError: true };
      }
    }
  });
}
