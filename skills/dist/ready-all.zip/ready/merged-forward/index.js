// skills/merged-forward/index.js
// 合并转发：把多条内容打包成一条「聊天记录」卡片发出去。
//
// 协议端支持的路子（已按本机的 SnowLuma 实现核对过）：
//   ① upload_forward_msg 上传节点数组 → { res_id / forward_id }
//   ② 再把 { type:'forward', data:{ id } } 当作一个消息段发出去
// 所以不需要"先发到自己的私聊再手动选中转发"—— 那只是人肉操作才需要的中间步骤。
import { createHash } from 'node:crypto';

let cfg = () => ({});
let log = () => {};

const QQ_NUMBER = /^\d{5,15}$/;

/** 允许作为转发目标的群号。留空 = 只允许当前会话（fail closed）。 */
function parseTargets(raw) {
  const parts = Array.isArray(raw) ? raw : String(raw ?? '').split(/[\s,，;；、|/]+/);
  const out = [];
  for (const part of parts) {
    const id = String(part ?? '').trim();
    if (QQ_NUMBER.test(id) && !out.includes(id)) out.push(id);
  }
  return out;
}

/** 阈值：超过几条就建议改用合并转发。设置里没填/填坏了都退回 3。 */
function readThreshold(settings) {
  const n = Number(settings?.autoForwardLines);
  if (!Number.isFinite(n)) return 3;
  return Math.max(1, Math.min(99, Math.round(n)));
}

/**
 * 把传进来的 lines 规整成节点文本：
 * - 支持数组，也支持一整段带换行的字符串
 * - 空行丢掉
 * - 单条过长按 maxChars 切开（而不是截断，避免吞内容）
 */
function normalizeLines(raw, { maxLines = 30, maxChars = 600 } = {}) {
  const source = Array.isArray(raw)
    ? raw
    : (typeof raw === 'string' ? raw.split(/\r?\n/) : []);
  const chunks = [];
  for (const item of source) {
    const text = String(item ?? '').replace(/\r/g, '').trim();
    if (!text) continue;
    if ([...text].length <= maxChars) {
      chunks.push(text);
      continue;
    }
    const chars = [...text];
    for (let i = 0; i < chars.length; i += maxChars) chunks.push(chars.slice(i, i + maxChars).join(''));
  }
  return { lines: chunks, tooMany: chunks.length > maxLines };
}

/**
 * 解析目标会话。
 * 支持：留空/here（当前会话）、self（机器人自己的私聊）、群号（必须在允许列表里）。
 */
function resolveTarget(raw, ctx, allowTargets) {
  const text = String(raw ?? '').trim();
  if (!text || text === 'here' || text === '当前会话' || text === '本群') {
    const isGroup = ctx.kind === 'group';
    return {
      chatKey: ctx.chatKey,
      kind: isGroup ? 'group' : 'private',
      groupId: isGroup ? Number(ctx.chatId) : 0,
      userId: isGroup ? 0 : Number(ctx.chatId),
      label: '当前会话'
    };
  }
  if (text === 'self' || text === '自己' || text === '私聊自己') {
    return { chatKey: `private:${ctx.selfId}`, kind: 'private', groupId: 0, userId: Number(ctx.selfId), label: '自己的私聊' };
  }
  const id = text.replace(/^group:/i, '').trim();
  if (!QQ_NUMBER.test(id)) {
    return { error: `看不懂这个目标：${text}。只支持「当前会话」、self（自己的私聊）或一个群号。` };
  }
  if (!allowTargets.includes(id)) {
    return {
      error: `目标群 ${id} 不在允许列表里（技能设置 → 允许转发到哪些群）。跨群转发必须先在设置里把这个群号加进去，这是防止有人指挥机器人往别的群刷屏。`
    };
  }
  return { chatKey: `group:${id}`, kind: 'group', groupId: Number(id), userId: 0, label: `群 ${id}` };
}

/** 卡片预览用的稳定指纹，供发送队列去重（同内容短时间内重复调用会被拦）。 */
function fingerprint(lines) {
  return createHash('sha1').update(lines.join('\u0000')).digest('hex').slice(0, 16);
}

/** 组装协议端要的节点数组：一条文本 = 一个节点 = 卡片里一个气泡。 */
function buildNodes(lines, { selfId, nickname }) {
  const uid = Number(selfId) || 0;
  return lines.map((line) => ({
    type: 'node',
    data: {
      user_id: uid,
      nickname: String(nickname || '我').slice(0, 40),
      // 用段数组而不是纯字符串：避免内容里的 [CQ:...] 被当成控制码解析
      content: [{ type: 'text', data: { text: line } }]
    }
  }));
}

// ── 发送护栏 ───────────────────────────────────────────────────────────
// 发卡片用的是协议端的 send_*_forward_msg，绕过了 sender 的限频/去重，
// 所以在这一层补一份等价的保护（同一会话 8 秒内不重复发、内容相同 3 分钟内只发一次）。
const recentSends = new Map(); // chatKey -> { key, at }

function guardSend(chatKey, key, now = Date.now()) {
  const prev = recentSends.get(chatKey);
  if (!prev) return '';
  if (prev.key === key && now - prev.at < 3 * 60 * 1000) {
    return '刚发过一模一样的合并转发，这次跳过（避免重复刷屏）。';
  }
  if (now - prev.at < 8000) {
    return '这个会话刚发过合并转发，等几秒再发（避免刷屏）。';
  }
  return '';
}

function recordSent(ctx, chatKey, { lines, messageId }) {
  recentSends.set(chatKey, { key: fingerprint(lines), at: Date.now() });
  try {
    ctx.store?.appendSelf?.(chatKey, { text: `[合并转发] ${lines.length} 条`, ts: Date.now(), mid: messageId ?? null });
  } catch { /* 留档失败不影响已发出的消息 */ }
}

/**
 * 发一张合并转发卡片。
 *
 * ⚠️ 这里必须用 `send_*_forward_msg`，不能"先 upload 再发 forward 段"：
 * 只带 res_id 的消息段会让协议端用默认值兜底（news 为空、tsum=1），
 * 手机端会自己去拉内容所以看着正常，**电脑端只认卡片里的预览行，于是显示乱码且点不开**。
 * 走 *_forward_msg 时协议端会用节点自己生成 source/summary/news，两个端都正常。
 *
 * 老版本协议端没有这些 action 时，退回 upload + forward 段（手机上正常，电脑上可能不好看）。
 */
async function sendCard(ctx, target, nodes, title) {
  const isGroup = target.kind === 'group';
  const action = isGroup ? 'send_group_forward_msg' : 'send_private_forward_msg';
  const params = isGroup
    ? { group_id: target.groupId, messages: nodes }
    : { user_id: target.userId, messages: nodes };
  if (title) params.source = title;

  try {
    const data = await ctx.onebot.call(action, params, 20000);
    return data?.message_id ?? null;
  } catch (error) {
    const text = String(error?.message ?? error);
    if (!/unknown|unsupported|not found|not implemented|404|500/i.test(text)) throw error;

    // 兼容老协议端
    const uploaded = await ctx.onebot.call('upload_forward_msg', {
      messages: nodes,
      ...(isGroup ? { group_id: target.groupId } : {})
    }, 15000);
    const forwardId = String(uploaded?.res_id || uploaded?.forward_id || uploaded?.id || '').trim();
    if (!forwardId) throw new Error('协议端没有返回转发 id');
    await ctx.sender.sendMedia(target.chatKey, [{ type: 'forward', data: { id: forwardId } }], {
      label: '[合并转发]',
      dedupeKey: fingerprint(nodes.map((n) => n.data.content[0].data.text))
    });
    return null;
  }
}

export function setup(api) {
  cfg = api.config;
  log = api.log;

  api.registerTool({
    id: 'send_forward',
    name: '合并转发',
    description: '把多条内容打包成一条「聊天记录」合并转发出去（卡片形式，点开才能看到每条）。当你要发的内容条数较多（阈值见技能设置）、或者一条消息太长会刷屏时使用；也可以用来把一段整理好的内容发到另一个群或机器人自己的私聊。参数 lines 是字符串数组，一条一个气泡。发完之后不要再用普通消息重复发同样的内容。',
    category: 'messaging',
    icon: '🗂️',
    parameters: {
      type: 'object',
      properties: {
        lines: {
          type: 'array',
          items: { type: 'string' },
          description: '要打包的每条内容，一条一个气泡，按顺序排列。最多 30 条，单条过长会自动切分。'
        },
        target: {
          type: 'string',
          description: '发到哪里：不填=当前会话；填 "self"=机器人自己的私聊；填群号=那个群（必须先在设置里允许）。'
        },
        title: {
          type: 'string',
          description: '卡片上方的来源标题，可选。不填就是「群聊的聊天记录」这类默认文案。'
        }
      },
      required: ['lines']
    },
    async execute(ctx, args = {}) {
      const settings = cfg() || {};
      const maxLines = Math.max(1, Math.min(99, Number(settings.maxLines) || 30));
      const maxChars = Math.max(50, Math.min(3000, Number(settings.maxCharsPerLine) || 600));

      // ① 参数校验
      const { lines, tooMany } = normalizeLines(args.lines, { maxLines, maxChars });
      if (!lines.length) {
        return { content: 'lines 是空的，没有可转发的内容。把要发的内容放进 lines 数组再试。', isError: true };
      }
      if (tooMany) {
        return {
          content: `要转发的条数超过上限（${maxLines} 条）。请压缩内容或分批发送，一次不要塞太多。`,
          isError: true
        };
      }

      // ② 目标与身份
      if (!ctx?.selfId) return { content: '拿不到机器人自己的 QQ 号，无法生成转发卡片。', isError: true };
      const allowTargets = parseTargets(settings.allowTargets);
      const target = resolveTarget(args.target, ctx, allowTargets);
      if (target.error) return { content: target.error, isError: true };

      // ③ 自己这层轻量护栏（直连协议端时会绕开 sender 的限频/去重）
      const key = fingerprint(lines);
      const blocked = guardSend(target.chatKey, key);
      if (blocked) return { content: blocked, isError: true };

      const nodes = buildNodes(lines, { selfId: ctx.selfId, nickname: ctx.botName || ctx.selfNickname });
      const title = String(args.title ?? '').trim();
      let messageId;
      try {
        messageId = await sendCard(ctx, target, nodes, title);
      } catch (error) {
        return { content: `合并转发发送失败：${error?.message ?? error}`, isError: true };
      }

      recordSent(ctx, target.chatKey, { lines, messageId });
      log(`合并转发已发出：${lines.length} 条 → ${target.label}`);
      return {
        content: `已把 ${lines.length} 条内容合并转发到「${target.label}」。这段内容不要再重复发一遍，也不用再补一句"已发送"。`
      };
    }
  });
}

export function available() {
  return { ok: true };
}

/**
 * 动态提示词：阈值来自设置，改完立刻生效（静态 prompt 写死数字的话，用户改了设置也不会变）。
 */
export function promptSections() {
  const settings = cfg() || {};
  const threshold = readThreshold(settings);
  const targets = parseTargets(settings.allowTargets);
  const where = targets.length
    ? `可以发到当前会话、机器人自己的私聊，或者这些群：${targets.join('、')}`
    : '目前只能发到当前会话和机器人自己的私聊（要跨群得先在设置里加群号）';
  return [{
    id: 'merged-forward-note',
    title: '合并转发',
    priority: 32,
    content: `要发的内容超过 ${threshold} 条、或者一条消息长到会刷屏时，别连发一堆普通消息，改用 merged-forward__send_forward 打包成一条聊天记录发出去：lines 传字符串数组，一条一个气泡。发完之后这段内容就不要再重复发一遍了。`
      + `短回复（${threshold} 句以内）不要用合并转发，直接说话。${where}。`
  }];
}

// 给隔离测试用（加载器不读这个导出）
export const __internals = {
  parseTargets, normalizeLines, resolveTarget, buildNodes, fingerprint, guardSend, recentSends, readThreshold
};
