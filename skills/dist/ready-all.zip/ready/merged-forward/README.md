# 合并转发（merged-forward）

让机器人把一段内容打包成**一条合并转发卡片**发出，而不是连发一堆消息刷屏。

## 做什么

提供一个发送工具：传入字符串数组，一条一个气泡，收件人要**点开卡片**才看到全部内容。

- 支持发到当前会话、指定群、或机主私聊
- 内置限频与去重：同会话 8 秒内不重复发、3 分钟内同内容不重发
- 超过条数阈值时可以自动把长内容转为卡片（`autoForwardLines`）

## 踩过的坑（重要）

卡片**必须**走协议端的 `send_group_forward_msg` / `send_private_forward_msg`，让协议端**自己生成预览**（source/summary/news）。

如果改成「先 upload 拿 res_id，再发一个 forward 段」，协议端会用兜底值填预览（news 为空、tsum=1）——手机端会自己按 resid 去拉内容所以看着正常，但**电脑端只渲染卡片预览行，会显示不全甚至点不开**。

## 安装

把本目录放进 QQ-Agent 的 `resources/app/skills/merged-forward/`，重启应用。

## 设置

| 设置 | 说明 |
|---|---|
| `autoForwardLines` | 超过多少条时自动改用卡片（0 = 不自动） |
| `allowTargets` | 允许转发到的群号/QQ 号，逗号分隔；留空按默认准入 |
| `maxLines` | 单张卡片最多几条 |
| `maxCharsPerLine` | 单条最多几个字 |

## 隐私

- 只发送你让它发的内容，不读取聊天记录
- 不联网、不上传
