// ADB 控制安卓手机（adb-control）—— LLM 型技能，放 skills/。
//
// ── 为什么是技能，不是插件 ───────────────────────────────────────────────
//   "该不该点、点哪、要不要继续"全是判断题，只能由模型来做 → registerTool
//   （plugin-loader 的 createSkillApi 只给 registerTool / config / log…，
//    技能没法主动发言，发言走模型的 send_message —— 控制手机正好是"模型干活"）。
//
// ── 前置条件（用户先在控制台配好）──────────────────────────────────────
//   1. 电脑能跑 adb（settings.adbBinary，默认 adb，需在系统 PATH）
//   2. 手机开启无线调试并已 adb connect 连上（settings.device 填 IP:端口）
//   3. 同一局域网（电脑网线、手机 WiFi 连同一路由器）
//
// ── 安全边界（这几条写死，别放开）──────────────────────────────────────
//   · 只用白名单动作（tap/swipe/text/back/home/key/open/screenshot/status），
//     不提供"任意 shell 命令"入口 —— 模型不可能在手机上学到足够危险的命令，
//     但它真的会被拿来做恶作剧，所以宁可少给。
//   · 每次执行前**不自动重连**：device 没填就只返回提示，让用户先去 adb devices
//     确认，而不是技能内部偷偷配对。
//   · input text 的转义做在参数层，靠 execFile 的数组参数（不走 shell），
//     从根上避免命令注入；输入内容里影响 input text 解析的字符统一转义。
//
// ── 踩坑备忘 ─────────────────────────────────────────────────────────────
//   · 截图走 `exec-out screencap -p`（stdout 直接是 PNG 字节），不要用
//     shell 重定向 —— execFile 不走 shell，重定向没用，还会拿不到二进制。
//   · 工具返回值直接进模型上下文：status/result 要给足"下一步怎么办"的提示，
//     但不要把整张 PNG 塞回去（那是几十 KB~几 MB）。
//   · 落盘状态一律避开 skills/（触发 fs.watch 热重载自激回路，见 api-beggar），
//     这里本技能无需落盘，截图文件写到 data/ 下即可。

const BUILD_TAG = 'v1.0.1';

// 纯 JS PNG 缩放（node 内置 zlib，无 ffmpeg 依赖）：把手机大截图缩到视觉模型
// 能接受的尺寸并重编码，同时记录缩放比供 tap/swipe 做坐标自动换算。
import { downscalePng } from './lib/png.js';

let cfg = () => ({});
let log = () => {};
let warn = () => {};
// child_process 在 setup 里懒加载（与 api-beggar 懒加载 fs 同理，避免顶层依赖）
let execFileImpl = null;

// 最近一次截图发给模型时的坐标缩放比：模型看到的是缩放图，tap/swipe 用它对
// 模型给的坐标做自动换算回真实屏幕坐标。不缩放时 sx=sy=1（恒等）。
let shotScale = { sx: 1, sy: 1, scaled: false };

// 声明了 web_fetch 权限后由 setup 注入（用于 adb_auto_task 把截图发给视觉模型判断）。
let fetchImpl = null;

/** 取 child_process.execFile（promise 化由 adbRun 完成）。 */
async function getExecFile() {
  if (execFileImpl) return execFileImpl;
  const m = await import('node:child_process');
  execFileImpl = m.execFile;
  return execFileImpl;
}

/** 读配置：脏值一律回退默认，绝不抛错。 */
function readSettings() {
  const c = cfg() || {};
  const str = (k, d) => { const s = String(c[k] ?? '').trim(); return s || d; };
  return {
    adbBinary: str('adbBinary', 'adb'),
    device: String(c.device ?? '').trim(),
    screenshotDir: String(c.screenshotDir ?? '').trim(),
    inputTimeoutMs: Number.isFinite(Number(c.inputTimeoutMs)) && Number(c.inputTimeoutMs) > 0
      ? Math.min(Number(c.inputTimeoutMs), 120000) : 20000
  };
}

function ok(payload) { return { content: JSON.stringify(payload, null, 1) }; }
function fail(message) { return { content: String(message), isError: true }; }

/**
 * 执行一条 adb 命令（用 execFile + 参数数组，不走 shell → 无注入风险）。
 * device 非空时自动拼 -s <device>。返回 { ok, stdout, stderr, code }。
 */
async function adbRun(s, args, { binary = false, timeout } = {}) {
  const exec = await getExecFile();
  const timeoutMs = timeout || s.inputTimeoutMs;
  const full = s.device ? ['-s', s.device, ...args] : args;
  return new Promise((resolve) => {
    exec(s.adbBinary, full, {
      timeout: timeoutMs,
      // ⚠️ 关键：二进制输出（exec-out screencap）必须按 Buffer 取，不能走默认 utf8。
      // 否则 PNG 第一个字节 0x89 会被解码成 U+FFFD（efbfbd），整张图头损坏，
      // 视觉 API 就会报 "unsupported image"。
      encoding: binary ? 'buffer' : 'utf8',
      maxBuffer: binary ? 256 * 1024 * 1024 : 64 * 1024 * 1024
    },
      (err, stdout, stderr) => {
        if (err) {
          resolve({ ok: false, stdout: '', stderr: String(stderr || ''), code: err.code ?? null, error: err.message });
          return;
        }
        resolve({ ok: true, stdout, stderr: String(stderr || ''), code: 0, error: null });
      });
  });
}

/** 人话化 adb 常见错误。 */
function humanizeAdbError(err) {
  const m = String(err || '');
  if (/not.*(found|recognized)|ENOENT|不是内部或外部命令/i.test(m)) return '找不到 adb（没在 PATH 里），请在技能设置里填 adb.exe 的完整路径';
  if (/connection refused|ECONNREFUSED|offline|无法访问/i.test(m)) return '连不上手机（设备离线或端口变了），请在电脑上重新 adb connect 并核对设备标识';
  if (/no devices|device not found/i.test(m)) return '没有可用设备：先检查无线调试连接，或确认 device 标识填对';
  return String(m || '未知错误').slice(0, 200);
}

/** 从 PNG 字节头读宽高（IHDR：16..23）。 */
function pngSize(buf) {
  if (!buf || buf.length < 24 || buf.readUInt32BE(0) !== 0x89504e47) return null;
  try { return { w: buf.readUInt32BE(16), h: buf.readUInt32BE(20) }; } catch { return null; }
}

/** 数字参数严格化，防模型传 NaN/负数/超长。 */
function intArg(v, { min = 0, max = 100000 } = {}) {
  const n = Number(v);
  if (!Number.isFinite(n)) return null;
  return Math.min(Math.max(Math.round(n), min), max);
}

// ── 主入口 ────────────────────────────────────────────────────────────────

export function setup(api) {
  cfg = api.config;
  log = api.log || (() => {});
  warn = api.warn || (() => {});
  fetchImpl = typeof api.fetch === 'function' ? api.fetch : null;

  api.registerTool({
    id: 'adb_status',
    name: '检查手机连接状态',
    description: '检查 adb 无线调试是否连着手机（status）并列出当前连接的设备。'
      + '什么时候用：① 群友让你控制手机、打开 App、点屏幕之前，先调它确认连没连上；'
      + '② 发现控制手机没反应、命令报错时，用它排查是不是连接断了。'
      + '没连上时返回的提示会告诉你该怎么处理（重新 connect / 核对设备标识）。',
    category: 'system',
    icon: '📱',
    defaultEnabled: true,
    parameters: { type: 'object', properties: {} },
    async execute() {
      try {
        const s = readSettings();
        // devices 不带 -s：全局列出所有设备，比只查目标更能说明问题
        const r = await adbRun(s, ['devices', '-l']);
        if (!r.ok) return fail('无法执行 adb：' + humanizeAdbError(r.stderr || r.error));
        const lines = String(r.stdout).split('\n').map((x) => x.trim()).filter(Boolean);
        const devices = lines.slice(1).filter((x) => /^[\w.:-]+/.test(x)).map((x) => x.split(/\s+/)[0]);
        const state = lines.slice(1).map((x) => x.split(/\s+/).slice(0, 2).join(' ')).filter(Boolean);
        const configured = s.device;
        const targetOnline = configured ? state.some((x) => x.startsWith(configured) && x.includes('device')) : false;
        return ok({
          adbBinary: s.adbBinary,
          configured: configured || '(未配置，多设备时必须填)',
          targetOnline,
          connected: devices,
          hint: targetOnline
            ? '手机已连上，可以直接调用 adb_control__adb_tap / adb_swipe / adb_text / adb_open 等。'
            : (configured
              ? '目标设备没在线：在电脑 cmd 里跑 adb connect ' + configured + ' 重连，再回来试；无线调试端口每次重开会变。'
              : '没配置 device，且当前连接了 ' + devices.length + ' 台设备。请在技能设置里把 device 填成 adb devices 里显示的那台（IP:端口）。')
        });
      } catch (error) {
        warn('adb_status 异常', error);
        return fail('检查连接失败：' + (error?.message ?? error));
      }
    }
  });

  api.registerTool({
    id: 'adb_tap',
    name: '点击屏幕',
    description: '在手机屏幕上指定坐标点击一次。坐标按**最近一次 adb_control__adb_screenshot 返回的图片**来填（工具会自动换算回真实屏幕坐标）。'
      + '必须先 adb_control__adb_status 确认手机连着；不知道坐标就先 adb_control__adb_screenshot 看截图判断。',
    category: 'system',
    icon: '👆',
    defaultEnabled: true,
    parameters: {
      type: 'object',
      properties: {
        x: { type: 'integer', description: '横坐标（按最近截图图上的坐标填）' },
        y: { type: 'integer', description: '纵坐标（按最近截图图上的坐标填）' }
      },
      required: ['x', 'y']
    },
    async execute(ctx, args) {
      const x = intArg(args?.x);
      const y = intArg(args?.y);
      if (x === null || y === null) return fail('x/y 必须是数字。先用 adb_control__adb_screenshot 拿到坐标。');
      // 若截图被缩放给模型看，把模型给的图上坐标换算回真实屏幕坐标
      const rx = Math.round(x * shotScale.sx);
      const ry = Math.round(y * shotScale.sy);
      try {
        const s = readSettings();
        if (!s.device) return fail('技能还没配置设备标识（device）。先在控制台填 adb devices 里那台的 IP:端口。');
        const r = await adbRun(s, ['shell', 'input', 'tap', String(rx), String(ry)]);
        if (!r.ok) return fail('点击失败：' + humanizeAdbError(r.stderr || r.error));
        return ok({ action: 'tap', given: [x, y], actual: [rx, ry], scaled: shotScale.scaled, result: '已点击。做完这一步，建议再截图确认效果，再决定下一步。' });
      } catch (error) {
        return fail('点击失败：' + (error?.message ?? error));
      }
    }
  });

  api.registerTool({
    id: 'adb_swipe',
    name: '滑动屏幕',
    description: '在手机屏幕上从 (x1,y1) 滑动到 (x2,y2)，duration 毫秒（默认 300，越短越快）。'
      + '可用于上滑/下滑/左滑/右滑。坐标按**最近一次 adb_control__adb_screenshot 返回的图片**填，工具会自动换算。',
    category: 'system',
    icon: '🖐️',
    defaultEnabled: true,
    parameters: {
      type: 'object',
      properties: {
        x1: { type: 'integer', description: '起点横坐标（按最近截图图上的坐标填）' },
        y1: { type: 'integer', description: '起点纵坐标（按最近截图图上的坐标填）' },
        x2: { type: 'integer', description: '终点横坐标（按最近截图图上的坐标填）' },
        y2: { type: 'integer', description: '终点纵坐标（按最近截图图上的坐标填）' },
        duration: { type: 'integer', description: '滑动时长毫秒，默认 300' }
      },
      required: ['x1', 'y1', 'x2', 'y2']
    },
    async execute(ctx, args) {
      const x1 = intArg(args?.x1), y1 = intArg(args?.y1);
      const x2 = intArg(args?.x2), y2 = intArg(args?.y2);
      if ([x1, y1, x2, y2].some((v) => v === null)) return fail('坐标必须是数字。');
      const d = intArg(args?.duration, { min: 0, max: 30000 }) ?? 300;
      // 换算：模型按最近截图（可能被缩放）给的坐标 → 真实屏幕坐标
      const rx1 = Math.round(x1 * shotScale.sx), ry1 = Math.round(y1 * shotScale.sy);
      const rx2 = Math.round(x2 * shotScale.sx), ry2 = Math.round(y2 * shotScale.sy);
      try {
        const s = readSettings();
        if (!s.device) return fail('技能还没配置设备标识（device）。');
        const r = await adbRun(s, ['shell', 'input', 'swipe', String(rx1), String(ry1), String(rx2), String(ry2), String(d)]);
        if (!r.ok) return fail('滑动失败：' + humanizeAdbError(r.stderr || r.error));
        return ok({ action: 'swipe', given: [x1, y1, x2, y2], actual: [rx1, ry1, rx2, ry2], scaled: shotScale.scaled, durationMs: d, result: '已滑动。建议截图确认效果。' });
      } catch (error) {
        return fail('滑动失败：' + (error?.message ?? error));
      }
    }
  });

  api.registerTool({
    id: 'adb_text',
    name: '输入文字',
    description: '在手机上当前聚焦的输入框里输入一段文字（走 adb input text）。'
      + '注意：只能输入 ASCII 里 input text 支持的字符，中文和部分符号可能打不出来或乱码（那是系统限制）。'
      + '空格会被自动转义成 %s。需要换行、点击候选等复杂操作时先截图看再一步步来。',
    category: 'system',
    icon: '⌨️',
    defaultEnabled: true,
    parameters: {
      type: 'object',
      properties: { text: { type: 'string', description: '要输入的文字（建议短一些，纯英文/数字最稳）' } },
      required: ['text']
    },
    async execute(ctx, args) {
      let text = String(args?.text ?? '').trim();
      if (!text) return fail('text 不能为空。');
      if (text.length > 500) text = text.slice(0, 500);
      // input text 的转义：空格 → %s；引号/反斜杠等特殊字符前加反斜杠。
      // 只处理"影响 input text 解析"的字符，其余原样传（数组参数已挡住 shell 注入）。
      let safe = text
        .replace(/\\/g, '\\\\')
        .replace(/"/g, '\\"')
        .replace(/'/g, "\\'")
        .replace(/ /g, '%s');
      try {
        const s = readSettings();
        if (!s.device) return fail('技能还没配置设备标识（device）。');
        const r = await adbRun(s, ['shell', 'input', 'text', safe]);
        if (!r.ok) return fail('输入失败：' + humanizeAdbError(r.stderr || r.error));
        return ok({ action: 'text', length: text.length, note: '已执行输入。若字符乱码或没进输入框，可能是系统限制，截图确认后换个输入法/方式。' });
      } catch (error) {
        return fail('输入失败：' + (error?.message ?? error));
      }
    }
  });

  api.registerTool({
    id: 'adb_key',
    name: '按键',
    description: '发送一个安卓按键（keyevent）。常用：4=返回、3=主页、66=回车/确认、67=删除、85=播放/暂停、24=音量加、25=音量减、26=电源键。',
    category: 'system',
    icon: '🔘',
    defaultEnabled: true,
    parameters: {
      type: 'object',
      properties: { code: { type: 'integer', description: 'keyevent 键码，如 4（返回）、3（主页）、66（回车）' } },
      required: ['code']
    },
    async execute(ctx, args) {
      const code = intArg(args?.code, { min: 0, max: 300 });
      if (code === null) return fail('code 必须是数字键码。');
      try {
        const s = readSettings();
        if (!s.device) return fail('技能还没配置设备标识（device）。');
        const r = await adbRun(s, ['shell', 'input', 'keyevent', String(code)]);
        if (!r.ok) return fail('按键失败：' + humanizeAdbError(r.stderr || r.error));
        return ok({ action: 'key', code, result: '已发送按键。' });
      } catch (error) {
        return fail('按键失败：' + (error?.message ?? error));
      }
    }
  });

  api.registerTool({
    id: 'adb_back',
    name: '返回',
    description: '相当于按手机返回键。返回后建议截图确认回到哪了。',
    category: 'system',
    icon: '↩️',
    defaultEnabled: true,
    parameters: { type: 'object', properties: {} },
    async execute() {
      try {
        const s = readSettings();
        if (!s.device) return fail('技能还没配置设备标识（device）。');
        const r = await adbRun(s, ['shell', 'input', 'keyevent', '4']);
        if (!r.ok) return fail('返回失败：' + humanizeAdbError(r.stderr || r.error));
        return ok({ action: 'back', result: '已返回。建议截图确认。' });
      } catch (error) {
        return fail('返回失败：' + (error?.message ?? error));
      }
    }
  });

  api.registerTool({
    id: 'adb_home',
    name: '回到桌面',
    description: '相当于按手机主页键，回到桌面。',
    category: 'system',
    icon: '🏠',
    defaultEnabled: true,
    parameters: { type: 'object', properties: {} },
    async execute() {
      try {
        const s = readSettings();
        if (!s.device) return fail('技能还没配置设备标识（device）。');
        const r = await adbRun(s, ['shell', 'input', 'keyevent', '3']);
        if (!r.ok) return fail('回桌面失败：' + humanizeAdbError(r.stderr || r.error));
        return ok({ action: 'home', result: '已回桌面。' });
      } catch (error) {
        return fail('回桌面失败：' + (error?.message ?? error));
      }
    }
  });

  api.registerTool({
    id: 'adb_open',
    name: '打开 App',
    description: '用应用包名打开一个 App（monkey 启动）。'
      + '常见包名：微信 com.tencent.mm、抖音 com.ss.android.ugc.aweme、QQ com.tencent.mobileqq、哔哩哔哩 tv.danmaku.bili、淘宝 com.taobao.taobao、小红书 com.xingin.xhs。'
      + '不知道包名时可先用 adb_control__adb_packages 搜。打开后建议截图确认到了哪个页面。',
    category: 'system',
    icon: '🚀',
    defaultEnabled: true,
    parameters: {
      type: 'object',
      properties: { pkg: { type: 'string', description: '应用包名，如 com.ss.android.ugc.aweme' } },
      required: ['pkg']
    },
    async execute(ctx, args) {
      let pkg = String(args?.pkg ?? '').trim();
      if (!pkg) return fail('pkg 不能为空。');
      if (!/^[a-zA-Z0-9._]+$/.test(pkg)) return fail('包名格式不对，只允许字母数字和点。');
      try {
        const s = readSettings();
        if (!s.device) return fail('技能还没配置设备标识（device）。');
        const r = await adbRun(s, ['shell', 'monkey', '-p', pkg, '-c', 'android.intent.category.LAUNCHER', '1']);
        if (!r.ok) return fail('打开失败：' + humanizeAdbError(r.stderr || r.error));
        const out = String(r.stdout);
        const okFlag = /Events injected: 1|appear|成功|No activities found/i.test(out);
        return ok({
          action: 'open', pkg,
          launched: /No activities found/i.test(out) ? false : true,
          result: /No activities found/i.test(out)
            ? '包名没找到（可能没装或包名不对）。用 adb_control__adb_packages 搜一下真实包名。'
            : '已发出打开指令。建议截图确认到了哪个页面。'
        });
      } catch (error) {
        return fail('打开失败：' + (error?.message ?? error));
      }
    }
  });

  api.registerTool({
    id: 'adb_packages',
    name: '搜索已安装 App 包名',
    description: '在手机上搜索已安装的应用包名（按关键词过滤）。'
      + '当你想打开某个 App 但不知道包名时用（例如搜「抖音」「微信」「bilibili」）。返回包名清单。',
    category: 'system',
    icon: '🧩',
    defaultEnabled: true,
    parameters: {
      type: 'object',
      properties: { keyword: { type: 'string', description: '包名关键词，如 ugc、weixin、douyin、bili、taobao' } }
    },
    async execute(ctx, args) {
      const kw = String(args?.keyword ?? '').trim().toLowerCase();
      try {
        const s = readSettings();
        if (!s.device) return fail('技能还没配置设备标识（device）。');
        const r = await adbRun(s, ['shell', 'pm', 'list', 'packages']);
        if (!r.ok) return fail('查询失败：' + humanizeAdbError(r.stderr || r.error));
        const pkgs = String(r.stdout).split('\n')
          .map((x) => x.replace(/^package:/, '').trim())
          .filter(Boolean)
          .filter((p) => !kw || p.toLowerCase().includes(kw));
        if (!pkgs.length) return ok({ keyword: kw, count: 0, packages: [], hint: '没搜到匹配的包。换个关键词，或直接 adb_control__adb_open 试常用包名。' });
        // 只回前 20 个，避免把整张包名列表塞进上下文
        const top = pkgs.slice(0, 20);
        return ok({ keyword: kw, count: pkgs.length, packages: top, hint: '把上面合适的包名填给 adb_control__adb_open。' });
      } catch (error) {
        return fail('查询失败：' + (error?.message ?? error));
      }
    }
  });

  api.registerTool({
    id: 'adb_screenshot',
    name: '手机截图',
    description: '给手机屏幕截一张 PNG 图。当前 LLM 模型支持看图时，会把截图**直接喂给模型看**（模型真正看得到屏幕内容，据此判断坐标）；模型不支持看图时，只返回文件路径和尺寸。'
      + '这是你看手机的"眼睛"：不知道怎么点、不确定现在在哪、操作后想确认效果时都用它。'
      + '注意：截图是内部动作，不要把图片本身发进群里。',
    category: 'system',
    icon: '📸',
    defaultEnabled: true,
    parameters: { type: 'object', properties: {} },
    async execute() {
      try {
        const s = readSettings();
        if (!s.device) return fail('技能还没配置设备标识（device）。');

        let buf = null;
        let compat = false;
        // 用 exec-out 把 PNG 字节直接流出来（不走 shell 重定向）。
        const r = await adbRun(s, ['exec-out', 'screencap', '-p'], { binary: true, timeout: 30000 });
        if (r.ok) {
          buf = Buffer.isBuffer(r.stdout) ? r.stdout : Buffer.from(r.stdout);
        } else {
          // 部分老 adb 没有 exec-out，退回 shell + pull 组合
          const r2 = await adbRun(s, ['shell', 'screencap', '-p', '/sdcard/_adb_shot.png']);
          if (!r2.ok) return fail('截图失败：' + humanizeAdbError(r2.stderr || r2.error));
          const pPull = await resolveShotPath(s);
          const r3 = await adbRun(s, ['pull', '/sdcard/_adb_shot.png', pPull]);
          await adbRun(s, ['shell', 'rm', '-f', '/sdcard/_adb_shot.png']);
          if (!r3.ok) return fail('截图失败（pull 也没成功）：' + humanizeAdbError(r3.stderr || r3.error));
          try {
            const fsPull = await import('node:fs');
            buf = fsPull.readFileSync(pPull);
          } catch { buf = null; }
          if (!buf) return fail('截图文件读不到，先确认截图目录可写。');
          compat = true;
        }
        if (!buf.length) return fail('截图返回了空内容（手机可能锁屏了）。先让手机亮屏再试。');
        const dim = pngSize(buf);
        const p = await resolveShotPath(s);
        const fs = await import('node:fs');
        fs.writeFileSync(p, buf);

        // 智能发图：模型支持看图 → 用纯 JS 把大图缩到视觉模型能接受的尺寸并喂给模型看。
        // 关键：完整手机截图尺寸大，deepseek-flash 这类视觉 API 会以 "unsupported image"
        // 拒收；且必须保证 PNG 是有效字节（见 adbRun 的 encoding:'buffer'）。缩放后记录
        // 缩放比 shotScale，tap/swipe 会按模型在图上给的坐标自动换算回真实屏幕坐标。
        const vision = await modelCanSeeImages();
        shotScale = { sx: 1, sy: 1, scaled: false };
        const textPart = dim
          ? `手机截图已保存：${p}（${dim.w}×${dim.h}，${buf.length} 字节）${compat ? '（旧 adb 兼容路径）' : ''}。`
          : `手机截图已保存：${p}（${buf.length} 字节）。`;
        if (vision.can) {
          let payload = buf;
          let scaledNote = '';
          const resized = downscalePng(buf, 960);
          if (resized && resized.buffer.length < buf.length) {
            payload = resized.buffer;
            shotScale = {
              sx: dim ? dim.w / resized.width : 1,
              sy: dim ? dim.h / resized.height : 1,
              scaled: true,
              scaledW: resized.width,
              scaledH: resized.height
            };
            scaledNote = dim
              ? `（已缩放为 ${resized.width}×${resized.height} 供模型看；点按/滑动坐标请按这张图上的填，工具会自动换算回 ${dim.w}×${dim.h}）`
              : '（已缩放供模型看）';
          }
          return {
            content: [
              { type: 'text', text: textPart + scaledNote },
              { type: 'image_url', image_url: { url: 'data:image/png;base64,' + payload.toString('base64') } }
            ]
          };
        }
        return ok({
          saved: p,
          width: dim ? dim.w : null,
          height: dim ? dim.h : null,
          bytes: buf.length,
          vision: false,
          visionNote: vision.reason || '',
          hint: dim
            ? '屏幕尺寸 ' + dim.w + '×' + dim.h + '。当前模型' + (vision.reason || '不支持看图') + '，无法直接看到画面，'
              + '请结合用户描述判断坐标填给 adb_control__adb_tap；要滑就用 adb_control__adb_swipe。'
            : ''
        });
      } catch (error) {
        return fail('截图失败：' + (error?.message ?? error));
      }
    }
  });

  // ── 自主循环任务：截图→视觉模型看→执行→循环 ─────────────────────────────
  api.registerTool({
    id: 'adb_auto_task',
    name: '自主操作手机（循环任务）',
    description: '给定一个目标，自动循环执行：截图手机画面 → 让视觉模型看 → 决定下一步动作（点击/滑动/输入/返回等）→ 执行 → 再截图，'
      + '直到任务完成或到达上限。用户说「自主任务：…」「你自己玩下手机，目标是…」时用。'
      + '⚠️ 会连续多次调用视觉模型看图（每次一步耗一次图片 token），并且真实操作手机。'
      + '循环逻辑写在程序里（不是靠模型记忆），稳定性强，不会跑几步就停下。',
    category: 'system',
    icon: '🤖',
    defaultEnabled: true,
    parameters: {
      type: 'object',
      properties: {
        goal: { type: 'string', description: '任务目标，例如「打开抖音随便刷几个视频」「看看手机现在开着的 App」「进设置改个壁纸」' },
        maxSteps: { type: 'integer', description: '最多循环多少步，默认 12，最大 30。防无限循环。' }
      },
      required: ['goal']
    },
    async execute(ctx, args) {
      const s = readSettings();
      if (!s.device) return fail('技能还没配置设备标识（device）。');
      const goal = String(args?.goal ?? '').trim();
      if (!goal) return fail('goal 不能为空。');
      const maxSteps = Math.min(Math.max(intArg(args?.maxSteps, { min: 1, max: 30 }) ?? 12, 1), 30);
      if (!fetchImpl) return fail('技能缺少联网权限：需要在 skill.json 声明 web_fetch（用于把截图发给模型判断）。');

      const SYSTEM =
        '你是安卓手机自主操作 Agent，由程序循环驱动。你只负责「看图 → 决定下一步 → 返回动作 JSON」。\n'
        + '只返回一个 JSON 对象，不要任何多余文字。格式：\n'
        + '{"action":"tap|swipe|text|back|home|enter|open","x":0,"y":0,"x1":0,"y1":0,"x2":0,"y2":0,"duration":300,"text":"...","pkg":"...","done":false,"reason":"一句话说明"}\n'
        + 'action 说明：tap(带x,y) / swipe(带x1,y1,x2,y2,duration) / text(带text) / back / home / enter / open(带pkg，包名)。\n'
        + '当任务已完成或无法继续时，返回 {"done":true,"reason":"..."}，不要再给动作。\n'
        + '规则：每次只做一步；坐标按当前这张图上的坐标填；先看清楚画面再决定，避免重复做同一件事；'
        + '遇到弹窗/广告优先关闭；**不要**执行支付、发消息、登录、删除、转账等不可逆或敏感操作。';

      const actionLog = [];
      const steps = [];
      let status = 'done';
      let lastReason = '';
      let stopped = false;

      for (let i = 1; i <= maxSteps && !stopped; i++) {
        // 1) 截图
        const shot = await captureScreenshot(s);
        if (shot.error) { status = 'error'; lastReason = shot.error; break; }

        // 2) 缩放（供模型看），并记录坐标缩放比
        const resized = downscalePng(shot.buf, 960);
        let payload = shot.buf;
        shotScale = { sx: 1, sy: 1, scaled: false };
        if (resized && resized.buffer.length < shot.buf.length) {
          payload = resized.buffer;
          shotScale = {
            sx: shot.dim ? shot.dim.w / resized.width : 1,
            sy: shot.dim ? shot.dim.h / resized.height : 1,
            scaled: true
          };
        }

        // 3) 发给视觉模型决定下一步
        const historyText = actionLog.length ? '已经执行过这些动作：' + actionLog.slice(-6).join('；') : '还没有动作';
        const call = await callVisionForAction(s, [
          { role: 'system', content: SYSTEM },
          { role: 'user', content: [
            { type: 'text', text: `任务目标：${goal}\n这是第 ${i}/${maxSteps} 步。${historyText}\n请返回下一步动作 JSON。` },
            { type: 'image_url', image_url: { url: 'data:image/png;base64,' + payload.toString('base64') } }
          ] }
        ]);
        if (call.error) { status = 'error'; lastReason = call.error; break; }
        const act = parseAction(call.content);
        if (!act) { status = 'error'; lastReason = '模型返回无法解析的动作：' + String(call.content || '').slice(0, 140); break; }

        // 4) 模型说完成了 → 结束
        if (act.done === true) { lastReason = String(act.reason || '任务完成'); break; }

        // 5) 执行动作
        const perf = await performAction(s, act);
        actionLog.push(perf.log);
        steps.push({ step: i, action: String(act.action || ''), detail: perf.log, ok: perf.ok });
        if (!perf.ok) { status = 'error'; lastReason = perf.log; break; }
      }

      if (status === 'done' && steps.length >= maxSteps) {
        status = 'max_steps';
        lastReason = lastReason || `已达循环上限 ${maxSteps} 步`;
      }

      return ok({
        status, goal, stepsRun: steps.length, maxSteps,
        lastReason, actionLog,
        hint: '自主任务结束（' + status + '）。需要继续就再说个新目标。'
      });
    }
  });

  log(`ADB 控制手机技能已加载（${BUILD_TAG}）｜工具：adb_status/tap/swipe/text/key/back/home/open/packages/screenshot/auto_task`);
}

/**
 * 判断这次截图能不能真正喂给模型看。
 * 依据（与核心 llm.js 的 specializedModelFor 一致）：消息带图片时，
 *   · 设置了「图片输入专用模型」visionModel → 请求会被路由到它 → 直接信它能看；
 *   · 没设置 → 由主模型看 → 按探测结论判断（'vision' 才发，no-vision/unknown 不发，避免把会话搞挂）。
 */
async function modelCanSeeImages() {
  try {
    const { getConfig } = await import('../../src/config.js');
    const { modelImageVerdict } = await import('../../src/vision-scan.js');
    const cfgApi = getConfig()?.api || {};
    if (cfgApi.vision === false) return { can: false, reason: '视觉输入已在设置里关闭' };
    const visionModel = String(cfgApi.visionModel ?? '').trim();
    if (visionModel) return { can: true, via: visionModel };
    const verdict = modelImageVerdict(cfgApi.provider, cfgApi.model);
    if (verdict === 'vision') return { can: true };
    if (verdict === 'no-vision') return { can: false, reason: '当前模型 ' + (cfgApi.model || '') + ' 不支持看图' };
    return { can: false, reason: '当前模型 ' + (cfgApi.model || '') + ' 看图能力未知（未探测或无法判定）' };
  } catch (error) {
    return { can: false, reason: '无法读取模型看图能力配置' };
  }
}

// ── adb_auto_task 用到的辅助 ──────────────────────────────────────────────

/** 读取 LLM 端点配置（Base URL / Key / 模型），供技能直接调视觉模型。 */
async function readLlmConfig() {
  try {
    const { getConfig } = await import('../../src/config.js');
    const c = getConfig() || {};
    const cfgApi = c.api || {};
    const provider = String(cfgApi.provider || '').trim();
    let apiKey = String(cfgApi.apiKey || '').trim();
    if (!apiKey) {
      try { apiKey = String(c.dshProviderKeys?.[provider] || '').trim(); } catch { /* ignore */ }
    }
    return {
      baseUrl: String(cfgApi.baseUrl || '').trim(),
      apiKey,
      model: String(cfgApi.visionModel || cfgApi.model || '').trim(),
      visionOn: cfgApi.vision !== false
    };
  } catch (error) {
    return { baseUrl: '', apiKey: '', model: '', visionOn: false };
  }
}

/** 调一次 OpenAI 兼容 chat/completions，返回 { content } 或 { error }。 */
async function callVisionForAction(s, messages, timeoutMs = 45000) {
  const ep = await readLlmConfig();
  if (!ep.baseUrl || !ep.model) return { error: '未配置模型（Base URL / 模型名），请先在 QQ Agent 设置里填好。' };
  if (!ep.visionOn) return { error: '视觉输入已在设置里关闭，无法自主看图。' };
  if (!ep.apiKey) return { error: '没拿到模型 API Key。' };
  const url = ep.baseUrl.replace(/\/+$/, '') + '/chat/completions';
  const headers = { 'content-type': 'application/json', authorization: `Bearer ${ep.apiKey}` };
  let res;
  try {
    res = await fetchImpl(url, {
      method: 'POST',
      headers,
      body: JSON.stringify({ model: ep.model, messages, temperature: 0.2, stream: false, max_tokens: 600 }),
      signal: AbortSignal.timeout(timeoutMs)
    });
  } catch (error) {
    return { error: '调模型失败：' + String(error?.message || error).slice(0, 200) };
  }
  const text = await res.text().catch(() => '');
  if (!res.ok) return { error: `模型 API HTTP ${res.status}: ${text.slice(0, 300)}` };
  let json = null;
  try { json = JSON.parse(text); } catch { json = null; }
  const content = json?.choices?.[0]?.message?.content ?? '';
  return { content: String(content).trim() };
}

/** 从模型文本里抠出第一个 JSON 对象。 */
function parseAction(content) {
  let text = String(content || '').trim();
  text = text.replace(/^```[a-zA-Z]*\s*/, '').replace(/```$/, '').trim();
  const s = text.indexOf('{');
  const e = text.lastIndexOf('}');
  if (s < 0 || e < 0 || e < s) return null;
  try { return JSON.parse(text.slice(s, e + 1)); } catch { return null; }
}

/** 截一张手机屏（二进制正确取法；exec-out 失败退回 shell+pull）。返回 {buf, dim} 或 {error}。 */
async function captureScreenshot(s) {
  const r = await adbRun(s, ['exec-out', 'screencap', '-p'], { binary: true, timeout: 30000 });
  if (r.ok) {
    const buf = Buffer.isBuffer(r.stdout) ? r.stdout : Buffer.from(r.stdout);
    if (!buf.length) return { error: '截图为空（手机可能锁屏了）。' };
    return { buf, dim: pngSize(buf) };
  }
  const r2 = await adbRun(s, ['shell', 'screencap', '-p', '/sdcard/_adb_shot.png']);
  if (!r2.ok) return { error: '截图失败：' + humanizeAdbError(r2.stderr || r2.error) };
  const pPull = await resolveShotPath(s);
  const r3 = await adbRun(s, ['pull', '/sdcard/_adb_shot.png', pPull]);
  await adbRun(s, ['shell', 'rm', '-f', '/sdcard/_adb_shot.png']);
  if (!r3.ok) return { error: '截图失败（pull 也没成功）。' };
  let buf = null;
  try { const fs = await import('node:fs'); buf = fs.readFileSync(pPull); } catch { buf = null; }
  if (!buf) return { error: '读不到截图文件。' };
  return { buf, dim: pngSize(buf) };
}

/** 执行一个动作（坐标按 shotScale 自动换算回真实屏幕坐标）。返回 {ok, log}。 */
async function performAction(s, act) {
  const a = act || {};
  const type = String(a.action || '').toLowerCase();
  const num = (v, d) => { const n = Number(v); return Number.isFinite(n) ? n : d; };

  if (type === 'tap') {
    const x = intArg(a.x), y = intArg(a.y);
    if (x === null || y === null) return { ok: false, log: 'tap 缺坐标' };
    const rx = Math.round(x * shotScale.sx), ry = Math.round(y * shotScale.sy);
    const r = await adbRun(s, ['shell', 'input', 'tap', String(rx), String(ry)]);
    return { ok: r.ok, log: r.ok ? `tap(${rx},${ry})` : ('tap 失败：' + humanizeAdbError(r.stderr || r.error)) };
  }
  if (type === 'swipe') {
    const x1 = intArg(a.x1), y1 = intArg(a.y1), x2 = intArg(a.x2), y2 = intArg(a.y2);
    if ([x1, y1, x2, y2].some((v) => v === null)) return { ok: false, log: 'swipe 缺坐标' };
    const d = Math.min(Math.max(Math.round(num(a.duration, 300)), 0), 30000);
    const rx1 = Math.round(x1 * shotScale.sx), ry1 = Math.round(y1 * shotScale.sy);
    const rx2 = Math.round(x2 * shotScale.sx), ry2 = Math.round(y2 * shotScale.sy);
    const r = await adbRun(s, ['shell', 'input', 'swipe', String(rx1), String(ry1), String(rx2), String(ry2), String(d)]);
    return { ok: r.ok, log: r.ok ? `swipe(${rx1},${ry1}->${rx2},${ry2})` : ('swipe 失败：' + humanizeAdbError(r.stderr || r.error)) };
  }
  if (type === 'text') {
    let text = String(a.text ?? '').trim();
    if (!text) return { ok: false, log: 'text 为空' };
    if (text.length > 200) text = text.slice(0, 200);
    const safe = text.replace(/\\/g, '\\\\').replace(/"/g, '\\"').replace(/'/g, "\\'").replace(/ /g, '%s');
    const r = await adbRun(s, ['shell', 'input', 'text', safe]);
    return { ok: r.ok, log: r.ok ? `text(${text.slice(0, 20)})` : ('text 失败：' + humanizeAdbError(r.stderr || r.error)) };
  }
  if (type === 'back') { const r = await adbRun(s, ['shell', 'input', 'keyevent', '4']); return { ok: r.ok, log: r.ok ? 'back' : 'back 失败' }; }
  if (type === 'home') { const r = await adbRun(s, ['shell', 'input', 'keyevent', '3']); return { ok: r.ok, log: r.ok ? 'home' : 'home 失败' }; }
  if (type === 'enter') { const r = await adbRun(s, ['shell', 'input', 'keyevent', '66']); return { ok: r.ok, log: r.ok ? 'enter' : 'enter 失败' }; }
  if (type === 'open') {
    let pkg = String(a.pkg ?? '').trim();
    if (!pkg) return { ok: false, log: 'open 缺包名' };
    if (!/^[a-zA-Z0-9._]+$/.test(pkg)) return { ok: false, log: 'open 包名非法' };
    const r = await adbRun(s, ['shell', 'monkey', '-p', pkg, '-c', 'android.intent.category.LAUNCHER', '1']);
    return { ok: r.ok, log: r.ok ? `open(${pkg})` : ('open 失败：' + humanizeAdbError(r.stderr || r.error)) };
  }
  return { ok: false, log: '未知动作：' + (type || '(空)') };
}

/** 计算截图落盘路径：优先用户配置，否则 <data>/adb-screens/。 */
async function resolveShotPath(s) {
  const path = await import('node:path');
  const fs = await import('node:fs');
  let dir = s.screenshotDir;
  if (!dir) {
    try {
      const { DATA_DIR } = await import('../../src/config.js');
      dir = DATA_DIR;
    } catch { dir = ''; }
  }
  if (!dir) dir = '.';
  const shotDir = path.join(dir, 'adb-screens');
  try { fs.mkdirSync(shotDir, { recursive: true }); } catch { /* 目录建不了就放当前目录 */ }
  const ts = new Date().toISOString().replace(/[:.]/g, '-');
  return path.join(dir, 'adb-screens', 'screen-' + ts + '.png');
}

/** 读本地文件字节数（供 pull 兼容路径用）。 */
async function sizeOf(p) {
  try {
    const fs = await import('node:fs');
    return fs.statSync(p)?.size ?? null;
  } catch { return null; }
}

/** 可用性自检：必须同步返回（manager 只认 false / {ok:false}）。 */
export function available() {
  return { ok: true };
}
