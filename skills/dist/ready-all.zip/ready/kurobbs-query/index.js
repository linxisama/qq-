// 库街区查询（LLM 型技能 / skills/）
//
// ── 类型判定：为什么这是「技能」而不是「插件」─────────────────────────────
//   用户要的是「我问 → 机器人去查」。什么算"在问练度"只有模型判断得准：
//   「我练度怎么样」「看看我角色」「这号养得如何」「查一下鸣潮」都能表达同一个意思，
//   写死关键词必然漏一半。所以这里 registerTool，工具进模型的 function 列表，
//   由模型决定什么时候调。
//   （对照：如果需求是"群里出现库街区链接就自动展开"，那才是条件确定型 → plugins/。）
//
// ── 分层 ──────────────────────────────────────────────────────────────────
//   lib/kurobbs.js  接口路径 / 两套请求头 / b-at / 响应解密 / 字段容错
//   lib/card.js     排版与画图（只认归一化后的数据）
//   lib/render.js   TrueType + PNG 渲染引擎（零依赖、不联网）
//   lib/store.js    图片落盘与清理
//   本文件负责：读配置 → 挑账号 → 调接口 → 归一化 → 出图 → 发送 → 回执
//
// ── 库街区的三处真实坑（都是靠前端的 axios 拦截器核对出来的）───────────────
//   ① 全部接口是 form-urlencoded，不是 JSON body
//   ② /aki/roleBox/akiBox/* 的响应 data 是「字符串 JSON」，甚至可能是 AES 密文
//   ③ 练度查询要两个 id：roleId = 账号的，id = 角色的；b-at 过期返回 10903
//
// ── 必须守住的约定（从项目源码核出来的，别凭直觉改）──────────────────────
//   · 联网要用 api.fetch（清单 permissions 里声明 web_fetch 才是真 fetch）
//   · 配置一律执行时用 cfg() 现读，setup 时快照会导致"改了设置不生效"
//   · available() 必须是同步函数（可用性判定走同步链）
//   · 图片走 ctx.sender.sendImage（自带限频/去重/留档），不要直接碰 onebot
//   · 工具失败要返回 isError: true 并把真实原因给模型，别让它以为已经查好了

import {
  callApi, ensureBAt, fetchIp, pick, redact, callLog, isTokenError,
  clearBAtCache, parseDataField, ENDPOINTS
} from './lib/kurobbs.js';
import { renderReport, renderRoleListCard, renderNoticeCard } from './lib/card.js';
import { saveImage } from './lib/store.js';
import {
  bindUser, unbindUser, getUser, listUsers, maskToken, resolveMemberId, looksLikeToken
} from './lib/bindings.js';

const BUILD_TAG = 'kurobbs-query v1.1.0';

let cfg = () => ({});
let log = () => {};
let warn = () => {};
let apiFetch = null;
// 注入的 api 本体要留着：api.capability 之类的软依赖入口靠它
let api = null;

const GAME_ID = 3;              // 3 = 鸣潮，2 = 战双
const MAX_ROSTER_FETCH = 200;   // 防御：接口异常返回超大数组时不要拖死渲染

// ══════════════════════════════════════════════════════════════════════════
// 「本轮是谁在说话」——库街区是**按人**查的，所以必须知道调用者是谁
// ══════════════════════════════════════════════════════════════════════════
//
// ⚠️ 工具拿到的 ctx 里**没有**"本轮发言人"，只有 chatKey/kind/chatId/onebot/
//    sender/session…。能拿到发言人的两个地方：
//      ① 提示词文本里（模型看得见，代码拿不到）
//      ② ctx.session.trigger[]（代码能拿到，项目里 affinity 技能用的就是它）
//    所以这里统一用 ②，并在拿不到时回退到"私聊对端"，最后才回退到模型
//    从聊天记录里带回来的 caller_id —— 与 group-admin 技能同一套兜底思路。

/** 本轮最后一位非机器人发言者（私聊就是对方） */
function lastSpeakerId(ctx) {
  try {
    const entries = Array.isArray(ctx?.session?.trigger) ? ctx.session.trigger : [];
    const self = String(ctx?.selfId || '');
    for (let i = entries.length - 1; i >= 0; i--) {
      const m = entries[i];
      const id = String(m?.senderId ?? m?.userId ?? '').trim();
      if (id && id !== self) return id;
    }
  } catch { /* 拿不到就算了 */ }
  return '';
}

/** 当前会话的对端 QQ（私聊才有） */
function privatePeerId(ctx) {
  const ck = String(ctx?.chatKey || '');
  return ck.startsWith('private:') ? ck.slice('private:'.length) : '';
}

/**
 * 「谁在问」：本轮发言人 > 私聊对端 > 模型带回来的 caller_id。
 * 三个都拿不到时返回空 —— 调用方必须给出可操作提示，不能瞎猜成别人。
 */
function callerId(ctx, args) {
  const explicit = qqOf(args?.caller_id);
  return lastSpeakerId(ctx) || privatePeerId(ctx) || explicit;
}

function qqOf(v) {
  const s = String(v ?? '').trim();
  return /^\d{5,15}$/.test(s) ? s : '';
}

/** 取群成员列表，用于把「名字」解析成 QQ 号（失败返回空数组，不抛） */
async function groupMembers(ctx) {
  const kind = String(ctx?.kind || '');
  const groupId = String(ctx?.chatId || '');
  if (kind !== 'group' || !/^\d+$/.test(groupId)) return [];
  try {
    const list = await ctx.onebot.call('get_group_member_list', { group_id: Number(groupId) });
    return Array.isArray(list) ? list : (Array.isArray(list?.data) ? list.data : []);
  } catch (error) {
    warn(`取群成员列表失败（用于把名字解析成 QQ）：${short(error)}`);
    return [];
  }
}

/**
 * 解析「要查谁的账号」，返回 { qq, token, source, mine }。
 *
 * 优先级（这是本功能的核心决策，别改乱）：
 *   ① 模型明确给了 target（QQ 号或名字）→ 查那个人（要对方绑过 token）
 *   ② 没给 target → 查提问者自己；提问者没绑就用主人（配置里）的 token
 *
 * source 只用于日志与提示，不会外泄 token。
 */
async function resolveSubject(ctx, args, settings) {
  const caller = callerId(ctx, args);
  const wantTarget = String(args?.target ?? '').trim();

  if (wantTarget) {
    let targetQq = qqOf(wantTarget);
    if (!targetQq) {
      // 不是纯数字 → 当群名片/昵称，在群成员里找
      const members = await groupMembers(ctx);
      targetQq = resolveMemberId(members, wantTarget);
      if (!targetQq) {
        return {
          error: `群里没找到叫「${wantTarget}」的人。可以直接说 QQ 号，或者让对方先说一句话我再认。`
        };
      }
    }
    if (caller && targetQq === caller) {
      // 点自己：走"自己"的分支（会在下面用他自己的 token 或主人 token）
      return finishSubject(targetQq, true, ctx, args, settings);
    }
    const entry = getUser(targetQq);
    if (!entry) {
      return {
        error: `QQ ${targetQq} 还没绑定库街区 token，我查不了他的数据。`
          + '让他私聊或群里发一句「绑定库街区 <他的token>」就能绑上。'
      };
    }
    return {
      qq: targetQq,
      token: entry.token,
      devCode: entry.devCode || settings.devCode,
      did: entry.did || settings.did,
      source: `他人绑定（${maskToken(entry.token)}）`,
      mine: false,
      accountName: entry.accountName || ''
    };
  }

  return finishSubject(caller, true, ctx, args, settings);
}

/**
 * 无 target 时：提问者自己的 token → （可选）主人的 token → 给出绑定引导。
 *
 * ⚠️ 默认**不回退**到主人配置的 token。这是刻意的：
 *    群友问「我的练度」而自己没绑定，如果拿主人的 token 去查，机器人会把
 *    **主人的账号数据**当成"你的练度"发到群里 —— 既是隐私泄露，也会让群友
 *    以为自己练度怎么突然这么高。宁可回一句"你还没绑定"，也不要给错的数据。
 *    主人自己要用默认 token，只要也用一次「绑定」即可（或者把下面的开关打开）。
 */
function finishSubject(caller, mine, ctx, args, settings) {
  const entry = caller ? getUser(caller) : null;
  if (entry) {
    return {
      qq: caller,
      token: entry.token,
      devCode: entry.devCode || settings.devCode,
      did: entry.did || settings.did,
      source: `本人绑定（${maskToken(entry.token)}）`,
      mine: true,
      accountName: entry.accountName || ''
    };
  }

  const canFallback = settings.useOwnerTokenForUnbound === true && Boolean(settings.token);
  if (canFallback) {
    return {
      qq: caller,
      token: settings.token,
      devCode: settings.devCode,
      did: settings.did,
      source: '主人配置的 token（因为开了"未绑定者用默认 token"开关）',
      mine: false,
      isOwnerFallback: true,
      accountName: ''
    };
  }

  const who = caller ? `QQ ${caller} ` : '你';
  return {
    error: `${who}还没绑定库街区 token，所以我查不了${caller ? '他的' : '你的'}账号。`
      + '绑定一次就行：把「绑定库街区 <你的token>」发给我（私聊或群里都可以，token 在库街区 App 里抓包得到）。'
      + '绑定之后随时说「我的练度」都能查。'
  };
}

// ══════════════════════════════════════════════════════════════════════════
// 生命周期
// ══════════════════════════════════════════════════════════════════════════

export function setup(injected) {
  api = injected;
  cfg = injected.config || (() => ({}));
  log = injected.log || (() => {});
  warn = injected.warn || (() => {});
  apiFetch = injected.fetch;
  log(`库街区查询已加载（${BUILD_TAG}）`);

  api.registerTool({
    id: 'query',
    name: '查询库街区练度',
    description:
      '查询《鸣潮》账号在库街区的数据：账号下拥有的角色、角色练度（等级 / 共鸣链 / 武器 / '
      + '技能等级 / 声骸）、以及地图探索度，渲染成一张卡片图并直接发到当前会话。'
      + '当群友说「查一下我的库街区」「我的角色练度怎么样」「我鸣潮练度」「我练了哪些角色」'
      + '「地图探索了多少」「看看我账号」时使用。'
      + '**默认查提问者自己的账号**（用他自己绑定的 token）。'
      + '如果是别人要求查另一个人（例如「查一下小明的练度」），把那个人的名字或 QQ 号填进 target；'
      + '对方没绑定 token 时会如实回报，不要编造他的数据。'
      + 'role 填账号角色名或序号（账号下有多个鸣潮账号时才需要）；character 填具体角色名'
      + '（如「今汐」），填了就会额外查这个角色的练度详情。'
      + 'list_roles 为 true 时只列出账号角色、不查其它数据。'
      + '图片由本工具直接发出，不要再调用发图工具。',
    category: 'query',
    icon: '🎮',
    parameters: {
      type: 'object',
      properties: {
        target: {
          type: 'string',
          description: '要查谁的账号：群名片、昵称或 QQ 号。**只有别人要求查另一个人时才填**；'
            + '问自己练度时不要填（不填就是查提问者自己）。'
        },
        role: {
          type: 'string',
          description: '账号角色：角色名或列表序号（1、2…）。账号下只有一个鸣潮账号时可以不填。'
        },
        character: {
          type: 'string',
          description: '可选：要查练度详情的具体角色名（如 今汐、忌炎）。不填则只出账号总览与探索度。'
        },
        list_roles: {
          type: 'boolean',
          description: '只列出账号下的游戏角色（不查练度），默认 false。'
        },
        include_explore: {
          type: 'boolean',
          description: '是否同时查地图探索度。不填则用技能设置里的开关。'
        },
        caller_id: {
          type: ['integer', 'string'],
          description: '可选：提问者的 QQ 号（从聊天记录里那位发言者的 (QQ:数字) 取）。'
            + '仅当系统没能自动识别提问者时作为兜底，一般不用填。'
        }
      }
    },
    async execute(ctx, args) {
      const settings = readSettings();

      // ── 0) 先确定"查谁的账号"：这一步决定了后面用哪个 token ──────────────
      const subject = await resolveSubject(ctx, args, settings);
      if (subject.error) return fail(subject.error);

      const base = {
        token: subject.token,
        devCode: subject.devCode || settings.devCode,
        did: subject.did || settings.did,
        base: settings.baseUrl,
        timeoutMs: settings.timeoutMs,
        fetchImpl: apiFetch,
        gameId: GAME_ID
      };

      // 用主人的 token 兜底去查别人时，说清楚查的是谁的号 —— 否则群友会
      // 误以为「这是我的练度」（这是最容易造成误解的一种结果）
      const fallbackNote = subject.isOwnerFallback
        ? '（这次用的是**机器人主人**配置的 token，查到的是主人的账号；'
          + '想查自己的请先绑定：把「绑定库街区 <你的token>」发给我）'
        : '';

      try {
        // web 端接口的 devCode 要带出口 IP，先取一次（失败会自动回退默认值）
        await fetchIp({ fetchImpl: apiFetch, log });

        // ── 1) 账号角色列表 ────────────────────────────────────────────────
        const accounts = await fetchAccounts(base, settings);
        if (!accounts.length) {
          return fail('库街区返回的账号角色列表是空的。可能原因：① 该 token 对应账号没有绑定鸣潮；'
            + '② token 已失效（重新抓包更新）；③ 接口字段变了（请把控制台日志发给维护者）。'
            + (fallbackNote ? `\n${fallbackNote}` : ''));
        }
        if (args?.list_roles === true) {
          const png = renderRoleListCard(accounts, { updatedAt: nowText() });
          const sent = await sendCard(ctx, png, '库街区账号角色');
          if (!sent.ok) return fail(sent.error);
          return ok(`账号下有 ${accounts.length} 个角色，已把列表图发到会话。`
            + '让群友挑一个（说名字或序号），再用 role 参数查询。不要编造角色数据。'
            + (fallbackNote ? `\n${fallbackNote}` : ''));
        }

        const chosenAccount = chooseAccount(accounts, args?.role, settings.defaultRole);
        if (!chosenAccount.account) return fail(chosenAccount.error);
        const account = chosenAccount.account;

        const auth = {
          ...base,
          roleId: account.roleId,
          serverId: account.serverId,
          userId: account.userId
        };

        const warnings = [];

        // b-at 要等有了 userId 才能换。
        // ⚠️ 顺序很重要：roleData（角色总览）**同样需要 b-at**，所以必须先换证再取总览。
        //    曾经把总览排在换证之前，表现是"探索度有、角色总览永远失败"。
        const bAtOf = async (fresh = false) => {
          if (fresh) clearBAtCache();
          return ensureBAt(
            { roleId: account.roleId, serverId: account.serverId, userId: account.userId },
            { ...base, gameId: GAME_ID }
          );
        };
        let bAt = '';
        try {
          bAt = await bAtOf();
        } catch (error) {
          warnings.push(`通行证（b-at）获取失败：${short(error)}`);
        }
        const authWithBAt = {
          ...auth,
          bAt,
          // b-at 失效（code 10903）时自动重换再重试一次
          onBAtExpired: () => bAtOf(true)
        };

        const roster = bAt
          ? await safe(() => fetchRoster(authWithBAt, warnings), '角色总览', warnings)
          : null;

        // ── 2) 角色练度详情（用户点了具体角色才查）─────────────────────────
        const wantCharacter = String(args?.character ?? '').trim();
        let detail = null;
        if (wantCharacter && bAt) {
          const owned = roster?.characters || [];
          const target = findCharacter(owned, wantCharacter);
          if (!target) {
            warnings.push(owned.length
              ? `账号下没有叫「${wantCharacter}」的角色`
              : `取不到角色总览，无法查「${wantCharacter}」的练度`);
          } else {
            const got = await safe(
              () => fetchCharacterDetail(authWithBAt, target),
              `「${target.name}」练度`,
              warnings
            );
            if (got) detail = got;
          }
        }

        // ── 3) 地图探索度 ─────────────────────────────────────────────────
        const wantExplore = args?.include_explore === undefined
          ? settings.includeExplore !== false
          : args.include_explore === true;
        let explore = null;
        if (wantExplore && bAt) {
          explore = await safe(() => fetchExplore(authWithBAt, warnings), '地图探索度', warnings);
        }

        if (!roster && !detail && !explore) {
          const png = renderNoticeCard('没能取到数据', [
            ...warnings,
            '如果提示 token 失效，请重新抓包更新技能设置里的 token。',
            '如果提示通行证失败，通常是 roleId / serverId 取错了，或该角色未绑定库街区。'
          ], { updatedAt: nowText() });
          const sent = await sendCard(ctx, png, '库街区查询失败');
          if (!sent.ok) return fail(sent.error);
          return fail(`库街区数据没取到，已把原因发到会话里。原因：${warnings.join('；')}`);
        }

        // ── 4) 出图 + 发送 ────────────────────────────────────────────────
        // 卡片上要写清"这是谁的号"：被点名查询时，卡片会被群里所有人看到，
        // 不标注的话容易被当成"发图那个人的练度"。
        const ownerTag = subject.mine ? '' : `（QQ ${subject.qq || '未知'} 的账号）`;
        const card = renderReport({
          role: {
            name: account.name + ownerTag,
            level: account.level,
            serverName: account.serverName,
            uid: account.userId,
            gameName: '鸣潮'
          },
          roster: roster?.characters || [],
          detail,
          explore,
          meta: { updatedAt: nowText(), warnings }
        });
        const sent = await sendCard(ctx, card, detail ? `${detail.name} 练度` : `${account.name} 库街区`);
        if (!sent.ok) return fail(sent.error);

        // ── 5) 回执：把图上数值写成文字进会话，模型才能接着聊细节 ───────────
        const summary = summarize(account, roster, detail, explore, warnings)
          + (subject.mine ? '' : `\n注意：这是 QQ ${subject.qq || '未知'} 的账号数据，不是提问者自己的。`)
          + (fallbackNote ? `\n${fallbackNote}` : '');
        pushSummary(ctx, summary);
        log(`已发送 ${account.name} 的报告卡（来源：${subject.source}；角色 ${roster?.characters?.length || 0} 名`
          + `${detail ? `，详情 ${detail.name}` : ''}`
          + `${explore?.regions?.length ? `，探索度 ${explore.regions.length} 个地区` : ''}）`);
        return ok(summary);
      } catch (error) {
        // 脱敏要用**本次实际使用的** token（可能是群友绑定的那个），
        // 不能只抹配置里的 —— 否则群友的 token 会随报错漏出去。
        const msg = redact(short(error), subject.token, settings.token, settings.devCode);
        warn(`查询失败：${msg}`);
        return fail(`库街区查询失败：${msg}`);
      }
    }
  });

  // ── 自检工具：出问题时跑一次就知道断在哪一步 ──────────────────────────────
  api.registerTool({
    id: 'diagnose',
    name: '库街区连通性自检',
    description:
      '库街区查询出问题时用它自检：检查 token 是否有效、账号角色接口是否通、'
      + 'b-at 通行证能否换到、响应里的 data 是不是需要解密的形态，'
      + '并列出最近几次接口调用的成败（不含任何密钥）。'
      + '当用户说「查不出来」「没反应」「报错了」时先调它。',
    category: 'system',
    icon: '🩺',
    defaultEnabled: true,
    parameters: { type: 'object', properties: {} },
    async execute() {
      const settings = readSettings();
      const lines = [];
      if (!settings.token) {
        return ok('自检结果：还没配置 token。请到控制台「技能」页的「库街区查询」填写。'
          + '（token 只存在本机，不会外传。）');
      }
      const base = {
        token: settings.token,
        devCode: settings.devCode,
        did: settings.did,
        base: settings.baseUrl,
        timeoutMs: settings.timeoutMs,
        fetchImpl: apiFetch,
        gameId: GAME_ID
      };
      lines.push(`token：已配置（长度 ${settings.token.length}，内容不显示）`);
      lines.push(`设备码：${settings.devCode ? '已配置' : '未配置（自动生成随机设备码）'}`);

      try {
        const ip = await fetchIp({ fetchImpl: apiFetch });
        lines.push(`出口 IP：${ip}`);
      } catch (error) {
        lines.push(`出口 IP：取不到（${short(error)}），会用默认值`);
      }

      try {
        const accounts = await fetchAccounts(base, settings);
        lines.push(`账号角色接口：通，拿到 ${accounts.length} 个账号角色`
          + (accounts.length ? `（${accounts.slice(0, 5).map((r) => r.name).join('、')}${accounts.length > 5 ? '…' : ''}）` : ''));
        if (accounts.length) {
          const a = accounts[0];
          try {
            const bAt = await ensureBAt(
              { roleId: a.roleId, serverId: a.serverId, userId: a.userId },
              { ...base }
            );
            lines.push(`b-at 通行证：换到了（长度 ${bAt.length}），练度/探索度接口可用`);
            try {
              const roster = await callApi('roleData', {
                ...base, bAt,
                params: { gameId: GAME_ID, roleId: a.roleId, serverId: a.serverId }
              });
              const chars = roster?.roleList || roster?.list || [];
              lines.push(`角色总览接口：通，${Array.isArray(chars) ? chars.length : 0} 个角色`
                + (Array.isArray(chars) && chars[0] ? `（字段：${Object.keys(chars[0]).slice(0, 8).join(', ')}…）` : ''));
            } catch (error) {
              lines.push(`角色总览接口：失败 —— ${short(error)}`);
            }
          } catch (error) {
            lines.push(`b-at 通行证：失败 —— ${short(error)}`);
          }
        }
      } catch (error) {
        lines.push(`账号角色接口：失败 —— ${short(error)}`);
      }

      const calls = callLog();
      if (calls.length) {
        lines.push('最近调用：');
        for (const c of calls) lines.push(`  ${c.at} ${c.api} ${c.ok ? 'OK' : '失败'} ${c.note || ''}`.trimEnd());
      }
      lines.push('（以上内容不含 token 本身，可直接贴给维护者。）');
      return ok(lines.join('\n'));
    }
  });

  api.registerTool({
    id: 'reset_cache',
    name: '清除库街区缓存',
    description: '清除内存里缓存的 b-at 通行证与出口 IP。换了 token、换了账号或查询异常时用一次。',
    category: 'system',
    icon: '🧹',
    defaultEnabled: true,
    parameters: { type: 'object', properties: {} },
    async execute() {
      clearBAtCache();
      return ok('已清除库街区的通行证缓存，下次查询会重新换取。');
    }
  });

  // ════════════════════════════════════════════════════════════════════════
  // 群友绑定：让每个人都能查自己的账号
  // ════════════════════════════════════════════════════════════════════════
  //
  // 为什么必须"每人一份 token"：库街区数据跟着 token 走，一个 token 只能查
  // 它自己账号的数据，没有"按 UID 查别人面板"的接口。
  //
  // ⚠️ 隐私提醒：绑定要在群里发 token，等于把账号凭据暴露给全群。
  //    代码无法替用户决定，所以做了两件事：① 回执只显示打码 token；
  //    ② 群里出现超长 token 样字符串时提醒一次（见文件末尾的 hooks）。

  api.registerTool({
    id: 'bind',
    name: '绑定库街区 token',
    description:
      '把一个库街区 token 绑定到某个 QQ 号上，之后那个人就能查自己的库街区数据了。'
      + '当有人说「绑定库街区 <token>」「这是我的库街区token」「我绑一下我的号」时使用。'
      + 'token 传抓到的那串原值；绑定者默认是**发这句话的人**，只有明确要求替别人绑时才填 qq。'
      + '绑定前会先验证 token 是否有效，无效会如实回报、不会写进去。'
      + '安全提醒：token 等于账号凭据，**最好私聊机器人发**；在群里发等于全群都能看到。',
    category: 'system',
    icon: '🔗',
    parameters: {
      type: 'object',
      properties: {
        token: { type: 'string', description: '库街区 token 原值（抓包得到的那一串）。' },
        qq: {
          type: 'string',
          description: '要绑到哪个 QQ 号上。不填 = 绑给发这句话的人（默认，且推荐）。'
        },
        caller_id: {
          type: ['integer', 'string'],
          description: '可选：说话人的 QQ 号（系统没识别出来时的兜底）。'
        }
      },
      required: ['token']
    },
    async execute(ctx, args) {
      const settings = readSettings();
      const raw = String(args?.token ?? '').trim();
      if (!raw) return fail('没有拿到 token。把 token 原样发给我就行，例如「绑定库街区 AbCd1234...」。');
      // token 可能被模型从「token=xxx」或「token: xxx」里带出来，这里统一清理
      const token = raw.replace(/^token\s*[:=]\s*/i, '').replace(/^["'`]|["'`]$/g, '').trim();
      if (!token) return fail('token 解析出来是空的，请把那一串原值发我。');

      const wantQq = qqOf(args?.qq);
      const speaker = callerId(ctx, args);
      const targetQq = wantQq || speaker;
      if (!targetQq) {
        return fail('我认不出这句话是谁说的，没法把 token 记在他名下。'
          + '请让他自己在群里说一句「绑定库街区 <token>」，或直接带上 QQ 号。');
      }

      if (targetQq !== speaker) {
        log(`有人代绑：发言人 ${speaker || '未知'} 要求把 token 绑到 ${targetQq}`);
      }

      // ── 先验证再落盘：无效 token 不写进文件 ─────────────────────────────
      let accountName = '';
      let kurobbsUserId = '';
      try {
        const accounts = await fetchAccounts({
          token,
          devCode: settings.devCode,
          did: settings.did,
          base: settings.baseUrl,
          timeoutMs: settings.timeoutMs,
          fetchImpl: apiFetch,
          gameId: GAME_ID
        }, settings);
        if (accounts.length) {
          accountName = accounts[0].name || '';
          kurobbsUserId = accounts[0].userId || '';
        }
      } catch (error) {
        const msg = redact(short(error), token, settings.devCode);
        warn(`绑定校验失败（QQ ${targetQq}）：${msg}`);
        return fail(`这个 token 验证没通过，没有绑定：${msg}\n`
          + '常见原因：复制不完整、token 已过期。请重新抓包后再试一次。');
      }

      const r = bindUser(targetQq, { token, kurobbsUserId, accountName });
      if (!r.ok) return fail(`绑定失败：${r.error}`);

      const where = String(ctx?.kind) === 'group'
        ? '这次是在**群里**发的，群里所有人都看到了那串 token。建议去控制台把库街区账号重新登录一次让旧 token 失效，'
          + '以后私聊我发新的。'
        : '';
      return ok(`已绑定到 QQ ${targetQq}${accountName ? `（库街区账号：${accountName}）` : ''}，`
        + `记的是 ${maskToken(token)}。之后他直接问「我的练度」就能查自己的号了。`
        + (where ? `\n提醒：${where}` : '')
        + '\n不要把 token 复述给任何人，也别再重复发一遍。');
    }
  });

  api.registerTool({
    id: 'whoami',
    name: '查库街区绑定状态',
    description:
      '查看库街区 token 的绑定情况：某个人绑了没有、绑的是哪个库街区账号（token 只显示打码），'
      + '以及一共有谁绑过。当有人问「我绑了吗」「谁绑了库街区」「怎么绑定」时使用。',
    category: 'system',
    icon: '🪪',
    parameters: {
      type: 'object',
      properties: {
        qq: { type: 'string', description: '可选：查某个 QQ 号绑了没有。不填则看当前提问者与总览。' },
        caller_id: {
          type: ['integer', 'string'],
          description: '可选：说话人的 QQ 号（系统没识别出来时的兜底）。'
        }
      }
    },
    async execute(ctx, args) {
      const settings = readSettings();
      const users = listUsers();
      const lines = [];

      let askQq = qqOf(args?.qq);
      const needle = String(args?.qq ?? '').trim();
      if (!askQq && needle && !/^\d+$/.test(needle)) {
        const members = await groupMembers(ctx);
        askQq = resolveMemberId(members, needle) || '';
      }
      const who = askQq || callerId(ctx, args);

      if (who) {
        const entry = getUser(who);
        lines.push(entry
          ? `QQ ${who}：已绑定${entry.accountName ? `，库街区账号「${entry.accountName}」` : ''}`
            + `，token ${maskToken(entry.token)}，绑定于 ${new Date(entry.boundAt).toLocaleString('zh-CN', { hour12: false })}`
          : `QQ ${who}：还没绑定。把「绑定库街区 <你的token>」发给我就能绑。`);
      } else {
        lines.push('我没认出这句话是谁说的，所以只报总览。');
      }

      lines.push(users.length
        ? `已绑定 ${users.length} 人：${users.map((u) => `${u.accountName || '未命名'}(${u.qq})`).join('、')}`
        : '目前还没有人绑定。绑定方式：私聊或群里发「绑定库街区 <你的token>」。');
      if (settings.token) lines.push('另外：机器人主人也配置了一个默认 token（未绑定的人查到的会是主人的账号）。');
      lines.push('（以上只显示打码后的 token，任何时候都不会把完整 token 发出来。）');
      return ok(lines.join('\n'));
    }
  });

  api.registerTool({
    id: 'unbind',
    name: '解绑库街区 token',
    description:
      '删掉某个 QQ 号的库街区 token 绑定。当有人说「解绑」「把库街区绑定删了」「换号了重新绑」时使用。'
      + '默认解绑说话人自己；管理员可以传 qq 指定别人（需要 admin=true 明确表示有权这么做）。',
    category: 'system',
    icon: '🔓',
    parameters: {
      type: 'object',
      properties: {
        qq: { type: 'string', description: '要解绑的 QQ 号。不填 = 解绑自己。' },
        admin: {
          type: 'boolean',
          description: '要解绑**别人**时必须传 true，表示请求者确认自己有权这么做。'
        },
        caller_id: {
          type: ['integer', 'string'],
          description: '可选：说话人的 QQ 号（系统没识别出来时的兜底）。'
        }
      }
    },
    async execute(ctx, args) {
      const speaker = callerId(ctx, args);
      const wantQq = qqOf(args?.qq);
      const target = wantQq || speaker;
      if (!target) return fail('我认不出这句话是谁说的，没法解绑。请让他自己说一句「解绑库街区」。');
      if (target !== speaker && args?.admin !== true) {
        return fail('解绑别人的绑定需要明确说明你有权这么做（admin=true）。'
          + '如果只是想解绑自己的，直接说「解绑库街区」即可。');
      }
      const r = unbindUser(target);
      if (!r.ok) return ok(`QQ ${target} 本来就没有绑定，不用解。`);
      log(`已解绑 QQ ${target} 的库街区 token`);
      return ok(`已解绑 QQ ${target}${r.username ? `（原库街区账号「${r.username}」）` : ''}。`
        + '之后要查得重新绑定。');
    }
  });

  log(`绑定功能已就绪（当前已绑定 ${listUsers().length} 人）`);
}

/**
 * 动态提示词片段：本轮群里出现疑似 token 时，临时补一条提醒。
 *
 * ⚠️ 为什么不用 before-context 钩子：`skillManager.runHook()` 执行完就
 *    **把返回值丢掉了**（orchestrator 里 `await skillManager.runHook(...)` 不接结果），
 *    所以钩子里 `return { notices: [...] }` 是**无效**的——写了也不会出现在提示词里。
 *    而 `promptSections(context)` 的返回值是被真正合并进提示词的（manager 会收集），
 *    所以注入提醒必须走这里。
 *
 * 判断与提示只针对**本批消息**，不记录、不回显那一串疑似 token。
 */
export function promptSections(context = {}) {
  try {
    if (String(context?.kind) !== 'group') return [];
    const entries = Array.isArray(context?.triggerEntries) ? context.triggerEntries : [];
    if (!entries.some((e) => looksLikeToken(e?.text || e?.raw || ''))) return [];
    warn('群里出现疑似库街区 token 的长串，已注入一条安全提醒（原值未记录）');
    return [{
      id: 'kurobbs-token-warning',
      title: '安全提醒',
      priority: 90,     // 安全相关，排在同技能普通片段之上（上限 99）
      content: '本轮群里有人贴了一串很长的字符，**很像库街区的 token**。'
        + 'token 等于账号凭据：请用一句话提醒他「这种 token 别在群里发，建议撤回」，'
        + '并告诉他正确的绑定方式是**私聊机器人**发「绑定库街区 <token>」，'
        + '或者去库街区重新登录让旧 token 失效。'
        + '你自己**绝对不要复述**那串字符的任何部分。'
    }];
  } catch (error) {
    warn(`token 提醒片段生成失败（已忽略）：${short(error)}`);
    return [];
  }
}

/**
 * 自检：**必须同步**（可用性判定走同步调用链）。
 *
 * ── 这里必须恒返回"可用"，这是个刻意的决定 ─────────────────────────────────
 * 本项目里 Skill 一旦判定 available=false，它注册的**所有工具都会从模型列表里
 * 消失**（见 tool-registry 的 getAbility 第 2 步）。而这个技能的功能入口就是
 * 「绑定 token」这个工具本身 —— 如果"没人绑定"就判不可用，就会出现死锁：
 *
 *     没人绑定 → 技能不可用 → 绑定工具看不见 → 永远没人能绑定
 *
 * （实测确实如此：加载后 available=false，`bind` 工具压根不出现在工具列表里。）
 *
 * 所以判断依赖只放到**执行时**：谁没绑 token，查询工具会返回一句可操作的话
 * （"把「绑定库街区 <token>」发给我"），而不是让整个技能消失。
 * 可用性判定本身也不该发网络请求 —— 会把同步调用链卡死。
 */
export function available(context = {}) {
  void context;
  return { ok: true };
}

export const dispose = () => clearBAtCache();

// ══════════════════════════════════════════════════════════════════════════
// 配置
// ══════════════════════════════════════════════════════════════════════════

function readSettings() {
  const c = cfg() || {};
  return {
    token: String(c.token ?? '').trim(),
    devCode: String(c.devCode ?? '').trim(),
    did: String(c.did ?? '').trim(),
    baseUrl: String(c.baseUrl ?? '').trim(),
    defaultRole: String(c.defaultRole ?? '').trim(),
    // 默认关：未绑定者不该拿到主人账号的数据（见 finishSubject 的注释）
    useOwnerTokenForUnbound: c.useOwnerTokenForUnbound === true,
    maxRoster: clampNum(c.maxRoster, 1, 200, 24),
    includeExplore: c.includeExplore !== false,
    timeoutMs: clampNum(c.timeoutMs, 5000, 120000, 20000)
  };
}

// ══════════════════════════════════════════════════════════════════════════
// 接口 → 归一化数据
// ══════════════════════════════════════════════════════════════════════════

/** 账号级角色列表（gamer/role/list，失败则退到 user/role/findRoleList） */
async function fetchAccounts(base, settings) {
  let data;
  try {
    data = await callApi('roleList', base);
  } catch (error) {
    if (isTokenError(null, error?.message)) throw error;
    warn(`账号角色主接口失败（${short(error)}），改用备用接口`);
    data = await callApi('roleListAlt', base);
  }
  const list = Array.isArray(data) ? data : (data?.list || data?.roleList || []);
  const accounts = list.map((raw) => ({
    roleId: str(pick(raw, 'roleId', 'role_id', 'id')),
    serverId: str(pick(raw, 'serverId', 'server_id')),
    userId: str(pick(raw, 'userId', 'user_id', 'uid')),
    name: str(pick(raw, 'roleName', 'role_name', 'name')) || '未命名角色',
    level: num(pick(raw, 'gameLevel', 'game_level', 'level')),
    serverName: str(pick(raw, 'serverName', 'server_name')),
    isDefault: pick(raw, 'isDefault', 'is_default') === true,
    gameId: num(pick(raw, 'gameId', 'game_id'))
  })).filter((a) => a.roleId && a.serverId);

  if (list.length && !accounts.length) {
    // 拿到列表却一条都过不了校验 = 字段名变了。必须报出来，不能静默返回空。
    warn(`账号角色列表拿到 ${list.length} 条，但没有一条能取出 roleId/serverId。`
      + `实际字段：${Object.keys(list[0] || {}).join(', ')}`);
  }
  void settings;
  return accounts;
}

/**
 * 账号下「拥有的可玩角色」列表。
 * 响应形如 { roleList: [...], showToGuest: bool }，roleList[].roleId 是**角色的 id**。
 */
async function fetchRoster(auth, warnings) {
  const data = await callApi('roleData', {
    ...auth,
    params: { gameId: GAME_ID, roleId: auth.roleId, serverId: auth.serverId }
  });
  const list = (Array.isArray(data?.roleList) ? data.roleList : null)
    || (Array.isArray(data?.list) ? data.list : null)
    || (Array.isArray(data) ? data : []);
  if (!list.length) {
    warnings.push('角色总览接口返回空（该账号可能没有公开角色数据）');
    return null;
  }
  const characters = list.slice(0, MAX_ROSTER_FETCH).map((raw) => ({
    id: str(pick(raw, 'roleId', 'role_id', 'id')),
    name: str(pick(raw, 'roleName', 'role_name', 'name')) || '？',
    level: num(pick(raw, 'level', 'roleLevel')),
    breach: num(pick(raw, 'breach', 'breakthrough')),
    star: num(pick(raw, 'starLevel', 'star', 'quality')),
    attribute: str(pick(raw, 'attributeName', 'attribute')),
    weaponType: str(pick(raw, 'weaponTypeName', 'weaponType'))
  })).filter((c) => c.name !== '？');
  // 练满的排前面，同等级按星级
  characters.sort((a, b) => (b.level || 0) - (a.level || 0) || (b.star || 0) - (a.star || 0));
  return { characters };
}

/**
 * 单个角色的练度详情。
 * ⚠️ getRoleDetail 要两个 id：roleId=账号的（auth 里），id=角色的（这里传 characterId）。
 */
async function fetchCharacterDetail(auth, target) {
  const data = await callApi('roleDetail', {
    ...auth,
    params: {
      gameId: GAME_ID,
      roleId: auth.roleId,
      serverId: auth.serverId,
      characterId: target.id
    }
  });
  // 风控：触发极验时 data 里会带 geeTest，此时没有真实数据
  if (data?.geeTest) {
    throw new Error('库街区要求人机验证（极验），暂无法查询。稍后再试，'
      + '或在库街区 App 里打开一次数据终端页面。');
  }
  return normalizeDetail(data, target);
}

/** 练度详情归一化（字段名全部来自 Haiyu 的 GamerRoilDetily 模型） */
function normalizeDetail(data, target) {
  const role = data?.role || {};
  const chainList = Array.isArray(data?.chainList) ? data.chainList : [];
  const weaponData = data?.weaponData || {};
  const weapon = weaponData.weapon || {};
  const skillList = Array.isArray(data?.skillList) ? data.skillList : [];
  const phantomData = data?.phantomData || {};
  const echoes = Array.isArray(phantomData.equipPhantomList) ? phantomData.equipPhantomList : [];

  return {
    name: str(pick(role, 'roleName', 'name')) || target.name,
    level: num(pick(role, 'level')) ?? num(data?.level) ?? target.level ?? undefined,
    star: num(pick(role, 'starLevel')) ?? target.star ?? undefined,
    chainTotal: chainList.length || 6,
    chainUnlocked: chainList.filter((c) => c?.unlocked === true).length,
    weapon: {
      name: str(pick(weapon, 'weaponName', 'name')),
      level: num(pick(weaponData, 'level', 'weaponLevel')),
      // resonLevel = 精炼等级（共鸣链）
      rank: num(pick(weaponData, 'resonLevel', 'resonanceLevel', 'refine')),
      star: num(pick(weapon, 'weaponStarLevel', 'starLevel'))
    },
    skills: skillList.map((s) => ({
      name: str(pick(s?.skill, 'name', 'skillName')) || '技能',
      level: num(pick(s, 'level')),
      kind: num(pick(s?.skill, 'type'))
    })).filter((s) => s.name),
    echoes: echoes.slice(0, 5).map((e) => {
      const main = Array.isArray(e?.mainProps) ? e.mainProps[0] : null;
      return {
        cost: num(pick(e, 'cost')),
        level: num(pick(e, 'level')),
        main: str(pick(main, 'attributeName', 'name')),
        mainValue: str(pick(main, 'attributeValue', 'value'))
      };
    }),
    bindCount: echoes.length
  };
}

/**
 * 探索度归一化。
 * 结构：exploreList[]（每个国家一条）
 *   → country.countryName + countryProgress(字符串百分比，如 "18.40")
 *   → areaInfoList[].areaName + areaProgress(数字百分比，如 11)
 * 注意两者类型不一致：一个字符串一个小数，都要按「0~100 的百分数」解析。
 */
async function fetchExplore(auth, warnings) {
  const data = await callApi('explore', {
    ...auth,
    params: { gameId: GAME_ID, roleId: auth.roleId, serverId: auth.serverId }
  });
  const list = Array.isArray(data?.exploreList) ? data.exploreList
    : (Array.isArray(data) ? data : []);
  const countries = [];
  const regions = [];
  for (const item of list) {
    const countryName = str(pick(item?.country, 'countryName', 'name'));
    const cp = parsePercent(pick(item, 'countryProgress', 'progress'));
    if (countryName) countries.push({ name: countryName, percent: cp });
    const areas = Array.isArray(item?.areaInfoList) ? item.areaInfoList : [];
    for (const a of areas) {
      const name = str(pick(a, 'areaName', 'name'));
      if (!name) continue;
      regions.push({ name, percent: parsePercent(pick(a, 'areaProgress', 'progress')) });
    }
  }
  if (!regions.length && !countries.length) {
    warnings.push('探索度接口返回空（可能该账号未开启数据展示）');
    return null;
  }
  // 地区很多（几十个），按探索度从高到低排，图上只看前若干个最直观
  regions.sort((a, b) => b.percent - a.percent);
  const valid = regions.filter((r) => r.percent > 0);
  const totalPercent = valid.length
    ? valid.reduce((a, r) => a + r.percent, 0) / valid.length
    : 0;
  return { countries, regions, totalPercent };
}

// ══════════════════════════════════════════════════════════════════════════
// 发送与会话回执
// ══════════════════════════════════════════════════════════════════════════

async function sendCard(ctx, png, note) {
  if (typeof ctx?.sender?.sendImage !== 'function' || !ctx?.chatKey) {
    return { ok: false, error: '当前会话没有可用的图片发送器，无法发图。' };
  }
  const file = saveImage(png, 'kurobbs');
  try {
    // file 优先（协议端自己读盘，body 极小）；dataUrl 作为协议端不同机时的回退
    await ctx.sender.sendImage(
      ctx.chatKey,
      { file, dataUrl: `base64://${png.toString('base64')}` },
      { note }
    );
  } catch (error) {
    return { ok: false, error: `图片发送失败：${short(error)}（图已存本地：${file}）` };
  }
  ctx.session?.sent?.push({
    type: 'image',
    text: `[图片:${note}]`,
    at: new Date().toLocaleTimeString('zh-CN', { hour12: false })
  });
  try { ctx.emit?.('session-update', ctx.session?.id); } catch { /* 上报失败不影响已发的图 */ }
  return { ok: true };
}

/**
 * 把图上的关键数值写成一条「自己发过的消息」进会话。
 *
 * 为什么需要它：模型**看不到**图片内容。不上报的话，群友追问「今汐几命」时
 * 模型只能瞎猜（这类幻觉比"不知道"更糟）。写进 session.sent 之后，
 * 后续轮次的提示词里就有这些数字了。
 */
function pushSummary(ctx, summary) {
  try {
    const text = `[库街区查询结果] ${summary.replace(/\n/g, ' / ')}`.slice(0, 700);
    ctx.session?.sent?.push({
      type: 'text',
      text,
      at: new Date().toLocaleTimeString('zh-CN', { hour12: false })
    });
    ctx.emit?.('session-update', ctx.session?.id);
  } catch { /* 回执失败不影响已发的图 */ }
}

function summarize(account, roster, detail, explore, warnings) {
  const parts = [];
  parts.push(`账号「${account.name}」${account.level != null ? `（账号等级 Lv.${account.level}）` : ''}`);
  const chars = roster?.characters || [];
  if (chars.length) {
    const top = chars.slice(0, 8).map((c) => `${c.name} Lv.${c.level ?? '?'}${c.star ? ` ${c.star}★` : ''}`);
    parts.push(`拥有角色 ${chars.length} 名，图上显示：${top.join('；')}${chars.length > 8 ? ' 等' : ''}`);
  }
  if (detail) {
    const bits = [`${detail.name} Lv.${detail.level ?? '?'}`];
    if (detail.chainUnlocked != null) bits.push(`共鸣链 ${detail.chainUnlocked}/${detail.chainTotal}`);
    if (detail.weapon?.name) {
      bits.push(`武器 ${detail.weapon.name}${detail.weapon.level != null ? ` Lv.${detail.weapon.level}` : ''}`
        + `${detail.weapon.rank != null ? ` 精${detail.weapon.rank}` : ''}`);
    }
    if (detail.skills?.length) {
      bits.push(`技能 ${detail.skills.slice(0, 5).map((s) => `${s.name}${s.level ?? '?'}`).join(' ')}`);
    }
    if (detail.bindCount) bits.push(`声骸 ${detail.bindCount} 件`);
    parts.push(bits.join('，'));
  }
  const regions = explore?.regions || [];
  if (regions.length) {
    parts.push(`地图探索度：${regions.slice(0, 8).map((r) => `${r.name} ${Math.round(r.percent * 100)}%`).join('、')}`
      + `${regions.length > 8 ? ' 等' : ''}`);
  }
  if (warnings.length) parts.push(`未能取到：${warnings.join('；')}`);
  parts.push('（以上数字来自接口，已渲染成图片发到会话；不要编造图中没有的数值。）');
  return parts.join('\n');
}

// ══════════════════════════════════════════════════════════════════════════
// 挑选与杂项
// ══════════════════════════════════════════════════════════════════════════

/** 挑账号角色：显式传的 role → 设置默认 → isDefault → 第一个 */
function chooseAccount(accounts, want, fallback) {
  const describe = () => accounts
    .map((r, i) => `${i + 1}.${r.name}${r.level != null ? `(Lv.${r.level})` : ''}`)
    .join('  ');
  const match = (needle) => {
    const s = String(needle || '').trim();
    if (!s) return null;
    if (/^\d+$/.test(s)) {
      const idx = Number(s) - 1;
      if (idx >= 0 && idx < accounts.length) return accounts[idx];
    }
    const lower = s.toLowerCase();
    return accounts.find((r) => r.name.toLowerCase() === lower)
      || accounts.find((r) => r.name.toLowerCase().includes(lower))
      || accounts.find((r) => r.roleId === s)
      || null;
  };
  if (want) {
    const hit = match(want);
    if (hit) return { account: hit };
    return { error: `账号下没有叫「${want}」的角色。可选：${describe()}（让群友说名字或序号。）` };
  }
  if (fallback) {
    const hit = match(fallback);
    if (hit) return { account: hit };
  }
  return { account: accounts.find((r) => r.isDefault) || accounts[0] };
}

/** 在拥有的角色里按名字/序号找目标（找不到返回 null，由调用方给可操作提示） */
function findCharacter(characters, want) {
  const s = String(want || '').trim();
  if (!s || !characters.length) return null;
  const lower = s.toLowerCase();
  return characters.find((c) => c.name.toLowerCase() === lower)
    || characters.find((c) => c.name.toLowerCase().includes(lower))
    || characters.find((c) => String(c.id) === s)
    || null;
}

async function safe(fn, label, warnings) {
  try {
    const r = await fn();
    if (r == null) return null;      // 具体原因由 fn 自己 warning
    return r;
  } catch (error) {
    warnings.push(`${label}查询失败：${short(error)}`);
    return null;
  }
}

/**
 * 百分比解析：接口这里**类型不一致** ——
 *   countryProgress 是字符串百分数（"18.40"）
 *   areaProgress 是数字百分数（11）
 * 所以统一解释为「0~100 的百分数」，再除以 100 归一化。
 */
function parsePercent(v) {
  const n = Number(String(v ?? '').replace('%', '').trim());
  if (!Number.isFinite(n)) return 0;
  return clampNum(n / 100, 0, 1, 0);
}

function str(v) {
  return v == null ? '' : String(v).trim();
}

function num(v) {
  if (v == null || v === '') return null;
  const n = Number(String(v).replace(/[^\d.-]/g, ''));
  return Number.isFinite(n) ? n : null;
}

function clampNum(value, min, max, fallback) {
  const n = Number(value);
  if (!Number.isFinite(n)) return fallback;
  return Math.max(min, Math.min(max, n));
}

function nowText() {
  return new Date().toLocaleString('zh-CN', { hour12: false });
}

function short(error) {
  return String(error?.message || error || '未知错误').slice(0, 200);
}

const ok = (content) => ({ content: String(content), isError: false });
const fail = (content) => ({ content: String(content), isError: true });

// 供测试/排障引用（不要删：导出点被桩测试用来核对路径表）
export { ENDPOINTS, parseDataField };
