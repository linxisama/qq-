/**
 * 方舟终末地超大杯 —— 群里提到游戏词条时，查资料 + 网络评价，
 * 先发一句“超大杯”，再补一句短理由。
 *
 * 数据源：
 *   · 明日方舟：PRTS MediaWiki API（action=parse / prop=wikitext）
 *   · 终末地：Endfield Wiki（wiki.gg）干员资料快照（lib/endfield-data.js）
 *   · 网络评价：Bing RSS（只取摘要，不抓整页；失败就不硬编）
 *
 * 设计取舍：
 *   · 工具自己用 ctx.sender 发两条消息，保证“超大杯”和理由不会被模型改写。
 *   · 查不到资料时，只有明确是游戏词条才发“资料没查到，但气势先到位”；
 *     完全不像游戏词的调用直接报错，不硬蹭。
 *   · 结果缓存 10 分钟；同群同词默认 60 秒冷却，防连续刷屏。
 */

import { ENDFIELD_ROSTER } from './lib/endfield-data.js';

let cfg = () => ({});
let log = () => {};
let warn = () => {};

const PRTS_API = 'https://prts.wiki/api.php';
const BING = 'https://cn.bing.com/search';
const CACHE_MS = 10 * 60 * 1000;

const ARKNIGHTS_HINTS = [
  '明日方舟', '罗德岛', '源石', '矿石病', '萨卡兹', '卡兹戴尔', '龙门', '维多利亚',
  '莱塔尼亚', '乌萨斯', '谢拉格', '叙拉古', '拉特兰', '伊比利亚', '玻利瓦尔',
  '萨尔贡', '阿戈尔', '米诺斯', '雷姆必拓', '卡西米尔', '干员', '危机合约',
  '集成战略', '生息演算', '保全派驻', '悖论模拟',
];

const CLASS_CN = {
  Guard: '近卫', Caster: '术师', Defender: '重装', Vanguard: '先锋',
  Sniper: '狙击', Medic: '医疗', Supporter: '辅助', Specialist: '特种',
  Striker: '突击',
};
const WEAPON_CN = {
  Sword: '单手剑', Greatsword: '双手剑', 'Great Sword': '双手剑', Polearm: '长枪',
  Bow: '弓', Handcannon: '手炮', 'Arts Unit': '法术单元', Staff: '法杖', Shield: '盾',
  Axe: '斧', Mace: '锤', Dagger: '短剑', Pistol: '手枪', Rifle: '步枪',
};
const ELEMENT_CN = {
  Physical: '物理', Arts: '法术', Cryo: '冰', Fire: '火', Heat: '火', Electric: '电',
  Nature: '自然', Void: '虚数',
};
const TAG_CN = {
  Lift: '浮空', Stagger: '击破', Vulnerable: '易伤', Breach: '破防',
  Heal: '治疗', Shield: '护盾', Buff: '增益', Debuff: '减益', AoE: '群攻',
  Burst: '爆发', Sustain: '续航', Control: '控制', Summon: '召唤',
  'Damage Dealer': '输出', 'HP Treatment': '治疗', 'SP Recovery': '技力回复',
  'Arts Susc.': '法术易伤', 'PHY Susc.': '物理易伤', Susceptibility: '易伤',
  'Nature Infliction': '自然附着', 'Cryo Infliction': '冰附着',
  'Electric Infliction': '电附着', 'Heat Infliction': '火附着',
  Electrify: '感电', Combust: '燃烧', Corrode: '侵蚀', Crush: '碎甲',
  'Knock Down': '击倒', 'Crowd Control': '控制', Link: '链接', Amp: '增幅',
  Protect: '保护', Crit: '暴击', Solidify: '凝固', Weakness: '虚弱',
  'Arts Burst': '法术爆发',
};
const STAT_CN = {
  Agility: '敏捷', Strength: '力量', Intellect: '智力', Will: '意志',
};

const cache = new Map();
const lastSent = new Map();

function clamp(n, lo, hi, dflt) {
  const v = Number(n);
  if (!Number.isFinite(v)) return dflt;
  return Math.min(hi, Math.max(lo, Math.round(v)));
}

function clip(s, n) {
  const t = String(s ?? '').replace(/\s+/g, ' ').trim();
  if (t.length <= n) return t;
  return `${t.slice(0, Math.max(1, n - 1))}…`;
}

function stripHtml(s) {
  return String(s ?? '')
    .replace(/<!\[CDATA\[|\]\]>/g, '')
    .replace(/<br\s*\/?>/gi, '，')
    .replace(/<[^>]+>/g, '')
    .replace(/&nbsp;/gi, ' ')
    .replace(/&amp;/gi, '&')
    .replace(/&quot;/gi, '"')
    .replace(/&#39;/gi, "'")
    .replace(/&lt;/gi, '<')
    .replace(/&gt;/gi, '>')
    .replace(/\s+/g, ' ')
    .trim();
}

/** 把 MediaWiki 的常见标记压成一句可读文本。 */
function stripWiki(s) {
  let t = String(s ?? '');
  t = t.replace(/<br\s*\/?>/gi, '，');
  for (let i = 0; i < 6; i += 1) {
    t = t.replace(/\{\{[^{}]*\|([^{}|]*)\}\}/g, '$1');
    t = t.replace(/\{\{[^{}]*\}\}/g, '');
  }
  t = t.replace(/\[\[[^\]|]*\|([^\]]*)\]\]/g, '$1');
  t = t.replace(/\[\[([^\]]*)\]\]/g, '$1');
  t = t.replace(/<[^>]+>/g, '');
  t = t.replace(/'''?/g, '');
  t = t.replace(/&nbsp;/gi, ' ');
  return t.replace(/\s+/g, ' ').trim();
}

function field(wikitext, name) {
  const safe = String(name).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const m = String(wikitext ?? '').match(new RegExp(`\\|\\s*${safe}\\s*=\\s*([^\\n]*)`));
  return m ? m[1].trim() : '';
}

function enc(s) {
  return encodeURIComponent(String(s ?? ''));
}

function cacheGet(key) {
  const hit = cache.get(key);
  if (!hit) return null;
  if (Date.now() - hit.at > CACHE_MS) {
    cache.delete(key);
    return null;
  }
  return hit.data;
}

function cacheSet(key, data) {
  cache.set(key, { at: Date.now(), data });
  if (cache.size > 300) {
    const first = cache.keys().next().value;
    if (first) cache.delete(first);
  }
  return data;
}

function getFetch(api) {
  if (typeof api?.fetch !== 'function') {
    throw new Error('没有 web_fetch 权限，无法查资料');
  }
  return api.fetch;
}

async function request(api, url, { json = false, timeout = 8000 } = {}) {
  const doFetch = getFetch(api);
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), Math.max(2000, timeout));
  try {
    const res = await doFetch(url, {
      signal: controller.signal,
      redirect: 'follow',
      headers: {
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) QQ-Agent-Game-Hypercup/1.0',
        'accept-language': 'zh-CN,zh;q=0.9,en;q=0.6',
        accept: json ? 'application/json' : 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
      },
    });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const text = await res.text();
    return json ? JSON.parse(text) : text;
  } catch (error) {
    if (error?.name === 'AbortError') throw new Error('查询超时');
    throw error;
  } finally {
    clearTimeout(timer);
  }
}

function normalizeKeyword(raw) {
  let s = String(raw ?? '').trim();
  s = s.replace(/^[“”"'《》【】\[\]]+|[“”"'《》【】\[\]]+$/g, '').trim();
  s = s.replace(/^(评价一下|评价|评测一下|评测|聊聊|说说|查一下|查查|看看|问一下|请问)\s*/g, '').trim();
  s = s.replace(/(怎么样|强不强|厉害吗|值得练吗|值得抽吗|好不好用|什么水平|是什么)$/g, '').trim();
  s = s.replace(/[?？!！。，,、;；:：]+$/g, '').trim();
  return clip(s, 40);
}

function detectGame(keyword) {
  if (Object.prototype.hasOwnProperty.call(ENDFIELD_ROSTER, keyword) || /终末地|塔卫二/.test(keyword)) return 'endfield';
  if (ARKNIGHTS_HINTS.some((w) => keyword.includes(w))) return 'arknights';
  return 'auto';
}

function pickPrtsTitle(hits, keyword) {
  const norm = (s) => String(s || '').replace(/\s*\([^)]*\)\s*$/, '').trim();
  const list = (hits || []).filter((h) => h && h.title && !/\/|分类|模板|文件/.test(h.title));
  const exact = list.find((h) => h.title === keyword);
  if (exact) return exact.title;
  const normalized = list.find((h) => norm(h.title) === keyword);
  if (normalized) return normalized.title;
  const starts = list.find((h) => h.title.startsWith(keyword));
  if (starts) return starts.title;
  return '';
}

async function prtsLookup(api, keyword, timeout) {
  const key = `ark:${keyword}`;
  const cached = cacheGet(key);
  if (cached) return cached;

  const hits = await request(api, `${PRTS_API}?action=query&list=search&srsearch=${enc(keyword)}&srlimit=8&format=json&formatversion=2`, { json: true, timeout });
  const title = pickPrtsTitle(hits?.query?.search || [], keyword);
  if (!title) return null;

  const page = await request(api, `${PRTS_API}?action=parse&page=${enc(title)}&prop=wikitext&format=json&formatversion=2&redirects=1`, { json: true, timeout });
  const wt = page?.parse?.wikitext;
  if (!wt || !/\{\{CharinfoV2/.test(wt)) return null;

  const rarityRaw = Number(field(wt, '稀有度'));
  const stars = Number.isFinite(rarityRaw) && rarityRaw >= 0 && rarityRaw <= 5 ? rarityRaw + 1 : 0;
  const tags = stripWiki(field(wt, '标签')).split(/\s+/).map((x) => x.trim()).filter(Boolean).slice(0, 4);
  const skills = [...wt.matchAll(/\|技能名=([^\n|]+)/g)]
    .map((m) => stripWiki(m[1]))
    .filter(Boolean)
    .filter((x, i, arr) => arr.indexOf(x) === i)
    .slice(0, 4);

  const info = {
    game: '明日方舟',
    gameKey: 'arknights',
    title: String(page.parse.title || title),
    stars,
    cls: stripWiki(field(wt, '职业')),
    branch: stripWiki(field(wt, '分支')),
    tags,
    trait: stripWiki(field(wt, '特性')),
    intro: stripWiki(field(wt, '干员简介') || field(wt, '干员简介补充')),
    skills,
    sourceUrl: `https://prts.wiki/w/${enc(page.parse.title || title)}`,
  };
  return cacheSet(key, info);
}

function endfieldLookup(keyword) {
  const row = ENDFIELD_ROSTER[keyword];
  if (!row) return null;
  const tags = Array.isArray(row.tags) ? row.tags : [];
  return {
    game: '终末地',
    gameKey: 'endfield',
    title: keyword,
    enTitle: row.en || '',
    rarity: Number(row.rarity) || 0,
    cls: row.class || '',
    clsCn: CLASS_CN[row.class] || row.class || '角色',
    weapon: row.weapon || '',
    weaponCn: WEAPON_CN[row.weapon] || row.weapon || '',
    element: row.element || '',
    elementCn: ELEMENT_CN[row.element] || row.element || '',
    tags,
    tagsCn: tags.map((x) => TAG_CN[x] || x).filter(Boolean).slice(0, 4),
    main: row.main || '',
    mainCn: STAT_CN[row.main] || row.main || '',
    sourceUrl: row.en ? `https://endfield.wiki.gg/wiki/${enc(row.en)}` : '',
  };
}

function parseRss(xml) {
  const blocks = String(xml || '').match(/<item>[\s\S]*?<\/item>/gi) || [];
  const get = (block, tag) => {
    const m = block.match(new RegExp(`<${tag}[^>]*>([\\s\\S]*?)</${tag}>`, 'i'));
    return stripHtml(m ? m[1] : '');
  };
  return blocks.map((b) => ({
    title: get(b, 'title'),
    link: get(b, 'link'),
    desc: get(b, 'description'),
  }));
}

function pickReview(items) {
  let best = null;
  let bestScore = -99;
  for (const it of items) {
    if (!it?.desc || it.desc.length < 20) continue;
    const meta = `${it.link} ${it.title}`;
    if (/prts\.wiki|wiki\.biligame|hypergryph\.com|baike\.baidu|wiki\.gg|官网|下载|充值|时装|皮肤|语音|立绘|壁纸/i.test(meta)) continue;
    let score = 0;
    if (/moegirl|tieba|nga|bilibili|taptap|gamersky|17173|gamer/i.test(it.link)) score += 3;
    if (/评价|测评|评测|强度|表现|推荐|值得|泛用|退环境|就业|新手|简评|攻略|好用|难用/.test(`${it.title} ${it.desc}`)) score += 2;
    if (/强|弱|输出|辅助|爆发|手感|开荒|决战技/.test(it.desc)) score += 1;
    if (score > bestScore) {
      best = it;
      bestScore = score;
    }
  }
  return bestScore >= 2 ? best : null;
}

async function fetchReview(api, game, title, timeout) {
  const gameName = game === 'endfield' ? '终末地' : '明日方舟';
  const query = `"${String(title).replace(/"/g, '')}" ${gameName} 评价 强度`;
  const url = `${BING}?q=${enc(query)}&format=rss&setlang=zh-hans`;
  try {
    const xml = await request(api, url, { timeout });
    const item = pickReview(parseRss(xml));
    if (!item) return '';
    return clip(item.desc, 120);
  } catch (error) {
    warn(`网络评价检索失败：${error?.message || error}`);
    return '';
  }
}

/** 从网络摘要里粗判风向，只给“不错/有争议/争议不小”，不假装读过全文。 */
function reviewSentiment(review) {
  const t = String(review || '');
  if (!t) return '';
  const pos = (t.match(/强|不错|推荐|值得|好用|泛用|舒服|开荒|T0|超大杯|决战技/g) || []).length;
  const neg = (t.match(/弱|不建议|退环境|难用|拉胯|争议|挤不进|不值得|刮痧/g) || []).length;
  if (pos && neg) return '网上评价有争议';
  if (pos) return '网上风评不错';
  if (neg) return '网上争议不小';
  return '';
}

function arknightsReason(info, review, max) {
  const role = [info.cls, info.branch].filter(Boolean).join('·');
  const bits = [];
  if (info.stars) bits.push(`${info.stars}星${role || '干员'}`);
  else if (role) bits.push(role);
  if (info.tags?.length) bits.push(`定位${info.tags.slice(0, 2).join('/')}`);
  const skill = info.skills?.[2] || info.skills?.[1] || info.skills?.[0];
  if (skill) bits.push(`招牌「${skill}」`);
  if (info.trait && !/降低|减少|下降|负面/.test(info.trait)) bits.push(clip(info.trait, 26));
  const mood = reviewSentiment(review);
  if (mood) bits.push(mood);
  return clip(bits.join('，') || `${info.title}这角色`, max);
}

function endfieldReason(info, review, max) {
  const role = `${info.rarity ? `${info.rarity}星` : ''}${info.clsCn || '角色'}`;
  const bits = [role];
  if (info.weaponCn) bits.push(info.weaponCn);
  if (info.tagsCn?.length) bits.push(info.tagsCn.slice(0, 2).join('/'));
  if (info.mainCn) bits.push(`主${info.mainCn}`);
  const mood = reviewSentiment(review);
  if (mood) bits.push(mood);
  return clip(bits.filter(Boolean).join('，'), max);
}

export function setup(api) {
  cfg = api?.config || (() => ({}));
  log = api?.log || (() => {});
  warn = api?.warn || (() => {});

  api.registerTool({
    id: 'rate_keyword',
    name: '游戏关键词超大杯',
    description: '查询明日方舟 / 终末地的干员、角色或游戏名资料，并给出“超大杯”加一句短理由。当群里出现游戏关键词，或有人让你评价某个干员/角色时使用。工具会直接把两条消息发到当前会话，成功后不要复述。',
    category: 'query',
    icon: '🏆',
    parameters: {
      type: 'object',
      properties: {
        keyword: { type: 'string', description: '要评价的游戏词条，例如“银灰”“陈千语”“真银斩”' },
        game: { type: 'string', enum: ['auto', 'arknights', 'endfield'], description: '游戏；不确定就填 auto' },
        context: { type: 'string', description: '可选：群里原话，帮助判断是哪一个词条' },
      },
      required: ['keyword'],
    },
    async execute(ctx, args) {
      const raw = String(args?.keyword ?? '').trim();
      if (!raw) return { content: '缺少 keyword：要评价哪个干员/角色/词条？', isError: true };
      const keyword = normalizeKeyword(raw);
      if (!keyword) return { content: '关键词是空的。', isError: true };

      const c = cfg();
      const timeout = clamp(c.timeoutMs, 3000, 15000, 8000);
      const maxChars = clamp(c.reasonMaxChars, 40, 160, 90);
      const cooldown = clamp(c.cooldownSeconds, 0, 3600, 60);
      const explicit = ['arknights', 'endfield'].includes(String(args?.game)) ? String(args.game) : 'auto';
      let game = explicit === 'auto' ? detectGame(keyword) : explicit;

      let info = null;
      try {
        if (game === 'endfield') {
          info = endfieldLookup(keyword);
          if (!info && explicit === 'auto') info = await prtsLookup(api, keyword, timeout);
          if (info?.gameKey === 'arknights') game = 'arknights';
        } else if (game === 'arknights') {
          info = await prtsLookup(api, keyword, timeout);
          if (!info && explicit === 'auto') info = endfieldLookup(keyword);
          if (info?.gameKey === 'endfield') game = 'endfield';
        } else {
          info = await prtsLookup(api, keyword, timeout);
          if (info) game = 'arknights';
          else {
            info = endfieldLookup(keyword);
            if (info) game = 'endfield';
          }
        }
      } catch (error) {
        warn(`查询 ${keyword} 失败：${error?.message || error}`);
        // 一个源超时不代表另一个源也没有；auto 模式再给另一家一次机会。
        if (game === 'auto') {
          try {
            info = endfieldLookup(keyword);
            if (info) game = 'endfield';
          } catch (secondError) {
            warn(`终末地兜底查询也失败：${secondError?.message || secondError}`);
          }
        }
      }

      let fallback = false;
      if (!info) {
        // 明确是游戏词条但资料页没铺全：不装死，给一句诚实的兜底。
        if (game === 'auto') {
          return { content: `没查到「${keyword}」的明日方舟/终末地资料；如果这不是游戏词条，就不要硬发超大杯。`, isError: true };
        }
        fallback = true;
        info = {
          game: game === 'endfield' ? '终末地' : '明日方舟',
          gameKey: game,
          title: keyword,
          fallback: true,
          sourceUrl: '',
        };
      }

      const chatKey = String(ctx?.chatKey || '');
      const dedupeKey = `${chatKey}|${info.gameKey}|${info.title}`;
      if (cooldown > 0 && chatKey) {
        const last = lastSent.get(dedupeKey) || 0;
        if (Date.now() - last < cooldown * 1000) {
          return { content: `skip: 「${info.title}」刚刚已经评价过，这次不要重复发。`, isError: true };
        }
      }

      let review = '';
      if (!fallback && c.reviewOnline !== false) {
        try {
          review = await fetchReview(api, info.gameKey, info.title, timeout);
        } catch (error) {
          warn(`网络评价读取失败：${error?.message || error}`);
        }
      }

      let reason;
      if (fallback) {
        if (/终末地|塔卫二/.test(info.title)) reason = '塔卫二开荒+基建+战斗，讨论度一直不低。';
        else if (/明日方舟/.test(info.title)) reason = '塔防老牌，干员和关卡讨论度一直很高。';
        else if (info.gameKey === 'endfield') reason = '塔卫二这边资料还没铺全，但气势先超大杯。';
        else reason = '资料页没查到，但气势先超大杯。';
      } else {
        reason = info.gameKey === 'endfield'
          ? endfieldReason(info, review, maxChars)
          : arknightsReason(info, review, maxChars);
      }

      const say = ['超大杯', reason || '别问，问就是超大杯。'];
      if (chatKey && typeof ctx?.sender?.sendTextBatch === 'function') {
        lastSent.set(dedupeKey, Date.now());
        try {
          await ctx.sender.sendTextBatch(chatKey, say);
          return {
            content: `已发送：超大杯 / ${say[1]}${/[。！？]$/.test(say[1]) ? '' : '。'}不要再复述或补发。`,
          };
        } catch (error) {
          lastSent.delete(dedupeKey);
          return { content: `查到「${info.title}」但发送失败：${error?.message || error}`, isError: true };
        }
      }

      lastSent.set(dedupeKey, Date.now());
      return { content: JSON.stringify({ game: info.game, keyword: info.title, verdict: '超大杯', reason, say, source: info.sourceUrl || '' }) };
    },
  });

  log('方舟终末地超大杯已就绪：PRTS + Endfield Wiki + Bing 评价');
}

export function deactivate() {
  cache.clear();
  lastSent.clear();
  log('方舟终末地超大杯已卸载');
}
