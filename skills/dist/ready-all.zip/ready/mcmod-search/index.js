// MC百科查询 —— LLM 型技能（skills/mcmod-search/）
//
// 两个工具：
//   ① mcmod-search__search —— 在 MC百科（search.mcmod.cn）搜关键词，返回「标题 + 链接 + 摘要」
//   ② mcmod-search__page   —— 读取某条条目的正文（只允许 mcmod.cn 的链接）
//
// 遵守本项目 skill 的硬约束（见 doc/extend_development/）：
//   · 工具 id 只用 [a-zA-Z0-9_-]（loader 会加 mcmod-search__ 前缀）
//   · 联网只走 api.fetch（清单已声明 permissions: ["web_fetch"]），不碰 globalThis.fetch
//   · 配置在执行时用 cfg() 读，不在 setup 里快照
//   · 所有失败路径 return { content, isError: true }，不把异常抛给上层
//   · 逻辑全部写在这个入口文件里（热重载只对入口做防缓存，拆到 lib/ 改完要重启）
//
// 纯函数（parseSearchResults / parsePage）额外 export，方便 test/ 里离线回归。

const SEARCH_URL = 'https://search.mcmod.cn/s';
const SITE_HOST_RE = /^(www\.)?mcmod\.cn$/i;
const MAX_HTML_CHARS = 800000;

const USER_AGENT =
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36';

// 详情页正文容器：按页面类型依次尝试（物品 / 教程 / 模组 / 兜底）
const CONTENT_CLASSES = ['item-content', 'post-content', 'text-area', 'class-text', 'common-text'];
// 搜索结果的链接只认这些路径（排除分类、标签等导航链接）
const DETAIL_PATH_RE = /^\/(class|item|modpack|post|data|modlist|tag)\/[^/]*\d/i;

let cfg = () => ({});
let log = () => {};
let net = null;   // api.fetch

// ── 小工具 ─────────────────────────────────────────────────────────────────

function clampInt(value, min, max, fallback) {
  const n = Math.round(Number(value));
  if (!Number.isFinite(n)) return fallback;
  return Math.min(max, Math.max(min, n));
}

/** 把孤立代理项换成 U+FFFD：避免把坏 emoji 送进模型请求（会被严格 JSON 解析器 400）。 */
function wellFormed(text) {
  const s = String(text ?? '');
  return typeof s.toWellFormed === 'function'
    ? s.toWellFormed()
    : s.replace(/[\uD800-\uDBFF](?![\uDC00-\uDFFF])|(?<![\uD800-\uDBFF])[\uDC00-\uDFFF]/g, '\uFFFD');
}

/** 按字符截断，且不把 emoji 的代理对劈成两半。 */
function safeCut(text, max) {
  const s = String(text ?? '');
  if (s.length <= max) return s;
  let cut = s.slice(0, max);
  if (/[\uD800-\uDBFF]$/.test(cut)) cut = cut.slice(0, -1);
  return cut;
}

function decodeEntities(input) {
  return String(input ?? '')
    .replace(/&quot;/g, '"')
    .replace(/&apos;/g, "'")
    .replace(/&#39;/g, "'")
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&nbsp;/g, ' ')
    .replace(/&mdash;/g, '—')
    .replace(/&hellip;/g, '…')
    .replace(/&#(\d{1,6});/g, (_m, code) => {
      const n = Number(code);
      return Number.isFinite(n) && n > 0 && n <= 0x10ffff ? String.fromCodePoint(n) : '';
    })
    .replace(/&amp;/g, '&');
}

/** 去掉 MC百科 wiki 语法残留：`[h1=标题]`、`[ban:title_menu]`、`[img]…[/img]`、`[b]` 之类。 */
function cleanWikiMarkup(input) {
  return wellFormed(String(input ?? ''))
    .replace(/\[(?:\/)?[a-z][a-z0-9_:-]*(?:=[^\]]*)?\]/gi, '')
    .replace(/[\uE000-\uF8FF]/g, '')   // 图标字体的私有区字符（&#xe604; 之类）
    .replace(/[ \t\u00a0]+/g, ' ')
    .replace(/ *\n */g, '\n')
    .trim();
}

/** 模组页正文头尾都有导航/教程列表，掐掉，只留下介绍主体。 */
function trimClassNoise(text) {
  let out = String(text ?? '');
  for (const marker of ['支持平台:', '模组介绍', '简介']) {
    const i = out.indexOf(marker);
    if (i > 0 && i < 3000) {
      out = out.slice(i);
      break;
    }
  }
  // 尾部是「教程列表」：连续出现「N 次浏览」的行之后的内容与模组本身无关
  const lines = out.split('\n');
  let hits = 0;
  for (let i = 0; i < lines.length; i += 1) {
    if (/\d\s*[万亿]?\s*次浏览/.test(lines[i])) {
      hits += 1;
      if (hits === 3) {
        out = lines.slice(0, Math.max(0, i - 2)).join('\n');
        break;
      }
    }
  }
  return out.trim();
}

/** HTML 片段 → 纯文本（块级标签转换行，单元格转竖线）。 */
function htmlToText(input) {
  const text = String(input ?? '')
    .replace(/<script[\s\S]*?<\/script>/gi, ' ')
    .replace(/<style[\s\S]*?<\/style>/gi, ' ')
    .replace(/<br\s*\/?>/gi, '\n')
    .replace(/<\/(td|th)>/gi, ' | ')
    .replace(/<\/(p|div|li|tr|h[1-6]|section|article|ul|ol|table|blockquote)>/gi, '\n')
    .replace(/<[^>]+>/g, '');
  return wellFormed(decodeEntities(text))
    .replace(/[ \t\u00a0]+/g, ' ')
    .replace(/ *\n */g, '\n')
    .replace(/\n{3,}/g, '\n\n')
    .trim();
}

/** 从 start 处的 <tag 开始，按同名标签配对切出完整的一段。 */
function takeBalancedTag(html, start, tag) {
  const re = new RegExp(`<${tag}\\b|</${tag}\\s*>`, 'gi');
  re.lastIndex = start;
  let depth = 0;
  let m;
  while ((m = re.exec(html))) {
    if (m[0][1] === '/') {
      depth -= 1;
      if (depth <= 0) return html.slice(start, m.index + m[0].length);
    } else {
      depth += 1;
    }
  }
  return html.slice(start);
}

/** 找到所有同 class 的块级元素（同一页面可能有好几个，比如模组页的「索引 / 介绍 / 教程」分栏）。 */
function findAllBlocksByClass(html, className) {
  const re = new RegExp(`<(div|li|section|article|td)\\b[^>]*class="[^"]*\\b${className}\\b[^"]*"[^>]*>`, 'gi');
  const out = [];
  let m;
  while ((m = re.exec(html))) {
    const seg = takeBalancedTag(html, m.index, m[1].toLowerCase());
    if (seg) out.push(seg);
    re.lastIndex = m.index + Math.max(1, seg.length);
  }
  return out;
}

/** 只要 div（搜索结果里一个 result-item 就是一个 div）。 */
function findDivByClass(html, className) {
  const re = new RegExp(`<div[^>]*class="[^"]*\\b${className}\\b[^"]*"[^>]*>`, 'i');
  const m = re.exec(html);
  if (!m) return '';
  return takeBalancedTag(html, m.index, 'div');
}

/** 在片段里找到第一个"条目详情"链接，返回 { url, text }。 */
function pickDetailLink(fragment) {
  const re = /<a\b[^>]*href="([^"]+)"[^>]*>([\s\S]*?)<\/a>/gi;
  let m;
  while ((m = re.exec(fragment))) {
    const href = decodeEntities(m[1]).trim();
    const text = htmlToText(m[2]);
    if (!text) continue;
    const normalized = href.startsWith('//') ? `https:${href}` : href;
    let u;
    try {
      u = new URL(normalized);
    } catch {
      continue;
    }
    if (!SITE_HOST_RE.test(u.hostname)) continue;
    if (!DETAIL_PATH_RE.test(u.pathname)) continue;
    return { url: u.toString(), text };
  }
  return null;
}

/** 搜索结果页 → [{ title, url, snippet }] */
export function parseSearchResults(html, limit = 5) {
  const out = [];
  const source = String(html ?? '');
  let cursor = 0;
  while (out.length < limit) {
    const marker = source.indexOf('class="result-item"', cursor);
    if (marker < 0) break;
    const divStart = source.lastIndexOf('<div', marker);
    if (divStart < 0) break;
    const block = takeBalancedTag(source, divStart, 'div');
    cursor = divStart + Math.max(1, block.length);

    const head = findDivByClass(block, 'head');
    const body = findDivByClass(block, 'body');
    const link = pickDetailLink(head || block);
    if (!link) continue;
    const snippet = cleanWikiMarkup(htmlToText(body)).replace(/\s+/g, ' ').trim();
    out.push({
      title: link.text,
      url: link.url,
      snippet: snippet.length > 240 ? `${safeCut(snippet, 240)}…` : snippet
    });
  }
  return out;
}

/** 详情页 → { title, text } */
export function parsePage(html, { maxChars = 3000 } = {}) {
  const source = String(html ?? '');
  const h1 = source.match(/<h1[^>]*>([\s\S]*?)<\/h1>/i);
  const titleTag = source.match(/<title[^>]*>([\s\S]*?)<\/title>/i);
  const title = htmlToText(h1 ? h1[1] : titleTag ? titleTag[1] : '')
    .replace(/\s*-\s*MC百科[\s\S]*$/i, '')
    .trim();

  let container = '';
  let containerClass = '';
  for (const cls of CONTENT_CLASSES) {
    const blocks = findAllBlocksByClass(source, cls);
    let bestText = '';
    let bestScore = -Infinity;
    for (const block of blocks) {
      const text = cleanWikiMarkup(htmlToText(block));
      // 教程列表那种分栏里全是「N 次浏览」，越像列表分越低；正文段落没有这种行
      const views = (text.match(/次浏览/g) || []).length;
      const score = text.length - views * 150;
      if (score > bestScore) {
        bestScore = score;
        bestText = text;
      }
    }
    if (bestText && bestScore >= 80) {
      container = bestText;
      containerClass = cls;
      break;
    }
  }
  let text = container;
  // 容器也没找到时（比如某些特殊页），退回正文主体
  if (!text || text.length < 40) {
    containerClass = 'fallback';
    text = cleanWikiMarkup(htmlToText(findDivByClass(source, 'common-background') || source));
  }
  if (containerClass === 'class-text' || containerClass === 'fallback') text = trimClassNoise(text);
  text = text.replace(/\n{3,}/g, '\n\n').trim();

  const clipped = text.length > maxChars
    ? `${safeCut(text, maxChars)}…（已截断，原文 ${text.length} 字）`
    : text;
  return { title, text: clipped, totalChars: text.length };
}

// ── 联网 ───────────────────────────────────────────────────────────────────

async function fetchHtml(url) {
  if (typeof net !== 'function') throw new Error('没有联网权限（清单缺少 permissions: ["web_fetch"]）');
  const timeoutMs = clampInt(cfg().timeoutSec, 5, 40, 15) * 1000;
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(new Error(`请求超时（${timeoutMs / 1000}s）`)), timeoutMs);
  try {
    const res = await net(url, {
      method: 'GET',
      redirect: 'follow',
      headers: {
        'user-agent': USER_AGENT,
        accept: 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'accept-language': 'zh-CN,zh;q=0.9,en;q=0.6'
      },
      signal: controller.signal
    });
    if (!res || !res.ok) throw new Error(`HTTP ${res ? res.status : '无响应'}`);
    const text = await res.text();
    return text.length > MAX_HTML_CHARS ? text.slice(0, MAX_HTML_CHARS) : text;
  } finally {
    clearTimeout(timer);
  }
}

// ── 生命周期 ───────────────────────────────────────────────────────────────

export function setup(api) {
  cfg = api.config;
  log = (...args) => api.log(...args);
  net = typeof api.fetch === 'function' ? api.fetch : null;

  api.registerTool({
    id: 'search',
    name: '搜 MC百科',
    description:
      '在 MC百科（mcmod.cn）搜索《我的世界》的模组 / 整合包 / 物品 / 方块 / 生物 / 维度 / 教程 / 资料，返回「标题 + 链接 + 摘要」。' +
      '当群友 @ 你问 MC 的事、聊到某个模组或整合包、问到物品/合成/机制、贴出模组名要查，或你对 MC 的某个具体资料不确定时使用。' +
      '搜完要回答具体内容时，再用 mcmod_page 读对应链接。与《我的世界》无关的话题不要用。',
    category: 'knowledge',
    icon: '⛏️',
    parameters: {
      type: 'object',
      properties: {
        query: {
          type: 'string',
          description: '搜索关键词。用具体的模组名 / 物品名 / 生物名 / 教程主题，例如「虚无世界3」「下界合金锭」「村民繁殖」。中英文都行。'
        },
        limit: {
          type: 'integer',
          description: '返回几条结果，1~10，默认按技能设置（通常 5）。'
        }
      },
      required: ['query']
    },
    async execute(_ctx, args) {
      try {
        const query = String(args?.query ?? '').trim();
        if (!query) return { content: '缺少搜索关键词 query。', isError: true };
        const fallback = clampInt(cfg().maxResults, 1, 10, 5);
        const limit = clampInt(args?.limit, 1, 10, fallback);
        const url = `${SEARCH_URL}?key=${encodeURIComponent(query)}`;
        const html = await fetchHtml(url);
        const results = parseSearchResults(html, limit);
        if (!results.length) {
          return {
            content: `MC百科没有搜到「${query}」的条目。可以换成模组英文名或更短的物品名再搜一次；也可以直接告诉群友没查到。`
          };
        }
        const lines = results.map((r, i) => {
          const head = `${i + 1}. ${r.title}`;
          return r.snippet ? `${head}\n   ${r.url}\n   摘要：${r.snippet}` : `${head}\n   ${r.url}`;
        });
        return {
          content: `MC百科搜索「${query}」的前 ${results.length} 条结果：\n${lines.join('\n')}\n\n需要具体数值、机制或合成方式时，用 mcmod_page 读上面最相关的那条链接。`
        };
      } catch (error) {
        log('search 失败：', error?.message ?? error);
        return { content: `搜索 MC百科失败：${error?.message ?? error}`, isError: true };
      }
    }
  });

  api.registerTool({
    id: 'page',
    name: '读 MC百科条目',
    description:
      '读取 MC百科某个条目的正文（模组介绍、物品属性、方块用途、生物机制、教程等）。' +
      '参数 url 必须是用 mcmod_search 搜出来的 mcmod.cn 链接。在需要具体数值、合成材料、版本差异、玩法细节时使用；' +
      '只是闲聊或已经知道答案时不要调用。',
    category: 'knowledge',
    icon: '📖',
    parameters: {
      type: 'object',
      properties: {
        url: {
          type: 'string',
          description: '条目链接，必须来自上一步 mcmod_search 的结果，例如 https://www.mcmod.cn/class/1269.html。'
        },
        maxChars: {
          type: 'integer',
          description: '正文最多返回多少字，500~8000，默认按技能设置（通常 3000）。'
        }
      },
      required: ['url']
    },
    async execute(_ctx, args) {
      try {
        const raw = String(args?.url ?? '').trim();
        if (!raw) return { content: '缺少 url。请先用 mcmod_search 搜索，再把结果里的链接传进来。', isError: true };

        let target;
        try {
          target = new URL(raw.startsWith('//') ? `https:${raw}` : raw);
        } catch {
          return { content: `这不是一个合法链接：${raw}`, isError: true };
        }
        if (!SITE_HOST_RE.test(target.hostname)) {
          return { content: `只支持 mcmod.cn 的链接（收到的是 ${target.hostname}）。请用 mcmod_search 搜索后取链接。`, isError: true };
        }
        if (target.protocol !== 'https:') {
          return { content: '只支持 https 链接。', isError: true };
        }

        const fallback = clampInt(cfg().maxPageChars, 500, 8000, 3000);
        const maxChars = clampInt(args?.maxChars, 500, 8000, fallback);
        const html = await fetchHtml(target.toString());
        const page = parsePage(html, { maxChars });
        if (!page.text || page.text.length < 40) {
          return {
            content: `这个页面没抓到正文（${target.toString()}）。可能是列表页、搜索页，或页面结构变了；可以换一条搜索结果再试。`,
            isError: true
          };
        }
        return {
          content: `《${page.title || 'MC百科条目'}》\n${page.text}\n\n来源：${target.toString()}`
        };
      } catch (error) {
        log('page 失败：', error?.message ?? error);
        return { content: `读取 MC百科条目失败：${error?.message ?? error}`, isError: true };
      }
    }
  });
}

/** 同步自检：关掉联网 或 缺 web_fetch 权限时，在「技能」页直接说明原因。 */
export function available() {
  const current = cfg() || {};
  if (current.allowNetwork === false) {
    return { ok: false, reason: '已在设置里关闭「允许联网查 MC百科」，打开后即可使用' };
  }
  if (typeof net !== 'function') {
    return { ok: false, reason: '缺少联网权限（清单未声明 web_fetch）' };
  }
  return { ok: true };
}
