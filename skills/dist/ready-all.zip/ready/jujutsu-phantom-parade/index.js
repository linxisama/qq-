// 幻影夜行向导 —— LLM 型技能（skills/）
//
// 与「明日方舟大师」同一套骨架：
//   ① 内置资料库（kb/）：卡牌图鉴 + 强度榜 + 技能文本 + 中日词典 + 机制文档 —— 离线、秒回
//   ② 联网工具：补资料库没有的新卡/新技能（豆腐幻夜 WIKI 的原始数据表）
//   ③ 提示词片段：只在闸门放行时注入，告诉模型怎么查证、怎么说话
//
// 硬约束（与 arknights-master 一致）：
//   · 工具 id 只用 [a-zA-Z0-9_-]，注册后自动变成 jujutsu-phantom-parade__xxx
//   · 联网只用 api.fetch，清单声明 permissions: ["web_fetch"]
//   · 配置用 cfg() 在调用时读，不在 setup 时快照
//   · 所有失败路径 return { content, isError: true }，不把异常抛给上层

import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import {
  findCards, cardsOfCharacter, buildCardLine, searchKb, kbCatalog, cardCount, kbFetchedAt, searchSkills
} from './lib/local-kb.js';
import { translateJp, lookupTerm, glossaryCount, glossaryCatalog } from './lib/glossary.js';
import {
  tierReady, tierNames, cardsInTier, tierOfCard, formatTierBlock, formatTierOverview, tierSource
} from './lib/tier.js';
import { searchSkillsLive, findCardsLive, siteUrl } from './lib/dfhy.js';
import {
  rememberTurn, decide, entryAddressesBot, textHasTopic, normalizeMode, learnSelf
} from './lib/trigger-gate.js';
import { findMemeHits, injectMemeInstructions } from './lib/memes.js';

let cfg = () => ({});
let log = () => {};
let net = null; // api.fetch

/** 卡牌/角色名清单：只在"聊到咒术回战时"模式里用，懒加载一次。
 *  放在入口读盘是有意的 —— 热重载只重载入口，lib/ 会被 ESM 缓存。 */
let topicNamesCache = null;
function topicNames() {
  if (topicNamesCache) return topicNamesCache;
  try {
    const file = path.join(path.dirname(fileURLToPath(import.meta.url)), 'kb', 'cards.json');
    const parsed = JSON.parse(fs.readFileSync(file, 'utf8'));
    const list = Array.isArray(parsed) ? parsed : (Array.isArray(parsed?.items) ? parsed.items : []);
    topicNamesCache = list.map((x) => String(x?.char ?? '')).filter(Boolean);
  } catch {
    topicNamesCache = [];
  }
  return topicNamesCache;
}

const WEB_HINT = '（联网不可用时，只能用内置资料库回答，并说明"内置资料库可能不是最新"。）';

/** 「向导」提示词：只在闸门放行时注入。 */
const GUIDE_TEXT = [
  '本轮群友是在跟你说话（@ 你、戳你、私聊你，或刚才叫过你），聊到《咒术回战：幻影夜行》时按行家水准作答：',
  '1) 事实优先：角色属性（幻/影/夜/行）、卡名、杯级、技能与被动效果、素材与玩法规则这类容易记错的内容，先用工具查证再答 —— 卡牌用 card_info；机制/术语/玩法先查 kb_search；强度榜用 tier_list；技能原文用 skill_search；日文原文看不懂或群友贴日文时用 glossary 翻译。资料库没有的新卡/新技能再用 dfhy_live 联网补。绝不凭印象编数值、编卡名、编卡池；查不到就直说查不到，并说明资料库快照日期。',
  '2) 术语按官方与社区通行口径：属性（幻/影/夜/行）、术式、体术、咒力、必杀槽、连携必杀、击破、黑闪、会心、领域展开、反转术式、回想等，不要和别的游戏的说法混用。',
  '3) 强度榜是社区整理的杯级榜，不是官方结论：回答时必须说明"来源是社区强度榜、以当前版本为准"，同杯级内从左到右递减，不要把它说成绝对排名。',
  '4) 像懂行的群友说话：先给结论再给理由，1~3 句说完；除非群友明确要详细攻略，不要长篇大论、不要堆 Markdown 表格，也不必每次都念出处。',
  '5) 如果本轮的【必须执行的指令】里给了要"原样发出"的文字（群里出现了"领域展开"这类触发词），就照它发出，一个字都不要改。',
  '6) 没聊到咒术回战/幻影夜行时不要主动往这上面扯；没被叫到时也不要提这些工具。'
].join('\n');

function clampInt(value, min, max, fallback) {
  const n = Math.round(Number(value));
  if (!Number.isFinite(n)) return fallback;
  return Math.min(max, Math.max(min, n));
}

/** 联网可用性（同步）。 */
function networkState() {
  const c = cfg() || {};
  if (c.allowNetwork === false) return { ok: false, reason: '设置里关掉了「允许联网补资料」' };
  if (typeof net !== 'function') return { ok: false, reason: '本技能没拿到联网权限（清单缺少 permissions: ["web_fetch"]）' };
  return { ok: true, reason: '' };
}

/** 本轮的梗命中记录：sessionId -> { hits, at }。 */
const memeFlags = new Map();
const MEME_FLAG_TTL_MS = 10 * 60 * 1000;

function rememberMemeHits(ctx, hits) {
  const sid = String(ctx?.sessionId ?? '').trim();
  if (!sid || !hits.length) return;
  const now = Date.now();
  memeFlags.set(sid, { hits, at: now });
  if (memeFlags.size > 200) {
    for (const [k, v] of memeFlags) if (now - v.at > MEME_FLAG_TTL_MS) memeFlags.delete(k);
  }
}

function memeHitsOf(ctx) {
  const sid = String(ctx?.sessionId ?? '').trim();
  if (!sid) return [];
  const hit = memeFlags.get(sid);
  if (!hit) return [];
  if (Date.now() - hit.at > MEME_FLAG_TTL_MS) {
    memeFlags.delete(sid);
    return [];
  }
  return hit.hits;
}

export function setup(api) {
  cfg = api.config;
  log = api.log || (() => {});
  net = typeof api.fetch === 'function' ? api.fetch : null;

  // ── 工具 1：卡牌资料 ──────────────────────────────────────────────────────
  api.registerTool({
    id: 'card_info',
    name: '查卡牌资料',
    description:
      '查询《咒术回战：幻影夜行》的卡牌资料：角色、卡名（日文原名）、属性（幻/影/夜/行）、社区强度杯级、是否 SP 卡。'
      + '当群友问某张卡是什么属性、谁有几张卡、这张卡强度怎么样、某个角色有哪些卡时使用。'
      + '参数 detail=true 时额外给出该角色名下全部卡牌。名字支持中文名、日文名、常见外号（娜娜明、大爷、纯爱战神等）。',
    category: 'knowledge',
    icon: '📖',
    parameters: {
      type: 'object',
      properties: {
        name: { type: 'string', description: '角色名或卡名，中文/日文/外号均可，如「五条悟」「虎杖悠仁」「娜娜明」。' },
        detail: { type: 'boolean', description: '是否列出该角色名下全部卡牌，默认 false。' }
      },
      required: ['name']
    },
    async execute(_ctx, args) {
      learnSelf(_ctx);
      const raw = String(args?.name ?? '').trim();
      if (!raw) return { content: '缺少 name 参数：请把角色名或卡名填进来。', isError: true };

      const c = cfg() || {};
      try {
        const { exact, candidates } = findCards(raw, 8);
        const hit = exact[0] || candidates[0] || null;

        // 本地没有：联网兜底（可能是新卡）
        if (!hit) {
          const ns = networkState();
          if (!ns.ok) {
            return {
              content: `内置资料库里没有「${raw}」（库内共 ${cardCount()} 张卡，快照 ${kbFetchedAt() || '未知'}），且现在不能联网：${ns.reason}。`
                + `${WEB_HINT}`,
              isError: true
            };
          }
          const live = await findCardsLive(net, raw, 8).catch(() => []);
          if (live.length) {
            const head = `「${raw}」内置资料库未收录，以下是资料站实时数据：`;
            const lines = live.map((x) => `· ${x.char}｜${x.title}${x.attr ? `｜${x.attr}属性` : ''}（卡ID ${x.cardId}）`);
            return { content: `${head}\n${lines.join('\n')}\n（来源：${siteUrl()}；杯级需要联网核对榜单，资料库未收录时不给强度结论。）` };
          }
          return { content: `没找到「${raw}」：内置资料库没有，资料站也没检索到。多半是名字写法不同，换全名再试。`, isError: true };
        }

        const lines = [buildCardLine(hit)];
        if (args?.detail === true) {
          const all = cardsOfCharacter(hit.char);
          if (all.length > 1) {
            lines.push(`【${hit.char}】名下有 ${all.length} 张卡：`);
            for (const card of all) {
              const bits = [card.title, card.attr ? `${card.attr}属性` : '', card.tier ? `强度 ${card.tier}` : '', card.sp ? 'SP' : ''];
              lines.push(`  · ${bits.filter(Boolean).join('｜')}（卡ID ${card.cardId}）`);
            }
          }
        }
        if (!exact.length && candidates.length > 1) {
          lines.push(`（还有相近结果：${candidates.slice(1, 6).map((x) => `${x.char}·${x.title}`).join('、')}，要哪个再单独查。）`);
        }
        if (c.includeSource !== false) lines.push(`来源：${siteUrl()}`);
        lines.push(`（资料库快照：${kbFetchedAt() || '未知'}；要技能/被动原文用 skill_search。）`);
        return { content: lines.join('\n') };
      } catch (error) {
        return { content: `查卡牌资料失败：${error?.message ?? error}`, isError: true };
      }
    }
  });

  // ── 工具 2：离线机制检索 ──────────────────────────────────────────────────
  api.registerTool({
    id: 'kb_search',
    name: '查幻影夜行资料库',
    description:
      '在机器人内置的《咒术回战：幻影夜行》资料库里检索（离线、秒回、不联网）：属性与相性、战斗系统（击破/黑闪/会心/必杀槽/连携必杀）、'
      + '领域展开与反转术式等术语、养成与素材、回想、玩法模式（主线/活动/强敌战/共斗等）。'
      + '当群友问机制怎么运作、某个术语什么意思、资源怎么用、某个玩法怎么玩时优先用它。'
      + '查具体卡牌请用 card_info，查强度榜用 tier_list。',
    category: 'knowledge',
    icon: '📚',
    parameters: {
      type: 'object',
      properties: {
        query: { type: 'string', description: '检索词，不要太长：如「击破」「必杀槽」「属性相性」「回想」「养成」。' },
        limit: { type: 'integer', description: '返回几段资料，1~6，默认 3。' }
      },
      required: ['query']
    },
    async execute(_ctx, args) {
      learnSelf(_ctx);
      const query = String(args?.query ?? '').trim();
      const limit = clampInt(args?.limit, 1, 6, 3);
      try {
        if (!query) {
          const catalog = kbCatalog();
          return { content: `内置资料库当前有这些主题（${catalog.length} 篇）：\n${catalog.map((t) => `· ${t}`).join('\n')}\n请给出更具体的检索词。` };
        }
        const { hits, catalog, total } = searchKb(query, limit, 900);
        if (!hits.length) {
          return {
            content: `内置资料库里没有和「${query}」直接相关的内容（当前共 ${total} 篇）：\n`
              + catalog.map((t) => `· ${t}`).join('\n')
              + '\n可以换个说法，或用 glossary 查术语、用 skill_search 查技能原文。'
              + (networkState().ok ? '' : ` ${WEB_HINT}`)
          };
        }
        log(`资料库命中 ${hits.length} 段（query=${query}）`);
        return { content: hits.map((h, i) => `【资料 ${i + 1}】${h.title}\n${h.snippet}\n（来源：${h.source}）`).join('\n\n') };
      } catch (error) {
        return { content: `资料库检索失败：${error?.message ?? error}`, isError: true };
      }
    }
  });

  // ── 工具 3：强度榜 ────────────────────────────────────────────────────────
  api.registerTool({
    id: 'tier_list',
    name: '查强度榜',
    description:
      '查询《咒术回战：幻影夜行》社区强度杯级榜：总览各杯级、某个杯级里有哪些卡、某张卡在第几杯级第几位。'
      + '当群友问「XX 强度怎么样」「最强的卡有哪些」「超大杯上都有谁」「这个榜怎么看」时使用。'
      + '杯级是社区整理、非官方结论，回答时要说清这一点，并说明同杯级内从左到右递减。',
    category: 'knowledge',
    icon: '🏆',
    parameters: {
      type: 'object',
      properties: {
        tier: { type: 'string', description: '杯级名（如「超大杯上」），留空则给总览。' },
        char: { type: 'string', description: '要定位的角色名，如「五条悟」；填了就查这张卡在哪一档。' },
        limit: { type: 'integer', description: '单个杯级最多列几张，1~60，默认 40。' }
      }
    },
    async execute(_ctx, args) {
      learnSelf(_ctx);
      try {
        if (!tierReady()) return { content: '强度榜数据缺失（kb/tier.json 读不到），这次没法查。', isError: true };

        const char = String(args?.char ?? '').trim();
        if (char) {
          const rows = tierOfCard(char);
          if (!rows.length) {
            return { content: `强度榜上没有「${char}」这张卡（可能未上榜，或名字写法不同；可先用 card_info 确认角色名）。` };
          }
          const lines = rows.map((r) => `${r.char}｜${r.titleJp}${r.attr ? `｜${r.attr}属性` : ''} → ${r.tier}（该杯级第 ${r.rankInTier} 位）${r.sp ? '｜SP' : ''}${r.uncertain ? '｜识别存疑' : ''}`);
          lines.push(`（来源：${tierSource()}；社区强度榜，同杯级内从左到右递减，以当前版本为准。）`);
          return { content: lines.join('\n') };
        }

        const tier = String(args?.tier ?? '').trim();
        if (!tier) return { content: formatTierOverview(6) + `\n（可选的杯级：${tierNames().join(' / ')}；想看某一档全部卡就把 tier 填上。）` };

        const res = cardsInTier(tier, clampInt(args?.limit, 1, 60, 40));
        if (!res.tier) return { content: `没有「${tier}」这个杯级。可选：${tierNames().join(' / ')}` };
        return { content: `${formatTierBlock(res.tier)}\n（来源：${tierSource()}；社区强度榜，仅供参考。）` };
      } catch (error) {
        return { content: `查强度榜失败：${error?.message ?? error}`, isError: true };
      }
    }
  });

  // ── 工具 4：技能/被动原文检索 ─────────────────────────────────────────────
  api.registerTool({
    id: 'skill_search',
    name: '搜技能与被动文本',
    description:
      '在技能/被动/特性的原始文本里检索（内置离线，找不到可联网补）：查某张卡的技能效果、某类效果（击破、黑闪、连携必杀、'
      + '减益、属性耐性）都有谁、某个被动叫什么。返回日文原文并附中文要点。'
      + '当群友贴技能截图问效果、问「谁有击破加成」「这个被动什么意思」时使用。',
    category: 'knowledge',
    icon: '✨',
    parameters: {
      type: 'object',
      properties: {
        query: { type: 'string', description: '检索词，如「击破」「連携必殺」「黒閃」「耐性」。' },
        limit: { type: 'integer', description: '返回几条，1~10，默认 5。' },
        live: { type: 'boolean', description: '本地没命中或想查最新技能时设 true 联网补，默认 false。' }
      },
      required: ['query']
    },
    async execute(_ctx, args) {
      learnSelf(_ctx);
      const query = String(args?.query ?? '').trim();
      if (!query) return { content: '缺少 query 参数：请给出要检索的关键词。', isError: true };
      const limit = clampInt(args?.limit, 1, 10, 5);

      const render = (rows, tag) => rows.map((s, i) => {
        const zh = translateJp(s.text || '');
        return `【${tag} ${i + 1}】#${s.id} ${s.name}\n原文：${(s.text || '（无描述）').slice(0, 400)}\n中文：${zh.slice(0, 400)}`;
      }).join('\n\n');

      try {
        const local = searchSkills(query, limit);
        const wantLive = args?.live === true || !local.length;
        if (local.length && !wantLive) return { content: render(local, '技能') };

        const ns = networkState();
        if (wantLive && !ns.ok) {
          if (local.length) return { content: render(local, '技能') + `\n（联网补新技能不可用：${ns.reason}）` };
          return { content: `本地没有「${query}」的技能记录，且现在不能联网：${ns.reason}。${WEB_HINT}`, isError: true };
        }
        if (!wantLive) return { content: `本地没有「${query}」的技能记录。可以加 live=true 联网查最新技能。` };

        const live = await searchSkillsLive(net, query, limit).catch((error) => ({ error }));
        if (live?.error) {
          if (local.length) return { content: render(local, '技能') + `\n（联网补充失败：${live.error.message ?? live.error}）` };
          return { content: `联网检索技能失败：${live.error.message ?? live.error}。${WEB_HINT}`, isError: true };
        }
        if (!live.length) {
          return { content: local.length ? render(local, '技能') : `资料站也没检索到「${query}」相关的技能。换个关键词（日文原名通常更准，如「黒閃」）。` };
        }
        return { content: render(live, '联网技能') };
      } catch (error) {
        return { content: `技能检索失败：${error?.message ?? error}`, isError: true };
      }
    }
  });

  // ── 工具 5：中日术语对照 ──────────────────────────────────────────────────
  api.registerTool({
    id: 'glossary',
    name: '查术语/中日对照',
    description:
      '查《咒术回战：幻影夜行》的战斗术语中日对照（内置词典，' + String(glossaryCount()) + ' 条）：'
      + '必杀槽、咒力、击破、黑闪、会心、连携必杀、领域展开、反转术式、状态异常等。'
      + '两种用法：text 传一段日文 → 整段翻译成中文；term 传一个词 → 查词条释义与对应日文。'
      + '当群友贴日文技能/被动原文、或问某个术语什么意思时使用。',
    category: 'knowledge',
    icon: '🔤',
    parameters: {
      type: 'object',
      properties: {
        text: { type: 'string', description: '要翻译的日文原文（技能描述、被动文本）。' },
        term: { type: 'string', description: '要查的术语（中文或日文都行）。' },
        limit: { type: 'integer', description: '查词条时最多返回几条，1~30，默认 10。' }
      }
    },
    async execute(_ctx, args) {
      learnSelf(_ctx);
      const text = String(args?.text ?? '').trim();
      const term = String(args?.term ?? '').trim();
      try {
        if (!text && !term) {
          return {
            content: '缺少参数：text（要翻译的日文原文）或 term（要查的术语）至少给一个。\n'
              + `词典共 ${glossaryCount()} 条，例如：${glossaryCatalog(8).join('、')} …`
          };
        }
        const out = [];
        if (text) out.push(`【整段翻译】\n${translateJp(text)}`);
        if (term) {
          const hits = lookupTerm(term, clampInt(args?.limit, 1, 30, 10));
          if (!hits.length) out.push(`词典里没有「${term}」。可以换个说法，或用 skill_search 查技能原文。`);
          else out.push(`【词条】\n${hits.map((h) => `· ${h.jp} → ${h.cn}`).join('\n')}`);
        }
        return { content: out.join('\n\n') };
      } catch (error) {
        return { content: `术语查询失败：${error?.message ?? error}`, isError: true };
      }
    }
  });

  // ── 工具 6：联网补资料 ────────────────────────────────────────────────────
  api.registerTool({
    id: 'dfhy_live',
    name: '联网查资料站',
    description:
      '联网访问豆腐幻夜 WIKI（' + siteUrl() + '）的原始数据表，检索内置资料库没有的新卡与新技能。'
      + '当 card_info / skill_search 查不到、或群友问刚实装的卡时使用。mode=card 查卡，mode=skill 查技能。',
    category: 'web',
    icon: '🌐',
    parameters: {
      type: 'object',
      properties: {
        query: { type: 'string', description: '检索关键词（角色名、卡名、技能名，日文原名更准）。' },
        mode: { type: 'string', enum: ['card', 'skill'], description: '查卡（card）还是查技能（skill），默认 card。' },
        limit: { type: 'integer', description: '返回几条，1~15，默认 8。' }
      },
      required: ['query']
    },
    async execute(_ctx, args) {
      learnSelf(_ctx);
      const query = String(args?.query ?? '').trim();
      if (!query) return { content: '缺少 query 参数：请给出要查的关键词。', isError: true };
      const ns = networkState();
      if (!ns.ok) return { content: `联网查资料站不可用：${ns.reason}。${WEB_HINT}`, isError: true };

      const mode = String(args?.mode ?? 'card') === 'skill' ? 'skill' : 'card';
      const limit = clampInt(args?.limit, 1, 15, 8);
      try {
        if (mode === 'skill') {
          const rows = await searchSkillsLive(net, query, limit);
          if (!rows.length) return { content: `资料站没检索到「${query}」相关的技能。换个关键词（日文原名更准）。` };
          return {
            content: `资料站技能检索「${query}」（${rows.length} 条）：\n`
              + rows.map((s, i) => `${i + 1}. #${s.id} ${s.name}\n   ${(s.text || '').slice(0, 240)}`).join('\n')
              + `\n（来源：${siteUrl()}；要整段中文用 glossary 翻译。）`
          };
        }
        const rows = await findCardsLive(net, query, limit);
        if (!rows.length) return { content: `资料站没检索到「${query}」相关的卡。换个关键词再试。` };
        return {
          content: `资料站卡牌检索「${query}」（${rows.length} 条）：\n`
            + rows.map((x, i) => `${i + 1}. ${x.char}｜${x.title}${x.attr ? `｜${x.attr}属性` : ''}（卡ID ${x.cardId}）`).join('\n')
            + `\n（来源：${siteUrl()}）`
        };
      } catch (error) {
        return { content: `联网查资料站失败：${error?.message ?? error}。${WEB_HINT}`, isError: true };
      }
    }
  });
}

/** 自检（同步）：没有硬依赖，资料库缺失也能靠联网工作。 */
export function available() {
  return true;
}

// ── 触发闸门 ────────────────────────────────────────────────────────────────
export const hooks = {
  'before-context': (ctx) => {
    try {
      const entries = Array.isArray(ctx?.triggerEntries) ? ctx.triggerEntries : [];
      learnSelf(ctx);
      const addressed = entries.some((e) => entryAddressesBot(e));
      const text = entries
        .map((e) => `${e?.text ?? ''} ${Array.isArray(e?.atNames) ? e.atNames.join(' ') : ''}`)
        .join('\n');
      const topic = textHasTopic(text, topicNames());
      rememberTurn(ctx, { addressed, topic });
      if (addressed || topic) {
        log(`闸门：${ctx?.chatKey ?? '?'} 本轮 ${addressed ? '被叫到' : ''}${addressed && topic ? ' + ' : ''}${topic ? '聊到咒术回战' : ''}`);
      }
      const hits = findMemeHits(text);
      if (hits.length) {
        rememberMemeHits(ctx, hits);
        log(`梗命中：${hits.map((h) => `${h.key}(${h.label})`).join('、')}${addressed ? '' : '（本轮没被叫到，不注入）'}`);
      }
    } catch {
      // 钩子失败不影响主流程
    }
  },

  'before-llm-messages': (ctx) => {
    try {
      const messages = ctx?.messages;
      if (!Array.isArray(messages) || !messages.length) return;
      const c = cfg() || {};
      if (c.memeEnabled === false) return;
      const hits = memeHitsOf(ctx);
      if (!hits.length) return;
      const verdict = decide(ctx, { mode: normalizeMode(c.triggerMode), graceMinutes: c.graceMinutes });
      if (!verdict.allow) return;
      const r = injectMemeInstructions(messages, hits, c);
      if (r.injected) log(`梗指令已注入：${r.keys.join('+')}（${verdict.why}）`);
      else log(`梗命中但没有内容可发（去设置里填「${hits.map((h) => h.label).join('、')}」的原文）`);
    } catch {
      // 注入失败不影响本轮对话
    }
  }
};

/** 动态提示词：只有闸门放行时才注入。 */
export function promptSections(ctx) {
  try {
    const c = cfg() || {};
    const verdict = decide(ctx || {}, { mode: normalizeMode(c.triggerMode), graceMinutes: c.graceMinutes });
    if (!verdict.allow) return [];
    return [{
      id: 'jujutsu-phantom-parade-guide',
      title: '幻影夜行向导',
      priority: 45,
      content: GUIDE_TEXT
    }];
  } catch {
    return [];
  }
}

export const providers = {
  'tool.guard': ({ toolId, context }) => {
    if (!String(toolId ?? '').startsWith('jujutsu-phantom-parade__')) return null; // 不归我管
    try {
      const c = cfg() || {};
      const verdict = decide(context || {}, { mode: normalizeMode(c.triggerMode), graceMinutes: c.graceMinutes });
      if (verdict.allow) return null;
      return { ok: false, reason: `幻影夜行向导：${verdict.why}` };
    } catch {
      return null;
    }
  }
};
