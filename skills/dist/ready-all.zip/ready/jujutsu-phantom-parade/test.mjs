// 实机自检：模拟宿主 api，跑通 6 个工具的所有分支。
// 用法：node test.mjs
import { setup, available, hooks, promptSections, providers } from './index.js';

const tools = new Map();
const logs = [];
const cfg = {
  triggerMode: '被@或戳一戳时',
  graceMinutes: 3,
  allowNetwork: false, // 先测离线路径
  searchLimit: 5,
  memeEnabled: true,
  memeDomainText: '领域展开——「伏魔御廚子」。',
  memeGojoText: '天上天下、唯我独尊。',
  includeSource: true
};

const api = {
  config: () => cfg,
  log: (m) => logs.push(m),
  fetch: globalThis.fetch,
  registerTool: (def) => tools.set(def.id, def)
};

setup(api);

const ctx = { sessionId: 's1', chatKey: 'g1', kind: 'group', selfId: '999', triggerEntries: [{ atMe: true, text: '@bot 五条悟有几张卡' }] };

let pass = 0;
let fail = 0;

async function call(id, args, label) {
  const tool = tools.get(id);
  if (!tool) { console.log(`✗ 工具 ${id} 未注册`); fail++; return; }
  try {
    const res = await tool.execute(ctx, args);
    const text = String(res?.content ?? '');
    const ok = text.length > 0 && !/^\s*$/.test(text);
    const bad = res?.isError === true && !label?.includes('预期失败');
    console.log(`\n${ok && !bad ? '✓' : '✗'} ${id}(${JSON.stringify(args)}) → ${text.length}字符${res?.isError ? ' [isError]' : ''}`);
    console.log(text.split('\n').slice(0, 6).map((l) => `   ${l}`).join('\n'));
    if (ok && !bad) pass++; else fail++;
  } catch (e) {
    console.log(`✗ ${id} 抛异常：${e.message}`);
    fail++;
  }
}

console.log('=== 注册的工具 ===');
console.log([...tools.keys()].join(', '));
console.log('available() =', available());

await call('card_info', { name: '五条悟', detail: true });
await call('card_info', { name: '娜娜明' });
await call('card_info', { name: '不存在的角色xyz' }, '预期失败');
await call('kb_search', { query: '击破', limit: 2 });
await call('kb_search', { query: '' });
await call('tier_list', {});
await call('tier_list', { tier: '超大杯上', limit: 5 });
await call('tier_list', { char: '五条悟' });
await call('skill_search', { query: '黒閃', limit: 2 });
await call('glossary', { term: '連携必殺' });
await call('glossary', { text: '選択した敵に近接攻撃の体術ダメージを与える' });
await call('dfhy_live', { query: '五条悟' }, '预期失败');

console.log('\n=== 闸门 ===');
hooks['before-context'](ctx);
const allowCase = decideCheck(ctx);
console.log('被@场景 allow =', allowCase);

// 换一个没被叫过的群，验证闸门真的否决（同群会被宽限窗口放行，那是预期行为）
const ctx2 = { sessionId: 's2', chatKey: 'g2', kind: 'group', triggerEntries: [{ atMe: false, text: '今天天气不错' }] };
hooks['before-context'](ctx2);
console.log('未被@场景 allow =', decideCheck(ctx2), '（应为 false）');
console.log('promptSections(未被叫到) =', promptSections(ctx2).length, '段（应为 0）');
const guard = providers['tool.guard']({ toolId: 'jujutsu-phantom-parade__card_info', context: ctx2 });
console.log('tool.guard 否决 =', guard);

// 同群宽限窗口：g1 刚被 @ 过，追问应放行
const ctx3 = { sessionId: 's3', chatKey: 'g1', kind: 'group', triggerEntries: [{ atMe: false, text: '那伏黑惠呢' }] };
hooks['before-context'](ctx3);
console.log('同群宽限窗口 allow =', decideCheck(ctx3), '（应为 true）');

// 私聊直接放行
const ctx4 = { sessionId: 's4', chatKey: 'p1', kind: 'private', triggerEntries: [] };
console.log('私聊 allow =', decideCheck(ctx4), '（应为 true）');

// 台词梗注入
const msgs = [{ role: 'user', content: '领域展开！' }];
hooks['before-context']({ sessionId: 's5', chatKey: 'g3', kind: 'group', triggerEntries: [{ atMe: true, text: '领域展开！' }] });
hooks['before-llm-messages']({ sessionId: 's5', chatKey: 'g3', kind: 'group', messages: msgs });
console.log('梗注入 =', msgs[0].content.includes('【必须执行的指令】'), '|', msgs[0].content.slice(-40));

function decideCheck(c) {
  const g = providers['tool.guard']({ toolId: 'jujutsu-phantom-parade__card_info', context: c });
  return g === null;
}

console.log(`\n=== 结果：通过 ${pass} / 失败 ${fail} ===`);
console.log('日志：', logs.slice(0, 6));
