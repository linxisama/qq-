// 重建内置资料库 kb/（cards / tier / glossary / skills）。
//
// 用法：
//   node tools/gen-kb.mjs <原始数据目录> [输出 kb 目录]
//
// 原始数据目录里需要这些文件（从 https://dfhyyx.kicp.fun 存下来）：
//   data_names.json  卡牌名与角色名
//   data_skills.json 技能文本
//   attr.js          属性表（CARD_ATTR / ATTR_NAME）
//   tier.js          强度榜（TIER_DATA）
//   zh_dict.js       中日术语词典（PACK）
//
// 角色中文名映射在下面的 CHAR_CN 里；资料站新增角色时补一行即可。

import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const SKILL_DIR = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const SRC = path.resolve(process.argv[2] || path.join(SKILL_DIR, 'raw'));
const OUT = path.resolve(process.argv[3] || path.join(SKILL_DIR, 'kb'));

if (!fs.existsSync(SRC)) {
  console.error(`原始数据目录不存在：${SRC}\n用法：node tools/gen-kb.mjs <原始数据目录> [输出 kb 目录]`);
  process.exit(1);
}
fs.mkdirSync(path.join(OUT, 'wiki'), { recursive: true });

const read = (f) => fs.readFileSync(path.join(SRC, f), 'utf8').replace(/^\uFEFF/, '');
const readJson = (f) => JSON.parse(read(f));

// 角色日文名 -> 国服/通用中文名
const CHAR_CN = {
  虎杖悠仁: '虎杖悠仁', 五条悟: '五条悟', 伏黒恵: '伏黑惠', 七海建人: '七海建人',
  狗巻棘: '狗卷棘', 禪院真希: '禅院真希', 釘崎野薔薇: '钉崎野蔷薇', パンダ: '胖达',
  東堂葵: '东堂葵', 結木海斗: '结木海斗', 家入硝子: '家入硝子', 竜胆サキ: '龙胆崎',
  夜蛾正道: '夜蛾正道', 禪院真依: '禅院真依', 西宮桃: '西宫桃', 夏油傑: '夏油杰',
  三輪霞: '三轮霞', 乙骨憂太: '乙骨忧太', 吉野順平: '吉野顺平', 冥冥: '冥冥',
  両面宿儺: '两面宿傩', 伏黒甚爾: '伏黑甚尔', 猪野琢真: '猪野琢真', 究極メカ丸: '究极机械丸',
  加茂憲紀: '加茂宪纪', 伊地知潔高: '伊地知洁高', 楽巌寺嘉伸: '乐岩寺嘉伸', 漏瑚: '漏瑚',
  真人: '真人', 陀艮: '陀艮', 日下部篤也: '日下部笃也', 花御: '花御', 漆英司: '漆英司',
  灰原雄: '灰原雄', 裏梅: '里梅', 禪院直毘人: '禅院直毘人', 加茂憲倫: '加茂宪伦',
  ミゲル: '米格尔', 脹相: '胀相', 与幸吉: '与幸吉'
};

/** attr.js 里的对象字面量 key 不带引号，不能直接 JSON.parse。 */
const evalObj = (src, name) => {
  const body = src.match(new RegExp(`${name}\\s*=\\s*(\\{[^}]*\\})`))[1];
  return new Function(`return (${body});`)();
};

const attrSrc = read('attr.js');
const ATTR_NAME = evalObj(attrSrc, 'ATTR_NAME');
const CARD_ATTR = evalObj(attrSrc, 'CARD_ATTR');

const tierSrc = read('tier.js');
const TIER_DATA = JSON.parse(tierSrc.match(/window\.TIER_DATA\s*=\s*(\[[\s\S]*?\]);/)[1]);

// 卡牌名（data_names.json 里混着 CharacterId / EnemyBaseId 记录，只取 CardId 且有 CharacterName 的）
const cardById = new Map();
for (const n of readJson('data_names.json')) {
  if (!n.CardId || !n.CharacterName) continue;
  const id = String(n.CardId);
  cardById.set(id, {
    cardId: id,
    charJp: n.CharacterName,
    char: CHAR_CN[n.CharacterName] || n.CharacterName,
    titleJp: n.Name,
    attr: ATTR_NAME[String(CARD_ATTR[id] || '')] || ''
  });
}

// 强度榜回填：杯级 / SP / 识别存疑
for (const block of TIER_DATA) {
  for (const cell of block.cells || []) {
    const hit = cardById.get(String(cell.card));
    if (!hit) continue;
    hit.tier = block.tier;
    if (cell.sp) hit.sp = true;
    if (cell.uncertain) hit.uncertainTier = true;
  }
}

const cards = [...cardById.values()].sort((a, b) => Number(a.cardId) - Number(b.cardId));
const fetchedAt = new Date().toISOString().slice(0, 10);

fs.writeFileSync(path.join(OUT, 'cards.json'), JSON.stringify({
  source: 'https://dfhyyx.kicp.fun',
  fetchedAt,
  attrName: ATTR_NAME,
  note: 'cardId = 游戏内 CardMaster ID；attr = 属性（幻/影/夜/行）；tier = 社区强度杯级（参考）',
  items: cards
}), 'utf8');

// 强度榜保留原杯级顺序
const tier = TIER_DATA.map((b) => ({
  tier: b.tier,
  color: b.color,
  cards: (b.cells || []).map((c) => {
    const hit = cardById.get(String(c.card));
    return {
      cardId: String(c.card),
      char: hit?.char || CHAR_CN[c.char] || c.char,
      charJp: hit?.charJp || c.char,
      titleJp: c.name,
      attr: hit?.attr || '',
      sp: Boolean(c.sp),
      uncertain: Boolean(c.uncertain)
    };
  })
}));
fs.writeFileSync(path.join(OUT, 'tier.json'), JSON.stringify({
  source: 'https://dfhyyx.kicp.fun',
  note: '杯级为社区强度榜，同一杯级内从左到右强度递减；仅作参考',
  tiers: tier
}), 'utf8');

// 中日术语词典
const dictSrc = read('zh_dict.js');
const packRaw = dictSrc.match(/var PACK\s*=\s*(\{[\s\S]*?\});\n/);
const PACK = packRaw ? JSON.parse(packRaw[1]) : {};
const glossary = Object.entries(PACK)
  .filter(([jp, cn]) => jp && cn && jp !== cn)
  .map(([jp, cn]) => ({ jp, cn }))
  .sort((a, b) => b.jp.length - a.jp.length);
fs.writeFileSync(path.join(OUT, 'glossary.json'), JSON.stringify({
  source: 'https://dfhyyx.kicp.fun',
  note: '战斗术语/技能描述中日对照（由游戏主数据表生成）。按 jp 长度降序，供最长匹配替换。',
  items: glossary
}), 'utf8');

// 技能表（角色侧：SkillId < 200000）
const skills = readJson('data_skills.json')
  .filter((s) => Number(s.SkillId) < 200000)
  .map((s) => ({ id: Number(s.SkillId), name: String(s.Name || ''), text: String(s.FlavorText || '') }))
  .filter((s) => s.name);
fs.writeFileSync(path.join(OUT, 'skills.json'), JSON.stringify({
  source: 'https://dfhyyx.kicp.fun',
  note: '技能/被动/特性文本（日文原文）。配合 glossary.json 可中日对照。',
  items: skills
}), 'utf8');

console.log(`cards=${cards.length} tiers=${tier.length} glossary=${glossary.length} skills=${skills.length}`);
console.log('属性分布 =', cards.reduce((m, c) => ((m[c.attr || '未标注'] = (m[c.attr || '未标注'] || 0) + 1), m), {}));
console.log(`输出目录：${OUT}`);
