// 画图技能入口（ComfyUI Draw v5.0.0）
//
// 职责（规格 §1/§2）：setup(pluginApi) / available()，注册 4 个工具
//   draw / prompt_tags / find_character_tags / comfyui_models
// 并把 draw 的**主链路**串起来：串行队列 → 同会话冷却 → 中文翻译 → 探活/拉起 → 参考图 →
//   外观提取 → 词库增强 → 参数 → 构建工作流 → 提交/轮询/取图 → 落档+发送 → 回执 → 清理。
//
// 本文件只做"编排"：所有能力都按规格 §4 的冻结接口从 lib/ 调用，绝不在这里重写它们的逻辑。
// 几个刻意的设计，逐条对应 §6 的防错条目：
//   · 队列与冷却挂在 globalThis（E9/M12）：热重载会重新执行 setup，若状态放在模块级变量里，
//     重载后队列计数与冷却时间戳就被清空 —— 同一会话连点会绕过冷却，队列长度也会失真。
//   · 任何"降级/回退"文案都由**实际返回值**决定（E4）：降级说明只在对应的 ok=false/字段真的出现时才拼。
//   · 临时文件只清自己前缀 qdraw_*（E11），且**不删刚发出的那张**。
//   · 落盘一律 `.part` → rename（E12）；扩展名按魔数定（E5，由 lib/comfy.js 的 fetchImage 给出）。
//   · 铁律：中文提示词翻译失败**硬报错**，绝不拿中文去出图（实测中文会丢场景）。
//
// 依赖：lib/{log,config,models,params,comfy,llm,tags,library,refs}.js（并行开发，接口见规格 §4）

import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

import * as logLib from './lib/log.js';
import * as config from './lib/config.js';
import * as models from './lib/models.js';
import * as params from './lib/params.js';
import * as comfy from './lib/comfy.js';
import * as llm from './lib/llm.js';
import * as tags from './lib/tags.js';
import * as library from './lib/library.js';
import * as refs from './lib/refs.js';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const SKILL_MODELS_DIR = path.join(HERE, 'models');

/**
 * 本技能 id：**从自己的目录名推导**（宿主按 `skills\<目录名>` 建索引，工具全名也是 `<id>__<toolId>`）。
 * 这样换 id 只要目录改名，本文件一个字都不用改 —— 别再写死字面量。
 */
const SKILL_ID = path.basename(HERE) || 'comfyui-newbie';
/**
 * 旧技能 id（5.1.0 起改名，原因是市场上已有同名条目）。**只用于"兼容读取"**：
 * 旧配置段 `skills['comfyui-image']`、旧数据目录 `<data>\comfyui-image\`（用户的 prompt-library 覆盖文件）。
 * 绝不写回、绝不删除 —— 用户想回退到旧版技能时代码照样能跑。
 */
const LEGACY_SKILL_ID = 'comfyui-image';
// 数据目录里的提示词库文件名（与 lib/library.js 的 LIB_FILE 同名；这里只用它拼候选路径）
const LIB_FILE = 'prompt-library.json';

const DEFAULT_BASE = 'http://127.0.0.1:8188';
// 串行队列上限：出图慢的时候连点会把任务无限堆在内存里，每个都要等前面几分钟。
// 满了**直接回绝**并如实报出前面有几张（含正在画的那张）。
const QUEUE_MAX = 6;
// 只清自己前缀的临时文件（E11）：ComfyUI input 里的参考图副本 + 本技能的落档/草稿文件。
const TEMP_PREFIX = 'qdraw_';
// 参考图副本另用一个更明确的前缀，便于日志里区分"参考图"与"成品图"；仍然以 qdraw_ 开头，
// 这样清理策略只要一套（E11：只认自己的前缀）。
const REF_TEMP_PREFIX = `${TEMP_PREFIX}ref_`;
// 队列/冷却/监听器/上次扫描结果的存放键（E9/M12：扛热重载）
const STATE_KEY = '__QQ_AGENT_COMFYUI_IMAGE_STATE__';
// refs.js 通过 globalThis 上这个键回问"会话存档 / 找图能力 / 角色参考"这些只有入口才有的东西
// （见 lib/refs.js 文件头：它不认识宿主存档，也不和 index.js 互相 import）。
const REFS_OWNER_KEY = '__comfyuiImageRefs';
// 软依赖：关键词找参考图靠「智能配图」技能提供的 image.search 能力。
// 为什么是软依赖：没装它时本技能要照常能画（降级成纯文生图），不该整个技能不可用。
const IMAGE_SEARCH_CAP = 'image.search';

const STATE_DEFAULTS = () => ({
  lastRunAt: new Map(),      // 会话 key → 上次"确实开始出图"的时间戳（冷却）
  queueTail: Promise.resolve(),
  queuePending: 0,           // 排队中（含正在跑的那个）
  // 启动扫描的判据：**上次同步之后的 skill.json 状态**（指纹 + 哪些键的下拉是空的），不是"每进程一次"——
  // 安装脚本会先写代码（触发热重载）再覆盖 skill.json，靠"扫过了"的布尔守卫会让重装后的空下拉永远填不上。
  // 见 bootScanDecision() 的注释。
  lastScanState: null,
  bootCount: null,           // 本进程尝试过几次启动扫描（null = 还没试过；用来区分"刚启动"与"热重载"）
  // 热重载后"磁盘上最新的 models 命名空间"（见 refreshModelsNs）：静态 import 那份可能是缓存里的旧实例
  modelsNs: null,
  modelsNsTried: false,
  // 旧 id 设置继承：覆盖映射按 config.json 指纹缓存（见 legacyOverrideMap），以及"回执只提示一次"的开关
  legacyOverride: null,
  legacyNoted: false,
  lastScan: null,            // 上一次扫描结果：rescan 的 added/removed 靠它做差（不再多扫一遍）
  watcher: null,             // 模型目录监听器（重载时要先停掉旧的）
  schemaSyncing: false,      // 同一时刻只允许一次"扫描→可能写盘"
  refCache: new Map(),       // 角色参考图缓存：键含全部影响结果的维度（E7）
  comfyRoots: null           // 自动探测到的 ComfyUI 安装根缓存（{at, roots}；盘符探测很慢，探一次就够）
});

/** 取（或建）挂在 globalThis 上的运行期状态。 */
function getState() {
  const g = globalThis;
  let s = g[STATE_KEY];
  if (!s || typeof s !== 'object') {
    s = STATE_DEFAULTS();
    g[STATE_KEY] = s;
  }
  // 热重载可能是"新代码 + 旧状态"：逐项补齐缺字段，不要把已有状态冲掉（那正是 M12 要防的）
  const d = STATE_DEFAULTS();
  for (const k of Object.keys(d)) if (s[k] === undefined) s[k] = d[k];
  if (!(s.lastRunAt instanceof Map)) s.lastRunAt = new Map();
  if (!(s.refCache instanceof Map)) s.refCache = new Map();
  return s;
}

// ── 运行期上下文（setup 填；工具与助手从这里读）──────────────────
const runtime = {
  dataDir: '',
  hostCfg: null,
  logger: null,
  log: null,       // 可调用的日志口（同时带 .info/.warn/.error，见 bridgeLogger）
  cfg: () => ({}),
  capability: () => undefined,
  hasCapability: () => false
};

/**
 * 把 makeLogger 的**对象**包成"可调用 + 带方法"的口。
 *
 * 为什么需要：§4 里 log.js 给的是 `{debug,info,warn,error,file,flush}` 对象，
 * 而别的模块（comfy/refs/models 的 watchModelDirs...）签名里的 `log` 是**函数**（`log(msg)`），
 * 两种用法必须同时成立 —— 否则要么丢日志、要么在 lib 里抛 "log is not a function"。
 */
function bridgeLogger(logger) {
  const fn = (...a) => { try { logger.info(...a); } catch { /* 日志失败不影响主流程 */ } };
  for (const level of ['debug', 'info', 'warn', 'error']) {
    fn[level] = (...a) => { try { logger[level](...a); } catch { /* 同上 */ } };
  }
  fn.file = () => { try { return logger.file(); } catch { return ''; } };
  // 刻意**不**转发 flush()：log.js 的 flush 会 end() 掉写入流，收尾时随手调一次
  // 会让之后所有日志静默丢失。只有技能卸载才该 flush，这里不做。
  fn.raw = logger;
  return fn;
}

// ── 小工具 ─────────────────────────────────────────────────────

/** 带超时保护。找图能力是**别人的**实现，慢起来可能几十秒，不能让它把一次出图拖死。 */
function withTimeout(promise, ms, label) {
  if (!(ms > 0)) return promise;
  let timer = null;
  return Promise.race([
    Promise.resolve(promise).finally(() => { if (timer) clearTimeout(timer); }),
    new Promise((_, rej) => {
      timer = setTimeout(() => rej(new Error(`${label}（超过 ${Math.round(ms / 1000)} 秒）`)), ms);
      timer.unref?.();
    })
  ]);
}

/** 文件名里的时间戳 + 随机串（同一秒内多次出图不会互相覆盖）。 */
function stampName() {
  const stamp = new Date().toISOString().replace(/[-:T]/g, '').slice(0, 14);
  return `${stamp}_${Math.random().toString(36).slice(2, 8)}`;
}

/** 只接受白名单扩展名（ComfyUI 用 mimetypes 过滤 input 目录，名字带错扩展名会被拒收）。 */
function safeExt(v, fallback = '') {
  const s = String(v ?? '').trim().toLowerCase();
  if (!s) return fallback;
  const withDot = s.startsWith('.') ? s : `.${s}`;
  return ['.png', '.jpg', '.jpeg', '.webp', '.gif', '.bmp'].includes(withDot) ? withDot : fallback;
}

/** 按魔数定扩展名（E5：不许硬编码 .png —— /view 也可能回 jpg/webp）。 */
function magicExt(buf) {
  const b = Buffer.isBuffer(buf) ? buf : Buffer.from(buf || []);
  if (b.length < 12) return '';
  if (b[0] === 0x89 && b[1] === 0x50 && b[2] === 0x4e && b[3] === 0x47) return '.png';
  if (b[0] === 0xff && b[1] === 0xd8 && b[2] === 0xff) return '.jpg';
  if (b.toString('latin1', 0, 4) === 'RIFF' && b.toString('latin1', 8, 12) === 'WEBP') return '.webp';
  const gif = b.toString('latin1', 0, 6);
  if (gif === 'GIF87a' || gif === 'GIF89a') return '.gif';
  if (b[0] === 0x42 && b[1] === 0x4d) return '.bmp';
  return '';
}

/** 原子写：先写 `.part` 再 rename（E12）。失败时把半成品删掉，不留垃圾。 */
function writeFileAtomic(dest, buf) {
  const part = `${dest}.part`;
  try {
    fs.writeFileSync(part, buf);
    fs.renameSync(part, dest);
    return { ok: true, reason: '' };
  } catch (error) {
    safeUnlink(part);
    return { ok: false, reason: logLib.describeFsError(error) };
  }
}

function safeUnlink(p) {
  if (!p) return;
  try { fs.unlinkSync(p); } catch { /* 删不掉就算了：清理失败不该改变主流程的结论 */ }
}

/** 异常 → 脱敏后的一句话（对外文案一律过 redact，E1）。 */
function errText(e) {
  if (e === null || e === undefined) return '未知错误';
  return logLib.redact(String(e?.message ?? e)).slice(0, 240);
}

/** 统一把要回给宿主 LLM 的文案脱敏（E1）。 */
const R = (s) => logLib.redact(String(s ?? ''));

// ══════════════════════════════════════════════════════════════
//  技能 id 变更（comfyui-image → comfyui-newbie）的**只读**兼容
// ══════════════════════════════════════════════════════════════

/** 只认"普通对象"（数组/日期/字符串都不算），用于安全地遍历宿主配置段。 */
function plainObject(v) {
  return (v && typeof v === 'object' && !Array.isArray(v)) ? v : null;
}

/** 空值判定：`''` / null / undefined 都算"没填"（与 E3 一致：**0 与 false 是有效值**，不算空）。 */
function isBlank(v) {
  return v === undefined || v === null || v === '';
}

/** 随包默认值（自己 skill.json 的 settings）—— 用来识别"新段里的值其实是安装脚本写的默认值"。 */
function packageDefaultSettings() {
  try {
    const j = JSON.parse(fs.readFileSync(SELF_SKILL_JSON, 'utf8').replace(/^\uFEFF/, ''));
    return plainObject(j?.settings) || {};
  } catch { return {}; }
}

/** 本技能自己的数据目录：**旧 id 那个已经存在就继续用它**（老用户的 prompt-library 覆盖文件在里面），否则用新 id。 */
function skillDataDirOf(dataDir) {
  const base = config.truthyStr(dataDir);
  const mine = path.join(base || '.', SKILL_ID);
  const legacy = path.join(base || '.', LEGACY_SKILL_ID);
  if (SKILL_ID !== LEGACY_SKILL_ID && existsDir(legacy) && !existsDir(mine)) return { dir: legacy, legacy: true };
  return { dir: mine, legacy: false };
}

/** 提示词库的候选路径：**新 id 的 data 目录优先，旧 id 的继续留着**，再接库自己的名单（data 根 + 随包那份）。 */
function libraryPathsFor(dataDir) {
  const sd = skillDataDirOf(dataDir);
  return uniqStr([
    path.join(sd.dir, LIB_FILE),
    path.join(dataDir || '.', SKILL_ID, LIB_FILE),
    path.join(dataDir || '.', LEGACY_SKILL_ID, LIB_FILE),   // 兼容旧 id 的 data 目录（必须保留）
    ...library.libraryPaths(dataDir)
  ]);
}

/**
 * 换 id 后把**旧技能段的设置继承过来**（一次性、**只读**）。
 *
 * 规则（`newSec` = 新段 `skills[SKILL_ID]`，`oldSec` = 旧段 `skills['comfyui-image']`）：
 *   · 旧段没有这个键（或值为空）→ 不动；
 *   · 新段**没有**这个键、或值是空串 → **继承旧值**；
 *   · 新段的值**恰好等于随包默认值**（= 安装脚本补进去的默认值，不是用户挑的）→ **继承旧值**（保护老用户）；
 *   · 其余（新段有非默认的显式值）→ **新段优先**，不继承。
 * ⚠️ 绝不写宿主配置（技能没有这个权限，也容易和宿主内存里的那份打架）——继承只发生在**本次进程的内存里**；
 * 面板里保存一次就会落到新段（回执/日志里提示一次）。
 *
 * @returns {{settings:object, inherited:string[], kept:string[], legacyFound:boolean}}
 */
function migrateSettingsFromLegacyId(raw, hostCfg) {
  const out = { ...(plainObject(raw) || {}) };
  const skills = plainObject(hostCfg?.skills) || {};
  const newSec = plainObject(skills[SKILL_ID]) || {};
  const oldSec = plainObject(skills[LEGACY_SKILL_ID]) || {};
  const oldKeys = Object.keys(oldSec).filter((k) => !isBlank(oldSec[k]));
  const legacyFound = oldKeys.length > 0;
  const inherited = [];
  const kept = [];
  if (!legacyFound || SKILL_ID === LEGACY_SKILL_ID) return { settings: out, inherited, kept, legacyFound: false };

  const defaults = packageDefaultSettings();
  for (const k of oldKeys) {
    const hasNew = Object.prototype.hasOwnProperty.call(newSec, k);
    const newVal = newSec[k];
    if (hasNew && !isBlank(newVal)) {
      const sameAsDefault = Object.prototype.hasOwnProperty.call(defaults, k)
        && JSON.stringify(defaults[k]) === JSON.stringify(newVal);
      if (!sameAsDefault) { kept.push(k); continue; }        // 新段是真·显式值 → 听新段的
      inherited.push(k);                                     // 新段只是安装脚本写的默认值 → 用旧值
      out[k] = oldSec[k];
      continue;
    }
    inherited.push(k);                                       // 新段没有 / 为空 → 继承
    out[k] = oldSec[k];
  }
  return { settings: out, inherited, kept, legacyFound: true };
}

/**
 * 旧→新的**覆盖映射**（只含"该继承的键"），按宿主 config.json 的指纹缓存。
 *
 * 为什么按文件指纹缓存、而不是按"每次调用"：
 *   · 宿主每次调 `api.config()` 都可能返回**新对象**，若跟着它重算，继承日志会在一次出图里刷好几遍；
 *   · config.json 才是"新段到底存了什么"的事实来源，它没变就不必重算。
 * 每调用一次只多一个 `statSync`，可以忽略。
 */
function legacyOverrideMap() {
  const st = getState();
  const stamp = fileStamp(path.join(runtime.dataDir || '.', 'config.json'));
  if (st.legacyOverride && st.legacyOverride.stamp === stamp) return st.legacyOverride;
  const host = config.readHostConfig(runtime.dataDir);
  const hostCfg = host?.ok ? host.config : null;
  // 传空 raw：返回的 settings 就只剩"从旧段继承来的键"= 覆盖映射
  const m = migrateSettingsFromLegacyId({}, hostCfg);
  st.legacyOverride = { stamp, map: m.settings, info: m };
  if (m.legacyFound && m.inherited.length) {
    runtime.logger?.info(`已从旧技能 id（${LEGACY_SKILL_ID}）继承 ${m.inherited.length} 项设置：${m.inherited.join('、')}`
      + `${m.kept.length ? `；新段里已有的显式值照旧生效（${m.kept.length} 项）` : ''}`
      + '。换 id 后新段是空的，所以这些值来自旧段；技能**不会**去写宿主配置，'
      + '若要在面板里看到它们，进去保存一次即可（可选，不保存也能一直用）。');
  } else if (m.legacyFound) {
    runtime.logger?.info(`旧技能 id（${LEGACY_SKILL_ID}）的设置段还在，但新段已有显式值，本次没继承任何键（旧段保留未动）`);
  }
  return st.legacyOverride;
}

/** 宿主给的这份设置里，这个键算不算"用户显式写的值"（非空、且不等于随包默认值）。 */
function looksExplicitInRaw(raw, key, defaults) {
  if (!Object.prototype.hasOwnProperty.call(raw || {}, key)) return false;
  const v = raw[key];
  if (isBlank(v)) return false;
  if (Object.prototype.hasOwnProperty.call(defaults, key) && JSON.stringify(defaults[key]) === JSON.stringify(v)) return false;
  return true;
}

/**
 * 包一层"生效设置"：宿主给的设置 + 旧 id 继承（**内存里合并，不落盘**）。
 * 所有 `runtime.cfg()` 的调用方（出图 / 清单 / 监听）看到的都是同一份。
 */
function effectiveSettings(raw) {
  const base = plainObject(raw) || {};
  const { map } = legacyOverrideMap();
  const keys = Object.keys(map);
  if (!keys.length) return base;
  const defaults = packageDefaultSettings();
  const out = { ...base };
  for (const k of keys) {
    if (looksExplicitInRaw(base, k, defaults)) continue;   // 宿主这份里已是显式值 → 听它的（双保险）
    out[k] = map[k];
  }
  return out;
}

/** 一次性提示（回执用）：换 id 继承过设置时，第一次出图在说明里告诉用户一句。 */
function legacyMigrationNote() {
  const st = getState();
  const m = legacyOverrideMap().info;
  if (!m || !m.legacyFound || !m.inherited.length || st.legacyNoted) return '';
  st.legacyNoted = true;
  return `已从旧技能 id（${LEGACY_SKILL_ID}）继承设置（${m.inherited.length} 项：${m.inherited.join('、')}）——`
    + '换 id 后新段是空的，所以这次用的是旧段的值；**旧段没有被改动**。'
    + '若要在面板里看到它们，进去保存一次即可（可选）。';
}

function uniqStr(list) {
  const out = [];
  for (const v of Array.isArray(list) ? list : []) {
    const s = typeof v === 'string' ? v.trim() : '';
    if (s && !out.includes(s)) out.push(s);
  }
  return out;
}

/** 从 scanModels 的结果里取某一类（容忍单复数两种键名写法）。 */
function bucketOf(scan, plural, singular) {
  const s = scan && typeof scan === 'object' ? scan : {};
  const v = Array.isArray(s[plural]) ? s[plural] : (Array.isArray(s[singular]) ? s[singular] : []);
  return uniqStr(v);
}

/**
 * 取 classifyModel 给的 label 里那截括号说明：
 * `anima-turbo-v1.1.safetensors（Anima 蒸馏版·12步/CFG1）` → `Anima 蒸馏版·12步/CFG1`。
 * 为什么需要：label 自带文件名，直接贴在文件名后面就成了"文件名（文件名（说明））"。
 */
function labelNote(label) {
  const m = /[（(]([^（()）]*)[）)]\s*$/.exec(String(label || ''));
  return m ? m[1].trim() : '';
}

/** 分类结果用不上时别抛：classifyModel 认不出种类也会给 family='unknown'。 */
function classify(name, kind) {
  try {
    const r = models.classifyModel(name, kind);
    if (r && typeof r === 'object') {
      return {
        family: String(r.family || 'unknown'),
        variant: String(r.variant || ''),
        label: String(r.label || name || '')
      };
    }
  } catch (error) {
    runtime.logger?.debug(`classifyModel 失败（按未识别处理）：${errText(error)}`);
  }
  return { family: 'unknown', variant: '', label: String(name || '') };
}

// ══════════════════════════════════════════════════════════════
//  1. 模型目录 + 扫描
// ══════════════════════════════════════════════════════════════

// 设置里没填「ComfyUI 安装目录」时按这些位置找（含各盘符）。
// 为什么必须自己探一遍：models.js 的 /object_info 那条路要求 ComfyUI **在线**；
// 而"把模型文件放进 models\ 就能被认出来、增删也能发现"是本技能的头号需求，
// 必须在 ComfyUI 没开的时候也成立 —— 所以要把真实的文件系统目录交给它。
const COMFY_ROOT_NAMES = [
  'AI\\ComfyUI', 'ComfyUI', 'ComfyUI_windows_portable', 'AI\\ComfyUI_windows_portable'
];

/** 候选安装根：A:~\Z:\ 里存在的盘符 × 常见目录名（不存在的盘不探，免得被网络盘拖住）。 */
function comfyRootCandidates() {
  const out = [];
  for (let i = 0; i < 26; i += 1) {
    const letter = String.fromCharCode(65 + i);
    let ok = false;
    try { ok = fs.existsSync(`${letter}:\\`); } catch { ok = false; }
    if (!ok) continue;
    for (const name of COMFY_ROOT_NAMES) out.push(`${letter}:\\${name}`);
  }
  return out;
}

const existsDir = (p) => { try { return fs.statSync(p).isDirectory(); } catch { return false; } };

/**
 * 找出可能的 ComfyUI 安装根（**真实目录**，不是猜的名字）。
 *
 * 规则（顺序很重要）：
 *   ① 设置里填了、而且**真正像 ComfyUI 根**（那层有 main.py）→ **只用它，不再去别的盘探测**。
 *      为什么：混进另一个安装的目录时，`pick()` 会选到"只有那个安装里才有"的文件名，
 *      提交给当前这台 ComfyUI 必然对不上（轻则报错，重则用了同名但不同版本的模型）。
 *   ② 没填、或填的那个不像 ComfyUI 根（比如误填成 models 那层）→ 按候选盘位自动探测（含各盘符 + 便携版）。
 * 自动探测的结果缓存在 globalThis（10 分钟）：`modelDirsOf` 每次出图都要用，
 * 而逐个盘符 existsSync 在"有网络盘/光驱"的机器上可能很慢 —— 探一次就够（连"一个都没有"也缓存）。
 */
function comfyRootsFor(c) {
  const st = getState();
  const configured = config.truthyStr(c?.comfyuiDir);
  const roots = [];
  let configuredLooksLikeRoot = false;

  if (configured) {
    try {
      const layout = comfy.comfyLayout(configured);
      // appDir = 真正有 main.py 的那层（两种布局都认）；没有它说明这个路径不是 ComfyUI 根
      const appDir = config.truthyStr(layout?.appDir);
      const hit = appDir || config.truthyStr(layout?.root);
      if (hit && existsDir(hit)) roots.push(hit);
      configuredLooksLikeRoot = Boolean(appDir);
    } catch { /* 布局探测失败就当没这个候选 */ }
  }
  if (configuredLooksLikeRoot) return uniqStr(roots);

  const cached = st.comfyRoots;
  const fresh = cached && Date.now() - cached.at < 10 * 60 * 1000 ? cached.roots : null;
  if (fresh) {
    for (const r of fresh) roots.push(r);
  } else {
    const found = [];
    for (const cand of comfyRootCandidates()) {
      if (!existsDir(cand)) continue;
      try {
        const layout = comfy.comfyLayout(cand);
        const hit = config.truthyStr(layout?.appDir);
        if (hit) found.push(hit);
      } catch { /* 单个候选探测失败不影响别的候选 */ }
    }
    st.comfyRoots = { at: Date.now(), roots: found };
    for (const r of found) roots.push(r);
    if (found.length) {
      runtime.logger?.info(`自动探测到 ${found.length} 个 ComfyUI 安装根（设置里的「ComfyUI 安装目录」没填/不像根目录时用它们扫模型）：`
        + found.map((p) => dirTail(p)).join(' ｜ '));
    }
  }
  return uniqStr(roots);
}

/** 某个安装根下的模型根目录候选（标准布局 → 嵌套/便携布局 → 技能目录），**保留顺序、不过滤存在性**。 */
function modelsRootsFor(c) {
  const roots = comfyRootsFor(c);
  const candidates = [];
  for (const root of roots) candidates.push(path.join(root, 'models'));              // 标准布局：<根>\models
  for (const root of roots) candidates.push(path.join(root, 'ComfyUI', 'models'));   // 根下再套一层 ComfyUI
  // 技能目录下的 models\：models.js 的 syncSchema 一直会扫它，这里也带上，保持一致（放最后）
  candidates.push(SKILL_MODELS_DIR);
  // 刻意**不过滤"当前不存在"的候选**：候选[0] 是 primary（用来拼"目前还不存在的目录"的路径），
  // 若在这里就把不存在的路径滤掉，设置里刚填好、models\ 还没建出来时 primary 会掉到技能目录去，
  // pick() 就会指向一个跟当前安装无关的地方。存在的优先由 pick() 现算。
  return uniqStr(candidates);
}

/**
 * 交给 models.js 的**真实模型目录集**（具名映射，形状与 tests/_harness 一致：
 * `{ commonRoot, diffusion_models, text_encoders, clip, vae, loras, checkpoints, upscale_models }`）。
 *
 * 为什么不再传"安装根"让它自己展开：`models.js` 的 expand 只在 ComfyUI **在线**（/object_info）时
 * 才拿得到模型名；传真实子目录之后，它离线也能靠文件系统列全 —— 这正是 §2 第 3 条要的
 * "放进文件夹就能认出来、增删都能发现"。`normalizeDirList` 对具名映射取 `Object.values`，
 * 缺哪个目录就传一个不存在的路径（它遇到不存在的目录直接跳过，不会报错）。
 */
function modelDirsOf(c) {
  const modelsRoots = modelsRootsFor(c);
  // primary（commonRoot）也用"里面真有模型"的优先：否则会把 `<根>\models` 这个空壳（只有几个空子目录，
  // 或残留着 ComfyUI 不会加载的旧文件的那层）一起交给 models.js 扫。
  const primary = modelsRoots.find((r) => modelsRootHasModels(r)) || modelsRoots[0] || SKILL_MODELS_DIR;
  /**
   * 每个模态目录怎么选（真机上丢过 LoRA，就是这一步选错）：
   *   `<根>\models` 与 `<根>\ComfyUI\models` 可能**同时存在**，而前者的 `loras\` 是空的 ——
   *   只按"目录存在"挑，就会选中那个空的，于是 loras 扫出来是空的（模型五类却正常）。
   * 所以顺序是：**存在且有东西** → 存在（哪怕空） → 不存在的标准位置（拼一个给"还没建出来"的情况用）。
   */
  const pick = (name) => {
    const cands = modelsRoots.map((r) => path.join(r, name));
    return cands.find((p) => existsDir(p) && hasEntriesDir(p))
      || cands.find((p) => existsDir(p))
      || path.join(primary, name);
  };
  return {
    commonRoot: primary,
    diffusion_models: pick('diffusion_models'),
    // 文本编码器目录名新老版本不同：新的是 text_encoders，老的是 clip —— 两个都传（不存在的会被跳过）
    text_encoders: pick('text_encoders'),
    clip: pick('clip'),
    vae: pick('vae'),
    loras: pick('loras'),
    checkpoints: pick('checkpoints'),
    upscale_models: pick('upscale_models')
  };
}

/** 目录集 → 一行可读的"去哪几个目录"（给日志用，路径本身会被 log.js 脱敏）。 */
function dirsForLog(dirs) {
  const vals = Object.values(dirs || {}).filter((v) => typeof v === 'string' && v);
  return uniqStr(vals);
}

/** 只保留路径尾部 2~3 段：`D:\AI\ComfyUI\models\loras` → `AI/ComfyUI/models/loras`（脱敏后仍可核对）。 */
function dirTail(p) {
  const parts = String(p || '').split(/[\\/]+/).filter(Boolean);
  return parts.slice(-3).join('/') || String(p || '');
}

/**
 * 取**磁盘上最新**的 models 命名空间（默认就是静态 `import` 的那一份）。
 *
 * 为什么需要（真机日志铁证）：宿主热重载只把 `index.js` 换成新代码（它会带自己的 cache-buster），
 * 而 `index.js` 里那句静态 `import './lib/models.js'` 解析出的 URL 没变 → 拿到的还是**第一次加载时
 * 缓存的那个模块实例**。逐文件安装于是出现"新 index.js + 旧 lib/models.js"：
 * 旧库没有 `LORA_SLOTS` 导出，`buildSchemaPatch` 也不产出 LoRA 槽 → 那次同步只写 4 处，
 * 5 个槽停在 `[""]`（而同一份文件在别的进程里 import 明明是新的）。
 *
 * 这里发现静态那份缺了 `LORA_SLOTS`（新导出的标志），就按 mtime 重新 import 一次拿磁盘上的新版；
 * 每个进程只试一次，失败就退回静态那份（下次重载/重启再试）。多出来的模块实例是安全的：
 * models.js 的模块级状态只有几个惰性 memo（`_redact` / `_resolveParams` / `_paramTable`），重复实例只是重复 memo。
 */
async function refreshModelsNs() {
  const st = getState();
  if (st.modelsNs) return st.modelsNs;
  if (typeof models.LORA_SLOTS !== 'undefined') { st.modelsNs = models; return models; }   // 静态那份就是新的 → 不折腾
  if (st.modelsNsTried) return models;                                                      // 每个进程只试一次
  st.modelsNsTried = true;
  try {
    const p = path.join(HERE, 'lib', 'models.js');
    const stamp = fileStamp(p);
    const fresh = await import(`${pathToFileURL(p).href}?v=${encodeURIComponent(stamp)}`);
    if (fresh && typeof fresh.syncSchema === 'function') {
      st.modelsNs = fresh;
      runtime.logger?.info(`lib/models.js 是热重载缓存里的旧实例（缺 LORA_SLOTS 等新导出）—— 已按磁盘上的最新文件`
        + `重新加载（v=${stamp}）：这次的扫描 / 同步 / 下拉补丁都用新那份，LoRA 槽能正常产出`);
      return fresh;
    }
    runtime.logger?.warn('重新加载 lib/models.js 拿到的不是可用模块，继续用当前实例');
  } catch (error) {
    runtime.logger?.warn(`重新加载 lib/models.js 失败（继续用当前实例，LoRA 槽可能刷不出来）：${errText(error)}`);
  }
  st.modelsNs = models;
  return models;
}

/** 该目录是不是"存在且里面确实有东西"（用来在多个候选里挑真正有模型的那个，见 modelDirsOf）。 */
function hasEntriesDir(p) {
  try { return fs.readdirSync(p).length > 0; } catch { return false; }
}

/** models.js 认得的模态子目录名（挑"哪个 models 根才是真的"时按它们判断，别被一堆空子目录骗了）。 */
const MODALITY_DIRS = ['diffusion_models', 'text_encoders', 'clip', 'vae', 'loras', 'checkpoints', 'upscale_models', 'unet', 'embeddings'];

/**
 * 这个 models 根里**确实有模型**吗（至少一个模态子目录里真有文件）。
 * 不能只看"`models\` 里有没有条目"：真机上 `<根>\models` 底下可能只有几个**空**的模态子目录，
 * 那样会被误判成"有东西"，于是把空壳当 primary 交出去扫（LoRA 就是这么丢的）。
 */
function modelsRootHasModels(root) {
  return MODALITY_DIRS.some((d) => hasEntriesDir(path.join(root, d)));
}

/** 把这次扫描实际用的目录逐个记进日志（尾部片段，脱敏后仍可核对）——排障"LoRA 怎么没扫到"就靠它。 */
function logModelDirs(dirs, where) {
  const keys = Object.keys(dirs || {}).filter((k) => k !== 'commonRoot');
  const parts = keys.map((k) => `${k}=${dirTail(dirs[k])}`);
  runtime.logger?.debug(`${where}：扫描目录（尾部片段）${parts.join(' ｜ ')}`);
}

/** 扫一次模型（只读：走 /object_info + 真实目录，绝不写 skill.json）。 */
async function scanNow(c) {
  const M = await refreshModelsNs();
  const base = baseUrlOf(c);
  const dirs = modelDirsOf(c);
  try {
    logModelDirs(dirs, '模型扫描');
    const scan = await M.scanModels(base, dirs);
    if (scan && typeof scan === 'object') {
      // 这些通常只是"ComfyUI 没在线，/object_info 用不了"—— 与"扫不到模型"是两回事，
      // 只记 debug（清单本身来自文件系统，照样是全的）。
      for (const msg of Array.isArray(scan.errors) ? scan.errors : []) runtime.logger?.debug(`在线信息不可用：${R(msg)}`);
      runtime.logger?.debug(`模型清单来自：${dirTail(path.dirname(dirs.commonRoot))}/models（含 ${dirsForLog(dirs).length} 个目录）`);
      return scan;
    }
  } catch (error) {
    runtime.logger?.warn(`模型扫描失败：${errText(error)}`);
  }
  return { unets: [], clips: [], vaes: [], loras: [], checkpoints: [], upscalers: [], errors: ['模型扫描失败（详见日志）'] };
}

function baseUrlOf(c) {
  const fromSettings = config.truthyStr(c?.baseUrl);
  return (fromSettings || DEFAULT_BASE).replace(/\/+$/, '');
}

// ══════════════════════════════════════════════════════════════
//  2. 路线与具体模型（§2：档位与具体模型都从下拉选）
// ══════════════════════════════════════════════════════════════

// 注：偏好顺序**不在本文件里内嵌**（见下面 preferFor()：唯一真源是 models.PREFER）。
// 单文件大模型"自动挑一个"也走同一套偏好；**不做**"列表第一个"的兜底（E2）——
// 偏好没命中时，只有"本机就这一个候选"才算没有歧义。

/**
 * 显式路线设置。
 *
 * ① **`modelRoute`（skill.json 的「模型路线」）是路线的唯一开关**：`auto` / `anima` / `sdxl`。
 *    `auto`（默认）= 下面的确定性规则；`anima` / `sdxl` = 用户强制。
 * ② `model` / `imageModel` / `selectedModel`（调用方直接给文件名）→ **只用来在已定好的路线里挑文件**，
 *    不再反过来改路线（见 planGeneration：路线的判定只看 modelRoute + 本机三件套齐不齐）。
 *
 * ⚠️ 历史上这里还认 `tier` / `profile` / `drawRoute` 三个老键，且它们能**强制**路线 ——
 * 真机上就踩到了：宿主会保留上一次安装存下来的设置，而**老包的 skill.json 里有 `profile: "illustrious"`**，
 * 于是面板/文档都说 auto，实际却走了光辉单文件（28 步/CFG 5），与 `modelRoute` 的描述不符。
 * 现在这三个键**不再影响路线**（只在日志里提示一句，便于排查），路线只认 modelRoute。
 *
 * 返回形状固定为 `{ kind:'anima'|'checkpoint'|'', model:string, from:string, forced:boolean, auto:boolean }`。
 */
function explicitRoute(c) {
  const route = config.truthyStr(c?.modelRoute).toLowerCase();
  if (/^(anima|anima[-_]turbo|anima[-_]base)$/.test(route)) {
    return { kind: 'anima', model: '', from: 'modelRoute', forced: true, auto: false };
  }
  if (/^(sdxl|illustrious|checkpoint|光辉|单文件)/.test(route)) {
    return { kind: 'checkpoint', model: '', from: 'modelRoute', forced: true, auto: false };
  }
  // auto / 空 / 认不出的值 → 交给确定性规则（认不出的值只记日志，不当成"强制"）
  const isAuto = !route || route === 'auto';
  if (!isAuto) runtime.logger?.warn(`「模型路线」的值「${R(route)}」不认识（按 auto 处理；可用：auto / anima / sdxl）`);

  // 老键残留只提示、不参与判定（上面注释里那个真机 bug 就是它们造成的）
  for (const key of ['tier', 'profile', 'drawRoute']) {
    const v = config.truthyStr(c?.[key]);
    if (!v || v === 'auto') continue;
    if (/^(illustrious|sdxl|checkpoint|单文件|anima)/i.test(v)) {
      runtime.logger?.debug(`设置里还有老键「${key}=${R(v)}」：它**不再**影响路线（路线只认「模型路线」；想固定就用它）`);
    }
  }
  for (const key of ['model', 'imageModel', 'selectedModel']) {
    const v = config.truthyStr(c?.[key]);
    if (v) return { kind: '', model: v, from: key, forced: false, auto: isAuto };
  }
  return { kind: '', model: '', from: '', forced: false, auto: isAuto };
}

/**
 * 定路线 + 定文件 + 定参数变体。
 *
 * 路线判定（依据 §2「模型、档位都从下拉里选」+ E2「不许静默替换」）：
 *   ① `modelRoute` = anima / sdxl → 用户强制（缺文件时明确报错并提示改回 auto，绝不偷偷改路线）；
 *   ② `auto`：Anima 三件套（底模+编码器+VAE）**在本机都能找到** → 走 Anima（档位由底模文件名的变体决定：
 *      含 turbo = 蒸馏档 12/CFG1，base/aesthetic/认不出 = 画质档 30/CFG4）；
 *   ③ `auto` 且三件套不齐、而 checkpoints 里单文件大模型可用 → 走 SDXL 单文件（28/CFG5）；
 *   ④ 都不成立 → 报错，并**逐条列出缺哪一项、该去哪个下拉/设置项里改**（绝不替用户挑第一个）。
 * ⚠️ 关键：**内容面板里"选中了单文件大模型"不改变 auto 的判定**（那是 per-family 的下拉，不是路线开关）——
 *    想用光辉就把「模型路线」设成 sdxl。这样文档（modelRoute 的描述）与行为一致，且路线只由
 *    "modelRoute + 本机三件套齐不齐"决定（`model`/`imageModel`/`selectedModel` 只在已定路线内挑文件）。
 *    真机上曾出现过"面板说 auto、实际走光辉"，根因是老包设置里的 `profile` 被当成强制路线（已改为只看 modelRoute）。
 */
function planGeneration(c, scan) {
  const unets = bucketOf(scan, 'unets', 'unet');
  const clips = bucketOf(scan, 'clips', 'clip');
  const vaes = bucketOf(scan, 'vaes', 'vae');
  const loras = bucketOf(scan, 'loras', 'lora');
  const ckpts = bucketOf(scan, 'checkpoints', 'checkpoint');

  const ex = explicitRoute(c);
  // 显式给了文件名时，它自己就是"用户选的那个模型"（只在该家族的路线里生效；找不到就交给下面的兜底/报错）
  const exIsUnet = Boolean(ex.model) && unets.includes(ex.model);
  const exIsCkpt = Boolean(ex.model) && ckpts.includes(ex.model);
  const wantUnet = exIsUnet ? ex.model : config.truthyStr(c.animaUnet);
  const wantClip = config.truthyStr(c.animaClip);
  const wantVae = config.truthyStr(c.animaVae);
  const wantLora = config.truthyStr(c.animaTurboLora);

  const animaReady = Boolean(wantUnet && wantClip && wantVae
    && unets.includes(wantUnet) && clips.includes(wantClip) && vaes.includes(wantVae));
  // 本机扫得到三件套（与设置无关）：路线判定要**优先看本次扫描结果** ——
  // 否则"技能刚装好、下拉还空着"会被判成"本机没有"，与同一份回执上面的清单自相矛盾。
  const animaScanReady = Boolean(unets.length && clips.length && vaes.length);
  const animaConfigured = Boolean(wantUnet || wantClip || wantVae);
  const autoPickCkpt = config.flag(c.autoPickCheckpoint, true);
  // 「模型路线」= auto 时把"本次实际走了哪条、为什么"告诉调用方（回执里要如实写）
  const routeAuto = ex.auto === true;
  const routeForced = ex.forced === true;

  const notes = [];
  if (ex.model && !exIsUnet && !exIsCkpt) {
    notes.push(`设置里的「${ex.from}」指向「${ex.model}」，但本机的模型清单里找不到它 —— 这次按下面的规则挑路线。`);
  }

  // 路线：modelRoute 强制 > auto 的"三件套齐不齐"
  // （顺序很关键：auto 时**三件套齐就必须走 Anima**，面板里选了单文件也不改路线 —— 与 modelRoute 的描述一致）
  let kind = '';
  if (ex.kind) kind = ex.kind;
  else if (animaReady || animaScanReady) kind = 'anima';   // 设置齐、**或本机扫得到三件套** → Anima
  else if (exIsCkpt || ckpts.length) kind = 'checkpoint';
  else if (exIsUnet) kind = 'anima';
  else if (animaConfigured || unets.length || clips.length || vaes.length) kind = 'anima';  // 半个 Anima 也算 Anima，好把缺的哪一项说清
  else kind = 'checkpoint';

  // ── Anima 路线 ───────────────────────────────────────────────
  if (kind === 'anima') {
    // 路线为什么这么定（回执要说清，E4）
    const ckptSelected = config.truthyStr(c.checkpoint);
    const needHint = (routeAuto || routeForced) && Boolean(ckptSelected);
    const routeWhy = routeForced
      ? '「模型路线」固定成 anima'
      : (animaReady ? '本机 Anima 三件套齐（底模 + 文本编码器 + VAE 都对得上）'
        : '本机扫得到 Anima 三件套（设置里还没选全，本次按本机清单挑的）');
    if (needHint) {
      // 面板里选了单文件却走 Anima：说清"为什么没用它"以及"怎么才能用它"（否则用户会以为选中就该生效）
      notes.push(`面板里也选了单文件大模型「${ckptSelected}」，但本次走 Anima`
        + `（${routeAuto ? '「模型路线」= auto 的规则是"本机 Anima 三件套齐就优先 Anima"' : '「模型路线」固定成 anima'}）；`
        + '想用单文件大模型就把「模型路线」设成 sdxl。');
    }
    // 三个角色都按"设置优先、设置为空则按本次扫描结果"来定（见 rolePick 的注释）
    const pUnet = rolePick(c.animaUnet, 'models\\diffusion_models', unets, 'animaUnet');
    const pClip = rolePick(c.animaClip, 'models\\text_encoders', clips, 'animaClip');
    const pVae = rolePick(c.animaVae, 'models\\vae', vaes, 'animaVae');
    const bad = [['Anima 底模', pUnet], ['文本编码器', pClip], ['VAE', pVae]].filter(([, r]) => !r.ok);
    if (bad.length) {
      const unknownMachine = scan?.reliable === false;   // 两个信息源都没通 → 不许说"本机没有"
      const reasons = bad.map(([label, r]) => roleFailText(label, r, unknownMachine));
      // 出路只在**本机确实有别的可用路线**时给（别让用户白跑一趟）
      const wayOut = ckpts.length
        ? `或者把「模型路线」设成 sdxl，用本机的单文件大模型（${ckpts.join('、')}）。`
        : '文件放好后点一次 comfyui_models(action="rescan")，下拉就会跟上。';
      return {
        ok: false,
        kind: 'anima',
        reasons,
        error: `这次没法按 Anima 路线出图：\n- ${reasons.join('\n- ')}\n`
          + (routeForced ? '（「模型路线」现在是 anima：要么按上面的提示补齐，要么把它改成 auto 或 sdxl。）' : wayOut)
      };
    }
    // 哪些项是"设置里没选、这次按偏好顺序从本机清单挑的"——如实写进说明（E4：不能让用户以为设置里已经填好了）
    const fromScan = [['底模', pUnet], ['编码器', pClip], ['VAE', pVae]]
      .filter(([, r]) => r.source === 'scan')
      .map(([label, r]) => `${label} ${r.name}（${r.rule || '本机只有一个候选'}）`);
    if (fromScan.length) {
      notes.push(`设置里还没选的项已按**本机清单**自动挑：${fromScan.join('、')}`
        + '（点一次 comfyui_models(action:"rescan") 会把它们写进设置下拉，之后就以设置里的为准）。');
    }
    const wantUnet = pUnet.name;
    const wantClip = pClip.name;
    const wantVae = pVae.name;

    const cls = classify(wantUnet, 'unet');
    const loraUsable = Boolean(wantLora) && loras.includes(wantLora);
    const distilledBase = cls.variant === 'turbo';

    // 蒸馏档怎么跑（§2/§5 + E4：文案必须等于实际做法）：
    //   底模本身是蒸馏版 → 直接跑，**不再挂** Turbo LoRA（挂上去是重复蒸馏）；
    //   底模是 base/aesthetic → 只有本机确实有 Turbo LoRA 时才挂它，才按 12 步/CFG 1；
    //   两者都不成立 → 老老实实按 Anima 画质档 30 步 / CFG 4（把 12/1 套到非蒸馏底模上会出坏图）。
    const useLora = !distilledBase && loraUsable;
    const variant = distilledBase || useLora ? 'turbo' : cls.variant;
    // label 里自带文件名，直接贴在文件名后面会变成"名字（名字（说明））"——只取括号里那截说明
    const clsNote = labelNote(cls.label) || 'Anima 底模';
    if (distilledBase) {
      notes.push(`底模「${wantUnet}」本身是蒸馏版（${clsNote}），按蒸馏档跑，不挂 Turbo LoRA。`);
    } else if (useLora) {
      notes.push(`底模是 ${clsNote}，按蒸馏档跑：挂上 Turbo LoRA「${wantLora}」。`);
    } else if (wantLora) {
      // 设置里填了 LoRA 但本机没有这个文件：**不静默跳过**（L2），如实说明，也不换成别的 LoRA
      notes.push(`${loraMissingText(wantLora, loras)}（Turbo LoRA 没挂上，这次按 Anima 画质档跑 30 步 / CFG 4。）`);
      runtime.logger?.warn(`Turbo LoRA 槽：${loraMissingText(wantLora, loras)}`);
    }

    // ── LoRA 链（L1~L6）────────────────────────────────────────
    // 顺序：极速槽（animaTurboLora）→ lora1 → lora2 → lora3；空串 = 这个槽不用（**绝不自动挑**，L1）
    const chain = buildLoraChain({
      loras,
      notes,
      slots: [
        { slot: '极速槽', name: wantLora, weight: 1.0, mount: useLora },   // 极速槽固定 1.0（与既有行为一致）
        // 三个槽位来自 models.LORA_SLOTS（顺序即挂载顺序），权重键同理 —— 不在这里写死名字
        ...loraSlots().map(({ slot, weightKey }) => ({ slot, name: c[slot], weight: c[weightKey] }))
      ]
    });
    // L4 的提示**不在这里**判：它要看"最终生效的 CFG"，而参数是后面才解析的（见 loraLowCfgNote 与 runDraw 的调用点）。
    // 早先在这里按 `variant === 'turbo'` 判断，真机上"蒸馏底模 + 手调 CFG 4"就被说成"低 CFG 效果被压住"——假话。

    return {
      ok: true,
      kind: 'anima',
      tier: variant === 'turbo' ? 'anima-turbo' : 'anima',
      family: 'anima',
      variant,
      auto: false,           // 这里是"自动挑的 checkpoint"那个 auto 的兄弟字段：Anima 路线不涉及
      routeAuto,
      routeForced,
      routeWhy,
      pickedFromScan: fromScan.length > 0,
      modelFrom: pUnet.source === 'settings' ? 'settings' : 'scan',   // 回执要说清"模型是怎么定的"
      modelRule: pUnet.rule || '',
      modelSetting: config.truthyStr(c.animaUnet),
      notes,
      modelName: wantUnet,
      // lora：极速槽（tierLabel 与旧逻辑都用它）；loras：完整的链（回执 L5 与工作流 L3 都用它）
      files: { unet: wantUnet, clip: wantClip, vae: wantVae, lora: useLora ? wantLora : '', loras: chain, checkpoint: '' }
    };
  }

  // ── SDXL 单文件大模型路线 ────────────────────────────────────
  if (!ckpts.length) {
    const unknownMachine = scan?.reliable === false;
    if (unknownMachine) {
      return {
        ok: false,
        kind: 'checkpoint',
        reasons: ['单文件大模型：**这次没能确认本机有没有**（既没连上 ComfyUI，也没读到模型目录）'],
        error: '这次没能确认本机有没有可用的模型：既没连上 ComfyUI，也没读到模型目录。\n'
          + '请把 ComfyUI 启动起来，或在设置里把「ComfyUI 安装目录」填对（里面有 main.py 或 ComfyUI\\main.py 的那一层），'
          + '然后点一次 comfyui_models(action="rescan")。'
      };
    }
    return {
      ok: false,
      kind: 'checkpoint',
      reasons: ['单文件大模型：**本机没有**（models\\checkpoints 里一个文件都没有）'
        + (unets.length || clips.length || vaes.length ? '；本机的 Anima 文件也不齐（三件套要底模 + 编码器 + VAE）' : '')],
      error: '本机 ComfyUI 的 models\\checkpoints 里一个单文件大模型都没有，也没有可用的 Anima 三件套。\n'
        + '请把 .safetensors 单文件大模型（光辉 Illustrious / WAI 这类）放进 ComfyUI\\models\\checkpoints\\ 后重启 ComfyUI，'
        + '再点一次 comfyui_models(action="rescan")；或者把「Anima 底模 / 文本编码器 / VAE」三项选好走 Anima 路线。'
        + (routeForced ? '\n（「模型路线」现在是 sdxl：要么放一个单文件大模型进去，要么把它改成 auto。）' : '')
    };
  }

  // 单文件大模型同样走 rolePick：设置里有且在本机 → 用它；设置为空 → 按扫描结果挑
  const ck = rolePick(exIsCkpt ? ex.model : c.checkpoint, 'models\\checkpoints', ckpts, 'checkpoint');
  // 路线为什么这么定（回执要说清，E4）：auto 走到这里必然是"三件套不齐"，把缺的哪一项点出来
  const animaGaps = [];
  if (!unets.length) animaGaps.push('本机没有 Anima 底模');
  else if (!config.truthyStr(c.animaUnet)) animaGaps.push('没选 Anima 底模');
  if (!clips.length) animaGaps.push('本机没有文本编码器');
  else if (!config.truthyStr(c.animaClip)) animaGaps.push('没选文本编码器');
  if (!vaes.length) animaGaps.push('本机没有 VAE');
  else if (!config.truthyStr(c.animaVae)) animaGaps.push('没选 VAE');
  const routeWhy = routeForced
    ? '「模型路线」固定成 sdxl'
    : `本机 Anima 三件套不齐（${animaGaps.join('、') || '设置里的底模 / 编码器 / VAE 没凑齐'}），而 checkpoints 里有单文件大模型`;
  let pickedCkpt = ck.ok ? ck.name : '';
  let pickedWhy = ck.ok ? (ck.why || '') : '';
  let pickedRule = ck.ok ? (ck.rule || '') : '';
  let modelFrom = ck.ok ? (ck.source === 'settings' ? 'settings' : 'scan') : '';
  if (!ck.ok) {
    // 设置里选了但本机没有：只有「找不到就自动挑一个」开着才顶替（skill.json 明确写了这个行为，且不改设置值）
    const canAuto = ck.source === 'settings-missing' && autoPickCkpt;
    const sub = canAuto ? scanPick(ckpts, 'checkpoint') : { ok: false, kind: 'ambiguous', list: ckpts };
    if (canAuto && sub.ok) {
      pickedCkpt = sub.name;
      pickedWhy = sub.why;
      pickedRule = sub.rule || '';
      modelFrom = 'scan-replace';
      notes.push(`设置里的单文件大模型「${ck.set}」本机找不到，${sub.why} → 改用了「${sub.name}」`
        + '（设置里的值没有被改动）。');
    } else if (ck.source === 'unset-ambiguous' || (canAuto && !sub.ok)) {
      return {
        ok: false,
        kind: 'checkpoint',
        reasons: [`单文件大模型：设置里${ck.source === 'settings-missing' ? `选的「${ck.set}」本机找不到` : '还没选'}，`
          + `本机有多个候选（${ckpts.join('、')}）但都不在自动推荐名单里 —— 请在下拉里明确选一个（自动挑绝不替你从多个里随便选）`],
        error: `设置里的单文件大模型${ck.ok ? '' : (ck.set ? `「${ck.set}」` : '（空）')}在本机找不到，自动挑也没挑出唯一的候选，所以这次不出图。\n`
          + `本机有：${ckpts.join('、')}\n请到技能设置的「单文件大模型」下拉里明确选一个。`
          + (routeForced ? '\n（「模型路线」现在是 sdxl：也可以把它改成 auto 或 anima。）' : '')
      };
    } else if (ck.source === 'settings-missing') {
      return {
        ok: false,
        kind: 'checkpoint',
        reasons: [`单文件大模型：设置里选的「${ck.set}」**在本机不存在**（本机有：${ckpts.join('、')}）`
          + '，而「找不到就自动挑一个」是关掉的'],
        error: `设置里选的单文件大模型「${ck.set}」在本机 checkpoints 里找不到，而「找不到就自动挑一个」是关掉的，所以这次不出图。\n`
          + `本机有：${ckpts.join('、')}\n请到技能设置的「单文件大模型」下拉里选一个。`
          + (routeForced ? '\n（「模型路线」现在是 sdxl：也可以把它改成 auto 或 anima。）' : '')
      };
    } else {
      return {
        ok: false, kind: 'checkpoint', reasons: ['单文件大模型：**本机没有**（models\\checkpoints 里一个文件都没有）'],
        error: '本机 ComfyUI 的 models\\checkpoints 里一个单文件大模型都没有。'
      };
    }
  } else if (ck.source === 'scan') {
    if (!autoPickCkpt) {
      return {
        ok: false,
        kind: 'checkpoint',
        reasons: [`单文件大模型：设置里还没选，本机有（${ckpts.join('、')}）`
          + '，而「找不到就自动挑一个」是关掉的 —— 请在下拉里选一个'],
        error: `设置里还没选单文件大模型，而「找不到就自动挑一个」是关掉的，所以这次不出图。\n`
          + `本机有：${ckpts.join('、')}\n请到技能设置的「单文件大模型」下拉里选一个。`
      };
    }
    notes.push(`设置里还没选单文件大模型，${ck.why} → 用了「${ck.name}」`
      + '（点一次 comfyui_models(action:"rescan") 会把它写进设置下拉，之后就以设置里的为准）。');
  }

  // ── LoRA 链（规格 §2/L1~L6）：单文件大模型上同样只挂"用户显式选了的"槽位 ──
  // 判"本机有没有"一律看**本次扫描结果**（loras），不看设置里的字符串（L2）。
  const chain = buildLoraChain({
    loras,
    notes,
    slots: loraSlots().map(({ slot, weightKey }) => ({ slot, name: c[slot], weight: c[weightKey] }))
  });
  if (chain.length) {
    // 不拦、只提示：Anima 系 LoRA 挂到 SDXL 单文件上通常无效或跑偏（用户要挂就挂，但要知情）
    notes.push('提示：这次是 SDXL 单文件大模型，挂的 LoRA 要是 **SDXL 系** 的才有效（Anima 系 LoRA 挂上去通常不起作用或跑偏）。');
  }

  return {
    ok: true, kind: 'checkpoint', tier: 'checkpoint', family: 'sdxl', variant: classify(pickedCkpt, 'checkpoint').variant,
    auto: ck.source !== 'settings',   // true = 这个文件不是设置里选的（本机清单里自动挑的 / 顶替的）
    routeAuto, routeForced,
    routeWhy,
    pickedFromScan: ck.source === 'scan', notes, modelName: pickedCkpt,
    modelFrom, modelRule: pickedRule, modelSetting: config.truthyStr(c.checkpoint),
    files: { unet: '', clip: '', vae: '', lora: '', loras: chain, checkpoint: pickedCkpt }
  };
}

/**
 * 本机清单里按偏好挑一个（偏好顺序 → 唯一候选）。
 *
 * 匹配与顺序的**唯一真源**是 `models.pickPreferred`（`PREFER` 的唯一匹配实现，rule-major）——
 * 本文件既不再内嵌顺序、也不再自己写匹配循环（E14：同一语义只留一个真源；
 * 上一版"设置说 turbo、回执写 aesthetic"就是两份顺序打架）。
 * 返回值带上命中的那条规则（`rule`），好让回执能如实写"按 /turbo/i 挑的"。
 * 一个都挑不出来时**说明原因**（`empty` = 本机真没有 / `ambiguous` = 有多个但没有可自动推荐的）：
 * E2 禁的是"取列表第一个"，所以多个候选且没有偏好命中时宁可报错让用户选。
 */
function scanPick(list, preferKey) {
  const names = Array.isArray(list) ? list : [];
  if (!names.length) return { ok: false, kind: 'empty', list: names };

  let hit = null;
  try {
    if (typeof models.pickPreferred === 'function') hit = models.pickPreferred(names, preferKey);
  } catch { hit = null; }
  if (hit && config.truthyStr(hit.value)) {
    return { ok: true, name: hit.value, rule: hit.rule || '', why: `按本机清单自动挑：${hit.rule || hit.by || '偏好命中'}` };
  }
  // 过渡期兜底：库里暂时还没有 pickPreferred 时，用 preferFor()（PREFER → 兜底表）的顺序自己试一遍
  if (!hit) {
    for (const re of preferFor(preferKey)) {
      const h = names.find((n) => re.test(String(n)));
      if (h) return { ok: true, name: h, rule: String(re), why: `按本机清单自动挑：${String(re)}` };
    }
  }
  if (names.length === 1) return { ok: true, name: names[0], rule: '', why: '按本机清单自动挑：本机只有一个候选' };
  return { ok: false, kind: 'ambiguous', list: names };
}

// ⚠️ 过渡期兜底：偏好顺序的**唯一真源**是 `lib/models.js` 导出的 `PREFER`（数组顺序即优先级，turbo 在前）。
// E14：同一语义只留一个真源 —— 历史上这里内嵌过一份顺序，结果同一台机器上"设置里是 turbo、回执写成 aesthetic"，
// 根因就是两份顺序各挑各的（models.js 的 syncSchema 一直是 rule-major，所以错的确实是这份内嵌顺序）。
// 因此现在改为：能取到 `models.PREFER` 就**只用它**（叠加 `models.pickPreferred` 做匹配），
// 这份表只作 models.js 回滚/尚未导出的保险，且顺序与它保持一致（turbo → base → aesthetic）。
const PREFER_FALLBACK = {
  animaUnet: [/anima[-_]?turbo/i, /turbo/i, /anima[-_]?base/i, /anima[-_]?aesthetic/i, /anima/i],
  animaClip: [/qwen/i, /t5|umt5/i, /clip/i],
  animaVae: [/qwen/i, /sdxl/i, /vae/i],
  animaTurboLora: [/anima[-_]?turbo/i, /turbo/i],
  checkpoint: [/illustrious/i, /wai/i, /noobai|noob/i, /pony/i, /sdxl/i, /xl/i]
};

/** 取某一路的偏好顺序：优先 `models.PREFER`（应改为只从这里取），拿不到才用过渡期兜底表。 */
function preferFor(key) {
  let fromLib = null;
  try {
    const p = models.PREFER;
    if (p && typeof p === 'object') fromLib = p[key];
  } catch { /* 库里没有这个导出：走兜底 */ }
  const list = (Array.isArray(fromLib) && fromLib.length) ? fromLib : (PREFER_FALLBACK[key] || []);
  // 允许库里用字符串写法（`'/turbo/i'` 或 `'turbo'`）：统一成 RegExp，免得 scanPick 里再分叉
  return list.map((p) => {
    if (p instanceof RegExp) return p;
    const s = String(p ?? '').trim();
    const m = /^\/(.*)\/([a-z]*)$/.exec(s);
    try {
      return m ? new RegExp(m[1], m[2] || 'i') : new RegExp(s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'i');
    } catch { return null; }
  }).filter(Boolean);
}

/**
 * 一个角色（底模 / 编码器 / VAE / 单文件大模型）这次到底用哪个文件。
 *
 * 规则（E2 + 体验修复 + 本次"设置优先"）：
 *   ① **设置里有值且本机有 → 直接用设置里的**（用户显式选的，或首次扫描自动填进去的）；
 *   ② 设置里有值但本机没有 → **不顶替**，报"设置里选的文件在本机不存在"（下拉点 rescan 就能跟上）；
 *   ③ **设置里为空** → 按偏好顺序（`models.PREFER`）挑 → 挑不出来再看"是否只有一个候选"。
 */
function rolePick(setVal, dirLabel, list, preferKey) {
  const set = config.truthyStr(setVal);
  const names = Array.isArray(list) ? list : [];
  if (set) {
    if (names.includes(set)) return { ok: true, name: set, source: 'settings' };
    return { ok: false, source: 'settings-missing', set, list: names, dirLabel };
  }
  const p = scanPick(names, preferKey);
  if (p.ok) return { ok: true, name: p.name, source: 'scan', why: p.why, rule: p.rule || '' };
  return { ok: false, source: p.kind === 'ambiguous' ? 'unset-ambiguous' : 'unset-empty', list: names, dirLabel };
}

/** 角色挑不出来时的一句人话 —— **三种情况分开说**（设置没选 / 设置选了但本机没有 / 本机确实没有）。 */
function roleFailText(roleLabel, r, unknownMachine = false) {
  if (r.source === 'settings-missing') {
    return `${roleLabel}：设置里选的「${r.set}」**在本机不存在**`
      + `（${r.dirLabel} 里本机有：${r.list.join('、') || '（空）'}）—— 点一次 rescan 会让下拉跟上本机，或直接在下拉里重选`;
  }
  if (r.source === 'unset-ambiguous') {
    return `${roleLabel}：设置里还没选，本机有多个候选（${r.list.join('、')}）但都不在自动推荐名单里 —— `
      + '请在下拉里选一个（或点一次 rescan 让技能自动挑一个对味的）';
  }
  if (r.source === 'unset-empty') {
    // 连"有没有"都不确定时**不许说"本机没有"**（scan.reliable === false = 两个信息源都没通）
    return unknownMachine
      ? `${roleLabel}：**这次没能确认本机有没有**（既没连上 ComfyUI，也没读到模型目录）—— `
        + '把 ComfyUI 启动起来（或在设置里填对「ComfyUI 安装目录」），再点一次 rescan'
      : `${roleLabel}：**本机没有**（${r.dirLabel} 里一个文件都没有）`;
  }
  return `${roleLabel}：不可用`;
}

/**
 * 回执/清单里"当前路线是怎么定下来的"一行。
 * 不只要说"用了哪条"，还要说**为什么**（真机上曾出现"面板说 auto、实际走光辉"而回执不解释，用户无法判断）。
 */
function routeLine(plan) {
  const used = plan.kind === 'checkpoint' ? 'SDXL 单文件大模型' : 'Anima 三件套';
  const why = config.truthyStr(plan.routeWhy);
  const head = plan.routeForced
    ? `「模型路线」= ${plan.kind === 'checkpoint' ? 'sdxl' : 'anima'}（你固定的，不参与自动判定）`
    : `「模型路线」= auto → 本次实际用 ${used}`;
  const tail = plan.routeForced
    ? ''
    : (plan.kind === 'checkpoint'
      ? '（想固定成 Anima 就把它设成 anima）'
      : '（想固定成单文件大模型就把它设成 sdxl）');
  return `${head}${why ? `｜原因：${why}` : ''}${tail}`;
}

/** 回执里的模型行：名字 + 家族/变体 + **这个文件是怎么定下来的**（一条说完，不铺开）。 */
function modelLine(plan) {
  const label = labelNote(classify(plan.modelName, plan.kind === 'checkpoint' ? 'checkpoint' : 'unet').label)
    || (plan.kind === 'checkpoint' ? 'SDXL 单文件大模型' : 'Anima 底模');
  const from = plan.modelFrom === 'settings'
    ? '来自设置'
    : (plan.modelFrom === 'scan-replace'
      ? `设置里的「${plan.modelSetting || ''}」本机没有，按「找不到就自动挑一个」挑的：${plan.modelRule || '本机只有一个候选'}（设置值未被改动）`
      : `按本机清单自动挑：${plan.modelRule || '本机只有一个候选'}`);
  return `- 模型：${plan.modelName}（${R(label)}；${from}）`;
}

// ══════════════════════════════════════════════════════════════
//  3. 尺寸 / 参数 / 工作流
// ══════════════════════════════════════════════════════════════

/** 目录尾部片段（见 dirTail）与"进程还在不在"这类小工具。 */

/**
 * 进程是否还活着。返回 `true` / `false` / `null`（不知道）。
 *
 * 为什么要它：`ensureStarted` 的 `spawned:true` 只说明"我们**尝试**拉起过"，
 * 而端口被既有实例占着时，它会先答复、我们的子进程随后退出 —— 那时 pid 已经没了。
 * 「已拉起（pid X）」这种话必须能核实过再说（E4），所以这里自己探一下。
 */
function isPidAlive(pid) {
  const n = Number(pid);
  if (!Number.isFinite(n) || n <= 0) return null;
  try {
    process.kill(n, 0);
    return true;
  } catch (error) {
    return error?.code === 'EPERM' ? true : false;   // EPERM = 存在但不是我们的；ESRCH = 已经没了
  }
}

/** 等一小会儿再确认一次（子进程"起来后立刻退出"有个时间差），只在确实尝试拉起过时才等。 */
async function confirmSpawnAlive(pid) {
  const first = isPidAlive(pid);
  if (first === false) return false;
  if (first === null) return null;
  // 刻意**不 unref** 这个定时器：unref 过的 sleep 在"事件循环刚好空闲"时永远不会触发
  // （表现为这条 await 悬住），而这里只需要等 1.2 秒。
  await new Promise((r) => setTimeout(r, 1200));
  return isPidAlive(pid);
}

/**
 * 一次 `ensureStarted` 的**归因文案**（E4：只按能核实的事实说）。
 *
 * 注意与 `ensureStarted` 的关系：它的 `spawned:true` 已经用"子进程还活着"确认过；
 * 我这里再等 1.2 秒复核一次，是**为了发现"起来了但随后退出"**（端口被别家占着时就是这个样子）。
 * 那种情况**不能说成"不是本次拉起的"** —— 我们确实拉起来了，只是它没留住：
 * 所以给第三种说法（见下），并且回执里关于拉起的说明**只保留一处**。
 *
 * @returns {{ text:string, ours:boolean, exited:boolean }} ours = 确实是本次拉起的（即便随后退出）
 */
async function attributeStarted(started) {
  const spawned = started?.spawned === true;
  if (!spawned) {
    // 没尝试拉起：要么一开始就在跑，要么就是被既有的实例答复了（comfy.js 会带 external/note）
    const externalish = started?.external === true || Boolean(config.truthyStr(started?.note));
    return {
      ours: false,
      exited: false,
      text: externalish
        ? 'ComfyUI 已在运行（**不是本次拉起的**：本次尝试起的进程没有接手，端口上跑的是既有的实例，通常是端口已被占用）'
        : 'ComfyUI 已在运行（本次没有拉起新进程）'
    };
  }
  if (started?.external === true) {
    return { ours: false, exited: false, text: 'ComfyUI 已在运行（**不是本次拉起的**：端口上跑的是既有的实例）' };
  }
  const alive = await confirmSpawnAlive(started.pid);
  if (alive === false) {
    // 第三种：本次**确实拉起过**，但进程随后退出（端口被占 / 被外部关掉 / 自己崩了）
    return {
      ours: true,
      exited: true,
      text: `ComfyUI 已拉起${started.pid ? `（pid ${started.pid}）` : ''}，但**本次起的进程随后退出了**`
        + '（可能是端口被占用或被外部关闭）—— 端口上现在有实例在应答，这次照常出图'
    };
  }
  return { ours: true, exited: false, text: `ComfyUI 已自动拉起${started.pid ? `（pid ${started.pid}）` : ''}` };
}

/** 回执里的尺寸行：把"来自哪"和"size=512 按 512×512 处理"这类说明拼在**一处**，口径统一、也便于测试。 */
function sizeLine(size, width, height) {
  return `- 尺寸：${width}x${height}（在显存上限 ${size.maxW}x${size.maxH} 内按 64 的倍数对齐）`
    + (size.explicit ? '，来自你指定的尺寸' : '，来自技能设置里的默认尺寸')
    // size 生效时 width/height 是被**忽略**的（有意：描述里写了"size 优先"）——
    // 同传两者时要把这个事实说全，否则用户会以为宽度被尊重了
    + (size.overrodeWH ? '（你给的 width/height 被 size 覆盖，按 size 优先）' : '')
    + (size.note ? `；${size.note}` : '');
}

/** 「ComfyUI 没开时自动拉起」关掉时的文案（独立出来是为了能单独核对，不靠跑一次出图）。 */
function autoStartOffText(base) {
  return `连不上本机 ComfyUI（${R(base)}），而设置里关掉了「ComfyUI 没开时自动拉起」——`
    + '请手动启动 ComfyUI（双击它目录下的启动脚本）后再试；或者把那个开关打开。';
}

/**
 * 参数表的**真源**到底走通没有（`models.paramTableSource()`：'params.resolveParams' / 'params.PARAM_TABLE' / 'fallback'）。
 *
 * 为什么要专门看它：`models.paramsForModel` 在 `lib/params.js` 加载失败时会**静默退回**一份兜底表，
 * 而那份兜底表的值与 §5 逐条相同 —— 值一样，所以出图结果不会错，**但"真源失效"这件事一点信号都没有**。
 * 一旦 §5 改了、兜底表忘了跟，参数就会悄悄跑偏。所以启动时读一次、写进日志；不是真源就 warn。
 *
 * 永不抛：取不到就如实写"未知"。
 * @returns {Promise<{source:string, text:string}>}
 */
async function readParamSource() {
  let source = '';
  try {
    if (typeof models.paramTableSource === 'function') source = config.truthyStr(await models.paramTableSource());
  } catch (error) {
    runtime.logger?.warn(`读取"参数表真源"失败（按未知处理）：${errText(error)}`);
    source = '';
  }
  // 顺带给出表本身的指纹：这样"真源通没通"之外，还能看出**加载到的是不是 §5 那张表**
  let fingerprint = '取不到表指纹';
  try {
    const t = params.PARAM_TABLE;
    const turbo = t?.anima?.turbo;
    const base = t?.anima?.base;
    const sdxl = t?.sdxl?.[''];
    if (turbo && base && sdxl) {
      fingerprint = `anima.turbo=${turbo.steps}/${turbo.cfg}·${turbo.sampler}+${turbo.scheduler}`
        + `，anima.base=${base.steps}/${base.cfg}`
        + `，sdxl=${sdxl.steps}/${sdxl.cfg}·${sdxl.sampler}+${sdxl.scheduler}`;
    }
  } catch { /* 指纹只是锦上添花，取不到就算了 */ }

  const text = source === 'params.resolveParams'
    ? `params.resolveParams（真源 lib/params.js 已加载；PARAM_TABLE ${fingerprint}）`
    : source === 'params.PARAM_TABLE'
      ? 'params.PARAM_TABLE（表拿到了，但 resolveParams 没取到）'
      : source === 'fallback'
        ? '兜底副本（不是真源：lib/params.js 没加载成功）'
        : '未知（取不到 paramTableSource）';
  return { source, text };
}

/** 启动时把参数真源写进日志；不是真源就 warn（静默失效必须变成看得见的一句话）。 */
async function logParamSource() {
  const { source, text } = await readParamSource();
  if (source === 'params.resolveParams') runtime.logger?.info(`参数真源：${text}`);
  else runtime.logger?.warn(`参数表来源：${text} —— 请检查 lib/params.js 能否被加载（参数表的唯一真源在它那里）`);
  return { source, text };
}

/**
 * 回执里关于"拉起的说明"——**只此一处**（别在别处再写一句，否则同一份回执会自相矛盾）。
 * @returns {string} 没有需要说明的就返回 ''
 */
function startedNote(attributed, seconds = 0) {
  if (!attributed?.ours) return '';
  if (attributed.exited) {
    return 'ComfyUI 是本次拉起的，但**本次起的进程随后退出了**（可能是端口被占用或被外部关闭）；'
      + '端口上现在有实例在应答，这次照常出图。';
  }
  return `ComfyUI 是本次自动拉起的（启动 + 就绪等待约 ${seconds} 秒）。`;
}

/**
 * 尺寸：设置默认值 → 调用方给的 size/width/height。
 * 全部经 config.intIn / config.align64Within（先夹 → 64 对齐 → 再夹），保证不越过显存上限。
 *
 * size 认三种写法（优先级：**可用的 size** 优先于 width/height；三者都没填 → 设置里的默认尺寸）：
 *   `1024x1024` / `1024×1024` / `1024*1024` → 宽高各自夹取；
 *   **裸数字 `512`** → 正方形 512×512（"想要方图"是最常见的意图，别浪费一个警告就丢掉）；
 *   其它写法 → 记一条把期望写法写清楚的警告；这时 width/height 有用就用它（别白白丢掉用户给的数字），
 *   两者都没给才回落到设置里的默认尺寸。
 */
function resolveSize(c, args) {
  const maxW = config.intIn(c.maxWidth, 512, 4096, 1536);
  const maxH = config.intIn(c.maxHeight, 512, 4096, 1536);
  let width = config.align64Within(c.defaultWidth, 512, maxW, 1024);
  let height = config.align64Within(c.defaultHeight, 512, maxH, 1024);
  let explicit = false;
  let note = '';
  let overrodeWH = false;

  const sizeArg = config.truthyStr(args?.size);
  const aw = Number(args?.width);
  const ah = Number(args?.height);
  // 显式 0 与留空同义（§5：0 只表示"没填"）；负数/NaN 同样不算填了
  const hasW = Number.isFinite(aw) && aw > 0;
  const hasH = Number.isFinite(ah) && ah > 0;

  if (sizeArg) {
    const m = /^(\d{3,4})\s*[x×*]\s*(\d{3,4})$/i.exec(sizeArg);
    const square = /^(\d{3,4})$/.exec(sizeArg);
    if (m) {
      width = config.align64Within(m[1], 512, maxW, width);
      height = config.align64Within(m[2], 512, maxH, height);
      explicit = true;
      overrodeWH = hasW || hasH;      // 同传了 width/height：回执里要如实说明它们被 size 覆盖了
    } else if (square) {
      // 裸数字 = 正方形（回执里要写清"按 512×512 处理"，别让用户以为被忽略了）
      width = config.align64Within(square[1], 512, maxW, width);
      height = config.align64Within(square[1], 512, maxH, height);
      explicit = true;
      overrodeWH = hasW || hasH;
      note = `size=${sizeArg} 按 ${width}×${height}（正方形）处理`;
      runtime.logger?.info(note);
    } else {
      // 写法认不出：**不白丢** width/height（有就用），两者都没有才回落到默认尺寸
      if (hasW || hasH) {
        if (hasW) width = config.align64Within(aw, 512, maxW, width);
        if (hasH) height = config.align64Within(ah, 512, maxH, height);
        explicit = true;
        note = `size=${sizeArg} 写法认不出，已改用你给的 width/height`;
      }
      runtime.logger?.warn(`size 参数写法不认识（${hasW || hasH ? '改用 width/height' : `按默认尺寸 ${width}x${height}`}）：${R(sizeArg).slice(0, 40)}`
        + '（期望写法：1024x1024 这种"宽x高"，或直接给 width/height；也可以只给一个数字表示正方形）');
    }
  } else if (hasW || hasH) {
    if (hasW) width = config.align64Within(aw, 512, maxW, width);
    if (hasH) height = config.align64Within(ah, 512, maxH, height);
    explicit = true;
  }
  return { width, height, maxW, maxH, explicit, note, overrodeWH };
}

/**
 * 按参考图比例算尺寸（**只在 composition 模式用**）。
 * appearance 模式不把图送进采样器，出图尺寸与参考图毫无关系，套它的比例只会莫名其妙。
 */
function fitSizeInto(srcW, srcH, targetW, targetH, maxW, maxH) {
  const w0 = Number(srcW) || 0;
  const h0 = Number(srcH) || 0;
  if (!(w0 > 0 && h0 > 0)) return null;
  const tw = Number(targetW) > 0 ? Number(targetW) : 1024;
  const th = Number(targetH) > 0 ? Number(targetH) : 1024;
  let k = Math.min(tw / w0, th / h0, Number(maxW) / w0, Number(maxH) / h0);
  let w = w0 * k;
  let h = h0 * k;
  const shortSide = Math.min(w, h);
  if (shortSide > 0 && shortSide < 512) {
    const k2 = 512 / shortSide;
    if (w * k2 <= maxW && h * k2 <= maxH) { w *= k2; h *= k2; }
  }
  const align = (v, max) => Math.max(64, Math.min(max, Math.round(v / 64) * 64));
  return { width: align(w, maxW), height: align(h, maxH) };
}

/**
 * 参数来源 → **给群友看的人话**。
 *
 * 措辞口径（重要）：回执会被宿主模型念给群里听，所以这里**不许出现只有开发者才懂的历史说法**
 * （"旧包 / 旧版 / 上一版 / 修复 / 重构"这类），一律换成用户视角的描述。四类来源统一成：
 *   Anima 基础 / 美学档官方参数 · Anima 蒸馏档参数 · SDXL（光辉 / Illustrious）常用值 · 默认兜底值。
 * @param {{origin?:string, auto?:boolean, fallbackReason?:string}} rp resolveParams（或本文件 safeResolveParams）的结果
 */
function originText(rp) {
  const r = rp && typeof rp === 'object' ? rp : { origin: String(rp ?? '') };
  const o = String(r.origin || '').trim();
  const auto = r.auto !== false;
  if (!auto && o === 'manual') return '设置里手调的（「参数自动跟随模型」关着，四项都填了）';
  if (!auto && o.startsWith('manual+')) {
    return `设置里手调的 + 没填的那几项按「${originText({ origin: o.slice(7), auto: true })}」`;
  }
  switch (o) {
    case 'official-anima-base': return 'Anima 基础 / 美学档官方参数（30 步 / CFG 4 / euler + simple）';
    case 'official-anima-turbo': return 'Anima 蒸馏档参数（12 步 / CFG 1 / euler + simple）';
    case 'official-sdxl': return 'SDXL（光辉 / Illustrious）常用值（28 步 / CFG 5 / euler_ancestral + normal）';
    case 'fallback': {
      const why = config.truthyStr(r.fallbackReason);
      return `默认兜底值（30 步 / CFG 4）——${why || '模型的家族 / 变体没认出来，按基础档的参数跑'}`;
    }
    default:
      // 认不出的来源标记不外泄内部写法，只说清"用了默认值"
      return o ? '默认兜底值（参数来源标记没认出来，按基础档的参数跑）' : '默认兜底值（没拿到参数来源标记）';
  }
}

/**
 * 档位 → 人话（E4：说清这次到底挂没挂 LoRA、底模是什么类型）。
 *
 * `paramsAuto=false`（「参数自动跟随模型」关着、步数/CFG 是手调的）时**只描述底模**，
 * 不再说"蒸馏档 / 画质档"——档位名自带 12 步 / CFG 1（或 30 / 4）的含义，跟手调的 30 步 / CFG 4
 * 摆在一起会让人以为"蒸馏档就是 30 步"（真机上被抓到的就是这么一句）。参数到底是多少，
 * 由紧跟其后的「参数来源 / 实际用 …」那几行如实交代。
 */
function tierLabel(tier, files, paramsAuto = true) {
  if (tier === 'checkpoint') return 'SDXL 单文件大模型（光辉 Illustrious / WAI 这类）';
  if (tier === 'anima-turbo') {
    if (!paramsAuto) return 'Anima 蒸馏底模';   // 底模本身是蒸馏版这个事实不变；参数是手调的，不在这里下结论
    return files?.lora
      ? `Anima 蒸馏档（底模 + Turbo LoRA「${files.lora}」）`
      // 说的是"不需要极速用的那条 LoRA"，不是"一个 LoRA 都没挂"（lora1~5 可能挂着）——
      // 别让这句和回执里的「- LoRA：…」打起来
      : 'Anima 蒸馏档（底模本身就是蒸馏版，不需要 Turbo LoRA）';
  }
  return paramsAuto ? 'Anima 画质档' : 'Anima 底模';
}

/**
 * 回执首行的固定说法（抽出来是为了能像回执一样被测试断言，而不是在测试里再抄一遍模板）。
 * 档位名与步数/CFG 用 `tierLabel(..., paramsAuto)` 分开表述（见它的注释）。
 */
function receiptHeadText({ sizeText, tier, files, paramsAuto, steps, cfg, technique, totalSeconds, sampleSeconds }) {
  return `已发送一张图（${sizeText}，${tierLabel(tier, files, paramsAuto)}，${steps} 步，CFG ${cfg}，${technique}，`
    + `总用时约 ${totalSeconds} 秒（其中采样约 ${sampleSeconds} 秒，其余是翻译、找参考图、外观提取等准备时间））。`;
}

// ══════════════════════════════════════════════════════════════
//  LoRA 链的小工具（规格《LoRA链-追加功能规格》§1/§2 L1~L6）
// ══════════════════════════════════════════════════════════════

/**
 * 权重：默认 0.8，夹到 0~1.5（`0` 是有效值 = 挂上但强度为零，与 §1 的 0~1.5 一致）。
 * 顺手取到 3 位小数：面板 step 是 0.05，3 位足够，而**不取整会漏出浮点尾巴**
 * （0.1×3 = 0.30000000000000004）—— 那个数字会原样出现在回执里给群友看（L5）。
 */
function clampLoraWeight(v) {
  const n = config.numOr(v, 0.8);
  const clamped = Math.min(1.5, Math.max(0, Number.isFinite(n) ? n : 0.8));
  return Math.round(clamped * 1000) / 1000;
}

/** 权重显示：整数补一位小数（0.8 → `0.8`，1 → `1.0`，1.25 → `1.25`，0.3 → `0.3`）。 */
function weightText(w) {
  const n = clampLoraWeight(w);
  return n === Math.round(n) ? n.toFixed(1) : String(n);
}

/** L2：设置里选了、但本机没有这个文件 —— 一句话，回执与日志共用（不许静默跳过）。 */
function loraMissingText(name, loras) {
  return `你要挂的 LoRA「${name}」在本机不存在（本机有：${loras?.length ? loras.join('、') : '一个都没有'}），这次没挂`;
}

/**
 * LoRA 槽位名与权重键的**唯一真源**在 `lib/models.js`（`LORA_SLOTS` / `LORA_WEIGHT_KEYS`）。
 *
 * 取不到时**不再"全部跳过"**，而是从 `skill.json` 的 `configSchema` 里按 `/^lora\d+$/` **派生**槽位名 ——
 * 面板上已经有什么槽，就按什么槽挂（这才是"唯一真源"该有的稳健做法）。真机上出现过
 * "取不到 models.LORA_SLOTS → 5 个槽全跳过"的情况：宿主热重载只换 index.js，静态 import 拿到的
 * 还是缓存里的旧 models.js（见 refreshModelsNs），派生兜底保证那种情况下仍有正确的槽位名。
 * 用了派生槽位会**明确写日志**（否则只看"取不到"看不出后果）。
 */
function loraSlots() {
  // 命名空间存在 getState() 里（与 refreshModelsNs 同一处），**不是** runtime —— 两者是不同的对象
  const ns = getState().modelsNs || models;
  let slots = null;
  let weightKeys = null;
  let from = '';
  try {
    if (Array.isArray(ns?.LORA_SLOTS) && ns.LORA_SLOTS.length) {
      slots = ns.LORA_SLOTS;
      weightKeys = ns.LORA_WEIGHT_KEYS;
      from = 'lib/models.js';
    }
  } catch { /* 命名空间取不到就往下走兜底 */ }
  if (!slots) {
    const derived = loraSlotsFromSchema();
    if (derived.length) { slots = derived; from = 'skill.json 的 configSchema（派生）'; }
  }
  if (!slots || !slots.length) {
    runtime.logger?.warn('既取不到 models.LORA_SLOTS，skill.json 里也没有 loraN 这样的槽位键 —— 本次不挂 lora 槽'
      + '（只有极速槽会挂）；请检查 lib/models.js 与 skill.json');
    return [];
  }
  const weights = (weightKeys && typeof weightKeys === 'object') ? weightKeys : {};
  if (from !== 'lib/models.js') {
    runtime.logger?.warn(`取不到 models.LORA_SLOTS —— 改用「${from}」得到的槽位：${slots.join('、')}`
      + `（按这些槽挂载；权重键按 ${slots[0]}Weight 这类命名约定推）`);
  }
  return slots.map((slot) => ({
    slot: String(slot),
    weightKey: config.truthyStr(weights[slot]) || `${String(slot)}Weight`
  }));
}

/** 从 skill.json 的 configSchema 里派生 LoRA 槽位名（`lora1`…`lora5`，按数字排序）。 */
function loraSlotsFromSchema() {
  try {
    const j = JSON.parse(fs.readFileSync(SELF_SKILL_JSON, 'utf8').replace(/^\uFEFF/, ''));
    const keys = Object.keys(j?.configSchema && typeof j.configSchema === 'object' ? j.configSchema : {});
    return keys.filter((k) => /^lora\d+$/.test(k))
      .sort((a, b) => Number(a.slice(4)) - Number(b.slice(4)));
  } catch { return []; }
}

/**
 * 组装本次要挂的 LoRA 链（规格 §1/§2 L1~L6）。**唯一的实现**，Anima 与单文件两条路线都用它。
 *
 * @param {string[]} loras 本次**扫描**到的 loras\ 文件（判"本机有没有"只看它，不看设置里的字符串 —— L2）
 * @param {Array<{slot:string,name:string,weight:*,mount?:boolean}>} slots 有序槽位（极速槽 → lora1 → … 按库里的 LORA_SLOTS 顺序）
 * @param {string[]} notes 说明汇总（本函数把 L2/L6 的说明写进去）
 * @returns {Array<{slot:string,name:string,weight:number}>} 真正要挂的链（顺序即挂载顺序）
 *
 * 三条规矩：
 *   · **绝不自动挑**（L1）：空串就是"这个槽不用"，不看偏好、不取第一个候选；
 *   · 设置里选了但本机没有 → **不静默跳过**（L2）：说明里写清 + 日志 warn，也不换成别的文件；
 *   · 同一个文件只挂一次（L6）：与前面槽位重复时跳过并说明。
 */
function buildLoraChain({ loras, slots, notes }) {
  const chain = [];
  for (const s of Array.isArray(slots) ? slots : []) {
    if (s.mount === false) continue;                        // 显式不挂（例：底模本身是蒸馏版，不挂极速 LoRA）
    const name = config.truthyStr(s.name);
    if (!name) continue;                                    // L1：空槽不挂、也不自动补
    const dup = chain.find((x) => x.name === name);
    if (dup) {                                              // L6：同一文件不挂两次
      notes.push(`LoRA「${name}」在「${s.slot}」里与「${dup.slot}」是同一个文件，已跳过（同一个文件只挂一次）。`);
      runtime.logger?.warn(`LoRA 槽「${s.slot}」与「${dup.slot}」重复（同一文件），已跳过`);
      continue;
    }
    if (!loras.includes(name)) {                             // L2：本机没有 → 不静默跳过
      notes.push(loraMissingText(name, loras));
      runtime.logger?.warn(`LoRA 槽「${s.slot}」：${loraMissingText(name, loras)}`);
      continue;
    }
    chain.push({ slot: s.slot, name, weight: clampLoraWeight(s.weight) });
  }
  return chain;
}

/** L5：回执里"实际挂了哪些 LoRA + 权重"一行；一个都没挂就返回 ''（保持回执干净）。 */
function loraLine(plan) {
  const chain = Array.isArray(plan?.files?.loras) ? plan.files.loras : [];
  if (!chain.length) return '';
  return `- LoRA：${chain.map((x) => `${x.name}（${weightText(x.weight)}）`).join('、')}`;
}

/** CFG 显示：去掉浮点尾巴（1 → `1`，1.5 → `1.5`）。 */
function cfgText(v) {
  const n = Number(v);
  return Number.isFinite(n) ? String(Math.round(n * 100) / 100) : String(v);
}

/**
 * L4 提示：挂了**非 turbo** 的 LoRA，而**本次实际**用的是低 CFG（≤ 1.5）时，提醒一句（不是拒绝）。
 *
 * ⚠️ 判据必须是**最终提交进 KSampler 的那个 CFG**，不能是"底模是不是蒸馏版"——
 * 真机上用户把「参数自动跟随模型」关掉、手调成 CFG 4，底模仍是蒸馏版，于是旧实现照样说
 * "低 CFG 下效果会被压住"，**说的是假话**（违反 E4）。数字也用实际值，不写死"CFG 1"。
 *
 * @param {object} plan planGeneration 的结果（取实际挂上的 LoRA 链）
 * @param {number} cfg 实际生效的 CFG
 * @param {boolean} paramsAuto 参数是不是"自动跟随模型"（决定给哪条建议：手调时就别再劝人关自动了）
 */
function loraLowCfgNote(plan, cfg, paramsAuto) {
  const c = Number(cfg);
  if (!Number.isFinite(c) || c > 1.5) return '';          // 不是低 CFG → 这句话不成立，一个字都不说
  const chain = Array.isArray(plan?.files?.loras) ? plan.files.loras : [];
  const nonTurbo = chain.filter((x) => !/turbo/i.test(String(x.name)));
  if (!nonTurbo.length) return '';                         // 只有 turbo 类 LoRA → 低 CFG 本来就是它的用法
  const names = nonTurbo.map((x) => x.name).join('、');
  const advice = paramsAuto
    ? '必要时把「参数自动跟随模型」关掉、把 CFG 提到 3~5 再试'
    : '必要时把 CFG 提到 3~5（或把这几个 LoRA 的权重调高）再试';
  return `提示：这次实际用的是低 CFG（CFG ${cfgText(c)}），而挂了非 turbo 的 LoRA「${names}」—— `
    + `低 CFG 下画风 / 写实类 LoRA 效果可能不明显甚至跑偏；${advice}。`;
}

/** 家族/档位默认的质量词与负面词（设置里留空时回落；数字与写法与 §5 的依据列同源）。 */
const PROFILE_TEXT = {
  sdxl: {
    qualityPrefix: 'masterpiece, best quality, amazing quality, very aesthetic, absurdres, newest',
    negative: 'bad quality, worst quality, worst detail, sketch, censor, jpeg artifacts, lowres, blurry, '
      + 'bad anatomy, bad hands, extra fingers, missing fingers, watermark, signature, text',
    prependQuality: true,
    promptStyle: '英文 danbooru 标签串（逗号分隔、小写、词组用下划线）',
    translateHint: '翻译成英文 danbooru 标签串：逗号分隔的短标签，小写，词组用下划线连接（如 silver_hair）。'
  },
  anima: {
    qualityPrefix: '',
    negative: 'worst quality, low quality, score_1, score_2, score_3, blurry, jpeg artifacts, sepia',
    prependQuality: false,
    promptStyle: '英文自然语言描述句（逗号分隔的短语）',
    translateHint: '翻译成英文自然语言描述句：逗号分隔的短语，像在描述一张画，而不是标签堆'
      + '（例如 a silver-haired girl standing under cherry blossom trees, soft daylight）。'
  }
};

/**
 * 只按设置**猜**这次大概走哪条路线（真正定下来要等探活 + 扫模型之后）。
 * 用途只有一个：给翻译一句正确的形态提示（SDXL 档吃标签串、Anima 档吃自然语言）——
 * 猜错最多是翻译措辞略偏，不会影响尺寸/参数/工作流。
 */
function guessFamily(c) {
  if (config.truthyStr(c?.animaUnet)) return 'anima';
  if (config.truthyStr(c?.checkpoint)) return 'sdxl';
  return 'anima';
}

function profileTextFor(family) {
  const local = PROFILE_TEXT[family] || PROFILE_TEXT.anima;
  // models.FAMILIES 是家族定义的唯一出处：它给了质量词/负面词就用它的，没有才用上面的本机回落值。
  const fam = models.FAMILIES && typeof models.FAMILIES === 'object' ? models.FAMILIES[family] : null;
  if (!fam || typeof fam !== 'object') return local;
  return {
    qualityPrefix: config.truthyStr(fam.qualityPrefix) || local.qualityPrefix,
    negative: config.truthyStr(fam.negative) || local.negative,
    prependQuality: config.flag(fam.prependQuality, local.prependQuality),
    promptStyle: config.truthyStr(fam.promptStyle) || local.promptStyle,
    translateHint: config.truthyStr(fam.translateHint) || local.translateHint
  };
}

/** §5 参数表的本机回落值（只在 params.resolveParams 抛错时用；数字与 §5 同源）。 */
const PARAM_FALLBACK = {
  anima: { '': { steps: 30, cfg: 4, sampler: 'euler', scheduler: 'simple', origin: 'official-anima-base' },
    turbo: { steps: 12, cfg: 1, sampler: 'euler', scheduler: 'simple', origin: 'official-anima-turbo' } },
  sdxl: { '': { steps: 28, cfg: 5, sampler: 'euler_ancestral', scheduler: 'normal', origin: 'official-sdxl' } }
};

/**
 * 包一层 resolveParams：它抛错时按 §5 兜底并**如实标 origin=fallback**（E4：不许假装知道参数从哪来）。
 * 为什么值得包：参数解析失败不该让整整一次出图失败 —— 兜底值本身就是"能出图的安全值"。
 */
function safeResolveParams({ settings, modelName, family, variant }) {
  try {
    const r = params.resolveParams({ settings, modelName, family, variant });
    if (r && typeof r === 'object' && Number.isFinite(Number(r.steps))) {
      return {
        ...r, steps: Number(r.steps), cfg: Number(r.cfg),
        origin: String(r.origin || 'fallback'), auto: r.auto !== false, fallbackReason: ''
      };
    }
    runtime.logger?.warn('参数解析返回了意外的结果，按参数表兜底');
  } catch (error) {
    runtime.logger?.warn(`参数解析失败（按参数表兜底）：${errText(error)}`);
  }
  const table = PARAM_FALLBACK[family] || PARAM_FALLBACK.anima;
  const row = table[variant] || table[''];
  return {
    ...row, auto: false, mixed: false, origin: 'fallback', table: { ...row },
    // 回执里要能说清"为什么走到了兜底"（E4）：这条原因只在真的出过错时才填
    fallbackReason: '这次算参数时出了错，已改用默认兜底值（完整信息在技能日志里）'
  };
}

/** 包一层 hiresPlan：它抛错时**关掉**本次二次放大（比"带着不确定的倍数去放"安全），并如实说明。 */
function safeHiresPlan(c, dims, sampler, scheduler) {
  try {
    const r = params.hiresPlan(c, dims);
    if (r && typeof r === 'object') return r;
  } catch (error) {
    runtime.logger?.warn(`二次放大计划失败（本次关闭二次放大）：${errText(error)}`);
  }
  return {
    enabled: false, scale: 1, steps: 10, denoise: 0.45,
    sampler: sampler || 'euler', scheduler: scheduler || 'simple',
    degraded: '二次放大本次已关闭：计算放大计划时出错（详见技能日志）。',
    method: config.truthyStr(c?.upscaleMethod) || 'bilinear'
  };
}

/**
 * 构建工作流。
 *
 * **节点号占用表**（刻意排布，别再改；加新节点前先看这张表）：
 *   1/2/3   Anima 三个 loader（UNET / CLIP / VAE）      4/5     正负提示词
 *   6       空 latent（文生图）                          7       第一段 KSampler
 *   8       VAEDecode                                    9       SaveImage
 *   10      LoRA 链 · 极速槽                             11/12   二次放大（LatentUpscaleBy + 第二段 KSampler）
 *   13~17   LoRA 链 · lora1~lora5（**按槽位固定**，空槽不占号而是预留）
 *   20/21/22 img2img（LoadImage / ImageScale / VAEEncode）
 * 为什么非要挑号：节点号撞了 ComfyUI 会直接报节点图错乱（旧包就吃过 LoRA 抢 10 号的亏）。
 * 单文件大模型路线复用同一套号（checkpoint 是 4 号，KSampler 是 3 号，其余同表）。
 */
function buildWorkflow(o) {
  const positive = o.prompt;
  const negative = o.negative;
  const hires = o.hires || { enabled: false };
  // denoise：有参考图才允许小于 1（走 img2img），否则必须 1.0 —— 没有参考图时低 denoise 只会画出糊图
  const rawDenoise = Number(o.denoise);
  const denoise = o.refImage
    ? (Number.isFinite(rawDenoise) ? Math.min(1, Math.max(0.05, rawDenoise)) : 0.6)
    : 1.0;

  // img2img 三节点：20 读图 → 21 等比缩到出图尺寸 → 22 编码成 latent
  const refChain = (vaeRef) => ({
    '20': { class_type: 'LoadImage', inputs: { image: o.refImage } },
    '21': {
      class_type: 'ImageScale',
      inputs: { image: ['20', 0], upscale_method: 'lanczos', width: o.width, height: o.height, crop: 'disabled' }
    },
    '22': { class_type: 'VAEEncode', inputs: { pixels: ['21', 0], vae: vaeRef } }
  });

  // ── LoRA 链（规格 §2/L3）──────────────────────────────────
  // 顺序：极速槽 → lora1 → lora2 → lora3（`files.loras` 已由 planGeneration 按这个顺序排好、去重、校验过本机存在）。
  // 兼容：只给了旧的 `files.lora`（极速槽单槽）时也照挂 —— 老调用方与早先的测试都走这条。
  const loraChain = Array.isArray(o.files?.loras) && o.files.loras.length
    ? o.files.loras
    : (config.truthyStr(o.files?.lora) ? [{ slot: '极速槽', name: o.files.lora, weight: 1 }] : []);
  /**
   * 把 LoRA 链接到 baseRef 后面，返回新的 model 引用。
   * **节点号按槽位固定**（不是按顺序打包）：极速槽 10、lora1 13、lora2 14、lora3 15、lora4 16、lora5 17 ——
   * 这样"lora1 永远是 13 号"，上面某个槽空着也不会让后面的号整体前移（空槽是**预留**，便于排查与对比工作流）。
   */
  const LORA_NODE_BY_SLOT = {
    极速槽: '10',
    lora1: '13', lora2: '14', lora3: '15', lora4: '16', lora5: '17'
  };
  const attachLoras = (wf, baseRef) => {
    let ref = baseRef;
    loraChain.forEach((item, i) => {
      // 未知槽位（将来库里再加槽）退回顺序号；13~17 用满了才往后排，避免撞到 20+ 的 img2img
      const id = LORA_NODE_BY_SLOT[item.slot] || String(13 + i);
      wf[id] = {
        class_type: 'LoraLoaderModelOnly',
        inputs: { model: ref, lora_name: item.name, strength_model: clampLoraWeight(item.weight) }
      };
      ref = [id, 0];
    });
    return ref;
  };

  if (o.kind === 'checkpoint') {
    const wf = {
      '4': { class_type: 'CheckpointLoaderSimple', inputs: { ckpt_name: o.files.checkpoint } },
      '6': { class_type: 'CLIPTextEncode', inputs: { text: positive, clip: ['4', 1] } },
      '7': { class_type: 'CLIPTextEncode', inputs: { text: negative, clip: ['4', 1] } },
      '8': { class_type: 'VAEDecode', inputs: { samples: ['3', 0], vae: ['4', 2] } },
      '9': { class_type: 'SaveImage', inputs: { filename_prefix: 'qq-agent', images: ['8', 0] } }
    };
    // 单文件大模型上也允许挂链（用户显式选的，不拦；是不是 SDXL 系 LoRA 由用户在回执说明里自己核对）
    const modelRef = attachLoras(wf, ['4', 0]);
    wf['3'] = {
      class_type: 'KSampler',
      inputs: {
        seed: o.seed, steps: o.steps, cfg: o.cfg, sampler_name: o.sampler, scheduler: o.scheduler, denoise,
        model: modelRef, positive: ['6', 0], negative: ['7', 0],
        latent_image: o.refImage ? ['22', 0] : ['5', 0]
      }
    };
    if (o.refImage) Object.assign(wf, refChain(['4', 2]));
    else wf['5'] = { class_type: 'EmptyLatentImage', inputs: { width: o.width, height: o.height, batch_size: 1 } };
    if (hires.enabled) {
      wf['11'] = { class_type: 'LatentUpscaleBy', inputs: { samples: ['3', 0], upscale_method: hires.method, scale_by: hires.scale } };
      wf['12'] = {
        class_type: 'KSampler',
        inputs: {
          seed: o.seed, steps: hires.steps, cfg: o.cfg,
          sampler_name: hires.sampler || o.sampler, scheduler: hires.scheduler || o.scheduler,
          denoise: hires.denoise, model: modelRef, positive: ['6', 0], negative: ['7', 0], latent_image: ['11', 0]
        }
      };
      wf['8'].inputs.samples = ['12', 0];
    }
    return wf;
  }

  // ── Anima 三件套 ─────────────────────────────────────────────
  const wf = {
    '1': { class_type: 'UNETLoader', inputs: { unet_name: o.files.unet, weight_dtype: 'default' } },
    '2': { class_type: 'CLIPLoader', inputs: { clip_name: o.files.clip, type: 'stable_diffusion', device: 'default' } },
    '3': { class_type: 'VAELoader', inputs: { vae_name: o.files.vae } },
    '4': { class_type: 'CLIPTextEncode', inputs: { text: positive, clip: ['2', 0] } },
    '5': { class_type: 'CLIPTextEncode', inputs: { text: negative, clip: ['2', 0] } },
    '8': { class_type: 'VAEDecode', inputs: { samples: ['7', 0], vae: ['3', 0] } },
    '9': { class_type: 'SaveImage', inputs: { filename_prefix: 'qq-agent', images: ['8', 0] } }
  };
  const modelRef = attachLoras(wf, ['1', 0]);
  if (o.refImage) Object.assign(wf, refChain(['3', 0]));
  else wf['6'] = { class_type: 'EmptyLatentImage', inputs: { width: o.width, height: o.height, batch_size: 1 } };
  wf['7'] = {
    class_type: 'KSampler',
    inputs: {
      seed: o.seed, steps: o.steps, cfg: o.cfg, sampler_name: o.sampler, scheduler: o.scheduler, denoise,
      model: modelRef, positive: ['4', 0], negative: ['5', 0],
      latent_image: o.refImage ? ['22', 0] : ['6', 0]
    }
  };
  if (hires.enabled) {
    wf['11'] = { class_type: 'LatentUpscaleBy', inputs: { samples: ['7', 0], upscale_method: hires.method, scale_by: hires.scale } };
    wf['12'] = {
      class_type: 'KSampler',
      inputs: {
        seed: o.seed, steps: hires.steps, cfg: o.cfg,
        sampler_name: hires.sampler || o.sampler, scheduler: hires.scheduler || o.scheduler,
        denoise: hires.denoise, model: modelRef, positive: ['4', 0], negative: ['5', 0], latent_image: ['11', 0]
      }
    };
    wf['8'].inputs.samples = ['12', 0];
  }
  return wf;
}

// ══════════════════════════════════════════════════════════════
//  4. 参考图：入口要提供给 refs.js 的宿主接口
// ══════════════════════════════════════════════════════════════
//
// refs.js 只负责"四来源优先级 + 校验"，它**故意不认识**会话存档、找图能力、booru 下载这些
// 只有入口才有的东西 —— 它通过 globalThis[REFS_OWNER_KEY] 回问。下面三个接口就是那扇门：
//   getImageBytes(media, opts)                聊天图的字节/本地缓存
//   characterReference(name, opts[, extra])   角色外观参考（booru，标签已验证才用）
//   keywordReference(keyword, opts[, extra])  关键词找图（宿主的 image.search 能力）
// 注意 ctx 每次调用都不同，所以**每次出图前**重新注册一次（不能只在 setup 里注册一次）。

function registerRefOwner(ctx) {
  const owner = {
    ctx,
    getImageBytes: (media, opts) => ownerGetImageBytes(ctx, media, opts),
    characterReference: (name, opts) => ownerCharacterReference(name, opts),
    keywordReference: (keyword, opts) => ownerKeywordReference(keyword, opts)
  };
  try {
    globalThis[REFS_OWNER_KEY] = owner;
    return owner;
  } catch (error) {
    // 挂不上去就等于"参考图三种来源全废"（refs.js 会返回"技能入口没有注册参考图接口"）。
    // 这种事必须留痕，否则用户只会看到"参考图没用上"而不知道为什么。
    runtime.logger?.error(`参考图桥注册失败（聊天图/角色图/关键词图都会不可用）：${errText(error)}`);
    return null;
  }
}

/** 注册（或确认）参考图桥，并把结果写进日志 —— 排查"参考图为啥没用上"时第一条要看的就是它。 */
function ensureRefOwner(ctx) {
  const owner = registerRefOwner(ctx);
  if (!owner) return null;
  try {
    const live = refs.ownerRef();
    const ok = Boolean(live && typeof live.getImageBytes === 'function' && typeof live.characterReference === 'function');
    runtime.logger?.info(`参考图桥已注册（${REFS_OWNER_KEY}）：getImageBytes/characterReference/keywordReference`
      + `${ok ? '' : '（警告：refs.ownerRef() 没读到，参考图来源会不可用）'}`);
    return owner;
  } catch (error) {
    runtime.logger?.warn(`参考图桥自检失败（不影响出图）：${errText(error)}`);
    return owner;
  }
}

/**
 * 聊天媒体的字节：`get_image` 协议端缓存优先（消息直链有时效，过一阵就 403），
 * 拿不到就交给 refs.js 自己按 media.url 走直链退路（它内部有体积上限与魔数校验）。
 */
async function ownerGetImageBytes(ctx, media, opts) {
  const maxMB = config.intIn(opts?.maxMB, 1, 50, 8);
  const fileId = config.truthyStr(media?.file);
  if (fileId && ctx?.onebot && typeof ctx.onebot.call === 'function') {
    try {
      const ret = await ctx.onebot.call('get_image', { file: fileId });
      const p = config.truthyStr(ret?.file);
      if (p && fs.existsSync(p)) return { file: p };
      // 有的实现只回一个可下载 url：这里把它读成字节（仍然受体积上限约束，走 refs 的下载口）
      const url = config.truthyStr(ret?.url);
      if (url) {
        const got = await refs.downloadImageBytes(url, { maxMB, log: runtime.log });
        if (got?.ok && got.buf?.length) return { buf: got.buf };
        return { reason: got?.reason || '缓存里的这张图取不到' };
      }
    } catch (error) {
      runtime.logger?.warn(`get_image 取聊天图失败（改走直链）：${errText(error)}`);
    }
  }
  return { reason: '' };   // 交给 refs.js 的直链退路
}

/**
 * 角色外观参考图：标签库验证 → dapi 查作品 → 下载候选中最合适的一张。
 *
 * 关键规则（E4/E7 + 旧包实测）：
 *   · **未验证的标签绝不用**（resolveCharacterName 的 verified=false 是"LLM 猜的写法"）；
 *   · 安全等级**绝不放宽**（查询串里的 rating:safe 只是"请求"，dapi 对不认识的限定词会静默忽略，
 *     所以候选必须按解析出来的 rating 再校一遍）；
 *   · 缓存键含全部影响结果的维度（apiBase / tag / safeOnly / minSide / maxMB），不同设置不互相污染。
 */
async function ownerCharacterReference(name, opts) {
  const c = runtime.cfg() || {};
  const maxMB = config.intIn(opts?.maxMB, 1, 50, config.intIn(c.refVisionMaxMB, 1, 50, 8));
  const apiBase = config.truthyStr(c.tagApiUrl) || tags.DEFAULT_TAG_API;
  const safeOnly = config.flag(c.refRatingSafe, true);
  const minSide = config.intIn(c.refMinShortSide, 0, 4096, 512);
  const timeoutMs = config.intIn(c.refSearchTimeoutSec, 5, 180, 40) * 1000;

  const resolved = await tags.resolveCharacterName(name, {
    apiUrl: apiBase,
    hostCfg: runtime.hostCfg,
    settings: c,
    dataDir: runtime.dataDir,
    timeoutMs: 30000,
    log: runtime.log
  });
  const tagName = typeof resolved?.tag === 'string' ? resolved.tag : config.truthyStr(resolved?.tag?.name);
  if (!resolved?.ok || !tagName) {
    return { ok: false, verified: false, reason: resolved?.reason || `拿不到「${name}」的标准角色标签` };
  }
  if (resolved.verified !== true) {
    return {
      ok: false, tag: tagName, verified: false,
      reason: resolved?.reason || `「${name}」的标签没有被标签库确认，不能用来找参考图`
    };
  }

  const cacheKey = `${apiBase}|${tagName}|${safeOnly ? 'safe' : 'any'}|${minSide}|${maxMB}`;
  const st = getState();
  const hit = st.refCache.get(cacheKey);
  if (hit && Date.now() - hit.at < 10 * 60 * 1000) {
    if (hit.value?.file && fs.existsSync(hit.value.file)) {
      runtime.logger?.info(`命中角色参考图缓存：${tagName}`);
      return { ...hit.value, cached: true };
    }
    st.refCache.delete(cacheKey);
  }

  const posts = await booruPostsFor(apiBase, tagName, { safeOnly, timeoutMs });
  if (!posts.ok) return { ok: false, tag: tagName, verified: true, reason: posts.reason };
  if (!posts.list.length) {
    return {
      ok: false, tag: tagName, verified: true,
      reason: `标签库里「${name}」（标签 ${tagName}）${safeOnly ? '没有 rating=safe 的' : '没有'}作品`
    };
  }

  const sized = posts.list.filter((p) => Math.min(p.width, p.height) >= minSide);
  let rated = sized;
  let relaxed = false;
  if (safeOnly) {
    const isSafe = (p) => String(p.rating || '').toLowerCase() === 'safe';
    rated = sized.filter(isSafe);
    if (!rated.length) {
      // 尺寸达标里没有 safe 的 → **只放宽尺寸，安全等级绝不放宽**
      rated = posts.list.filter(isSafe);
      relaxed = true;
    }
    if (!rated.length) {
      return {
        ok: false, tag: tagName, verified: true,
        reason: `「${name}」（标签 ${tagName}）查到的 ${posts.list.length} 张作品里没有 rating=safe 的`
          + '（接口很可能忽略了 rating=safe 限定词）；为保证发到群里的图安全，这次不用参考图'
      };
    }
  } else if (!sized.length) {
    relaxed = true;
  }

  const pool = rated.slice().sort((a, b) => {
    const good = (p) => (p.width / p.height >= 0.5 && p.width / p.height <= 1.6 ? 1 : 0);   // 像人物立绘的优先
    const d = good(b) - good(a);
    if (d !== 0) return d;
    return b.width * b.height - a.width * a.height;
  });

  const dir = refDirOf(c);
  const baseName = `${REF_TEMP_PREFIX}${stampName()}`;
  const problems = [];
  for (const p of pool.slice(0, 5)) {   // booru 偶尔给死链，多试几张
    const got = await refs.downloadImageBytes(p.url, { maxMB, timeoutMs, log: runtime.log });
    if (!got?.ok || !got.buf?.length) { problems.push(got?.reason || '下载失败'); continue; }
    const dest = path.join(dir, `${baseName}${safeExt(got.ext, magicExt(got.buf)) || '.png'}`);
    const w = writeFileAtomic(dest, got.buf);
    if (!w.ok) { problems.push(`落盘失败：${w.reason}`); continue; }
    const value = {
      ok: true,
      file: dest,
      width: p.width,
      height: p.height,
      rating: p.rating,
      tag: tagName,
      verified: true,
      candidates: pool.length,
      relaxed,
      source: `safebooru/${tagName}`,
      reason: ''
    };
    if (st.refCache.size >= 60) { const oldest = st.refCache.keys().next().value; if (oldest !== undefined) st.refCache.delete(oldest); }
    st.refCache.set(cacheKey, { at: Date.now(), value });
    runtime.logger?.info(`角色参考图 ${tagName}：${p.width}x${p.height}｜rating=${p.rating}｜候选 ${pool.length} 张`);
    return value;
  }
  return {
    ok: false, tag: tagName, verified: true,
    reason: `「${name}」的候选图（${pool.length} 张）全部下载失败${problems.length ? `：${R(problems[0])}` : ''}`
  };
}

/** 参考图落盘目录：优先用 refs.js 的判定口径（settings.refImageDir → data/ref-images）。 */
function refDirOf(c) {
  const custom = config.truthyStr(c?.refImageDir);
  const dir = custom || path.join(runtime.dataDir || '.', 'ref-images');
  try { fs.mkdirSync(dir, { recursive: true }); } catch { /* 建不出来时下面的原子写会给出真实原因 */ }
  return dir;
}

/**
 * 查 dapi 作品并解析候选（先 solo 收紧到单角色，没有再放宽）。
 * 走 comfy.fetchWithTimeout + readBodyLimited（E5：所有响应读取都带上限与超时）。
 */
async function booruPostsFor(apiBase, tagName, { safeOnly, timeoutMs }) {
  const ratingFilter = safeOnly ? ' rating:safe' : '';
  const queries = [`${tagName} solo${ratingFilter}`, `${tagName}${ratingFilter}`];
  let lastReason = '';
  for (const q of queries) {
    let text = '';
    try {
      const url = `${apiBase}?page=dapi&s=post&q=index&limit=40&tags=${encodeURIComponent(q)}`;
      const resp = await comfy.fetchWithTimeout(url, {
        method: 'GET',
        headers: { 'User-Agent': 'QQAgent/1.0', Accept: 'application/xml,text/xml,*/*' }
      }, timeoutMs, runtime.log);
      if (!resp || resp.__error) { lastReason = `标签库请求失败（${R(resp?.__error || '没有响应')}）`; continue; }
      if (!resp.ok) { lastReason = `标签库 HTTP ${resp.status}`; continue; }
      const body = await comfy.readBodyLimited(resp, 16 * 1024 * 1024, '标签库响应');
      if (!body?.ok) { lastReason = R(body?.reason || '标签库响应读取失败'); continue; }
      text = body.buf.toString('utf8');
    } catch (error) {
      lastReason = `查角色作品失败（网络或超时）：${errText(error)}`;
      continue;
    }
    // 形状校验（与 lib/tags.js 同一口径）：dapi 的**合法空结果**长 `<?xml …?><posts count="0"/>`，
    // 里面只有 `<posts>`、没有 `<post `。所以"有没有 <posts 根节点"才是数据合法的判据；
    // 一个限流/验证 HTML 页两样都没有 → 判为**服务异常**（免得把限流说成"这个角色没有作品"）。
    if (!/<posts\b/i.test(text) && !/<post[\s/>]/i.test(text)) {
      lastReason = '标签库返回了非预期内容（可能是镜像限流/验证页），不是作品数据';
      continue;
    }
    const list = parseBooruPosts(text);
    if (list.length) return { ok: true, list, query: q };
  }
  if (lastReason) return { ok: false, list: [], reason: lastReason };
  return { ok: true, list: [] };
}

/**
 * `<post ... />` → 候选数组。
 * 属性名**必须带边界**：裸 `width="` 会命中 `sample_width="`（旧包实测因此静默取到错的尺寸，
 * 尺寸错了短边筛选与参考图比例跟着错，且一声不响）。
 */
function parseBooruPosts(xml) {
  const out = [];
  for (const m of String(xml).matchAll(/<post\b[^>]*\/?>/gi)) {
    const t = m[0];
    const g = (k) => new RegExp(`(?:^|\\s)${k}="([^"]*)"`, 'i').exec(t)?.[1] || '';
    const fileUrl = g('file_url');
    const url = fileUrl || g('sample_url');
    if (!url || !/^https?:\/\//i.test(url)) continue;
    const w = Number(fileUrl ? g('width') : g('sample_width')) || 0;
    const h = Number(fileUrl ? g('height') : g('sample_height')) || 0;
    if (!(w > 0 && h > 0)) continue;
    out.push({ url, width: w, height: h, rating: g('rating'), viaSample: !fileUrl });
  }
  return out;
}

/**
 * 关键词找图：走宿主能力 `image.search`（「智能配图」技能提供）。
 * 软依赖：能力不在就返回可读原因，主链路降级成纯文生图，绝不因此让整个技能不可用。
 */
async function ownerKeywordReference(keyword, opts) {
  const c = runtime.cfg() || {};
  const count = config.intIn(c.refSearchCount, 1, 12, 6);
  const minShortSide = config.intIn(c.refMinShortSide, 0, 4096, 512);
  const timeoutSec = config.intIn(c.refSearchTimeoutSec, 5, 180, 40);

  if (typeof runtime.capability !== 'function' || typeof runtime.hasCapability !== 'function') {
    return { ok: false, reason: '当前宿主没有提供「找图能力」接口，这次按纯文字画' };
  }
  if (!runtime.hasCapability(IMAGE_SEARCH_CAP)) {
    return { ok: false, reason: '没装/没开「智能配图」技能（找图能力 image.search 由它提供），这次按纯文字画' };
  }

  let cap;
  try { cap = runtime.capability(IMAGE_SEARCH_CAP, { keyword, count, minShortSide }); }
  catch (error) { return { ok: false, reason: `找图能力调用失败：${errText(error)}` }; }
  if (!cap) return { ok: false, reason: '找图能力没有返回结果，这次按纯文字画' };

  let r;
  try { r = await withTimeout(Promise.resolve(cap), timeoutSec * 1000, '找参考图超时'); }
  catch (error) { return { ok: false, reason: errText(error) }; }
  if (!r || typeof r !== 'object') return { ok: false, reason: '找图能力返回了意外的结果' };
  if (!r.ok) return { ok: false, reason: R(r.error || (r.errors || []).join('；') || '图源没有可用结果') };

  const usable = (r.images || []).filter((im) => im?.file && fs.existsSync(im.file));
  if (!usable.length) return { ok: false, reason: '找图能力没有返回可用的本地文件' };

  const sized = usable.filter((im) => Math.min(Number(im.width) || 0, Number(im.height) || 0) >= minShortSide);
  const pool = (sized.length ? sized : usable).slice();
  // pixiv 优先：ACG 关键词下搜索引擎给的"原图"经常是**带字幕的 AI 图**，
  // 字幕会被 img2img 忠实复现成乱码字母（旧包实测），pixiv 是真人插画，没有这层水印。
  const isPixiv = (im) => /pixiv/i.test(String(im.source || '')) || /pixiv/i.test(String(im.url || ''));
  pool.sort((a, b) => {
    const pa = isPixiv(a) ? 1 : 0;
    const pb = isPixiv(b) ? 1 : 0;
    if (pa !== pb) return pb - pa;
    return (Number(b.width) * Number(b.height)) - (Number(a.width) * Number(a.height));
  });
  const best = pool[0];
  return {
    ok: true,
    file: best.file,
    width: Number(best.width) || 0,
    height: Number(best.height) || 0,
    source: String(best.source || best.url || ''),
    candidates: usable.length,
    relaxed: sized.length === 0 && minShortSide > 0,
    reason: ''
  };
}

// ══════════════════════════════════════════════════════════════
//  5. 参考图送进 ComfyUI（/upload/image，退回复制到 input）
// ══════════════════════════════════════════════════════════════

/**
 * 把本地参考图交给 ComfyUI，返回 LoadImage 节点要填的 image 名。
 *
 * 两条路（① 失败才走 ②，文案按**实际走了哪条**写，E4）：
 *   ① `POST /upload/image`：不依赖"本技能知不知道 ComfyUI 装在哪"，远端 ComfyUI 也能用；
 *   ② 复制进 `<ComfyUI 根>\input\`：某些版本/前置代理会把 multipart 挡掉。
 * 落进 ComfyUI input 的副本一律用 qdraw_ref_ 前缀 —— 清理时只认自己这个前缀（E11）。
 */
async function stageReferenceForComfy(refFile, c, base) {
  const maxMB = config.intIn(c.refVisionMaxMB, 1, 50, 8);
  const maxBytes = maxMB * 1024 * 1024;
  let buf;
  try {
    const st = fs.statSync(refFile);
    if (!st.isFile() || !st.size) return { ok: false, reason: '参考图不是普通文件或为空' };
    if (st.size > maxBytes) return { ok: false, reason: `参考图 ${(st.size / 1048576).toFixed(1)}MB，超过上限 ${maxMB}MB` };
    buf = fs.readFileSync(refFile);
  } catch (error) {
    return { ok: false, reason: `读参考图失败：${logLib.describeFsError(error)}` };
  }
  if (!buf.length) return { ok: false, reason: '参考图是空文件' };
  const ext = safeExt(path.extname(refFile), magicExt(buf) || '.png');
  const name = `${REF_TEMP_PREFIX}${stampName()}${ext}`;

  // ① 官方上传接口
  try {
    if (typeof FormData === 'function' && typeof Blob === 'function') {
      const form = new FormData();
      form.append('image', new Blob([buf]), name);
      form.append('overwrite', 'true');
      const resp = await comfy.fetchWithTimeout(`${base}/upload/image`, { method: 'POST', body: form }, 60000, runtime.log);
      if (resp && resp.ok) {
        const j = await resp.json().catch(() => null);
        const gotName = config.truthyStr(j?.name);
        if (gotName) {
          const ref = config.truthyStr(j?.subfolder) ? `${config.truthyStr(j.subfolder)}/${gotName}` : gotName;
          return { ok: true, ref, how: 'upload' };
        }
        runtime.logger?.warn('/upload/image 返回 200 但没给文件名，改用复制到 input 目录');
      } else if (resp) {
        runtime.logger?.warn(`/upload/image HTTP ${resp.status}，改用复制到 input 目录`);
      } else {
        runtime.logger?.warn(`/upload/image 没有响应（${R(resp?.__error || '未知')}），改用复制到 input 目录`);
      }
    } else {
      runtime.logger?.warn('运行环境没有 FormData/Blob，跳过上传接口，直接复制到 input 目录');
    }
  } catch (error) {
    runtime.logger?.warn(`/upload/image 失败（${errText(error)}），改用复制到 input 目录`);
  }

  // ② 退路：复制进 input 目录（先 .part 再 rename，E12）
  let layout = null;
  try { layout = comfy.comfyLayout(config.truthyStr(c.comfyuiDir)); } catch { layout = null; }
  const roots = uniqStr([layout?.appDir, layout?.root]);
  const candidates = [];
  for (const r of roots) {
    candidates.push(path.join(r, 'input'));
    candidates.push(path.join(r, 'ComfyUI', 'input'));
  }
  const inputDir = uniqStr(candidates).find((p) => { try { return fs.existsSync(p); } catch { return false; } });
  if (!inputDir) {
    return {
      ok: false,
      reason: '上传参考图失败，也没找到 ComfyUI 的 input 目录'
        + (roots.length ? '' : '（技能设置里没填「ComfyUI 安装目录」，无法退回复制方案）')
    };
  }
  const dest = path.join(inputDir, name);
  const w = writeFileAtomic(dest, buf);
  if (!w.ok) return { ok: false, reason: `复制参考图到 input 目录失败：${w.reason}` };
  return { ok: true, ref: name, how: 'copy' };
}

// ══════════════════════════════════════════════════════════════
//  6. 自己产生的临时文件清理（E11）
// ══════════════════════════════════════════════════════════════

function listFilesWithMtime(dir) {
  const out = [];
  let names = [];
  try { names = fs.readdirSync(dir); } catch { return out; }
  for (const n of names) {
    const full = path.join(dir, n);
    try {
      const st = fs.statSync(full);
      if (st.isFile()) out.push({ name: n, full, mtimeMs: st.mtimeMs });
    } catch { /* 单个文件读不到 stat 就跳过，不影响其它文件 */ }
  }
  return out;
}

/** 本技能可能留下临时文件的目录（ComfyUI input 也在内：那里的副本是我们放进去的）。 */
function ownTempDirs(c) {
  const dirs = [path.join(runtime.dataDir || '.', 'ref-images'), path.join(runtime.dataDir || '.', 'comfyui-images')];
  const outDir = config.truthyStr(c?.outputDir);
  if (outDir) dirs.push(outDir);
  try {
    const layout = comfy.comfyLayout(config.truthyStr(c?.comfyuiDir));
    for (const r of uniqStr([layout?.appDir, layout?.root])) dirs.push(path.join(r, 'input'));
  } catch { /* 布局探测失败就只清 data 下的两处 */ }
  return uniqStr(dirs);
}

/**
 * 清理**只属于自己**的旧临时文件：前缀 qdraw_ + 保留策略（最近 N 个 / D 天）。
 *
 * 三条硬约束（E11）：
 *   · 只动 `qdraw_*` —— ComfyUI input 里用户自己放的图、别的技能的文件一个字都不碰；
 *   · **绝不删刚发出的那张**（protectPath），否则用户点开消息里那张图会 404；
 *   · 任何失败只 warn，绝不向上抛 —— 收尾动作不能把一张已经发出去的图变成"失败"。
 * `refKeepDays = 0` 是**有效值**：表示关掉"按天删"，只按个数保留（E3）。
 */
function cleanupOwnTempFiles(c, protectPath) {
  try {
    const keepFiles = config.intIn(c?.refKeepFiles, 1, 5000, 100);
    const keepDays = config.intIn(c?.refKeepDays, 0, 365, 7);
    const deadline = keepDays > 0 ? Date.now() - keepDays * 24 * 60 * 60 * 1000 : 0;
    const protect = protectPath ? path.resolve(protectPath) : '';
    let removed = 0;
    for (const dir of ownTempDirs(c)) {
      const rows = listFilesWithMtime(dir).filter((f) => f.name.startsWith(TEMP_PREFIX));
      if (!rows.length) continue;
      rows.sort((a, b) => b.mtimeMs - a.mtimeMs);   // 新的在前，下标就是"保留名额"
      rows.forEach((f, i) => {
        if (protect && path.resolve(f.full) === protect) return;     // 刚发出的那张（E11）
        const tooOld = deadline > 0 && f.mtimeMs < deadline;
        if (!tooOld && i < keepFiles) return;
        try { fs.unlinkSync(f.full); removed += 1; }
        catch (error) { runtime.logger?.warn(`清理旧临时文件失败（${f.name}）：${logLib.describeFsError(error)}`); }
      });
    }
    if (removed) {
      runtime.logger?.info(`已清理 ${removed} 个自己产生的旧临时文件（保留最近 ${keepFiles} 个 / ${keepDays} 天；只动 ${TEMP_PREFIX}*）`);
    }
    return removed;
  } catch (error) {
    runtime.logger?.warn(`清理旧临时文件失败（不影响出图）：${errText(error)}`);
    return 0;
  }
}

// ══════════════════════════════════════════════════════════════
//  7. 模型下拉同步 + 目录监听（E9）
// ══════════════════════════════════════════════════════════════

// 技能自己的 skill.json。安装脚本会**覆盖**它，所以"启动时该不该扫"的判据必须绑到这个文件的实际状态，
// 而不是"这个进程扫过一次了"（见 bootScanDecision 的注释：那个判据会让重装后的空下拉永远填不上）。
const SELF_SKILL_JSON = path.join(HERE, 'skill.json');
// 参与"下拉是否就绪"判断的模型键（与 lib/models.js 的 SYNC_SPECS 同一批）。
// LoRA 槽位（lora1~5）不写在这里 —— 它们从 models.LORA_SLOTS 动态取，见 modelEnumKeys()。
const MODEL_ENUM_KEYS = ['animaUnet', 'animaClip', 'animaVae', 'animaTurboLora', 'checkpoint'];

/** 参与判定的全部键：模型五类 + 库里的 LoRA 槽位（去重）。 */
function modelEnumKeys() {
  const slots = loraSlots().map((s) => s.slot);
  return slots.length ? uniqStr([...MODEL_ENUM_KEYS, ...slots]) : MODEL_ENUM_KEYS.slice();
}

/** 候选数：`""` **不算候选**（LoRA 槽用它表示"这个槽不用"）。 */
function countCandidates(values) {
  return Array.isArray(values) ? values.filter((v) => config.truthyStr(v)).length : 0;
}

/** 单个文件的轻量指纹 `大小:mtime`；读不到给 `-`（当作"变了"，宁可扫一次）。 */
function fileStamp(p) {
  try {
    const s = fs.statSync(p);
    return `${s.size}:${Math.round(s.mtimeMs)}`;
  } catch { return '-'; }
}

/** skill.json 自己的指纹（保留这个单项查询，便于排查"到底是谁变了"）。 */
function skillJsonFingerprint() {
  return fileStamp(SELF_SKILL_JSON);
}

/**
 * **技能自身状态**的指纹：`skill.json` + `index.js` + `lib/` 下所有 `.js` 的 `大小:mtime`。
 *
 * 为什么必须包含**代码**（真机上踩到的最后一个缺口）：安装是**逐文件写入**的 ——
 * `index.js` 一落盘宿主就热重载，那一刻 `lib/models.js` 可能还是旧版（比如旧版不写 LoRA 槽），
 * 于是这次扫描只填了模型五类，却把指纹记成"已扫"；等新版 `models.js` 落盘时，
 * 只比 `skill.json` 的老指纹 → "未变" → **永不重扫** → 5 个 LoRA 槽一直停在 `[""]`。
 * 把代码纳入指纹后：代码一变就必须重扫 ✓，而"我们自己写 skill.json"那一轮仍会被正确跳过
 * （见 bootScanDecision 的防自激说明）。
 *
 * 返回值带**分项**（不是拼成一个不可读的长串），这样日志能说清"到底谁变了"。
 */
function skillStateMap() {
  const map = {};
  map['skill.json'] = fileStamp(SELF_SKILL_JSON);
  map['index.js'] = fileStamp(path.join(HERE, 'index.js'));
  let files = [];
  try { files = fs.readdirSync(path.join(HERE, 'lib')).filter((f) => f.endsWith('.js')).sort(); } catch { files = []; }
  for (const f of files) map[`lib/${f}`] = fileStamp(path.join(HERE, 'lib', f));
  return map;
}

/** 状态映射 → 一个可比较的短串（存进 globalThis 的用户态里，不落盘）。 */
function skillStateFingerprint(map = skillStateMap()) {
  return Object.keys(map).sort().map((k) => `${k}=${map[k]}`).join('|');
}

/**
 * 读一遍 skill.json 里"模型下拉"的状态：哪些键**一个候选都没有**、哪些键的当前值已不在候选里。
 *
 * `emptyKeys` 用的是"候选数 = 0"（把 `""` 排除在外）：这样 LoRA 槽从 `['', 'real_skin']` 变成 `['']`
 * （候选被清掉）也能被识别成"从有到空"，而不是被当成"非空"漏过去。
 */
function readModelEnumState() {
  const emptyKeys = [];
  const staleKeys = [];
  try {
    const j = JSON.parse(fs.readFileSync(SELF_SKILL_JSON, 'utf8').replace(/^\uFEFF/, ''));
    const schema = j?.configSchema && typeof j.configSchema === 'object' ? j.configSchema : {};
    const settings = j?.settings && typeof j.settings === 'object' ? j.settings : {};
    for (const key of modelEnumKeys()) {
      const raw = schema?.[key]?.values;
      const values = Array.isArray(raw) ? raw.map(String) : null;
      if (values && countCandidates(values) === 0) emptyKeys.push(key);
      // "值不在候选里"只查模型五类：LoRA 槽的值按设计会被 syncSchema **保留**（SYNC_PRESERVE_KEYS），
      // 拿它当"必须重扫"的理由只会每次重载白扫一遍；槽里指向已删文件的情况由出图时的 L2 说明负责。
      const cur = config.truthyStr(settings[key]);
      if (MODEL_ENUM_KEYS.includes(key) && cur && values && values.length && !values.includes(cur)) staleKeys.push(key);
    }
    return { readOk: true, emptyKeys, staleKeys };
  } catch {
    return { readOk: false, emptyKeys, staleKeys };
  }
}

/**
 * 启动扫描该不该做 —— 判据绑到 **技能自身的实际状态**（skill.json + index.js + lib/*.js）。
 *
 * 为什么不能"每进程只扫一次"（真机踩到的 bug）：安装脚本先写 index.js/lib（触发热重载 → 我们扫一次、
 * 记下"扫过了"），**然后**才把 skill.json 覆盖成包内那份干净副本（下拉全空）——
 * 于是那个挂在 globalThis、跨热重载存活的守卫把之后的启动扫描全挡掉，下拉永远是空的。
 * 为什么指纹还必须包含**代码**：见 skillStateMap 的注释（逐文件安装 + 热重载的必然坑）。
 *
 * 必须扫的理由（任一条成立）：
 *   ① 本进程还没尝试过启动扫描（`bootCount` 为空）—— 进程刚起来，先扫一次；
 *   ② 没有上次扫描记录；
 *   ③ 状态变过：`skill.json` 变过 / **代码变过（index.js、lib/models.js …）**（逐项列出来）；
 *   ④ **下拉"从有到空"**（上次还有候选的键这次一个候选都没有）—— 安装覆盖的典型指纹；
 *   ⑤ 某个模型键的当前值非空、但不在它的候选里（选项换了，设置里还留着旧值）。
 * 全部不成立才跳过。
 *
 * ⚠️ 为什么"某个键候选为空"**不能单独**当成必须重扫的理由：本机某类模型确实一个都没有时，
 * models.js 会如实写 `values: []` / `['']`（并带 `reliable:true`），那是**正常状态**；
 * 若一律当可疑，每次外部重载都会白扫一遍。所以只有"**从有到空**"才可疑。
 *
 * 防自激（**没有**丢掉）：状态在**每次成功同步之后**重新记录（见 syncSchemaOnce），
 * 所以"我们写 skill.json → 宿主重载"那一轮，指纹与记录一致 → 跳过 ✓；
 * 即使某次真的多扫一遍，因为 models.syncSchema 只在**内容变化**时写盘，也不会形成循环（自测③专门断言了这点）。
 */
function bootScanDecision() {
  const st = getState();
  const map = skillStateMap();
  const prev = st.lastScanState && typeof st.lastScanState === 'object' ? st.lastScanState : null;
  const snap = readModelEnumState();
  const reasons = [];

  if (st.bootCount == null) reasons.push('进程刚启动，先扫一次');
  else if (!prev) reasons.push('还没有扫描记录');

  if (prev) {
    const prevFiles = prev.files && typeof prev.files === 'object' ? prev.files : null;
    // 兼容早先只存了单个 fingerprint 的记录：那次记录不能用来判断"变没变"，当成"没有可用记录"
    const changed = prevFiles
      ? Object.keys(map).filter((k) => prevFiles[k] !== map[k]).concat(
        Object.keys(prevFiles).filter((k) => !(k in map)))
      : [];
    if (changed.length) {
      const settingsChanged = changed.filter((k) => k === 'skill.json');
      const codeChanged = changed.filter((k) => k !== 'skill.json');
      const bits = [];
      if (settingsChanged.length) bits.push('skill.json 变过');
      if (codeChanged.length) bits.push(`代码变过（${codeChanged.join('、')}）`);
      reasons.push(bits.join('；'));
    } else if (!prevFiles && st.bootCount != null) {
      reasons.push('上次记录里没有文件状态（老版本记的）');
    }
  }

  if (snap.readOk) {
    const prevEmpty = new Set(prev && Array.isArray(prev.emptyKeys) ? prev.emptyKeys : []);
    const grew = snap.emptyKeys.filter((k) => !prevEmpty.has(k));
    if (grew.length && prev) reasons.push(`下拉从有到空（${grew.join('、')}）`);
    else if (grew.length) reasons.push(`下拉是空的（${grew.join('、')}）`);
    if (snap.staleKeys.length) reasons.push(`设置里的值不在选项里（${snap.staleKeys.join('、')}）`);
  } else {
    reasons.push('skill.json 读不出来');
  }
  return { scan: reasons.length > 0, reasons, files: map, fingerprint: skillStateFingerprint(map), emptyKeys: snap.emptyKeys };
}

/**
 * 扫一遍并按**内容是否变化**决定要不要写 skill.json（判定在 models.syncSchema 里，E9）。
 *
 * 刻意**不传 force**：写不写盘只能由"内容变了"决定；显式 rescan 也用同一个入口，
 * 这样"检查点扫描/工具调用/启动扫描"三条路的行为完全一致。
 */
async function syncSchemaOnce(c, { source }) {
  const st = getState();
  if (st.schemaSyncing) return { ok: false, changed: false, reason: '正在刷新', busy: true };
  st.schemaSyncing = true;               // try/finally：任何分支都要复位（E13）
  try {
    // 用磁盘上最新的 models.js（热重载只换 index.js 时，静态那份可能是旧实例 → LoRA 槽刷不出来）
    const M = await refreshModelsNs();
    const base = baseUrlOf(c);
    // 把**真实的模型目录集**一起传下去：syncSchema 内部默认只扫 <skill>/models + /object_info，
    // 那样 ComfyUI 没开时"新放进 ComfyUI\models\ 的模型"永远刷不出来（§2 第 3 条要的正是它离线也能认）。
    logModelDirs(modelDirsOf(c), source);
    const r = await M.syncSchema(base, { dirs: modelDirsOf(c) });
    const out = r && typeof r === 'object' ? r : { ok: false, changed: false, reason: '同步没有返回结果' };
    if (out.scan) st.lastScan = out.scan;
    // 状态在**同步之后**记：写盘会把 mtime 改掉，记"写之前"的指纹等于下次重载必然判"变过"→ 自激。
    // 注意"扫描了但没写盘"这条路也要记（`out.ok` 就记）：否则每次重载都会因为同一个理由重扫。
    if (out.ok) {
      const map = skillStateMap();
      st.lastScanState = { files: map, fingerprint: skillStateFingerprint(map), emptyKeys: readModelEnumState().emptyKeys };
    }
    if (out.ok && out.changed) runtime.logger?.info(`${source}：模型下拉已更新（${R(out.reason)}）`);
    else if (!out.ok) runtime.logger?.warn(`${source}：模型下拉未更新（${R(out.reason)}）`);
    else runtime.logger?.debug(`${source}：模型清单没变，未写盘`);
    return out;
  } catch (error) {
    runtime.logger?.warn(`${source}：扫描/同步失败（${errText(error)}）`);
    return { ok: false, changed: false, reason: `扫描/同步失败：${errText(error)}` };
  } finally {
    st.schemaSyncing = false;
  }
}

/**
 * 目录监听：新增/删除模型后自动刷新下拉（§2 第 3 条）。
 *
 * E9 的两条重点都在这里：
 *   · **防抖 + 同一内容不重复回调**由 models.watchModelDirs 负责（它比内容签名）；
 *   · 回调里**只调一次 syncSchema，绝不再自己扫一遍**（写盘后再触发扫描 = 自激），
 *     而且用 schemaSyncing 保证同一时刻只有一次"扫描→可能写盘"。
 */
function startModelWatch(c) {
  const st = getState();
  if (st.watcher) { try { st.watcher.stop(); } catch { /* 旧监听器已经关掉也是无害的 */ } st.watcher = null; }
  if (!config.flag(c?.watchModels, true)) {
    runtime.logger?.info('模型目录自动监听是关掉的（要新增模型后自动刷新下拉就打开「自动监听模型目录」，或手动 rescan）');
    return null;
  }
  const dirs = modelDirsOf(c);
  // 具名映射 → 只留真实存在的目录（不存在的不监听；models.js 自己也会跳过）
  const existing = dirsForLog(dirs).filter((d) => { try { return fs.existsSync(d); } catch { return false; } });
  if (!existing.length) {
    runtime.logger?.info('模型目录监听未启用：没有可监听的目录（填了「ComfyUI 安装目录」后重启技能即可）');
    return null;
  }
  const debounceMs = config.intIn(c?.watchDebounceMs, 1000, 600000, 1500);
  try {
    // 传**真实的模型子目录**（diffusion_models / checkpoints / …），而不是安装根：
    // 这样 ComfyUI 没开时"丢一个 .safetensors 进 models\ 就刷新下拉"照样成立（§2 第 3 条）。
    st.watcher = models.watchModelDirs(dirs, (evt) => { void onModelDirsChanged(evt); }, { debounceMs, log: runtime.log });
    // 排障用两行：① 按要求给出脱敏后的绝对路径；② 去掉盘符/用户目录的尾部（脱敏不会吃掉它，能真的核对）
    runtime.logger?.info(`已开始监听模型目录（防抖 ${debounceMs}ms，${existing.length} 个目录）`
      + `｜监听目录：${existing.map((p) => R(p)).join(' ｜ ')}`);
    runtime.logger?.info(`监听目录明细（尾部片段，脱敏后仍可核对）：${existing.map((p) => dirTail(p)).join(' ｜ ')}`);
  } catch (error) {
    runtime.logger?.warn(`模型目录监听启动失败（不影响出图，可以用 rescan）：${errText(error)}`);
    st.watcher = null;
  }
  return st.watcher;
}

/**
 * 监听回调：只做"再同步一次下拉"，**不再额外扫描**（E9 防自激）。
 *
 * 日志分三层，便于判断"监听到底有没有触发过 / 触发了但内容没变"：
 *   · 收到事件 → DEBUG「收到监听事件」（models.watchModelDirs 只在**内容签名真的变了**时才回调）
 *   · 扫完发现清单没变 → DEBUG「模型清单没变，未写盘」
 *   · 清单变了并写盘 → INFO「下拉已更新」
 */
async function onModelDirsChanged(evt) {
  const st = getState();
  const dirCount = Array.isArray(evt?.dirs) ? evt.dirs.length : 0;
  if (st.schemaSyncing) {
    runtime.logger?.debug(`模型目录有变化：收到监听事件，但正在刷新中，本次跳过（目录 ${dirCount} 个）`);
    return;
  }
  runtime.logger?.debug(`模型目录有变化：收到监听事件（目录 ${dirCount} 个），开始重新扫描`);
  const c = runtime.cfg() || {};
  const r = await syncSchemaOnce(c, { source: '模型目录有变化' });
  if (r?.changed) runtime.logger?.info('模型目录有变化：模型清单变了，设置里的下拉已更新');
  else if (r?.ok) runtime.logger?.debug('模型目录有变化：模型清单没变，未写盘');
}

/**
 * 启动扫描：**判据是 skill.json 的实际状态**（见 bootScanDecision），不是"每进程一次"。
 * 注意状态里那个 `bootScanned` 已经不用了（它挂 globalThis、跨热重载存活，正是重装后空下拉的成因）。
 */
async function bootScan() {
  const st = getState();
  // 先确认手里的 models.js 是磁盘上那份（热重载可能留了旧实例）——**必须早于** bootScanDecision()：
  // 判定要用 loraSlots() 列出 LoRA 槽，晚刷新就会先按派生槽位说一句"取不到"，日志噪音且误导。
  await refreshModelsNs();
  const d = bootScanDecision();
  // 记"本进程试过启动扫描了"：`null → 数字` 之后，同一进程里的热重载就只按指纹/空集判断（防自激的关键）
  st.bootCount = (Number.isFinite(Number(st.bootCount)) ? Number(st.bootCount) : 0) + 1;
  if (!d.scan) {
    // 措辞跟着判据走：现在比的是"技能自身状态"（skill.json + index.js + lib/*.js），不再只是 skill.json
    const why = '技能自身状态没变（skill.json 与 index.js／lib/*.js 的（大小, mtime）都与上次扫描后一致）';
    runtime.logger?.info(`启动扫描：跳过（${why}）`);
    return { ok: true, skipped: true, changed: false, reason: why };
  }
  runtime.logger?.info(`启动扫描：执行（${d.reasons.join('；')}）`);
  const r = await syncSchemaOnce(runtime.cfg() || {}, { source: '启动扫描' });
  // 失败（ComfyUI 没开等）不记状态 → 下次重载/工具调用还有机会补扫
  return r;
}

// ══════════════════════════════════════════════════════════════
//  8. 队列 / 冷却
// ══════════════════════════════════════════════════════════════

function enqueue(task) {
  const st = getState();
  st.queuePending += 1;
  const run = st.queueTail.then(task, task);
  st.queueTail = run.then(() => {}, () => {});
  return run.finally(() => { st.queuePending -= 1; });   // 进出都记账，finally 保证复位（E13）
}

function queueDepth() {
  return getState().queuePending;
}

// ══════════════════════════════════════════════════════════════
//  9. 工具提示词库（本地 1100+ 概念）
// ══════════════════════════════════════════════════════════════

function libCategories(lib) {
  const cats = Array.isArray(lib?.categories) && lib.categories.length
    ? lib.categories
    : (Array.isArray(lib?.meta?.categories) ? lib.meta.categories : []);
  return cats.map((c) => ({ id: String(c?.id ?? ''), name: String(c?.name ?? c?.id ?? ''), n: Number(c?.n ?? (Array.isArray(c?.concepts) ? c.concepts.length : 0)) || 0, domain: String(c?.domain || 'descriptive') }));
}

function formatLibraryHits(r, query, category) {
  const hits = Array.isArray(r?.hits) ? r.hits : [];
  const cats = Array.isArray(r?.categories) ? r.categories : [];
  if (!hits.length) {
    const list = cats.map((c) => `${c.id}（${c.name}）`).join('、');
    return `提示词库里没找到「${query || category}」。\n可用的类目有：${list || '（库未加载）'}\n换关键词，或用 category 参数按类目查。`;
  }
  const verified = r?.verified instanceof Set ? r.verified : null;
  const total = Number(r?.total) || hits.length;
  const lines = [`提示词库里查到 ${total} 条${total > hits.length ? `（下面显示前 ${hits.length} 条）` : ''}：`, ''];
  for (const h of hits) {
    const domain = String(h.domain || 'descriptive');
    lines.push(`【${h.zh || ''}】  ${h.cat || ''} · ${h.catName || ''}${domain === 'convention' ? '（提示词约定类）' : ''}`);
    const tagList = Array.isArray(h.tags) ? h.tags : [];
    if (tagList.length) {
      const marked = tagList.map((t) => (domain === 'convention' || !verified ? t : (verified.has(t) ? `${t}✓` : t)));
      lines.push(`  标签（写进 SDXL / Illustrious 档的 prompt）：${marked.join(', ')}`);
    } else {
      lines.push('  标签：无（本概念的候选写法都没通过标签库核对，见下）');
    }
    if (h.en) lines.push(`  自然语言（写进 Anima 档的 prompt）：${h.en}`);
    if (Array.isArray(h.alt) && h.alt.length) {
      lines.push(`  备用写法（标签库里查不到，仍可能有效，谨慎使用）：${h.alt.join(', ')}`);
    }
    lines.push('');
  }
  if (hits.some((h) => String(h.domain || '') === 'descriptive')) lines.push('（✓ = 该标签已核对过标签库，写法可靠）');
  if (hits.some((h) => String(h.domain || '') === 'convention')) lines.push('（提示词约定类：标签库不收录这类词，所以没有 ✓，但这是模型官方推荐的写法）');
  if (hits.some((h) => !(Array.isArray(h.tags) && h.tags.length))) lines.push('（有概念的标签为空：它的候选写法都没通过核对，此时优先用上面的自然语言描述）');
  return lines.join('\n');
}

/**
 * 词库增强：从提示词里**确定性地**捞出库中概念，补上更准确的写法。
 *
 * 为什么是确定性字符串匹配而不是再问一次 LLM：用户原话里出现「雨天」是纯判断，准确、免费、不增加往返；
 * 而写法错了等于白写（模型不认识那个词）。形态按家族选：SDXL 吃标签串，Anima 吃自然语言 —— 加错反而有害。
 * 默认关（`promptLibraryAuto`），因为它会改写用户自己写的描述。
 *
 * ⚠️ **匹配口径：只认中文**（`row.zh`，逐条 `text.includes(zh)`）。传进来的 `promptText` 是**翻译前**的原文，
 * 所以：
 *   · 中文输入 → 能命中（库里的概念键就是中文说法，「雨天」「回眸」这类）；
 *   · **纯英文输入 → 一定一条都匹配不到**（`hasCJK` 为假、不会走翻译，原文里没有中文概念词）。
 * 也就是说英文输入时这个功能是**静默不生效**的 —— 这是设计取舍（不拿英文去反查中文库，避免瞎命中），
 * 但必须留下可查的痕迹：开了增强却没命中且输入不含中文时，打一条日志说明"不是没命中，是口径如此"。
 */
function enrichFromLibrary(promptText, c, family) {
  const empty = { matched: [], added: [] };
  if (config.flag(c?.promptLibraryAuto, false) !== true) return empty;
  // 候选路径由本文件给出（新 id 的 data 目录优先，**旧 id 的继续留着**，再接库自己的名单）
  const lib = library.loadLibrary({ dataDir: runtime.dataDir, paths: libraryPathsFor(runtime.dataDir) });
  const rows = Array.isArray(lib?.rows) ? lib.rows : [];
  if (!rows.length) return empty;
  const text = String(promptText || '');
  const maxTags = config.intIn(c?.promptLibraryMaxTags, 1, 30, 8);
  const isTagStyle = family === 'sdxl';
  // 长词优先：先匹配「雨天」再考虑「雨」，避免短词把长词的机会抢走；只认长度 ≥2 的中文概念
  const candidates = rows
    .filter((r) => String(r.zh || '').length >= 2 && String(r.zh).length <= 8 && text.includes(String(r.zh)))
    .sort((a, b) => String(b.zh).length - String(a.zh).length);
  if (!candidates.length) {
    // 英文输入（不含中日韩文字）时这里必然为空 —— 说清"是口径问题"，别让人以为库坏了
    if (!llm.hasCJK(text)) {
      runtime.logger?.info('词库增强：提示词是纯英文（按中文概念匹配），这次没有命中 —— 需要补写法就先用 prompt_tags 查一下');
    } else {
      runtime.logger?.debug('词库增强：提示词里没有与库中概念匹配的中文词');
    }
    return empty;
  }
  const matched = [];
  const added = [];
  const usedZh = new Set();
  for (const row of candidates) {
    const zh = String(row.zh);
    if (usedZh.has(zh)) continue;
    usedZh.add(zh);
    // 走库自己的检索口拿"规范行"（类目/标签都按库的规则给），拿不到就退回上面这一行
    let hit = row;
    try {
      const r = library.searchLibrary(lib, zh, { limit: 1 });
      if (r?.hits?.length) hit = r.hits[0];
    } catch (error) {
      runtime.logger?.debug(`词库检索失败（用行数据兜底）：${errText(error)}`);
    }
    const values = isTagStyle
      ? (Array.isArray(hit.tags) ? hit.tags : [])
      : (hit.en ? [String(hit.en)] : []);
    if (!values.length) continue;
    matched.push(zh);
    for (const v of values) {
      const s = String(v).trim();
      if (s && !added.includes(s)) added.push(s);
      if (added.length >= maxTags) break;
    }
    if (added.length >= maxTags) break;
  }
  return { matched, added };
}

// ══════════════════════════════════════════════════════════════
//  10. draw 主链路
// ══════════════════════════════════════════════════════════════

const drawFail = (content) => ({ content, isError: true });

/**
 * 任务体（在串行队列里跑）。全部状态复位都靠 try/finally（E13）。
 * 步骤编号与 §1/§2 的主链路一一对应。
 */
async function runDraw(ctx, args) {
  const logger = runtime.logger;
  const c = runtime.cfg() || {};
  const taskStartedAt = Date.now();

  // 冷却记账刻意声明在 try **外面**：finally 里要用旧值把"占位时间戳"还原。
  const cdKey = config.truthyStr(ctx?.chatKey) || config.truthyStr(ctx?.key) || '__local__';
  const cooldownMs = Math.max(0, config.numOr(c.cooldownSec, 60)) * 1000;
  const cdStore = getState().lastRunAt;
  const cdPrev = cdStore.get(cdKey) || 0;
  let cdCommitted = false;
  let sentFile = '';
  let promptId = '';

  try {
    // 出图也要用"磁盘上那份" models.js（planGeneration 要按 LORA_SLOTS 枚举槽位）；
    // 已刷新过就是一次缓存命中，代价可以忽略。
    await refreshModelsNs();
    // ── 2. 同会话冷却：判定在任务体内 ─────────────────────────
    // 为什么判定放在任务体内、打点推迟到拿到 prompt_id：
    //   一张图要跑十几秒到几分钟，若"读时间戳→判定"发生在入队之前，期间连点会全部通过检查、全部排队，
    //   冷却形同虚设；而"打点"若发生在任务开头，翻译失败/探活失败也会占住冷却窗口（明明没出图却要等）。
    if (cooldownMs > 0) {
      const elapsed = Date.now() - cdPrev;
      if (cdPrev && elapsed < cooldownMs) {
        return drawFail(`这个会话刚画过图，还要等 ${Math.ceil((cooldownMs - elapsed) / 1000)} 秒。`);
      }
      // 占位：先占住窗口，免得"排队期间连点"绕过判定；失败会在 finally 里还原成 cdPrev
      cdStore.set(cdKey, Date.now());
    }

    // ── 5 的前置：参考图接口注册（ctx 每次调用都不同，所以每次出图前刷新）──
    ensureRefOwner(ctx);
    // 回执的"说明"行：从这一步就开始收集（探活/拉起、路线、参考图、降级都要往里写）
    const notes = [];

    // ── 3. 中文翻译（失败硬报错，绝不拿中文去出图）──────────────
    const inputPrompt = config.truthyStr(args?.prompt);
    let promptText = inputPrompt;
    let translatedText = '';
    // 翻译形态按"设置里看着像哪条路线"给（真正走哪条要等探活 + 扫模型之后才知道）。
    // 它只影响翻译措辞：SDXL 档要标签串，Anima 档要自然语言描述句 —— 加错了反而有害。
    const profileHint = profileTextFor(guessFamily(c));
    if (llm.hasCJK(inputPrompt)) {
      if (config.flag(c.autoTranslate, true) !== true) {
        return drawFail('提示词里有中文，但「中文自动翻译」被关掉了。本机模型只认英文，请把画面改成英文提示词再调用。');
      }
      const tr = await llm.translate(inputPrompt, {
        hostCfg: runtime.hostCfg,
        settings: c,
        dataDir: runtime.dataDir,
        hint: profileHint.translateHint,
        timeoutMs: config.intIn(c.llmTimeoutSec, 5, 300, 60) * 1000,
        log: runtime.log
      });
      if (!tr?.ok) {
        return drawFail(`提示词里有中文，自动翻译失败了（${R(tr?.reason || '未知原因')}）。请自己把它写成英文提示词再调用一次。`);
      }
      translatedText = config.truthyStr(tr.text);
      if (!translatedText) return drawFail('翻译结果为空，没有拿中文去出图。请自己写成英文提示词再调用。');
      promptText = translatedText;
      logger.info(`中文提示词已翻译：${inputPrompt.slice(0, 30)}… → ${translatedText.slice(0, 60)}…`);
    }

    // ── 4. 探活 / 自动拉起 ────────────────────────────────────
    // 先自己尊重「ComfyUI 没开时自动拉起」这个开关：`comfy.ensureStarted` 内部只负责"起得来/起不来"，
    // 它不看这个设置 —— 所以关掉时必须由这里先把关，否则"关掉自动拉起"照样会去起一个进程（还会占端口）。
    const base = baseUrlOf(c);
    const autoStart = config.flag(c.autoStartComfyUI, true);
    const ensureStartedAt = Date.now();
    let started = null;
    if (!autoStart) {
      const alive = await comfy.pingComfy(base, 8000);
      if (!alive) return drawFail(autoStartOffText(base));
      started = { ok: true, spawned: false, already: true, pid: null, reason: '' };
    } else {
      started = await comfy.ensureStarted(c, runtime.log);
    }
    if (!started?.ok) {
      // 文案只用 comfy.js 给的**真实分类原因**（E4/E6：目录错/布局错/缺解释器/端口占用各说各的）
      return drawFail(`连不上本机 ComfyUI（${R(base)}），自动拉起也没成功：${R(started?.reason || '未知原因')}`);
    }
    // 归因：`spawned:true` 只代表"我们尝试过"，端口被既有实例占着时它其实已经退出 —— 核实过再写文案（E4）
    const attributed = await attributeStarted(started);
    const ensureSeconds = Math.round((Date.now() - ensureStartedAt) / 1000);
    logger.info(`${attributed.text}（探活用时约 ${ensureSeconds} 秒）`);
    // 回执里关于拉起的说明**只有这一处**（startedNote 是唯一出口）
    const startNote = startedNote(attributed, ensureSeconds);
    if (startNote) notes.push(startNote);

    // ── 4b. 定模型（必须在探活成功之后：模型清单要问 ComfyUI / 扫目录）──
    const scan = await scanNow(c);
    const plan = planGeneration(c, scan);
    if (!plan.ok) return drawFail(plan.error);
    if (Array.isArray(plan.notes) && plan.notes.length) {
      notes.push(...plan.notes);
      for (const n of plan.notes) logger.info(`路线说明：${n}`);
    }
    const family = plan.family;
    const profile = profileTextFor(family);

    // ── 5. 参考图（四来源优先级都在 refs.js 里）───────────────
    const refMode = config.truthyStr(args?.ref_mode || c.refMode) === 'composition' ? 'composition' : 'appearance';
    const appearanceOnly = refMode === 'appearance';
    const refDenoise = Math.min(0.95, Math.max(0.2, config.numOr(args?.ref_denoise, config.numOr(c.refDenoise, 0.6))));
    const wantRef = Boolean(
      config.truthyStr(args?.ref_file) || config.truthyStr(args?.ref_character) || config.truthyStr(args?.ref_keyword)
      || (args?.ref_message_id !== undefined && args?.ref_message_id !== null && String(args.ref_message_id).trim() !== '')
      || args?.ref_recent_image === true
    );

    let refFile = '';          // 本地参考图（外观提取 / 上传都用它）
    let refSource = '';
    let refMeta = {};
    let refComfyName = '';     // 送进 ComfyUI 后的 image 名（只有 composition 模式才有意义）
    let refAppearance = [];
    let refAppearanceDropped = 0;
    let charTag = '';          // 已验证的角色标准标签（未验证的绝不注入）
    const refEnabled = config.flag(c.refEnabled, true);

    if (wantRef && !refEnabled) {
      notes.push('技能设置里关掉了「参考图」，这次按纯文字画。');
    } else if (wantRef) {
      // 角色标准标签：**单独解析一次**并用 verified 卡死（E4：未验证的标签不得注入 prompt）
      const charName = config.truthyStr(args?.ref_character);
      if (charName) {
        try {
          const r = await tags.resolveCharacterName(charName, {
            apiUrl: config.truthyStr(c.tagApiUrl) || tags.DEFAULT_TAG_API,
            hostCfg: runtime.hostCfg, settings: c, dataDir: runtime.dataDir, timeoutMs: 30000, log: runtime.log
          });
          const name = typeof r?.tag === 'string' ? r.tag : config.truthyStr(r?.tag?.name);
          if (r?.ok && r.verified === true && name) {
            charTag = name;
            logger.info(`角色「${charName}」→ 已验证标签 ${name}`);
          } else {
            notes.push(`角色「${charName}」的标准标签没能通过标签库确认${r?.reason ? `（${R(r.reason)}）` : ''}，`
              + '这次不往 prompt 里注入角色标签（只按你写的描述画）。');
          }
        } catch (error) {
          notes.push(`角色「${charName}」的标签查询失败（${errText(error)}），这次不往 prompt 里注入角色标签。`);
        }
      }

      // 四来源优先级（ref_file > 聊天图 > 角色 > 关键词）全在 refs.js 里；这里只负责
      // "按实际返回的原因写说明"（E4：没拿到的图绝不写成拿到了）
      {
        try {
          // settings 里补上 dataDir / log：refs.js 的落盘目录与内部日志都从 settings 里取（它的接口就这么设计的）
          const refSettings = { ...c, dataDir: runtime.dataDir, log: runtime.log };
          const picked = await refs.pickReference(args, ctx, refSettings, runtime.log);
          if (picked?.ok && (picked.file || picked.buf?.length)) {
            refSource = String(picked.source || '');
            refMeta = picked.meta && typeof picked.meta === 'object' ? picked.meta : {};
            const fromFile = config.truthyStr(picked.file);
            if (fromFile) refFile = fromFile;
            else {
              // 只给了字节：落盘才能给视觉模型读、才能上传给 ComfyUI（文件名带自己的前缀，E11）
              const ext = safeExt(picked.meta?.ext, magicExt(picked.buf) || '.png');
              const dest = path.join(refDirOf(c), `${REF_TEMP_PREFIX}${stampName()}${ext}`);
              const w = writeFileAtomic(dest, picked.buf);
              if (w.ok) refFile = dest;
              else notes.push(`参考图落盘失败（${w.reason}），这次不用参考图。`);
            }
            if (refFile) {
              logger.info(`参考图就绪：来源 ${R(refSource || '未知')}｜${Number(refMeta.width) || 0}x${Number(refMeta.height) || 0}`);
            }
          } else if (picked?.reason) {
            // 按**实际原因**写说明（"没这张图" / "取图失败" / "能力没装" 各说各的）
            notes.push(`${R(picked.reason)}${/[。！？]$/.test(String(picked.reason)) ? '' : '。'}`);
            logger.warn(`参考图没用上：${R(picked.reason)}`);
          }
        } catch (error) {
          notes.push(`取参考图失败（${errText(error)}），这次按纯文字画。`);
        }
      }
    }

    // ── 6. 外观提取（放在探活/定模型**之后**）──────────────────
    // 为什么必须在探活之后：外观提取要调宿主的视觉模型（可能要几十秒）。
    //   放在前面的话，"ComfyUI 都没开"这种情况会先白等一大截才报错；确认能出图了再花这个时间。
    if (refFile && appearanceOnly) {
      const ex = await tags.extractAppearance(refFile, {
        hostCfg: runtime.hostCfg,
        settings: c,
        dataDir: runtime.dataDir,
        timeoutMs: config.intIn(c.refExtractTimeoutSec, 5, 300, 60) * 1000,
        log: runtime.log
      });
      if (ex?.ok && Array.isArray(ex.tags) && ex.tags.length) {
        refAppearance = ex.tags.map(String);
        refAppearanceDropped = Array.isArray(ex.dropped) ? ex.dropped.length : 0;
        logger.info(`外观标签提取成功（${R(ex.model || '视觉模型')}）：${refAppearance.join(', ')}`
          + (refAppearanceDropped ? `｜已剔除 ${refAppearanceDropped} 个构图/姿势类标签` : ''));
      } else {
        // 提取失败时**故意不回退 img2img**：那会把参考图的构图带进来，违背 appearance 模式的承诺
        notes.push(`这次是「只取外观」模式，但外观提取失败（${R(ex?.reason || '未知原因')}）—— 为保证构图不受参考图影响，这次不用参考图。`);
        logger.warn(`外观提取失败：${R(ex?.reason || '未知原因')}`);
      }
      refFile = '';   // appearance 模式下无论成败都不把图送进采样器
    }

    // ── 尺寸 ─────────────────────────────────────────────────
    const size = resolveSize(c, args);
    let width = size.width;
    let height = size.height;
    if (!appearanceOnly && refFile && !size.explicit && Number(refMeta.width) > 0 && Number(refMeta.height) > 0) {
      const fit = fitSizeInto(refMeta.width, refMeta.height, width, height, size.maxW, size.maxH);
      if (fit) {
        logger.info(`按参考图比例定尺寸：${width}x${height} + 参考图 ${refMeta.width}x${refMeta.height} → ${fit.width}x${fit.height}`);
        width = fit.width;
        height = fit.height;
      }
    }

    // ── 7. 词库增强（本地，不联网）────────────────────────────
    const libEnrich = enrichFromLibrary(inputPrompt, c, family);
    if (libEnrich.added.length) {
      promptText = `${promptText}, ${libEnrich.added.join(family === 'sdxl' ? ', ' : '. ')}`;
      logger.info(`提示词库命中 ${libEnrich.matched.length} 个概念（${libEnrich.matched.join('、')}），补上：${libEnrich.added.join(' / ')}`);
    }

    // ── 8. 参数（自动 / 手调 + 二次放大计划）──────────────────
    const rp = safeResolveParams({ settings: c, modelName: plan.modelName, family, variant: plan.variant });
    const argSteps = Number(args?.steps);
    const argCfg = Number(args?.cfg);
    const steps = Number.isFinite(argSteps) && argSteps > 0
      ? config.intIn(argSteps, 1, 150, rp.steps)
      : config.intIn(rp.steps, 1, 150, 30);
    const cfg = Number.isFinite(argCfg) && argCfg > 0
      ? config.intIn(argCfg, 0, 20, rp.cfg)
      : config.intIn(rp.cfg, 0, 20, 4);
    const sampler = config.truthyStr(rp.sampler) || 'euler';
    const scheduler = config.truthyStr(rp.scheduler) || 'simple';
    const paramsAuto = rp.auto !== false;
    // L4 提示：用**刚定下来的实际 CFG** 判断（手调 4 就闭嘴，真在低 CFG 才说话）
    const lowCfgNote = loraLowCfgNote(plan, cfg, paramsAuto);
    if (lowCfgNote) { notes.push(lowCfgNote); logger.info(lowCfgNote); }
    const seedArg = Number(args?.seed);
    const seed = Number.isFinite(seedArg) && seedArg >= 0 ? Math.floor(seedArg) : Math.floor(Math.random() * 2147483647);
    const hires = safeHiresPlan(c, { width, height, maxW: size.maxW, maxH: size.maxH }, sampler, scheduler);
    if (hires?.degraded) { notes.push(String(hires.degraded)); logger.info(`二次放大：${hires.degraded}`); }

    // ── 组装提示词（角色标签 → 参考图外观标签 → 用户描述）──────
    // 未验证的角色标签绝不在这里出现（charTag 只有 verified=true 才会被赋值）。
    const inject = [];
    const lower = () => promptText.toLowerCase();
    if (charTag && !lower().includes(charTag.toLowerCase())) inject.push(charTag);
    for (const t of refAppearance) if (!lower().includes(String(t).toLowerCase())) inject.push(String(t));
    if (inject.length) {
      promptText = `${inject.join(', ')}, ${promptText}`;
      logger.info(`已注入标签：${inject.join(', ')}${refAppearance.length ? '（外观标签来自参考图，不携带构图）' : ''}`);
    }
    const qualityPrefix = config.truthyStr(c.qualityPrefix) || profile.qualityPrefix;
    const prependQuality = config.flag(c.prependQuality, true) && profile.prependQuality;
    const positive = prependQuality && qualityPrefix ? `${qualityPrefix}, ${promptText}` : promptText;
    // img2img 时补一组**文字类**负面词：参考图上印的字会被忠实复现成乱码字母（旧包实测），
    //   而 Anima 官方负面词里一个文字类词都没有，所以这里单独兜底。
    const refNegative = refFile ? 'text, watermark, signature, letters, words, caption, subtitles, logo, title, chinese text' : '';
    const negative = [
      config.truthyStr(c.extraNegative),
      config.truthyStr(args?.negative_prompt),
      refNegative,
      config.truthyStr(c.negativePrefix) || profile.negative
    ].filter(Boolean).join(', ');

    // ── 9.5 参考图送进 ComfyUI（composition 模式才需要）────────
    if (refFile && !appearanceOnly) {
      const staged = await stageReferenceForComfy(refFile, c, base);
      if (staged?.ok) {
        refComfyName = staged.ref;
        logger.info(`参考图已交给 ComfyUI（${staged.how === 'upload' ? '上传接口' : '复制到 input 目录'}）`);
      } else {
        // 如实说明降级原因，并退回纯文生图（绝不假装用了参考图）
        notes.push(`${R(staged?.reason || '参考图没能交给 ComfyUI')} —— 这次按纯文字画。`);
        logger.warn(`参考图降级为纯文生图：${R(staged?.reason || '未知原因')}`);
        refFile = '';
        refComfyName = '';
      }
    }

    // ── 9./10. 构建工作流 + 提交 ─────────────────────────────
    const wf = buildWorkflow({
      kind: plan.kind,
      files: plan.files,
      prompt: positive,
      negative,
      width,
      height,
      steps,
      cfg,
      sampler,
      scheduler,
      seed,
      hires,
      refImage: refComfyName,
      denoise: refDenoise
    });
    const submit = await comfy.submitPrompt(base, wf);
    if (!submit?.ok || !config.truthyStr(submit.promptId)) {
      // submitPrompt 已经把"拒绝的原因类别/状态码"压好了（不回显 node_errors 与本机路径）
      return drawFail(`${R(submit?.reason || 'ComfyUI 没有返回 prompt_id')}。常见原因是底模文件名不对、模型文件缺失或工作流参数越界；完整信息已写进技能日志。`);
    }
    promptId = config.truthyStr(submit.promptId);

    // 冷却正式打点：到这一步才算"确实开始出图"（ComfyUI 收下任务并给了 prompt_id）。
    // 之后的失败（轮询超时/执行报错/取图失败）都算"跑过了"，时间戳保留；之前的失败一律不占冷却。
    if (cooldownMs > 0) { cdStore.set(cdKey, Date.now()); cdCommitted = true; }
    const pollStartedAt = Date.now();
    const modelDesc = plan.kind === 'checkpoint'
      ? plan.files.checkpoint
      : `${plan.files.unet}${plan.files.lora ? ` + LoRA ${plan.files.lora}` : ''}`;
    logger.info(`已提交 ${promptId}｜${plan.tier}｜${width}x${height}｜${steps} 步｜CFG ${cfg}｜${modelDesc}`
      + `｜${refComfyName ? `img2img denoise ${refDenoise}` : (refAppearance.length ? 'txt2img（参考图只提供外观标签）' : 'txt2img')}`);

    // ── 10.1 轮询 ────────────────────────────────────────────
    const timeoutSec = config.intIn(c.timeoutSec, 60, 3600, 420);
    const waited = await comfy.waitForImage(base, promptId, { timeoutSec, log: runtime.log });
    if (!waited?.ok) {
      let extra = '';
      // 超时路径由 waitForImage **内部**调 abortJob 并按实际返回值写进 reason，这里不追加，
      // 否则回执里会出现两遍"已经让它停下…"。非超时失败（执行报错 / 查不到进度 / 跑完没图）
      // 时任务可能还在跑，补一次收尸，同样按返回值如实说（E4）。
      if (!waited?.aborted) {
        try {
          const ab = await comfy.abortJob(base, promptId, runtime.log);
          extra = ' ' + abortText(ab);
        } catch (error) {
          extra = ` 收尸调用失败（${errText(error)}）。`;
        }
      }
      return drawFail(`${R(waited?.reason || '等待出图失败')}${extra}`);
    }

    // ── 10.2 取图 ────────────────────────────────────────────
    const maxImageBytes = config.intIn(c.imageMaxMB, 1, 512, 24) * 1024 * 1024;
    const img = await comfy.fetchImage(base, waited.item, maxImageBytes, runtime.log);
    if (!img?.ok || !img.buf?.length) {
      return drawFail(`取图失败：${R(img?.reason || '没有取到图片数据')}`);
    }
    // 扩展名按魔数定（E5）：lib 给的 ext 与魔数不一致时以魔数为准（并留一条日志线索）
    const magic = magicExt(img.buf);
    const ext = magic || safeExt(img.ext) || '.png';
    if (magic && safeExt(img.ext) && magic !== safeExt(img.ext)) {
      logger.warn(`取回图片的扩展名以魔数为准：lib 说 ${safeExt(img.ext)}，魔数是 ${magic}`);
    }

    // ── 11. 落档：先 .part 再 rename；发送成功才算留档 ──────────
    const outDir = config.truthyStr(c.outputDir) || path.join(runtime.dataDir || '.', 'comfyui-images');
    let dest = '';
    try {
      fs.mkdirSync(outDir, { recursive: true });
      dest = path.join(outDir, `${TEMP_PREFIX}${stampName()}${ext}`);
      const w = writeFileAtomic(dest, img.buf);
      if (!w.ok) return drawFail(`图画好了，但落盘失败：${w.reason}`);
    } catch (error) {
      return drawFail(`图画好了，但落盘失败：${logLib.describeFsError(error)}`);
    }

    const totalSeconds = Math.round((Date.now() - taskStartedAt) / 1000);
    const sampleSeconds = Math.round((Date.now() - pollStartedAt) / 1000);
    const outW = hires?.enabled ? Math.round(width * (Number(hires.scale) || 1)) : width;
    const outH = hires?.enabled ? Math.round(height * (Number(hires.scale) || 1)) : height;
    const technique = refComfyName
      ? `参考图重绘（img2img，重绘幅度 ${refDenoise}）`
      : (refAppearance.length ? '文字生成 + 参考图外观' : '文字生成');

    try {
      if (typeof ctx?.sender?.sendImage !== 'function') {
        throw new Error('当前上下文拿不到 sender，无法发图');
      }
      await ctx.sender.sendImage(ctx.chatKey, { file: dest }, { note: `AI画图 ${outW}x${outH}` });
    } catch (error) {
      // 发送失败 → 删掉刚落的那张，避免兄弟功能把它当成"机器人刚画好的图"（§1/E11 的同一意图）。
      // 路径不回显给模型：完整信息只进日志。
      logger.warn(`图片已落盘但发送失败，已删除留档：${path.basename(dest)}｜${errText(error)}`);
      safeUnlink(dest);
      return drawFail(`图画好了，但发送失败（${errText(error)}）。为避免被当成"刚画好的图"，本机留档已删除。`);
    }
    sentFile = dest;
    logger.info(`出图完成 总 ${totalSeconds}s（采样 ${sampleSeconds}s）｜${plan.tier}｜${outW}x${outH}｜${path.basename(dest)}`);

    // ── 12. 回执（数字与降级说明全部来自实际结果，E4）──────────
    const lines = [];
    const sizeText = hires?.enabled
      ? `${outW}x${outH}（二次放大 ${hires.scale}x，基础 ${width}x${height}）`
      : `${width}x${height}`;
    lines.push(receiptHeadText({
      sizeText, tier: plan.tier, files: plan.files, paramsAuto,
      steps, cfg, technique, totalSeconds, sampleSeconds
    }));
    lines.push(sizeLine(size, width, height));
    // 换 id 后第一次出图：告诉用户设置是从旧段继承来的（只提示一次；旧段没被改动）
    const migNote = legacyMigrationNote();
    if (migNote) lines.push(`- 说明：${migNote}`);
    lines.push(`- 参数来源：${originText(rp)}；实际用 ${steps} 步 / CFG ${cfg} / ${sampler} + ${scheduler}`
      + (paramsAuto ? '（自动跟随模型）' : '（设置里手调）'));
    lines.push(`- 路线：${routeLine(plan)}`);
    lines.push(modelLine(plan));
    if (loraLine(plan)) lines.push(loraLine(plan));   // L5：实际挂了哪些 LoRA + 权重（一个都没挂就不出这行）
    if (refComfyName) lines.push(`- 参考图：${R(refSource || '本地文件')}（作为 img2img 底图，重绘幅度 ${refDenoise}）`);
    else if (refAppearance.length) lines.push(`- 参考图：${R(refSource || '未知来源')}（**只提供了外观**：${refAppearance.join(', ')}；构图、姿势、机位完全由你的描述决定）`);
    else if (refSource) lines.push(`- 参考图：${R(refSource)}（这次没用上）`);
    for (const n of notes) lines.push(`- 说明：${n}`);
    lines.push(`- 留档：${logLib.redact(dest)}`);
    lines.push('不要再复述或描述图片内容，群友自己看得见。');
    return { content: lines.join('\n') };
  } catch (error) {
    if (error?.name === 'AbortError') return drawFail('请求超时了，ComfyUI 可能正忙或者卡住了。');
    logger.warn(`画图失败（完整堆栈见下）：${error?.stack || error}`);
    return drawFail(`画图失败：${errText(error)}`);
  } finally {
    // 失败路径**不占用冷却**（E13）：把开跑时放的占位时间戳还原成上一张成功出图的时间。
    if (cooldownMs > 0 && !cdCommitted) {
      if (cdPrev) cdStore.set(cdKey, cdPrev);
      else cdStore.delete(cdKey);
    }
    // 只有**成功出图**之后才顺手清一次自己产生的旧临时文件：
    //   失败时不动磁盘，现场（参考图、上传件）保持原样，方便排查；清理本身只 warn（E11）。
    if (sentFile) {
      try { cleanupOwnTempFiles(runtime.cfg() || {}, sentFile); }
      catch (error) { logger.warn(`清理临时文件时出错（已忽略）：${errText(error)}`); }
    }
  }
}

/** 收尸结果 → 如实的一句话（E4：没核实过的事绝不说）。 */
function abortText(ab) {
  if (!ab || typeof ab !== 'object') return '';
  if (ab.interrupted && ab.deleted) return '已经让它停下并清出了队列。';
  if (ab.interrupted) return '已经让它停下（队列里没有可删的条目）。';
  if (ab.deleted) return '它已经不在运行中，只把队列里的残留条目删掉了。';
  return `没有对 ComfyUI 做任何中断/清理：${R(ab.reason || '这个任务已经不在队列里了')}`;
}

/** `picked` 一条 → "来源"显示串：优先库给的 by（形如 `PREFER.animaUnet[0]=/turbo/i`），再退 byText / reason。 */
function pickedSource(v) {
  if (!v || typeof v !== 'object') return '';
  const by = config.truthyStr(v.by);
  if (by) return by;
  const byText = config.truthyStr(v.byText);
  if (byText) return byText;
  return config.truthyStr(v.reason);
}

/**
 * `comfyui_models(action:"rescan")` 回执里"自动选中 / 已清空"那几行。
 *
 * ⚠️ 这里**两种形状都要吃**，而且绝不能抛：
 *   · 旧形状 `picked = ['animaUnet → x', …]`（数组）
 *   · 新形状 `picked = { animaUnet: { value, by, byText, reason }, … }`（对象）
 * 为什么专门写出来：`models.syncSchema` 把 `picked` 从数组改成对象之后，
 * 原来那句 `if (r.picked?.length)` 在对象上**恒为假** —— 回执行静默消失、不报错也没有日志，
 * 是最难发现的一类破坏。所以判形状而不是判 truthy/length，并且顺手把"**为什么选它**"带上。
 * `cleared` 同样两种形状都吃（它现在是数组，但不再赌它将来不变）。
 */
function pickedClearedLines(r) {
  const out = [];
  try {
    if (!r || typeof r !== 'object') return out;

    // ── 已清空 ──────────────────────────────────────────────
    const cleared = r.cleared;
    if (Array.isArray(cleared) && cleared.length) {
      out.push(`- 已清空（本机找不到对应文件）：${cleared.map((x) => R(x)).join('；')}`);
    } else if (cleared && typeof cleared === 'object') {
      const rows = Object.entries(cleared).filter(([, v]) => v).map(([k, v]) => `${k}${typeof v === 'object' ? `：${config.truthyStr(v.reason) || '本机找不到'}` : `：${v}`}`);
      if (rows.length) out.push(`- 已清空（本机找不到对应文件）：${rows.map((x) => R(x)).join('；')}`);
    }

    // ── 自动选中 ────────────────────────────────────────────
    const picked = r.picked;
    if (Array.isArray(picked) && picked.length) {
      out.push(`- 自动选中：${picked.map((x) => R(x)).join('；')}`);
    } else if (picked && typeof picked === 'object') {
      // 压成一行摘要（每个键都保留"为什么是它"，来源不丢）
      const parts = [];
      for (const [key, v] of Object.entries(picked)) {
        if (!v) continue;
        const value = typeof v === 'object' ? (config.truthyStr(v.value) || '（未给文件名）') : String(v);
        const src = pickedSource(v);
        parts.push(`${key}→${value}${src ? `（${src}）` : ''}`);
      }
      if (parts.length) out.push(`- 自动选中（已写进设置里的下拉）：${parts.map((x) => R(x)).join('、')}`);
    }
  } catch (error) {
    // 排版失败也不该让整条回执崩掉：只说一句，别把有用信息一起吞了
    out.push(`- （自动选中/清空的说明排版失败：${errText(error)}）`);
  }
  return out;
}

// ══════════════════════════════════════════════════════════════
//  11. comfyui_models / find_character_tags / prompt_tags 的共用实现
// ══════════════════════════════════════════════════════════════

/**
 * 「设置里的模型下拉现在是什么状态」——**三种情况分开说**（本次体验问题的核心）：
 *   ① 还没选，但本机扫到了 → 说清"点 rescan / 等首次扫描会自动填上"（这是刚装好时的正常状态）；
 *   ② 选了，但那个文件在本机不存在 → 说清"下拉已可重扫"；
 *   ③ 已选且本机都有 → 一句"已选齐"。
 * 为什么不能只说一句"本机没有"：设置空 ≠ 本机没有 —— 旧逻辑把这两件事混成了一句，
 * 于是同一条回执里"上面列出 anima 三件套、下面说本机没有"自相矛盾。
 */
function settingsStatusText(c, scan) {
  const setUnet = config.truthyStr(c?.animaUnet);
  const setClip = config.truthyStr(c?.animaClip);
  const setVae = config.truthyStr(c?.animaVae);
  const setCkpt = config.truthyStr(c?.checkpoint);
  const unets = bucketOf(scan, 'unets', 'unet');
  const clips = bucketOf(scan, 'clips', 'clip');
  const vaes = bucketOf(scan, 'vaes', 'vae');
  const ckpts = bucketOf(scan, 'checkpoints', 'checkpoint');

  const animaScanned = unets.length && clips.length && vaes.length;
  if (!setUnet && !setClip && !setVae && !setCkpt) {
    if (animaScanned) {
      return `**还没选**（本机已扫到 Anima 三件套：底模 ${unets.length} 个 / 编码器 ${clips.length} 个 / VAE ${vaes.length} 个；`
        + '点 rescan 或等首次扫描会自动填上）';
    }
    if (ckpts.length) {
      return `**还没选**（本机已扫到 ${ckpts.length} 个单文件大模型；点 rescan 或等首次扫描会自动填上）`;
    }
    return `还没选（本机也还没扫到模型文件：把 .safetensors 放进 ComfyUI 的 models\\ 对应目录即可）`;
  }

  const missing = [];
  if (setUnet && !unets.includes(setUnet)) missing.push(`Anima 底模「${setUnet}」`);
  if (setClip && !clips.includes(setClip)) missing.push(`文本编码器「${setClip}」`);
  if (setVae && !vaes.includes(setVae)) missing.push(`VAE「${setVae}」`);
  if (setCkpt && !ckpts.includes(setCkpt)) missing.push(`单文件大模型「${setCkpt}」`);
  if (missing.length) {
    return `${missing.join('、')}**在本机不存在**（下拉已可重扫：点一次 rescan 会按本机清单刷新，或直接在下拉里重选）`;
  }
  return '已选齐，且本机都有';
}

function modelListText(scan, c, paramSource = null) {
  const patch = (() => {
    try { return models.buildSchemaPatch(scan) || {}; } catch { return {}; }
  })();
  /** 取 label 里那个括号说明（"anima-turbo-v1.1.safetensors（Anima 蒸馏版·12步/CFG1）" → "Anima 蒸馏版·12步/CFG1"）。 */
  const line = (title, key, empty) => {
    const p = patch[key];
    const values = Array.isArray(p?.values) ? p.values : [];
    if (!values.length) return `- ${title}：${empty}`;
    // labels 是 models.classifyModel 给的分类标签（"Anima 蒸馏版·12步/CFG1" 这类），
    // 和设置里下拉看到的是同一份文案（§2 第 2 条：选中后参数自动跟随，用户得看得见族/变体）。
    const shown = values.map((v) => {
      const note = labelNote(p?.labels?.[v]);
      return note ? `${v}（${note}）` : v;
    });
    return `- ${title}：${shown.join('、')}`;
  };
  const upscalers = bucketOf(scan, 'upscalers', 'upscaler');
  const lines = [
    '本机 ComfyUI 可用模型（只读清单，**没有**改动设置里的下拉）：',
    line('Anima 底模（diffusion_models）', 'animaUnet', '（无）'),
    line('文本编码器（text_encoders）', 'animaClip', '（无）'),
    line('VAE', 'animaVae', '（无）'),
    line('Turbo LoRA（只列名字带 turbo 的）', 'animaTurboLora', '（无 —— 底模本身是蒸馏版就直接跑蒸馏档）'),
    line('单文件大模型（checkpoints）', 'checkpoint', '（无）'),
    // LoRA 槽位：三个槽共用同一份候选（去掉空项，空项表示"这个槽不用"）
    // 兜底：models.js 还没产出 lora1 时，直接用本次扫描的 loras 列表（照样是"本机实际有什么"）
    (() => {
      const slots = loraSlots();
      const slotKey = slots[0]?.slot || 'lora1';
      const range = slots.length > 1 ? `${slots[0].slot}~${slots[slots.length - 1].slot}` : (slots[0]?.slot || 'lora1');
      const raw = (patch[slotKey]?.values?.length ? patch[slotKey].values : bucketOf(scan, 'loras', 'lora'));
      const vals = raw.filter((v) => config.truthyStr(v));
      return `- LoRA（可挂在 ${range}，按槽号顺序挂）：${vals.length ? vals.join('、') : '（无 —— loras\\ 里没有 .safetensors）'}`;
    })(),
    `- 放大模型（upscale_models）：${upscalers.length ? upscalers.join('、') : '（无，二次放大用的是潜空间算法，不依赖这个）'}`
  ];
  const plan = planGeneration(c, scan);
  if (plan.ok) {
    // 只报"哪个文件 → 什么档位"（档位名里已经含了"SDXL 单文件大模型"，不要再重复一遍）
    // 参数是手调的时候，档位名只描述**底模**（`autoParams` 关着时"蒸馏档 ⇒ 12 步/CFG 1"并不成立）
    lines.push(`当前路线：${plan.modelName} → ${tierLabel(plan.tier, plan.files, config.flag(c?.autoParams, true))}`);
    lines.push(`路线判定：${routeLine(plan)}`);
  } else {
    // 定不下来时**逐条**说清是哪一种（设置没选 / 设置选的文件本机没有 / 本机确实没有），不混成一句
    lines.push('当前路线还定不下来：');
    for (const r of (Array.isArray(plan.reasons) ? plan.reasons : [R(String(plan.error || '').split('\n')[0])])) {
      lines.push(`  · ${R(r)}`);
    }
    lines.push('  （放好模型文件后点一次 rescan，或在下拉里明确选一个；「模型路线」可以设成 auto / anima / sdxl。）');
  }
  lines.push(`- 设置里的模型下拉：${settingsStatusText(c, scan)}`);
  // 参数真源（§5 唯一真源 = lib/params.js 的 PARAM_TABLE）：不是真源就如实说明，别让它静默失效
  lines.push(`- 参数表来源：${paramSource?.text || '（本次没读到：见技能日志）'}`);
  lines.push(`- 本机清单：Anima 底模 ${bucketOf(scan, 'unets', 'unet').length} 个 / 文本编码器 ${bucketOf(scan, 'clips', 'clip').length} 个`
    + ` / VAE ${bucketOf(scan, 'vaes', 'vae').length} 个 / LoRA ${bucketOf(scan, 'loras', 'lora').length} 个`
    + ` / 单文件大模型 ${bucketOf(scan, 'checkpoints', 'checkpoint').length} 个`);
  for (const n of (Array.isArray(plan.notes) ? plan.notes : [])) lines.push(`- 说明：${R(n)}`);
  // 这些通常只是"ComfyUI 没在线，/object_info 用不了"（在线信息缺失），与"文件系统里没有模型"是两回事：
  // 上面的清单本来就来自文件系统扫描，照样是全的 —— 所以措辞上要说清"不影响上面的清单"。
  const errs = Array.isArray(scan?.errors) ? scan.errors : [];
  for (const e of errs.slice(0, 5)) lines.push(`- 在线信息不可用（不影响上面的清单）：${R(e)}`);
  return lines.join('\n');
}

/**
 * 角色名 → 标准标签 + 角色卡。
 * name 可以是中文/日文/英文：写法猜测与验证都在 tags.resolveCharacterName 里（含 LLM 猜写法 + 标签库验证）。
 */
async function characterLookupText(name, sampleArg) {
  const c = runtime.cfg() || {};
  const apiUrl = config.truthyStr(c.tagApiUrl) || tags.DEFAULT_TAG_API;
  const sample = config.intIn(sampleArg, 10, 100, config.intIn(c.characterCardSample, 10, 100, 60));
  const top = config.intIn(c.characterCardTop, 5, 40, 16);

  const resolved = await tags.resolveCharacterName(name, {
    apiUrl, hostCfg: runtime.hostCfg, settings: c, dataDir: runtime.dataDir, timeoutMs: 30000, log: runtime.log
  });
  const tagName = typeof resolved?.tag === 'string' ? resolved.tag : config.truthyStr(resolved?.tag?.name);
  if (!resolved?.ok || !tagName) {
    // 「标签库里确实没有」与「查询本身失败（网络/服务）」要分开说：
    // 前者该让模型去 web_search 找确切写法，后者该等一会儿重试 —— 混成一句会把用户引到错误方向。
    if (resolved?.network) {
      return {
        content: `查标签库失败（网络或服务问题，**不是**"没有这个角色"）：${R(resolved.reason)}\n`
          + '过一会儿再试；或者你用自己的 web_search 搜「<角色名> danbooru tags」拿到写法后直接写进 draw 的 prompt。'
      };
    }
    return {
      content: `标签库里没找到「${name}」${resolved?.guessed ? `（我猜的英文标签是 ${resolved.guessed}）` : ''}。\n`
        + `${R(resolved?.reason || '可能是这个小众角色在标签库里没有，或者我猜的拼写不对。')}\n`
        + '建议：用你自己的 web_search 搜「<角色名> danbooru tags」或「<角色名> 角色卡 提示词」，'
        + '拿到确定写法后直接写进 draw 的 prompt（英文）。'
    };
  }
  if (resolved.verified !== true) {
    return {
      content: `「${name}」我没能在标签库里确认标准标签${resolved.guessed ? `（猜的是 ${resolved.guessed}）` : ''}。\n`
        + `${R(resolved?.reason || '这个写法没有被标签库确认')}\n`
        + '所以我**不会**把这个标签当成角色标签用。建议你搜一下确切写法再写进 prompt；'
        + '或者只描述外观（发色/发型/瞳色）也能画出来。'
    };
  }

  const lines = [`角色「${name}」→ 标准标签：${tagName}`
    + (resolved.resolvedBy ? `（通过${R(resolved.resolvedBy)}确认）` : '')];
  let card = null;
  try {
    card = await tags.characterCard(tagName, {
      apiUrl, sample, top, hostCfg: runtime.hostCfg, settings: c, dataDir: runtime.dataDir, timeoutMs: 35000, log: runtime.log
    });
  } catch (error) {
    lines.push(`（统计角色卡失败：${errText(error)}）`);
  }
  if (card?.ok && Array.isArray(card.ranked) && card.ranked.length) {
    const look = card.ranked.filter((x) => tags.APPEARANCE_RE.test(String(x.name || '')));
    const others = card.ranked.filter((x) => !tags.APPEARANCE_RE.test(String(x.name || '')));
    lines.push('', `角色卡（统计了 ${card.samples} 张该角色的图，数字是出现比例）：`);
    if (look.length) lines.push(`  外观（优先用）：${look.map((x) => `${x.name} ${Math.round((Number(x.ratio) || 0) * 100)}%`).join(', ')}`);
    if (others.length) lines.push(`  其他常见：${others.map((x) => `${x.name} ${Math.round((Number(x.ratio) || 0) * 100)}%`).join(', ')}`);
    lines.push('', '注意：「其他常见」里可能混进同作品的其他角色或常见搭配，按画面需要挑，不要全塞。');
  } else if (card?.reason) {
    lines.push('', `（${R(card.reason)}）`);
  } else {
    lines.push('', '（没抓到样本图，只能给你标准标签本身）');
  }
  const alts = Array.isArray(resolved.alternatives) ? resolved.alternatives.slice(0, 5) : [];
  if (alts.length) {
    lines.push(`备选标签：${alts.map((t) => `${t?.name || t}${t?.count ? `(${t.count})` : ''}`).join(', ')}`);
  }
  lines.push('', '接下来：把这些标签 + 群友要的场景拼成英文 prompt，再调用 draw 画图。');
  return { content: lines.join('\n') };
}

// ══════════════════════════════════════════════════════════════
//  12. 技能入口
// ══════════════════════════════════════════════════════════════

export function available() {
  return true;
}

export function setup(api) {
  const rawCfg = typeof api?.config === 'function' ? api.config : () => ({});
  // 宿主给的设置先过一层"旧 id 继承"（内存里合并，绝不写宿主配置）：换 id 后新段是空的，
  // 老用户的 comfyuiDir / 模型下拉 / LoRA 槽都在旧段里，没有这一层就等于让他们重新配一遍。
  runtime.rawCfg = rawCfg;
  runtime.cfg = () => effectiveSettings(rawCfg());
  runtime.capability = typeof api?.capability === 'function' ? api.capability : () => undefined;
  runtime.hasCapability = typeof api?.hasCapability === 'function' ? api.hasCapability : () => false;

  runtime.dataDir = config.resolveDataDir();
  const logger = logLib.makeLogger(api || {}, runtime.dataDir);
  runtime.logger = logger;
  runtime.log = bridgeLogger(logger);
  const log = runtime.log;

  // 宿主配置（LLM 端点/视觉模型都从它来）。读不到不是致命错误：
  // 翻译/外观提取会各自给出"为什么用不了"的真实原因（E4）。
  const host = config.readHostConfig(runtime.dataDir);
  runtime.hostCfg = host?.ok ? host.config : null;

  // 旧 id 的数据目录（<data>\comfyui-image\）已存在就继续用：老用户放在里面的 prompt-library 覆盖文件不能丢。
  runtime.skillDataDir = skillDataDirOf(runtime.dataDir);
  if (runtime.skillDataDir.legacy) {
    log.info(`本技能的数据目录沿用旧 id 的那个（兼容）：${logLib.redact(runtime.skillDataDir.dir)}`
      + `｜新 id 的目录（${SKILL_ID}）建好并放进同名文件后就会自动切换过去`);
  }
  // 触发一次继承（把日志打出来），并把结果留给回执用的一次性提示
  void effectiveSettings(rawCfg());

  // 参考图接口的默认注册（setup 时还没有 ctx）：出图前会用真实 ctx 再注册一次
  ensureRefOwner(null);

  // 参数真源自检（不抛、不挡加载）：params.js 没加载成功时 models 会静默用兜底表，这里必须留下看得见的信号
  void logParamSource();

  // ── 工具四：本机模型清单 / 重扫下拉 ──────────────────────────
  api.registerTool({
    id: 'comfyui_models',
    name: '本机模型清单',
    description:
      '列出本机 ComfyUI 里可用的模型：Anima 底模（diffusion_models）、文本编码器、VAE、Turbo LoRA、'
      + '单文件大模型（checkpoints，如光辉 Illustrious / WAI）、放大模型 —— 并标出每个模型的家族与变体。'
      + '默认 action="list" **只读清单、绝不改设置**；action="rescan" 才会重扫并把结果刷新到设置里的下拉，'
      + '同时返回这次新增 / 移除了哪些（本机放了新模型或删了模型之后用它）。'
      + '群友问「有哪些模型」「能画什么」「换个模型」时用它。',
    category: 'system',
    icon: '🧩',
    parameters: {
      type: 'object',
      properties: {
        action: {
          type: 'string',
          enum: ['list', 'rescan'],
          description: 'list（默认）= 只看清单，不动设置；rescan = 重扫本机模型并刷新设置里的下拉，返回新增/移除'
        }
      }
    },
    async execute(_ctx, args) {
      const c = runtime.cfg() || {};
      const action = config.truthyStr(args?.action).toLowerCase() || 'list';
      if (action !== 'rescan') {
        const scan = await scanNow(c);
        return { content: modelListText(scan, c, await readParamSource()) };
      }
      const st = getState();
      const prev = st.lastScan;
      const r = await syncSchemaOnce(c, { source: '手动重扫' });
      if (!r?.ok) {
        return { content: `重扫失败：${R(r?.reason || '未知原因')}`, isError: true };
      }
      const next = r.scan && typeof r.scan === 'object' ? r.scan : null;
      const diff = prev && next ? models.detectChanges(prev, next) : null;
      const lines = [modelListText(next || (await scanNow(c)), c, await readParamSource()), ''];
      if (diff) {
        lines.push(`本次重扫：新增 ${diff.added.length} 个${diff.added.length ? `（${diff.added.map((x) => R(x)).join('、')}）` : ''}，`
          + `移除 ${diff.removed.length} 个${diff.removed.length ? `（${diff.removed.map((x) => R(x)).join('、')}）` : ''}。`);
      } else {
        // 没有可比对的上一份清单时如实说（不编造"新增 0 个"）
        lines.push('本次重扫完成。这是第一次扫描，没有可比对的上一份清单，所以只报当前数量。');
      }
      lines.push(r.changed ? '设置里的下拉已更新。' : '设置里的下拉本来就是最新的，没有写盘。');
      lines.push(...pickedClearedLines(r));
      return { content: lines.join('\n') };
    }
  });

  // ── 工具三：查角色标签 / 角色卡 ─────────────────────────────
  api.registerTool({
    id: 'find_character_tags',
    name: '查角色标签（角色卡）',
    description:
      '联网查一个动漫/游戏角色的**标准 danbooru 标签**和它的「角色卡」（画这个角色最常用的标签）。'
      + '适用：群友点名要画某个具体角色时（「画个初音未来」「来个雷姆」）—— **先调这个**，再把标签拼进 draw 的 prompt。'
      + 'name 可以是中文（初音未来）、日文或英文（hatsune miku / hatsune_miku）。'
      + '返回标准角色标签 + 该角色样本图里的高频共现标签（带出现比例）。'
      + '**只有通过标签库确认的标签才会被当作角色标签**：没确认的会明确告诉你"不确定"，不要拿它当角色标签用。',
    category: 'media',
    icon: '🔎',
    parameters: {
      type: 'object',
      properties: {
        name: { type: 'string', description: '角色名，中文/日文/英文都行，例如「初音未来」「雷姆」「hatsune miku」' },
        sample: { type: 'number', description: '统计多少张样本图来算高频标签，默认用设置里的值（60），范围 10~100' }
      },
      required: ['name']
    },
    async execute(_ctx, args) {
      const name = config.truthyStr(args?.name);
      if (!name) return { content: '缺少 name：告诉我角色名。', isError: true };
      try {
        return await characterLookupText(name, args?.sample);
      } catch (error) {
        log.warn(`查角色标签失败：${errText(error)}`);
        return { content: `查标签库失败：${errText(error)}`, isError: true };
      }
    }
  });

  // ── 工具二：查提示词标签库 ──────────────────────────────────
  const libForSchema = library.loadLibrary({ dataDir: runtime.dataDir, paths: libraryPathsFor(runtime.dataDir) });
  const cats = libCategories(libForSchema);
  api.registerTool({
    id: 'prompt_tags',
    name: '查提示词标签库',
    description:
      `查一份**逐个核对过写法**的提示词标签库（${Array.isArray(libForSchema?.rows) ? libForSchema.rows.length : 0} 个概念 / `
      + `${cats.length} 个类目）。用来把中文描述变成**准确的 danbooru 标签**或**自然语言短语** —— `
      + '凭记忆写标签经常写错写法，写法错了模型就不认识，等于白写。\n'
      + '**什么时候用**：群友的要求里有具体视觉概念时（天气、光线、场景、服装、姿势、表情、画风、道具、动物…），先查一下再拼进 draw 的 prompt。\n'
      + '**两种产出**：`标签` 给 SDXL / Illustrious 档用（标签串）；`自然语言` 给 Anima 档用（直接抄那句英文描述）。\n'
      + '不传参数调用会列出全部类目。\n'
      + `类目：${cats.map((x) => `${x.id}（${x.name}）`).join('、') || '（库未加载）'}`,
    category: 'media',
    icon: '📚',
    parameters: {
      type: 'object',
      properties: {
        query: { type: 'string', description: '要查的概念，中文或英文都行，也可以直接查标签名（如「雨天」「rain」「umbrella」「银发」「回眸」）' },
        category: { type: 'string', description: '限定某个类目 id（可选）；不传则在全部类目里查' },
        limit: { type: 'number', description: '返回条数上限，默认 12（范围 1~50）' }
      }
    },
    async execute(_ctx, args) {
      const lib = library.loadLibrary({ dataDir: runtime.dataDir, paths: libraryPathsFor(runtime.dataDir) });
      if (!Array.isArray(lib?.rows) || !lib.rows.length) {
        return {
          content: `提示词库没加载成功：${R(lib?.reason || '缺 prompt-library.json')}。请检查技能目录里有没有这个文件。`,
          isError: true
        };
      }
      const query = config.truthyStr(args?.query);
      const category = config.truthyStr(args?.category);
      if (!query && !category) {
        const lines = [`提示词库：${lib.rows.length} 个概念 / ${libCategories(lib).length} 个类目`, ''];
        for (const x of libCategories(lib)) {
          lines.push(`- ${x.id}（${x.name}）${x.domain === 'convention' ? '  ← 提示词约定类' : ''}：${x.n} 个概念`);
        }
        lines.push('', '用 query 查具体概念（如 query="雨天"），或用 category 查某个类目（如 category="lighting"）。');
        return { content: lines.join('\n') };
      }
      const r = library.searchLibrary(lib, query, {
        category,
        limit: config.intIn(args?.limit, 1, 50, 12)
      });
      log.debug(`查提示词库：query=「${query}」category=「${category}」→ ${Number(r?.total) || 0} 条`);
      const merged = { ...r, categories: libCategories(lib), verified: lib.verified };
      return { content: formatLibraryHits(merged, query, category) };
    }
  });

  // ── 工具一：画图 ────────────────────────────────────────────
  api.registerTool({
    id: 'draw',
    name: 'AI 画图',
    description:
      '用本机 ComfyUI 按描述生成一张图并发送到当前会话。模型（Anima 三件套或 SDXL 单文件大模型）由技能设置里的下拉决定，'
      + '参数默认跟着选中的模型走（Anima 蒸馏 12 步 / CFG 1、Anima 基础与美学 30 步 / CFG 4、SDXL 单文件 28 步 / CFG 5）。\n'
      + '适用：群友说「画一个…」「帮我画…」「生成一张…的图」。\n'
      + '**中文可以直接写进 prompt**，技能会自动翻译成英文再画（要 1~2 秒；翻译失败会明确报错，不会拿中文去出图）。\n'
      // 工具全名由**宿主**按技能 id 拼成 `<id>__<toolId>`（这里注册的 id 都是不带前缀的，见 api.registerTool 调用）。
      // 所以这句话必须跟着 id 走 —— 用 SKILL_ID（从目录名推导），别写死。
      + `群友点名要画某个具体角色时，先用 ${SKILL_ID}__find_character_tags 查标准标签，再把标签拼进 prompt；`
      + '要"长得像"还可以传 ref_character。\n'
      + '**群友自己发了图、或引用着某张图说「照着这个画」时，用 ref_message_id 传那条消息的 #数字**'
      + '（拿不准 id 就用 ref_recent_image）—— 那是**最准的参考**，就是群友本人给的那张。\n'
      + '**默认的 ref_mode=appearance 只从参考图里提取外观标签写进 prompt，不拿参考图当底图重绘**：'
      + '构图/姿势/机位/背景完全由 prompt 决定。只有群友明确要求"照抄构图/姿势/同款机位"时才传 ref_mode="composition"。\n'
      + '质量词由工具自动补，不用自己写。',
    category: 'media',
    icon: '🎨',
    parameters: {
      type: 'object',
      properties: {
        prompt: {
          type: 'string',
          description:
            '画面描述。**中文或英文都行**（中文会被自动翻译）。描述人物特征、服装、动作、场景、光线、镜头。'
            + '如果已经用 find_character_tags 查到了角色标签，把标签和场景拼在一起，'
            + '例如：hatsune_miku, twintails, aqua_hair, aqua_eyes, drinking bubble tea, sitting in a cafe, warm lighting'
        },
        negative_prompt: { type: 'string', description: '额外要避免的内容（可选）。常规负面词已自动带上。' },
        ref_character: {
          type: 'string',
          description:
            '**角色外观参考**（可选）。填一个角色名（中文/日文/英文都行：「初音未来」「雷姆」「frieren」）。'
            + '技能会去标签库确认这个角色的标准标签，再找一张**确实是这个角色**的图当参考（走 booru 标签，标签本身就是保证）。'
            + '**只有通过标签库确认的标签才会补进 prompt**（没确认的绝不会被当成角色标签用）。'
            + '配合默认的 ref_mode=appearance 时，这张图**只用来提取外观**（发型/发色/瞳色/配饰），不会被当成底图重绘。'
        },
        ref_keyword: {
          type: 'string',
          description:
            '参考图关键词（可选）。填了就先用「智能配图」找一张真实图片当参考。'
            + '例如群友说「照着樱花树下那种感觉画」就填「樱花树下少女」。'
            + '**只在群友确实想要"照着某张图"时才填**，普通「画一个…」不要填（那会限制发挥）。'
            + '要画具体角色请优先用 ref_character。'
        },
        ref_mode: {
          type: 'string',
          enum: ['appearance', 'composition'],
          description:
            '参考图怎么用（可选）。**不填 = 跟随技能设置**（设置里当前是 appearance 还是 composition 以实际为准；'
            + '出厂默认值是 appearance，但用户可能改过）。'
            + '**appearance = 只取外观**：从参考图里提取发型/发色/瞳色/配饰/服装写进 prompt，'
            + '走**纯文生图**，构图/姿势/机位/背景完全由 prompt 决定。'
            + 'composition = 按参考图重绘（img2img），构图和姿势会跟着参考图走。'
            + '群友说「画成这样的」但没要求照抄姿势构图 → 用 appearance。'
        },
        ref_denoise: {
          type: 'number',
          description:
            '参考图重绘幅度 0.2~0.95（可选，默认跟随技能设置）。**只在 ref_mode=composition 时生效**（appearance 模式不重绘）。'
            + '**越低越像参考图**（0.3 几乎照抄构图只换画风），**越高越自由**（0.8 只借个大概布局）。'
            + '群友说「就要这张的感觉」用 0.35~0.5；说「参考一下但换个场景」用 0.6~0.75。'
        },
        ref_file: {
          type: 'string',
          description:
            '参考图的本地文件路径（可选，一般不用填）。**允许任意本地路径**（不限技能目录），'
            + '但要过体积与格式校验：扩展名必须是 png/jpg/jpeg/webp/gif，文件头必须真的是图片，'
            + '且不超过技能设置里的参考图体积上限（默认 8MB）。在校验不通过时会明确告诉你原因。'
            + '正常用 ref_keyword / ref_message_id 让技能自己找。'
        },
        ref_message_id: {
          type: ['integer', 'string'],
          description:
            '**用聊天里某条消息的图片当参考图**（可选）。填那条消息的 id —— 就是聊天记录里每条消息前的 #数字（可能为负数，'
            + '带不带 # 都行）。**这是最准的参考**：群友自己发的图就是他要的那张。'
            + '适用：群友发了图/引用着图说「照着这个画」「画成这样的」「同款」。'
            + '注意 id 只能填聊天记录里真实出现过的 #数字，不要自己编。'
        },
        ref_recent_image: {
          type: 'boolean',
          description:
            '用当前会话里**最近一张**群友发的图片当参考（可选）。'
            + '当你拿不准该用哪条消息的 id 时用这个（与 ref_message_id 二选一，ref_message_id 更精确）。'
        },
        size: {
          type: 'string',
          enum: ['1024x1024', '832x1216', '1216x832', '1152x896', '896x1152', '1344x768', '768x1344'],
          description:
            '画面尺寸（可选）。不填用技能设置里的默认尺寸（现为 1024x1024）。'
            + '**只在 ref_mode=composition（按参考图重绘）时**，不填才会按参考图比例自动算；'
            + '默认的 appearance 模式不拿参考图当底图，尺寸与参考图无关，不填就是设置里的默认尺寸。'
            + '竖图（人像全身）用 832x1216，横图（风景）用 1216x832。'
        },
        width: {
          type: 'number',
          description: '画面宽度（像素，512~1536，会被对齐到 64 的倍数；可选）。与 size 二选一，**size 优先**。'
        },
        height: {
          type: 'number',
          description: '画面高度（像素，512~1536，会被对齐到 64 的倍数；可选）。与 size 二选一，**size 优先**。'
        },
        steps: {
          type: 'number',
          description:
            '采样步数（可选）。**不填或填 0 = 按模型推荐值**（Anima 蒸馏版 12、Anima 基础/美学版 30、SDXL 单文件 28）。'
            + '范围 1~150，一般不建议超过 60（再高只烧时间）。'
        },
        cfg: {
          type: 'number',
          description:
            'CFG 强度（可选）。**不填或填 0 = 按模型推荐值**（Anima 蒸馏版 1、Anima 基础/美学版 4、SDXL 单文件 5）。范围 0~20。'
        },
        seed: { type: 'number', description: '随机种子（可选）。不填 = 每次随机；固定一个数字可复现同一张图。' }
      },
      required: ['prompt']
    },

    async execute(ctx, args) {
      const c = runtime.cfg() || {};
      const inputPrompt = config.truthyStr(args?.prompt);
      if (!inputPrompt) return drawFail('缺少 prompt：请给我要画的画面描述。');
      if (!ctx?.sender || typeof ctx.sender.sendImage !== 'function') {
        return drawFail('当前上下文拿不到 sender，无法发图。');
      }

      // ── 1. 入队：串行 + 上限 6 ────────────────────────────────
      // 队列计数**如实**报（含正在画的那张），并且整段用 try/finally 记账（E13）。
      const pending = queueDepth();
      if (pending >= QUEUE_MAX) {
        return drawFail(`前面还有 ${pending} 张在排队（含正在画的那张），等它们画完再让我画吧。`);
      }
      log.info(`收到画图请求（队列里 ${pending} 张）`);
      return enqueue(() => runDraw(ctx, args));
    }
  });

  // ── 启动后的模型扫描 + 目录监听（E9）────────────────────────
  //
  // 为什么延迟 1.5 秒：让宿主的技能加载流程先走完，别和"设置界面首次渲染"抢资源。
  // "该不该扫"由 bootScanDecision() 按 **skill.json 的实际状态**判断（指纹 + 下拉是否空 + 值是否失效）：
  // 这样"安装脚本先写代码、后覆盖 skill.json"造成的空下拉会被下一次重载立刻补上，
  // 而我们自己写盘触发的那次重载因为指纹一致而跳过 —— 自激照样防住。
  setTimeout(() => {
    void (async () => {
      try {
        startModelWatch(runtime.cfg() || {});
        await bootScan();
      } catch (error) {
        log.warn(`启动扫描/监听失败（不影响出图，可用 comfyui_models 手动重扫）：${errText(error)}`);
      }
    })();
  }, 1500).unref?.();
  setTimeout(() => {
    // 设置可能在启动 1.5 秒时还没到位：再过一会儿重新挂一次监听（stop 旧的是幂等的）
    try { if (runtime.cfg()?.comfyuiDir) startModelWatch(runtime.cfg() || {}); } catch { /* 忽略 */ }
  }, 8000).unref?.();

  log.info(`${SKILL_ID} 已注册 4 个工具：draw / prompt_tags / find_character_tags / comfyui_models`
    + `｜ComfyUI ${baseUrlOf(runtime.cfg() || {})}`
    + `｜data ${logLib.redact(runtime.dataDir)}`
    + '｜参数默认跟随模型（Anima 蒸馏 12/1、Anima 基础与美学 30/4、SDXL 单文件 28/5）');
}

/**
 * 内省出口：**不属于规格 §4 的冻结接口**，只给测试/排查用（lib/models.js、lib/library.js 也有同款）。
 * 有了它，"模型目录集怎么算出来的""modelRoute 怎么定的"可以在不启动宿主、不碰 skill.json 的前提下断言。
 */
export const __internal = {
  modelDirsOf, modelsRootsFor, comfyRootsFor, dirsForLog, dirTail,
  planGeneration, explicitRoute, routeLine, modelLine, rolePick, roleFailText, scanPick, preferFor, PREFER_FALLBACK,
  settingsStatusText, modelListText, pickedClearedLines, pickedSource, originText, tierLabel,
  readParamSource, logParamSource, startedNote, bootScanDecision, bootScan, skillJsonFingerprint, SELF_SKILL_JSON,
  skillStateMap, skillStateFingerprint, readModelEnumState, modelEnumKeys,
  refreshModelsNs, loraSlotsFromSchema, hasEntriesDir, logModelDirs,
  SKILL_ID, LEGACY_SKILL_ID, migrateSettingsFromLegacyId, effectiveSettings, skillDataDirOf, libraryPathsFor,
  packageDefaultSettings, legacyMigrationNote, settingsNow: () => runtime.cfg(),
  loraLine, clampLoraWeight, weightText, loraMissingText, buildLoraChain, loraSlots,
  loraLowCfgNote, receiptHeadText, cfgText,
  buildWorkflow, resolveSize, sizeLine, safeResolveParams, safeHiresPlan, attributeStarted, isPidAlive, autoStartOffText,
  cleanupOwnTempFiles, getState, bridgeLogger
};
