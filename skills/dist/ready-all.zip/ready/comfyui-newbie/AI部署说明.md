# AI部署说明 · QQ Agent 画图包 v5

> 这份是**给 AI 助手（或替你操作的人）看的操作手册**：命令、验收标准、失败口径、排错、下载脚本。
> 人看的介绍在 `介绍.md`。本包只有**一个**技能：`comfyui-newbie`（画图）。图上的写字整块不做。

---

## 0. 验收标准（照这个判"装好没装好"）

| # | 标准 | 怎么验 |
|---|---|---|
| 1 | `install.mjs` 正常装完，退出码 0 | `echo $LASTEXITCODE`（PowerShell）/ `echo %ERRORLEVEL%`（cmd） |
| 2 | `check.mjs` 输出里**没有 `✘`** | 有 `!` 没关系 —— **缺模型文件属于提醒，不算失败** |
| 3 | `check.mjs --draw` 真出一张 512×512 | 产物落盘、尺寸正确、回执与实际一致 |
| 4 | 六项回归测试通过（`SKIP` 不算失败） | `tests\01-draw` … `06-lora-chain`，退出码 0 |
| 5 | 技能在控制台里 `active=true`、`loadError` 为空、注册 4 个工具 | `check.mjs` 第 3 节，或控制台 → 技能 |
| 6 | **没有动用户已有的设置** | `enabled` / `cooldownSec` / `timeoutSec` 及用户填过的 `baseUrl`、`comfyuiDir`、`lora1~5` 保持原值 |

> `!` = 提醒（本机没放某个模型、ComfyUI 没开、**装的是别的版本**…）。`✘` 只留给三种真问题：**技能没装 / 连不上 ComfyUI / 出图失败**。
> ⚠️ 同一条原因不会既报 `!` 又报 `✘`：文件齐全（版本不同也算齐全）就照常做 `--draw` 实测。

## 1. 命令速查

```powershell
# 只看计划，一个字节都不改（推荐先跑这个）
node install.mjs --app "D:\你的\QQ Agent" --comfy "D:\AI\ComfyUI" --dry-run

# 真装（可重复执行）
node install.mjs --app "D:\你的\QQ Agent" --comfy "D:\AI\ComfyUI"

# 体检 + 真跑一张 512×512
node check.mjs --app "D:\你的\QQ Agent" --draw

# 五项回归测试
node tests\01-draw.mjs                --app "D:\你的\QQ Agent"
node tests\02-params.mjs              --app "D:\你的\QQ Agent"
node tests\03-models.mjs              --app "D:\你的\QQ Agent" --comfy "D:\AI\ComfyUI"
node tests\04-redact.mjs              --app "D:\你的\QQ Agent"
node tests\05-prefer-consistency.mjs  --app "D:\你的\QQ Agent"
```

| 参数 | 用在哪 | 说明 |
|---|---|---|
| `--app <目录>` | install / check / tests | QQ Agent 安装目录（**含 `resources\app\skills`** 的那一层）。指到 `resources\app` 也能认 |
| `--comfy <目录>` | install / check / tests | ComfyUI 安装目录。**不合法会立刻早退并打印正确用法**，绝不会先动技能再报错 |
| `--base-url <地址>` | install / check / tests | ComfyUI 地址，默认 `http://127.0.0.1:8188`；生成的 `run_nvidia_gpu.bat` 端口跟着它走 |
| `--console <地址>` | install / check | 控制台地址，默认 `http://127.0.0.1:3210` |
| `--dry-run` | install | 零改动；会打印每一步"真跑时会做什么" |
| `--draw` | check | 真跑一张 512×512 并校验产物 |
| `--data-dir <目录>` | check | 显式指定 data 目录（默认自动判定） |
| `--unet/--clip/--vae` | install | 显式指定模型文件名，覆盖预填 |
| `--no-write` | tests/03-models | 跳过"临时放一个假模型"的增删识别段 |

**路径都不要写死**：四个脚本都用 `--app` / 自动探测，探测不到就报一条明确的失败让你补参数。

## 2. `install.mjs` 到底做了什么（以及它的保证）

1. **定位 QQ Agent**（认含 `resources\app\skills` 的那层）→ 判定 data 目录
2. **备份 + 原子安装技能**
   - 旧目录**先整目录备份**成 `comfyui-newbie.bak-backup-<时间戳>`，逐项校验文件数与字节数；
   - **备份失败即中止**，一个字节都不动原目录（绝不"备份失败还照样删原目录"）；
   - 安装包先拷到**同盘**临时目录 → 旧目录改名让开 → 临时目录 rename 就位；
   - 任一步失败**自动回滚**（把备份改回原名），并如实说明"原目录未改动 / 已回滚 / 回滚也失败（备份在哪）"。
3. **处理旧目录名的技能目录**（`skills\comfyui-image\`，老用户升级路径）—— 目的是**避免两个画图技能同时注册**
   （每条消息被两个技能抢、各出一张图、冷却互相打架）。判据是"**三个我方标记全都要有**"：
   `lib\` 目录 + `prompt-library.json` + `skill.json` 的署名含 `Toga` / `Mozamubik`。
   - **是**本技能的旧版 → 整目录**同盘 rename** 到 `<app>\_skill-backups\<时间戳>\comfyui-image.bak-<时间戳>\`（两个都不丢，可回滚）；
   - **不是**（例：QQ Agent 自带的官方 `comfyui-image`，它是从本项目派生出去的宿主资源）→ **一个字节都不动**，
     改为在配置里把 `skills['comfyui-image'].enabled = false` **停用**（同样可逆：控制台里重新启用即可）；
   - 输出里会写清走的是哪条、以及"确认新版没问题后可自行删除备份"。
4. **把同 id 的旧备份移出技能树**（防"装了等于没装"）：
   宿主是按目录里的 `skill.json` **id** 建索引的。`skills\` 下若同时有 `comfyui-newbie\` 与
   `comfyui-newbie.bak-backup-<ts>\`（同 id），**谁是赢家取决于扫描顺序**（不确定）。
   真机实测过：磁盘上是 v5.0.0，控制台条目却是 `dir=skills/comfyui-newbie.bak-backup-…` `v=4.4.0`，
   群里跑的还是旧代码。所以安装后会把 `skills\` 下**本包会装的 id** 的所有 `*.bak-*`（含历史遗留）
   **同盘 rename** 到 `<app>\_skill-backups\<时间戳>\`。
   - 安全检查：路径必须在 `skills\` 下、名字必须含 `.bak`、目标不存在；移动失败只 `!` 提醒（不算安装失败）
   - 为什么必须同盘：`rename` 跨卷会 `EXDEV`（D:→C: 实测失败）；`_skill-backups` 在 app 目录下，同一个卷
   - **回滚**：把 `_skill-backups\<时间戳>\comfyui-newbie.bak-*` 改名回 `comfyui-newbie\`（先把现役的改名让开），再重启 QQ Agent
5. **定位 ComfyUI**（认两种布局：`main.py` 在根目录，或在 `ComfyUI\` 子目录）→ 生成 `run_nvidia_gpu.bat`
   - 同名旧文件先备份；文件内容来自**与 `payload\host\run_nvidia_gpu.bat` 同一份模板**（安装时会比对，不一致会报出来）；
   - 6 条 python 候选、端口参数化、失败时 `pause` 停窗；**纯 ASCII**（bat 跑在 OEM 代码页，写中文会乱码）。
6. **扫模型**：先 `/system_stats` 探活，再 `/object_info` 列模型 —— 两件事分开判，
   "在线但模型列表超时"与"根本没响应"给**不同**的文案（别把责任推给一个其实开着的服务）。
7. **写配置**：先读现有配置 → **只补用户没有的键** → 深合并 → 通过控制台 `POST http://127.0.0.1:3210/api/config` 写回**整份合并结果**
   （控制台没开才直写 `data\config.json`，且**原子写 + 写前备份**）。
   - **绝不写** `enabled`、`cooldownSec`、`timeoutSec`（用户关掉的开关、设过的冷却不该被安装脚本改回去 —— §6/E8）；
     唯一例外是第 3 步那种"同名但不是我们的技能"，明确写 `enabled=false` 把它停用；
   - 环境指向型键（`baseUrl` / `comfyuiDir` / 三个模型名）**只在其为空时**补；
   - 换了 id 之后，**旧 id 段里的用户设置会当作基底**（选过的模型名 / 冷却 / 开关不会被重置），旧段保留不删；
   - ⚠️ 控制台地址**固定 3210**：同机有多个 QQ Agent 时可能写到另一个安装，脚本会打一行提醒让人手动核对。
8. **重扫并核对"注册的到底是哪个目录 / 哪个版本"**：
   只看 `active=true` + 工具数**区分不出新旧** —— 旧版 v4.4.0 也注册同样的 4 个同名工具。
   所以必须断言 ① `dir` 不含 `.bak` 且等于 `skills/comfyui-newbie`；② `version` 等于本包 `skill.json` 的版本；③ `loadError` 为空。

> 第 5 步之后的任何意外都不会让脚本"装一半就死"：那几步包在 `try/finally` 里，
> 写配置与重扫**一定会尝试**，失败时打印"现在该做什么"（重跑 / 手动填设置 / 加 `trustedPlugins`）。

**失败口径**：技能没装成 / 配置写失败 / **注册的不是本次装的目录或版本** → **退出码 1**。安装包不完整 → 跳过该技能（不动任何文件）并给出缺哪个文件的清单；ComfyUI 没开、扫不到模型 → 只提醒，退出码仍为 0。

## 3. `check.mjs` 检查了什么

| 节 | 内容 | 失败口径 |
|---|---|---|
| 1 | 宿主位置、data 目录 | 找不到 → `✘` |
| 2 | 技能文件清单（与 `install.mjs` 的 `NEED` **同源**）、`lib\` 模块、提示词库、**装的是不是本包这一版**、**`skills\` 下有没有同 id 的 `.bak` 抢注册**、**有没有旧目录名 `comfyui-image\` 会同时注册** | 缺文件 / 缺 `lib\` / 有同 id 的 `.bak` / 有旧目录名 → `✘`；版本比本包旧 → `!` |
| 3 | 控制台状态、`loadError`、工具数、**实际注册的 `dir` 与 `version`**、关键配置 | 加载错误 / 列表里没有 / `dir` 带 `.bak`、是旧目录名 `comfyui-image`、或不是 `skills/comfyui-newbie` → `✘`；版本不一致 / 控制台没开 → `!` |
| 4 | ComfyUI 在不在、版本、python、torch、设备、显存、启动脚本 | 连不上 → `✘`（真问题） |
| 5 | **模型识别**：Anima 底模与变体（turbo / base / aesthetic）、编码器、VAE、LoRA、`checkpoints\` 单文件大模型 | 扫不到清单 → `!`；缺某一类 → `!` |
| **6.5** | **LoRA（可选）**：`models\loras\` 里发现几个 LoRA；**五个槽（1~5）**填的值在本机在不在；挂载顺序与"绝不自动挑"的说明 | 一个都没有 → `!`；槽里的值本机没有 → `!`（**都不算失败**） |
| 6 | **档位可用性**（三态） | 见下 |
| 7 | `--draw` 真跑一张 512×512，校验产物落盘 + 尺寸 | 出图失败 → `✘`；缺模型文件 → `!` + 说明缺什么 |

**档位是"自动判定"的，不是设置项**（见 `介绍.md` 的档位表）：

| 档位 | 判定依据 | 步数 / CFG | 采样器 / 调度器 |
|---|---|---|---|
| Anima 极速 | 底模文件名带 `turbo` | 12 / 1 | `euler` / `simple` |
| Anima 基础 / 美学 | 文件名带 `base` / `aesthetic` | 30 / 4 | `euler` / `simple` |
| Anima 兜底 | 认不出变体 | 30 / 4 | `euler` / `simple` |
| SDXL / 光辉 | `checkpoints\` 的单文件大模型 | 28 / 5 | `euler_ancestral` / `normal` |

三态含义：`✔ 可跑` / `! 缺文件（提醒，不算失败）` / `! 未知（ComfyUI 没开或列不出来，判断不了）`。
**缺模型文件永远不是 `✘`**；`✘` 只给"技能没装 / 连不上 ComfyUI / 出图失败"。

### LoRA 链（`check.mjs` 的 §6.5；规格《LoRA链-追加功能规格》L1~L7）

| 项 | 规则 |
|---|---|
| 槽位 | `lora1` / `lora2` / `lora3` / `lora4` / `lora5`（**5 个**），加原有的极速槽 `animaTurboLora`（优先级最前）—— 最多同时挂 **6 个** |
| 权重 | `lora1Weight` ~ `lora5Weight`，范围 **0 ~ 1.5**，默认 **0.8**（`0` 是有效值） |
| 候选 | `models\loras\` 里**全部** `.safetensors`；`values = ['', …]`，空串恒在第一位、label 是「（不用这个槽）」；一个文件都没有时是 `['']`（不是 `[]`） |
| 挂载顺序 | 极速槽 → 槽 1 → 槽 2 → 槽 3 → 槽 4 → 槽 5（顺序影响结果）；**同一文件不重复挂** |
| 节点号 | 极速槽 10、槽 1~5 = 13~17（**按槽位预留**：某个槽空着不会让后面的号前移）；其余节点 1~9、img2img 20~22 |
| **L1 绝不自动挑** | 五个槽的初值与 `syncSchema`/`buildSchemaPatch` 的自动选择一律保持 `""`，且**都不在 `PREFER` 里** —— 静默挂上用户没选的人物/画风 LoRA 会直接改变出图内容 |
| L2 选了但本机没有 | **不静默跳过**：不挂，并在回执里写"你要挂的 X 在本机不存在（本机有：…），这次没挂" |
| L4 蒸馏档 + 非 turbo LoRA | 允许挂，但回执提示一句（CFG 1 下画风/写实类 LoRA 可能不明显或跑偏） |
| L5 回执 | 一行 `- LoRA：X（0.8）、Y（1.0）`，只列本次**实际挂上**的（空槽位不出现） |

验证这条链**只认工作流里的 `LoraLoaderModelOnly` 节点**（`tests\06-lora-chain.mjs` 就是按图上的连接关系读顺序与权重的）。

## 4. 回归测试

```powershell
node tests\01-draw.mjs               --app "<QQ Agent>"                       # 真出图 + 尺寸
node tests\02-params.mjs             --app "<QQ Agent>"                       # §5 参数表三个分支（不需要 ComfyUI）
node tests\03-models.mjs             --app "<QQ Agent>" --comfy "<ComfyUI>"   # 模型识别 + 增删识别（假树，不碰真机目录）
node tests\04-redact.mjs             --app "<QQ Agent>"                       # 脱敏（含空格路径 / UNC / /Users）
node tests\05-prefer-consistency.mjs --app "<QQ Agent>"                       # 偏好顺序两处一致（防漂移，不需要 ComfyUI）
node tests\06-lora-chain.mjs         --app "<QQ Agent>"                       # LoRA 链：断言实际提交的工作流（不需要 ComfyUI）
```

- 退出码 `0` = 全通过（可带 `SKIP`），`1` = 有 `FAIL`。`SKIP` = 本机前提凑不齐（例如 `checkpoints\` 里没有单文件大模型）。
- `03-models` / `06-lora-chain` 只在 **`%TEMP%`** 里造假 ComfyUI 树（`06` 还会写两个假 `.safetensors`），跑完（含失败、Ctrl+C）整棵清理，**不碰任何真实模型文件**；不放心就加 `--no-write`。
- `06-lora-chain` 断言的是**实际提交给 ComfyUI 的工作流**（`LoraLoaderModelOnly` 节点的连接顺序与 `strength_model`），走真实代码路径 `planGeneration` → `buildWorkflow`，不自己拼图、也不需要 ComfyUI 在跑。
- 测试断言的是**技能自己导出的** `PARAM_TABLE` / `resolveParams` / `scanModels` / `detectChanges` / `syncSchema` / `classifyModel` / `buildSchemaPatch` / `redact` / `planGeneration` / `buildWorkflow` / `PREFER` / `LORA_SLOTS` —— 不在测试里重写一份逻辑（重写就等于测了个假的）。
- 技能模块还没到位时，测试会 `FAIL` 并说明"技能里没有 `lib/xxx.js`" —— 那是装残了/写错了，不该被 `SKIP` 掩盖。

## 5. 下载 Anima 三件套（命令行分块下载更稳）

ModelScope 上 `CircleStone-Labs/Anima` 的单文件直链（浏览器另存也行）：

```
底模   https://modelscope.cn/api/v1/models/CircleStone-Labs/Anima/repo?Revision=master&FilePath=split_files/diffusion_models/anima-turbo-v1.1.safetensors
编码器 https://modelscope.cn/api/v1/models/CircleStone-Labs/Anima/repo?Revision=master&FilePath=split_files/text_encoders/qwen_3_06b_base.safetensors
VAE    https://modelscope.cn/api/v1/models/CircleStone-Labs/Anima/repo?Revision=master&FilePath=split_files/vae/qwen_image_vae.safetensors
```

PowerShell 分块下载（断点续传，单连接卡住就重跑同一条命令）：

```powershell
$dst = "D:\AI\ComfyUI\ComfyUI\models\diffusion_models"
$url = "https://modelscope.cn/api/v1/models/CircleStone-Labs/Anima/repo?Revision=master&FilePath=split_files/diffusion_models/anima-turbo-v1.1.safetensors"
$out = Join-Path $dst "anima-turbo-v1.1.safetensors"
$chunk = 32MB
$done = if (Test-Path $out) { (Get-Item $out).Length } else { 0 }
while ($true) {
  $to = $done + $chunk - 1
  try {
    Invoke-WebRequest -Uri $url -Headers @{ Range = "bytes=$done-$to" } -OutFile "$out.part" -TimeoutSec 600
    $fs = [System.IO.File]::Open($out, 'Append'); $ps = [System.IO.File]::OpenRead("$out.part")
    $ps.CopyTo($fs); $ps.Close(); $fs.Close(); Remove-Item "$out.part"
    $done = (Get-Item $out).Length
    Write-Host "已下载 $([math]::Round($done/1MB,1)) MB"
  } catch { Write-Host "这一块失败（多半是断连）：$($_.Exception.Message) —— 重跑本段即可续传"; break }
}
```

下完把三个文件放进 `介绍.md` 那张表的对应目录，然后跑一次：

```powershell
node check.mjs --app "D:\你的\QQ Agent"
```

## 6. 排错

| 现象 | 原因 / 处理 |
|---|---|
| `install.mjs` 报"安装包不完整，缺 index.js" | `payload\skill\comfyui-newbie\` 没和 `install.mjs` 放一起，或被杀软删了。补全三个文件：`index.js`、`skill.json`、`prompt-library.json`（外加 `lib\` 整个目录） |
| 报"备份旧版失败 —— 已中止，原目录未改动" | 通常是 QQ Agent 还开着占用了技能目录。完全退出（含托盘）后重跑；**原目录没被动过**，放心 |
| 报"就位失败 —— 已回滚，原技能目录完好" | 同上；若同时提示"回滚也失败"，按提示里的路径手动把 `.bak-backup-*` 或 `.bak-*.old` 改回 `comfyui-newbie` |
| 装完控制台看不到技能 | 完全重启一次 QQ Agent（安装脚本会尝试 `POST /api/skills/reload`，控制台没开就失败，那不算安装失败） |
| **装完"看起来成功"、但群里跑的还是旧代码**（控制台条目指向 `…bak-backup-…`、版本还是旧的） | `skills\` 下同时有同 id 的 `.bak` 目录，宿主的去重选中了旧的那个。跑一次 `install.mjs`（第 3 步会把同 id 的 `.bak-*` 同盘移到 `<app>\_skill-backups\<时间戳>\`），再重启 QQ Agent。`check.mjs` 现在会直接报这一条（第 2 节报 `.bak` 抢注册、第 3 节比对实际注册的 `dir`/`version`） |
| 想回到旧版本 | 把 `<app>\_skill-backups\<时间戳>\comfyui-newbie.bak-*` 改名回 `comfyui-newbie\`（先把现役的 `comfyui-newbie\` 改名让开），再重启 QQ Agent |
| `check.mjs` 报 `✘ 连不上` | ComfyUI 没启动；或用 `--base-url` 指定真实地址 |
| `check.mjs` 报 `! 装的是 v4.x，本包带的是 v5.0.0` | 技能目录里还是旧版本：跑一次 `install.mjs`（旧目录会自动备份） |
| 出图报"模型没找到" | 用控制台的模型下拉选一个本机真实存在的文件；确认文件真的在 `models\` 对应子目录里 |
| 想挂的 LoRA 没生效 | ① 文件要放进 `ComfyUI\models\loras\`（`.safetensors`）；② 在设置 →「LoRA 槽 1~5」里**自己选**（技能绝不自动挑）；③ `check.mjs` 的 §6.5 会告诉你本机发现了几个、你选的还在不在；④ 回执里那一行 `- LoRA：X（0.8）` 只列真正挂上的 |
| 蒸馏档（CFG 1）下 LoRA 看起来没效果 | 这是 L4 的已知现象：低 CFG 下画风/写实类 LoRA 可能不明显甚至跑偏。关掉「参数自动跟随模型」、把 CFG 提到 3~5 再试 |
| 出图很慢 | 换 `anima-turbo-v1.1`、关二次放大、尺寸降到 832×1216 |
| 中文提示词没生效 | 翻译复用 QQ Agent 的 LLM 配置；控制台里把模型/provider 配好 |
| 技能日志在哪 | `<data>\logs\comfyui-newbie-YYYY-MM-DD.log`（warn/error 都会落盘；对外文案已脱敏，路径显示为 `<本机路径>`）。历史日志 `comfyui-image-*.log` 仍留在原地可查 |

## 7. 打包 / 交付注意

- **别把测试残留打进包**：`*.new-*`、`.tmp-*`、`.part-*`、`__pycache__`、`.bak-*`、任何 `logs\` 与 `data\` 内容都不该出现在交付包里。
- 原子安装/回滚这类测试的临时目标目录放在 **`%TEMP%`**，不要在包根建目录（否则几十万个空文件会跟着包走）。
- **不要在包根留测试快照**：像 `config.json` 快照这种含 api key 的文件一定要删（本包的验收过程里已经踩过一次，已清理）。
- `payload\skill\comfyui-newbie` 必须是**真目录**，不能是 junction/symlink（否则别人解压或安装会出问题）。
- 中文文件（`介绍.md` / `AI部署说明.md` / `skill.json` / `tests\README.md`）**一律用 Node 的 `fs` 读写**，不要拿 PowerShell 的 `Set-Content` / `Get-Content -Raw` 来回改 —— 那是 GBK↔UTF-8 的坑，会把中文整份写坏（字节数还不一定变，很难发现）。要原子写就 `fs.writeFileSync(tmp)` + `fs.renameSync`。

## 8. 本包文件清单

```
install.mjs                     一键安装（备份+原子替换+回滚、同 id 备份移出技能树、核对注册目录/版本、不强制改设置、失败计入退出码）
check.mjs                       环境检测（三态档位、✘ 只留真问题、核对实际注册的 dir/version、--draw 真跑一张）
介绍.md                         给人看的介绍（含"档位由所选模型自动判定"的表）
AI部署说明.md                    本文件
payload\skill\comfyui-newbie\    技能本体：index.js + lib\{log,config,models,params,comfy,llm,tags,library,refs}.js
                                + prompt-library.json（沿用旧包的数据文件）+ skill.json
payload\host\run_nvidia_gpu.bat 手动启动脚本的参考副本（与 install.mjs 的生成器同源）
tests\_harness.mjs              测试公用工具（data 目录判定：先看 QQ_AGENT_DATA_DIR 再回落）
tests\01-draw.mjs               出图主链路 + 产物尺寸
tests\02-params.mjs             参数表三个分支 + 显式 0 语义
tests\03-models.mjs             模型识别 + 增删识别（在 %TEMP% 假 ComfyUI 树上做）
tests\04-redact.mjs             脱敏（含空格路径 / UNC / /Users）
tests\05-prefer-consistency.mjs 偏好顺序两处一致（PREFER vs index.js rolePick，防漂移）
tests\06-lora-chain.mjs         LoRA 链：断言实际提交的工作流（顺序 / 权重 / 绝不自动挑）
tests\README.md                 测试用法与 SKIP 约定
```

> 装到目标机器后，`<QQ Agent>\resources\app\skills\` 下每个 id **只应有一个目录**；
> 被替换掉的旧版本会被移到 `<QQ Agent>\_skill-backups\<时间戳>\`（不在技能树里，不会跟新版本抢注册）。
