/**
 * follow-up-window —— 群聊「接话窗口」（确定性型插件 / 放在 plugins/）
 *
 * ── 用户要的行为 ─────────────────────────────────────────────────────────
 *   1. 只在群聊生效，私聊不碰。
 *   2. 群聊常态按概率触发（默认 30%，可改）。
 *   3. 机器人发言之后，接下来的 3~5 条群消息是一个“回话窗口”：
 *      先读这些消息，判断它们和机器人刚说的话有没有关系。
 *        · 有关   → 正常进入思考并回答；
 *        · 无关   → 回落到常态概率，抽中才回答，没抽中就静默。
 *
 * ── 为什么做成插件，而不是技能 ───────────────────────────────────────────
 *   触发时机是死规则（“机器人发言后 + 接下来 3~5 条”），而且必须在
 *   核心的“响应档位”判定之前/之外生效 —— 这不能交给模型自己决定。
 *   技能只能注册工具，模型没被触发时根本看不到工具，会静默失效。
 *   所以放 plugins/，用 hooks 插进主流程：
 *     · after-tool         机器人真的把消息发出去后，开窗口；
 *     · before-context     核心已经决定要跑这一轮时，做相关性判定；
 *     · before-llm-messages 把“这是接话 / 这是静默”告诉模型；
 *     · before-tool        静默轮硬拦所有工具，防止模型偷偷发消息；
 *     · llm.request-params 静默轮只留 finish，尽量少花 token。
 *
 * ── 关键实现限制（源码事实）─────────────────────────────────────────────
 *   核心的 resolveContextTier() 是 prompt.js 里的模块级函数，没有对外
 *   暴露“触发前”钩子。扩展无法在“这条消息要不要触发”之前插一脚，所以：
 *     · 开窗口时，临时把这个群的档位顶到 100%（让每条消息都进入判定）；
 *     · 在 before-context 里再做相关性 / 常态概率判定；
 *     · 无关且没抽中 → 静默轮：不向群里发任何内容。
 *   这保证“群里看到的行为”符合要求；代价是无关消息也会产生一次极小的
 *   收尾调用（只保留 finish 工具、提示词替换成一句话）。不这么做，
 *   扩展层没有任何办法在核心掷骰子之前把 30% 改成“有关必接”。
 *
 *   档位覆盖只改 getConfig() 的内存对象，不写 data/config.json；窗口结束、
 *   插件关闭或热重载时恢复原值。同步常态概率也只在内存里做，重启后由
 *   activate() 重新应用。
 */

const BUILD_TAG = 'v1.0.0';

const DEFAULTS = {
  normalProbability: 30,
  windowMin: 3,
  windowMax: 5,
  windowTtlSec: 300,
  relevance: 'balanced',
  syncGlobalProbability: true,
  silentWhenUnrelated: true
};

const WINDOW_NOTE_MARK = '【回话窗口】';
const GATE_SYSTEM = [
  '你是 QQ 群聊里的静默收尾器。',
  '本轮已经被判定为：新消息和机器人刚才的话无关，而且常态概率没有抽中。',
  '不要接话，不要解释，不要调用除 finish 之外的任何工具。',
  '只调用 finish，把 summary 写成“无关，跳过”。'
].join('');
const GATE_USER = '（本轮静默跳过，不向群里发送任何内容）';

const SEND_TOOLS = new Set([
  'send_message',
  'send_to',
  'send_image',
  'send_sticker',
  'send_poke'
]);

/** 这些词太常见，不能单独当作“共同话题”的证据。 */
const STOP_BIGRAMS = new Set([
  '这个', '那个', '什么', '怎么', '就是', '不是', '可以', '我们', '你们', '他们',
  '真的', '哈哈', '然后', '因为', '所以', '但是', '还是', '已经', '没有', '一个',
  '现在', '时候', '自己', '知道', '觉得', '可能', '应该', '如果', '这样', '那样',
  '一下', '一点', '有点', '其实', '只是', '不过', '而且', '或者', '以及', '还有',
  '这种', '那种', '今天', '明天', '昨天', '晚上', '早上', '中午', '刚才', '刚刚',
  '确实', '一样', '也是', '不是', '没有', '这么', '那么', '多少', '为什么'
]);

let cfg = () => ({});
let log = () => {};
let warn = () => {};
let getConfig = null;
let loadConfig = null;
let tierToSlider = null;

/** chatKey -> { botText, botAt, remaining, expiresAt, sessionId } */
const windows = new Map();
/** sessionId -> { suppressed, related, why, botText, at } */
const decisions = new Map();
/** chatKey -> { id, prevPeak, prevSlider } */
const forcedChats = new Map();
let baseUnifiedTier;
let baseUnifiedSaved = false;
let janitor = null;
let lastSyncedProbability = null;
let lastAppliedPos = null;
let globalSnapshot = null;

// ───────────────────────────── 设置 ─────────────────────────────

function clampInt(value, min, max, fallback) {
  const n = Number(value);
  if (!Number.isFinite(n)) return fallback;
  return Math.max(min, Math.min(max, Math.round(n)));
}

function settings() {
  const s = (typeof cfg === 'function' ? cfg() : null) || {};
  const num = (key, min, max) => {
    const n = Number(s[key]);
    if (!Number.isFinite(n)) return DEFAULTS[key];
    return Math.max(min, Math.min(max, Math.round(n)));
  };
  const bool = (key) => (s[key] === undefined || s[key] === null ? DEFAULTS[key] : s[key] !== false);
  let windowMin = num('windowMin', 1, 20);
  let windowMax = num('windowMax', 1, 20);
  if (windowMax < windowMin) [windowMin, windowMax] = [windowMax, windowMin];
  return {
    normalProbability: num('normalProbability', 0, 100),
    windowMin,
    windowMax,
    windowTtlSec: num('windowTtlSec', 30, 3600),
    relevance: ['loose', 'balanced', 'strict'].includes(s.relevance) ? s.relevance : DEFAULTS.relevance,
    syncGlobalProbability: bool('syncGlobalProbability'),
    silentWhenUnrelated: bool('silentWhenUnrelated')
  };
}

function clone(value) {
  if (value === undefined) return undefined;
  try { return structuredClone(value); } catch { return JSON.parse(JSON.stringify(value)); }
}

// ───────────────────────────── 文本与相关性 ─────────────────────────────

/** 去掉 CQ 码、媒体占位、@ 片段，只留真正打出来的字。 */
export function normalizeForMatch(text) {
  return String(text == null ? '' : text)
    .replace(/\[CQ:[^\]]*\]/g, ' ')
    .replace(/\[[^\]]{0,80}\]/g, ' ')
    .replace(/@[^\s]{1,32}/g, ' ')
    .replace(/https?:\/\/\S+/gi, ' ')
    .replace(/[^\p{Script=Han}\p{L}\p{N}]+/gu, ' ')
    .toLowerCase()
    .replace(/\s+/g, ' ')
    .trim();
}

/** 中文按二元组、英文/数字按词切，够做“有没有共同话题词”的粗判。 */
function tokenize(text) {
  const out = new Set();
  const s = String(text || '');
  for (const run of s.match(/[\p{Script=Han}]+/gu) || []) {
    if (run.length === 1) out.add(run);
    else for (let i = 0; i < run.length - 1; i += 1) out.add(run.slice(i, i + 2));
  }
  for (const word of s.match(/[a-z0-9_]{2,}/g) || []) out.add(word);
  return out;
}

function isQuoteToBot(raw, ctx = {}) {
  for (const entry of ctx.entries || []) {
    const reply = entry?.reply;
    if (!reply) continue;
    const sender = String(reply.sender || '');
    const senderId = String(reply.senderId || '');
    const selfId = String(ctx.selfId || '');
    if (senderId && selfId && senderId === selfId) return true;
    if (sender === '我') return true;
    if (sender && ctx.selfNickname && sender.includes(ctx.selfNickname)) return true;
    if (sender && ctx.botName && sender.includes(ctx.botName)) return true;
  }
  const match = String(raw).match(/\[引用\s*([^：:\]]+)(?:[：:]([^\]]*))?\]/);
  if (!match) return false;
  const sender = String(match[1] || '').trim();
  if (!sender) return false;
  if (sender === '我') return true;
  if (ctx.selfNickname && sender.includes(ctx.selfNickname)) return true;
  if (ctx.botName && sender.includes(ctx.botName)) return true;
  if (ctx.selfId && sender.includes(ctx.selfId)) return true;
  return false;
}

function isAddressedToBot(raw, ctx = {}) {
  const text = String(raw || '');
  const names = [ctx.selfNickname, ctx.botName].map((x) => String(x || '').trim()).filter(Boolean);
  for (const name of names) {
    if (text.includes(`@${name}`)) return true;
  }
  if (ctx.selfId && text.includes(`(QQ:${ctx.selfId})`)) return true;
  return false;
}

/**
 * 判断“新消息”和“机器人上一句”有没有关系。
 *
 * 这是本地启发式，不调用模型（钩子只有 5 秒且不允许发请求）。它宁可
 * 把边界情况判成“有关”（多接一次），也不轻易把明显接话判成“无关”。
 * 真正的语义细判仍交给主模型 —— 这里只决定“要不要让它进入思考”。
 *
 * @param {string} botText 机器人刚发出去的话
 * @param {string} newText 新消息合并文本
 * @param {object} ctx { selfNickname, botName, selfId, entries }
 * @param {'loose'|'balanced'|'strict'} mode
 * @returns {{related:boolean, score:number, why:string}}
 */
export function judgeRelevance(botText, newText, ctx = {}, mode = 'balanced') {
  const bot = String(botText || '').trim();
  const raw = String(newText || '').trim();
  if (!bot || !raw) return { related: false, score: 0, why: '缺少可对照的文本' };

  const quoteBot = isQuoteToBot(raw, ctx);
  const addressed = isAddressedToBot(raw, ctx);
  const botNorm = normalizeForMatch(bot);
  const newNorm = normalizeForMatch(raw);
  if (!botNorm || !newNorm) return { related: false, score: 0, why: '文本里没有可匹配的字词' };

  const botTerms = tokenize(botNorm);
  const newTerms = tokenize(newNorm);
  const shared = [...newTerms]
    .filter((term) => botTerms.has(term) && !STOP_BIGRAMS.has(term))
    .slice(0, 8);
  const sharedCount = shared.length;

  const short = newNorm.length <= 14;
  const botAsked = /[?？]|吗|呢|什么|怎么|为什么|哪|谁|多少|如何|是不是|要不要|行不行|有没有/.test(bot);
  const botRequest = /(帮我|帮忙|查|搜|找|来|发|看看|推荐|告诉|给我|能不能|可以|麻烦)/.test(bot);
  const questionLike = /[?？]|吗|呢|怎么|为什么|为啥|咋|什么|哪|谁|多少|如何|是不是|要不要|行不行|有没有/.test(raw);
  const discourse = /(刚才|刚刚|上面|前面|你说|你说的|这话|那句|继续|然后呢|后来呢|所以呢|为什么|怎么说|真的假的|不会吧|确实|同意|不对|不是|哈哈|笑死|离谱|有道理|我也是|我也|一样|谁不是)/.test(raw);
  const openFollow = /^(怎么|为啥|为什么|咋|然后|后来|真的|确实|不会吧|什么意思|怎么说|继续|然后呢|所以呢|发生|出了|咋了|怎么了)/.test(raw.trim());
  const answerish = short && !questionLike && !openFollow;
  const agree = /^(我也|我也是|我也觉得|一样|同样|确实|真的|可不是|谁不是|有道理|同意|对的|是啊|对啊|好家伙|笑死|哈哈)/.test(raw.trim());
  const directYou = /(^|[\s，。！？~、])(你|妳)(?=[\s，。！？~、]|$)/.test(raw)
    || (short && /你(觉得|说|看|呢)?/.test(raw));
  const shortReaction = short && /^(哈|笑|啊|嗯|哦|对|是|好|行|可以|6|牛|草|乐|典|绷|？|\?)/.test(raw.trim());
  const newTopicish = newNorm.length >= 24 && sharedCount === 0 && !quoteBot && !addressed && !discourse && !agree;

  let score = 0;
  const reasons = [];

  if (quoteBot) { score += 6; reasons.push('引用了你'); }
  if (addressed) { score += 4; reasons.push('@了你'); }
  if (sharedCount) {
    score += Math.min(4, sharedCount);
    if (shared.some((term) => term.length >= 2)) score += 1;
    reasons.push(`共同话题词：${shared.slice(0, 4).join('、')}`);
  }
  if ((botAsked || botRequest) && (agree || answerish)) { score += 2; reasons.push('在回应你刚才的问题/请求'); }
  if (discourse) { score += 1; reasons.push('有承接信号'); }
  if (openFollow) { score += 2; reasons.push('顺着刚才追问'); }
  if (agree) { score += 2; reasons.push('附和/接话'); }
  if (directYou) { score += 1; reasons.push('在对你说话'); }
  if (shortReaction) { score += 1; reasons.push('短反应'); }
  if (newTopicish) { score -= 3; reasons.push('像独立的新话题'); }

  const threshold = mode === 'loose' ? 1 : mode === 'strict' ? 3 : 2;
  const related = score >= threshold;
  return {
    related,
    score,
    why: reasons.length ? `${reasons.join('；')}（${score} 分，阈值 ${threshold}）` : `没有共同话题词（${score} 分，阈值 ${threshold}）`
  };
}

/** 3~5 这种区间按每次发言随机取一个整数。 */
export function pickWindowSize(conf = settings()) {
  const min = Math.max(1, Math.min(20, Number(conf.windowMin) || 3));
  const max = Math.max(min, Math.min(20, Number(conf.windowMax) || 5));
  return min + Math.floor(Math.random() * (max - min + 1));
}

// ───────────────────────────── 档位覆盖 ─────────────────────────────

function storeOf() {
  try {
    return getConfig?.()?.store || null;
  } catch {
    return null;
  }
}

/**
 * 把这个群的档位顶到 100%，让窗口内每条消息都能进入 before-context。
 * 只改内存；releaseChat 会按快照恢复。
 */
function forceChat(chatKey) {
  const store = storeOf();
  if (!store) return false;
  const [kind, id] = String(chatKey || '').split(':');
  if (kind !== 'group' || !id) return false;
  if (forcedChats.has(chatKey)) return true;

  if (!baseUnifiedSaved) {
    baseUnifiedTier = store.unifiedTier;
    baseUnifiedSaved = true;
  }
  forcedChats.set(chatKey, {
    id,
    prevPeak: clone(store.groupPeakPos?.[id]),
    prevSlider: clone(store.groupSliderPos?.[id])
  });

  store.unifiedTier = false;
  store.groupPeakPos = { ...(store.groupPeakPos || {}) };
  store.groupSliderPos = { ...(store.groupSliderPos || {}) };
  // peakSchedule 开着时核心读 groupPeakPos；关着时读 groupSliderPos。
  // 两个都写成 100，哪种配置下都能顶满。
  store.groupPeakPos[id] = { peak: 100, valley: 100 };
  store.groupSliderPos[id] = 100;
  return true;
}

function releaseChat(chatKey) {
  const rec = forcedChats.get(chatKey);
  if (!rec) return;
  const store = storeOf();
  if (store) {
    const peak = store.groupPeakPos?.[rec.id];
    if (peak && Number(peak.peak) === 100 && Number(peak.valley) === 100) {
      if (rec.prevPeak === undefined) delete store.groupPeakPos[rec.id];
      else store.groupPeakPos[rec.id] = rec.prevPeak;
    }
    const slider = store.groupSliderPos?.[rec.id];
    if (Number(slider) === 100) {
      if (rec.prevSlider === undefined) delete store.groupSliderPos[rec.id];
      else store.groupSliderPos[rec.id] = rec.prevSlider;
    }
  }
  forcedChats.delete(chatKey);
  if (!forcedChats.size && baseUnifiedSaved) {
    if (store && store.unifiedTier === false) store.unifiedTier = baseUnifiedTier;
    baseUnifiedSaved = false;
  }
}

function releaseAll() {
  for (const key of [...forcedChats.keys()]) {
    try { releaseChat(key); } catch { /* 恢复失败不阻断卸载 */ }
  }
  forcedChats.clear();
  baseUnifiedSaved = false;
}

/** 把常态概率同步到核心的响应档位（仅内存，不写配置文件）。 */
function applyGlobalProbability() {
  const conf = settings();
  if (!conf.syncGlobalProbability) return;
  if (lastSyncedProbability === conf.normalProbability) return;
  const store = storeOf();
  if (!store) return;
  const p = conf.normalProbability;
  const rawPos = typeof tierToSlider === 'function' ? tierToSlider(3, p) : (20 + p * 0.7);
  const pos = Math.round((Number(rawPos) || 41) * 100) / 100;

  // 第一次应用前留一份原值，停用/热重载时恢复。若当前值已经是我们上一次
  // 写进去的 30%/41，而磁盘里还是旧值（例如上一版没有恢复逻辑），优先用
  // 磁盘值当快照，避免把“被改过的值”当成用户的原始设置。
  if (!globalSnapshot) {
    let snapshot = {
      contextSliderPos: store.contextSliderPos,
      contextTier: store.contextTier,
      randomPercent: store.randomPercent,
      peak: clone(store.peakSchedule?.peak),
      valley: clone(store.peakSchedule?.valley)
    };
    try {
      const diskStore = typeof loadConfig === 'function' ? loadConfig()?.store : null;
      const looksApplied = Number(store.randomPercent) === 30 && Number(store.contextSliderPos) === 41;
      const diskDiffers = diskStore
        && (Number(diskStore.randomPercent) !== 30 || Number(diskStore.contextSliderPos) !== 41);
      if (looksApplied && diskDiffers) {
        snapshot = {
          contextSliderPos: diskStore.contextSliderPos,
          contextTier: diskStore.contextTier,
          randomPercent: diskStore.randomPercent,
          peak: clone(diskStore.peakSchedule?.peak),
          valley: clone(diskStore.peakSchedule?.valley)
        };
      }
    } catch { /* 读不到磁盘就按当前值快照 */ }
    globalSnapshot = snapshot;
  }

  store.contextSliderPos = pos;
  store.contextTier = 3;
  store.randomPercent = p;
  // 峰谷开着时，核心按时段取 peak/valley 的 sliderPos；两边都写成同一个值，
  // 常态概率才不会被时段覆盖。用户想保留峰谷，就在插件设置里关掉同步。
  if (store.peakSchedule?.enabled === true) {
    store.peakSchedule.peak = { ...(store.peakSchedule.peak || {}), sliderPos: pos };
    store.peakSchedule.valley = { ...(store.peakSchedule.valley || {}), sliderPos: pos };
  }
  lastSyncedProbability = p;
  lastAppliedPos = pos;
  log('常态群聊触发概率已同步为 %s%%（仅内存；停用或重启后恢复原档位）', p);
}

/** 停用/热重载时把常态档位恢复回去；用户中途手改过的值不动。 */
function restoreGlobalProbability() {
  if (!globalSnapshot) return;
  const store = storeOf();
  if (store) {
    if (Number(store.contextSliderPos) === Number(lastAppliedPos)) {
      store.contextSliderPos = globalSnapshot.contextSliderPos;
    }
    if (Number(store.contextTier) === 3) store.contextTier = globalSnapshot.contextTier;
    if (Number(store.randomPercent) === Number(lastSyncedProbability)) {
      store.randomPercent = globalSnapshot.randomPercent;
    }
    if (store.peakSchedule?.enabled === true) {
      if (Number(store.peakSchedule.peak?.sliderPos) === Number(lastAppliedPos)) {
        store.peakSchedule.peak = clone(globalSnapshot.peak);
      }
      if (Number(store.peakSchedule.valley?.sliderPos) === Number(lastAppliedPos)) {
        store.peakSchedule.valley = clone(globalSnapshot.valley);
      }
    }
  }
  globalSnapshot = null;
  lastSyncedProbability = null;
  lastAppliedPos = null;
}

// ───────────────────────────── 窗口 ─────────────────────────────

function startWindow(chatKey, botText, sessionId) {
  const conf = settings();
  const text = String(botText || '').trim();
  if (!text) return;
  const now = Date.now();
  const remaining = pickWindowSize(conf);
  windows.set(chatKey, {
    botText: text.slice(0, 500),
    botAt: now,
    remaining,
    expiresAt: now + conf.windowTtlSec * 1000,
    sessionId: String(sessionId || '')
  });
  // 先做全局快照/同步，再顶这个群的档位：否则第一次应用的快照会把
  // “groupPeakPos=100”当成用户原值，停用时恢复错。
  applyGlobalProbability();
  const forced = forceChat(chatKey);
  log('检测到群发言，开接话窗口：%s → 接下来最多看 %s 条（档位顶满：%s）',
    chatKey, remaining, forced ? '成功' : '不可用（拿不到核心配置）');
}

function stopJanitor() {
  if (janitor) {
    clearInterval(janitor);
    janitor = null;
  }
}

function startJanitor() {
  stopJanitor();
  janitor = setInterval(() => {
    const now = Date.now();
    for (const [chatKey, win] of [...windows.entries()]) {
      if (Number(win.expiresAt) <= now) {
        windows.delete(chatKey);
        releaseChat(chatKey);
        log('接话窗口超时，恢复常态：%s', chatKey);
      }
    }
    for (const [sid, decision] of [...decisions.entries()]) {
      if (now - Number(decision.at || 0) > 60 * 60 * 1000) decisions.delete(sid);
    }
  }, 15 * 1000);
  janitor.unref?.();
}

function sessionIdOf(ctx = {}) {
  return String(ctx?.session?.id || ctx?.sessionId || '');
}

function clip(text, max) {
  const s = String(text || '').replace(/\s+/g, ' ').trim();
  return s.length > max ? `${s.slice(0, max)}…` : s;
}

function appendNote(messages, note) {
  if (!Array.isArray(messages) || !messages.length) return;
  for (let i = messages.length - 1; i >= 0; i -= 1) {
    const message = messages[i];
    if (!message || message.role !== 'user') continue;
    if (typeof message.content === 'string') {
      if (!message.content.includes(WINDOW_NOTE_MARK)) message.content = `${message.content}\n\n${note}`;
    } else if (Array.isArray(message.content)) {
      const has = message.content.some((part) => part?.type === 'text' && String(part.text || '').includes(WINDOW_NOTE_MARK));
      if (!has) message.content.push({ type: 'text', text: note });
    }
    return;
  }
}

// ───────────────────────────── 生命周期 ─────────────────────────────

export async function setup(api) {
  cfg = typeof api?.config === 'function' ? api.config : () => ({});
  log = typeof api?.log === 'function' ? api.log : () => {};
  warn = typeof api?.warn === 'function' ? api.warn : log;

  // 软依赖核心配置 / 档位换算。取不到就降级为“只做相关性提示、不顶档位”，
  // 绝不让一次 import 失败把插件变成“加载失败”。
  try {
    const mod = await import('../../src/config.js');
    if (typeof mod.getConfig === 'function') getConfig = mod.getConfig;
    if (typeof mod.loadConfig === 'function') loadConfig = mod.loadConfig;
  } catch (error) {
    getConfig = null;
    loadConfig = null;
    warn('没拿到核心配置模块，无法临时顶高档位：%s', error?.message ?? error);
  }
  try {
    const mod = await import('../../src/tier-slider.js');
    if (typeof mod.tierToSlider === 'function') tierToSlider = mod.tierToSlider;
  } catch {
    tierToSlider = null;
  }

  releaseAll();
  windows.clear();
  decisions.clear();
  lastSyncedProbability = null;

  // 这个条目放在 skills/ 目录时，加载器会把它当“LLM 型”并检查是否注册了工具。
  // 本功能的核心其实是确定性钩子；这个只读状态工具只是给“技能”页一个合法入口，
  // 默认关闭，不占用模型的工具列表。
  if (typeof api?.registerTool === 'function') {
    api.registerTool({
      id: 'window_status',
      name: '接话窗口状态',
      description: '查看当前群聊的接话窗口状态（只读，不改变任何东西）。当用户问“机器人刚才为什么接话/为什么不接话”，或需要排查窗口是否还开着时使用。',
      category: 'system',
      icon: '🪟',
      defaultEnabled: false,
      parameters: { type: 'object', properties: {} },
      async execute(ctx) {
        if (ctx?.kind !== 'group') return { content: '接话窗口只在群聊生效，当前不是群聊。', isError: true };
        const win = windows.get(String(ctx.chatKey || ''));
        if (!win) return { content: '当前没有接话窗口：机器人还没发过言，或窗口已经用完/超时。' };
        const left = Math.max(0, Math.ceil((Number(win.expiresAt) - Date.now()) / 1000));
        return {
          content: [
            `接话窗口：还剩 ${win.remaining} 条 / 最长 ${left} 秒`,
            `机器人上一句：「${clip(win.botText, 80)}」`,
            `档位是否临时顶满：${forcedChats.has(String(ctx.chatKey)) ? '是' : '否'}`
          ].join('\n')
        };
      }
    });
  }

  log('接话窗口已加载（%s）：常态 %s%%，发言后看 %s~%s 条，最长等待 %s 秒',
    BUILD_TAG, settings().normalProbability, settings().windowMin, settings().windowMax, settings().windowTtlSec);
}

/** 自检必须同步返回。 */
export function available() {
  return true;
}

export async function activate() {
  startJanitor();
  applyGlobalProbability();
}

export async function deactivate() {
  stopJanitor();
  releaseAll();
  restoreGlobalProbability();
  windows.clear();
  decisions.clear();
}

export function dispose() {
  stopJanitor();
  releaseAll();
  restoreGlobalProbability();
  windows.clear();
  decisions.clear();
}

// ───────────────────────────── 钩子 ─────────────────────────────

export const hooks = {
  /**
   * 机器人真正发出文字后开窗口。只认 send_message：
   * 图片/表情/戳一戳没有可做语义对照的“上一句”，强行开窗只会制造噪声。
   */
  'after-tool'(ctx = {}) {
    try {
      if (ctx.kind !== 'group') return;
      if (ctx.toolName !== 'send_message') return;
      if (ctx.result?.isError) return;
      const session = ctx.session;
      const sent = Array.isArray(session?.sent) ? session.sent : [];
      const lastText = [...sent].reverse().find((item) => item?.type === 'text' && String(item.text || '').trim());
      if (!lastText) return;
      startWindow(ctx.chatKey, lastText.text, session?.id);
    } catch (error) {
      warn('开接话窗口失败（不影响发言）：%s', error?.message ?? error);
    }
  },

  /**
   * 核心已经决定跑这一轮时，判断“是不是接话”。
   * 注意：这是“触发之后”的钩子，所以窗口内先用档位顶满保证每条都能到这里。
   */
  'before-context'(ctx = {}) {
    try {
      if (ctx.kind !== 'group') return;
      if (ctx.proactive === true) return;
      const chatKey = String(ctx.chatKey || '');
      const win = windows.get(chatKey);
      if (!win) return;
      if (Date.now() > Number(win.expiresAt)) {
        windows.delete(chatKey);
        releaseChat(chatKey);
        return;
      }

      const entries = Array.isArray(ctx.triggerEntries) ? ctx.triggerEntries.filter(Boolean) : [];
      const text = entries.map((entry) => String(entry?.text || '')).filter(Boolean).join('\n').trim();
      if (!text) return;

      // 设置里的常态概率可能刚被用户改过；下一次触发时同步到核心。
      applyGlobalProbability();
      const conf = settings();
      const judgement = judgeRelevance(win.botText, text, {
        selfNickname: ctx.selfNickname,
        botName: ctx.botName,
        selfId: ctx.selfId,
        entries
      }, conf.relevance);

      let allowed = judgement.related;
      let why = judgement.why;
      let roll = null;
      if (!judgement.related) {
        roll = Math.random() * 100;
        allowed = roll < conf.normalProbability;
        why += `；无关，按常态概率 ${conf.normalProbability}% 掷出 ${roll.toFixed(0)}，${allowed ? '接话' : '静默'}`;
      }

      const sid = sessionIdOf(ctx);
      if (sid) {
        decisions.set(sid, {
          suppressed: conf.silentWhenUnrelated === true && !allowed,
          related: judgement.related,
          allowed,
          why,
          botText: win.botText,
          at: Date.now()
        });
      }

      // 一批可能包含多条（运行期间堆积/2 秒聚批），按条数扣窗口，避免
      // “3 条窗口实际看了 6 条”。
      const consumed = Math.max(1, entries.length);
      win.remaining -= consumed;
      log('接话判定 %s：%s（本批 %s 条，窗口剩 %s）', chatKey, why, consumed, win.remaining);
      if (win.remaining <= 0) {
        windows.delete(chatKey);
        releaseChat(chatKey);
        log('接话窗口用完，恢复常态：%s', chatKey);
      }
    } catch (error) {
      warn('接话判定失败（本轮按正常触发继续）：%s', error?.message ?? error);
    }
  },

  /**
   * 静默轮：把上下文换成一句“只收尾”，避免为一条无关消息付整段上下文
   * 的输入费；接话轮则在最后一条 user 消息后补一句提示，让模型知道
   * “这是因为你刚说过话才被叫起来的”，不要提规则。
   */
  'before-llm-messages'(ctx = {}) {
    try {
      const sid = sessionIdOf(ctx);
      const decision = sid ? decisions.get(sid) : null;
      if (!decision) return;
      const messages = ctx.messages;
      if (!Array.isArray(messages)) return;

      if (decision.suppressed) {
        messages.length = 0;
        messages.push({ role: 'system', content: GATE_SYSTEM });
        messages.push({ role: 'user', content: GATE_USER });
        return;
      }

      if (decision.related) {
        appendNote(messages, `${WINDOW_NOTE_MARK}你刚才在群里说：「${clip(decision.botText, 100)}」。这批新消息和你的话有关，顺着接；不要提“窗口”“规则”“判定”这些词。`);
      } else {
        appendNote(messages, `${WINDOW_NOTE_MARK}这批新消息和你刚才的话关系不大，但常态概率这次抽中了你；想接就自然插一句，不想接就 finish，别硬聊。`);
      }
    } catch (error) {
      warn('加工接话提示失败（不影响发言）：%s', error?.message ?? error);
    }
  },

  /** 静默轮硬拦所有非 finish 工具，防止模型绕过提示偷偷发消息。 */
  'before-tool'(ctx = {}) {
    try {
      const sid = sessionIdOf(ctx);
      const decision = sid ? decisions.get(sid) : null;
      if (!decision?.suppressed) return;
      const name = String(ctx.toolName || '');
      if (name === 'finish' || name.endsWith('__finish')) return;
      if (SEND_TOOLS.has(name) || name.includes('send_') || name.includes('__send_')) {
        return { block: true, reason: '本轮判定为无关且未抽中，已静默收尾；请只调用 finish。' };
      }
      return { block: true, reason: '本轮判定为静默收尾，不要调用工具；请只调用 finish。' };
    } catch {
      return undefined;
    }
  }
};

// ───────────────────────────── 能力 ─────────────────────────────

export const providers = {
  /**
   * 静默轮只留 finish 工具，并把输出预算压小。这样即使模型不听话，
   * 也只能收尾，不会发消息；同时避免把整段无关上下文再送一遍。
   */
  'llm.request-params'({ body, context } = {}) {
    try {
      const sid = String(context?.sessionId || '');
      const decision = sid ? decisions.get(sid) : null;
      if (!decision?.suppressed) return undefined;
      if (!body || typeof body !== 'object') return undefined;
      const tools = Array.isArray(body.tools)
        ? body.tools.filter((tool) => tool?.function?.name === 'finish')
        : null;
      const next = { ...body };
      if (tools && tools.length) {
        next.tools = tools;
        next.tool_choice = 'auto';
      }
      next.max_tokens = Math.min(Number(next.max_tokens) || 512, 512);
      return { body: next };
    } catch {
      return undefined;
    }
  }
};
