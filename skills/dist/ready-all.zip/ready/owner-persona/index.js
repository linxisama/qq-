// 主人改人设 —— 主人在聊天里直接说，就能查看 / 切换「某个会话」或「全局」的人设。
//
// ── 认人（自给自足，不依赖任何其它插件）──────────────────────────────────────
// 主人 QQ 号填在本技能设置里（configSchema 的 ownerIds），判定只看**号码相等**：
//   · 号码来源：ctx.session.trigger[].senderId —— 协议字段，不是聊天正文。
//     ⚠️ 工具的 ctx 里**没有** senderId / userId（orchestrator.js:899 的实际字段），
//        别去 ctx.userId 上找；做法与 skills/message-recall-2 的 resolveCallerId() 一致。
//   · 名字、群名片、正文里自称"我是你主人"一律不作数。
// 不是主人 → 直接拒绝，**连人设名单都不回**。
//
// ── 人设模型（与 UI 完全同一套判据）──────────────────────────────────────────
//   · 全局人设：config.persona = { botName, selfNickname, roleText, participation, customRules, ... }
//   · 会话独立人设：config.personaByChat[chatKey] = { roleText?, participation?, customRules?, systemPromptOverride? }
//     生效规则见 src/config.js:708 personaForChat()：
//       - personaUnified !== false（"所有会话共用一个"）时，personaByChat **不生效**；
//       - 键两种格式都认：先按 id 段（123）查，再按 chatKey（group:123）查；
//       - 只覆盖 roleText / participation / customRules / systemPromptOverride 四个字段，
//         botName / selfNickname 是账号身份，任何会话都不能单独改。
//   · 人设库：内置 src/personas.js 的 PERSONAS + config.customPersonas（用户在设置页存的）。
//     名字的判据与 UI 一致：**roleText 与模板 text 全等**才算"就是这个人设"，
//     否则 UI 显示"自定义"（见 ui/app/06-settings-render.js:606 的同一行逻辑）。
//
// ── 为什么是工具，不是钩子 ───────────────────────────────────────────────────
// 钩子 5 秒超时、不能发消息、规范里明确"不得有副作用"；改人设是写操作，还要把结果回给主人
// （doc/extend_development/plugin-development.md §2）。顺带自然语言直接可用。

let api = null;
let cfg = () => ({});

/** 工具短名（注册后实际 id 是 owner-persona__persona）。 */
const TOOL_ID = 'persona';
/** QQ 号 / 群号形态：5~15 位纯数字。 */
const ID_RE = /^\d{5,15}$/;
/** 指向"全局人设"的写法。 */
const GLOBAL_WORDS = new Set(['全局', '全局人设', '默认', '统一', '统一人设', 'global', 'all', 'default']);

const log = (...a) => { try { api?.log?.(...a); } catch { /* 日志失败不影响功能 */ } };

// ── 谁是主人 ───────────────────────────────────────────────────────────────

/** 归一化主人名单：数组或逗号/分号/顿号/空白分隔的字符串。 */
export function normalizeOwnerIds(raw) {
  const list = Array.isArray(raw) ? raw : String(raw ?? '').split(/[,，;；、\s]+/);
  const out = [];
  for (const item of list) {
    const id = String(item ?? '').trim();
    if (ID_RE.test(id) && !out.includes(id)) out.push(id);
  }
  return out;
}

export function ownerIds(conf = null) {
  return normalizeOwnerIds((conf || cfg()).ownerIds);
}

/** 解析触发者 QQ 号（与 owner-identity / message-recall-2 同源：触发批的 senderId）。 */
export function resolveCallerId(ctx) {
  const entries = ctx?.session?.trigger;
  if (Array.isArray(entries)) {
    for (let i = entries.length - 1; i >= 0; i -= 1) {
      const sid = String(entries[i]?.senderId ?? '').trim();
      if (sid && sid !== 'self') return sid;
    }
  }
  try {
    const recent = ctx?.store?.recent?.(ctx.chatKey, { limit: 30, includeSelf: false }) || [];
    for (let i = recent.length - 1; i >= 0; i -= 1) {
      const sid = String(recent[i]?.senderId ?? '').trim();
      if (sid && sid !== 'self') return sid;
    }
  } catch { /* store 不可用就当拿不到 */ }
  return '';
}

/** 主人闸门。三种失败给不同的话：没配名单 / 取不到号码 / 不是主人。 */
export function checkOwner(callerId) {
  const ids = ownerIds();
  if (!ids.length) {
    return { ok: false, reason: '还没填主人 QQ 号：去「技能 → 主人改人设 → 主人 QQ 号」填上（多个用逗号分隔），填好就能用。' };
  }
  if (!callerId) return { ok: false, reason: '拿不到这条消息的发送者 QQ 号，没法确认是不是主人。' };
  const id = String(callerId).trim();
  if (!ids.includes(id)) {
    return { ok: false, reason: `只有主人能改人设（这条消息来自 QQ:${id}，不在主人名单里）。` };
  }
  return { ok: true, callerId: id };
}

// ── 读核心（配置 + 人设库 + personaForChat）─────────────────────────────────

let injectedCore = null;
let corePromise = null;

/**
 * 定位核心的 src/config.js 与 src/personas.js。技能可能在两处，两条相对路径都试：
 *   resources/app/skills/<id>/index.js → ../../src/...
 *   <数据根>/modules/<id>/index.js     → ../../../resources/app/src/...
 */
export async function loadCore() {
  const bases = ['../../src/', '../../../resources/app/src/'];
  const tried = [];
  for (const base of bases) {
    try {
      const conf = await import(`${base}config.js`);
      const pers = await import(`${base}personas.js`);
      if (typeof conf.getConfig !== 'function' || typeof conf.updateConfig !== 'function') {
        tried.push(`${base}config.js（导出不完整）`);
        continue;
      }
      return {
        getConfig: conf.getConfig,
        updateConfig: conf.updateConfig,
        // 生效人设以核心的 personaForChat 为准（统一开关、两种键格式这些规则不重写一遍）
        personaForChat: typeof conf.personaForChat === 'function' ? conf.personaForChat : null,
        deepMerge: typeof conf.deepMerge === 'function' ? conf.deepMerge : null,
        // 仅自测用：内存态覆盖配置（不落盘），用来把真 personaForChat 和本地兜底实现逐条对照
        setRuntimeConfig: typeof conf.setRuntimeConfig === 'function' ? conf.setRuntimeConfig : null,
        PERSONAS: pers?.PERSONAS && typeof pers.PERSONAS === 'object' ? pers.PERSONAS : {},
        from: base,
      };
    } catch (error) {
      tried.push(`${base}（${error?.message ?? error}）`);
    }
  }
  throw new Error(`找不到核心模块，两条路径都不通：${tried.join('；')}`);
}

async function core() {
  if (injectedCore) return injectedCore;
  if (!corePromise) corePromise = loadCore();
  return corePromise;
}

// ── 人设库与名字 ───────────────────────────────────────────────────────────

/** 人设目录：内置（PERSONAS）+ 自定义（customPersonas），字段与 UI 的 /api/persona-templates 对齐。 */
export function catalogOf(conf, PERSONAS = {}) {
  const builtins = Object.entries(PERSONAS || {}).map(([id, p]) => ({
    id,
    name: String(p?.name ?? id).trim(),
    text: String(p?.text ?? ''),
    customRules: '',
    builtin: true,
  }));
  const customs = (Array.isArray(conf?.customPersonas) ? conf.customPersonas : []).map((p, i) => ({
    id: `custom_${i}`,
    name: String(p?.name ?? '').trim(),
    text: String(p?.text ?? ''),
    customRules: String(p?.customRules ?? ''),
    builtin: false,
  }));
  return [...builtins, ...customs].filter((p) => p.name && p.text);
}

/**
 * 按 roleText 反查人设名 —— 与 UI 完全同一套判据（文本全等）。
 * 匹配不到返回 ''（UI 在这种情况下显示"自定义"）。
 */
export function nameOfRoleText(catalog, roleText) {
  const t = String(roleText ?? '');
  if (!t.trim()) return '';
  const hit = (catalog || []).find((p) => p.text === t);
  return hit ? hit.name : '';
}

/**
 * 某会话实际生效的人设 —— 与 src/config.js:708 personaForChat() **同口径**的本地实现。
 * 正式路径优先用核心那个（runPersona 里传进来），这份只在拿不到核心时兜底、并供自测对照，
 * 自测里会拿它和真函数逐条比，防止两套规则漂移。
 */
export function effectiveForChat(conf, chatKey) {
  const base = conf?.persona || {};
  const [kind, id] = String(chatKey || '').split(':');
  if (!id) return base;
  if (conf?.personaUnified !== false) return base;
  const perChat = conf?.personaByChat && typeof conf.personaByChat === 'object' ? conf.personaByChat : {};
  // 两种键格式都认：UI 存 chatKey（group:123），历史数据可能是裸 id
  const raw = perChat[String(id)] ?? perChat[String(chatKey)];
  if (!raw || typeof raw !== 'object') return base;
  const pick = (v) => (typeof v === 'string' && v.trim() ? v.trim() : undefined);
  const out = { ...base };
  if (kind === 'group' || kind === 'private') {
    const roleText = pick(raw.roleText);
    const customRules = pick(raw.customRules);
    const spo = pick(raw.systemPromptOverride);
    if (roleText !== undefined) out.roleText = roleText;
    if (customRules !== undefined) out.customRules = customRules;
    if (spo !== undefined) out.systemPromptOverride = spo;
    if (['low', 'medium', 'high'].includes(raw.participation)) out.participation = raw.participation;
  }
  return out;
}

/** 只读现状：某会话（或全局）现在生效的人设。 */
export function readState(conf, catalog, chatKey, personaForChatFn = null) {
  const isGlobal = !chatKey;
  const base = conf?.persona || {};
  const perChat = conf?.personaByChat && typeof conf.personaByChat === 'object' ? conf.personaByChat : {};
  let override = null;
  let effective = base;
  if (!isGlobal) {
    const id = String(chatKey).split(':')[1] || '';
    // 与 personaForChat 同口径：两种键格式都认
    const raw = perChat[String(chatKey)] ?? perChat[id];
    if (raw && typeof raw === 'object') override = raw;
    effective = typeof personaForChatFn === 'function' ? personaForChatFn(chatKey) : effectiveForChat(conf, chatKey);
  }
  return {
    isGlobal,
    effective,
    override,
    unified: conf?.personaUnified !== false,
    name: nameOfRoleText(catalog, effective?.roleText),
    globalName: nameOfRoleText(catalog, base?.roleText),
  };
}

// ── 目标解析 ───────────────────────────────────────────────────────────────

/**
 * 把模型给的 target 归一化成 { kind: 'global' } 或 { kind:'group'|'private', chatKey, id }。
 * 省略 target = 当前会话。裸数字默认当群号（要私聊请写 private:号码 或给 kind=private）。
 */
export function parseTarget(raw, ctx, kindHint = '') {
  const cur = String(ctx?.chatKey || '');
  const text = String(raw ?? '').trim();
  if (!text) {
    if (!/^(group|private):\S+$/.test(cur)) return { error: '拿不到当前会话信息，请直接给出目标（如 group:123456 / private:10001 / 全局）。' };
    const [k, id] = cur.split(':');
    return { kind: k, chatKey: cur, id, current: true };
  }
  const low = text.toLowerCase();
  if (GLOBAL_WORDS.has(text) || GLOBAL_WORDS.has(low)) return { kind: 'global', chatKey: '', id: '' };

  const m = text.match(/^(group|private|群|私聊|好友)\s*[:：]?\s*(\d{5,15})$/i);
  if (m) {
    const kind = /^(group|群)$/i.test(m[1]) ? 'group' : 'private';
    return { kind, chatKey: `${kind}:${m[2]}`, id: m[2] };
  }
  const bare = text.replace(/\D/g, '');
  if (ID_RE.test(bare)) {
    const kind = String(kindHint || '').toLowerCase() === 'private' ? 'private' : 'group';
    return { kind, chatKey: `${kind}:${bare}`, id: bare };
  }
  return { error: `认不出目标「${text}」。用 group:群号 / private:QQ号 / 全局，或省略表示当前会话。` };
}

// ── 工具主流程 ─────────────────────────────────────────────────────────────

const fmtList = (names) => names.map((n) => `- ${n}`).join('\n');

/** 只列名字（主人的要求：查看与列举都只给名字）。 */
export function renderNameList(catalog) {
  const names = catalog.map((p) => p.name);
  if (!names.length) return '人设库里还没有任何可用的人设。';
  return `可用人设（${names.length} 个，只有名字）：\n${fmtList(names)}`;
}

export async function runPersona(ctx, args) {
  const action = String(args?.action ?? 'view').trim().toLowerCase();
  if (!['view', 'list', 'set'].includes(action)) {
    return { content: `action 只能是 view / list / set，收到的是「${args?.action}」。`, isError: true };
  }

  // ① 认人 —— 先于一切读取：不是主人连人设名单都不给看
  const callerId = resolveCallerId(ctx);
  const gate = checkOwner(callerId);
  if (!gate.ok) {
    log(`拒绝了一次改人设请求：${gate.reason}`);
    return { content: gate.reason, isError: true };
  }

  // ② 核心 + 人设库
  let c;
  try {
    c = await core();
  } catch (error) {
    return { content: `读不到核心配置，没法处理人设：${error?.message ?? error}`, isError: true };
  }
  const conf = c.getConfig();
  const catalog = catalogOf(conf, c.PERSONAS);

  if (action === 'list') return { content: renderNameList(catalog) };

  // ③ 目标
  const t = parseTarget(args?.target, ctx, args?.kind);
  if (t.error) return { content: t.error, isError: true };
  const label = t.kind === 'global' ? '全局人设' : t.chatKey;
  const st = readState(conf, catalog, t.kind === 'global' ? '' : t.chatKey, c.personaForChat);

  if (action === 'view') {
    const name = st.name || '自定义（正文不在人设库里，界面上也显示"自定义"）';
    const lines = [];
    if (t.kind === 'global') {
      lines.push(`🌐 全局人设：${name}`);
    } else {
      lines.push(`💬 ${t.chatKey} 的人设：${name}`);
      lines.push(st.override ? '（这个会话设了独立人设）' : `（跟随全局：${st.globalName || '自定义'}）`);
    }
    if (st.unified && t.kind !== 'global') {
      lines.push('⚠️ 现在开着「所有的群聊/私聊使用同一个人设」，所以分会话人设不生效 —— 要按会话分人设得先在 设置 → 人设 里关掉它。');
    }
    return { content: lines.join('\n') };
  }

  // action === 'set'
  const want = String(args?.name ?? '').trim();
  if (!want) {
    return { content: `要给 ${label} 换成哪个人设？先看名字列表再告诉我一个（调用 action=list）。`, isError: true };
  }
  const exact = catalog.filter((p) => p.name === want);
  let picked = exact[0];
  if (!picked) {
    const fuzzy = catalog.filter((p) => p.name.includes(want)).map((p) => p.name);
    const hint = fuzzy.length ? `你是不是想说：${fuzzy.slice(0, 8).join('、')}` : '先调用 action=list 看都有哪些名字。';
    return { content: `人设库里没有叫「${want}」的。${hint}`, isError: true };
  }
  if (exact.length > 1) {
    return { content: `有 ${exact.length} 个人设都叫「${want}」，分不清是哪个 —— 请先在设置页把其中一个改名。`, isError: true };
  }
  if (t.kind !== 'global' && st.unified) {
    return {
      content: '现在开着「所有的群聊/私聊使用同一个人设」，分会话人设不生效。'
        + '要按会话分人设，先在 设置 → 人设 里关掉那个开关（关掉后已有条目会恢复生效），再来改这个会话。',
      isError: true,
    };
  }

  const entryFields = { roleText: picked.text, customRules: picked.customRules || '' };
  try {
    if (t.kind === 'global') {
      // 只写 roleText / customRules：botName、selfNickname 是账号身份，谁都不能顺手改掉
      c.updateConfig({ persona: entryFields });
    } else {
      // 保留该会话已有的 participation / systemPromptOverride（UI 的选择器也是这个语义）
      const prev = st.override && typeof st.override === 'object' ? st.override : {};
      const entry = { ...prev, ...entryFields };
      c.updateConfig({ personaByChat: { [t.chatKey]: entry } });
    }
  } catch (error) {
    return { content: `写入配置失败（没有改动）：${error?.message ?? error}`, isError: true };
  }
  log(`主人 ${callerId} 把 ${label} 的人设改成「${picked.name}」`);

  const tail = t.kind === 'global'
    ? '所有没设独立人设的会话下次回话就用它。'
    : '这个会话下次回话就用它。';
  return { content: `✅ 已把 ${label} 的人设改成「${picked.name}」。${tail}` };
}

// ── 技能生命周期 ───────────────────────────────────────────────────────────

export function setup(a) {
  api = a;
  cfg = a?.config || (() => ({}));
  try {
    a.registerTool({
      id: TOOL_ID,
      name: '人设查看与切换',
      description:
        '查看 / 切换「某个会话」或「全局」的人设（角色设定）。主人说「现在是什么人设」「把本群人设换成 XX」'
        + '「换个 xx 人设」时调用本工具。action=list 只回人设名字（没有任何正文），主人挑完再 action=set 直接生效。'
        + '主人身份由本工具按设置里的主人 QQ 号自行校验，你不必自己判断，非主人的调用会被拒绝。',
      category: 'system',
      parameters: {
        type: 'object',
        properties: {
          action: {
            type: 'string',
            enum: ['view', 'list', 'set'],
            description: 'view=看目标现在的人设（名字）；list=列出全部人设名；set=换成指定人设。默认 view。',
          },
          target: {
            type: 'string',
            description: 'group:群号 / private:QQ号 / 全局(global) / 省略=当前会话。想改别的会话时，先用 get_chats 查它的 chatKey，或直接写号码（裸号码默认当群号）。',
          },
          name: {
            type: 'string',
            description: 'set 时必填：人设名，必须与 action=list 列出的名字完全一致。',
          },
          kind: {
            type: 'string',
            enum: ['group', 'private'],
            description: 'target 只写了裸号码时，用它说明号码是群号还是 QQ 号；省略按群号。',
          },
        },
        required: ['action'],
      },
      execute: (ctx, args) => runPersona(ctx, args),
    });
  } catch (error) {
    log(`工具注册失败：${error?.message ?? error}`);
  }
}

export function available() {
  if (cfg().enabled === false) return { ok: false, reason: '技能设置里的「启用」是关的' };
  if (!ownerIds().length) {
    return { ok: false, reason: '还没填主人 QQ 号 —— 在技能设置里填上（多个用逗号分隔），这个技能才会生效' };
  }
  return { ok: true };
}

// 提示词片段写在 skill.json 的 prompt.sections 里（id: owner-persona-rules）：
// 加载器会把清单静态片段与导出的 promptSections() 按 id 去重（src/skills/manager.js:470-493），
// 两处都写等于维护两份；"技能没生效就别注入"由加载器的 isActive 统一管。

/** 测试与调试入口（正式运行不需要）。 */
export const internals = {
  resolveCallerId, checkOwner, ownerIds, normalizeOwnerIds, loadCore, catalogOf,
  nameOfRoleText, readState, effectiveForChat, parseTarget, renderNameList, runPersona, TOOL_ID,
  setCore: (c) => { injectedCore = c; },
  resetCore: () => { injectedCore = null; corePromise = null; },
};
