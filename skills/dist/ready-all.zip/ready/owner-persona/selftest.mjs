// owner-persona 自测（离线，不联网、**绝不碰真实配置**）。
//
// 用法（在技能目录里跑，用 QQ Agent 自带的 node）：
//   & "<QQ Agent 安装目录>\resources\app\snowluma\node.exe" selftest.mjs
//
// 覆盖：清单/工具注册、主人闸门、人设目录与名字判据、查看（独立/跟随全局/统一开关/自定义）、
//       列举（只给名字、不泄露正文）、切换（写哪几个字段、不碰 botName、保留 participation、
//       统一开关拦截、重名/不存在/缺 name）、目标解析、核心接线（与真 personaForChat 逐条对照）。
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const SKILL_DIR = path.dirname(fileURLToPath(import.meta.url));
const manifest = JSON.parse(fs.readFileSync(path.join(SKILL_DIR, 'skill.json'), 'utf8'));
const mod = await import('./index.js');

let pass = 0;
let fail = 0;
const check = (name, fn) => {
  try { fn(); pass += 1; console.log(`  ok   ${name}`); }
  catch (e) { fail += 1; console.log(`  FAIL ${name}: ${e?.message ?? e}`); }
};
const acheck = async (name, fn) => {
  try { await fn(); pass += 1; console.log(`  ok   ${name}`); }
  catch (e) { fail += 1; console.log(`  FAIL ${name}: ${e?.message ?? e}`); }
};

// ── 测试脚手架 ─────────────────────────────────────────────────────────────
const ROLE = {
  jing: 'ROLE-正文-小鲸鱼-AAAA',
  cat: 'ROLE-正文-猫娘-BBBB',
  cat2: 'ROLE-正文-猫娘二号-CCCC',
  mao: 'ROLE-正文-毛毛-DDDD',
};
const PERSONAS = {
  xiaojingyu: { name: '小鲸鱼（默认）', text: ROLE.jing },
};

/** 假核心：与 core 同款 deepMerge 语义（对象递归、数组整体替换），并记录写入。 */
function makeCore({ conf = {}, personas = PERSONAS } = {}) {
  const state = structuredClone({
    persona: { botName: '小鲸鱼', selfNickname: '鱼', roleText: ROLE.jing, participation: 'medium', customRules: '', systemPromptOverride: '' },
    personaByChat: {},
    personaUnified: false,
    customPersonas: [],
    ...conf,
  });
  const writes = [];
  const merge = (base, patch) => {
    const out = { ...base };
    for (const [k, v] of Object.entries(patch)) {
      if (v && typeof v === 'object' && !Array.isArray(v) && base[k] && typeof base[k] === 'object' && !Array.isArray(base[k])) {
        out[k] = merge(base[k], v);
      } else {
        out[k] = structuredClone(v);
      }
    }
    return out;
  };
  return {
    state,
    writes,
    core: {
      getConfig: () => structuredClone(state),
      updateConfig: (patch) => { writes.push(structuredClone(patch)); Object.assign(state, merge(state, patch)); return structuredClone(state); },
      personaForChat: (chatKey) => mod.internals.effectiveForChat(state, chatKey),
      PERSONAS: personas,
    },
  };
}

const CATALOG = [
  { id: 'xiaojingyu', name: '小鲸鱼（默认）', text: ROLE.jing, customRules: '', builtin: true },
  { id: 'custom_0', name: '猫娘', text: ROLE.cat, customRules: 'RULES-猫娘', builtin: false },
  { id: 'custom_1', name: '猫娘二号', text: ROLE.cat2, customRules: '', builtin: false },
];

function makeApi({ ownerIds = '1062935770' } = {}) {
  const tools = [];
  const api = {
    config: () => ({ enabled: true, ownerIds }),
    registerTool: (def) => { tools.push(def); return `owner-persona__${def.id}`; },
    log: () => {},
    warn: () => {},
    capability: () => { throw new Error('本技能不该调用 api.capability（不依赖外部能力）'); },
    hasCapability: () => { throw new Error('本技能不该调用 api.hasCapability（不依赖外部能力）'); },
  };
  return { api, tools };
}

const tool0 = (tools) => tools.find((t) => t.id === 'persona');
const ctxGroup = (senderId, id = '546789624') => ({
  chatKey: `group:${id}`, kind: 'group', chatId: id, selfId: '10001',
  session: { trigger: [{ senderId }] }, store: { recent: () => [] },
});
const ctxPrivate = (senderId, id = '1062935770') => ({
  chatKey: `private:${id}`, kind: 'private', chatId: id, selfId: '10001',
  session: { trigger: [{ senderId }] }, store: { recent: () => [] },
});

console.log('\n[1] 清单与注册');
const { api, tools } = makeApi({});
mod.setup(api);
{
  check('id 合法且与目录名一致', () => {
    assert.match(manifest.id, /^[a-zA-Z0-9][a-zA-Z0-9._-]*$/);
    assert.equal(manifest.id, path.basename(SKILL_DIR));
  });
  check('category 合法、无前置依赖', () => {
    assert.ok(['model', 'message', 'knowledge', 'media', 'utility'].includes(manifest.category));
    assert.ok(!manifest.requires || manifest.requires.length === 0);
  });
  check('设置里有主人 QQ 号，且说清留空后果', () => {
    assert.equal(manifest.settings.ownerIds, '');
    assert.ok(manifest.configSchema.ownerIds?.label);
    assert.match(String(manifest.configSchema.ownerIds.description), /留空/);
  });
  check('configSchema 与 settings 键一致', () => assert.deepEqual(Object.keys(manifest.configSchema).sort(), Object.keys(manifest.settings).sort()));
  check('提示词片段写清了"只念名字"与工具名', () => {
    const s = manifest.prompt?.sections?.[0];
    assert.ok(s && s.priority > 0 && s.priority <= 99);
    assert.ok(String(s.content).includes('owner-persona__persona'));
    assert.match(String(s.content), /只念名字|不要把角色设定正文/);
  });
}

console.log('\n[2] 工具注册');
{
  check('注册了 1 个工具，短名 persona', () => assert.deepEqual(tools.map((t) => t.id), ['persona']));
  check('完整 id 字符集安全、≤64', () => {
    const full = `owner-persona__${tools[0].id}`;
    assert.match(full, /^[a-zA-Z0-9_-]+$/);
    assert.ok(full.length <= 64);
  });
  check('description 有做什么/什么时候用/谁能用', () => {
    const d = tools[0].description;
    assert.ok(d.includes('人设'));
    assert.ok(d.includes('调用本工具'));
    assert.ok(d.includes('主人'));
  });
  check('parameters：三项都有 description，required=action，action 三选一', () => {
    const p = tools[0].parameters;
    for (const k of ['action', 'target', 'name']) assert.ok(p.properties[k]?.description, `${k} 缺 description`);
    assert.deepEqual(p.required, ['action']);
    assert.deepEqual(p.properties.action.enum, ['view', 'list', 'set']);
  });
  check('工具不带 requires（不依赖外部能力）', () => assert.ok(!tools[0].requires || !tools[0].requires.length));
  check('available()：填了号码 = ok', () => assert.equal(mod.available().ok, true));
  check('available()：没填号码 = 不可用且说明原因', () => {
    const fresh = makeApi({ ownerIds: '' });
    mod.setup(fresh.api);
    const r = mod.available();
    assert.equal(r.ok, false);
    assert.match(r.reason, /还没填主人 QQ 号/);
    mod.setup(api);
  });
}

console.log('\n[3] 主人闸门');
{
  const run = (ctx, args) => tool0(tools).execute(ctx, args);

  await acheck('非主人 → 拒绝，且不回人设名单', async () => {
    const { core: c } = makeCore();
    mod.internals.setCore(c);
    const r = await run(ctxGroup('999999999'), { action: 'list' });
    assert.equal(r.isError, true);
    assert.match(r.content, /只有主人能改人设/);
    assert.ok(!r.content.includes('猫娘'), '不该把名单回给非主人');
  });

  await acheck('非主人 → 拒绝，也不写配置', async () => {
    const { core: c, writes } = makeCore();
    mod.internals.setCore(c);
    const r = await run(ctxGroup('999999999'), { action: 'set', name: '猫娘' });
    assert.equal(r.isError, true);
    assert.equal(writes.length, 0);
  });

  await acheck('拿不到发送者号码 → 拒绝', async () => {
    const { core: c } = makeCore();
    mod.internals.setCore(c);
    const r = await run({ chatKey: 'group:1', kind: 'group', chatId: '1', session: { trigger: [] }, store: { recent: () => [] } }, { action: 'list' });
    assert.equal(r.isError, true);
    assert.match(r.content, /拿不到/);
  });

  await acheck('多主人：第二个号也放行', async () => {
    const multi = makeApi({ ownerIds: '1062935770, 2229576564' });
    mod.setup(multi.api);
    const { core: c } = makeCore();
    mod.internals.setCore(c);
    const r = await tool0(multi.tools).execute(ctxPrivate('2229576564'), { action: 'list' });
    assert.notEqual(r.isError, true);
    mod.setup(api);
  });
}

console.log('\n[4] 人设目录与名字判据');
{
  check('catalogOf：内置在前、自定义在后，跳过缺名/缺正文的脏数据', () => {
    const cat = mod.internals.catalogOf({ customPersonas: [{ name: '猫娘', text: ROLE.cat }, { name: '空正文', text: '' }, { name: '', text: 'x' }] }, PERSONAS);
    assert.deepEqual(cat.map((p) => p.name), ['小鲸鱼（默认）', '猫娘']);
    assert.equal(cat[0].builtin, true);
    assert.equal(cat[1].builtin, false);
  });
  check('名字判据 = 正文全等（与 UI 的同一行逻辑一致）', () => {
    const cat = mod.internals.catalogOf({}, PERSONAS);
    assert.equal(mod.internals.nameOfRoleText(cat, ROLE.jing), '小鲸鱼（默认）');
    assert.equal(mod.internals.nameOfRoleText(cat, ` ${ROLE.jing} `), '', '带空格不算全等（与 UI 一致）');
    assert.equal(mod.internals.nameOfRoleText(cat, '随便写的正文'), '');
    assert.equal(mod.internals.nameOfRoleText(cat, ''), '');
  });
  check('列表只给人设名，不含正文', () => {
    const out = mod.internals.renderNameList(CATALOG);
    assert.ok(out.includes('猫娘') && out.includes('小鲸鱼（默认）'));
    assert.ok(!out.includes('ROLE-正文'), '不能泄露角色设定正文');
    assert.ok(!out.includes('RULES-'), '不能泄露附加规则');
  });
}

console.log('\n[5] 查看');
{
  const run = (ctx, args) => tool0(tools).execute(ctx, args);

  await acheck('有独立人设 → 名字 + 标注"独立"（且不含正文）', async () => {
    const { core: c } = makeCore({ conf: { personaByChat: { 'group:546789624': { roleText: ROLE.cat } }, customPersonas: [{ name: '猫娘', text: ROLE.cat }] } });
    mod.internals.setCore(c);
    const r = await run(ctxGroup('1062935770'), { action: 'view' });
    assert.match(r.content, /group:546789624 的人设：猫娘/);
    assert.match(r.content, /独立人设/);
    assert.ok(!r.content.includes('ROLE-正文'));
  });

  await acheck('没有独立人设 → 名字 + "跟随全局"并报出全局名', async () => {
    const { core: c } = makeCore({ conf: { personaByChat: { 'group:546789624': { roleText: ROLE.cat } } } });
    mod.internals.setCore(c);
    const r = await run(ctxGroup('1062935770', '777777'), { action: 'view' });
    assert.match(r.content, /group:777777 的人设：小鲸鱼（默认）/);
    assert.match(r.content, /跟随全局：小鲸鱼（默认）/);
  });

  await acheck('他人会话也能查（给 chatKey）', async () => {
    const { core: c } = makeCore({ conf: { personaByChat: { 'private:2229576564': { roleText: ROLE.mao } }, customPersonas: [{ name: '毛毛', text: ROLE.mao }] } });
    mod.internals.setCore(c);
    const r = await run(ctxPrivate('1062935770'), { action: 'view', target: 'private:2229576564' });
    assert.match(r.content, /private:2229576564 的人设：毛毛/);
  });

  await acheck('全局人设也能查', async () => {
    const { core: c } = makeCore();
    mod.internals.setCore(c);
    const r = await run(ctxPrivate('1062935770'), { action: 'view', target: '全局' });
    assert.match(r.content, /全局人设：小鲸鱼（默认）/);
  });

  await acheck('正文匹配不到命名人设 → 说"自定义"', async () => {
    const { core: c } = makeCore({ conf: { personaByChat: { 'group:546789624': { roleText: '临时手写的正文' } } } });
    mod.internals.setCore(c);
    const r = await run(ctxGroup('1062935770'), { action: 'view' });
    assert.match(r.content, /自定义/);
  });

  await acheck('裸 id 键（历史数据）也能读到', async () => {
    const { core: c } = makeCore({ conf: { personaByChat: { 546789624: { roleText: ROLE.cat } }, customPersonas: [{ name: '猫娘', text: ROLE.cat }] } });
    mod.internals.setCore(c);
    const r = await run(ctxGroup('1062935770'), { action: 'view' });
    assert.match(r.content, /人设：猫娘/);
    assert.match(r.content, /独立人设/);
  });

  await acheck('统一开关开着 → 分会话人设不生效，并给出警告', async () => {
    const { core: c } = makeCore({ conf: { personaUnified: true, personaByChat: { 'group:546789624': { roleText: ROLE.cat } } } });
    mod.internals.setCore(c);
    const r = await run(ctxGroup('1062935770'), { action: 'view' });
    assert.match(r.content, /人设：小鲸鱼（默认）/, '统一模式下应显示全局人设');
    assert.match(r.content, /⚠️/);
    assert.match(r.content, /设置 → 人设/);
  });
}

console.log('\n[6] 列举');
{
  await acheck('list 只给名字（内置 + 自定义）', async () => {
    const { core: c } = makeCore({ conf: { customPersonas: [{ name: '猫娘', text: ROLE.cat, customRules: 'RULES-猫娘' }] } });
    mod.internals.setCore(c);
    const r = await tool0(tools).execute(ctxPrivate('1062935770'), { action: 'list' });
    assert.match(r.content, /小鲸鱼（默认）/);
    assert.match(r.content, /猫娘/);
    assert.ok(!r.content.includes('ROLE-正文') && !r.content.includes('RULES-'));
  });

  await acheck('省略 action 时默认 view（不是 list）', async () => {
    const { core: c } = makeCore();
    mod.internals.setCore(c);
    const r = await tool0(tools).execute(ctxPrivate('1062935770'), {});
    assert.match(r.content, /人设：/);
  });
}

console.log('\n[7] 切换');
{
  const run = (ctx, args) => tool0(tools).execute(ctx, args);

  await acheck('换本会话人设 → 写 personaByChat[chatKey] 的 roleText/customRules', async () => {
    const { core: c, state, writes } = makeCore({ conf: { customPersonas: [{ name: '猫娘', text: ROLE.cat, customRules: 'RULES-猫娘' }] } });
    mod.internals.setCore(c);
    const r = await run(ctxGroup('1062935770'), { action: 'set', name: '猫娘' });
    assert.notEqual(r.isError, true, r.content);
    assert.equal(state.personaByChat['group:546789624'].roleText, ROLE.cat);
    assert.equal(state.personaByChat['group:546789624'].customRules, 'RULES-猫娘');
    assert.deepEqual(Object.keys(writes[0]), ['personaByChat'], '只该写 personaByChat');
    assert.deepEqual(Object.keys(writes[0].personaByChat), ['group:546789624'], '只该写这一个会话');
  });

  await acheck('保留该会话已有的 participation / systemPromptOverride', async () => {
    const { core: c, state } = makeCore({
      conf: {
        personaByChat: { 'group:546789624': { roleText: ROLE.jing, participation: 'high', systemPromptOverride: 'SPO-保留我' } },
        customPersonas: [{ name: '猫娘', text: ROLE.cat }],
      },
    });
    mod.internals.setCore(c);
    await run(ctxGroup('1062935770'), { action: 'set', name: '猫娘' });
    const e = state.personaByChat['group:546789624'];
    assert.equal(e.participation, 'high');
    assert.equal(e.systemPromptOverride, 'SPO-保留我');
    assert.equal(e.roleText, ROLE.cat);
  });

  await acheck('不碰其它会话的条目', async () => {
    const { core: c, state } = makeCore({
      conf: { personaByChat: { 'group:777777': { roleText: ROLE.mao } }, customPersonas: [{ name: '猫娘', text: ROLE.cat }] },
    });
    mod.internals.setCore(c);
    await run(ctxGroup('1062935770'), { action: 'set', name: '猫娘' });
    assert.equal(state.personaByChat['group:777777'].roleText, ROLE.mao);
  });

  await acheck('换全局人设 → 写 persona.roleText/customRules，**不碰 botName/selfNickname**', async () => {
    const { core: c, state } = makeCore({ conf: { customPersonas: [{ name: '猫娘', text: ROLE.cat, customRules: 'RULES-猫娘' }] } });
    mod.internals.setCore(c);
    const r = await run(ctxPrivate('1062935770'), { action: 'set', target: '全局', name: '猫娘' });
    assert.notEqual(r.isError, true, r.content);
    assert.equal(state.persona.roleText, ROLE.cat);
    assert.equal(state.persona.customRules, 'RULES-猫娘');
    assert.equal(state.persona.botName, '小鲸鱼', 'botName 是账号身份，不能被顺手改掉');
    assert.equal(state.persona.selfNickname, '鱼');
  });

  await acheck('给他人会话换人设（chatKey 形式）', async () => {
    const { core: c, state } = makeCore({ conf: { customPersonas: [{ name: '猫娘', text: ROLE.cat }] } });
    mod.internals.setCore(c);
    await run(ctxPrivate('1062935770'), { action: 'set', target: 'private:2229576564', name: '猫娘' });
    assert.equal(state.personaByChat['private:2229576564'].roleText, ROLE.cat);
  });

  await acheck('统一开关开着 + 分会话 → 拒绝并指路（不写配置）', async () => {
    const { core: c, writes } = makeCore({ conf: { personaUnified: true, customPersonas: [{ name: '猫娘', text: ROLE.cat }] } });
    mod.internals.setCore(c);
    const r = await run(ctxGroup('1062935770'), { action: 'set', name: '猫娘' });
    assert.equal(r.isError, true);
    assert.match(r.content, /所有会话共用一个|同一个/);
    assert.equal(writes.length, 0);
  });

  await acheck('统一开关开着 + 改全局 → 允许（这正是那个开关管辖的对象）', async () => {
    const { core: c, state } = makeCore({ conf: { personaUnified: true, customPersonas: [{ name: '猫娘', text: ROLE.cat }] } });
    mod.internals.setCore(c);
    const r = await run(ctxPrivate('1062935770'), { action: 'set', target: '全局', name: '猫娘' });
    assert.notEqual(r.isError, true, r.content);
    assert.equal(state.persona.roleText, ROLE.cat);
  });

  await acheck('名字不存在 → 拒绝，并给相近的名字（仍然只有名字）', async () => {
    const { core: c, writes } = makeCore({ conf: { customPersonas: [{ name: '猫娘', text: ROLE.cat }, { name: '猫娘二号', text: ROLE.cat2 }] } });
    mod.internals.setCore(c);
    const r = await run(ctxGroup('1062935770'), { action: 'set', name: '猫' });
    assert.equal(r.isError, true);
    assert.match(r.content, /猫娘/);
    assert.ok(!r.content.includes('ROLE-正文'));
    assert.equal(writes.length, 0);
  });

  await acheck('重名 → 拒绝（不猜）', async () => {
    const { core: c, writes } = makeCore({ conf: { customPersonas: [{ name: '猫娘', text: ROLE.cat }, { name: '猫娘', text: ROLE.cat2 }] } });
    mod.internals.setCore(c);
    const r = await run(ctxGroup('1062935770'), { action: 'set', name: '猫娘' });
    assert.equal(r.isError, true);
    assert.match(r.content, /都叫|重名|分不清/);
    assert.equal(writes.length, 0);
  });

  await acheck('没给 name → 拒绝并提示先 list', async () => {
    const { core: c, writes } = makeCore();
    mod.internals.setCore(c);
    const r = await run(ctxGroup('1062935770'), { action: 'set' });
    assert.equal(r.isError, true);
    assert.match(r.content, /action=list/);
    assert.equal(writes.length, 0);
  });

  await acheck('写失败 → 明确报错，不假装成功', async () => {
    mod.internals.setCore({
      getConfig: () => ({ persona: { roleText: ROLE.jing }, personaByChat: {}, personaUnified: false, customPersonas: [{ name: '猫娘', text: ROLE.cat }] }),
      updateConfig: () => { throw new Error('磁盘只读'); },
      personaForChat: (k) => mod.internals.effectiveForChat({ persona: { roleText: ROLE.jing }, personaByChat: {} }, k),
      PERSONAS,
    });
    const r = await run(ctxGroup('1062935770'), { action: 'set', name: '猫娘' });
    assert.equal(r.isError, true);
    assert.match(r.content, /写入配置失败/);
  });
}

console.log('\n[8] 目标解析');
{
  const ctx = ctxGroup('1062935770', '546789624');
  check('省略 → 当前会话', () => {
    const t = mod.internals.parseTarget('', ctx);
    assert.equal(t.chatKey, 'group:546789624');
    assert.equal(t.current, true);
  });
  check('group:123 / private:123 / 群123 / 私聊123 都认', () => {
    assert.equal(mod.internals.parseTarget('group:123456', ctx).chatKey, 'group:123456');
    assert.equal(mod.internals.parseTarget('private:123456', ctx).chatKey, 'private:123456');
    assert.equal(mod.internals.parseTarget('群123456', ctx).chatKey, 'group:123456');
    assert.equal(mod.internals.parseTarget('私聊 123456', ctx).chatKey, 'private:123456');
  });
  check('裸数字默认当群号，kind=private 时当私聊', () => {
    assert.equal(mod.internals.parseTarget('123456', ctx).chatKey, 'group:123456');
    assert.equal(mod.internals.parseTarget('123456', ctx, 'private').chatKey, 'private:123456');
  });
  check('全局的各种写法', () => {
    for (const w of ['全局', '全局人设', '默认', 'global', 'ALL']) {
      assert.equal(mod.internals.parseTarget(w, ctx).kind, 'global', w);
    }
  });
  check('认不出 → 报错并给格式', () => {
    const t = mod.internals.parseTarget('那个群', ctx);
    assert.ok(t.error);
    assert.match(t.error, /group:群号/);
  });
  check('没有当前会话信息且没给 target → 报错', () => {
    const t = mod.internals.parseTarget('', { chatKey: '' });
    assert.ok(t.error);
  });
}

console.log('\n[9] 核心接线（真装在技能目录里时才有效）');
{
  mod.internals.resetCore();
  try {
    const c = await mod.internals.loadCore();
    check('能定位核心 config.js + personas.js，并拿到内置人设', () => {
      assert.ok(c.from);
      assert.equal(typeof c.getConfig, 'function');
      assert.equal(typeof c.updateConfig, 'function');
      assert.equal(typeof c.personaForChat, 'function');
      assert.ok(Object.keys(c.PERSONAS).length >= 1);
    });
    console.log(`       路径：${c.from}`);

    // 本地兜底实现 vs 核心真函数：用核心自带的 setRuntimeConfig 注入合成配置逐条对照。
    // ⚠️ setRuntimeConfig 只改**当前进程**的内存（注释就写着"不落盘"），而且这里是独立的
    //    node 进程 —— 碰不到正在运行的程序，也绝不会写配置文件。
    check('effectiveForChat 与核心 personaForChat 在合成配置上逐条一致', () => {
      if (!c.setRuntimeConfig) throw new Error('核心没导出 setRuntimeConfig，无法对照');
      const original = c.getConfig();
      const cases = [
        { personaUnified: false, personaByChat: { 'group:1': { roleText: 'A' } } },
        { personaUnified: true, personaByChat: { 'group:1': { roleText: 'A' } } },
        { personaUnified: false, personaByChat: { 1: { roleText: 'B' } } },
        { personaUnified: false, personaByChat: { 'group:1': { roleText: 'A', participation: 'high', systemPromptOverride: 'S' } } },
        { personaUnified: false, personaByChat: { 'group:1': { roleText: '   ' } } },
        { personaUnified: false, personaByChat: { 'group:1': { participation: 'low' } } },
      ];
      try {
        for (const conf of cases) {
          const merged = c.deepMerge(original, conf);
          c.setRuntimeConfig(merged);
          for (const key of ['group:1', 'private:2', 'group:546789624']) {
            assert.deepEqual(
              mod.internals.effectiveForChat(merged, key),
              c.personaForChat(key),
              `${key} @ ${JSON.stringify(conf)}`
            );
          }
        }
      } finally {
        c.setRuntimeConfig(original);
      }
    });

    check('deepMerge：写一个会话的 personaByChat 不会整体替换掉别的会话', () => {
      if (!c.deepMerge) throw new Error('核心没导出 deepMerge');
      const base = { personaByChat: { 'group:1': { roleText: 'A' }, 'group:2': { roleText: 'B' } } };
      const out = c.deepMerge(base, { personaByChat: { 'group:2': { roleText: 'C' } } });
      assert.equal(out.personaByChat['group:1'].roleText, 'A', '别的会话必须留着');
      assert.equal(out.personaByChat['group:2'].roleText, 'C');
    });
  } catch (error) {
    console.log(`  skip 未能定位核心模块（在工作区里跑就会这样）：${error?.message ?? error}`);
  }
}

console.log(`\n===== 通过 ${pass}，失败 ${fail} =====`);
process.exit(fail ? 1 : 0);
