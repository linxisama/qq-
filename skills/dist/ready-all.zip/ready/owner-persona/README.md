# 主人改人设（owner-persona）

主人在聊天里**直接说**，就能查看 / 切换「某个会话」或「全局」的人设。**列举时只给人设名字**。

```
主人：现在是什么人设            → owner-persona__persona { action: "view" }            （当前会话）
主人：546789624 那群什么人设     → { action: "view", target: "group:546789624" }
主人：全局是什么人设            → { action: "view", target: "全局" }

主人：给我换个人设              → { action: "list" }   ← 只念名字，不剧透正文
主人：那就昭昭                  → { action: "set", name: "昭昭" }   ← 选中即改，立即生效
主人：把那个群换成猫娘          → { action: "set", target: "group:546789624", name: "猫娘" }
```

不是主人说这些话 → 工具直接拒绝，**连人设名单都不回**。

---

## 先填一项设置：主人 QQ 号

**技能设置 → 主人改人设 → 主人 QQ 号**（多个用逗号分隔；空格/分号/顿号也认）。

- 判定**只看号码相等**：名字、群名片、正文里自称"我是你主人"，全都不算数。
- 留空 = 本技能不生效（技能页会显示原因，工具也不会给模型）。
- 号码来源是协议字段 `ctx.session.trigger[].senderId`
  （⚠️ 工具的 `ctx` 里**没有** `senderId` / `userId`，别去那儿找）。
- 本技能**不依赖**任何其它插件（不读「主人识别」那份名单）。

## 它到底改了什么

| | 字段 | 说明 |
|---|---|---|
| ✅ 会话 | `config.personaByChat[chatKey]` 的 `roleText` + `customRules` | 只写这两个字段；该会话已有的 `participation` / `systemPromptOverride` **原样保留**（与 UI 的「选择人设」同语义） |
| ✅ 全局 | `config.persona` 的 `roleText` + `customRules` | 只写这两个；`botName` / `selfNickname` 是账号身份，**任何情况下都不碰**（改了会和 @ 判定、存档里的称呼对不上） |
| ❌ 不写 | 其它会话的条目、人设库本身 | 写的是"只带目标那一个键"的 patch，`deepMerge` 只合并这一处，别的会话不受影响 |

**改动即时生效**，下一个回合就用新人设（不用重启）。

## 名字是怎么判定的

与 UI **完全同一套判据**：某会话/全局当前生效的 `roleText` 与某个人设模板的 `text` **全等**，
才算"就是这个人设"，然后显示它的名字；匹配不到就显示"自定义"
（`ui/app/06-settings-render.js:606` 就是这一行逻辑，这里刻意不另发明一套）。

- 人设库 = 内置 `src/personas.js` 的 `PERSONAS` + 设置页存的 `config.customPersonas`。
- 生效人设以核心 `src/config.js:708 personaForChat()` 为准（统一开关、`group:123` 与裸 `123` 两种键格式，
  这些规则不重写一遍；本地那份兜底实现有自测与真函数逐条对照）。

## 已知边界（都是设计取舍）

- **「所有的群聊/私聊使用同一个人设」开着时，分会话人设根本不生效**：此时改会话会被拒绝，
  并提示去 设置 → 人设 关掉那个开关（改**全局**仍然允许 —— 那正是该开关管辖的对象）。
- 人设库里有**重名**时，`set` 会拒绝并让人先去改名（不猜是哪个）。
- 手写的、不在人设库里的正文 → 只能显示"自定义"，**没法用说话切回去**（先把它存成一个人设即可）。
- 列举与查看**只给名字**，角色设定正文永远不会被念出来（自测里有专门的"不泄露正文"断言）。

## 自测

```powershell
cd "<QQ Agent 安装目录>\resources\app\skills\owner-persona"
& "<QQ Agent 安装目录>\resources\app\snowluma\node.exe" selftest.mjs
```

**45 个用例全过**（在安装目录里跑；在工作区里跑会跳过最后 3 个核心接线用例）。
全部离线、**绝不碰真实配置**（注入的假核心 `setCore`）。

覆盖：清单/工具注册、主人闸门（非主人 / 未配号码 / 取不到号码 / 多主人）、人设目录与名字判据、
查看（独立 / 跟随全局 / 全局 / 统一开关警告 / 自定义 / 裸 id 键历史数据）、
列举（只给名字、不泄露正文）、切换（写哪两个字段、不碰 `botName`、保留 `participation`、
不碰其它会话、统一开关拦截、重名 / 不存在 / 缺 name / 写失败）、目标解析，
最后三项拿**真代码**验证：能定位核心 `config.js` + `personas.js`、
本地兜底实现与真 `personaForChat` 在合成配置上**逐条一致**、
`deepMerge` 写一个会话不会整体替换掉别的会话。

> 拿真函数对照时用的是核心自带的 `setRuntimeConfig`（注释写明"内存态、不落盘"），
> 而且跑在独立的 node 进程里 —— 碰不到正在运行的程序，也不会写配置文件。

## 装在哪

- 当前：`resources/app/skills/owner-persona/`（与其它技能同级；程序更新只覆盖
  `src/ ui/ electron/ assets/ doc/ node_modules/`，**不动 `skills/`**）。
- 也可以：`<数据根>/modules/owner-persona/` —— `index.js` 里两条相对路径都试过。
