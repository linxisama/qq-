// 控制台背景 + 外观（把一张图片铺到 QQ Agent 控制台页面的背景上，并保证文字仍然看得清）
//
// ── 先说清楚它为什么"不是标准插件"（重要）────────────────────────────────
// 扩展系统**没有**改动控制台前端的口子：清单里没有路由 / 资源 / UI 注入这类字段，
// 核心消费的能力名里也没有任何和界面有关的（见 skill-reference.md §1.8）。
// 所以这个功能只能走"文件级"做法，本文件做的就两件事：
//   ① 把选中的图片复制成 ui/console-bg.<ext>（ui/ 由核心静态服务，MIME 与 CSP 都放行图片）
//   ② 在 ui/style.css 末尾写入一段**带标记的** CSS（背景图 + 面板样式 + 字体 + 文字阴影）
// 被写入的只有那段标记块；停用技能时会整段删掉，图片也一起清掉。
//
// ── 为什么放在 skills/ 而不是 plugins/ ────────────────────────────────
// 插件的硬要求是"至少提供一个能力或钩子"，否则加载器会警告
// "在 plugins/ 却没有提供能力或钩子：没有任何代码会去调用它"。
// 而这个功能真正对外的一步是"注册一个工具让机器人能换背景"，
// 所以它是 LLM 型技能（configSchema 设置 + 工具，两条路都汇到同一个 apply）。
//
// ── 踩过的两个坑（改之前先读）────────────────────────────────────────
// ① 只给 body 铺图 = **看不见**：#topbar / #tabs / .list-pane / .detail-pane /
//    .usage-pane / .settings-* 各自画着实心背景，整页被盖死。所以必须同时处理面板
//    （默认 glass：半透明磨砂 —— 既透出背景，又保住文字对比度）。
// ② 改了模板必须 +TEMPLATE_VERSION：否则"图没换、压暗没改"时指纹不变，
//    已应用的旧模板永远不会被重写，用户会以为设置没生效。
//
// ── 安全边界 ─────────────────────────────────────────────────────────
// 「允许机器人换背景」默认**关闭**：关着的时候群里任何人说什么都改不了控制台。
// 打开后，若装了「主人识别」，只有主人能改（软依赖 message.owner-check）；
// 没配主人名单时按"没装"处理（只记一条日志），不会把所有人挡在门外。

import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(__dirname, '..', '..');
const UI_DIR = path.join(ROOT, 'ui');
const UI_CSS = path.join(UI_DIR, 'style.css');
const DATA_DIR = process.env.QQ_AGENT_DATA_DIR || path.join(ROOT, 'data');
const DROP_DIR = path.join(DATA_DIR, 'console-bg');   // 丢图文件夹：放这里就用最新的一张
const CSS_BACKUP = path.join(DROP_DIR, 'style.css.bak');

export const MARK_BEGIN = '/* ==== console-background:begin';
export const MARK_END = '/* ==== console-background:end ==== */';
/** 模板版本：改了 buildCssBlock 的输出就 +1 —— 否则已应用的旧模板不会重写（指纹没变）。 */
export const TEMPLATE_VERSION = 3;
const IMAGE_PREFIX = 'console-bg';
const ALLOWED_EXT = ['.png', '.jpg', '.jpeg', '.webp', '.gif'];

/** 会被透明/磨砂化的整页面板（它们原本是实心背景，会把整页图盖死）。 */
const PANEL_SELECTORS = [
  '#topbar', '#tabs', '.list-pane', '.detail-pane',
  '.usage-pane', '.snowluma-pane', '.fullpage',
  '.settings-sidebar', '.settings-pane'
];

let cfg = () => ({});
let log = () => {};
let warn = () => {};
let ownerCheck = null;
let timer = null;

// ── 纯函数部分（可被 test/console-background-test.mjs 直接测）───────────────

/** 压暗百分比归一化：只认 0~90，非法值回落 45。 */
export function clampDimPercent(v) {
  const n = Number(v);
  if (!Number.isFinite(n)) return 45;
  return Math.max(0, Math.min(90, Math.round(n)));
}

/** 铺图方式归一化：只认 cover / contain / tile，其它一律 cover。 */
export function normalizeFit(v) {
  const s = String(v ?? '').trim().toLowerCase();
  return ['cover', 'contain', 'tile'].includes(s) ? s : 'cover';
}

/** 面板样式归一化：glass（半透明磨砂，默认）/ transparent（全透）/ solid（实心）。 */
export function normalizePanelStyle(v) {
  const s = String(v ?? '').trim().toLowerCase();
  return ['glass', 'transparent', 'solid'].includes(s) ? s : 'glass';
}

/** 界面缩放：只认 80~150，非法或 100 都返回 100（100 = 不写 zoom）。 */
export function clampScalePercent(v) {
  const n = Number(v);
  if (!Number.isFinite(n)) return 100;
  return Math.max(80, Math.min(150, Math.round(n)));
}

/**
 * 生成要写进 style.css 的那段 CSS。四件事：
 *  ① body 铺上「压暗渐变 + 图片」，fixed 让图片相对**视口**定位（滚动不动）。
 *  ② 面板样式：glass = 用当前主题底色做半透明磨砂（默认，可读性最好）；
 *     transparent = 完全透明；solid = 不动面板（面板保持实心，背景只在缝隙露出）。
 *  ③ 可选：整体字体（覆盖 --font-ui）、界面缩放（zoom）、文字阴影（压在照片上也能认）。
 */
export function buildCssBlock({
  imageName,
  dimPercent = 45,
  fit = 'cover',
  panelStyle = 'glass',
  textShadow = true,
  fontFamily = '',
  uiScalePercent = 100
} = {}) {
  const dim = clampDimPercent(dimPercent) / 100;
  const mode = normalizeFit(fit);
  const size = mode === 'contain' ? 'contain' : (mode === 'tile' ? 'auto' : 'cover');
  const repeat = mode === 'tile' ? 'repeat' : 'no-repeat';
  const url = `url("/${IMAGE_PREFIX}${path.extname(imageName) || '.png'}")`;
  const style = normalizePanelStyle(panelStyle);
  const scale = clampScalePercent(uiScalePercent);
  const font = String(fontFamily ?? '').trim();

  const body = [
    `  background-image: linear-gradient(rgba(6, 10, 18, ${dim.toFixed(2)}), rgba(6, 10, 18, ${dim.toFixed(2)})), ${url};`,
    `  background-size: cover, ${size};`,
    '  background-position: center center, center center;',
    `  background-repeat: no-repeat, ${repeat};`,
    '  background-attachment: fixed, fixed;'
  ];
  // 文字阴影：默认开。字直接压在照片上时，没有阴影会糊成一片。
  if (textShadow !== false) body.push('  text-shadow: 0 1px 3px rgba(0, 0, 0, 0.65);');
  // 界面缩放：只在不是 100 时写（避免给默认用户引入布局变量）
  if (scale !== 100) body.push(`  zoom: ${(scale / 100).toFixed(2)};`);

  const out = [
    `${MARK_BEGIN}（由「控制台背景」技能自动写入，请勿手改）==== */`,
    'body {',
    ...body,
    '}'
  ];

  if (font) out.push(':root, [data-theme] {', `  --font-ui: ${font} !important;`, '}');

  if (style !== 'solid') {
    out.push(
      '/* 以下面板原本是实心背景，会把整页背景整个盖住（不透明 = 看不见）→ 改成透出背景 */',
      '#topbar, #tabs, .list-pane, .detail-pane, .usage-pane, .snowluma-pane, .fullpage,',
      '.settings-sidebar, .settings-pane {'
    );
    if (style === 'glass') {
      // 用主题自己的底色做半透明（color-mix 不支持时优雅退化：保持原实心色，背景暂时看不见）
      out.push(
        '  background-color: color-mix(in srgb, var(--bg0) 62%, transparent) !important;',
        '  backdrop-filter: blur(7px);',
        '  -webkit-backdrop-filter: blur(7px);'
      );
    } else {
      out.push('  background-color: transparent !important;');
    }
    out.push('}');
  }

  out.push(MARK_END);
  return out.join('\n');
}

/**
 * 把标记块写进 CSS 文本：已有就整段替换，没有就追加到末尾。
 * 标记只认"开始行 → 结束行"这一段，其余内容一个字节都不动。
 */
export function upsertBlock(css, block) {
  const text = String(css ?? '');
  const begin = text.indexOf(MARK_BEGIN);
  if (begin < 0) return `${text.replace(/\s*$/, '')}\n\n${block}\n`;
  const endAt = text.indexOf(MARK_END, begin);
  // 结束标记丢了（被手改过 / 写了一半）：从开始标记一路替换到文件末尾，避免留下半截规则
  const tail = endAt < 0 ? text.length : endAt + MARK_END.length;
  return `${text.slice(0, begin)}${block}${text.slice(tail)}`;
}

/** 删掉标记块，返回与原文件其余部分一致的 CSS 文本。 */
export function stripBlock(css) {
  const text = String(css ?? '');
  const begin = text.indexOf(MARK_BEGIN);
  if (begin < 0) return text;
  const endAt = text.indexOf(MARK_END, begin);
  const tail = endAt < 0 ? text.length : endAt + MARK_END.length;
  return `${text.slice(0, begin)}${text.slice(tail)}`.replace(/\n{3,}/g, '\n\n');
}

// ── 文件操作 ───────────────────────────────────────────────────────────

function readCss() {
  try { return fs.readFileSync(UI_CSS, 'utf8'); } catch { return null; }
}

/** 同目录 tmp + rename：写一半断电也不会把 style.css 变成半截文件。 */
function writeCssAtomic(text) {
  const tmp = `${UI_CSS}.tmp-console-bg`;
  fs.writeFileSync(tmp, text, 'utf8');
  fs.renameSync(tmp, UI_CSS);
}

/** 第一次修改前留一份备份（只留一次，不覆盖）。 */
function backupOnce() {
  try {
    if (fs.existsSync(CSS_BACKUP)) return;
    fs.mkdirSync(DROP_DIR, { recursive: true });
    fs.copyFileSync(UI_CSS, CSS_BACKUP);
    log(`已备份原样式到 ${CSS_BACKUP}`);
  } catch (error) {
    warn(`备份样式失败（继续执行）：${error?.message ?? error}`);
  }
}

/** 现有 ui/console-bg.* 的文件名（用于换扩展名时清掉旧的）。 */
function existingImages() {
  try {
    return fs.readdirSync(UI_DIR).filter((n) => n.toLowerCase().startsWith(`${IMAGE_PREFIX}.`));
  } catch { return []; }
}

function removeExistingImages(keep = '') {
  for (const name of existingImages()) {
    if (name === keep) continue;
    try { fs.unlinkSync(path.join(UI_DIR, name)); } catch { /* 删不掉不影响背景 */ }
  }
}

/** 丢图文件夹里最新的一张可用图片（imagePath 留空时用）。 */
function newestDropImage() {
  try {
    if (!fs.existsSync(DROP_DIR)) return '';
    const cands = fs.readdirSync(DROP_DIR)
      .filter((n) => ALLOWED_EXT.includes(path.extname(n).toLowerCase()))
      .map((n) => {
        const full = path.join(DROP_DIR, n);
        try { return { full, mtime: fs.statSync(full).mtimeMs }; } catch { return null; }
      })
      .filter(Boolean)
      .sort((a, b) => b.mtime - a.mtime);
    return cands[0]?.full || '';
  } catch { return ''; }
}

/** 校验一张图片能不能用；返回 { ok, ext, reason }。 */
export function checkImage(src) {
  const p = String(src ?? '').trim();
  if (!p) return { ok: false, reason: '没有填图片路径' };
  if (!path.isAbsolute(p)) return { ok: false, reason: '需要本机图片的完整路径（例如 D:\\图片\\bg.jpg）' };
  const ext = path.extname(p).toLowerCase();
  if (!ALLOWED_EXT.includes(ext)) return { ok: false, reason: `只支持 ${ALLOWED_EXT.join(' / ')}，这张是 ${ext || '（没有扩展名）'}` };
  let st = null;
  try { st = fs.statSync(p); } catch { return { ok: false, reason: `找不到这个文件：${p}` }; }
  if (!st.isFile()) return { ok: false, reason: `这不是一个文件：${p}` };
  return { ok: true, ext, size: st.size, mtime: st.mtimeMs };
}

// ── 应用 / 撤销 ────────────────────────────────────────────────────────

const state = { fp: '', src: '', applied: false, warned: false };

/** 把样式铺上去（复制图片 + 写 CSS）。返回 { ok, reason? }。 */
export function applyImage(opts = {}) {
  const { src } = opts;
  const chk = checkImage(src);
  if (!chk.ok) return { ok: false, reason: chk.reason };

  const css = readCss();
  if (css === null) return { ok: false, reason: `读不到 ${UI_CSS}（控制台前端文件被移动过？）` };

  backupOnce();

  const destName = `${IMAGE_PREFIX}${chk.ext}`;
  const dest = path.join(UI_DIR, destName);
  try {
    removeExistingImages(destName);
    fs.copyFileSync(String(src).trim(), dest);
  } catch (error) {
    return { ok: false, reason: `复制图片失败：${error?.message ?? error}` };
  }

  const block = buildCssBlock({ ...opts, imageName: destName });
  const next = upsertBlock(css, block);
  if (next === css) { state.applied = true; return { ok: true, dest }; }   // 一字未变，不写盘
  try {
    writeCssAtomic(next);
  } catch (error) {
    return { ok: false, reason: `写 style.css 失败：${error?.message ?? error}` };
  }
  // 写完读回确认（写坏样式表会让控制台样式全崩，必须验；失败就用备份还原）
  const back = readCss();
  if (!back || !back.includes(MARK_BEGIN)) {
    try {
      if (fs.existsSync(CSS_BACKUP)) {
        fs.copyFileSync(CSS_BACKUP, UI_CSS);
        return { ok: false, reason: `写入后校验失败，已用备份还原 ${UI_CSS}` };
      }
    } catch { /* 还原失败也要如实返回 */ }
    return { ok: false, reason: '写入后校验失败（style.css 可能已损坏，备份见 data/console-bg/style.css.bak）' };
  }
  state.applied = true;
  return { ok: true, dest };
}

/** 撤掉背景与外观改动（删 CSS 块 + 删图片）。 */
export function clearBackground() {
  const css = readCss();
  if (css !== null && css.includes(MARK_BEGIN)) {
    try { writeCssAtomic(stripBlock(css)); } catch (error) { return { ok: false, reason: `还原 style.css 失败：${error?.message ?? error}` }; }
  }
  removeExistingImages('');
  state.applied = false;
  return { ok: true };
}

/** 把当前设置折算成"应用参数 + 指纹"。指纹变了才重新写盘。 */
function planFromSettings() {
  const c = cfg();
  const want = String(c.imagePath ?? '').trim();
  const src = want || newestDropImage();
  const opts = {
    src,
    dimPercent: clampDimPercent(c.dimPercent),
    fit: normalizeFit(c.fit),
    panelStyle: normalizePanelStyle(c.panelStyle),
    textShadow: c.textShadow !== false,
    fontFamily: String(c.fontFamily ?? '').trim(),
    uiScalePercent: clampScalePercent(c.uiScalePercent)
  };
  let mtime = 0;
  try { mtime = fs.statSync(src).mtimeMs; } catch { /* 下面 checkImage 会报错 */ }
  const fp = [src, mtime, opts.dimPercent, opts.fit, opts.panelStyle,
    opts.textShadow ? 1 : 0, opts.fontFamily, opts.uiScalePercent, TEMPLATE_VERSION].join('|');
  return { src, opts, fp };
}

/** 按当前设置同步一次（定时轮询与 activate 都走它）。 */
function syncFromSettings(reason = 'poll') {
  if (typeof cfg !== 'function') return;      // setup 还没跑
  const { src, opts, fp } = planFromSettings();

  if (!src) {
    if (state.applied) { clearBackground(); log('没有可用背景图，已撤掉背景'); }
    else if (!state.warned) { state.warned = true; log('还没配置背景图（设置里填图片路径，或把图片放进 data/console-bg/）'); }
    state.fp = ''; state.src = '';
    return;
  }
  state.warned = false;

  // 指纹相同**且**标记块还在文件里，才算"不用干活"：
  // 后半句是为了自愈 —— 升级覆盖 ui/ 后那段 CSS 会丢，丢了必须重写回去。
  const css = readCss();
  const blockStillThere = Boolean(css && css.includes(MARK_BEGIN));
  if (state.fp === fp && blockStillThere) return;
  state.fp = fp; state.src = src;

  const r = applyImage(opts);
  if (r.ok) log(`${reason}：控制台外观已更新（${path.basename(src)}·压暗 ${opts.dimPercent}%·${opts.fit}·面板 ${opts.panelStyle}${opts.fontFamily ? '·字体已改' : ''}${opts.uiScalePercent !== 100 ? `·缩放 ${opts.uiScalePercent}%` : ''}）`);
  else warn(`${reason}：外观没生效 —— ${r.reason}`);
}

// ── 生命周期 ───────────────────────────────────────────────────────────

export function setup(api) {
  cfg = api.config;
  log = api.log;
  warn = api.warn;
  // 软依赖：装了「主人识别」就借它做权限判定，没装也照常工作
  ownerCheck = typeof api.capability === 'function' ? api.capability('message.owner-check') : null;

  api.registerTool({
    id: 'set_background',
    name: '更换控制台背景',
    description: '更换或取消 QQ Agent 控制台（Web 界面）的背景图。只有当用户明确说「把控制台背景换成 <某个图片路径>」「换个背景」「取消控制台背景」时才用。set 需要 imagePath（本机图片的完整路径，png/jpg/jpeg/webp/gif）；clear 清除背景。压暗、面板样式、字体等外观项一律用控制台里保存的设置，本工具不改它们。改完要让用户按 F5 刷新控制台。',
    category: 'system',
    icon: '🖼️',
    parameters: {
      type: 'object',
      properties: {
        action: { type: 'string', enum: ['set', 'clear'], description: 'set = 换背景；clear = 取消背景。' },
        imagePath: { type: 'string', description: 'action=set 时必填：本机图片的完整路径，例如 D:\\图片\\bg.jpg。' }
      },
      required: ['action']
    },
    async execute(ctx, args) {
      const c = cfg();
      if (c.allowBotChange !== true) {
        return { content: '控制台背景目前只允许在本机控制台的「技能 → 控制台背景」里改（设置项「允许机器人换背景」是关着的）。请让用户自己在控制台里改。', isError: true };
      }

      // 装了主人识别、且配了主人名单 → 只有主人能改
      try {
        const gate = ownerCheck?.({ triggerEntries: Array.isArray(ctx.session?.trigger) ? ctx.session.trigger : undefined, kind: ctx.kind, selfId: ctx.selfId });
        if (gate && gate.ownerMode === false && gate.rules) {
          return { content: '只有主人能更换控制台背景。', isError: true };
        }
      } catch (error) {
        warn(`主人判定失败（按放行处理）：${error?.message ?? error}`);
      }

      const action = String(args?.action ?? '').trim().toLowerCase();
      if (action === 'clear') {
        const r = clearBackground();
        if (!r.ok) return { content: `取消失败：${r.reason}`, isError: true };
        state.fp = ''; state.src = '';
        return { content: '已取消控制台背景。记得让用户按 F5 刷新控制台页面。' };
      }

      // 用配置里的外观项（压暗/面板样式/字体/缩放），只把图片换成模型给的那张
      const src = String(args?.imagePath ?? '').trim() || String(c.imagePath ?? '').trim();
      const { opts } = planFromSettings();
      const r = applyImage({ ...opts, src });
      if (!r.ok) return { content: `换背景失败：${r.reason}`, isError: true };
      state.fp = '';          // 让下一轮轮询按"配置"重新核对一次（幂等，不会重复写盘）
      state.src = src;
      return { content: `已把控制台背景换成 ${path.basename(src)}。请让用户按 F5（或 Ctrl+F5）刷新控制台页面才能看到。` };
    }
  });
}

export async function activate() {
  // 先把"丢图文件夹"建好，用户往里放图片就能用（不用先手建目录）
  try { fs.mkdirSync(DROP_DIR, { recursive: true }); } catch { /* 建不了不影响其它路径 */ }
  syncFromSettings('activate');
  if (timer) clearInterval(timer);
  // 3 秒轮询：改了设置 / 往 data/console-bg/ 丢了新图，几秒后自动生效；
  // 顺带自愈——升级覆盖 ui/style.css 后把那段 CSS 重新写回去。
  timer = setInterval(() => syncFromSettings('poll'), 3000);
  timer.unref?.();
}

export async function deactivate() {
  if (timer) { clearInterval(timer); timer = null; }
  clearBackground();      // ⚠️ 必须清干净：否则"技能关掉了背景还在"
  try { fs.rmSync(`${UI_CSS}.tmp-console-bg`, { force: true }); } catch { /* ignore */ }
  state.fp = ''; state.src = ''; state.applied = false;
}
