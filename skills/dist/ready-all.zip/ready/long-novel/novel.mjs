#!/usr/bin/env node
// 长篇小说项目管家 —— DSH 侧（SKILL.md 里用 node 调）与 QQ Agent 侧（index.js import）**共用同一份实现**。
//
// 为什么要共用：两边都要读写同一批文件，如果各写一份，久了必然分叉 ——
// 一边认的目录结构另一边不认，简报的口径也会不一样，最后变成"用哪个入口写出来的东西不一样"。
// 所以这里只写一次，两边都从这里走。
//
// ── 项目目录长这样 ──────────────────────────────────────────────────────────
//   <项目目录>/
//     state.json        元信息与进度（标题/题材/每章目标字数/已完成章/下一章号）
//     bible.md          设定集：世界观、人物、称呼、语气、时间线、硬设定（唯一真相源）
//     outline.md        卷章大纲：每章一条（标题/目标/节拍/出场/章末钩子）
//     continuity.md     连续性台账：逐章追加"已确立的事实"（谁知道什么、伤、物品、承诺…）
//     chapters/
//       0001-第一章标题.md
//       0002-...
//
// ── 为什么要有 continuity 这一层 ────────────────────────────────────────────
// 长篇小说崩，几乎都崩在连续性上：第 12 章写她左臂受伤，第 30 章她双手抱臂；
// 第 40 章已经说过的事，第 55 章又被当成秘密揭开。写到几十万字靠"记得住"是不可能的，
// 靠的就是这份**逐章追加的台账** —— 每章写完往上一记，下一章的简报把它带进去。
//
// 用法（CLI）：
//   node novel.mjs new    --dir <项目目录> --title "书名" [--genre 题材] [--target 3000] [--chapters 60]
//   node novel.mjs brief  --dir <项目目录> [--chapter N] [--tail 1200]
//   node novel.mjs save   --dir <项目目录> --chapter N --file <正文.md> [--note "本章确立的事实"]
//   node novel.mjs note   --dir <项目目录> --chapter N --text "补一条台账"
//   node novel.mjs status --dir <项目目录>
//   node novel.mjs list   [--base <父目录>]
//   node novel.mjs check  --dir <项目目录>

import fs from 'node:fs';
import fsp from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const F = {
  state: 'state.json',
  bible: 'bible.md',
  outline: 'outline.md',
  continuity: 'continuity.md',
  chapters: 'chapters',
  style: 'style.md'
};

/** 本文件就在技能目录里，模板放它旁边的 templates/。 */
const HERE = path.dirname(fileURLToPath(import.meta.url));
const TEMPLATES_DIR = path.join(HERE, 'templates');

/**
 * 简报里带多少字的文风模板。
 * 文风要每章都提醒（不然几章之后就飘了），但整份塞进去会把每章提示词撑大 ——
 * 所以截断，并指出完整文件的路径。
 */
const DEFAULT_STYLE_CHARS = 3000;

const SCHEMA = 'long-novel/v1';

/** 可用的文风模板。 */
export async function listTemplates() {
  try {
    const names = await fsp.readdir(TEMPLATES_DIR);
    return names
      .filter((n) => n.toLowerCase().endsWith('.md'))
      .map((n) => ({ name: n.replace(/\.md$/i, ''), file: path.join(TEMPLATES_DIR, n) }))
      .sort((a, b) => a.name.localeCompare(b.name, 'zh'));
  } catch {
    return [];
  }
}

// ── 小工具 ──────────────────────────────────────────────────────────────────

/** 中文字数按**非空白字符**计 —— 这是中文写作圈的口径，不是 UTF-8 字节数。 */
export function countWords(text) {
  return String(text ?? '').replace(/\s+/g, '').length;
}

/** 文件名 slug：去掉路径敌意字符，留中文（中文标题直接当文件名可读性最好）。 */
function slug(title, max = 40) {
  const s = String(title ?? '').trim()
    .replace(/[\\/:*?"<>|\r\n\t]/g, '')
    .replace(/\s+/g, ' ')
    .slice(0, max)
    .trim();
  return s || '未命名';
}

function chapterFileName(n, title) {
  return `${String(n).padStart(4, '0')}-${slug(title)}.md`;
}

async function readIfExists(file) {
  try { return await fsp.readFile(file, 'utf8'); } catch { return null; }
}

async function writeAtomic(file, text) {
  await fsp.mkdir(path.dirname(file), { recursive: true });
  const tmp = file + '.tmp';
  await fsp.writeFile(tmp, text, 'utf8');
  await fsp.rename(tmp, file);
}

// ── 状态 ────────────────────────────────────────────────────────────────────

export async function readState(dir) {
  const raw = await readIfExists(path.join(dir, F.state));
  if (!raw) throw new Error(`不是长篇项目（缺 ${F.state}）：${dir}`);
  const s = JSON.parse(raw);
  if (s?.schema !== SCHEMA) throw new Error(`state.json 版本不对（期望 ${SCHEMA}）：${dir}`);
  return s;
}

async function writeState(dir, state) {
  state.updatedAt = new Date().toISOString();
  await writeAtomic(path.join(dir, F.state), JSON.stringify(state, null, 2) + '\n');
  return state;
}

/** 已完成章节：从 chapters/ 实读，不信 state 里的缓存（磁盘才是真相）。 */
export async function listChapters(dir) {
  const cdir = path.join(dir, F.chapters);
  let names = [];
  try { names = await fsp.readdir(cdir); } catch { return []; }
  const out = [];
  for (const name of names) {
    const m = /^(\d{4})-(.+)\.md$/.exec(name);
    if (!m) continue;
    const file = path.join(cdir, name);
    const text = (await readIfExists(file)) ?? '';
    const st = await fsp.stat(file).catch(() => null);
    out.push({ n: Number(m[1]), title: m[2], file, words: countWords(text), mtimeMs: st?.mtimeMs ?? 0 });
  }
  return out.sort((a, b) => a.n - b.n);
}

// ── 大纲 / 台账解析 ─────────────────────────────────────────────────────────

/**
 * 解析前先剥掉 HTML 注释。
 * 为什么需要：骨架里给的格式示例就放在 `<!-- -->` 里 —— 不剥的话，
 * 新建出来的项目一打开就"已经有第 1 章大纲了"，简报永远不会提醒你还得补大纲。
 */
function stripComments(text) {
  return String(text ?? '').replace(/<!--[\s\S]*?-->/g, '');
}

/**
 * 解析大纲：以 `## 第 N 章 标题` 或 `## N. 标题` 为一条。
 * 每条下面的正文行原样保留 —— 不规定死格式，作者想怎么写都行（目标/节拍/出场/钩子只是建议）。
 */
export function parseOutline(text) {
  const map = new Map();
  let cur = null;
  for (const line of stripComments(text).split('\n')) {
    const h = /^##\s*(?:第\s*)?(\d+)\s*(?:章)?\s*[.、:：]?\s*(.*)$/.exec(line);
    if (h) {
      cur = { n: Number(h[1]), title: (h[2] || '').trim(), lines: [] };
      map.set(cur.n, cur);
      continue;
    }
    if (cur && line.trim()) cur.lines.push(line);
  }
  return map;
}

/** 解析连续性台账：同样以 `## 第 N 章` 分节。 */
export function parseContinuity(text) {
  return parseOutlineLike(text);
}

function parseOutlineLike(text) {
  const map = new Map();
  let cur = null;
  for (const line of stripComments(text).split('\n')) {
    const h = /^##\s*(?:第\s*)?(\d+)\s*(?:章)?\b(.*)$/.exec(line);
    if (h) {
      cur = Number(h[1]);
      if (!map.has(cur)) map.set(cur, []);
      continue;
    }
    if (cur != null && line.trim()) map.get(cur).push(line);
  }
  return map;
}

/**
 * 从 bible 里摘【硬设定】行。
 *   · 跳过 markdown 标题行 —— `## 【硬设定】清单` 这种小节名不是设定，收进去只会刷屏；
 *   · 只收**标记后面真写了内容**的 —— 骨架里那行空的占位标记同理。
 */
export function pickHardRules(bibleText) {
  return String(bibleText ?? '')
    .split('\n')
    .filter((l) => /【硬设定】/.test(l))
    .filter((l) => !/^\s*#{1,6}\s/.test(l))
    .map((l) => l.replace(/^[\s\-*>]+/, '').trim())
    .filter((l) => l.replace(/【硬设定】[:：]?/, '').trim().length >= 2)
    .slice(0, 40);
}

// ── 简报：长篇能不能连贯写下去，全靠这一段 ──────────────────────────────────

/**
 * 生成第 N 章的写作简报。
 *
 * 构成（顺序有意为之，越靠后越"要照着做"）：
 *   ① 项目元信息   —— 书名/题材/每章目标字数
 *   ② 本章大纲     —— 这一章要干什么
 *   ③ 上一章结尾   —— 衔接用的原文尾巴（防"跳回开头"）
 *   ④ 连续性台账   —— 最近几章的既定事实（防前后矛盾）
 *   ⑤ 硬设定       —— bible 里标了【硬设定】的行（称呼/年龄/禁忌…最容易被写飞）
 *   ⑥ 交稿要求     —— 目标字数、不要中途收尾、不要省略
 *
 * @param {string} dir 项目目录
 * @param {{chapter?:number, tailChars?:number, bibleChars?:number}} opts
 */
export async function buildBrief(dir, opts = {}) {
  const state = await readState(dir);
  const chapters = await listChapters(dir);
  const doneMax = chapters.length ? Math.max(...chapters.map((c) => c.n)) : 0;
  const n = Number.isFinite(opts.chapter) && opts.chapter > 0 ? Number(opts.chapter) : doneMax + 1;
  const tailChars = Number.isFinite(opts.tailChars) && opts.tailChars > 0 ? opts.tailChars : 1200;

  const outlineText = (await readIfExists(path.join(dir, F.outline))) ?? '';
  const outline = parseOutline(outlineText);
  const beat = outline.get(n) || null;

  const prev = chapters.filter((c) => c.n < n).sort((a, b) => b.n - a.n)[0] || null;
  let prevTail = '';
  if (prev) {
    const text = (await readIfExists(prev.file)) ?? '';
    const body = text.trim();
    prevTail = body.length > tailChars ? '……' + body.slice(-tailChars) : body;
  }

  const contText = (await readIfExists(path.join(dir, F.continuity))) ?? '';
  const cont = parseContinuity(contText);
  const contRecent = [...cont.keys()].filter((k) => k < n).sort((a, b) => b - a).slice(0, 3).reverse();

  const bibleText = (await readIfExists(path.join(dir, F.bible))) ?? '';
  const hardLines = pickHardRules(bibleText);

  // 文风模板（见 listTemplates）。放在交稿要求之前 —— 它是"怎么写"，
  // 交稿要求是"交成什么样"，后者压轴。
  const styleText = ((await readIfExists(path.join(dir, F.style))) ?? '').trim();
  const styleCap = Number(state.styleChars) > 0 ? Number(state.styleChars) : DEFAULT_STYLE_CHARS;

  const target = Number(state.targetWordsPerChapter) || 3000;
  const lines = [];
  lines.push(`# 第 ${n} 章 写作简报`);
  lines.push('');
  lines.push(`- 书名：${state.title || '(未命名)'}`);
  if (state.genre) lines.push(`- 题材：${state.genre}`);
  lines.push(`- 每章目标字数：${target}`);
  lines.push(`- 已完成：${chapters.length} 章（最高章号 ${doneMax}）｜这份简报是给第 ${n} 章的`);
  lines.push('');
  lines.push('## 本章大纲');
  if (beat) {
    lines.push(`### 第 ${n} 章${beat.title ? ' ' + beat.title : ''}`);
    lines.push(...(beat.lines.length ? beat.lines : ['（大纲里这一章只有标题，没有正文说明 —— 按上一章的走向自己接。）']));
  } else {
    lines.push(`（大纲里**没有**第 ${n} 章这一条。两条路：先补大纲，或者按上一章结尾顺势往下写一节。不要凭空开新局。）`);
  }
  lines.push('');
  if (prevTail) {
    lines.push(`## 上一章（第 ${prev.n} 章${prev.title ? ' ' + prev.title : ''}）的结尾原文`);
    lines.push('```');
    lines.push(prevTail);
    lines.push('```');
    lines.push('');
    lines.push('（接着这段往下写。人物站位、称呼、时间、语气、正在进行到一半的动作，都要接得上 —— 不要重置场景，不要跳回开头。）');
    lines.push('');
  }
  if (contRecent.length) {
    lines.push('## 连续性台账（最近几章已确立的事实，不要写矛盾）');
    for (const k of contRecent) {
      lines.push(`### 第 ${k} 章`);
      lines.push(...cont.get(k));
    }
    lines.push('');
  } else if (cont.size) {
    lines.push('（台账里还没有第 ' + n + ' 章之前的记录 —— 第一次写的话，写完记得用 note 记一条。）');
    lines.push('');
  }
  if (hardLines.length) {
    lines.push('## 硬设定（从 bible 摘出，不得违反）');
    lines.push(...hardLines);
    lines.push('');
  }
  if (bibleText) {
    lines.push(`（完整设定集见 ${path.join(dir, F.bible)} —— 需要人物细节时去读，简报里不塞全文。）`);
    lines.push('');
  }
  if (styleText) {
    const trimmed = styleText.length > styleCap;
    lines.push(`## 文风要求${state.template ? `（模板：${state.template}）` : ''}`);
    lines.push(trimmed ? styleText.slice(0, styleCap) : styleText);
    if (trimmed) {
      lines.push('');
      lines.push(`（文风模板太长已截断，完整版见 ${path.join(dir, F.style)} —— 写之前读一遍全文。）`);
    }
    lines.push('');
  }
  lines.push('## 交稿要求');
  lines.push(`- 目标 ${target} 字（中文按非空白字符计）。写得比目标长没关系，**不要为了凑字数灌水，也不要提前收尾**。`);
  lines.push('- 直接给正文。不写开场白、不写"以下是我的创作"、结尾不加总结或现实提醒。');
  lines.push('- 章末留一个往下走的钩子，不要在这一章把矛盾解决干净。');
  lines.push('- 写完调用保存（把正文交给它），并附一条本章确立的事实，供连续性台账使用。');
  return lines.join('\n');
}

// ── 体检 ────────────────────────────────────────────────────────────────────

export async function runCheck(dir) {
  const state = await readState(dir);
  const chapters = await listChapters(dir);
  const issues = [];

  const outlineText = (await readIfExists(path.join(dir, F.outline))) ?? '';
  const outline = parseOutline(outlineText);
  const continuityText = (await readIfExists(path.join(dir, F.continuity))) ?? '';
  const cont = parseContinuity(continuityText);

  if (!(await readIfExists(path.join(dir, F.bible)))) issues.push('缺 bible.md（设定集是唯一真相源，没有它连续性迟早崩）');
  if (!outlineText.trim()) issues.push('outline.md 是空的 —— 没有大纲的长篇会越写越散');
  if (state.template && !(await readIfExists(path.join(dir, F.style)))) {
    issues.push(`state 里记着文风模板「${state.template}」，但 style.md 不见了 —— 每章简报会缺文风那一段，几章之后文风就飘了`);
  }

  // 章号断档
  const nums = chapters.map((c) => c.n);
  for (let i = 1; i < nums.length; i++) {
    if (nums[i] !== nums[i - 1] + 1) issues.push(`章号断档：第 ${nums[i - 1]} 章之后直接是第 ${nums[i]} 章`);
  }

  // 已写的章在大纲里没有
  const noBeat = chapters.filter((c) => !outline.has(c.n));
  if (noBeat.length) issues.push(`${noBeat.length} 章没有大纲条目：${noBeat.slice(0, 8).map((c) => '第 ' + c.n + ' 章').join('、')}${noBeat.length > 8 ? ' …' : ''}`);

  // 已写的章没有台账
  const noNote = chapters.filter((c) => !cont.has(c.n));
  if (noNote.length) issues.push(`${noNote.length} 章没有连续性记录：${noNote.slice(0, 8).map((c) => '第 ' + c.n + ' 章').join('、')}${noNote.length > 8 ? ' …' : ''}（下一章简报会缺这一段）`);

  // 短章
  const target = Number(state.targetWordsPerChapter) || 3000;
  const short = chapters.filter((c) => c.words < target * 0.6);
  if (short.length) issues.push(`${short.length} 章明显偏短（不足目标的 60%）：${short.slice(0, 8).map((c) => `第 ${c.n} 章 ${c.words} 字`).join('、')}`);

  return { issues, chapters, outline, continuity: cont };
}

// ── CLI ─────────────────────────────────────────────────────────────────────

function parseArgs(argv) {
  const out = { _: [] };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a.startsWith('--')) {
      const key = a.slice(2);
      const next = argv[i + 1];
      if (next === undefined || next.startsWith('--')) out[key] = true;
      else { out[key] = next; i += 1; }
    } else out._.push(a);
  }
  return out;
}

const SKELETON_BIBLE = (title) => `# 设定集 · ${title}

> 这里是长篇的**唯一真相源**。人物、称呼、时间线、硬设定都写这儿。
> 简报只摘【硬设定】行，其余细节写到需要时再回来读。

## 人物

### 主角
- 姓名：
- 称呼（谁叫他什么，不同人叫法可能不同）：
- 外观：
- 性格：
- 说话方式（口头禅、句长、脏话程度）：
- 【硬设定】

### 配角
（同上）

## 世界观与时间线

## 【硬设定】清单

> 这一栏的东西**任何一章都不许写飞**：称呼、年龄、亲缘关系、谁还不知道真相、禁忌。
> 写法就是标记后面直接写内容，例如：
> \`- 【硬设定】左耳失聪，任何一章不许写成她双侧听力正常\`
> （只有标记后面真写了内容的才会进简报；下面这行空的模板不会。）

- 【硬设定】
`;

const SKELETON_OUTLINE = `# 卷章大纲

> 一章一条，工具按 \`## 第 N 章\` 解析（章号用阿拉伯数字）。
> 每条下面想怎么写都行，建议四行：目标 / 节拍 / 出场 / 钩子。

<!-- 格式示例 —— 这一段在注释里，不会被解析。照它的样子写你自己的章节：

## 第 1 章 章名
目标：这一章要推进什么
节拍：发生哪几件事
出场：谁出现
钩子：章末留什么悬念

至少先把前 5 章写出来再动笔，不然越写越散。
-->

`;

const SKELETON_CONTINUITY = `# 连续性台账

> 每写完一章追加一条：这一章**确立了哪些事实**（谁知道了什么、受没受伤、拿了什么东西、许了什么承诺）。
> 下一章的简报会把最近几章带进去。写得短没关系，关键是"事实"，不是复述情节。

`;

async function cmdNew(a) {
  const dir = path.resolve(String(a.dir || ''));
  if (!a.dir) throw new Error('new 必须给 --dir <项目目录>');
  if (fs.existsSync(path.join(dir, F.state))) throw new Error(`目录里已经有长篇项目了：${dir}`);
  const title = String(a.title || '').trim();
  if (!title) throw new Error('new 必须给 --title "书名"');

  // 文风模板：复制进项目当 style.md —— 项目自包含，之后改模板不影响已建的项目。
  const templateName = String(a.template || '').trim();
  let styleText = '';
  if (templateName) {
    const available = await listTemplates();
    const hit = available.find((t) => t.name === templateName);
    if (!hit) {
      const names = available.map((t) => t.name);
      throw new Error(`没有「${templateName}」这个文风模板。可用的是：${names.length ? names.join('、') : '（templates/ 目录是空的）'}`);
    }
    styleText = (await readIfExists(hit.file)) ?? '';
    if (!styleText.trim()) throw new Error(`模板「${templateName}」是空文件。`);
  }

  await fsp.mkdir(path.join(dir, F.chapters), { recursive: true });
  const state = {
    schema: SCHEMA,
    title,
    genre: String(a.genre || '').trim(),
    template: templateName || '',
    targetWordsPerChapter: Number(a.target) > 0 ? Number(a.target) : 3000,
    plannedChapters: Number(a.chapters) > 0 ? Number(a.chapters) : 0,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  };
  await writeState(dir, state);
  await writeAtomic(path.join(dir, F.bible), SKELETON_BIBLE(title));
  await writeAtomic(path.join(dir, F.outline), SKELETON_OUTLINE);
  await writeAtomic(path.join(dir, F.continuity), SKELETON_CONTINUITY);
  if (styleText) await writeAtomic(path.join(dir, F.style), styleText);

  return `已建好长篇项目：${dir}\n`
    + `书名：${title}｜每章目标 ${state.targetWordsPerChapter} 字${state.plannedChapters ? '｜计划 ' + state.plannedChapters + ' 章' : ''}`
    + (templateName ? `｜文风模板：${templateName}（已复制成 style.md，每章简报都会带上它）` : '｜文风模板：未选（需要的话用 templates 命令看有哪些）')
    + '\n\n接下来按这个顺序来：\n  1. 填 bible.md（人物与硬设定）\n  2. 填 outline.md（至少前 5 章）\n  3. 取第 1 章简报 → 写 → 保存';
}

async function cmdTemplates() {
  const list = await listTemplates();
  if (!list.length) return `templates 目录是空的：${TEMPLATES_DIR}`;
  const lines = ['可用的文风模板（new 时用 --template <名字> 选）：'];
  for (const t of list) {
    const text = (await readIfExists(t.file)) ?? '';
    const first = text.split('\n').find((l) => /^#\s/.test(l)) || '';
    const title = first.replace(/^#\s*/, '').trim();
    lines.push(`  ${t.name}　${title}`);
  }
  lines.push('');
  lines.push('选了之后会复制成项目里的 style.md，每章简报自动带上（要改直接改那份）。');
  return lines.join('\n');
}

async function cmdBrief(a) {
  const dir = path.resolve(String(a.dir || ''));
  const text = await buildBrief(dir, {
    chapter: a.chapter ? Number(a.chapter) : undefined,
    tailChars: a.tail ? Number(a.tail) : undefined
  });
  return text;
}

async function cmdSave(a) {
  const dir = path.resolve(String(a.dir || ''));
  const state = await readState(dir);
  const n = Number(a.chapter);
  if (!Number.isFinite(n) || n <= 0) throw new Error('save 必须给 --chapter N');
  let text = '';
  if (a.text === true || typeof a.text === 'string') {
    if (typeof a.text === 'string') text = a.text;
  }
  if (!text && typeof a.file === 'string') {
    text = (await readIfExists(path.resolve(a.file))) ?? '';
    if (!text) throw new Error(`读不到正文文件（或它是空的）：${a.file}`);
  }
  if (!text.trim()) throw new Error('save 需要 --file <正文.md>（或 --text "正文"）');

  const outline = parseOutline((await readIfExists(path.join(dir, F.outline))) ?? '');
  const beat = outline.get(n);
  const file = path.join(dir, F.chapters, chapterFileName(n, beat?.title || `第${n}章`));
  await writeAtomic(file, text.trim() + '\n');

  const words = countWords(text);
  if (a.note && typeof a.note === 'string') await appendNote(dir, n, a.note);
  state.lastChapter = n;
  await writeState(dir, state);

  const target = Number(state.targetWordsPerChapter) || 3000;
  const warn = words < target * 0.6 ? `\n⚠️ 只有目标字数的 ${Math.round((words / target) * 100)}% —— 是这一章本来就短，还是写漏了？` : '';
  return `已保存第 ${n} 章：${path.basename(file)}（${words} 字）${a.note ? '，并记了一条连续性台账' : '\n⚠️ 没带 --note，这一章在连续性台账里是空的 —— 下一章的简报会缺这一段。'}\n下一章是第 ${n + 1} 章。${warn}`;
}

async function appendNote(dir, n, text) {
  const file = path.join(dir, F.continuity);
  let body = (await readIfExists(file)) ?? SKELETON_CONTINUITY;
  const marker = `## 第 ${n} 章`;
  if (body.includes(marker)) {
    // 已有该章小节 → 在其小节末尾追加
    const lines = body.split('\n');
    const at = lines.findIndex((l) => l.trim() === marker);
    let end = lines.length;
    for (let i = at + 1; i < lines.length; i++) {
      if (/^##\s/.test(lines[i])) { end = i; break; }
    }
    const insert = `- ${String(text).trim()}`;
    lines.splice(end, 0, insert);
    body = lines.join('\n');
  } else {
    body = body.replace(/\s*$/, '\n') + `\n${marker}\n- ${String(text).trim()}\n`;
  }
  await writeAtomic(file, body);
}

async function cmdNote(a) {
  const dir = path.resolve(String(a.dir || ''));
  await readState(dir);
  const n = Number(a.chapter);
  if (!Number.isFinite(n) || n <= 0) throw new Error('note 必须给 --chapter N');
  const text = String(a.text || '').trim();
  if (!text) throw new Error('note 必须给 --text "..."');
  await appendNote(dir, n, text);
  return `已往连续性台账的第 ${n} 章追加一条。`;
}

async function cmdStatus(a) {
  const dir = path.resolve(String(a.dir || ''));
  const state = await readState(dir);
  const { issues, chapters } = await runCheck(dir);
  const total = chapters.reduce((s, c) => s + c.words, 0);
  const next = chapters.length ? Math.max(...chapters.map((c) => c.n)) + 1 : 1;
  const lines = [];
  lines.push(`《${state.title}》${state.genre ? ' · ' + state.genre : ''}`);
  lines.push(`目录：${dir}`);
  lines.push(`已完成 ${chapters.length} 章｜共 ${total} 字｜下一章：第 ${next} 章｜每章目标 ${state.targetWordsPerChapter} 字${state.plannedChapters ? '｜计划 ' + state.plannedChapters + ' 章' : ''}`);
  if (chapters.length) {
    lines.push('');
    lines.push('最近几章：');
    for (const c of chapters.slice(-6)) lines.push(`  第 ${c.n} 章${c.title ? ' ' + c.title : ''}　${c.words} 字`);
  }
  if (issues.length) {
    lines.push('');
    lines.push('体检发现：');
    for (const i of issues) lines.push('  ⚠️ ' + i);
  } else {
    lines.push('');
    lines.push('体检：没发现问题。');
  }
  return lines.join('\n');
}

async function cmdList(a) {
  const base = path.resolve(String(a.base || path.join(process.cwd(), 'data', 'novels')));
  let names = [];
  try { names = await fsp.readdir(base); } catch { return `目录不存在或读不到：${base}`; }
  const rows = [];
  for (const name of names) {
    const dir = path.join(base, name);
    try {
      const st = await readState(dir);
      const ch = await listChapters(dir);
      rows.push(`  ${name}　《${st.title}》　${ch.length} 章　${ch.reduce((s, c) => s + c.words, 0)} 字`);
    } catch { /* 不是长篇项目，跳过 */ }
  }
  return rows.length ? `${base}\n${rows.join('\n')}` : `${base} 下没有长篇项目。`;
}

async function cmdCheck(a) {
  const dir = path.resolve(String(a.dir || ''));
  const { issues } = await runCheck(dir);
  return issues.length ? issues.map((i) => '⚠️ ' + i).join('\n') : '没发现问题。';
}

const COMMANDS = { new: cmdNew, brief: cmdBrief, save: cmdSave, note: cmdNote, status: cmdStatus, list: cmdList, check: cmdCheck, templates: cmdTemplates };

// ── 可编程 API（QQ Agent 的 index.js 从这里 import，不再走 CLI）──────────────
// 参数形状与 CLI 的 argv 解析结果一致：{ dir, chapter, file, text, note, base, template, ... }
export const api = {
  createProject: cmdNew,
  brief: cmdBrief,
  saveChapter: cmdSave,
  addNote: cmdNote,
  status: cmdStatus,
  listProjects: cmdList,
  check: cmdCheck,
  listTemplates: cmdTemplates
};

async function main() {
  const argv = process.argv.slice(2);
  const cmd = argv[0];
  const fn = COMMANDS[cmd];
  if (!fn) {
    console.log('用法：node novel.mjs <new|brief|save|note|status|list|check|templates> [--dir ...] [选项]');
    console.log('详见文件头部注释。');
    process.exit(cmd ? 2 : 0);
  }
  try {
    const out = await fn(parseArgs(argv.slice(1)));
    if (out) console.log(out);
  } catch (error) {
    console.error('❌ ' + (error?.message ?? error));
    process.exit(1);
  }
}

// 只有被直接执行时才跑 CLI；被 import（QQ Agent 那边的 index.js）时什么都不做。
// ⚠️ 这里必须用 fileURLToPath 再 path.resolve 比对 —— 直接拿 import.meta.url 和
//    process.argv[1] 拼字符串在 Windows 上不可靠（盘符大小写、反斜杠、URL 编码都会差）。
const invokedDirectly = (() => {
  const entry = process.argv[1];
  if (!entry) return false;
  try { return path.resolve(entry) === path.resolve(fileURLToPath(import.meta.url)); }
  catch { return false; }
})();
if (invokedDirectly) main();
