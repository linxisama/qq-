// 写长小说（连载长篇）—— 给小鲸鱼一组"把长篇写下去"的工具。
//
// 【为什么要它】长篇崩掉几乎都不是文笔问题，是连续性：第 12 章写她左臂受伤、
// 第 30 章她双手抱臂；第 40 章已经揭开的事，第 55 章又被当成秘密。写到几十万字
// 靠"记得住"是不可能的，靠的是把设定、大纲、既定事实**落到盘上**，每章开写前取回来。
//
// 【实现放哪】全部逻辑在 ./novel.mjs —— 那是 DSH 侧（long-novel 技能）与这边
// **共用同一份实现**。这里只做三件事：身份闸、路径解析、把结果包成工具返回。
// 两边各写一份的话，迟早出现"一边认的目录结构另一边不认、简报口径还不一样"。
//
// 【它不生成正文】正文由模型写，工具只负责建项目、给简报、存档、记账、体检。

import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { DATA_DIR } from '../../src/config.js';

// ⚠️ 这里**不能**写成静态 `import { api as novel } from './novel.mjs'`。
// 热重载时 plugin-loader 只给入口加时间戳（plugin-loader.js:305 `import(entryUrl + '?t=' + Date.now())`），
// 而**静态子依赖的 URL 不继承父模块的查询串** —— Node 按裸 URL 永久缓存。
// 结果：index.js 换新了、novel.mjs 还是旧的，症状就是"盘上明明有、运行时说
// novel.listTemplates is not a function"。自己带 mtime 版本号动态 import 才躲得开。
const NOVEL_MJS = path.join(path.dirname(fileURLToPath(import.meta.url)), 'novel.mjs');
const NOVEL_STAMP = String(fs.statSync(NOVEL_MJS).mtimeMs);
const { api: novel, readState, listChapters } = await import(
  `${pathToFileURL(NOVEL_MJS).href}?v=${NOVEL_STAMP}`
);

let api = null;

/** 单章正文上限的兜底值（技能设置里可改）。 */
const DEFAULT_MAX_CHAPTER_CHARS = 40000;

// ── 身份闸（与 group-admin / background / archive-clean 同款）───────────────

function ownerIdSet(raw) {
  const parts = Array.isArray(raw) ? raw : String(raw ?? '').split(/[\s,，、;；]+/);
  return new Set(parts.map((v) => String(v ?? '').trim()).filter(Boolean));
}

/** 谁在说话：本会话最近一条**别人**发的消息的发送者。 */
export function latestCaller(ctx) {
  const store = ctx?.store;
  const chatKey = String(ctx?.chatKey ?? '');
  if (!store || typeof store.recent !== 'function' || !chatKey) return { callerId: '', callerName: '' };
  let list = [];
  try { list = store.recent(chatKey, { limit: 6, includeSelf: false }) || []; } catch { list = []; }
  for (let i = list.length - 1; i >= 0; i -= 1) {
    const m = list[i];
    if (m && m.senderId) return { callerId: String(m.senderId), callerName: String(m.senderName || '') };
  }
  return { callerId: '', callerName: '' };
}

/** 是不是主人：本轮触发批优先（群友在主人之后插话时 latestCaller 会认错人），再退回落最近一条。 */
export function isOwner(callerId, cfg) {
  const id = String(callerId ?? '').trim();
  if (!id) return false;
  if (ownerIdSet(cfg?.ownerIds).has(id)) return true;
  try {
    const r = api?.capability?.('message.owner-check', { userId: id });
    if (r && typeof r === 'object' && r.isOwner === true) return true;
  } catch { /* 主人识别插件坏了按非主人处理，不放行 */ }
  return false;
}

function ownerTriggers(ctx, cfg) {
  const list = Array.isArray(ctx?.session?.trigger) ? ctx.session.trigger : [];
  const out = [];
  for (const e of list) {
    if (!e || e.self) continue;
    const id = String(e.senderId || '');
    if (id && isOwner(id, cfg)) out.push(e);
  }
  return out;
}

function guard(ctx, cfg) {
  const fromBatch = ownerTriggers(ctx, cfg);
  if (fromBatch.length) {
    const last = fromBatch[fromBatch.length - 1];
    return { callerId: String(last.senderId || ''), callerName: String(last.senderName || '') };
  }
  const { callerId, callerName } = latestCaller(ctx);
  if (!callerId) {
    return { error: '拒绝：没能确认是谁在说话（本会话没查到最近的消息记录），身份不明一律不操作。' };
  }
  if (!isOwner(callerId, cfg) && cfg?.allowNonOwner !== true) {
    return {
      error: '拒绝：这次调用不是主人发起的。按你的安全规则回绝，对群友的说辞就用这句话：'
        + '「这个只有主人能用」。不要重试，也不要解释工具的存在。'
    };
  }
  return { callerId, callerName };
}

// ── 路径解析 ────────────────────────────────────────────────────────────────

export function novelsRoot(cfg) {
  const raw = String(cfg?.novelsDir ?? '').trim();
  return raw ? path.resolve(raw) : path.join(DATA_DIR, 'novels');
}

/**
 * 把工具参数里的 `project` 解析成绝对目录。
 *
 * 规则：
 *   · 绝对路径（D:\小说\潮汐纪）→ 按路径走，受 allowAbsolutePath 开关约束；
 *   · 相对写法（潮汐纪 / 子目录/潮汐纪）→ **相对长篇根目录**解析，且必须仍在根目录内。
 *
 * ⚠️ 相对写法**绝不能**用裸的 path.resolve(s)：那是相对**进程当前目录**解析的，
 *    而 cwd 是任意值 —— 实测从 E:\Program Files 起跑时传 '../逃出去'，
 *    项目就被建到了 E:\Program Files\逃出去，跑出根目录之外。
 */
export function resolveProject(cfg, raw) {
  const s = String(raw ?? '').trim();
  if (!s) throw new Error('没说清是哪个项目（project 传项目名，或绝对路径）。');
  if (/[\x00-\x1f]/.test(s)) throw new Error('项目路径含控制字符。');

  const root = novelsRoot(cfg);
  if (path.isAbsolute(s) || /^[A-Za-z]:/.test(s)) {
    if (cfg?.allowAbsolutePath === false) {
      throw new Error('技能设置里关掉了「允许指定项目绝对路径」，只能用项目名。');
    }
    return path.resolve(s);
  }

  const dir = path.resolve(root, s);
  const rel = path.relative(path.resolve(root), dir);
  if (rel.startsWith('..') || path.isAbsolute(rel)) {
    throw new Error(`项目路径跑到长篇根目录外面了：${dir}。想建到别处就传绝对路径（需开启「允许指定项目绝对路径」）。`);
  }
  return dir;
}

/** 简短进度行，给几个工具复用。 */
async function progressLine(dir) {
  try {
    const st = await readState(dir);
    const ch = await listChapters(dir);
    const next = ch.length ? Math.max(...ch.map((c) => c.n)) + 1 : 1;
    const total = ch.reduce((s, c) => s + c.words, 0);
    return `《${st.title}》已完成 ${ch.length} 章／${total} 字，下一章第 ${next} 章`;
  } catch {
    return '';
  }
}

// ── 工具 ────────────────────────────────────────────────────────────────────

export function setup(skillApi) {
  api = skillApi;
  const cfgOf = () => skillApi?.config?.() || {};
  const deny = (msg) => ({ content: msg, isError: true });

  skillApi.registerTool({
    id: 'novel_create',
    name: '新建长篇项目',
    description: '开一部长篇：建目录骨架（设定集 / 卷章大纲 / 连续性台账 / chapters），并记住书名与每章目标字数。'
      + '可选给一个**文风模板**（template），它会被复制成项目里的 style.md，之后**每章简报都会带上**，'
      + '文风就不会写着写着飘掉。不确定有哪些模板就先别填，用 novel_status（不填 project）看一遍。'
      + '新建之后先填 bible.md（人物与【硬设定】）和 outline.md（至少前 5 章），再用 novel_brief 取第 1 章简报开写。'
      + '**同一目录不会重复建**（已有项目会被拒）。**只有主人能用。**',
    category: 'system',
    icon: '📖',
    parameters: {
      type: 'object',
      properties: {
        project: { type: 'string', description: '项目名（会在长篇根目录下建一个同名目录），也可以给绝对路径' },
        title: { type: 'string', description: '书名' },
        genre: { type: 'string', description: '可选，题材，如「科幻/悬疑」' },
        template: { type: 'string', description: '可选，文风模板名（如「网文」「小黄文」）。不填就不带文风模板。' },
        targetWords: { type: 'number', description: '可选，每章目标字数，默认 3000' },
        plannedChapters: { type: 'number', description: '可选，计划写多少章' }
      },
      required: ['project', 'title']
    },
    async execute(ctx, args) {
      const g = guard(ctx, cfgOf());
      if (g.error) return deny(g.error);
      let dir;
      try { dir = resolveProject(cfgOf(), args?.project); }
      catch (error) { return deny(`拒绝：${error?.message ?? error}`); }
      try {
        const out = await novel.createProject({
          dir,
          title: String(args?.title ?? '').trim(),
          genre: String(args?.genre ?? '').trim(),
          template: String(args?.template ?? '').trim(),
          target: Number(args?.targetWords) || 0,
          chapters: Number(args?.plannedChapters) || 0
        });
        return { content: out, isError: false };
      } catch (error) {
        return deny(`新建失败：${error?.message ?? error}`);
      }
    }
  });

  skillApi.registerTool({
    id: 'novel_brief',
    name: '取下一章的写作简报',
    description: '拿到「这一章该写什么」的完整简报：本章大纲 + **上一章的结尾原文** + 最近几章的连续性台账 + '
      + '设定集里标了【硬设定】的行 + 目标字数与交稿要求。**动笔前必须先调它** —— 长篇能不能接得上全靠这一段。'
      + '默认取下一章（按已有章号顺延），也可以指定 chapter。**只有主人能用。**',
    category: 'system',
    icon: '📋',
    parameters: {
      type: 'object',
      properties: {
        project: { type: 'string', description: '项目名或绝对路径' },
        chapter: { type: 'number', description: '可选，要写第几章；不填 = 下一章' },
        tailChars: { type: 'number', description: '可选，上一章结尾带多少字进来，默认 1200' }
      },
      required: ['project']
    },
    async execute(ctx, args) {
      const g = guard(ctx, cfgOf());
      if (g.error) return deny(g.error);
      let dir;
      try { dir = resolveProject(cfgOf(), args?.project); }
      catch (error) { return deny(`拒绝：${error?.message ?? error}`); }
      try {
        const out = await novel.brief({
          dir,
          chapter: Number(args?.chapter) || 0,
          tail: Number(args?.tailChars) || 0
        });
        return { content: out, isError: false };
      } catch (error) {
        return deny(`取简报失败：${error?.message ?? error}`);
      }
    }
  });

  skillApi.registerTool({
    id: 'novel_save',
    name: '保存写好的这一章',
    description: '把刚写完的这一章正文存进项目（自动计字数、按章号命名、更新进度）。'
      + '**一定要带 note**：用一两句写清「这一章确立了哪些事实」（谁知道了什么、受没受伤、拿了什么、许了什么承诺）——'
      + '那是下一章简报的连续性来源，漏了下一章就容易写矛盾。'
      + '⚠️ 正文要作为 text 参数**完整**传进来，不要只传摘要或省略号。**只有主人能用。**',
    category: 'system',
    icon: '💾',
    parameters: {
      type: 'object',
      properties: {
        project: { type: 'string', description: '项目名或绝对路径' },
        chapter: { type: 'number', description: '这是第几章' },
        text: { type: 'string', description: '这一章的完整正文' },
        note: { type: 'string', description: '本章确立的事实（连续性台账用，强烈建议填）' }
      },
      required: ['project', 'chapter', 'text']
    },
    async execute(ctx, args) {
      const cfg = cfgOf();
      const g = guard(ctx, cfg);
      if (g.error) return deny(g.error);
      let dir;
      try { dir = resolveProject(cfg, args?.project); }
      catch (error) { return deny(`拒绝：${error?.message ?? error}`); }

      const text = typeof args?.text === 'string' ? args.text : '';
      if (!text.trim()) return deny('拒绝：text 是空的 —— 正文没传进来。');
      const cap = Number(cfg?.maxChapterChars) > 0 ? Number(cfg.maxChapterChars) : DEFAULT_MAX_CHAPTER_CHARS;
      if (text.length > cap) {
        return deny(`拒绝：正文 ${text.length} 字符，超过单章上限 ${cap}。分两次存：先存前半，再用 novel_note 补记本章事实。`);
      }
      try {
        const out = await novel.saveChapter({
          dir,
          chapter: Number(args?.chapter),
          text,
          note: typeof args?.note === 'string' ? args.note : ''
        });
        return { content: out, isError: false };
      } catch (error) {
        return deny(`保存失败：${error?.message ?? error}`);
      }
    }
  });

  skillApi.registerTool({
    id: 'novel_note',
    name: '补记一章的连续性台账',
    description: '往连续性台账里追加一条「第 N 章确立的事实」。存章时忘了给 note、或者事后想起还漏了一条（比如'
      + '「那把刀在第 7 章就丢了」），用它补上 —— 下一章的简报会把最近几章带进去。**只有主人能用。**',
    category: 'system',
    icon: '📝',
    parameters: {
      type: 'object',
      properties: {
        project: { type: 'string', description: '项目名或绝对路径' },
        chapter: { type: 'number', description: '这条事实属于第几章' },
        text: { type: 'string', description: '要记的事实，一两句就够' }
      },
      required: ['project', 'chapter', 'text']
    },
    async execute(ctx, args) {
      const g = guard(ctx, cfgOf());
      if (g.error) return deny(g.error);
      let dir;
      try { dir = resolveProject(cfgOf(), args?.project); }
      catch (error) { return deny(`拒绝：${error?.message ?? error}`); }
      try {
        const out = await novel.addNote({ dir, chapter: Number(args?.chapter), text: String(args?.text ?? '') });
        return { content: out, isError: false };
      } catch (error) {
        return deny(`记账失败：${error?.message ?? error}`);
      }
    }
  });

  skillApi.registerTool({
    id: 'novel_status',
    name: '看长篇进度',
    description: '不填 project = 列出所有长篇项目。填了 project = 报这个项目的进度（已完成几章、共多少字、下一章是第几章），'
      + '并顺手做一次**体检**：章号有没有断档、哪几章没写大纲、哪几章没记连续性台账、哪几章明显偏短。'
      + '接着写之前、或者觉得"哪里不对劲"时用它。**只有主人能用。**',
    category: 'system',
    icon: '📊',
    parameters: {
      type: 'object',
      properties: {
        project: { type: 'string', description: '可选，项目名或绝对路径；不填就列出全部项目' }
      }
    },
    async execute(ctx, args) {
      const cfg = cfgOf();
      const g = guard(ctx, cfg);
      if (g.error) return deny(g.error);
      try {
        if (!String(args?.project ?? '').trim()) {
          const list = await novel.listProjects({ base: novelsRoot(cfg) });
          const tpl = await novel.listTemplates({});
          return { content: `${list}\n\n${tpl}`, isError: false };
        }
        const dir = resolveProject(cfg, args.project);
        const out = await novel.status({ dir });
        return { content: out, isError: false };
      } catch (error) {
        return deny(`读进度失败：${error?.message ?? error}`);
      }
    }
  });

  skillApi.log('写长小说已加载（5 个工具；项目根目录 %s）', novelsRoot(cfgOf()));
}
