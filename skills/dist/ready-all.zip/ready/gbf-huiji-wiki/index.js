// 碧蓝幻想 · 灰机中文维基百科 —— LLM 型技能（skills/）
//
// 做什么：群友 @机器人 问 GBF（グラブル）的问题时，去 https://gbf.huijiwiki.com
// 查中文维基，回答「活动开始/结束时间」「某角色有几个驱散、几个弱体、什么效果」这类问题；
// 查不到就明确回答「Wiki 里没找到」，不编造数值。
// 另外会先查技能目录下 answers.txt（主人自己维护的问答），命中就直接用本地答案。
//
// ──────────────────────────────────────────────────────────────────────────
// ⚠️ 这一节是本技能存在的**唯一原因**，改动前务必读完（本机实测 2026-10-07）
// ──────────────────────────────────────────────────────────────────────────
// gbf.huijiwiki.com 全站在 Cloudflare「交互式人机验证」后面。实测结论：
//
//   请求方式                              结果
//   ────────────────────────────────────  ─────────────────────────────
//   Node/undici fetch（含 api.fetch）     403 + 验证页
//   Node 原生 https（safe-fetch 走的）    403 + 验证页
//   Electron / headless Chrome            过不了交互式验证
//   公共 CORS 代理 / r.jina.ai            不可用
//   ★ 系统 curl.exe + 浏览器 Sec-Fetch 头  200 ✅
//
// 而且 curl 能过**不是**因为 User-Agent，也不是因为 Accept：
// 实测单独加 UA / Accept / Accept-Language / Accept-Encoding / Sec-Fetch 任意一项都还是 403，
// 必须凑齐「浏览器 UA + Accept + Accept-Language + Upgrade-Insecure-Requests + 四个
// Sec-Fetch-*（Dest/Mode/Site/User）」这一整套才会 200 —— 也就是说 Cloudflare 认的是
// 「像一次真正的浏览器顶层导航」这个**整体特征**，Node 的 TLS 指纹 + 缺头都会被判成机器人。
//
// 所以：抓取一律走 curl.exe 子进程（BROWSER_HEADERS 一个字都不能删），不要"顺手优化"
// 成 api.fetch —— 那样会静默退回 403 验证页，表现为"查什么都说没找到"。
// 同理，curl 不能走 api.fetch 的白名单，所以本技能用 node:child_process 而不是 api.fetch。
//
// 抓取成功后按 MediaWiki API（action=parse）拿渲染后的 HTML，在本地抽成纯文本 +
// 表格行，再交给模型。HTML 转文本/表格在本地做，省 token 也避免把 1MB 页面塞进上下文。

import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const DEFAULT_BASE = 'https://gbf.huijiwiki.com';
const skillDir = () => path.dirname(fileURLToPath(import.meta.url));

let cfg = () => ({});

// ══════════════════════════════════════════════════════════════════════
//  一、配置
// ══════════════════════════════════════════════════════════════════════
const num = (v, def, lo, hi) => {
  const n = Number(v);
  if (!Number.isFinite(n)) return def;
  return Math.max(lo, Math.min(hi, n));
};

function settings() {
  const c = cfg() || {};
  return {
    base: String(c.wikiBase || DEFAULT_BASE).trim().replace(/\/+$/, '') || DEFAULT_BASE,
    maxChars: num(c.maxAnswerChars, 20000, 1500, 30000),
    maxHits: num(c.maxSearchHits, 6, 1, 15),
    cacheMinutes: num(c.cacheMinutes, 720, 0, 10080),
    timeoutMs: num(c.timeoutMs, 30000, 5000, 120000),
    curlPath: String(c.curlPath || '').trim(),
    localFile: String(c.localAnswerFile || 'answers.txt').trim() || 'answers.txt',
    localFirst: c.localFirst !== false,
  };
}

/** 数据目录：优先 <QQ Agent 数据目录>/gbf-huiji-wiki，其次技能目录/.cache */
function dataDir() {
  const base = process.env.QQ_AGENT_DATA_DIR
    || path.resolve(skillDir(), '..', '..', '..', '..', 'data');
  try {
    const d = path.join(base, 'gbf-huiji-wiki');
    fs.mkdirSync(d, { recursive: true });
    return d;
  } catch {
    const d = path.join(skillDir(), '.cache');
    try { fs.mkdirSync(d, { recursive: true }); } catch { /* 只读就放弃缓存 */ }
    return d;
  }
}

const cachePath = () => path.join(dataDir(), 'cache.json');
let cache = null;

function loadCache() {
  if (cache) return cache;
  try {
    const raw = JSON.parse(fs.readFileSync(cachePath(), 'utf8'));
    cache = (raw && typeof raw === 'object' && !Array.isArray(raw)) ? raw : {};
  } catch { cache = {}; }
  return cache;
}

function saveCache() {
  try {
    const p = cachePath();
    fs.writeFileSync(`${p}.tmp`, JSON.stringify(cache), 'utf8');
    fs.renameSync(`${p}.tmp`, p);   // 原子写：断电不会留下半截 JSON 毁掉整个缓存
  } catch { /* 写不进去不影响本次查询 */ }
}

function cacheGet(key, ttlMinutes) {
  const c = loadCache()[key];
  if (!c) return null;
  if (ttlMinutes > 0 && Date.now() - c.at > ttlMinutes * 60000) return null;
  return c.value;
}

function cacheSet(key, value) {
  const c = loadCache();
  c[key] = { at: Date.now(), value };
  // 顺手清掉过期很久的条目，避免缓存无限膨胀
  const cutoff = Date.now() - 30 * 86400000;
  for (const [k, v] of Object.entries(c)) {
    if (v && typeof v.at === 'number' && v.at < cutoff) delete c[k];
  }
  saveCache();
}

// ══════════════════════════════════════════════════════════════════════
//  二、curl.exe（唯一能抓通本站的方式，见文件头）
// ══════════════════════════════════════════════════════════════════════
const BROWSER_UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36';

/** 少一个都可能被 Cloudflare 判成机器人 —— 见文件头实测表。 */
const BROWSER_HEADERS = [
  `User-Agent: ${BROWSER_UA}`,
  'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
  'Accept-Language: zh-CN,zh;q=0.9,en;q=0.8',
  'Upgrade-Insecure-Requests: 1',
  'Sec-Fetch-Dest: document',
  'Sec-Fetch-Mode: navigate',
  'Sec-Fetch-Site: none',
  'Sec-Fetch-User: ?1',
];

function findCurl(explicit) {
  const cands = [
    explicit,
    process.env.QQA_CURL,
    path.join(process.env.SystemRoot || 'C:\\Windows', 'System32', 'curl.exe'),
    'curl.exe',
  ].filter(Boolean);
  for (const c of cands) {
    try {
      if (c === 'curl.exe' || fs.existsSync(c)) return c;
    } catch { /* 忽略 */ }
  }
  return 'curl.exe';
}

/** 用 curl.exe 抓一个 URL。返回 { ok, status, body }。 */
function curlGet(url, {
  timeoutMs = 30000, curlPath = '', cookie = '', referer = '', acceptLanguage = '',
} = {}) {
  return new Promise((resolve) => {
    const out = path.join(os.tmpdir(), `qqa-gbf-${process.pid}-${Date.now()}-${Math.random().toString(36).slice(2)}.txt`);
    const args = [
      '-s', '-L', '--compressed',
      '--max-time', String(Math.max(5, Math.ceil(timeoutMs / 1000))),
      '-o', out, '-w', '%{http_code}',
    ];
    for (const h of BROWSER_HEADERS) {
      // 允许按站点覆盖 Accept-Language（NGA 走它自己的）
      if (acceptLanguage && /^accept-language:/i.test(h)) continue;
      args.push('-H', h);
    }
    if (acceptLanguage) args.push('-H', `Accept-Language: ${acceptLanguage}`);
    if (cookie) args.push('-H', `Cookie: ${cookie}`);
    if (referer) args.push('-H', `Referer: ${referer}`);
    args.push(url);

    let status = '';
    let stderr = '';
    let child;
    try {
      child = spawn(findCurl(curlPath), args, { windowsHide: true });
    } catch (error) {
      return resolve({ ok: false, status: 0, body: '', bodyBytes: null, error: `无法启动 curl：${error?.message ?? error}` });
    }
    const timer = setTimeout(() => { try { child.kill(); } catch { /* 忽略 */ } }, timeoutMs + 5000);

    child.stdout?.on('data', (d) => { status += d.toString(); });
    child.stderr?.on('data', (d) => { stderr += d.toString(); });
    child.on('error', (error) => {
      clearTimeout(timer);
      resolve({ ok: false, status: 0, body: '', bodyBytes: null, error: `curl 启动失败：${error?.message ?? error}` });
    });
    child.on('close', () => {
      clearTimeout(timer);
      let body = '';
      let bodyBytes = null;
      // 原始字节也要留着：NGA 是 GB18030，按 utf8 读会变乱码
      try { bodyBytes = fs.readFileSync(out); } catch { /* 可能没产出文件 */ }
      try { body = bodyBytes ? bodyBytes.toString('utf8') : ''; } catch { /* 忽略 */ }
      try { fs.unlinkSync(out); } catch { /* 忽略 */ }
      const code = Number(String(status).trim()) || 0;
      resolve({
        ok: code >= 200 && code < 300,
        status: code,
        body,
        bodyBytes,
        error: code === 0 ? (stderr.trim().slice(0, 200) || 'curl 没有返回 HTTP 状态（网络不通或超时）') : '',
      });
    });
  });
}

const isChallenge = (body) => /请稍候|正在进行安全验证|人机验证|安全验证|just a moment|cf_chl|challenge-platform/i.test(String(body || '').slice(0, 8000));

const API = (base, params) => `${base}/api.php?${new URLSearchParams({ format: 'json', formatversion: '2', ...params })}`;

/** 调 MediaWiki API 并解析 JSON。带缓存。 */
async function apiGet(base, params, { s, cacheKey, ttl } = {}) {
  const url = API(base, params);
  const key = cacheKey ? `api:${cacheKey}` : `api:${url}`;
  const minutes = ttl === undefined ? s.cacheMinutes : ttl;
  const hit = cacheGet(key, minutes);
  if (hit) return { ...hit, cached: true };

  const r = await curlGet(url, { timeoutMs: s.timeoutMs, curlPath: s.curlPath });
  if (!r.ok || isChallenge(r.body)) {
    const reason = isChallenge(r.body)
      ? '被 Cloudflare 人机验证挡住（HTTP ' + r.status + '）'
      : (r.error || `HTTP ${r.status}`);
    const res = { ok: false, reason, url };
    return res;   // 失败不写缓存，下次还有机会
  }
  let data = null;
  try { data = JSON.parse(r.body); } catch { return { ok: false, reason: '维基返回的不是合法 JSON（接口可能变了）', url }; }
  const res = { ok: true, data, url };
  cacheSet(key, res);
  return res;
}

// ══════════════════════════════════════════════════════════════════════
//  三、HTML → 文本 / 表格
// ══════════════════════════════════════════════════════════════════════
function decodeEntities(s) {
  return String(s ?? '')
    .replace(/&nbsp;/gi, ' ')
    .replace(/&amp;/gi, '&')
    .replace(/&lt;/gi, '<')
    .replace(/&gt;/gi, '>')
    .replace(/&quot;/gi, '"')
    .replace(/&#0?39;|&apos;/gi, "'")
    .replace(/&#(\d+);/g, (_, d) => { try { return String.fromCodePoint(Number(d)); } catch { return ' '; } })
    .replace(/&#x([0-9a-f]+);/gi, (_, h) => { try { return String.fromCodePoint(parseInt(h, 16)); } catch { return ' '; } });
}

function stripNoise(html) {
  return String(html || '')
    .replace(/<!--[\s\S]*?-->/g, ' ')
    .replace(/<script[\s\S]*?<\/script>/gi, ' ')
    .replace(/<style[\s\S]*?<\/style>/gi, ' ')
    .replace(/<noscript[\s\S]*?<\/noscript>/gi, ' ')
    // 灰机页面上的编辑器按钮/工具栏/目录，对答题没用
    .replace(/<div[^>]*class="[^"]*(?:mw-editsection|toc|navbox|noprint|mw-jump|printfooter|catlinks|tooltips-content)[^"]*"[^>]*>[\s\S]*?<\/div>/gi, ' ');
}

function htmlToText(html) {
  return decodeEntities(
    stripNoise(html)
      .replace(/<br\s*\/?>/gi, '\n')
      .replace(/<\/(p|div|li|tr|h[1-6]|section|article|dd|dt)>/gi, '\n')
      .replace(/<[^>]+>/g, ' ')
  )
    .replace(/[ \t\u00a0]+/g, ' ')
    .replace(/ *\n */g, '\n')
    .replace(/\n{3,}/g, '\n\n')
    .trim();
}

// ── 表格解析 ──────────────────────────────────────────────────────────
// ⚠️ 不能用 /<table[^>]*>([\s\S]*?)<\/table>/ 这种正则去切表格：
//    灰机的资料页（如「驱散」总表）**表格里嵌表格**，非贪婪正则会在内层 </table>
//    就截断，把「287 条 / 角色技能 266 行」的页面砍成 62 行 —— 而且是静默砍，
//    表现为"数量数不对"。这里改成按标签深度显式配对，嵌套表格整体当一个单元格。
const TABLE_TAG_RE = /<table\b[^>]*>|<\/table\s*>/gi;

/**
 * 顶层表格区间。做法：按标签顺序扫一遍，用 depth 记嵌套层数，
 * depth 从 0 回到 0 的那一对就是一个顶层表格（嵌套表格整体含在里面）。
 */
function topLevelTables(html) {
  const src = String(html || '');
  const out = [];
  let depth = 0;
  let start = -1;
  TABLE_TAG_RE.lastIndex = 0;
  let m;
  while ((m = TABLE_TAG_RE.exec(src)) !== null) {
    const isClose = m[0].charAt(1) === '/';
    if (isClose) {
      depth--;
      if (depth <= 0) {
        if (start >= 0) out.push({ index: start, end: m.index + m[0].length, html: src.slice(start, m.index + m[0].length) });
        start = -1;
        depth = 0;
      }
    } else {
      if (depth === 0) start = m.index;
      depth++;
    }
  }
  if (start >= 0) out.push({ index: start, end: src.length, html: src.slice(start) });   // HTML 被截断时兜底
  return out;
}

const TR_RE = /<tr\b[^>]*>([\s\S]*?)<\/tr\s*>/gi;
const CELL_RE = /<(th|td)\b[^>]*>([\s\S]*?)<\/\1\s*>/gi;

/** 表格 → 每行一个字符串数组（单元格已转文本，嵌套表格整体当一个单元格）。 */
function tableRows(tableHtml) {
  const rows = [];
  for (const tr of String(tableHtml).matchAll(TR_RE)) {
    const cells = [...tr[1].matchAll(CELL_RE)].map((c) => {
      // 单元格里的嵌套表格整体当一个单元格：先把嵌套表格替换成它的文本，再统一清洗
      let inner = c[2];
      for (const t of topLevelTables(inner)) inner = inner.replace(t.html, ` ${tableToText(t.html)} `);
      return htmlToText(inner).replace(/\n+/g, ' ').trim();
    });
    if (cells.some((c) => c)) rows.push(cells);
  }
  return rows;
}

/** 表格 → 一行一条，列用「｜」分隔（技能效果/数量这样最好读）。 */
function tableToText(tableHtml) {
  return tableRows(tableHtml).map((cells) => cells.join(' ｜ ')).join('\n');
}

/** 页面里包含某个词的表格行（用于「某角色有几个驱散」这种指名查询）。 */
function rowsMentioning(html, term, { max = 40 } = {}) {
  const t = String(term || '').trim();
  if (t.length < 2) return [];
  const hits = [];
  for (const sec of tableSections(String(html))) {
    for (const cells of sec.rows) {
      const line = cells.join(' ｜ ');
      if (!line.includes(t)) continue;
      hits.push(line.replace(/\s+/g, ' ').trim());
      if (hits.length >= max) return hits;
    }
  }
  return hits;
}

// 分类型表格：灰机的资料页（「驱散」「弱体」这类）是一个大 tabber，
// 每个 tab 一类（角色技能 / 召唤石 / 武器 / 主角技能），且每类前面有一行「◆总计：N」。
// 必须把「分类 + 总数 + 该分类的行」绑在一起，否则模型会：
//   ① 把 287 当成"所有类型加起来"；② 因为主角技能排在最前面而数错角色的数量。
const CATEGORY_NAMES = {
  '主角技能': '主角（职业）技能',
  '角色技能': '角色技能',
  '召唤石': '召唤石',
  '武器': '武器',
  'char': '角色技能',
  'summon': '召唤石',
  'weapon': '武器',
};

/** 把页面表格切成带分类标签的段落。 */
function tableSections(html) {
  const src = String(html || '');
  const out = [];
  for (const t of topLevelTables(src)) {
    const before = src.slice(Math.max(0, t.index - 1200), t.index);
    const tag = before.lastIndexOf('data-catg="');
    let label = '';
    if (tag >= 0) {
      const v = before.slice(tag + 'data-catg="'.length).split('"')[0];
      label = CATEGORY_NAMES[v] || v;
    }
    const tm = before.match(/总计[：:]\s*(\d+)(?![\s\S]*总计[：:])/);
    out.push({ index: t.index, label, total: tm ? Number(tm[1]) : null, rows: tableRows(t.html) });
  }
  // 同一分类可能被切成好几张表（嵌套关系复杂时），把相邻同名分类合并
  const merged = [];
  for (const s of out) {
    const last = merged[merged.length - 1];
    if (last && last.label && last.label === s.label) {
      last.rows.push(...s.rows);
      if (last.total === null) last.total = s.total;
    } else {
      merged.push({ ...s, rows: [...s.rows] });
    }
  }
  return merged.filter((s) => s.rows.length);
}

/**
 * 把分类表格按预算拼成文本。
 * 预算不够时**优先保留与 focus 相关的行**，其余截断并明确标注 —— 静默截断会让模型
 * 以为"就这么几条"，进而把「几个驱散」数错。
 */
function renderSections(secs, { budget, focus = '' } = {}) {
  if (!secs.length) return { text: '', truncated: false };
  const per = Math.max(400, Math.floor(budget / secs.length));
  const f = String(focus || '').trim();
  const parts = [];
  let truncated = false;

  for (const s of secs) {
    const head = s.label
      ? `【${s.label}】${s.total === null ? `共 ${s.rows.length} 条` : `共 ${s.total} 条（维基标注）`}`
      : '';
    const hot = f.length >= 2 ? s.rows.filter((r) => r.includes(f)) : [];
    const first = s.rows[0] || '';
    const header = /来源|技能名|描述/.test(first) ? first : '';
    const body = s.rows.filter((r) => r !== header);
    const chosen = hot.length ? [...hot] : body;

    let text = chosen.join('\n');
    if (text.length > per) { text = text.slice(0, per); truncated = true; }
    const note = hot.length
      ? `（只列与「${f}」相关的 ${hot.length} 行；本类共 ${s.rows.length} 行）`
      : (text.length < body.join('\n').length
        ? `（⚠️ 本类共 ${s.rows.length} 行，这里只放了前一部分：**总数以「共 ${s.total ?? s.rows.length} 条」为准**，缺的行可用 title+query 指定名称再查）`
        : '');
    parts.push([head, header, text, note].filter(Boolean).join('\n'));
  }
  return { text: parts.join('\n\n'), truncated };
}

/** 抽条目正文：按 h2/h3 切块，表格按分类转文本；优先保留技能/效果/时间这类块。 */
function extractBody(html, { maxChars = 20000, focus = '' } = {}) {
  const h = stripNoise(html);
  const heads = [...h.matchAll(/<h([234])[^>]*>([\s\S]*?)<\/h\1>/gi)];

  // ⚠️ 分类标签（data-catg）和「◆总计：N」都写在**表格前面**，而表格往往紧跟在
  //    标题之后 —— 如果先按标题把 HTML 切片、再在切片里找标签，那个前缀就落在
  //    切片外面了（踩过：标签全丢，287 条消失，模型数错数量）。
  //    所以这里**从整页切**，切片里自带前缀。
  const marks = [...heads.map((m) => ({ pos: m.index, head: m })), { pos: h.length, head: null }];

  const chunks = [];
  for (let i = 0; i < marks.length - 1; i++) {
    const m = marks[i];
    const title = htmlToText(m.head[2]).replace(/\s+/g, ' ').trim();
    if (!title || /^目次$|^目录$/.test(title)) continue;
    const start = m.pos;
    const end = marks[i + 1].pos;
    const seg = h.slice(start, end);
    const tops = topLevelTables(seg);
    const prefix = h.slice(Math.max(0, start - 1200), start);
    const secs = tableSections(prefix + seg);
    // 正文取"去掉表格后的散段"：表格已经单独列了，避免同一份数据出现两遍。
    // 嵌套表格也要一并挖掉，否则内层 </table> 后面的碎片会留在正文里。
    let noTables = seg;
    for (const t of tops) noTables = noTables.replace(t.html, ' ');
    const plain = htmlToText(noTables).replace(title, '').trim();
    if (secs.length || plain.length > 40) chunks.push({ title, secs, text: plain });
  }

  // 答题相关的块优先，其余按原顺序补足
  const hot = /驱散|弱体|减益|技能|奥义|被动|效果|使用间隔|冷却|时间|日程|开放|开始|结束|举办|掉落|属性|上限|倍率|解放|觉醒/i;
  const picked = [...chunks.filter((c) => hot.test(c.title)), ...chunks.filter((c) => !hot.test(c.title))];
  const withTables = picked.filter((c) => c.secs.length);
  // 有没有带分类的表格页（「驱散」这类总表）——有就把大部分预算给表格
  const tableBudget = withTables.length ? maxChars : 0;

  const out = [];
  let len = 0;
  for (const c of picked) {
    if (len >= maxChars) break;
    const parts = [];
    if (c.secs.length) {
      const remaining = Math.max(1500, tableBudget - len);
      const r = renderSections(c.secs, { budget: remaining, focus });
      if (r.text) parts.push(r.text);
    }
    if (c.text) parts.push(c.text.slice(0, Math.min(2000, Math.max(0, maxChars - len))));
    const body = parts.join('\n').trim();
    if (!body) continue;
    out.push(`## ${c.title}\n${body}`);
    len += c.title.length + body.length;
  }
  let text = out.join('\n\n').trim();
  const hasSections = withTables.length > 0;

  // 页面没有"带分类的表格"时（总览/时间表这类，如「活动/2026」没有小标题），
  // 退回「表格行 + 全文」——否则只剩导航文字。
  // ⚠️ 有分类表格时**绝不能**走这条路：那会把辛苦整理好的分类+总数整段顶掉，
  //    表现为"287 条"消失、模型数错数量（踩过）。
  if (!hasSections && text.length < 3000) {
    const tops = topLevelTables(h);
    let noTables = h;
    for (const t of tops) noTables = noTables.replace(t.html, ' ');
    const full = htmlToText(noTables);
    const tableText = tops.map((t) => tableToText(t.html)).filter(Boolean).join('\n');
    const anchor = chunks.find((c) => c.title && c.title.length >= 3)?.title;
    let cut = full;
    if (anchor) {
      const idx = full.indexOf(anchor);
      if (idx > 0) cut = full.slice(idx);
    }
    const combined = [tableText, cut].filter(Boolean).join('\n');
    // 表格行优先：它们是这个页面的实际内容
    text = combined.length > text.length ? combined : text;
  }
  return text.slice(0, maxChars);
}

/** 数一数文本里提到某个效果几次（粗略但实用） */
function countMentions(text, word) {
  return (String(text).match(new RegExp(word, 'g')) || []).length;
}

/** 从条目正文里给出「与问题相关的」零散行，供模型抓重点 */
function gatherEvidence(html, text, question) {
  const lines = [];
  const q = String(question || '');
  for (const w of ['驱散', '弱体', '减益', '净化', '时间', '开始', '结束']) {
    if (!q.includes(w)) continue;
    const n = countMentions(text, w);
    if (n) lines.push(`· 正文里出现「${w}」${n} 次`);
  }
  const rows = rowsMentioning(html, q.match(/[\u4e00-\u9fa5A-Za-z]{2,8}/)?.[0] || '', { max: 15 });
  return { lines, rows };
}

// ══════════════════════════════════════════════════════════════════════
//  三·五、NGA（bbs.nga.cn）—— 需要登录态的论坛来源
// ══════════════════════════════════════════════════════════════════════
// 为什么必须带 Cookie（本机实测）：
//   · NGA 整站在权限门禁后面：不带 Cookie 访问 thread.php / read.php 一律
//     403「访客不能直接访问 (ERROR:15)」；连它自己发的访客 cookie
//     （ngaPassportUid=guest****）也一样被挡。
//   · 带上主人账号的 ngaPassportUid/ngaPassportCid 之后：200，正常出内容。
//   所以这一块**只有配了 ngaCookie 才可用**，没配就如实说读不了。
//
// 另外两点和灰机不同，写在这里免得后人踩：
//   ① NGA 是 GB18030 编码的老 PHPWind 页面（不是 UTF-8），curl 抓回来必须按
//      charset 解码，否则全是乱码。
//   ② NGA 的 HTML 属性用**单引号**（class='postcontent'），不是双引号 ——
//      按双引号写正则一个都匹配不到。
//   ③ 帖子正文是 UBB 码（[b][url=…][table]），不是 HTML，要单独转文本。
const NGA_HOST_RE = /^https?:\/\/(?:bbs\.nga\.cn|nga\.178\.com|ngabbs\.com|bbs\.ngacn\.cc)\//i;
const NGA_LIST_RE = /thread\.php\?(?:[^#]*\b)?fid=(\d+)/i;
const NGA_TID_RE = /[?&]tid=(\d+)/i;

const NGA_DEFAULT_FID = '560';   // 碧蓝幻想版

function ngaCookie() {
  return String((cfg() || {}).ngaCookie || '').trim();
}

/** NGA 功能总开关（设置里默认不勾选）。 */
function ngaEnabled() {
  return (cfg() || {}).ngaEnabled === true;
}

/**
 * NGA 功能是否真的可用：开关打开 + 有 Cookie + 节流时间大于 0。
 * 三者缺一就不发任何请求 —— 前端保存时虽然也会拦，但配置可能是手改的，
 * 所以运行期必须再判一次（这里是唯一真正决定"要不要打 NGA"的地方）。
 */
function ngaReady() {
  const c = cfg() || {};
  if (c.ngaEnabled !== true) return { ok: false, why: 'disabled' };
  if (!String(c.ngaCookie || '').trim()) return { ok: false, why: 'nokey' };
  const ttl = Number(c.ngaCacheMinutes);
  if (!Number.isFinite(ttl) || ttl <= 0) return { ok: false, why: 'nottl' };
  return { ok: true, ttl: Math.max(1, Math.min(1440, ttl)) };
}

/** 把 UBB 码转成给模型看的纯文本。 */
function ubbToText(src, { maxChars = 12000 } = {}) {
  let s = String(src || '');
  s = s.replace(/<br\s*\/?>/gi, '\n');
  s = s.replace(/\[quote\]([\s\S]*?)\[\/quote\]/gi, (_, inner) =>
    '\n> ' + ubbToText(inner, { maxChars }).split('\n').join('\n> ') + '\n');
  s = s.replace(/\[collapse[^\]]*\]([\s\S]*?)\[\/collapse\]/gi, '\n（折叠内容）\n$1\n');
  s = s.replace(/\[img\][\s\S]*?\[\/img\]/gi, '（图）');
  s = s.replace(/\[img=[^\]]*\][\s\S]*?\[\/img\]/gi, '（图）');
  s = s.replace(/\[flash[^\]]*\][\s\S]*?\[\/flash\]/gi, '（视频）');
  s = s.replace(/\[url=([^\]]+)\]([\s\S]*?)\[\/url\]/gi, (_, u, t) => {
    const label = String(t).replace(/\[[^\]]*\]/g, '').trim();
    return label ? `${label}(${u})` : u;
  });
  s = s.replace(/\[url\]([\s\S]*?)\[\/url\]/gi, '$1');
  s = s.replace(/\[\/?(?:b|i|u|del|h|list|\*|align[^\]]*|color[^\]]*|size[^\]]*|font[^\]]*|table|\/tr|\/td|td[^\]]*|tr[^\]]*|left|right|center|indent|float[^\]]*|pid[^\]]*|uid[^\]]*|tid[^\]]*|s[^\]]*|randomblock[^\]]*)\]/gi, '');
  s = s.replace(/\[[^\]\n]{0,40}\]/g, '');   // 剩下认不出的标签一律去掉
  s = decodeEntities(s);
  return s.replace(/[ \t\u00a0]+/g, ' ').replace(/ *\n */g, '\n').replace(/\n{3,}/g, '\n\n').trim().slice(0, maxChars);
}

/** 按页面声明的 charset 解码（NGA 是 GB18030）。 */
function decodeNgaBody(bytes, fallback) {
  try {
    if (bytes && bytes.length) {
      const head = Buffer.from(bytes.slice(0, 4000)).toString('latin1');
      const m = head.match(/charset\s*=\s*['"]?([\w-]+)/i);
      let enc = 'gb18030';
      if (m) {
        const c = m[1].toLowerCase();
        enc = /gb/.test(c) ? 'gb18030' : (/utf/.test(c) ? 'utf-8' : c);
      }
      return new TextDecoder(enc).decode(bytes);
    }
  } catch { /* 落到 fallback */ }
  return String(fallback || '');
}

/** 从帖子 HTML 里抽楼层：作者、时间、标题、正文。 */
function parseNgaThread(html, { maxChars = 12000, maxFloors = 20 } = {}) {
  const src = String(html);

  // ⚠️ NGA 的 HTML 是**不闭合**的：只有第 0 层有 </p>，后面几层都没有。
  //    所以不能用 /<p …>([\s\S]*?)<\/p>/ 去切 —— 那样只能抓到 1 层（踩过）。
  //    可靠的边界是**下一个 id='postcontentN' 锚点**（文档顺序）。
  const anchors = [...src.matchAll(/id='postcontent(\d+)'[^>]*>/gi)].map((m) => ({ idx: m[1], start: m.index, after: m.index + m[0].length }));

  const out = [];
  for (let i = 0; i < anchors.length && out.length < maxFloors; i++) {
    const a = anchors[i];
    const end = i + 1 < anchors.length ? anchors[i + 1].start : src.length;
    let raw = src.slice(a.after, end);

    // 尾巴上挂着这一层的附件区/签名/按钮，以及下一层的容器标签，都要切掉。
    // 注意不能只找 </p>：NGA 只有第 0 层有 </p>，后面几层没有（踩过 → 正文里漏出
    // "</span> <div class='clear'>" 这种 HTML 碎片）。
    const nextId = i + 1 < anchors.length ? anchors[i + 1].idx : null;
    const cutters = [
      /<\/p>/i,
      // 正文外面还套着 <span id='postcontentandsubjectN'>，所以正文一结束就是
      // "</span> <br/> </span>" —— 这里是正文真正的右边界（实测结构）
      /<\/span>\s*<br\s*\/?>\s*<\/span>/i,
      /<\/span>\s*<\/span>/i,
      /<h4[^>]*class='[^']*postbodysubtitle/i,   // 附件区标题
      /<span[^>]*id='postattach/i,
      /<div[^>]*id='postsign/i,                  // 签名
      /<div[^>]*class='clear'/i,
      /<script/i,                                // 楼层尾部脚本（commonui.postArg.proc）
      /<div[^>]*id='postBtnPos/i,
      /<span[^>]*id='posterinfo/i,
      /<\/td>/i,
      /<\/tr>/i,
      /<table[^>]*class='forumbox postbox'/i,    // 下一层的容器
      /<tr[^>]*id='post1strow/i,
    ];
    if (nextId) cutters.push(new RegExp(`id='postcontainer${nextId}'`, 'i'));
    let cut = raw.length;
    for (const re of cutters) {
      const m = raw.search(re);
      if (m >= 0 && m < cut) cut = m;
    }
    raw = raw.slice(0, cut);

    const i2 = a.idx;
    // ⚠️ NGA 的昵称是页面加载后用 JS 填进 <a id='postauthorN'> 的，静态 HTML 里是空的。
    //    所以作者名基本取不到，但 uid 在链接里 —— 用它标识发言者更实在。
    const authorM = src.match(new RegExp(`id='postauthor${i2}'[^>]*>([\\s\\S]{0,60}?)<`, 'i'));
    let author = authorM ? decodeEntities(authorM[1]).trim() : '';
    const uidM = src.match(new RegExp(`func=ucp&uid=(\\d+)'[^>]*id='postauthor${i2}'`, 'i'))
      || src.match(new RegExp(`id='postauthor${i2}'`, 'i')) && src.slice(Math.max(0, a.start - 600), a.start).match(/func=ucp&uid=(\d+)/);
    const uid = uidM ? uidM[1] : '';
    if (!author && uid) author = `uid:${uid}`;
    const dateM = src.match(new RegExp(`id='postdate${i2}'[^>]*>([^<]{0,40})<`, 'i'));
    const subjM = src.match(new RegExp(`id='postsubject${i2}'[^>]*>([\\s\\S]{0,200}?)</h3>`, 'i'));

    const text = ubbToText(raw, { maxChars });
    if (!text) continue;
    out.push({
      floor: out.length + 1,
      author: author || '（未取到）',
      date: dateM ? decodeEntities(dateM[1]).trim() : '',
      subject: subjM ? decodeEntities(subjM[1].replace(/<[^>]+>/g, ' ')).replace(/\s+/g, ' ').trim() : '',
      text,
    });
  }
  return out;
}

/** 统计楼层数（用于告诉模型"这只是前 N 层，帖子还有更多"）。 */
function countNgaFloors(html) {
  return [...String(html).matchAll(/id='postcontent(\d+)'/gi)].length;
}

/** 从版块列表页抽帖子标题。 */
function parseNgaList(html, { max = 40 } = {}) {
  const seen = new Set();
  const rows = [];
  for (const m of String(html).matchAll(/<a[^>]+href='\/read\.php\?tid=(\d+)'[^>]*>([\s\S]{0,160}?)<\/a>/gi)) {
    const tid = m[1];
    const title = decodeEntities(m[2].replace(/<[^>]+>/g, ' ')).replace(/\s+/g, ' ').trim();
    if (!title || title.length < 4) continue;
    if (seen.has(tid)) continue;
    seen.add(tid);
    rows.push({ tid, title });
    if (rows.length >= max) break;
  }
  return rows;
}

/** NGA 页面抓取（GB18030 解码 + Cookie）。 */
async function ngaGet(url, { s, referer = '' } = {}) {
  const cookie = ngaCookie();
  const ready = ngaReady();
  if (!ready.ok) {
    const why = ready.why === 'disabled' ? 'NGA 帖子查询功能没有开启'
      : (ready.why === 'nokey' ? '没配置 NGA Cookie' : '「NGA 内容缓存时间」不合法（必须大于 0）');
    return { ok: false, reason: `${why}，所以读不了 NGA。` };
  }
  const r = await curlGet(url, {
    timeoutMs: s.timeoutMs,
    curlPath: s.curlPath,
    cookie,
    referer,
    acceptLanguage: 'zh-CN,zh;q=0.9,en;q=0.8',
  });
  if (!r.ok) {
    const body = String(r.body || '');
    if (r.status === 403 || /访客不能直接访问/.test(body)) {
      return {
        ok: false,
        reason: 'NGA 返回 403「访客不能直接访问」—— Cookie 失效了或没有登录态。'
          + '请重新从浏览器复制一次 Cookie（技能设置 → NGA 登录 Cookie）。',
        blocked: true,
      };
    }
    return { ok: false, reason: r.error || `HTTP ${r.status}` };
  }
  const text = decodeNgaBody(r.bodyBytes, r.body);
  if (/访客不能直接访问/.test(text.slice(0, 4000))) {
    return { ok: false, reason: 'NGA 说「访客不能直接访问」—— Cookie 没有登录态或已过期。', blocked: true };
  }
  return { ok: true, html: text, url };
}

// ══════════════════════════════════════════════════════════════════════
//  四、搜索 / 读页
// ══════════════════════════════════════════════════════════════════════
/** 全文搜索：拿条目名 + 摘要（摘要在答题时往往就够用）。 */
async function searchWiki(base, term, { s, limit = 6 } = {}) {
  const res = await apiGet(base, {
    action: 'query', list: 'search', srsearch: term, srlimit: String(limit), srprop: 'snippet|size|wordcount',
  }, { s, cacheKey: `search:${term}:${limit}`, ttl: Math.min(s.cacheMinutes, 120) });
  if (!res.ok) return { ok: false, reason: res.reason };
  const raw = res.data?.query?.search ?? [];
  const hits = raw.map((h) => ({
    title: String(h.title || ''),
    size: Number(h.size) || 0,
    snippet: htmlToText(h.snippet || '').slice(0, 300),
  })).filter((h) => h.title);
  return { ok: true, hits, cached: res.cached === true };
}

/** 前缀建议：角色名这类"条目名很规整"的查询，它比全文搜索准得多。 */
async function suggestTitles(base, term, { s, limit = 8 } = {}) {
  const res = await apiGet(base, { action: 'opensearch', search: term, limit: String(limit) }, {
    s, cacheKey: `opensearch:${term}:${limit}`, ttl: Math.min(s.cacheMinutes, 120),
  });
  if (!res.ok) return { ok: false, reason: res.reason };
  const arr = Array.isArray(res.data) ? res.data : [];
  return { ok: true, titles: Array.isArray(arr[1]) ? arr[1].map(String) : [] };
}

/**
 * 读一个条目的渲染 HTML + 纯文本（缓存的是抽好的文本，省内存）。
 * focus = 这次提问里最关心的词（通常是角色名）：表格很大时优先保留含它的行。
 */
async function readPage(base, title, { s, maxChars = 20000, focus = '' } = {}) {
  const res = await apiGet(base, { action: 'parse', page: title, prop: 'text|displaytitle', disabletoc: '1' }, {
    s, cacheKey: `page:${title}:${maxChars}:${focus ? 'f' : ''}`,
  });
  if (!res.ok) return { ok: false, reason: res.reason };
  const d = res.data;
  if (d?.error) {
    return { ok: false, reason: `维基里没有「${title}」这个条目（${d.error.code || 'missingtitle'}）`, missing: true };
  }
  const html = String(d?.parse?.text ?? '');
  if (!html) return { ok: false, reason: `条目「${title}」没有正文`, missing: true };
  const realTitle = String(d?.parse?.title || title);
  const text = extractBody(html, { maxChars, focus });
  return {
    ok: true,
    title: realTitle,
    pageId: d?.parse?.pageid,
    url: `${base}/wiki/${encodeURIComponent(realTitle)}`,
    text,
    htmlLen: html.length,
    cached: res.cached === true,
    _html: html,      // 只在本进程内用于顺手抽表格行，不返回给模型
  };
}

// ══════════════════════════════════════════════════════════════════════
//  五、本地问答 answers.txt
// ══════════════════════════════════════════════════════════════════════
//  格式（人写，机器读；`#` 开头是注释）：
//    ### Q: 问题或关键词
//    关键词: 逗号或空格分隔，可选
//    来源: 可选
//    答案:
//    多行答案……
function localFilePath(name) {
  return path.isAbsolute(name) ? name : path.join(skillDir(), name);
}

function parseLocalAnswers(name) {
  const file = localFilePath(name);
  let raw = '';
  try { raw = fs.readFileSync(file, 'utf8'); } catch { return { entries: [], file, missing: true }; }
  raw = raw.replace(/^\uFEFF/, '');   // 容错：万一存成了带 BOM 的 UTF-8

  const entries = [];
  let cur = null;
  let mode = '';
  for (const line of raw.split(/\r?\n/)) {
    const t = line.trim();
    const qm = t.match(/^###\s*(?:Q|问)\s*[:：]\s*(.+)$/i);
    if (qm) {
      if (cur) entries.push(cur);
      cur = { q: qm[1].trim(), keywords: [], source: '', answer: [] };
      mode = 'answer';
      continue;
    }
    if (!cur) continue;
    const km = t.match(/^(?:关键词|关键字|keywords?)\s*[:：]\s*(.+)$/i);
    if (km) { cur.keywords = km[1].split(/[,，、\s]+/).map((x) => x.trim()).filter(Boolean); mode = ''; continue; }
    const sm = t.match(/^(?:来源|source|链接|url)\s*[:：]\s*(.+)$/i);
    if (sm) { cur.source = sm[1].trim(); mode = ''; continue; }
    if (/^(?:答案|答|A)\s*[:：]\s*$/i.test(t) || /^(?:答案|答|A)\s*[:：]/i.test(t)) {
      mode = 'answer';
      const rest = t.replace(/^(?:答案|答|A)\s*[:：]\s*/i, '').trim();
      if (rest) cur.answer.push(rest);
      continue;
    }
    if (/^#{1,6}\s/.test(t) && !qm) continue;      // 其它标题当分隔
    if (mode === 'answer' && t) cur.answer.push(t);
  }
  if (cur) entries.push(cur);

  return {
    entries: entries
      .map((e) => ({ ...e, answer: e.answer.join('\n').trim() }))
      .filter((e) => e.q && e.answer),
    file,
    missing: false,
  };
}

const normText = (s) => String(s || '')
  .toLowerCase()
  .replace(/[\s\u3000]/g, '')
  .replace(/[?？。，,、!！:：;；'"「」『』()（）\[\]【】]/g, '');

/**
 * 设置面板里「本地问答」存下来的问答（config.localQA，JSON 字符串）。
 * 形态：[{ q, a, keywords? }]。任何解析失败都退回空数组 ——
 * 一段坏数据不该让整个查询挂掉。
 */
function configQaEntries() {
  const raw = (cfg() || {}).localQA;
  let arr = null;
  if (Array.isArray(raw)) arr = raw;
  else if (typeof raw === 'string' && raw.trim()) {
    try {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) arr = parsed;
    } catch { arr = null; }
  }
  if (!arr) return [];
  return arr
    .map((x) => ({
      q: String(x?.q ?? '').trim(),
      answer: String(x?.a ?? '').trim(),
      // 关键词列：面板里是空格分隔的一行，也容忍逗号/顿号
      keywords: String(x?.keywords ?? '').split(/[\s,，、]+/).map((s) => s.trim()).filter(Boolean),
      source: '',
    }))
    .filter((e) => e.q && e.answer);
}

// 提问里常见的"语气/疑问"字：算重合度时要跳过，
// 否则"团战什么时候开始"和"活动时间怎么看"会靠「么/时/候」这种噪音词误命中。
const STOP_CHARS = '的了呢吗吧啊呀么什怎哪是多有是时候个这那一会能可要就还也都很太被把给和跟与或什么了吗';
const isStop = (ch) => STOP_CHARS.includes(ch);

/** 最长连续公共子串长度（用来判断"像不像同一个问题"） */
function longestCommonRun(a, b) {
  let best = 0;
  for (let i = 0; i < a.length; i++) {
    for (let j = 0; j < b.length; j++) {
      let k = 0;
      while (i + k < a.length && j + k < b.length && a[i + k] === b[j + k]) k++;
      if (k > best) best = k;
    }
  }
  return best;
}

/**
 * 有意义的连续重合长度：把两端的虚词（是/的/了…）削掉再算。
 * 例：「驱散是什么」vs「驱散是啥意思」原始重合是"驱散是"(3)，削掉尾巴的"是"
 * 之后真实重合是"驱散"(2) —— 虚词撑出来的长度会虚高，导致"看起来很像"。
 */
function meaningfulRun(a, b) {
  let best = 0;
  for (let i = 0; i < a.length; i++) {
    for (let j = 0; j < b.length; j++) {
      let k = 0;
      while (i + k < a.length && j + k < b.length && a[i + k] === b[j + k]) k++;
      let s = 0;
      let e = k;
      while (s < e && isStop(a[i + s])) s++;
      while (e > s && isStop(a[i + e - 1])) e--;
      if (e - s > best) best = e - s;
    }
  }
  return best;
}

/**
 * 给一条问答打相似度分（0~100）。
 * 「类似的问题回答相同答案」就是靠这里：除了完全一致，还认
 *   · 问题互为子串（"古战场什么时候开" ↔ "古战场几点开"）
 *   · 关键词命中（面板里可以给一条问答写多个关键词/同义词）
 *   · 中文连续重合度（"圣德芬有几个驱散" ↔ "圣德芬的驱散技能"）
 *
 * ⚠️ 两条刻意的规则，都是实测踩出来的：
 *   ① 一方完整包含另一方时，分数**不按长度重罚** —— 关键词往往很短（"团战"），
 *      若按长度加权，会被别条问答的长句偶然包含压过去。
 *   ② **命中关键词的条目永远优先于只靠问句相似度命中的条目**。
 *      关键词是主人手动写的强信号；问句之间的字面相似很可能只是巧合
 *      （"团战什么时候开始" 和 "活动时间怎么看" 就撞了好几个虚词）。
 */
function scoreEntry(e, q) {
  const keywords = (e.keywords || []).map(normText).filter(Boolean);
  const question = normText(e.q);
  const hay = [question, ...keywords].filter(Boolean);
  let best = 0;
  for (const h of hay) {
    if (!h) continue;
    if (h === q) { best = Math.max(best, 100); continue; }
    const shortest = Math.min(h.length, q.length);

    // ① 一方完整包含另一方：命中的是"整个片段"，长度只做小幅加成
    if (q.includes(h) || h.includes(q)) {
      best = Math.max(best, 72 + Math.min(18, shortest * 2));
      continue;
    }

    // ② 连续重合：按最长**有效**连续片段（削掉两端虚词）占较短一方的比例给分
    const run = meaningfulRun(h, q);
    if (run >= 2 && run / Math.max(1, shortest) >= 0.5) {
      best = Math.max(best, Math.min(74, Math.round((run / shortest) * 80)));
    }

    // ③ 2-gram 重合兜底。⚠️ 中文疑问/语气词会制造大量假重合
    //    （"团战什么时候开始" 和 "活动时间怎么看" 光靠"什么/时候"就能撞到 80 分），
    //    所以：两个字的 gram 里只要有一个是停用字就跳过，
    //    并且要求**至少 3 个** gram 命中 —— 只靠一两个虚词不算"相似问题"。
    let overlap = 0;
    let total = 0;
    for (let i = 0; i + 1 < q.length; i++) {
      const gram = q.slice(i, i + 2);
      if (isStop(gram[0]) || isStop(gram[1])) continue;
      total++;
      if (h.includes(gram)) overlap++;
    }
    if (overlap >= 3 && total) {
      best = Math.max(best, Math.min(64, Math.round((overlap / total) * 70)));
    }
  }

  // 强制规则②：问句本身没有强命中、但关键词命中了 → 按关键词长度给分。
  // 用长度而不是固定值：关键词越长越具体（"什么时候开"），越该压过笼统的短词（"团战"）。
  if (best < 80) {
    let kwBest = 0;
    for (const k of keywords) {
      if (k.length < 2) continue;
      if (q.includes(k) || k.includes(q)) kwBest = Math.max(kwBest, 78 + Math.min(12, k.length - 2));
    }
    if (kwBest) best = kwBest;
  }
  return best;
}

/** 本地问答：设置面板里的 + answers.txt 文件里的，合并后按相似度取最匹配的几条。 */
function findLocalAnswer(query) {
  const { localFile } = settings();
  const fileParsed = parseLocalAnswers(localFile);
  const fromConfig = configQaEntries();
  const entries = [...fromConfig, ...(fileParsed.entries || [])];
  const file = fileParsed.missing ? `${localFile}（还没创建）` : localFile;
  const origin = { config: fromConfig.length, file: fileParsed.missing ? 0 : (fileParsed.entries || []).length };

  if (!entries.length) {
    return { ok: true, entries: [], file, missing: fileParsed.missing && !origin.config, total: 0, origin };
  }
  const q = normText(query);
  if (!q) return { ok: true, entries: [], file, total: entries.length, origin };

  const scored = [];
  for (const e of entries) {
    const s = scoreEntry(e, q);
    if (s > 0) scored.push({ e, score: s });
  }
  scored.sort((a, b) => b.score - a.score);
  // 阈值：太牵强的匹配不如没有（免得用错的本地答案盖掉真正该去查维基的问题）。
  // 60 分意味着至少要有"关键词命中"或"问句互为子串"这种强信号；
  // 纯 2-gram 字面相似达不到（上限 64，且要求 ≥3 个 gram 命中）。
  const hits = scored.filter((x) => x.score >= 60).slice(0, 3).map((x) => ({ ...x.e, score: x.score }));
  return { ok: true, entries: hits, file, total: entries.length, origin };
}

function groupQuestion(query) {
  const q = String(query || '');
  const asks = [];
  if (/驱散|消除|ディスペル|dispel/i.test(q)) asks.push('驱散');
  if (/弱体|减益|debuff|弱化/i.test(q)) asks.push('弱体');
  if (/活动|时间|开始|结束|开启|关闭|日程|什么时候|几号|几点|期间/i.test(q)) asks.push('时间');
  return asks;
}

/**
 * 决定"这次最关心哪个词"：长表（如「驱散」287 行）靠它把相关行提到前面。
 * 优先用问题里的人名；问题就是条目名时（「驱散」）不聚焦，避免把所有行都滤掉。
 */
function focusTerm(title, query) {
  const cands = extractConstituents(query).filter((c) => !title || !title.includes(c));
  if (cands.length) return cands[0];
  const t = String(title || '').trim();
  const q = String(query || '').trim();
  if (t && q && t !== q && q.length <= 12 && q.includes(t)) return '';   // 问的就是条目本身
  return '';
}

// 提问里的"问法"词：判断专有名词时要去掉，剩下的才是人名/条目名。
// 例：「娜露梅娅有几个驱散」→ 去掉「有几个」「驱散」→ 娜露梅娅
const NOISE_WORDS = [
  '请问', '麻烦', '帮忙', '帮我', '一下', '是什么', '有什么', '有哪些', '有没有', '有没有什么',
  '几个', '多少', '哪些', '哪个', '什么', '怎么', '如何', '为什么', '是不是', '能不能', '可以',
  '驱散', '弱体', '减益', '净化', '效果', '技能', '奥义', '被动', '武器', '召唤', '召唤石', '角色',
  '时间', '开始', '结束', '开启', '关闭', '活动', '期间', '日程', '安排', '上限', '倍率', '数量',
  '这个', '那个', '这只', '那只', '这位', '那位', '的话', '呢', '吗', '吧', '啊', '呀', '的',
];

/** 从一句人话里抠出可能的专有名词（人名/条目名），用于在长表里聚焦。 */
function extractConstituents(text) {
  let q = String(text || '').trim();
  if (!q) return [];
  const out = new Set();
  // ① 常见提问模板：「X 有几个 Y」「X 的 Y」「X 什么时候」（必须带 g，否则 matchAll 抛错）
  for (const m of q.matchAll(/^(.{2,12}?)(?:有|的|是|这|那|什么时候|何时|几|多少)/g)) out.add(m[1]);
  // ② 去噪词后剩下的中文片段
  let cleaned = q;
  for (const w of NOISE_WORDS) cleaned = cleaned.split(w).join(' ');
  for (const chunk of cleaned.split(/[\s,，、。？?！!：:；;（）()\[\]【】"']+/)) {
    const s = chunk.trim();
    if (s.length >= 2 && s.length <= 12 && /[\u4e00-\u9fa5A-Za-z]/.test(s)) out.add(s);
  }
  // ③ 去掉纯问句/纯数字
  return [...out].filter((s) => !/^[0-9]+$/.test(s) && !/^[的了呢吗吧啊呀]+$/.test(s)).slice(0, 4);
}

// ══════════════════════════════════════════════════════════════════════
//  六、结果渲染（给模型看的资料）
// ══════════════════════════════════════════════════════════════════════
const today = () => new Date().toLocaleDateString('zh-CN', { year: 'numeric', month: 'long', day: 'numeric', weekday: 'long' });

function renderLocal({ query, found, file }) {
  const L = ['【来源】本地问答（不走维基）'];
  const cfgCount = found.origin ? found.origin.config : 0;
  const fileCount = found.origin ? found.origin.file : 0;
  L.push(`【共 ${found.total || 0} 条】设置面板里 ${cfgCount} 条`
    + (fileCount ? ` ＋ answers.txt 里 ${fileCount} 条` : '')
    + `（文件：${file}）`);

  if (!found.entries.length) {
    if (!found.total) {
      L.push('', '【状态】本地问答还是空的（这是正常的，第一次用都会这样）。',
        '【下一步】直接用 gbf_wiki 去维基查。',
        '如果这个问题以后还会被反复问到，可以在机器人控制台「技能 → 碧蓝幻想·灰机中文维基百科 → 设置」里，'
        + '用「＋ 新增一组问答」把它固定下来，以后就直接照你的答案回答了。');
      return L.join('\n');
    }
    L.push('', `【状态】${found.total} 条本地问答里没有匹配「${query}」的。`,
      '【下一步】用 gbf_wiki 查维基。想把答案固定下来就去技能设置里加一组问答。');
    return L.join('\n');
  }
  L.push('', `【命中】匹配到 ${found.entries.length} 条本地问答 —— **直接按这里的答案回答，不用再去搜维基**。`);
  for (const e of found.entries) {
    L.push('', `### 问：${e.q}`);
    if (e.keywords.length) L.push(`关键词：${e.keywords.join('、')}`);
    if (e.source) L.push(`来源：${e.source}`);
    L.push('答：', e.answer);
  }
  L.push('', '【回答要求】用本地答案里的说法回答（这是主人自己维护的，优先于维基）。'
    + '如果本地答案里有来源链接，一并附上。');
  return L.join('\n');
}

function renderNoResult({ query, base, hits, titles, tried, note }) {
  const L = [`【查询】${query}`, `【站内搜索】${base}`, `【今天】${today()}`];
  L.push('', '【状态】❌ 在灰机中文维基里没找到相关内容。');
  if (tried?.length) L.push(`【试过的关键词】${tried.join(' / ')}`);
  if (note) L.push(`【说明】${note}`);
  if (titles?.length) {
    L.push('', '【维基里有这些相近条目】（不确定是不是你要的，可以让群友确认）');
    titles.slice(0, 8).forEach((t) => L.push(`· ${t}  →  ${base}/wiki/${encodeURIComponent(t)}`));
  }
  if (hits?.length) {
    L.push('', '【搜索结果里有这些】（可能只是部分匹配）');
    hits.slice(0, 6).forEach((h) => L.push(`· ${h.title}${h.snippet ? ` —— ${h.snippet.slice(0, 120)}` : ''}`));
  }
  L.push('',
    '【必须这样回答】如实告诉群友「这个在灰机中文维基里没找到」，',
    '可以补一句建议：换个说法再问，或者说「日文站 GameWith 可能有」。',
    '**严禁**凭印象编造技能效果、倍率、上限或活动时间。');
  return L.join('\n');
}

function renderPage({ query, page, asks, evidence, base }) {
  const L = [];
  L.push(`【来源】碧蓝幻想中文维基（灰机）`, `【条目】${page.title}`, `【链接】${page.url}`);
  L.push(`【今天】${today()}`);
  if (page.cached) L.push('（本条来自本地缓存，未重新联网）');
  if (asks.length) L.push(`【这次问的是】${asks.join('、')}`);

  if (asks.includes('时间')) {
    L.push('', '【看时间时的注意】活动时间一般写成「10月7日 16:00 ～ 10月14日 19:59」。'
      + '请对照上面的「今天」判断它是**正在进行**、**已经结束**还是**还没开始**，并原样给出起止时刻。'
      + '跨年的排期表请用条目里标明的年份。');
  }
  if (asks.includes('驱散') || asks.includes('弱体')) {
    L.push('', '【怎么数数量】这类条目（例如「驱散」总表）把每个技能的描述都列出来了。'
      + '请**先数清这个角色有几个技能带驱散／几个带弱体**，再逐条说效果和作用对象（单体/全体）、'
      + '使用间隔。同一个技能里出现多次要算多次，别把「全驱散」当成普通驱散。');
  }
  if (evidence?.lines?.length) {
    L.push('', '【正文统计】');
    evidence.lines.forEach((x) => L.push(x));
  }
  if (evidence?.rows?.length) {
    L.push('', '【与提问直接相关的表格行】');
    evidence.rows.slice(0, 15).forEach((r) => L.push(`· ${r}`));
  }
  L.push('', '【条目正文】', page.text || '(没有抽到可用正文)');
  L.push('', '【回答要求】只根据上面的正文回答，先结论后细节，最后附上条目链接。'
    + '正文里没有的数字**不要**自己补。');
  return L.join('\n');
}

function renderCandidates({ query, base, hits, titles, asks }) {
  const L = [];
  L.push(`【查询】${query}`, `【站内搜索】${base}`, `【今天】${today()}`);
  if (asks.length) L.push(`【这次问的是】${asks.join('、')}`);
  L.push('', '【状态】还没锁定到具体条目 —— 下面是候选，请挑一个再查。');
  if (hits.length) {
    L.push('', '【全文搜索命中】');
    hits.forEach((h, i) => {
      L.push(`${i + 1}. ${h.title}`);
      if (h.snippet) L.push(`   摘要：${h.snippet}`);
      L.push(`   链接：${base}/wiki/${encodeURIComponent(h.title)}`);
    });
  }
  if (titles.length) {
    L.push('', '【条目名以该关键词开头】（角色/技能条目通常在这里，通常比全文搜索更准）');
    titles.forEach((t) => L.push(`· ${t}`));
  }
  L.push('',
    '【下一步】把最像的那个**标题原样**填进 title，再调用一次 gbf_wiki（或 gbf_page）读它的正文。',
    '如果这些都不是群友问的东西，就如实说「灰机中文维基里没找到」，不要硬套一个不相关的条目。');
  return L.join('\n');
}

// ══════════════════════════════════════════════════════════════════════
//  七、技能入口
// ══════════════════════════════════════════════════════════════════════
export function setup(api) {
  cfg = () => api.config() || {};
  api.log('碧蓝幻想·灰机中文维基 已加载'
    + `（本地问答：设置面板 + ${settings().localFile}；抓取：curl.exe + 浏览器头，绕过 Cloudflare）`);

  // ── 工具 1：主查询 ───────────────────────────────────────────────
  api.registerTool({
    id: 'gbf_wiki',
    name: '查碧蓝幻想中文维基',
    description:
      '在碧蓝幻想中文维基（灰机 gbf.huijiwiki.com）里查资料并返回条目正文，用于回答 GBF 的问题：'
      + '活动/古战场/公会战的开始与结束时间、某个角色有几个驱散、几个弱体、技能具体什么效果、'
      + '武器/召唤石/Boss 特动等。用法：填 query 先搜一次；若返回的是「候选条目」，挑最像的把标题填进 title 再调一次。'
      + '当群友 @机器人 或私聊问到碧蓝幻想（GBF／グラブル／granblue）时使用；'
      + '群里别人自己聊 GBF 且没叫机器人时**不要**使用，不要主动插话。',
    category: 'knowledge',
    icon: '📖',
    defaultEnabled: true,
    parameters: {
      type: 'object',
      properties: {
        query: {
          type: 'string',
          description: '要查的内容，群友的原话即可（含俗称黑话，如「大巴」「阿妮拉」「路西HL」「古战场什么时候开」）。也可以是维基链接或条目名。',
        },
        title: {
          type: 'string',
          description: '已确定的维基条目名（例如「驱散」「活动/2026」「娜露梅娅(SSR)」）。填了就跳过搜索直接读这个条目。',
        },
        mode: {
          type: 'string',
          enum: ['auto', 'search', 'answer'],
          description: 'auto=先搜索、够用就直接答（默认）；search=只要搜索结果列表；answer=必须读到条目正文再答。',
        },
      },
      required: ['query'],
    },
    async execute(ctx, args) {
      try {
        const s = settings();
        const query = String(args?.query ?? '').trim();
        const givenTitle = String(args?.title ?? '').trim();
        const mode = ['auto', 'search', 'answer'].includes(args?.mode) ? args.mode : 'auto';
        if (!query && !givenTitle) return { content: 'query 不能为空：请把群友的问题原样放进来', isError: true };

        let asks = groupQuestion(givenTitle || query);
        let focus = focusTerm(givenTitle, query);

        // ① 本地问答优先（命中就不用联网）
        if (s.localFirst && !givenTitle && mode !== 'search') {
          const local = findLocalAnswer(query);
          if (local.entries?.length) {
            api.log(`「${query}」命中本地问答 ${local.entries.length} 条，直接用本地答案`);
            return { content: renderLocal({ query, found: local, file: local.file }) };
          }
        }

        // ② 指定了条目 → 直接读
        if (givenTitle) {
          const page = await readPage(s.base, givenTitle, { s, maxChars: s.maxChars, focus });
          if (!page.ok) {
            const sug = await suggestTitles(s.base, givenTitle, { s, limit: s.maxHits });
            return {
              content: renderNoResult({
                query: givenTitle, base: s.base, titles: sug.ok ? sug.titles : [],
                note: page.reason, tried: [givenTitle],
              }),
            };
          }
          return { content: renderPage({ query, page, asks, evidence: gatherEvidence(page._html, page.text, focus || query), base: s.base }) };
        }

        // ③ 「某角色有几个驱散/弱体」→ 直接查索引总表（维基已经把全服技能整理成表了），
        //    用角色名当 focus，只把该角色的行提出来。这比先全文搜索准得多。
        if (mode !== 'search') {
          const idxTitle = asks.includes('驱散') ? '驱散' : (asks.includes('弱体') ? '弱体' : '');
          if (idxTitle && focus) {
            const idx = await readPage(s.base, idxTitle, { s, maxChars: s.maxChars, focus });
            if (idx.ok && idx.text.includes(focus)) {
              api.log(`「${query}」→ 索引表「${idxTitle}」聚焦「${focus}」（${idx.text.length} 字）`);
              return {
                content: renderPage({
                  query, page: idx, asks,
                  evidence: gatherEvidence(idx._html, idx.text, focus), base: s.base,
                }),
              };
            }
          }
        }

        // ④ 「什么时候开 / 这周有什么活动」→ 先看「活动/<今年>」排期总表
        //    （维基把全年活动起止都排好了；搜索"这周有什么活动"这种口语反而搜不到）
        if (mode !== 'search' && asks.includes('时间')) {
          const year = new Date().getFullYear();
          const y = await readPage(s.base, `活动/${year}`, { s, maxChars: s.maxChars, focus: '' });
          if (y.ok && /\d+月\d+日/.test(y.text)) {
            api.log(`「${query}」→ 排期表「活动/${year}」（${y.text.length} 字）`);
            return {
              content: renderPage({
                query, page: y, asks,
                evidence: { lines: [], rows: [] }, base: s.base,
              }) + `\n\n【说明】上面是 ${year} 年全年排期总表。`
                + `如果群友问的是「现在/这周」，请对照【今天】挑出正在进行和即将开始的活动。`,
            };
          }
        }

        // ⑤ 搜索 + 前缀建议
        const [search, suggest] = await Promise.all([
          searchWiki(s.base, query, { s, limit: s.maxHits }),
          suggestTitles(s.base, query, { s, limit: 8 }),
        ]);
        const hits = search.ok ? search.hits : [];
        const titles = suggest.ok ? suggest.titles : [];
        if (!search.ok && !suggest.ok) {
          return {
            content: `【状态】❌ 维基查询失败：${search.reason || suggest.reason}\n`
              + `【链接】${s.base}\n`
              + '【下一步】这多半是网络问题或被 Cloudflare 拦了。可以过一会儿再试；'
              + '仍然不行就如实告诉群友「维基现在查不了」，不要编造内容。',
          };
        }

        // 条目名完全命中（或前缀建议唯一且高度吻合）→ 直接读正文
        const exact = [...titles, ...hits.map((h) => h.title)].find((t) => t === query);
        let pick = exact || '';
        if (!pick && titles.length === 1 && mode !== 'search') pick = titles[0];
        if (!pick && mode === 'search') {
          return { content: renderCandidates({ query, base: s.base, hits, titles, asks }) };
        }
        if (!pick) {
          // 只有一个强候选（搜索第一条标题包含查询词或反之）时也直接读，省一轮
          const first = hits[0];
          if (first && mode === 'auto' && first.title.length >= 2
            && (first.title.includes(query) || query.includes(first.title))) {
            pick = first.title;
          }
        }

        if (!pick) {
          const local = s.localFirst ? findLocalAnswer(query) : { entries: [], file: localFilePath(s.localFile) };
          let content = renderCandidates({ query, base: s.base, hits, titles, asks });
          if (local.entries?.length) content = renderLocal({ query, found: local, file: local.file }) + '\n\n' + content;
          if (!hits.length && !titles.length) {
            const file = localFilePath(s.localFile);
            return {
              content: renderNoResult({
                query, base: s.base, hits, titles,
                note: `全文搜索和条目名建议都没有结果（本地问答文件：${file}）。`,
              }),
            };
          }
          api.log(`「${query}」未锁定条目，返回 ${hits.length} 条搜索 + ${titles.length} 条建议`);
          return { content };
        }

        const page = await readPage(s.base, pick, { s, maxChars: s.maxChars });
        if (!page.ok) {
          return { content: renderNoResult({ query, base: s.base, hits, titles, note: page.reason, tried: [pick] }) };
        }
        api.log(`「${query}」→ 条目「${page.title}」（正文 ${page.text.length} 字）`);
        return { content: renderPage({ query, page, asks, evidence: gatherEvidence(page._html, page.text, query), base: s.base }) };
      } catch (error) {
        return { content: `查维基时出错：${error?.message ?? error}`, isError: true };
      }
    },
  });

  // ── 工具 2：读整页 / 某个小节 ─────────────────────────────────────
  api.registerTool({
    id: 'gbf_page',    name: '读碧蓝幻想维基条目',
    description:
      '按**确切的条目名**读碧蓝幻想中文维基（灰机）的一个页面，返回全文（含表格转成的一行行数据）。'
      + '用于：已知条目名要读全文、gbf_wiki 返回候选后确认读某一条、或想再读一遍某个条目的完整内容。'
      + '当群友 @机器人 或私聊要「某条目的全部内容／完整技能表／全部活动时间表」时使用。',
    category: 'knowledge',
    icon: '📄',
    defaultEnabled: true,
    parameters: {
      type: 'object',
      properties: {
        title: { type: 'string', description: '确切的维基条目名，如「驱散」「活动/2026」「古战场」「娜露梅娅(SSR)」。不要填问题句子。' },
        question: { type: 'string', description: '可选：群友原本问的问题。填了会在结果里带上「与提问相关的表格行」，更容易答准。' },
      },
      required: ['title'],
    },
    async execute(ctx, args) {
      try {
        const s = settings();
        const title = String(args?.title ?? '').trim();
        if (!title) return { content: 'title 不能为空（要确切的条目名）', isError: true };
        const question = String(args?.question ?? '').trim();
        const asks = groupQuestion(question || title);
        const focus = focusTerm(title, question);

        const page = await readPage(s.base, title, { s, maxChars: s.maxChars, focus });
        if (!page.ok) {
          const sug = await suggestTitles(s.base, title, { s, limit: s.maxHits });
          return {
            content: renderNoResult({
              query: title, base: s.base, titles: sug.ok ? sug.titles : [],
              note: page.reason, tried: [title],
            }),
          };
        }
        const evidence = (focus || question) ? gatherEvidence(page._html, page.text, focus || question) : { lines: [], rows: [] };
        api.log(`读条目「${page.title}」（正文 ${page.text.length} 字）`);
        return { content: renderPage({ query: question || title, page, asks, evidence, base: s.base }) };
      } catch (error) {
        return { content: `读条目时出错：${error?.message ?? error}`, isError: true };
      }
    },
  });

  // ── 工具 3：读 NGA 碧蓝版（论坛来源，需要登录 Cookie）──────────────
  api.registerTool({
    id: 'nga_fetch',
    name: '读NGA碧蓝版',
    description:
      '读 NGA 玩家社区「碧蓝幻想」版（bbs.nga.cn，fid=560）的内容：'
      + '填了 url 就读那个帖子/版块页（支持 read.php?tid=… 和 thread.php?fid=… 链接），不填 url 就读该版当前帖子列表。'
      + '用于回答「群友贴的 NGA 链接里说了什么」「NGA 上对这个怎么看」。'
      + '当群友 @机器人 或私聊贴出 NGA 链接、或明确问到 NGA 上的说法时使用；没被叫到时不要主动去读。'
      + '注意：NGA 需要登录态（技能设置里配 NGA Cookie）才能读，没配或失效会返回读不了的原因。',
    category: 'knowledge',
    icon: '💬',
    defaultEnabled: true,
    parameters: {
      type: 'object',
      properties: {
        url: { type: 'string', description: 'NGA 页面链接（整条贴进来即可，如 https://bbs.nga.cn/read.php?tid=12345678）。不填则读碧蓝版当前帖子列表。' },
        tid: { type: 'string', description: '可选：帖子 id（read.php?tid= 后面那串数字）。已知 tid 没链接时用这个。' },
        maxFloors: { type: 'number', description: '最多读几层楼，默认 12，范围 1~40。只看楼主前几层时填小一点。' },
      },
    },
    async execute(ctx, args) {
      try {
        const s = settings();
        const ready = ngaReady();

        // 总开关没开 → 一句话说清，并告诉模型改用维基
        if (!ready.ok && ready.why === 'disabled') {
          return {
            content: '【状态】NGA 帖子查询功能当前是**关闭**的（技能设置里「开启 NGA 帖子查询」没有勾选）。\n'
              + '【怎么办】如果群友只是贴了个 NGA 链接：就如实说「NGA 查询功能没开」，'
              + '然后用 gbf_wiki 去灰机中文维基查同样的内容；**不要**假装读过 NGA，也不要编造 NGA 上的说法。\n'
              + '【想开启】让主人到机器人控制台 → 技能 → 碧蓝幻想·灰机中文维基百科 → 设置，'
              + '先填「NGA 登录 Cookie」、确认「NGA 内容缓存时间」大于 0，再勾选「开启 NGA 帖子查询」。',
          };
        }

        const cookie = ngaCookie();
        const rawUrl = String(args?.url ?? '').trim();
        const tidArg = String(args?.tid ?? '').trim();
        const maxFloors = Math.max(1, Math.min(40, Number(args?.maxFloors) || 12));

        // 勾了开关但缺 Cookie
        if (!ready.ok && ready.why === 'nokey') {
          return {
            content: '【状态】❌ 读不了 NGA：开关虽然开了，但「NGA 登录 Cookie」还没填。\n'
              + '【为什么】NGA 整站需要登录才能看，不带登录态一律返回「访客不能直接访问」。\n'
              + '【怎么办】让主人到技能设置里填好 Cookie 再试；在那之前用灰机维基回答，'
              + '并如实告诉群友「NGA 现在读不了」，**不要**编造 NGA 上的说法。',
          };
        }
        // 勾了开关、有 Cookie，但节流时间不合法
        if (!ready.ok && ready.why === 'nottl') {
          return {
            content: '【状态】❌ 读不了 NGA：「NGA 内容缓存时间」必须是大于 0 的分钟数（默认 30）。\n'
              + '【为什么】这个值是请求节流，用来把对 NGA 的请求量压到最低，降低账号被风控的风险，'
              + '所以不允许设成 0 或空。\n'
              + '【怎么办】让主人到技能设置里把它改回 30（或更大）再试。',
          };
        }

        // 定 URL：给了链接就用链接；只给 tid 拼 read.php；都没给就列版块
        let url = '';
        let kind = '';
        let referer = '';
        if (rawUrl) {
          if (!NGA_HOST_RE.test(rawUrl)) {
            return {
              content: `【状态】❌ 这不是 NGA 的链接：${rawUrl}\n`
                + '【说明】本工具只读 bbs.nga.cn / ngabbs.com 的页面。灰机维基的内容请用 gbf_wiki。',
            };
          }
          url = rawUrl;
          kind = NGA_TID_RE.test(url) ? 'thread' : (NGA_LIST_RE.test(url) ? 'list' : 'other');
          referer = `https://bbs.nga.cn/thread.php?fid=${(url.match(NGA_LIST_RE) || [, NGA_DEFAULT_FID])[1]}`;
        } else if (tidArg && /^\d+$/.test(tidArg)) {
          url = `https://bbs.nga.cn/read.php?tid=${tidArg}`;
          kind = 'thread';
          referer = `https://bbs.nga.cn/thread.php?fid=${NGA_DEFAULT_FID}`;
        } else {
          url = `https://bbs.nga.cn/thread.php?fid=${NGA_DEFAULT_FID}`;
          kind = 'list';
          referer = 'https://bbs.nga.cn/';
        }

        // 缓存：默认 30 分钟（见 manifest 的 ngaCacheMinutes 说明）
        const ttl = ready.ttl;
        const ck = `nga:${url}`;
        let html = cacheGet(ck, ttl);
        let fromCache = false;
        if (html) {
          fromCache = true;
        } else {
          const r = await ngaGet(url, { s, referer });
          if (!r.ok) {
            return {
              content: `【状态】❌ 读 NGA 失败：${r.reason}\n`
                + `【链接】${url}\n`
                + '【下一步】如果是 Cookie 失效，提醒主人去技能设置里重新填一次；'
                + '在那之前用灰机维基回答，并如实告诉群友「NGA 现在读不了」。不要编造 NGA 的内容。',
            };
          }
          html = r.html;
          cacheSet(ck, html);
        }

        const head = [
          '【来源】NGA 玩家社区 · 碧蓝幻想版（玩家论坛，非官方数据）',
          `【链接】${url}`,
          `【今天】${today()}`,
          fromCache ? `（本条来自本地缓存，${ttl} 分钟内不重复请求 NGA）` : '',
        ].filter(Boolean);

        if (kind === 'thread') {
          const floors = parseNgaThread(html, { maxChars: Math.min(4000, Math.floor(s.maxChars / Math.max(1, maxFloors))), maxFloors });
          if (!floors.length) {
            return {
              content: `${head.join('\n')}\n\n【状态】❌ 抓到页面了，但没解析出楼层内容`
                + '（可能这个 tid 是版块跳转页、帖子被删、或 NGA 改了页面结构）。\n'
                + '【下一步】如实告诉群友这个帖子读不到内容，可以让他直接贴正文。',
            };
          }
          const titleM = html.match(/<title>([\s\S]*?)<\/title>/i);
          // 标题里夹杂的标签会被换成空格，压一下，否则出一串空格（踩过）
          const title = titleM ? decodeEntities(titleM[1]).replace(/\s*NGA玩家社区\s*$/i, '').replace(/\s+/g, ' ').trim() : '';
          const totalFloors = countNgaFloors(html);
          const L = head.slice();
          if (title) L.push(`【帖子标题】${title}`);
          L.push(`【本次读到 ${floors.length} 层，本页共 ${totalFloors} 层】`
            + (totalFloors > floors.length ? '（帖子可能更长，需要更多楼层就把 maxFloors 调大）' : ''), '');
          for (const f of floors) {
            L.push(`── 第 ${f.floor} 楼${f.author ? ` · ${f.author}` : ''}${f.date ? ` · ${f.date}` : ''} ──`);            if (f.subject) L.push(`（标题：${f.subject}）`);
            L.push(f.text, '');
          }
          L.push('【回答要求】这是**玩家论坛**内容，可能过时或只是个人观点。'
            + '回答时说明「这是 NGA 帖子里的说法」；涉及数值/时间等硬信息，优先以灰机维基为准，冲突就两个都说。');
          api.log(`读 NGA 帖子 ${url}（${floors.length} 层）`);
          return { content: L.join('\n') };
        }

        // 版块列表 / 其它页：给标题清单
        const rows = parseNgaList(html, { max: 40 });
        if (!rows.length) {
          const txt = htmlToText(html).slice(0, 1500);
          return { content: `${head.join('\n')}\n\n【状态】没解析出帖子列表，先给页面正文：\n${txt}` };
        }
        const L = head.slice();
        L.push(`【碧蓝幻想版当前帖子】共 ${rows.length} 条（链接格式：https://bbs.nga.cn/read.php?tid=<数字>）`, '');
        rows.forEach((r, i) => L.push(`${i + 1}. ${r.title}\n   tid=${r.tid}`));
        L.push('', '【下一步】想看哪一条，把它的 tid 填进 tid（或把链接填进 url）再调一次本工具读正文。');
        api.log(`读 NGA 版块列表（${rows.length} 条）`);
        return { content: L.join('\n') };
      } catch (error) {
        return { content: `读 NGA 时出错：${error?.message ?? error}`, isError: true };
      }
    },
  });

  // ── 工具 4：查本地问答 ────────────────────────────────────────────
  api.registerTool({
    id: 'gbf_local',
    name: '查本地GBF问答',
    description:
      '在主人自己维护的「本地问答」里查有没有现成答案。'
      + '内容来自两处：机器人控制台「技能 → 设置」里用问答面板填的，以及技能目录下的 answers.txt（可选）。'
      + '这些是主人手写的、优先于维基的内容，支持相似问法（关键词/同义词）命中同一条答案。'
      + '当群友 @机器人 或私聊问碧蓝幻想（GBF）的问题时，**先**用它查一次；'
      + '命中就直接按里面的说法回答，不用再联网。',
    category: 'knowledge',
    icon: '🗒️',
    defaultEnabled: true,
    parameters: {
      type: 'object',
      properties: {
        query: { type: 'string', description: '群友的问题原话或关键词' },
        list: { type: 'boolean', description: 'true = 不搜索，直接列出本地问答里的所有问题标题（含设置面板里加的和 answers.txt 里的）' },
      },
      required: ['query'],
    },
    async execute(_ctx, args) {
      try {
        const s = settings();
        if (args?.list === true) {
          const fromConfig = configQaEntries();
          const fileParsed = parseLocalAnswers(s.localFile);
          const fileEntries = fileParsed.entries || [];
          if (!fromConfig.length && !fileEntries.length) {
            return {
              content: '本地问答还是空的。\n'
                + '可以到机器人控制台「技能 → 碧蓝幻想·灰机中文维基百科 → 设置」，用「＋ 新增一组问答」加一条；\n'
                + `或者按格式手写 ${s.localFile}（可选）。`,
            };
          }
          const L = [`【本地问答】共 ${fromConfig.length + fileEntries.length} 条`,
            `（设置面板 ${fromConfig.length} 条${fileEntries.length ? ` ＋ ${s.localFile} ${fileEntries.length} 条` : ''}）`];
          if (fromConfig.length) {
            L.push('', '— 设置面板里加的 —');
            fromConfig.forEach((e, i) => L.push(`${i + 1}. ${e.q}${e.keywords.length ? `（关键词：${e.keywords.join('、')}）` : ''}`));
          }
          if (fileEntries.length) {
            L.push('', `— ${s.localFile} 里的 —`);
            fileEntries.forEach((e, i) => L.push(`${i + 1}. ${e.q}`));
          }
          return { content: L.join('\n') };
        }

        const query = String(args?.query ?? '').trim();
        if (!query) return { content: 'query 不能为空', isError: true };
        const found = findLocalAnswer(query);
        return { content: renderLocal({ query, found, file: found.file }) };
      } catch (error) {
        return { content: `查本地问答时出错：${error?.message ?? error}`, isError: true };
      }
    },
  });
}

/**
 * NGA 功能开/关时，往提示词里插一段"当前状态"，让模型立刻知道该不该用 nga_fetch。
 * ⚠️ 不能把 nga_fetch 做成"关了就让整个技能不可用"：可用性是**技能级**的，
 *    那样会连 gbf_wiki / gbf_page / gbf_local 一起失效（技能变红、工具全没）。
 *    所以开关在**工具执行时**强制（见 nga_fetch 的 ready 判定），这里只是提前告知。
 */
export function promptSections() {
  const r = ngaReady();
  if (r.ok) {
    return [{
      id: 'gbf-nga-status',
      title: 'NGA 帖子查询：已开启',
      priority: 39,
      content: 'NGA 帖子查询**已开启**。群友贴 NGA 链接（bbs.nga.cn / ngabbs.com 的 read.php、thread.php）时，'
        + '用 nga_fetch 读那个帖子再回答；明确问「NGA 上怎么说」时也可以用它。'
        + '记得说明这是玩家论坛的说法，数值/时间优先以灰机维基为准。',
    }];
  }
  const why = r.why === 'nokey' ? '登录 Cookie 还没填'
    : (r.why === 'nottl' ? '「NGA 内容缓存时间」不合法（必须大于 0）' : '主人没有勾选「开启 NGA 帖子查询」');
  return [{
    id: 'gbf-nga-status',
    title: 'NGA 帖子查询：已关闭',
    priority: 39,
    content: `NGA 帖子查询**当前是关闭的**（原因：${why}）。`
      + '所以**不要**调用 nga_fetch。'
      + '群友贴 NGA 链接时，如实说「NGA 查询功能没开」，然后改用 gbf_wiki / gbf_page 去灰机中文维基查同样的内容；'
      + '**绝对不要**假装读过那个 NGA 帖子，也不要凭印象编 NGA 上的说法。',
  }];
}

/** 自检：同步返回。curl 缺失时给出可读原因（首次乐观放行 + 缓存结果）。 */
let curlOk = null;
let probing = false;
export function available() {
  if (curlOk === null && !probing) {
    probing = true;
    const { timeoutMs, curlPath } = settings();
    curlGet(`${DEFAULT_BASE}/api.php?action=query&meta=siteinfo&format=json`, { timeoutMs: Math.min(timeoutMs, 15000), curlPath })
      .then((r) => { curlOk = r.ok && !isChallenge(r.body); })
      .catch(() => { curlOk = false; });
  }
  if (curlOk === false) {
    return { ok: false, reason: '抓不到维基（需要系统 curl.exe，且网络要对 gbf.huijiwiki.com 通）' };
  }
  return true;   // 首次乐观放行
}

export function dispose() {
  cache = null;
  curlOk = null;
  probing = false;
}
