// 本地曲库点歌 —— 把 data/music-library/ 里的音频变成群友能点的歌。
//
// 三件事：
//   1. 找歌：递归扫曲库、按文件名打分；有歧义就报候选让群里挑，不乱放。
//   2. 放歌：手动高潮 > 已缓存切片 > 自动判高潮 > 比例兜底，先发高潮段语音；
//      语音发不出、或有人要完整版，就发整首音频文件。
//   3. 定高潮：只有主人 / editQq 白名单能改，改完立刻重切并写 highlights.json
//      （手改同一个文件同样生效，每读一次现读，不缓存句柄）。
//
// 缓存全在 data/music-library/.clips/，按源文件指纹（路径+大小+mtime）失效 —— 切过一次就不再切。
// 曲库、登记表、缓存都必须落在 DATA_DIR 下：skills/ 目录被 fs.watch 监听，
// 运行期往里写文件会反复触发热重载，还会把自己的产物扫成曲目。
import fs from 'node:fs';
import path from 'node:path';
import * as store from './lib/store.js';
import * as analyze from './lib/analyze.js';

let cfg = () => ({});
let cap = null;
let log = () => {};
let warn = () => {};

const nowText = () => new Date().toLocaleTimeString('zh-CN', { hour12: false });
const clampNum = (v, lo, hi, dflt) => {
  const n = Number(v);
  return Number.isFinite(n) ? Math.min(hi, Math.max(lo, n)) : dflt;
};

export function setup(api) {
  cfg = typeof api.config === 'function' ? api.config : () => ({});
  cap = typeof api.capability === 'function' ? api.capability : null;
  log = api.log || (() => {});
  warn = api.warn || (() => {});

  registerSearch(api);
  registerPlay(api);
  registerHighlight(api);
}

/**
 * 自检：曲库目录不可写才判定不可用。
 * 刻意不检查 ffmpeg —— available() 返回 ok:false 会把整个技能连工具一起隐藏
 * （skills/manager.js 的 isAvailable），而 ffmpeg 缺失时我们还能发整首文件。
 */
export function available() {
  try {
    const dir = store.libDir(cfg());
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    fs.accessSync(dir, fs.constants.W_OK);
    return { ok: true };
  } catch (error) {
    return { ok: false, reason: `曲库目录不可写：${error?.message ?? error}` };
  }
}

// ── 共用 ────────────────────────────────────────────────────────────────────

function settings() {
  const c = cfg() || {};
  return {
    dir: store.libDir(c),
    clips: store.clipsDir(c),
    clipSeconds: Math.round(clampNum(c.clipSeconds, 10, 120, 30)),
    startPct: clampNum(c.searchStartPct, 0, 90, 15),
    endPct: clampNum(c.searchEndPct, 10, 100, 85),
    matchSilence: c.matchSilence !== false,
    fallbackRatio: clampNum(c.fallbackRatio, 0, 1, 0.4),
    editQq: String(c.editQq ?? '')
      .split(/[,，;；\s]+/)
      .map((s) => s.trim())
      .filter((s) => /^\d{5,15}$/.test(s)),
    maxClips: Math.round(clampNum(c.maxClips, 0, 10000, 0))
  };
}

function windowOpts(s, seconds) {
  return {
    seconds,
    startPct: s.startPct,
    endPct: s.endPct,
    matchSilence: s.matchSilence,
    count: 3
  };
}

function markSent(ctx, text, type = 'voice') {
  try {
    ctx.session?.sent?.push({ type, text, at: nowText() });
  } catch { /* 记账失败不影响已发出的消息 */ }
  try {
    ctx.emit?.('session-update', ctx.session?.id);
  } catch { /* 同上 */ }
}

function isDuplicateMsg(msg) {
  return /刚发过|重复刷屏|短时间内/.test(String(msg ?? ''));
}

// ── 单一出口闸：同一轮里语音和卡片/文件只能来一种 ─────────────────────────

/** 本轮（本 session）已发出的消息记账。session 是「一条用户消息」级别的，见 orchestrator。 */
function sentMedia(ctx) {
  const list = ctx?.session?.sent;
  return Array.isArray(list) ? list : [];
}

/** 记账文本里抽歌名：「[音乐] 晴天」「[音乐:晴天]」「[文件] 晴天.mp3」。 */
function sentName(entry) {
  const raw = String(entry?.text ?? '');
  const m = raw.match(/^\[(?:音乐|文件)[:\s\]]+\s*([^\]]+)\]?/);
  const name = (m ? m[1] : raw).trim();
  return name.replace(/\.[^.]+$/, '');
}

/** 归一化后互相包含且至少 2 字 → 认作同一首（复用 store.normName，不另起炉灶）。 */
function sameSong(a, b) {
  const x = store.normName(a);
  const y = store.normName(b);
  if (x.length < 2 || y.length < 2) return false;
  return x.includes(y) || y.includes(x);
}

/** 这条用户消息里是否明确要了「另一种出口」（完整版/链接/在线/卡片/下载）。 */
function wantsOther(ctx) {
  try {
    const entries = Array.isArray(ctx?.session?.trigger) ? ctx.session.trigger : [];
    const text = entries.map((m) => String(m?.text ?? '')).join(' ');
    return /链接|完整|整首|全程|在线|卡片|发卡|文件|下载|地址|http/i.test(text);
  } catch {
    return false;
  }
}

/**
 * 命中则本轮不该再发：`kinds` 里列出的记账类型中已有同名一条。
 * 例外：用户这条消息明说了要另一种形式 → 放行（否则「要完整版」会被自己拦死）。
 */
function blockedBySingleExit(ctx, kinds, stem) {
  if (wantsOther(ctx)) return null;
  for (const e of sentMedia(ctx)) {
    const t = String(e?.type ?? '');
    if (!kinds.includes(t)) continue;
    if (sameSong(sentName(e), stem)) return { type: t, text: String(e?.text ?? '') };
  }
  return null;
}


/** 本轮最后一位非机器人发言人（senderId 是协议字段，不是聊天正文）。 */
function lastSpeaker(ctx) {
  try {
    const entries = Array.isArray(ctx?.session?.trigger) ? ctx.session.trigger : [];
    for (let i = entries.length - 1; i >= 0; i--) {
      const m = entries[i];
      if (m && !m.self && m.senderId) return String(m.senderId);
    }
  } catch { /* 拿不到就算了 */ }
  return '';
}

async function canEdit(s, ctx) {
  const uid = lastSpeaker(ctx);
  if (!uid || uid === 'self') return { ok: false, uid, why: '拿不到发言人的 QQ 号' };
  if (s.editQq.includes(uid)) return { ok: true, uid, via: '白名单' };
  if (cap) {
    try {
      const r = cap('message.owner-check', { userId: uid });
      const v = r && typeof r.then === 'function' ? await r : r;
      if (v && v.isOwner) return { ok: true, uid, via: '主人' };
    } catch { /* 没装主人识别插件就当不是主人 */ }
  }
  return { ok: false, uid, why: `QQ ${uid} 不在可修改名单里` };
}

const DENY_TEXT = '改高潮会直接影响所有人听到的段落，只有主人、或技能设置里 editQq 名单中的 QQ 能改。可以把「歌名 + 想要的起点时间」转告主人，让 TA 来定。';

/** 找歌。error 里 empty=true 表示"曲库本身是好的，只是没这首"（不算失败，模型好回退在线点歌）。 */
function resolveSong(s, query, limit) {
  if (!fs.existsSync(s.dir)) {
    return {
      error: `曲库目录还不存在：${s.dir}\n把音频文件（mp3 / flac / wav / m4a / ogg / aac / opus…）丢进这个目录或它的子文件夹，就能点歌。\n本地没歌可发 → 这是唯一该走在线点歌/发卡片的情况；上面这行目录路径只给主人看，别贴进群。`
    };
  }
  const items = store.scanLibrary(s.dir);
  if (!items.length) {
    return {
      error: `曲库是空的（${s.dir}）。先往里放几首歌。\n本地没歌可发 → 这是唯一该走在线点歌/发卡片的情况；目录路径别贴进群。`,
      empty: true
    };
  }
  const matches = store.matchSongs(items, query, limit);
  if (!matches.length) {
    return {
      error: `本地曲库没有「${query}」（共 ${items.length} 首）。换个关键词，或走在线点歌。\n本地匹配不到 → 这是唯一该发在线卡片/链接的情形，可以调 send_music；别贴本地路径。`,
      empty: true
    };
  }
  return { items, matches, target: store.pickTarget(matches) };
}

async function describeMatches(s, matches) {
  const hl = store.readHighlights(s.dir);
  const lines = [];
  for (const m of matches) {
    const key = store.songKey(m);
    const duration = store.cachedProbe(s.clips, key, m) || await analyze.ensureDuration(m, s.clips);
    const h = store.findHighlight(hl, m.base);
    const bits = [];
    if (duration) bits.push(store.fmtTime(duration));
    bits.push(h ? `手动高潮 ${store.fmtTime(h.start)}${h.seconds ? ` 起 ${h.seconds}s` : ''}` : '自动判高潮');
    const clipSec = s.clipSeconds;
    const hasClip = fs.existsSync(store.clipFiles(s.clips, key, h?.seconds || clipSec).wav);
    bits.push(hasClip ? '已切好' : '未切');
    lines.push(`- ${m.base}（${bits.join('，')}）`);
  }
  return lines;
}

/** 源文件被换过之后，key 会变；改高潮只删切片，曲线和时长缓存留着。 */
function invalidateSong(s, item) {
  const key = store.songKey(item);
  let names = [];
  try {
    names = fs.readdirSync(s.clips);
  } catch {
    return 0;
  }
  let n = 0;
  for (const name of names) {
    if (!name.startsWith(`${key}.`)) continue;
    if (name.endsWith('.curve.json') || name.endsWith('.probe.json')) continue;
    try {
      fs.unlinkSync(path.join(s.clips, name));
      n++;
    } catch { /* 删不掉就留着 */ }
  }
  return n;
}

/**
 * 产出一段可发的语音切片。
 * 返回 wav=null 表示切不出来（ffmpeg 缺失 / 文件坏）—— 调用方据此降级到发文件。
 */
async function prepareClip(s, item, { seconds = null, force = false } = {}) {
  const key = store.songKey(item);
  const hl = store.findHighlight(store.readHighlights(s.dir), item.base);

  let sec = Number(seconds) > 0 ? Math.round(Number(seconds)) : s.clipSeconds;
  if (!(Number(seconds) > 0) && hl?.seconds) sec = Math.round(hl.seconds);
  sec = Math.min(120, Math.max(5, sec));

  let curve = null;
  try {
    curve = await analyze.ensureCurve(item, s.clips);
  } catch (error) {
    warn('分析 %s 失败：%s', item.base, error?.message ?? error);
  }

  let duration = curve?.duration || store.cachedProbe(s.clips, key, item) || 0;
  let mode = 'auto';
  let start = null;

  if (hl) {
    start = hl.start;
    mode = 'manual';
  }
  if (curve) {
    if (start === null) {
      const w = analyze.pickWindows(curve, windowOpts(s, sec))[0];
      if (w) {
        start = w.start;
        mode = 'auto';
      } else {
        start = curve.duration * s.fallbackRatio;
        mode = 'ratio';
      }
    }
    duration = curve.duration;
  } else {
    if (!(duration > 0)) duration = await analyze.ensureDuration(item, s.clips) || 0;
    if (start === null) {
      start = duration * s.fallbackRatio;
      mode = 'ratio';
    }
  }

  start = duration > 0
    ? Math.min(Math.max(0, start), Math.max(0, duration - sec))
    : Math.max(0, start);
  start = Math.round(start * 100) / 100;

  const files = store.clipFiles(s.clips, key, sec);
  const expect = { key, start, seconds: sec };
  if (!force && store.clipUsable(files.wav, store.readJson(files.meta), expect)) {
    return { wav: files.wav, start, seconds: sec, mode, cached: true, duration, manual: Boolean(hl) };
  }

  fs.mkdirSync(s.clips, { recursive: true });
  const tc = await analyze.toolchain();
  if (!tc?.ok) {
    return { wav: null, start, seconds: sec, mode, cached: false, duration, manual: Boolean(hl), reason: '没找到 ffmpeg，切不了语音段' };
  }
  const ok = await analyze.cutClip(item.file, files.wav, start, sec);
  if (!ok) {
    return { wav: null, start, seconds: sec, mode, cached: false, duration, manual: Boolean(hl), reason: 'ffmpeg 切片失败' };
  }
  try {
    store.writeJsonAtomic(files.meta, {
      v: 1,
      key,
      start,
      seconds: sec,
      mode,
      src: item.file,
      size: item.size,
      mtime: Math.round(item.mtime),
      at: new Date().toISOString()
    });
    const removed = store.pruneClips(s.clips, s.maxClips);
    if (removed) log('按 maxClips=%d 清理了 %d 个旧切片文件', s.maxClips, removed);
  } catch (error) {
    warn('写切片 meta 失败：%s', error?.message ?? error);
  }
  return { wav: files.wav, start, seconds: sec, mode, cached: false, duration, manual: Boolean(hl) };
}

const MODE_TEXT = { manual: '手动设定', auto: '自动判定', ratio: '比例兜底' };

// ── 工具 1：查曲库 ──────────────────────────────────────────────────────────

function registerSearch(api) {
  api.registerTool({
    id: 'search_local_music',
    name: '查本地曲库',
    description: '在本地曲库（data/music-library）按歌名找歌，返回命中的文件、时长、有没有手动设高潮、有没有切好片。点歌前先用它确认本地有没有；唯一命中时可直接播，不用再问一遍。命中→只发语音；本地没有→才可以走在线点歌发卡片/链接。',
    category: 'media',
    parameters: {
      type: 'object',
      properties: {
        query: { type: 'string', description: '歌名关键词，可带歌手，如「晴天」「周杰伦 晴天」' },
        limit: { type: 'number', description: '最多返回几条，默认 8' }
      },
      required: ['query']
    },
    async execute(ctx, args) {
      try {
        const s = settings();
        const q = String(args?.query ?? '').trim();
        if (!q) return { content: '缺 query：想找哪首歌？', isError: true };
        const r = resolveSong(s, q, Math.round(clampNum(args?.limit, 1, 20, 8)));
        if (r.error) return { content: r.error, isError: !r.empty };
        const total = store.scanLibrary(s.dir).length;
        const body = await describeMatches(s, r.matches);
        return {
          content: [
            `曲库共 ${total} 首，命中 ${r.matches.length} 条：`,
            ...body,
            '本地命中 → 接下来只调 play_local_music 发高潮段语音；别再调 send_music，别贴链接、卡片或本地路径。'
          ].join('\n'),
          isError: false
        };
      } catch (error) {
        return { content: `查曲库失败：${error?.message ?? error}`, isError: true };
      }
    }
  });
}

// ── 工具 2：放歌 ────────────────────────────────────────────────────────────

function registerPlay(api) {
  api.registerTool({
    id: 'play_local_music',
    name: '放本地曲库的歌',
    description: '本地曲库点歌：取手动高潮或自动判定的最响段切成 30 秒发语音；语音发不出、或对方明确要完整版时改发整首音频文件。同一首歌切过一次就走缓存，不会重复切。多个同名候选时会返回列表让群里挑。命中并发完之后本轮就结束——不要再调 send_music、不要贴链接或本地路径（单一出口）。',
    category: 'media',
    parameters: {
      type: 'object',
      properties: {
        query: { type: 'string', description: '歌名关键词，可带歌手' },
        seconds: { type: 'number', description: '这次想要的段长（秒），只影响本次，不改默认设置' },
        mode: {
          type: 'string',
          enum: ['auto', 'voice', 'file'],
          description: 'auto=默认（先语音，失败转文件）；voice=只发高潮段语音；file=直接发完整文件'
        }
      },
      required: ['query']
    },
    async execute(ctx, args) {
      try {
        const s = settings();
        const q = String(args?.query ?? '').trim();
        if (!q) return { content: '缺 query：要放哪首歌？', isError: true };
        const r = resolveSong(s, q, 12);
        if (r.error) return { content: r.error, isError: !r.empty };
        if (!r.target) {
          const body = await describeMatches(s, r.matches.slice(0, 6));
          return {
            content: [
              `本地有 ${r.matches.length} 首像「${q}」的，要放哪首？回我文件名或歌名就行：`,
              ...body,
              '挑定之前什么都别发：不发语音、不发卡片、不贴链接。'
            ].join('\n'),
            isError: false
          };
        }

        const item = r.target;
        // 单一出口：本轮已经发过同名的卡片/文件 → 不再补语音（用户明说要另一种时放行）
        const dup = blockedBySingleExit(ctx, ['music', 'file'], item.base);
        if (dup) {
          return {
            content: `本轮已经发过同名的${dup.type === 'music' ? '音乐卡片' : '完整文件'}（${dup.text}），按单一出口规则不再补发语音。真要换形式，请让用户在新的一条消息里明说（「要完整版」「要链接」）。`,
            isError: false
          };
        }

        const key = store.songKey(item);
        const mode = ['auto', 'voice', 'file'].includes(args?.mode) ? args.mode : 'auto';
        const seconds = Number(args?.seconds) > 0 ? Number(args?.seconds) : null;
        const label = `[音乐] ${item.base.replace(/\.[^.]+$/, '')}`;

        let clip = null;
        let clipNote = '';
        if (mode !== 'file') {
          clip = await prepareClip(s, item, { seconds });
          if (!clip.wav && mode === 'voice') {
            return {
              content: `切不出「${item.base}」的高潮段（${clip.reason || '原因未知'}）。改用 mode='file' 发完整文件——这是「匹配不到语音」的合法出口，不是失败。`,
              isError: true
            };
          }
          if (!clip.wav) clipNote = `（切不出高潮段：${clip.reason || '原因未知'}）`;
        }

        if (clip?.wav) {
          try {
            await ctx.sender.sendMedia(
              ctx.chatKey,
              [{ type: 'record', data: { file: clip.wav } }],
              { label, dedupeKey: `music:${key}:${clip.start}:${clip.seconds}` }
            );
            markSent(ctx, label, 'voice');
            const src = `${MODE_TEXT[clip.mode] || clip.mode}${clip.cached ? '，缓存未重切' : ''}`;
            return {
              content: [
                `已放「${label.slice(4)}」${store.fmtTime(clip.start)} 起 ${clip.seconds}s（${src}）。`,
                '本轮点歌到此结束：不要再调 send_music / 在线点歌，不要贴链接、本地路径，也不要复述歌名。'
                + '用户之后要「完整版」或「链接」，再用 mode=\'file\' 或交给在线点歌。'
              ].join('\n'),
              isError: false
            };
          } catch (error) {
            const msg = String(error?.message ?? error);
            if (isDuplicateMsg(msg)) {
              return { content: `「${label.slice(4)}」刚才已经放过一遍了，过几秒再点。`, isError: false };
            }
            warn('语音发送失败，转文件：%s', msg);
          }
        }

        // 语音这条走不通（或明确要文件） → 发完整文件
        const name = path.basename(item.file);
        try {
          await ctx.sender.sendMedia(
            ctx.chatKey,
            [{ type: 'file', data: { file: item.file, name } }],
            { label: `[文件] ${name}`, dedupeKey: `music-file:${key}` }
          );
          markSent(ctx, `[文件] ${name}`, 'file');
          const head = mode === 'file'
            ? `已发完整文件：${name}`
            : clipNote
              ? `已发完整文件${clipNote}：${name}`
              : `语音没发出去，改成发完整文件：${name}`;
          return {
            content: [
              head,
              '单一出口：本轮只发这一条，别再补语音、音乐卡片、链接或歌名；用户要在线链接时再交给点歌技能。'
            ].join('\n'),
            isError: false
          };
        } catch (error) {
          const msg = String(error?.message ?? error);
          if (isDuplicateMsg(msg)) {
            return { content: `${name} 刚发过了，过几秒再点。`, isError: false };
          }
          warn('文件段发送失败：%s', msg);
        }

        if (ctx.kind === 'group' && typeof ctx.onebot?.call === 'function') {
          try {
            await ctx.onebot.call('upload_group_file', {
              group_id: Number(ctx.chatId),
              file: item.file,
              name
            }, 60000);
            markSent(ctx, `[文件] ${name}`, 'file');
            return {
              content: [
                `已用群文件方式发出：${name}`,
                '单一出口：本轮只发这一条，别再补语音、卡片、链接或歌名。'
              ].join('\n'),
              isError: false
            };
          } catch (error) {
            warn('upload_group_file 失败：%s', error?.message ?? error);
          }
        }
        warn('整首文件发送失败，文件在 %s', item.file);
        return {
          content: `把「${name}」发到群里失败了。文件已留在曲库目录（路径不进群，别贴到群里）。可以改用 send_music 发在线链接。`,
          isError: true
        };
      } catch (error) {
        return { content: `放歌失败：${error?.message ?? error}`, isError: true };
      }
    }
  });
}

// ── 工具 3：设定高潮 ────────────────────────────────────────────────────────

function registerHighlight(api) {
  api.registerTool({
    id: 'set_local_highlight',
    name: '设定歌曲高潮段',
    description: '手动指定某首歌的高潮段，只有主人或 editQq 白名单能改。三种用法：给 start（如 1:05 或 65）直接定；不给参数让它返回 3 个候选段、用户说「选第 2 个」时传 choice=2；auto=true 恢复自动判定。改完立刻重切并写入 data/music-library/highlights.json（手改该文件同样生效）。',
    category: 'media',
    parameters: {
      type: 'object',
      properties: {
        query: { type: 'string', description: '歌名关键词，可带歌手' },
        start: { type: 'string', description: '高潮起点，如「1:05」「65」；不填则先要候选段' },
        seconds: { type: 'number', description: '段长秒数，默认用技能设置的 clipSeconds；会一并存进登记表' },
        choice: { type: 'number', description: '选第几个候选（1~3），与 start 二选一' },
        auto: { type: 'boolean', description: 'true = 删掉手动设定，恢复自动判定' }
      },
      required: ['query']
    },
    async execute(ctx, args) {
      try {
        const s = settings();
        const q = String(args?.query ?? '').trim();
        if (!q) return { content: '缺 query：要改哪首歌？', isError: true };

        const gate = await canEdit(s, ctx);
        if (!gate.ok) return { content: `${gate.why}。${DENY_TEXT}`, isError: true };

        const r = resolveSong(s, q, 8);
        if (r.error) return { content: r.error, isError: !r.empty };
        if (!r.target) {
          const body = await describeMatches(s, r.matches.slice(0, 6));
          return { content: `「${q}」有 ${r.matches.length} 个候选，要改哪首？\n${body.join('\n')}`, isError: false };
        }
        const item = r.target;

        if (args?.auto === true) {
          const hl = store.readHighlights(s.dir);
          const hit = store.findHighlight(hl, item.base);
          if (hit) {
            delete hl[hit.key];
            store.writeHighlights(s.dir, hl);
          }
          invalidateSong(s, item);
          const clip = await prepareClip(s, item, {});
          return {
            content: clip.wav
              ? `已恢复「${item.base}」自动判定：${store.fmtTime(clip.start)} 起 ${clip.seconds}s，已重切缓存。`
              : `已删除「${item.base}」的手动设定；ffmpeg 不可用，下次点歌再切。`,
            isError: false
          };
        }

        let curve = null;
        try {
          curve = await analyze.ensureCurve(item, s.clips);
        } catch (error) {
          warn('分析 %s 失败：%s', item.base, error?.message ?? error);
        }

        const startArg = args?.start;
        const hasStart = startArg !== undefined && startArg !== null && String(startArg).trim() !== '';
        const choice = Math.round(Number(args?.choice) || 0);
        let chosen = null;

        // 没曲线就没法挑候选段；但用户直接报了起点时间的照样收（切不切得出来另说）
        if (!curve && !hasStart) {
          return {
            content: `分析不出「${item.base}」的响度曲线（没音轨 / 文件损坏 / ffmpeg 不可用），没法给候选段。可以直接报起点时间，我按比例兜底切。`,
            isError: false
          };
        }

        const existing = store.findHighlight(store.readHighlights(s.dir), item.base);
        let sec = Number(args?.seconds) > 0
          ? Math.round(Number(args?.seconds))
          : (existing?.seconds || s.clipSeconds);
        sec = Math.min(120, Math.max(5, sec));

        if (hasStart) {
          chosen = store.parseTime(startArg);
          if (chosen === null) {
            return { content: `起点「${startArg}」看不懂，用「1:05」或「65」这样的写法。`, isError: true };
          }
        } else if (choice >= 1) {
          const cands = analyze.pickWindows(curve, windowOpts(s, sec));
          if (!cands[choice - 1]) {
            return {
              content: `只有 ${cands.length} 个候选，没有第 ${choice} 个：\n${renderCandidates(curve, cands)}`,
              isError: true
            };
          }
          chosen = cands[choice - 1].start;
        } else {
          const cands = analyze.pickWindows(curve, windowOpts(s, sec));
          if (!cands.length) {
            return { content: `「${item.base}」算不出候选段，直接报起点时间（如 1:05）我来定。`, isError: false };
          }
          return {
            content: [
              `「${item.base}」全长 ${store.fmtTime(curve.duration)}，给你 ${cands.length} 个最响的候选段。`,
              renderCandidates(curve, cands),
              '回「选第 2 个」这样的答复，或直接给起点时间（1:05）。'
            ].join('\n'),
            isError: false
          };
        }

        const duration = curve?.duration || 0;
        const start = duration > 0
          ? Math.min(Math.max(0, chosen), Math.max(0, duration - sec))
          : Math.max(0, chosen);
        const rounded = Math.round(start * 10) / 10;
        const stats = curve ? analyze.windowStats(curve, rounded, sec) : null;

        const all = store.readHighlights(s.dir);
        const targetKey = existing?.key || item.base;
        all[targetKey] = {
          start: rounded,
          seconds: sec,
          note: String(args?.note ?? '').slice(0, 60),
          updatedAt: new Date().toISOString(),
          by: gate.uid
        };
        store.writeHighlights(s.dir, all);
        invalidateSong(s, item);
        const clip = await prepareClip(s, item, {});

        const lines = [
          `已设定「${item.base}」高潮 = ${store.fmtTime(rounded)} 起 ${sec}s（${gate.via} QQ:${gate.uid} 存进 highlights.json）`
        ];
        if (Math.abs(rounded - chosen) > 0.05) {
          lines.push(`你给的 ${store.fmtTime(chosen)} 超出可用范围，已收到 ${store.fmtTime(rounded)}（全曲 ${store.fmtTime(duration)}）。`);
        }
        if (stats) {
          const rel = stats.rel;
          lines.push(rel >= -1
            ? `该段平均 ${stats.avg.toFixed(1)} LUFS，比全曲均值 ${rel >= 0 ? '+' : ''}${rel.toFixed(1)}。`
            : `注意：该段平均 ${stats.avg.toFixed(1)} LUFS，比全曲均值 ${rel.toFixed(1)}（明显更安静）。仍然按你说的设了，如果不是想要的段，重新给我时间点。`);
        }
        lines.push(clip.wav
          ? `已重切并缓存${clip.cached ? '（本来就是这段，没重复切）' : ''}，下次点歌直接用。`
          : '设定已保存，但 ffmpeg 不可用，暂时切不出语音段。');
        return { content: lines.join('\n'), isError: false };
      } catch (error) {
        return { content: `设定高潮失败：${error?.message ?? error}`, isError: true };
      }
    }
  });
}

function renderCandidates(curve, list) {
  return list.map((c, i) => {
    const len = Math.round((c.end ?? c.start) - c.start);
    const rel = Number(c.rel ?? 0);
    return `${i + 1}. ${store.fmtTime(c.start)} 起 ${len}s（平均 ${Number(c.avg).toFixed(1)} LUFS，比全曲均值 ${rel >= 0 ? '+' : ''}${rel.toFixed(1)}）`;
  }).join('\n');
}
