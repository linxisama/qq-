// 换头像 —— 把用户刚发来的那张图换成机器人自己的 QQ 头像，用完即删。
//
// 为什么放在 skills/（LLM 型）而不是 plugins/（确定性型）：
//   「用户是不是在明确要求用这张图当头像」是语义判断，只能由模型来做。
//   确定性型插件没有「进模型工具列表」的入口，模型看不见，也就永远不会触发。
//
// 流程（对应需求：下载 → 换头像 → 删图片）：
//   1. 从本轮触发消息里找图片段（data.url / data.file），没有就回看最近聊天记录
//   2. 下载到系统临时目录（有大小上限，并校验文件头确实是图片）
//   3. ctx.onebot.call('set_qq_avatar', { file }) —— SnowLuma 的扩展动作
//   4. finally 里无条件删掉临时文件（换失败也删，不在磁盘上留图）
//
// 注意：set_qq_avatar 不在 onebot.js 的 SLOW_ACTION 白名单里，默认只给 15 秒；
// 头像上传要走「接收 body → 上传腾讯」，这里显式传更长的超时，否则大图必超时。

import fsp from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { randomBytes } from 'node:crypto';

const DEFAULT_MAX_MB = 10;
const DOWNLOAD_TIMEOUT_MS = 30000;
const AVATAR_TIMEOUT_MS = 120000;

// QQ 图床（multimedia.nt.qq.com.cn / gchat.qpic.cn）对无 UA 的请求经常直接 RST，
// 伪装成浏览器再带个 Referer，成功率明显更高。
const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36';

let cfg = () => ({});
let httpFetch = null;

// ── 小工具 ──────────────────────────────────────────────────────────────

function clamp(n, lo, hi) {
  const v = Number(n);
  if (!Number.isFinite(v)) return lo;
  return Math.min(hi, Math.max(lo, Math.round(v)));
}

function fmtSize(bytes) {
  const n = Number(bytes) || 0;
  if (n < 1024) return `${n} B`;
  if (n < 1024 * 1024) return `${(n / 1024).toFixed(1)} KB`;
  return `${(n / 1024 / 1024).toFixed(2)} MB`;
}

/** 按文件头判断真实格式 —— 不信 Content-Type，更不信扩展名。 */
function sniffImage(buf) {
  const b = buf;
  if (b.length >= 3 && b[0] === 0xff && b[1] === 0xd8 && b[2] === 0xff) return { ext: 'jpg', label: 'JPEG' };
  if (b.length >= 8 && b[0] === 0x89 && b[1] === 0x50 && b[2] === 0x4e && b[3] === 0x47) return { ext: 'png', label: 'PNG' };
  if (b.length >= 6) {
    const head6 = b.toString('ascii', 0, 6);
    if (head6 === 'GIF87a' || head6 === 'GIF89a') return { ext: 'gif', label: 'GIF' };
  }
  if (b.length >= 12 && b.toString('ascii', 0, 4) === 'RIFF' && b.toString('ascii', 8, 12) === 'WEBP') {
    return { ext: 'webp', label: 'WebP' };
  }
  if (b.length >= 2 && b[0] === 0x42 && b[1] === 0x4d) return { ext: 'bmp', label: 'BMP' };
  return null;
}

/** 一条存档消息里的图片段。 */
function imagesOfMessage(msg) {
  const out = [];
  for (const m of Array.isArray(msg?.media) ? msg.media : []) {
    if (!m || m.kind !== 'image') continue;
    const url = String(m.url || '').trim();
    const file = String(m.file || '').trim();
    if (!url && !file) continue;
    out.push({
      url,
      file,
      senderId: String(msg?.senderId || ''),
      senderName: String(msg?.senderName || ''),
      text: String(msg?.text || ''),
      atMe: msg?.atMe === true
    });
  }
  return out;
}

/**
 * 收集候选图，按时间从早到晚排列。
 * 优先「本轮触发的消息」（含 @ 的那批），没有再看最近 30 条聊天记录 ——
 * 用户常把图单独发一条、再补一句「@机器人 用这张当头像」。
 */
function collectCandidates(ctx) {
  const seen = new Set();
  const out = [];
  const add = (img, source) => {
    const key = img.url || img.file;
    if (!key || seen.has(key)) return;
    seen.add(key);
    out.push({ ...img, source });
  };

  const trigger = Array.isArray(ctx?.session?.trigger) ? ctx.session.trigger : [];
  for (const m of trigger) for (const img of imagesOfMessage(m)) add(img, '本轮消息');

  if (!out.length) {
    let recent = [];
    try {
      recent = ctx?.store?.recent?.(ctx.chatKey, { limit: 30 }) || [];
    } catch { recent = []; }
    for (const m of [...recent].reverse()) for (const img of imagesOfMessage(m)) add(img, '最近聊天记录');
  }
  return out;
}

/** 选图：默认优先「@ 了机器人的那条消息」里的最后一张，否则用最新一张。 */
function pickCandidate(list, args) {
  const idx = Number(args?.image_index);
  if (Number.isInteger(idx) && idx >= 1 && idx <= list.length) return { item: list[idx - 1], index: idx };
  for (let i = list.length - 1; i >= 0; i--) {
    if (list[i].atMe) return { item: list[i], index: i + 1 };
  }
  return { item: list[list.length - 1], index: list.length };
}

/** 只有 data.file 没有 url 时，问协议端要一个能下载的地址。 */
async function resolveImageUrl(ctx, item) {
  if (item.url) return item.url;
  if (typeof ctx?.onebot?.call !== 'function') throw new Error('拿不到 OneBot 连接');
  const got = await ctx.onebot.call('get_image', { file: item.file });
  const url = String(got?.url || '').trim();
  if (url) return url;
  const file = String(got?.file || '').trim();
  if (/^https?:\/\//i.test(file)) return file;
  throw new Error('这条图片消息拿不到可下载的地址（可能已过期）');
}

/** 流式下载并强制大小上限，避免把几十 MB 的原图整个读进内存。 */
async function fetchImageBuffer(url, maxBytes) {
  if (typeof httpFetch !== 'function') throw new Error('缺少 web_fetch 权限（skill.json 的 permissions 被删了？）');

  let res;
  try {
    res = await httpFetch(url, {
      method: 'GET',
      redirect: 'follow',
      headers: { 'User-Agent': UA, Accept: 'image/*,*/*;q=0.8', Referer: 'https://qun.qq.com/' },
      signal: AbortSignal.timeout(DOWNLOAD_TIMEOUT_MS)
    });
  } catch (error) {
    const t = String(error?.name || '') + String(error?.message || '');
    throw new Error(/timeout|abort/i.test(t) ? `图片下载超时（${DOWNLOAD_TIMEOUT_MS / 1000} 秒）` : `图片下载失败：${error?.message ?? error}`);
  }
  if (!res.ok) throw new Error(`图片下载失败：HTTP ${res.status}`);

  const declared = Number(res.headers.get('content-length') || 0);
  if (declared && declared > maxBytes) throw new Error(`图片太大（${fmtSize(declared)}，上限 ${fmtSize(maxBytes)}）`);

  const reader = res.body?.getReader ? res.body.getReader() : null;
  if (!reader) {
    const buf = Buffer.from(await res.arrayBuffer());
    if (buf.length > maxBytes) throw new Error(`图片太大（${fmtSize(buf.length)}，上限 ${fmtSize(maxBytes)}）`);
    return buf;
  }

  const chunks = [];
  let total = 0;
  try {
    for (;;) {
      const { done, value } = await reader.read();
      if (done) break;
      if (!value) continue;
      total += value.byteLength;
      if (total > maxBytes) {
        await reader.cancel().catch(() => {});
        throw new Error(`图片太大（已超过 ${fmtSize(maxBytes)} 上限）`);
      }
      chunks.push(Buffer.from(value));
    }
  } finally {
    try { reader.releaseLock(); } catch { /* ignore */ }
  }
  return Buffer.concat(chunks);
}

/** 开启「仅指定 QQ」时的白名单判断。 */
function denyReasonByOwner(item) {
  if (cfg().ownerOnly !== true) return '';
  const allow = String(cfg().ownerQQ || '').split(/[\s,，、;；]+/).filter(Boolean);
  const sender = String(item?.senderId || '');
  if (sender && allow.includes(sender)) return '';
  return `已开启「仅指定 QQ 可换头像」，${sender || '当前发送者'} 不在允许名单里`;
}

/** 把 OneBot / SnowLuma 的原始报错翻译成能让人看懂的一句话。 */
function explainError(error) {
  const msg = String(error?.message ?? error ?? '未知错误');
  if (/timeout|超时|AbortError/i.test(msg)) return '上传头像超时（协议端 2 分钟没传完）';
  if (/retcode=1404|not.?found|unsupported|不支持/i.test(msg)) {
    return `${msg}（当前协议端可能没实现 set_qq_avatar，需要更新 SnowLuma）`;
  }
  return msg;
}

// ── 技能入口 ────────────────────────────────────────────────────────────

export function setup(api) {
  cfg = () => api.config() || {};
  httpFetch = api.fetch;

  api.registerTool({
    id: 'set_avatar',
    name: '换成这张头像',
    category: 'system',
    icon: '🖼️',
    defaultEnabled: true,
    description:
      '把用户刚刚发来的图片下载下来，换成机器人自己的 QQ 头像，成功后删除临时图片。'
      + '只在两个条件同时成立时调用：①用户明确要求换头像（“用这张当头像”“换成这个头像”“把头像改成这张”）；'
      + '②本轮消息里确实带了图片。'
      + '用户只是发图、夸头像、开玩笑、或在聊别人的头像时不要调用。多张图分不清时先用 send_message 问一句再调。'
      + '调用成功后如实回复；工具报错就说明没换成，不要声称已换。',
    parameters: {
      type: 'object',
      properties: {
        image_index: {
          type: 'integer',
          description: '可选。本轮同时出现多张图、用户指定了具体某张时，填它在候选列表里的序号（从 1 开始，按时间从早到晚）。不确定就别填，默认用最新一张。',
          minimum: 1
        }
      },
      required: []
    },

    async execute(ctx, args) {
      const list = collectCandidates(ctx);
      if (!list.length) {
        return {
          content: '没找到可用的图片：这轮消息里没有图片段。请让用户把图片和「用这张当头像」发在一起（或紧挨着发）再试。',
          isError: true
        };
      }

      const { item, index } = pickCandidate(list, args);
      const who = item.senderName || item.senderId || '对方';

      const denied = denyReasonByOwner(item);
      if (denied) return { content: `没有换头像：${denied}。`, isError: true };

      const maxMB = clamp(Number(cfg().maxMB) || DEFAULT_MAX_MB, 1, 50);
      const maxBytes = maxMB * 1024 * 1024;

      let tmpPath = '';
      let tmpDir = '';
      try {
        const url = await resolveImageUrl(ctx, item);
        const bytes = await fetchImageBuffer(url, maxBytes);
        if (!bytes.length) throw new Error('下载到的文件是空的');

        const kind = sniffImage(bytes);
        if (!kind) throw new Error('下载到的内容不是图片（链接可能已过期，或被 CDN 拦截返回了错误页）');

        tmpDir = path.join(os.tmpdir(), 'qq-agent-avatar');
        await fsp.mkdir(tmpDir, { recursive: true });
        tmpPath = path.join(tmpDir, `${Date.now()}-${randomBytes(4).toString('hex')}.${kind.ext}`);
        await fsp.writeFile(tmpPath, bytes);

        if (typeof ctx?.onebot?.call !== 'function') throw new Error('当前环境拿不到 OneBot 连接，无法调用 set_qq_avatar');

        // 显式给长超时：头像要上传到腾讯，15 秒默认超时不够。
        await ctx.onebot.call('set_qq_avatar', { file: tmpPath }, AVATAR_TIMEOUT_MS);

        const extra = list.length > 1 ? `（本轮共 ${list.length} 张图，用的是第 ${index} 张，${who} 发的）` : '';
        return {
          content:
            `换头像成功：已把机器人头像换成${who}发的那张图（${kind.label}，${fmtSize(bytes.length)}）${extra}。`
            + '临时文件已删除。头像在 QQ 客户端刷新可能要几秒到一分钟。'
            + '用一两句自然口语告诉用户换好了就行，不要罗列格式、大小、临时文件等技术细节。',
          isError: false
        };
      } catch (error) {
        return {
          content: `换头像失败：${explainError(error)}。请如实告诉用户这次没换成，不要说已经换好了。`,
          isError: true
        };
      } finally {
        // 需求要求「之后将图片删去」：无论成功失败都删，换别人头像也不例外。
        if (tmpPath) {
          try { await fsp.unlink(tmpPath); } catch { /* 已不存在 / 被占用都无所谓 */ }
        }
      }
    }
  });
}

/** 权限被删掉时明确报出来，而不是让工具变成哑巴。 */
export function available() {
  if (typeof httpFetch !== 'function') {
    return { ok: false, reason: '缺少 web_fetch 权限（skill.json 的 permissions 被删了？）' };
  }
  return true;
}
