// 【竞技场评分·抓取脚本】由技能 arena-rating 调起（node fetch.mjs <输出目录>）
// 流程：打开 B 站 UP 空间合集页 → 取最新一期《XX版本竞技场评分》合集 → 里面每个视频
//       → 进视频页，从评论区接口取强度图 → 下载到输出目录，并写 manifest.json
//
// 为什么必须用浏览器：直连网页会撞验证码，直连接口会被风控（412 / -352）。
// ⚠️ 必须静音：抓的是视频页，否则会把视频声音放出来。
import { spawn } from 'node:child_process';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';

const OUT = process.argv[2] || path.join(process.cwd(), 'images');
const EDGE_CANDIDATES = [
  'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe',
  'C:/Program Files/Microsoft/Edge/Application/msedge.exe',
  '/usr/bin/microsoft-edge', '/usr/bin/google-chrome', '/usr/bin/chromium', '/usr/bin/chromium-browser'
];
const EDGE = process.env.ARENA_BROWSER || EDGE_CANDIDATES.find((p) => fs.existsSync(p));
if (!EDGE) {
  console.log(JSON.stringify({ ok: false, error: '没找到可用的浏览器（Edge/Chrome）。可在环境变量 ARENA_BROWSER 里指定可执行文件路径。' }));
  process.exit(0);
}
const MID = process.env.ARENA_MID || '673249';
const KEYWORD = process.env.ARENA_KEYWORD || '版本竞技场评分';
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
fs.mkdirSync(OUT, { recursive: true });

const PORT = 9360;
async function launch(url) {
  // ⚠️ profile 放**系统临时目录**，不要放进技能目录（以前是 OUT/.profile）：
  //    技能目录里任何变化都会触发 App 重扫重载（线上实测刷屏），且浏览器缓存会撑大技能包。
  const profile = path.join(os.tmpdir(), 'dsh-arena-fetch-profile');
  const child = spawn(EDGE, ['--headless=new', '--no-first-run', '--no-default-browser-check',
    `--remote-debugging-port=${PORT}`, `--user-data-dir=${profile}`, '--window-size=1400,1200', '--lang=zh-CN',
    '--mute-audio', '--autoplay-policy=user-gesture-required', url], { stdio: 'ignore', windowsHide: true });
  let ver = null;
  for (let i = 0; i < 60 && !ver; i++) { await sleep(500); try { const r = await fetch(`http://127.0.0.1:${PORT}/json/version`); if (r.ok) ver = await r.json(); } catch { /* wait */ } }
  if (!ver) throw new Error('浏览器启动失败');
  return child;
}

const child = await launch(`https://space.bilibili.com/${MID}/lists`);
const pages = await (await fetch(`http://127.0.0.1:${PORT}/json/list`)).json();
const page = pages.find((p) => p.type === 'page' && /bilibili/.test(p.url)) || pages.find((p) => p.type === 'page');
// ⚠️ Electron 自带的 Node 是 v20，**没有全局 WebSocket**（那是 v22 才加的）。
//    直接用会报 `WebSocket is not defined`，所以退回应用自带的 ws 包（resources/app/node_modules/ws）。
const WS = globalThis.WebSocket || (await import('ws')).WebSocket;
const ws = new WS(page.webSocketDebuggerUrl);
await new Promise((r) => { ws.onopen = r; });
let seq = 0; const waiting = new Map(); const captured = []; const pendingIds = new Set();
ws.onmessage = (e) => {
  const m = JSON.parse(e.data);
  if (m.id && waiting.has(m.id)) { waiting.get(m.id)(m); waiting.delete(m.id); return; }
  if (m.method === 'Network.responseReceived' && /\/x\/v2\/reply|comment/.test(m.params.response.url) && /json/i.test(m.params.response.mimeType || '')) pendingIds.add(m.params.requestId);
  if (m.method === 'Network.loadingFinished' && pendingIds.has(m.params.requestId)) {
    const id = m.params.requestId; pendingIds.delete(id);
    send('Network.getResponseBody', { requestId: id }, 15000).then((r) => {
      const t = r?.result?.base64Encoded ? Buffer.from(r.result.body, 'base64').toString('utf8') : String(r?.result?.body || '');
      if (t.length > 200) captured.push(t);
    }).catch(() => {});
  }
};
const send = (method, params = {}, timeoutMs = 20000) => new Promise((res) => {
  const id = ++seq;
  const timer = setTimeout(() => { waiting.delete(id); res({ __timeout: true }); }, timeoutMs);
  waiting.set(id, (m) => { clearTimeout(timer); res(m); });
  try { ws.send(JSON.stringify({ id, method, params })); } catch { clearTimeout(timer); waiting.delete(id); res({ __timeout: true }); }
});
const ev = async (expr) => (await send('Runtime.evaluate', { expression: expr, returnByValue: true, awaitPromise: true }))?.result?.result?.value;
const killAudio = `document.querySelectorAll('video,audio').forEach(v=>{try{v.muted=true;v.volume=0;v.pause()}catch(e){}})`;

async function main() {
  await send('Page.enable'); await send('Network.enable');
  await sleep(12000);

  // 合集列表 → 找最新一期《XX版本竞技场评分》
  const colls = await ev(`(() => {
    const out = [];
    const seen = new Set();
    for (const el of document.querySelectorAll('*')) {
      const t = (el.innerText || '').split('\\n')[0].trim();
      if (t.startsWith('合集·') && t.length < 80 && !seen.has(t)) { seen.add(t); out.push(t); }
    }
    return out;
  })()`) || [];
  const hit = colls.find((t) => t.includes(KEYWORD) && !/过期|预测|预评分/.test(t)) || colls.find((t) => t.includes(KEYWORD));
  const matched = colls.findIndex((t) => t === hit);

  // 点开这一期的“查看更多”（按钮顺序与合集顺序一致）
  const clicked = await ev(`(() => {
    const btns = [...document.querySelectorAll('button,a,div,span')].filter(e => (e.innerText||'').trim() === '查看更多');
    const i = ${matched};
    if (!btns[i]) return false;
    btns[i].scrollIntoView(); btns[i].click(); return true;
  })()`);
  await sleep(9000);
  const collUrl = await ev('location.href');

  const videos = await ev(`(() => {
    const out = new Map();
    for (const a of document.querySelectorAll('a[href*="/video/"]')) {
      const m = a.href.match(/\\/video\\/(BV[0-9A-Za-z]+)/);
      const t = (a.innerText || '').trim().replace(/\\s+/g, ' ');
      if (m && t) out.set(m[1], t.slice(0, 100));
    }
    return [...out.entries()];
  })()`) || [];

  const manifest = { collection: hit, collectionUrl: collUrl, keyword: KEYWORD, fetchedAt: new Date().toISOString(), videos: {} };
  for (const [bv, title] of videos) {
    captured.length = 0;
    await send('Page.navigate', { url: `https://www.bilibili.com/video/${bv}/` });
    await sleep(14000);
    await ev(killAudio);
    for (let i = 0; i < 10; i++) { await ev('window.scrollBy(0, 1100)'); await ev(killAudio); await sleep(1200); }
    await sleep(4000);
    await ev(killAudio);
    // 再走一遍「最热」评论：有些榜图只出现在热门排序里（例如澳新那张 596×940）
    await ev(`(() => { const roots=[document]; for (let i=0;i<roots.length&&i<60;i++) for (const el of roots[i].querySelectorAll('*')) if (el.shadowRoot) roots.push(el.shadowRoot); for (const r of roots) for (const el of r.querySelectorAll('*')) { const t=(el.innerText||'').trim(); if (t==='最热'||t==='热门') { el.click(); return 1 } } return 0 })()`);
    await sleep(5000);
    for (let i = 0; i < 8; i++) { await ev('window.scrollBy(0, 1100)'); await ev(killAudio); await sleep(1100); }
    await sleep(3000);
    const urls = new Set();
    for (const body of captured) {
      let j = null; try { j = JSON.parse(body); } catch { continue; }
      const walk = (o) => {
        if (!o || typeof o !== 'object') return;
        if (Array.isArray(o)) { o.forEach(walk); return; }
        if (o.img_src && /hdslb/.test(o.img_src)) urls.add(String(o.img_src).replace(/^http:/, 'https:'));
        for (const k of Object.keys(o)) walk(o[k]);
      };
      walk(j?.data);
    }
    const saved = [];
    let n = 0;
    for (const u of urls) {
      try {
        const r = await fetch(u, { headers: { 'User-Agent': 'Mozilla/5.0', Referer: 'https://www.bilibili.com/' } });
        if (!r.ok) continue;
        const buf = Buffer.from(await r.arrayBuffer());
        if (buf.length < 20000) continue;
        const ext = buf.subarray(0, 4).toString('hex') === '89504e47' ? '.png' : '.jpg';
        const f = path.join(OUT, `${bv}_${n}${ext}`);
        fs.writeFileSync(f, buf);
        saved.push({ file: path.basename(f), path: f, url: u, kb: Math.round(buf.length / 1024) });
        n += 1;
      } catch { /* ignore */ }
    }
    manifest.videos[bv] = { title, images: saved };
    fs.writeFileSync(path.join(OUT, 'manifest.json'), JSON.stringify(manifest, null, 1), 'utf8');
    console.log(`[arena] ${bv} ${title.slice(0, 30)} → ${saved.length} 张图`);
  }

  // 标注"哪张是强度榜"：把每张图在浏览器里打开，用 canvas 看**左边那列是不是一排评分等级色**
  // （这是群友给的判据：强度榜左栏是 5/4.5/4/3.5… 一格一色；实战截图左栏基本是单色）
  for (const info of Object.values(manifest.videos)) {
    for (const img of info.images || []) {
      try {
        await send('Page.navigate', { url: 'file:///' + img.path.replace(/\\/g, '/') });
        await sleep(350);
        const r = await ev(`(() => {
          const im = document.images[0];
          if (!im || !im.naturalWidth) return null;
          const W = im.naturalWidth, H = im.naturalHeight;
          const c = document.createElement('canvas'); c.width = W; c.height = H;
          const ctx = c.getContext('2d'); ctx.drawImage(im, 0, 0);
          const x0 = Math.max(1, Math.round(W * 0.015)), x1 = Math.max(x0 + 3, Math.round(W * 0.10));
          const w = x1 - x0;
          const d = ctx.getImageData(x0, 0, w, H).data;
          const countBands = (ya, yb) => {
            const buckets = new Map();
            for (let y = ya; y < yb; y++) {
              const rs = [], gs = [], bs = [];
              for (let x = 0; x < w; x += 2) { const i = (y * w + x) * 4; rs.push(d[i]); gs.push(d[i+1]); bs.push(d[i+2]); }
              rs.sort((a,b)=>a-b); gs.sort((a,b)=>a-b); bs.sort((a,b)=>a-b);
              const k = rs.length >> 1; const R = rs[k], G = gs[k], B = bs[k];
              const mx = Math.max(R,G,B), mn = Math.min(R,G,B), sat = mx - mn;
              let key;
              if (sat < 45) key = 'gray' + Math.round(mx / 45);
              else {
                let h;
                if (mx === R) h = ((G - B) / (mx - mn)) % 6;
                else if (mx === G) h = (B - R) / (mx - mn) + 2;
                else h = (R - G) / (mx - mn) + 4;
                key = 'h' + Math.round((((h * 60) + 360) % 360) / 30);
              }
              buckets.set(key, (buckets.get(key) || 0) + 1);
            }
            const span = yb - ya;
            let strong = 0;
            for (const v of buckets.values()) if (v / span >= 0.03) strong++;
            return strong;
          };
          // 超长图（例如 1052x15000 的整卡长图）分段扫描，取最好的那一段
          const chunk = (H > 2 * W) ? 1200 : H;
          let best = 0;
          for (let y0 = 0; y0 < H; y0 += Math.max(1, Math.floor(chunk * 0.5))) {
            best = Math.max(best, countBands(y0, Math.min(H, y0 + chunk)));
            if (y0 + chunk >= H) break;
          }
          return { W, H, strong: best };
        })()`);
        if (r) {
          img.size = `${r.W}x${r.H}`;
          img.leftColorBands = r.strong;
          img.chart = r.strong >= 5 && r.H >= 400;   // ★强度榜
        }
      } catch { /* 标注失败不影响抓取 */ }
    }
  }
  fs.writeFileSync(path.join(OUT, 'manifest.json'), JSON.stringify(manifest, null, 1), 'utf8');
  const charts = Object.values(manifest.videos).flatMap((v) => (v.images || []).filter((x) => x.chart)).length;
  console.log(`[arena] 标注完成：${charts} 张判定为强度榜`);
  fs.writeFileSync(path.join(OUT, 'manifest.json'), JSON.stringify(manifest, null, 1), 'utf8');
  console.log(JSON.stringify({ ok: true, out: OUT, collection: hit, videos: Object.keys(manifest.videos).length }, null, 1));
}

try {
  await main();
} catch (error) {
  console.log(JSON.stringify({ ok: false, error: String(error?.message ?? error) }));
} finally {
  try { ws.close(); } catch { /* ignore */ }
  try { process.kill(child.pid); } catch { /* ignore */ }
  process.exit(0);
}
