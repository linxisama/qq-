// 【竞技场评分·标注+按档切片】幂等：随时可重跑（每次 arena_fetch 重抓后会丢标注，跑一次就恢复）
//
// 判定"哪张是强度榜"：**左边那列是评分等级**（5/4.5/4/3.5… 一格一色）→ 左栏色带数 ≥5 且高 ≥400。
// 生成切片：**按"卡片行"切**（一行一张图）—— 一行就是一个档位，放大到宽 ~1600px。
//   为什么按行切：模型对"一整张大图"常常消化不了；一行一张的小图读起来成功率高得多。
//
// ⚠️⚠️ 三条铁律（2026-10-11 实测得出，**改这个文件前先读**，踩过就是整国数据错）：
//   ① **色板容差必须 ≤20**：4.5 橙 (255,191,127) 与 4 黄 (255,223,127) **只差 G 通道 32**，
//      容差给 45 会把这两档并成一档 → 整段档位错位。
//   ② **色带块高 ≠ 卡片行数**：色带块只是左侧的"档位标签方块"，**同一个档位块可能横跨好几行卡片**
//      （美国榜"2 普通人"块 384px = 3 行；3.5/3/2.5/1 都是 256px = 2 行）。
//      旧版直接"一块切一张"→ 一块里混了 3 行卡 → 模型必然串档、漏卡（美国榜因此从 103 张读成 37 张）。
//      **正确做法：卡片行是横贯全图的等宽条，必须拟合出行网格 y0+k*h 再逐行切。**
//   ③ **窗口上沿要贴行首**（y0 = 网格行首），否则每行最上面那张卡的"卡名栏"被切掉 → 漏卡、串名。
//
// 行网格怎么求（不靠猜 128px，逐图自动拟合）：
//   ① 色板（容差≤20）逐行标出档位 → 合并成"档位块"
//   ② 每个块高都必须是 h 的整数倍 → 由此定 h
//   ③ "块边界集合"与"网格点集合"一一对应（数量相等且误差最小）→ 定 y0
//   实测量级：美国榜 h=129 y0=3.5 共 15 行；BV1wzeh62ETu h=132.5；BV1NUMG6qESg h=116.5
//   （都是 0.5px 粒度，所以 h 不能用整数硬编码）
//
// 拟合失败时**回退**：按色带块切，但强制把过高块等分（单张切片高度 ≤ 1.6×图宽/8），
//   保证"一块混 3 行"这种致命切法不会再出现。
//
// 用法: node prepare.mjs [images目录]
import { spawn } from 'node:child_process';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const HERE = path.dirname(fileURLToPath(import.meta.url));
// ⚠️ 兜底也放在技能目录**外面**（2026-10-12）：市场打包是递归收技能目录、上限 100 个文件，
//    抓一次强度图就几百张，放目录里会导致技能永远发布不出去（报"文件数量过多"）。
//    正常调用时 index.js 会通过 argv[2] 传目录，这里只是直接跑脚本时的兜底。
const OUT = process.argv[2] || path.join(HERE, '..', '..', 'data', 'arena-rating-images');
const MANIFEST = path.join(OUT, 'manifest.json');
const EDGE_CANDIDATES = [
  'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe',
  'C:/Program Files/Microsoft/Edge/Application/msedge.exe',
  '/usr/bin/microsoft-edge', '/usr/bin/google-chrome', '/usr/bin/chromium'
];
const EDGE = process.env.ARENA_BROWSER || EDGE_CANDIDATES.find((p) => fs.existsSync(p));
if (!EDGE) { console.log(JSON.stringify({ ok: false, error: '没找到浏览器' })); process.exit(0); }
if (!fs.existsSync(MANIFEST)) { console.log(JSON.stringify({ ok: false, error: '还没有 manifest.json（先 arena_fetch）' })); process.exit(0); }

const manifest = JSON.parse(fs.readFileSync(MANIFEST, 'utf8'));
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const PORT = 9365;
const child = spawn(EDGE, ['--headless=new', '--no-first-run', '--no-default-browser-check',
  // ⚠️ profile 必须放在**系统临时目录**，绝不能放进技能目录（以前写的是 OUT/.profile-prepare）：
  //    App 的文件监控会把技能目录里任何变化当成"技能变更"→ 反复重扫重载（线上实测刷屏），
  //    而且浏览器缓存文件动辄几十上百 MB，全堆在技能包里。
  `--remote-debugging-port=${PORT}`, `--user-data-dir=${path.join(os.tmpdir(), 'dsh-arena-prepare-profile')}`,
  '--window-size=1200,900', '--lang=zh-CN', '--mute-audio', 'about:blank'], { stdio: 'ignore', windowsHide: true });
let ver = null;
for (let i = 0; i < 60 && !ver; i++) { await sleep(500); try { const r = await fetch(`http://127.0.0.1:${PORT}/json/version`); if (r.ok) ver = await r.json(); } catch { /* wait */ } }
if (!ver) { console.log(JSON.stringify({ ok: false, error: '浏览器启动失败' })); process.exit(0); }
const pages = await (await fetch(`http://127.0.0.1:${PORT}/json/list`)).json();
const WS = globalThis.WebSocket || (await import('ws')).WebSocket;
const ws = new WS(pages.find((p) => p.type === 'page').webSocketDebuggerUrl);
await new Promise((r) => { ws.onopen = r; });
let seq = 0; const waiting = new Map();
ws.onmessage = (e) => { const m = JSON.parse(e.data); if (m.id && waiting.has(m.id)) { waiting.get(m.id)(m); waiting.delete(m.id); } };
const send = (method, params = {}, t = 60000) => new Promise((res) => {
  const id = ++seq;
  const timer = setTimeout(() => { waiting.delete(id); res({}); }, t);
  waiting.set(id, (m) => { clearTimeout(timer); res(m); });
  ws.send(JSON.stringify({ id, method, params }));
});
const ev = async (expr) => (await send('Runtime.evaluate', { expression: expr, returnByValue: true, awaitPromise: true }))?.result?.result?.value;
await send('Page.enable');

// 左栏色带统计（判"是不是榜图"）+ 档位行边界
// ⚠️ 关键：榜图外面可能裹着黑边/网页留白（截图类），左边那条"评分等级列"并不贴着 x=0。
//    所以**从左往右多试几个起始位置**，哪条能数出最多色带就按哪条算。
//    （线上教训：法国榜 873x998 是网页截图，黑边占了左侧 ~12%，旧版固定看 1%~10% 只数到 1 条 → 被判"不是榜图"）
const ANALYZE = `(() => {
 try {
  const im = document.images[0];
  if (!im || !im.naturalWidth) return null;
  const W = im.naturalWidth, H = im.naturalHeight;
  const c = document.createElement('canvas'); c.width = W; c.height = H;
  const ctx = c.getContext('2d'); ctx.drawImage(im, 0, 0);
  const offsets = [0.01, 0.06, 0.10, 0.14, 0.18, 0.22, 0.26, 0.30, 0.36, 0.42];
  let best = { strong: -1, x0: 0, x1: 0, bands: [] };
  for (const off of offsets) {
    const x0 = Math.round(W * off);
    const x1 = Math.min(W, x0 + Math.max(6, Math.round(W * 0.07)));
    if (x1 - x0 < 5) continue;
    const r = analyzeAt(x0, x1);
    if (r && r.strong > best.strong) best = { ...r, x0, x1 };
  }
  if (best.strong < 0) return null;
  return { W, H, strong: best.strong, bands: best.bands, rowsInfo: best.rowsInfo, x0: best.x0, x1: best.x1 };

  function analyzeAt(x0, x1) {
  const w = x1 - x0;
  const d = ctx.getImageData(x0, 0, w, H).data;
  const mid = (y) => {
    const rs = [], gs = [], bs = [];
    for (let x = 0; x < w; x += 2) { const i = (y * w + x) * 4; rs.push(d[i]); gs.push(d[i+1]); bs.push(d[i+2]); }
    rs.sort((a,b)=>a-b); gs.sort((a,b)=>a-b); bs.sort((a,b)=>a-b);
    const k = rs.length >> 1; return [rs[k], gs[k], bs[k]];
  };
  const far = (a, b, t) => Math.abs(a[0]-b[0]) + Math.abs(a[1]-b[1]) + Math.abs(a[2]-b[2]) > (t || 45);
  const bands = []; let start = 0, prev = mid(0);
  for (let y = 1; y < H; y++) {
    const cc = mid(y);
    if (far(cc, prev)) { if (y - start >= Math.max(30, H / 40)) { bands.push([start, y]); start = y; } prev = cc; }
  }
  if (H - start >= 30) bands.push([start, H]);
  const merged = [];
  for (const [a, b] of bands) {
    const last = merged[merged.length - 1];
    if (last && !far(mid(Math.floor((last[0]+last[1])/2)), mid(Math.floor((a+b)/2)), 70) && a - last[1] < 12) last[1] = b;
    else merged.push([a, b]);
  }
  // 色带统计（超长图分段扫描）
  const countBands = (ya, yb) => {
    const buckets = new Map();
    for (let y = ya; y < yb; y++) {
      const [R, G, B] = mid(y);
      const mx = Math.max(R,G,B), mn = Math.min(R,G,B), sat = mx - mn;
      let key;
      if (sat < 45) key = 'gray' + Math.round(mx / 45);
      else {
        let h;
        if (mx === R) h = ((G - B) / (mx - mn)) % 6;
        else if (mx === G) h = (B - R) / (mx - mn) + 2;
        else h = (R - G) / (mx - mn) + 4;
        key = 'h' + Math.round((((h * 60) + 360) % 360) / 30);
      }
      buckets.set(key, (buckets.get(key) || 0) + 1);
    }
    const span = yb - ya; let strong = 0;
    for (const v of buckets.values()) if (v / span >= 0.03) strong++;
    return strong;
  };
  const chunk = (H > 2 * W) ? 1200 : H;
  let strongBest = 0;
  for (let y0 = 0; y0 < H; y0 += Math.max(1, Math.floor(chunk * 0.5))) {
    strongBest = Math.max(strongBest, countBands(y0, Math.min(H, y0 + chunk)));
    if (y0 + chunk >= H) break;
  }
  return { strong: strongBest, bands: merged, rowsInfo: gridInfo(d, 0, w, w, H) };
  }

  // ── 行网格拟合：铁律②③的落地 ───────────────────────────────────────────
  // 标档位用"逐像素命中色板 → 取该行出现最多的档位"（色板容差 20，铁律①）。
  //   为什么不用"中位色再比色板"：色带采样窗口只有几像素宽，中位色会被抗锯齿/图标带偏，
  //   而 4.5 橙 (255,191,127) 与 4 黄 (255,223,127) 只差 G 通道 32，一偏就并档（铁律①）。
  //   逐像素投票对窗口宽度不敏感，实测块数稳定。
  // 行网格：**只匹配"档位块的起点"** —— 色带块会被卡图图标/黑边截断，
  //   块高能用来定 h（整数倍），但块的终点不可靠，不能用来定位。
  //   实测量级：美国榜 h=129 y0=5 共 15 行；日本 h=116.5 共 15 行；BV1wzeh62ETu h=132.5 共 16 行。
  function gridInfo(px, x0, x1, W, H2) {
    const PAL = { '5':[255,127,127], '4.5':[255,191,127], '4':[255,223,127],
                  '3.5':[191,255,127], '3':[127,255,127], '2.5':[127,255,255],
                  '2':[127,191,255], '1':[207,207,207], '0':[247,247,247] };
    const dd = (a,b) => Math.abs(a[0]-b[0]) + Math.abs(a[1]-b[1]) + Math.abs(a[2]-b[2]);
    const near = (rgb) => { let bt = null, bd = Infinity;
      for (const t in PAL) { const v = dd(rgb, PAL[t]); if (v <= 20 && v < bd) { bt = t; bd = v; } }
      return bt; };
    // ① 每行取"命中色板的像素里出现最多的档位"
    const rowTier = [];
    for (let y = 0; y < H2; y++) {
      const cnt = {};
      for (let x = x0; x < x1; x++) {
        const i = (y * W + x) * 4;
        const t = near([px[i], px[i + 1], px[i + 2]]);
        if (t) cnt[t] = (cnt[t] || 0) + 1;
      }
      let bt = null, bn = 0;
      for (const t in cnt) if (cnt[t] > bn) { bn = cnt[t]; bt = t; }
      // 至少要有 35% 宽度命中色板（否则该行被图标/黑边挡住，判为无效）
      rowTier.push(bn >= (x1 - x0) * 0.35 ? bt : null);
    }
    // ② 合并同档位片段（18px 以下当噪声）
    const blocks = []; let cur = null;
    for (let y = 0; y < H2; y++) {
      const t = rowTier[y];
      if (!t) continue;
      if (cur && cur.tier === t) cur.y1 = y;
      else { if (cur && cur.y1 - cur.y0 + 1 >= 18) blocks.push(cur); cur = { tier: t, y0: y, y1: y }; }
    }
    if (cur && cur.y1 - cur.y0 + 1 >= 18) blocks.push(cur);
    // ⚠️ heights 必须在函数作用域声明：回退分支（下面）也要用它。
    //    之前写在 if 块里，导致回退时 "heights is not defined" 抛异常 →
    //    上层 ANALYZE 被 try/catch 吞掉 → 所有图都被判成"分析失败"（charts=0）。
    const heights = blocks.map((b) => b.y1 - b.y0 + 1);
    if (blocks.length >= 2) {
      const starts = blocks.map((b) => b.y0);
      const nblocks = blocks.length;
      const minBlockH = Math.min(...heights);
      let best = null;
      // ② h 从 40 到 400 以 0.5px 搜索：块高必须是 h 的整数倍（残片按 1 行计）
      //    个别块会被图标/黑边多截几像素，所以"最多允许 1 个块不达标"（越界行数会体现在日志里）
      for (let hi = 80; hi <= 800; hi++) {
        const h = hi / 2;
        // ⚠️ 硬约束：一行卡片至少占"最小色带块"的 0.7 倍。
        //    没有这条，h 会退化到 41 这种过拟合解（把一行切成 3 份），
        //    因为任何块高都能被足够小的 h 整除（英国榜实测会切出 44 行）。
        if (h < minBlockH * 0.7) continue;
        const ks = []; let miss = 0;
        for (const v of heights) {
          const k = Math.max(1, Math.round(v / h));
          if (k === 1 && v < 0.8 * h) { ks.push(1); continue; }   // 截断残片
          if (Math.abs(v - k * h) > Math.max(12, h * 0.14)) miss += 1;
          ks.push(k);
        }
        if (miss > 1) continue;
        const total = ks.reduce((a, b) => a + b, 0);
        if (total < 3 || total > 25) continue;
        // ③ 只匹配"块起点"（块的终点会被图标/黑边截断，不可靠），y0 在 2 个周期内枚举
        for (let yi = 0; yi <= Math.round(2 * h * 2); yi++) {
          const y0 = yi / 2;
          let err = 0, ok = true;
          for (const s of starts) {
            const kk = Math.round((s - y0) / h);
            if (kk < 0) { ok = false; break; }
            const e = Math.abs(s - (y0 + kk * h));
            if (e > err) err = e;
            const tolG = Math.max(8, h * 0.06);
            if (err > tolG) { ok = false; break; }
          }
          if (!ok) continue;
          // 选择顺序：① 越界块最少 ② 行数最少（避免把一行切成多份）③ 起点误差最小
          const score = [miss, total, Math.round(err * 10)];
          if (!best || score[0] < best.score[0] ||
              (score[0] === best.score[0] && score[1] < best.score[1]) ||
              (score[0] === best.score[0] && score[1] === best.score[1] && score[2] < best.score[2])) {
            best = { score, h, y0, ks, total, err, miss };
          }
        }
      }
      if (best) {
        const rows = []; let cursor = 0;
        blocks.forEach((b, i) => {
          for (let j = 0; j < best.ks[i]; j++) {
            rows.push({ tier: b.tier,
              y0: Math.round(best.y0 + cursor * best.h), y1: Math.round(best.y0 + (cursor + 1) * best.h) });
            cursor += 1;
          }
        });
        return { h: best.h, y0: best.y0, mixed: false, rows, err: best.err, nblocks };
      }
    }
    // 回退：拟合失败时按"中位块高"切，保证**没有任何一片超过一行卡的高度**。
    //   为什么用中位块高当上限：色带块的常见高度就是 1 行（美国榜 127≈真值 129、
    //   英国榜 ~120≈真值 ~125），用它当上限既不会把块切碎，也不会留下巨片。
    //   踩过的三个坑：
    //   ① 用全局最小块高 → 残片（72px）把正常块切成 60px 薄片，连一行都装不下；
    //   ② 向下取整 → 法国长图 633x14999 留下 1453px 的巨片，模型读不了；
    //   ③ min(n,4) 之类的块数封顶 → 长图照样留巨片。
    const sortedH = heights.slice().sort((a, b) => a - b);
    const medH = sortedH[Math.floor(sortedH.length / 2)] || 128;
    // 基准取"**剔除残片后的最小块高**"——它才是 1 行的高度。
    //   ⚠️ 不能用中位块高：中位数常常落在"2 行"的块上
    //   （美国榜中位 255、英国榜中位 237，都等于 2 行），会造成翻倍切分。
    //   也不能直接用全局最小：末端残片（英国 48px）会把正常块切成薄片。
    const solid = sortedH.filter((v) => v >= medH * 0.55);
    let cap = solid.length ? solid[0] : medH;
    // 再加一条"图宽 25%"的硬上限：真实一行卡的高度不会超过它
    cap = Math.max(64, Math.min(cap, Math.round(W * 0.25)));
    // 下限：一行卡最少也有 ~110px 高（实测美国 129 / 英国 ~125 / 日本 116.5）——
    //   没有这条下限，基准一旦塌到 60 就会把正常的一行切成两片薄片。
    cap = Math.max(cap, 110);
    const rows = [];
    for (const b of blocks) {
      const hh = b.y1 - b.y0 + 1;
      const n = Math.max(1, Math.min(60, Math.ceil(hh / cap - 0.02)));
      for (let j = 0; j < n; j++) {
        rows.push({ tier: b.tier,
          y0: b.y0 + Math.floor(j * hh / n), y1: b.y0 + Math.floor((j + 1) * hh / n) });
      }
    }
    return { h: null, y0: null, mixed: true, rows, nblocks: blocks.length, cap, medH, sortedH };
  }
 } catch (e) { return { __err: String(e && e.message || e) }; }
})()`;


let charts = 0;
let rows = 0;
let fitted = 0, fellBack = 0;
// ⚠️ 先清掉上一轮的切片：切片张数会随算法变化（旧算法 8 张 / 新算法 15 张），
//    不清就会留下"文件在磁盘上、但 manifest 里没有"的旧碎片，模型万一读到就是错的。
//    只删 *_rowNN.jpg，原始榜图（*_0.png 之类）一个不动。
let cleaned = 0;
for (const info of Object.values(manifest.videos || {})) {
  for (const img of info.images || []) {
    const dir = path.dirname(img.path);
    const base = path.basename(img.path).replace(/\.(png|jpe?g|webp)$/i, '');
    let names = [];
    try { names = fs.readdirSync(dir); } catch { continue; }
    for (const n of names) {
      if (n.startsWith(base + '_row') && /\.jpe?g$/i.test(n)) {
        try { fs.unlinkSync(path.join(dir, n)); cleaned += 1; } catch { /* ignore */ }
      }
    }  }
}
if (cleaned) console.log(`[准备] 清掉上一轮切片 ${cleaned} 张`);
for (const info of Object.values(manifest.videos || {})) {
  for (const img of info.images || []) {
    if (!fs.existsSync(img.path)) continue;
    await send('Page.navigate', { url: 'file:///' + img.path.replace(/\\/g, '/') });
    await sleep(450);
    let a = await ev(ANALYZE);
    // 图片偶尔没加载完就分析 → 返回空，重试一次
    if (!a || a.__err) { await sleep(900); a = await ev(ANALYZE); }
    // ⚠️ ANALYZE 内部有 try/catch 兜底（单张图出错不该让整个脚本崩），
    //    但错误**必须打出来**——曾经因为 heights 作用域 bug 让所有图静默失败（charts=0），
    //    排查了很久。这里把 __err 显式暴露。
    if (a && a.__err) console.log(`[准备] ⚠️ ${path.basename(img.path)} 分析异常：${a.__err}`);
    if (!a || a.__err) { delete img.rows; delete img.parts; delete img.grid; delete img.chart; continue; }
    img.size = `${a.W}x${a.H}`;
    img.leftColorBands = a.strong;
    // ⚠️ 强度榜是**竖长**的（实测 1080x1937 / 957x1752 / 1111x2122，宽高比 0.5~0.56）。
    //    横版大图（2532x1170 = 2.16）是网页截图/横排图，强行按行网格切会把"一行"切碎
    //    （实测 BV1kv3u68E2j_1 被切成 5 张碎片）→ 直接判为非榜图。
    img.chart = a.strong >= 5 && a.H >= 400 && a.H > a.W;
    // ⚠️ 不是榜图就必须把旧的 rows 清掉：上面的清理已经把上一轮切片文件删了，
    //    这里若只 continue，manifest 会留着指向"已删文件"的 rows 记录 →
    //    插件按 manifest 去读会拿到不存在的路径（实测出现过 25 条这种悬空记录）。
    if (!img.chart) { delete img.rows; delete img.parts; delete img.grid; continue; }
    charts += 1;
    const scale = Math.min(2.5, 1600 / a.W);
    const made = [];
    // ★ 铁律②③：按拟合出来的"卡片行"切（一行一张），而不是按色带块切
    // ⚠️ 行数上限 25：真实强度榜是 8~20 行。超过 25 行说明这不是"一行一档"的榜图
    //    （实测 1052x15000 的长截图会被拟合成 32 行碎片）→ 丢掉行网格，改走回退。
    const ri = a.rowsInfo;
    const gridOk = ri && ri.h && !ri.mixed && ri.rows && ri.rows.length <= 25;
    let rowList;
    if (gridOk) rowList = ri.rows;
    else rowList = (ri && ri.rows) || (a.bands || []).map(([y0, y1]) => ({ tier: null, y0, y1 }));
    if (gridOk) { fitted += 1; img.grid = { h: ri.h, y0: ri.y0 }; }
    else { fellBack += 1; img.grid = { h: null, y0: null, fallback: true }; }

    // ── 名栏定位（每张图可能都不一样，所以不硬编码 y=6~30，而是逐行探测）────────
    //   名栏 = 卡片顶部那条"浅色底 + 深色文字"的横带。特征：平均亮度明显高于卡图。
    //   用法：切"名栏条"放大给模型精读卡名；读不出卡名时回落到下半部文本区。
    const detectNameBar = async () => {
      const r = await ev(`(() => {
        const im = document.images[0];
        if (!im || !im.naturalWidth) return null;
        const W = im.naturalWidth, H = im.naturalHeight;
        const c = document.createElement('canvas'); c.width = W; c.height = H;
        const ctx = c.getContext('2d'); ctx.drawImage(im, 0, 0);
        const X0 = Math.round(W * 0.13);
        const band = ctx.getImageData(X0, 0, W - X0, H).data;
        const bw = W - X0;
        const lum = new Float32Array(H);
        for (let y = 0; y < H; y++) {
          let s = 0;
          for (let x = 0; x < bw; x += 3) { const i = (y * bw + x) * 4; s += (band[i] + band[i + 1] + band[i + 2]) / 3; }
          lum[y] = s / Math.ceil(bw / 3);
        }
        let mn = 1e9, mx = -1e9;
        for (let y = 0; y < H; y++) { if (lum[y] < mn) mn = lum[y]; if (lum[y] > mx) mx = lum[y]; }
        const thr = mn + (mx - mn) * 0.52;
        // 第一个足够长的"亮带"就是名栏
        let y0 = -1, y1 = -1;
        for (let y = 0; y < H; y++) {
          if (lum[y] >= thr) { if (y0 < 0) y0 = y; y1 = y; }
          else if (y0 >= 0 && y1 - y0 >= 12) break;
          else if (y0 >= 0) { y0 = -1; y1 = -1; }
        }
        if (y0 < 0 || y1 - y0 < 8) return null;
        return { y0, y1: y1 + 1, thr: Math.round(thr) };
      })()`);
      return r && !r.__err ? r : null;
    };
    const nb = await detectNameBar();
    if (nb) img.nameBar = nb;

    for (let i = 0; i < rowList.length; i++) {
      const { y0, y1, tier } = rowList[i];
      if (y1 - y0 < 20) continue;
      const ok = await ev(`(() => {
        const im = document.images[0];
        if (!im || !im.naturalWidth) return false;
        const c = document.createElement('canvas');
        c.width = Math.round(${a.W} * ${scale}); c.height = Math.round(${y1 - y0} * ${scale});
        const ctx = c.getContext('2d');
        ctx.imageSmoothingEnabled = true; ctx.imageSmoothingQuality = 'high';
        ctx.drawImage(im, 0, ${y0}, ${a.W}, ${y1 - y0}, 0, 0, c.width, c.height);
        window.__PART__ = c.toDataURL('image/jpeg', 0.9);
        return true;
      })()`);
      if (!ok) continue;
      const dataUrl = await ev('window.__PART__');
      if (typeof dataUrl !== 'string' || !dataUrl.startsWith('data:image/jpeg;base64,')) continue;
      const outPath = img.path.replace(/\.(png|jpe?g|webp)$/i, `_row${String(i + 1).padStart(2, '0')}.jpg`);
      fs.writeFileSync(outPath, Buffer.from(dataUrl.slice('data:image/jpeg;base64,'.length), 'base64'));
      const rec = { file: path.basename(outPath), path: outPath, rows: `${y0}-${y1}`, tier, size: `${Math.round(a.W * scale)}x${Math.round((y1 - y0) * scale)}` };

      // ── 每行额外切一份"名栏条"（放大），供精读卡名 ──────────────────────
      //   名栏文案（顶部浅色带）→ 用它读卡名；指令/反制卡名栏里没有名字，
      //   所以同时切一份"下半文本区"，读名栏失败时看它。
      //   ⚠️ 这条路径与"按行网格切"完全解耦：即使行高没拟合对（回退），
      //   名栏条也能让模型按卡名逐张核对（卡名对不上就是切错了）。
      //   只为**拟合成功的行**生成：回退图的行本来就不精确，生成一堆条子没意义还慢。
      if (nb && gridOk) {
        const SH = Math.max(26, nb.y1 - nb.y0 + 8);
        // 窄图不分段（避免把一张卡名切成两半）；宽图分 2 段保证放大后文字够大
        const SEG = a.W > 1200 ? 2 : 1, MAG = 4;
        const segW = Math.ceil(a.W / SEG);
        const bars = [];
        for (let si = 0; si < SEG; si++) {
          const bx = si * segW;
          const bw = Math.min(segW, a.W - bx);
          if (bw <= 8) continue;
          const bp = img.path.replace(/\.(png|jpe?g|webp)$/i, `_row${String(i + 1).padStart(2, '0')}_name${si + 1}.jpg`);
          const okBar = await ev(`(() => {
            const im = document.images[0];
            if (!im || !im.naturalWidth) return false;
            const c = document.createElement('canvas');
            c.width = Math.round(${bw} * ${MAG}); c.height = Math.round(${SH} * ${MAG});
            const ctx = c.getContext('2d');
            ctx.imageSmoothingEnabled = true; ctx.imageSmoothingQuality = 'high';
            ctx.drawImage(im, ${bx}, ${y0}, ${bw}, ${SH}, 0, 0, c.width, c.height);
            window.__BAR__ = c.toDataURL('image/jpeg', 0.92);
            return true;
          })()`);
          if (!okBar) continue;
          const bUrl = await ev('window.__BAR__');
          if (typeof bUrl !== 'string' || !bUrl.startsWith('data:image/jpeg;base64,')) continue;
          fs.writeFileSync(bp, Buffer.from(bUrl.slice('data:image/jpeg;base64,'.length), 'base64'));
          bars.push(path.basename(bp));
        }
        if (bars.length) rec.nameBars = bars;
      }

      // ── 下半部"文本区条"（指令/反制卡的卡名在这里）──────────────────────
      //   使用者 2026-10-11 指出的规则：单位卡名在最上面的名栏里；
      //   指令/反制卡最上面没有名栏，名字在**下半部文本区**。
      //   所以名栏条读不出卡名时，看这条。
      if (gridOk) {
        const rowH = y1 - y0;
        const ty0 = y0 + Math.round(rowH * 0.55);
        const th = Math.max(20, y1 - ty0 - 2);
        const SEG = a.W > 1200 ? 2 : 1, MAG = 4;
        const segW = Math.ceil(a.W / SEG);
        const bars = [];
        for (let si = 0; si < SEG; si++) {
          const bx = si * segW;
          const bw = Math.min(segW, a.W - bx);
          if (bw <= 8) continue;
          const bp = img.path.replace(/\.(png|jpe?g|webp)$/i, `_row${String(i + 1).padStart(2, '0')}_text${si + 1}.jpg`);
          const okT = await ev(`(() => {
            const im = document.images[0];
            if (!im || !im.naturalWidth) return false;
            const c = document.createElement('canvas');
            c.width = Math.round(${bw} * ${MAG}); c.height = Math.round(${th} * ${MAG});
            const ctx = c.getContext('2d');
            ctx.imageSmoothingEnabled = true; ctx.imageSmoothingQuality = 'high';
            ctx.drawImage(im, ${bx}, ${ty0}, ${bw}, ${th}, 0, 0, c.width, c.height);
            window.__BAR2__ = c.toDataURL('image/jpeg', 0.92);
            return true;
          })()`);
          if (!okT) continue;
          const tUrl = await ev('window.__BAR2__');
          if (typeof tUrl !== 'string' || !tUrl.startsWith('data:image/jpeg;base64,')) continue;
          fs.writeFileSync(bp, Buffer.from(tUrl.slice('data:image/jpeg;base64,'.length), 'base64'));
          bars.push(path.basename(bp));
        }
        if (bars.length) rec.textBars = bars;
      }
      made.push(rec);
      rows += 1;
    }
    if (made.length) { img.rows = made; delete img.parts; }
    // 一张切片都没产出（行都被过滤/画布失败）→ 记录也要清掉，别留悬空路径
    else { delete img.rows; delete img.parts; delete img.grid; }
    const tag = gridOk ? `行网格 h=${ri.h} y0=${ri.y0} 块=${ri.nblocks} err=${ri.err}`
      : `⚠️回退(${ri ? '块=' + ri.nblocks + ' cap=' + ri.cap + ' 块高=' + (ri.sortedH || []).join(',') : '无色带块'})`;
    const tiers = [...new Set(made.map((m) => m.tier).filter(Boolean))].join('/');
    console.log(`[准备] ${path.basename(img.path)} ${img.size} 左栏${a.strong} → ★强度榜 ${made.length} 张 · ${tag}${tiers ? ' · 档位 ' + tiers : ''}`);
  }
}
fs.writeFileSync(MANIFEST, JSON.stringify(manifest, null, 1), 'utf8');
console.log(JSON.stringify({ ok: true, charts, rows, fitted, fellBack, out: OUT }));
ws.close();
try { process.kill(child.pid); } catch { /* ignore */ }
process.exit(0);
