// 「竞技场评分」——把 B 站 UP「华南有只虎」每期《XX版本竞技场评分》视频评论区里的强度图
// 变成机器人能查的数据。
//
// 为什么是技能（LLM 型）而不是插件：
//   触发时机要理解人话（"更新一下竞技场评分"/"XX 几分"），且**读图必须用模型的视觉能力** ——
//   图上的卡名只有 5~7 像素高，工具自己切图+感知哈希试过，区分度不够（正确匹配 6~14、
//   硬凑的也有 18~22），所以定死规则那条路走不通，得让模型看图。
//
// 数据流：
//   ① arena_fetch  → 无头浏览器抓最新一期合集的全部视频 → 每个视频评论区的强度图下载到 images/
//   ② 模型逐张读图 → arena_record 把「阵营 → 档位 → 卡名」写进 ratings.json
//   ③ 群友问起来   → arena_rating 查表回答
//   ④ 每 90 天（或群里按了「重新读取」按钮）→ 自动提示模型再走一遍 ①~②
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const SKILL_DIR = path.dirname(fileURLToPath(import.meta.url));
const DATA_FILE = path.join(SKILL_DIR, 'ratings.json');
const STATE_FILE = path.join(SKILL_DIR, 'state.json');
// ⚠️ 图片目录**故意放在技能目录外面**（2026-10-12 改）：
//   · 市场打包是"递归收整个技能目录"，上限 100 个文件 —— 抓一次强度图就有几百张，
//     放技能目录里会导致**永远发不出去**（报"文件数量过多"）；
//   · 这些图是运行时数据，别人不需要（他们要抓会自己抓）。
//   放在 app/data/ 下，既是稳定的绝对位置，也不会混进发布包。
const APP_ROOT = path.resolve(SKILL_DIR, '..', '..');
const IMAGE_DIR = process.env.ARENA_IMAGE_DIR || path.join(APP_ROOT, 'data', 'arena-rating-images');

const TIER_MEANING = {
  '??': '未评级（图里标的就是问号）',
  '5': '超强 · 只给 2-3 张牌，宁缺毋滥',
  '4.5': '很强 · 打出来让对手虎躯一震',
  '4': '超模 · 有较高收益，稳定，易实现',
  '3.5': '不错 · 有一定收益，下限不低',
  '3': '好牌 · 有一点收益，不会让我们陷入劣势',
  '2.5': '凑合 · 勉强用，打错容易陷入劣势',
  '2': '普通人 · 打出来很容易陷入劣势',
  '1': '弱者 · 几乎打不过同费用的人',
  '0': '神卡！打出来让对手露出笑容'
};

let cfg = () => ({});
let log = () => {};

const readJson = (file, fallback) => {
  try { return JSON.parse(fs.readFileSync(file, 'utf8')); } catch { return fallback; }
};
const writeJson = (file, data) => {
  fs.mkdirSync(path.dirname(file), { recursive: true });
  fs.writeFileSync(file, JSON.stringify(data, null, 1), 'utf8');
};
const norm = (s) => String(s ?? '').toLowerCase().replace(/[\s\-_·、，,.。:：/()（）【】\[\]]+/g, '');

const loadRatings = () => readJson(DATA_FILE, { version: '', collections: {}, updatedAt: '' });
const loadState = () => readJson(STATE_FILE, { lastFetchAt: 0, lastHandledRequest: 0, history: [] });

// ── 离线全卡池（1629 张）───────────────────────────────────────────────────
// 用途：读图时把"从名栏条上读到的卡名"拿来这里核对。
//   · 命中 → 用站内写法入档（读图常见错字会被纠正过来）
//   · 查不到 → 说明卡名读错了、或者这一行切片不准 → 让模型重看，而不是硬记
// 为什么必须离线：站内域名 qwq.wards.mom 经常 DNS 失败，读榜时不能依赖它。
const POOL_FILE = path.join(SKILL_DIR, 'cards-meta.json');
let POOL_CACHE = null;
function loadPool() {
  if (POOL_CACHE) return POOL_CACHE;
  const arr = readJson(POOL_FILE, null);
  POOL_CACHE = Array.isArray(arr) ? arr : [];
  return POOL_CACHE;
}
function poolByFaction(zh) {
  const en = FACTION_EN[zh] || '';
  const all = loadPool();
  return en ? all.filter((c) => c.faction === en) : all;
}


// ── 选国习惯表（主国/盟国优先度）──────────────────────────────────────────
// 「客观表」由评分数据算，改不了；「习惯表」是使用者实战手感，可改（设置页拖动 或 @机器人）。
const COUNTRY_ALIAS = {
  美国: ['美', 'usa', 'us', 'america', '美帝'],
  苏联: ['苏', 'soviet', 'ussr', '俄', '毛子'],
  德国: ['德', 'germany', 'ger', '德佬'],
  日本: ['日', 'japan', 'jp', '鬼子'],
  英国: ['英', 'britain', 'uk', 'england', '约翰牛'],
  法国: ['法', 'france', 'fr', '高卢'],
  芬兰: ['芬', 'finland', 'fin'],
  澳新: ['澳', 'anzac', 'an', '澳大利亚', '新西兰', '澳洲'],
  波兰: ['波', 'poland', 'pol', '大波波'],
  意大利: ['意', 'italy', 'it', '呆梨']
};
const MAIN_GROUP = ['德国', '日本', '美国', '英国', '苏联'];
// ⚠️ 盟国池 = **全部国家**：KARDS 里**主国也能当盟国选**（使用者 2026-10-11 指出），
//    所以选盟国时要考虑所有国家，不能只列非主国那批。
const ALLY_GROUP = ['芬兰', '法国', '澳新', '波兰', '意大利', '美国', '苏联', '日本', '英国', '德国'];
const DEFAULT_MAIN_ORDER = ['美国', '苏联', '日本', '英国', '德国'];
// 默认：先非主国盟国（实战手感），主国排在后面（它们通常当主国用）
const DEFAULT_ALLY_ORDER = ['芬兰', '法国', '澳新', '波兰', '意大利', '美国', '苏联', '日本', '英国', '德国'];

/** 一个词 → 可能的国名列表（支持简写：芬→芬兰、澳→澳新） */
function matchCountries(part) {
  const t = String(part || '').trim();
  if (!t) return [];
  const key = t.toLowerCase().replace(/\s+/g, '');
  const all = [...MAIN_GROUP, ...ALLY_GROUP];
  const exact = all.filter((f) => f === t);
  if (exact.length) return exact;
  // 别名表（含英文）
  for (const [f, aliases] of Object.entries(COUNTRY_ALIAS)) {
    if (aliases.some((a) => a === key || a === t)) return [f];
  }
  // 长名包含：「苏联」→ 命中；「芬兰」→ 命中
  const inc = all.filter((f) => f.includes(t) || t.includes(f));
  if (inc.length) return inc;
  // 首字：「芬」→ 芬兰（唯一就返回，多个就都返回让调用方判断）
  const first = all.filter((f) => f[0] === t);
  return first;
}

/** 解析用户写的顺序串 → 国名数组（保留原顺序，去重） */
function parsePreferenceOrder(raw, group) {
  const list = group === 'main' ? MAIN_GROUP : ALLY_GROUP;
  const out = []; const unknown = [];
  for (const part of String(raw || '').split(/[,，、>→|\/\s]+/).map((x) => x.trim()).filter(Boolean)) {
    const cand = matchCountries(part).filter((f) => list.includes(f));
    if (!cand.length) { unknown.push(part); continue; }
    for (const f of cand) if (!out.includes(f)) out.push(f);
  }
  return { order: out, unknown };
}

function settingsCfgFile() {
  try {
    const here = path.dirname(fileURLToPath(import.meta.url));   // .../app/skills/arena-rating
    return path.join(here, '..', '..', '..', '..', 'data', 'config.json');
  } catch { return ''; }
}

function readPreferredOrder(group) {
  const list = group === 'main' ? MAIN_GROUP : ALLY_GROUP;
  const fallback = group === 'main' ? DEFAULT_MAIN_ORDER : DEFAULT_ALLY_ORDER;
  const file = settingsCfgFile();
  if (file && fs.existsSync(file)) {
    try {
      const c = JSON.parse(fs.readFileSync(file, 'utf8'));
      const sk = (c.skills || {})['arena-rating'] || {};
      const raw = group === 'main' ? sk.mainOrder : sk.allyOrder;
      if (raw) {
        const { order } = parsePreferenceOrder(raw, group);
        if (order.length) {
          // ⚠️ 必须**补全**：旧配置（或早期版本）可能只存了一部分国家
          //    （实测踩过：allyOrder 只存了 5 个非主国，导致"主国当盟国"那批被漏掉）。
          //    补全顺序：先用户给的，再按默认顺序把剩下的接上。
          const out = order.slice();
          for (const f of fallback) if (list.includes(f) && !out.includes(f)) out.push(f);
          for (const f of list) if (!out.includes(f)) out.push(f);
          return out;
        }
      }
    } catch { /* 读不到就退回默认 */ }
  }
  return fallback.slice();
}

/**
 * 写回「主国/盟国习惯优先度」。
 * ⚠️ 优先走**控制台 API**（POST /api/skills/<id> 带 settings）：核心会走 updateConfig ——
 *    同时更新内存配置和 config.json，不会和别处的配置修改互相覆盖（官方路径，推荐）。
 *    只有当 API 不可达（控制台端口关了）时，才退化成**直接改 config.json 文件**，
 *    这时若核心持有旧的内存快照，后写可能覆盖，所以返回时标注用了哪条路。
 */
async function writePreferredOrder(group, order) {
  const key = group === 'main' ? 'mainOrder' : 'allyOrder';
  const merged = order.slice();
  for (const f of (group === 'main' ? MAIN_GROUP : ALLY_GROUP)) if (!merged.includes(f)) merged.push(f);
  const value = merged.join(',');

  // ① 官方路径：控制台 API
  for (const port of [3210, 3211, 3212]) {
    try {
      const res = await fetch(`http://127.0.0.1:${port}/api/skills/arena-rating`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ settings: { [key]: value } })
      });
      if (res.ok) {
        const j = await res.json().catch(() => ({}));
        if (j && j.ok === false) return { ok: false, reason: j.error || 'API 拒绝了这次修改', via: 'api' };
        return { ok: true, value, via: 'api' };
      }
    } catch { /* 端口不通就试下一个 */ }
  }

  // ② 退化路径：直接写文件
  const file = settingsCfgFile();
  if (!file || !fs.existsSync(file)) return { ok: false, reason: '控制台 API 不通，且找不到 data/config.json' };
  try {
    const cfg = JSON.parse(fs.readFileSync(file, 'utf8'));
    cfg.skills = cfg.skills || {};
    cfg.skills['arena-rating'] = cfg.skills['arena-rating'] || {};
    cfg.skills['arena-rating'][key] = value;
    const tmp = file + '.tmp-arena';
    fs.writeFileSync(tmp, JSON.stringify(cfg, null, 2), 'utf8');
    fs.copyFileSync(tmp, file);
    try { fs.unlinkSync(tmp); } catch { /* ignore */ }
    return { ok: true, value, via: 'file' };
  } catch (e) {
    return { ok: false, reason: String(e && e.message || e) };
  }
}


// ── 写入权限：只有认定的主人才能改竞技场强度榜（2026-10-12 加）────────────
// 判定顺序（任一能确定就返回结果；全都确定不了 → 放行，保持向后兼容）：
//   ① owner-identity 插件的能力 message.owner-check（官方判定处，优先）
//   ② 直接读 config.skills['owner-identity'].ids（能力不可用时的兜底）
//   ③ 没有任何主人配置 → 不启用校验（照旧谁都能写）
let ownerCheckFn = null;
let hasOwnerCap = () => false;
const OWNER_SKILL_ID = 'owner-identity';

function ownerConfFromConfig() {
  try {
    const file = settingsCfgFile();
    if (!file || !fs.existsSync(file)) return null;
    const c = JSON.parse(fs.readFileSync(file, 'utf8'));
    return (c.skills || {})[OWNER_SKILL_ID] || (c.plugins || {})[OWNER_SKILL_ID] || null;
  } catch { return null; }
}

/** 主人识别插件**是否启用** —— 没启用就完全不做权限校验（使用者 2026-10-12 明确） */
function ownerEnabledFromConfig() {
  const sk = ownerConfFromConfig();
  if (!sk) return false;                       // 压根没配置 → 视为没启用
  // enabled=false 显式关闭；字段缺失时按"已启用"处理（用户在设置页保存过就说明启用了）
  return sk.enabled !== false;
}

function ownerIdsFromConfig() {
  const sk = ownerConfFromConfig();
  if (!sk) return [];
  const raw = String(sk.ids ?? sk.ownerIds ?? '').trim();
  return raw ? raw.split(/[,，、\s]+/).map((x) => x.replace(/\D/g, '')).filter(Boolean) : [];
}

/**
 * 这个调用者能不能写入？
 * @returns {{ allowed: boolean, reason?: string, caller?: string }}
 */
function guardWrite(ctx, what) {
  const caller = String(ctx?.callerId || '').replace(/\D/g, '');
  if (!caller) {
    // 核心没给 callerId（老版本，或不是从群消息触发的）→ 判不了，放行并留痕
    return { allowed: true, caller: '', reason: 'no-caller' };
  }
  // ① 官方能力
  let capResult = null;
  try { if (ownerCheckFn) capResult = ownerCheckFn(caller); } catch { capResult = null; }
  if (capResult && typeof capResult === 'object' && 'isOwner' in capResult) {
    if (capResult.isOwner === true) return { allowed: true, caller, via: 'capability' };
    return { allowed: false, caller, via: 'capability', reason: 'not-owner' };
  }
  // ② 兜底：直接读配置 —— ⚠️ 但**插件没启用就一律放行**
  //    （使用者 2026-10-12 明确：没有启用这个插件时默认不设置权限。
  //      哪怕 ids 里还留着旧号码，也不能因此拦住人 —— 关掉插件 = 关掉校验。）
  if (!ownerEnabledFromConfig()) {
    return { allowed: true, caller, via: 'owner-disabled', reason: 'owner-disabled' };
  }
  const ids = ownerIdsFromConfig();
  if (!ids.length) {
    // 启用了但没填主人号 → 等于没配，放行
    return { allowed: true, caller, via: 'no-owner-configured', reason: 'no-owner-configured' };
  }
  if (ids.includes(caller)) return { allowed: true, caller, via: 'config' };
  return { allowed: false, caller, via: 'config', reason: 'not-owner' };
}

/** 拒绝时统一的话术 */
function denyMessage(what, caller) {
  return '⛔ **只有主人能改竞技场强度榜**（' + what + '）。\n'
    + '这条消息来自 QQ ' + (caller || '（认不出）') + '，不在主人名单里，所以**没有写入**。\n'
    + '要授权：让主人在「主人识别」里加上你的 QQ 号，或者由主人自己来改。';
}


/** 记一笔排序变动（谁把哪张卡调哪去了，便于回溯） */
function saveOrder(ratings, faction, tier, name, relation) {
  ratings.orderLog = Array.isArray(ratings.orderLog) ? ratings.orderLog : [];
  ratings.orderLog.unshift({ at: new Date().toISOString(), faction, tier, name, relation });
  ratings.orderLog = ratings.orderLog.slice(0, 100);
  ratings.updatedAt = new Date().toISOString();
  writeJson(DATA_FILE, ratings);
}
/** 渲染某档的编号列表（1 最强） */
function renderTier(faction, tier, list) {
  return '**' + faction + ' ' + tier + ' 档**（' + (TIER_MEANING[tier] || '') + '）：\n'
    + list.map((n, i) => '  ' + (i + 1) + '. ' + n + (i === 0 ? '  ← 最强' : '')).join('\n');
}

async function runPrepare(log) {
  try {
    const manifestFile = path.join(IMAGE_DIR, 'manifest.json');
    const m = readJson(manifestFile, null);
    if (m && m.__prepared === 'rowgrid-v1') return '\n（切片已是最新，跳过 prepare）';
    const script = path.join(SKILL_DIR, 'prepare.mjs');
    if (!fs.existsSync(script)) return '\n（缺少 prepare.mjs，跳过切片）';
    const env = { ...process.env, ELECTRON_RUN_AS_NODE: '1' };
    await new Promise((resolve) => {
      const child = spawn(process.execPath, [script, IMAGE_DIR], { env, windowsHide: true });
      let out = '';
      child.stdout.on('data', (d) => { out += String(d); });
      child.stderr.on('data', (d) => { out += String(d); });
      child.on('close', () => resolve(out));
      setTimeout(() => { try { child.kill(); } catch { /* ignore */ } resolve(out); }, 10 * 60 * 1000);
    });
    const after = readJson(manifestFile, null);
    if (after) { after.__prepared = 'rowgrid-v1'; writeJson(manifestFile, after); }
    const charts = Object.values(after?.videos || {}).reduce((n, v) => n + (v.images || []).filter((i) => i.chart).length, 0);
    const rows = Object.values(after?.videos || {}).reduce((n, v) => n + (v.images || []).reduce((k, i) => k + ((i.rows || []).length), 0), 0);
    log(`arena_fetch：prepare 完成，${charts} 张强度榜 → ${rows} 张行图`);
    return `\n（已按卡片行切好：${charts} 张强度榜 → ${rows} 张行图）`;
  } catch (e) {
    return `\n（切片失败：${String(e && e.message || e).slice(0, 120)}）`;
  }
}

/** 在一份 ratings 里找某张卡（名字模糊匹配），返回 [{faction, tier, name}] */
function findCard(ratings, query) {
  const q = norm(query);
  if (!q) return [];
  const hits = [];
  for (const [faction, info] of Object.entries(ratings.factions || {})) {
    for (const [tier, names] of Object.entries(info.tiers || {})) {
      for (const name of names) {
        const n = norm(name);
        if (n === q || n.includes(q) || q.includes(n)) hits.push({ faction, tier, name, exact: n === q });
      }
    }
  }
  hits.sort((a, b) => Number(b.exact) - Number(a.exact) || a.name.length - b.name.length);
  return hits;
}

/**
 * 阵营名归一化。主播为了躲平台关键词把阵营写成谐音错字（酥莲/瑛國/渼國…），
 * 模型经常照抄成阵营名存进去 —— 线上真的出现过一条「渼國(美国)」的空条目。
 * 所以**不靠模型记**，这里统一折算成标准名。
 */
const FACTION_ALIAS = {
  酥莲: '苏联', 苏莲: '苏联', 蘇聯: '苏联', 苏联: '苏联', soviet: '苏联',
  瑛國: '英国', 瑛国: '英国', 英國: '英国', 英国: '英国', britain: '英国',
  渼國: '美国', 渼国: '美国', 美國: '美国', 美国: '美国', usa: '美国',
  法国: '法国', 法國: '法国', 芬兰: '芬兰', 芬蘭: '芬兰', 波兰: '波兰', 波蘭: '波兰',
  澳新: '澳新', anzus: '澳新', anzac: '澳新', 日本: '日本', 德国: '德国', 德國: '德国'
};
function normalizeFaction(input) {
  const raw = String(input || '').trim();
  if (!raw) return '';
  // 去掉「渼國(美国)」这种括号尾巴，只取括号里/括号外的标准名
  const inParen = raw.match(/[（(]\s*([^）)]+)\s*[）)]/);
  const candidates = [inParen ? inParen[1] : '', raw.replace(/[（(][^）)]*[）)]/g, ''), raw];
  for (const c of candidates) {
    const key = String(c).trim().toLowerCase();
    if (FACTION_ALIAS[key]) return FACTION_ALIAS[key];
    const zh = FACTION_ALIAS[String(c).trim()];
    if (zh) return zh;
  }
  return raw;
}

/**
 * 标准阵营名 → 站内卡池 API 的 faction 参数。
 * ⚠️ 提到模块级（2026-10-11）：原先它写在 arena_record.execute 里面，
 *    arena_pick 的卡池查询（fetchPool）在另一个闭包里，拿不到 → 会 ReferenceError。
 */
const FACTION_EN = { 苏联: 'Soviet', 英国: 'Britain', 美国: 'USA', 波兰: 'Poland', 澳新: 'Anzac', 德国: 'Germany', 法国: 'France', 芬兰: 'Finland', 日本: 'Japan', 意大利: 'Italy' };

function summarize(ratings) {
  const factions = Object.entries(ratings.factions || {});
  if (!factions.length) return '还没有任何竞技场评分数据（先按「重新读取竞技场评分」按钮抓一期）。';
  const lines = [`数据版本：${ratings.version || '（未标注）'}｜更新于 ${ratings.updatedAt || '未知'}`];
  for (const [faction, info] of factions) {
    const tiers = Object.entries(info.tiers || {});
    const total = tiers.reduce((s, [, names]) => s + names.length, 0);
    lines.push(`· ${faction}：${total} 张（${tiers.map(([t, n]) => `${t}档${n.length}张`).join('、')}）`);
  }
  return lines.join('\n');
}

/** 把 manifest 渲染成给模型看的清单（含"下一步必须做"的指令） */
function renderManifest(prefix, manifest) {
  const lines = [];
  if (prefix) lines.push(prefix);
  lines.push(`最新合集：${manifest.collection}`);
  lines.push(`视频 ${Object.keys(manifest.videos || {}).length} 期，强度图：`);
  for (const [bv, info] of Object.entries(manifest.videos || {})) {
    lines.push(`· ${String(info.title).slice(0, 40)}｜${bv}｜${(info.images || []).length} 张`);
    for (const img of info.images || []) {
      const mark = img.chart === true ? '★强度榜' : (img.chart === false ? '不是' : '未判定');
      lines.push(`    [${mark}] ${img.path}${img.size ? '  ' + img.size : ''}${img.leftColorBands != null ? '  左栏色带' + img.leftColorBands : ''}`);
      for (const p of img.parts || []) lines.push(`        ↳ 放大切片：${p.path}  ${p.size || ''}（原图第 ${p.rows || '?'} 行）`);
    }
  }
  lines.push('', '---', '**下一步（必须做）**：**读 ★强度榜 那张的「放大切片」文件（…_partN.png），不要直接读原图** —— '
    + '原图卡名只有 5~7 像素高，你念不出来（线上实测就是这样卡住的）；切片是放大 3 倍的，卡名清楚。'
    + '用 read_image 一张张读，把「阵营 → 档位 → 卡名」用 arena_record 记下来'
    + '（阵营从视频标题认：酥莲=苏联、瑛國=英国、渼國=美国）；一次读不完就分批读，记完再告诉群友这期更新了什么。'
    + '\n**兜底**：如果某个阵营**一张都没有标出 ★强度榜**，就把那期剩下的图**也看一遍**（尤其是很高的超长图、'
    + '或看起来像"左边一列彩色等级格"的图）—— 标注只是辅助，别因为没标就跳过。'
    + '确认确实没有榜图，就如实说「这期没找到该阵营的榜图」，**不要编**。');
  return lines.join('\n');
}

/** 视频标题 → 阵营（UP 用谐音错字躲关键词：酥莲=苏联、瑛國=英国、渼國=美国） */
const FACTION_FROM_TITLE = [
  [/酥莲|苏联/, '苏联'], [/瑛國|瑛国|英国/, '英国'], [/渼國|渼国|美国/, '美国'],
  [/法国/, '法国'], [/芬兰/, '芬兰'], [/波兰/, '波兰'], [/澳新/, '澳新'], [/日本/, '日本'], [/德国|火山环带/, '德国']
];
function factionOfTitle(title) {
  for (const [re, name] of FACTION_FROM_TITLE) if (re.test(String(title || ''))) return name;
  return '';
}

/** 待读队列：manifest 里有榜图的阵营 - 已入库的阵营 */
function buildTodo() {
  const manifest = readJson(path.join(IMAGE_DIR, 'manifest.json'), null);
  const ratings = loadRatings();
  if (!manifest) return { done: false, pending: [], message: '还没有抓过图（先 arena_fetch）' };
  const have = new Set(Object.keys(ratings.factions || {}));
  const pending = [];
  for (const [bv, info] of Object.entries(manifest.videos || {})) {
    const faction = factionOfTitle(info.title);
    if (!faction || have.has(faction)) continue;
    const charts = (info.images || []).filter((x) => x.chart === true);
    if (!charts.length) continue;
    pending.push({
      faction, bv, title: info.title,
      charts: charts.map((c) => ({
        path: c.path, size: c.size,
        rows: (c.rows || []).map((r) => r.path),          // 档位行图（一行一档，主力）
        parts: (c.parts || []).map((p) => p.path)         // 旧的分段切片（兼容）
      }))
    });
  }
  return { done: pending.length === 0, pending, collected: [...have] };
}

// ── 缺「KARDS 强制查询」插件时的提醒（半小时内不重复念）──
let isTrigActive = () => true;
let __trigTipAt = 0;
function triggerPluginHint() {
  if (isTrigActive()) return "";
  if (Date.now() - __trigTipAt < 30 * 60 * 1000) return "";
  __trigTipAt = Date.now();
  return '\n\n💡 **提醒**：没检测到「**KARDS 强制查询**」插件（id: kards-trigger）在生效。'
    + '没有它的话，机器人不保证"该查卡的时候一定先去查"（可能凭记忆回答，容易报错数据）。'
    + '建议在「**设置 → 插件**」里安装并启用「**KARDS 强制查询**」。';
}

export function setup(api) {

  // ── 提醒：缺「KARDS 强制查询」插件（使用者 2026-10-12 要求）────────────
  // 场景：装了本技能、却没装/没启用 kards-trigger —— 那样"该查的时候一定先查"
  // 这层确定性保障就没了（模型可能凭记忆瞎答）。检测到缺失就**主动告知用户去装**，
  // 必须给出插件名称。用 api.isSkillActive 判定（核心的启停状态，含"没装"）。
  if (typeof api?.isSkillActive === "function") {
    isTrigActive = () => {
      try { return api.isSkillActive("kards-trigger") === true; } catch { return true; }
    };
  }
  const __rawRegister = typeof api?.registerTool === "function" ? api.registerTool.bind(api) : null;
  if (__rawRegister) {
    api.registerTool = (def) => {
      const orig = def && typeof def.execute === "function" ? def.execute : null;
      if (!orig) return __rawRegister(def);
      const wrapped = Object.assign({}, def, {
        execute: async (ctx, args) => {
          const r = await orig(ctx, args);
          try {
            if (r && typeof r.content === "string" && !isTrigActive()) r.content += triggerPluginHint();
          } catch { /* 提示失败不影响主流程 */ }
          return r;
        }
      });
      return __rawRegister(wrapped);
    };
  }

  // 主人识别（owner-identity 插件）：软依赖 —— 没有这个能力就照常工作
  if (typeof api?.capability === 'function') ownerCheckFn = (id) => api.capability('message.owner-check', { userId: id });
  if (typeof api?.hasCapability === 'function') hasOwnerCap = () => api.hasCapability('message.owner-check');
  cfg = api.config;
  log = typeof api.log === 'function' ? api.log : () => {};

  api.registerTool({
    id: 'arena_todo',
    name: '竞技场评分·待读队列',
    description: '取出**下一个还没入库的阵营**的强度图（含放大切片路径）。'
      + '**读完一个阵营就用 arena_record 记下来，然后再调一次本工具取下一个**，直到它返回「全部读完了」。'
      + '这是「jjc更新」之后推进读图的标准方式：一次只处理一个阵营，别想一口气读完所有图。',
    category: 'knowledge',
    icon: '📋',
    parameters: { type: 'object', properties: {} },
    execute() {
      const todo = buildTodo();
      if (!todo.done && !todo.pending.length) {
        return { content: `待读队列：${todo.message}\n已入库：${(todo.collected || []).join('、') || '（空）'}` };
      }
      if (todo.done) {
        return { content: `✅ 全部读完了，已入库：${todo.collected.join('、')}。\n如果群友还要更新，就说一句「jjc更新」。` };
      }
      const one = todo.pending[0];
      const lines = [
        `📋 待读 ${todo.pending.length} 个阵营，本次处理：**${one.faction}**（${one.bv}）`,
        `视频：${one.title}`,
        '',
        '**下面会直接附上这个阵营的"档位行图"（一档一张，左边彩色条上的数字/文字就是档位）**：'
      ];
      lines.push('',
        `**本阵营标准名：${one.faction}** —— 视频标题里写的是主播的谐音错字（酥莲=苏联、瑛國=英国、渼國=美国），`
        + '**记录时用标准名**（工具也会自动归一，但你别写错）。',
        '档位就是图上**左边那列彩色条**上的标记：`5 / 4.5 / 4 / 3.5 / 3 / 2.5 / 2 / 1 / 0 / ??`（0 档叫"神卡"）。',
        `读完这个阵营，立刻调用 arena_record：{"faction":"${one.faction}","version":"澳新风暴","tiers":{"5":["卡名",...],"4.5":[...]}}`,
        '**只写图上确实看清的**；看不清的档位/卡名不要写进去（宁缺毋滥）。',
        '记完再调一次 arena_todo 取下个阵营。',
        '',
        '⛔ **重要：图片已经在下面直接给你了，请"用眼睛看"它们，禁止调用任何读图工具**'
        + '（`read_image` / `explain_image` / `list_viewable_images` 一律不许用 —— 它们读不了技能目录里的文件，'
        + '线上实测你为这个白白烧掉十几轮）。看完直接写结论。');
      // ⚠️ 关键：把"档位行图"作为图片直接塞进工具结果（核心会当成 user 消息里的 image 部分发给模型）。
      //    一行一档的小图（~100-250KB JPEG）比整张大图好读得多 —— 大图模型常常消化不了、转而去调别的工具。
      const rowFiles = one.charts.flatMap((c) => (c.rows || c.parts || []).map((r) => (typeof r === 'string' ? r : r.path))).slice(0, 12);
      const images = [];
      for (const p of rowFiles) {
        try {
          const buf = fs.readFileSync(p);
          if (buf.length > 3 * 1024 * 1024) continue;
          const mime = /\.png$/i.test(p) ? 'image/png' : 'image/jpeg';
          images.push({ type: 'image_url', image_url: { url: `data:${mime};base64,${buf.toString('base64')}` } });
        } catch { /* 读不到就跳过 */ }
      }
      if (images.length) {
        lines.push('', `（已附上 ${one.faction} 的 ${images.length} 张档位行图，直接看图，不要调用任何读图工具。）`);
        return { content: [{ type: 'text', text: lines.join('\n') }, ...images] };
      }
      return { content: lines.join('\n') };
    }
  });

  api.registerTool({
    id: 'arena_rating',
    name: '竞技场评分查询',
    description: '查 B 站「华南有只虎」《版本竞技场评分》里某张卡的竞技场强度档位（0~5，5 最强），'
      + '也可以按阵营列出各档位的卡（要「XX 强度榜」就带 faction）。'
      + '**群友问竞技场强度/强度榜时必须先调用本工具**，不要凭印象回答、也不要先说抓不到。'
      + '如果返回「评分表里没有这个阵营/这张卡」，**先请群友直接发一张强度图**（最快最准）；群友不方便发，再调用 arena_fetch 去抓本地现成的图。',
    category: 'knowledge',
    icon: '🏆',
    parameters: {
      type: 'object',
      properties: {
        name: { type: 'string', description: '卡名（可只给一部分，如「白色死神」）' },
        faction: { type: 'string', description: '阵营，如 芬兰 / 法国 / 苏联（可选，配合 tier 用）' },
        tier: { type: 'string', description: '档位，如 5 / 4.5 / 3（可选，配合 faction 用）' }
      }
    },
    execute(_ctx, args) {
      const ratings = loadRatings();
      const name = String(args?.name || '').trim();
      const faction = String(args?.faction || '').trim();
      const tier = String(args?.tier ?? '').trim();
      if (name) {
        const hits = findCard(ratings, name);
        if (!hits.length) return { content: `评分表里没有「${name}」。\n${summarize(ratings)}\n（可能是这期榜单没收录，或名字写法不同；可以让群友确认一下卡名。）` };
        return {
          content: `「${name}」的竞技场评分：\n` + hits.slice(0, 5).map((h) => `· ${h.faction} **${h.tier} 档**（${TIER_MEANING[h.tier] || ''}）→ 榜单上写作「${h.name}」`).join('\n')
            + `\n（版本：${ratings.version || '未标注'}；来源：B 站《版本竞技场评分》系列视频评论区的强度图）`
        };
      }
      if (faction) {
        const info = (ratings.factions || {})[faction];
        if (!info) return { content: `评分表里没有「${faction}」这个阵营。\n${summarize(ratings)}` };
        const tiers = Object.entries(info.tiers || {}).filter(([t]) => !tier || t === tier);
        if (!tiers.length) return { content: `「${faction}」没有 ${tier} 档。` };
        // 档内**按数组顺序编号**（数组顺序就是强弱顺序：1 最强）：使用者 2026-10-12 要求
        const render = ([t, names]) => {
          const list = Array.isArray(names) ? names : [];
          if (!list.length) return `**${t} 档**（${TIER_MEANING[t] || ''}）：（空）`;
          return `**${t} 档**（${TIER_MEANING[t] || ''}）：\n`
            + list.map((n, i) => `  ${i + 1}. ${n}`).join('\n');
        };
        return {
          content: `${faction}（${ratings.version || ''}）竞技场评分（**档内按强弱排序，1 最强**）：\n`
            + tiers.map(render).join('\n')
            + '\n\n（档位本身也分高低：9 > 5 > 4.5 > 4 > 3.5 > 3 > 2.5 > 2 > 1 > 0。'
            + '觉得某张牌在同档里该排更前/更后，就说「XX 比 YY 强」或「XX 比 YY 弱」。）'
        };
      }
      return { content: summarize(ratings) };
    }
  });

  // ── 三选一选卡（2026-10-11 加）────────────────────────────────────────
  // 「n x」= **这一选会往你卡组里塞 n 张**。
  //   使用者 2026-10-11 两次更正后的最终口径：
  //   ① 它不是"你已有几张"，而是"选了就把这 n 张塞进卡组"（4x → 4 张进卡组）。
  //   ② **n 与稀有度完全无关** —— 它只说明"这一选给你几张"。
  //      稀有度**必须按卡名去卡池查**（cards-meta.json 的 rarity 字段）。
  //      反例实证：白色死神的 n=1，但它真实稀有度是 Special(银卡)，不是精英。
  //   实战含义：n 大 = 这次多塞几张（数量收益）；单卡强弱/稀有度看**卡池查出来的真实值**。
  // 「论外」仍然保留，但改成**按查出来的 Elite(精英/金卡)** 判定，与 n 无关。
  // 曲线数据（右侧卡组列表）是**可选**输入：给了才做补缺口判断，没给就只比档位。
  /** 卡池 rarity → 中文俗称（铁=普通、铜=限定、银=特殊、金=精英；别弄反金/银） */
  const RARITY_ZH = {
    Standard: { official: '普通', common: '铁卡' },
    Limited: { official: '限定', common: '铜卡' },
    Special: { official: '特殊', common: '银卡' },
    Elite: { official: '精英', common: '金卡' }
  };
  /** 按卡名（+可选阵营）查**真实稀有度**；查不到就返回 null（**绝不从 n 反推**） */
  const rarityByName = (name, factionZh) => {
    const pool = factionZh ? poolByFaction(factionZh) : loadPool();
    const key = norm(name);
    if (!key) return null;
    const hit = pool.find((c) => norm(c.name) === key)
      || pool.find((c) => key.length >= 3 && norm(c.name).includes(key));
    if (!hit) return null;
    const zh = RARITY_ZH[hit.rarity];
    return zh ? { ...zh, rarity: hit.rarity, canonical: hit.name } : null;
  };
  /** 高优先级档位（比"分高的更强"，但先看它最高能到哪一档） */
  const TIER_RANK = ['5', '4.5', '4', '3.5', '3', '2.5', '2', '1', '0'];
  const tierRank = (t) => {
    const i = TIER_RANK.indexOf(String(t));
    return i < 0 ? TIER_RANK.length : i;
  };

  // 卡池（站内 API）带 TTL 缓存：一次选卡最多拉 1~2 个阵营，避免每张卡都单独请求。
  // 站内域名偶尔 DNS 解析失败 —— 拉不到就**降级**（档位照常查，费用/攻防以截图为准）。
  const poolCache = new Map();
  const POOL_TTL = 30 * 60 * 1000;
  async function fetchPool(faction) {
    const cached = poolCache.get(faction);
    if (cached && Date.now() - cached.at < POOL_TTL) return cached.pool;
    const en = FACTION_EN[faction];
    const pool = [];
    if (en) {
      for (let page = 1; page <= 4; page++) {
        try {
          const res = await fetch(`https://qwq.wards.mom/api/collection/cards?faction=${en}&limit=100&page=${page}`, { headers: { 'User-Agent': 'QQ-Agent/arena-rating' } });
          const j = await res.json();
          if (!Array.isArray(j.cards) || !j.cards.length) break;
          for (const c of j.cards) {
            pool.push({
              name: String(c.name_zh || ''), cost: Number(c.kredits ?? c.cost),
              attack: Number(c.attack), defense: Number(c.defense),
              rarity: String(c.rarity || ''), type: String(c.type || ''),
              faction // ⚠️ 必须带上：跨阵营选卡时要靠它标出每张卡的真实阵营
            });
          }
          if (j.hasMore !== true) break;
        } catch { break; }
      }
    }
    poolCache.set(faction, { at: Date.now(), pool });
    return pool;
  }

  /**
   * 全局卡池：把**所有阵营**的卡池一次拉全（并行），带 30 分钟缓存。
   * 为什么需要它：三选一的三张卡**不一定同阵营**（使用者实测：法国那选里出现美国卡），
   * 只查一个阵营的池子就会把别国的卡判成"查不到"。
   * @returns {{ pool: Array, byName: Map }} pool 每项带 faction 字段；byName 以归一化卡名为键
   */
  let globalPoolCache = null;
  async function fetchGlobalPool() {
    if (globalPoolCache && Date.now() - globalPoolCache.at < POOL_TTL) return globalPoolCache;
    const factions = Object.keys(FACTION_EN);
    const pools = await Promise.all(factions.map((f) => fetchPool(f).catch(() => [])));
    const pool = [];
    const byName = new Map();
    for (const list of pools) {
      for (const c of list) {
        pool.push(c);
        const key = norm(c.name);
        if (!byName.has(key)) byName.set(key, c);
      }
    }
    globalPoolCache = { at: Date.now(), pool, byName };
    return globalPoolCache;
  }

  /** 在本地评分表里找档位（优先精确命中；跨阵营，除非指定了 faction） */
  function findTier(ratings, name, faction) {
    const q = norm(name);
    if (!q) return null;
    let partial = null;
    const entries = faction
      ? (ratings.factions?.[faction] ? [[faction, ratings.factions[faction]]] : [])
      : Object.entries(ratings.factions || {});
    for (const [fac, info] of entries) {
      for (const [tier, names] of Object.entries(info.tiers || {})) {
        for (const n of names) {
          const nn = norm(n);
          if (!nn) continue;
          // ⚠️ 精确命中必须优先于部分命中：不能"先撞上谁就返回谁"，
          //    否则跨阵营搜「拦截」会拿到另一个阵营里名字更长的卡（线上会给出错误档位）。
          if (nn === q) return { faction: fac, tier, name: n, exact: true };
          if (!partial && (nn.includes(q) || q.includes(nn))) partial = { faction: fac, tier, name: n, exact: false };
        }
      }
    }
    return partial;
  }

  /** 右侧卡组列表（可选）：支持 {name,cost,count} 数组，或 "卡名:费用x数量" 字符串数组 */
  function parseDeck(input) {
    const raw = Array.isArray(input) ? input : (typeof input === 'string' ? input.split(/[\n;；]+/) : []);
    const out = [];
    for (const item of raw) {
      let name = '', count = 1, cost = null;
      if (typeof item === 'string' && item.trim()) {
        name = item.trim();
        let m = name.match(/^(.*?)[\s:：]*(\d+)\s*[xX×]\s*(\d+)\s*$/);       // 卡名:费用x数量
        if (m) { name = m[1].trim(); cost = Number(m[2]); count = Number(m[3]); }
        else {
          m = name.match(/^(.*?)[\s:：]*[xX×]?\s*(\d+)\s*$/);                 // 卡名 x2 / 卡名 2
          if (m) { name = m[1].trim(); count = Number(m[2]); }
        }
      } else if (item && typeof item === 'object') {
        name = String(item.name ?? item.card ?? '').trim();
        count = Number(item.count ?? item.copies ?? item.n ?? 1) || 1;
        cost = item.cost != null ? Number(item.cost) : null;
      }
      name = name.replace(/[（(]\s*[）)]/g, '').trim();
      if (!name) continue;
      out.push({ name, count: Math.max(1, Math.min(9, count)), cost: Number.isFinite(cost) ? cost : null });
    }
    return out;
  }
  const costOf = (c) => (Number.isFinite(Number(c?.cost)) ? Number(c.cost) : null);
  /** 按费用 × 份数统计曲线（费用未知的跳过） */
  function curveOf(items) {
    const map = new Map();
    for (const it of items) {
      const k = costOf(it);
      if (k == null) continue;
      map.set(k, (map.get(k) || 0) + (Number(it.count) || 1));
    }
    return map;
  }
  const curveText = (map) => {
    const keys = [...map.keys()].sort((a, b) => a - b);
    if (!keys.length) return '';
    return keys.map((k) => `${k}费×${map.get(k)}`).join('  ');
  };

  /** 名字里的数字串（「步兵第634团」→ "634"）。数字不一致一律不算同一张卡。 */
  const numOf = (s) => (String(s).match(/\d+/g) || []).join(',');

  /**
   * 把读图得来的卡名归一到站内写法（口径与 arena_record 完全一致）：
   *   ① 归一化后精确命中 → 用站内写法
   *   ② 数字一致 + 长度相近(±1) + 字符重合 ≥0.75 → 判为同一张卡
   *   ③ 其余 → null（对不上就不认，宁缺毋滥；**绝不允许靠猜数字**）
   */
  function resolvePoolName(pool, name) {
    const q = norm(name);
    if (!q) return null;
    for (const c of pool) if (norm(c.name) === q) return c;
    const qd = numOf(name);
    let best = null; let bs = 0;
    for (const c of pool) {
      const cn = norm(c.name);
      if (numOf(c.name) !== qd) continue;                    // 数字不同 → 直接排除
      if (Math.abs(cn.length - q.length) > 1) continue;
      const setQ = new Set(q);
      let ov = 0;
      for (const ch of new Set(cn)) if (setQ.has(ch)) ov += 1;
      const s = ov / Math.max(cn.length, q.length);
      if (s > bs) { bs = s; best = c; }
    }
    return best && bs >= 0.75 ? best : null;
  }

  api.registerTool({
    id: 'arena_pick',
    name: '竞技场选卡（三选一）',
    description: '竞技场「三选一」选卡建议：把三张卡的卡名/费用/攻防/特效 + 卡下面的「n x」+ 右侧当前卡组列表交给它，'
      + '它按「这一选各给几张（n x）+ 竞技场档位 + 卡组费用曲线」给出选哪张和理由。'
      + '**n x 是"选它会往卡组里塞几张"，不是稀有度标签、也不是你已有几张**。'
      + '**群友发来三选一截图问"选哪张/怎么选"时必须先调用本工具**，不要凭印象挑。',
    category: 'knowledge',
    icon: '🎯',
    parameters: {
      type: 'object',
      properties: {
        faction: { type: 'string', description: '本选所属阵营（截图右上/标题上的，如 芬兰 / 苏联）。跨阵营搜档位会影响准确性，能给就给。' },
        cards: {
          type: 'array',
          description: '三张候选卡，每张一个对象（画面上从左到右的顺序）。卡名务必按图上原话填。',
          items: {
            type: 'object',
            properties: {
              name: { type: 'string', description: '卡名（图上原话）' },
              cost: { type: 'number', description: '费用（左上角的数字，如 2 = 2K）' },
              attack: { type: 'number', description: '攻击力' },
              defense: { type: 'number', description: '防御力' },
              type: { type: 'string', description: '卡牌类型，如 步兵 / 坦克 / 火炮 / 战斗机 / 指令 / 反制' },
              effect: { type: 'string', description: '特效文字（可选）' },
              copies: { type: 'number', description: '卡下面标的那个 n（4/3/2/1）＝**选它会往卡组里塞几张**，与稀有度**完全无关**。稀有度由本工具按卡名去卡池查，别从 n 推断。看不清就不填。' }
            },
            required: ['name']
          }
        },
        deck: {
          type: 'array',
          description: '（可选但强烈建议）右侧当前卡组列表，每张一个对象 {name, cost, count}。给了才能判断"补费用曲线"；'
            + '没给就只比档位。',
          items: {
            type: 'object',
            properties: {
              name: { type: 'string' },
              cost: { type: 'number' },
              count: { type: 'number' }
            }
          }
        }
      },
      required: ['cards']
    },
    async execute(_ctx, args) {
      let rawCards = (Array.isArray(args?.cards) ? args.cards : []).filter((c) => c && String(c.name || '').trim());
      if (!rawCards.length) return {
        // ⚠️ 插件现在"带图 + 沾选字"就会启用选卡通道，所以这里也会被非卡牌的图调到 —— 说清楚，别让模型硬凑三张卡
        content: '没拿到三张候选卡，所以这不是一次竞技场三选一（或者图没读清）。\n'
          + '· 如果图里**确实是左中右三张 KARDS 卡**：请把三张卡的卡名读出来，重新调用本工具（cards 至少要有 name）。\n'
          + '· 如果图里**不是卡牌图**（风景、表情包、别的游戏）：**就按图片本来的内容正常回答**，不用讲选卡。',
        isError: true
      };
      if (rawCards.length > 4) rawCards = rawCards.slice(0, 4);
      const factionArg = normalizeFaction(args?.faction) || '';
      const deck = parseDeck(args?.deck);

      const ratings = loadRatings();
      // 每张卡：读档位（本地表，**跨阵营**）+ 卡片详情（站内卡池，拉不到就用截图给的数值）
      const items = [];
      // ⚠️ 2026-10-11 重要修正：**三选一的三张卡不一定同阵营**（使用者实测：法国那选里出现美国卡）——
      //    以前只查 `faction` 那一个卡池，别的阵营的卡就"查不到/没对上"。现在：
      //    ① 档位一律**跨阵营**搜（faction 只当提示，局中卡没查到就全局找）；
      //    ② 卡名归一用**全局卡池**（一次拉全阵营，30 分钟缓存），并记录每张卡的真实阵营。
      const globalPool = await fetchGlobalPool();
      const inGlobal = globalPool.pool.length > 0;
      for (const rc of rawCards) {
        const name = String(rc.name).trim();
        const hit = findTier(ratings, name, factionArg) || findTier(ratings, name, '');
        // 读图给的卡名可能是繁体/异体写法 → 用站内卡池归一（和 arena_record 一样的口径）
        const fromGlobal = inGlobal ? resolvePoolName(globalPool.pool, name) : null;
        let canon = fromGlobal;
        let canonFaction = fromGlobal ? globalPool.byName.get(norm(fromGlobal.name))?.faction || '' : '';
        if (!canon) {
          // 全局没对上：退回"档位命中的阵营 / 传入的阵营"的卡池再试一次
          const guess = hit?.faction || factionArg || '';
          if (guess) {
            const p = await fetchPool(guess);
            const c2 = p.length ? resolvePoolName(p, name) : null;
            if (c2) { canon = c2; canonFaction = guess; }
          }
        }
        const faction = canonFaction || hit?.faction || factionArg || '';
        items.push({
          key: String(rc.key || name),
          given: name,
          name: canon ? canon.name : name,
          renamed: canon && canon.name !== name,
          rawCost: Number(rc.cost), rawAtk: Number(rc.attack), rawDef: Number(rc.defense),
          type: String(rc.type || canon?.type || ''),
          effect: String(rc.effect || ''),
          copies: Number(rc.copies),
          faction: faction || '',
          cost: canon && Number.isFinite(canon.cost) ? canon.cost : (Number.isFinite(Number(rc.cost)) ? Number(rc.cost) : null),
          attack: Number.isFinite(Number(rc.attack)) ? Number(rc.attack) : (canon ? canon.attack : null),
          defense: Number.isFinite(Number(rc.defense)) ? Number(rc.defense) : (canon ? canon.defense : null),
          tier: hit ? String(hit.tier) : null,
          tierName: hit ? hit.name : null,
          tierFaction: hit ? hit.faction : null,
          tierApprox: hit ? !hit.exact : false,
          inPool: !!canon
        });
      }

      // ① 稀有度 ② 档位 ③ 曲线
      const deckCurve = curveOf(deck);
      const deckTotal = [...deckCurve.values()].reduce((a, b) => a + b, 0);
      const slots = items.map((it) => {
        const cost = costOf(it);
        // 稀有度**按卡名去卡池查**（与 n 无关）；档位查不到也照样把稀有度查出来
        const rare = rarityByName(it.name, it.faction || factionArg);
        if (it.tier == null) {
          return { ...it, rare, power: null,
            reason: `本地评分表里查不到这张卡的档位${rare ? `（稀有度：${rare.official}${rare.common}）` : ''}` };
        }
        const power = tierRank(it.tier);
        // 「n x」缺失时**默认 1 张**（使用者 2026-10-11 定的）：卡下面没标 n 的按给 1 张算。
        // 这在"三张都不超过 3 档"的规则里很关键 —— 否则没标的会被当成"说不清"排到最后，
        // 而它其实往往正是最该选的那张（给得少）。
        const copiesNum = Number(it.copies);
        const copiesN = Number.isFinite(copiesNum) && copiesNum > 0 ? copiesNum : 1;
        const copiesDefault = !(Number.isFinite(copiesNum) && copiesNum > 0);
        const nTxt = `，这一选给 ${copiesN} 张${copiesDefault ? '（图上没标 n，按 1 张算）' : ''}`;
        const before = (deckCurve.get(cost) || 0) + 1;
        const used = deckTotal + 1;
        const reason = deckTotal
          ? `档位 ${it.tier}（第 ${power + 1} 优先）${nTxt}；` +
            `加上它 ${cost} 费变 ${before} 张（本次已选 ${used} 张，占比 ${(before / used * 100).toFixed(0)}%）`
          : `档位 ${it.tier}（第 ${power + 1} 优先）${nTxt}。没给卡组列表，没法算曲线`;
        return { ...it, rare, power, reason, copies: copiesN, copiesDefault };
      });

  // 「论外」= 卡池查出来是 **Elite(精英/金卡)**（与 n 无关）。
  //   使用者 2026-10-11 说明：**金卡只有主国才有 —— 德国 / 日本 / 美国 / 英国 / 苏联**
  //   （其他阵营都是盟国，没有金卡；法国也不是主国）。
  //   而且金卡**出现概率太低，所以当初就没放进评分表** —— 这正是"论外"的来源：
  //   评分表里查不到它，不是读图读漏了，是它本来就不在榜里。
  //   所以精英卡：不套常规档位比较，单独看它的特效值不值。
      const isElite = (c) => !!(c.rare && c.rare.rarity === 'Elite');
      // ⚠️ 精英卡**不能加 c.power != null 的条件**：金卡概率太低、本来就没进评分表，
      //    所以它的 power 常常就是 null —— 加了条件反而会把"最该论外的那类"漏掉（实测踩过）。
      const ranked = slots.filter((c) => c.power != null && !isElite(c));
      const elites = slots.filter((c) => isElite(c));
      const unknown = slots.filter((c) => c.power == null && !isElite(c));

      // 冠军选取规则（使用者 2026-10-11 加的第 2 条）：
      //   ① 默认看**档位最高**（并列时看稀有度，再并列时看费用曲线缺口）
      //   ② **若三张卡的档位都不超过 3 分（含 3 分）** → 改看**这一选给几张**，
      //      **优先推荐给牌数最少的那组**：品质都没拉开时，少塞几张进卡组更划算
      //      （3 分以下多给 4 张，等于往卡组里塞 4 张弱牌）。
      let winner = null; let best = null; let reasonText = '';
      const allWeak = ranked.length && ranked.every((c) => tierRank(c.tier) >= tierRank('3'));
      if (allWeak) {
        // 按 copies 升序（少 → 多）。copies 已在上面统一成"缺省=1张"，所以不需要特殊兜底
        const byN = ranked.slice().sort((a, b) => {
          const na = Number(a.copies) || 1;
          const nb = Number(b.copies) || 1;
          return na - nb
            || a.power - b.power                                    // 给牌数相同 → 档位更高的优先
            || ((b.rare ? 1 : 0) - (a.rare ? 1 : 0))
            || ((curveOf([b]).get(costOf(b)) || 0) - (curveOf([a]).get(costOf(a)) || 0));
        });
        best = byN[0]; winner = best;
        const sameN = byN.filter((c) => (Number(c.copies) || 1) === (Number(best.copies) || 1));
        const nList = ranked.map((c) => `${Number(c.copies) || 1}张`).join(' / ');
        const defNote = ranked.some((c) => c.copiesDefault) ? '（图上没标 n 的按 1 张算）' : '';
        if (sameN.length === 1) {
          reasonText = `**三张都不超过 3 档**（${ranked.map((c) => `${c.name} ${c.tier}档`).join('、')}）—— 品质没拉开，`
            + `按「**少塞几张进卡组**」选：它这一选只给 ${Number(best.copies) || 1} 张（三张分别是 ${nList}）${defNote}`;
        } else {
          reasonText = `**三张都不超过 3 档**（${ranked.map((c) => `${c.name} ${c.tier}档`).join('、')}）—— 品质没拉开，`
            + `优先「**少塞几张进卡组**」：${sameN.length} 张都是 ${Number(best.copies) || 1} 张，`
            + `**给牌数相同时取分数最高的那张** → 选 ${best.name}（${best.tier} 档）${defNote}`;
        }
      } else if (ranked.length) {
        ranked.sort((a, b) =>
          a.power - b.power
          || (Number(a.tierApprox) - Number(b.tierApprox))     // 精确命中优先于"只匹配到名字一部分"
          || ((b.rare ? 1 : 0) - (a.rare ? 1 : 0))
          || ((curveOf([b]).get(costOf(b)) || 0) - (curveOf([a]).get(costOf(a)) || 0)));
        best = ranked[0]; winner = best;
        const tied = ranked.filter((c) => c.power === best.power);
        const nTxtBest = Number.isFinite(Number(best.copies)) ? `，这一选给 ${best.copies} 张` : '';
        if (tied.length === 1) {
          reasonText = `档位最高（${best.tier}）${nTxtBest}`
            + `${best.rare ? `，稀有度 ${best.rare.official}(${best.rare.common})` : '，稀有度卡池里没查到'}`;
        } else {
          reasonText = `同为 ${best.tier} 档（并列 ${tied.length} 张）→ 按稀有度取更高的那张（稀有度按卡名查卡池，与 n 无关）`
            + '，再按卡组费用曲线取更缺的那一档';
        }
      } else if (elites.length) {
        winner = elites[0];
        reasonText = '三张里只有这张是**精英（金卡）**（按卡池查出来的稀有度，与它给几张无关）—— 金卡只有主国才有、且概率太低没进评分表，按「论外」单独看';
      } else {
        reasonText = '三张卡在本地评分表里都没查到档位 —— 只能看费用曲线与特效，别硬套档位';
      }

      const deco = (c) => {
        let s = '—';
        if (c.cost != null && c.attack != null) s = `${c.cost}K  ${c.attack}/${c.defense}`;
        else if (c.cost != null) s = `${c.cost}K`;
        return s;
      };
      // 表里两件事分开写：**这一选给几张**（看 n）和**稀有度**（看卡池查出来的值）——两者无关
      const rareOf = (c) => {
        const nn = Number(c.copies) || 1;
        const n = `给 ${nn} 张${c.copiesDefault ? '(未标,默认1)' : ''}`;
        const r = c.rare ? `${c.rare.official}${c.rare.common}` : '稀有度未查到';
        return `${n} / ${r}`;
      };
      const tierOf = (c) => {
        if (c.tier == null) return '查不到';
        // 模糊命中（群友/模型只写了名字的一部分）要标出来，免得把"相近的另一张卡"当成这张
        return c.tierApprox ? `${c.tier} 档（近似「${c.tierName}」）` : `${c.tier} 档`;
      };
      const mark = (c) => (c === winner ? ' ⬅︎ 选它' : (c.rare && c.rare.rarity === 'Elite' ? ' （论外）' : ''));

      // ⚠️ 三张卡**不一定同阵营** → 每张都标出它的真实阵营，别让群友以为都是本选阵营的
      const facCount = new Set(items.map((x) => x.faction).filter(Boolean)).size;
      const head = facCount > 1
        ? `【竞技场选卡】跨阵营（本选含 ${[...new Set(items.map((x) => x.faction).filter(Boolean))].join('、')}）`
        : `【竞技场选卡】${factionArg || items.map((x) => x.faction).find(Boolean) || '阵营未给'}`;
      const lines = [head];
      lines.push('```');
      lines.push(`卡名（阵营）             费用    攻防   这一选给几张 / 稀有度       档位`);
      for (const c of slots) {
        const raw = c.name + (c.renamed ? `(图上写「${c.given}」)` : '');
        const label = (c.faction ? `${raw}（${c.faction}）` : raw).slice(0, 22);
        const cp = `${Number(c.copies) || 1}x${c.copiesDefault ? '(默认1)' : ''}`;
        lines.push(`${label.padEnd(22)} ${deco(c).padEnd(7)} ${String(cp + '→' + rareOf(c)).padEnd(17)} ${tierOf(c)}${mark(c)}`);
      }
      lines.push('```');

      const noPick = winner ? '' : '【结论】**别让我替你拍板**：三张卡都没有档位数据，请按费用曲线、特效和**这一选各给几张**自行权衡（或先跑一次「jjc更新」把评分表补全）。';
      const pickLine = winner
        ? `【结论】选 **${winner.name}**${deco(winner) !== '—' ? `（${deco(winner)}）` : ''}`
          + `${winner.copies ? ` · **选它会往卡组塞 ${winner.copies} 张**` : ''}`
          + `${winner.rare ? `（稀有度 ${winner.rare.official}${winner.rare.common}，按卡名查得）` : '（稀有度卡池里没查到）'}`
          + `${winner.tier != null ? ` · ${winner.tier} 档` : ''}\n理由：${reasonText}。`
        : noPick;

      const why = slots.map((c) => `· ${c.name}：${c.reason}`).join('\n');
      const curveLines = [];
      if (deckCurve.size) {
        curveLines.push(`你给的卡组（${deckTotal} 张）：${curveText(deckCurve)}`);
        const picked = winner || slots[0];
        if (picked && costOf(picked) != null) {
          const after = new Map(deckCurve);
          after.set(costOf(picked), (after.get(costOf(picked)) || 0) + 1);
          curveLines.push(`选完 **${picked.name}** 之后：${curveText(after)}`);
        }
      } else {
        curveLines.push('【费用曲线】没给「右侧卡组列表」→ 没算曲线。下次把右侧清单一起读进来（卡名 + 费用 + 数量），'
          + '同档位并列时才能判断"该补哪一档"。');
      }

      const warn = [];
      const miss = unknown.filter((c) => c.inPool === false);
      if (miss.length) warn.push(`⚠️ 这些卡在站内卡池里没对上，档位也没查到（名字可能抄错了，建议让群友确认）：${miss.map((c) => c.given).join('、')}`);
      if (elites.length) warn.push(`ℹ️ ${elites.map((c) => c.name).join('、')} 按卡池查出来是**精英（金卡）**：金卡只有**主国**（德国/日本/美国/英国/苏联）才有，其他阵营都是盟国、没有金卡。金卡**出现概率太低，当初就没放进评分表**（所以它在评分表里查不到是正常的，不是你读漏了）—— 按「论外」处理：不套常规档位比较，单独看它值不值。`);
      if (items.some((c) => c.renamed)) warn.push(`ℹ️ 已按站内写法归一：${items.filter((c) => c.renamed).map((c) => `「${c.given}」→「${c.name}」`).join('、')}`);

      return { content: [lines.join('\n'), pickLine, '【逐张理由】', why, '', curveLines.join('\n'), warn.length ? '\n' + warn.join('\n') : ''].filter(Boolean).join('\n') };
    }
  });

  api.registerTool({
    id: 'arena_record',
    name: '记录竞技场评分',
    description: '把读图得到的某个阵营的竞技场评分写进评分表（会覆盖该阵营旧数据并归档）。'
      + '群友让你"更新竞技场评分"、或你刚读完强度图时使用。',
    category: 'knowledge',
    icon: '📝',
    parameters: {
      type: 'object',
      properties: {
        faction: { type: 'string', description: '阵营名，如 芬兰' },
        version: { type: 'string', description: '版本名，如 澳新风暴' },
        video: { type: 'string', description: '来源视频的 BV 号（可选）' },
        tiers: {
          type: 'object',
          description: '档位 → 卡名数组，例如 {"5":["极寒陷阱","白色死神"],"4.5":["福克 D.XXI"]}。'
            + '档位用图上写的：5 / 4.5 / 4 / 3.5 / 3 / 2.5 / 2 / 1 / 0 / ??'
        }
      },
      required: ['faction', 'tiers']
    },
    async execute(ctx, args) {
      {
        const g = guardWrite(ctx, '写入整个阵营的榜单');
        if (!g.allowed) return { content: denyMessage('写入整个阵营的榜单', g.caller), isError: true };
      }
      const faction = normalizeFaction(args?.faction);
      const tiers = args?.tiers;
      if (!faction || !tiers || typeof tiers !== 'object') return { content: '缺少 faction 或 tiers。', isError: true };
      // ── 写入前自动核对卡名（2026-10-11 加）────────────────────────────
      // 模型读图会把繁体/日文写法原样抄下来（魚雷艇 / 歩兵第七十聯隊 …），站内是简体，
      // 直接入库就会出现"查不到的卡名"。这里拿该阵营卡池逐条比对：
      //   · 精确命中（含空格/标点差异）→ 用站内写法
      //   · 数字一致 + 长度相近 + 字符重合 ≥0.75 → 判定同一张卡，用站内写法
      //   · 其余 → **丢弃**（宁缺毋滥），并如实告诉模型哪几条没通过
      //   （FACTION_EN / numOf 已提到模块级，见文件上方 —— arena_pick 也要用）
      let pool = [];
      const en = FACTION_EN[faction];
      if (en) {
        for (let page = 1; page <= 4; page++) {
          try {
            const res = await fetch(`https://qwq.wards.mom/api/collection/cards?faction=${en}&limit=100&page=${page}`, { headers: { 'User-Agent': 'QQ-Agent/arena-rating' } });
            const j = await res.json();
            if (!Array.isArray(j.cards) || !j.cards.length) break;
            pool.push(...j.cards);
            if (j.hasMore !== true) break;
          } catch { break; }
        }
      }
      const exact = new Map(pool.map((c) => [norm(c.name_zh), c.name_zh]));
      const canonical = (name) => {
        const q = norm(name);
        if (exact.has(q)) return exact.get(q);
        if (!pool.length) return String(name);            // 拉不到卡池就不判断，原样保留
        const qd = numOf(name);
        let best = null; let bs = 0;
        for (const c of pool) {
          const cn = norm(c.name_zh);
          if (numOf(c.name_zh) !== qd) continue;
          if (Math.abs(cn.length - q.length) > 1) continue;
          const setQ = new Set(q); let ov = 0;
          for (const ch of new Set(cn)) if (setQ.has(ch)) ov += 1;
          const s = ov / Math.max(cn.length, q.length);
          if (s > bs) { bs = s; best = c; }
        }
        return best && bs >= 0.75 ? best.name_zh : null;
      };
      const renamed = []; const dropped = [];
      const clean = {};
      for (const [tier, names] of Object.entries(tiers)) {
        const key = String(tier).trim();
        const list = (Array.isArray(names) ? names : [names]).map((x) => String(x).trim()).filter(Boolean);
        const kept = [];
        for (const n of list) {
          const c = canonical(n);
          if (c === null) { dropped.push(`${key}档「${n}」`); continue; }
          if (c !== n) renamed.push(`「${n}」→「${c}」`);
          kept.push(c);
        }
        if (kept.length || key in TIER_MEANING) clean[key] = kept;
      }
      if (pool.length && !Object.values(clean).some((a) => a.length)) {
        return { content: `⚠️ ${faction} 报的 ${dropped.length} 条卡名**没一条能对上司站内卡池**，已全部丢弃（不写入）。\n${dropped.slice(0, 8).join('、')}`, isError: true };
      }
      const ratings = loadRatings();
      ratings.factions = ratings.factions || {};
      ratings.factions[faction] = { tiers: clean, video: String(args?.video || ''), at: new Date().toISOString() };
      if (args?.version) ratings.version = String(args.version);
      ratings.updatedAt = new Date().toISOString();
      writeJson(DATA_FILE, ratings);

      const state = loadState();
      state.history = [{ at: ratings.updatedAt, faction, version: ratings.version, count: Object.values(clean).reduce((s, x) => s + x.length, 0) }, ...(state.history || [])].slice(0, 50);
      writeJson(STATE_FILE, state);

      const total = Object.values(clean).reduce((s, x) => s + x.length, 0);
      const notes = [];
      if (renamed.length) notes.push(`· 已按站内写法归一 ${renamed.length} 条：${renamed.slice(0, 6).join('、')}${renamed.length > 6 ? ' …' : ''}`);
      if (dropped.length) notes.push(`· **丢弃 ${dropped.length} 条**（站内卡池里对不上，不许编）：${dropped.slice(0, 8).join('、')}${dropped.length > 8 ? ' …' : ''}`);
      return { content: `已记录 ${faction} 的竞技场评分：${total} 张（${Object.keys(clean).length} 个档位）。${notes.length ? '\n' + notes.join('\n') : ''}\n当前评分表：\n${summarize(ratings)}` };
    }
  });

  api.registerTool({
    id: 'arena_set_preference',
    name: '改选国习惯表',
    description: '群友说「主国习惯改成 美>苏>日>英>德」「盟国排序换成 芬兰>澳新>法国>波兰」时用：'
      + '把顺序写回技能设置（设置页的「主国/盟国习惯优先度」会同步变），**下次给建议立刻生效，不用重启**。'
      + '支持简写（芬=芬兰、澳=澳新、苏=苏联…）；填错的国名会被拒并列出可选项。',
    category: 'knowledge',
    icon: '⚙️',
    parameters: {
      type: 'object',
      properties: {
        group: { type: 'string', description: '改哪一组：main＝主国（德日美英苏）/ ally＝盟国（芬兰法国澳新波兰意大利）。也可直接写「主国」「盟国」。' },
        order: { type: 'string', description: '新的优先顺序，用 > 或逗号分隔，越靠前越优先。例：美>苏>日>英>德。支持简写：芬、澳、苏、德、日、英、法、波、意。' }
      },
      required: ['order']
    },
    async execute(ctx, args) {
      {
        const g = guardWrite(ctx, '改选国习惯表');
        if (!g.allowed) return { content: denyMessage('改选国习惯表', g.caller), isError: true };
      }
      const rawGroup = String(args?.group || '').trim();
      const g = /主|main/i.test(rawGroup) ? 'main' : (/盟|ally/i.test(rawGroup) ? 'ally' : '');
      if (!g) {
        // 没给 group：按用户写的国名自动判断（写的是主国名就改主国）
        const bare = parsePreferenceOrder(args?.order, 'main');
        const bareAlly = parsePreferenceOrder(args?.order, 'ally');
        const guess = bare.order.length >= bareAlly.order.length ? 'main' : 'ally';
        return await applyPreference(guess, String(args?.order || ''));
      }
      return await applyPreference(g, String(args?.order || ''));

      async function applyPreference(group, orderText) {
        const list = group === 'main' ? MAIN_GROUP : ALLY_GROUP;
        const label = group === 'main' ? '主国' : '盟国';
        const { order, unknown } = parsePreferenceOrder(orderText, group);
        if (unknown.length) {
          return { content: '❌ 认不出这些名字：' + unknown.join('、') + '\n'
            + '**' + label + '可选项**：' + list.join('、') + '\n'
            + '（支持简写：' + list.map((f) => (COUNTRY_ALIAS[f] || [])[0] || f[0]).join('、') + '）', isError: true };
        }
        if (!order.length) return { content: '❌ 没解析出任何国名。' + label + '可选项：' + list.join('、'), isError: true };
        const missing = list.filter((f) => !order.includes(f));
        const finalOrder = order.concat(missing);          // 没提到的补到末尾（保留其相对顺序）
        const before = readPreferredOrder(group);
        const r = await writePreferredOrder(group, finalOrder);
        const fmt = (a) => a.join(' > ');
        if (!r.ok) {
          return { content: '⚠️ 顺序已解析但**写回设置失败**（' + r.reason + '）。\n'
            + '请手动改：技能设置 → 「' + label + '习惯优先度」→ ' + fmt(finalOrder), isError: true };
        }
        return { content: '✅ 已更新「' + label + '习惯优先度」（设置页同步生效，不用重启' + (r.via === 'api' ? '，走控制台 API' : '，直接写配置文件') + '）：\n'
          + '  旧：' + fmt(before) + '\n  新：' + fmt(finalOrder)
          + (missing.length ? '\n  （没提到的 ' + missing.join('、') + ' 自动补到末尾）' : '') };
      }
    }
  });

  api.registerTool({
    id: 'arena_pick_country',
    name: '选国建议（主国/盟国）',
    description: '群友问「竞技场选哪个国家」「主国选什么」「盟国配哪个」时用。'
      + '会**分别**给出两张表并各自评价：① 客观表（按评分数据算，改不了）② 习惯表（设置里可拖动的优先度）。'
      + '两表结论不一致时**如实说明分歧，让群友自己选**。',
    category: 'knowledge',
    icon: '🌍',
    parameters: { type: 'object', properties: {} },
    execute() {
      const MAIN = ['德国', '日本', '美国', '英国', '苏联'];
      // 盟国池 = 全部国家：主国也能当盟国选（不能只列非主国）
      const ALLY = ['芬兰', '法国', '澳新', '波兰', '意大利', '美国', '苏联', '日本', '英国', '德国'];
      const parseOrder = (raw, all, defaults) => {
        const out = [];
        const txt = String(raw ?? '').trim();
        if (txt) {
          for (const part of txt.split(/[,，、>→|\/\s]+/).map((x) => x.trim()).filter(Boolean)) {
            const hit = all.find((f) => f === part || f.includes(part) || part.includes(f));
            if (hit && !out.includes(hit)) out.push(hit);
          }
        }
        for (const f of defaults) if (!out.includes(f)) out.push(f);
        return out;
      };
      const c = cfg() || {};
      // 优先读被 @ 改过/设置页拖过的顺序（同一份 config.json），读不到再用默认
      const mainOrder = readPreferredOrder('main').length ? readPreferredOrder('main') : parseOrder(c.mainOrder, MAIN, DEFAULT_MAIN_ORDER);
      const allyOrder = readPreferredOrder('ally').length ? readPreferredOrder('ally') : parseOrder(c.allyOrder, ALLY, DEFAULT_ALLY_ORDER);

      const ratings = loadRatings();
      const F = ratings.factions || {};
      const stat = (f) => {
        const info = F[f];
        if (!info) return null;
        const t = info.tiers || info;
        const cnt = (keys) => keys.reduce((s, k) => s + (Array.isArray(t[k]) ? t[k].length : 0), 0);
        const h2 = cnt(['5', '4.5']), h1 = cnt(['4', '3.5']), lo = cnt(['2', '1', '0']);
        const h9 = Array.isArray(t['9']) ? t['9'].length : 0;
        let total = 0; for (const k in t) if (Array.isArray(t[k])) total += t[k].length;
        return { h2, h1, lo, h9, total, score: h2 * 2 + h1 - lo };
      };
      const rankGroup = (list) => list.map((f) => ({ f, s: stat(f) }))
        .filter((x) => x.s).sort((a, b) => b.s.score - a.s.score);

      const lines = ['【竞技场选国】客观表与习惯表**分别**列出（两者可能不一致，请自己选）', ''];
      for (const [label, list, order] of [['主国（有金卡）', MAIN, mainOrder],
        ['盟国（可选全部国家，含主国当盟国）', ALLY, allyOrder]]) {
        const obj = rankGroup(list);
        const have = F ? list.filter((f) => F[f]) : [];
        lines.push('── ' + label + ' ──');
        // 客观表
        lines.push('**客观表**（按评分数据算，本工具改不了）：');
        if (obj.length) {
          obj.forEach((x, i) => {
            lines.push(`  ${i + 1}. ${x.f}  得分 ${x.s.score > 0 ? '+' : ''}${x.s.score}（5/4.5档 ${x.s.h2}、4/3.5档 ${x.s.h1}、低分 ${x.s.lo}，共 ${x.s.total} 张）`);
          });
        } else lines.push('  （没有可用数据）');
        const miss = list.filter((f) => !F[f]);
        if (miss.length) lines.push(`  （未录入，客观表排不了：${miss.join('、')}）`);
        // 习惯表
        const ho = order.filter((f) => list.includes(f));
        lines.push('**习惯表**（你在设置里拖的顺序，越靠前越优先）：');
        lines.push('  ' + ho.map((f, i) => `${i + 1}. ${f}`).join('  '));
        // 分歧
        if (obj.length >= 2) {
          const objFirst = obj[0].f;
          const habFirst = ho[0];
          if (objFirst !== habFirst) {
            lines.push(`⚠️ **两表分歧**：客观表推 **${objFirst}**，你的习惯表推 **${habFirst}**`);
          } else {
            lines.push(`✅ 两表一致：都推 **${objFirst}**`);
          }
        }
        lines.push('');
      }
      lines.push('**怎么用**：客观表看数据、习惯表看实战手感。想改习惯表 → 技能设置里拖「主国/盟国习惯优先度」。');
      return { content: lines.join('\n') };
    }
  });

  api.registerTool({
    id: 'arena_reorder',
    name: '同档内排序（只调顺序，不改档位）',
    description: '群友说「**这张比那张强**」「**这张比那张弱**」「**这张是这档最强/最弱**」时用：'
      + '**只在同一档位内部**调强弱顺序（数组顺序＝强弱，越靠前越强）。'
      + '⚠️ **本工具绝不改变任何卡的分档** —— 跨档位的请求一律拒绝并说明原因'
      + '（档位高低本身就决定强弱：9 > 5 > 4.5 > 4 > 3.5 > 3 > 2.5 > 2 > 1 > 0）；'
      + '若群友认为某张牌的**档位本身**评错了，那要走 arena_set_tier（改档位，需主人权限），不是本工具。',
    category: 'knowledge',
    icon: '🔀',
    parameters: {
      type: 'object',
      properties: {
        name: { type: 'string', description: '要移动的那张卡（群友怎么说的就怎么填，支持模糊匹配）' },
        relation: { type: 'string', description: 'stronger＝比它强 / weaker＝比它弱 / top＝这档最强 / bottom＝这档最弱', enum: ['stronger', 'weaker', 'top', 'bottom'] },
        than: { type: 'string', description: '对照的卡名（relation 为 stronger/weaker 时必填）' },
        faction: { type: 'string', description: '可选：限定阵营（同名卡跨阵营时建议给）' }
      },
      required: ['name', 'relation']
    },
    execute(ctx, args) {
      const rawName = String(args?.name || '').trim();
      const rel = String(args?.relation || '').trim().toLowerCase();
      const rawThan = String(args?.than || '').trim();
      if (!rawName) return { content: '缺少 name（要移动哪张卡？）', isError: true };
      if (!['stronger', 'weaker', 'top', 'bottom'].includes(rel)) {
        return { content: 'relation 只能是 stronger / weaker / top / bottom。', isError: true };
      }
      if ((rel === 'stronger' || rel === 'weaker') && !rawThan) {
        return { content: 'relation 是 ' + rel + ' 时必须给 than（跟哪张卡比？）', isError: true };
      }

      const ratings = loadRatings();
      /** 精确找卡：返回所有"归一化后完全相等"的命中（跨档/跨阵营都列出来） */
      const locateExact = (query) => {
        const qq = norm(query);
        const out = [];
        for (const [faction, info] of Object.entries(ratings.factions || {})) {
          if (args?.faction && normalizeFaction(args.faction) !== faction) continue;
          for (const [tier, names] of Object.entries(info.tiers || {})) {
            (Array.isArray(names) ? names : []).forEach((n) => {
              if (norm(n) === qq) out.push({ faction, tier, name: n });
            });
          }
        }
        return out;
      };
      /** 找不到就放宽成"包含"匹配（只用于给提示，不直接动数据） */
      const locateLoose = (query) => {
        const qq = norm(query);
        const out = [];
        for (const [faction, info] of Object.entries(ratings.factions || {})) {
          if (args?.faction && normalizeFaction(args.faction) !== faction) continue;
          for (const [tier, names] of Object.entries(info.tiers || {})) {
            for (const n of (Array.isArray(names) ? names : [])) {
              const nn = norm(n);
              if (nn !== qq && (nn.includes(qq) || qq.includes(nn))) out.push({ faction, tier, name: n });
            }
          }
        }
        return out;
      };

      // ① 定位要移动的卡 —— 必须唯一，否则要求澄清（绝不静默挑一张）
      let me = null;
      const mineExact = locateExact(rawName);
      if (mineExact.length === 1) me = mineExact[0];
      else if (mineExact.length > 1) {
        return { content: '❓ 「' + rawName + '」在评分表里有 ' + mineExact.length + ' 处，**需要你确认是哪一张**：\n'
          + mineExact.map((x, i) => '  ' + (i + 1) + '. ' + x.faction + ' · ' + x.tier + ' 档 · ' + x.name).join('\n')
          + '\n（补上 faction 参数，或把卡名写全一点）', isError: true };
      } else {
        const loose = locateLoose(rawName);
        if (loose.length === 1) me = loose[0];
        else if (loose.length > 1) {
          return { content: '❓ 「' + rawName + '」匹配到多张，**需要你确认是哪一张**：\n'
            + loose.slice(0, 8).map((x, i) => '  ' + (i + 1) + '. ' + x.faction + ' · ' + x.tier + ' 档 · ' + x.name).join('\n'), isError: true };
        }
      }
      if (!me) return { content: '❌ 评分表里没有「' + rawName + '」（可能还没读进榜，或名字不对）。', isError: true };

      const arr = ratings.factions[me.faction].tiers[me.tier];
      const idxMe = arr.findIndex((x) => norm(x) === norm(me.name));
      if (idxMe < 0) return { content: '❌ 内部定位失败。', isError: true };

      // ② top / bottom：档内移首/尾（**不动档位键**）
      if (rel === 'top' || rel === 'bottom') {
        arr.splice(idxMe, 1);
        if (rel === 'top') arr.unshift(me.name); else arr.push(me.name);
        saveOrder(ratings, me.faction, me.tier, me.name, rel === 'top' ? '同档内：这档最强' : '同档内：这档最弱');
        const pos = arr.indexOf(me.name) + 1;
        return { content: '✅ **' + me.name + '** 已移到 ' + me.faction + ' **' + me.tier + ' 档内**第 ' + pos + ' 位'
          + '（' + (rel === 'top' ? '最强' : '最弱') + '）。档位没变，只调了同档内顺序。\n' + renderTier(me.faction, me.tier, arr) };
      }

      // ③ stronger / weaker：对照卡**必须同档同阵营**
      const rivalExact = locateExact(rawThan).filter((x) => x.faction === me.faction);
      let rival = null;
      if (rivalExact.length === 1) rival = rivalExact[0];
      else if (rivalExact.length > 1) {
        return { content: '❓ 「' + rawThan + '」在 ' + me.faction + ' 里有 ' + rivalExact.length + ' 处，确认一下是哪张：\n'
          + rivalExact.map((x) => '  · ' + x.tier + ' 档 · ' + x.name).join('\n'), isError: true };
      } else {
        const loose = locateLoose(rawThan).filter((x) => x.faction === me.faction);
        if (loose.length === 1) rival = loose[0];
        else if (loose.length > 1) return { content: '❓ 「' + rawThan + '」匹配到多张，确认一下：\n' + loose.slice(0, 6).map((x) => '  · ' + x.tier + ' 档 · ' + x.name).join('\n'), isError: true };
      }
      if (!rival) return { content: '❌ 评分表里没有「' + rawThan + '」（或不在 ' + me.faction + '）。', isError: true };
      if (norm(rival.name) === norm(me.name)) return { content: '⚠️ 这是同一张卡，不用排。', isError: true };

      // ⚠️ 跨档 → 拒绝（本工具不改档位，也不做跨档比较）
      if (rival.tier !== me.tier) {
        return {
          content: '⛔ **跨档位不能调顺序**（本工具只在同一档内排序，不会改任何卡的分档）：\n'
            + '· ' + me.name + ' → **' + me.tier + ' 档**\n'
            + '· ' + rival.name + ' → **' + rival.tier + ' 档**\n\n'
            + '档位高低本身已经决定强弱（9 > 5 > 4.5 > 4 > 3.5 > 3 > 2.5 > 2 > 1 > 0）。\n'
            + '如果你认为 **' + me.name + ' 的档位评错了**（该升/该降档），那是改档位，要用 arena_set_tier（需主人权限）；\n'
            + '如果你只是想在同档里让它更靠前，请挑一张**同档**的卡作对比。',
          isError: true
        };
      }

      // ④ 同档内移动
      const idxRival = arr.findIndex((x) => norm(x) === norm(rival.name));
      arr.splice(idxMe, 1);
      const to = arr.findIndex((x) => norm(x) === norm(rival.name));
      arr.splice(rel === 'stronger' ? to : to + 1, 0, me.name);
      saveOrder(ratings, me.faction, me.tier, me.name, '同档内：' + (rel === 'stronger' ? '强于 ' : '弱于 ') + rival.name);
      const pos = arr.indexOf(me.name) + 1;
      return {
        content: '✅ **' + me.name + '** 在 ' + me.faction + ' **' + me.tier + ' 档内**排到第 ' + pos + ' 位'
          + '（' + (rel === 'stronger' ? '强于' : '弱于') + ' ' + rival.name + '）。**档位没变**，只调了同档内顺序。\n'
          + renderTier(me.faction, me.tier, arr)
      };
    }
  });

  api.registerTool({
    id: 'arena_update_cards',
    name: '更新卡牌表',
    description: '从 KARDS 卡牌图鉴网站**重新拉一遍全卡表**，更新本技能用的离线卡牌数据（cards-meta.json）。'
      + '群友说「卡牌数据更新」「更新卡牌表」「有新卡了刷新一下」时用它。'
      + '**限制：一天最多更新一次**（没变化时重拉没意义）—— 刚更新过会说还要等多久。'
      + '卡牌表是**查稀有度、核对卡名的依据**（arena_check_name / arena_set_tier 都依赖它）。'
      + '会先备份旧表，再报告变化（新增/移除各多少张）。主人可用 {"force":true} 强制重拉。',
    category: 'knowledge',
    icon: '🔄',
    parameters: {
      type: 'object',
      properties: {
        force: { type: 'boolean', description: '忽略"一天一次"的限制，强制重拉（一般不用；只在怀疑网站数据变了、想立刻核对时用）' }
      }
    },
    async execute(ctx, args) {
      // 更新本地数据文件算"写操作" → 走主人校验（与另外三个写入工具一致）
      {
        const g = guardWrite(ctx, '更新卡牌表');
        if (!g.allowed) return { content: denyMessage('更新卡牌表', g.caller), isError: true };
      }
      // ── 一天最多一次（使用者 2026-10-12 要求）────────────────────────────
      const COOLDOWN_MS = 24 * 60 * 60 * 1000;
      const st0 = loadState();
      const lastAt = Number(st0.lastCardsUpdateAt) || 0;
      const left = COOLDOWN_MS - (Date.now() - lastAt);
      if (!args?.force && lastAt && left > 0) {
        // ⚠️ 分钟必须 floor（round 会算出「23 小时 60 分钟」——实测踩过）
        const h = Math.floor(left / 3600000), m2 = Math.floor((left % 3600000) / 60000);
        return {
          content: '⏳ **卡牌表一天最多更新一次**，刚刚已经更新过了。\n'
            + '上次更新：' + new Date(lastAt).toLocaleString('zh-CN') + '\n'
            + '还要等：约 ' + (h > 0 ? h + ' 小时 ' : '') + m2 + ' 分钟\n'
            + '（游戏出了新卡的话，明天再来更新就行；主人想立刻重拉可以带 {"force":true}）',
          isError: true
        };
      }

      const API = 'https://qwq.wards.mom/api/collection/cards';
      const FACTIONS = ['Germany', 'USA', 'Soviet', 'France', 'Britain', 'Japan', 'Italy', 'Poland', 'Anzac', 'Finland', 'Neutral'];
      const HDR = { 'User-Agent': 'QQ-Agent/arena-rating' };
      const get = async (url) => {
        for (let i = 0; i < 3; i++) {
          try {
            const ctl = new AbortController();
            const t = setTimeout(() => ctl.abort(), 15000);
            const r = await fetch(url, { headers: HDR, signal: ctl.signal });
            clearTimeout(t);
            if (r.ok) return await r.json();
          } catch { /* 重试 */ }
        }
        return null;
      };
      const all = [];
      const fail = [];
      for (const fac of FACTIONS) {
        let got = 0;
        for (let page = 1; page <= 20; page++) {
          const j = await get(API + '?faction=' + fac + '&limit=100&page=' + page);
          if (!j || !Array.isArray(j.cards) || !j.cards.length) break;
          for (const c of j.cards) {
            all.push({
              id: c.card_id, name: c.name_zh, en: c.name_en, faction: c.faction, type: c.type,
              rarity: c.rarity, kredits: c.kredits, attack: c.attack, defense: c.defense,
              op: c.operation_cost, img: c.image_url
            });
          }
          got += j.cards.length;
          if (j.hasMore !== true) break;
        }
        if (!got) fail.push(fac);
      }
      // 安全阀：拉得太少说明网站出问题 → 宁可不更新，也别把好表冲掉
      const old = readJson(POOL_FILE, null);
      const oldLen = Array.isArray(old) ? old.length : 0;
      if (!all.length) return { content: '❌ 一张都没拉到（网站可能挂了或接口变了），**没有动本地卡表**。', isError: true };
      if (oldLen && all.length < oldLen * 0.8) {
        return { content: '⚠️ 只拉到 ' + all.length + ' 张，比现有的 ' + oldLen + ' 张少太多（可能有阵营拉失败：'
          + (fail.join('、') || '未知') + '）—— **为安全起见没有覆盖本地卡表**，稍后再试。', isError: true };
      }
      // 备份旧表 → 写新表 → 清缓存
      const bak = POOL_FILE.replace(/\.json$/, '') + '-backup-' + new Date().toISOString().slice(0, 10) + '.json';
      try { if (old) fs.copyFileSync(POOL_FILE, bak); } catch { /* ignore */ }
      fs.writeFileSync(POOL_FILE, JSON.stringify(all, null, 1), 'utf8');
      POOL_CACHE = null;

      // 记下这次更新时间（限流依据）
      const st = loadState();
      st.lastCardsUpdateAt = Date.now();
      writeJson(STATE_FILE, st);

      // 报告变化
      const oldIds = new Set((old || []).map((c) => c.id));
      const newIds = new Set(all.map((c) => c.id));
      const added = all.filter((c) => !oldIds.has(c.id));
      const removed = (old || []).filter((c) => !newIds.has(c.id));
      let msg = '🔄 卡牌表已更新：**' + all.length + ' 张**（上次 ' + oldLen + ' 张）';
      if (added.length) msg += '\n· 新增 ' + added.length + ' 张：' + added.slice(0, 8).map((c) => c.name).join('、') + (added.length > 8 ? ' …' : '');
      if (removed.length) msg += '\n· 移除 ' + removed.length + ' 张：' + removed.slice(0, 8).map((c) => c.name).join('、') + (removed.length > 8 ? ' …' : '');
      if (!added.length && !removed.length) msg += '（没有变化，网站上还是这一版）';
      if (fail.length) msg += '\n⚠️ 这几个阵营没拉到：' + fail.join('、');
      msg += '\n（旧表已备份为 ' + bak.split(/[\\/]/).pop() + '；一天内不会重复更新）';
      return { content: msg };
    }
  });

  api.registerTool({
    id: 'arena_set_tier',
    name: '写入单卡强度（群友口头报分）',
    description: '群友直接说「XX 卡是 X 分」时用：**先按卡名在离线卡池里搜出这张卡确认它存在，再把强度写进评分表**。'
      + '不会凭空写 —— 卡池里查不到就直接拒绝并说明（可以让他确认卡名）。'
      + '与 arena_record 的分工：arena_record 是「读完一整张强度图后整阵营覆盖写入」；本工具是「单张卡补写/改分」。',
    category: 'knowledge',
    icon: '✍️',
    parameters: {
      type: 'object',
      properties: {
        name: { type: 'string', description: '卡名（群友怎么说的就怎么填，工具会自己归一到站内写法）' },
        tier: { type: 'string', description: '强度档位，用图上那套：9 / 5 / 4.5 / 4 / 3.5 / 3 / 2.5 / 2 / 1 / 0 / ??' },
        faction: { type: 'string', description: '可选：限定阵营（如 苏联）。同名卡跨阵营时建议给，不给则按权重挑最匹配的那张' }
      },
      required: ['name', 'tier']
    },
    async execute(ctx, args) {
      child_check: {
        const g = await Promise.resolve(guardWrite(ctx, '写入单卡强度'));
        if (!g.allowed) return { content: denyMessage('写入单卡强度', g.caller), isError: true };
      }
      const rawName = String(args?.name || '').trim();
      const rawTier = String(args?.tier ?? '').trim();
      if (!rawName) return { content: '缺少 name（要写哪张卡？）', isError: true };
      if (!rawTier) return { content: '缺少 tier（这张卡几分？）', isError: true };
      // 档位归一：允许 9分 / 4.5分 / "5 超强" / ?? 等写法
      const tm = /^(\?\?|\d+(?:\.\d+)?)/.exec(rawTier);
      const tier = tm ? tm[1] : rawTier;
      const FACTION_ZH = { Soviet: '苏联', Britain: '英国', USA: '美国', Poland: '波兰', Anzac: '澳新',
        Germany: '德国', France: '法国', Finland: '芬兰', Japan: '日本', Italy: '意大利', Neutral: '中立' };

      // ① 搜：按卡名（归一化）在离线卡池里找
      const pool = loadPool();
      if (!pool.length) return { content: '离线卡池没加载（cards-meta.json 缺失）', isError: true };
      const q = norm(rawName);
      let hits = pool.filter((c) => norm(c.name) === q);
      // ⚠️ 跨阵营可能有同名卡（「T-34-85 1945」这种），选错阵营就写错榜。
      //    没给 faction 且命中多张 → **先把候选列出来让群友确认**，不闷头挑一张。
      if (!hits.length && q.length >= 3) {
        const inc = pool.filter((c) => norm(c.name).includes(q) || (q.length >= 4 && q.includes(norm(c.name))));
        const minLen = Math.min(...inc.map((c) => norm(c.name).length));
        hits = inc.filter((c) => norm(c.name).length === minLen);   // 只留最贴近的那一档长度
      }
      if (!hits.length) {
        // 番号一致 + 字符重合 ≥0.75 的近似（读错一位数字时能救回来，但要标出来）
        const nums = (x) => (String(x).match(/\d+/g) || []).join(',');
        const near = pool.filter((c) => nums(c.name) === nums(rawName) && nums(rawName) !== '')
          .map((c) => { const a = new Set(norm(rawName)), b = new Set(norm(c.name));
            let ov = 0; for (const ch of a) if (b.has(ch)) ov += 1;
            return { c, s: ov / Math.max(a.size, b.size) }; })
          .filter((x) => x.s >= 0.75).sort((x, y) => y.s - x.s);
        if (!near.length) {
          return { content: '❌ 卡池里**搜不到**「' + rawName + '」（这张卡不存在，或名字读错/写法不同）。\n'
            + '**没有确认过的卡名不许写入** —— 请让群友确认一下卡名，或用 arena_check_name 先核对。', isError: true };
        }
        hits = [near[0].c];
        var approxNote = '（按番号+字形近似匹配，重合 ' + Math.round(near[0].s * 100) + '%）';
      }

      // ② 定：跨阵营同名 → 让群友确认；给了 faction 就直接定位
      const FACTION_ZH2 = FACTION_ZH;
      if (!args?.faction) {
        const byFac = {};
        for (const c of hits) { const zh0 = FACTION_ZH2[c.faction] || c.faction; (byFac[zh0] = byFac[zh0] || []).push(c); }
        const facs = Object.keys(byFac);
        if (facs.length > 1) {
          const lines = [];
          for (const f of facs) lines.push('· **' + f + '**：' + byFac[f].map((c) => c.name + '（' + c.kredits + 'K）').join('、'));
          return { content: '❓ 「' + rawName + '」在卡池里**对应多个阵营的同名卡，需要你确认是哪一张**（或直接在 faction 里说明阵营）：\n'
            + lines.join('\n') + '\n\n确认后再说一次（例如：faction 填「' + facs[0] + '」）。**在你确认前我不写入** —— 写错阵营会污染另一个国家的榜。' };
        }
      }
      let card = hits[0];
      if (args?.faction) {
        const want = FACTION_ZH[normalizeFaction(args.faction)] || String(args.faction);
        const fh = hits.find((c) => FACTION_ZH[c.faction] === want);
        if (fh) card = fh;
      }
      const zh = FACTION_ZH[card.faction] || card.faction;

      // ③ 写：写进评分表（同阵营同档位去重；已存在于别的档位则先移除 —— 改分）
      const ratings = loadRatings();
      ratings.factions = ratings.factions || {};
      const entry = ratings.factions[zh] || { tiers: {} };
      entry.tiers = entry.tiers || {};
      const removed = [];
      for (const t of Object.keys(entry.tiers)) {
        const arr = entry.tiers[t];
        if (!Array.isArray(arr)) continue;
        const i = arr.findIndex((x) => norm(x) === norm(card.name));
        if (i >= 0) { arr.splice(i, 1); removed.push(t); }
      }
      if (!Array.isArray(entry.tiers[tier])) entry.tiers[tier] = [];
      entry.tiers[tier].push(card.name);
      delete entry.verified;                    // 单卡补写后，整榜"已核对"的标记不再成立
      entry.updatedAt = new Date().toISOString();
      ratings.factions[zh] = entry;
      ratings.updatedAt = new Date().toISOString();
      writeJson(DATA_FILE, ratings);

      let n = 0; for (const t in entry.tiers) if (Array.isArray(entry.tiers[t])) n += entry.tiers[t].length;
      const tierZh = { '9': '非人', '5': '超强', '4.5': '很强', '4': '超模', '3.5': '不错', '3': '好牌',
        '2.5': '凑合', '2': '普通人', '1': '弱者', '0': '神卡', '??': '未评级' }[tier] || '';
      return { content: '✅ 已写入：**' + card.name + '**（' + zh + '，' + card.kredits + 'K）→ **' + tier + ' 档'
        + (tierZh ? '（' + tierZh + '）' : '') + '**' + (approxNote || '')
        + (removed.length ? '\n（它原来在 ' + removed.join('、') + ' 档，已按改分移除）' : '')
        + '\n现在 ' + zh + ' 共 ' + n + ' 张。' };
    }
  });

  api.registerTool({
    id: 'arena_fetch',
    name: '抓取竞技场评分图（备选）',
    description: '【备选手段】去 B 站抓最新一期《XX版本竞技场评分》的视频评论区的强度图（无头浏览器，5~8 分钟）。'
      + '⚠️ **首选是让群友把强度图直接发到群里**（配一句「jjc更新」）—— 那样又快又准，**不需要调用本工具**。'
      + '只有在**群友没发图、又确实需要更新**时才用它；而且**它不一定有用**：依赖本机有浏览器和 B 站页面可达，'
      + '**抓到的也不一定是最新一期**、还可能缺档位。抓完返回图片路径清单，接着逐张读图 → arena_record。'
      + '群友明确说"自己去抓"、或按了技能设置里的「自动抓取并读图（不一定有用）」按钮时使用。',
    category: 'knowledge',
    icon: '📥',
    parameters: {
      type: 'object',
      properties: {
        mid: { type: 'string', description: 'UP 主 uid，默认 673249（华南有只虎）' },
        force: { type: 'boolean', description: '强制重新下载（默认 false：12 小时内抓过就直接复用现成的图）。群友说「jjc更新」「强制更新」时传 true。' }
      }
    },
    async execute(ctx2, args) {
      const c = cfg() || {};
      const script = path.join(SKILL_DIR, 'fetch.mjs');
      if (!fs.existsSync(script)) return { content: '缺少抓取脚本 fetch.mjs。', isError: true };
      const outDir = IMAGE_DIR;
      fs.mkdirSync(outDir, { recursive: true });

      // 刚抓过就直接用现成的图（抓一次要 6 分钟，没必要重复抓）；force=true 时跳过
      const manifestFile = path.join(outDir, 'manifest.json');
      const fresh = readJson(manifestFile, null);
      const ageHours = fresh?.fetchedAt ? (Date.now() - Date.parse(fresh.fetchedAt)) / 3600000 : Infinity;
      const reuseHours = Number(c.reuseHours) || 12;
      // force=true 表示"重抓"，但如果刚抓完没多久（默认 30 分钟内）就别白等 8 分钟 ——
      // 线上真实情况：12:04 那次抓完图，下一轮调用崩了，重来一遍没必要再下载一次。
      const forceReuseMinutes = Number(c.forceReuseMinutes) || 30;
      const justFetched = fresh?.fetchedAt && (Date.now() - Date.parse(fresh.fetchedAt)) / 60000 < forceReuseMinutes;
      if (!args?.force && fresh && ageHours < reuseHours) {
        log(`arena_fetch：${ageHours.toFixed(1)} 小时前刚抓过，直接用现成的 ${Object.keys(fresh.videos || {}).length} 期图`);
        const prep = await runPrepare(log);
        return { content: renderManifest(`（${ageHours.toFixed(1)} 小时前刚抓过，直接用这批图，没有重新下载；群友若要强制重抓，用 force=true）${prep}`, readJson(manifestFile, fresh)) };
      }
      if (args?.force && justFetched) {
        const mins = ((Date.now() - Date.parse(fresh.fetchedAt)) / 60000).toFixed(0);
        log(`arena_fetch：${mins} 分钟前刚强制抓过，直接复用（避免重复下载）`);
        const prep = await runPrepare(log);
        return { content: renderManifest(`（${mins} 分钟前刚抓过一次，直接复用这批图；要真正重下请等 ${forceReuseMinutes} 分钟后再 force）${prep}`, readJson(manifestFile, fresh)) };
      }
      const env = {
        ...process.env,
        // ⚠️ 关键：技能跑在 Electron 里，process.execPath 是「QQ Agent.exe」而不是 node。
        //    不加这个变量，spawn 它会**再启动一个 Electron 实例**（被单实例锁挡掉、什么都不干）；
        //    加上之后这个 exe 就按纯 Node 运行（实测 v20.18.3），fetch.mjs 才能跑起来。
        ELECTRON_RUN_AS_NODE: '1',
        ARENA_MID: String(args?.mid || c.upMid || '673249'),
        ARENA_KEYWORD: String(c.collectionKeyword || '版本竞技场评分')
      };
      const result = await new Promise((resolve) => {
        const child = spawn(process.execPath, [script, outDir], { env, windowsHide: true });
        let out = '';
        child.stdout.on('data', (d) => { out += String(d); });
        child.stderr.on('data', (d) => { out += String(d); });
        child.on('close', () => resolve(out));
        setTimeout(() => { try { child.kill(); } catch { /* ignore */ } resolve(out + '\n（超时中断）'); }, 15 * 60 * 1000);
      });
      const state = loadState();
      state.lastFetchAt = Date.now();
      writeJson(STATE_FILE, state);

      const manifest = readJson(path.join(outDir, 'manifest.json'), null);
      if (!manifest) return { content: `抓取没拿到结果，脚本输出：\n${out.slice(-1500)}`, isError: true };
      const prep = await runPrepare(log);
      return { content: renderManifest('', readJson(path.join(outDir, 'manifest.json'), manifest)) + prep };
    }
  });

  api.registerTool({
    id: 'arena_check_name',
    name: '竞技场评分·卡名核对',
    description: '把**从榜图上读到的卡名**拿到离线全卡池（1629 张）里核对：返回「命中 / 近似 / 查不到」。'
      + '读图时**每读出一批卡名就该调它一次** —— 命中就用它给的**站内写法**记录；'
      + '「查不到」说明名字读错了或这一行切片不准，**不要硬记**，回头再看一眼图。'
      + '不联网（站内域名常 DNS 失败），纯本地比对。',
    category: 'knowledge',
    icon: '🔎',
    parameters: {
      type: 'object',
      properties: {
        names: { type: 'array', items: { type: 'string' }, description: '要核对的卡名数组（从图上读到的原样写法）' },
        faction: { type: 'string', description: '可选：限定阵营（中文，如「美国」），能显著减少误配' }
      },
      required: ['names']
    },
    execute(_ctx, args) {
      const names = (args?.names || []).map((s) => String(s || '').trim()).filter(Boolean);
      if (!names.length) return { content: '没给 names（要核对哪些卡名？）', isError: true };
      const fac = normalizeFaction(args?.faction || '');
      const pool = fac ? poolByFaction(fac) : loadPool();
      if (!pool.length) return { content: '离线卡池没加载（cards-meta.json 缺失）', isError: true };

      const lines = [];
      let hit = 0, near = 0, miss = 0;
      for (const raw of names) {
        // ① 精确命中（归一化后）
        const exact = pool.filter((c) => norm(c.name) === norm(raw));
        if (exact.length) {
          hit += 1;
          lines.push(`✅ ${raw} → **${exact[0].name}**（${exact[0].kredits}K ${exact[0].attack}/${exact[0].defense} ${exact[0].type}）`);
          continue;
        }
        // ② 近似：数字一致 + 长度相近 + 字符重合 ≥0.75（与 resolvePoolName 同口径）
        const nums = (s) => (String(s).match(/\d+/g) || []).join(',');
        const cands = pool.filter((c) => nums(c.name) === nums(raw) && nums(raw) !== '').map((c) => {
          const a = new Set(norm(raw)); const b = new Set(norm(c.name));
          let inter = 0; for (const ch of a) if (b.has(ch)) inter += 1;
          const overlap = inter / Math.max(1, Math.max(a.size, b.size));
          return { c, overlap, lenDiff: Math.abs(norm(c.name).length - norm(raw).length) };
        }).filter((x) => x.overlap >= 0.75 && x.lenDiff <= 1)
          .sort((x, y) => y.overlap - x.overlap);
        if (cands.length) {
          near += 1;
          lines.push(`🟡 ${raw} → 近似 **${cands[0].c.name}**（重合 ${(cands[0].overlap * 100).toFixed(0)}%，${cands[0].c.kredits}K）`);
          continue;
        }
        miss += 1;
        lines.push(`❌ ${raw} → 卡池里查不到（**名字可能读错了，或这一行切片不准 → 回头再看一眼图，别硬记**）`);
      }
      const head = `卡名核对（${fac || '全阵营'}）：命中 ${hit} / 近似 ${near} / 查不到 ${miss}`;
      return { content: [head, '', ...lines].join('\n') };
    }
  });
}

export const hooks = {
  // 该不该提示"去更新评分"：① 群里按了「重新读取」按钮 ② 距上次抓取超过 N 天
  'before-context': (payload) => {
    try {
      const c = cfg() || {};
      const state = loadState();
      const request = Number(c.refreshRequest) || 0;
      const days = Number(c.autoRefreshDays) || 90;
      const stale = Date.now() - (Number(state.lastFetchAt) || 0) > days * 86400000;
      const asked = request > (Number(state.lastRefreshRequest) || 0);
      if (!asked && !stale) return;
      if (asked) { state.lastRefreshRequest = request; writeJson(STATE_FILE, state); }
      const why = asked ? '群里按了「重新读取竞技场评分」按钮' : `距上次抓取已超过 ${days} 天`;
      return `arena-rating: ${why} → 需要更新评分表`;
    } catch { /* 静默 */ }
    return undefined;
  },

  'before-llm-messages': (payload) => {
    try {
      if (!Array.isArray(payload?.messages)) return;
      const c = cfg() || {};
      const state = loadState();
      const request = Number(c.refreshRequest) || 0;
      const days = Number(c.autoRefreshDays) || 90;
      const stale = Date.now() - (Number(state.lastFetchAt) || 0) > days * 86400000;
      const asked = request > (Number(state.lastRefreshRequest) || 0);
      if (!asked && !stale) return;
      const ratings = loadRatings();
      const have = Object.keys(ratings.factions || {}).length;
      payload.messages.push({
        role: 'user',
        content: `【系统提示】${asked ? '群里按了「重新读取竞技场评分」按钮' : `距上次抓取已超过 ${days} 天`}。`
          + '请按这个顺序做：① 调用 arena_fetch 抓最新一期《版本竞技场评分》的强度图；'
          + '② 用 read_image **逐张读图**（竖长的那张是强度榜；横版截图不是）；'
          + '③ 每读完一个阵营，用 arena_record 记录（阵营从视频标题认：酥莲=苏联、瑛國=英国、渼國=美国）；'
          + '④ 全部记完后，在群里用一两句话说明这期更新了什么。'
          + `\n（当前表里已有 ${have} 个阵营的数据；如果这次抓不到图，就说明抓取失败、不要编数据。）`
      });
    } catch { /* 静默 */ }
  }
};

// ── 硬绑定：KARDS 强制查询（kards-trigger）──────────────────────────────
// 使用者 2026-10-12 要求：竞技场检索/卡牌检索**强制绑定**该插件（原本是独立的 kards-core，
// 后来按使用者要求并入了强制查询插件）—— 插件没启用，
// 这两个技能**直接不可用**（核心据此判定 not active：工具不注册、提示词不注入，
// 模型根本看不见这两个技能）。纯开关，不参与对话。
export function available() {
  try {
    const cfgPath = path.join(path.dirname(fileURLToPath(import.meta.url)), '..', '..', '..', '..', 'data', 'config.json');
    if (!fs.existsSync(cfgPath)) {
      return { ok: false, reason: '找不到 data/config.json —— 无法确认「KARDS 强制查询」插件是否启用' };
    }
    const c = JSON.parse(fs.readFileSync(cfgPath, 'utf8'));
    const sk = (c.skills || {})['kards-trigger'] || (c.plugins || {})['kards-trigger'];
    if (!sk || sk.enabled !== true) {
      return { ok: false, reason: '「KARDS 强制查询」(kards-trigger) 未启用 —— 本技能强制绑定它，请先在设置里启用该插件' };
    }
    return { ok: true };
  } catch (e) {
    return { ok: false, reason: '检查「KARDS 强制查询」插件时出错：' + String(e && e.message || e) };
  }
}
