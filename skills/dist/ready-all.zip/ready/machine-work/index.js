// 本机干活（machine-work）—— 让 QQ Agent 不经过 DSH，自己在这台电脑上动手。
//
// ── 为什么要有这个技能 ─────────────────────────────────────────────────────
// 原来"要在电脑上干活"只有一条路：把任务交给「微型 DSH」技能，由它 spawn 一个
// DSH 进程（冷启动几十秒、要传人设、结果还得转回来）。可大多数请求根本不是那个量级：
// 读一个文件、改一行配置、跑一条命令、搜一段代码 —— 为这些去冷启动一个 agent，
// 就像为了买瓶水开卡车。
//
// 本技能把这些能力直接做成 QQ Agent 自己的工具（就在这个进程里，一次调用一次动作）：
//   read_file / write_file / edit_file / list_dir / glob_files / search_files
//   run_command / read_image / download_file / work_info
//
// ── 安全模型（这个技能必须讲清楚，它的能力等于"用主人的账号操作这台机器"）──────
//   1. 只认主人：每次调用都先算「谁在说话」，再核对主人身份（本技能名单 或
//      应用的「主人识别」能力，任一命中）。认不出就拒绝 —— 宁可让主人多说一句，
//      也不能因为"大概是主人"就放行一条 rm -rf。
//   2. 默认只在私聊可用：群里任何人都会给机器人发消息，而工具的 ctx 里**没有**
//      调用者 QQ（只有 chatKey/kind/chatId/selfId/store/session…），只能靠
//      "本会话最近一条别人发的消息"反推。主人刚说完、群友紧接着也说话，反推就会
//      张冠李戴 —— 那等于把 shell 权限开放给任何会抢话的群友。私聊没有这个歧义。
//   3. 三道可调的口子：只读模式 / 允许目录白名单 / 命令黑名单（都在技能设置里）。
//   4. 审计：每次调用落一行 JSON 到 data\machine-work\audit.jsonl。
//
// ⚠️ 关于 lib/ 的加载方式：入口文件是被 plugin-loader 用 `?t=时间戳` 动态 import 的
//    （热重载用），但**相对 import 不带那个时间戳** —— ESM 按 URL 缓存，改完 lib/
//    里的文件再"重新加载技能"，拿到的还是旧模块。所以这里对每个 lib 模块也带上
//    自己的时间戳动态 import：改完任何文件重新加载即刻生效，不用重启应用。

let api = null;
/** lib 模块集合（在 setup 里按时间戳加载，见文件头最后一段说明） */
let L = null;

const TOOL_PREFIX = 'machine-work__';

// ── 身份 ───────────────────────────────────────────────────────────────────

function ownerIdSet(raw) {
  const parts = Array.isArray(raw) ? raw : String(raw ?? '').split(/[\s,，、;；]+/);
  return new Set(parts.map((v) => String(v ?? '').trim()).filter(Boolean));
}

/**
 * 谁在说话：本会话最近一条**别人**发的消息的发送者。
 * ⚠️ 这只是"反推"，不是协议端给的调用者身份 —— 它给不出"发送这条指令的人是谁"，
 *    所以群聊场景才有歧义（设置里的「允许在群聊里用」默认关，原因见文件头）。
 */
function latestCaller(ctx) {
  const store = ctx?.store;
  const chatKey = String(ctx?.chatKey ?? '');
  if (!store || typeof store.recent !== 'function' || !chatKey) return { callerId: '', callerName: '' };
  let list = [];
  try { list = store.recent(chatKey, { limit: 6, includeSelf: false }) || []; } catch { list = []; }
  for (let i = list.length - 1; i >= 0; i -= 1) {
    const m = list[i];
    if (m && m.senderId) return { callerId: String(m.senderId), callerName: String(m.senderName || '') };
  }
  return { callerId: '', callerName: '' };
}

/** 是不是主人：本技能名单 或 主人识别插件，任一命中即可。只认 QQ 号。 */
function isOwner(callerId, cfg) {
  const id = String(callerId ?? '').trim();
  if (!id) return false;
  if (ownerIdSet(cfg?.ownerIds).has(id)) return true;
  try {
    const r = api?.capability?.('message.owner-check', { userId: id });
    if (r && typeof r === 'object' && r.isOwner === true) return true;
  } catch { /* 主人识别插件坏了按非主人处理，不放行 */ }
  return false;
}

/**
 * 三个闸共用的前置检查。返回 { error } 表示拒绝；返回 { callerId, callerName } 表示放行。
 * 拒绝文案是**给模型看的话** —— 里面写清了"该怎么对那个人说"，
 * 免得模型自己发挥成"系统忙，请稍后再试"。
 */
function guard(ctx, cfg) {
  if (cfg?.enabled === false) {
    return { error: '本机干活技能已被主人关掉（技能设置里的总开关），不要重试。' };
  }
  const kind = String(ctx?.kind ?? '');
  if (kind !== 'private' && cfg?.allowGroup !== true) {
    return {
      error: '本机干活默认只在私聊里用，这个会话不是私聊，已拒绝。\n'
        + '原因：群聊里工具无法确认这条指令是谁发的，只能按"最近一条别人的消息"反推，'
        + '张冠李戴等于把执行命令的权限给了别人。\n'
        + '如果主人确实想在群里用，请主人到技能设置里打开「允许在群聊里用」。'
        + '对群友就说「这个只有主人能用」，不要解释技术细节、不要重试。'
    };
  }
  const { callerId, callerName } = latestCaller(ctx);
  if (!callerId) {
    return {
      error: '拒绝：没能确认是谁在说话（本会话查不到最近的消息记录），身份不明一律不操作。\n'
        + '如实告诉主人"身份没法确认，所以没动手"，不要换种方式重试。'
    };
  }
  if (!isOwner(callerId, cfg)) {
    return {
      error: '拒绝：这次调用不是主人发起的（说话的人是 ' + (callerName || '未知') + '：' + callerId + '）。\n'
        + '按你的安全规则回绝，对那个人说「这个只有主人能用」即可 —— '
        + '不要执行、不要解释工具的存在、不要换种写法再试。'
    };
  }
  return { callerId, callerName };
}

// ── 每个工具共用的外壳：身份闸 + 异常兜底 + 审计 ────────────────────────────

async function runTool(ctx, name, args, fn) {
  const cfg = api?.config?.() || {};
  const g = guard(ctx, cfg);
  if (g.error) return { content: g.error, isError: true };

  const started = Date.now();
  let result;
  try {
    result = await fn(cfg, g);
  } catch (error) {
    result = L.reply.fail(L.reply.errText(error));
  }
  try {
    L.audit.record({
      tool: name,
      ok: !result?.isError,
      ms: Date.now() - started,
      error: result?.isError ? String(typeof result.content === 'string' ? result.content : '').slice(0, 300) : '',
      callerId: g.callerId,
      callerName: g.callerName,
      chatKey: ctx?.chatKey,
      kind: ctx?.kind,
      args
    }, cfg);
  } catch { /* 审计失败不影响工具 */ }
  return result;
}

// ── 工具注册 ───────────────────────────────────────────────────────────────

function registerTools(skillApi) {
  // 统一给每个工具补上默认分类/图标；id 不在这里加前缀 —— plugin-loader 会加
  // （它加的才是发给模型的最终名字：machine-work__read_file）。
  const T = (def) => skillApi.registerTool({ category: 'system', icon: '🔧', ...def });

  T({
    id: 'read_file',
    name: '读文件',
    icon: '📖',
    description: '读主人这台电脑上的一个文本文件。**只有主人能用**：主人以外的人让你读文件时不要调用，'
      + '直接说「这个只有主人能用」。输出每行前面有 `行号| ` 前缀（显示用的，文件里没有）。'
      + '大文件用 offset/limit 分段读；二进制文件和超大文件会被拒绝（会给替代建议）。',
    parameters: {
      type: 'object',
      properties: {
        path: { type: 'string', description: '文件路径。绝对路径最保险；相对路径以工作目录（work_info 可查）为基准' },
        offset: { type: 'integer', description: '可选：从第几行开始（从 1 开始），不填是第 1 行' },
        limit: { type: 'integer', description: '可选：最多读多少行' }
      },
      required: ['path']
    },
    async execute(ctx, args) {
      return runTool(ctx, 'read_file', args, (cfg) => L.fsops.readFile(cfg, args));
    }
  });

  T({
    id: 'write_file',
    name: '写文件',
    icon: '📝',
    description: '新建一个文件，或者**整体覆盖**一个文件。**只有主人能用**。'
      + '要写入的完整内容放在 content 里（不是片段！）。'
      + '已存在的文件如果这次会话里没读过（读文件会把它记成"已看过"，自己写的也算），'
      + '会被要求先 read_file 读一遍，或者显式传 overwrite: true 盲写；'
      + '只改一小段请用 edit_file。',
    parameters: {
      type: 'object',
      properties: {
        path: { type: 'string', description: '文件路径（父目录不存在会自动创建）' },
        content: { type: 'string', description: '要写入的完整文本内容' },
        overwrite: { type: 'boolean', description: '可选：文件已存在且这次没读过它时，必须传 true 才让覆盖' }
      },
      required: ['path', 'content']
    },
    async execute(ctx, args) {
      return runTool(ctx, 'write_file', args, (cfg) => L.fsops.writeFile(cfg, args));
    }
  });

  T({
    id: 'edit_file',
    name: '改文件',
    icon: '✏️',
    description: '在一个已存在的文件里做**局部替换**（old_string → new_string）。**只有主人能用**。'
      + 'old_string 必须和文件里一字不差，且默认要求**唯一**（出现多次要传 replace_all: true 或者把上下文写长）；'
      + '不要带 read_file 输出的 `行号| ` 前缀。改之前必须先 read_file 读过这个文件。',
    parameters: {
      type: 'object',
      properties: {
        path: { type: 'string', description: '文件路径' },
        old_string: { type: 'string', description: '要被替换掉的原文（必须一字不差，且默认必须唯一）' },
        new_string: { type: 'string', description: '替换成什么。要删掉这段就传空字符串' },
        replace_all: { type: 'boolean', description: '可选：old_string 出现多次时，全部替换' }
      },
      required: ['path', 'old_string', 'new_string']
    },
    async execute(ctx, args) {
      return runTool(ctx, 'edit_file', args, (cfg) => L.fsops.editFile(cfg, args));
    }
  });

  T({
    id: 'list_dir',
    name: '列目录',
    icon: '📁',
    description: '列出一个目录里有什么（类型 / 大小 / 修改时间 / 名字）。**只有主人能用**。'
      + '想知道某个目录结构、或确认某个文件在不在时用它，不要用 run_command 去 dir。',
    parameters: {
      type: 'object',
      properties: {
        path: { type: 'string', description: '目录路径。不填就是当前工作目录' }
      }
    },
    async execute(ctx, args) {
      return runTool(ctx, 'list_dir', args, (cfg) => L.fsops.listDir(cfg, args));
    }
  });

  T({
    id: 'glob_files',
    name: '找文件',
    icon: '🔎',
    description: '按通配符在目录树里找文件。**只有主人能用**。支持 `**`（任意层级）、`*`（同级）、`?`。'
      + '例：`**/*.md`、`skills/**/index.js`、`*.json`（没有斜杠时按任意层级的文件名匹配）。'
      + '默认跳过 node_modules / .git 等噪音目录。',
    parameters: {
      type: 'object',
      properties: {
        pattern: { type: 'string', description: '通配符，例如 **/*.js' },
        path: { type: 'string', description: '可选：从哪个目录开始找，不填用工作目录' },
        limit: { type: 'integer', description: '可选：最多返回多少个（默认 200，上限 2000）' }
      },
      required: ['pattern']
    },
    async execute(ctx, args) {
      return runTool(ctx, 'glob_files', args, (cfg) => L.fsops.globFiles(cfg, args));
    }
  });

  T({
    id: 'search_files',
    name: '搜内容',
    icon: '🔦',
    description: '按正则表达式在文件内容里搜（相当于 grep）。**只有主人能用**。'
      + '返回 `文件:行号: 那一行的内容`。默认区分大小写、跳过二进制和大文件；'
      + '可以用 glob 参数把范围收窄（例如 glob: "**/*.js"）。找函数、找配置项、找报错都用它。',
    parameters: {
      type: 'object',
      properties: {
        pattern: { type: 'string', description: '正则表达式，例如 function\\s+\\w+ 或 timeout' },
        path: { type: 'string', description: '可选：在哪个目录（或文件）里搜，不填用工作目录' },
        glob: { type: 'string', description: '可选：只搜匹配这个通配符的文件，例如 **/*.js' },
        ignoreCase: { type: 'boolean', description: '可选：true 表示忽略大小写' },
        limit: { type: 'integer', description: '可选：最多返回多少行（默认 100，上限 500）' }
      },
      required: ['pattern']
    },
    async execute(ctx, args) {
      return runTool(ctx, 'search_files', args, (cfg) => L.fsops.searchFiles(cfg, args));
    }
  });

  T({
    id: 'run_command',
    name: '执行命令',
    icon: '🖥️',
    description: '在主人这台电脑上执行一条 PowerShell 命令（**真正的执行，不是模拟**）。**只有主人能用**。'
      + '会返回输出和 `[exit code: N]`；超时会连子进程树一起杀掉。'
      + '默认**这一轮就等它跑完**；要是这条命令可能跑很久（构建、装依赖、跑测试、起服务），'
      + '传 `background: true` 转入后台，立刻拿到任务号，然后用 job_output 查进度 / job_kill 停掉它。'
      + '只读模式下会被拒绝，命中技能设置里的命令黑名单（diskpart / format / shutdown 等）也会被拒绝 —— '
      + '被拒绝时如实转述原因，不要换个写法绕。工作目录默认是技能设置里的工作目录。'
      + '编码已经处理好（Get-Content/Set-Content/Out-File 默认 UTF-8，输出回传也是 UTF-8），不用自己加 -Encoding。'
      + '⚠️ 改 JSON / 配置文件请用 edit_file 或 write_file，别用 Set-Content —— Windows PowerShell 5.1 的 '
      + 'Set-Content 会写成带 BOM 的 UTF-8，而 JSON.parse 不认 BOM，应用读配置会直接报错。',
    parameters: {
      type: 'object',
      properties: {
        command: { type: 'string', description: '要执行的命令（PowerShell 语法，可以多行）' },
        cwd: { type: 'string', description: '可选：在哪个目录里执行，不填用工作目录' },
        timeoutSec: { type: 'integer', description: '可选：超时秒数（默认用技能设置里的值，上限 1800；后台任务传 0 = 不限时）' },
        background: { type: 'boolean', description: '可选：true = 转到后台跑，立刻返回任务号（不用干等，跑完会主动把结果发回会话）' }
      },
      required: ['command']
    },
    async execute(ctx, args) {
      return runTool(ctx, 'run_command', args, (cfg, g) => (
        args?.background === true
          ? L.jobs.startJob(cfg, args, g, ctx)
          : L.shell.runCommand(cfg, args)
      ));
    }
  });

  T({
    id: 'job_list',
    name: '后台任务列表',
    icon: '📋',
    description: '列出所有后台任务（运行中 / 已完成 / 已终止），含状态、耗时、输出字节数和"还有多少没读"。**只有主人能用**。'
      + '主人问「那个任务跑得怎么样了」「刚才让你跑的东西呢」时先看它。',
    parameters: { type: 'object', properties: {} },
    async execute(ctx, args) {
      return runTool(ctx, 'job_list', args, () => L.jobs.listJobs());
    }
  });

  T({
    id: 'job_output',
    name: '看后台任务输出',
    icon: '📄',
    description: '看一个后台任务的输出。**只有主人能用**。默认只回**上次之后的新内容**（游标推进，反复查不会重复烧上下文）；'
      + '任务没结束时能看进度，结束后会给出完整日志的路径。要看全量传 full: true。',
    parameters: {
      type: 'object',
      properties: {
        job_id: { type: 'string', description: '任务号，例如 j1（从 run_command 的 background 回执或 job_list 拿）' },
        full: { type: 'boolean', description: '可选：true = 从头回全部（默认只回上次之后的新内容）' },
        maxKB: { type: 'integer', description: '可选：这次最多回多少 KB（默认 64，上限 256）' }
      },
      required: ['job_id']
    },
    async execute(ctx, args) {
      return runTool(ctx, 'job_output', args, () => L.jobs.readJob(args));
    }
  });

  T({
    id: 'job_kill',
    name: '停掉后台任务',
    icon: '🛑',
    description: '终止一个还在跑的后台任务（连同它的子进程树一起杀）。**只有主人能用**。'
      + '主人说「停掉那个」「别跑了」时用它。终止前收到的输出仍然可以 job_output 看。',
    parameters: {
      type: 'object',
      properties: {
        job_id: { type: 'string', description: '要停的任务号，例如 j1' }
      },
      required: ['job_id']
    },
    async execute(ctx, args) {
      return runTool(ctx, 'job_kill', args, () => L.jobs.killJob(args));
    }
  });

  T({
    id: 'read_image',
    name: '看图',
    icon: '🖼️',
    requiresVision: true,
    description: '读主人电脑上的一个图片文件，让**你自己看**（视觉模型直接看到画面）。**只有主人能用**。'
      + '支持 png/jpeg/gif/webp 等；太大的图会自动压缩后发给你。'
      + '主人发来的本地图片、截图、生成的图，都可以用它看。',
    parameters: {
      type: 'object',
      properties: {
        path: { type: 'string', description: '图片文件路径' }
      },
      required: ['path']
    },
    async execute(ctx, args) {
      return runTool(ctx, 'read_image', args, (cfg) => L.media.readImage(cfg, args));
    }
  });

  T({
    id: 'download_file',
    name: '下载文件',
    icon: '⬇️',
    description: '把一个 http/https 地址的文件下载到主人电脑上的指定路径。**只有主人能用**。'
      + '有大小上限（默认 64 MB）与超时；失败会删掉半截文件，不会留残废文件在盘上。',
    parameters: {
      type: 'object',
      properties: {
        url: { type: 'string', description: '下载地址（http/https）' },
        path: { type: 'string', description: '保存到哪个路径（含文件名）' },
        maxMB: { type: 'integer', description: '可选：大小上限 MB（默认 64，上限 2048）' },
        timeoutSec: { type: 'integer', description: '可选：超时秒数（默认 120，上限 600）' }
      },
      required: ['url', 'path']
    },
    async execute(ctx, args) {
      return runTool(ctx, 'download_file', args, (cfg) => L.media.downloadFile(cfg, args));
    }
  });

  T({
    id: 'work_info',
    name: '干活环境',
    icon: 'ℹ️',
    description: '查当前的工作目录、只读模式、允许访问的目录、shell、命令黑名单、审计日志位置。**只有主人能用**。'
      + '拿不准相对路径的基准、或者不确定能不能写的时候，先调它看一眼。',
    parameters: { type: 'object', properties: {} },
    async execute(ctx, args) {
      return runTool(ctx, 'work_info', args, (cfg) => {
        const roots = L.paths.allowedRootsOf(cfg);
        const problems = L.paths.patternProblems(cfg);
        const rules = L.paths.compilePatterns(cfg?.denyPatterns).filter((r) => r.re).length;
        const lines = [
          `工作目录（相对路径的基准，也是 run_command 的默认 cwd）：${L.paths.workDirOf(cfg)}`,
          `程序目录：${L.paths.APP_ROOT}`,
          `data 目录：${L.paths.DATA_DIR}`,
          `只读模式：${cfg?.readOnly === true ? '开（能看不能动：写文件/改文件/跑命令/下载都会被拒绝）' : '关（可写）'}`,
          `允许访问的目录：${roots.length ? roots.map((r) => `\n  - ${r}`).join('') : '不限制（整机）'}`,
          `允许在群聊里用：${cfg?.allowGroup === true ? '是' : '否（只在私聊里能用）'}`,
          `shell：${L.shell.describeShell(cfg)}`,
          `超时：命令 ${Math.min(1800, Math.max(1, Math.floor(Number(cfg?.commandTimeoutSec) || 120)))} 秒`
            + `；输出上限 ${Math.max(4, Number(cfg?.maxOutputKB) || 64)} KB`
            + `；read_file 默认 ${Math.max(1, Number(cfg?.readMaxKB) || 512)} KB`,
          `命令黑名单：${rules} 条生效${problems.length ? `；⚠️ ${problems.length} 条正则写错了（未生效）：${problems.join('、')}` : ''}`,
          `已记录"读过"的文件：${L.paths.ledgerSize()} 个（本次进程内）`,
          `后台任务：${L.jobs.jobStats().running} 个在跑 / 共 ${L.jobs.jobStats().total} 个（日志目录 ${L.jobs.jobStats().dir}）`,
          `审计日志：${cfg?.auditLog === false ? '已关闭' : L.audit.auditPath()}`,
          `本次调用者：${ctx?.kind ?? ''}:${ctx?.chatKey ?? ''}`
        ];
        return L.reply.ok(lines.join('\n'));
      });
    }
  });
}

// ── 接「长任务定时报告」 ────────────────────────────────────────────────────
// 后台任务动辄跑几分钟到几十分钟，这段时间会话是**完全静默**的（只有跑完那一下才回报）。
// 报告技能通过能力总线来问「现在有哪些长活在跑」，我们注册一个 list() 源给它现问。
//
// 为什么还要每 60 秒重注册一次：报告技能热重载时它的源表会整个清空，而它没有任何
// 办法知道我们还在 —— 重注册是这边唯一能做的自愈动作，成本是一次 Map.set。
// 报告技能没装 / 关了 / 坏了，`api.capability()` 一律返回 undefined（它吞异常），
// 这里静默跳过 —— 后台任务本身绝不该因为「报告发不出去」受任何影响。
const REPORT_SOURCE_ID = 'machine-work';
let reportSyncTimer = null;

function ensureReportSource() {
  if (!L?.jobs?.reportEntries) return;
  try {
    api?.capability?.('report.source', {
      id: REPORT_SOURCE_ID,
      label: '本机干活 · 后台任务',
      list: () => L.jobs.reportEntries()
    });
  } catch { /* 报告技能不在就安静地不报 */ }
}

function startReportSync() {
  ensureReportSource();
  if (reportSyncTimer) return;
  reportSyncTimer = setInterval(ensureReportSource, 60_000);
  try { reportSyncTimer.unref?.(); } catch { /* 有的运行时不支持 */ }
}

function stopReportSync() {
  if (reportSyncTimer) { clearInterval(reportSyncTimer); reportSyncTimer = null; }
  try { api?.capability?.('report.drop-source', { id: REPORT_SOURCE_ID }); } catch { /* ignore */ }
}

// ── 入口 ───────────────────────────────────────────────────────────────────

export async function setup(skillApi) {
  api = skillApi;

  // 见文件头最后一段：相对 import 不吃 loader 的缓存破坏参数，这里自己带一个。
  const t = Date.now();
  const imp = (p) => import(new URL(`${p}?t=${t}`, import.meta.url).href);
  L = {
    reply: await imp('./lib/reply.js'),
    paths: await imp('./lib/paths.js'),
    fsops: await imp('./lib/fs-ops.js'),
    shell: await imp('./lib/shell.js'),
    media: await imp('./lib/media.js'),
    audit: await imp('./lib/audit.js'),
    jobs: await imp('./lib/jobs.js'),
    notify: await imp('./lib/notify.js')
  };

  registerTools(skillApi);
  startReportSync();
  skillApi.log(`本机干活已加载：工作目录=${L.paths.workDirOf(skillApi.config?.() || {})}，`
    + `data=${L.paths.DATA_DIR}，工具=${TOOL_PREFIX}*`);
}

/**
 * 技能被停用 / 重载 / 删除时：**杀掉所有后台任务**。
 *
 * 为什么必须做：后台任务的句柄（child process、日志流、临时脚本）只活在这个模块实例的内存里。
 * 热重载会加载一个**新的** lib/jobs.js 实例，旧的 Map 连同里面所有任务一起被丢掉 ——
 * 那些进程就变成没人认领的孤儿：还在占 CPU、还在写文件，而主人再也查不到、
 * 也停不掉（工具查的是新实例的空列表）。宁可掐掉，也不要留一堆失控的进程。
 * 代价：改技能文件触发重载会把正在跑的后台任务一起杀掉 —— 这条写进了设置说明。
 */
export async function deactivate(reason) {
  stopReportSync();
  try {
    const killed = L?.jobs?.killAll?.(`技能被停用/重载：${reason ?? ''}`);
    if (killed?.length) api?.log?.(`停用：已终止后台任务 ${killed.join('、')}`);
  } catch (error) {
    api?.warn?.(`停用时终止后台任务失败：${error?.message ?? error}`);
  }
}

/** 删除技能时也要收尾（plugin-loader 的 dispose 路径）。 */
export function dispose() {
  stopReportSync();
  try { L?.jobs?.killAll?.('技能被删除'); } catch { /* ignore */ }
}

/** 给自检脚本用的出口（应用不会调它）。 */
export const __test__ = {
  guard,
  latestCaller,
  isOwner,
  get TOOL_PREFIX() { return TOOL_PREFIX; },
  get libs() { return L; }
};
