# 本机干活（machine-work）

让 QQ Agent **不经过 DSH**、自己在主人的电脑上真的动手：读文件、写文件、改文件、列目录、找文件、搜内容、跑 PowerShell、看图、下载文件。

---

## 为什么要有这个技能

在这之前，"要在电脑上干活"只有一条路：把任务交给 **微型 DSH**（`dsh-agent`）技能，由它 spawn 一个 DSH 进程。
那是个好东西，但它的启动成本很高——冷启动几十秒、要传人设、结果还要转回来。

而绝大多数请求根本不是那个量级：

| 主人说 | 以前 | 现在 |
| --- | --- | --- |
| 「看一眼 `data\config.json` 里模型是哪个」 | 交给 DSH，等 30~60 秒 | `read_file`，一次调用，几毫秒 |
| 「把那个 timeout 改成 60」 | 交给 DSH | `read_file` → `edit_file` |
| 「跑一下这个脚本看看报不报错」 | 交给 DSH | `run_command` |
| 「搜一下哪段代码用了 `getConfig`」 | 交给 DSH | `search_files` |

为买一瓶水开卡车是不划算的。所以这里把能力**直接做成 QQ Agent 自己的工具**——
就在应用进程里，一次工具调用就是一次真实的文件读写或进程执行，没有中间商、没有冷启动。

**分工**：小活（读/改/跑/搜）用本技能；需要多步自主探索、要开子代理、要跑很久的复杂任务，才交给微型 DSH。
技能自带的提示词片段已经把这条分工写进系统提示词了，模型知道什么时候用哪个。

---

## 工具一览（发给模型的名字都带 `machine-work__` 前缀）

| 工具 | 干什么 | 备注 |
| --- | --- | --- |
| `read_file(path, offset?, limit?)` | 读文本文件 | 输出每行带 `行号\| ` 前缀；二进制/超大文件会被拒绝并给替代方案 |
| `write_file(path, content, overwrite?)` | 新建或**整体覆盖** | **先看再改**规则见下 |
| `edit_file(path, old_string, new_string, replace_all?)` | 局部替换 | `old_string` 必须唯一（除非 `replace_all`） |
| `list_dir(path)` | 列目录 | 类型 / 大小 / 修改时间；目录在前 |
| `glob_files(pattern, path?, limit?)` | 按通配符找文件 | `**` `*` `?`；无斜杠的模式按任意层级匹配 |
| `search_files(pattern, path?, glob?, limit?)` | 按正则搜内容（grep） | 返回 `文件:行号: 内容` |
| `run_command(command, cwd?, timeoutSec?, background?)` | 跑一条 PowerShell | 真执行；超时杀进程树；`background: true` 转后台 |
| `job_list()` | 列后台任务 | 状态 / 耗时 / 还有多少没读 |
| `job_output(job_id, full?, maxKB?)` | 看后台任务输出 | 默认只回**上次之后的新内容** |
| `job_kill(job_id)` | 停掉后台任务 | 连子进程树一起杀 |
| `read_image(path)` | 看图 | 走多模态 parts，模型真的"看"到画面；大图自动压缩 |
| `download_file(url, path, maxMB?)` | 下载文件 | 有大小上限与超时；失败删残件 |
| `work_info()` | 看当前配置 | 工作目录 / 只读 / 白名单 / shell / 后台任务 / 审计路径 |

**先看再改**：覆盖一个已存在的文件前，必须在本会话里 `read_file` 读过它，否则拒绝（除非显式传 `overwrite: true`）。
两个例外：① 这个文件是你这次会话里用 `write_file` 自己写的（那你当然知道里面是什么）；
② 文件读完**之后**被外部改过 —— 这时记账作废，要求重读（防的是把别人刚改的东西盖掉）。
`edit_file` 同样要求先读过。

---

## 后台任务

前台 `run_command` 是**阻塞**的：一条跑 10 分钟的构建会把那一轮对话从头挂到尾，中途不能插话也不能看进度。
长活走后台：

```
run_command(command: "npm run build", background: true)   →  已转入后台：j1
job_output(job_id: "j1")                                   →  只回上次之后的新输出
job_kill(job_id: "j1")                                     →  连子进程树一起杀掉
```

四条设计决定，每条都有原因：

1. **输出有界 + 落盘**。内存里只留最近 1 MB（超了从头丢，丢了多少会写明）；完整输出同时流式写进
   `data\machine-work\jobs\<任务号>.log` —— 想看全的用 `read_file` / `search_files` 去读那个文件。
   让它读日志，而不是把几百 MB 灌进对话，直接决定这功能用得起用不起。
2. **`job_output` 只回增量**（游标推进）。反复查同一个任务不会把同一段日志重复烧进上下文。
   需要全量传 `full: true`。
3. **跑完主动回报**。模型那一轮早就结束了，没人会去轮询 —— 不主动发回来，后台任务就是石沉大海。
   结束（跑完/失败/被停/超时）时会以机器人身份把「状态 + 最后一段输出 + 完整日志路径」发回**发起它的那个会话**，
   走的是应用自己的本地发送路由（同「微型 DSH」发结果那条路）。
   发不出去不影响任务本身，只在 `job_list` 里标一句「回报失败」。可以在设置里关掉。
4. **技能被停用/重载时杀掉所有后台任务**。任务句柄（子进程、日志流、临时脚本）只活在当前模块实例的内存里，
   热重载会加载新的 `lib/jobs.js` 实例 —— 旧任务就变成没人认领的孤儿：还在占 CPU、还在写文件，
   而主人再也查不到也停不掉。**宁可掐掉。** 代价是：改技能文件触发的热重载会把正在跑的后台任务一起杀掉。

后台任务**不限时**（`timeoutSec` 传 0 就是这个意思），所以并发上限（默认 3）是唯一的闸。
另外它**没有 stdin**：需要交互的命令（`npm init` 之类）在后台会一直等输入，直到你停掉它。

后台不是"绕开闸的近路"：只读模式、命令黑名单、cwd 白名单检查与前台**共用同一份代码**
（`preflightCommand`）—— 少了这一层，模型把 `diskpart` 丢进后台就绕过去了。

---

## 安全模型

这个技能的能力等于**用主人的账号操作这台机器**，所以身份的判定是它的核心，不是附属功能。

### 1. 只认主人

每次调用都先算「谁在说话」，再核对主人身份：**本技能设置里的 `ownerIds` 名单** 或 **应用统一的「主人识别」能力**（`message.owner-check`），任一命中才放行。
两个都拿不到结论 → **拒绝**（不猜、不放行）。判定只认 QQ 号，群名片和昵称不参与。

### 2. 默认只在私聊可用（`allowGroup` 默认关）

工具的 `ctx` 里**没有调用者 QQ**，只能靠"本会话最近一条**别人**发的消息"反推。
私聊里这没有歧义（整个会话只有主人一个人）；群里就有：主人刚说完话、一个群友紧接着也说话，反推就会把群友当主人——
那等于把执行命令的权限开放给任何会抢话的群友。所以群里默认直接拒绝，要开得主人自己打开，并知道上面这个风险。

### 3. 三道可调的口子

- **只读模式**（`readOnly`）：能看不能动，写/改/跑/下载一律拒绝。
- **允许访问的目录**（`allowedRoots`）：填了之后，本技能路径类工具碰的每一个路径（含 `run_command` 的 cwd）都必须在里面。
  ⚠️ **它管不住命令内容** —— `run_command` 里写 `Get-Content D:\别处\x.txt` 照样读得出来。
  它挡的是"模型把路径搞错"和"顺手把整个 C 盘遍历一遍"，不是防主人自己。真正的命令隔离要操作系统级沙箱。
- **命令黑名单**（`denyPatterns`）：一行一条正则，拿整条命令匹配，命中即拒绝。
  默认挡 `diskpart`、`format C:`、`shutdown`、`Restart-Computer`、`Stop-Computer`、`Clear-Disk`、`Initialize-Disk`、`Remove-Partition`、`cipher /w`、`rm -rf /`、`reg delete HKLM`。
  ⚠️ 这是**防手滑**，不是安全边界。写错的正则不会被静默忽略——`work_info` 会把"哪条规则编译失败了"报出来。

### 4. 审计

每次调用（谁、在哪个会话、什么工具、什么参数、成没成、花了多久）追加一行 JSON 到
`data\machine-work\audit.jsonl`。超过 5 MB 转存一份，保留最近 3 份。
正文类参数只记摘要（前 200 字 + 总长度），不会把整份文件内容抄进日志。可以在设置里关掉。

---

## 实现上值得记住的几件事

这些都是踩过之后写死在代码注释和自检里的，改代码前先读一遍，别踩回去：

- **命令不拼命令行，写临时脚本**。`-Command "<文本>"` 要穿过 Node 的参数转义、cmd.exe 的解析、PowerShell 的解析三层，命令里有一个双引号就可能被吃掉。
  现在是把命令原样写进 `data\machine-work\tmp\run_*.ps1`（**带 UTF-8 BOM**，否则 PowerShell 5.1 按 ANSI 解析脚本，中文提示词全烂），用 `-File` 跑，跑完删掉。
- **中文输出必须治两处**：脚本开头的 `[Console]::OutputEncoding = UTF8`（管它往管道里写什么字节），
  和子进程环境里的 `PYTHONIOENCODING=utf-8`（这台机器上跑 python 的场景很多，不设就是 GBK 乱码）。
  另外给子进程加了 `NO_COLOR=1`：ANSI 颜色转义对模型是纯噪音。
- **还要治第三处：文件读写编码**（这条是 2026-10-08 在真机上跑冒烟测试才发现的）。
  本机**没装 PowerShell 7**（`where.exe pwsh` 找不到，`C:\Program Files\PowerShell\7\pwsh.exe` 也不存在），
  所以 `auto` 正确地回落到了 Windows PowerShell 5.1 —— 而 5.1 的 `Get-Content` **默认按系统 ANSI 码页读文件**，
  读一个 UTF-8 无 BOM 的中文文件回来是「涓枃鍐呭」。修法是序幕里六行
  `$PSDefaultParameterValues['Get-Content:Encoding'] = 'utf8'`（读、写、追加、Out-File、CSV 各一条）。
  两个细节别改错：① 值只能是**字符串** `'utf8'`，5.1 的 `-Encoding` 参数类型是
  `FileSystemCmdletProviderEncoding`，塞 `UTF8Encoding` 对象会绑定失败并**静默回落**
  （Out-File 甚至会用它的默认 UTF-16LE 写文件，字节以 `FF FE` 开头）；② 5.1 的 `Set-Content 'utf8'`
  写出来**带 BOM**，而 `JSON.parse` 不认 BOM —— 所以工具描述里明确写了「改 JSON/配置用 edit_file / write_file，别用 Set-Content」。
- **超时必须杀进程树**（`taskkill /T /F`）。只杀父进程的话，构建脚本留下的孙子进程会一直占着管道，命令永远不返回，整轮对话挂死。
- **输出只保留开头 + 结尾**（默认 64 KB）。只看开头会丢掉报错，只看结尾会丢掉上下文。
- **`lib/` 是带时间戳动态 import 的**。入口文件被 loader 用 `?t=时间戳` 加载，但**相对 import 不带那个时间戳**——
  ESM 按 URL 缓存，改完 `lib/` 再"重新加载技能"拿到的还是旧模块。所以 `index.js` 里对每个 lib 模块也带了自己的时间戳。
- **审计日志曾经永远是空的**：`rotateIfNeeded()` 在文件还不存在时 `statSync` 抛 ENOENT，异常被外层 catch 吞掉，
  结果每条记录都写不进去且一声不响。是自检脚本里的「审计日志已生成」把它抓出来的。

---

## 自检怎么跑

两套，分工不同：

```powershell
# ① 逻辑自检：206 项，在临时目录里把 13 个工具真跑一遍（可重复、不碰真实环境）
node "E:\Program Files\QQ Agent\resources\app\skills\machine-work\tests\verify-machine-work.mjs"

# ② 真机冒烟：39 项，用**默认配置**在真实路径上干活（App 目录 / 真 data 目录 / 真图 / 真命令 / 真外网）
node "E:\Program Files\QQ Agent\resources\app\skills\machine-work\tests\smoke-real-env.mjs"
```

① 覆盖：清单与注册一致性、身份闸的四种情形、先看再改的三种情形、`edit_file` 的行号前缀兜底、白名单、黑名单、
超时杀树、只读模式、中文编码（写/读/命令三条链）、输出截断、审计摘要、坏正则，
以及后台任务的全套：转后台、增量读、`full`、日志落盘、并发上限、失败状态、停止、**回报链路**
（在测试里起一个本地桩服务器冒充应用的 `test-send` 路由，断言它收到了正确的 URL 和正文）、
`deactivate` 杀掉在跑的任务。

② 覆盖的是①测不到的东西：默认工作目录在 Program Files 里到底**能不能写**、相对路径指到哪、
6 MB 的大图会不会被压缩后塞进对话、真外网能不能下、后台任务日志有没有落进真实 data 目录、
审计日志有没有落到真实位置、临时脚本有没有残留。
⚠️ ②里做后台任务时会**强制关掉主动回报** —— 真机上应用的 3210 端口是活的，开着就等于拿主人真实的 QQ 私聊当测试环境。

改这个技能之后**两套都要重跑**。它们已经抓到过三个真 bug：审计日志静默全丢、超时断言写错、
以及 PowerShell 5.1 读 UTF-8 文件乱码（②抓到的，①在临时目录里跑不到这个组合）。

---

## 排障

| 现象 | 原因 / 怎么办 |
| --- | --- |
| 模型说「这个只有主人能用」 | 说话的人不是主人，或者群聊里 `allowGroup` 没开。这是预期行为 |
| 工具一律回「拒绝：没能确认是谁在说话」 | 本会话还没有别人发过消息（工具靠聊天记录反推调用者），或「主人识别」插件被关了且 `ownerIds` 为空 |
| 「不在允许访问的目录里」 | `allowedRoots` 填了白名单，目标不在里面。要放宽就改设置 |
| 「命令命中了黑名单」 | **不要**换种写法重试。这是主人设的闸；确实需要就请主人删掉那条规则 |
| 命令输出里中文是乱码 | 已修（序幕里设了 `Get-Content:Encoding`）。真再遇到，先把 `$PSVersionTable.PSVersion` 和具体命令发出来 |
| 某个 JSON 配置被改坏 / 应用读配置报错 | 多半是模型用 `Set-Content` 写的：PowerShell 5.1 会写成带 BOM 的 UTF-8，`JSON.parse` 不认 BOM。工具描述里已经禁止这么干，改用 `edit_file` |
| 后台任务不见了 / 查不到 | 任务记录只活在内存里，**重启应用就没了**（日志文件还在 `data\machine-work\jobs\`）。另外技能被停用或热重载时，正在跑的任务会被主动杀掉，这是有意的 |
| 后台任务回报没收到消息 | 看 `job_list` 里有没有「回报失败」；回报走应用的本地发送路由，端口取自 `config.server.port`，发不出去不影响任务本身 |
| 改了 `lib/` 里的文件但行为没变 | 理论上不该发生（lib 带时间戳 import）。真遇到了就重启 QQ Agent，并把这个案例记下来 |
| 设置页里这 13 个工具在「⚙️ 系统反馈」分类下 | 有意为之：设置页的分类是硬编码的 8 类，新增一类要改 `src\tool-registry.js` 和 `ui\app\06-settings-render.js` 两个文件 |

---

## 文件清单

```
skills\machine-work\
  skill.json                    清单：设置项 / 配置表单（设置页据此渲染）/ 提示词片段
  index.js                      入口：身份闸 + 13 个工具注册 + 每个工具共用的外壳（闸/兜底/审计）+ deactivate 收尾
  lib\paths.js                  路径解析与访问控制（工作目录、白名单、黑名单编译、读过的文件记账）
  lib\fs-ops.js                 读/写/改/列目录/找文件/搜内容 + 输出截断
  lib\shell.js                  run_command（前置检查、shell 选择、UTF-8 编码、超时杀树、输出收集）
  lib\jobs.js                   后台任务（有界输出缓冲、增量读、日志落盘、主动回报、收尾杀进程）
  lib\notify.js                 往会话发消息（应用本地 test-send 路由，900 字分块 + CQ 中和）
  lib\media.js                  看图（多模态 parts）与下载
  lib\audit.js                  审计日志（摘要、转存）
  lib\reply.js                  工具返回值的两种形态（ok / fail / deny）
  tests\verify-machine-work.mjs 逻辑自检（临时目录，206 项）
  tests\smoke-real-env.mjs      真机冒烟（默认配置，真实路径，39 项）
```

运行时会落在 `data\machine-work\` 下的：`audit.jsonl`（审计）、`tmp\run_*.ps1|cmd`（临时脚本，跑完即删）、
`jobs\<任务号>.log`（后台任务的完整输出）。
