// 本机干活技能的自检：把每个工具**真的跑一遍**（真读写、真执行命令、真下载）。
//
// 跑法：
//   node "E:\Program Files\QQ Agent\resources\app\skills\machine-work\tests\verify-machine-work.mjs"
//
// 为什么不用 mock：这个技能的全部价值就是"真的动手"。把 fs 打桩之后，
// 剩下的只是"我的桩能不能被我的代码调用"——什么也证明不了。
// 所以每一项都在**临时目录**里做真事，跑完删掉；
// 唯一动到真实环境的是：data 目录被 QQ_AGENT_DATA_DIR 指到临时目录（审计/临时脚本都落那儿）。
//
// ⚠️ 必须在 import 技能入口**之前**设 QQ_AGENT_DATA_DIR：lib/paths.js 在模块加载时
//    就把 DATA_DIR 定下来了，晚了就指到真实 data 目录里去了。

import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import http from 'node:http';
import { fileURLToPath, pathToFileURL } from 'node:url';

const SKILL_DIR = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const TMP = fs.mkdtempSync(path.join(os.tmpdir(), 'mw-verify-'));
const WORK = path.join(TMP, 'work');
const OUTSIDE = path.join(TMP, 'outside');
fs.mkdirSync(WORK, { recursive: true });
fs.mkdirSync(OUTSIDE, { recursive: true });
process.env.QQ_AGENT_DATA_DIR = path.join(TMP, 'data');

let pass = 0;
let fail = 0;
const failures = [];

function check(name, cond, extra = '') {
  if (cond) {
    pass += 1;
    console.log(`  ok   ${name}`);
  } else {
    fail += 1;
    failures.push(name);
    console.log(`  FAIL ${name}${extra ? `\n       ${extra}` : ''}`);
  }
}

function section(title) {
  console.log(`\n§ ${title}`);
}

const manifest = JSON.parse(fs.readFileSync(path.join(SKILL_DIR, 'skill.json'), 'utf8'));

// ── 假装自己是 plugin-loader ───────────────────────────────────────────────
const tools = new Map();
let callLog = [];
const cfg = {
  enabled: true,
  ownerIds: '',
  allowGroup: false,
  readOnly: false,
  workDir: WORK,
  allowedRoots: WORK,
  denyPatterns: manifest.settings.denyPatterns,
  shell: 'auto',
  commandTimeoutSec: 30,
  maxOutputKB: 64,
  readMaxKB: 512,
  auditLog: true
};

const OWNER = '2624585744';
const skillApi = {
  // 复刻 plugin-loader 的命名规则：skillId__toolId
  registerTool(def) {
    const id = `machine-work__${String(def.id).replace(/[^a-zA-Z0-9_-]/g, '_')}`;
    tools.set(id, def);
    return id;
  },
  config: () => cfg,
  capability(name, args = {}) {
    if (name === 'message.owner-check') return { isOwner: String(args?.userId) === OWNER };
    return undefined;
  },
  log: (...a) => console.log('   [skill]', ...a),
  warn: (...a) => console.log('   [skill:warn]', ...a)
};

const mod = await import(pathToFileURL(path.join(SKILL_DIR, 'index.js')).href);
await mod.setup(skillApi);

function ctxOf({ kind = 'private', caller = OWNER, callerName = '乌——拉', chatKey = `private:${OWNER}` } = {}) {
  return {
    kind,
    chatKey,
    chatId: OWNER,
    selfId: '10001',
    store: { recent: () => (caller ? [{ senderId: caller, senderName: callerName }] : []) },
    session: {}
  };
}

async function call(id, args = {}, ctx = ctxOf()) {
  const def = tools.get(`machine-work__${id}`);
  if (!def) throw new Error(`工具没注册：${id}`);
  callLog.push(id);
  return await def.execute(ctx, args);
}

const textOf = (r) => (Array.isArray(r.content) ? r.content.filter((p) => p.type === 'text').map((p) => p.text).join('\n') : String(r.content));

// ── §1 注册与清单 ──────────────────────────────────────────────────────────
section('1. 注册与清单一致性');
const EXPECTED = ['read_file', 'write_file', 'edit_file', 'list_dir', 'glob_files', 'search_files',
  'run_command', 'job_list', 'job_output', 'job_kill', 'read_image', 'download_file', 'work_info'];
check('注册了 13 个工具', tools.size === EXPECTED.length, `实际 ${tools.size}：${[...tools.keys()].join(', ')}`);
for (const id of EXPECTED) check(`工具 machine-work__${id} 存在`, tools.has(`machine-work__${id}`));
for (const [id, def] of tools) {
  check(`${id} 的字段齐全（name/description/parameters/execute）`,
    !!def.name && !!def.description && !!def.parameters && typeof def.execute === 'function');
  const props = Object.keys(def.parameters.properties || {});
  const req = def.parameters.required || [];
  check(`${id} 的 required 都在 properties 里`, req.every((r) => props.includes(r)), `required=${req} props=${props}`);
}

// 提示词里写到的工具名必须真的存在（文档漂移是这类技能的常见腐坏方式）
const promptText = (manifest.prompt?.sections || []).map((s) => s.content).join('\n');
const mentioned = [...new Set([...promptText.matchAll(/machine-work__([a-z_]+)/g)].map((m) => m[1]))];
check('提示词里提到的工具全部存在', mentioned.every((m) => EXPECTED.includes(m)), `提到：${mentioned.join(', ')}`);
check('提示词覆盖了全部 13 个工具', EXPECTED.every((e) => mentioned.includes(e)), `只提到：${mentioned.join(', ')}`);

// 每个设置项都要有表单说明（否则在设置页里是一片没有解释的输入框）
const settingKeys = Object.keys(manifest.settings);
const schemaKeys = Object.keys(manifest.configSchema);
check('settings 与 configSchema 一一对应',
  settingKeys.length === schemaKeys.length && settingKeys.every((k) => schemaKeys.includes(k)),
  `settings=${settingKeys.join(',')} schema=${schemaKeys.join(',')}`);
for (const k of schemaKeys) {
  check(`configSchema.${k} 有 label 和 description`, !!manifest.configSchema[k].label && !!manifest.configSchema[k].description);
}

// ── §2 身份闸 ──────────────────────────────────────────────────────────────
section('2. 身份闸（只认主人 / 默认只在私聊）');
const allowed = await call('list_dir', { path: WORK }, ctxOf());
check('主人调用放行', !allowed.isError, textOf(allowed));

const stranger = await call('list_dir', { path: WORK }, ctxOf({ caller: '123456789', callerName: '路人' }));
check('陌生人调用被拒绝', stranger.isError && textOf(stranger).includes('不是主人'), textOf(stranger));
check('拒绝文案给了"该怎么说"的指引', textOf(stranger).includes('只有主人能用'));

const unknown = await call('list_dir', { path: WORK }, ctxOf({ caller: '' }));
check('认不出调用者时拒绝', unknown.isError && textOf(unknown).includes('没能确认'), textOf(unknown));

const inGroup = await call('list_dir', { path: WORK }, ctxOf({ kind: 'group', chatKey: 'group:123456' }));
check('群聊默认拒绝', inGroup.isError && textOf(inGroup).includes('只在私聊里用'), textOf(inGroup));

cfg.allowGroup = true;
const inGroupAllowed = await call('list_dir', { path: WORK }, ctxOf({ kind: 'group', chatKey: 'group:123456' }));
check('打开 allowGroup 后群聊可用', !inGroupAllowed.isError, textOf(inGroupAllowed));
cfg.allowGroup = false;

const viaOwnerIds = await call('list_dir', { path: WORK }, ctxOf({ caller: '55555' }));
check('名单外的号在能力判定为 false 时被拒', viaOwnerIds.isError);
cfg.ownerIds = '55555';
const viaList = await call('list_dir', { path: WORK }, ctxOf({ caller: '55555' }));
check('技能自带名单也认', !viaList.isError, textOf(viaList));
cfg.ownerIds = '';

// ── §3 read_file ───────────────────────────────────────────────────────────
section('3. read_file');
const sample = path.join(WORK, 'sample.txt');
fs.writeFileSync(sample, ['第一行', '第二行 target', '第三行', '第四行', '第五行'].join('\n'), 'utf8');

const r1 = await call('read_file', { path: sample });
check('读整文件成功', !r1.isError && textOf(r1).includes('第一行'), textOf(r1));
check('带行号前缀', /^\s*2\| 第二行 target$/m.test(textOf(r1)), textOf(r1));
check('报告了总行数', textOf(r1).includes('共 5 行'), textOf(r1));
check('中文没乱码', textOf(r1).includes('第二行 target'));

const r2 = await call('read_file', { path: sample, offset: 3, limit: 2 });
check('offset/limit 生效', textOf(r2).includes('第三行') && textOf(r2).includes('第四行') && !textOf(r2).includes('第五行'), textOf(r2));

const r3 = await call('read_file', { path: path.join(WORK, '不存在.txt') });
check('不存在的文件给出明确错误', r3.isError && textOf(r3).includes('不存在'), textOf(r3));

const r4 = await call('read_file', { path: WORK });
check('对目录给出"用 list_dir"的提示', r4.isError && textOf(r4).includes('list_dir'), textOf(r4));

const binFile = path.join(WORK, 'bin.dat');
fs.writeFileSync(binFile, Buffer.from([0x50, 0x4b, 0x03, 0x04, 0x00, 0x01, 0x02]));
const r5 = await call('read_file', { path: binFile });
check('二进制文件被拒绝并给替代方案', r5.isError && textOf(r5).includes('二进制'), textOf(r5));

const rel = await call('read_file', { path: 'sample.txt' });
check('相对路径以工作目录为基准', !rel.isError && textOf(rel).includes('第一行'), textOf(rel));

// ── §4 write_file（先看再改）───────────────────────────────────────────────
section('4. write_file / 先看再改');
const newFile = path.join(WORK, 'sub', 'deep', 'new.txt');
const w1 = await call('write_file', { path: newFile, content: 'hello 新文件' });
check('新建（含多层父目录）成功', !w1.isError && fs.readFileSync(newFile, 'utf8') === 'hello 新文件', textOf(w1));
check('回执里写了"已新建"', textOf(w1).includes('已新建'), textOf(w1));

// 「先看再改」的三种情形，一条条钉住语义：
//   (a) 外部就存在的文件（从没用工具读过写过）→ 盲写必须被拒
//   (b) 这次会话里工具自己写的文件 → 允许再写（自己写的当然知道里面是什么）
//   (c) 读过之后被外部改过 → 记账作废，要求重读
const extFile = path.join(WORK, 'external.txt');
fs.writeFileSync(extFile, '外部创建的内容，从没被工具碰过', 'utf8');
const w2 = await call('write_file', { path: extFile, content: '盲改' });
check('(a) 没读过就覆盖被拒绝', w2.isError && textOf(w2).includes('先读过'), textOf(w2));
check('(a) 拒绝后文件没被改动', fs.readFileSync(extFile, 'utf8') === '外部创建的内容，从没被工具碰过');

const w2b = await call('write_file', { path: newFile, content: '再写一次' });
check('(b) 这次会话里自己写过的文件可以直接覆盖', !w2b.isError, textOf(w2b));

const chFile = path.join(WORK, 'changed.txt');
fs.writeFileSync(chFile, 'v1', 'utf8');
await call('read_file', { path: chFile });
fs.writeFileSync(chFile, 'v2：外部把它改长了', 'utf8');
const w2c = await call('write_file', { path: chFile, content: 'x' });
check('(c) 读过之后被外部改过 → 要求重读', w2c.isError && textOf(w2c).includes('先读过'), textOf(w2c));

await call('read_file', { path: newFile });
const w3 = await call('write_file', { path: newFile, content: '读过之后覆盖 OK' });
check('读过之后可以直接覆盖', !w3.isError && fs.readFileSync(newFile, 'utf8') === '读过之后覆盖 OK', textOf(w3));
check('回执里写了"已覆盖"', textOf(w3).includes('已覆盖'), textOf(w3));

const w4 = await call('write_file', { path: newFile, content: '盲写也可以', overwrite: true });
check('显式 overwrite: true 放行盲写', !w4.isError, textOf(w4));

const w5 = await call('write_file', { path: newFile });
check('缺 content 时报错并指向 edit_file', w5.isError && textOf(w5).includes('edit_file'), textOf(w5));

const wEmpty = await call('write_file', { path: path.join(WORK, 'empty.txt'), content: '' });
check('写空文件成功', !wEmpty.isError && fs.readFileSync(path.join(WORK, 'empty.txt'), 'utf8') === '', textOf(wEmpty));

// ── §5 edit_file ───────────────────────────────────────────────────────────
section('5. edit_file');
const editFile = path.join(WORK, 'edit.txt');
fs.writeFileSync(editFile, 'alpha\nbeta\ngamma\ndelta\n', 'utf8');

const e0 = await call('edit_file', { path: editFile, old_string: 'beta', new_string: 'BETA' });
check('没读过就改被拒绝', e0.isError && textOf(e0).includes('先读过'), textOf(e0));

const shown = textOf(await call('read_file', { path: editFile }));
const e1 = await call('edit_file', { path: editFile, old_string: 'beta', new_string: 'BETA' });
check('读过后替换成功', !e1.isError && fs.readFileSync(editFile, 'utf8').includes('BETA'), textOf(e1));

const e2 = await call('edit_file', { path: editFile, old_string: '不存在的原文', new_string: 'x' });
check('找不到 old_string 时解释原因', e2.isError && textOf(e2).includes('找不到'), textOf(e2));

const dupFile = path.join(WORK, 'dup.txt');
fs.writeFileSync(dupFile, 'same\nother\nsame\n', 'utf8');
await call('read_file', { path: dupFile });
const e3 = await call('edit_file', { path: dupFile, old_string: 'same', new_string: 'S' });
check('不唯一时拒绝并要求 replace_all', e3.isError && textOf(e3).includes('replace_all'), textOf(e3));
const e4 = await call('edit_file', { path: dupFile, old_string: 'same', new_string: 'S', replace_all: true });
check('replace_all 全改', !e4.isError && fs.readFileSync(dupFile, 'utf8') === 'S\nother\nS\n', textOf(e4));

// 抄了 read_file 的行号前缀 —— 兜底要能救回来
const prefFile = path.join(WORK, 'pref.txt');
fs.writeFileSync(prefFile, 'line one\nline two\n', 'utf8');
const prefShown = textOf(await call('read_file', { path: prefFile }));
const lineWithPrefix = prefShown.split('\n').find((l) => l.includes('line two'));
const e5 = await call('edit_file', { path: prefFile, old_string: lineWithPrefix, new_string: 'LINE TWO' });
check('带行号前缀的 old_string 被兜底救回', !e5.isError && fs.readFileSync(prefFile, 'utf8').includes('LINE TWO'), `${lineWithPrefix} → ${textOf(e5)}`);
check('兜底时给出了提示', textOf(e5).includes('行号'), textOf(e5));

// 真实以数字开头的原文不应被误伤
const numFile = path.join(WORK, 'num.txt');
fs.writeFileSync(numFile, '12: 这是真的内容\n', 'utf8');
await call('read_file', { path: numFile });
const e6 = await call('edit_file', { path: numFile, old_string: '12: 这是真的内容', new_string: '改过了' });
check('真实以数字开头的原文能精确匹配', !e6.isError && fs.readFileSync(numFile, 'utf8').includes('改过了'), textOf(e6));

// ── §6 list_dir / glob / search ────────────────────────────────────────────
section('6. list_dir / glob_files / search_files');
const l1 = await call('list_dir', { path: WORK });
check('列目录成功', !l1.isError && textOf(l1).includes('sample.txt'), textOf(l1).slice(0, 300));
check('列目录标出了目录', textOf(l1).includes('DIR'), textOf(l1).slice(0, 300));

const l2 = await call('list_dir', { path: sample });
check('对文件调 list_dir 时给出提示', l2.isError && textOf(l2).includes('read_file'), textOf(l2));

const g1 = await call('glob_files', { pattern: '**/*.txt', path: WORK });
check('glob **/*.txt 命中', !g1.isError && textOf(g1).includes('sample.txt'), textOf(g1).slice(0, 300));
const g2 = await call('glob_files', { pattern: '*.txt', path: WORK });
check('无斜杠模式按任意层级匹配', !g2.isError && textOf(g2).includes('sample.txt'), textOf(g2).slice(0, 300));
const g3 = await call('glob_files', { pattern: '**/*.nope', path: WORK });
check('没有命中时明确说"没有匹配"', !g3.isError && textOf(g3).includes('没有匹配'), textOf(g3));
const g4 = await call('glob_files', { pattern: '**/*.txt', path: WORK, limit: 1 });
check('limit 生效并提示可调大', !g4.isError && textOf(g4).includes('只回前 1 个'), textOf(g4));

const s1 = await call('search_files', { pattern: 'target', path: WORK });
check('搜到内容并带行号', !s1.isError && /sample\.txt:2:/.test(textOf(s1)), textOf(s1).slice(0, 400));
const s2 = await call('search_files', { pattern: 'TARGET', path: WORK });
check('默认区分大小写', textOf(s2).includes('没有命中'), textOf(s2).slice(0, 200));
const s3 = await call('search_files', { pattern: 'TARGET', path: WORK, ignoreCase: true });
check('ignoreCase 生效', !s3.isError && textOf(s3).includes('sample.txt:2:'), textOf(s3).slice(0, 300));
const s4 = await call('search_files', { pattern: '第一', path: WORK, glob: '**/*.json' });
check('glob 过滤生效（json 里没有中文内容）', textOf(s4).includes('没有命中'), textOf(s4).slice(0, 300));
const s5 = await call('search_files', { pattern: '([', path: WORK });
check('正则写错时给出明确错误', s5.isError && textOf(s5).includes('正则'), textOf(s5));

// ── §7 允许目录（白名单）──────────────────────────────────────────────────
section('7. 允许访问的目录（白名单）');
fs.writeFileSync(path.join(OUTSIDE, 'secret.txt'), '白名单外', 'utf8');
cfg.allowedRoots = WORK;
const a1 = await call('read_file', { path: path.join(OUTSIDE, 'secret.txt') });
check('白名单外的读被拒绝', a1.isError && textOf(a1).includes('允许访问的目录'), textOf(a1));
const a2 = await call('run_command', { command: 'Write-Output hi', cwd: OUTSIDE });
check('cwd 在白名单外时命令被拦', a2.isError && textOf(a2).includes('允许访问的目录'), textOf(a2).slice(0, 200));
// ⚠️ 诚实记录一条**已知边界**：白名单管的是"本技能路径类工具碰哪里"，
//    管不住命令内容 —— `Get-Content 白名单外的文件` 照样能读出来（cwd 在工作目录里，
//    路径写在命令里）。真正的命令隔离需要操作系统级沙箱，不是正则能做的。
//    这里把这个事实钉在测试里，免得以后有人以为白名单能挡住 run_command。
const a2b = await call('run_command', { command: 'Get-Content "' + path.join(OUTSIDE, 'secret.txt') + '" -Raw', cwd: WORK });
check('已知边界：命令内容里的路径不受白名单限制（文档已写明）', !a2b.isError, textOf(a2b).slice(0, 200));
check('拦截文案列出了白名单目录', textOf(a1).includes(WORK), textOf(a1));
cfg.allowedRoots = '';
const a3 = await call('read_file', { path: path.join(OUTSIDE, 'secret.txt') });
check('清空白名单后放行', !a3.isError && textOf(a3).includes('白名单外'), textOf(a3));

// ── §8 run_command ─────────────────────────────────────────────────────────
section('8. run_command');
const c1 = await call('run_command', { command: 'Write-Output "hello from powershell"', cwd: WORK });
check('基本命令执行成功', !c1.isError && textOf(c1).includes('hello from powershell'), textOf(c1));
check('带 [exit code: 0]', textOf(c1).includes('[exit code: 0]'), textOf(c1));

const c2 = await call('run_command', { command: 'Write-Output "中文输出不乱码：鲨鱼"', cwd: WORK });
check('中文输出不乱码', textOf(c2).includes('中文输出不乱码：鲨鱼'), textOf(c2));

const c3 = await call('run_command', { command: 'exit 3', cwd: WORK });
check('非 0 退出码被报出来（不算工具失败）', !c3.isError && textOf(c3).includes('[exit code: 3]'), textOf(c3));

const c4 = await call('run_command', { command: 'Write-Error "出错了"', cwd: WORK });
check('stderr 单独成段', textOf(c4).includes('标准错误') && textOf(c4).includes('出错了'), textOf(c4));

const c5 = await call('run_command', { command: '[Console]::OutputEncoding.WebName', cwd: WORK });
check('输出编码已设成 utf-8', textOf(c5).toLowerCase().includes('utf-8'), textOf(c5));

// ── 编码回归：真实抓到过的 bug ──────────────────────────────────────────────
// Windows PowerShell 5.1 的 Get-Content 默认按系统 ANSI 码页读文件，
// 读一个 UTF-8 无 BOM 的中文文件（比如本技能自己写的文件）会回「涓枃鍐呭」这种乱码。
// 靠序幕里的 $PSDefaultParameterValues['Get-Content:Encoding']='utf8' 修掉。
const zhFile = path.join(WORK, '注意这里的编码.txt');   // 文件名也带中文：路径同样要能过
fs.writeFileSync(zhFile, '中文内容 line-one 结束\n', 'utf8');
check('测试文件确认是 UTF-8 无 BOM', fs.readFileSync(zhFile)[0] !== 0xEF);

const enc1 = await call('run_command', { command: `Get-Content "${zhFile}"`, cwd: WORK });
check('Get-Content 读 UTF-8 中文不乱码', !enc1.isError && textOf(enc1).includes('中文内容 line-one 结束'), textOf(enc1));
check('没有出现 U+FFFD 替换字符', !textOf(enc1).includes('\uFFFD'), textOf(enc1));

const enc2 = await call('run_command', { command: `Get-Content "${zhFile}" -Raw`, cwd: WORK });
check('命令里出现中文路径也没问题（脚本带 BOM）', !enc2.isError && textOf(enc2).includes('中文内容'), textOf(enc2));

// Set-Content 写出来的中文，Node 这边要能按 UTF-8 读回来（5.1 会带 BOM，要能容忍）
const enc3 = await call('run_command', { command: `Set-Content -Path "${path.join(WORK, 'shell-written.txt')}" -Value "命令写的第二行"; Write-Output done`, cwd: WORK });
check('Set-Content 写入成功', !enc3.isError && fs.existsSync(path.join(WORK, 'shell-written.txt')), textOf(enc3));
const shellWritten = fs.readFileSync(path.join(WORK, 'shell-written.txt'), 'utf8').replace(/^\uFEFF/, '');
check('Shell 写的中文是 UTF-8（不是 GBK）', shellWritten.includes('命令写的第二行'), JSON.stringify(shellWritten));

const c6 = await call('run_command', { command: 'Get-ChildItem -Name', cwd: WORK });
check('cwd 生效（能列出工作目录里的文件）', textOf(c6).includes('sample.txt'), textOf(c6));

const c7 = await call('run_command', { command: 'New-Item -ItemType File -Name made-by-command.txt -Force | Out-Null; Write-Output done', cwd: WORK });
check('命令真的改了磁盘', fs.existsSync(path.join(WORK, 'made-by-command.txt')), textOf(c7));

const c8 = await call('run_command', { command: 'diskpart', cwd: WORK });
check('黑名单拦住 diskpart', c8.isError && textOf(c8).includes('黑名单'), textOf(c8));
const c9 = await call('run_command', { command: 'format C:', cwd: WORK });
check('黑名单拦住 format C:', c9.isError, textOf(c9));
const c10 = await call('run_command', { command: 'Stop-Computer', cwd: WORK });
check('黑名单拦住 Stop-Computer', c10.isError, textOf(c10));
const c11 = await call('run_command', { command: 'Write-Output "formatting a string"', cwd: WORK });
check('正常命令不被黑名单误伤', !c11.isError && textOf(c11).includes('formatting a string'), textOf(c11));

const t0 = Date.now();
const c12 = await call('run_command', { command: 'Start-Sleep -Seconds 30; Write-Output "不该看到这行"', cwd: WORK, timeoutSec: 2 });
const tMs = Date.now() - t0;
check('超时被标记', c12.isError && textOf(c12).includes('超时'), textOf(c12));
check('超时后确实回来了（没有挂死）', tMs < 15000, `耗时 ${tMs} ms`);
// ⚠️ 只能断言"标准输出段是空的"，不能拿整段文本里有没有那句话去判 ——
//    回执开头会原样回落命令本身，那句话当然在里面（这一条一开始就写错过）。
check('超时后没有拿到命令后半段的输出',
  textOf(c12).includes('--- 标准输出 ---\n（空）'), textOf(c12));

const c13 = await call('run_command', { command: 'Write-Output "还活着"', cwd: WORK });
check('超时杀掉之后还能继续跑命令', !c13.isError && textOf(c13).includes('还活着'), textOf(c13));

const c14 = await call('run_command', { command: 'Write-Output "x"'.repeat(1), cwd: path.join(WORK, '不存在目录') });
check('cwd 不存在时报错', c14.isError && textOf(c14).includes('工作目录不存在'), textOf(c14));

// 超大输出要保留开头和结尾（把上限临时压到 4 KB，20000 行 ≈ 220 KB）
const bigCap = cfg.maxOutputKB;
cfg.maxOutputKB = 4;
const c15 = await call('run_command', { command: '1..20000 | ForEach-Object { "line $_" }', cwd: WORK });
cfg.maxOutputKB = bigCap;
check('大输出被截断且保留头尾',
  textOf(c15).includes('line 1') && textOf(c15).includes('line 20000') && textOf(c15).includes('省略'),
  `len=${textOf(c15).length}`);

// ── §9 readOnly ────────────────────────────────────────────────────────────
section('9. 只读模式');
cfg.readOnly = true;
const ro1 = await call('read_file', { path: sample });
check('只读模式下读文件仍然可用', !ro1.isError, textOf(ro1).slice(0, 200));
const ro2 = await call('write_file', { path: path.join(WORK, 'x.txt'), content: 'x' });
check('只读模式下写文件被拒绝', ro2.isError && textOf(ro2).includes('只读模式'), textOf(ro2));
const ro3 = await call('edit_file', { path: sample, old_string: '第一行', new_string: 'X' });
check('只读模式下改文件被拒绝', ro3.isError && textOf(ro3).includes('只读模式'), textOf(ro3));
const ro4 = await call('run_command', { command: 'Write-Output hi', cwd: WORK });
check('只读模式下执行命令被拒绝', ro4.isError && textOf(ro4).includes('只读模式'), textOf(ro4));
const ro5 = await call('download_file', { url: 'http://127.0.0.1:1/x', path: path.join(WORK, 'x.bin') });
check('只读模式下下载被拒绝', ro5.isError && textOf(ro5).includes('只读模式'), textOf(ro5));
check('只读模式下确实没写文件', !fs.existsSync(path.join(WORK, 'x.txt')));
cfg.readOnly = false;

// ── §10 read_image ─────────────────────────────────────────────────────────
section('10. read_image');
// 造一个最小合法 PNG（1x1）
const png = Buffer.from(
  'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8AAAwAB/wH2yQAAAABJRU5ErkJggg==',
  'base64'
);
const imgPath = path.join(WORK, 'dot.png');
fs.writeFileSync(imgPath, png);
const i1 = await call('read_image', { path: imgPath });
check('读图返回 text + image_url 两个 part', Array.isArray(i1.content) && i1.content.length === 2
  && i1.content[0].type === 'text' && i1.content[1].type === 'image_url', JSON.stringify(i1).slice(0, 200));
check('data URL 是 base64 png', String(i1.content?.[1]?.image_url?.url || '').startsWith('data:image/png;base64,'));
check('文本里给了路径和大小', textOf(i1).includes('dot.png') && textOf(i1).includes('B'), textOf(i1));

const i2 = await call('read_image', { path: sample });
check('对文本文件调 read_image 被拒绝', i2.isError && textOf(i2).includes('不像图片'), textOf(i2));
const i3 = await call('read_image', { path: path.join(WORK, '不存在.png') });
check('不存在的图片报错', i3.isError && textOf(i3).includes('不存在'), textOf(i3));

// ── §11 download_file ──────────────────────────────────────────────────────
section('11. download_file');
const PAYLOAD = Buffer.from('这是下载下来的内容 download-payload', 'utf8');
const server = http.createServer((req, res) => {
  if (req.url === '/good.bin') {
    res.writeHead(200, { 'content-type': 'application/octet-stream', 'content-length': PAYLOAD.length });
    res.end(PAYLOAD);
  } else if (req.url === '/big.bin') {
    res.writeHead(200, { 'content-type': 'application/octet-stream', 'content-length': 5 * 1024 * 1024 });
    res.end(Buffer.alloc(5 * 1024 * 1024));
  } else {
    res.writeHead(404).end('nope');
  }
});
await new Promise((r) => server.listen(0, '127.0.0.1', r));
const base = `http://127.0.0.1:${server.address().port}`;

const d1 = await call('download_file', { url: `${base}/good.bin`, path: path.join(WORK, 'dl.bin') });
check('下载成功', !d1.isError && fs.readFileSync(path.join(WORK, 'dl.bin')).equals(PAYLOAD), textOf(d1));
check('回执里有大小和 content-type', textOf(d1).includes('content-type'), textOf(d1));
check('没有留下 .part 残件', !fs.existsSync(path.join(WORK, 'dl.bin.part')));

const d2 = await call('download_file', { url: `${base}/404.bin`, path: path.join(WORK, 'dl404.bin') });
check('404 时明确报错', d2.isError && textOf(d2).includes('404'), textOf(d2));
check('404 时没有生成文件', !fs.existsSync(path.join(WORK, 'dl404.bin')));

const d3 = await call('download_file', { url: `${base}/big.bin`, path: path.join(WORK, 'big.bin'), maxMB: 1 });
check('超过大小上限时中止并删残件', d3.isError && !fs.existsSync(path.join(WORK, 'big.bin')), textOf(d3).slice(0, 200));

const d4 = await call('download_file', { url: 'ftp://x/y', path: path.join(WORK, 'x') });
check('非 http(s) 被拒绝', d4.isError && textOf(d4).includes('http'), textOf(d4));

const d5 = await call('download_file', { url: `${base}/good.bin`, path: path.join(OUTSIDE, 'blocked.bin') });
check('白名单为空时可写任意位置', !d5.isError, textOf(d5).slice(0, 150));
cfg.allowedRoots = WORK;
const d6 = await call('download_file', { url: `${base}/good.bin`, path: path.join(OUTSIDE, 'blocked2.bin') });
check('白名单生效时下载被拦', d6.isError && textOf(d6).includes('允许访问的目录'), textOf(d6));
cfg.allowedRoots = '';
server.close();

// ── §12 work_info / 审计日志 ───────────────────────────────────────────────
section('12. work_info 与审计日志');
const w = await call('work_info');
check('work_info 成功', !w.isError, textOf(w));
check('work_info 报了工作目录', textOf(w).includes(WORK), textOf(w).slice(0, 300));
check('work_info 报了只读状态', textOf(w).includes('只读模式'), textOf(w).slice(0, 400));
check('work_info 报了 shell', textOf(w).includes('shell'), textOf(w).slice(0, 500));

const auditFile = path.join(TMP, 'data', 'machine-work', 'audit.jsonl');
check('审计日志已生成', fs.existsSync(auditFile), auditFile);
const auditLines = fs.existsSync(auditFile) ? fs.readFileSync(auditFile, 'utf8').trim().split('\n') : [];
check('审计日志有记录', auditLines.length > 20, `行数 ${auditLines.length}`);
const last = auditLines.length ? JSON.parse(auditLines[auditLines.length - 1]) : {};
check('审计记录含工具名/调用者/成败/耗时',
  'tool' in last && 'callerId' in last && 'ok' in last && 'ms' in last, JSON.stringify(last).slice(0, 200));
const wrote = auditLines.map((l) => JSON.parse(l)).filter((l) => l.tool === 'write_file' && !l.ok);
check('审计里记到了被拒绝的那次写入', wrote.length > 0);
const bigArgs = auditLines.map((l) => JSON.parse(l)).find((l) => l.tool === 'write_file' && l.ok);
check('审计里的正文参数是摘要不是全文',
  !bigArgs || !String(bigArgs.args?.content || '').includes('\n'.repeat(10)), JSON.stringify(bigArgs?.args || {}).slice(0, 200));

// 关掉审计就不写了
cfg.auditLog = false;
const before = fs.statSync(auditFile).size;
await call('work_info');
check('关掉审计后不再写', fs.statSync(auditFile).size === before);
cfg.auditLog = true;

// 坏正则不能把人吓死：work_info 要报出来，其他命令照常
cfg.denyPatterns = 'diskpart\n([\n\\bshutdown\\b';
const bad = await call('work_info');
check('坏正则被报出来', textOf(bad).includes('写错'), textOf(bad).slice(0, 600));
const stillWorks = await call('run_command', { command: 'Write-Output ok', cwd: WORK });
check('坏正则不影响正常命令', !stillWorks.isError && textOf(stillWorks).includes('ok'), textOf(stillWorks));
const stillDenies = await call('run_command', { command: 'shutdown /s', cwd: WORK });
check('坏正则不影响好规则', stillDenies.isError, textOf(stillDenies));
cfg.denyPatterns = manifest.settings.denyPatterns;

// 关闭总开关
cfg.enabled = false;
const off = await call('work_info');
check('总开关关闭后一律拒绝', off.isError && textOf(off).includes('关掉'), textOf(off));
cfg.enabled = true;

// ── §13 提示词片段 ─────────────────────────────────────────────────────────
section('13. 提示词片段');
check('有一个提示词片段', (manifest.prompt?.sections || []).length === 1);
const sec = manifest.prompt.sections[0];
check('priority 低于 99（不得覆盖核心安全规则）', sec.priority < 99, String(sec.priority));
check('提示词里说明了只认主人', sec.content.includes('只有主人'), sec.content.slice(0, 80));
check('提示词里说明了不要绕道 DSH', sec.content.includes('dsh-agent__dsh_run'));
check('提示词里说明了先看再改', sec.content.includes('先'), sec.content.slice(0, 120));

// ── §13 后台任务 ───────────────────────────────────────────────────────────
section('13. 后台任务（run_command background + job_*）');

// 把「应用自己的发送接口」换成本地桩服务器：回报链路（任务结束 → POST test-send）就能整条验到。
// setRuntimeConfig 只改内存，不写盘（config.js 里就是给自测注入用的）。
const { setRuntimeConfig, getConfig } = await import('../../../src/config.js');
const received = [];
const appStub = http.createServer((req, res) => {
  let body = '';
  req.on('data', (c) => { body += c; });
  req.on('end', () => {
    received.push({ url: req.url, body: (() => { try { return JSON.parse(body); } catch { return { raw: body }; } })() });
    res.writeHead(200, { 'content-type': 'application/json' });
    res.end(JSON.stringify({ ok: true }));
  });
});
await new Promise((r) => appStub.listen(0, '127.0.0.1', r));
const stubPort = appStub.address().port;
const prevCfg = getConfig();
setRuntimeConfig({ ...structuredClone(prevCfg), server: { ...(prevCfg.server || {}), port: stubPort, token: '' } });

const j1 = await call('run_command', { command: 'Write-Output "第一步"; Start-Sleep -Seconds 1; Write-Output "第二步"', cwd: WORK, background: true });
check('转后台立刻返回任务号', !j1.isError && /已转入后台：j\d+/.test(textOf(j1)), textOf(j1));
check('回执里给了任务号与日志路径', /j\d+/.test(textOf(j1)) && textOf(j1).includes('.log'), textOf(j1));
const jobId = /已转入后台：(j\d+)/.exec(textOf(j1))?.[1];
check('任务号是 j1 这种短号', /^j\d+$/.test(String(jobId)), String(jobId));

const jl1 = await call('job_list');
check('job_list 列出了它', !jl1.isError && textOf(jl1).includes(jobId), textOf(jl1));
check('job_list 标了运行中', textOf(jl1).includes('运行中'), textOf(jl1));

const jo1 = await call('job_output', { job_id: jobId });
check('job_output 能立刻读（哪怕还在跑）', !jo1.isError && textOf(jo1).includes(jobId), textOf(jo1));
check('读过的内容被标成已读（第二次不该重复）', textOf(jo1).length > 0);

await new Promise((r) => setTimeout(r, 2500));
const jo2 = await call('job_output', { job_id: jobId });
check('跑完后拿到剩下输出（第二步）', textOf(jo2).includes('第二步'), textOf(jo2));
check('读完之后再读是"没有新输出"（游标推进，不重复烧上下文）', textOf(await call('job_output', { job_id: jobId })).includes('没有新输出'));

const joAll = await call('job_output', { job_id: jobId, full: true });
check('full: true 能拿到完整输出（含第一步）', textOf(joAll).includes('第一步') && textOf(joAll).includes('第二步'), textOf(joAll));

const logPath = path.join(TMP, 'data', 'machine-work', 'jobs', `${jobId}.log`);
check('完整日志落盘了', fs.existsSync(logPath), logPath);
check('日志里有完整两行', fs.existsSync(logPath) && fs.readFileSync(logPath, 'utf8').includes('第二步'));

const jl2 = await call('job_list');
check('job_list 标了已完成', textOf(jl2).includes('已完成'), textOf(jl2));

// 回报链路：任务结束 → POST 到应用自己的 test-send
await new Promise((r) => setTimeout(r, 500));
check('跑完主动回报（往会话发了消息）', received.length > 0, JSON.stringify(received).slice(0, 300));
const notice = received[0] || {};
check('回报打到正确的会话路由', String(notice.url || '').endsWith('/api/chats/private_2624585744/test-send'), String(notice.url));
check('回报里有任务号、状态和输出', JSON.stringify(notice.body || {}).includes(jobId) && JSON.stringify(notice.body || {}).includes('后台任务'), JSON.stringify(notice.body).slice(0, 300));
check('回报里带了完整日志路径', JSON.stringify(notice.body || {}).includes('.log'), JSON.stringify(notice.body).slice(0, 400));

// 失败的任务也要回报，并且状态是"失败"
const j2 = await call('run_command', { command: 'Write-Output "要炸了"; exit 7', cwd: WORK, background: true });
const job2 = /已转入后台：(j\d+)/.exec(textOf(j2))?.[1];
await new Promise((r) => setTimeout(r, 2000));
const jl3 = await call('job_list');
check('失败任务标成失败（带 exit 7）', textOf(jl3).includes('失败') && textOf(jl3).includes('exit 7'), textOf(jl3));
check('失败任务也回报了', received.some((r) => JSON.stringify(r.body).includes(job2)), JSON.stringify(received.map((r) => r.body)).slice(0, 400));

// 停掉一个还在跑的任务
const j3 = await call('run_command', { command: 'Start-Sleep -Seconds 60; Write-Output "不该跑完"', cwd: WORK, background: true });
const job3 = /已转入后台：(j\d+)/.exec(textOf(j3))?.[1];
const k1 = await call('job_kill', { job_id: job3 });
check('job_kill 受理', !k1.isError && textOf(k1).includes(job3), textOf(k1));
await new Promise((r) => setTimeout(r, 4000));
const jl4 = await call('job_list');
const line3 = textOf(jl4).split('\n').find((l) => l.includes(`${job3} `)) || '';
check('被停的任务状态是"被终止"', line3.includes('被终止'), line3 || textOf(jl4).slice(0, 400));
const k2 = await call('job_kill', { job_id: job3 });
check('已经结束的任务再停一次不报错', !k2.isError && textOf(k2).includes('已经结束'), textOf(k2));

// 并发上限
const capPrev = cfg.maxBackgroundJobs;
cfg.maxBackgroundJobs = 1;
const j4 = await call('run_command', { command: 'Start-Sleep -Seconds 20', cwd: WORK, background: true });
const job4 = /已转入后台：(j\d+)/.exec(textOf(j4))?.[1];
const j5 = await call('run_command', { command: 'Write-Output x', cwd: WORK, background: true });
check('到并发上限时拒绝新的后台任务', j5.isError && textOf(j5).includes('上限'), textOf(j5));
check('拒绝文案里列出了在跑的任务号', textOf(j5).includes(job4), textOf(j5));
await call('job_kill', { job_id: job4 });
cfg.maxBackgroundJobs = capPrev;

// 后台也必须过闸（只读 / 黑名单 / 白名单）—— 后台不是绕开闸的近路
cfg.readOnly = true;
const roJob = await call('run_command', { command: 'Write-Output x', cwd: WORK, background: true });
check('只读模式下后台任务也被拒绝', roJob.isError && textOf(roJob).includes('只读模式'), textOf(roJob));
cfg.readOnly = false;

const denyJob = await call('run_command', { command: 'diskpart', cwd: WORK, background: true });
check('黑名单在后台同样生效', denyJob.isError && textOf(denyJob).includes('黑名单'), textOf(denyJob));

const badJob = await call('run_command', { command: 'Write-Output x', cwd: path.join(WORK, '不存在'), background: true });
check('后台任务也会校验 cwd', badJob.isError && textOf(badJob).includes('工作目录不存在'), textOf(badJob));

const noId = await call('job_output', {});
check('job_output 缺 job_id 时给出提示', noId.isError && textOf(noId).includes('job_id'), textOf(noId));
const wrongId = await call('job_output', { job_id: 'j999' });
check('问不存在的任务号时列出当前任务', wrongId.isError && textOf(wrongId).includes('没有这个后台任务'), textOf(wrongId));

// 关掉主动回报
cfg.notifyOnJobDone = false;
const recvBefore = received.length;
const j6 = await call('run_command', { command: 'Write-Output "静默跑完"', cwd: WORK, background: true });
await new Promise((r) => setTimeout(r, 2000));
check('关掉回报后不再发消息', received.length === recvBefore, `received ${received.length} vs ${recvBefore}`);
cfg.notifyOnJobDone = true;

// ── §14 停用技能要杀掉后台任务 ─────────────────────────────────────────────
section('14. 停用技能时的收尾（不能让后台进程变成孤儿）');
const j7 = await call('run_command', { command: 'Start-Sleep -Seconds 120', cwd: WORK, background: true });
check('起了一个长任务', !j7.isError, textOf(j7));
const jobsMod = mod.__test__.libs.jobs;
check('任务在跑（jobStats.running = 1）', jobsMod.jobStats().running === 1, JSON.stringify(jobsMod.jobStats()));
await mod.deactivate('自检模拟重载');
check('deactivate 之后没有在跑的任务了', jobsMod.jobStats().running === 0, JSON.stringify(jobsMod.jobStats()));

setRuntimeConfig(prevCfg);
appStub.close();

// ── 收尾 ───────────────────────────────────────────────────────────────────
console.log(`\n调用过的工具：${[...new Set(callLog)].join(', ')}`);
console.log(`\n结果：${pass} 通过 / ${fail} 失败`);
if (fail) console.log(`失败项：\n- ${failures.join('\n- ')}`);

try { fs.rmSync(TMP, { recursive: true, force: true }); } catch { /* ignore */ }
// 用 exitCode 而不是 process.exit()：立刻 exit 会在 libuv 还在关句柄时触发
// "Assertion failed: !(handle->flags & UV_HANDLE_CLOSING)" ——
// 退出码照样是 1，但最后那行崩溃信息会把真正的失败项从视野里挤掉。
process.exitCode = fail ? 1 : 0;
