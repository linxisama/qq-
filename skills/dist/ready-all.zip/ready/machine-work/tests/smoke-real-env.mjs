// 真实环境冒烟测试：**不设临时目录**，就用技能 manifest 里的默认配置，
// 在主人这台机器的真实路径上干活（App 目录 / 真 data 目录 / 真图片 / 真命令 / 真网络）。
//
// 和 verify-machine-work.mjs 的分工：
//   那个测"逻辑对不对"（边界、拒绝、超时、编码），在临时目录里做，可重复；
//   这个测"默认配置在这台机器上到底能不能用" —— 默认工作目录在 Program Files 里，
//   能不能写、相对路径指哪、真图压缩走不走、真网络通不通，这些都只有真跑才知道。
//
// ⚠️ 它会往真实 data 目录写审计日志（这是正常行为，本来就该记），
//    除此之外创建的文件都在跑完时删掉。

import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

const SKILL_DIR = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const APP_ROOT = path.resolve(SKILL_DIR, '..', '..');            // resources/app
const INSTALL_ROOT = path.resolve(APP_ROOT, '..', '..');          // 安装目录

// 故意不设 QQ_AGENT_DATA_DIR：走 lib/paths.js 自己的解析链（真实场景就是这样）
delete process.env.QQ_AGENT_DATA_DIR;

let pass = 0; let fail = 0;
const failures = [];
const created = [];

function check(name, cond, extra = '') {
  if (cond) { pass += 1; console.log(`  ok   ${name}`); }
  else { fail += 1; failures.push(name); console.log(`  FAIL ${name}${extra ? `\n       ${extra}` : ''}`); }
}
const section = (t) => console.log(`\n§ ${t}`);

const manifest = JSON.parse(fs.readFileSync(path.join(SKILL_DIR, 'skill.json'), 'utf8'));
// 用默认设置（就是模型实际会拿到的配置），一个字段都不改
const cfg = { ...manifest.settings };

const OWNER = '2624585744';
const tools = new Map();
const skillApi = {
  registerTool(def) { const id = `machine-work__${def.id}`; tools.set(id, def); return id; },
  config: () => cfg,
  capability: (n, a = {}) => (n === 'message.owner-check' ? { isOwner: String(a?.userId) === OWNER } : undefined),
  log: (...a) => console.log('   [skill]', ...a),
  warn: () => {}
};
const mod = await import(pathToFileURL(path.join(SKILL_DIR, 'index.js')).href);
await mod.setup(skillApi);

const ctx = {
  kind: 'private', chatKey: `private:${OWNER}`, chatId: OWNER, selfId: '10001',
  store: { recent: () => [{ senderId: OWNER, senderName: '乌——拉' }] }, session: {}
};
const call = (id, args = {}) => tools.get(`machine-work__${id}`).execute(ctx, args);
const textOf = (r) => (Array.isArray(r.content) ? r.content.filter((p) => p.type === 'text').map((p) => p.text).join('\n') : String(r.content));

// ── §1 默认配置指向哪 ──────────────────────────────────────────────────────
section('1. 默认配置（模型实际会拿到的）');
const w = await call('work_info');
const wt = textOf(w);
check('work_info 可用', !w.isError, wt);
check('默认工作目录 = resources\\app', wt.includes(APP_ROOT), wt.split('\n')[0]);
check('data 目录解析到了真实安装目录', wt.includes(path.join(INSTALL_ROOT, 'data')), wt.split('\n').slice(0, 4).join(' | '));
check('data 目录确实存在', fs.existsSync(path.join(INSTALL_ROOT, 'data')));
check('白名单默认不限制（整机）', wt.includes('不限制'), wt);
check('默认不是只读', wt.includes('只读模式：关'), wt);
check('默认不允许群聊', wt.includes('允许在群聊里用：否'), wt);
check('自动选中了 shell', /pwsh|powershell/.test(wt), wt);

// ── §2 相对路径 / 真读真搜 ─────────────────────────────────────────────────
section('2. 相对路径 + 真读 / 真找 / 真搜');
const r1 = await call('read_file', { path: 'skills\\dsh-agent\\skill.json', offset: 1, limit: 4 });
check('相对路径以工作目录为基准读到了真文件', !r1.isError && textOf(r1).includes('dsh-agent'), textOf(r1).slice(0, 200));

const g1 = await call('glob_files', { pattern: 'skills/*/skill.json', limit: 30 });
check('真目录树里找到了技能清单', !g1.isError && textOf(g1).includes('machine-work'), textOf(g1).slice(0, 300));

const s1 = await call('search_files', { pattern: 'message\\.owner-check', path: 'plugins', limit: 5 });
check('真源码里搜到了 message.owner-check', !s1.isError && textOf(s1).includes('owner-check'), textOf(s1).slice(0, 300));

const l1 = await call('list_dir', { path: '.' });
check('列工作目录（App 根）', !l1.isError && textOf(l1).includes('skills'), textOf(l1).slice(0, 200));

// ── §3 真命令 ──────────────────────────────────────────────────────────────
section('3. 真命令（默认 cwd = App 目录）');
const c1 = await call('run_command', { command: 'node -v; (Get-Location).Path' });
check('node -v 能跑', !c1.isError && /v\d+\.\d+/.test(textOf(c1)), textOf(c1));
check('cwd 就是工作目录', textOf(c1).includes(APP_ROOT), textOf(c1));

const c2 = await call('run_command', { command: 'Get-ChildItem -Path skills -Directory | Measure-Object | Select-Object -ExpandProperty Count' });
check('能读到技能目录数量', !c2.isError && /1[0-9]/.test(textOf(c2)), textOf(c2));

// 中文 + 真实文件（用 Get-Content 读一个**含中文的真实 UTF-8 无 BOM 文件**——
// 这一条曾经真的挂过：本机没装 PowerShell 7，自动回落 5.1，而 5.1 的 Get-Content
// 默认按 GBK 读，读出来是「鏈満骞叉椿」。修法是序幕里设 Get-Content:Encoding=utf8）
const c3 = await call('run_command', { command: 'Get-Content "skills\\machine-work\\skill.json" -TotalCount 6' });
check('命令读中文文件没乱码', !c3.isError && textOf(c3).includes('本机干活'), textOf(c3));
check('输出里没有替换字符（U+FFFD）', !textOf(c3).includes('\uFFFD'), textOf(c3));

const c4 = await call('run_command', { command: '(Get-Command powershell -ErrorAction SilentlyContinue).Source; $PSVersionTable.PSVersion.ToString(); (Get-Command pwsh -ErrorAction SilentlyContinue).Source' });
check('报得出用的是哪个 shell', !c4.isError, textOf(c4));
console.log(`       （${textOf(c4).split('\n').filter((l) => l && !l.startsWith('$')).slice(0, 3).join(' / ')}）`);

// ── §4 真图片（含压缩路径）──────────────────────────────────────────────────
section('4. 真图片');
const whalePng = path.join(APP_ROOT, 'ui', 'whale', 'whale.png');
const i1 = await call('read_image', { path: whalePng });
check('读真 PNG 成功', Array.isArray(i1.content) && i1.content[1]?.type === 'image_url', JSON.stringify(i1).slice(0, 200));
check('返回了真实字节大小', textOf(i1).includes('KB'), textOf(i1).slice(0, 200));

const bigJpg = path.join(APP_ROOT, 'ui', 'skins', 'blue-fantasy', 'assets', 'whale-art.jpg');
const i2 = await call('read_image', { path: bigJpg });
check('读真 JPG 成功', Array.isArray(i2.content) && i2.content[1]?.type === 'image_url', textOf(i2).slice(0, 200));

const hugePng = path.join(APP_ROOT, 'ui', 'beauticode', 'themes', 'internal-beyond', 'bg-canvas.png');
const st = fs.existsSync(hugePng) ? fs.statSync(hugePng) : null;
if (st) {
  const i3 = await call('read_image', { path: hugePng });
  const compressed = textOf(i3).includes('已压到');
  check('大图（6MB）能读', Array.isArray(i3.content) && i3.content[1]?.type === 'image_url', textOf(i3).slice(0, 300));
  const b64len = String(i3.content?.[1]?.image_url?.url || '').length;
  check('大图确实被压小了（否则 base64 会超过 8MB）', b64len < 8 * 1024 * 1024, `base64 长度=${b64len}，原图=${st.size}，压缩说明=${compressed}`);
}

// ── §5 真写（Program Files 里能不能写）─────────────────────────────────────
section('5. 真写盘（默认工作目录在 Program Files 里）');
const relTarget = path.join(APP_ROOT, '_mw-smoke.tmp');
const w1 = await call('write_file', { path: '_mw-smoke.tmp', content: '冒烟测试\n第二行' });
if (!w1.isError) created.push(relTarget);
check('相对路径写进 App 目录成功（Program Files 可写）', !w1.isError && fs.existsSync(relTarget), textOf(w1));

if (!w1.isError) {
  const r2 = await call('read_file', { path: '_mw-smoke.tmp' });
  check('写进去的内容能读回来', textOf(r2).includes('第二行'), textOf(r2));
  const e1 = await call('edit_file', { path: '_mw-smoke.tmp', old_string: '第二行', new_string: '第二行改过了' });
  check('局部改成功', !e1.isError && fs.readFileSync(relTarget, 'utf8').includes('改过了'), textOf(e1));
}

const dataTarget = path.join(INSTALL_ROOT, 'data', '_mw-smoke', 'smoke.txt');
const w2 = await call('write_file', { path: dataTarget, content: 'data 目录也能写' });
if (!w2.isError) created.push(dataTarget);
check('data 目录可写（审计/临时脚本靠它）', !w2.isError, textOf(w2));

// ── §6 真网络 ──────────────────────────────────────────────────────────────
section('6. 真下载（外网）');
const dlTarget = path.join(INSTALL_ROOT, 'data', '_mw-smoke', 'robots.txt');
const d1 = await call('download_file', { url: 'https://hf-mirror.com/robots.txt', path: dlTarget, maxMB: 1, timeoutSec: 30 });
if (!d1.isError) created.push(dlTarget);
check('从 hf-mirror 下到了真文件', !d1.isError && fs.existsSync(dlTarget) && fs.statSync(dlTarget).size > 0, textOf(d1).slice(0, 300));
if (!d1.isError) {
  const head = fs.readFileSync(dlTarget, 'utf8').slice(0, 60).replace(/\n/g, ' ');
  console.log(`       （下到的开头：${head}…）`);
}

// ── §7 后台任务（真机）────────────────────────────────────────────────────
section('7. 后台任务（真机默认配置）');
// ⚠️ 这一节**必须关掉主动回报**：真机上应用的 3210 端口是活的，
//    开着回报就等于拿主人真实的 QQ 私聊做测试（会真的弹消息）。
//    「跑完主动回报」这条链在 verify-machine-work.mjs 里用本地桩服务器验过了（含路由和正文），
//    这里只验真机上的进程、日志落盘和收尾。
const notifyPrev = cfg.notifyOnJobDone;
cfg.notifyOnJobDone = false;
const b1 = await call('run_command', { command: '1..3 | ForEach-Object { Write-Output "后台第 $_ 行" }; Start-Sleep -Seconds 1', background: true });
check('真机上转后台成功', !b1.isError && /已转入后台：j\d+/.test(textOf(b1)), textOf(b1));
const bgId = /已转入后台：(j\d+)/.exec(textOf(b1))?.[1];
await new Promise((r) => setTimeout(r, 2500));
const b2 = await call('job_output', { job_id: bgId });
check('后台任务输出能读回来', !b2.isError && textOf(b2).includes('后台第 3 行'), textOf(b2));
const bgLog = path.join(INSTALL_ROOT, 'data', 'machine-work', 'jobs', `${bgId}.log`);
check('完整日志落进了真实 data 目录', fs.existsSync(bgLog), bgLog);
const b3 = await call('job_list');
check('job_list 能看到它且已结束', !b3.isError && textOf(b3).includes('已完成'), textOf(b3).slice(0, 400));

// 收尾：起一个长任务，然后模拟"技能被停用"，确认它被掐掉
const b4 = await call('run_command', { command: 'Start-Sleep -Seconds 120', background: true });
const jobsMod = mod.__test__.libs.jobs;
check('长任务在跑', jobsMod.jobStats().running === 1, JSON.stringify(jobsMod.jobStats()));
await mod.deactivate('冒烟测试收尾');
check('停用后没有残留在跑的任务', jobsMod.jobStats().running === 0, JSON.stringify(jobsMod.jobStats()));
cfg.notifyOnJobDone = notifyPrev;

// ── §8 审计日志落哪 ────────────────────────────────────────────────────────section('7. 审计日志');
const audit = path.join(INSTALL_ROOT, 'data', 'machine-work', 'audit.jsonl');
check('审计日志写进了真实 data 目录', fs.existsSync(audit), audit);
if (fs.existsSync(audit)) {
  const lines = fs.readFileSync(audit, 'utf8').trim().split('\n').filter(Boolean);
  const last = JSON.parse(lines[lines.length - 1]);
  check('审计里有本次真实调用', lines.length > 0, `行数 ${lines.length}`);
  console.log(`       最后一条：${last.ts} ${last.tool} ok=${last.ok} caller=${last.callerId} ${last.ms}ms`);
  check('审计记的是主人 QQ', last.callerId === OWNER, JSON.stringify(last).slice(0, 200));
}

// ── §9 临时脚本有没有留下垃圾 ──────────────────────────────────────────────
section('9. 收尾');
const tmpDir = path.join(INSTALL_ROOT, 'data', 'machine-work', 'tmp');
const leftovers = fs.existsSync(tmpDir) ? fs.readdirSync(tmpDir) : [];
check('临时脚本跑完即删（没有残留）', leftovers.length === 0, leftovers.join(', '));

for (const f of created) { try { fs.rmSync(f, { force: true }); } catch { /* ignore */ } }
try { fs.rmSync(path.join(INSTALL_ROOT, 'data', '_mw-smoke'), { recursive: true, force: true }); } catch { /* ignore */ }
check('清理完成（测试文件已删）', !fs.existsSync(relTarget) && !fs.existsSync(dataTarget));

console.log(`\n结果：${pass} 通过 / ${fail} 失败`);
if (fail) console.log(`失败项：\n- ${failures.join('\n- ')}`);
process.exitCode = fail ? 1 : 0;
