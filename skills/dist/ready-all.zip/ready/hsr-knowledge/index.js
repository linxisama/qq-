// 星穹铁道知识库 —— 从 biligame wiki（sr）抓取条目，整理成可读文本交给模型回答。
//
// 数据来源（MediaWiki，公开可读，无需登录 / Cookie）：
//   https://wiki.biligame.com/sr/api.php
//   · 搜索：action=query&list=search&srsearch=<关键词>
//   · 取正文：action=parse&page=<标题>&prop=text&section=0  → 渲染后 HTML，再去标签成纯文本
//
// 设计：能联网查就查（保证数值/名称准确）；查不到或断网时提示模型改用自身常识作答，
//       而不是把错误抛给用户。

const SR_API = 'https://wiki.biligame.com/sr/api.php';

const DEFAULT_MAX_CHARS = 1400;
const DEFAULT_TIMEOUT = 15000;
const SEARCH_LIMIT = 5;
const TOP_INTRO = 2; // 最多抓取前几条结果的正文

let cfg = () => ({});

// ---------- 文本处理 ----------

function decodeEntities(s) {
  return String(s)
    .replace(/&nbsp;|&#160;/gi, ' ')
    .replace(/&lt;/gi, '<')
    .replace(/&gt;/gi, '>')
    .replace(/&quot;/gi, '"')
    .replace(/&#39;|&apos;/gi, "'")
    .replace(/&mdash;/gi, '—')
    .replace(/&amp;/gi, '&');
}

/** 把一段 HTML 压成纯文本（去掉样式/脚本/标签，顺手清掉引用角标 [1]）。 */
function htmlToText(html) {
  return decodeEntities(
    String(html)
      .replace(/<style[\s\S]*?<\/style>/gi, ' ')
      .replace(/<script[\s\S]*?<\/script>/gi, ' ')
      .replace(/<[^>]+>/g, ' ')
  )
    .replace(/\[[\d, ]*\]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

function truncate(s, n) {
  const t = String(s || '');
  if (t.length <= n) return t;
  // 尽量在词边界截断，避免半个词
  const cut = t.slice(0, n).replace(/\s+\S*$/, '');
  return `${cut}…`;
}

function clamp(n, lo, hi) {
  const v = Number(n);
  if (!Number.isFinite(v)) return lo;
  return Math.min(hi, Math.max(lo, Math.round(v)));
}

// ---------- 抓取 ----------

function fetchOptions() {
  const ms = clamp(Number(cfg().timeoutMs) || DEFAULT_TIMEOUT, 3000, 60000);
  try {
    return { signal: AbortSignal.timeout(ms), headers: { 'User-Agent': 'QQAgent-Skill/1.0' } };
  } catch {
    return { headers: { 'User-Agent': 'QQAgent-Skill/1.0' } };
  }
}

async function getJson(params) {
  const url = `${SR_API}?${new URLSearchParams(params).toString()}`;
  const res = await fetch(url, fetchOptions());
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  const json = await res.json();
  if (json?.error) throw new Error(json.error.info || json.error.code || 'API 返回错误');
  return json;
}

async function searchWiki(q) {
  const json = await getJson({
    action: 'query',
    list: 'search',
    srsearch: q,
    srlimit: SEARCH_LIMIT,
    format: 'json',
    formatversion: '2'
  });
  return json?.query?.search || [];
}

async function getIntro(title) {
  const json = await getJson({
    action: 'parse',
    page: title,
    prop: 'text',
    section: '0',
    format: 'json',
    formatversion: '2'
  });
  const html = json?.parse?.text;
  if (!html) throw new Error('页面没有返回内容');
  return htmlToText(html);
}

// ---------- 技能入口 ----------

export function setup(api) {
  cfg = api.config;

  api.registerTool({
    id: 'hsr_query',
    name: '查星穹铁道知识',
    description:
      '查询《崩坏：星穹铁道》（星铁）相关知识，数据来自 biligame 官方 wiki。'
      + '当群友 @机器人 或被问到星铁的角色、光锥（武器）、命途、属性、遗器、配队、'
      + '剧情/世界观、材料、敌人、版本情报、卡池相关等任何游戏知识时使用。'
      + '参数 query 写用户想查的关键词（如「丹恒」「景元」「星穹列车」「光锥」「开拓者」），'
      + '拿不准的专有名词直接作为 query 传入即可。'
      + '注意：工具只返回 wiki 资料，由你据此组织自然语言回答，不要编造 wiki 里没有的具体数值。',
    category: 'knowledge',
    icon: '📖',
    parameters: {
      type: 'object',
      properties: {
        query: {
          type: 'string',
          description: '要查询的星穹铁道关键词，如角色名、光锥名、剧情/世界观名词、系统名等。'
        }
      },
      required: ['query']
    },
    async execute(_ctx, args) {
      const query = String(args?.query || '').trim();
      if (!query) {
        return { content: '缺少 query 参数：把要查的星穹铁道内容（如角色名、光锥名、剧情关键词）告诉我。', isError: true };
      }

      const maxChars = clamp(Number(cfg().maxChars) || DEFAULT_MAX_CHARS, 200, 4000);

      try {
        const results = await searchWiki(query);
        if (!results.length) {
          return {
            content:
              `在《崩坏：星穹铁道》wiki 上没有搜到与「${query}」相关的条目。`
              + '请基于你自身对《崩坏：星穹铁道》的了解回答用户，并说明这是基于常识、非官方实时资料。'
          };
        }

        const blocks = [];
        const titles = [];
        for (const r of results.slice(0, TOP_INTRO)) {
          titles.push(r.title);
          try {
            const intro = truncate(await getIntro(r.title), maxChars);
            if (intro) blocks.push(`■ ${r.title}\n${intro}`);
          } catch {
            // 单条正文抓取失败，忽略，继续下一条
          }
        }

        const related = results.map((r) => r.title);

        if (!blocks.length) {
          // 正文都抓不到，至少给搜索摘要
          const snips = results
            .slice(0, 3)
            .map((r) => `■ ${r.title}\n${decodeEntities(r.snippet || '')}`)
            .join('\n\n');
          return {
            content:
              `（wiki 正文抓取失败，以下是搜索摘要）\n${snips}\n\n`
              + `相关条目：${related.join('、')}\n\n`
              + `请结合以上线索与你的常识回答用户关于「${query}」的问题。`
          };
        }

        const text = blocks.join('\n\n');
        return {
          content:
            `以下是从《崩坏：星穹铁道》biligame wiki 查到的资料（来源条目：${titles.join('、')}；`
            + `相关条目还有：${related.join('、')}），请据此用自然口语回答用户，不要照抄大段原文，只给与问题相关的关键信息：\n\n${text}`
        };
      } catch (error) {
        const reason = error?.name === 'TimeoutError' ? '抓取超时' : (error?.message ?? error);
        return {
          content:
            `联网查询星穹铁道 wiki 失败（${reason}）。`
            + '请基于你自身对《崩坏：星穹铁道》的了解回答用户，并说明这是基于常识、非官方实时资料。'
        };
      }
    }
  });
}
