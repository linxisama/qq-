// 关注 / 取关 B站 UP 主（bilibili-follow v1.0.1）—— 本地自制技能
//
// 形态：skills/ + registerTool（**LLM 型**）。注册三个工具：follow / unfollow / list。
//
// ⚠️ 为什么放 skills/ 而不是 plugins/：
//   宿主 plugin-loader.js 的 lintKindPlacement 认定 ——
//     plugins/ 是**确定性型**（提供能力 providers / 钩子 hooks，核心按能力名取用）
//     skills/  是**LLM 型**（registerTool 注册工具，由模型决定何时调用）
//   本技能是工具型。若放进 plugins/，启动日志会报
//   "在 plugins/（确定性型）却没有提供能力、钩子或提示词片段：没有任何代码会去调用它"。
//
// ⚠️ 也**不碰**在用的 plugins/bilibili-video-downloader 与 plugins/bili-video：
//   那两个是"转发视频"的确定性插件，本技能只**只读**其中一份 cookie 配置（见下），
//   不改它们一个字节。它们若升级替换，本技能的读法也不会影响它们。
//
// ── 三道硬闸（缺一不可；下面的代码顺序 = 闸门顺序）────────────────────────
//   ① 只允许机主私聊：ctx.chatKey 必须严格等于 `private:<ownerQQ>`。
//      机主 QQ 取自 self-profile 技能的 ownerQQ（见 ownerQQOf()）。**默认留空** ——
//      留空时本闸门拒绝所有人（fail-closed），要用就先在 self-profile 里配好 ownerQQ。
//      **拿不到 ctx / 拿不到 chatKey 时保守拒绝**，不是放行。
//   ② 每日上限：perDay（默认 2），计数写在持久化的状态文件里，重启不丢。
//      ⚠️ 状态文件损坏时**失败关闭**（拒绝执行 + 留证 + 绝不清零额度），
//         这是本项目已经踩过的坑（plugins/affinity 的账本被空壳覆盖），照它的做法办。
//   ③ 登录态：动手前先打 x/web-interface/nav；未登录 / 凭据失效就明确报错，绝不静默失败。
//
// ── 为什么这三条都不能省 ────────────────────────────────────────────────
//   · 关注/取关改的是**真实 B站账号**的关系链，好友动态、UP 主后台都看得见；
//     而"取关"没有二次确认 —— 模型顺手一调就可能把机主攒了几年的关注清掉。
//   · 频繁的关系变更正是 B站风控的典型触发行为（可能招来限制）。
//   · 所以三道闸**故意不做成可配置绕过**：perDay 只能调小（填 0 = 完全关闭），
//     机主判定写死在 self-profile 的 ownerQQ 上，登录态一律先探再动。
//
// ── 判断成败看 B站的业务码 code，**不看 HTTP 状态码**────────────────────
//   本项目已有血泪教训：只看 HTTP 200 就把 B站的限流/风控说成"没搜到"。
//   这里一律解析 JSON 体、以 code === 0 为唯一成功判据；HTTP 非 2xx 但体里带 code
//   时也照样按 code 判定（B站经常这么干），只有连 JSON 都不是才退回报 HTTP。
//   码值含义依据 bilibili-API-collect 的 docs/user/relation.md：
//     0 成功 · -101 账号未登录 · -102 账号被封停 · -111 csrf 校验失败 · -400 请求错误
//     22001 不能对自己进行此操作 · 22003 用户位于黑名单（即"已被拉黑"）
//   ⚠️ 注意 22001 不是"已被拉黑"（网上常见误传），22003 才是。
//
// ── 成功文案里为什么要带粉丝数 ──────────────────────────────────────────
//   只回一句"已关注"时，模型无法确认自己关注的是不是同名的人。
//   带上 UID + 粉丝数，机主一眼能看出对不对（同名 UP 主很多）。
//
// ── 搜索接口为什么必须同时带 buvid3 指纹（v1.0.1 实测结论，别删）─────────
//   本机出口 IP 处在 B站风控名单里，实测（2026-10-10，同一分钟内对照）：
//     · 搜索接口**完全匿名**（连 Cookie 头都没有）→ HTTP 412 / code:-412 / "request was banned"
//     · 搜索接口带 **buvid3 指纹**           → code:0 ✓
//     · 搜索接口带 **登录 cookie**           → 时好时坏（同一台机器上两种结果都复现过）
//   结论：buvid3/buvid4 指纹是"最低门槛"，登录态**不能替代**它 —— 两者都带最稳。
//   所以 v1.0.1 起：搜索前先领一次 x/frontend/finger/spi（匿名接口，无需登录），
//   把 buvid3/buvid4 与登录 cookie 拼在一起发；领不到指纹也**不因此失败**，
//   只是这一趟少一层保护（宁可发出去，也不要因为一次指纹请求挂掉就整个放弃）。
//   ⚠️ 取 stream 的那条路（转发视频）不受影响 —— 那是另一个插件，本技能只读它的 cookie。

import fs from 'node:fs'
import path from 'node:path'
import { DATA_DIR as CONFIG_DATA_DIR } from '../../src/config.js'
import { getSkillConfig } from '../../src/skills/config.js'

const SKILL_ID = 'bilibili-follow'
/**
 * 机主 QQ 的回退值。
 *
 * ⚠️ 默认**留空**：本文件会随技能上传到公开市场，写死任何人的号都会跟着公开。
 *    留空时下面的 ownerQQOf() 返回 ''，第 ① 道闸门（chatKey === `private:<ownerQQ>`）
 *    会拒绝所有人 —— fail-closed，正是"没配就不放行"该有的行为。
 *    要用这个技能：在 self-profile 技能里配好 ownerQQ，或在这里填上你自己的号。
 */
const FALLBACK_OWNER_QQ = ''
/** 在用的 B站转发插件 id —— 只读它的 cookie 配置，不改它。 */
const DOWNLOADER_ID = 'bilibili-video-downloader'

const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
  + '(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
const REFERER = 'https://www.bilibili.com/'
const TIMEOUT_MS = 15000

/** B站接口域名（默认官方）。仅供本地假服务测试覆盖，**不从配置读**，避免被 UI 改歪。 */
let apiBase = 'https://api.bilibili.com'
const envBase = String(process.env.BILI_FOLLOW_API_BASE || '').trim()
if (envBase) apiBase = envBase.replace(/\/+$/, '')

/**
 * 数据目录。优先吃环境变量 QQ_AGENT_DATA_DIR（应用启动时用它指定数据目录），
 * 没设再退回核心 src/config.js 推导出来的 DATA_DIR（它同样认这个环境变量，
 * 另外还支持 QQ_AGENT_PROFILE 的多实例后缀）。
 * ⚠️ 不能按本文件所在目录往上推算：便携版会把数据目录重定向到安装目录之外。
 */
const DATA_DIR = String(process.env.QQ_AGENT_DATA_DIR || '').trim() || CONFIG_DATA_DIR
/** 本技能自己的状态（每日额度计数）。与插件同约定：<数据目录>/plugin-data/<id>/ */
const PLUGIN_DATA_DIR = path.join(DATA_DIR, 'plugin-data', SKILL_ID)
const STATE_FILE = path.join(PLUGIN_DATA_DIR, 'state.json')
/** 应用主配置：回退读下载插件的 cookie 用（只取这一个键）。 */
const CONFIG_FILE = path.join(DATA_DIR, 'config.json')
/** 在用下载插件的扫码登录凭据（见 resolveCookie 的第 ③ 段）。 */
const DOWNLOADER_AUTH_FILE = path.join(DATA_DIR, 'plugin-data', DOWNLOADER_ID, 'auth.json')

const DEFAULT_SETTINGS = {
  enabled: true,
  perDay: 2,
  cookie: '',
  // 扩展项（需求里只点名了前三个；这一条是为了"开箱能用"，可关，见 README）
  useDownloaderLogin: true
}

// ── 设置读取 ────────────────────────────────────────────────────────────
// ⚠️ 宿主构造工具 ctx 时**没有** config / skillConfig 键（src/orchestrator.js 里核实过），
//    所以 ctx?.skillConfig ?? ctx?.config?.skills?.[id] 恒为 {} ——
//    表现为"设置页改了没用、也不报错"。正确入口只有 setup(api) 里的 api.config()
//    （src/plugin-loader.js：config: () => skillManager.settingsOf(id)，已合并 manifest 默认值）。
//    这里再叠一层 getSkillConfig 兜底，好处是脱离宿主（本地单测）也能读设置。
let conf = () => ({ ...DEFAULT_SETTINGS })

function settingsRaw() {
  let raw = null
  try {
    if (typeof conf === 'function') raw = conf()
  } catch { raw = null }
  if (raw && typeof raw === 'object' && Object.keys(raw).length) return raw
  try {
    const c = getSkillConfig(SKILL_ID, DEFAULT_SETTINGS)
    if (c && typeof c === 'object') return c
  } catch { /* 读不到就用默认值 */ }
  return { ...DEFAULT_SETTINGS }
}

function cfgOf() {
  const raw = settingsRaw()
  const perDayNum = Number(raw.perDay)
  return {
    enabled: raw.enabled !== false,
    // perDay <= 0 表示"完全禁止"，不是"不限量" —— 保守解释，见文件头的说明。
    perDay: Number.isFinite(perDayNum) ? Math.max(0, Math.trunc(perDayNum)) : DEFAULT_SETTINGS.perDay,
    cookie: String(raw.cookie ?? '').trim(),
    useDownloaderLogin: raw.useDownloaderLogin !== false
  }
}

/**
 * 机主 QQ 的唯一来源：self-profile 技能的 ownerQQ。
 * 取不到（技能没装 / 没配 / 配置读崩）就回退 FALLBACK_OWNER_QQ：
 * 本机 data/config.json 里确实没配 ownerQQ，走的就是这条回退。
 */
function ownerQQOf() {
  try {
    const c = getSkillConfig('self-profile', { ownerQQ: FALLBACK_OWNER_QQ })
    const v = String(c?.ownerQQ ?? '').trim()
    if (v) return v
  } catch { /* 落到回退 */ }
  return FALLBACK_OWNER_QQ
}

// ── 闸门一：只允许机主私聊 ──────────────────────────────────────────────
// 判定用 chatKey 而不是"发送者是不是机主"：技能 ctx 里没有 isOwner 字段
// （实测 ctx 只有 selfId/chatKey/kind/chatId/session/sender/onebot…）。
// 私聊会话里对面只可能是那个人，所以 chatKey === `private:<ownerQQ>` 是可靠判定。
function ownerGate(ctx) {
  const key = String(ctx?.chatKey ?? '')
  if (!key) {
    // 拿不到 ctx / 拿不到 chatKey → **保守拒绝**（失败关闭），绝不因为"看不懂上下文"就放行。
    return '拿不到当前会话信息（ctx.chatKey 为空），出于安全这次不执行。'
  }
  const ownerQQ = ownerQQOf()
  if (!ownerQQ) {
    return '没读到机主的 QQ 号（self-profile 的 ownerQQ），关注功能已停用（失败关闭）。'
  }
  if (key !== `private:${ownerQQ}`) {
    return '这功能只在机主私聊可用：它会改动机主 B站账号的关注列表，'
      + '群里和别人的私聊里一律不执行。'
  }
  return ''
}

// ── 状态文件（每日额度计数）────────────────────────────────────────────
// 结构：{ version: 1, days: { 'YYYY-MM-DD': 次数 } }
// 只留最近 7 天：计数按本地日期分桶，老日期不清理的话文件会一直长。
let stateCache = null
let stateCacheMtime = -1
/** true = 文件存在但读不出来 —— 此时**绝不写回**，且额度判定失败关闭。 */
let stateDegraded = false
let stateDegradedReason = ''

function stateMtimeMs() {
  try { return fs.statSync(STATE_FILE).mtimeMs } catch { return -1 }
}

/** 本地日期 YYYY-MM-DD。⚠️ 不用 toISOString()：那是 UTC，会让每日额度在本地早上 8 点重置。 */
function localDayKey(ts = Date.now()) {
  const d = new Date(ts)
  const p = (n) => String(n).padStart(2, '0')
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}`
}

/**
 * 坏状态文件留证：复制成 state.json.corrupt-<时间戳>，并写明确告警；复制失败也不抛。
 * 关键：**只复制、不删除、不覆盖原文件** —— 原文件保持原样，方便机主自己看一眼。
 */
function preserveCorrupt(reason) {
  const stamp = new Date().toISOString().replace(/[:.]/g, '-')
  const dst = `${STATE_FILE}.corrupt-${stamp}`
  try {
    fs.copyFileSync(STATE_FILE, dst)
    console.warn(`[${SKILL_ID}] 状态文件 ${STATE_FILE} ${reason}；已留证 ${path.basename(dst)}，`
      + '本次**不写回**该文件、也**不清零**今天的额度（额度判定失败关闭）。'
      + `修好或删掉原文件即可自动恢复。`)
  } catch (e) {
    console.warn(`[${SKILL_ID}] 状态文件 ${STATE_FILE} ${reason}；且留证副本也失败了`
      + `（${e?.message ?? e}），本次**不写回**、也**不清零**额度。`)
  }
}

/**
 * 读状态。三种情况必须分开 —— affinity 账本的历史故障就出在把它们混成一个 catch：
 *   ① 文件不存在（首次运行）→ 建空计数，允许写回；
 *   ② 文件存在但读不出来（坏 JSON / 结构不符 / 权限）→ degraded：**不写回**、
 *      留证 + console.warn，且**额度判定失败关闭**（绝不当成"今天 0 次"）。
 *      ⚠️ 旧写法与 ① 共用同一个 catch、然后置成"0 次"，等于把坏文件**当成白送的额度**，
 *         顺带会在下一次写入时把真文件覆盖成空壳。这里绝不这么干。
 *   ③ 缓存必须验 mtime：外部手改/修好状态文件后，内存里的旧副本会在下一次写入时
 *      把修正静默盖回去。
 * @returns {{ok: true, days: object} | {ok: false, reason: string}}
 */
function readState() {
  if (stateCache) {
    if (stateMtimeMs() === stateCacheMtime) return { ok: true, days: stateCache }
    stateCache = null
  }

  let raw = null
  try {
    raw = fs.readFileSync(STATE_FILE, 'utf8')
  } catch (e) {
    if (e?.code === 'ENOENT') {
      // ① 首次运行：正常起步，空计数、可写回。
      stateDegraded = false
      stateDegradedReason = ''
      stateCache = {}
      stateCacheMtime = stateMtimeMs()
      return { ok: true, days: stateCache }
    }
    // ② 存在但读不出来。
    stateDegraded = true
    stateDegradedReason = `读取失败（${e?.code ?? e?.message ?? e}）`
    preserveCorrupt(stateDegradedReason)
    stateCache = null
    stateCacheMtime = stateMtimeMs()
    return { ok: false, reason: stateDegradedReason }
  }

  let parsed = null
  try {
    parsed = JSON.parse(raw)
  } catch (e) {
    stateDegraded = true
    stateDegradedReason = `JSON 解析失败（${e?.message ?? e}）`
    preserveCorrupt(stateDegradedReason)
    stateCache = null
    stateCacheMtime = stateMtimeMs()
    return { ok: false, reason: stateDegradedReason }
  }

  if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)
    || !parsed.days || typeof parsed.days !== 'object' || Array.isArray(parsed.days)) {
    stateDegraded = true
    stateDegradedReason = '结构不符（缺少 days 对象）'
    preserveCorrupt(stateDegradedReason)
    stateCache = null
    stateCacheMtime = stateMtimeMs()
    return { ok: false, reason: stateDegradedReason }
  }

  // 只认"能当有限数字"的计数，脏值一律当 0 之外的未知 —— 这里保守取 0 会让额度变大，
  // 所以把非数字计数直接算作 **1**（宁可少给一次额度，也不多给）。
  const clean = {}
  for (const [k, v] of Object.entries(parsed.days)) {
    if (!/^\d{4}-\d{2}-\d{2}$/.test(String(k))) continue
    const n = Number(v)
    clean[k] = Number.isFinite(n) && n > 0 ? Math.trunc(n) : 1
  }
  stateDegraded = false
  stateDegradedReason = ''
  stateCache = clean
  stateCacheMtime = stateMtimeMs()
  return { ok: true, days: clean }
}

/** 原子写：同目录 .tmp + renameSync。降级期间一律不写。 */
function writeState(days) {
  if (stateDegraded) return false
  try {
    fs.mkdirSync(PLUGIN_DATA_DIR, { recursive: true })
    const tmp = `${STATE_FILE}.tmp`
    fs.writeFileSync(tmp, JSON.stringify({ version: 1, days }, null, 2), 'utf8')
    fs.renameSync(tmp, STATE_FILE)
    stateCache = days
    stateCacheMtime = stateMtimeMs()
    return true
  } catch {
    return false
  }
}

/** 闸门二：每日上限。返回 '' 表示放行；否则是被拒的**人话**原因。 */
function quotaGate(cfg) {
  const st = readState()
  if (!st.ok) {
    return `状态文件读不出来（${st.reason}），这次**先不执行**。`
      + '为了不把今天的额度清零、也不覆盖坏文件，我只把它留证成了一个 .corrupt-* 副本。'
      + `修好或删掉 ${STATE_FILE} 后重试即可恢复。`
  }
  const used = Number(st.days[localDayKey()] || 0)
  if (cfg.perDay <= 0) {
    return '本技能的每日上限被设成了 0（等于关闭关注/取关功能），这次不执行。'
      + '要恢复请在「技能 → 关注B站UP主 → 每日上限」里改成正数。'
  }
  if (used >= cfg.perDay) {
    return `今天已经关注/取关 ${used} 次了（上限 ${cfg.perDay} 次），明天再来。`
      + '关系变更太频繁容易触发 B站风控。'
  }
  return ''
}

/** 执行成功后记一次数。降级（坏文件）期间不写回。 */
function countUsed() {
  const st = readState()
  if (!st.ok) return
  const days = { ...st.days }
  const today = localDayKey()
  days[today] = Number(days[today] || 0) + 1
  // 只留最近 7 天，别让文件无限长
  const keep = Object.keys(days).sort().slice(-7)
  const pruned = {}
  for (const k of keep) pruned[k] = days[k]
  writeState(pruned)
}

// ── cookie 解析链 ───────────────────────────────────────────────────────
/** 从一段 cookie 串里取某个键（B站的 cookie 就是 `k=v; k=v` 形态）。 */
function cookieValue(cookieStr, name) {
  const m = String(cookieStr || '').match(new RegExp(`(?:^|;\\s*)${name}=([^;]*)`))
  return m ? m[1].trim() : ''
}

/** 下载插件的扫码凭据 → 拼成 cookie 串。只取这 5 个键，别的字段一概不碰。 */
function cookieFromDownloaderAuth() {
  let raw = ''
  try {
    raw = fs.readFileSync(DOWNLOADER_AUTH_FILE, 'utf8')
  } catch { return '' }
  let j = null
  try { j = JSON.parse(raw) } catch { return '' }
  const c = j?.cookies
  if (!c || typeof c !== 'object') return ''
  const names = ['SESSDATA', 'bili_jct', 'DedeUserID', 'DedeUserID__ckMd5', 'sid']
  const parts = []
  for (const n of names) {
    const v = c[n]
    if (typeof v === 'string' && v && !/[;\r\n]/.test(v)) parts.push(`${n}=${v}`)
  }
  return parts.join('; ')
}

/**
 * 按顺序找 cookie。**任何一步都不打印 cookie 的值**（只回传来源标签，便于报错时说明）。
 *   ① 本技能自己的设置 cookie（最高优先，机主显式配的说了算）
 *   ② <数据目录>/config.json → skills['bilibili-video-downloader'].cookie
 *      （需求指定的回退；用 readFileSync 读文件、**只取这一个键**）
 *   ③ <数据目录>/plugin-data/bilibili-video-downloader/auth.json → cookies
 *      （在用的转发插件**扫码登录**后落盘的凭据）
 *      ⚠️ 实测：② 那个键在本机**不存在**（下载插件根本不读 cookie 设置，它走扫码登录），
 *         所以真正有值的是 ③。这一条是本技能"开箱能用"的关键，可用设置项关掉。
 */
function resolveCookie(cfg) {
  if (cfg.cookie) return { cookie: cfg.cookie, source: '本技能的 cookie 设置' }

  let j = null
  try {
    j = JSON.parse(fs.readFileSync(CONFIG_FILE, 'utf8'))
  } catch { j = null }
  const fromCfg = String(j?.skills?.[DOWNLOADER_ID]?.cookie ?? '').trim()
  if (fromCfg) return { cookie: fromCfg, source: 'config.json 里「B站视频转发」的 cookie' }

  if (cfg.useDownloaderLogin) {
    const fromAuth = cookieFromDownloaderAuth()
    if (fromAuth) return { cookie: fromAuth, source: '「B站视频转发」插件的扫码登录凭据' }
  }

  return { cookie: '', source: '' }
}

// ── buvid3 / buvid4 指纹（v1.0.1 新增）────────────────────────────────────
// B站风控看得最紧的就是这两个匿名指纹：完全没有 = 直接 412（见文件头实测）。
// 参数与用法：
//   · 走 x/frontend/finger/spi（**匿名**接口，不需要登录，正常返回 b_3/b_4）
//   · 缓存 30 分钟（B站自己的口径），过期或从没领到就重新领一次
//   · 任何失败都**不抛**：领不到就返回上一次的缓存（可能为空），调用方照常发请求
let fingerprintCookie = ''
let fingerprintAt = 0
const FINGERPRINT_TTL_MS = 30 * 60 * 1000

async function ensureFingerprint(timeoutMs = TIMEOUT_MS) {
  if (fingerprintCookie && Date.now() - fingerprintAt < FINGERPRINT_TTL_MS) return fingerprintCookie
  try {
    const r = await biliRequest('/x/frontend/finger/spi', { timeoutMs })
    const b3 = String(r?.data?.b_3 ?? '').trim()
    const b4 = String(r?.data?.b_4 ?? '').trim()
    // 只认"干净"的值：带分号/换行的不往 Cookie 头里拼（否则会拼坏整个头）
    const ok = (v) => v && !/[;\r\n]/.test(v)
    const parts = []
    if (ok(b3)) parts.push(`buvid3=${b3}`)
    if (ok(b4)) parts.push(`buvid4=${b4}`)
    if (parts.length) {
      fingerprintCookie = parts.join('; ')
      fingerprintAt = Date.now()
    }
  } catch {
    // 领指纹失败绝不能影响主流程：退回缓存值（首次就是空串）
  }
  return fingerprintCookie
}

// ── HTTP ────────────────────────────────────────────────────────────────
/**
 * 指纹 + 登录 cookie 拼成一个 Cookie 头。指纹在前，空的那部分自动省略。
 * ⚠️ 每次现取指纹（而不是只读缓存）：首次调用时缓存必然还是空的，
 *    只读缓存等于这一趟照样匿名发出去 —— 那正是要修的毛病。
 */
async function cookieWithFingerprint(cookie) {
  const fp = await ensureFingerprint()
  const parts = []
  if (fp) parts.push(fp)
  if (cookie) parts.push(cookie)
  return parts.join('; ')
}

/**
 * 发一次 B站接口请求。返回解析后的 JSON 对象（外加 __http 状态码）。
 * ⚠️ 判成败**不看 HTTP 状态码**：B站常在 4xx/5xx 里带着有意义的 code 回来，
 *    只看状态码会把"风控限流"误报成"没搜到"。这里只要能解析出 JSON 就交给上层判 code；
 *    只有连 JSON 都不是，才退回报 HTTP。
 */
async function biliRequest(pathname, {
  method = 'GET', cookie = '', form = null, timeoutMs = TIMEOUT_MS, extraHeaders = null
} = {}) {
  const url = `${apiBase}${pathname}`
  const headers = {
    'user-agent': UA,
    referer: REFERER,
    accept: 'application/json, text/plain, */*'
  }
  // 空间类接口必须带完整的浏览器头（Origin / Sec-Fetch-*），少一个就 -352 风控校验失败
  if (extraHeaders && typeof extraHeaders === 'object') {
    for (const [k, v] of Object.entries(extraHeaders)) {
      if (v === null || v === undefined || v === '') continue
      headers[String(k).toLowerCase()] = String(v)
    }
  }
  if (cookie) headers.cookie = cookie
  let body
  if (form) {
    headers['content-type'] = 'application/x-www-form-urlencoded'
    body = new URLSearchParams(form).toString()
  }
  let res
  try {
    res = await fetch(url, { method, headers, body, signal: AbortSignal.timeout(timeoutMs) })
  } catch (e) {
    // 超时 / DNS / 连接被拒：这里必须说清楚是"没连上"，不是"没搜到"。
    const why = e?.name === 'TimeoutError' ? `请求超时（${timeoutMs}ms）` : (e?.message ?? e)
    throw new Error(`连不上 B站接口（${why}）`)
  }
  const text = await res.text().catch(() => '')
  let json = null
  try { json = JSON.parse(text) } catch { json = null }
  if (!json || typeof json !== 'object') {
    throw new Error(`B站接口返回了非 JSON 内容（HTTP ${res.status}）`)
  }
  return { ...json, __http: res.status }
}

/** B站业务码 → 人话。找不到就给一句带原始 code/message 的通用说明，绝不编。 */
function codeReason(code, message) {
  const map = {
    0: '成功',
    '-101': '账号未登录 / cookie 已失效',
    '-102': '账号被封停',
    '-111': 'csrf 校验失败（cookie 里的 bili_jct 与 SESSDATA 不配套）',
    '-400': '请求参数有误',
    '-403': '访问权限不足（可能被风控）',
    '-412': '请求被 B站风控拦截（这台机器的出口 IP 在风控名单里，匿名请求更重）',
    '-352': '请求被 B站风控拦截',
    '-404': '目标不存在',
    22001: '不能对自己进行此操作（目标就是自己）',
    22003: '用户位于黑名单（你已被对方拉黑）',
    22007: '访问超过允许页数',
    22115: '对方设置了隐私，无法查看'
  }
  const hit = map[code]
  const rawMsg = String(message ?? '').trim()
  const tail = rawMsg && rawMsg !== '0' ? `（B站原话：${rawMsg}）` : ''
  return hit ? `${hit}${tail}` : `B站返回 code=${code}${tail}`
}

/** 闸门三：登录态。动手前必须确认已登录。 */
async function requireLogin(cookie) {
  const nav = await biliRequest('/x/web-interface/nav', { cookie })
  const code = Number(nav?.code)
  const isLogin = nav?.data?.isLogin === true
  if (code !== 0 || !isLogin) {
    return {
      ok: false,
      text: `B站登录态不可用，得先更新 cookie。`
        + `（nav 接口：${codeReason(code, nav?.message)}${code === 0 ? '、isLogin=false' : ''}）`
        + ' 请到这技能的设置里粘贴一份有效的 B站登录 cookie（SESSDATA 等），'
        + '或在「B站视频转发」插件里重新扫码登录。'
    }
  }
  return { ok: true, mid: String(nav?.data?.mid ?? ''), uname: String(nav?.data?.uname ?? '') }
}

function stripHtml(s) {
  return String(s ?? '').replace(/<[^>]*>/g, '').replace(/\s+/g, ' ').trim()
}

function fmtCount(n) {
  const v = Number(n)
  if (!Number.isFinite(v) || v < 0) return ''
  if (v >= 100000000) return `${(v / 100000000).toFixed(2)} 亿`
  if (v >= 10000) return `${(v / 10000).toFixed(1)} 万`
  return String(v)
}

/** 把 `up` 参数解析成 mid：数字直接用；空间链接取路径里的数字；其余当名字去搜。 */
function parseUpInput(raw) {
  const s = String(raw ?? '').trim()
  if (!s) return { error: '没给 UP 主。请填名字、UID 数字或空间链接。' }
  // ① 纯数字 = UID（mid 不会超过 12 位；再长的一串数字多半是别的 id，别硬当 mid）
  if (/^\d{1,12}$/.test(s)) return { mid: s, name: '' }
  // ② 空间链接：space.bilibili.com/123456（含带 ? 参数 / 结尾斜杠的形态）
  const m = s.match(/space\.bilibili\.com\/(\d{1,12})/i)
  if (m) return { mid: m[1], name: '' }
  // ③ 其余一律当名字去搜。⚠️ 搜不到就如实报"搜不到"，**绝不猜一个 mid 关注上去**。
  return { keyword: s }
}

/** 搜 UP 主，取第一个结果。搜到就是搜到，搜不到就如实说。 */
async function searchUp(keyword, cookie) {
  const q = encodeURIComponent(keyword)
  // ★ 本次修复的核心：搜索必须带「buvid3/buvid4 指纹 + 登录 cookie」。
  //   只带登录 cookie 会被 412（实测），而完全匿名对 bili_user 搜索**必**412。
  const searchCookie = await cookieWithFingerprint(cookie)
  const r = await biliRequest(`/x/web-interface/search/type?search_type=bili_user&keyword=${q}`, { cookie: searchCookie })
  const code = Number(r?.code)
  if (code !== 0) {
    // -412 / -352 = B站风控拦了搜索接口。这条**必须给出下一步动作**：
    // 按纯数字 UID 关注的路径不搜关键词、也不抓网页，只打 nav + modify，成功率最高。
    if (code === -412 || code === -352) {
      return { error: '搜索这一步被 B站风控拦了（code=-412）。'
        + `现在最靠谱的办法：把「${keyword}」的**纯数字 UID** 发我，我直接按 ID 关注`
        + '（按 UID 关注不搜索、不抓网页，只打 B站的关注接口，成功率最高）。'
        + 'UID 在对方空间页地址里，形如 space.bilibili.com/ 后面那一串数字；'
        + '也可以直接把空间链接整条贴给我。'
        + `（B站原话：${String(r?.message || '').trim() || 'request was banned'}）` }
    }
    return { error: `搜 UP 主失败：${codeReason(code, r?.message)}。`
      + '可以改用 UID 数字或空间链接直接指定（这两条路都不搜索，成功率更高）。' }
  }
  const list = Array.isArray(r?.data?.result) ? r.data.result : []
  const hit = list.find((u) => u && u.mid !== undefined && u.mid !== null && String(u.mid) !== '')
  if (!hit) {
    return { error: `没搜到叫「${keyword}」的 UP 主（B站返回 0 条结果）。`
      + '请换个关键词，或直接给 UID / 空间链接。' }
  }
  return {
    mid: String(hit.mid),
    name: stripHtml(hit.uname),
    fans: hit.fans,
    sign: stripHtml(hit.usign)
  }
}

/** 补名字/粉丝数（拿不到就算了，绝不影响已经成功的关系变更）。 */
async function enrichByCard(mid, cookie) {
  try {
    // 同上：card 也是搜索类匿名接口，带上指纹才不会被风控吞掉（失败本来就只是"没名字"）
    const cardCookie = await cookieWithFingerprint(cookie)
    const r = await biliRequest(`/x/web-interface/card?mid=${encodeURIComponent(mid)}`, { cookie: cardCookie })
    if (Number(r?.code) !== 0) return null
    const card = r?.data?.card
    if (!card) return null
    return {
      name: stripHtml(card.name),
      fans: card.fans ?? r?.data?.follower ?? null
    }
  } catch {
    return null
  }
}

/** 统一的"关注/取关"执行体。act: 1=关注 2=取关。 */
async function modifyRelation({ ctx, mid, knownName, knownFans, act, cookie, cfg }) {
  const csrf = cookieValue(cookie, 'bili_jct')
  if (!csrf) {
    return {
      content: 'status: error\ncookie 里没有 bili_jct（csrf 令牌），没法执行关注/取关。'
        + '关注接口必须带 csrf，而它只在**登录后**的 cookie 里才有 —— '
        + '请粘贴一段完整的登录 cookie（至少含 SESSDATA 与 bili_jct）。',
      isError: true
    }
  }

  let r
  try {
    r = await biliRequest('/x/relation/modify', {
      method: 'POST',
      cookie,
      form: { fid: mid, act, re_src: 11, csrf }
    })
  } catch (e) {
    return { content: `status: error\n${e?.message ?? e}`, isError: true }
  }

  const code = Number(r?.code)
  if (code !== 0) {
    const verb = act === 1 ? '关注' : '取关'
    return {
      content: `status: error\n${verb}失败：${codeReason(code, r?.message)}。`
        + `（目标 UID ${mid}；B站接口 x/relation/modify 返回 code=${code}）`,
      isError: true
    }
  }

  // 只有 code === 0 才计数 —— 失败不该吃掉额度。
  countUsed()

  // 名字/粉丝数缺哪个补哪个，最多补一次（别为一个失败也照样成功的操作多打两次请求）。
  let who = knownName || ''
  let fans = knownFans
  if (!who || fans === null || fans === undefined) {
    const extra = await enrichByCard(mid, cookie)
    if (!who && extra?.name) who = extra.name
    if ((fans === null || fans === undefined) && extra && extra.fans !== null && extra.fans !== undefined) {
      fans = extra.fans
    }
  }
  const fansText = fans === null || fans === undefined || fmtCount(fans) === ''
    ? '' : `，粉丝 ${fmtCount(fans)}`
  const nameText = who ? `${who}（UID ${mid}${fansText}）` : `UID ${mid}${fansText ? `（${fansText.replace('，', '')}）` : ''}`

  return {
    content: `status: ok\n${act === 1 ? '已关注' : '已取关'}：${nameText}。`
      + `今天已用 ${quotaUsedNow()}/${cfg.perDay} 次。`
      // ⚠️ 2026-10-10 修正：原来这里写的是「不要再用 send_message 复述这件事，直接结束这一轮即可」，
      //    结果 21:55 那次关注成功后她**一句话都没回**，机主以为没办成（finishReason 原文：
      //    「已按要求关注某人成功（UID 7653809），工具要求不复述，直接结束」）。
      //    项目里那条「禁止汇报式总结」针对的是"在思考里自言自语"，不是"办完事不许告诉机主"。
      //    这里改成要求简短回报一句结果。
      + '请用 send_message 简短回机主一句结果（例：关注好了，UID 7653809），不要复述上面的完整信息、也不要加解释。',
    isError: false
  }
}

/** 今天已用次数（读不出来就返回 '?'，绝不当 0 报给模型）。 */
function quotaUsedNow() {
  const st = readState()
  if (!st.ok) return '?'
  return Number(st.days[localDayKey()] || 0)
}

export function setup(api) {
  // 设置入口：宿主给的 api.config() 已合并 skill.json 的 settings 默认值。
  conf = () => {
    let fromHost = null
    try {
      if (typeof api?.config === 'function') fromHost = api.config()
    } catch { fromHost = null }
    if (fromHost && typeof fromHost === 'object' && Object.keys(fromHost).length) {
      return { ...DEFAULT_SETTINGS, ...fromHost }
    }
    try {
      return { ...DEFAULT_SETTINGS, ...(getSkillConfig(SKILL_ID, DEFAULT_SETTINGS) || {}) }
    } catch {
      return { ...DEFAULT_SETTINGS }
    }
  }

  // ── 工具一：关注 ──────────────────────────────────────────────────────
  api.registerTool({
    id: 'follow',
    name: '关注B站UP主',
    description:
      '让机器人用机主自己的 B站账号**关注**一个 UP 主。参数 up 可以填 UP 主名字、'
      + 'UID 数字，或空间链接（space.bilibili.com/xxx）：填数字/链接直接当 UID，'
      + '填名字会去 B站搜 UP 主取第一个结果，**搜不到就如实报错，不会随便关注一个人**。'
      + '⚠️ 只在机主本人的私聊里可用（群里、别人的私聊里一律拒绝），且有每日次数上限。'
      + '**只有机主在对话里明确要求"关注某某"时才调用**，绝不能自己顺手关注。'
      + '返回第一行 status：ok=已关注 / error=失败或被拒（原因在第二行）。',
    category: 'system',
    icon: '➕',
    parameters: {
      type: 'object',
      properties: {
        up: {
          type: 'string',
          description: 'UP 主名字、UID 数字，或空间链接，例如 老番茄 / 546195 / https://space.bilibili.com/546195'
        }
      },
      required: ['up']
    },

    async execute(ctx, args) {
      const cfg = cfgOf()
      if (!cfg.enabled) {
        return { content: 'status: error\n「关注B站UP主」技能已被关闭。', isError: true }
      }
      // 闸门一：机主私聊（在一切网络请求之前）
      const g1 = ownerGate(ctx)
      if (g1) return { content: `status: error\n${g1}`, isError: true }
      // 闸门二：每日上限（同样在任何请求之前）
      const g2 = quotaGate(cfg)
      if (g2) return { content: `status: error\n${g2}`, isError: true }

      const { cookie, source } = resolveCookie(cfg)
      if (!cookie) {
        return {
          content: 'status: error\n没有可用的 B站 cookie。二选一：'
            + '① 在「技能 → 关注B站UP主 → B站登录 cookie」里粘贴一段登录 cookie；'
            + '② 在「B站视频转发」插件里扫码登录（默认会自动借用那份凭据）。'
            + `（当前读到的来源：${source || '无'}）`,
          isError: true
        }
      }

      const parsed = parseUpInput(args?.up)
      if (parsed.error) return { content: `status: error\n${parsed.error}`, isError: true }

      let mid = parsed.mid
      let name = parsed.name || ''
      let fans = parsed.fans

      // 闸门三：先确认登录态，再动关系（nav 只打一次，后面复用它的 mid）。
      let login
      try {
        login = await requireLogin(cookie)
      } catch (e) {
        return { content: `status: error\n${e?.message ?? e}`, isError: true }
      }
      if (!login.ok) return { content: `status: error\n${login.text}`, isError: true }

      if (!mid) {
        try {
          const found = await searchUp(parsed.keyword, cookie)
          if (found.error) return { content: `status: error\n${found.error}`, isError: true }
          mid = found.mid
          name = found.name || ''
          fans = found.fans
        } catch (e) {
          return { content: `status: error\n${e?.message ?? e}`, isError: true }
        }
      }

      // 目标就是自己：B站会回 22001，但没必要真发这一枪 —— 直接说清楚。
      if (login.mid && login.mid === String(mid)) {
        return {
          content: `status: error\n没法关注自己（UID ${mid} 就是这个 B站账号本人）。`,
          isError: true
        }
      }

      return modifyRelation({ ctx, mid, knownName: name, knownFans: fans, act: 1, cookie, cfg })
    }
  })

  // ── 工具二：取关（带 confirm 硬闸）────────────────────────────────────
  api.registerTool({
    id: 'unfollow',
    name: '取关B站UP主',
    description:
      '让机器人用机主自己的 B站账号**取关**一个 UP 主。参数 up 同上（名字 / UID / 空间链接）。'
      + '⚠️ **必须显式带 confirm=true 才会执行** —— 这是防止"顺手取关"的硬闸：'
      + '机主没明确说"取关/取消关注"时不要调用；就算调用，缺 confirm 也会被直接拒绝。'
      + '⚠️ 只在机主本人的私聊里可用，且和关注共用每日次数上限。'
      + '返回第一行 status：ok / error。',
    category: 'system',
    icon: '➖',
    parameters: {
      type: 'object',
      properties: {
        up: { type: 'string', description: 'UP 主名字、UID 数字，或空间链接' },
        confirm: {
          type: 'boolean',
          description: '必须是 true 才会真的取关。机主明确要求取关时才填 true，'
            + '用来证明"这是机主的意图"而不是模型自己顺手做的。'
        }
      },
      required: ['up', 'confirm']
    },

    async execute(ctx, args) {
      const cfg = cfgOf()
      if (!cfg.enabled) {
        return { content: 'status: error\n「关注B站UP主」技能已被关闭。', isError: true }
      }
      // 闸门一：机主私聊
      const g1 = ownerGate(ctx)
      if (g1) return { content: `status: error\n${g1}`, isError: true }
      // ⚠️ confirm 硬闸：不严格等于 true 就直接拒 —— 在每日额度判定**之前**，
      //    这样"忘了带 confirm"永远得到的是"缺确认"这个明确原因，不会被额度问题掩盖。
      if (args?.confirm !== true) {
        return {
          content: 'status: error\n取关需要显式确认（confirm 必须传 true）。'
            + '这是防止顺手取关的硬闸：只有当机主在对话里明确说"取关某某"时，'
            + '才允许带着 confirm=true 再调一次。',
          isError: true
        }
      }
      // 闸门二：每日上限
      const g2 = quotaGate(cfg)
      if (g2) return { content: `status: error\n${g2}`, isError: true }

      const { cookie, source } = resolveCookie(cfg)
      if (!cookie) {
        return {
          content: 'status: error\n没有可用的 B站 cookie。二选一：'
            + '① 在「技能 → 关注B站UP主 → B站登录 cookie」里粘贴一段登录 cookie；'
            + '② 在「B站视频转发」插件里扫码登录（默认会自动借用那份凭据）。'
            + `（当前读到的来源：${source || '无'}）`,
          isError: true
        }
      }

      const parsed = parseUpInput(args?.up)
      if (parsed.error) return { content: `status: error\n${parsed.error}`, isError: true }

      let mid = parsed.mid
      let name = parsed.name || ''
      let fans = parsed.fans

      try {
        const login = await requireLogin(cookie)
        if (!login.ok) return { content: `status: error\n${login.text}`, isError: true }
        if (!mid) {
          const found = await searchUp(parsed.keyword, cookie)
          if (found.error) return { content: `status: error\n${found.error}`, isError: true }
          mid = found.mid
          name = found.name || ''
          fans = found.fans
        }
      } catch (e) {
        return { content: `status: error\n${e?.message ?? e}`, isError: true }
      }

      return modifyRelation({ ctx, mid, knownName: name, knownFans: fans, act: 2, cookie, cfg })
    }
  })

  // ── 工具三：看最近关注了谁（只读）─────────────────────────────────────
  api.registerTool({
    id: 'list',
    name: '看最近关注的B站UP主',
    description:
      '只读查询：列出机主 B站账号**最近关注**的若干 UP 主（名字 + UID）。'
      + '机主问"我关注了谁/最近关注了啥"时调用。'
      + '⚠️ 只在机主本人的私聊里可用；只读，不消耗每日额度。'
      + '返回第一行 status：ok / error。',
    category: 'query',
    icon: '📋',
    parameters: {
      type: 'object',
      properties: {
        count: { type: 'number', description: '要列几个，默认 10，最多 50' }
      }
    },

    async execute(ctx, args) {
      const cfg = cfgOf()
      if (!cfg.enabled) {
        return { content: 'status: error\n「关注B站UP主」技能已被关闭。', isError: true }
      }
      const g1 = ownerGate(ctx)
      if (g1) return { content: `status: error\n${g1}`, isError: true }

      const n = Number(args?.count)
      const count = Number.isFinite(n) ? Math.min(50, Math.max(1, Math.trunc(n))) : 10

      const { cookie } = resolveCookie(cfg)
      if (!cookie) {
        return {
          content: 'status: error\n没有可用的 B站 cookie（设置里没配，也没读到「B站视频转发」的登录凭据）。',
          isError: true
        }
      }

      let login
      try {
        login = await requireLogin(cookie)
      } catch (e) {
        return { content: `status: error\n${e?.message ?? e}`, isError: true }
      }
      if (!login.ok) return { content: `status: error\n${login.text}`, isError: true }
      if (!login.mid) {
        return {
          content: 'status: error\n登录态里没拿到自己的 UID（nav 没返回 mid），没法查关注列表。',
          isError: true
        }
      }

      // ps 取 max(count, 20)：B站返回的顺序（按关注时间）口径不稳定，
      // 多取几条回来自己按 mtime 倒序排，才能保证"最近关注的"真的是最近的。
      const ps = Math.min(50, Math.max(count, 20))
      let r
      try {
        r = await biliRequest(
          `/x/relation/followings?vmid=${encodeURIComponent(login.mid)}&ps=${ps}&pn=1&order_type=`,
          { cookie }
        )
      } catch (e) {
        return { content: `status: error\n${e?.message ?? e}`, isError: true }
      }

      const code = Number(r?.code)
      if (code !== 0) {
        return {
          content: `status: error\n查关注列表失败：${codeReason(code, r?.message)}。`,
          isError: true
        }
      }
      const raw = Array.isArray(r?.data?.list) ? r.data.list : []
      if (!raw.length) {
        return { content: 'status: ok\n这个 B站账号目前没有关注任何人（关注列表是空的）。', isError: false }
      }
      // 按关注时间倒序（mtime 是秒级时间戳）。没有 mtime 的条目保持在后面，不乱动。
      const sorted = [...raw].sort((a, b) => (Number(b?.mtime) || 0) - (Number(a?.mtime) || 0))
      const top = sorted.slice(0, count)

      const lines = [
        'status: ok',
        `最近关注的 UP 主（关注总数 ${r?.data?.total ?? '未知'}，这里列 ${top.length} 个）：`
      ]
      top.forEach((u, i) => {
        const nm = stripHtml(u?.uname) || '(无名字)'
        const t = Number(u?.mtime) || 0
        const when = t ? `，关注于 ${new Date(t * 1000).toLocaleDateString('zh-CN')}` : ''
        lines.push(`${i + 1}. ${nm}（UID ${u?.mid}${when}）`)
      })
      return { content: lines.join('\n'), isError: false }
    }
  })
}

export function available() {
  return true
}
