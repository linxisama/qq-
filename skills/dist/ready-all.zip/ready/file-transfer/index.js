// 文件传输技能：把**专属文件夹**下、**当前会话自己的分区**里的文件上传发送到当前会话。
//
// 存储布局（这些规则全部在本技能内实现，生产者绕不过去）：
//   <allowedDir>/
//     .index.json              索引（体积 / 创建时间 / 已发送时间），原子写
//     private_10001/           每个私聊一个分区
//     group_123456789/         每个群一个分区
//     <根目录文件>              管理员专属「公共区」（手工放进去的文件）
//
// 安全模型（四层）：
//   1. 工具参数只收**文件名**，不收路径 —— 模型无法表达"发任意文件"
//   2. 只在本会话自己的分区里解析；跨窗口必须管理员显式传 chat
//   3. path.relative 确认落地路径仍在分区内（挡 ../ 与绝对路径）
//   4. realpath 双侧解析后再比对（挡符号链接逃逸）
//
// 命名规范（防覆盖）：净化非法字符 → 同名自动加序号 -2/-3… → 兜底加时间戳，
// 写入用 COPYFILE_EXCL 双保险，绝不覆盖既有文件。
//
// 实现说明：
//   · 上传走 ctx.onebot.call('upload_private_file' | 'upload_group_file')。
//     onebot.call 原样透传无 action 白名单；upload_ 前缀已命中 SLOW_ACTION，
//     自动享受 90 秒宽容超时（onebot.js:58）。
//   · **有意不走 sender 管道**：SendQueue 没有文件上传方法，而其内部（chain/限频/去重）
//     是真私有（# 前缀），技能拿不到。文件发送是低频操作，这里自建限频与去重，
//     留档用 ctx.store.appendSelf —— 与 sender 的留档约定保持同一格式。
//   · 对外提供两个能力：
//       file.stage          生产者入库（生产方技能把产物放进当前会话分区）
//       file.storage-admin  管理接口（核心路由做薄适配，给网页端列表/删除/清理）

import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const SKILL_DIR = path.dirname(fileURLToPath(import.meta.url));
const APP_ROOT = path.resolve(SKILL_DIR, '..', '..');
// 默认待发区放 data/ 下：data/ 在 .gitignore 里，待发文件不会进版本库。
const DEFAULT_DIR = path.join(APP_ROOT, 'data', 'outbound-files');
const INDEX_FILE = '.index.json';
const ROOT_PARTITION = '_root_';   // 根目录遗留文件 = 管理员专属公共区

let cfg = () => ({});
let log = () => {};
const minuteHits = new Map();   // chatKey -> number[]（本分钟内发送时间戳）
const lastSent = new Map();     // `${chatKey}:${name}` -> ts（去重窗口）

function settings() {
  try { return cfg() || {}; } catch { return {}; }
}
function allowedDir() {
  const configured = String(settings().allowedDir || '').trim();
  return configured ? path.resolve(configured) : DEFAULT_DIR;
}

// ── 分区 ──────────────────────────────────────────────────────────────
// 分区键 private_<QQ> / group_<群号>：与项目 store.js / memory.js 的会话目录命名一致
// （Windows 不允许冒号，所以不能用 chatKey 原样）。
function partitionOf(chatKey) {
  const [kind, id] = String(chatKey ?? '').split(':');
  if ((kind !== 'private' && kind !== 'group') || !/^\d+$/.test(String(id ?? ''))) return null;
  return `${kind}_${id}`;
}
function partitionDir(partition) {
  return partition === ROOT_PARTITION ? allowedDir() : path.join(allowedDir(), partition);
}
function isAdmin(ctx) {
  const owner = String(settings().ownerQQ || '').trim();
  if (!owner) return false;
  // 私聊：chatId 就是对方 QQ，直接比对
  if (ctx?.kind === 'private' && String(ctx.chatId ?? '') === owner) return true;
  // 群聊：chatId 是群号，管理员身份要看**触发消息的发送者**（与项目
  // message.owner-check 同一口径：触发批里有没有主人在说话）
  const trigger = ctx?.session?.trigger;
  if (Array.isArray(trigger)) {
    return trigger.some((m) => String(m?.senderId ?? '') === owner);
  }
  return false;
}

// ── 命名规范（防覆盖）─────────────────────────────────────────────────
/** 净化文件名：去路径分隔符与控制字符、折叠空白、去首部点（防隐藏文件）、主名截断 120 字符 */
function sanitizeName(raw) {
  let s = String(raw ?? '').replace(/[\\/:*?"<>|\u0000-\u001f]/g, '_').trim();
  s = s.replace(/\s+/g, ' ').replace(/^\.+/, '');
  if (!s) s = 'file';
  const ext = path.extname(s).slice(0, 20);
  const stem = (ext ? s.slice(0, -ext.length) : s).slice(0, 120) || 'file';
  return stem + ext;
}
/** 分区内取一个不冲突的名字：x.pdf → x-2.pdf → … → x-HHmmss.pdf → x-<epoch>.pdf */
function uniqueName(dir, base) {
  const ext = path.extname(base);
  const stem = ext ? base.slice(0, -ext.length) : base;
  const taken = (n) => fs.existsSync(path.join(dir, n));
  if (!taken(base)) return base;
  for (let i = 2; i <= 50; i++) {
    const n = `${stem}-${i}${ext}`;
    if (!taken(n)) return n;
  }
  const p = (x) => String(x).padStart(2, '0');
  const d = new Date();
  const stamp = `${p(d.getHours())}${p(d.getMinutes())}${p(d.getSeconds())}`;
  if (!taken(`${stem}-${stamp}${ext}`)) return `${stem}-${stamp}${ext}`;
  return `${stem}-${Date.now()}${ext}`;
}

// ── 索引（体积 / 创建时间 / 已发送时间）───────────────────────────────
function indexPath() { return path.join(allowedDir(), INDEX_FILE); }
function loadIndex() {
  try {
    const raw = JSON.parse(fs.readFileSync(indexPath(), 'utf8'));
    const files = (raw && typeof raw.files === 'object' && raw.files) || {};
    return { version: 1, files };
  } catch {
    return { version: 1, files: {} };
  }
}
function saveIndex(idx) {
  fs.mkdirSync(allowedDir(), { recursive: true });
  const tmp = `${indexPath()}.${process.pid}.tmp`;
  fs.writeFileSync(tmp, JSON.stringify(idx, null, 1), 'utf8');
  fs.renameSync(tmp, indexPath());
}
const keyOf = (partition, name) => `${partition}/${name}`;
function filePathOf(entry) {
  return entry.partition === ROOT_PARTITION
    ? path.join(allowedDir(), entry.name)
    : path.join(allowedDir(), entry.partition, entry.name);
}
function encodeId(key) { return Buffer.from(key, 'utf8').toString('base64url'); }
function decodeId(id) {
  try { return Buffer.from(String(id ?? ''), 'base64url').toString('utf8'); } catch { return ''; }
}

/**
 * 对账磁盘与索引：磁盘上多出的补录（sentAt=null、createdAt=mtime），索引里消失的剔除。
 * 每次 list / stage / send / cleanup 都跑一次，防手工增删文件后记账漂移。
 */
function reconcile() {
  const idx = loadIndex();
  const root = allowedDir();
  const seen = new Set();
  const entries = [];
  let totalBytes = 0;
  let changed = false;

  const addEntry = (partition, name, stat) => {
    const key = keyOf(partition, name);
    const prev = idx.files[key] || {};
    const entry = {
      key, partition, name, size: stat.size,
      createdAt: Number(prev.createdAt) || stat.mtimeMs,
      sentAt: Number(prev.sentAt) || null,
      sendCount: Number(prev.sendCount) || 0
    };
    idx.files[key] = entry;
    seen.add(key);
    entries.push(entry);
    totalBytes += stat.size;
  };

  let dirents = [];
  try { dirents = fs.readdirSync(root, { withFileTypes: true }); } catch { dirents = []; }
  for (const d of dirents) {
    if (d.isFile()) {
      if (d.name === INDEX_FILE || d.name.startsWith('.index.json')) continue;
      try { addEntry(ROOT_PARTITION, d.name, fs.statSync(path.join(root, d.name))); } catch { /* 忽略 */ }
      continue;
    }
    if (!d.isDirectory()) continue;
    let inner = [];
    try { inner = fs.readdirSync(path.join(root, d.name), { withFileTypes: true }); } catch { continue; }
    for (const f of inner) {
      if (!f.isFile()) continue;
      try { addEntry(d.name, f.name, fs.statSync(path.join(root, d.name, f.name))); } catch { /* 忽略 */ }
    }
  }
  for (const k of Object.keys(idx.files)) {
    if (!seen.has(k)) { delete idx.files[k]; changed = true; }
  }
  if (changed || entries.some((e) => !e.size)) saveIndex(idx);
  else saveIndex(idx);   // 索引可能补录了新条目，统一落盘（文件很小）
  return { index: idx, entries, totalBytes };
}

// ── 容量与清理 ────────────────────────────────────────────────────────
function limits() {
  const maxMB = Math.max(1, Number(settings().maxTotalMB) || 500);
  const pct = Math.min(100, Math.max(1, Number(settings().cleanupAtPercent) || 90));
  const maxBytes = maxMB * 1024 * 1024;
  return { maxMB, pct, maxBytes, thresholdBytes: Math.floor(maxBytes * pct / 100) };
}
function usage() {
  const { entries, totalBytes } = reconcile();
  const lim = limits();
  return { entries, totalBytes, ...lim };
}
/**
 * 清理：只删**已发送**文件，按 sentAt 升序，直到低于阈值。
 * 绝不删未发送文件；已发送的删完仍超阈值时返回 warned=true（只告警）。
 */
function cleanup() {
  const u = usage();
  const lim = limits();
  if (u.totalBytes < lim.thresholdBytes) {
    return { removed: 0, freedBytes: 0, warned: false, totalBytes: u.totalBytes, ...lim };
  }
  const sent = u.entries.filter((e) => e.sentAt).sort((a, b) => a.sentAt - b.sentAt);
  const idx = loadIndex();
  let total = u.totalBytes, freed = 0;
  const removedNames = [];
  for (const e of sent) {
    if (total < lim.thresholdBytes) break;
    try {
      fs.unlinkSync(filePathOf(e));
      delete idx.files[e.key];
      removedNames.push(e.name);
      freed += e.size;
      total -= e.size;
    } catch (err) {
      log(`清理失败（跳过）：${e.key} — ${err?.message ?? err}`);
    }
  }
  if (removedNames.length) saveIndex(idx);
  const warned = total >= lim.thresholdBytes;
  if (warned) {
    log(`⚠️ 待发区 ${(total / 1048576).toFixed(1)}MB 仍超过清理阈值 ${(lim.thresholdBytes / 1048576).toFixed(1)}MB，`
      + '但已无「已发送」文件可清理——未发送文件不会被自动删除');
  }
  return { removed: removedNames.length, freedBytes: freed, warned, totalBytes: total, ...lim };
}

// ── 工具输出 ──────────────────────────────────────────────────────────
const ok = (content) => ({ content });
const err = (content) => ({ content: `错误：${content}`, isError: true });

/**
 * 本地路径 → file:/// URI。
 * 与 src/sender.js 的 toFileUri 同逻辑；技能要自包含（市场包只带技能目录），
 * 所以本地实现一份。实测（2026-09-30）：NapCat 只认这个格式去开本地文件，
 * 裸的 Windows 路径会被报"识别URL失败"。
 */
function toFileUri(p) {
  let s = String(p).replace(/\\/g, '/');
  if (!/^file:\/\//i.test(s)) s = 'file:///' + s.replace(/^\/+/, '');
  return encodeURI(s).replace(/#/g, '%23').replace(/\?/g, '%3F');
}

/**
 * 依次尝试多种 file 形态上传。
 *
 * 实测教训（2026-09-30）：NapCat 跑在 Docker 容器里时**读不到宿主机路径**——
 * file:/// 形态会拿到容器内的 ENOENT。所以必须像 sendImage 的图片回退一样：
 * 先试 file:///（协议端同机时零传输成本），失败回退 base64://（容器也通用，
 * 代价是 HTTP body 膨胀 1.33 倍，故设体积阈值）。
 */
async function uploadWithFallback(ctx, action, params, abs, stat) {
  const maxB64 = Math.max(1, Number(settings().base64FallbackMB ?? 20));
  const attempts = [['file:///', toFileUri(abs)]];
  if (stat.size <= maxB64 * 1024 * 1024) {
    attempts.push(['base64://', 'base64://' + fs.readFileSync(abs).toString('base64')]);
  }
  let lastErr = null;
  for (const [label, value] of attempts) {
    try {
      const data = await ctx.onebot.call(action, { ...params, file: value });
      log(`上传成功（形态 ${label}）`);
      return data;
    } catch (e) {
      lastErr = e;
      log(`上传形态 ${label} 失败：${e?.message ?? e}`);
    }
  }
  const hint = attempts.length < 2
    ? `文件超过 base64 回退阈值（${maxB64}MB），只能走文件路径——需协议端能直接读到该路径`
    : '协议端（如 Docker 容器里的 NapCat）读不到宿主机路径，且文件超过 base64 回退阈值';
  throw new Error(`${lastErr?.message ?? lastErr}。${hint}。文件本体仍在：${abs}`);
}

export function available() {
  return true;   // 待发区在首次入库时创建，无前置依赖
}

// ── 对外能力 ──────────────────────────────────────────────────────────
export const providers = {
  /**
   * 生产者入库：由本技能决定分区、净化并唯一化文件名、记账、顺带清理。
   * 消费方只给"哪个会话、源文件在哪、想叫什么名"。
   */
  'file.stage': ({ chatKey, sourcePath, name } = {}) => {
    try {
      const partition = partitionOf(chatKey);
      if (!partition) return { ok: false, error: `非法会话 key：${chatKey}` };
      const src = String(sourcePath ?? '');
      if (!src || !fs.existsSync(src)) return { ok: false, error: `源文件不存在：${src}` };
      const dir = partitionDir(partition);
      fs.mkdirSync(dir, { recursive: true });
      const finalName = uniqueName(dir, sanitizeName(name || path.basename(src)));
      const dest = path.join(dir, finalName);
      // COPYFILE_EXCL：即使 uniqueName 判断与写入之间有竞态，也不会覆盖既有文件
      fs.copyFileSync(src, dest, fs.constants.COPYFILE_EXCL);
      const stat = fs.statSync(dest);
      const idx = loadIndex();
      idx.files[keyOf(partition, finalName)] = {
        partition, name: finalName, size: stat.size,
        createdAt: Date.now(), sentAt: null, sendCount: 0
      };
      saveIndex(idx);
      const cl = cleanup();
      return { ok: true, name: finalName, partition, path: dest, cleanup: cl };
    } catch (e) {
      return { ok: false, error: e?.message ?? String(e) };
    }
  },

  /** 管理接口：核心路由做薄适配（网页端列表 / 删除 / 清理 / 用量） */
  'file.storage-admin': () => ({
    usage: () => {
      const u = usage();
      return { totalBytes: u.totalBytes, maxBytes: u.maxBytes, thresholdBytes: u.thresholdBytes, maxMB: u.maxMB, cleanupAtPercent: u.pct };
    },
    list: () => {
      const u = usage();
      const map = new Map();
      for (const e of u.entries) {
        if (!map.has(e.partition)) map.set(e.partition, { partition: e.partition, files: [], bytes: 0 });
        const g = map.get(e.partition);
        g.files.push({
          id: encodeId(e.key), name: e.name, size: e.size,
          createdAt: e.createdAt, sentAt: e.sentAt, sendCount: e.sendCount
        });
        g.bytes += e.size;
      }
      const partitions = [...map.values()].sort((a, b) => b.bytes - a.bytes);
      for (const g of partitions) g.files.sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
      return {
        partitions,
        usage: { totalBytes: u.totalBytes, maxBytes: u.maxBytes, thresholdBytes: u.thresholdBytes, maxMB: u.maxMB, cleanupAtPercent: u.pct }
      };
    },
    remove: (id) => {
      const key = decodeId(id);
      const u = usage();
      const entry = u.entries.find((e) => e.key === key);
      if (!entry) return { ok: false, error: '文件不存在（可能已被清理）' };
      try {
        fs.unlinkSync(filePathOf(entry));
        const idx = loadIndex();
        delete idx.files[key];
        saveIndex(idx);
        return { ok: true, name: entry.name, size: entry.size };
      } catch (e) {
        return { ok: false, error: e?.message ?? String(e) };
      }
    },
    cleanup: () => cleanup(),
    dir: () => allowedDir()
  })
};

export function setup(api) {
  cfg = api.config;
  log = api.log;

  api.registerTool({
    id: 'send_file',
    name: '发送文件',
    description: '把**当前会话自己分区**里的文件上传发送到当前会话。name 参数只填文件名；别的会话的文件发不了（管理员可用 chat 参数跨窗口发送）。',
    category: 'system',
    parameters: {
      type: 'object',
      properties: {
        name: { type: 'string', description: '当前会话分区里的文件名（不是路径），如 报告-20260930.pdf' },
        note: { type: 'string', description: '可选：一句话说明这是什么文件' },
        chat: { type: 'string', description: '仅管理员可用：指定从哪个会话的分区发送，形如 group:123456789 或 private:88888' }
      },
      required: ['name']
    },
    async execute(ctx, args) {
      const s = settings();

      // ── 可选门禁：仅管理员 ──
      if (s.ownerOnly && !isAdmin(ctx)) {
        const owner = String(s.ownerQQ || '').trim();
        if (!owner) return err('已开启"仅管理员可用"，但还没配置管理员 QQ 号。');
        return err('文件发送只对管理员开放。');
      }

      if (!ctx || (ctx.kind !== 'private' && ctx.kind !== 'group')) {
        return err('当前会话类型不支持发送文件。');
      }
      if (!/^\d+$/.test(String(ctx.chatId ?? ''))) {
        return err('会话 id 非法，无法上传文件。');
      }

      // ── 分区：默认只在本会话自己的分区；跨窗口仅管理员 ──
      const ownPartition = partitionOf(ctx.chatKey);
      if (!ownPartition) return err('无法识别当前会话分区。');
      let partition = ownPartition;
      const requestedChat = String(args?.chat ?? '').trim();
      if (requestedChat) {
        if (!isAdmin(ctx)) {
          return err('跨会话发送只对管理员开放：只能发送本会话自己分区里的文件。');
        }
        const target = requestedChat === ROOT_PARTITION ? ROOT_PARTITION : partitionOf(requestedChat);
        if (!target) return err(`chat 参数格式不对：${requestedChat}（应为 group:123 或 private:456）`);
        partition = target;
      }
      const dir = partitionDir(partition);

      // ── 第一层：参数只收文件名 ──
      const name = String(args?.name ?? '').trim();
      if (!name) return err('缺少文件名');
      if (name.includes('/') || name.includes('\\') || name === '.' || name === '..') {
        return err('name 只能是文件名，不能带路径。');
      }

      // ── 第二层：落地路径必须仍在分区目录内 ──
      const abs = path.resolve(dir, name);
      const rel = path.relative(dir, abs);
      if (!rel || rel.startsWith('..') || path.isAbsolute(rel)) {
        return err('文件不在该会话的分区内。');
      }

      // ── 第三层：realpath 双侧解析（挡符号链接逃逸）──
      try {
        const realDir = fs.realpathSync(dir);
        const realFile = fs.realpathSync(abs);
        const relReal = path.relative(realDir, realFile);
        if (relReal.startsWith('..') || path.isAbsolute(relReal)) {
          return err('文件不在该会话的分区内（符号链接）。');
        }
      } catch {
        return err(`文件不存在：${name}（分区 ${partition}）`);
      }

      let stat;
      try {
        stat = fs.statSync(abs);
      } catch {
        return err(`文件不存在：${name}`);
      }
      if (!stat.isFile()) return err(`${name} 不是普通文件`);
      const maxMB = Math.max(1, Number(s.maxSizeMB) || 100);
      if (stat.size > maxMB * 1024 * 1024) {
        return err(`文件 ${name} 超过体积上限（${(stat.size / 1048576).toFixed(1)}MB > ${maxMB}MB）`);
      }

      // ── 技能内限频 + 去重 ──
      const now = Date.now();
      const hits = (minuteHits.get(ctx.chatKey) || []).filter((t) => now - t < 60000);
      const perMin = Math.max(1, Number(s.maxPerMinute) || 10);
      if (hits.length >= perMin) {
        return err(`发送太频繁（每分钟最多 ${perMin} 个文件），请稍后再试`);
      }
      const dedupeKey = `${ctx.chatKey}:${name}`;
      if (now - (lastSent.get(dedupeKey) || 0) < 8000) {
        return err(`文件 ${name} 刚刚发送过，已跳过（避免重复）`);
      }

      // ── 进度消息（走 sender 管道：限频/留档/转义都有）──
      const note = String(args?.note ?? '').trim();
      try {
        await ctx.sender.sendTextBatch(ctx.chatKey, [`⏳ 正在发送文件：${name}${note ? `（${note}）` : ''}…`]);
      } catch (e) {
        log(`进度消息发送失败（不影响文件上传）：${e?.message ?? e}`);
      }

      // ── 上传（file:/// 先行，失败回退 base64）──
      const isPrivate = ctx.kind === 'private';
      const action = isPrivate ? 'upload_private_file' : 'upload_group_file';
      const params = isPrivate
        ? { user_id: Number(ctx.chatId), name }
        : { group_id: Number(ctx.chatId), name };

      let data;
      try {
        data = await uploadWithFallback(ctx, action, params, abs, stat);
      } catch (e) {
        return err(`文件上传失败：${e?.message ?? e}`);
      }

      // ── 留档（与 sender 的 appendSelf 约定一致）──
      const ts = Date.now();
      try {
        ctx.store?.appendSelf?.(ctx.chatKey, { text: `[文件:${name}]`, ts, mid: null });
      } catch (e) {
        log(`留档失败（文件已发出）：${e?.message ?? e}`);
      }

      // ── 记账 + 顺带清理（已发送文件可被清理腾空间）──
      try {
        const idx = loadIndex();
        const key = keyOf(partition, name);
        const prev = idx.files[key] || {};
        idx.files[key] = {
          partition, name, size: stat.size,
          createdAt: Number(prev.createdAt) || stat.mtimeMs,
          sentAt: ts, sendCount: (Number(prev.sendCount) || 0) + 1
        };
        saveIndex(idx);
      } catch (e) {
        log(`索引记账失败（文件已发出）：${e?.message ?? e}`);
      }
      let cl = { removed: 0, warned: false, totalBytes: 0, thresholdBytes: 0 };
      try { cl = cleanup(); } catch (e) { log(`自动清理失败：${e?.message ?? e}`); }

      minuteHits.set(ctx.chatKey, [...hits, now]);
      lastSent.set(dedupeKey, now);
      log(`已上传 ${name} → ${ctx.chatKey}（分区 ${partition}，file_id=${data?.file_id ?? '无'}）`);

      const extra = [];
      if (cl.removed) extra.push(`已自动清理 ${cl.removed} 个最久远的已发送文件`);
      if (cl.warned) {
        extra.push(`⚠️ 待发区已超过容量阈值（${(cl.totalBytes / 1048576).toFixed(1)}MB ≥ ${(cl.thresholdBytes / 1048576).toFixed(1)}MB），`
          + '但已无已发送文件可清理——请到控制台「文件」页手动处理');
      }
      return ok([`文件已发送：${name}${note ? `（${note}）` : ''}`, ...extra].join('\n'));
    }
  });
}
