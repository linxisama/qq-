# 文件传输（file-transfer）

把**专属文件夹**下、**当前会话自己的分区**里的文件上传发送到会话。`src/` 里只有三个薄适配端点
（给网页端用），存储规则全部在本技能内实现——生产者与网页端看到的是同一份真相。

## 存储布局

```
<allowedDir>/                     默认 <qq-agent>/data/outbound-files/（gitignored）
  .index.json                     索引：体积 / 创建时间 / 已发送时间（原子写）
  private_10001/                  每个私聊一个分区
  group_123456789/                每个群一个分区
  <根目录文件>                     公共区（仅管理员可发）
```

分区键用 `private_<QQ>` / `group_<群号>`——与项目 `store.js` / `memory.js` 的会话目录命名一致
（Windows 不允许冒号，所以不能直接用 chatKey）。

## 四条存储规则

**1. 命名规范（防覆盖）**：入库时净化文件名（去路径分隔符与控制字符、折叠空白、去首部点、
主名截断 120 字符），同名自动加序号 `-2`/`-3`…（最多 50 个），再冲突就加 `-HHmmss` 时间戳。
写入用 `COPYFILE_EXCL` 双保险——**绝不覆盖既有文件**。同一份报告当天重复生成不再覆盖旧文件。

**2. 分区隔离（禁跨窗口）**：`send_file` 默认只在本会话自己的分区里找文件，别的会话的文件发不了。
只有**管理员**（`ownerQQ` 私聊）能用 `chat` 参数跨窗口发送（`chat="group:123"`），非管理员传这个参数直接拒绝。

**3. 容量上限 + 自动清理**：达到 `maxTotalMB × cleanupAtPercent%` 时，按 `sentAt` 升序删除
**已发送**文件直到低于阈值。**未发送文件永不自动删除**；已发送的删完仍超限时只告警
（界面红字 + 日志 + 发送结果里提示）。触发时机是入库后与发送后（惰性），另有界面手动清理按钮。

**4. 索引对账**：每次 list/stage/send/cleanup 都把磁盘与索引对一遍——手工放进来的文件自动补录
（`sentAt=null`），手工删掉的自动剔除，避免记账漂移。

## 工具

`file-transfer__send_file`，参数：

| 参数 | 必填 | 说明 |
|---|---|---|
| `name` | 是 | 当前会话分区里的**文件名**（不是路径） |
| `note` | 否 | 一句话说明 |
| `chat` | 否 | **仅管理员**：指定从哪个会话的分区发送（`group:123` / `private:456`） |

## 配置（网页端「技能 → 文件传输」弹窗，管理员可改）

| 字段 | 默认 | 说明 |
|---|---|---|
| `allowedDir` | `data/outbound-files/` | 存储根目录，各分区建在它下面 |
| `maxSizeMB` | 100 | 单文件体积上限（发送时校验） |
| `base64FallbackMB` | 20 | 路径上传失败时，不超过此体积改用 base64 重传 |
| `maxPerMinute` | 10 | 发送限频 |
| `maxTotalMB` | **500** | 存储总容量上限 |
| `cleanupAtPercent` | 90 | 达到上限的百分比就触发清理 |
| `ownerOnly` | false | 仅管理员可用 |
| `ownerQQ` | 空 | 管理员 QQ（跨窗口发送与 ownerOnly 判定用） |

## 对外能力

| 能力 | 用途 |
|---|---|
| `file.stage` | 生产者入库：`api.capability('file.stage', { chatKey, sourcePath, name })` → 由本技能决定分区、净化唯一化、落盘、记账、顺带清理，返回 `{ ok, name, partition }` |
| `file.storage-admin` | 管理接口：`list()` / `remove(id)` / `usage()` / `cleanup()` / `dir()`，供核心路由做薄适配 |

> 旧的 `file.outbound-dir`（返回目录、让生产者自己 `copyFileSync`）**已移除**——
> 它绕过了命名规范与索引记账，同一份报告当天重复生成会静默覆盖。

## 网页端「文件」页

- 前端：`ui/app/13-files.js`（页签 `files`），总占用进度条（标注上限与阈值）+ 按分区折叠列表
  （文件名/体积/存入时间/已发送标记）+ 每项删除 + 「清理已发送」+「刷新」
- 后端：`src/routes.js` 三个薄适配端点，逻辑全在技能里
  - `GET /api/file-transfer/files` → 分区 + 文件 + 用量
  - `DELETE /api/file-transfer/files/:id`（id 是 `分区/文件名` 的 base64url）
  - `POST /api/file-transfer/cleanup`
  - 技能被关闭时三个端点回 **503 + 明确原因**（不崩）

## 上传形态回退（实测踩坑：NapCat 在 Docker 里）

2026-09-30 实测：`upload_private_file` 的 `file` 参数用**裸 Windows 路径**会被报
「识别URL失败」；换成 `file:///` URI 后 NapCat 会真的去开文件，但拿到的是**容器内**的
`ENOENT`——协议端跑在 Docker 容器里时读不到宿主机路径。

所以上传按 sendImage 的图片回退模式做两段式：先试 `file:///`（同机时零传输成本），
失败且体积 ≤ `base64FallbackMB` 就回退 `base64://` 内联重传（容器通用）。

## 已知限制

- **NapCat 的 `upload_private_file` 要求 bot 与对方互为好友**；群文件要求 bot 在群内。
  失败时工具报原因，文件本体仍在分区里可手动取
- 上传接口返回 `file_id` 而非 `message_id`，留档的 `mid` 记为 `null`
- 清理是**惰性**的（入库/发送时触发），长期不发消息就不会自动清理，可在界面手动清理
- 网页端只做查看/删除/清理，**不做上传**；往别的分区放文件目前仍需落盘操作

## 验证

本技能在作者工作区里有一份端到端验证脚本（不随技能分发），覆盖：分区隔离（含管理员跨窗口
与非管理员拒绝）、命名唯一化与净化、索引对账、容量清理（只删已发送 + 只剩未发送时告警）、
路径安全、体积上限、上传回退、去重、ownerOnly，以及端到端（生产方入库 → 发送 → 重复不覆盖）。
