// 内核装载桥 —— 插件与情绪系统独立内核之间的唯一通道。
//
// 内核落位（2026-10-08 完全移植）：内核 7 模块随插件放在 <插件目录>/kernel/，
//   profile 资产在 <DATA_DIR>/plugins/emotion-core/profiles/（平铺，文件名即注册表条目）。
//   不再依赖任何跨盘绝对路径（此前跨盘绝对路径写死，换机/发包必崩）。
//
// 🔴 路径含空格/中文（"QQ agent mu"），必须 pathToFileURL——
//    直接 import 绝对路径或 new URL().pathname 会 ERR_MODULE_NOT_FOUND（%20 坑，2026-09-20 实测）。
//
// 内核零依赖（其 test §2 有硬保证），目录内相对 import（emotion-core←atoms、
// persona-gate←emotion-core、persona-judge←persona-fit），整体搬动不破坏。

import path from 'node:path';
import fs from 'node:fs';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { DATA_DIR } from '../../src/config.js';

const PLUGIN_DIR = path.dirname(fileURLToPath(import.meta.url));

/** 默认内核与 profile 位置（可在插件 config 里用 kernelDir 覆盖；空值 = 用这里的锚点）。 */
export const DEFAULT_KERNEL_DIR = path.join(PLUGIN_DIR, 'kernel');
export const PROFILES_DIR = path.join(DATA_DIR, 'plugins', 'emotion-core', 'profiles');
export const DEFAULT_PROFILE = path.join(PROFILES_DIR, '合欢.json');

/** 动态 import 内核主模块（返回 emotion-core.mjs 的导出面）。
 *  🔴 2026-10-02：加 mtime 破缓存——此前裸 URL，宿主进程对 emotion-core.mjs→atoms.mjs
 *  的 ESM 缓存永久有效，插件 reload（judge/bridge 两层 ?t=）换不动内核代码：
 *  实测 atoms.mjs 改 agent→joy 溢出后宿主仍跑旧映射（离线新进程验证有 joy、宿主无）。
 *  与 loadModules 对 judge.mjs 的破缓存同手法、同根因（宿主热重载只破入口一层）。 */
export async function importKernel(kernelDir = DEFAULT_KERNEL_DIR) {
  const p = path.join(kernelDir, 'emotion-core.mjs');
  const url = pathToFileURL(p).href + `?t=${fs.statSync(p).mtimeMs}`;
  return await import(url);
}

/** 读正式版 profile JSON。 */
export function readProfile(profilePath = DEFAULT_PROFILE) {
  return JSON.parse(fs.readFileSync(profilePath, 'utf8'));
}

/**
 * 组装一个可用的内核实例。
 * @param {{kernelDir?:string, profilePath?:string, state?:object|null, now?:number}} opt
 * @returns {Promise<{core:object, profile:object, cardId:string}>} core = createCore() 返回值
 */
export async function createKernelInstance(opt = {}) {
  const K = await importKernel(opt.kernelDir);
  const profile = readProfile(opt.profilePath);
  const now = opt.now ?? Date.now();
  const core = K.createCore({
    cardId: profile.cardId,
    profile,
    state: opt.state || null,
    now
  });
  return { core, profile, cardId: profile.cardId || 'unknown' };
}

/** 状态快照（持久化用）：只取可 JSON 化的字段。 */
export function snapshotState(core, now = Date.now()) {
  core.tick(now);
  return JSON.parse(JSON.stringify(core.state));
}

export default { importKernel, readProfile, createKernelInstance, snapshotState };
