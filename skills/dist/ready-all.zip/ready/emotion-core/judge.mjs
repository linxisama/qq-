// 判词层 v1（词表版）—— 把到达她的消息判定成内核评价事件。
//
// ⚠️ 与 persona-fit 的 SIGNALS 是两套词表、两个用途，不要混：
//   persona-fit = 「这张卡**允许**什么情绪表达」（配 profile，离线）
//   本文件     = 「这条**消息**是什么情绪事件」（运行时判消息，逐条）
//
// v1 纪律（影子期）：
//   · 宁漏勿误 —— thirdParty/desire 用极窄匹配，误判的代价（吃醋/占有欲常驻刷屏）
//     远大于漏判的代价（少一次情绪波动）。
//   · 中性消息返回 null —— 寒暄不推情绪。
//   · 只产出数据，不做任何注入 —— 影子期 LLM 侧不感知本插件。
//
// 深度复用：否定窗口逻辑借鉴 persona-fit（12 字回看 + 子句截断），口径一致好对拍。

const NEGATIONS = ['不', '绝不', '从不', '并不', '没有', '没', '别', '禁止', '不许', '不准', '切勿', '莫', '并非'];
// 🔴 v1.2：逗号/顿号加入子句截断 —— 首日实测抓到「今晚也不会走开哦，爱你哦」的「爱你」
// 被 12 字窗口里的「不会」误杀（中文先抑后扬句式：不哭了抱抱/别闹喜欢你/不会走开哦爱你）。
const CLAUSE_BREAK = /[。！？!?，,、\n]/;

// 🔴 v1.9.1：「别」是高频词素误杀源——「特别开心/特别可爱/别人夸你/你跟别的女生玩得开心」
// 全被窗口里的「别」当否定词杀掉 pos 计数（v1.9.1 边界用例撞出）。修：单字「别」后随字
// 命中词素白名单时不算否定（真正祈使「别走/别闹」后随动词，不受影响）。
const BIE_LEXEME = /^[人的特级别离区个告辞扭辨别鉴送永积]/;
function isNegated(lower, idx) {
  const window = lower.slice(Math.max(0, idx - 12), idx);
  for (let i = window.length - 1; i >= 0; i--) {
    for (const n of NEGATIONS) {
      if (!window.startsWith(n, i)) continue;
      if (n === '别') {
        const rest = window.slice(i + 1);
        // 「别」后是空（特别|开心）或首字是词素（别人|别的|特别…）⇒ 不是祈使否定
        if (rest === '' || BIE_LEXEME.test(rest)) continue;
      }
      if (!CLAUSE_BREAK.test(window.slice(i))) return true;
    }
  }
  return false;
}

/** 正向词（别人对她表达的好意/夸奖/亲近）。 */
const POS_WORDS = ['喜欢', '爱你', '想你', '夸', '厉害', '真棒', '好看', '可爱', '谢谢', '辛苦',
  '开心', '高兴', '有趣', '搞笑', '温柔', '聪明', '晚安', '早安', '抱抱', '亲亲', '贴贴',
  '安心', '放心', '暖心', '治愈'];
/** 负向词（对她的攻击/冷落/嫌弃）。v1.9 补 难过/伤心（「又开心又难过」混合句此前漏负）。 */
const NEG_WORDS = ['滚', '闭嘴', '烦', '讨厌', '蠢', '傻', '无聊', '垃圾', '恶心', '骗',
  '虚伪', '冷漠', '不理你', '凶', '骂', '闭麦', '拉黑', '难过', '伤心'];
/** 程度词（抬强度）。 */
const INTENSIFIERS = ['太', '超', '好', '真', '绝了', '死', '特别', '超级', '非常', '极其'];
/** 归因她（「怪你」句式 → attributionOther，委屈/炸毛燃料）。
 *  v1.9 扩：全量审计 838 条归因 0 命中 ⇒ 补 是你让/害(得)我/全怪你（「都怪你，害我等了这么久」此前漏）。
 *  🔴 v1.9.5：否定环视（A/B 首日实测方向误判）——「没开相关功能，你理解不了，**我不怪你**」
 *  的「怪你」子串命中 ⇒ attribution=other 强制 v=-0.6，宽恕句落 sad+5.3。加 (?<![不没别无需])，
 *  与 OBJECT_RE 的同款手法对齐。 */
const BLAME_RE = /(?<![不没别无需])(?:都?[怪赖怨]你|你凭什么|就是你(的错|的问题)|你的问题|怪不得别人|是你(让|害|搞|弄)|害得?我|全怪你)/;
/** 归因己（v1.9 新增：attributionSelf → 愧疚/难过通道）。「是我自己不好」「都怪我」「我的错」。
 *  刻意不收单字「怪我」前无「都/是」的口语反问（「怪我咯」单独收录）。
 *  🔴 v1.9.5：同款否定环视——「别怪我/不怪我」是辩护不是愧疚，不该进 attribution=self。 */
const SELF_BLAME_RE = /(?<![不没别])(?:是我(自己)?(的错|不好|不对|害的)|都?[怪赖怨]我|怪我咯|我的错)/;
/** 否定式自贬（v1.9 新增：🔴 全盲修复）。「没有人会喜欢我」「喜欢你的人根本没有」——
 *  「喜欢」被计正向、整句误判 +0.8，实为重度自我否定（sad 燃料）。窄匹配防误伤：
 *  「没有人比你更好」（真夸奖）不含 喜欢/在乎/爱+我 尾，不命中。 */
const SELF_DEPRECATION_RE = /没[人有]+(会|会去|要)?(喜欢|在乎|爱)我|(喜欢|在乎|爱)(我|你)?的人(根本|压根|确实|真的)?(没有|不存在|一个都没)/;
/** 轻度贬损（v1.9 新增）。「真是个笨猫」「果然靠不住」「你是假猫娘吧」——既有词表全盲。
 *  落 -0.6（比重攻击 滚/垃圾 的 -0.8 轻，符合「轻度」定位）。
 *  刻意不收 笨蛋/傻瓜（情侣间高频爱称，误伤代价 > 漏判）。 */
const LIGHT_INSULT_RE = /笨(猫|狗狗?|喵)|假猫(娘)?|靠不住|真没用|没用的东西|真差劲|废物|真逊|好逊/;
/** 亲昵动作动词表（v1.9.2 新增：动词+角色名 通道）。词表 DESIRE_RE 只收「动词+我/你」，
 *  宾语是角色名时抓不到（「摸摸百可花」「揉揉猫尾草的头」）。
 *  双保险宁漏勿误：亲昵动词 +（其他卡名 或 本卡名）⇒ desire 标记（影子期只标记）。
 *  刻意不收单字 打/踢/骂/拍（歧义；「拍了拍」是 QQ 拍一拍固定句式，整词收录）。
 *  🔴 v1.9.3 收窄：**取消拍一拍无条件特判**——实测 12 条 [拍一拍] 全是群友互拍广播
 *  （「小梦儿 拍了拍 九条美姬」），进消息流 ≠ 拍她（与 0930 群聊实测「98% 不指向她」同教训）。
 *  拍一拍只在被拍者是卡名时经名字路径命中。 */
const AFFECTION_VERBS = /(摸摸|摸了摸|揉揉|捏捏|拍了拍|蹭蹭|贴贴|rua|薅)/;
/** 第三方极窄匹配（宁漏勿误：误判 = 吃醋/占有欲常驻）。 */
const THIRD_PARTY_RE = /你(和|跟)(她|他|别人)|别的(女|男)|那个(女生?|男生?)|新欢|前任|别人的女朋友?/;
/** 亲密互动（desire 事件源，影子期只记录不生效）。
 *  v1.1 扩身体亲密动作族 —— 首日影子数据漏判 2 例（「（抱紧）」「再贴紧些（收紧了几分力）」），
 *  舞台指令括号里的亲密接触是私聊高频信号源，与「抱抱/亲亲」同族。
 *  v1.3 补 摸着/摸你/怀里/入怀/解衣/褪衣/抚摸/爱抚/宠着/宠你（655 条回放审计漏判前几名）。
 *  刻意不收：单字「宝」（宝物误伤）、「收紧」（收紧预算误伤）；露骨性描写细节（手指/水声等）
 *  词表强行覆盖会泛化误伤，留给判词 LLM v2 对拍——v1 定位是宽覆盖常见情感事件。
 *  v1.9：摸族加否定性环视 (?<![估琢忖揣]) —— 边界用例抓到「估摸着我还在睡」被「摸着」
 *  误命中 desire（估算义，非亲密动作）。 */
const DESIRE_RE = /(抱抱|抱紧|抱着|抱我|贴贴|贴紧|亲亲|亲了|亲你|亲我|亲一口|亲上|接吻|吻住|吻你|吻我|吻上|热吻|深吻|啄|吻痕|亲热|rua|(?<![估琢忖揣])摸摸头|(?<![估琢忖揣])摸着|(?<![估琢忖揣])摸你|(?<![估琢忖揣])摸我|蹭蹭|蹭我|蹭你|蹭到|牵着|挽着|靠在你|靠着她|靠着我|睡在|依偎|搂|窝在|偎|我怀里|我入怀|解衣|褪衣|抚摸|爱抚|宠着|宠你|把玩|玉足|舔|脱了|咬你|咬我|揪你|揪我)/;
/** 关系爱称/关系定义（v1.1 新增；v1.2 补「夫妻相」；v1.3 补 夫人/爱妻——回放审计「收到，夫人」漏判）。
 *  命中 → desire 标记（影子期只记录）+ 弱正效价。刻意不含单字「宝」（宝物/法宝误伤）。 */
// v1.9.7 加 主人/妈妈/哥哥（人设广场 69 卡语料挖掘，用户签字）：主人(?![公翁]) 防「主人公/主人翁」；
// 妈妈接受「你妈妈」字面误命中（语境概率低，影子账观察），v1.9.7 影子候选见 shadowMatch。
const PET_RE = /老婆|女友|女朋友|亲爱的|宝贝|宝宝|宝儿|达令|相公|夫君|娘子|老公|夫妻相|夫人|爱妻|主人(?![公翁])|妈妈|哥哥/;

/**
 * v1.9.7 影子账候选（2026-10-07 用户拍板：B4/B5/C 不进判定，只观察）。
 * shadowMatch(text) 纯函数（L1 零副作用），index.js(L3) 写影子账时挂 lexShadow 字段。
 * 观察期 3~5 天：误报率可控再毕业进 PET_RE/NEG_WORDS，不可控就删——不动 judge() 判定。
 */
const SHADOW_LEXICON = ['老师', '大人', '老板', '主公', '大哥', '呜呜', '哭哭'];
export function shadowMatch(text) {
  const t = String(text || '');
  if (!t) return [];
  return SHADOW_LEXICON.filter((w) => t.includes(w));
}
/** 对象分支（想念/想见 —— longing 通道）。v1.2 补「惦记/想念」；v1.3 补「爱你」
 *  （「我爱你哦」是被表白，应走 longing——回放审计 655 条里频次不低）。
 *  v1.9 补「理(一)理我/搭理我」（求关注，边界用例「理理我嘛」此前判 null）；
 *  加 (?<![不别没]) 环视防否定式误入（「别不理我」实为求关注，但「你怎么不理我了」
 *  是冷落抱怨——两义难分，影子期宁漏勿误，一并排除，只收正向祈使形态）。 */
const OBJECT_RE = /想(你|见你|见我|念)|惦记|挂念|爱你|爱(我|你)吗|喜欢我吗|我的爱|回应我的|什么时候(回来|出现|上线)|好久不见|陪我|来陪我|回来啦|去哪了|(有没有|想不想)想我|想不想我|想我(吗|么|了没|没有|了吗|我不)|(?<![不别没])理(一)?理我|(?<![不别没])搭理我/;
/** 行为分支（对她行为的赞同 —— regard 通道）。
 *  v1.3：删单字「稳」（回放审计误判「无论走得多远，家就在身边」——抒情被当夸奖）；
 *        前缀补「最」（「我们家小眠最棒了」漏判）。 */
const AGENT_RE = /(真|好|很|太|超|最)(棒|厉害|强|聪明|靠谱|乖)|做得好|服了|佩服|学到了|专业/;

/** 🔴 v1.9.4：嵌套方括号感知的引用段剥离。旧正则 \[引用 [^\]]*\] 遇内嵌 [at]/[reply]
 *  会在第一个 ] 提前收口，引用正文尾巴（「我厉不厉害]」）泄漏进判定文本。
 *  实现：扫描到「[引用」后做括号深度计数，切到配对 ] 为止，整段移除。 */
function stripQuoteSegments(text) {
  let out = '';
  let i = 0;
  while (i < text.length) {
    if (text.startsWith('[引用', i)) {
      let depth = 0;
      let j = i;
      for (; j < text.length; j++) {
        if (text[j] === '[') depth++;
        else if (text[j] === ']') { depth--; if (depth === 0) { j++; break; } }
      }
      i = j; // 引用段（含被拍者/被引用人）整段丢弃
      continue;
    }
    out += text[i++];
  }
  return out;
}

function countMatches(text, words) {
  const lower = text.toLowerCase();
  let pos = 0, neg = 0;
  for (const w of words) {
    const lw = w.toLowerCase();
    let from = 0;
    for (;;) {
      const idx = lower.indexOf(lw, from);
      if (idx < 0) break;
      // 否定窗口内的命中不计数（「不喜欢」不是喜欢；「不讨厌」不是讨厌）
      if (!isNegated(lower, idx)) { (POS_WORDS.includes(w) ? pos++ : neg++); }
      from = idx + lw.length;
      if (pos + neg > 20) break;
    }
  }
  return { pos, neg };
}

/**
 * 判定一条消息。
 * @param {string} text 消息文本（已去 @ 前缀也可，原样也行）
 * @param {string[]} [otherNames] 其他角色卡的名字（调用方从 config 取，排除本卡）。
 *   文本含这些名字且本条已有正向/亲密命中时 → thirdParty=true：
 *   「我爱你，百可花」是给别人的爱，记到本卡头上是错账（影子期宁漏勿误）。
 * @returns {null|{branch,time,valence,intensity,attribution,thirdParty,desire,thirdPartyName,why}}
 *   null = 中性消息，不施加事件
 */
export function judge(text, otherNames = [], selfName = '') {
  // 🔴 v1.9.4 三处文本预处理重构：
  // ① 引用段嵌套感知剥离（stripQuoteSegments，替换 v1.x 的 \(?\[引用 [^\]]*\] 一次正则）；
  // ② @提及保护：通用 @\S+ 清洗会把「摸摸@猫尾草」的卡名一起删掉（10-01 实测漏判根因）——
  //    先把 @+已知名字（本卡名/botName 别名/其他卡名）还原成裸名字，再清掉其余 @token；
  // ③ selfName 支持数组（本卡名 + botName 等代称，v1.9.2 通道语义不变：只进爱抚通道，
  //    绝不进 thirdParty 检测）。
  const selfNames = Array.isArray(selfName) ? selfName.filter(Boolean).map(String) : (selfName ? [String(selfName)] : []);
  const knownNames = [...selfNames, ...(Array.isArray(otherNames) ? otherNames : [])].filter(Boolean);
  let t = stripQuoteSegments(String(text || ''));
  for (const n of knownNames) {
    t = t.split('@' + n).join(n).split('＠' + n).join(n);
  }
  t = t.replace(/[@＠]\S+/g, '').trim();
  if (!t) return null;

  const lower = t.toLowerCase();
  const isObject = OBJECT_RE.test(t);
  const isAgent = AGENT_RE.test(t);
  const { pos, neg } = countMatches(t, [...POS_WORDS, ...NEG_WORDS]);

  // 归因 / 第三方 / 亲密 / 爱称 —— 四个标记独立判定
  // v1.9：attribution 支持 'self'（愧疚通道）；SELF_DEPRECATION / LIGHT_INSULT 两个新标记
  let attribution = null;
  if (BLAME_RE.test(t)) attribution = 'other';
  else if (SELF_BLAME_RE.test(t)) attribution = 'self';
  const selfDep = SELF_DEPRECATION_RE.test(t);
  const lightInsult = LIGHT_INSULT_RE.test(t);
  // 🔴 v1.9.1 thirdParty 不再先验判定（收窄）——THIRD_PARTY_RE 命中无条件置 true 的话，
  // thirdPartyName=null，宿主拦截判据不成立就照常落账（双路径缺陷）。合一判定挪到效价后。
  let thirdParty = false;
  const pet = PET_RE.test(t);
  // 🔴 v1.9.2 动词+角色名爱抚通道（v1.9.3 收窄；v1.9.4 扩）：亲昵动词 +（本卡名/代称 或 其他卡名）。
  // v1.9.4：selfName 支持数组（本卡名 + botName——「@小鲸鱼 摸摸」的 QQ 昵称此前抓不到）；
  // @提及保护已把「摸摸@猫尾草」还原成「摸摸猫尾草」，名字相邻判定得以命中。
  // selfNames 只进本通道，绝不进 thirdParty 名字检测——「我爱你，猫尾草」对她本人是正向不是第三方。
  // [拍一拍] 广播不再无条件算（v1.9.3）：群友互拍占绝大多数，只有被拍者是卡名才经名字路径命中。
  const nameAffection = AFFECTION_VERBS.test(t)
    && (selfNames.some((n) => t.includes(n))
      || (Array.isArray(otherNames) && otherNames.some((n) => n && t.includes(n))));
  // 🔴 v1.9.4 裸爱抚窄通道：整条消息基本只有亲昵动词（≤6 字，如「摸摸」「摸摸摸摸」「贴贴」）。
  // 10-01 实测：仅艾特群里裸「摸摸」高频且几乎必指向她（消息能进判定链本来就经过了
  // 艾特/回复门槛），按 desire 只标记 + 弱正处理。长句里夹摸摸不收（宁漏勿误）。
  const bareAffection = AFFECTION_VERBS.test(t) && t.replace(/\s+/g, '').length <= 6;
  const desire = DESIRE_RE.test(t) || pet || nameAffection || bareAffection;

  // 分支优先级：agent（对行为的赞同类通常是明确夸）> object > event
  let branch = 'event';
  if (isAgent) branch = 'agent';
  else if (isObject) branch = 'object';

  // 效价
  let valence = 0;
  if (pos > 0 && neg === 0) valence = 0.8;
  else if (neg > 0 && pos === 0) valence = -0.8;
  else if (pos > 0 && neg > 0) valence = 0.2; // 混合（「讨厌，谁要喜欢你」）弱正
  if (branch === 'agent') valence = Math.max(valence, 0.8);
  if (branch === 'object') valence = Math.max(valence, 0.6);
  // 爱称兜底弱正（「笨笨老婆」——关系亲昵本身是弱正向信号，别以 valence=0 落账）
  if (pet) valence = Math.max(valence, 0.4);
  // 亲密动作同理（v1.2：首日实测「（摸摸头）再抱下去…」desire=true 但 valence=0，
  // joy delta=0 落账无意义——亲密互动本身就是弱正向）。
  // 🔴 v1.5：desire 弱正不得覆盖负向——实机误判「怎么不去你豆包妈妈怀里躺躺啊」（对线骂人，
  // 「怀里」命中 desire）被抬成 +0.4。负向时 desire 只做标记，效价维持负。 */
  if (desire && valence >= 0) valence = Math.max(valence, 0.4);
  // 🔴 v1.9 否定式自贬：「喜欢你的人根本没有」的「喜欢」会被计正向，整句误判 +0.8——
  // 必须在效价兜底之后强制压回重度负（sad 燃料）。
  if (selfDep) valence = -0.8;
  // v1.9 轻度贬损：压到 -0.6（比 NEG_WORDS 重攻击的 -0.8 轻）。
  if (lightInsult) valence = Math.min(valence, -0.6);

  // 强度
  let intensity = 0.6;
  if (t.length <= 5) intensity = 0.35;
  // v1.9：全角「！」计入强度（「滚！！！」此前 0.6——只数了半角）
  if ((t.match(/[!！]/g) || []).length >= 2 || INTENSIFIERS.some((w) => lower.includes(w))) intensity = 0.9;
  if (valence === 0) intensity = Math.min(intensity, 0.2);
  // 攻击/归因类不限长短：「滚」「都怪你」两个字也是明确负向事件（影子期实测：短攻击句
  // 被 0.35 强度过滤是误设计——攻击的强度在词义里，不在句子长度里）
  if (neg > 0) intensity = Math.max(intensity, 0.6);
  if (attribution) { intensity = Math.max(intensity, 0.6); valence = Math.min(valence, -0.6); }
  if (lightInsult) intensity = Math.max(intensity, 0.5);
  // 🔴 v1.9.4 礼节性问候降档：POS_WORDS 里的 晚安/早安 单独成句被判强正（10-02 实测
  // 「[图片][晚安]」v=0.8 i=0.6 → joy+14.6，睡前道别刷 joy 偏热）。仅当：问候词命中 +
  // event 分支 + 无 desire + pos≤1（「太可爱了晚安」的夸奖主信号不压）+ 无负向 ⇒
  // 效价压 0.4、强度压 0.35（保留「暖事件」弱波动）。object/agent 分支不压（「晚安想你了」
  // 走 object 该留）。
  if (valence > 0 && branch === 'event' && !desire && neg === 0 && pos <= 1
    && /晚安|早安|午安|好梦/.test(t)) {
    valence = Math.min(valence, 0.4);
    intensity = Math.min(intensity, 0.35);
  }
  // 🔴 v1.9.1 长文降权（用户拍板）：>80 字的判定率 66~100%——小说稿/角色扮演长段，
  // 信号密度低且污染影子账。降权而非跳过：留痕可见（审计能查），波动贴地——
  //   >80 字 intensity ≤0.35；>200 字 ≤0.25（= 宿主 minIntensity，几乎无波动）。
  // desire/thirdParty 标记不受影响（标记不是波动源）。放最后：压过 neg/attr 的强度抬升，
  // 长篇对线小作文同样低密度。短攻击句「滚」不受影响（长度门槛卡着）。
  if (t.length > 200) intensity = Math.min(intensity, 0.25);
  else if (t.length > 80) intensity = Math.min(intensity, 0.35);

  // 🔴 v1.9.1 thirdParty 合一（修双路径缺陷）：只有一条判定路径——
  // 正向/亲密命中 +（句中出现其他卡名 或 THIRD_PARTY_RE 词表命中）⇒ thirdParty=true。
  //   · 名字路径（v1.7）：thirdPartyName=那张卡 ⇒ 宿主留痕时能定位「给了谁」；
  //   · 词表路径（收窄版）：群聊「你跟别人跑了」定位不到人，thirdPartyName=null，
  //     宿主按 j.thirdParty 拦截（v1.9.1 起判据放宽为只看 thirdParty）；
  //   · 负向一律不查（对线语境提到别人本就该记，v1.7 既定原则）；
  //   · 放在中性过滤之前：valence=0 但词表命中的消息仍留痕不落账（与 v1.8 行为一致）。
  let thirdPartyName = null;
  if (valence > 0 || desire) {
    const hitName = Array.isArray(otherNames) ? otherNames.find((n) => n && t.includes(n)) : null;
    if (hitName) { thirdParty = true; thirdPartyName = hitName; }
    else if (THIRD_PARTY_RE.test(t)) thirdParty = true;
  }

  // 中性消息不施加（寒暄噪声防线）
  if (valence === 0 && !desire && !thirdParty && !attribution) return null;

  // 🔴 v1.9.5【P3】好感 verdict 通道：折算成记忆树语义事件类型（praise/insult/touch）。
  //   · touch 优先且须效价非负（「摸摸个头滚」这种负语境摸摸不收，宁缺勿误）；
  //   · insult 须负向 + 词表/轻贬/怪罪命中；自贬（selfDep）是说她自己不好，不是骂本卡 → 排除；
  //   · praise = 其余正向；care 通道 v2 候选暂不产出。
  //   这里只管"是不是语义事件"；方向闸（本卡名/@命中才许 praise/insult 入账）在 index.js 调用处。
  let relType = null;
  if ((nameAffection || bareAffection) && valence >= 0) relType = 'touch';
  else if (valence < 0 && (neg > 0 || lightInsult || attribution === 'other') && !selfDep) relType = 'insult';
  else if (valence > 0) relType = 'praise';

  return {
    branch,
    time: 'settled',
    valence,
    intensity,
    attribution,
    thirdParty,
    thirdPartyName,
    desire,
    relType,
    bareAffection,
    why: `${branch}|v=${valence}|i=${intensity}${selfDep ? '|selfDep' : ''}${lightInsult ? '|insult' : ''}`
  };
}

/** 判词层版本（影子数据里带着，方便日后对拍 LLM v2 时分代）。
 *  v1.1：DESIRE_RE 扩身体亲密动作族 + 新增爱称 PET_RE + POS_WORDS 加安心族（首日影子数据漏判 5 例）。
 *  v1.2：🔴 否定窗口加逗号截断（「不会走开哦，爱你」被「不会」误杀——中文先抑后扬句式系统性误判）；
 *        OBJECT_RE 补惦记/挂念/想念；DESIRE_RE 补亲一口/啄/吻痕/亲热/蹭到；PET_RE 补夫妻相；
 *        desire 命中兜底弱正 0.4。实测样本：第二批 43 行（v1.0 判定 9/9 方向对、漏判 ≥10）。
 *  v1.3：655 条历史回放审计（判定率 31.1%，方向误判 1 例）——AGENT_RE 删单字「稳」+ 前缀补「最」；
 *        OBJECT_RE 补「爱你」；PET_RE 补 夫人/爱妻；DESIRE_RE 补 摸着/怀里/入怀/解衣/褪衣/抚摸/爱抚/宠着/宠你。
 *  v1.4：实机监测补 接吻/吻住/吻你/吻上/热吻/深吻（「更加认真的接吻」「吻住莉贝尔」漏判）。
 *        单字「吻」仍不收（「口吻」负向语境误伤）。v1.3 上机同时确认：破缓存修复生效（词表自动上机）、
 *        response 记录随热重载自愈、「不要对我这么凶嘛」撒娇被否定窗口正确豁免（中性是对的）。
 *  v1.5：🔴 实机负向通道首战抓到误判——「怎么不去你豆包妈妈怀里躺躺啊」（对线骂人）被「怀里」
 *        误命中 desire 且抬成 +0.4。修：①「怀里/入怀」收窄为「我怀里/我入怀」；②desire 弱正
 *        只在 valence≥0 时生效（负向时 desire 只标记不抬效价）。另记录在案：「nmd，谁想你」
 *        傲娇反话判 object 弱正——词表对反话天生盲区，判弱正伤害有限，留给 LLM v2。
 *  v1.6：黎杳卡实测漏判二连——OBJECT_RE 补 爱(我|你)吗/喜欢我吗/我的爱/回应我的（「你爱我吗」
 *        两次 neutral）；DESIRE_RE 补 动词+我 形态（吻我/亲我/抱我/摸我/靠着我）。
 *  v1.7：🔴 第三方指向（多卡同玩实测）——「我爱你，百可花」被判本卡正向 v=0.8（给别人的爱
 *        记到了黎杳账上，跨角色错账）。judge 加第三参 otherNames（调用方传其他卡名，排除本卡）：
 *        正向/亲密命中且句中出现名字 → thirdParty=true + thirdPartyName，调用方只留痕不落账。
 *        只做名字出现的必要条件，宾语语义留给 LLM v2；负向不查（对线语境提到别人本就该记负向）。
 *  v1.8：0930 二诊补漏——OBJECT_RE 补「想我」系变体（想我吗/想我了没/想我没有/有没有想我/想不想我；
 *        收紧尾缀防「我想我们」误报，「你想我了吗」此前落 neutral）；DESIRE_RE 补 把玩/玉足/舔
 *        （R18 场景词，无歧义亲密；「治疗/服务」是黎杳职业词故意不收防误报）。
 *  v1.9：🔴 45 条边界用例对拍抓出 18 失败后的修复版（对拍器 run-boundary-cases.mjs，多卡视角）——
 *        ① 强度：全角「！」计入 /🈲「滚！！！」此前 0.6；② 否定式自贬 SELF_DEPRECATION_RE
 *        （「没有人会喜欢我」「喜欢你的人根本没有」此前「喜欢」计正向误判 +0.8）；③ attribution
 *        词表大扩（other 补 是你让/害(得)我/全怪你；新增 self 归因 SELF_BLAME_RE「都怪我/我的错/
 *        是我自己不好」——全量 838 条归因 0 命中的修复）；④ NEG_WORDS 补 难过/伤心（「又开心又难过」
 *        应混合 0.2 实际 0.8）；⑤ OBJECT_RE 补 理(一)理我/搭理我（「理理我嘛」判 null；带否定环视）；
 *        ⑥ 轻度贬损 LIGHT_INSULT_RE（笨猫/假猫娘/靠不住 → -0.6）；⑦ DESIRE_RE 摸族加 (?<![估琢忖揣])
 *        环视（「估摸着我还在睡」被「摸着」误命中 desire）。
 *  v1.9.1：四项拍板落地（2026-10-01 凌晨）——① 🔴 thirdParty 合一收窄（修双路径缺陷）：
 *        THIRD_PARTY_RE 命中不再无条件 thirdParty=true（旧路径 name=null ⇒ 宿主旧判据
 *        (thirdParty&&thirdPartyName) 不拦截 ⇒ 错账照记）。新路径：正向/亲密 +（卡名命中 或
 *        THIRD_PARTY_RE 词表命中）⇒ thirdParty=true；负向不查；宿主判据同步放宽为只看 j.thirdParty。
 *        ② 长文降权：>80 字 intensity ≤0.35、>200 字 ≤0.25（=minIntensity，贴地波动），
 *        治「小说稿判定率 66~100% 污染影子账」。③ 🎁「别」词素误杀修复（isNegated）：
 *        「特别开心/特别可爱/别人夸你」被窗口里的「别」当否定词杀掉 pos——BIE_LEXEME 词素
 *        白名单（别后为空或首字∈词素集 ⇒ 不算祈使否定）。
 *  v1.9.2：动词+角色名爱抚通道（拍板实施）——AFFECTION_VERBS（摸摸/揉揉/捏捏/拍了拍/蹭蹭/
 *        贴贴/rua/薅）+（其他卡名 / 本卡名）⇒ desire 标记。新增第四参 selfName（本卡名，只进
 *        本通道，绝不进 thirdParty 名字检测——「我爱你，猫尾草」对她本人是正向不是第三方）。
 *        不收 打/踢/骂/拍 单字（歧义）。
 *  v1.9.3：🔴 上机实测即翻车翻正——拍一拍无条件特判在真实数据 12/12 全是群友互拍广播
 *        （「小梦儿 拍了拍 九条美姬」），进消息流 ≠ 拍她（与 0930 群聊实测同教训）。
 *        取消 [拍一拍] 特判，拍一拍只在被拍者是卡名时经名字路径命中。
 *  v1.9.4：全天判定质量报告（20261001）四项落地——① 引用段嵌套感知剥离（stripQuoteSegments，
 *        旧正则遇内嵌 [at]/[reply] 在第一个 ] 提前收口，引用正文尾巴泄漏）；② @提及保护：
 *        通用 @\S+ 清洗会连卡名一起删（「摸摸@猫尾草」「猫娘真乖，摸摸@猫尾草」漏判根因），
 *        先还原 @+已知名字 再清其余 @token；selfName 升级为数组（本卡名+botName，「@小鲸鱼
 *        摸摸」的 QQ 昵称通道）；③ 裸爱抚窄通道（整条 ≤6 字只有亲昵动词 → desire 标记+弱正，
 *        「摸摸」「摸摸摸摸」实测漏判）；④ 礼节问候降档（晚安/早安单独成句 v≤0.4 i≤0.35，
 *        治「[图片][晚安]」joy+14.6 偏热）；⑤ AGENT_RE 补（真|好|超|很|太|最）乖。
 *  v1.9.5：🔴 A/B 首日实测方向误判（2026-10-02 10:18）——「没开相关功能，你理解不了，
 *        我不怪你」的「怪你」子串命中 BLAME_RE ⇒ attribution=other 强制 v=-0.6，
 *        宽恕句落 sad+5.3（v1.9.4 era 首个方向错误）。修：BLAME_RE / SELF_BLAME_RE
 *        加 (?<![不没别(无需)]) 否定环视——「我不怪你/别怪我/不怪我」不再进归因通道。
 *  v1.9.7：词表扩充第一批（2026-10-07 人设广场 69 卡/34.5 万字语料挖掘 + 用户签字）——
 *        ① DESIRE_RE 补 咬你/咬我/揪你/揪我（亲密咬/打闹揪）；② PET_RE 补 主人(?![公翁])/妈妈/哥哥
 *        （主人 101 次为广场女仆卡群绝对主流；妈妈接受「你妈妈」字面误命中风险，影子观察）。
 *        ③ 影子账候选通道 shadowMatch()：老师/大人/老板/主公/大哥（PET 存疑项）+ 呜呜/哭哭
 *        （情感观察），纯函数只供 L3 写影子账 lexShadow 字段，不动判定——3~5 天误报率
 *        可控再毕业（与 P3 判定源影子账同方法论）。拍类明确不收（铁律 14 拍一拍通道）。
 *  v1.9.6：【P3】新增 relType/bareAffection 两个返回字段（不改任何既有判定逻辑）——
 *        judge 结果折算成记忆树语义事件类型（praise/insult/touch，见 return 前注释），
 *        供 index.js 调 treeReceiveVerdict 补好感账（影子期与词表双跑，src 标记对照）。
 *        映射纪律：touch 须效价非负；insult 排除自贬；care v2 候选不产出。 */
export const JUDGE_VERSION = 'rule-v1.9.7';

export default { judge, JUDGE_VERSION };
