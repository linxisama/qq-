// 情绪内核影子模式（新）—— 与 emotion-shadow（六维 E 维采集端）并存，职责不同：
//   emotion-shadow = 六维记忆的 E 维采集（scoreText 词表 → emotion.json）
//   本插件        = 新情绪内核的**事件判定 + 七原子轨迹**影子记录（judge.mjs → JSONL）
//
// ══ 影子纪律（与 emotion-shadow 同款，上线前逐条自查）══════════════════
//   ① 零注入：不改 messages、不 promptSections、不注册工具 —— 对模型完全隐形，零 token。
//   ② 只写自己的目录：data/plugins/emotion-core/ —— 绝不碰 mood.json / memory / config。
//   ③ 失败一律静默：本插件任何错误不得影响机器人正常回复。
//
// ══ 三条刻意设计（都有出处，别"优化"掉）══════════════════════════════════
//   ① 🔴 **不用定时器** —— emotion-shadow 实测：这版宿主 skillManager.activate() 是死代码，
//      setInterval 永远不会跑。持久化全部走钩子内惰性刷盘（elapsed 判断）。
//   ② **desire 已放开（2026-10-03 用户拍板，I9 审计 `desire放开审计-20261003.md`）** ——
//      apply 事件带 desire:true；实际生效范围由 profile 的 I9 台账决定
//      （enabled+desireConfirmed=true 才有 desire 原子，未签卡由内核数学钳制）。
//   ③ **中性消息不施加**（judge 返回 null）—— 寒暄噪声会把七原子推成常数背景。
//
// ══ 多人设分账（2026-09-30 深夜，换卡测试逼出）═════════════════
//   宿主 chatBindings 分会话绑人设（绑定关系示例：A=黎杳 / B=贴吧鱼 / 其余=全局合欢）。
//   情绪是「人设」的属性：apply 的基线/钳制是卡的性格参数，跨人设共享状态账=错配。
//   ⇒ 按 personaId 各持一份 core 实例 + 独立 state 文件；映射表里没有的 persona 只记判定。
//   ⚠️ 宿主热重载只破入口缓存（plugin-loader `?t=` 只加 index.js）——judge.mjs/kernel-bridge.mjs
//      必须动态 import + mtime 破缓存键（见 loadModules）。
//
// 数据流：before-context（判定+施加+记 JSONL）→ after-response（记输出摘要）→ after-tool（惰性刷盘）

import path from 'node:path';
import fs from 'node:fs';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { DATA_DIR, getConfig } from '../../src/config.js';
// ── 2026-10-08 社区包解耦：宿主 src 依赖收敛 ─────────────────────────────
//   config.js        保留（0.4.x 核心必有）；
//   util.js          → vendor 自持（官方原版未必有）；
//   persona-store.js → 软依赖动态 import（缺失降级为默认卡，见 loadModules）；
//   emotion-residue  → vendor 自持副本（纯函数零状态，词表双改纪律见 vendor 头注释）；
//   memory-tree.js   → 软依赖动态 import（缺失则 judge 好感补账停用，其余不受影响）。
import { writeJsonAtomic } from './vendor/write-json-atomic.mjs';
import { scoreText, aggregate, snapshotFromText } from './vendor/emotion-residue.mjs';
// 【P3 20261003】judge 语义事件 → 记忆树好感补账（treeReceiveVerdict：方向校验/指纹去重/影子账全在 L3）。
// 🔴 2026-10-08 起改为软依赖（loadModules 动态装载）：宿主有 memory-tree 就补账（洛版现役照常），
//    没有就 relTree=null，:549 调用点判空跳过——官方 0.4.5 原版没有这个文件，静态 import 会炸掉整个插件。
//    静态 import 与宿主共享同一模块实例（缓存/树状态单例，不产生第二份状态）——动态 import 同一 URL 亦共享缓存，单例语义不变。

// 🔴 judge.mjs / kernel-bridge.mjs 动态 import + mtime 破缓存。
// 根因（2026-09-29 实测）：宿主热重载只给入口 index.js 加 ?t=，模块图内的相对导入
// （import './judge.mjs'）URL 不变 → 命中 ESM 模块缓存 → 词表改三轮上机仍是 v1.0。
// 技能页「关开」走 toggle 生命周期（同一模块对象重 setup），同样换不了代码。
// 解法：用文件 mtime 当破缓存键——judge.mjs 一改，mtime 变 → 新 URL → 强制重导入。
const PLUGIN_DIR = path.dirname(fileURLToPath(import.meta.url));
const APP_ROOT = path.resolve(PLUGIN_DIR, '..', '..');   // plugins/emotion-core → app root

let judgeFn = null;         // judge.mjs 的 judge()
let shadowMatchFn = null;   // judge.mjs 的 shadowMatch()（v1.9.7 影子账候选，只观察不动判定）
let judgeVersion = 'unknown';
let bridge = null;          // kernel-bridge.mjs 全模块
let bridge6d = null;        // bridge-6d.mjs 全模块（createBridge——E 维↔内核对接层，20261003 任务④）
let judgeLlm = null;        // judge-llm.mjs 全模块（LLM v2 哨兵异步复核，对拍期只写影子账）
let judgeLlmReady = false;
// ── 软依赖（2026-10-08 社区包解耦）：宿主有就增强，没有就降级，主功能不受影响 ──
let personaStore = null;    // src/persona-store.js（多卡分账 / 树空间 memoryKey）；null = 降级默认卡
let relTree = null;         // src/memory-tree.js（judge 好感补账 P3）；null = 补账停用

/** persona-store 软依赖包装：宿主有就透传，没有降级。 */
function currentMemoryKeyOf() {
  try { return personaStore ? (personaStore.currentMemoryKey() || '') : ''; } catch { return ''; }
}
function personaInfoOf(chatKey, opt = {}) {
  try { return personaStore ? personaStore.personaForChat(chatKey, opt) : { memoryKey: '' }; } catch { return { memoryKey: '' }; }
}

async function loadModules() {
  const jm = path.join(PLUGIN_DIR, 'judge.mjs');
  const bm = path.join(PLUGIN_DIR, 'kernel-bridge.mjs');
  const lm = path.join(PLUGIN_DIR, 'judge-llm.mjs');
  const [j, b, l] = await Promise.all([
    import(pathToFileURL(jm).href + `?t=${fs.statSync(jm).mtimeMs}`),
    import(pathToFileURL(bm).href + `?t=${fs.statSync(bm).mtimeMs}`),
    import(pathToFileURL(lm).href + `?t=${fs.statSync(lm).mtimeMs}`)
  ]);
  judgeFn = j.judge;
  shadowMatchFn = j.shadowMatch || null;
  judgeVersion = j.JUDGE_VERSION;
  bridge = b;
  judgeLlm = l;
  // bridge-6d.mjs 在内核目录（kernelDir），与 judge 同款 mtime 破缓存。
  // 缺文件/装载失败 → bridge6d=null：读方向停用（影子账不记 mood 行），写方向不受影响。
  try {
    const kd = (api && typeof api.config === 'function' ? api.config() : null)?.kernelDir
      || path.join(PLUGIN_DIR, 'kernel');   // 2026-10-08 完全移植：内核随插件，锚点相对插件目录
    const bp = path.join(kd, 'bridge-6d.mjs');
    if (fs.existsSync(bp)) {
      bridge6d = await import(pathToFileURL(bp).href + `?t=${fs.statSync(bp).mtimeMs}`);
    }
  } catch (e) {
    bridge6d = null;
    try { api?.warn?.('bridge-6d 装载失败（读方向停用，不影响其余功能）', e?.message ?? e); } catch { /* 忽略 */ }
  }
  // ── 软依赖装载（2026-10-08 社区包解耦）────────────────────────────────
  // 宿主 src 有这两个模块（洛版现役）→ 全功能；官方 0.4.5 原版没有 → 降级：
  //   personaStore=null ⇒ 多卡分账退化为"全部会话按默认卡"；
  //   relTree=null      ⇒ judge 好感补账停用（:549 判空跳过），影子账 judge 行照常。
  // 🔴 不需要 mtime 破缓存——宿主 src 无热重载，进程内装一次即可；
  //    同一 URL 的动态 import 与静态 import 共享 ESM 缓存 ⇒ memory-tree 树状态仍是单例。
  try {
    personaStore = await import(pathToFileURL(path.join(APP_ROOT, 'src', 'persona-store.js')).href);
  } catch (e) {
    personaStore = null;
    try { api?.warn?.('persona-store 不可用：多卡分账降级为默认卡', e?.message ?? e); } catch { /* 忽略 */ }
  }
  try {
    relTree = await import(pathToFileURL(path.join(APP_ROOT, 'src', 'memory-tree.js')).href);
  } catch (e) {
    relTree = null;
    try { api?.warn?.('memory-tree 不可用：judge 好感补账停用（P3），其余功能不受影响', e?.message ?? e); } catch { /* 忽略 */ }
  }
}

const STATE_FLUSH_MS = 5 * 60 * 1000;   // 状态快照：距上次 ≥5min 才写（惰性）
const MAX_MSG_SNIPPET = 40;             // JSONL 里消息摘要长度
const MAX_RESP_SNIPPET = 60;            // 回复摘要长度

/** personaId → profile 路径映射。不在此表的 persona 只记判定不施加（无 profile=无性格参数）。 */
const DEFAULT_PERSONA_ID = 'custom:467dcecf';   // 全局默认（合欢）——无绑定/配置缺失时回落
// C0（2026-10-06）：注册表外置——PERSONA_PROFILES 降级为内置兜底，运行时读
// data/plugins/emotion-core/profiles.json（{default, profiles:{pid: 路径或文件名}}，15s 软缓存）。
// 文件名相对 profiles/ 子目录；含 / 或 \ 视为绝对路径。这样新卡归档注册=写一个 JSON，
// 免改代码免重载（情绪工作台 G 的地基）。软缓存逻辑与社区分享包 loadPersonaProfiles 同款。
// 2026-10-08 完全移植：profile 资产平铺进 data/plugins/emotion-core/profiles/，
// 内置兜底表改用运行时拼路径，不再写死任何跨盘绝对路径。
const EMO_PROFILES_DIR = path.join(DATA_DIR, 'plugins', 'emotion-core', 'profiles');
const BUILTIN_PERSONA_PROFILES = {
  'custom:467dcecf': path.join(EMO_PROFILES_DIR, '合欢.json'),
    'custom:9cecadb7': path.join(EMO_PROFILES_DIR, '16-黎杳-妹系抑郁斯德哥尔摩型.json'),
    'custom:2f0b2227': path.join(EMO_PROFILES_DIR, '贴吧鱼-暴躁小鲸鱼.json'),
    'custom:5d6e4a9f': path.join(EMO_PROFILES_DIR, '百可花-害羞花骑士.json'),
    // 2026-09-30 T1：某群绑的猫尾草，此前整天 108 行留痕 / 施加 0（无 profile ⇒ ensureCoreFor return null）
    'custom:e6133161': path.join(EMO_PROFILES_DIR, '猫尾草-软乖猫娘.json'),
    // 2026-10-01：莉贝尔（傲娇书库管理员）——此前私聊 9 条判定全部 personaSkipped；desire 按卡面禁（禁恋爱脑直球），aggression 0.25~0.45 冷嘲线
    'custom:924472fc': path.join(EMO_PROFILES_DIR, '莉贝尔-傲娇书库管理员.json')
  };

const PERSONA_REGISTRY_FILE = path.join(DATA_DIR, 'plugins', 'emotion-core', 'profiles.json');
let PERSONA_CACHE = { at: 0, map: null };

function loadPersonaProfiles() {
  const now = Date.now();
  if (now - PERSONA_CACHE.at < 15000 && PERSONA_CACHE.map) return PERSONA_CACHE.map;   // 15s 软缓存
  let map = null;
  try {
    const j = JSON.parse(fs.readFileSync(PERSONA_REGISTRY_FILE, 'utf8'));
    map = {};
    const base = path.join(DATA_DIR, 'plugins', 'emotion-core', 'profiles');
    for (const [pid, p] of Object.entries(j.profiles || {})) {
      const s = String(p || '');
      map[pid] = s.includes('/') || s.includes('\\') ? s : path.join(base, s);
    }
  } catch { /* 无/坏注册文件 = 回落内置表 */ }
  if (!map || !Object.keys(map).length) map = BUILTIN_PERSONA_PROFILES;   // 空表兜底：绝不让全部卡掉线
  PERSONA_CACHE = { at: now, map };
  return map;
}
function personaProfiles() { return loadPersonaProfiles(); }

let api = null;
let cfgCache = () => ({});
let log = () => {};
let loadingModules = false;
let modulesReady = false;

let shadowFile = '';

/** hint 冷却记忆（personaId → {text, at}）。内存态：重载清零，不影响影子账。 */
const hintMemo = new Map();

/** personaId → { core, cardId, stateFile, lastFlush, loading, error } */
const cores = new Map();

function cfg() {
  const c = (api && typeof api.config === 'function' ? api.config() : null) || {};
  return {
    kernelDir: c.kernelDir || (bridge?.DEFAULT_KERNEL_DIR ?? path.join(PLUGIN_DIR, 'kernel')),
    minIntensity: Math.max(0, Math.min(1, Number(c.minIntensity) ?? 0.25)),
    snapshotEveryMs: Math.max(30000, Number(c.snapshotEveryMs) || STATE_FLUSH_MS),
    logResponses: c.logResponses !== false,
    logNeutral: c.logNeutral !== false,  // 影子期默认留痕中性/低强度（算漏判率用）
    // 🔴 hint 注入总开关（影子→hint 阶段，20260930）：默认关——影子期纪律「零注入」；
    //    用户拍板后 config 开 injectEnabled:true，走 before-llm-messages 热生效（无需重启）
    injectEnabled: c.injectEnabled === true,
    // ⚠️ Number(undefined)=NaN，而 NaN ?? 20 不触发空值合并（NaN 非 null）——必须用 isFinite 判
    injectMinLevel: Number.isFinite(Number(c.injectMinLevel)) ? Number(c.injectMinLevel) : 20,
    // 🔴 v1.9.4 A/B 白名单：非空时只对列表内 chatKey 注入（开闸 A/B 用，空/缺省=全部会话）
    injectAllowlist: Array.isArray(c.injectAllowlist) ? c.injectAllowlist.map(String) : null,
    // 🔴 v1.9.5 hint 同文案冷却（毫秒）：joy 高位期间同一句「些许欣喜…」逐轮重复注入
    // （18:1x 实测 3 分钟 8 次）——提示词复读。同文案在冷却窗口内不注，情绪文案变了
    // 立即放行（情绪转折不被冷却吃掉）；0=不冷却。冷却记忆是内存态，重载清零。
    hintCooldownMs: Number.isFinite(Number(c.hintCooldownMs)) ? Number(c.hintCooldownMs) : 600000
  };
}

function getConfigSafe() {
  try { return getConfig(); } catch { return null; }
}

/** 本地时区日期（toISOString 是 UTC——凌晨 0~8 点启动会把文件名定成前一天，跨天也不切）。 */
function localDay(ts = Date.now()) {
  const d = new Date(ts);
  const p = (n) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}`;
}

function ensureFiles() {
  const dir = path.join(DATA_DIR, 'plugins', 'emotion-core');
  fs.mkdirSync(dir, { recursive: true });
  shadowFile = path.join(dir, `shadow-${localDay()}.jsonl`);
}

// ── 首跑播种（2026-10-08 社区包方案 E）────────────────────────────────
// 社区包只装 plugins/，注册表与 profile 资产在 data/ 下不随包 ⇒ 首跑从插件内 seed/ 补齐。
// 🔴 只增不改：注册表存在、profile 文件已存在时一个字节都不碰（更新安装 / 现役重装安全）。
// export 供离线验收脚本直测（临时目录播种语义）。
export function seedIfEmpty() {
  const dataDir = path.join(DATA_DIR, 'plugins', 'emotion-core');
  const seedDir = path.join(PLUGIN_DIR, 'seed');
  let copied = 0;
  try {
    // ① 注册表：完全不存在时才写出厂版（default 卡映射见 seed/profiles.json 的 _comment）
    //    冷启动 data/plugins/emotion-core/ 可能不存在（setup 里 ensureFiles 先跑才兜底）——自建，别依赖调用方。
    fs.mkdirSync(dataDir, { recursive: true });
    const reg = path.join(dataDir, 'profiles.json');
    if (!fs.existsSync(reg)) {
      fs.copyFileSync(path.join(seedDir, 'profiles.json'), reg);
      copied += 1;
      PERSONA_CACHE = { at: 0, map: null };   // 立即失效软缓存，本轮就能读到播种结果
    }
    // ② profile JSON：逐张缺了才拷
    const pDir = path.join(dataDir, 'profiles');
    fs.mkdirSync(pDir, { recursive: true });
    const seedProfiles = path.join(seedDir, 'profiles');
    for (const name of fs.readdirSync(seedProfiles)) {
      const dst = path.join(pDir, name);
      if (!fs.existsSync(dst)) { fs.copyFileSync(path.join(seedProfiles, name), dst); copied += 1; }
    }
    if (copied) { try { log?.(`emotion-core 首跑播种：补齐 ${copied} 个文件（seed/ → data/plugins/emotion-core/）`); } catch { /* 忽略 */ } }
  } catch (e) {
    try { api?.warn?.('emotion-core 播种失败（不影响既有数据）', e?.message ?? e); } catch { /* 忽略 */ }
  }
  return copied;
}

function stateFileFor(personaId) {
  // 兼容：默认人设（无绑定回落/activeId 缺失）沿用旧 state.json；其他人设独立文件
  const active = getConfigSafe()?.persona?.activeId || DEFAULT_PERSONA_ID;
  if (!personaId || personaId === active) {
    return path.join(DATA_DIR, 'plugins', 'emotion-core', 'state.json');
  }
  const safe = String(personaId).replace(/[^a-zA-Z0-9]/g, '_');
  return path.join(DATA_DIR, 'plugins', 'emotion-core', `state-${safe}.json`);
}

/** 会话绑定的人设 ID（chatBindings 优先，回落全局 activeId）。读不到返回 ''。 */
function getChatPersona(chatKey) {
  try {
    const g = getConfigSafe();
    const legacy = String(g?.chatBindings?.[chatKey]?.persona || g?.persona?.activeId || '');
    if (legacy) return legacy;
    // 0.4.5 兼容（2026-10-06 人格归因修复）：洛版没有 chatBindings/activeId ——
    // 绑定在 personaByChat（键=裸号码，批1迁移写入），全局活动卡=config.persona；
    // 卡 id 在 customPersonas[].id（与 PERSONA_PROFILES 同一 id 空间，0.3.0 id 原样保留）。
    // 按会话生效的 roleText 反查卡 id；解析不到返回 ''，调用方按各自回落处理。
    // ⚠️ 修复前本函数恒返回 ''：钩子全部回落 DEFAULT_PERSONA_ID（合欢）——
    //    绑定猫尾草的群也在吃合欢的情绪档（影子账 76/76 全归因合欢，人设越界）。
    const cid = String(chatKey || '');
    const bare = cid.includes(':') ? cid.split(':').pop() : cid;
    const perChat = g?.personaByChat || {};
    const hit = perChat[bare] || perChat[cid];
    const roleText = String((hit && hit.roleText) ?? g?.persona?.roleText ?? '');
    if (!roleText) return '';
    const card = (g?.customPersonas || []).find((p) => String(p.text || '') === roleText);
    return String(card?.id || '');
  } catch { return ''; }
}

function appendShadow(obj) {
  try {
    // 跨天自动切换：日期按本地时区、每次写入时重算（此前启动时算死 + UTC，凌晨启动会把数据写进前一天的文件）
    const want = path.join(path.dirname(shadowFile), `shadow-${localDay()}.jsonl`);
    if (want !== shadowFile) {
      shadowFile = want;
      try { api?.log?.(`影子日志跨天：切换到 ${path.basename(want)}`); } catch { /* 忽略 */ }
    }
    fs.appendFileSync(shadowFile, JSON.stringify(obj) + '\n', 'utf8');
  } catch (e) {
    try { api?.warn?.('影子日志写入失败（不影响对话）', e?.message ?? e); } catch { /* 忽略 */ }
  }
}

/** v1.9.7 词表影子候选（老师/大人/老板/主公/大哥/呜呜/哭哭）——只进影子账 lexShadow 字段，不动判定。 */
function lexShadowOf(t) {
  try { return shadowMatchFn ? shadowMatchFn(t) : []; } catch { return []; }
}

/** 某人设实例的状态刷盘（惰性）。 */
function flushEntry(entry, force = false) {
  if (!entry || !entry.core || !entry.stateFile) return;
  const now = Date.now();
  if (!force && now - entry.lastFlush < cfg().snapshotEveryMs) return;
  try {
    writeJsonAtomic(entry.stateFile, { savedAt: now, cardId: entry.cardId, state: bridge.snapshotState(entry.core, now) }, 1);
    entry.lastFlush = now;
  } catch (e) {
    try { api?.warn?.('情绪状态落盘失败（不影响对话）', e?.message ?? e); } catch { /* 忽略 */ }
  }
}

function flushAll(force = false) {
  for (const entry of cores.values()) flushEntry(entry, force);
}

/** 异步装载某人设的内核实例（已就绪返回 entry；未就绪/失败返回 null，后续消息自动补上）。 */
function ensureCoreFor(personaId) {
  if (!personaId || !modulesReady) return null;
  const profilePath = personaProfiles()[personaId];
  if (!profilePath) return null;                     // 无 profile 的人设 → 只记判定不施加
  const existing = cores.get(personaId);
  if (existing) return existing.loading || existing.error ? null : existing;
  const entry = { core: null, cardId: '', personaId: String(personaId || ''), stateFile: stateFileFor(personaId), lastFlush: 0, loading: true, error: '' };
  cores.set(personaId, entry);
  (async () => {
    let prev = null;
    try {
      if (fs.existsSync(entry.stateFile)) {
        const j = JSON.parse(fs.readFileSync(entry.stateFile, 'utf8'));
        if (j?.state) prev = j.state;
      }
    } catch { prev = null; }
    const r = await bridge.createKernelInstance({ kernelDir: cfg().kernelDir, profilePath, state: prev });
    entry.core = r.core; entry.cardId = r.cardId; entry.loading = false;
    // 🔴 20261003 任务④：为实例挂 bridge-6d 桥（读方向：E 维残留 → baseline.mood）。
    // 内核不 import 宿主——六维接口由宿主（本插件）注入，契约见 bridge-6d.mjs 头部。
    if (bridge6d?.createBridge) {
      entry.bridge = bridge6d.createBridge(r.core, { scoreText, aggregate, snapshotFromText });
      entry.lastMoodPull = 0;
    }
    try { api?.log?.(`情绪内核已装载 [${personaId}]：${r.cardId}（judge ${judgeVersion}，${prev ? '状态已恢复' : '全新'}${entry.bridge ? '，bridge-6d 已挂' : ''}）`); } catch { /* 忽略 */ }
  })().catch((e) => {
    entry.loading = false; entry.error = String(e?.message ?? e);
    try { api?.error?.('情绪内核装载失败（不影响对话）', entry.error); } catch { /* 忽略 */ }
  });
  return null;
}

/** 某人设实例的状态快照摘要（JSONL 里的她当前状态）。 */
function brief(entry) {
  const v = entry.core.render(Date.now());
  return {
    levels: v.levels,
    dominant: v.dominant?.label || '平静',
    derived: (v.derived || []).map((d) => `${d.label}(${Math.round(d.intensity)})`)
  };
}

/**
 * hint 措辞映射（影子→hint 阶段）：把内核 render 的主导情绪翻译成一行注入文本。
 * 只在 dominant.level ≥ injectMinLevel 时产出（平静不废话，避免每轮打爆上下文）；
 * 恒拼「只影响语气不改变行为」约束句——防卡外行为（六维铁律六：情绪不改变行为方式）。
 */
function deriveHint(entry, minLevel) {
  let v;
  try { v = entry.core.render(Date.now()); } catch { return ''; }
  const dom = v?.dominant;
  if (!dom || !dom.label || dom.label === '平静' || !(dom.level >= minLevel)) return '';
  const head = `${dom.band || ''}${dom.label}`;
  const runner = dom.runnerUp && dom.runnerUp.label && dom.runnerUp.label !== '平静'
    ? `（另带一点${dom.runnerUp.label}）` : '';
  return `${head}${runner}。以上是角色此刻的内部情绪，只影响说话的语气与节奏，绝不改变行为方式与对人的距离感。`;
}

const MOOD_PULL_MS = 5 * 60 * 1000;   // 读方向节流：每实例 5 分钟拉一次 E 维聚合（mood 半衰 8h，粒度足够）

/**
 * 读方向（20261003 任务④）：E 维残留聚合 → core.state.baseline.mood。
 * 数据源 = emotion-shadow 维护的 data/memory/<人设>/_global/emotion.json（只读，绝不写——
 * 那边是内存 cache 全量覆盖刷盘，外部直写会被吞）。桶选择：当前会话桶优先
 * （她对这个会话的心境），没有当前桶则合并全部桶（心境跨会话连续）。
 * 只在 apply 前回灌才有意义：applyEvent 读 baseline.mood 做心境依存偏置（±30%）。
 */
function pullMood(chatKey, entry, now = Date.now()) {
  try {
    if (!entry?.bridge?.available || !entry.core) return;
    if (entry.lastMoodPull && now - entry.lastMoodPull < MOOD_PULL_MS) return;
    entry.lastMoodPull = now;
    const file = path.join(DATA_DIR, 'memory', currentMemoryKeyOf() || '_unknown', '_global', 'emotion.json');
    let entries = [];
    try {
      const raw = JSON.parse(fs.readFileSync(file, 'utf8'));
      const b = raw?.buckets?.[chatKey];
      if (Array.isArray(b?.entries)) entries = b.entries;
      else for (const bb of Object.values(raw?.buckets || {})) {
        if (Array.isArray(bb?.entries)) entries.push(...bb.entries);
      }
    } catch { return; }   // 无文件/解析失败 = 无 E 维数据，不动 baseline
    const r = entry.bridge.pullBaseline(entries, now);
    if (!r) return;
    stats.moodPulls = (stats.moodPulls || 0) + 1;
    // 留痕：mood 变化时才记（恒 0 的行只有噪声价值）
    if (r.mood !== 0) {
      appendShadow({ type: 'mood', at: now, chat: chatKey, personaId: entry.personaId,
        mood: r.mood, residue: r.residue, valence: r.valence, count: r.count });
    }
  } catch { /* 静默：读方向失败绝不影响判定 */ }
}

/**
 * 写方向（20261003 任务④）：judge 施加成功 + 词表对该文本 0 命中（补盲）→
 * judge 事件分借 capability('emotion.shadow.append') 入 emotion.json 对应桶。
 * 补盲闸是消除双计的关键：词表通道（emotion-shadow before-context）已采的文本
 * 不重采；judge 的独有盲区（代称摸摸/引用行/昵称爱抚）才由本通道补。
 * 🔴 红线：只进 emotion.json（状态账本），绝不碰 facts/events——E 维是状态不是事实。
 */
function bridgeWrite(chatKey, entry, j, text, senderId, now = Date.now()) {
  try {
    if (!chatKey || !entry?.core) return;
    if (typeof api?.capability !== 'function') return;
    const rec = {
      at: now,
      valence: Number(j.valence) || 0,
      intensity: Number(j.intensity) || 0,
      subject: senderId ? 'other' : null,
      snippet: text.slice(0, MAX_MSG_SNIPPET),
      src: 'emotion-core/judge'
    };
    if (senderId) rec.senderId = String(senderId);
    const r = api.capability('emotion.shadow.append', { chatKey, entry: rec });
    if (r && r.ok) {
      stats.bridgeWrites = (stats.bridgeWrites || 0) + 1;
      appendShadow({ type: 'bridge-write', at: now, chat: chatKey, personaId: entry.personaId,
        valence: rec.valence, intensity: rec.intensity, msg: rec.snippet });
    }
  } catch { /* 静默：写方向失败绝不影响判定 */ }
}

export function setup(a) {
  api = a;
  cfgCache = a.config;
  log = a.log;
  ensureFiles();
  seedIfEmpty();   // 首跑播种（2026-10-08 社区包方案 E）：只补缺失文件，绝不覆盖
  if (!loadingModules && !modulesReady) {
    loadingModules = true;
    loadModules()
      .then(() => {
        modulesReady = true; loadingModules = false;
        try { log?.(`emotion-core 模块就绪（judge ${judgeVersion}）`); } catch { /* 忽略 */ }
        // LLM v2 哨兵复核初始化（失败静默停用，不影响主流程）
        // 🔴 config 必须用全局 getConfigSafe()——api.config() 是插件 settings 节
        //   （plugin-loader.js:94 settingsOf），里面没有 webSearch.deepseek.apiKey，
        //   10-04 实测：用它初始化 ⇒ key 恒空 ⇒ 哨兵静默停用（影子账 0 行 llm-judge）。
        try {
          judgeLlmReady = judgeLlm.init({
            log, config: () => getConfigSafe() || {},
            appendShadow,
            cardNameResolver: (pid) => String((getConfigSafe()?.customPersonas || []).find((p) => p.id === pid)?.name || '')
          });
        } catch { judgeLlmReady = false; }
        // 🔴 v1.9.4：预热**全部已注册** persona（原只预热默认卡合欢）。宿主热重载会重建
        // 模块实例（plugin-loader 对 plugins/ 递归 watch + ?t= 重 import ⇒ cores 清空），
        // 未预热的卡在重载后首条判定会赶 loading 窗口 personaSkipped 一次（10-01 报告 §3 实测）。
        for (const pid of Object.keys(personaProfiles())) ensureCoreFor(pid);
      })
      .catch((e) => { loadingModules = false; try { api?.error?.('emotion-core 模块装载失败（影子停用，不影响对话）', e?.message ?? e); } catch { /* 忽略 */ } });
  }
  try { log?.('emotion-core 影子模式初始化（多人设分账；enabledByDefault=false，技能页手动开）'); } catch { /* 忽略 */ }
}

export function available() {
  // 🔴 必须同步：返回 Promise 会被当 truthy（技能页假绿）
  if (modulesReady) return true;
  if (loadingModules) return { ok: false, reason: '内核模块异步装载中（首次几秒内）' };
  return { ok: false, reason: '尚未初始化' };
}

export const hooks = {
  // ── hint 注入（影子→hint 阶段）：injectEnabled 默认关，开了才改 messages ──
  // 挂 before-llm-messages 而非 promptSections：promptSections 是系统提示的一部分，
  // 必须字节稳定（前缀缓存），而情绪状态每轮都变——这里就地追加一条临时 system 消息。
  'before-llm-messages'(ctx = {}) {
    try {
      if (!modulesReady) return;
      const c = cfg();
      if (c.injectEnabled !== true) return;
      // v1.9.4 A/B 白名单：只在列表内的会话注入（开闸期先圈一个群对照，跑稳再放开）
      if (Array.isArray(c.injectAllowlist) && c.injectAllowlist.length
        && !c.injectAllowlist.includes(String(ctx?.chatKey || ''))) return;
      const chatKey = String(ctx?.chatKey || '');
      const personaId = getChatPersona(chatKey) || DEFAULT_PERSONA_ID;
      const entry = cores.get(personaId);
      if (!entry || !entry.core) return;
      const text = deriveHint(entry, c.injectMinLevel);
      if (!text) return;
      // 🔴 v1.9.5 同文案冷却：同一情绪文案在 hintCooldownMs 内不重复注（防提示词复读）；
      // 文案变了（情绪转折）立即放行。
      const memo = hintMemo.get(personaId);
      if (c.hintCooldownMs > 0 && memo && memo.text === text
        && Date.now() - memo.at < c.hintCooldownMs) {
        stats.hintCooldownSkipped = (stats.hintCooldownSkipped || 0) + 1;
        return;
      }
      hintMemo.set(personaId, { text, at: Date.now() });
      const messages = ctx?.messages;
      if (!Array.isArray(messages) || !messages.length) return;
      messages.push({ role: 'system', content: `【当前状态】\n${text}` });
      stats.hintInjected = (stats.hintInjected || 0) + 1;
      // 🔴 v1.9.5 A/B 观测留痕：注入在影子账记一行（内容+时刻+会话），否则开闸效果
      // 只能靠「看她回得像不像」主观判断。行量可控：平静不注入（deriveHint 返回空）。
      try {
        appendShadow({ type: 'hint', at: Date.now(), chat: chatKey, personaId, text });
      } catch { /* 留痕失败不影响注入 */ }
    } catch { /* 静默：注入失败不影响对话 */ }
  },

  'before-context'(ctx = {}) {
    try {
      if (!modulesReady || !judgeFn) return;
      const c = cfg();
      const chatKey = String(ctx?.chatKey || '');
      const entries = Array.isArray(ctx?.triggerEntries) ? ctx.triggerEntries : [];
      const now = Date.now();

      // 🔴 20261003 任务④ 读方向：本会话判定开始前，先把 E 维残留聚合成心境回灌
      // baseline.mood——applyEvent 读它做心境依存偏置，回灌必须发生在 apply 之前。
      const prePersonaId = getChatPersona(chatKey) || DEFAULT_PERSONA_ID;
      pullMood(chatKey, cores.get(prePersonaId), now);

      for (const e of entries) {
        if (!e || e.self === true) continue; // 只判别人说的（她对镜像自己的话不产生情绪）
        const text = String(e?.text ?? e?.content ?? '').trim();
        if (!text) continue;
        // 本会话的人设归属：neutral/skipped-low 也要带（否则分账统计漏掉中性/漏判行）
        const chatPersonaId = getChatPersona(chatKey) || DEFAULT_PERSONA_ID;
        // 其他角色卡名（排除本卡）：judge 用它做第三方指向检测——给别人的爱不能记本卡账上
        const otherNames = (getConfigSafe()?.customPersonas || [])
          .filter((p) => p.name && p.id !== chatPersonaId)
          .map((p) => String(p.name));
        // v1.9.2：本卡名（judge 的「动词+角色名」爱抚通道要用——「揉揉猫尾草的头」；
        // judge 内部保证 selfName 只进爱抚通道、不进 thirdParty 检测）
        // 🔴 v1.9.4：selfName 升级为数组——追加 botName（QQ 昵称），群友「@小鲸鱼 摸摸」
        // 用昵称不掐卡名，此前抓不到（10-01 报告漏判第一族）。
        const selfNames = [
          String((getConfigSafe()?.customPersonas || []).find((p) => p.id === chatPersonaId)?.name || ''),
          String(getConfigSafe()?.botName || '')
        ].filter(Boolean);
        const j = judgeFn(text, otherNames, selfNames);
        stats.judged += 1;
        // 🔴 LLM v2 哨兵（20261003 对拍期）：边界样本异步复核，只写影子账不改判定。
        // 触发=a)判null但有情感信号 b)desire/tp/attribution 命中 c)5%抽样。
        try {
          if (judgeLlmReady && judgeLlm.shouldReview(j, text)) {
            judgeLlm.enqueue({
              text, chat: chatKey, personaId: prePersonaId,
              ruleJudge: j ? { branch: j.branch, valence: j.valence, intensity: j.intensity, desire: j.desire === true, thirdParty: j.thirdParty === true } : null
            });
          }
        } catch { /* 静默：哨兵失败不影响判定 */ }
        if (!j) {
          stats.skippedNeutral += 1;
          // 影子期留痕：中性判定也记录（否则算不出漏判率）。审完可由 logNeutral:false 关掉。
          if (cfg().logNeutral !== false) {
            appendShadow({ type: 'neutral', at: now, chat: chatKey, personaId: chatPersonaId || undefined, lexShadow: lexShadowOf(text), msg: text.slice(0, MAX_MSG_SNIPPET) });
          }
          continue;
        }
        if (j.intensity < c.minIntensity && !j.desire && !j.thirdParty) {
          stats.skippedNeutral += 1;
          if (cfg().logNeutral !== false) {
            appendShadow({ type: 'skipped-low', at: now, chat: chatKey, personaId: chatPersonaId || undefined, judge: j, lexShadow: lexShadowOf(text), msg: text.slice(0, MAX_MSG_SNIPPET) });
          }
          continue;
        }

        // 多人设分流：本会话绑的人设有没有 profile？（无绑定回落默认）
        const personaId = chatPersonaId;
        const entry = ensureCoreFor(personaId);
        // 🔴 第三方指向（v1.7 引入；v1.9.1 判据放宽）：这份情绪是给别人卡的（如「我爱你，百可花」），
        // 只留痕不落账——错账（把给别人的爱记本卡头上）比漏账危害大，影子期宁漏勿误。
        // v1.9.1：judge 侧已把 thirdParty 合一收窄（正向/亲密 + 卡名或词表命中），词表路径
        // thirdPartyName=null 但同样该拦——判据从 (thirdParty && thirdPartyName) 放宽为 thirdParty。
        if (j.thirdParty) {
          stats.skippedThirdParty = (stats.skippedThirdParty || 0) + 1;
          appendShadow({
            type: 'judge', at: now, chat: chatKey, judgeVersion,
            personaId: personaId || undefined, thirdPartyOf: j.thirdPartyName,
            lexShadow: lexShadowOf(text),
            msg: text.slice(0, MAX_MSG_SNIPPET),
            judge: { ...j }, applied: [], blocked: ['third-party']
          });
          continue;
        }

        // 【P3 20261003】judge 语义事件 → 记忆树好感补账（放在情绪 profile 检查之前：
        // 好感账不依赖情绪内核 profile，无 profile 的卡也要记）。方向闸在本侧：
        // praise/insult 须文本命中本卡名/botName（@保护前原文）；touch 另许裸爱抚
        // （v1.9.2 拍板语义：能进判定链的裸「摸摸」几乎必指向她）。方向不可归因 ⇒
        // 带_null direction 进 treeReceiveVerdict → 被丢弃只记影子账（宁缺毋反）。
        // 【p3fix 20261003】影子账首日实测三处修正：
        // ① memoryKey 用 personaForChat().memoryKey（树空间 p_xxx），原传 chatPersonaId
        //    是 config 空间 custom:xxx——两套 id 空间，judge 账会记错树；
        // ② 私聊(private:*)1:1 无歧义 ⇒ 方向直接放行——私聊夸人不带名字，
        //    nameHit 闸把影子账首日 18/18 judge 全拦成 no-direction（实测数据）；
        // ③ 时间字段是 e.ts（entry 真实字段），原 e.at 不存在恒回落 now。
        if (j.relType) {
          const nameHit = selfNames.some((n) => n && text.includes(n));
          const isPrivate = String(chatKey).startsWith('private:');
          const toSelf = isPrivate || (j.relType === 'touch' ? (nameHit || j.bareAffection) : nameHit);
          const mkTree = personaInfoOf(chatKey, { senderId: String(e?.senderId || '') }).memoryKey || '';
          try {
            // 🔴 双护栏（2026-10-08 社区包解耦）：relTree 缺失（官方原版）或 memoryKey 为空
            //    （persona-store 降级）都跳过补账——树空间定位不到就是写不进，硬调只会炸。
            if (relTree?.treeReceiveVerdict && mkTree) relTree.treeReceiveVerdict({
              userId: String(e?.senderId || ''), name: String(e?.senderName || e?.name || ''),
              chatKey, memoryKey: mkTree, at: Number(e?.ts) || now,
              type: j.relType, text,
              direction: toSelf ? { from: String(e?.senderId || ''), to: 'self' } : null
            });
          } catch { /* 补账失败不影响回复 */ }
        }
        if (!entry || !entry.core) {
          stats.skippedPersona += 1;
          // 只记判定不施加（无 profile=无性格参数；或实例装载中——下轮消息自动补上）
          appendShadow({
            type: 'judge', at: now, chat: chatKey, judgeVersion,
            personaId: personaId || undefined, personaSkipped: true,
            lexShadow: lexShadowOf(text),
            msg: text.slice(0, MAX_MSG_SNIPPET),
            judge: { ...j, desireNote: j.desire ? '未施加（无实例，下轮补上）' : undefined },
            applied: [], blocked: []
          });
          continue;
        }

        // 🔴 desire 放开（2026-10-03 用户拍板，I9 审计 `desire放开审计-20261003.md`）：
        // 158 条影子判定质量过关（私聊负向 0/tp 分流 0）。生效范围由 profile I9 台账决定——
        // 合欢/黎杳/百可花 confirmed=true 即刻生效；猫尾草(false)/莉贝尔·贴吧鱼(未签)
        // 的 desire 原子数学上不可达（atoms.mjs enabledByDefault=false + I9 闸门）。
        const ev = {
          branch: j.branch, time: j.time,
          valence: j.valence, intensity: j.intensity,
          attribution: j.attribution, thirdParty: j.thirdParty,
          desire: j.desire === true
        };
        const r = entry.core.apply(ev, now);
        stats.applied += 1;
        // 🔴 20261003 任务④ 写方向：judge 施加成功 + 词表 0 命中（补盲闸，消除双计）
        // → judge 事件分补进 emotion.json 桶，让 E 维聚合也吃到词表盲区的情绪事件。
        if (r.applied.length > 0 && scoreText(text).intensity === 0) {
          bridgeWrite(chatKey, entry, j, text, String(e?.senderId || ''), now);
        }
        appendShadow({
          type: 'judge', at: now, chat: chatKey, judgeVersion,
          personaId: personaId || undefined,
          lexShadow: lexShadowOf(text),
          msg: text.slice(0, MAX_MSG_SNIPPET),
          judge: { ...j, desireNote: j.desire ? '已生效（I9 已签卡；未签卡由内核钳制）' : undefined },
          applied: r.applied, blocked: r.blocked,
          state: brief(entry)
        });
      }
      flushAll();
    } catch (e) {
      try { api?.warn?.('情绪影子采集失败（已跳过本批，不影响回复）', e?.message ?? e); } catch { /* 忽略 */ }
    }
  },

  'after-response'(ctx = {}) {
    try {
      respStats.seen += 1;
      if (!modulesReady || !cfg().logResponses) return;
      // 宿主传的是 { response, session }（原始 OpenAI 响应对象），文本在 response.message.content
      const resp = ctx?.response;
      let text = '';
      if (typeof resp?.message?.content === 'string') text = resp.message.content;
      else if (typeof ctx?.text === 'string') text = ctx.text; // 兼容：测试/其他宿主形态
      text = text.trim();
      if (!text) { respStats.empty += 1; return; }
      appendShadow({
        type: 'response', at: Date.now(), chat: String(ctx?.chatKey || ''),
        text: text.slice(0, MAX_RESP_SNIPPET)
      });
      flushAll();
    } catch (e) {
      // v1.2 诊断：response 记录消失之谜的排查计数（首错 warn，后续静默计数）
      respStats.errors += 1;
      if (respStats.errors === 1) {
        try { api?.warn?.('情绪影子 after-response 记录失败（首次，后续静默计数）', e?.message ?? e); } catch { /* 忽略 */ }
      }
    }
  },

  // 惰性刷盘的第二触发点（emotion-shadow 同款：避免尾部丢失）
  'after-tool'() {
    try { flushAll(); } catch { /* 忽略 */ }
  }
};

// after-response 诊断计数（respSeen/respEmpty/respErrors）——2026-09-29 16:39 后 response
// 记录消失之谜的排查面；热重载自愈后保留计数防复发。
const respStats = { seen: 0, empty: 0, errors: 0 };

// 采集统计（聚合所有人设实例）
const stats = { judged: 0, applied: 0, skippedNeutral: 0, skippedNoCore: 0, skippedPersona: 0, errors: 0 };

/** 能力出口（影子期主要给测试/对拍脚本用；无核心调用方，命名防僵尸：见 emotion-shadow 先例）。 */
export const providers = {
  'emotion-core.snapshot': (ctx = {}) => {
    try {
      if (!modulesReady) return undefined;
      // 面板无 ctx.chatKey → 补默认回落（与钩子路径一致），否则整份快照 undefined、
      // 情绪页永远空（2026-10-06 实测：预装载明明成功，面板却一张卡都看不到）。
      const personaId = getChatPersona(String(ctx?.chatKey || '')) || DEFAULT_PERSONA_ID;
      const entry = cores.get(personaId);
      if (!entry?.core) return undefined;
      const b = brief(entry);
      const cfgNow = cfg();
      // 🔴 v0.2.0 面板数据面：values=默认人设扁平值（live-panel schema 按 key 取）
      // + cards=全部已装载实例（live-panel rawValues 透传后，情绪页按全卡视角渲染）
      const cards = [];
      // v0.2.2：顶层镜像默认卡（entry）的 derivedMap（emotion-shadow 采样 jealous 用）。
      // 🔴 作用域纪律：derivedMap 的 let 在 for 块内，块外不可见——顶层引用必须在循环里
      //    显式捕获（00:1x 探针实测抓过 ReferenceError，catch 吞掉后整份快照 undefined）
      let topDerivedMap = {};
      for (const [pid, e] of cores) {
        if (!e?.core) continue;
        const bb = brief(e);
        const nm = String((getConfigSafe()?.customPersonas || []).find((p) => p.id === pid)?.name || pid);
        // v0.2.1：bridge-6d 心境底色（E 维残留聚合回灌值，-100~100）随卡展示
        // v0.2.2：派生强度结构化（id→intensity）——emotion-shadow 采样 jealous 字段用
        let derivedMap = {};
        try {
          derivedMap = Object.fromEntries(
            e.core.render(Date.now()).derived.map((d) => [d.id, Math.round(d.intensity)])
          );
        } catch { /* 忽略 */ }
        if (e === entry) topDerivedMap = derivedMap;
        cards.push({ personaId: pid, name: nm, dominant: bb.dominant, derived: bb.derived, levels: bb.levels,
          mood: Number(e.core.state?.baseline?.mood) || 0, derivedMap });
      }
      const L = b.levels || {};
      return {
        at: Date.now(),
        values: {
          dominant: b.dominant || '平静',
          derivedText: (b.derived || []).join('、'),
          injectState: cfgNow.injectEnabled ? '开（全卡）' : '关',
          judgeVersion,
          hintInjected: stats.hintInjected || 0,
          hintCooldownSkipped: stats.hintCooldownSkipped || 0,
          moodPulls: stats.moodPulls || 0,
          bridgeWrites: stats.bridgeWrites || 0,
          bridge6d: bridge6d ? '已挂' : '未装载',
          cardCount: cards.length,
          joy: L.joy ?? 0, sad: L.sad ?? 0, hope: L.hope ?? 0, unease: L.unease ?? 0,
          longing: L.longing ?? 0, regard: L.regard ?? 0, desire: L.desire ?? 0,
          stir: L.stir ?? 0, energy: L.energy ?? 0,
          // 🔴 cards 必须放在 values **内部**：live-panel 的 fetchValues 只保留 r.values，
          // 顶层 cards 会被丢弃（12:19 实测踩过；derivedMap 重构 Edit 时又把本键冲丢过
          // 一次——00:1x 探针复抓。UI 全卡视角读 values.cards，缺了它情绪页只剩 schema 降级）。
          cards,
          // v0.2.2：顶层镜像默认卡的 derivedMap（emotion-shadow 采样 jealous 用）
          derivedMap: topDerivedMap
        },
        // —— 以下字段为 v0.1 旧形状，保留向后兼容 ——
        cardId: entry.cardId, personaId, judgeVersion,
        respStats: { ...respStats }, hintInjected: stats.hintInjected || 0,
        ...b
      };
    } catch (e) { api?.warn?.('emotion-core.snapshot 构建失败（面板降级）', e?.message ?? e); return undefined; }
  }
};

/** 离线诊断/测试用。 */
export function debugStats() {
  const list = [];
  for (const [pid, e] of cores) list.push({ personaId: pid, cardId: e.cardId, ready: !!e.core, loading: e.loading, error: e.error });
  return { judgeVersion, modulesReady, bridge6d: bridge6d ? 'loaded' : 'missing',
    llmSentinel: judgeLlm ? judgeLlm.debugStats() : 'missing',
    respStats: { ...respStats }, stats: { ...stats }, personas: list, shadowFile };
}

export function dispose() {
  try { flushAll(true); } catch { /* 忽略 */ }
}

export default { setup, available, hooks, providers, debugStats, dispose };

// watch-reload probe 20261004
