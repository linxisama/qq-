// 〔状态面板〕—— R18 管理 + 情绪内核 + 好感度（2026-10-06 从 0.3.0 移植）
//
// 三个块的来源：
//   ① R18 管理 —— 新写（0.3.0 的按卡开关 + 全局范围/白名单，接口 /api/persona-nsfw）。
//   ② 情绪内核 —— 0.3.0「情绪页」原样移植，数据源 /api/live-panel?skill=emotion-core。
//   ③ 好感度 —— 0.3.0「好感页」原样移植，数据源 /api/memory-tree?all=1（+ /api/chats 取群名）。
// 心情页（mood-chain）按用户拍板**不做**：该系统将被新情绪系统替代。
//
// 放进设置页的原因：0.4.5 的设置分区是"用户脑子里的任务"合并制，状态查看属于
// 低频观察动作，不值得占顶栏一个一级页面。本文件只画，不碰表单保存链路
// （live/树面板是只读的，R18 块自己走 /api/persona-nsfw，不进 saveConfig 的
// "收集所有 input 再 POST"——否则会把只读字段当配置项写回空串）。
'use strict';

// ── 分区骨架 ─────────────────────────────────────────────────────────────
// 由 06-settings-render.js 的 sections.status 调用；只给容器，数据异步填。
function renderStatusSection() {
  return `
  <div class="mood-wrap">
    <div class="mood-head">
      <h2>R18 / 分寸管理</h2>
      <span class="mood-spacer"></span>
      <button class="btn btn-small" id="st-nsfw-refresh">刷新</button>
    </div>
    <div id="st-nsfw"><div class="mood-empty">正在加载…</div></div>

    <div class="mood-head" style="margin-top:34px">
      <h2>情绪内核</h2>
      <span class="mood-spacer"></span>
      <button class="btn btn-small" id="st-emo-refresh">刷新</button>
    </div>
    <div id="st-emo"><div class="mood-empty">正在加载…</div></div>

    <div class="mood-head" style="margin-top:34px">
      <h2>好感度</h2>
      <span class="mood-spacer"></span>
      <button class="btn btn-small" id="st-wr-refresh">刷新</button>
    </div>
    <div id="st-warmth"><div class="mood-empty">正在加载…</div></div>

    <div class="mood-note">情绪/好感为只读面板：数值由本地算出（零 token），停留本页时 10 秒自动刷新；
R18 为可写配置，改动即时落盘生效。心情（mood-chain）面板按拍板不做——将被新情绪系统替代。</div>
  </div>`;
}

// 由 07-settings-events.js 的 bindSettingsEvents 末尾调用（非本分区时容器不存在，全部空操作）。
function bindStatusPanel() {
  const box = $('#settings-form');
  if (!box || !box.querySelector('#st-nsfw')) return;
  loadNsfwPanel();
  loadEmoPanel();
  loadWarmthPanel();
  $('#st-nsfw-refresh')?.addEventListener('click', () => loadNsfwPanel());
  $('#st-emo-refresh')?.addEventListener('click', () => loadEmoPanel());
  $('#st-wr-refresh')?.addEventListener('click', () => loadWarmthPanel());
  // 停留本分区时 10 秒自动刷新（情绪 + 好感；R18 是配置，手动刷新即可）
  try { clearInterval(statusTimer); } catch { /* 忽略 */ }
  statusTimer = setInterval(() => {
    if (state.tab === 'settings' && state.settingsSection === 'status') {
      loadEmoPanel();
      loadWarmthPanel();
    } else { clearInterval(statusTimer); statusTimer = null; }
  }, STATUS_TICK_MS);
}
let statusTimer = null;
const STATUS_TICK_MS = 10000;

// ══════════════════════════════════════════════════════════════════════════
// ① R18 管理（新写；0.3.0 ui/app.js:3577 按卡开关 + 6022-6053 全局范围 的合体）
// ══════════════════════════════════════════════════════════════════════════

async function loadNsfwPanel() {
  const box = $('#st-nsfw');
  if (!box) return;
  let d;
  try {
    d = await api('/api/persona-nsfw');
  } catch (e) {
    box.innerHTML = `<div class="mood-empty">读取失败：${esc(String(e?.message || e))}</div>`;
    return;
  }
  const g = d.global || {};
  const showWl = g.nsfw && g.nsfwScope === 'whitelist';
  const cards = d.cards || [];
  box.innerHTML = `
    <div class="mood-cards">
      <div class="mood-card wide">
        <div class="checkbox-row" style="display:flex;gap:8px;align-items:center">
          <input type="checkbox" id="st-nsfw-on" ${g.nsfw ? 'checked' : ''} />
          <label for="st-nsfw-on" style="cursor:pointer">成人向对话（R18）总开关</label>
          <span class="mood-desc" style="margin:0">开关解除的是"回避"，不是"红线"：未成年 / 非自愿 / 真实个人信息三条红线写死在提示词里，任何开关都解不掉。</span>
        </div>
        <div class="field" id="st-nsfw-scope-box" style="margin-top:12px;${g.nsfw ? '' : 'display:none'}">
          <label>生效范围</label>
          <select id="st-nsfw-scope">
            <option value="private"${g.nsfwScope === 'private' ? ' selected' : ''}>仅私聊</option>
            <option value="all"${g.nsfwScope === 'all' ? ' selected' : ''}>全部会话（含群聊，慎选）</option>
            <option value="whitelist"${g.nsfwScope === 'whitelist' ? ' selected' : ''}>白名单</option>
          </select>
        </div>
        <div class="field" id="st-nsfw-wl-box" style="margin-top:10px;${showWl ? '' : 'display:none'}">
          <label>白名单（逗号分隔）</label>
          <input type="text" id="st-nsfw-wl" value="${esc((g.nsfwWhitelist || []).join(', '))}" placeholder="group:123456, private:987654" />
        </div>
        <div class="hint mood-desc" id="st-nsfw-wl-hint" style="${showWl ? '' : 'display:none'}">只在这里列出的会话里解除回避，其余会话照常回避。写 <code>group:群号</code> 或 <code>private:QQ号</code>；只写号码（如 <code>123456</code>）则群和私聊都算命中。</div>
        <div class="hint mood-desc" id="st-nsfw-scope-hint" style="${g.nsfw ? '' : 'display:none'}">群聊里发这类内容容易违规并影响群，除非确认群成员都是成年人且群规允许，否则保持"仅私聊"或改用白名单。</div>
      </div>
    </div>
    <div class="mood-h3">按卡开关（独立于其他卡；对绑定了这张卡的会话生效，活动卡同步全局镜像）</div>
    <div class="mood-cards">
      ${cards.map((c) => `
        <div class="mood-card">
          <div class="checkbox-row" style="display:flex;gap:8px;align-items:center">
            <input type="checkbox" class="st-card-nsfw" data-index="${c.index}" id="st-card-${c.index}" ${c.nsfw ? 'checked' : ''} />
            <label for="st-card-${c.index}" style="cursor:pointer" title="${esc(c.name)}">${esc(c.name)}</label>
          </div>
          <div class="mood-desc">${c.nsfw ? 'R18 已开' : '未开'}</div>
        </div>`).join('')}
    </div>`;

  const syncBoxes = () => {
    const on = !!$('#st-nsfw-on')?.checked;
    const scope = $('#st-nsfw-scope')?.value || 'private';
    $('#st-nsfw-scope-box').style.display = on ? '' : 'none';
    $('#st-nsfw-scope-hint').style.display = on ? '' : 'none';
    $('#st-nsfw-wl-box').style.display = (on && scope === 'whitelist') ? '' : 'none';
    $('#st-nsfw-wl-hint').style.display = (on && scope === 'whitelist') ? '' : 'none';
  };
  $('#st-nsfw-on')?.addEventListener('change', syncBoxes);
  $('#st-nsfw-scope')?.addEventListener('change', syncBoxes);

  const saveGlobal = async () => {
    const wl = ($('#st-nsfw-wl')?.value || '').split(',').map((s) => s.trim()).filter(Boolean);
    try {
      await api('/api/persona-nsfw', { method: 'POST', body: JSON.stringify({
        target: 'global',
        nsfw: !!$('#st-nsfw-on')?.checked,
        nsfwScope: $('#st-nsfw-scope')?.value || 'private',
        nsfwWhitelist: [...new Set(wl)]
      }) });
      loadNsfwPanel();
    } catch (e) { qaAlert(`保存失败：${e.message}`); }
  };
  $('#st-nsfw-on')?.addEventListener('change', () => { syncBoxes(); saveGlobal(); });
  $('#st-nsfw-scope')?.addEventListener('change', () => { syncBoxes(); saveGlobal(); });
  $('#st-nsfw-wl')?.addEventListener('change', saveGlobal);
  box.querySelectorAll('.st-card-nsfw').forEach((b) => b.addEventListener('change', async () => {
    b.disabled = true;
    try {
      await api('/api/persona-nsfw', { method: 'POST', body: JSON.stringify({
        index: Number(b.dataset.index), nsfw: b.checked
      }) });
      loadNsfwPanel();
    } catch (e) {
      b.disabled = false;
      qaAlert(`保存失败：${e.message}`);
    }
  }));
}

// ══════════════════════════════════════════════════════════════════════════
// ② 情绪内核（0.3.0 情绪页 loadEmoPage/renderEmoPage 原样移植，仅换容器）
// ══════════════════════════════════════════════════════════════════════════

const EMO_ATOMS = [
  ['joy', '欣喜'], ['sad', '低落'], ['hope', '期盼'], ['unease', '不安'],
  ['longing', '眷恋'], ['regard', '敬服'], ['stir', '悸动'], ['energy', '精神'],
  ['desire', '欲念']
];

async function loadEmoPanel() {
  const box = $('#st-emo');
  if (!box) return;
  let data;
  try {
    data = await api('/api/live-panel?skill=emotion-core');
  } catch (e) {
    box.innerHTML = `<div class="mood-empty">读取失败：${esc(String(e?.message || e))}</div>`;
    return;
  }
  renderEmoPanel(data);
}

function emoCardHtml(c) {
  const levels = (c && c.levels) || {};
  const derived = Array.isArray(c.derived) ? c.derived : [];
  const atoms = EMO_ATOMS.map(([k, label]) => {
    const v = Number(levels[k]);
    const has = Number.isFinite(v);
    const pct = has ? Math.max(0, Math.min(100, v)) : null;
    const val = has ? `<b class="mood-num">${Math.round(v * 10) / 10}</b>` : '<span class="mood-missing">—</span>';
    const bar = has ? `<div class="mood-bar"><div class="mood-bar-fill" style="width:${pct.toFixed(1)}%"></div></div>` : '';
    return `<div class="mood-card"><div class="mood-label">${esc(label)} ${esc(k)}</div>${val}${bar}</div>`;
  }).join('');
  const derHtml = derived.length
    ? `<div class="mood-note">派生：${esc(derived.join('、'))}</div>`
    : '';
  return `<div class="mood-h3">${esc(c.name || c.personaId || '未命名卡')}</div>
    <div class="mood-cards">
      <div class="mood-card wide"><div class="mood-label">主导情绪</div><span class="mood-text">${esc(c.dominant || '平静')}</span></div>
    </div>
    <div class="mood-cards">${atoms}</div>
    ${derHtml}`;
}

function renderEmoPanel(d) {
  const box = $('#st-emo');
  if (!box) return;
  const at = d.at ? new Date(d.at).toLocaleTimeString('zh-CN', { hour12: false }) : '—';
  const badges = [];
  if (!d.available) badges.push('<span class="skills-badge bad">取不到数值</span>');
  else if (d.stale) badges.push('<span class="skills-badge warn">插件未生效 · 显示磁盘上最后一刻的值</span>');
  else badges.push('<span class="skills-badge ok">生效中</span>');
  if (!d.enabled) badges.push('<span class="skills-badge warn">已禁用</span>');
  const why = [];
  if (d.reason) why.push(d.reason);
  if (d.error) why.push(d.error);
  const whyHtml = why.length
    ? `<div class="mood-note warn">看不到数值的原因：${esc(why.join('；'))}</div>` : '';

  const snap = d.rawValues && d.rawValues['emotion-core.snapshot'];
  const cards = snap && Array.isArray(snap.cards) ? snap.cards : [];
  // 空态要说话：cards=0 时若是"没有实例"而不是"故障"，直接讲清楚，
  // 否则一排「—」会被读成"未生效"（2026-10-06 用户实测反馈）。
  // host 是 v1.1（有 rawValues 键）时不再降级渲染 schema 扁平组 —— 那只是
  // 默认卡镜像且此刻全为 '—'，解释文字比一排占位符有用得多。
  const cardsHtml = cards.length
    ? cards.map(emoCardHtml).join('')
    : (snap
      ? '<div class="mood-empty">还没有任何卡装载情绪实例 —— 情绪内核是<b>按需装载</b>的：' +
        '某张卡收到第一条消息后，它的情绪实例才会建立并出现在这里。' +
        (d.enabled === false ? '另外：插件当前处于禁用状态。' : '') +
        '</div>'
      : (statusGroupsHtml(d) || '<div class="mood-empty">读取不到快照（host 无 rawValues 透传，见「为什么看不到」）。</div>'));
  const statsHtml = snap
    ? `<div class="mood-note">judge ${esc(snap.judgeVersion || '—')} · 注入开闭：${esc(snap.values?.injectState || '—')} · 累计注入 ${esc(String(snap.values?.hintInjected ?? '—'))} 次 · 冷却跳过 ${esc(String(snap.values?.hintCooldownSkipped ?? '—'))} 次</div>`
    : '';

  box.innerHTML = `
    <div class="mood-head" style="margin-bottom:10px">
      <span class="mood-at muted">emotion-core · ${esc(at)}</span>
      ${badges.join('')}
    </div>
    ${whyHtml}
    ${cardsHtml}
    ${statsHtml}`;
}

function statusGroupsHtml(d) {
  const groups = Array.isArray(d.groups) ? d.groups : [];
  if (!groups.length) return '';
  return groups.map((g) => `
    <div class="mood-h3">${esc(g.name)}</div>
    <div class="mood-cards">${(g.items || []).map(moodItemHtml).join('')}</div>`).join('');
}

function moodItemHtml(it) {
  const isText = it.pct === null;
  let shown = String(it.value ?? '');
  const val = it.missing
    ? '<span class="mood-missing">—</span>'
    : (isText ? `<span class="mood-text">${esc(shown || '—')}</span>` : `<b class="mood-num">${esc(shown)}</b>`);
  const bar = (it.pct === null || it.missing)
    ? ''
    : `<div class="mood-bar"><div class="mood-bar-fill ${esc(it.state || '')}" style="width:${Number(it.pct).toFixed(1)}%"></div></div>`;
  const desc = it.description ? `<div class="mood-desc">${esc(it.description)}</div>` : '';
  return `<div class="mood-card${it.wide ? ' wide' : ''}">
      <div class="mood-label">${esc(it.label)}</div>
      ${val}${bar}${desc}
    </div>`;
}

// ══════════════════════════════════════════════════════════════════════════
// ③ 好感度（0.3.0 好感页 loadWarmthPage/renderWarmthPage/wrDetailHtml/wrAdminHtml
//    原样移植；数据源已桶化：/api/memory-tree?all=1 的 memoryKey = personaKey 桶）
// ══════════════════════════════════════════════════════════════════════════

const WARMTH_BAND_COLOR = {
  trusted: 'var(--red, #d94f5c)',
  close: 'var(--orange, #d97f2f)',
  familiar: 'var(--accent, #3272c4)',
  acquainted: '#64748b',
  stranger: '#9aa1ab'
};

function wrAgo(t) {
  if (!t) return '—';
  const m = Math.floor((Date.now() - t) / 60000);
  if (m < 1) return '刚刚';
  if (m < 60) return m + ' 分钟前';
  if (m < 1440) return Math.floor(m / 60) + ' 小时前';
  return Math.floor(m / 1440) + ' 天前';
}
function wrFmtT(t) {
  const d = new Date(t);
  const z = (n) => String(n).padStart(2, '0');
  return z(d.getMonth() + 1) + '-' + z(d.getDate()) + ' ' + z(d.getHours()) + ':' + z(d.getMinutes());
}
function wrChatLabel(ck, names) {
  if (names && names[ck]) return names[ck];
  const m = /^(group|private):(\d+)$/.exec(ck || '');
  if (!m) return ck || '';
  return (m[1] === 'group' ? '群 ' : '私聊 ') + m[2];
}
function wrSpark(log) {
  const pts = (log || []).slice(-24);
  if (pts.length < 2) return '';
  const vs = pts.map((x) => Number(x.v) || 0);
  const min = Math.min.apply(null, vs), max = Math.max.apply(null, vs), span = Math.max(1, max - min);
  const W = 240, H = 36;
  const xy = pts.map((p, i) =>
    (i / (pts.length - 1) * W).toFixed(1) + ',' + (H - 4 - ((Number(p.v) || 0) - min) / span * (H - 8)).toFixed(1));
  return '<svg width="' + W + '" height="' + H + '" style="display:block">' +
    '<polyline points="' + xy.join(' ') + '" fill="none" stroke="var(--red, #d94f5c)" stroke-width="1.6"/></svg>';
}

async function loadWarmthPanel() {
  const box = $('#st-warmth');
  if (!box) return;
  const selVal = box.querySelector('#wr-chat') ? box.querySelector('#wr-chat').value : 'all';
  const sortVal = box.querySelector('#wr-sort') ? box.querySelector('#wr-sort').value : 'warmth';
  let tree, chats;
  try {
    const qs = (selVal && selVal !== 'all') ? ('?chat=' + encodeURIComponent(selVal) + '&all=1') : '?all=1';
    const [t, c] = await Promise.all([
      api('/api/memory-tree' + qs),
      api('/api/chats').catch(() => null)
    ]);
    tree = t;
    chats = c;
  } catch (e) {
    box.innerHTML = '<div class="mood-empty">读取失败：' + esc(String(e && e.message || e)) + '</div>';
    return;
  }
  renderWarmthPanel(tree, chats, selVal, sortVal);
}

function renderWarmthPanel(tree, chats, selVal, sortVal) {
  const box = $('#st-warmth');
  if (!box) return;
  const names = {};
  for (const c of ((chats && chats.chats) || [])) names[c.key] = c.chatName || '';
  const bands = tree.bands || [];
  const bandName = {};
  for (const b of bands) bandName[b.key] = b.name;

  const cardVal = box.querySelector('#wr-card') ? box.querySelector('#wr-card').value : 'all';
  const cardNames = [...new Set((tree.people || []).map((p) => p.cardName || '').filter(Boolean))];
  let people = tree.people || [];
  if (cardVal !== 'all') people = people.filter((p) => (p.cardName || '') === cardVal);
  if (selVal !== 'all') people = people.filter((p) => p.chatKey === selVal);
  const relBond = (p) => (p.rel && p.rel.bond !== undefined && p.rel.bond !== null) ? (Number(p.rel.bond) || 0) : (p.warmth && p.warmth.value || 0);
  if (sortVal === 'active') people.sort((a, b) => (b.lastSeenAt || 0) - (a.lastSeenAt || 0));
  else if (sortVal === 'name') people.sort((a, b) => String(a.primaryName || a.userId).localeCompare(String(b.primaryName || b.userId), 'zh'));
  else people.sort((a, b) => relBond(b) - relBond(a));

  const byBand = {};
  const bandNm = {};
  for (const p of people) {
    const b = (p.warmth && p.warmth.band) || {};
    const k = b.key || 'stranger';
    byBand[k] = (byBand[k] || 0) + 1;
    if (b.name) bandNm[k] = b.name;
  }
  const order = ['trusted', 'close', 'familiar', 'acquainted', 'stranger'];
  const bandKeys = [...order.filter((k) => byBand[k]), ...Object.keys(byBand).filter((k) => !order.includes(k))];
  const bandChips = '<span class="wr-band">共 <b>' + people.length + '</b> 人</span>' +
    bandKeys.map((k) =>
      '<span class="wr-band"><b style="color:' + (WARMTH_BAND_COLOR[k] || '#999') + '">' + esc(bandNm[k] || bandName[k] || k) + '</b> × ' + byBand[k] + '</span>').join('');

  const chatOpts = ['<option value="all">全部会话</option>']
    .concat((tree.chats || []).map((c) =>
      '<option value="' + esc(c.key) + '"' + (c.key === selVal ? ' selected' : '') + '>' +
      esc(wrChatLabel(c.key, names)) + '（' + c.people + ' 人）</option>'))
    .join('');

  const rows = people.map((p) => {
    const w = p.warmth || {};
    const band = w.band || { key: 'stranger', name: '—' };
    const color = WARMTH_BAND_COLOR[band.key] || '#999';
    const rel = p.rel || {};
    const hasRel = rel.bond !== undefined && rel.bond !== null;
    const pct = Math.max(0, Math.min(100, hasRel ? (Number(rel.bond) || 0) : (Number(w.value) || 0)));
    const val = hasRel ? (Number(rel.valence) || 0) : null;
    const valColor = val == null ? '' : (val >= 0 ? 'var(--red, #d94f5c)' : '#3a9e5f');
    const chips = (p.tags || []).map((t) =>
      '<span class="wr-chip' + (t.kind === 'short' ? ' short' : '') + '" title="' + esc(t.hint || '') + '">' + esc(t.name) + '</span>').slice(0, 6).join('');
    const nm = p.primaryName || Object.values(p.names || {})[0] || p.userId;
    return '<div class="wr-card" data-qq="' + esc(p.userId) + '" data-ck="' + esc(p.chatKey || '') + '" data-mk="' + esc(p.memoryKey || '') + '">' +
      '<div class="wr-row">' +
      '<div class="wr-who"><div class="nm" title="' + esc(nm) + '">' + esc(nm) + '</div>' +
      '<div class="sub">' + esc(p.userId) + ' · ' + esc(wrChatLabel(p.chatKey, names)) + (p.cardName ? ' · 卡 <b style="color:var(--accent,#3272c4)">' + esc(p.cardName) + '</b>' : '') + ' · 说过 ' + (p.talk || 0) + ' 句</div></div>' +
      '<div class="wr-barwrap" title="亲疏 bond（双轴主轴）"><div class="mood-bar"><div class="mood-bar-fill" style="width:' + pct + '%;background:' + color + '"></div></div></div>' +
      '<div class="wr-num"><b>' + pct.toFixed(1) + '</b> /100' + (val == null ? '' : ' · <span title="近期好恶 valence（正=近期偏向你）" style="color:' + valColor + '">' + (val >= 0 ? '+' : '') + val.toFixed(1) + '</span>') + ' · ' + wrAgo(p.lastSeenAt) + '活跃</div>' +
      '<span class="wr-badge" style="background:' + color + '">' + esc(band.name) + '</span>' +
      '<div class="wr-chips">' + chips + '</div>' +
      '</div>' +
      '<div class="wr-detail">' + wrDetailHtml(p) + '</div>' +
      '</div>';
  }).join('');

  box.innerHTML =
    '<div class="mood-head" style="margin-bottom:10px">' +
    '<span class="mood-at muted">' + wrFmtT(Date.now()) + '</span>' +
    '<span class="skills-badge ok">记忆树 · ' + people.length + ' 人</span>' +
    '</div>' +
    '<div class="wr-toolbar">' +
    '<select id="wr-card">' +
    '<option value="all">全部卡片</option>' +
    cardNames.map((n) => '<option value="' + esc(n) + '"' + (n === cardVal ? ' selected' : '') + '>' + esc(n) + '</option>').join('') +
    '</select>' +
    '<select id="wr-chat">' + chatOpts + '</select>' +
    '<select id="wr-sort">' +
    '<option value="warmth"' + (sortVal === 'warmth' ? ' selected' : '') + '>按好感排序</option>' +
    '<option value="active"' + (sortVal === 'active' ? ' selected' : '') + '>按最近活跃</option>' +
    '<option value="name"' + (sortVal === 'name' ? ' selected' : '') + '>按名字</option>' +
    '</select>' +
    '</div>' +
    '<div class="wr-bands">' + bandChips + '</div>' +
    (rows || '<div class="mood-empty">还没有交往记录</div>') +
    '<div class="mood-note">只读面板：数值 = 记忆树档案，10 秒自动刷新。模型看到的是定性档位，这里的精确值只有你能看。</div>';

  const sel = box.querySelector('#wr-chat');
  if (sel) sel.addEventListener('change', () => loadWarmthPanel());
  const cardSel = box.querySelector('#wr-card');
  if (cardSel) cardSel.addEventListener('change', () => loadWarmthPanel());
  const sort = box.querySelector('#wr-sort');
  if (sort) sort.addEventListener('change', () => loadWarmthPanel());
  box.querySelectorAll('.wr-row').forEach((row) => {
    row.addEventListener('click', () => row.parentElement.classList.toggle('open'));
  });
  box.querySelectorAll('.wr-del').forEach((btn) => {
    btn.addEventListener('click', async (e) => {
      e.stopPropagation();
      const card = btn.closest('.wr-card');
      if (!card || btn.disabled) return;
      btn.disabled = true;
      try {
        await api('/api/memory-tree/person', { method: 'POST', body: JSON.stringify({
          qq: card.getAttribute('data-qq'),
          chatKey: card.getAttribute('data-ck'),
          memoryKey: card.getAttribute('data-mk') || '',
          removeTag: btn.getAttribute('data-tag')
        }) });
        loadWarmthPanel();
      } catch (err) {
        btn.disabled = false;
        qaAlert('删除失败：' + (err && err.message || err));
      }
    });
  });
  box.querySelectorAll('.wr-addform').forEach((form) => {
    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      const card = form.closest('.wr-card');
      const msg = form.querySelector('.wr-admin-msg');
      // ⚠️ 必须走 form.elements：form.name 是表单自身的 name 属性（内置属性优先于同名控件），
      //   直接写 form.name 拿到的是空字符串（0.3.0 20260925 修过的坑，原样保留）。
      const name = form.elements.name.value.trim();
      if (!card || !name) return;
      const submit = form.querySelector('button[type="submit"]');
      if (submit) submit.disabled = true;
      try {
        await api('/api/memory-tree/person', { method: 'POST', body: JSON.stringify({
          qq: card.getAttribute('data-qq'),
          chatKey: card.getAttribute('data-ck'),
          memoryKey: card.getAttribute('data-mk') || '',
          addTag: { name: name, hint: form.elements.hint.value.trim(), kind: form.elements.kind.value }
        }) });
        loadWarmthPanel();
      } catch (err) {
        if (submit) submit.disabled = false;
        if (msg) msg.textContent = '添加失败：' + (err && err.message || err);
      }
    });
  });
}

function wrDetailHtml(p) {
  const w = p.warmth || {};
  const rel = p.rel || {};
  const hasRel = rel.bond !== undefined && rel.bond !== null;
  const relLogs = (rel.log || []).slice(-10).reverse()
    .map((l) => '<div class="wr-logline"><span class="t">' + wrFmtT(l.t) + '</span>' +
      '<span class="d ' + ((Number(l.d) || 0) >= 0 ? 'up' : 'down') + '">' +
      ((Number(l.d) || 0) >= 0 ? '+' : '') + Number(l.d).toFixed(1) + '</span>' +
      '<span>' + esc(String(l.why || '')) + ' <span class="mood-desc" style="margin:0">（bond ' + Number(l.b).toFixed(1) + ' / val ' + Number(l.v).toFixed(1) + '）</span></span></div>').join('');
  const legacyLogs = (w.log || []).slice(-10).reverse()
    .map((l) => '<div class="wr-logline"><span class="t">' + wrFmtT(l.t) + '</span>' +
      '<span class="d ' + ((Number(l.d) || 0) >= 0 ? 'up' : 'down') + '">' +
      ((Number(l.d) || 0) >= 0 ? '+' : '') + Number(l.d).toFixed(1) + '</span>' +
      '<span>' + esc(l.why || '') + ' <span class="mood-desc" style="margin:0">（到 ' + Number(l.v).toFixed(1) + '）</span></span></div>').join('');
  const shorts = (p.tags || []).filter((t) => t.kind === 'short')
    .map((t) => '<div>· <b>' + esc(t.name) + '</b>' + (t.hint ? ' — ' + esc(t.hint) : '') +
      ' <span class="mood-desc" style="margin:0">（' + wrAgo(t.lastSeenAt || t.createdAt) + '观察到）</span></div>').join('');
  const longs = (p.tags || []).filter((t) => t.kind === 'long')
    .map((t) => '<div>· <b>' + esc(t.name) + '</b>' + (t.hint ? ' — ' + esc(t.hint) : '') + '</div>').join('');
  const tweaks = (p.tweaks || []).filter((t) => t.active !== false)
    .map((t) => '<div>· ' + esc(t.text) + '</div>').join('');
  const words = ((p.style && p.style.words) || []).slice(0, 8)
    .map((x) => '<span class="wr-chip">' + esc(x.w) + '×' + x.n + '</span>').join('');
  const llm = (p.llm && p.llm.note)
    ? '<div class="mood-desc">模型最近一次评分（' + wrFmtT(p.llm.at) + '）：' + esc(p.llm.note) + '</div>' : '';
  const legacyHead = '<h4 class="mood-h3" style="margin-top:4px">好感变动（最近 ' + Math.min(10, (w.log || []).length) + ' 条）</h4>' +
    wrSpark(w.log) + (legacyLogs || '<div class="mood-desc">还没有变动记录</div>') + llm;
  const dualHead = '<h4 class="mood-h3" style="margin-top:4px">双轴：亲疏 bond <b>' + Number(rel.bond).toFixed(1) + '</b> /100 · 近期好恶 valence <b>' + ((Number(rel.valence) || 0) >= 0 ? '+' : '') + (Number(rel.valence) || 0).toFixed(1) + '</b></h4>' +
    (relLogs || '<div class="mood-desc">双轴还没有事件流水</div>') + llm;
  return '<div class="wr-grid"><div>' +
    (hasRel ? dualHead : legacyHead) +
    '</div><div>' +
    '<h4 class="mood-h3" style="margin-top:4px">档案（档位：' + esc((w.band || {}).name || '—') + '）</h4>' +
    (shorts ? '<h4 class="mood-h3">短期状态</h4>' + shorts : '') +
    (longs ? '<h4 class="mood-h3">长期印象标签</h4>' + longs : '') +
    (tweaks ? '<h4 class="mood-h3">相处方式</h4>' + tweaks : '') +
    (words ? '<h4 class="mood-h3">口头禅候选</h4><div>' + words + '</div>' : '') +
    ((!shorts && !longs && !tweaks && !words) ? '<div class="mood-desc">还没有标签</div>' : '') +
    '</div></div>' + wrAdminHtml(p);
}

function wrAdminHtml(p) {
  const tags = p.tags || [];
  const items = tags.map((t) =>
    '<span class="wr-chip' + (t.kind === 'short' ? ' short' : '') + '">' + esc(t.name) +
    '<button class="wr-del" data-tag="' + esc(t.name) + '" title="删除这个标签">✕</button></span>').join('');
  return '<h4 class="mood-h3">手动管理标签（QQ 级：TA 在所有群的档案一起变）</h4>' +
    '<div class="wr-admin">' +
    '<div class="wr-admin-tags">' + (items || '<span class="mood-desc" style="margin:0">（暂无标签）</span>') + '</div>' +
    '<form class="wr-addform">' +
    '<input name="name" placeholder="标签名（如：在看番）" required maxlength="12">' +
    '<input name="hint" placeholder="该怎么处（可选，给模型看）" maxlength="60">' +
    '<select name="kind"><option value="short">短期（48h 过时）</option><option value="long">长期（不过时）</option></select>' +
    '<button type="submit" class="btn btn-small">添加</button>' +
    '<span class="wr-admin-msg mood-desc" style="margin:0"></span>' +
    '</form></div>';
}
