# webui/ —— 情绪内核面板参考件（宿主 UI 侧）

> 这是**宿主 UI 侧**的面板实现，不是插件本体。官方 0.4.5 的插件协议**没有 WebUI 挂载点**
> （manifest 无 routes/ui/panel 字段），所以社区包里的面板只能作为**参考件 / 手动接线材料**
> 分发。洛版改机版用户**已自带**这套面板（随宿主分发），无需任何操作。

## 一、数据链路（三件套怎么咬合）

```
插件本体（随包，无需另配）
  plugin.json configSchema 里的 type:"live" 条目（liveJoy / liveHope / liveUnease / …）
      ↑ 声明"我要显示什么键、什么阈值"
  index.js 注册能力 emotion-core.snapshot（只读快照，零 token）
      │
宿主侧（本目录参考件 + 手动接线）
  ui/app/14-status-panel.js  ──GET /api/live-panel?skill=emotion-core──▶  src/routes.js 路由
      ▲                                                                        │
      └──────────── 渲染电平表 ◀── livePanelSnapshot()（src/skills/live-panel.js）◀┘
                        按 configSchema 的 live 条目取值/阈值着色（warnAt/dangerAt/goodAt）
```

文件对应关系：

| 本目录文件 | 洛版现役位置 | 作用 |
|---|---|---|
| `14-status-panel.js` | `ui/app/14-status-panel.js`（535 行） | 面板 UI：R18 管理 + 情绪内核电平表 + 好感度三块 |
| `live-panel.js` | `src/skills/live-panel.js`（203 行） | 只读取值器：按 configSchema 的 `source` 能力名取快照 |

## 二、官方原版用户手动接线（四步，改完必须重启宿主）

1. **拷面板**：`14-status-panel.js` → 宿主 `resources/app/ui/app/`。
2. **注册 script**：`ui/index.html` 里加一行（与现有编号行并排）：
   ```html
   <script defer src="/app/14-status-panel.js"></script>
   ```
3. **补路由**：`src/routes.js` 顶部 import 区加：
   ```js
   import { livePanelSnapshot } from './skills/live-panel.js';
   ```
   并把 `live-panel.js` 拷到 `resources/app/src/skills/`，路由表里加（`/api/providers` 附近即可）：
   ```js
   {
     method: 'GET', pattern: '/api/live-panel',
     handler: async ({ res, json, url }) => {
       const skillId = String(url.searchParams.get('skill') || 'emotion-core').trim();
       try {
         return json(res, 200, livePanelSnapshot({ skillId }));
       } catch (error) {
         return json(res, 200, { skillId, available: false, error: String(error?.message ?? error), groups: [] });
       }
     }
   },
   ```
4. **重启宿主**。`ui/` 与 `src/` 无热重载，改完不重启不生效。

## 三、依赖与限制（写实的坑）

- `live-panel.js` 依赖 `src/skills/manager.js`（技能管理器）——官方 0.4.5 自带，无需额外拷。
- `14-status-panel.js` 含三块：**情绪内核块**（`/api/live-panel`）随本包可用；
  **好感度块**（`/api/memory-tree`）需要装记忆树才出数；**R18 管理块**（`/api/persona-nsfw`）
  是洛版宿主端点，官方原版没有——此块显示"接口不可用"属预期，可自行删除该块代码。
- 这条路**不是官方协议保障**：插件加载器当前无沙箱（主进程直接 import），面板路由借宿主
  HTTP 服务走通；将来宿主加隔离则此路径可能失效。
- 取值失败的显示口径是"为什么看不到"（`available:false + reason`），不是接口报错——
  面板没数据先查插件是否在技能页启用。
