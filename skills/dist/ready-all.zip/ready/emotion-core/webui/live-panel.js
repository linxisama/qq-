// 实时面板数据（只读仪表）—— 给「心情」这类页面用。
//
// 为什么单独一个文件，而不是塞进 /api/skills：
//   技能页的 configSchema 表单只认 boolean / enum / number / string 四种 type，
//   `type:'live'` 是**只读**的（不能编辑、也不该被保存回 config），把它混进技能页
//   那套"收集所有 input 再 POST"的表单里，会退化成空输入框、一点保存就把
//   `liveHappy:''` 这类空串写进配置。所以 live 字段**不进技能页**，由独立页面消费。
//
// 取值口径（能力优先于名字，与全项目一致）：
//   面板不认识 mood.json，也不 import 任何具体插件 —— 它只按 configSchema 里声明的
//   `source`（能力名）去问"谁提供这个能力"，拿到 `{ values: {键: 值} }` 再按 `key` 取值。
//   以后换一套心情引擎，只要还提供同名能力，这里一行都不用改。
//
// 唯一"认识具体插件"的地方是调用方传入的 skillId 默认值 —— 那是页面入口的选择，
// 不是数据链路的依赖。

import { skillManager } from './manager.js';

/** 值 → 0~max 的整数；不是数字就返回 null（交给调用方按文本显示）。 */
function asNumber(v) {
  const n = Number(v);
  return Number.isFinite(n) ? n : null;
}

/** 按阈值给状态：bad 用 warnAt/dangerAt，good 用 goodAt；其余不给状态。 */
function stateOf(item, num) {
  if (num === null) return '';
  if (item.tone === 'bad') {
    const danger = asNumber(item.dangerAt);
    const warn = asNumber(item.warnAt);
    if (danger !== null && num >= danger) return 'danger';
    if (warn !== null && num >= warn) return 'warn';
    return '';
  }
  if (item.tone === 'good') {
    const good = asNumber(item.goodAt);
    return good !== null && num >= good ? 'good' : '';
  }
  return '';
}

/**
 * 抓一份能力的实时值。
 *
 * 两级降级是故意的：
 *   ① 先要"生效中"的提供者（口径与运行时一致：插件被禁用就拿不到）
 *   ② 拿不到再退到"已加载但没生效"的提供者 —— 面板是**看数据**的地方，
 *      插件关了也应该能看到磁盘上最后一刻的值（标 stale），而不是整页空白。
 *      否则排障时反而看不到东西：越是需要看数值的时候（怀疑它没跑）越看不到。
 *
 * @returns {{values: Object|null, at: number, error: string, stale: boolean}}
 */
function fetchValues(id, source, context) {
  const empty = { values: null, at: 0, error: '', stale: false };
  let providers = [];
  try {
    providers = skillManager.getCapabilityProviders(source, context) || [];
  } catch (e) {
    // 能力表本身出问题不影响别的字段，记下来继续
    return { ...empty, error: String(e?.message ?? e) };
  }
  if (!providers.length) {
    const skill = skillManager.registry.get(id);
    const fn = skill?.providers?.[source];
    if (typeof fn !== 'function') {
      return { ...empty, error: `没有任何生效中的插件提供能力 ${source}` };
    }
    try {
      const r = fn();
      return { values: (r && typeof r === 'object' ? (r.values || r) : null), at: Number(r?.at) || Date.now(), error: '', stale: true };
    } catch (e) {
      return { ...empty, error: String(e?.message ?? e), stale: true };
    }
  }
  try {
    const r = providers[0].fn();
    return { values: (r && typeof r === 'object' ? (r.values || r) : null), at: Number(r?.at) || Date.now(), error: '', stale: false };
  } catch (e) {
    return { ...empty, error: String(e?.message ?? e) };
  }
}

/**
 * 取某个 Skill 的 live 面板快照。
 *
 * @param {Object}  opts
 * @param {string}  opts.skillId  目标 Skill（默认 mood-chain）
 * @param {Object}  opts.context  可用性判定上下文
 * @returns {{skillId:string, name:string, version:string, at:number,
 *            available:boolean, enabled:boolean, active:boolean, stale:boolean,
 *            reason:string, error:string,
 *            groups:Array<{name:string, items:Array<Object>}>}}
 */
export function livePanelSnapshot({ skillId = 'mood-chain', context = {} } = {}) {
  const id = String(skillId || '').trim();
  const base = {
    skillId: id,
    name: '',
    version: '',
    at: Date.now(),
    available: false,
    enabled: false,
    active: false,
    stale: false,
    reason: '',
    error: '',
    groups: []
  };

  let skill = null;
  let view = null;
  try {
    skill = skillManager.registry.get(id) || null;
  } catch (e) {
    return { ...base, reason: String(e?.message ?? e) };
  }
  try {
    view = (skillManager.list(context) || []).find((s) => s && s.id === id) || null;
  } catch (e) {
    /* list 失败不影响取值，只是拿不到三态 */
  }

  base.name = String(view?.name || skill?.manifest?.name || id);
  base.version = String(view?.version || skill?.manifest?.version || '');
  base.enabled = Boolean(view?.enabled);
  base.active = Boolean(view?.active);

  if (!skill) {
    return { ...base, reason: `插件 ${id} 未加载${view?.loadError ? `（${view.loadError}）` : ''}` };
  }

  const schema = (skill.manifest && skill.manifest.configSchema) || {};
  const liveKeys = Object.keys(schema).filter((k) => schema[k] && schema[k].type === 'live');
  if (!liveKeys.length) {
    return { ...base, reason: `${id} 的 configSchema 里没有 type:'live' 字段` };
  }

  // 同一个 source 只问一次（12 个字段同属 mood.snapshot，别调 12 遍）
  const cache = new Map();
  const valuesFor = (source) => {
    if (!cache.has(source)) cache.set(source, fetchValues(id, source, context));
    return cache.get(source);
  };

  const groups = [];
  const groupIndex = new Map();
  const errors = [];
  let stale = false;
  let at = 0;

  for (const k of liveKeys) {
    const item = schema[k] || {};
    const source = String(item.source || '').trim();
    let raw = undefined;
    if (source) {
      const got = valuesFor(source);
      if (got.error) errors.push(`${source}：${got.error}`);
      if (got.stale) stale = true;
      if (got.at > at) at = got.at;
      raw = got.values ? got.values[item.key] : undefined;
    }
    const num = asNumber(raw);
    const max = asNumber(item.max);
    const gName = String(item.group || '').trim() || '其他';
    if (!groupIndex.has(gName)) {
      groupIndex.set(gName, { name: gName, items: [] });
      groups.push(groupIndex.get(gName));
    }
    groupIndex.get(gName).items.push({
      key: String(item.key || k),
      label: String(item.label || item.key || k),
      description: String(item.description || ''),
      max: max === null ? null : max,
      tone: item.tone === 'good' || item.tone === 'bad' ? item.tone : '',
      goodAt: asNumber(item.goodAt),
      warnAt: asNumber(item.warnAt),
      dangerAt: asNumber(item.dangerAt),
      wide: item.wide === true,
      // 空串不能当 0：文本项（正在做的事）没安排时是 ''，显示成 0 会让人以为真有个值
      value: (num === null || raw === '') ? String(raw ?? '') : Math.round(num * 10) / 10,
      // 进度条百分比：有 max 才算；无 max 的（主导情绪/当前状态）按文本显示
      pct: (num === null || max === null || max <= 0) ? null : Math.max(0, Math.min(100, (num / max) * 100)),
      state: stateOf(item, num),
      // 值缺失（能力没给、或键对不上）单独标出来，别显示成 0 —— 0 是有意义的数值
      missing: raw === undefined || raw === null || raw === ''
    });
  }

  return {
    ...base,
    at: at || Date.now(),
    available: !errors.length || groups.some((g) => g.items.some((i) => !i.missing)),
    stale,
    reason: view?.reason || '',
    error: [...new Set(errors)].join('；'),
    groups,
    // v1.1（20261003）：透传能力的原始返回（如 emotion-core.snapshot 的 cards 全卡数组），
    // 供专用页面（情绪页）做 schema 之外的全卡渲染。只读，不含任何可写状态。
    rawValues: Object.fromEntries([...cache].filter(([, g]) => g && g.values).map(([src, g]) => [src, g.values]))
  };
}

export default livePanelSnapshot;
