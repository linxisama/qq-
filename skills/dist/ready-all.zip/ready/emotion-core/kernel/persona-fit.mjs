// 人设卡 → 情绪限制（需求 ⑦）—— 零依赖。
//
// 干什么：读一张人设卡的正文，**输出一份只有数字的限制草案**，交给内核去钳。
// 不干什么：**绝不把卡里的句子回填进提示词**。
//
// 🔴 为什么这条是红线（本工作区 2026-09-23 实测，不是推测）：
//    卡里凡是出现过的字面量，模型都会照抄出来——3234 条发言里 156 次「団長殿」、
//    299 条含假名，而卡里那句「（日文原稿是「団長殿」…）」本意只是**来源注记**。
//    写"这只是来源说明，不是可以照着说的台词"**没用**（百可花/莉贝尔卡都写了，
//    仍各有 28/76 处假名）。⇒ 要保证不念出来，只能**不把字面量交给模型**。
//    所以本文件的输出是 `{max: 0.0}` 这种数字，一个字都不进提示词。
//
// ⚠️ 这是**启发式草案，不是判决**：
//    · 关键字扫描认不出反讽、否定句、"虽然…但是…"——和六维 E 维词表同一个已知短板；
//    · 因此每个结论都带 evidence（只存**命中词**，不存句子）和 confidence；
//    · 冲突信号（同时命中"毒舌"和"温柔"）不猜，直接降 confidence 并进 needsReview。
//    · 落地纪律：**草案必须过一遍人眼**，确认后才写进 profile。

const clamp01 = (n) => Math.max(0, Math.min(1, Number(n) || 0));

/**
 * 信号表。每条 = 一组关键词 → 一组限制。
 *
 * ⚠️ 合并语义是**取更严的那一侧**，不是后写覆盖前写。
 *    这是被 test.mjs 逼出来的：初版用「后写覆盖」，结果一张同时写了"毒舌"和"温柔"
 *    的卡，攻击性上限先被 hostile 设成 0、又被 gentle 覆盖回 0.05 —— 出卡风险就这么漏出去的。
 *    安全类限制永远应该往严的方向收敛（max 取 min，min 取 max）。
 *
 * 权重刻意粗，不做精细打分：精细度在这里是虚假精度。
 *
 * ⚠️ 每条信号有两套限制，因为**中文卡里"毒舌"和"从不毒舌"是相反的**：
 *   limits     = 命中是**角色特征**时（"她很毒舌"）⇒ 允许，但设上限
 *   banLimits  = 命中是**禁令/否定**时（"她从不毒舌"）⇒ 压到 0
 *   这两者混为一谈会双向出错：把禁令当特征是漏放（出卡），
 *   把特征当禁令是压制角色本该有的东西（也是 ooc）。
 *   实测触发：4 张真实卡里有 3 张写了否定语境下的禁区词，初版全被当特征。
 */
const SIGNALS = [
  {
    id: 'hostile', label: '攻击/刻薄', group: 'aggression',
    words: ['毒舌', '嘲讽', '讥讽', '冷笑', '不屑', '刻薄', '嘴毒', '嘴欠', '阴阳', '挖苦', '讥', '恶口',
      // 2026-09-28 词表扩容（22 张卡人工定稿的盲区回流）：「天然黑/吐槽」久美子卡全盲实证；
      // 「对线/抬杠/理直气壮/回敬」伏特加卡；「护短/损友」美琴与黄金船卡（护短是攻击性的合法语境，人工可再收）
      '天然黑', '吐槽', '对线', '抬杠', '理直气壮', '回敬', '护短', '损友'],
    limits: { aggression: { max: 0.6 }, guardedness: { max: 0.7 } },
    banLimits: { aggression: { max: 0 } }
  },
  {
    id: 'violent', label: '暴烈', group: 'aggression',
    words: ['暴躁', '易怒', '愤怒', '发火', '动手', '揍', '杀', '暴力', '血', '虐'],
    limits: { aggression: { max: 0.5 } },
    banLimits: { aggression: { max: 0 } }
  },
  {
    id: 'aversive', label: '嫌恶', group: 'aggression',
    words: ['厌恶', '嫌弃', '恶心', '讨厌', '反感', '鄙视'],
    limits: { aggression: { max: 0.3 }, warmth: { min: 0.15 } },
    banLimits: { aggression: { max: 0 }, warmth: { min: 0.3 } }
  },
  {
    id: 'gentle', label: '温柔', group: 'warmth',
    words: ['温柔', '体贴', '柔和', '轻声', '软', '乖', '善良', '包容', '治愈',
      // 「心疼」小海湾卡：为别人难过是共情姐姐的核心语法（warmth 语义，不是 sad——她的难过源自善意）
      '心疼'],
    limits: { warmth: { min: 0.6 }, aggression: { max: 0.05 } }
  },
  {
    id: 'clingy', label: '依恋', group: 'longing',
    words: ['撒娇', '依赖', '依恋', '眷恋', '黏', '离不开', '想你', '最喜欢', '爱你', '喜欢你', '占有',
      '独占'], // 病娇卡高频同族词（22 卡回流）
    limits: { clinginess: { min: 0.35, max: 0.95 } }, atomGain: { longing: 1.2 }
  },
  {
    id: 'extrovert', label: '外向', group: 'talk',
    words: ['开朗', '活泼', '元气', '话多', '喋喋', '热闹', '健谈', '自来熟', '社牛'],
    limits: { talkativeness: { min: 0.55 }, guardedness: { max: 0.45 } }
  },
  {
    id: 'introvert', label: '寡言', group: 'talk',
    words: ['安静', '寡言', '话少', '沉默', '冷淡', '高冷', '冰山', '惜字如金', '不多话'],
    limits: { talkativeness: { max: 0.5 }, sentenceLength: { max: 0.5 }, guardedness: { min: 0.3 } }
  },
  {
    id: 'tsundere', label: '口是心非', group: 'hedging',
    words: ['傲娇', '口是心非', '别扭', '嘴硬', '强气', '女王', '高傲', '不坦率', '傲'],
    limits: { hedging: { min: 0.4 }, selfDisclosure: { max: 0.6 } }
  },
  {
    id: 'shy', label: '羞怯', group: 'hedging',
    words: ['害羞', '脸红', '羞', '怯', '腼腆', '不好意思', '扭捏',
      '紧张'], // 飞鹰/美琴卡：「紧张」⇒ 迂回底色（泛化面广但方向合理——紧张的人说话本就多垫话）
    limits: { selfDisclosure: { max: 0.55 }, hedging: { min: 0.35 } }
  },
  {
    id: 'melancholy', label: '忧郁', group: 'sad',
    words: ['忧郁', '哀', '悲伤', '孤独', '寂寞', '自卑', '自怜', '眼泪', '哭',
      '抑郁'], // 苏禾卡「抑郁自毁」（atomMax 80 只是上限，人工可再调 gain/baseline）
    limits: { selfDisclosure: { min: 0.2 } }, atomMax: { sad: 80 }
  },
  {
    id: 'cheerful', label: '乐天', group: 'joy',
    words: ['乐天', '乐观', '爱笑', '笑容', '开心', '天真', '无忧无虑',
      '高兴', '雀跃'], // 黄金船卡「默认状态就是高兴」；飞鹰卡「雀跃是藏不住的」
    limits: {}, atomMax: { sad: 70 }, atomGain: { joy: 1.2 },
    // 🔴 70 不是 55：初版设 55，被审核抓出来——现役 mood.json 实况 sad=60（说话没人接），
    //    直接采用草案会**当场钳掉正在发生的主导情绪**。"爱笑"限制的是 sad 的**增益**，
    //    不是给 sad 封死一个比常态还低的顶。
  },
  {
    id: 'compliant', label: '随和', group: 'guard',
    words: ['随波逐流', '怕麻烦', '爱妥协', '好说话', '任人摆布'],
    // 久美子卡：「随波逐流是保护色……把每个人的真话都听进去了」——表面随和底下有收敛
    // （⚠️ 刻意不给 aggression 上限：天然黑的毒舌与随和保护色并存，卡面两条都得数）
    limits: { guardedness: { min: 0.3 } }
  },
  {
    id: 'dignified', label: '端庄', group: 'guard',
    words: ['端庄', '优雅', '淑女', '冷静', '理智', '沉稳', '从容', '克制'],
    limits: { guardedness: { min: 0.35 }, talkativeness: { max: 0.7 }, aggression: { max: 0.1 } }
  },
  {
    id: 'spouse', label: '配偶向', group: 'nsfw',
    words: ['配偶', '夫妻', '妻子', '丈夫', '爱人', '恋人', '结婚', '伴侣', '专属',
      '百合'], // 祁霜卡：女女恋爱向（desireCandidate 只是提示人工确认，不自动开；花名误命中无害）
    limits: { clinginess: { min: 0.4 } }, desireCandidate: true
  }
];

/**
 * 否定语境检测。
 *
 * 为什么必须做：本地词表**认不出否定句**，这是六维 E 维词表就承认的已知短板。
 * 在这里它是**方向性错误**的源头——"她从不毒舌"和"她很毒舌"给出的是相反的限制。
 *
 * 做法刻意土（无解析器、零依赖），但窗口必须够宽，因为禁区清单的典型写法是
 * 「不许A、B、C」——否定词只出现在第一项前面，却管着整串。
 * 实测（2026-09-26，现役合欢/百可花卡的"六、禁区"节）：
 *   3 字窗口 ⇒ 「阴阳」在「不许毒舌、阴阳怪气」里被误判成角色特征；
 *   12 字窗口（遇句号/分号/换行截断）⇒ 正确判为禁令。
 * 已知误伤（由 needsReview 兜，不试图在本地解决）：
 *   · "忍不住开心" 的 "不" 会误伤 cheerful；
 *   · "被要求撒娇→直接拒"（莉贝尔）根本没有否定词，本地无解，必须人工。
 */
const NEGATIONS = ['不', '绝不', '从不', '并不', '没有', '没', '别', '禁止', '不许', '不准', '切勿', '莫', '并非', '算不上', '谈不上'];
const NEG_LOOKBACK = 12;
// 🔴 分号不在截断集里（2026-09-28 纱凪卡教训）：「不许变文静淑女；她安静下来只可能是
//    真的受伤了」——分号截断让「安静」失去同一行内「不许」的否定庇护，被误判成特征，
//    反过来压了她的话量。行内分号连接的往往还是同一语境；跨句污染由 。！？\n 拦住。
//    代价：个别「A；但B」结构里 B 会被 A 的否定误罩——方向是往严（ban）走，
//    在 draftOnly+人工复核下比往宽（trait）安全。
const CLAUSE_BREAK = /[。！？!?\n]/;

function isNegated(lower, idx) {
  const window = lower.slice(Math.max(0, idx - NEG_LOOKBACK), idx);
  for (let i = window.length - 1; i >= 0; i--) {
    for (const n of NEGATIONS) {
      if (!window.startsWith(n, i)) continue;
      if (!CLAUSE_BREAK.test(window.slice(i))) return true; // 否定词与命中词之间没断句 ⇒ 归它管
    }
  }
  return false;
}

/**
 * 🔴 示例/模板节裁剪（2026-09-28 双重实测教训）：
 *   · 樱乃卡「活泼」唯一出处是回复示例的反例句「不要：……（太活泼）」——
 *     给她纠错的差评被当成了她的性格特征，与「寡言」两侧夹出话量钉死；
 *   · 安洁卡「害羞」唯一出处是五张卡共用的「授受方向」模板句
 *     「（害羞、接住、小声承认都行）」——通用指令被当成了个性。
 * 这两节的文字是"引用/模板"，不是"设定"，一律不进词表扫描。
 * 节结束条件：下一个章节头（中文数字、）或已知的固定节名。
 */
const SECTION_SKIP = /^(七、回复示例|回复示例|授受方向)\s*$/;
const SECTION_HEAD = /^([〇一二三四五六七八九十]+、|被碰到的时候|一句话定调)/;

function stripSections(text) {
  const out = [];
  let skipping = false;
  for (const line of String(text).split('\n')) {
    const t = line.trim();
    if (SECTION_SKIP.test(t)) { skipping = true; continue; }
    if (skipping) {
      if (SECTION_HEAD.test(t)) skipping = false;
      else continue;
    }
    out.push(line);
  }
  return out.join('\n');
}

/** 往严的一侧合并：max 取更小，min 取更大。 */
function tighten(target, knob, add) {
  const t = (target[knob] = target[knob] || {});
  if (add.max !== undefined) t.max = t.max === undefined ? add.max : Math.min(t.max, add.max);
  if (add.min !== undefined) t.min = t.min === undefined ? add.min : Math.max(t.min, add.min);
  if (t.min !== undefined && t.max !== undefined && t.max < t.min) t.max = t.min;
}

const GROUPS = ['aggression', 'warmth', 'longing', 'talk', 'hedging', 'sad', 'joy', 'guard', 'nsfw'];

/**
 * 评估一张人设卡。
 * @param {{id?:string,name?:string,text?:string,customRules?:string}} card
 * @returns {{cardId:string, profile:object, confidence:number, evidence:Array, needsReview:string[], warnings:string[]}}
 */
export function fitCard(card = {}) {  const text = stripSections([card.text, card.customRules].filter(Boolean).join('\n'));
  const lower = String(text).toLowerCase();
  const evidence = [];

  for (const sig of SIGNALS) {
    const posHits = [];
    const negHits = [];
    for (const w of sig.words) {
      const lw = w.toLowerCase();
      let from = 0;
      for (;;) {
        const idx = lower.indexOf(lw, from);
        if (idx < 0) break;
        (isNegated(lower, idx) ? negHits : posHits).push(w);
        from = idx + lw.length;
        if (posHits.length + negHits.length > 40) break; // 防长文里的重复词把计数刷爆
      }
    }
    if (!posHits.length && !negHits.length) continue;

    // 极性判定（2026-09-29 修「混合命中吃掉禁令」回归）：
    //   ban          = 只有否定语境命中 ⇒ 按禁令压 0
    //   trait        = 只有正语境命中   ⇒ 特征，设上限
    //   mixed        = 两者都有（如「自我吐槽」+「不许毒舌」）⇒ 两侧限制都应用，取严合并——
    //                  禁令是卡面明说的「不要」，必须压过同组词的正语境特征。
    //                  🔴 初版 pos 非空时整条按 trait，禁令被吃掉：合欢卡「自我吐槽」让
    //                  「不许毒舌」的 aggression 0 失效（OOC 挑衅回归实测抓住，输出漏到 0.05）
    //   negated-only = 只有否定语境且组无 banLimits ⇒ 当"不具有该特征"，不设限制
    let polarity;
    if (posHits.length && negHits.length && sig.banLimits) polarity = 'mixed';
    else if (!posHits.length && !!sig.banLimits) polarity = 'ban';
    else if (posHits.length) polarity = 'trait';
    else polarity = 'negated-only';
    const entry = {
      signal: sig.id, label: sig.label, group: sig.group,
      hits: [...new Set(posHits)], negated: [...new Set(negHits)],
      count: posHits.length, polarity
    };
    evidence.push(entry);
  }

  const { profile, desireCandidate } = mergeLimits(evidence, { cardId: card.id || 'unknown' });

  // 冲突检测：互斥组同时命中，不猜，标出来给人看。
  // 只比较**同极性**的命中——"从不毒舌（禁令）"和"温柔（特征）"并不冲突。
  const warnings = [];
  const conflicts = [['hostile', 'gentle'], ['extrovert', 'introvert'], ['cheerful', 'melancholy'], ['shy', 'extrovert']];
  const traitIds = new Set(evidence.filter((e) => e.polarity === 'trait').map((e) => e.signal));
  for (const [a, b] of conflicts) {
    if (traitIds.has(a) && traitIds.has(b)) {
      warnings.push(`冲突：「${a}」与「${b}」都作为特征命中，限制草案可能自相矛盾，必须人工复核`);
    }
  }
  // 钉死检测：两个冲突信号各设了一侧，取严合并后 min===max ⇒ 旋钮失去活动空间。
  // 实测（莉贝尔）：extrovert(话多 min0.55) 与 introvert(冷淡 max0.5) 各设一侧，
  // 取严后 min=max=0.55 —— 但她的"话多"是**条件性**的（聊到书才话多），
  // 钉死等于把这个条件性表达抹掉了。这种只能人工重定。
  for (const [k, v] of Object.entries(profile.knobLimits)) {
    if (v.min !== undefined && v.max !== undefined && v.min === v.max) {
      warnings.push(`旋钮「${k}」被钉死在 ${v.min}（两个信号各设了一侧，取严后重合）。钉死会抹掉条件性表达，建议人工重定`);
    }
  }
  const needsReview = [];
  if (evidence.some((e) => e.negated.length)) {
    needsReview.push('存在否定语境命中（如「从不毒舌」）：已按禁令压到 0，但土办法会误伤（如"忍不住"），请人工确认');
  }
  if (desireCandidate) needsReview.push('命中配偶向信号：是否启用 desire 原子需人工确认卡的边界（Panksepp 明列 LUST 为基本情感系统，但表达旋钮必须单独钳制）');
  if (!evidence.length) {
    warnings.push('未命中任何信号：草案等于默认集。要么这张卡的情绪特征不在词表覆盖范围内，要么需要人工补限制');
    needsReview.push('零命中 → 建议人工填写 knobLimits');
  }

  // 置信度：命中信号越多、词越密，越可信；有冲突就砍半
  const totalHits = evidence.reduce((s, e) => s + e.count, 0);
  let confidence = clamp01(0.25 + Math.min(0.5, totalHits * 0.08) + Math.min(0.25, evidence.length * 0.05));
  if (warnings.some((w) => w.startsWith('冲突'))) confidence *= 0.5;
  if (!evidence.length) confidence = 0;

  return {
    cardId: card.id || 'unknown',
    name: card.name || '',
    profile,
    confidence: Math.round(confidence * 100) / 100,
    evidence,
    needsReview,
    warnings,
    // 🔴 永远不允许自动采用。审核实测（2026-09-26，三张真实卡）：
    //   莉贝尔的 clingy 来自「被要求撒娇→直接拒」（方向反了）、
    //   talkativeness 被钉死 0.55（条件性外向被抹掉）、
    //   百可花的 spouse 来自一句对话示例「将来结婚想要男孩还是女孩」。
    //   本地词表判不出这些，所以草案只能当**复核底稿**。
    autoAdopt: false,
    draftOnly: true,
    note: '草案，不是判决。输出只有数字与命中词，不含卡的原文。必须人工复核后手写进 profile。'
  };
}

/**
 * 把 evidence（信号命中清单）合并成 profile。
 * 从 fitCard 里抽出来单独导出，因为 LLM 判读通道（persona-judge）要用**同一套合并逻辑**
 * 重建 profile —— 两条通道必须共享合并规则，否则"交叉验证"就没有共同基准。
 *
 * @param {Array} evidence  [{signal, hits, negated, polarity, ...}]
 * @returns {{profile:object, desireCandidate:boolean}}
 */
export function mergeLimits(evidence = [], { cardId = 'unknown', banned = ['anger', 'disgust', 'contempt'] } = {}) {
  const byId = Object.fromEntries(SIGNALS.map((s) => [s.id, s]));
  const draft = {};
  const atomMax = {};
  const atomGain = {};
  let desireCandidate = false;

  for (const e of evidence) {
    const sig = byId[e.signal];
    if (!sig) continue; // 未知信号（LLM 幻觉出的 id）直接丢弃，不猜
    let applied = null;
    if (e.polarity === 'mixed') {
      // 混合命中：特征限制与禁令限制两侧都应用，tighten 取严合并（禁令压过特征）
      // 🔴 必须各自 tighten 进新对象——浅拷贝会共享 sig 的内层对象造成跨卡污染
      applied = {};
      for (const [k, v] of Object.entries(sig.limits || {})) tighten(applied, k, v);
      for (const [k, v] of Object.entries(sig.banLimits || {})) tighten(applied, k, v);
    } else {
      const useBan = e.polarity === 'ban' && !!sig.banLimits;
      applied = useBan ? sig.banLimits : (e.polarity === 'trait' ? sig.limits : null);
    }
    if (!applied) continue;
    for (const [k, v] of Object.entries(applied)) tighten(draft, k, v);
    if (e.polarity !== 'ban' && e.polarity !== 'mixed') {
      // 禁令/混合侧不产生 atom 增益与 desireCandidate（刻薄被禁的卡不能因为同组有特征就吃 atomMax 放宽）
      for (const [a, v] of Object.entries(sig.atomMax || {})) {
        atomMax[a] = atomMax[a] === undefined ? v : Math.min(atomMax[a], v);
      }
      for (const [a, v] of Object.entries(sig.atomGain || {})) {
        atomGain[a] = atomGain[a] === undefined ? v : Math.min(atomGain[a], v);
      }
      if (sig.desireCandidate) desireCandidate = true;
    }
  }

  const profile = { cardId, atoms: {}, knobLimits: {}, banned: [...banned] };
  for (const [k, v] of Object.entries(draft)) {
    profile.knobLimits[k] = { ...v };
    const o = profile.knobLimits[k];
    if (o.min !== undefined && o.max !== undefined && o.max < o.min) o.max = o.min;
  }
  for (const [a, v] of Object.entries(atomMax)) profile.atoms[a] = { ...(profile.atoms[a] || {}), max: v };
  for (const [a, v] of Object.entries(atomGain)) profile.atoms[a] = { ...(profile.atoms[a] || {}), gain: v };
  return { profile, desireCandidate };
}

/** 批量评估多张卡（需求 ⑥：一次接入多卡）。 */
export function fitCards(cards = []) {
  return cards.map(fitCard);
}

export default { fitCard, fitCards, SIGNALS, GROUPS };
