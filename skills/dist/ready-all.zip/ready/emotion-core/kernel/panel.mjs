// 可视化数据契约（需求 ①）—— 零依赖。
//
// 现役面板的三处失信（2026-09-26 实测，本文件逐条修掉）：
//   失信 1｜重名：EMOTIONS.sad.label='抑郁'，depress 模块的面板 label 也叫「抑郁」
//           ⇒ 截图上「主导情绪 强烈抑郁」紧挨着「抑郁 100」，看着像因果，其实毫无关系
//           （主导来自 sad=60「说话没人接」，depress=100 是 09-24 冻结的死值）。
//           修法：本文件所有条目都带 **id**，并显式校验 id 唯一，label 只作显示。
//   失信 2｜禁用模块照常显示活数：depress.enabled=false 已冻结 48 小时，
//           面板仍然显示 100，且没有任何"已停用/已冻结"标记。
//           修法：enabled=false 或衰减到无意义的，一律标 frozen=true，并给出 stale 原因。
//   失信 3｜主导情绪是个孤立字符串，看不出为什么。
//           修法：附带 margin（领先多少）、runnerUp（第二名是谁）、why（触发原因）。
//
// 一个额外原则：**每个派生项都必须显示它的输入值和公式**。
// 光显示"吃醋 72"是不可解释的，显示"吃醋 72 = √(眷恋 68 × 不安 76)"才可审计。

const MIN = 60 * 1000;
const r1 = (n) => Math.round(Number(n) * 10) / 10;

/** 一个数值是否还有意义：低于 1，或距上次事件写入已过了 4 个半衰期（≈原值的 6%）。 */
export function isFrozen(level, touchedAt, halfLifeMin, now) {
  const ageMin = Math.max(0, (now - (Number(touchedAt) || 0)) / MIN);
  const hl = Math.max(1, Number(halfLifeMin) || 60);
  return level < 1 || ageMin > hl * 4;
}

/**
 * 生成面板数据契约。
 * @param {object} core  createCore() 的返回值
 * @param {{now?:number}} opt
 */
export function panelSchema(core, { now = Date.now() } = {}) {
  const { cfg, state } = core;
  const view = core.render(now);
  const seen = new Set();
  const warnings = [];

  const atoms = Object.values(cfg.atoms).map((a) => {
    const slot = state.atoms[a.id] || { level: 0, at: now, touchedAt: now, why: '' };
    const level = r1(slot.level);
    // ⚠️ 年龄一律用 touchedAt（最后一次事件写入）。slot.at 会被懒结算拨到 now，
    //    用它算年龄永远得 0 —— 审核实测（2026-09-26）踩过。
    const touched = Number(slot.touchedAt) || Number(slot.at) || now;
    const frozen = !a.enabled || isFrozen(level, touched, a.halfLifeMin, now);
    if (seen.has(a.id)) warnings.push(`id 重复：${a.id}（面板必须按 id 定位，label 重复无所谓，id 重复会让前端取错值）`);
    seen.add(a.id);
    return {
      id: a.id, label: a.label, level,
      bandLabel: bandLabel(level),
      enabled: !!a.enabled,
      frozen,
      stale: !a.enabled ? 'disabled-by-card' : (frozen ? 'decayed' : null),
      max: a.max, min: a.min, gain: a.gain,
      competes: !!a.competes,
      branch: a.branch, time: a.time, valence: a.valence,
      halfLifeMin: a.halfLifeMin,
      sinceTouchMin: Math.round((now - touched) / MIN),
      why: slot.why || '',
      attribution: slot.attribution || null
    };
  });

  const mods = Object.values(cfg.mods).map((m) => {
    const slot = state.mods[m.id] || { level: 0, at: now, touchedAt: now };
    const level = r1(slot.level);
    const touched = Number(slot.touchedAt) || Number(slot.at) || now;
    return {
      id: m.id, label: m.label, level, enabled: m.enabled !== false,
      frozen: isFrozen(level, touched, m.halfLifeMin, now),
      halfLifeMin: m.halfLifeMin, sinceTouchMin: Math.round((now - touched) / MIN),
      note: m.note || ''
    };
  });

  const knobs = Object.keys(cfg.knobs).map((id) => {
    const k = cfg.knobs[id];
    const hit = view.knobs.clampedBy.find((c) => c.knob === id);
    return {
      id, label: k.label,
      raw: view.knobs.raw[id], clamped: view.knobs.clamped[id],
      min: k.min, max: k.max, base: k.base,
      clampedByCard: !!hit, clampInfo: hit || null
    };
  });

  for (const b of cfg.banned) {
    if (!cfg.atoms[b] && !cfg.mods[b]) {
      warnings.push(`banned 里的 "${b}" 不是已注册原子/调制量（保留占位可以，但面板不会显示它——确认是故意保留的还是拼错了）`);
    }
  }

  return {
    cardId: cfg.cardId,
    at: now,
    schemaVersion: 1,
    dominant: {
      atom: view.dominant.atom, label: view.dominant.label,
      level: view.dominant.level, band: view.dominant.band,
      margin: view.dominant.margin,
      runnerUp: view.dominant.runnerUp,
      why: view.dominant.why,
      explain: view.dominant.atom
        ? `${view.dominant.band}${view.dominant.label}（${view.dominant.level}）领先第二名 ${view.dominant.margin}；触发：${view.dominant.why || '—'}`
        : '无主导情绪（所有参与竞争的原子都低于 20）'
    },
    atoms,
    mods,
    derived: view.derived.map((d) => ({
      id: d.id, label: d.label, intensity: d.intensity, band: bandLabel(d.intensity),
      inputs: d.inputs,
      explain: `${d.label} ${d.intensity} = ${Object.entries(d.inputs).map(([k, v]) => `${k} ${v}`).join(' × ')}`
    })),
    knobs,
    blockedAtoms: view.blockedAtoms,
    warnings
  };
}

function bandLabel(level) {
  if (level >= 80) return '强烈';
  if (level >= 60) return '明显';
  if (level >= 40) return '有点';
  if (level >= 20) return '些许';
  return '微微';
}

/** 终端 / 日志用的紧凑文本面板（宿主没有 UI 时也能看）。 */
export function formatPanel(schema) {
  const L = [];
  L.push(`[${schema.cardId}] ${new Date(schema.at).toISOString()}`);
  L.push(`主导：${schema.dominant.explain}`);
  L.push('原子：');
  for (const a of schema.atoms) {
    const tag = a.enabled ? (a.frozen ? ' 冻结' : '') : ' 已停用';
    const mark = a.enabled && !a.frozen ? '' : '·';
    L.push(`  ${mark}${a.label}(${a.id}) ${a.level}${a.bandLabel ? ' ' + a.bandLabel : ''}${tag}${a.attribution ? ' 归因=' + a.attribution : ''}${a.why ? ' ← ' + a.why : ''}`);
  }
  L.push('调制：');
  for (const m of schema.mods) L.push(`  ${m.label} ${m.level}${m.frozen ? ' 冻结' : ''}`);
  if (schema.derived.length) {
    L.push('派生：');
    for (const d of schema.derived) L.push(`  ${d.explain}`);
  } else L.push('派生：无');
  L.push('旋钮（卡钳制后）：');
  for (const k of schema.knobs) {
    const c = k.clampedByCard ? `  ← 被卡钳制(raw ${k.raw} → ${k.clamped}, ${k.clampInfo.by}=${k.clampInfo.limit})` : '';
    L.push(`  ${k.label} ${k.clamped}${c}`);
  }
  if (schema.warnings.length) {
    L.push('警告：');
    for (const w of schema.warnings) L.push(`  ! ${w}`);
  }
  return L.join('\n');
}

export default { panelSchema, formatPanel, isFrozen };
