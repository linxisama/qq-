// 情绪内核 —— 零依赖、宿主无关、配置驱动。
//
// 七条需求在本文件里的落点：
//   ② 不是高度定制：原子集由评价格导出（atoms.mjs），**没有任何一个人名、角色名、口癖**
//      写死在内核里；换卡 = 换一份 profile 数字。
//   ③ 不破坏人设：卡外行为不是靠提示词"求它别做"，而是**在旋钮层被钳死**
//      （aggression.max=0 ⇒ 毒舌/嘲讽/愤怒在数学上不可达）。
//   ⑤ 独立运行：本文件不 import 任何宿主模块，也不 import 六维记忆。
//   ⑥ 可适配任意卡：profile 是数据，新卡 = 新增一份 JSON，内核一行不改。
//   ⑦ 按卡限制：见 profile 的 atoms.enabled/max 与 knobLimits。
//
// ⚠️ 一条铁律（来自本工作区 2026-09-23 的实测教训）：
//    人设卡的**原文绝不能回填进提示词**。卡里出现的字面量（哪怕是"这只是来源说明"）
//    都会被模型照抄出来——实测 3234 条发言里 156 次「団長殿」、299 条含假名。
//    所以 profile 里**只有数字**，注入文本一律由内核按旋钮生成，与卡无关。

import {
  SCHEMA_VERSION, DEFAULT_ATOMS, DEFAULT_MODS, DEFAULT_KNOBS,
  ATOM_KNOB_WEIGHTS, STIR_KNOB_WEIGHTS, DERIVED_RULES,
  MAX_DELTA, REGRESS_RATE, FLAG_TTL_MIN, appraise
} from './atoms.mjs';

const MIN = 60 * 1000;
const clamp = (n, lo = 0, hi = 100) => {
  const v = Number(n);
  if (!Number.isFinite(v)) return lo;
  return v < lo ? lo : v > hi ? hi : v;
};
const r3 = (n) => Math.round(Number(n) * 1000) / 1000;

export const BANDS = [
  { min: 80, label: '强烈' }, { min: 60, label: '明显' },
  { min: 40, label: '有点' }, { min: 20, label: '些许' }, { min: 0, label: '微微' }
];
export function bandOf(level) {
  const l = clamp(level);
  return (BANDS.find((b) => l >= b.min) || BANDS[BANDS.length - 1]).label;
}

/**
 * 把卡的 profile 与默认集编译成一份可直接用的配置。
 * profile 可以只写要覆盖的项，其余回落默认 —— 新卡的接入成本因此接近零。
 */
export function compileProfile(profile = {}) {
  const p = profile || {};
  const atoms = {};
  for (const [id, def] of Object.entries(DEFAULT_ATOMS)) {
    const o = p.atoms?.[id] || {};
    atoms[id] = {
      ...def,
      id,
      enabled: o.enabled === undefined ? !!def.enabledByDefault : !!o.enabled,
      max: clamp(o.max === undefined ? 100 : o.max, 0, 100),
      min: clamp(o.min === undefined ? 0 : o.min, 0, 100),
      gain: Math.max(0, Math.min(3, Number(o.gain === undefined ? 1 : o.gain)))
    };
  }
  const mods = {};
  for (const [id, def] of Object.entries(DEFAULT_MODS)) {
    const o = p.mods?.[id] || {};
    mods[id] = { ...def, id, enabled: o.enabled !== false, max: clamp(o.max === undefined ? 100 : o.max, 0, 100) };
  }
  const knobs = {};
  for (const [id, def] of Object.entries(DEFAULT_KNOBS)) {
    const lim = p.knobLimits?.[id] || {};
    knobs[id] = {
      ...def, id,
      min: clamp(lim.min === undefined ? 0 : lim.min, 0, 1),
      max: clamp(lim.max === undefined ? 1 : lim.max, 0, 1)
    };
    if (knobs[id].max < knobs[id].min) knobs[id].max = knobs[id].min;
  }
  // baseline：mood 是全局心境偏置（既有）；原子键 = **per-atom 基线**（2026-09-28 阿枝卡逼出：
  // 「常年低烧的不安」——无事件时 unease 也该停在基线上，而不是归 0）。
  // 基线不得超过该原子的 max（钳制），未知原子键静默丢弃（闸门 I10 会另行报错）。
  const baseline = { mood: Math.max(-100, Math.min(100, Number(p.baseline?.mood) || 0)) };
  for (const [id, def] of Object.entries(atoms)) {
    if (p.baseline?.[id] !== undefined) {
      baseline[id] = clamp(Number(p.baseline[id]) || 0, 0, Math.min(100, def.max ?? 100));
    }
  }
  // mod 基线（2026-09-28 飞鹰卡逼出）：「心跳快是默认档位」——高唤醒卡的 stir 静置也该烧在基线上。
  // mod 无独立 max 概念差异（compile 已给默认 100），钳 [0, min(100, def.max)]。
  for (const [id, def] of Object.entries(mods)) {
    if (p.baseline?.[id] !== undefined) {
      baseline[id] = clamp(Number(p.baseline[id]) || 0, 0, Math.min(100, def.max ?? 100));
    }
  }
  return {
    cardId: String(p.cardId || 'default'),
    atoms, mods, knobs,
    banned: Array.isArray(p.banned) ? p.banned.slice() : [],
    baseline,
    derivedIds: Array.isArray(p.derivedIds) ? p.derivedIds.slice() : DERIVED_RULES.map((r) => r.id)
  };
}

export function createState(cfg, now = Date.now()) {
  const atoms = {};
  // touchedAt = 最后一次**事件写入**的时刻。它与 at 分开记，因为 tick 的懒结算
  // 每次读都会把 at 拨到 now（否则会二次衰减）——审核实测（2026-09-26）：
  // 只用 at 的话，两小时后面板 ageMin 永远显示 0，"冻结/陈旧"判据整个失效。
  for (const id of Object.keys(cfg.atoms)) {
    // 初始电平 = 基线（有基线的原子开局就「烧」在那里，比如阿枝的常备不安）
    atoms[id] = { level: Number(cfg.baseline?.[id]) || 0, at: now, touchedAt: now, why: '', attribution: null };
  }
  const mods = {};
  for (const [id, m] of Object.entries(cfg.mods)) {
    // 初值 = 基线（有 mod 基线的卡开局就「烧」在那里，比如飞鹰的常备悸动）；无基线保持既有语义（energy=100 满格，其余 0）
    mods[id] = { level: cfg.baseline?.[id] ?? (id === 'energy' ? 100 : 0), at: now, touchedAt: now, why: '' };
  }
  return {
    v: SCHEMA_VERSION, cardId: cfg.cardId, atoms, mods,
    baseline: { ...cfg.baseline },
    flags: {},
    updatedAt: now
  };
}

/**
 * 半衰衰减（与六维记忆同一套衰减模型，便于对接时口径一致）。
 * base（2026-09-28 新增）：per-atom 基线——衰减的归宿从 0 改成基线；level 低于基线时同样
 * 按指数律**回升**向基线（公式对上下两个方向对称）。base 缺省 0，与旧行为完全兼容。
 */
export function decayedLevel(level, at, halfLifeMin, now, base = 0) {
  const hl = Math.max(1, Number(halfLifeMin) || 60);
  const ageMin = Math.max(0, (now - (Number(at) || 0)) / MIN);
  return clamp(base + (level - base) * Math.pow(0.5, ageMin / hl));
}

/** 把状态推进到 now（懒衰减：只在读写时结算，不依赖定时器）。 */
export function tick(state, cfg, now = Date.now()) {
  for (const [id, a] of Object.entries(state.atoms)) {
    const def = cfg.atoms[id];
    if (!def) continue;
    a.level = decayedLevel(a.level, a.at, def.halfLifeMin, now, Number(cfg.baseline?.[id]) || 0);
    a.at = now;
  }
  for (const [id, m] of Object.entries(state.mods)) {
    const def = cfg.mods[id];
    if (!def) continue;
    // 衰减归宿 = mod 基线（无基线为 0，与原子同律）；energy 不设基线时保持既有行为（向 0 慢衰减）
    m.level = decayedLevel(m.level, m.at, def.halfLifeMin, now, Number(cfg.baseline?.[id]) || 0);
    m.at = now;
  }
  state.updatedAt = now;
  return state;
}

/**
 * 施加一个评价事件。
 * @returns {{applied:Array, blocked:Array, flags:string[]}}
 *   blocked 里记录"哪个原子因为卡的限制没被触发" —— 这是 ⑦ 的可审计证据，
 *   面板上要能看见"系统想让她生气，但卡把它关了"，而不是悄悄什么都不发生。
 */
export function applyEvent(state, cfg, event, now = Date.now()) {
  tick(state, cfg, now);
  const { deltas, attribution, flags } = appraise(event);
  const applied = [];
  const blocked = [];
  for (const d of deltas) {
    const isMod = !!cfg.mods[d.atom];
    const def = isMod ? cfg.mods[d.atom] : cfg.atoms[d.atom];
    if (!def) { blocked.push({ atom: d.atom, delta: r3(d.delta), reason: 'unknown-atom' }); continue; }
    // 卡里禁掉的原子：不吃这个增量，但记账
    if (cfg.banned.includes(d.atom) || def.enabled === false) {
      blocked.push({ atom: d.atom, label: def.label, delta: r3(d.delta), reason: 'disabled-by-card', why: d.why });
      continue;
    }
    let delta = Math.max(-MAX_DELTA, Math.min(MAX_DELTA, Number(d.delta) || 0)) * (def.gain || 1);
    // 心境依存（mood-congruent encoding）：底色为正时正向原子更容易被点亮，底色为负时反之。
    // 幅度刻意小（±30%），底色是**偏置**不是**判决**——否则一次坏心情会让所有好事都失效。
    if (!isMod && def.valence) {
      const bias = (Number(state.baseline?.mood) || 0) / 100 * 0.3;
      delta *= def.valence === 'positive' ? 1 + bias : 1 - bias;
    }
    const slot = isMod ? state.mods[d.atom] : state.atoms[d.atom];
    const before = slot.level;
    slot.level = clamp(before + delta, def.min || 0, def.max);
    slot.at = now;
    slot.touchedAt = now;
    slot.why = d.why;
    if (!isMod && attribution) slot.attribution = attribution;
    applied.push({ atom: d.atom, label: def.label, from: r3(before), to: r3(slot.level), delta: r3(slot.level - before), why: d.why });
  }
  // 情境标记由**事件**写入，带保鲜期；渲染时过期就不算数
  state.flags = state.flags || {};
  for (const f of flags) {
    if (FLAG_TTL_MIN[f] !== undefined) state.flags[f] = now;
  }
  state.updatedAt = now;
  return { applied, blocked, flags };
}

/** 每次交互向基线回落（ChatMood 的实测比例），防止情绪单向累积。回落归宿=per-atom 基线。 */
export function regress(state, cfg, now = Date.now()) {
  tick(state, cfg, now);
  for (const [id, a] of Object.entries(state.atoms)) {
    const base = Number(cfg.baseline?.[id]) || 0;
    a.level = clamp(base + (a.level - base) * (1 - REGRESS_RATE));
  }
  state.updatedAt = now;
  return state;
}

/** 取当前各原子读数（0~100）。 */
export function levels(state, cfg, now = Date.now()) {
  tick(state, cfg, now);
  const out = {};
  for (const [id, a] of Object.entries(state.atoms)) out[id] = r3(a.level);
  for (const [id, m] of Object.entries(state.mods)) out[id] = r3(m.level);
  return out;
}

/**
 * 合成器：状态 → 主导情绪 + 派生 + 旋钮 + 注入提示。
 *
 * 关键区别（对比现役）：现役是 **赢者通吃** —— 只有一个原子拿到行为脚本，
 * 其余拿到一句"还有点 X、Y 的小情绪"。这里所有原子都通过旋钮**同时**影响输出，
 * 主导情绪只是"用来解释"的那一个，不是"唯一有权说话"的那一个。
 */
export function render(state, cfg, now = Date.now()) {
  const s = levels(state, cfg, now);

  // 主导：只在 enabled 且 competes 的原子里比。
  // longing（慢变量）刻意不参与 —— 它和 joy 差一个数量级的时间尺度，
  // 并列争主导正是现役"吃醋"犯的错（异质成员同一把尺）。
  const ranked = Object.values(cfg.atoms)
    .filter((a) => a.enabled && a.competes === true)
    .map((a) => ({ id: a.id, label: a.label, level: s[a.id] || 0 }))
    .sort((a, b) => b.level - a.level);

  const top = ranked[0] || { id: null, label: '平静', level: 0 };
  const second = ranked[1] || { id: null, label: '', level: 0 };
  const dominant = {
    atom: top.level >= 20 ? top.id : null,
    label: top.level >= 20 ? top.label : '平静',
    level: r3(top.level),
    band: bandOf(top.level),
    margin: r3(top.level - second.level),
    runnerUp: second.level >= 20 ? { atom: second.id, label: second.label, level: r3(second.level) } : null,
    why: state.atoms[top.id]?.why || ''
  };

  // 旋钮第一步：base + Σ(原子/100 × 权重)，唤醒再调制 ⇒ raw
  // （钳制放在派生偏置之后统一做一次，见下）
  const raw = {};
  const clampedBy = [];
  for (const [kid, k] of Object.entries(cfg.knobs)) {
    let v = k.base;
    for (const [aid, w] of Object.entries(ATOM_KNOB_WEIGHTS)) {
      const amt = w[kid];
      if (amt === undefined) continue;
      if (!cfg.atoms[aid]?.enabled) continue;
      v += ((s[aid] || 0) / 100) * amt;
    }
    const stirW = STIR_KNOB_WEIGHTS[kid];
    if (stirW !== undefined) v += ((s.stir || 0) / 100) * stirW;
    raw[kid] = r3(Math.max(0, Math.min(1, v)));
  }

  // 派生：规则表，输出输入值以便面板解释
  const derived = [];
  // 情境标记来自事件，且必须还在保鲜期内
  const flagSet = new Set();
  for (const [f, ttl] of Object.entries(FLAG_TTL_MIN)) {
    const at = Number(state.flags?.[f]) || 0;
    if (at && now - at <= ttl * MIN) flagSet.add(f);
  }
  for (const rule of DERIVED_RULES) {
    if (!cfg.derivedIds.includes(rule.id)) continue;
    let ok = true;
    for (const [aid, need] of Object.entries(rule.requires || {})) {
      const src = aid === 'stir' ? s.stir : s[aid];
      if ((src || 0) < need) { ok = false; break; }
    }
    if (ok && rule.when && !rule.when(s)) ok = false;
    if (ok && rule.needs) ok = rule.needs.every((f) => flagSet.has(f));
    // notNeeds（2026-09-28）：反向标记条件——别扭=「吃醋减去第三方」，
    // 同一批 longing×unease，有 thirdParty 走吃醋、没有走别扭，二者互斥不打架。
    if (ok && rule.notNeeds) ok = rule.notNeeds.every((f) => !flagSet.has(f));
    if (!ok) continue;
    const val = clamp(rule.intensity(s));
    if (val <= 0) continue;
    derived.push({
      id: rule.id, label: rule.label, intensity: r3(val),
      band: bandOf(val),
      inputs: Object.fromEntries(Object.keys(rule.requires || {}).map((k) => [k, s[k] ?? s.stir])),
      knobBias: rule.knobBias || {}
    });
  }
  // 派生的旋钮偏置**先并进 raw**，再统一过一次钳制。
  // ⚠️ 顺序不能反：初版是先钳制、再把偏置加到 clamped 上再钳一次，
  //    结果这一步的钳制没进 clampedBy —— 面板上 warmth 显示 0.6 却没有任何"被卡拦过"的记录，
  //    等于可审计性在最关键的那一次拦截上瞎了。raw/clamped 语义也必须一致，否则面板没法解释。
  for (const d of derived) {
    for (const [kid, bias] of Object.entries(d.knobBias || {})) {
      if (cfg.knobs[kid] === undefined) continue;
      raw[kid] = r3(Math.max(0, Math.min(1, (raw[kid] ?? 0) + bias * (d.intensity / 100))));
    }
  }

  const clamped = {};
  for (const [kid, k] of Object.entries(cfg.knobs)) {
    const c = Math.max(k.min, Math.min(k.max, raw[kid] ?? 0));
    clamped[kid] = r3(c);
    if (Math.abs(c - (raw[kid] ?? 0)) > 0.001) {
      clampedBy.push({
        knob: kid, label: k.label, raw: raw[kid], clamped: r3(c),
        by: c > raw[kid] ? 'min' : 'max', limit: c > raw[kid] ? k.min : k.max
      });
    }
  }

  return {
    cardId: cfg.cardId,
    at: now,
    levels: s,
    dominant,
    derived,
    knobs: { raw, clamped, clampedBy },
    activeFlags: [...flagSet],
    blockedAtoms: Object.values(cfg.atoms).filter((a) => !a.enabled).map((a) => ({ atom: a.id, label: a.label, reason: 'disabled-by-card' })),
    hint: hintFrom(cfg, clamped, dominant)
  };
}

const KNOB_HINT = {
  talkativeness: ['话可以多说几句', '少说两句也无妨'],
  warmth: ['语气放软一点', '不必刻意热络'],
  sentenceLength: ['可以把话说完整', '短句就够了'],
  clinginess: ['想靠近一点', '保持一点距离'],
  hedging: ['可以先绕着问', '直接说就好'],
  selfDisclosure: ['可以说点自己的事', '自己的事不必多提'],
  guardedness: ['别把话说满', '不用设防'],
  intimacy: ['想凑近一点', '保持分寸'],
  aggression: ['', '']
};

/**
 * 注入提示：**只写行动倾向，不写情绪陈述**。
 * 现役 25 段自由文本产出"状态腔"的根因，就是写成了"我现在很难过"（陈述）
 * 而不是"我现在想做什么"（倾向）——笛卡尔《论灵魂的激情》art.40 早就说清楚了。
 * 且本函数**完全不读人设卡**，所以不存在把卡里的字面量念出来的风险。
 */
export function hintFrom(cfg, clamped, dominant) {
  const parts = [];
  const deltas = Object.entries(cfg.knobs)
    .map(([id, k]) => ({ id, label: k.label, d: (clamped[id] ?? 0) - k.base }))
    .filter((x) => Math.abs(x.d) >= 0.08)
    .sort((a, b) => Math.abs(b.d) - Math.abs(a.d))
    .slice(0, 3);
  for (const { id, d } of deltas) {
    const pair = KNOB_HINT[id];
    if (!pair) continue;
    const line = d > 0 ? pair[0] : pair[1];
    if (line) parts.push(line);
  }
  // ⚠️ 刻意**不写情绪名**。写「（吃醋）」等于告诉模型"你现在在吃醋"，
  //    它就会演一个"吃醋的人"——那正是状态腔的成因。派生名只进面板给人看，不进提示词。
  if (!parts.length) return '';
  return `${parts.join('，')}。`;
}

/** 一小层便利封装：把上面所有纯函数收成一个对象。 */
export function createCore({ cardId = 'default', profile = {}, state = null, now = Date.now() } = {}) {
  const cfg = compileProfile({ ...profile, cardId: profile.cardId || cardId });
  const st = state || createState(cfg, now);
  return {
    cfg,
    state: st,
    apply: (event, at = Date.now()) => applyEvent(st, cfg, event, at),
    regress: (at = Date.now()) => regress(st, cfg, at),
    levels: (at = Date.now()) => levels(st, cfg, at),
    render: (at = Date.now()) => render(st, cfg, at),
    tick: (at = Date.now()) => tick(st, cfg, at)
  };
}

export default {
  compileProfile, createState, createCore, tick, applyEvent, regress, levels, render,
  bandOf, BANDS, decayedLevel, hintFrom, SCHEMA_VERSION
};
