// 基础情绪原子集 —— 零依赖。
//
// ⚠️ 本文件的原子**不是手列的清单**，是从「评价格」的笛卡尔积导出来的。
//    理由：手列清单必然随作者偏好漂移，而现役五维（happy/excited/angry/jealous/sad）
//    正是这么来的——它把唤醒（excited）、复合态（angry/jealous）和效价（happy/sad）
//    混在同一把尺上，于是"苦甜交织"在结构上不可能、异质成员并列争"主导"。
//
// 评价三轴（取自 OCC / Ortony-Clore-Collins 1988，计算情绪领域最广泛使用的模型）：
//   branch  评的是什么   event 事件后果 | object 对象吸引 | agent 主体行为
//   time    时间指向     settled 已发生 | pending 未定 | durable 持续
//   valence 效价         positive 可欲 | negative 不可欲
//
// 事件分支的完备展开 = 2×2 = 4 格，一格不多一格不少：
//   settled×positive → joy   已得到的好事
//   settled×negative → sad   已发生的坏事 / 所依恋者缺席
//   pending×positive → hope  还没得到但盼着（OCC prospect-based 的 hope 方向）
//   pending×negative → unease  可能发生的不好的事（OCC 的 fear 方向）
// 对象分支再补 1 格：longing 眷恋（趋近）；其反向「排斥」= 厌恶，**默认不导出**
//   （绝大多数卡都没有合法的厌恶表达，开了只会被演出成毒舌/嫌弃 → 出卡）。
// 主体行为分支 = regard 敬服（OCC approbation），**默认关**：
//   它需要"规范/标准"这个评价源，聊天场景里很不稳定，先留位不启用。
//
// 一条硬纪律：**任何原子都必须有独立的行动倾向**（笛卡尔《论灵魂的激情》art.40：
// 激情的功能是推动灵魂去意愿某事）。没有可演出出口的"更基本的项"
// （例如《礼运》的欲/恶两极、斯宾诺莎的力量增减）哲学上更基本，但演不出来，不收。
//
// 唯一的例外（2026-09-28 用户拍板）：desire（亲密欲）来自 Panksepp 七系统的 LUST，
// **不是评价格的输出**——它是第一个"格外的"原子。作为交换条件，它：
//   ① enabledByDefault:false，没有任何卡默认拥有它；
//   ② 出口只有一个专属旋钮 intimacy（基础值 0），不污染其他旋钮语义；
//   ③ 闸门 I9 把关：profile 里启用它必须伴随 desireConfirmed:true（人工确认过
//      卡内有合法的亲密关系设定）——百可花「结婚」对话示例的误报证明词表不可信。

export const SCHEMA_VERSION = 1;

export const BRANCH = { EVENT: 'event', OBJECT: 'object', AGENT: 'agent' };
export const TIME = { SETTLED: 'settled', PENDING: 'pending', DURABLE: 'durable' };
export const VALENCE = { POSITIVE: 'positive', NEGATIVE: 'negative' };

/** 数值护栏（抄 ChatMood v1.3.0 的实测值，不是拍的）：单次事件最大跳变。 */
export const MAX_DELTA = 25;
/** 每次交互向基线回归的比例（同上，实测值）。 */
export const REGRESS_RATE = 0.025;

/**
 * 情境标记的保鲜期（分钟）。
 * 「第三方出现」是一次性的**事件事实**，不是持续状态——它必须会过期，
 * 否则她会在两小时后突然对一个早就翻篇的话题吃醋（现役 jealousy 的 releasedAt
 * 冷却只管"别重复发作"，管不了"前提已经不成立"这回事）。
 */
export const FLAG_TTL_MIN = { thirdParty: 45, attributionOther: 120, attributionSelf: 120 };

export const DEFAULT_ATOMS = {
  joy: {
    label: '欣喜', branch: BRANCH.EVENT, time: TIME.SETTLED, valence: VALENCE.POSITIVE,
    halfLifeMin: 30, competes: true, enabledByDefault: true, deck: '快'
  },
  sad: {
    label: '低落', branch: BRANCH.EVENT, time: TIME.SETTLED, valence: VALENCE.NEGATIVE,
    halfLifeMin: 120, competes: true, enabledByDefault: true, deck: '中'
  },
  hope: {
    label: '期盼', branch: BRANCH.EVENT, time: TIME.PENDING, valence: VALENCE.POSITIVE,
    halfLifeMin: 90, competes: true, enabledByDefault: true, deck: '中'
  },
  unease: {
    label: '不安', branch: BRANCH.EVENT, time: TIME.PENDING, valence: VALENCE.NEGATIVE,
    halfLifeMin: 90, competes: true, enabledByDefault: true, deck: '中'
  },
  longing: {
    label: '眷恋', branch: BRANCH.OBJECT, time: TIME.DURABLE, valence: VALENCE.POSITIVE,
    halfLifeMin: 720, competes: false, enabledByDefault: true, deck: '慢'
  },
  regard: {
    label: '敬服', branch: BRANCH.AGENT, time: TIME.DURABLE, valence: VALENCE.POSITIVE,
    halfLifeMin: 480, competes: false, enabledByDefault: false, deck: '慢'
  },
  // 唯一的非格导出原子（Panksepp LUST）。与 longing 的分工：
  //   longing = 持续的想念/想靠近（慢变量，12h 半衰期，可完全无性）；
  //   desire  = 当下的亲密驱动（45min，指向身体亲近）。
  // 只有配偶向卡在人工确认后显式开启；事件侧必须由宿主显式标 desire:true 才会涨——
  // 它不吃评价格的事件流，避免"任何好事"都被误读成亲密驱动。
  desire: {
    label: '亲密欲', branch: null, time: TIME.SETTLED, valence: VALENCE.POSITIVE,
    halfLifeMin: 45, competes: true, enabledByDefault: false, deck: '快',
    source: 'panksepp-lust', gridDerived: false
  }
};

/** 调制量：不是情绪，不参与主导竞争，只做乘数/开关。 */
export const DEFAULT_MODS = {
  stir: { label: '悸动', halfLifeMin: 10, note: '唤醒强度（Barrett / Russell 核心情感第二维）' },
  energy: { label: '精神', halfLifeMin: 480, note: '行动能力上限，钳制所有原子的表达幅度' }
};

/**
 * 表达旋钮（= Ortony & Turner 1990 说的"亚成分"层：比情绪名更接近可观测事实）。
 * 全部 0~1；aggression 默认是 0，绝大多数卡的钳制只需把它钉死即可。
 */
export const DEFAULT_KNOBS = {
  talkativeness: { label: '话量', base: 0.5 },
  warmth: { label: '语气暖度', base: 0.5 },
  sentenceLength: { label: '句长', base: 0.5, note: '0=碎句，1=长句' },
  clinginess: { label: '黏人', base: 0.3 },
  hedging: { label: '迂回试探', base: 0.3 },
  selfDisclosure: { label: '自我暴露', base: 0.3 },
  guardedness: { label: '收敛防备', base: 0.3 },
  aggression: { label: '攻击性', base: 0, note: '毒舌/嘲讽/愤怒的唯一出口；卡内无合法表达时钳到 0' },
  intimacy: { label: '亲密主动', base: 0, note: 'desire 的唯一出口；desire 关闭（默认）时恒为 0' }
};

/** 原子 → 旋钮 权重矩阵。值可正可负；旋钮值 = base + Σ(level/100 × weight)。 */
export const ATOM_KNOB_WEIGHTS = {
  joy: { talkativeness: +0.40, warmth: +0.50, sentenceLength: +0.10, selfDisclosure: +0.20, guardedness: -0.30 },
  sad: { talkativeness: -0.50, warmth: -0.15, sentenceLength: -0.35, selfDisclosure: -0.20, guardedness: +0.30 },
  hope: { talkativeness: +0.20, hedging: +0.40, clinginess: +0.15, warmth: +0.10 },
  unease: { hedging: +0.50, guardedness: +0.40, talkativeness: -0.10, sentenceLength: -0.20 },
  longing: { clinginess: +0.60, warmth: +0.30, selfDisclosure: +0.30, guardedness: -0.20 },
  regard: { warmth: +0.20, selfDisclosure: +0.10 },
  desire: { intimacy: +0.80, clinginess: +0.30, warmth: +0.10, hedging: -0.15 }
};

/** 唤醒（stir）对旋钮的调制：高唤醒 = 话更多、句子更碎。 */
export const STIR_KNOB_WEIGHTS = { talkativeness: +0.25, sentenceLength: -0.30, hedging: +0.15 };

/**
 * 派生情绪：**渲染时按规则表合成，不占状态位、不参与主导竞争**。
 * 这样"苦甜交织"第一次在结构上可能（现役共用一把尺，做不到），
 * 而且派生项是**可解释的**——面板能显示它的输入值和公式，不是一段黑箱散文。
 */
export const DERIVED_RULES = [
  {
    id: 'jealousy', label: '吃醋',
    requires: { longing: 45, unease: 35 },
    needs: ['thirdParty'],
    intensity: (s) => Math.sqrt(s.longing * s.unease),
    knobBias: { clinginess: +0.20, hedging: +0.30, warmth: -0.20 },
    note: '复合情绪的正确位置：不是并列维度，而是 longing × unease 的乘积项'
  },
  {
    id: 'bashful', label: '害羞',
    requires: { joy: 30, longing: 50, stir: 60 },
    intensity: (s) => (Math.min(s.joy, s.longing) * s.stir) / 100,
    knobBias: { selfDisclosure: -0.20, sentenceLength: -0.25, warmth: +0.20, hedging: +0.20 }
  },
  {
    id: 'aggrieved', label: '委屈',
    requires: { sad: 30 },
    needs: ['attributionOther'],
    intensity: (s) => s.sad * 0.8,
    knobBias: { clinginess: +0.30, hedging: +0.25, aggression: 0 },
    note: 'RAGE 通道的低唤醒出口（受伤向内）。aggression 权重写死 0——委屈不是愤怒的弱化版，它不该带攻击性；高唤醒出口=炸毛（fury），同一份 sad 按唤醒劈开'
  },
  {
    id: 'wistful', label: '感伤',
    requires: { joy: 25, sad: 25 },
    intensity: (s) => {
      const d = Math.abs(s.joy - s.sad) / Math.max(s.joy, s.sad);
      return d <= 0.25 ? Math.sqrt(s.joy * s.sad) : 0;
    },
    knobBias: { selfDisclosure: +0.25, sentenceLength: +0.20, talkativeness: -0.10 },
    note: 'expressions-plus 的 bittersweet 规则：两者都够高且差值 ≤25% 才成立'
  },
  {
    id: 'restless', label: '心浮',
    requires: { unease: 40, stir: 65 },
    intensity: (s) => Math.sqrt(s.unease * s.stir),
    knobBias: { talkativeness: +0.20, sentenceLength: -0.30, hedging: +0.20 }
  },
  {
    id: 'atease', label: '安然',
    requires: { longing: 50 },
    when: (s) => s.unease <= 20 && s.stir <= 35 && s.sad <= 25,
    intensity: (s) => s.longing * (1 - s.unease / 100),
    knobBias: { warmth: +0.20, guardedness: -0.25, sentenceLength: +0.15 },
    note: '被依恋着且安心。sad ≤25 是 2026-09-28 苏禾卡逼出的补丁——「沉底式安静」（longing 高+unease 低）会被旧公式误判成安然，但深度低落里没有安然；安心与低落互斥'
  },
  // ── 第二批（2026-09-28，G3 拍板落地）：全部用现有零件合成，不占状态位 ──────
  {
    id: 'awkward', label: '别扭',
    requires: { longing: 50, unease: 25 },
    notNeeds: ['thirdParty'],
    intensity: (s) => Math.sqrt(s.longing * s.unease) * 0.8,
    knobBias: { clinginess: +0.15, hedging: +0.30, warmth: -0.15 },
    note: '想靠近又不安，但没有第三方——傲娇的底料；与吃醋互斥（吃醋必须 thirdParty，别扭必须没有）'
  },
  {
    id: 'eager', label: '期待',
    requires: { hope: 40, stir: 50 },
    intensity: (s) => Math.sqrt(s.hope * s.stir),
    knobBias: { talkativeness: +0.20, sentenceLength: -0.15, hedging: +0.15 },
    note: '盼着的兴奋版：hope 够高且被唤醒抬高'
  },
  {
    id: 'smug', label: '得意',
    requires: { joy: 45, stir: 55 },
    intensity: (s) => Math.sqrt(s.joy * s.stir) * 0.9,
    knobBias: { talkativeness: +0.25, sentenceLength: -0.20, guardedness: -0.20 },
    note: '得逞了的雀跃；joy 单独高不算，必须有唤醒'
  },
  {
    id: 'guilty', label: '愧疚',
    requires: { sad: 35 },
    needs: ['attributionSelf'],
    intensity: (s) => s.sad * 0.7,
    knobBias: { selfDisclosure: +0.30, hedging: +0.25, warmth: +0.10 },
    note: '低落 + 归因于自己。与委屈（attributionOther）互为归因镜像——同一份 sad，怪别人是委屈，怪自己是愧疚'
  },
  {
    id: 'aching', label: '心疼',
    requires: { longing: 45, sad: 30 },
    intensity: (s) => Math.sqrt(s.longing * s.sad) * 0.85,
    knobBias: { warmth: +0.25, clinginess: +0.15, talkativeness: -0.10 },
    note: '为在意的人难过：longing（在意）× sad（难过）。归因目标是第三方的事，内核不表达，交给措辞层'
  },
  // ── 第三批（2026-09-28 19:1x，用户"再想一些"）─────────────────────────────
  {
    id: 'reluctant', label: '不舍',
    requires: { longing: 60 },
    when: (s) => s.hope <= 15 && s.stir <= 30,
    intensity: (s) => s.longing * (1 - s.hope / 100) * 0.9,
    knobBias: { clinginess: +0.30, sentenceLength: +0.20, talkativeness: -0.15 },
    note: '分开时刻的低唤醒眷恋：盼头（hope）熄了、也不激动，就是想多留一会儿。与安然的区别在 hope——安然的盼头是满的'
  },
  {
    id: 'relieved', label: '释然',
    requires: { joy: 30, sad: 20 },
    when: (s) => s.unease <= 15,
    intensity: (s) => s.joy * (1 - s.unease / 100) * 0.9,
    knobBias: { guardedness: -0.20, warmth: +0.15, talkativeness: +0.15 },
    note: '担心过去了的轻快：还残留一点 sad（余悸/代价），但不安已经落地'
  },
  {
    id: 'wary', label: '警觉',
    requires: { unease: 45 },
    when: (s) => s.stir <= 40,
    intensity: (s) => s.unease * (1 - s.stir / 100),
    knobBias: { guardedness: +0.35, hedging: +0.20, talkativeness: -0.20 },
    note: '冷静的提防：与心浮（restless）是同一份不安的两种唤醒态——低唤醒=警觉观察，高唤醒=心浮气躁，二者互斥'
  },
  {
    id: 'smitten', label: '心动',
    requires: { desire: 40, stir: 50, joy: 30 },
    intensity: (s) => Math.min(s.desire, s.stir) * s.joy / 100,
    knobBias: { intimacy: +0.30, hedging: +0.20, sentenceLength: -0.25 },
    note: '怦然：desire（亲密驱动）× 唤醒 × joy。第一批用到 desire 的派生——只在开了 desire 的卡上可能出现'
  },
  // ── 第四批（2026-09-28，desire 系扩容 + 病娇预铺）─────────────────────────
  // desire 稀疏（只认宿主显式事件、45min 半衰），门槛压到 30~40，且尽量与长寿原子组合。
  {
    id: 'possessive', label: '占有欲',
    requires: { desire: 35, longing: 35 },
    needs: ['thirdParty'],
    intensity: (s) => Math.sqrt(s.desire * s.longing) * 0.85,
    knobBias: { clinginess: +0.40, intimacy: +0.20, warmth: -0.10 },
    note: '提到别人时贴得更近、话里有话。与吃醋的差异：吃醋=longing×unease（慌），占有欲=desire×longing（近）——病娇卡的主力派生，普通卡是偶发萌点'
  },
  {
    id: 'craving', label: '焦渴',
    requires: { desire: 40, unease: 25 },
    when: (s) => s.joy <= 20,
    intensity: (s) => s.desire * (1 - s.joy / 100),
    knobBias: { intimacy: +0.25, clinginess: +0.30, hedging: -0.20 },
    note: '想要而不得的烦躁：与心动按 joy 劈开（心动 joy≥30，焦渴 joy≤20），互斥成对'
  },
  {
    id: 'sated', label: '餍足',
    requires: { desire: 30 },
    when: (s) => s.desire <= 55 && s.joy >= 40 && s.unease <= 15 && s.stir <= 45,
    intensity: (s) => s.joy * (s.desire / 100),
    knobBias: { warmth: +0.25, guardedness: -0.30, sentenceLength: +0.15 },
    note: '亲近之后的安稳：唯一要求 desire「中等而非高」的规则。stir 上限 45 是动力学实测定的——desire/joy 事件本身都抬 stir（+20/条），「joy≥40 且 stir≤25」在事件驱动下不可达；45 仍低于心动的 50 与心浮的 65，语义是「兴奋已回落」'
  },
  {
    id: 'flustered', label: '羞赧',
    requires: { desire: 30, sad: 20 },
    needs: ['attributionSelf'],
    intensity: (s) => Math.sqrt(s.desire * s.sad) * 0.8,
    knobBias: { hedging: +0.30, selfDisclosure: -0.30, sentenceLength: -0.20 },
    note: '欲望被自己意识到/被点破时的难堪：desire × sad（难堪）× 归因self——复用愧疚的标记，但内核面是「驱动被撞见」而非「做错了事」'
  },
  // ── 第五批（2026-09-28 深夜，批2遗留清账）─────────────────────────────────
  {
    id: 'fury', label: '炸毛',
    requires: { sad: 30, stir: 55 },
    needs: ['attributionOther'],
    intensity: (s) => Math.sqrt(s.sad * s.stir) * 0.9,
    knobBias: { aggression: +0.50, talkativeness: +0.15, hedging: -0.20 },
    note: '被冤枉/被冒犯的高唤醒对抗态：与委屈是同一份 sad 的两种唤醒态（低唤醒=委屈受伤，高唤醒=炸毛对线，同 wary/restless 的劈法）。needs attributionOther——怒有明确对象（「明明是他先动手的」）；aggression 偏置 +0.50 是内核首次给攻击性开口子，实际表达仍被卡级 aggression.max 钳制（美琴 0.5/伏特加 0.4/其余 0=想炸也炸不出，可审计）'
  },
  {
    id: 'revere', label: '既敬且亲',
    requires: { regard: 45, longing: 45 },
    intensity: (s) => Math.sqrt(s.regard * s.longing) * 0.85,
    knobBias: { warmth: +0.20, hedging: +0.15, clinginess: +0.10 },
    note: '敬慕与亲近并存：「想成为那样的人」+「想靠近」。regard 走 agent 分支（对行为的敬服）、longing 走 object 分支（想靠近），两个慢变量相乘——敬慕第二张（久美子）与敬慕型（特别周）双卡验证的语义'
  },
  {
    id: 'reverePain', label: '敬重之痛',
    requires: { regard: 45, sad: 30 },
    intensity: (s) => Math.sqrt(s.regard * s.sad) * 0.8,
    knobBias: { selfDisclosure: +0.20, warmth: +0.15, talkativeness: +0.10 },
    note: '看着敬佩的人坠落/放弃时的难过：与心疼（longing×sad「为在意的人难过」）的分工在在意源——心疼是亲近之苦，敬重之痛是「那样的人不该这样」的失落，会忍不住开口（「……不甘心吗？」）'
  }
];

/**
 * 评价（appraisal）：把一个事件翻译成对各原子的增量。
 *
 * @param {object} e
 *   branch      'event'|'object'|'agent'   评的是什么（缺省 'event'）
 *   time        'settled'|'pending'         已发生 / 还没定（缺省按 valence 推：负向多为已发生）
 *   valence     -1 ~ 1                      可欲为正
 *   intensity   0 ~ 1
 *   attribution 'other'|'none'|'self'       归因（斯宾诺莎：情绪 = 效价 + 外在原因的观念）
 *   thirdParty  boolean                     是否涉及第三方（吃醋的必要条件）
 *   uncertain   boolean                     本地判定拿不准时打折，不硬判方向
 * @returns {{deltas: Array<{atom:string,delta:number,why:string}>, attribution: string|null, flags: string[]}}
 */
export function appraise(e) {
  const ev = e || {};
  // ⚠️ 按**值**校验，不是按 key：BRANCH 的 key 是大写的 EVENT/OBJECT/AGENT，
  //    而调用方传的是小写值 'object'。写成 BRANCH[ev.branch] 会静默回落成 event
  //    ——这个 bug 被 test.mjs 第 15 组抓到（对象分支的增量压根没生成）。
  const branch = [BRANCH.EVENT, BRANCH.OBJECT, BRANCH.AGENT].includes(ev.branch) ? ev.branch : BRANCH.EVENT;
  const valence = Math.max(-1, Math.min(1, Number(ev.valence) || 0));
  let intensity = Math.max(0, Math.min(1, Number(ev.intensity) || 0));
  const flags = [];
  if (ev.uncertain === true) { intensity *= 0.5; flags.push('uncertain'); }
  if (ev.thirdParty === true) flags.push('thirdParty');
  const attribution = ev.attribution || null;
  if (attribution === 'other') flags.push('attributionOther');
  if (attribution === 'self') flags.push('attributionSelf'); // 愧疚类派生的前提（2026-09-28 新增）

  const amp = MAX_DELTA * intensity;
  const out = [];

  if (branch === BRANCH.EVENT) {
    // 时间指向缺省：pending 只在调用方明确给出时采用，避免"未来的坏事"被当成已发生。
    const pending = ev.time === TIME.PENDING;
    const pos = valence >= 0;
    if (!pending && pos) {
      out.push({ atom: 'joy', delta: +amp * valence, why: '已得到的好事' });
      out.push({ atom: 'sad', delta: -amp * valence * 0.4, why: '交叉抑制' });
    } else if (!pending && !pos) {
      out.push({ atom: 'sad', delta: +amp * -valence, why: '已发生的坏事' });
      out.push({ atom: 'joy', delta: -amp * -valence * 0.4, why: '交叉抑制' });
    } else if (pending && pos) {
      out.push({ atom: 'hope', delta: +amp * valence, why: '盼着的好事' });
    } else {
      out.push({ atom: 'unease', delta: +amp * -valence, why: '可能发生的不好的事' });
      out.push({ atom: 'hope', delta: -amp * -valence * 0.4, why: '交叉抑制' });
    }
    // 唤醒跟着强度走，但只有强事件才明显
    if (intensity >= 0.4) out.push({ atom: 'stir', delta: +amp * 0.8, why: '强事件抬高唤醒' });
  } else if (branch === BRANCH.OBJECT) {
    const d = valence >= 0 ? +amp * valence : -amp * -valence * 0.6;
    out.push({ atom: 'longing', delta: d, why: valence >= 0 ? '想靠近' : '被推开' });
  } else if (branch === BRANCH.AGENT) {
    out.push({ atom: 'regard', delta: valence >= 0 ? +amp * valence : -amp * -valence * 0.5, why: '对行为的赞同/不赞同' });
    // 🔴 v1.1 评价映射扩展（2026-10-02 A/B 实测拍板）：agent 正效价溢出喜悦。
    // OCC 原义：他者行为的赞同（approbation）本身就伴随 joy——被夸是"已得到的好事"。
    // 此前 agent 只推 regard，而 regard enabledByDefault:false ⇒ 大多数卡被夸情绪零反应
    // （实测：猫尾草「饱饱你好聪明」v=0.8 i=0.9 全 blocked）。溢出系数 0.5：
    // 敬服仍是 agent 分支的主信号（慢变量），joy 是即时伴随（快变量），不喧宾夺主。
    // 负效价（行为被贬）不溢出——被贬的 joy 交由 event 分支的交叉抑制处理，此处不双重扣。
    if (valence >= 0) {
      out.push({ atom: 'joy', delta: +amp * valence * 0.5, why: '被赞同的欣喜（agent 溢出 0.5）' });
    }
  }

  // desire 通道：不吃评价格的事件流，只有宿主**显式**标 desire:true 才涨。
  // 否则"任何好事"都会被误读成亲密驱动（比如被夸 → 想贴贴，方向就错了）。
  if (ev.desire === true) {
    const di = Math.max(0.3, Math.min(1, Number(ev.intensity) || 0.3));
    out.push({ atom: 'desire', delta: +MAX_DELTA * di * 0.8, why: '亲密驱动（宿主显式标记）' });
  }

  return { deltas: out, attribution, flags };
}

export default {
  SCHEMA_VERSION, BRANCH, TIME, VALENCE, MAX_DELTA, REGRESS_RATE,
  DEFAULT_ATOMS, DEFAULT_MODS, DEFAULT_KNOBS, ATOM_KNOB_WEIGHTS, STIR_KNOB_WEIGHTS,
  DERIVED_RULES, appraise
};
