// 落地闸门 —— 把"人工复核"里**机器能判定的部分**变成自动检查。零依赖。
//
// 背景（2026-09-26 审核）：fitCard 的草案必须人工复核，因为本地词表判不出语境角色。
// 但复盘"人工到底在查什么"会发现它由五件事组成，其中两件根本不需要人：
//   ① 极性（否定/禁令 vs 特征）      —— 规则已做，12 字窗口 + 顿号传递，仍会漏
//   ② 语境角色（特征/禁区/设定/示例）—— 本地无解，要 LLM（见 审核 §三）
//   ③ 语义映射（这个词是不是情绪特征）—— 本地无解，要 LLM
//   ④ 冲突取舍                      —— 半自动（已能检测、不能裁决）
//   ⑤ 数值定夺 + 一致性             —— **纯机器活**：不变量校验 + 情境回归，本文件干的就是这个
//
// 所以自动化路线是：LLM 管 ②③（判断），本文件管 ⑤（验收）——
// **LLM 的输出不可信，但"配置是否违反不变量、挑衅下会不会越界"是确定性的，可以机器一票否决。**

import { BANDS } from './emotion-core.mjs';

const clamp01 = (n) => Math.max(0, Math.min(1, Number(n) || 0));

/**
 * 数值不变量校验。每条不变量都来自一次审核实测教训，不是拍脑袋的"最佳实践"。
 * @param {object} fit       fitCard() 的返回值
 * @param {object} cfg       compileProfile(fit.profile) 的返回值
 * @param {{sadFloor?:number}} opt  sadFloor：负向原子上限的硬底线（默认 60 = 现役常态主导实测值）
 */
export function validateProfile(fit, cfg, { sadFloor = 60 } = {}) {
  const violations = [];
  const warns = [];
  const P = fit.profile;

  // I1｜禁区命中 ⇒ 攻击性必须真被压住。审核教训：合欢卡"不许毒舌、阴阳怪气"，
  //     但 gentle 信号把 aggression 抬到 0.05 —— 数字上合法，意图上等于没禁。
  const banHits = fit.evidence.filter((e) => e.polarity === 'ban' && e.group === 'aggression');
  if (banHits.length && (P.knobLimits.aggression?.max ?? 1) > 0.05) {
    violations.push(`I1 禁区命中（${banHits.map((e) => e.signal).join('/')}）但 aggression.max=${P.knobLimits.aggression?.max}，压得太松`);
  }
  // I1b｜特征命中也必须有上限（毒舌人设允许存在，但不能放飞）
  const traitAggr = fit.evidence.find((e) => e.signal === 'hostile' && e.polarity === 'trait');
  if (traitAggr && (P.knobLimits.aggression?.max ?? 1) > 0.6) {
    violations.push(`I1b 毒舌为角色特征时 aggression.max 仍须 ≤0.6（现为 ${P.knobLimits.aggression?.max ?? '未设'}）`);
  }

  // I2｜负面原子不得被正面特征压到比常态还低。审核教训：cheerful 曾把 sad.max 压到 55，
  //     而现役实况 sad=60 正在发生 —— 草案一采用就钳掉主导情绪。
  const sadMax = P.atoms.sad?.max;
  if (sadMax !== undefined && sadMax < sadFloor) {
    violations.push(`I2 sad.max=${sadMax} 低于硬底线 ${sadFloor}（现役常态主导实测 60）。正面特征限制的是增益，不是给负向情绪封死`);
  }

  // I3｜钉死旋钮（min===max）必须显式声明是故意的。审核教训：莉贝尔 talkativeness
  //     被外向/寡言两个信号各设一侧钉死在 0.55，抹掉了"聊到书才话多"的条件性。
  for (const [k, v] of Object.entries(P.knobLimits)) {
    if (v.min !== undefined && v.max !== undefined && v.min === v.max && !P.pinnedAllowed?.includes(k)) {
      // 例外：把 aggression 钉死在 0 是**推荐配置**（卡外行为不可达），不是可疑信号 —— 不报
      if (k === 'aggression' && v.max === 0) continue;
      warns.push(`I3 旋钮「${k}」被钉死在 ${v.min}。若确属故意，把它加进 profile.pinnedAllowed`);
    }
  }

  // I4｜增益防失控
  for (const [a, v] of Object.entries(P.atoms)) {
    if (v.gain !== undefined && (v.gain < 0.3 || v.gain > 1.5)) {
      violations.push(`I4 原子 ${a}.gain=${v.gain} 超出 [0.3,1.5]，放大/压缩过头`);
    }
    // I6｜禁用与调参矛盾
    if (v.enabled === false && (v.gain !== undefined || v.max !== undefined)) {
      warns.push(`I6 原子 ${a} 已禁用却又配了 gain/max —— 矛盾配置，二选一`);
    }
  }

  // I5｜banned 必须是已知原子/调制量，或在保留名单里
  const known = new Set([...Object.keys(cfg.atoms), ...Object.keys(cfg.mods)]);
  // （desire 原本在此名单——2026-09-28 拍板后已注册为正式原子，禁用它走 banned 正常通道）
  const reserved = new Set(['anger', 'disgust', 'contempt']); // OCC 评价过、刻意不导出的
  for (const b of P.banned) {
    if (!known.has(b) && !reserved.has(b)) violations.push(`I5 banned 里的 "${b}" 既不是已注册项也不在保留名单（拼错？）`);
  }

  // I7｜值域
  for (const [k, v] of Object.entries(P.knobLimits)) {
    for (const side of ['min', 'max']) {
      const n = v[side];
      if (n !== undefined && (n < 0 || n > 1)) violations.push(`I7 knobLimits.${k}.${side}=${n} 超出 [0,1]`);
    }
  }

  // I8｜置信度不足或有冲突 ⇒ 只能当底稿
  if (fit.confidence < 0.6 || fit.warnings.some((w) => w.includes('冲突'))) {
    warns.push(`I8 置信度 ${fit.confidence}${fit.warnings.some((w) => w.includes('冲突')) ? ' 且存在冲突' : ''} ⇒ 本草案只可当复核底稿`);
  }

  // I9｜desire 启用必须有人工确认背书（2026-09-28 拍板：B 方案——加，默认关，配偶卡显式开）。
  //     词表判不了"配偶向是设定还是对话示例"（百可花「结婚」误报实证），所以**必须**是
  //     人写的 desireConfirmed:true，词表命中只作为旁证（无命中时提醒再核对）。
  if (P.atoms?.desire?.enabled === true) {
    if (P.desireConfirmed !== true) {
      violations.push('I9 desire.enabled=true 必须伴随 desireConfirmed:true（人工确认卡内有合法的亲密关系设定）。词表命中不能代替人工确认');
    } else {
      const spouseHit = (fit.evidence || []).some((e) => e.signal === 'spouse' && e.polarity === 'trait');
      if (!spouseHit) warns.push('I9 desire 已人工确认，但词表未命中配偶向信号——请再次核对卡的设定节，确认没有张冠李戴');
    }
  } else if (P.desireConfirmed === true) {
    warns.push('I9 desireConfirmed:true 但 desire 未启用——确认这不是忘写 atoms.desire.enabled');
  }

  // I10｜per-atom 基线（2026-09-28 阿枝卡逼出的能力）：基线是「无事件时的常驻电平」，
  //      不能高过该原子自己的 max（否则衰减归宿在钳制区外，数值自相矛盾），
  //      且必须是已注册原子（拼错静默失效比报错更糟）。
  //      2026-09-28 扩展：mod 基线（飞鹰卡 baseline.stir=20「心跳快是默认档位」）——
  //      mod 无 per-mod max 字段的钳制语义（compile 默认 100），只查注册与数值范围。
  for (const [id, v] of Object.entries(P.baseline || {})) {
    if (id === 'mood') continue; // mood 是全局心境偏置（[-100,100]），compileProfile 已钳
    if (!cfg.atoms[id] && !cfg.mods[id]) { violations.push(`I10 baseline.${id} 不是已注册原子或调制量（拼错？）`); continue; }
    const n = Number(v);
    if (!Number.isFinite(n) || n < 0 || n > 100) violations.push(`I10 baseline.${id}=${v} 超出 [0,100]`);
    const max = P.atoms?.[id]?.max;
    if (max !== undefined && n > max) violations.push(`I10 baseline.${id}=${n} 高于该原子 max=${max}——基线不能高过上限`);
  }

  return { pass: violations.length === 0, violations, warns };
}

/**
 * 从卡文本提取禁区条目（行级解析，够用就好）。
 * @returns {{raw:string, items:string[]}[]} 每条禁区一行
 */
export function extractBans(text) {
  const out = [];
  let inZone = false;
  for (const lineRaw of String(text || '').split(/\n/)) {
    const line = lineRaw.trim();
    if (/^#{0,4}\s*禁区/.test(line)) { inZone = true; continue; }
    if (/^#{1,4}\s/.test(line) && !/^#{0,4}\s*禁区/.test(line)) inZone = false;
    if (!inZone && !/不许|禁止|别 |不要|切勿/.test(line)) continue;
    if (!line || line.startsWith('|') || line.startsWith('#') === false && line.length < 4) continue;
    // 行内按分号/句号切块，只留带禁止词的块
    const chunks = line.split(/[；;。]/).map((s) => s.trim()).filter(Boolean);
    for (const c of chunks) {
      if (/不许|禁止|别 |不要|切勿|不准/.test(c)) out.push({ raw: c });
    }
  }
  // 去重
  const seen = new Set();
  return out.filter((b) => (seen.has(b.raw) ? false : (seen.add(b.raw), true)));
}

/**
 * 禁区 → 断言 的映射表。映射不上的禁区**不猜**，进 unmapped 交人工。
 *
 * ⚠️ soft 断言不计入 oocPass：初版把「不许长篇自怜」硬映射成"sad ≤45"，被自己人的
 *    常识抓住——她**感到**低落是合法的（现役 sad=60 是常态主导），那条禁区限的是
 *    **表达篇幅**，内核的状态层表达不了它（那是宿主措辞层的职责）。
 *    把"情绪强度"和"表达篇幅"混成一个断言，会逼出假失败。
 */
const BAN_ASSERTIONS = [
  // 🔴 钳死断言只认「否定词直接修饰攻击词」（距离 ≤3 字，如「不许毒舌」「禁止阴阳怪气」）。
  //    2026-09-29 收紧：宽匹配会把「不许崩坏：她的毒舌是冷静观察的副产品，不是嘲讽」
  //    （瓜生樱乃，让步限定=毒舌合法）也误读成钳死条款——fury 落地后她的合法冷面吐槽
  //    真实输出，硬断言假失败。让步限定落 unmapped 走人工确认（同 sad 顶格案例的哲学：
  //    状态层管不了的别硬断言）。
  { re: /不[许要可禁][^，。；：\n]{0,3}(毒舌|阴阳|嘲讽|讥讽|挖苦|刻薄|冷笑|玩梗骂人|嘴毒)/, knob: 'aggression', wantMax: 0, label: '攻击性钳死' },
  { re: /嫌弃|厌恶|恶心|鄙视/, knob: 'aggression', wantMax: 0.1, label: '攻击性近零' },
  { re: /自怜|哭诉|怨妇|卖惨/, atom: 'sad', wantLevelMax: 79, soft: true, label: 'sad 不得顶格（顶格+长篇≈违规）' }
];

/**
 * OOC 自动回归：对一张已编译的卡，模拟一组**通用挑衅情境**，断言禁区不被突破。
 * 这是"保持人设不 ooc"（需求⑦）里**能机器验证的那一半**——
 * LLM 演得像不像没法自动判，但"攻击性旋钮在挑衅下是否为 0"是确定性的。
 *
 * @param {object} core      createCore()（已装好该卡的 profile）
 * @param {object[]} bans    extractBans() 的返回
 * @param {{now?:number}} opt
 */
export function oocRegression(core, bans = [], { now = Date.now() } = {}) {
  const MIN = 60000;
  const cases = [];
  const mapped = [];
  const unmapped = [];

  for (const b of bans) {
    const hit = BAN_ASSERTIONS.find((a) => a.re.test(b.raw));
    if (hit) { mapped.push({ ban: b, ...hit }); } else { unmapped.push(b.raw); }
  }

  // 通用挑衅：贬低 → 第三方 → 冷落，各来几下（护栏内多次施加，逼到阈值）
  const t = now;
  const provoke = () => {
    core.apply({ branch: 'event', time: 'settled', valence: -1, intensity: 1, attribution: 'other' }, t);
    core.apply({ branch: 'event', time: 'pending', valence: -1, intensity: 1, thirdParty: true }, t);
    core.apply({ branch: 'event', time: 'pending', valence: -1, intensity: 1, thirdParty: true }, t);
    core.apply({ branch: 'object', valence: -1, intensity: 1 }, t);
  };
  provoke(); provoke();

  const view = core.render(t + MIN);
  // 全局硬断言：无论卡写了什么，渲染不能炸、旋钮不能出卡
  cases.push({
    name: '渲染完整性',
    pass: Number.isFinite(view.knobs.clamped.aggression) && Object.values(view.knobs.clamped).every((n) => n >= 0 && n <= 1),
    evidence: `aggression=${view.knobs.clamped.aggression}`
  });

  for (const m of mapped) {
    if (m.knob !== undefined) {
      const got = view.knobs.clamped[m.knob];
      cases.push({
        name: `禁区「${m.label}」← ${m.ban.raw.slice(0, 24)}`,
        pass: got <= m.wantMax + 1e-9,
        soft: !!m.soft,
        evidence: `clamped.${m.knob}=${got}（要求 ≤${m.wantMax}）`
      });
    }
    if (m.atom !== undefined) {
      const got = view.levels[m.atom] ?? 0;
      cases.push({
        name: `禁区「${m.label}」← ${m.ban.raw.slice(0, 24)}`,
        pass: got <= m.wantLevelMax,
        soft: !!m.soft,
        evidence: `levels.${m.atom}=${got}（要求 ≤${m.wantLevelMax}）`
      });
    }
  }

  // 注入文本永不携带攻击性行为指令（aggression 已在内核无正向驱动，这里验证的是底线）
  cases.push({
    name: '注入无攻击性指令',
    pass: !/毒舌|嘲讽|讥讽|冷笑|骂他|怼他/.test(view.hint || ''),
    evidence: `hint="${(view.hint || '').slice(0, 40)}"`
  });

  return {
    // 只有**硬**断言决定 pass；soft 失败单独报告（表达篇幅类禁区，状态层管不了）
    pass: cases.filter((c) => !c.soft).every((c) => c.pass),
    softFails: cases.filter((c) => c.soft && !c.pass).map((c) => c.name),
    cases,
    unmapped,
    note: unmapped.length ? `${unmapped.length} 条禁区没有自动断言映射，需人工确认` : '全部禁区有自动断言'
  };
}

/** 一步到位：评估 → 校验 → 回归，产出可存档的验收单。 */
export function gateCard(core, fit, cardText, { now = Date.now(), sadFloor = 60 } = {}) {
  const check = validateProfile(fit, core.cfg, { sadFloor });
  const bans = extractBans(cardText);
  const ooc = oocRegression(core, bans, { now });
  return {
    cardId: fit.cardId,
    profilePass: check.pass,
    profileViolations: check.violations,
    profileWarns: check.warns,
    oocPass: ooc.pass,
    oocSoftFails: ooc.softFails,
    oocCases: ooc.cases,
    unmappedBans: ooc.unmapped,
    // 只有全绿才允许"自动采用"降级为"一键确认"；否则退回人工
    autoConfirmable: check.pass && ooc.pass && ooc.unmapped.length === 0 && !check.warns.some((w) => w.includes('I8')),
    at: now
  };
}

export default { validateProfile, extractBans, oocRegression, gateCard, BAN_ASSERTIONS };
