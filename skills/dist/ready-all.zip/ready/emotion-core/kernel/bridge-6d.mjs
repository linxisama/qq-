// 与 QQ-Agent 0.3.0 现役「六维记忆」的对接层（需求 ④）—— 可选，且**内核不依赖它**（需求 ⑤）。
//
// ⚠️ 本文件**不 import 任何宿主模块**。六维那边的函数由宿主**注入**进来：
//      createBridge({ core, memory6d: { scoreText, aggregate, snapshotFromText } })
//    这样内核在没有六维记忆的环境里照常跑（需求 ⑤ 的硬保证，不是口头保证）。
//
// 对接点只有两个，方向相反：
//   写方向（情绪 → 记忆）：内核的评价事件编码成 E 维记录，交给宿主写进记忆条目。
//     现役 E 维 = src/emotion-residue.js，导出
//       scoreText(text,{explain}) → {valence,intensity,uncertain,hits,lexVersion}
//       snapshotFromText(text,{at,subject,src}) → 一条可直接落盘的 E 维记录
//       aggregate(entries,now,{halfLifeHours,windowHours}) → {residue,valence,count,latestAt}
//       residueAt(intensity,at,now,{halfLifeHours}) / LEX_VERSION / E_WEIGHT_DEFAULT
//     ——以上是 2026-09-26 实读本机 src/ 核过的，不是按文档猜的。
//   读方向（记忆 → 情绪）：E 维残留聚合出「心境底色」，回灌成 baseline.mood，
//     让内核在下一个事件上带心境依存偏置（mood-congruent encoding）。
//
// 🔴 一条纪律：E 维是**状态**不是**事实**——情绪残留绝不能写进 facts/events 当断言。
//    这条是六维那边自己立的红线（emotion-residue.js 文件头第 ① 条），对接时不能破。

/**
 * @param {object} core      createCore() 的返回值
 * @param {object} memory6d  宿主注入的六维接口；缺省则整座桥退化为空操作
 */
export function createBridge(core, memory6d = null) {
  const m = memory6d || {};
  const has = (fn) => typeof m[fn] === 'function';
  const ok = has('scoreText') && has('aggregate');

  return {
    available: ok,
    missing: ['scoreText', 'aggregate', 'snapshotFromText'].filter((k) => !has(k)),

    /**
     * 读方向：把一批 E 维记录聚合成心境底色，写进内核。
     * @returns {{mood:number, residue:number, valence:number, count:number}|null}
     */
    pullBaseline(entries, now = Date.now()) {
      if (!ok) return null;
      const agg = m.aggregate(entries, now, { halfLifeHours: 8, windowHours: 48 }) || {};
      const residue = Number(agg.residue) || 0;
      const valence = Number(agg.valence) || 0;
      // residue 0~1，valence -1~1 ⇒ mood -100~100。残留在 0.1 以下时不再偏置，避免噪声主导。
      const mood = residue < 0.1 ? 0 : Math.round(valence * residue * 100);
      core.state.baseline = { ...(core.state.baseline || {}), mood };
      return { mood, residue, valence, count: Number(agg.count) || 0 };
    },

    /**
     * 写方向：用六维那套词表给一段文本打分，再翻译成内核的评价事件并施加。
     * 这样内核与六维**共用同一个情绪判定源**，不会出现两套词表互相打架。
     * @returns {{applied:Array, blocked:Array, from:{valence:number,intensity:number,uncertain:boolean}, fallback:boolean}}
     *   fallback=true 表示宿主没注入接口，改用了内核自带的兜底（恒定强度，无方向判断）
     */
    appraiseText(text, { branch = 'event', time = null, attribution = null, thirdParty = false, now = Date.now() } = {}) {
      let valence = 0;
      let intensity = 0.5;
      let uncertain = false;
      let fallback = false;
      if (has('scoreText')) {
        const s = m.scoreText(text) || {};
        valence = Number(s.valence) || 0;
        intensity = Number(s.intensity) || 0;
        uncertain = !!s.uncertain;
      } else {
        fallback = true;
        uncertain = true; // 兜底时一律标不确定 ⇒ 强度打对折、不硬判方向
      }
      const r = core.apply({ branch, time, valence, intensity, attribution, thirdParty, uncertain }, now);
      return { ...r, from: { valence, intensity, uncertain }, fallback };
    },

    /** 把一段文本编码成可直接落盘的 E 维记录（宿主负责真正写库）。 */
    toMemoryRecord(text, { at = Date.now(), subject = null } = {}) {
      if (has('snapshotFromText')) return m.snapshotFromText(text, { at, subject, src: 'emotion-core' });
      if (has('scoreText')) {
        const s = m.scoreText(text) || {};
        return { valence: s.valence || 0, intensity: s.intensity || 0, at, src: 'emotion-core/scoreText' };
      }
      return null;
    }
  };
}

export default { createBridge };
