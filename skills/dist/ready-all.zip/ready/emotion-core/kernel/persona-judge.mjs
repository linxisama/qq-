// LLM 判读通道（opt-in）—— 零依赖。
//
// 🔴 使用纪律（用户 2026-09-26 明确要求）：
//   1. **是否用 LLM 完全由用户决定**：不注入 judge 函数，本通道就不存在，
//      fitCard / 手写 profile 两条路照常工作，行为与从前完全一致。
//   2. **用户可以选择自己编写**：handGate() 让手写的 profile 走同一套闸门
//      （不变量 + OOC 挑衅回归），不经过 fitCard、更不经过 LLM。
//   3. LLM 的产出永远是**建议**：只回 JSON 数字/枚举，过 schema 校验，
//      与规则通道交叉对比，**不一致必标红**，永不静默采用。
//
// 隐私知情：judge 被调用时会把**命中词 ±40 字上下文**发给宿主配置的模型服务商。
// 这是用户选择启用本通道即视为同意的事项；不想发就用 off 路径（手写 + 闸门）。
//
// 与 bridge-6d 同款模式：内核不 import 任何 SDK/HTTP 客户端，宿主注入：
//   judge = async ({ messages, temperature }) => string   （返回模型原文）
// 怎么发请求（fetch 哪个 endpoint、带哪个 key）全部是宿主的事。

import { mergeLimits } from './persona-fit.mjs';
import pfDefault from './persona-fit.mjs';
const SIGNAL_BY_ID = Object.fromEntries(pfDefault.SIGNALS.map((s) => [s.id, s]));

const CONTEXT_RADIUS = 40; // 命中词前后各取多少字给模型判断

/**
 * 收集需要判语境的命中词及其上下文。
 * 上下文刻意截短（±40 字）：够模型判断"这句话在说谁、是不是禁令"，
 * 又不会把整张卡搬进请求 —— 隐私最小化。
 *
 * @param {string} text     卡全文
 * @param {Array} evidence  fitCard() 的返回 .evidence
 * @returns {{items:Array, note:string}}  items: [{signal, word, context}]
 */
export function collectContexts(text, evidence = []) {
  const raw = String(text || '');
  const lower = raw.toLowerCase();
  const items = [];
  const seen = new Set();

  for (const e of evidence) {
    for (const w of [...(e.hits || []), ...(e.negated || [])]) {
      const lw = w.toLowerCase();
      let from = 0;
      for (;;) {
        const idx = lower.indexOf(lw, from);
        if (idx < 0) break;
        from = idx + lw.length;
        const key = `${e.signal}:${w}`;
        if (seen.has(key)) continue; // 同词多次出现只送一处（省 token；判断极性够用）
        seen.add(key);
        items.push({
          signal: e.signal,
          word: w,
          context: raw.slice(Math.max(0, idx - CONTEXT_RADIUS), idx + w.length + CONTEXT_RADIUS).replace(/\s+/g, ' ')
        });
        break;
      }
    }
  }
  return {
    items,
    note: `上下文截取 ±${CONTEXT_RADIUS} 字，隐私最小化；同词多次出现只送第一处`
  };
}

/**
 * 组装发给模型的请求体。宿主负责真正发出去。
 * @returns {{messages:[{role,content}], temperature:number, expect:'json'}}
 */
export function buildJudgeRequest(items) {
  const lines = items.map((it, i) => `${i + 1}. 词「${it.word}」 上下文：…${it.context}…`);
  const content = [
    '你在帮一个聊天机器人的情绪系统审核角色卡。下面每个「词」都是从卡里找到的候选情绪特征词。',
    '请对每个词判断：',
    '  polarity: "trait"（这是角色的性格特征，允许表现）',
    '            | "ban"（这是禁区/否定/不许做的事，必须压制）',
    '            | "irrelevant"（与情绪特征无关：背景设定、对话示例、条件性行为描写等）',
    '注意：中文卡常用「不许A、B、C」的清单写法，否定词管整串；',
    '「被要求X→拒绝」说明角色不做X，不是角色有X这个特征。',
    '只输出 JSON 数组，不要解释：[{"i":1,"polarity":"..."},{"i":2,...}]',
    '',
    ...lines
  ].join('\n');
  return {
    messages: [{ role: 'user', content }],
    temperature: 0, // 可复现：同一输入必给同一输出
    expect: 'json'
  };
}

/**
 * 解析模型回复。**严格**：非法 JSON、越界枚举、幻觉条目一律整体拒收，
 * 拒收后由调用方回落规则草案 —— 宁可退回人工，也不用半信半疑的结果。
 */
export function parseJudgment(raw, expectCount = null) {
  const text = String(raw ?? '').trim();
  const m = text.match(/\[[\s\S]*\]/); // 容忍模型把 JSON 包在 ```json 围栏或前后废话里
  if (!m) return { ok: false, reason: '回复里没有 JSON 数组', judgments: [] };
  let arr;
  try { arr = JSON.parse(m[0]); } catch (e) { return { ok: false, reason: `JSON 解析失败：${e.message}`, judgments: [] }; }
  if (!Array.isArray(arr)) return { ok: false, reason: '不是数组', judgments: [] };
  if (expectCount !== null && arr.length !== expectCount) {
    return { ok: false, reason: `条数不匹配（期望 ${expectCount}，得到 ${arr.length}）`, judgments: [] };
  }
  const ALLOWED = new Set(['trait', 'ban', 'irrelevant']);
  const judgments = [];
  for (const it of arr) {
    const i = Number(it?.i);
    const p = it?.polarity;
    if (!Number.isInteger(i) || i < 1 || i > (expectCount ?? arr.length)) {
      return { ok: false, reason: `条目 i 越界：${JSON.stringify(it)}`, judgments: [] };
    }
    if (!ALLOWED.has(p)) return { ok: false, reason: `polarity 非法：${JSON.stringify(it)}`, judgments: [] };
    judgments[i - 1] = p;
  }
  return { ok: true, reason: '', judgments };
}

/**
 * 把模型判断合并进规则草案。
 *
 * @param {object} fit        fitCard() 的返回
 * @param {string[]} judgments 与 collectContexts().items 一一对应的极性数组
 * @param {object} opt
 *   disagreement 默认 'flag'：
 *     'flag' 不一致处保留规则结果、逐条标红（默认——两通道打架时谁也没资格替人决定）
 *     'llm'  不一致处听 LLM（用户明确信任模型时才开）
 *     'rule' 不一致处听规则（= 只采纳两通道一致的部分，最保守）
 * @returns {{profile, evidence, disagreements, dropped, source}}
 */
export function mergeJudgment(fit, judgments, items, { disagreement = 'flag' } = {}) {
  const byWord = new Map();
  items.forEach((it, i) => byWord.set(`${it.signal}:${it.word}`, judgments[i]));

  const disagreements = [];
  const dropped = [];
  const nextEvidence = [];
  const uniq = (a) => [...new Set(a)];

  for (const e of fit.evidence) {
    const newHits = [];
    const newNeg = [];
    const flips = [];
    let touched = false;
    for (const w of e.hits || []) {
      const llm = byWord.get(`${e.signal}:${w}`);
      if (llm === 'ban') { newNeg.push(w); flips.push(`${w}:trait→ban`); touched = true; }
      else if (llm === 'irrelevant') { dropped.push(`${e.signal}:${w}(→irrelevant)`); touched = true; }
      else newHits.push(w);
    }
    for (const w of e.negated || []) {
      const llm = byWord.get(`${e.signal}:${w}`);
      if (llm === 'trait') { newHits.push(w); flips.push(`${w}:ban→trait`); touched = true; }
      else if (llm === 'irrelevant') { dropped.push(`${e.signal}:${w}(→irrelevant)`); touched = true; }
      else newNeg.push(w);
    }

    // 逐词比对是否真的有改动（词级翻转可以只动 limits 不动信号极性，不能只看极性）
    const sameBuckets = uniq(newHits).length === (e.hits || []).length
      && uniq(newNeg).length === (e.negated || []).length
      && uniq(newHits).every((w) => (e.hits || []).includes(w))
      && uniq(newNeg).every((w) => (e.negated || []).includes(w));
    if (!touched && sameBuckets) { nextEvidence.push(e); continue; }

    // 2026-09-29：混合命中（mixed）语义贯通——LLM 翻转后正/禁令两侧都在时，重建为 mixed
    //（否则 mixed 在 'llm' 分支下被压成 ban/trait，「特征+禁令并存」的合并语义丢失）
    const sigDef = SIGNAL_BY_ID[e.signal];
    const newPolarity = !newHits.length ? 'ban'
      : (newNeg.length && sigDef?.banLimits ? 'mixed' : 'trait'); // 全部被判无关 ⇒ 只剩禁令侧；再无 ⇒ 上面 touched 分支处理不了整删
    if (!newHits.length && !newNeg.length) {
      // 整个信号被判无关 —— 这也是对规则的不一致，同样要走策略
      if (disagreement === 'llm') { dropped.push(`${e.signal}:整体无关`); continue; }
      if (disagreement === 'flag') {
        disagreements.push({ signal: e.signal, rule: e.polarity, llm: 'irrelevant', flips, resolved: '保留规则结果并标红（disagreement=flag）' });
      }
      nextEvidence.push(e);
      continue;
    }

    if (newPolarity === e.polarity && sameBuckets) { nextEvidence.push(e); continue; }

    const action = disagreement === 'llm' ? 'llm' : disagreement === 'rule' ? 'rule' : 'flag';
    // 极性没变但词级有翻转时，"规则=trait vs LLM=trait"这种标红会让人看不懂 —— 说明白是词级的事
    const llmLabel = newPolarity === e.polarity ? `${newPolarity}（仅词级翻转）` : newPolarity;
    if (action === 'rule') { nextEvidence.push(e); continue; }
    if (action === 'flag') {
      disagreements.push({ signal: e.signal, rule: e.polarity, llm: llmLabel, flips, resolved: '保留规则结果并标红（disagreement=flag）' });
      nextEvidence.push(e);
      continue;
    }
    disagreements.push({ signal: e.signal, rule: e.polarity, llm: llmLabel, flips, resolved: '采用 LLM（disagreement=llm）' });
    nextEvidence.push({
      ...e,
      hits: uniq(newHits),
      negated: uniq(newNeg),
      count: newHits.length,
      polarity: newPolarity,
      judged: true
    });
  }

  const { profile, desireCandidate } = mergeLimits(nextEvidence, { cardId: fit.cardId });
  return {
    profile: { ...profile, atoms: { ...profile.atoms } },
    evidence: nextEvidence,
    disagreements,
    dropped,
    desireCandidate,
    source: 'rules+llm'
  };
}

/**
 * 手写 profile 的验收通道（不经过 fitCard，更不经过 LLM）。
 * 手写是**一等公民**：它得到和自动草案完全相同的机器检验。
 * @param {string} cardText  卡全文（仅用于提取禁区做 OOC 回归，不会被发送）
 * @param {object} profile   用户手写的 profile
 * @param {object} opt       { cardId, now, sadFloor }
 */
export async function gateHandwritten(cardText, profile, { cardId = 'hand', now = Date.now(), sadFloor = 60 } = {}) {
  const [{ createCore }, { validateProfile, extractBans, oocRegression }] = await Promise.all([
    import('./emotion-core.mjs'), import('./persona-gate.mjs')
  ]);
  const synthesizedFit = {
    profile, cardId: profile.cardId || cardId,
    evidence: [], confidence: 1, // 手写 = 用户权威，不参与置信度折扣
    warnings: [], needsReview: ['手写 profile：机器只验一致性与禁区落实，"数值合不合你的意图"仍由你自己负责']
  };
  const core = createCore({ cardId: profile.cardId || cardId, profile, now });
  const check = validateProfile(synthesizedFit, core.cfg, { sadFloor });
  const bans = extractBans(cardText);
  const ooc = oocRegression(core, bans, { now });
  return {
    cardId: core.cfg.cardId,
    source: 'hand-written',
    profilePass: check.pass,
    profileViolations: check.violations,
    profileWarns: check.warns,
    oocPass: ooc.pass,
    oocCases: ooc.cases,
    oocSoftFails: ooc.softFails,
    unmappedBans: ooc.unmapped,
    autoConfirmable: check.pass && ooc.pass && ooc.unmapped.length === 0,
    at: now
  };
}

/**
 * 通道封装。judge 不传 ⇒ available:false，一切都退回规则/手写路径。
 * @param {{judge?:Function}} opt  judge: async ({messages, temperature}) => string
 */
export function createJudgeChannel({ judge = null } = {}) {
  const available = typeof judge === 'function';
  return {
    available,
    note: available
      ? 'LLM 判读已启用（opt-in）。产出永远是建议，交叉不一致必标红。'
      : '未启用 LLM（off 路径）：fitCard 草案或手写 profile + 闸门，与之前完全一致。',

    /** 完整走一遍：收集上下文 → 请求 → 解析 → 合并 → 交叉报告。任一步失败都安全回落。 */
    async review(fit, cardText, { disagreement = 'flag' } = {}) {
      if (!available) return { ok: false, reason: 'judge 未注入（LLM off）' };
      const { items } = collectContexts(cardText, fit.evidence);
      if (!items.length) return { ok: true, skipped: true, reason: '没有需要判语境的命中词' };
      const req = buildJudgeRequest(items);
      let raw;
      try { raw = await judge(req); } catch (e) { return { ok: false, reason: `judge 调用失败：${e.message}` }; }
      const parsed = parseJudgment(raw, items.length);
      if (!parsed.ok) return { ok: false, reason: parsed.reason, request: req };
      const merged = mergeJudgment(fit, parsed.judgments, items, { disagreement });
      return { ok: true, items, judgments: parsed.judgments, ...merged };
    }
  };
}

export default { collectContexts, buildJudgeRequest, parseJudgment, mergeJudgment, gateHandwritten, createJudgeChannel };
