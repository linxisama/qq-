# emotion-core —— 情绪内核（判定 → 数学内核 → 提示词注入）

给 0.4.5 宿主装**独立情绪系统**的插件：每条到达角色的消息先过词表判定（评价层），
推算七个情绪原子的电平（欣喜 joy / 欲念 desire / 低落 sad / 期盼 hope / 不安 unease /
眷恋 longing / 敬服 regard，外加悸动 stir、精神 energy 两个调制项），再按人设卡
（profile）的脾性曲线钳制后，把"她现在的情绪状态"注入提示词。

```
消息 ──▶ judge 评价层（词表，<1ms，零 token）
     ──▶ 影子账（data/plugins/emotion-core/shadow-*.jsonl，5 分钟惰性快照）
     ──▶ 数学内核（7 个原子电平 + 半衰期 + 派生情绪，例：吃醋 = √(眷恋×不安)）
     ──▶ hint 注入（before-llm-messages；injectEnabled 开了才生效）
     ──▶ bridge-6d 双向对接：读 = 六维记忆 E 维残留回灌心境底色；写 = judge 补盲入 E 维桶
```

## 安装与启用

1. 装进宿主 `resources/app/plugins/emotion-core/`（市场一键安装自动完成）。
2. **技能页手动启用**（默认不启用）。
3. 首跑自动播种：`data/plugins/emotion-core/` 下缺注册表和卡档时，从插件内 `seed/`
   补齐出厂注册表 + 8 张示例卡。**只补缺失文件，绝不覆盖已有数据**（更新安装安全）。
4. 改插件配置走技能页表单（热生效）；只有改 `src/`、`ui/` 才需要重启宿主。

## 期盼 hope / 不安 unease 这些电平怎么开

**不用开**——插件启用后评价层与内核全自动运行，hope/unease 电平由消息判定自然驱动
（例：还没得到但盼着 → hope 涨；被冷落/被攻击 → unease 涨；电平随半衰期自然衰减）。

需要选择的只有两件事：

| 事项 | 默认 | 打开方式 | 代价 |
|---|---|---|---|
| 看电平（可视化） | 洛版改机版自带面板 | 官方原版手动接 `webui/` 参考件（见该目录 README） | 零 token，只读仪表；改 `ui/`、`src/` 需重启宿主 |
| LLM 哨兵复核（judge-llm） | **关** | 宿主配置里填 DeepSeek key（`webSearch.deepseek.apiKey`）即自动活 | 只复核边界样本（漏判候选 / 高危标记二审 / 5% 抽样），队列上限 40、同文本 24h 去重；deepseek-flash 单条 ≤2000 token。**结果只写影子账，不改变任何判定** |
| hint 注入（行为生效） | **关** | 插件配置 `injectEnabled: true`，热生效 | 情绪状态进入提示词，开始影响角色语气（这才是"她真的有情绪"的开关） |

## 多卡分账（personaId 映射）

卡档注册表在 `data/plugins/emotion-core/profiles.json`（首跑播种的出厂版只有一条：
`default` 指向的默认 id → 示例卡 合欢.json）。键是**宿主人设 id**（形如 `custom:<hash>`），
每台机器不同：

1. 在宿主人设管理页查自己卡的 id；
2. 往注册表 `profiles` 加一行：`"你的id": "你的卡.json"`（卡文件放 `profiles/` 子目录，
   随包已带 7 张未映射的示例卡可参考其参数结构）；
3. 最多 **15 秒**生效，无需重载；把 `default` 也改成你的 id，未识别的会话会走你的卡。

没有宿主 persona-store 的环境（官方原版降级路径）所有会话按默认卡分账——单卡正常用，
多卡分账退化，其余功能不受影响。

## 适用版本与降级说明

- **适用 0.4.5**（apiVersion 1）。洛版改机版全功能。
- 官方原版**没有** `src/memory-tree.js`（记忆树）：judge 好感补账自动停用，日志会出现
  「memory-tree 不可用：judge 好感补账停用」——这是**预期降级，不是故障**，其余全功能。
- `util.js` / `persona-store.js` 缺失时同样自动降级（原子写自持、单卡分账），插件可正常加载。

## 卡是性格参数，不是台词本

profile 只描述**脾性曲线与钳制**（什么情绪允许表达、表达到什么强度），不写"她爱谁"、
不写台词。装了包角色不会突然说卡里没有的话；想要角色说某句话，去人设卡加，而不是往
profile 里塞。修改 profile 参数前建议先理解 persona-gate（闸门）机制：内核见 `kernel/persona-gate.mjs` 头注释。

## 目录结构

```
emotion-core/
├─ index.js          插件入口（钩子接线、影子账、注入、分账）
├─ plugin.json       manifest（含面板 live 条目声明）
├─ kernel/           独立数学内核 7 模块（零宿主依赖，可单独复用）
├─ judge.mjs         评价层·词表版（运行时判定，<1ms）
├─ judge-llm.mjs     评价层·LLM 哨兵（默认关，只写影子账）
├─ kernel-bridge.mjs 内核装载桥（目录可配置）
├─ vendor/           自持副本（原子写、emotion-residue 词表算术）
├─ seed/             出厂注册表 + 8 张示例卡（首跑播种用）
└─ webui/            宿主面板参考件（官方原版手动接线用，见其中 README）
```
