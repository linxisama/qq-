// judge-llm.mjs —— LLM v2 哨兵异步复核器（2026-10-03，调研 `llm-v2-judge调研-20261003.md`）
//
// 架构（调研定稿）：规则 judge（v1.9.6，同步 <1ms）照旧全量跑；本模块只复核**边界样本**
//   a) 规则判 null 但文本含情感信号特征（漏判候选）
//   b) desire / thirdParty / attribution 命中（高危标记二审）
//   c) 随机 5% 抽样（持续校准）
// LLM=deepseek-flash（与宿主主链路同款，key 复用 config.webSearch.deepseek.apiKey）。
//
// ══ 纪律 ══
//   ① 对拍期：结果**只写影子账**（type:'llm-judge'），不改变任何判定行为。
//   ② 失败一律静默：超时/解析失败/无 key 都不影响主流程（宁漏勿误口径）。
//   ③ 不碰提示词、不碰行为——输出与规则同构的事件字段，仅供对拍与将来融合。
//   ④ 不用定时器（宿主 activate() 是死代码）：队列由 enqueue 驱动 pump。

const MAXQ = 40;                 // 队列上限（超出直接丢，宁漏勿误）
const TIMEOUT_MS = 30000;        // 单条 LLM 超时（flash 带思考，留足）
const MAX_TOKENS = 2000;         // flash 是思考型（reasoning_content 计入输出），给足防截断
const DEBOUNCE_TEXT_MS = 24 * 3600e3;  // 同文本 24h 只复核一次
const SAMPLE_RATE = 0.05;        // 随机抽样率

let api = null;
let key = '';
let baseUrl = 'https://api.deepseek.com/v1';
let model = 'deepseek-flash';
let shadowFn = null;             // (obj)=>void  写影子账（复用 emotion-core 的 appendShadow）
let cardNameOf = () => '';       // (personaId)=>卡名
let lastError = '';              // 诊断面（debugStats 可见）

const seenText = new Map();      // text -> ts（去重）
const queue = [];
let running = false;
export const stats = { enqueued: 0, done: 0, errors: 0, agree: 0, disagree: 0, dropped: 0 };

/** 哨兵触发判定（index.js 每条判定后调用；true=该进复核队列）。 */
export function shouldReview(j, text, { now = Date.now() } = {}) {
  // a) 规则判 null 的漏判候选：带情感信号特征（叹词/波浪/笑哭呜语气/长度中等的呼语句）
  if (!j) {
    return /[!！]{1,}|~|～|哈哈|呜|唉|嘛|呀|哦哦|诶|喂/.test(text) && text.length >= 2 && text.length <= 60;
  }
  // b) 高危标记二审
  if (j.desire || j.thirdParty || j.attribution) return true;
  // c) 随机抽样
  return Math.random() < SAMPLE_RATE;
}

/** 入队（index.js 调用）。同文本 24h 去重；队列满丢弃。 */
export function enqueue(sample) {
  try {
    const text = String(sample.text || '');
    const now = Date.now();
    const last = seenText.get(text);
    if (last && now - last < DEBOUNCE_TEXT_MS) { stats.dropped++; return false; }
    if (seenText.size > 500) seenText.clear();
    seenText.set(text, now);
    if (queue.length >= MAXQ) { stats.dropped++; return false; }
    queue.push({ ...sample, text });
    stats.enqueued++;
    pump();
    return true;
  } catch { return false; }
}

async function pump() {
  if (running) return;
  running = true;
  try { while (queue.length) await judgeOne(queue.shift()); }
  finally { running = false; }
}

const SYS = (cardName) => `你是群聊机器人的情绪判定复核器。机器人扮演角色「${cardName}」。下面给你一条别人发的消息，请从「${cardName}」的视角判断：这条消息对她构成了什么情感事件？

只输出一行 JSON，不要任何其他文字：
{"branch":"event|object|agent|null","valence":<-1到1的小数>,"intensity":<0到1的小数>,"desire":<true|false>,"thirdParty":<true|false>,"attribution":"self|other|null","why":"<不超过18字>"}

字段语义：
- branch=event：消息是对她本人行为的正/负事件（夸她、骂她、摸她、冷落她、为她出头）
- branch=object：想念/求关注类（"想你了""你怎么不理我"），通常带 longing
- branch=agent：对她刚做行为的赞同/敬服（"真棒""靠谱"）
- branch=null：无情绪信号（纯寒暄/问题/无关闲聊），此时 valence=0、intensity=0
- valence：方向。负=骂/贬损/阴阳/冷落；正=夸/亲昵/关心/为她出头
- desire：消息含对她本人的亲密动作或爱称（摸摸/抱抱/老婆/宝贝…）才是 true
- thirdParty：情绪指向的是**别人**不是她（"我爱你，XX"里 XX 是别的角色 / 摸的是别人的头）才是 true
- attribution：self=他自己表达的情绪（如"我好累"），other=观测到的别人的情绪，null=不适用

判定要点（从真实误判里来的）：
- 「我帮你骂他」是**为她出头**=event 正向，不是负向；
- 「行行行，你厉害」是敷衍反讽=负向弱；
- 「早上好」「在吗」=null 无事件；
- 「摸摸头@某角色名」若 @ 的是别的角色=thirdParty true；
- 「你怎么不理我了」=object + 弱负（冷落感）。

消息：`;

async function judgeOne(s) {
  const t0 = Date.now();
  try {
    if (!key) { stats.errors++; return; }
    const cardName = cardNameOf(s.personaId) || '角色';
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), TIMEOUT_MS);
    const resp = await fetch(baseUrl.replace(/\/$/, '') + '/chat/completions', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + key },
      body: JSON.stringify({
        model,
        messages: [
          { role: 'system', content: SYS(cardName) },
          { role: 'user', content: String(s.text || '').slice(0, 300) }
        ],
        temperature: 0, max_tokens: MAX_TOKENS, stream: false
      }),
      signal: ctrl.signal
    });
    clearTimeout(timer);
    if (!resp.ok) {
      lastError = `HTTP ${resp.status}: ${(await resp.text()).slice(0, 150)}`;
      stats.errors++;
      return;
    }
    const data = await resp.json();
    const raw = String(data?.choices?.[0]?.message?.content || '').trim();
    const m = raw.match(/\{[\s\S]*\}/);
    if (!m) {
      lastError = `no-json: ${raw.slice(0, 120) || '(空 content，思考耗尽 token?)'}`;
      stats.errors++;
      return;
    }
    let llm;
    try { llm = JSON.parse(m[0]); } catch (e) { lastError = 'parse: ' + String(e?.message ?? e).slice(0, 100); stats.errors++; return; }
    // 字符串"null"/"true"/"false" 归一化（LLM 常把 JSON null 写成字符串）
    if (llm.branch === 'null' || llm.branch === 'none' || llm.branch === '') llm.branch = null;
    for (const k of ['desire', 'thirdParty']) {
      if (llm[k] === 'true') llm[k] = true;
      else if (llm[k] === 'false' || llm[k] === 'null' || llm[k] === undefined) llm[k] = false;
    }
    if (llm.attribution === 'null') llm.attribution = null;
    // schema 强约束：解析不过=丢弃（宁漏勿误）
    if (llm.branch !== null && !['event', 'object', 'agent'].includes(llm.branch)) {
      lastError = `schema: bad branch=${llm.branch}`;
      stats.errors++;
      return;
    }
    llm.valence = Number.isFinite(Number(llm.valence)) ? Math.max(-1, Math.min(1, Number(llm.valence))) : 0;
    llm.intensity = Number.isFinite(Number(llm.intensity)) ? Math.max(0, Math.min(1, Number(llm.intensity))) : 0;
    llm.why = String(llm.why || '').slice(0, 40);
    const rule = s.ruleJudge
      ? { branch: s.ruleJudge.branch, valence: s.ruleJudge.valence, intensity: s.ruleJudge.intensity, desire: !!s.ruleJudge.desire, thirdParty: !!s.ruleJudge.thirdParty }
      : null;
    const agree = rule
      ? (rule.branch === llm.branch && Math.sign(rule.valence || 0) === Math.sign(llm.valence || 0) && !!rule.desire === (llm.desire === true))
      : llm.branch === null;
    if (agree) stats.agree++; else stats.disagree++;
    stats.done++;
    // 🔴 对拍期：只写影子账，不改变判定行为
    if (shadowFn) {
      shadowFn({
        type: 'llm-judge', at: Date.now(), chat: s.chat || '', personaId: s.personaId || undefined,
        latencyMs: Date.now() - t0, msg: s.text.slice(0, 40),
        rule, llm: { branch: llm.branch, valence: llm.valence, intensity: llm.intensity, desire: llm.desire === true, thirdParty: llm.thirdParty === true, attribution: llm.attribution ?? null, why: llm.why },
        agree
      });
    }
  } catch (e) { lastError = 'fetch: ' + String(e?.message ?? e).slice(0, 120); stats.errors++; }
}

/** 初始化（index.js setup 调用）。 */
export function init({ log, config, appendShadow, cardNameResolver }) {
  api = log;
  shadowFn = appendShadow;
  cardNameOf = cardNameResolver;
  try {
    const c = config() || {};
    key = String(c?.webSearch?.deepseek?.apiKey || '');
    const bu = String(c?.webSearch?.deepseek?.baseUrl || '');
    // webSearch.deepseek.baseUrl 是 responses 端点（…/responses）——chat 用官方 v1 根
    baseUrl = bu ? bu.replace(/\/responses$/, '') : 'https://api.deepseek.com/v1';
    if (!/\/v1$/.test(baseUrl)) baseUrl = baseUrl.replace(/\/$/, '') + '/v1';
  } catch { /* 用默认 */ }
  if (!key) { try { api?.warn?.('judge-llm：未找到 deepseek key，哨兵复核静默停用（不影响主流程）'); } catch { /* 忽略 */ }
    return false; }
  try { api?.log?.(`judge-llm 哨兵复核就绪（${model}@${baseUrl}，对拍期：只写影子账）`); } catch { /* 忽略 */ }
  return true;
}

export function debugStats() {
  return { ...stats, queueLen: queue.length, model, ready: !!key, lastError };
}
