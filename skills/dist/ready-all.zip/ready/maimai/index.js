// 舞萌 DX 查分 Skill —— 把 maimai_bot（Python）接进 QQ Agent。
//
// 分工：
//   · 本文件负责「QQ Agent 侧的一切」：工具注册、事件上下文解析、图片/文字发送、密钥脱敏
//   · 查分、绑定、出图全部交给 maimai_bot（Python），通过常驻子进程用 JSON 行通信
// 这样升级查分逻辑（曲库、图片版式、新指令）不用改这个 Skill。
//
// 两个关键设计（都来自 QQ Agent 的约定）：
//   1. 发消息一律走 ctx.sender（它内部有发送队列/限频/去重/留档），
//      绝不直接 ctx.onebot.send*；
//   2. 图片走 ctx.sender.sendImage({ dataUrl })，不塞进工具返回的 content
//      —— 否则几十万 token 的 base64 会进模型上下文，又贵又没用。
import path from 'node:path';
import { PythonBridge } from './lib/bridge.js';

let cfg = () => ({});
let log = () => {};
let warn = () => {};

// ─────────────────────────────────────────────────────────── 桥接进程

let bridge = null;
let bridgeKey = '';

function bridgeEnv(c) {
  const env = {
    MAIMAI_IMAGE: c.imageEnabled === false ? '0' : '1'
  };
  if (c.imageFormat) env.MAIMAI_IMAGE_FORMAT = String(c.imageFormat);
  if (c.databasePath) env.MAIMAI_DB_PATH = String(c.databasePath);
  if (c.secretKey) env.MAIMAI_SECRET_KEY = String(c.secretKey);
  if (c.lxnsDeveloperToken) env.MAIMAI_LXNS_DEVELOPER_TOKEN = String(c.lxnsDeveloperToken);
  if (c.jacketDir) env.MAIMAI_JACKET_DIR = String(c.jacketDir);
  if (Number.isFinite(Number(c.rateLimitSeconds))) env.MAIMAI_RATE_LIMIT = String(c.rateLimitSeconds);
  if (Number.isFinite(Number(c.timeoutSeconds))) env.MAIMAI_REQUEST_TIMEOUT = String(c.timeoutSeconds);
  return env;
}

function configSignature(c) {
  return JSON.stringify([
    c.pythonPath, c.projectDir, c.configPath, c.databasePath, c.secretKey,
    c.lxnsDeveloperToken, c.imageEnabled, c.imageFormat, c.jacketDir, c.rateLimitSeconds
  ]);
}

/** 取（必要时重建）桥接进程。配置一变就重建，避免新旧配置混用。 */
function bridgeFor() {
  const c = cfg();
  const key = configSignature(c);
  if (bridge && bridgeKey === key) return bridge;
  if (bridge) {
    log('配置已变更，重启 Python 桥接进程');
    bridge.stop();
    bridge = null;
  }
  const python = String(c.pythonPath || 'python').trim() || 'python';
  const args = ['-m', 'maimai_bot.bridge'];
  const configPath = String(c.configPath || '').trim();
  if (configPath) args.push('--config', configPath);
  args.push('--platform', 'qq');

  bridge = new PythonBridge({
    python,
    args,
    cwd: String(c.projectDir || '').trim(),
    env: bridgeEnv(c),
    log: (line) => log(line)
  });
  bridgeKey = key;
  return bridge;
}

// ─────────────────────────────────────────────────────────── 可用性自检
// available() 走同步调用链：返回 Promise 会被当成「可用」。
// 所以这里首次乐观放行 + 后台探测 + 缓存结果（QQ Agent 文档推荐的模式）。

const probe = { checked: false, ok: true, reason: '', running: false, lastAt: 0, signature: '' };
const PROBE_RETRY_MS = 60000; // 探测失败后隔一分钟重试

export function available() {
  // 配置变了（换了 Python 路径/项目目录）就立刻重新探测，
  // 不然用户改完设置还得等 TTL 或重启应用，看起来像"改了没用"。
  const signature = configSignature(cfg());
  const configChanged = probe.checked && probe.signature !== signature;
  const retryDue = probe.checked && !probe.ok && Date.now() - probe.lastAt > PROBE_RETRY_MS;
  if (probe.checked && !configChanged && !retryDue) {
    return probe.ok ? true : { ok: false, reason: probe.reason };
  }
  // 还没探测过（或缓存已失效）：先放行，后台去探；失败会缓存，下次如实汇报
  if (!probe.running) {
    probe.running = true;
    probeBridge()
      .catch(() => {})
      .finally(() => {
        probe.running = false;
      });
  }
  return true;
}

async function probeBridge() {
  const started = Date.now();
  const signature = configSignature(cfg());
  try {
    const info = await bridgeFor().start({ timeoutMs: 30000 });
    probe.checked = true;
    probe.ok = true;
    probe.reason = '';
    probe.lastAt = Date.now();
    probe.signature = signature;
    log(`依赖探测通过（${Date.now() - started}ms），数据库=${info?.database}`);
    return true;
  } catch (error) {
    probe.checked = true;
    probe.ok = false;
    probe.reason = `无法启动 Python 查分服务：${error?.message ?? error}。请在技能设置里检查「Python 解释器」与「maimai_bot 项目目录」。`;
    probe.lastAt = Date.now();
    probe.signature = signature;
    warn(probe.reason);
    return false;
  }
}

// ─────────────────────────────────────────────────────────── 密钥脱敏
//
// 用户在群里发「绑定 落雪 <个人API密钥>」时，这条消息会被塞进提示词发给模型。
// 密钥不该出现在模型上下文里，所以：
//   before-llm-messages → 把密钥换成占位符 ⟨maimai-secret:1⟩，真值只留在本进程内存
//   工具被调用时        → 把 command 里的占位符还原成真值再交给 Python
// 占位符与密钥一一对应，不做按人缓存，所以不存在「串号绑错人」的可能。

const secrets = new Map(); // id -> { value, at }
let secretSeq = 1;
const SECRET_TTL_MS = 10 * 60 * 1000;
const SECRET_RE = /⟨maimai-secret:(\d+)⟩/g;

function pruneSecrets() {
  const now = Date.now();
  for (const [id, item] of secrets) {
    if (now - item.at > SECRET_TTL_MS) secrets.delete(id);
  }
}

/** 从一条消息里找出「绑定指令中的密钥」，返回密钥片段数组。 */
function findSecrets(text) {
  const raw = String(text ?? '').trim();
  // ⚠️ 这里**不能**用 \b：绑定目标里有中文（落雪/水鱼/机台），
  // 而 \b 基于 ASCII 的 \w 判定，中文后面根本不存在词边界，
  // 结果就是「绑定 落雪 <密钥>」永远匹配不上、脱敏静默失效。
  // 用 (?=\s|$) 表达「这个词到此为止」。
  const head = /^[/!！／.\s]*(绑定|bind)\s+(落雪|lxns|水鱼|df|diving-?fish|机台|qr|arcade)(?=\s|$)([\s\S]*)$/i.exec(raw);
  if (!head) return [];
  const target = head[2].toLowerCase();
  const rest = String(head[3] || '').trim();
  if (!rest) return [];

  if (target === '落雪' || target === 'lxns') {
    if (/^(qq|fc)\s*:/i.test(rest)) return []; // qq:/fc: 不是密钥
    const token = rest.split(/\s+/)[0] || '';
    return token.length >= 12 ? [token] : [];
  }
  if (target === '水鱼' || target === 'df' || target.startsWith('diving')) {
    const token = /^token\s*:\s*(\S+)/i.exec(rest);
    return token && token[1].length >= 8 ? [token[1]] : [];
  }
  const qrcode = /(SGWCMAID\S+)/i.exec(rest); // 机台二维码：等价于账号凭据
  return qrcode ? [qrcode[1]] : [];
}

function stashSecret(value) {
  for (const [id, item] of secrets) {
    if (item.value === value) return `⟨maimai-secret:${id}⟩`; // 同一个密钥复用占位符
  }
  const id = secretSeq++;
  secrets.set(id, { value, at: Date.now() });
  return `⟨maimai-secret:${id}⟩`;
}

/** 把待发给模型的消息里的密钥换成占位符（原地修改）。 */
export function redactMessages(messages) {
  if (!Array.isArray(messages)) return 0;
  pruneSecrets();
  let replaced = 0;
  for (const message of messages) {
    if (!message || typeof message !== 'object') continue;
    replaced += redactContent(message);
  }
  return replaced;
}

function redactContent(holder) {
  let count = 0;
  const content = holder.content;
  if (typeof content === 'string') {
    let text = content;
    for (const secret of findSecrets(text)) {
      if (!text.includes(secret)) continue;
      const placeholder = stashSecret(secret);
      text = text.split(secret).join(placeholder);
      count += 1;
    }
    holder.content = text;
    return count;
  }
  if (Array.isArray(content)) {
    for (const part of content) {
      if (part && typeof part === 'object' && typeof part.text === 'string') {
        count += redactContent(part);
      }
    }
  }
  return count;
}

/** 把占位符还原成真值（工具执行前调用）。 */
export function restoreSecrets(text) {
  pruneSecrets();
  return String(text ?? '').replace(SECRET_RE, (match, id) => {
    const item = secrets.get(Number(id));
    return item ? item.value : match;
  });
}

export const hooks = {
  // 只做内存里的字符串替换：轻量、不联网、不发消息（符合钩子禁令）
  'before-llm-messages': ({ messages }) => {
    if (cfg().redactSecrets === false) return;
    try {
      const count = redactMessages(messages);
      if (count) log(`已在提示词里脱敏 ${count} 处密钥`);
    } catch (error) {
      warn(`密钥脱敏失败（不影响对话）：${error?.message ?? error}`);
    }
  }
};

// ─────────────────────────────────────────────────────────── 上下文解析

/** 触发者的 QQ 号：私聊就是 chatId，群聊取最近一条非自己的消息。 */
function resolveSenderId(ctx) {
  if (ctx?.kind === 'private' && ctx.chatId) return String(ctx.chatId);
  try {
    const recent = ctx?.store?.recent?.(ctx.chatKey, { limit: 1, includeSelf: false }) || [];
    const last = recent[recent.length - 1];
    if (last?.senderId) return String(last.senderId);
  } catch (error) {
    warn(`读取触发者失败：${error?.message ?? error}`);
  }
  return '';
}

/** 解析要查询的「别人」：显式 QQ 优先；给了 at 就按 @ 的名字反查成员。 */
function resolveTargetQq(ctx, args) {
  const explicit = String(args?.target_qq ?? '').trim();
  if (/^\d{5,12}$/.test(explicit)) return { qq: explicit, how: 'explicit' };
  if (explicit.toLowerCase() !== 'at' || ctx?.kind !== 'group') return { qq: '', how: 'none' };

  try {
    const recent = ctx.store?.recent?.(ctx.chatKey, { limit: 1, includeSelf: false }) || [];
    const entry = recent[recent.length - 1];
    const own = new Set([ctx.selfNickname, ctx.botName, ctx.selfId].filter(Boolean).map(String));
    const names = (entry?.atNames || []).map(String).filter((name) => name && !own.has(name));
    if (!names.length) return { qq: '', how: 'no-at' };

    const members = ctx.store?.activeMembers?.(ctx.chatKey) || [];
    const hits = members.filter((m) => names.includes(String(m?.name || '')));
    // 同名成员无法区分时宁可不猜，避免查错人
    if (hits.length === 1 && hits[0]?.userId) return { qq: String(hits[0].userId), how: 'at' };
    return { qq: '', how: hits.length > 1 ? 'ambiguous' : 'unmatched' };
  } catch (error) {
    warn(`解析 @ 目标失败：${error?.message ?? error}`);
    return { qq: '', how: 'error' };
  }
}

// ─────────────────────────────────────────────────────────── 发送
// 长文本按行切片：QQ 单条消息放不下完整 B50 文字版（约 3.2k 字符）。

function splitText(text, maxChars, maxChunks) {
  const limit = Math.max(200, Number(maxChars) || 900);
  const cap = Math.max(1, Number(maxChunks) || 4);
  const chunks = [];
  let current = '';
  for (const line of String(text ?? '').split('\n')) {
    if (current && current.length + line.length + 1 > limit) {
      chunks.push(current);
      current = line;
      if (chunks.length >= cap) break;
    } else {
      current = current ? `${current}\n${line}` : line;
    }
  }
  if (chunks.length < cap && current) chunks.push(current);
  if (chunks.length >= cap) {
    const rest = String(text ?? '').length;
    if (rest > chunks.join('\n').length) {
      chunks[cap - 1] = `${chunks[cap - 1]}\n…（内容较长已截断，可让它只发图片或缩小范围）`;
    }
  }
  return chunks.filter(Boolean);
}

async function sendImage(ctx, image) {
  const dataUrl = `data:${image.mime || 'image/jpeg'};base64,${image.base64}`;
  await ctx.sender.sendImage(ctx.chatKey, { dataUrl }, { note: image.filename || '成绩图' });
}

// ─────────────────────────────────────────────────────────── 工具注册

export function setup(api) {
  cfg = api.config;
  log = api.log || (() => {});
  warn = api.warn || api.log || (() => {});

  api.registerTool({
    id: 'query',
    name: '舞萌 DX 查分',
    icon: '🎵',
    category: 'query',
    description:
      '查询舞萌 DX（maimai）街机成绩，并把结果直接发到当前会话。'
      + '当群友说「查分」「b50」「我的 b50」「我」「看看成绩」「单曲 xxx 多少分」'
      + '「曲目 xxx 定数」「等级 14+ 有什么歌」「牌子 镜将 进度」「绑定账号」「更新/同步成绩」时使用。'
      + 'command 参数填舞萌指令原文（如 "b50"、"我"、"单曲 潘多拉"、"等级 14+ MASTER"、"牌子 镜将"）。'
      + '第一次用需要先绑定：把用户的「绑定 …」原文交给这个工具即可。'
      + '不要用它查其它游戏；也不要替用户编造成绩数字。',
    parameters: {
      type: 'object',
      properties: {
        command: {
          type: 'string',
          description:
            '舞萌指令原文，例如 "b50"、"我"、"单曲 潘多拉"、"曲目 834"、"等级 14+ MASTER"、'
            + '"牌子 镜将"、"绑定 落雪 <密钥>"、"更新 机台 落雪"、"帮助"。'
            + '如果原文里出现 ⟨maimai-secret:1⟩ 这样的占位符，请原样保留，不要替换、不要询问密钥内容。'
        },
        target_qq: {
          type: 'string',
          description:
            '要查询的是**其他群友**时才有：知道对方 QQ 号就填数字；'
            + '用户只是 @ 了某人、你没拿到 QQ 号时填 "at"（我会尝试从 @ 解析）。'
            + '查用户自己时不要填这个参数。'
        }
      },
      required: ['command']
    },

    async execute(ctx, args) {
      const c = cfg();
      const command = restoreSecrets(String(args?.command ?? '').trim());
      if (!command) return { content: '缺少 command 参数：请把用户的舞萌指令原文填进来。', isError: true };
      if (command.length > 500) return { content: '指令过长，请只传用户的舞萌指令原文。', isError: true };

      const senderId = resolveSenderId(ctx);
      if (!senderId) {
        return { content: '拿不到发送者的 QQ 号，无法按人绑定/查分。请让用户自己发一条指令试试。', isError: true };
      }

      const target = resolveTargetQq(ctx, args);
      const timeoutMs = Math.max(5, Number(c.timeoutSeconds) || 180) * 1000;

      let response;
      try {
        response = await bridgeFor().request(
          'handle',
          { user_id: senderId, text: command, target_user_id: target.qq || null },
          { timeoutMs }
        );
      } catch (error) {
        const hint = error?.code === 'start-timeout' || error?.code === 'spawn-failed'
          ? '请在技能设置里检查「Python 解释器」与「maimai_bot 项目目录」是否正确（该目录下要有 maimai_bot/ 包）。'
          : '查分服务暂时不可用，稍后再试。';
        return { content: `调用查分服务失败：${error?.message ?? error}。${hint}`, isError: true };
      }

      if (!response || response.ok === false) {
        return { content: `查分失败：${response?.error || '未知错误'}`, isError: true };
      }

      const sent = [];
      let imageFailed = '';

      if (response.image && c.sendImage !== false) {
        try {
          await sendImage(ctx, response.image);
          sent.push('图片');
        } catch (error) {
          imageFailed = `（图片发送失败：${error?.message ?? error}）`;
          warn(`图片发送失败：${error?.message ?? error}`);
        }
      }

      const text = String(response.text || '').trim();
      if (text) {
        try {
          const chunks = splitText(text, c.maxChunkChars, c.maxChunks);
          await ctx.sender.sendTextBatch(ctx.chatKey, chunks);
          sent.push('文字');
        } catch (error) {
          warn(`文字发送失败：${error?.message ?? error}`);
          return { content: `结果已生成但发送失败：${error?.message ?? error}`, isError: true };
        }
      }

      if (!sent.length) {
        return { content: text || '没有可发送的内容。', isError: !text };
      }

      // 让模型别复述：内容已经由 sender 直接发给群友，且已留档
      return {
        content:
          `已通过发送队列把结果（${sent.join(' + ')}）发给群友，内容包含：`
          + `${text.slice(0, 120)}${text.length > 120 ? '…' : ''}。`
          + '不要再复述这些内容，也不要重复发送；如需补充说明请简短一句。'
          + (imageFailed ? `注意：${imageFailed}` : '')
          + (target.how === 'at' ? `（已按 @ 解析为 QQ ${target.qq}）` : '')
          + (target.how === 'ambiguous' || target.how === 'unmatched'
            ? '（没能确定被 @ 的是谁，已改查发送者本人；如需查别人请让用户给出 QQ 号）'
            : '')
      };
    }
  });
}

// 技能被关掉/卸载时把 Python 进程收干净，别留幽灵进程
export function deactivate() {
  bridge?.stop();
  bridge = null;
  bridgeKey = '';
}

export function dispose() {
  deactivate();
  secrets.clear();
}

// 项目根目录（便于调试时确认相对路径解析到哪）
export function projectDir() {
  return path.resolve(String(cfg().projectDir || '.'));
}
