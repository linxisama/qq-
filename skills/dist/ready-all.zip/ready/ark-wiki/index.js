// 方舟维基速查（LLM 型技能 / skills/ark-wiki）
//
// ── 为什么是技能，不是插件 ─────────────────────────────────────────────────
// 判据（见 src/skills/manifest.js 与 README「扩展（两型）」）：
//   plugins/ 确定性型 —— 触发条件能写成 if，满足就必然执行
//   skills/  LLM 型   —— registerTool，用不用、什么时候用由模型判断
// 这里显然是后者：「群友问银灰强不强」这句话没有任何 if 能描述，必须模型读懂
// 人话、决定查不查、查哪个站、查完怎么用自己的人设口吻转述。
//
// ── 两个站的接口完全不一样（这是本技能存在的理由）────────────────────────
//   PRTS（明日方舟）  = 标准 MediaWiki，走 api.php：
//       搜索 action=query&list=search
//       正文 action=parse&page=X&prop=wikitext  ← 用 wikitext 而不是 extracts！
//             因为干员页是模板拼的，extracts 只吐标题（实测 283 字，全是空章节名），
//             而 wikitext 里有完整的模板参数（干员名/稀有度/职业/分支/特性/标签/
//             画师/配音/时装…），信息密度高得多。
//   终末地（fz.wiki） = Next.js + ProseMirror 富文本，走 api.fz.wiki：
//       搜索 GET /api/v1/search?q=X                 → { hits: [{ title, snippet }] }
//       正文 GET /api/v1/articles/by-title?ns=0&title=X&withRevision=1
//             → { article, revision.contentJson }（ProseMirror JSON，要自己拍平）
//       ⚠️ revision.contentText 只有 200 字（是目录+分类，不是正文），别用它。
//
// ── 踩过的坑（都已在代码里兜住）──────────────────────────────────────────
//   1) 终末地页面的正文**不在 HTML 里**（前端二次请求拿的），直接抓 HTML 只能拿到
//      导航栏 —— 所以必须走它的 JSON 接口，不能网页抓取。
//   2) ProseMirror 里混着大量噪声：`endfield-workflow` 之类的内部标记、图片 URL、
//      十六进制颜色、纯数字 id。不滤掉会把上下文塞爆（实测伊冯页 7788 字里
//      近一半是噪声）。见 flattenRich() 的 NOISE 规则。
//   3) 条目名要带命名空间前缀：终末地是「干员/伊冯」「武器/O.B.J.尖峰」这种形态，
//      从搜索结果里原样拿回来传回去最稳；也允许模型直接给纯名字（自动尝试补前缀）。
//   4) 两个站都可能抽风（PRTS 偶发 502、fz 的 CDN 抖动），一律给清楚的错误文案，
//      并且明确要求模型「查不到就说查不到，不要编数值」。
//
// 依赖：只用 node 内置模块 + api.fetch（需要在 skill.json 声明 permissions:
// ["web_fetch"]）。本文件不 import 任何 src/ 下的模块（本项目硬规矩）。

const PRTS_API = 'https://prts.wiki/api.php';
const FZ_API = 'https://api.fz.wiki/api/v1';
const UA = 'QQ-Agent/ark-wiki (+https://https://www.fz.wiki)';

/** 终末地的一级命名空间（用来判断条目属于哪个站 / 补全前缀）。 */
const FZ_NAMESPACES = ['干员', '武器', '装备', '敌人', '物品', '卡池', '副本', '商店', '地图',
  '活动', '任务', '教程', '基建', '蚀刻章', '影片', 'PRTS记录', 'Baker', '游戏动态'];

const DEFAULTS = { maxBodyChars: 2500, maxResults: 5, snippetChars: 160, timeoutMs: 15000 };

let cfg = () => ({});
let log = () => {};
let warn = () => {};
let fetchImpl = null;

// ─────────────────────────── 生命周期 ───────────────────────────

export function setup(api) {
  cfg = api.config || (() => ({}));
  log = api.log || (() => {});
  warn = api.warn || (() => {});
  fetchImpl = typeof api.fetch === 'function' ? api.fetch : null;
  if (!fetchImpl) warn('没有拿到联网能力：skill.json 里需要 permissions: ["web_fetch"]');

  api.registerTool({
    id: 'wiki_search',
    name: '搜方舟维基',
    description: '在 终末地 wiki（fz.wiki）里搜条目，返回标题+摘要+来源站。'
      + '什么时候用：群里聊到方舟/终末地的干员、武器、物品、敌人、关卡、活动，或者有人问具体数值/技能/材料/怎么获得时，'
      + '先用它搜出正确的条目名，再用 wiki_read 读那一条。'
      + 'keyword 给要搜的名字（如「银灰」「伊冯」「O.B.J.尖峰」）；不确定是哪个游戏就 site 留 auto（两边都搜）。'
      + '⚠️ 摘要只是用来挑条目的，**不要把摘要当答案**——细节要 wiki_read 读出来。',
    category: 'knowledge',
    icon: '📖',
    defaultEnabled: true,
    parameters: {
      type: 'object',
      properties: {
        keyword: { type: 'string', description: '要搜的名字或关键词，比如「银灰」「终末地 伊冯」「长柄武器」' },
        site: { type: 'string', enum: ['auto', 'endfield'], description: '搜哪个站：固定为终末地（endfield）；auto 也只会查终末地' },
        limit: { type: 'number', description: '每个站最多返回几条（默认取技能设置）' }
      },
      required: ['keyword']
    },
    async execute(_ctx, args) {
      const a = normalizeArgs(args);
      const s = settings();
      const keyword = String(a.keyword ?? '').trim();
      if (!keyword) return fail('关键词为空');
      const site = String(a.site ?? 'auto').toLowerCase();
      const limit = clampInt(a.limit, 1, 15, s.maxResults);

      const jobs = [];
      if (site === 'auto' || site === 'endfield') jobs.push(['endfield', searchEndfield(keyword, limit, s)]);
      if (!jobs.length) return fail('site 只支持 auto / endfield');

      const settled = await Promise.all(jobs.map(async ([k, p]) => [k, await p]));
      const lines = [];
      const errors = [];
      for (const [k, r] of settled) {
        const label = k === '终末地 wiki';
        if (!r.ok) { errors.push(`${label}：${r.error}`); continue; }
        if (!r.hits.length) { lines.push(`【${label}】没有匹配的条目`); continue; }
        lines.push(`【${label}】`);
        for (const h of r.hits) {
          lines.push(`  · ${h.title}${h.snippet ? `　—　${h.snippet}` : ''}`);
        }
        lines.push(`  （要读详情：wiki_read，site=${k}，title 原样填上面的标题）`);
      }
      if (!lines.length) return fail(`两个站都没搜到：「${keyword}」${errors.length ? `（${errors.join('；')}）` : ''}`);
      return {
        content: `搜索「${keyword}」的结果：\n${lines.join('\n')}`
          + (errors.length ? `\n（部分站点失败：${errors.join('；')}）` : '')
          + '\n下一步：挑最像的那条，用 wiki_read 读正文；读不到就如实说查不到，不要编。'
      };
    }
  });

  api.registerTool({
    id: 'wiki_read',
    name: '读方舟维基条目',
    description: '读 终末地 wiki 某一条目的正文（干员面板/技能/材料/敌人数据/活动说明等），'
      + '已做过清洗，直接可读。什么时候用：wiki_search 之后拿到了标题，要细节时读它。'
      + 'title 必须是搜索返回的那个标题（终末地的要带前缀，如「干员/伊冯」）；site 填搜索时标明的站。'
      + '读到的内容请用你自己的话转述，别整段照抄；里面没有的信息就说查不到，**不要编数值**。',
    category: 'knowledge',
    icon: '📚',
    defaultEnabled: true,
    parameters: {
      type: 'object',
      properties: {
        title: { type: 'string', description: '条目标题（搜索返回的那个，终末地形如「干员/伊冯」）' },
        site: { type: 'string', enum: ['auto', 'endfield'], description: '哪個站（只支持 endfield / auto，两者都只查终末地）' },
        maxChars: { type: 'number', description: '这次最多返回几个字（默认取技能设置）' }
      },
      required: ['title']
    },
    async execute(_ctx, args) {
      const a = normalizeArgs(args);
      const s = settings();
      const rawTitle = String(a.title ?? '').trim();
      if (!rawTitle) return fail('标题为空');
      const title = extractTitle(rawTitle);
      const maxChars = clampInt(a.maxChars, 0, 20000, s.maxBodyChars);
      let site = String(a.site ?? 'auto').toLowerCase();
      if (!['auto', 'endfield'].includes(site)) site = 'auto';

      const order = site === 'auto' ? guessSites(title) : [site];
      const tried = [];
      for (const k of order) {
        const r = await readEndfield(title, maxChars, s);   // 只保留终末地
        if (r.ok) {
          return {
            content: `【来源：${k === '终末地 wiki'}｜条目：${r.title}】\n${r.text}`
              + (r.note ? `\n（${r.note}）` : '')
              + '\n（记得用自己的话转述，只挑和问题相关的那几点；维基上没有的就别补。）'
          };
        }
        tried.push(`${k}：${r.error}`);
      }
      return fail(`读取「${title}」失败 —— ${tried.join('；')}。`
        + '先确认条目名是否正确（可以再 wiki_search 一次），仍然读不到就如实告诉群友「维基上没查到」，不要凭记忆编数值。');
    }
  });

  const s0 = settings();
  log(`终末地维基速查已加载（仅终末地）｜正文上限 ${s0.maxBodyChars} 字｜每站最多 ${s0.maxResults} 条`);
}

// ─────────────────────────── 设置 ───────────────────────────

function settings() {
  const raw = (typeof cfg === 'function' ? cfg() : null) || {};
  const pick = (k) => (raw[k] === undefined || raw[k] === null || raw[k] === '' ? DEFAULTS[k] : raw[k]);
  return {
    maxBodyChars: clampInt(pick('maxBodyChars'), 0, 20000, DEFAULTS.maxBodyChars),
    maxResults: clampInt(pick('maxResults'), 1, 15, DEFAULTS.maxResults),
    snippetChars: clampInt(pick('snippetChars'), 0, 500, DEFAULTS.snippetChars),
    timeoutMs: clampInt(pick('timeoutMs'), 3000, 60000, DEFAULTS.timeoutMs)
  };
}

function clampInt(v, min, max, dflt) {
  const n = Number(v);
  if (!Number.isFinite(n)) return dflt;
  return Math.max(min, Math.min(max, Math.round(n)));
}

/** 工具参数可能是 JSON 字符串（不同端点习惯不同），统一成对象。 */
function normalizeArgs(args) {
  if (typeof args === 'string') { try { return JSON.parse(args) || {}; } catch { return {}; } }
  return args || {};
}

function fail(message) {
  return { content: `错误：${message}`, isError: true };
}

// ─────────────────────────── 公共小工具 ───────────────────────────

/** URL 里可能被模型塞进完整链接，抽成标题。 */
function extractTitle(input) {
  const s = String(input || '').trim();
  const m = s.match(/^https?:\/\/[^/]+\/wiki\/(.+)$/i);
  if (!m) return s;
  try { return decodeURIComponent(m[1]); } catch { return m[1]; }
}

/** auto 模式下的站点猜测：带终末地命名空间前缀的归终末地，其余默认 PRTS。 */
function guessSites(title) {
  const head = String(title).split('/')[0];
  const isFz = FZ_NAMESPACES.includes(head);
  return ['endfield'];   // 2026-10-22：只留终末地，auto 也不再猜 PRTS
}

/** 去掉 HTML 标签与实体（搜索摘要里带 <span class="searchmatch"> / <mark>）。 */
function stripHtml(s) {
  return String(s ?? '')
    .replace(/<[^>]{0,200}>/g, '')
    .replace(/&nbsp;/g, ' ')
    .replace(/&ensp;|&emsp;/g, ' ')
    .replace(/&quot;/g, '"').replace(/&#39;|&apos;/g, "'")
    .replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&amp;/g, '&')
    .replace(/&#(\d+);/g, (_, d) => { const n = Number(d); return n > 0 && n < 0x10ffff ? String.fromCodePoint(n) : ' '; })
    .replace(/\s+/g, ' ')
    .trim();
}

function clip(s, max, what = '内容') {
  const t = String(s ?? '');
  if (!max || t.length <= max) return { text: t, note: '' };
  return { text: t.slice(0, max), note: `已截断：全文还有约 ${t.length - max} 字没显示（需要更多可以再读一次并调大 maxChars，或换个更具体的条目）` };
}

async function httpJson(url, { timeoutMs, method = 'GET', body = null } = {}) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const res = await fetchImpl(url, {
      method,
      signal: controller.signal,
      headers: Object.assign(
        { 'user-agent': UA, accept: 'application/json, text/plain, */*', 'accept-language': 'zh-CN,zh;q=0.9' },
        body ? { 'content-type': 'application/json' } : {}
      ),
      ...(body ? { body: JSON.stringify(body) } : {})
    });
    const text = await res.text();
    if (!res.ok) throw new Error(`HTTP ${res.status}${text ? `：${text.slice(0, 120)}` : ''}`);
    try { return JSON.parse(text); } catch { throw new Error('返回的不是 JSON（站点可能在维护）'); }
  } finally {
    clearTimeout(timer);
  }
}

// ─────────────────────────── PRTS（MediaWiki）───────────────────────────

async function searchPrts(keyword, limit, s) {
  try {
    const url = `${PRTS_API}?action=query&list=search&srsearch=${encodeURIComponent(keyword)}`
      + `&srlimit=${limit}&srprop=snippet&format=json&formatversion=2`;
    const j = await httpJson(url, { timeoutMs: s.timeoutMs });
    const arr = Array.isArray(j?.query?.search) ? j.query.search : [];
    return {
      ok: true,
      hits: arr.map((x) => ({
        title: String(x.title || ''),
        snippet: clip(stripHtml(x.snippet), s.snippetChars).text
      })).filter((x) => x.title)
    };
  } catch (e) {
    return { ok: false, error: String(e?.message || e) };
  }
}

async function readPrts(title, maxChars, s) {
  try {
    const url = `${PRTS_API}?action=parse&page=${encodeURIComponent(title)}&prop=wikitext&format=json&redirects=1`;
    const j = await httpJson(url, { timeoutMs: s.timeoutMs });
    if (j?.error) return { ok: false, error: `PRTS 说：${stripHtml(j.error.info || j.error.code)}` };
    const wt = j?.parse?.wikitext;
    const raw = typeof wt === 'string' ? wt : wt?.['*'];
    if (!raw) return { ok: false, error: 'PRTS 没有返回正文（条目可能不存在）' };
    const clean = cleanWikitext(raw);
    const c = clip(clean, maxChars);
    const redirectedFrom = j?.parse?.redirects?.[0]?.from;
    return {
      ok: true,
      title: String(j?.parse?.title || title),
      text: c.text,
      note: [c.note, redirectedFrom ? `（由「${redirectedFrom}」重定向而来）` : ''].filter(Boolean).join(' ')
    };
  } catch (e) {
    return { ok: false, error: String(e?.message || e) };
  }
}

/**
 * PRTS 的 wikitext 清洗。
 * 目标：把「模板参数 + 少量正文」变成人能读的键值行，扔掉语法噪音。
 * 刻意**保留** `|键=值` 形式的模板参数 —— 干员的面板数据全在那里。
 */
function cleanWikitext(src) {
  let s = String(src ?? '');
  s = s.replace(/<!--[\s\S]*?-->/g, '');                       // 注释
  s = s.replace(/<ref[^>]*>[\s\S]*?<\/ref>/gi, '');            // 引用
  s = s.replace(/<ref[^>]*\/>/gi, '');
  s = s.replace(/\{\{color\|[^|{}]*\|([^{}]*)\}\}/gi, '$1');   // {{color|#fff|文字}} → 文字
  s = s.replace(/\{\{fa\|([^{}|]*)\}\}/gi, '★$1');             // {{fa|2}} → ★2
  // 单层模板：有 |k=v 参数的展开成行；只有位置参数（模板名/导航这类）整块丢掉 ——
  // 实测 {{干员页面名|银灰|SilverAsh|…}} 和 {{pathnav2|干员一览}} 展开出来全是噪音。
  s = s.replace(/\{\{([^{}]*)\}\}/g, (_m, inner) => {
    const parts = String(inner).split('|');
    const kv = parts.slice(1).filter((p) => p.includes('='));
    if (kv.length) return `\n${kv.map((p) => p.replace(/^\s+|\s+$/g, '')).join('\n')}\n`;
    return '';
  });
  s = s.replace(/\{\{|\}\}/g, ' ');                            // 残留花括号
  // 嵌套模板没被上面吃掉时留下的残骸，如「异格干员|原型=|非异格=1」
  s = s.replace(/^\s*[\w\u4e00-\u9fa5]{2,14}(?:\|[^=\n]*=[^\n|]*)+(?:\|[^\n|]*)?\s*$/gm, '');
  s = s.replace(/\[\[(?:File|文件|Image|分类|Category):[^\]]*\]\]/gi, ' ');  // 图片/分类
  s = s.replace(/\[\[[^\]|]*\|([^\]]*)\]\]/g, '$1');           // [[a|b]] → b
  s = s.replace(/\[\[([^\]]*)\]\]/g, '$1');                    // [[a]] → a
  s = s.replace(/\[https?:\/\/\S+\s+([^\]]*)\]/g, '$1');       // 外链 → 文字
  s = s.replace(/\[https?:\/\/\S+\]/g, ' ');
  s = s.replace(/'''|''/g, '');                                // 粗体/斜体
  s = s.replace(/<br\s*\/?>/gi, '\n');
  s = s.replace(/<\/?(?:div|span|p|center|small|big|b|i|u|font)[^>]*>/gi, ' ');
  s = s.replace(/__[A-Z]+__/g, ' ');                           // __NOTOC__ 之类
  s = s.replace(/^[|!]\s*/gm, '');                             // 行首多余的表格符
  s = s.replace(/\|-+\s*/g, '');
  s = s.replace(/^\s*=+\s*(.*?)\s*=+\s*$/gm, '【$1】');         // == 标题 == → 【标题】
  s = s.replace(/^\s*\|?\s*([^=\n|]{1,20})=$/gm, '');          // 空值行（键在、值空）丢掉
  s = s.replace(/[ \t]+/g, ' ');
  s = s.replace(/\n{3,}/g, '\n\n');
  return s.trim();
}

// ─────────────────────────── 终末地 wiki（Next.js + JSON API）────────────

async function searchEndfield(keyword, limit, s) {
  try {
    const j = await httpJson(`${FZ_API}/search?q=${encodeURIComponent(keyword)}`, { timeoutMs: s.timeoutMs });
    const hits = Array.isArray(j?.hits) ? j.hits : [];
    return {
      ok: true,
      hits: hits.slice(0, limit).map((h) => ({
        title: String(h.title || ''),
        snippet: clip(stripHtml(h.snippet), s.snippetChars).text
      })).filter((h) => h.title)
    };
  } catch (e) {
    return { ok: false, error: String(e?.message || e) };
  }
}

async function readEndfield(title, maxChars, s) {
  const candidates = buildEndfieldTitles(title);
  let lastErr = '没有可用的条目名';
  for (const t of candidates) {
    try {
      const j = await httpJson(`${FZ_API}/articles/by-title?ns=0&title=${encodeURIComponent(t)}&withRevision=1`, { timeoutMs: s.timeoutMs });
      if (!j?.article) { lastErr = `没有「${t}」这个条目`; continue; }
      const text = flattenRich(j.revision?.contentJson, { desc: j.article.description, categories: j.article.categories });
      if (!text) { lastErr = `「${t}」的正文是空的（可能还没人写）`; continue; }
      const c = clip(text, maxChars);
      return {
        ok: true,
        title: String(j.article.title || t),
        text: c.text,
        note: [j.article.description ? `官方摘要：${stripHtml(j.article.description)}` : '', c.note].filter(Boolean).join('｜')
      };
    } catch (e) {
      lastErr = String(e?.message || e);
    }
  }
  return { ok: false, error: lastErr };
}

/** 终末地条目名要带命名空间前缀；模型可能只给纯名字，这里补几个候选。 */
function buildEndfieldTitles(title) {
  const t = String(title || '').trim();
  const out = [t];
  if (!t.includes('/')) {
    for (const ns of ['干员', '武器', '物品', '敌人', '装备', '活动', '任务', '教程']) out.push(`${ns}/${t}`);
  }
  return [...new Set(out)];
}

/**
 * 把终末地的 ProseMirror 富文本拍平成可读文本。
 * 噪声（内部标记 / 图片 URL / 颜色 / 纯数字 id）一律丢掉 —— 不滤的话一条干员页
 * 会吐出 7000+ 字，一半是 `endfield-workflow` 这种垃圾。
 */
function flattenRich(doc, meta = {}) {
  if (!doc) return '';
  const out = [];
  const seen = new Set();
  const NOISE = /^(?:endfield[\w-]*|https?:\/\/\S+|#[0-9a-fA-F]{3,8}|\d{1,4}|[A-Za-z][\w-]{0,3})$/;

  const push = (t) => {
    const s = String(t ?? '').replace(/\s+/g, ' ').trim();
    if (!s || NOISE.test(s)) return;
    if (seen.has(s)) return;          // 同一段文字重复出现（卡片里常见）只留一次
    seen.add(s);
    out.push(s);
  };

  const walk = (node) => {
    if (node == null) return;
    if (typeof node === 'string') { push(node); return; }
    if (Array.isArray(node)) { node.forEach(walk); return; }
    if (typeof node !== 'object') return;

    const type = String(node.type || '');
    if (type === 'text') { push(node.text); return; }
    if (type === 'hardBreak') { out.push('\n'); return; }

    // 自定义卡片：把 attrs 里带人话的字段倒出来（bio / meta[{label,value}] / 名称等）
    if (node.attrs) {
      const a = node.attrs;
      const bits = [];
      for (const [k, v] of Object.entries(a)) {
        if (v == null || v === '' || k === 'id' || k === 'hero') continue;
        if (typeof v === 'string' || typeof v === 'number') {
          const s = String(v);
          if (NOISE.test(s)) continue;
          bits.push(s.length > 800 ? `${s.slice(0, 400)}…` : s);
        } else if (Array.isArray(v)) {
          for (const it of v) {
            if (it && typeof it === 'object') {
              const label = it.label ?? it.name ?? '';
              const value = it.value ?? it.desc ?? it.text ?? '';
              if (label || value) bits.push(`${label}${label && value ? '：' : ''}${value}`);
            } else if (typeof it === 'string' && !NOISE.test(it)) bits.push(it);
          }
        }
      }
      if (bits.length) { push(bits.join('｜')); out.push('\n'); }
    }

    if (type === 'tableRow') {
      const cells = [];
      const sub = { push: (t) => { const s = String(t ?? '').trim(); if (s && !NOISE.test(s)) cells.push(s); } };
      // 表格行单独收，用 | 分隔更好读
      const walkCell = (n) => {
        if (!n) return;
        if (Array.isArray(n)) { n.forEach(walkCell); return; }
        if (typeof n === 'string') { sub.push(n); return; }
        if (n.type === 'text') { sub.push(n.text); return; }
        if (n.content) walkCell(n.content);
      };
      walkCell(node.content);
      if (cells.length) out.push(cells.join(' | ') + '\n');
      return;
    }

    if (node.content) walk(node.content);
    if (type === 'paragraph' || type === 'heading') out.push('\n');
  };

  walk(doc.content || doc);
  let text = out.join('').replace(/[ \t]+/g, ' ').replace(/\n{3,}/g, '\n\n').trim();

  // 头尾补一点结构化信息（摘要/分类），对模型判断很有用
  const head = [];
  if (meta.desc) head.push(`【一句话】${stripHtml(meta.desc)}`);
  if (Array.isArray(meta.categories) && meta.categories.length) head.push(`【分类】${meta.categories.join('、')}`);
  return [head.join('\n'), text].filter(Boolean).join('\n');
}

// ─────────────────────────── 排障用导出 ───────────────────────────

export const __internals = { cleanWikitext, flattenRich, stripHtml, buildEndfieldTitles, guessSites, extractTitle };
