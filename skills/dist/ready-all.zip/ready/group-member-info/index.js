// 群成员资料查询（group-member-info）。
//
// ── 为什么是「技能」而不是「插件」 ──────────────────────────────────────────
// 「群友问的是谁、想查群名片还是等级/头衔」只能靠模型理解人话判断，
// 没有一条能写死的触发条件；插件的语义是"条件满足必跑"，套不上。
// 所以做成 LLM 型技能：注册工具进模型 function 列表，用不用、何时用由模型决定。
//
// ── 数据从哪来 ──────────────────────────────────────────────────────────────
// 全部走现有 SnowLuma 协议端（OneBot v11）的标准动作，不需要额外服务：
//   get_group_member_list —— 群成员列表（含 card/level/title/role/join_time 等）
//   get_group_member_info —— 单个成员详情（列表缺字段时的兜底）
//
// ── 隐私边界 ────────────────────────────────────────────────────────────────
// 只返回群内公开资料；不查 QQ 号对应的手机号/住址等。查不到如实说，不编造。
//
// ⚠️ 本文件在 resources/app 里，应用自动更新会覆盖，装回来即可。

let cfg = () => ({});

const ROLE_NAME = { owner: '群主', admin: '管理员', member: '成员' };
const MAX_LIST = 100;

function clamp(n, lo, hi, fallback) {
  const v = Number(n);
  if (!Number.isFinite(v)) return fallback;
  return Math.min(hi, Math.max(lo, Math.round(v)));
}

/** 把群号从 chatKey（group:616278233）里取出来；私聊返回 ''。 */
function groupIdOf(ctx, args) {
  const explicit = String(args?.groupId ?? '').trim();
  if (/^\d{5,15}$/.test(explicit)) return explicit;
  const key = String(ctx?.chatKey ?? '');
  const m = key.match(/^group[:/](\d{5,15})$/);
  return m ? m[1] : '';
}

/** 拉取成员列表（OneBot 失败时抛出可读错误）。 */
async function fetchMembers(ctx, groupId) {
  if (!ctx?.onebot || typeof ctx.onebot.call !== 'function') {
    throw new Error('机器人没有连上 QQ，无法查询群成员');
  }
  const data = await ctx.onebot.call('get_group_member_list', { group_id: Number(groupId) }, 20000);
  const list = Array.isArray(data) ? data : (Array.isArray(data?.members) ? data.members : null);
  if (!list) throw new Error('协议端没有返回成员列表');
  return list;
}

const clean = (v) => String(v ?? '').replace(/^[@＠\s]+/, '').replace(/\s+/g, ' ').trim();
const norm = (v) => clean(v).toLowerCase().replace(/\s+/g, '');

function displayName(m) {
  const card = clean(m.card);
  const nick = clean(m.nickname);
  if (card && nick && card !== nick) return `${card}（${nick}）`;
  return card || nick || `QQ ${m.user_id}`;
}

/** 时间戳 → 北京时间 YYYY-MM-DD HH:mm；0/空 → 未知。 */
function fmtTime(ts) {
  const n = Number(ts);
  if (!Number.isFinite(n) || n <= 0) return '未知';
  const d = new Date(n * 1000 + 8 * 3600 * 1000);
  return d.toISOString().slice(0, 16).replace('T', ' ');
}

function nowSec() { return Math.floor(Date.now() / 1000); }

/** 精确 → 前缀 → 包含 的匹配顺序；返回 { member, candidates }。 */
function matchMember(members, query) {
  const q = clean(query);
  if (!q) return { member: null, candidates: [] };
  const digits = /^\d{5,15}$/.test(q);
  if (digits) {
    const hit = members.find((m) => String(m.user_id) === q);
    if (hit) return { member: hit, candidates: [] };
  }
  const nq = norm(q);
  const exact = members.filter((m) => norm(m.card) === nq || norm(m.nickname) === nq);
  if (exact.length === 1) return { member: exact[0], candidates: [] };
  if (exact.length > 1) return { member: null, candidates: exact };
  const fuzzy = members.filter((m) => {
    const c = norm(m.card);
    const n = norm(m.nickname);
    return (c && c.includes(nq)) || (n && n.includes(nq));
  });
  if (fuzzy.length === 1) return { member: fuzzy[0], candidates: [] };
  return { member: null, candidates: fuzzy };
}

function memberLine(m) {
  const role = ROLE_NAME[m.role] || String(m.role || '成员');
  const level = clean(m.level) ? `Lv${clean(m.level)}` : '等级未知';
  const title = clean(m.title) ? `「${clean(m.title)}」` : '';
  return `· ${displayName(m)} — ${role}，${level}${title ? '，头衔' + title : ''}（QQ ${m.user_id}）`;
}

function formatMember(m, opts = {}) {
  const lines = ['【群成员资料】'];
  lines.push(`QQ号：${m.user_id}`);
  lines.push(`昵称：${clean(m.nickname) || '未知'}`);
  lines.push(`群名片：${clean(m.card) || '（无，显示昵称）'}`);
  lines.push(`身份：${ROLE_NAME[m.role] || String(m.role || '成员')}`);
  lines.push(`QQ等级：${clean(m.level) || '未知'}`);
  const title = clean(m.title);
  const expire = Number(m.title_expire_time) || 0;
  lines.push(`群头衔：${title ? title + (expire > nowSec() ? `（有效期至 ${fmtTime(expire)}）` : '') : '（无）'}`);
  if (opts.showJoinTime !== false) lines.push(`入群时间：${fmtTime(m.join_time)}`);
  if (opts.showLastSpeak) lines.push(`最后发言：${fmtTime(m.last_sent_time)}`);
  const shut = Number(m.shut_up_timestamp) || 0;
  lines.push(`当前状态：${shut > nowSec() ? `禁言中（至 ${fmtTime(shut)}）` : '正常'}`);
  if (m.is_robot) lines.push('备注：这是机器人账号');
  return lines.join('\n');
}

function candidatesText(candidates, query) {
  const shown = candidates.slice(0, 8);
  const lines = [`没找到唯一匹配「${clean(query)}」的群成员，找到 ${candidates.length} 个相近的：`];
  for (const m of shown) lines.push(memberLine(m));
  if (candidates.length > shown.length) lines.push(`…还有 ${candidates.length - shown.length} 个没列出。`);
  lines.push('请让提问者确认是哪一个（可以补 QQ 号），不要自己猜。');
  return lines.join('\n');
}

export function setup(api) {
  cfg = () => api.config() || {};

  api.registerTool({
    id: 'get_member_info',
    name: '查询群成员资料',
    description: '查询当前群里某个成员的公开资料：群名片（群昵称）、昵称、QQ等级、群头衔（称号）、身份（群主/管理员/成员）、入群时间、最后发言、禁言状态。member 传 QQ 号或群名片/昵称；不确定是谁时先用 list_group_members 找候选。查不到如实说，不要编造。',
    category: 'query',
    icon: '🪪',
    defaultEnabled: true,
    parameters: {
      type: 'object',
      properties: {
        member: { type: 'string', description: '要查的群成员：QQ号，或群名片/昵称（可带 @ 前缀）' },
        groupId: { type: 'string', description: '可选：群号。默认用当前聊天所在的群；私聊里查群成员时必须给。' }
      },
      required: ['member'],
      additionalProperties: false
    },
    async execute(ctx, args) {
      const c = cfg() || {};
      const groupId = groupIdOf(ctx, args);
      if (!groupId) return { content: '当前不是群聊，需要在参数里给出群号（groupId）。', isError: true };
      const query = clean(args?.member);
      if (!query) return { content: '缺少 member 参数：请传 QQ 号或群名片/昵称。', isError: true };
      let members;
      try {
        members = await fetchMembers(ctx, groupId);
      } catch (error) {
        return { content: `查询群成员失败：${error?.message ?? error}`, isError: true };
      }
      const { member, candidates } = matchMember(members, query);
      if (member) {
        return { content: formatMember(member, { showJoinTime: c.showJoinTime !== false, showLastSpeak: c.showLastSpeak === true }) };
      }
      if (candidates.length) return { content: candidatesText(candidates, query) };
      return { content: `群里没有找到「${query}」对应的成员。可以换个 QQ 号或完整群名片再试；如果对方刚改过群名片，可能还没同步。` };
    }
  });

  api.registerTool({
    id: 'list_group_members',
    name: '列出群成员一览',
    description: '列出当前群的成员一览（群名片/昵称、身份、QQ等级、群头衔），用于确认昵称相近的是谁、找某人的 QQ 号。默认最多 30 人，可用 limit 调整；可用 filter 只筛群名片/昵称包含关键词的人。',
    category: 'query',
    icon: '👥',
    defaultEnabled: true,
    parameters: {
      type: 'object',
      properties: {
        limit: { type: 'integer', description: '最多列几个人（1~100），默认按技能设置' },
        filter: { type: 'string', description: '可选：只列出群名片/昵称包含这个词的成员' },
        groupId: { type: 'string', description: '可选：群号。默认用当前聊天所在的群。' }
      },
      additionalProperties: false
    },
    async execute(ctx, args) {
      const c = cfg() || {};
      const groupId = groupIdOf(ctx, args);
      if (!groupId) return { content: '当前不是群聊，需要在参数里给出群号（groupId）。', isError: true };
      let members;
      try {
        members = await fetchMembers(ctx, groupId);
      } catch (error) {
        return { content: `查询群成员失败：${error?.message ?? error}`, isError: true };
      }
      const filter = clean(args?.filter);
      if (filter) {
        const nf = norm(filter);
        members = members.filter((m) => norm(m.card).includes(nf) || norm(m.nickname).includes(nf));
        if (!members.length) return { content: `群里没有群名片/昵称包含「${filter}」的成员。` };
      }
      const limit = clamp(args?.limit, 1, MAX_LIST, clamp(c.maxListCount, 1, MAX_LIST, 30));
      const roleOrder = { owner: 0, admin: 1, member: 2 };
      // 先按身份排序再截断：群主/管理员优先进入前 N 个，互不挤占；同身份保持原顺序。
      const sorted = [...members].sort((a, b) => (roleOrder[a.role] ?? 3) - (roleOrder[b.role] ?? 3));
      const shown = sorted.slice(0, limit);
      const lines = [`群成员一览（共 ${members.length} 人${filter ? `，匹配「${filter}」` : ''}${members.length > shown.length ? `，只列前 ${shown.length} 人` : ''}）：`];
      for (const m of shown) lines.push(memberLine(m));
      if (members.length > shown.length) lines.push(`…还有 ${members.length - shown.length} 人没列出（可加 filter 或调大 limit）。`);
      return { content: lines.join('\n') };
    }
  });
}

/** 自测用（不注册工具）：直接调用这些函数即可。 */
export const internals = { groupIdOf, fetchMembers, matchMember, formatMember, memberLine, fmtTime, clean, norm };
