// 跨会话聊资（cross-chat-gossip）—— LLM 型 Skill
//
// 判定：用户要的是「机器人像真人一样，知道隔壁在聊什么，偶尔提一嘴」。
//   · 需要模型自己判断「这会儿要不要说出来」→ LLM 型（skills/），工具由模型决定何时调；
//   · 但「别泄露私事、别把记忆撑爆」必须是**确定性**的 → 用 hook 兜底自动注入，
//     并且在代码里做敏感词过滤，不依赖模型自觉。
//   所以这里两条腿都有：工具（模型主动打听）+ before-llm-messages（每轮自动带一点点）。
//
// 三条硬约束：
//   1) 只记最近一丁点 —— 窗口默认 60 分钟、每会话 4 句、整段 220 字，读完就忘，不写盘；
//   2) 不搬运私事 —— 私聊默认不参与；群聊里命中钱/病/住址/证件/感情/QQ 号的句子整句丢；
//   3) 不破坏缓存 —— 片段追加到最后一条 user 消息末尾，system 前缀保持原样
//      （与缓存稳定优化、分层会话记忆的注入位置约定一致）。
//
// 只读 data/messages/*.json，不建索引、不落盘。
import fs from 'node:fs';
import path from 'node:path';
import { DATA_DIR } from '../../src/config.js';
// 设置必须实时读：面板改完设置不会重载 Skill（routes 只写 config），
// 在 setup 里抓一份快照会永远读到旧值。
import { getSkillConfig } from '../../src/skills/config.js';

const SKILL_ID = 'cross-chat-gossip';
const MESSAGES_DIR = path.join(DATA_DIR, 'messages');
const SESSIONS_DIR = path.join(DATA_DIR, 'sessions');
const INDEX_FILE = path.join(DATA_DIR, 'session-index-cache.json');

const HEADING = '【别的窗口】';
const MAX_LINE = 110;
const MEDIA_ONLY = /^\[(图片|表情|贴图|语音|视频|文件|链接|音乐|小程序|合并转发|引用|撤回|QQ红包|戳一戳)\]\s*$/;

// 内置私事过滤：命中就整句丢弃（宁可少说，不可串私事）。
const PRIVATE_RE = /(密码|验证码|身份证|银行卡|卡号|转账|付款|收款|借钱|还钱|欠款|工资|薪水|奖金|发红包|手机号|电话号|住址|地址|门牌|快递单|医院|挂号|病历|手术|体检报告|怀孕|例假|分手|离婚|吵架|闹翻|抑郁|自杀|遗书|裸照|开房|出轨|偷情|举报|投诉|网贷|贷款|征信|欠债|赌博)/;

const DEFAULTS = {
  enabled: true,
  autoInject: true,
  windowMinutes: 60,
  maxChats: 2,
  maxChars: 220,
  perChatMessages: 4,
  includeGroups: true,
  includePrivate: false,
  blockWords: ''
};

function readSettings() {
  let raw = {};
  try { raw = getSkillConfig(SKILL_ID, DEFAULTS) || {}; } catch { raw = {}; }
  const num = (v, def, min, max) => {
    const n = Number(v);
    if (!Number.isFinite(n)) return def;
    return Math.min(max, Math.max(min, Math.round(n)));
  };
  return {
    enabled: raw.enabled !== false,
    autoInject: raw.autoInject !== false,
    windowMinutes: num(raw.windowMinutes, DEFAULTS.windowMinutes, 1, 1440),
    maxChats: num(raw.maxChats, DEFAULTS.maxChats, 1, 6),
    maxChars: num(raw.maxChars, DEFAULTS.maxChars, 60, 800),
    perChatMessages: num(raw.perChatMessages, DEFAULTS.perChatMessages, 1, 10),
    includeGroups: raw.includeGroups !== false,
    includePrivate: raw.includePrivate === true,
    blockWords: String(raw.blockWords ?? '')
  };
}

function extraBlockWords(text) {
  return String(text || '')
    .split(/[\n,，;；、]+/)
    .map((s) => s.trim())
    .filter((s) => s.length >= 1)
    .slice(0, 60);
}

function loadMessages(chatKey) {
  try {
    const safe = String(chatKey).replace(/[^a-z0-9_]/gi, '_');
    let t = fs.readFileSync(path.join(MESSAGES_DIR, `${safe}.json`), 'utf8');
    if (t.charCodeAt(0) === 0xfeff) t = t.slice(1);
    const j = JSON.parse(t);
    return Array.isArray(j.messages) ? j.messages : [];
  } catch {
    return [];
  }
}

const nameCache = new Map();
/** 群名：从 session-index-cache 找该会话最近一次 session，读它的 chatName（最多几次文件读）。 */
function sessionChatName(chatKey) {
  if (nameCache.has(chatKey)) return nameCache.get(chatKey);
  let out = '';
  try {
    let t = fs.readFileSync(INDEX_FILE, 'utf8');
    if (t.charCodeAt(0) === 0xfeff) t = t.slice(1);
    const entries = JSON.parse(t)?.entries;
    if (Array.isArray(entries)) {
      const hit = entries
        .filter((e) => e?.chatKey === chatKey && e?.id)
        .sort((a, b) => Number(b.startedAt || 0) - Number(a.startedAt || 0))[0];
      if (hit) {
        const s = JSON.parse(fs.readFileSync(path.join(SESSIONS_DIR, `${hit.id}.json`), 'utf8'));
        out = String(s?.chatName || '').trim();
      }
    }
  } catch { out = ''; }
  nameCache.set(chatKey, out);
  if (nameCache.size > 64) nameCache.delete(nameCache.keys().next().value);
  return out;
}

/** 会话显示名：私聊用对方昵称，群聊用群名，都没有就按会话号兜底。 */
function chatLabel(chatKey, messages) {
  if (String(chatKey).startsWith('private:')) {
    const peer = messages.map((m) => (m.self ? '' : cleanName(m.senderName))).find(Boolean);
    return peer ? `和${peer}的私聊` : '和一个朋友的私聊';
  }
  const id = (/^group:(\d+)$/.exec(chatKey) || [])[1] || '';
  const name = sessionChatName(chatKey);
  if (name) return `「${name.slice(0, 14)}」群`;
  return id ? `另一个群（${id.slice(-4)}）` : '另一个群';
}

function cleanName(name) {
  return String(name || '').replace(/[\u200B-\u200F\u2060-\u206F\uFEFF]/g, '').trim().slice(0, 10);
}

function cleanText(text) {
  return String(text || '')
    .replace(/http(s)?:\/\/\S+/g, '')
    .replace(/@\S+/g, '')
    .replace(/\s+/g, ' ')
    .trim();
}

/** 一句能不能当谈资：有内容、不是媒体占位、不含私事。 */
function usable(message, blocked) {
  const text = cleanText(message?.text);
  if (!text || MEDIA_ONLY.test(text)) return false;
  if (text.length < 6 || text.length > 140) return false;
  // 引用块常带对方 QQ 号/手机号，整句不搬
  if (/\[引用|QQ\s*:?\s*\d{5,}|\d{7,}/.test(text)) return false;
  if (PRIVATE_RE.test(text)) return false;
  for (const w of blocked) {
    if (w && text.includes(w)) return false;
  }
  return true;
}

function clip(text, max) {
  const chars = Array.from(String(text));
  return chars.length <= max ? String(text) : chars.slice(0, max).join('') + '…';
}

function pickChats(settings, currentChatKey) {
  let files = [];
  try { files = fs.readdirSync(MESSAGES_DIR); } catch { return []; }
  const cutoff = Date.now() - settings.windowMinutes * 60000;
  const rows = [];
  for (const f of files) {
    const m = /^(group|private)_(\d+)\.json$/.exec(f);
    if (!m) continue;
    const kind = m[1];
    if (kind === 'group' && !settings.includeGroups) continue;
    if (kind === 'private' && !settings.includePrivate) continue;
    const chatKey = `${kind}:${m[2]}`;
    if (chatKey === currentChatKey) continue;
    const messages = loadMessages(chatKey);
    const recent = messages.filter((x) => Number(x.ts || 0) >= cutoff);
    if (recent.length < 3) continue;
    const lastAt = Math.max(...recent.map((x) => Number(x.ts || 0)));
    rows.push({ chatKey, messages, recent, lastAt });
  }
  rows.sort((a, b) => b.lastAt - a.lastAt);
  return rows.slice(0, settings.maxChats);
}

/** 组装注入片段；没有可用素材时返回空串。 */
export function buildFragment(settings, currentChatKey) {
  if (!settings.enabled) return '';
  const blocked = extraBlockWords(settings.blockWords);
  const parts = [];
  for (const row of pickChats(settings, currentChatKey)) {
    const usableMsgs = row.recent.filter((m) => !m.self && usable(m, blocked));
    if (!usableMsgs.length || usableMsgs.length < 2) continue;
    const last = usableMsgs.slice(-settings.perChatMessages);
    const names = [...new Set(last.map((m) => cleanName(m.senderName)).filter(Boolean))].slice(0, 2);
    const talk = last.map((m) => clip(cleanText(m.text), 46)).filter(Boolean);
    if (!talk.length) continue;
    const label = chatLabel(row.chatKey, row.messages);
    const who = names.length ? `${names.join('、')}在聊` : '有人在聊';
    const line = `·${label}：${who}「${talk[talk.length - 1]}」` +
      (talk.length > 1 ? `，之前提到「${talk[talk.length - 2]}」` : '');
    parts.push(clip(line, MAX_LINE));
  }
  if (!parts.length) return '';
  const body = clip(parts.join('\n'), settings.maxChars);
  return `${HEADING}你不在的时候，别的会话里刚有人聊（当路过的闲话，能接就接一句，别说“系统记录”这种话；私事一个字都别提）：\n${body}`;
}

/** 追加到最后一条 user 消息（system 前缀不动，缓存不失效）。 */
export function injectIntoMessages(messages, fragment) {
  if (!fragment || !Array.isArray(messages)) return false;
  for (let i = messages.length - 1; i >= 0; i -= 1) {
    const m = messages[i];
    if (m?.role !== 'user') continue;
    if (typeof m.content === 'string') {
      if (m.content.includes(HEADING)) return false;
      m.content = `${m.content}\n\n${fragment}`;
      return true;
    }
    if (Array.isArray(m.content)) {
      const already = m.content.some((p) => p?.type === 'text' && String(p.text || '').includes(HEADING));
      if (already) return false;
      m.content.push({ type: 'text', text: `\n\n${fragment}` });
      return true;
    }
    return false;
  }
  return false;
}

// ── 扩展点 ─────────────────────────────────────────────────────────────────

/** 注册 peek 工具：模型想主动打听别的会话最近在聊什么时自己调。 */
export function setup(api) {
  api.registerTool({
    id: 'peek',
    name: '看看别处聊什么',
    description: '查看**别的会话**最近在聊什么（不是你当前的会话）。想聊起别处的事、想显得消息灵通、'
      + '或别人问「你知不知道群里刚在说什么」时用它。只返回最近一小段别人的闲话，'
      + '私事（钱、病、住址、证件、感情纠葛）已经过滤掉，不要再追问这些细节。',
    category: 'query',
    icon: '👂',
    defaultEnabled: true,
    parameters: {
      type: 'object',
      properties: {
        minutes: { type: 'integer', description: '回溯多少分钟，默认用设置里的窗口（一般 60）。' },
        maxChats: { type: 'integer', description: '最多看几个会话，默认用设置里的值（一般 2）。' },
        includePrivate: { type: 'boolean', description: '是否连私聊一起看，默认用设置（一般关）。' }
      }
    },
    execute(ctx, args) {
      try {
        const s = readSettings();
        if (!s.enabled) return { content: '跨会话聊资已关闭。', isError: true };
        const merged = {
          ...s,
          windowMinutes: Number(args?.minutes) || s.windowMinutes,
          maxChats: Number(args?.maxChats) || s.maxChats,
          includePrivate: args?.includePrivate === undefined ? s.includePrivate : args.includePrivate === true
        };
        const frag = buildFragment(merged, String(ctx?.chatKey || ''));
        if (!frag) return { content: '最近别的会话没什么新动静。', isError: false };
        return { content: frag, isError: false };
      } catch (error) {
        return { content: `查看别的会话失败：${error?.message ?? error}`, isError: true };
      }
    }
  });
  api.log?.('跨会话聊资已就绪：自动旁听 + peek 工具');
}

export const hooks = {
  'before-llm-messages': ({ messages, chatKey } = {}) => {
    try {
      const settings = readSettings();
      if (!settings.enabled || !settings.autoInject) return;
      const fragment = buildFragment(settings, chatKey);
      if (!fragment) return;
      injectIntoMessages(messages, fragment);
    } catch {
      // 八卦失败不能影响正经回复
    }
  }
};

export function available() { return { ok: true }; }
