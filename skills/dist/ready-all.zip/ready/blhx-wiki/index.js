// 碧蓝航线 BWIKI（wiki.biligame.com/blhx）查询
//
// 两个实测出来的坑，代码里的每个判断都是有原因的：
//
// ① 反爬：**不带 Referer 一律返回 HTTP 567 的 HTML 反爬页**（不是 JSON）。
//    必须带 `Referer: https://wiki.biligame.com/blhx/`。请求太快也会被拦，
//    所以内置最小间隔 + 页面缓存。
//
// ② 页面结构：这个站的「舰船信息 / 配装推荐 / 情人节礼物 / 舰船台词」四块
//    放在 **tabber 标签页**里，MediaWiki 给它们的 section index 是 "."（不是数字），
//    **无法按 section 号单独取**，只能读整页再按标签名切。其余章节才是正常数字。
//
// 网络走 curl.exe：本机 node 的 fetch 对 bilibili 系主机不稳定（B 站主站、
// pixiv 都栽过），curl 用系统栈一直可靠。
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { execFile } from 'node:child_process';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const DATA_DIR = path.resolve(HERE, '..', '..', 'data');
const CACHE_DIR = path.join(DATA_DIR, 'blhx-cache');

const API = 'https://wiki.biligame.com/blhx/api.php';
const REFERER = 'https://wiki.biligame.com/blhx/';
const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36';

let getCfg = () => ({});
let lastCallAt = 0;

export function setup(api) {
  getCfg = () => {
    try { return api.config() || {}; } catch { return {}; }
  };

  api.registerTool({
    id: 'blhx_search',
    name: '搜碧蓝航线Wiki',
    description:
      '在 B站「碧蓝航线 BWIKI」里搜索条目。适用：找舰娘、装备、活动、攻略、机制说明的页面。' +
      '返回页面标题列表；拿到标题后再用 blhx_read 读正文。',
    category: 'knowledge',
    icon: '⚓',
    parameters: {
      type: 'object',
      properties: {
        query: { type: 'string', description: '搜索词：舰娘名（企业/贝尔法斯特）、装备名、活动名、机制词' },
        limit: { type: 'integer', description: '返回条数，1~12，默认 8' },
      },
      required: ['query'],
    },
    async execute(ctx, args) {
      const query = String(args?.query ?? '').trim();
      if (!query) return { content: '搜索词不能为空。', isError: true };
      const limit = Math.min(12, Math.max(1, Number(args?.limit) || 8));

      try {
        const j = await callApi({ action: 'query', list: 'search', srsearch: query, srlimit: String(limit) });
        const list = j?.query?.search || [];
        if (!list.length) {
          return { content: `BWIKI 里没搜到「${query}」。换个说法（舰娘本名 / 装备或活动的正式名）再试，也可以直接 blhx_read 传标题。` };
        }
        const lines = list.map((it, i) => `${i + 1}. ${it.title}` + (it.snippet ? `　—　${clean(it.snippet).slice(0, 100)}` : ''));
        return {
          content: `BWIKI 搜索「${query}」命中 ${list.length} 条：\n${lines.join('\n')}\n\n用 blhx_read 传标题读正文（标题照抄，别改）。`,
        };
      } catch (e) {
        return { content: `查 BWIKI 失败：${String(e?.message ?? e)}`, isError: true };
      }
    },
  });

  api.registerTool({
    id: 'blhx_read',
    name: '读碧蓝航线Wiki',
    description:
      '读取 B站「碧蓝航线 BWIKI」某个页面的正文。' +
      'section 可传：标签页名（舰船信息 / 配装推荐 / 情人节礼物 / 舰船台词）、' +
      '普通章节名（原型舰简介 / 二战经历 / 游戏相关…）、或章节序号。' +
      '不传 section 时默认读「舰船信息」（属性/稀有度/建造时间/掉落）。正文长时用 offset 续读。',
    category: 'knowledge',
    icon: '📖',
    parameters: {
      type: 'object',
      properties: {
        title: { type: 'string', description: '页面标题（照抄 blhx_search 返回的标题）' },
        section: { type: 'string', description: '可选：标签页名 / 章节名 / 章节序号' },
        offset: { type: 'integer', description: '可选：从第几个字符开始读，默认 0' },
      },
      required: ['title'],
    },
    async execute(ctx, args) {
      const cfg = getCfg();
      const maxChars = Math.max(500, Number(cfg.maxChars) || 8000);
      const title = String(args?.title ?? '').trim();
      if (!title) return { content: '标题不能为空。', isError: true };

      try {
        // ── 1) 章节表（顺便验证页面存在）──
        const secJson = await callApi({ action: 'parse', page: title, prop: 'sections' }, { cacheKey: `sec:${title}` });
        if (!secJson?.parse) {
          const why = secJson?.error?.info || secJson?.error?.code || '页面不存在';
          return { content: `BWIKI 上没有「${title}」这个页面（${why}）。先用 blhx_search 搜正确标题。`, isError: true };
        }

        const sections = secJson.parse.sections || [];
        const realTitle = secJson.parse.title || title;

        // tabber 标签页（index 非数字）vs 普通章节（index 数字）
        const tabNames = [];
        const numbered = [];
        for (const s of sections) {
          const line = String(s.line ?? '').trim();
          if (!line) continue;
          const n = Number(s.index);
          if (Number.isFinite(n) && n > 0) numbered.push({ index: n, line });
          else tabNames.push(line);
        }

        const want = String(args?.section ?? '').trim();

        // ── 2) 决定读哪一块 ──
        let mode = 'auto';          // 'auto' | 'section' | 'tab'
        let sectionIndex = null;
        let tabName = null;

        if (want) {
          const asNum = Number(want);
          if (Number.isFinite(asNum) && numbered.some((s) => s.index === asNum)) {
            mode = 'section'; sectionIndex = asNum;
          } else {
            const exactTab = tabNames.find((t) => t === want);
            const fuzzyTab = tabNames.find((t) => t.includes(want) || want.includes(t));
            const exactNum = numbered.find((s) => s.line === want);
            const fuzzyNum = numbered.find((s) => s.line.includes(want) || want.includes(s.line));
            if (exactTab || (fuzzyTab && !exactNum && !fuzzyNum)) {
              mode = 'tab'; tabName = exactTab || fuzzyTab;
            } else if (exactNum || fuzzyNum) {
              mode = 'section'; sectionIndex = (exactNum || fuzzyNum).index;
            } else {
              const list = [...tabNames.map((t) => `[标签页] ${t}`), ...numbered.map((s) => `${s.index}. ${s.line}`)].join('\n');
              return {
                content: `「${realTitle}」里没有叫「${want}」的章节或标签页。可用：\n${list}\n\n传名字或序号再读一次。`,
                isError: true,
              };
            }
          }
        } else if (tabNames.length) {
          // 默认读第一个标签页（这个站就是「舰船信息」）
          mode = 'tab'; tabName = tabNames[0];
        } else if (numbered.length) {
          mode = 'section'; sectionIndex = numbered[0].index;
        }

        // ── 3) 取正文 ──
        let text;
        if (mode === 'section') {
          const j = await callApi({ action: 'parse', page: realTitle, prop: 'text', section: String(sectionIndex) },
            { cacheKey: `txt:${realTitle}:${sectionIndex}` });
          text = stripHtml(j?.parse?.text || '');
        } else {
          // 标签页在整页里，只能取整页再切
          const j = await callApi({ action: 'parse', page: realTitle, prop: 'text' },
            { cacheKey: `full:${realTitle}` });
          const full = stripHtml(j?.parse?.text || '');
          text = mode === 'tab' ? sliceTab(full, tabNames, tabName) : stripLeadingToc(full, tabNames);
        }

        text = trimBoilerplate(text);
        if (!text.trim()) {
          return { content: `「${realTitle}」这一块读出来是空的（可能全是图表）。`, isError: true };
        }

        const offset = Math.max(0, Number(args?.offset) || 0);
        const slice = text.slice(offset, offset + maxChars);
        const more = offset + maxChars < text.length;

        const label = mode === 'section' ? `第 ${sectionIndex} 节` : (tabName ? `标签页「${tabName}」` : '正文');
        const toc = sections.map((s) => `${s.line}`).filter(Boolean).join(' · ');

        const head =
          `【碧蓝航线 BWIKI】${realTitle} · ${label}` +
          `\n来源：https://wiki.biligame.com/blhx/${encodeURIComponent(realTitle)}` +
          (toc ? `\n可读章节：${toc}` : '') +
          (offset ? `\n从第 ${offset} 字符开始` : '') +
          (more ? `\n还有后续，用 offset=${offset + maxChars} 继续` : '');

        return { content: `${head}\n\n----- 正文开始 -----\n${slice}\n----- 正文结束 -----` };
      } catch (e) {
        return { content: `读 BWIKI 失败：${String(e?.message ?? e)}`, isError: true };
      }
    },
  });
}

// ── 正文切块 ──────────────────────────────────────────────────

/**
 * 从整页文本里切出某个标签页的内容。
 * 用 lastIndexOf 找标签名，避开目录里那一次出现。
 */
function sliceTab(text, tabNames, want) {
  const pos = [];
  for (const name of tabNames) {
    const idx = text.lastIndexOf(name);
    if (idx >= 0) pos.push({ name, idx });
  }
  pos.sort((a, b) => a.idx - b.idx);
  if (!pos.length) return text;

  const start = want ? pos.find((p) => p.name === want) || pos[0] : pos[0];
  const next = pos.find((p) => p.idx > start.idx);
  return text.slice(start.idx, next ? next.idx : undefined);
}

/** 不指定标签页时的兜底：砍掉开头的「目录」块，从第一个标签名开始。 */
function stripLeadingToc(text, tabNames) {
  const head = text.slice(0, 200);
  if (!head.includes('目录')) return text;
  let best = -1;
  for (const name of tabNames) {
    const i = text.lastIndexOf(name);
    if (i >= 0 && (best < 0 || i < best)) best = i;
  }
  return best > 0 ? text.slice(best) : text;
}

// ── 底层 ──────────────────────────────────────────────────────

function sleep(ms) {
  return new Promise((r) => setTimeout(r, ms));
}

async function callApi(params, { cacheKey = null } = {}) {
  const cfg = getCfg();
  const cacheMinutes = Math.max(0, Number(cfg.cacheMinutes) || 30);
  const minGap = Math.max(0, Number(cfg.minGapMs) || 700);

  const cacheFile = cacheKey ? path.join(CACHE_DIR, `${safeName(cacheKey)}.json`) : null;
  if (cacheFile && cacheMinutes > 0) {
    try {
      const st = fs.statSync(cacheFile);
      if (Date.now() - st.mtimeMs < cacheMinutes * 60000) {
        return JSON.parse(fs.readFileSync(cacheFile, 'utf8'));
      }
    } catch { /* 无缓存 */ }
  }

  const wait = lastCallAt + minGap - Date.now();
  if (wait > 0) await sleep(wait);
  lastCallAt = Date.now();

  const qs = new URLSearchParams({ ...params, format: 'json', formatversion: '2' }).toString();
  const body = await curlGet(`${API}?${qs}`);

  let json;
  try {
    json = JSON.parse(body);
  } catch {
    throw new Error('BWIKI 返回了非 JSON（多半是 567 反爬页）。稍等一会儿再试；连续失败说明被临时限流。');
  }

  if (cacheFile && cacheMinutes > 0) {
    try {
      fs.mkdirSync(CACHE_DIR, { recursive: true });
      fs.writeFileSync(cacheFile, JSON.stringify(json), 'utf8');
    } catch { /* 缓存失败不影响结果 */ }
  }
  return json;
}

function curlGet(url) {
  return new Promise((resolve, reject) => {
    execFile('curl.exe', [
      '-4', '-sS', '--max-time', '25',
      '-A', UA,
      '-H', `Referer: ${REFERER}`,          // 不带这个就是 567
      '-H', 'Accept: application/json',
      url,
    ], { timeout: 35000, maxBuffer: 32 * 1024 * 1024, windowsHide: true }, (err, stdout, stderr) => {
      if (err) return reject(new Error(String(stderr || err.message || err).slice(0, 200)));
      resolve(String(stdout || ''));
    });
  });
}

function safeName(s) {
  return String(s).replace(/[\\/:*?"<>|\u0000-\u001f]/g, '_').slice(0, 120);
}

function stripHtml(html) {
  return String(html || '')
    .replace(/<script[\s\S]*?<\/script>/gi, ' ')
    .replace(/<style[\s\S]*?<\/style>/gi, ' ')
    .replace(/<br\s*\/?>/gi, '\n')
    .replace(/<\/(p|div|li|tr|h[1-6])>/gi, '\n')
    .replace(/<[^>]+>/g, ' ')
    .replace(/&#160;|&nbsp;/g, ' ')
    .replace(/&quot;/g, '"')
    .replace(/&#39;|&apos;/g, "'")
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&amp;/g, '&')
    .replace(/[ \t]+/g, ' ')
    .replace(/\n{3,}/g, '\n\n')
    .trim();
}

/** 清掉这个站每页都有的模板名残留和免责声明。 */
function trimBoilerplate(text) {
  let t = String(text || '');
  t = t.replace(/^(?:MediaWiki:[A-Za-z]+\s*)+/i, '');
  const endMark = t.indexOf('感谢您对WIKI的支持');
  if (endMark >= 0 && endMark < 1500) t = t.slice(endMark + '感谢您对WIKI的支持'.length);
  const w = t.indexOf('指挥官大人~');
  if (w >= 0 && w < 200) {
    const tail = t.indexOf('ヾ(o◕∀◕)ﾉ', w);
    if (tail >= 0 && tail - w < 500) t = t.slice(tail + 'ヾ(o◕∀◕)ﾉ'.length);
  }
  return t.replace(/^[\s:：·.]+/, '').trim();
}

function clean(s) {
  return stripHtml(s).replace(/\s+/g, ' ').trim();
}
