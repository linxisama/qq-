# -*- coding: utf-8 -*-
"""
把配装/配队讲解渲染成一张 PNG 卡片（gf2-guide 配套，完整版讲解用）。

用法：
    python render.py <input.json> <output.png>

输入 JSON 结构：
{
  "title": "威玛西娜 · 配装攻略",
  "subtitle": "少前2：追放 · 4.2版本",
  "sections": [
    { "heading": "角色定位", "bullets": ["物理输出核心", "依赖暴击词条"] },
    { "heading": "配装推荐", "bullets": ["武器：xxx", "配件：xxx"] }
  ],
  "sources": ["BV1Shpk6hEdX · 晓杰425"],
  "stamp": "2026/10/17"
}

设计说明（与 pcr-guide/render.py 同一套路，别各写一套）：
  · 宽固定 860，高按内容自适应（先量后画，两趟）。
  · 换行按**像素宽度**（中文不能按字符数切）。
  · 字体按优先级探测，全缺退回 Pillow 内置位图字体（中文会变方块，
    但至少不抛异常让整条链路挂掉）。
  · 只依赖 Pillow。
  · 防爆：分节/条目/行数全部设上限，超了截断并标注——模型偶尔会
    丢过来一大段文字，那时候要一张能发进 QQ 的图，不是一幅长卷。
"""
import sys
import os
import json

try:
    from PIL import Image, ImageDraw, ImageFont
except Exception as exc:  # Pillow 没装时给出人能看懂的原因
    sys.stderr.write("Pillow 不可用: %s\n" % exc)
    sys.exit(2)

# ── 视觉常量 ──────────────────────────────────────────────────────────
W = 860
PAD = 30
HEADER_H = 100
FOOTER_H = 64
SEC_GAP = 16

BG = (20, 24, 36)
HEADER_BG = (28, 34, 52)
LINE = (48, 56, 78)
TEXT = (238, 242, 252)
TEXT_DIM = (146, 156, 180)
TEXT_FAINT = (112, 122, 146)
ACCENT = (92, 225, 198)        # 分节标题条 / 条目圆点（少前2用青色，和 PCR 的金色区分）
LINK = (110, 175, 255)

MAX_SECTIONS = 8
MAX_BULLETS = 6
MAX_BULLET_LINES = 3
MAX_TOTAL_H = 2600             # QQ 图片别太夸张，超了截断

FONT_CANDIDATES = [
    ("C:/Windows/Fonts/msyh.ttc", "C:/Windows/Fonts/msyhbd.ttc"),
    ("C:/Windows/Fonts/msyh.ttf", "C:/Windows/Fonts/msyhbd.ttf"),
    ("C:/Windows/Fonts/NotoSansSC-VF.ttf", "C:/Windows/Fonts/NotoSansSC-VF.ttf"),
    ("C:/Windows/Fonts/simhei.ttf", "C:/Windows/Fonts/simhei.ttf"),
    ("C:/Windows/Fonts/Deng.ttf", "C:/Windows/Fonts/Dengb.ttf"),
]

_font_cache = {}


def pick_font_files():
    for reg, bold in FONT_CANDIDATES:
        if os.path.exists(reg):
            return reg, (bold if os.path.exists(bold) else reg)
    return None, None


REG_PATH, BOLD_PATH = pick_font_files()


def font(size, bold=False):
    key = (size, bold)
    if key in _font_cache:
        return _font_cache[key]
    path = BOLD_PATH if bold else REG_PATH
    f = None
    if path:
        try:
            f = ImageFont.truetype(path, size)
        except Exception:
            f = None
    if f is None:
        try:
            f = ImageFont.load_default()
        except Exception:
            f = None
    _font_cache[key] = f
    return f


def wrap(draw, text, fnt, max_w, max_lines=None):
    """按像素宽度换行；超出 max_lines 时最后一行加省略号。"""
    text = str(text or "").replace("\r", "")
    lines = []
    cur = ""
    for ch in text:
        if ch == "\n":
            lines.append(cur)
            cur = ""
            continue
        if draw.textlength(cur + ch, font=fnt) <= max_w:
            cur += ch
        else:
            lines.append(cur)
            cur = ch
    if cur:
        lines.append(cur)
    if max_lines and len(lines) > max_lines:
        lines = lines[:max_lines]
        last = lines[-1]
        while last and draw.textlength(last + "…", font=fnt) > max_w:
            last = last[:-1]
        lines[-1] = last + "…"
    return lines or [""]


def norm_sections(data):
    """清洗模型传来的分节：去空、裁数量。"""
    out = []
    for sec in (data.get("sections") or [])[:MAX_SECTIONS]:
        heading = str(sec.get("heading") or "").strip() or "要点"
        bullets = [str(b).strip() for b in (sec.get("bullets") or []) if str(b).strip()]
        if bullets:
            out.append({"heading": heading, "bullets": bullets[:MAX_BULLETS]})
    return out


def measure(draw, sections):
    """先量：算出每个分节块的高度。"""
    f_head = font(20, bold=True)
    f_bullet = font(17)
    inner_w = W - PAD * 2
    heights = []
    for sec in sections:
        h = 8 + 30 + 6                            # 分节标题行
        for b in sec["bullets"]:
            h += len(wrap(draw, b, f_bullet, inner_w - 26, MAX_BULLET_LINES)) * 26
        h += 6
        heights.append(h)
    return heights


def render(data, out_path):
    sections = norm_sections(data)
    title = str(data.get("title") or "").strip() or "少前2 · 配装攻略"
    subtitle = str(data.get("subtitle") or "").strip()
    stamp = str(data.get("stamp") or "").strip()
    sources = [str(s).strip() for s in (data.get("sources") or []) if str(s).strip()]

    if not sections:
        sys.stderr.write("没有可渲染的分节内容\n")
        return None

    probe = ImageDraw.Draw(Image.new("RGB", (10, 10)))
    heights = measure(probe, sections)
    total_h = HEADER_H + FOOTER_H + sum(heights) + SEC_GAP * max(0, len(sections) - 1) + PAD
    truncated = False
    if total_h > MAX_TOTAL_H:
        # 从尾部砍分节，直到塞得下；砍过就在页脚注明
        while sections and total_h > MAX_TOTAL_H:
            sections.pop()
            heights.pop()
            truncated = True
            total_h = HEADER_H + FOOTER_H + sum(heights) + SEC_GAP * max(0, len(sections) - 1) + PAD
        if not sections:
            sys.stderr.write("内容过多，无法渲染\n")
            return None

    img = Image.new("RGB", (W, max(360, total_h)), BG)
    d = ImageDraw.Draw(img)

    # ── 头部 ──
    d.rectangle([0, 0, W, HEADER_H], fill=HEADER_BG)
    d.rectangle([0, HEADER_H - 3, W, HEADER_H], fill=ACCENT)
    d.text((PAD, 22), title, font=font(28, bold=True), fill=TEXT)
    sub_bits = [b for b in [subtitle, stamp] if b]
    if sub_bits:
        d.text((PAD, 62), "   ·   ".join(sub_bits), font=font(17), fill=TEXT_DIM)

    # ── 分节 ──
    f_head = font(20, bold=True)
    f_bullet = font(17)
    inner_w = W - PAD * 2
    y = HEADER_H + SEC_GAP
    for sec, h in zip(sections, heights):
        # 分节标题：左侧竖条 + 文字
        d.rounded_rectangle([PAD, y + 8, PAD + 4, y + 8 + 24], radius=2, fill=ACCENT)
        d.text((PAD + 14, y + 6), sec["heading"], font=f_head, fill=TEXT)
        yy = y + 8 + 30 + 6
        for b in sec["bullets"]:
            d.text((PAD + 6, yy), "·", font=f_bullet, fill=ACCENT)
            for ln in wrap(d, b, f_bullet, inner_w - 26, MAX_BULLET_LINES):
                d.text((PAD + 24, yy), ln, font=f_bullet, fill=TEXT)
                yy += 26
        y += h + SEC_GAP

    # ── 页脚 ──
    fy = max(y, total_h - FOOTER_H)
    d.line([PAD, fy, W - PAD, fy], fill=LINE, width=1)
    if sources:
        src = "来源：" + " / ".join(sources[:3])
        for ln in wrap(d, src, font(15), inner_w, 2):
            d.text((PAD, fy + 14), ln, font=font(15), fill=LINK)
    note = "内容整理自 B 站攻略" + ("（过长已截断）" if truncated else "") + "，以游戏内当前版本为准"
    d.text((PAD, fy + 36), note, font=font(15), fill=TEXT_FAINT)

    os.makedirs(os.path.dirname(os.path.abspath(out_path)), exist_ok=True)
    img.save(out_path, "PNG", optimize=True)
    return out_path


def main():
    if len(sys.argv) < 3:
        sys.stderr.write("用法: render.py <input.json> <output.png>\n")
        return 2
    in_path, out_path = sys.argv[1], sys.argv[2]
    # utf-8-sig：兼容调用方（Node）的无 BOM 写法和手工带 BOM 的 JSON
    with open(in_path, "r", encoding="utf-8-sig") as fh:
        data = json.load(fh)
    try:
        result = render(data, out_path)
    except Exception as exc:
        sys.stderr.write("渲染失败: %s\n" % exc)
        return 3
    if not result:
        sys.stderr.write("渲染未产出\n")
        return 3
    sys.stdout.write(out_path)
    return 0


if __name__ == "__main__":
    sys.exit(main())
