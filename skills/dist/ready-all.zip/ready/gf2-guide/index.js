// 少前2攻略助手（gf2-guide v1.3.0）—— 本地自制技能
// ─────────────────────────────────────────────────────────────────────
// 类型：LLM 型技能（skills/）。
//   群友问的是开放式问题（"威玛西娜怎么养""4.2活动怎么打"），规则写不死、
//   要理解人话，所以放 skills/ 由模型决定何时调用；写成 plugins/（确定性型）
//   反而会静默失效 —— 那种类型靠核心代码按能力名触发，没人调就没有然后。
//
// 数据源：B 站搜索接口。
//   ⚠️ 实测结论（pcr-guide 同款路径，别照直觉改）：
//   · x/space/wbi/arc/search（UP 空间投稿）需要 wbi 签名且极易被风控
//     （随机 -352 或整页 WAF HTML），所以不用它。
//   · x/web-interface/search/type **不需要 wbi**，但要带 buvid3 cookie
//     （x/frontend/finger/spi 匿名获取，缓存 1 小时），不带会被风控。
//   · 查询词**别无脑补游戏名前缀**：B 站搜索是多词 AND，实测
//     「少女前线2 威玛西娜 配装」会把 18 万播放的正经配装视频整个挤掉；
//     原词优先，原词结果不够相关才补全兜底，杂音靠 GF2_HINT 过滤。
//   · 排序两种都拉合并：综合序保召回/质量，最新序保时效（实测
//     niche 关键词只拉最新序有时只有 3 条杂结果）。
//   · 偶发返回整页 HTML（WAF 挑战页）而不是 JSON，必须先取 text 判首字符，
//     直接 res.json() 会抛 "Unexpected token '<'"，很难排查。
//   · 主路径万一失效，自动降级 wbi 签名路径（nav 取密钥 → 排序签名）重试一次。
//   · 视频简介全文走 x/web-interface/view；热门评论走 x/v2/reply?sort=1
//     （按点赞排序，攻略视频的热评常有「省流」文字总结，是完整版讲解的关键素材）。
//
// 出图：交给同目录的 render.py（Python + Pillow），和 pcr-guide 同一条成熟路线。
//   本机实测系统 Python314 自带 Pillow；pcr-guide 配置里那个 pythonPath 是
//   别的机器的路径（不存在于本机），所以 findPython 的探测列表含 314。
//   渲染失败一律降级发文字版 —— 群里不能干等。
// ─────────────────────────────────────────────────────────────────────

import crypto from 'node:crypto';
import { spawn } from 'node:child_process';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const SKILL_ID = 'gf2-guide';
const SEARCH_API = 'https://api.bilibili.com/x/web-interface/search/type';
const WBI_SEARCH_API = 'https://api.bilibili.com/x/web-interface/wbi/search/type';
const SPI_API = 'https://api.bilibili.com/x/frontend/finger/spi';
const NAV_API = 'https://api.bilibili.com/x/web-interface/nav';
const VIEW_API = 'https://api.bilibili.com/x/web-interface/view';
const REPLY_API = 'https://api.bilibili.com/x/v2/reply';
const VIDEO_BASE = 'https://www.bilibili.com/video/';
// 官方 WIKI（gf2-bbs.exiliumgf.com）的后端 API。2026-10-17 实测打通：
//   · 角色列表：POST /wiki/handbook {type:1, limit:200, hero_param:{}, weapon_param:{}}
//     → data.list[]，每项含 hero_id/hero_name/attribute/role/team/skill 等
//   · 角色详情：POST /wiki/hero_detail {id: <hero_id>}
//     → data.info，含职业/稀有度/属性/武器/小队/简介/技能/固键共键/显像形态
//   · 注意是 POST + JSON body，响应壳 {Code:0, Message, data}；Code!==0 即失败。
//   · 这个 WIKI 比 wiki.biligame.com/gf2 全得多（68 个角色，伊格蕾塔/
//     威玛西娜在 B 站 WIKI 上都没页面），角色数据一律以它为准。
const WIKI_API = 'https://gf2-bbs-api.exiliumgf.com';
const WIKI_PAGE = 'https://gf2-bbs.exiliumgf.com/wiki/doll?id=';
const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
  + '(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36';

const CACHE_MS = 5 * 60 * 1000;      // 同一关键词 5 分钟内不重复请求
const BUVID_MS = 60 * 60 * 1000;     // buvid3 缓存 1 小时
const WBI_MS = 30 * 60 * 1000;       // wbi 密钥缓存 30 分钟

// 默认优先UP主：官方账号（实测 mid 697654195，约 108 万粉）。
// 官方视频（版本前瞻/活动预告）对「版本/活动」类问题很有用，可在设置里改。
const DEFAULT_UPS = ['少女前线2-追放制作组'];

// 命中这些词就认为是少前2相关内容（用来过滤 B 站搜出来的杂音）。
const GF2_HINT = /少女前线2|少前2|追放|girls'?\s*frontline\s*2|gf2/i;

// wbi 签名重排表（B 站公开算法，SocialSisterYi/bilibili-API-collect 同款）。
const MIXIN_KEY_ENC_TAB = [
  46, 47, 18, 2, 53, 8, 23, 32, 15, 50, 10, 31, 58, 3, 45, 35,
  27, 43, 5, 49, 33, 9, 42, 19, 29, 28, 14, 39, 12, 38, 41, 13,
  37, 48, 7, 16, 24, 55, 40, 61, 26, 17, 0, 1, 60, 51, 30, 4,
  22, 25, 54, 21, 56, 59, 6, 63, 57, 62, 11, 36, 20, 34, 44, 52
];

const HERE = path.dirname(fileURLToPath(import.meta.url));
const RENDER_SCRIPT = path.join(HERE, 'render.py');
const HERO_CARD_SCRIPT = path.join(HERE, 'hero_card.py');
const OUT_DIR = path.join(os.tmpdir(), 'qq-agent-gf2-guide');

let _api = null;
let _registered = false;
let cfgOf = () => ({});
let log = () => {};

// ── 缓存 ─────────────────────────────────────────────────────────────

const _cache = new Map();
function cacheGet(k) {
  const v = _cache.get(k);
  if (!v) return null;
  if (Date.now() - v.at > CACHE_MS) { _cache.delete(k); return null; }
  return v.value;
}
function cacheSet(k, value) {
  _cache.set(k, { at: Date.now(), value });
  if (_cache.size > 60) _cache.delete(_cache.keys().next().value);
}

let _buvid = { v: '', at: 0 };
let _wbi = { key: '', at: 0 };

function conf() {
  const c = cfgOf() || {};
  const ups = String(c.upList ?? '').trim()
    ? String(c.upList).split(/[,，\n]/).map((s) => s.trim()).filter(Boolean)
    : DEFAULT_UPS.slice();
  return {
    ups,
    returnCount: Math.min(20, Math.max(1, Number(c.returnCount) || 8)),
    descChars: Math.min(400, Math.max(0, Number(c.descChars) || 90)),
    timeoutMs: Math.min(60000, Math.max(3000, Number(c.timeoutMs) || 15000)),
    // totalrank = 综合排序：实测对角色攻略召回最好（18 万播放的正经
    // 配装视频只在综合序里出现），设为默认；pubdate 问「最新/当期」时用。
    order: c.order === 'pubdate' ? 'pubdate' : 'totalrank',
    pythonPath: String(c.pythonPath || '').trim(),
    renderTimeoutMs: Math.min(120000, Math.max(5000, Number(c.renderTimeoutMs) || 30000)),
    heroCardVoices: c.heroCardVoices !== false
  };
}

// ── B 站请求 ─────────────────────────────────────────────────────────

async function getBuvid() {
  if (_buvid.v && Date.now() - _buvid.at < BUVID_MS) return _buvid.v;
  try {
    const res = await _api.fetch(SPI_API, { headers: { 'User-Agent': UA } });
    const txt = await res.text();
    if (txt.startsWith('{')) {
      const j = JSON.parse(txt);
      const v = (j && j.data && j.data.b_3) || '';
      if (v) { _buvid = { v, at: Date.now() }; return v; }
    }
  } catch (e) {
    log(`[${SKILL_ID}] 取 buvid3 失败（继续尝试无 cookie 请求）：${e && e.message}`);
  }
  return '';
}

/** B 站接口统一入口：带 buvid3 cookie、判 WAF、判 code。返回解析后的 JSON。 */
async function biliGetJson(url, cookie) {
  const { timeoutMs } = conf();
  if (!_api || typeof _api.fetch !== 'function') {
    throw new Error('没有联网权限（skill.json 里需要 permissions: ["web_fetch"]）');
  }
  const ctl = new AbortController();
  const timer = setTimeout(() => ctl.abort(), timeoutMs);
  let txt = '';
  try {
    const res = await _api.fetch(url, {
      signal: ctl.signal,
      headers: {
        'User-Agent': UA,
        Referer: 'https://www.bilibili.com/',
        Accept: 'application/json, text/plain, */*',
        ...(cookie ? { Cookie: cookie } : {})
      }
    });
    if (!res || !res.ok) throw new Error(`B 站返回 HTTP ${res ? res.status : '未知'}`);
    txt = await res.text();
  } catch (e) {
    if (e && e.name === 'AbortError') throw new Error(`请求 B 站超时（${timeoutMs}ms）`);
    throw e;
  } finally {
    clearTimeout(timer);
  }

  // ⚠️ WAF 挑战页是 HTML，直接 res.json() 会抛 "Unexpected token '<'"。
  if (!txt.trimStart().startsWith('{')) {
    throw new Error('B 站返回了风控页面（不是 JSON），稍等一会儿再试');
  }
  const j = JSON.parse(txt);
  if (j.code !== 0) throw new Error(`B 站接口错误 ${j.code}：${j.message || '未知'}`);
  return j;
}

/** wbi 签名：参数排序 → 去特殊字符 → md5(query + mixin_key)。 */
function wbiSign(params, mixinKey) {
  const clean = (v) => String(v).replace(/[!'()*]/g, '').replace(/\s+/g, '');
  const p = {};
  for (const [k, v] of Object.entries(params)) p[k] = clean(v);
  p.wts = String(Math.floor(Date.now() / 1000));
  const sorted = Object.keys(p).sort();
  const qs = new URLSearchParams(sorted.map((k) => [k, p[k]])).toString();
  p.w_rid = crypto.createHash('md5').update(qs + mixinKey).digest('hex');
  return new URLSearchParams(
    sorted.concat('w_rid').map((k) => [k, p[k]])
  ).toString();
}

async function getWbiMixinKey() {
  if (_wbi.key && Date.now() - _wbi.at < WBI_MS) return _wbi.key;
  const j = await biliGetJson(NAV_API, '');
  const wbi = (j.data && j.data.wbi_img) || {};
  const img = String(wbi.img_url || '').split('/').pop().split('.')[0];
  const sub = String(wbi.sub_url || '').split('/').pop().split('.')[0];
  if (!img || !sub) throw new Error('nav 接口未返回 wbi 密钥');
  const raw = img + sub;
  const key = MIXIN_KEY_ENC_TAB.map((i) => raw[i] || '').join('').slice(0, 32);
  _wbi = { key, at: Date.now() };
  return key;
}

async function searchVideos(keyword, order) {
  order = order || conf().order;
  const qs = new URLSearchParams({ search_type: 'video', order, keyword }).toString();
  const buvid = await getBuvid();
  const cookie = buvid ? `buvid3=${buvid}` : '';
  try {
    // 主路径：非 wbi + buvid3（实测稳定）
    const j = await biliGetJson(`${SEARCH_API}?${qs}`, cookie);
    return (j.data && j.data.result) || [];
  } catch (e) {
    // 降级：wbi 签名路径重试一次
    log(`[${SKILL_ID}] 主搜索路径失败（${e && e.message}），改用 wbi 签名重试`);
    const mixin = await getWbiMixinKey();
    const signed = wbiSign({ search_type: 'video', order, keyword, page: 1 }, mixin);
    const j2 = await biliGetJson(`${WBI_SEARCH_API}?${signed}`, cookie);
    return (j2.data && j2.data.result) || [];
  }
}

/**
 * 单个查询的候选池：综合序 + 最新序各拉一次，按 bvid 去重合并。
 * 为什么两种排序都拉（2026-10-17 实测教训，别改回去）：
 *   · 只用综合序：经典攻略全，但可能漏掉当期新视频；
 *   · 只用最新序： niche 关键词有时只返回 3 条杂结果（实测
 *     「威玛西娜 配装」最新序只有 3 条，正经视频差点漏掉）；
 *   · 两种互补合并才不漏。某一种失败（风控）时用另一种的结果继续。
 */
async function searchPool(keyword) {
  const main = conf().order;
  const orders = main === 'pubdate' ? ['pubdate', 'totalrank'] : ['totalrank', 'pubdate'];
  const seen = new Set();
  const pool = [];
  for (const ord of orders) {
    let raw = [];
    try {
      raw = await searchVideos(keyword, ord);
    } catch (e) {
      log(`[${SKILL_ID}] 搜索（${ord}）失败：${e && e.message}，用已拿到的结果继续`);
    }
    for (const v of raw) {
      const bvid = String(v.bvid || '');
      if (bvid && seen.has(bvid)) continue;
      if (bvid) seen.add(bvid);
      pool.push(v);
    }
  }
  return pool;
}

// ── 官方 WIKI（gf2-bbs.exiliumgf.com）────────────────────────────────

const WIKI_LIST_MS = 30 * 60 * 1000;   // 角色列表缓存 30 分钟
const WIKI_DETAIL_MS = 5 * 60 * 1000;  // 角色详情缓存 5 分钟（wiki 与 hero_card 可能都要用）
let _heroList = { at: 0, items: [] };
const _heroDetail = new Map();         // hero_id -> {at, info}

/** WIKI 接口统一入口：POST + JSON body，判 Code。 */
async function wikiPost(path, body) {
  const { timeoutMs } = conf();
  const ctl = new AbortController();
  const timer = setTimeout(() => ctl.abort(), timeoutMs);
  try {
    const res = await _api.fetch(WIKI_API + path, {
      method: 'POST',
      signal: ctl.signal,
      headers: {
        'User-Agent': UA,
        'Content-Type': 'application/json',
        Accept: 'application/json',
        Referer: 'https://gf2-bbs.exiliumgf.com/'
      },
      body: JSON.stringify(body || {})
    });
    if (!res || !res.ok) throw new Error(`WIKI 返回 HTTP ${res ? res.status : '未知'}`);
    const txt = await res.text();
    if (!txt.trimStart().startsWith('{')) throw new Error('WIKI 返回了风控页面（不是 JSON）');
    const j = JSON.parse(txt);
    // ⚠️ WIKI 响应壳是**大写**键：{Code, Message, data}（实测），不是 B 站的小写 code
    const code = j.code ?? j.Code;
    const message = j.message ?? j.Message;
    if (Number(code) !== 0) throw new Error(`WIKI 接口错误 ${code}：${message || '未知'}`);
    return j.data;
  } catch (e) {
    if (e && e.name === 'AbortError') throw new Error(`请求 WIKI 超时（${timeoutMs}ms）`);
    throw e;
  } finally {
    clearTimeout(timer);
  }
}

/** 全量角色列表（缓存 30 分钟）。 */
async function getHeroList() {
  if (_heroList.items.length && Date.now() - _heroList.at < WIKI_LIST_MS) {
    return _heroList.items;
  }
  const data = await wikiPost('/wiki/handbook',
    { type: 1, limit: 200, hero_param: {}, weapon_param: {} });
  const items = (data && data.list) || [];
  if (!items.length) throw new Error('WIKI 角色列表是空的');
  _heroList = { at: Date.now(), items };
  return items;
}

/** 去 HTML（WIKI 的技能/固键描述是 Word 搬过来的表格，必须洗成纯文本）。 */
function stripHtml(s) {
  return String(s ?? '')
    .replace(/<a[^>]*>[\s\S]*?<\/a>/gi, '')   // 先整体删链接（「查看角色PV」「查看武器图鉴」这类跳转，没用）
    .replace(/<br\s*\/?>/gi, '\n')
    .replace(/<\/(p|div|tr|li|h[1-6])>/gi, '\n')
    .replace(/<[^>]+>/g, ' ')
    .replace(/&nbsp;/gi, ' ')
    .replace(/&amp;/gi, '&')
    .replace(/&lt;/gi, '<')
    .replace(/&gt;/gi, '>')
    .replace(/&quot;/gi, '"')
    .replace(/[ \t]+/g, ' ')
    .replace(/\n\s*\n+/g, '\n')
    .trim();
}

function clip(s, n) {
  const t = stripHtml(s);
  return t.length > n ? t.slice(0, n) + '…' : t;
}

/** 行内字段用：把所有空白（含换行）压成单空格，避免表格残渣把一行撑炸。 */
function clipFlat(s, n) {
  const t = stripHtml(s).replace(/\s+/g, ' ');
  return t.length > n ? t.slice(0, n) + '…' : t;
}

/** 角色名匹配：精确 → 角色名包含输入 → 输入包含角色名。 */
function findHero(list, name) {
  const n = String(name || '').trim();
  if (!n) return null;
  let hit = list.find((h) => h.hero_name === n);
  if (hit) return hit;
  if (n.length >= 2) hit = list.find((h) => h.hero_name.includes(n));
  if (hit) return hit;
  return list.find((h) => h.hero_name.length >= 2 && n.includes(h.hero_name)) || null;
}

/** 把角色详情格式化成给模型看的文本（分段截断，控制 token）。 */
function fmtHeroDetail(hero, info) {
  const lines = [
    'status: ok',
    `【${info.name || hero.hero_name}】官方 WIKI 资料（${WIKI_PAGE}${hero.hero_id}）`,
    `职业：${info.role || '?'} ｜ 稀有度：${info.rarity || '?'} ｜ 异位属性：${info.attr || '?'}`
      + ` ｜ 小队：${info.team || '?'}`,
    `武器：${info.weapon || '?'}${info.model ? `（${info.model}` : ''}`
      + `${info.ammo_model ? ' · ' + info.ammo_model + '弹' : ''}${info.model ? '）' : ''}`
  ];
  if (info.cv) lines.push(`配音：${clipFlat(info.cv, 120)}`);
  if (info.desc) lines.push('', '【角色简介】', clip(info.desc, 400));

  const skills = Array.isArray(info.skill) ? info.skill : [];
  if (skills.length) {
    lines.push('', `【技能】（${skills.length} 个）`);
    for (const s of skills.slice(0, 6)) {
      lines.push(`· ${s.name}：${clip(s.desc, 260) || '(无描述)'}`);
    }
  }

  const talents = Array.isArray(info.talent) ? info.talent : [];
  if (talents.length) {
    lines.push('', `【固键/共键】（${talents.length} 项）`);
    for (const t of talents.slice(0, 8)) {
      lines.push(`· ${t.name}：${clip(t.desc, 160) || '(无描述)'}`);
    }
  }

  if (info.remoulding) {
    lines.push('', '【显像形态】', clip(info.remoulding, 600));
  }
  if (info.weapon_desc) {
    lines.push('', '【武器】', clip(info.weapon_desc, 300));
  }

  lines.push('', '提示：以上是官方 WIKI 的结构化资料，写配装/讲解时角色数据以这些为准，'
    + 'B 站攻略视频作操作层面补充；数值以游戏内当前版本为准。');
  return lines.join('\n');
}

async function wikiLookup(args) {
  const name = String((args && (args.name || args.hero || args.keyword)) || '').trim();
  if (!name) {
    return { content: '没给角色名。请填 name，例如：伊格蕾塔、威玛西娜、针、莱娜。', isError: true };
  }
  const list = await getHeroList();
  const hero = findHero(list, name);
  if (!hero) {
    const names = list.map((h) => h.hero_name).join('、');
    return {
      content: `官方 WIKI 里没有找到「${name}」这个角色。WIKI 现收录 ${list.length} 个角色：${names}。`
        + '请从上面列表里选正确的角色名重试（注意译名，如 AK15 在 WIKI 里叫「威玛西娜」）。',
      isError: true
    };
  }
  const info = await getHeroDetail(hero.hero_id);
  if (!info.name) throw new Error('WIKI 返回的角色详情是空的');
  return { content: fmtHeroDetail(hero, info) };
}

/** 角色详情 info（带 5 分钟缓存，wiki 与 hero_card 共用；返回的是 info 本体）。 */
async function getHeroDetail(heroId) {
  const hit = _heroDetail.get(heroId);
  if (hit && Date.now() - hit.at < WIKI_DETAIL_MS) return hit.info;
  const data = await wikiPost('/wiki/hero_detail', { id: heroId });
  const info = (data && data.info) || {};
  _heroDetail.set(heroId, { at: Date.now(), info });
  if (_heroDetail.size > 30) _heroDetail.delete(_heroDetail.keys().next().value);
  return info;
}

/** 解析数值面板（prop 是 HTML 表格，洗完是「攻击： 784」这样的行）。 */
function parseStats(propHtml) {
  const text = stripHtml(propHtml);
  const stats = [];
  const re = /([^\s：:]{1,8})\s*：\s*([^\n]+)/g;
  let m;
  while ((m = re.exec(text)) !== null) {
    const label = m[1].replace(/\s+/g, '');
    const value = m[2].trim();
    if (label && value && value.length <= 20) stats.push({ label, value });
  }
  return stats.slice(0, 12);
}

/** 解析椎体表格（battle_skill 是规整的 HTML 表：椎体等级/技能等级/椎体效果/技能追加效果）。 */
function parseZhui(battleHtml) {
  const rows = String(battleHtml || '').match(/<tr[^>]*>[\s\S]*?<\/tr>/gi) || [];
  const out = [];
  for (const row of rows) {
    const cells = (row.match(/<t[dh][^>]*>([\s\S]*?)<\/t[dh]>/gi) || [])
      .map((c) => clipFlat(c.replace(/<[^>]+>/g, ' '), 2000).trim());
    if (cells.length < 3) continue;
    if (cells[0].includes('椎体等级')) continue;   // 表头
    out.push({
      tier: cells[0] || '',
      skill: cells[1] || '',
      effect: cells[2] || '',
      extra: cells[3] || ''
    });
  }
  return out;
}

/** 解析显像形态表格（remoulding：显像形态/解锁等级/显像因子/效果，四列规整表）。 */
function parseRemould(remouldHtml) {
  const rows = String(remouldHtml || '').match(/<tr[^>]*>[\s\S]*?<\/tr>/gi) || [];
  const out = [];
  for (const row of rows) {
    const cells = (row.match(/<t[dh][^>]*>([\s\S]*?)<\/t[dh]>/gi) || [])
      .map((c) => clipFlat(c.replace(/<[^>]+>/g, ' '), 2000).trim());
    if (cells.length < 4) continue;
    if (cells[0].includes('显像形态')) continue;   // 表头
    out.push({ form: cells[0] || '', level: cells[1] || '', factor: cells[2] || '', effect: cells[3] || '' });
  }
  return out;
}

/** 组装 hero_card 渲染所需的 payload（从 WIKI 详情）。 */
function buildHeroPayload(hero, info, includeVoices) {
  const tags = [info.role, info.rarity, info.attr, info.team].filter(Boolean);
  const infoLines = [];
  if (info.weapon) {
    infoLines.push(`武器：${info.weapon}`
      + `${info.model ? `（${info.model}` : ''}`
      + `${info.ammo_model ? ' · ' + info.ammo_model + '弹' : ''}`
      + `${info.model ? '）' : ''}`);
  }
  if (info.cv) infoLines.push(`配音：${clipFlat(info.cv, 60)}`);
  if (info.en_name) infoLines.push(`英文名：${info.en_name}`);

  // 立绘：优先 hero_profile 里的「立绘」高清图，退回 portrait.pc
  let portraitUrl = '';
  const prof = (info.hero_profile || []).find((p) => p && p.name === '立绘');
  if (prof) {
    const m = String(prof.desc || '').match(/src="([^"]+)"/);
    if (m) portraitUrl = m[1];
  }
  if (!portraitUrl) portraitUrl = (info.portrait || {}).pc || '';

  return {
    mode: 'hero',
    name: info.name || hero.hero_name,
    portrait_url: portraitUrl,
    tags,
    info_lines: infoLines,
    desc: stripHtml(info.desc),
    stats: parseStats(info.prop),
    skills: (info.skill || []).map((s) => ({ name: s.name, desc: stripHtml(s.desc) })),
    talents: (info.talent || []).map((t) => ({ name: t.name, desc: stripHtml(t.desc) })),
    weapon: stripHtml(info.weapon_desc),
    zhui: parseZhui(info.battle_skill),
    remould: parseRemould(info.remoulding),
    gifts: (info.gift || [])
      .map((g) => ({ name: g.name, desc: clipFlat(g.desc, 120) }))
      .filter((g) => g.desc),
    voices: includeVoices
      ? (info.voice || []).slice(0, 30).map((v) => ({ title: v.title, speech: v.speech }))
      : [],
    voices_battle: includeVoices
      ? (info.voice_battle || []).slice(0, 25).map((v) => ({ title: v.title, speech: v.speech }))
      : [],
    link: WIKI_PAGE + hero.hero_id
  };
}

/** 出 WIKI 角色大卡。 */
async function heroCard(args, chatKey, sender) {
  const name = String((args && args.name) || '').trim();
  if (!name) {
    return { content: '没给角色名。请填 name，例如：伊格蕾塔、威玛西娜、罗蕾莱。', isError: true };
  }
  const list = await getHeroList();
  const hero = findHero(list, name);
  if (!hero) {
    const names = list.map((h) => h.hero_name).join('、');
    return {
      content: `官方 WIKI 里没有找到「${name}」这个角色。WIKI 现收录 ${list.length} 个角色：${names}。`
        + '请从上面列表里选正确的角色名重试。',
      isError: true
    };
  }
  const includeVoices = conf().heroCardVoices !== false;
  const payload = buildHeroPayload(hero, await getHeroDetail(hero.hero_id), includeVoices);

  if (!sender || !chatKey || typeof sender.sendImage !== 'function') {
    // 没有发送通道：把资料整理成文字返回，让模型自己发
    const lines = [`【${payload.name}】官方 WIKI 资料`, `职业：${payload.tags.join(' / ')}`];
    if (payload.stats.length) {
      lines.push('数值：' + payload.stats.map((s) => `${s.label} ${s.value}`).join(' · '));
    }
    for (const s of payload.skills.slice(0, 5)) lines.push(`· ${s.name}：${clipFlat(s.desc, 120)}`);
    return { content: lines.join('\n'), isError: true };
  }

  const file = await runCardScript(HERO_CARD_SCRIPT, payload);
  await sender.sendImage(chatKey, { file }, { note: `少前2角色卡 ${payload.name}` });
  log(`[${SKILL_ID}] 已发角色大卡：${file}（${payload.name}）`);
  return {
    content: `角色大卡已发送（${payload.name}：立绘/数值/技能/固键/武器/椎体/显像/羁绊`
      + `${includeVoices ? '/语音' : ''}）。接着在回复里给群友配装/养成文字讲解，`
      + '并提醒「以游戏内当前版本为准」；不要逐句复述图片内容。'
  };
}

// ── 格式化 ───────────────────────────────────────────────────────────

function cleanTitle(s) {
  return String(s || '')
    .replace(/<[^>]+>/g, '')       // B 站会给关键词包 <em class="keyword">
    .replace(/&amp;/g, '&')
    .replace(/&quot;/g, '"')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/\s+/g, ' ')
    .trim();
}

function cleanDesc(s) {
  const t = cleanTitle(s);
  // B 站不少视频的简介就是 "-"、"." 这种占位符，列出来没信息量
  if (!t || t.length < 4 || /^[-—–.·、,，。\s]+$/.test(t)) return '';
  return t;
}

function fmtVideo(v, descChars) {
  const desc = cleanDesc(v.description);
  return {
    title: cleanTitle(v.title),
    up: String(v.author || ''),
    bvid: String(v.bvid || ''),
    ts: Number(v.pubdate || 0) * 1000,
    date: v.pubdate ? new Date(v.pubdate * 1000).toLocaleDateString('zh-CN') : '',
    duration: String(v.duration || ''),
    play: Number(v.play || 0),
    desc: descChars > 0 ? desc.slice(0, descChars) : ''
  };
}

function isRelevant(item, upSet) {
  if (upSet.has(item.up)) return true;
  return GF2_HINT.test(item.title) || GF2_HINT.test(item.desc);
}

function shortNum(n) {
  if (!n) return '';
  if (n >= 10000) return (n / 10000).toFixed(1) + '万';
  return String(n);
}

function buildQuery(keyword) {
  const s = String(keyword || '').trim();
  if (!s) return '';
  // 关键词里没带游戏名就补上，否则「配队」能搜出一堆别的游戏
  if (GF2_HINT.test(s)) return s;
  return '少女前线2 ' + s;
}

/** 从任意输入里认出 BV 号。 */
function parseBvid(input) {
  const m = String(input ?? '').match(/BV[0-9A-Za-z]{10}/);
  return m ? m[0] : '';
}

// ── 查询 ─────────────────────────────────────────────────────────────

async function lookup(args) {
  const c = conf();
  const upSet = new Set(c.ups);
  const rawKeyword = String((args && (args.keyword || args.topic)) || '').trim();
  const onlyUp = String((args && args.up) || '').trim();

  if (!rawKeyword && !onlyUp) {
    return {
      content: '没给查询内容。请填 keyword，例如：某个角色名、新手开荒、配队、强度榜、当期活动攻略。',
      isError: true
    };
  }

  // 候选查询：原词优先。**不要**无脑补游戏名 —— 2026-10-17 实测：
  // 「少女前线2 威玛西娜 配装」这种补全词会把 18 万播放的正经配装
  // 视频整个挤掉（B 站搜索是多词 AND，前缀白加一个约束）。
  // 只有原词没带游戏名、且原词结果不够相关时，才补全兜底；
  // 杂音靠 isRelevant 的 GF2_HINT 过滤，不靠查询词。
  let subject = rawKeyword;
  if (onlyUp) subject = `${onlyUp} ${rawKeyword}`.trim();
  const candidates = [subject];
  if (!GF2_HINT.test(subject)) candidates.push('少女前线2 ' + subject);

  const key = 'q:' + candidates.join(' | ');
  let items = cacheGet(key);
  if (!items) {
    const pool = [];
    const seen = new Set();
    for (const q of candidates) {
      for (const v of await searchPool(q)) {
        const bvid = String(v.bvid || '');
        if (bvid && seen.has(bvid)) continue;
        if (bvid) seen.add(bvid);
        pool.push(v);
      }
      // 相关结果够 3 条就不再补查询：省请求、省模型轮次
      const relevant = pool.filter((v) => isRelevant(fmtVideo(v, 0), upSet)).length;
      if (relevant >= 3) break;
    }
    items = pool.map((v) => fmtVideo(v, c.descChars));
    cacheSet(key, items);
  }

  let picked = items.filter((it) => isRelevant(it, upSet));
  if (onlyUp) picked = picked.filter((it) => it.up.includes(onlyUp));
  if (!picked.length) {
    return {
      content: `B 站上没搜到「${rawKeyword || onlyUp}」相关的少女前线2视频（关键词：${candidates[0]}）。`
        + '可以换个说法再试：角色全名、玩法全称，或者加上「攻略 / 作业 / 配队 / auto」；'
        + '也可以改用 web_search 查图文攻略。',
      isError: true
    };
  }

  // 排序：标题命中主词 > 优先UP主 > 高播放 > 发布时间。
  // 主词 = 关键词里最长的词（通常是角色名/实体名）——不能拿整个
  // keyword 去 includes：「威玛西娜 配装」整个短语几乎不出现在标题里，
  // 会让标题命中失效（2026-10-17 踩过的坑）。
  // 高播放分档加权（10万+2、1万+1）：群友用播放量投票出来的攻略，
  // 比新发的没人看的靠谱；版本号类查询有标题命中保护，不怕老视频抢位。
  const mainTerm = subject.split(/\s+/).filter(Boolean)
    .sort((a, b) => b.length - a.length)[0] || subject;
  const playTier = (it) => (it.play >= 100000 ? 2 : it.play >= 10000 ? 1 : 0);
  const rank = (it) => (it.title.includes(mainTerm) ? 2 : 0)
    + (upSet.has(it.up) ? 1 : 0)
    + playTier(it);
  picked.sort((a, b) => (rank(b) - rank(a)) || (b.ts - a.ts));

  const out = [`【B站 · 少女前线2攻略视频｜关键词：${rawKeyword || onlyUp}】`];

  const line = (it, i) => {
    const star = upSet.has(it.up) ? '★' : '　';
    return `  ${i}.${star} ${it.title}\n       ${it.up} · ${it.date}`
      + `${it.duration ? ' · ' + it.duration : ''}`
      + `${it.play ? ' · ' + shortNum(it.play) + '播放' : ''}\n       ${VIDEO_BASE}${it.bvid}`
      + (it.desc ? `\n       简介：${it.desc}` : '');
  };

  let n = 0;
  for (const it of picked.slice(0, c.returnCount)) out.push(line(it, ++n));
  if (picked.length > n) out.push('', `（另有 ${picked.length - n} 条未列出）`);
  if (upSet.size) out.push('', `★ = 优先UP主（${c.ups.join(' / ')}）`);

  out.push('', '提示：以上是视频标题与简介，正文在视频里；回复时给群友链接，'
    + '别把没看过的视频内容说成自己看过的。'
    + '要写配装/配队讲解时，优先挑标题最对口、播放量最高的那条，用 gf2-guide__read 读它的素材。');

  return { content: out.join('\n') };
}

// ── 读攻略正文素材（简介全文 + 热门评论）────────────────────────────

async function readVideo(args) {
  const bvid = parseBvid(args && (args.url || args.bvid || args.keyword));
  if (!bvid) {
    return {
      content: '没认出 BV 号。请传视频链接或 BV 号，例如 https://www.bilibili.com/video/BV1Shpk6hEdX。'
        + 'BV 号从 gf2-guide__lookup 的返回里拿。',
      isError: true
    };
  }

  const buvid = await getBuvid();
  const cookie = buvid ? `buvid3=${buvid}` : '';
  const view = await biliGetJson(`${VIEW_API}?bvid=${encodeURIComponent(bvid)}`, cookie);
  const d = view.data || {};
  const stat = d.stat || {};
  const owner = d.owner || {};

  const lines = [
    'status: ok',
    `标题：${cleanTitle(d.title) || '(无)'}`,
    `UP主：${owner.name || '(未知)'}${owner.mid ? ` (uid ${owner.mid})` : ''}`,
    `发布：${d.pubdate ? new Date(d.pubdate * 1000).toLocaleDateString('zh-CN') : '(未知)'}`
      + `    数据：播放 ${shortNum(stat.view) || 0} · 弹幕 ${shortNum(stat.danmaku) || 0} · 点赞 ${shortNum(stat.like) || 0}`,
    `链接：${VIDEO_BASE}${d.bvid || bvid}`
  ];

  const pages = Array.isArray(d.pages) ? d.pages : [];
  if (pages.length > 1) {
    lines.push(`分P（共 ${pages.length} 个，只列前 8 个）：`);
    for (const p of pages.slice(0, 8)) {
      lines.push(`  P${p.page} ${cleanTitle(p.part) || '(未命名)'}`);
    }
  }

  // 简介全文 —— 完整版讲解的主要素材之一
  const desc = cleanTitle(d.desc);
  if (desc && desc !== '-') {
    lines.push('', '【简介全文】', desc.slice(0, 1500));
  } else {
    lines.push('', '【简介全文】（这个视频没写简介）');
  }

  // 热门评论（按点赞）—— 攻略视频的热评常有「省流」文字总结。
  // 取不到不影响主流程：简介 + 标题仍然够写一版讲解。
  try {
    const reply = await biliGetJson(
      `${REPLY_API}?type=1&oid=${encodeURIComponent(d.aid)}&sort=1&ps=6&pn=1`, cookie);
    const replies = (reply.data || {}).replies || [];
    if (replies.length) {
      lines.push('', '【热门评论（按点赞排序，前 6 条）】');
      for (const rp of replies) {
        const msg = String((rp.content || {}).message || '').replace(/\s+/g, ' ').trim();
        if (msg) lines.push(`· [${rp.like || 0}赞] ${msg.slice(0, 200)}`);
      }
    } else {
      lines.push('', '【热门评论】（没有评论或评论区已关闭）');
    }
  } catch (e) {
    lines.push('', `【热门评论】没取到（${(e && e.message) || e}）——不影响简介使用`);
  }

  lines.push('', '注意：以上是真实素材。写讲解时只能用这些内容 + 常识，'
    + '不要编造简介和评论里没有的数值/机制；素材不够就明说，或改用 web_search / web_fetch 补充。');

  return { content: lines.join('\n') };
}

// ── Python 渲染 ──────────────────────────────────────────────────────

function findPython() {
  const configured = conf().pythonPath;
  if (configured && fs.existsSync(configured)) return configured;
  const cands = [];
  if (process.env.LOCALAPPDATA) {
    // ⚠️ 探测列表要含 314：本机系统 Python 就是 3.14（pcr-guide 的列表停在 310，
    //    它配置里那个 pythonPath 又是别的机器的路径，照抄会出不了图）。
    for (const v of ['Python314', 'Python313', 'Python312', 'Python311', 'Python310']) {
      cands.push(path.join(process.env.LOCALAPPDATA, 'Programs', 'Python', v, 'python.exe'));
    }
  }
  for (const p of cands) if (fs.existsSync(p)) return p;
  return 'python';   // 交给 PATH（Windows 上可能是应用商店 stub，故优先配置项）
}

function runPy(script, args, timeoutMs) {
  const py = findPython();
  return new Promise((resolve, reject) => {
    let child;
    try {
      child = spawn(py, [script, ...args], { windowsHide: true });
    } catch (e) {
      reject(new Error(`无法启动 Python（${py}）：${e && e.message}`));
      return;
    }
    let err = '';
    let settled = false;
    const timer = setTimeout(() => {
      if (settled) return;
      settled = true;
      try { child.kill(); } catch { /* ignore */ }
      reject(new Error(`脚本超时（${timeoutMs}ms）`));
    }, timeoutMs);
    child.stderr.on('data', (d) => { err += d.toString(); });
    child.on('error', (e) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      reject(new Error(`无法启动 Python（${py}）：${e && e.message}`));
    });
    child.on('close', (code) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      if (code === 0) resolve();
      else reject(new Error(`脚本退出码 ${code}${err ? '：' + err.trim().slice(0, 200) : ''}`));
    });
  });
}

function pruneOld(keep = 20) {
  try {
    const files = fs.readdirSync(OUT_DIR)
      .filter((f) => f.endsWith('.png'))
      .map((f) => ({ f, t: fs.statSync(path.join(OUT_DIR, f)).mtimeMs }))
      .sort((a, b) => b.t - a.t);
    for (const x of files.slice(keep)) fs.rmSync(path.join(OUT_DIR, x.f), { force: true });
  } catch { /* 清理失败无所谓 */ }
}

/** 通用出图管线：写 payload JSON → 调指定 Python 脚本 → 返回 PNG 路径。 */
async function runCardScript(script, payload) {
  if (!fs.existsSync(script)) {
    throw new Error(`找不到渲染脚本 ${script}`);
  }
  fs.mkdirSync(OUT_DIR, { recursive: true });
  const stamp = Date.now() + '-' + Math.random().toString(36).slice(2, 8);
  const inPath = path.join(OUT_DIR, `in-${stamp}.json`);
  const outPath = path.join(OUT_DIR, `gf2-${stamp}.png`);
  const full = script === HERO_CARD_SCRIPT
    ? payload   // hero_card.py 的 payload 已是完整结构
    : {
        title: payload.title,
        subtitle: payload.subtitle || '',
        sections: payload.sections,
        sources: payload.sources || [],
        stamp: new Date().toLocaleDateString('zh-CN')
      };
  fs.writeFileSync(inPath, JSON.stringify(full, null, 2), 'utf8');
  try {
    await runPy(script, [inPath, outPath], conf().renderTimeoutMs);
  } finally {
    try { fs.rmSync(inPath, { force: true }); } catch { /* ignore */ }
  }
  if (!fs.existsSync(outPath)) throw new Error('渲染脚本没有产出图片');
  pruneOld();
  return outPath;
}

/** 讲解卡片出图（模型自写内容的 card 工具用）。 */
async function renderCard(payload) {
  return runCardScript(RENDER_SCRIPT, payload);
}

/** 出图失败时的文字降级版：把同一份讲解发成文字，群里不干等。 */
function textVersion(p) {
  const lines = [`【${p.title}】`];
  if (p.subtitle) lines.push(p.subtitle);
  for (const s of p.sections) {
    lines.push('', `◆ ${s.heading}`);
    for (const b of s.bullets) lines.push(`· ${b}`);
  }
  if (p.sources && p.sources.length) lines.push('', `来源：${p.sources.join(' / ')}`);
  lines.push('', '内容整理自 B 站攻略，以游戏内当前版本为准');
  return lines.join('\n');
}

// ── 生命周期 ─────────────────────────────────────────────────────────

function doSetup(api) {
  if (_registered) return;
  _registered = true;
  _api = api;
  cfgOf = () => (api && typeof api.config === 'function' ? (api.config() || {}) : {});
  log = (...a) => { try { if (api && typeof api.log === 'function') api.log(...a); } catch { /* 日志失败不影响主流程 */ } };

  if (!api || typeof api.fetch !== 'function') {
    log(`[${SKILL_ID}] ⚠️ api.fetch 不可用 —— 本技能需要联网，请在 skill.json 里保留 permissions: ["web_fetch"]`);
  }

  // ── 工具一：查攻略视频 ──
  api.registerTool({
    id: 'lookup',
    name: '找少前2攻略视频',
    description:
      '从 B 站找少女前线2：追放（少前2 / GF2）的攻略视频，默认优先官方账号'
      + '「少女前线2-追放制作组」（可在设置里改优先UP主名单），其余按相关度和时间排序。'
      + '适用：角色配队/养成/测评、新手开荒、强度榜、当期版本活动关卡攻略、抽卡建议等。'
      + 'keyword 填要查的主题（角色名 / 玩法名 / 版本+活动 / 新手开荒 / 配队 / 强度榜）；'
      + '只想看某个 UP 主的视频时用 up 参数。'
      + '注意：返回的是视频标题、简介和链接——正文在视频里，你看不到画面，不要编造作业细节。'
      + '要读某个视频的详细素材（简介全文+热评），用 gf2-guide__read。',
    category: 'query',
    icon: '🔍',
    parameters: {
      type: 'object',
      properties: {
        keyword: {
          type: 'string',
          description: '要查的主题，例如：威玛西娜、莱娜、新手开荒、配队、强度榜、4.2版本活动攻略'
        },
        up: {
          type: 'string',
          description: '可选。只看某个 UP 主的视频，例如：少女前线2-追放制作组。'
        }
      }
    },
    async execute(ctx, args) {
      try {
        return await lookup(args);
      } catch (e) {
        const msg = (e && e.message) || String(e);
        log(`[${SKILL_ID}] 查询失败：${msg}`);
        return {
          content: `找少前2攻略视频失败：${msg}。可以稍后再试，或直接用 web_search 查图文攻略。`,
          isError: true
        };
      }
    }
  });

  // ── 工具二：读视频正文素材 ──
  api.registerTool({
    id: 'read',
    name: '读少前2攻略视频的素材',
    description:
      '给一个 B 站视频链接或 BV 号，取回它的完整简介、分P列表和点赞最高的热门评论。'
      + '攻略视频的热评里常有「省流」文字总结，是写配装讲解的关键素材。'
      + '在 lookup 之后挑中最相关的 1 个视频时调用本工具；'
      + '拿到素材后先自己综合，再写讲解 / 调 gf2-guide__card 出图。'
      + '注意：返回的是素材不是结论，只能用这些内容 + 常识作答，不要编造里面没有的数值。',
    category: 'query',
    icon: '📖',
    parameters: {
      type: 'object',
      properties: {
        url: {
          type: 'string',
          description: 'B 站视频链接或 BV 号，例如 https://www.bilibili.com/video/BV1Shpk6hEdX。BV 号从 gf2-guide__lookup 的返回里拿'
        }
      },
      required: ['url']
    },
    async execute(ctx, args) {
      try {
        return await readVideo(args);
      } catch (e) {
        const msg = (e && e.message) || String(e);
        log(`[${SKILL_ID}] 读素材失败：${msg}`);
        return {
          content: `读取攻略视频素材失败：${msg}。可以换一个视频试，或直接用 web_search / web_fetch 查图文攻略。`,
          isError: true
        };
      }
    }
  });

  // ── 工具三：查官方 WIKI 角色资料 ──
  api.registerTool({
    id: 'wiki',
    name: '查少前2官方WIKI角色资料',
    description:
      '查《少女前线2：追放》官方 WIKI（gf2-bbs.exiliumgf.com）的角色资料：职业/稀有度/'
      + '异位属性/武器/小队/角色简介/技能/固键共键/显像形态。官方 WIKI 收录 68 个角色，'
      + '数据最全（伊格蕾塔、威玛西娜这些在 B 站 WIKI 上都没页面），'
      + '**角色数据一律以它为准**。'
      + '问角色数据、技能机制、配装/养成素材时先用本工具；'
      + 'name 填角色名（如 伊格蕾塔、威玛西娜、针、莱娜）。'
      + '查不到时它会返回 WIKI 全部角色名，换正确译名重试即可。'
      + '注意：本工具只查官方 WIKI，不要去猜 WIKI 网页 URL（猜了就是 404）。',
    category: 'query',
    icon: '📚',
    parameters: {
      type: 'object',
      properties: {
        name: {
          type: 'string',
          description: '角色名，例如：伊格蕾塔、威玛西娜、针、莱娜、刘莳'
        }
      },
      required: ['name']
    },
    async execute(ctx, args) {
      try {
        return await wikiLookup(args);
      } catch (e) {
        const msg = (e && e.message) || String(e);
        log(`[${SKILL_ID}] WIKI 查询失败：${msg}`);
        return {
          content: `查官方 WIKI 失败：${msg}。可以稍后再试，或改用 web_search 查图文攻略。`,
          isError: true
        };
      }
    }
  });

  // ── 工具五：WIKI 角色大卡 ──
  api.registerTool({
    id: 'hero_card',
    name: '生成少前2角色WIKI大卡',
    description:
      '查官方 WIKI 并直接把角色资料渲染成一张大卡发群：**角色立绘** + 职业/稀有度/异位属性/小队'
      + ' + 数值面板（攻击/生命/防御/暴击等）+ 角色简介 + 技能效果 + 固键/共键 + 武器 + 椎体'
      + ' + 显像形态 + 羁绊礼物 + 语音。'
      + '群友问角色/配装/养成/「这人形怎么样」时，用本工具把权威资料一图打包发给群友；'
      + 'name 填角色名（如 伊格蕾塔、威玛西娜、罗蕾莱）。'
      + '之后自己在回复里补配装/养成文字讲解，别逐句复述图片。'
      + '渲染失败会自动降级成文字版，不会什么都不发。',
    category: 'query',
    icon: '🃏',
    parameters: {
      type: 'object',
      properties: {
        name: {
          type: 'string',
          description: '角色名，例如：伊格蕾塔、威玛西娜、罗蕾莱、莱娜'
        }
      },
      required: ['name']
    },
    async execute(ctx, args) {
      const chatKey = String((ctx && ctx.chatKey) || '');
      const sender = ctx && ctx.sender;
      try {
        return await heroCard(args, chatKey, sender);
      } catch (e) {
        const msg = (e && e.message) || String(e);
        log(`[${SKILL_ID}] 角色大卡失败，降级发文字：${msg}`);
        // 降级：尽力用 wiki 的文字版顶上
        try {
          const fallback = await wikiLookup(args);
          if (!fallback.isError && sender && chatKey && typeof sender.sendTextBatch === 'function') {
            await sender.sendTextBatch(chatKey, [String(fallback.content)]);
            return { content: `出图失败（${msg}），已改用文字版角色资料发给群友。` };
          }
          return fallback;
        } catch (e2) {
          return { content: `角色大卡失败：${msg}；降级也失败：${(e2 && e2.message) || e2}`, isError: true };
        }
      }
    }
  });

  // ── 工具四：讲解卡片出图 ──
  api.registerTool({
    id: 'card',
    name: '把配装讲解做成卡片图发群',
    description:
      '把写好的配装/配队讲解渲染成一张卡片图，直接发到当前会话。'
      + '用于「怎么配装/怎么配队/带什么装备/词条怎么选」这类要照着做的问题：'
      + '先 lookup 找视频 → read 拿素材 → 自己综合写讲解 → 调本工具出图，'
      + '文字讲解同时在回复里给群友。'
      + 'sections 每个分节含 heading + bullets，每条 bullet 一两句话，别长篇大论'
      + '（分节最多 8 个、每节最多 6 条，超了会被截断）。'
      + '渲染失败会自动降级成文字版发群，不会什么都不发。',
    category: 'query',
    icon: '🖼️',
    parameters: {
      type: 'object',
      properties: {
        title: {
          type: 'string',
          description: '卡片标题，例如：威玛西娜 · 配装攻略'
        },
        subtitle: {
          type: 'string',
          description: '可选副标题，例如：少前2：追放 · 4.2版本'
        },
        sections: {
          type: 'array',
          description: '分节讲解，1~8 个分节',
          items: {
            type: 'object',
            properties: {
              heading: {
                type: 'string',
                description: '分节标题，例如：角色定位 / 配装推荐 / 词条优先级 / 输出循环 / 注意事项'
              },
              bullets: {
                type: 'array',
                description: '该节的要点，每条一两句话',
                items: { type: 'string' }
              }
            },
            required: ['heading', 'bullets']
          }
        },
        sources: {
          type: 'array',
          description: '可选，来源标注，例如：["BV1Shpk6hEdX · 晓杰425"]',
          items: { type: 'string' }
        }
      },
      required: ['title', 'sections']
    },
    async execute(ctx, args) {
      const chatKey = String((ctx && ctx.chatKey) || '');
      const sender = ctx && ctx.sender;
      const title = String((args && args.title) || '').trim();
      const secs = (Array.isArray(args && args.sections) ? args.sections : [])
        .filter((s) => s && String(s.heading || '').trim()
          && Array.isArray(s.bullets) && s.bullets.some((b) => String(b || '').trim()))
        .map((s) => ({
          heading: String(s.heading).trim(),
          bullets: s.bullets.map((b) => String(b).trim()).filter(Boolean)
        }));

      if (!title || !secs.length) {
        return {
          content: '卡片需要 title（标题）和至少一个有效分节（heading + bullets）。'
            + '例如：title="威玛西娜 · 配装攻略"，sections=[{heading:"配装推荐", bullets:["武器：专武优先"]}]。',
          isError: true
        };
      }

      const payload = {
        title,
        subtitle: String((args && args.subtitle) || '').trim(),
        sections: secs,
        sources: Array.isArray(args && args.sources) ? args.sources.map(String).filter(Boolean) : []
      };

      if (!sender || !chatKey || typeof sender.sendImage !== 'function') {
        return {
          content: '拿不到发送通道（ctx.sender / chatKey），图没发出去。'
            + '可以把下面的讲解用文字发给群友：\n' + textVersion(payload),
          isError: true
        };
      }

      try {
        const file = await renderCard(payload);
        await sender.sendImage(chatKey, { file }, { note: `少前2攻略卡 ${title}` });
        log(`[${SKILL_ID}] 已发攻略卡：${file}（${secs.length} 个分节）`);
        return {
          content: `卡片图已发送（${secs.length} 个分节）。接着在回复里给群友文字讲解和攻略链接，`
            + '并提醒「以游戏内当前版本为准」；不要逐句复述图片内容。'
        };
      } catch (e) {
        const msg = (e && e.message) || String(e);
        log(`[${SKILL_ID}] 出图失败，降级发文字：${msg}`);
        // 降级：同一份讲解用文字发出去，别让群里干等
        try {
          const text = textVersion(payload);
          if (typeof sender.sendTextBatch === 'function') await sender.sendTextBatch(chatKey, [text]);
          else if (typeof sender.sendText === 'function') await sender.sendText(chatKey, text);
          else throw new Error('sender 上没有可用的发文字方法');
          return { content: `出图失败了（${msg}），已改用文字发出讲解。` };
        } catch (e2) {
          return {
            content: `出图失败：${msg}；降级发文字也失败：${(e2 && e2.message) || e2}`,
            isError: true
          };
        }
      }
    }
  });

  // ── 工具四：功能目录 ──
  api.registerTool({
    id: 'menu',
    name: '发送功能目录',
    description:
      '群友 @我 但只说了「少女前线2 / 少前2 / 追放 / GF2」这类**没带具体问题**的话，'
      + '或者问「你能做什么」「有啥功能」「怎么用」时，调这个发一份功能目录给群里。'
      + '本工具会直接把目录原样发出去（保证内容准确完整），你只需要在发完之后补一句很短的招呼，'
      + '不要复述目录内容，也不要去查视频。',
    category: 'query',
    icon: '📋',
    parameters: { type: 'object', properties: {} },
    async execute(ctx) {
      const chatKey = String((ctx && ctx.chatKey) || '');
      const sender = ctx && ctx.sender;
      if (!sender || !chatKey) {
        return { content: '拿不到发送通道，功能目录没发出去。', isError: true };
      }
      const c = conf();
      const text = [
        '🎮 少前2攻略助手 · 功能目录',
        '',
        '【能查】角色配队/养成/测评 · 强度榜 · 活动关卡攻略 · 新手开荒 · 抽卡建议',
        '',
        '【怎么用】',
        '· 「威玛西娜怎么养」→ 我去 B 站找攻略视频',
        '· 「威玛西娜怎么配装」→ 官方 WIKI 角色大卡（立绘+数值+技能+椎体）+ B 站攻略 + 分步讲解',
        '· 「伊格蕾塔技能是什么」→ 查官方 WIKI 角色资料',
        '· 「罗蕾莱这人形怎么样」→ 直接出角色大卡',
        '· 「4.2版本活动怎么打」→ 换成当期版本/活动名就行',
        '· 「少前2强度榜」→ 同上，直接问',
        '· 想要图文攻略 → 我会顺手搜官网和 B 站 WIKI',
        '',
        `【优先来源】${c.ups.join(' · ')}`,
        '',
        '直接问就行，不用记命令 ✨'
      ].join('\n');
      try {
        if (typeof sender.sendTextBatch === 'function') await sender.sendTextBatch(chatKey, [text]);
        else if (typeof sender.sendText === 'function') await sender.sendText(chatKey, text);
        else throw new Error('sender 上没有可用的发文字方法');
        log(`[${SKILL_ID}] 已发功能目录`);
        return { content: '功能目录已发送。你只需再补一句很短的话（例如"有啥想问的直接说"），不要复述目录内容。' };
      } catch (e) {
        return { content: `发功能目录失败：${(e && e.message) || e}`, isError: true };
      }
    }
  });

  log(`[${SKILL_ID}] 已就绪（工具：lookup / read / wiki / hero_card / card / menu，数据源：B站视频+官方WIKI，出图：render.py + hero_card.py）`);
}

export function setup(api) { doSetup(api); }
export function register(api) { doSetup(api); }
export function available() { return { ok: true }; }
export function dispose() {
  _registered = false;
  _api = null;
  _cache.clear();
  _buvid = { v: '', at: 0 };
  _wbi = { key: '', at: 0 };
  _heroList = { at: 0, items: [] };
  _heroDetail.clear();
}
export const hooks = {};

export const internals = { cleanTitle, cleanDesc, buildQuery, isRelevant, lookup, readVideo, parseBvid, textVersion, GF2_HINT, wikiLookup, findHero, stripHtml, clipFlat, heroCard, buildHeroPayload, parseStats, parseZhui };
