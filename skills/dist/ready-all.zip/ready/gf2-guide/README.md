# gf2-guide · 少前2攻略助手（QQ Agent 扩展）v1.3.0

少女前线2：追放（少前2 / GF2）攻略查询技能。

## 安装
在 QQ Agent 里导入本 zip，会解压安装到 `skills/gf2-guide/`。
若该目录已存在（技能已装过），安装器会自动改名成 `gf2-guide_1`，
想覆盖的话先删掉旧目录再导入。

## 功能（6 个工具）
- `gf2-guide__hero_card`：官方 WIKI 角色大卡（1440 宽屏双栏）——立绘+数值面板（60级）+
  简介+技能+固键共键+武器+椎体全档+显像形态表格+羁绊+语音全量
- `gf2-guide__wiki`：查官方 WIKI 角色资料（68 个角色，文字版）
- `gf2-guide__lookup`：从 B 站找少前2攻略视频（综合序+最新序合并，
  按相关度和播放量排序，官方账号优先）
- `gf2-guide__read`：读视频完整简介 + 分P + 热门评论（省流总结常在热评）
- `gf2-guide__card`：把模型自写的配装讲解渲染成卡片图发群
- `gf2-guide__menu`：被 @ 但只提「少前2」时发功能目录

## 依赖
- `permissions: ["web_fetch"]`（B 站/WIKI 接口，已声明）
- 出图需要本机 Python + Pillow（Windows 自带 Python 一般有；
  没有就在设置里填 pythonPath）
