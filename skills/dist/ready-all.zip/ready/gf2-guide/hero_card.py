# -*- coding: utf-8 -*-
"""
把官方 WIKI 角色资料渲染成一张角色大卡 PNG（gf2-guide 配套 hero_card 工具用）。

用法：
    python hero_card.py <input.json> <output.png>

输入 JSON 结构（由 index.js 从 WIKI API 整理好传进来，本脚本只负责排版）：
{
  "mode": "hero",
  "name": "罗蕾莱",
  "portrait_url": "https://...png",          # 立绘（下载失败就退化为无图头部）
  "tags": ["支援", "精英人形", "燃烧", "国安局"],
  "info_lines": ["武器：因戈尔夫50（SSD-62D · 狙击枪）", "配音：…"],
  "desc": "角色简介…",
  "stats": [{"label": "攻击", "value": "784"}, ...],
  "skills": [{"name": "普攻·…", "desc": "…"}],
  "talents": [{"name": "固键1", "desc": "…"}],
  "weapon": "…",
  "zhui": [{"tier": "椎体·一", "skill": "痛楚恩典 Lv.2", "effect": "…", "extra": "…"}],
  "remould": [{"form": "胚胎", "level": "0", "factor": "尖兵*4火力*2", "effect": "…"}],
  "gifts": [{"name": "+75%好感度", "desc": "…"}],
  "voices": [{"title": "日常-01", "speech": "…"}],
  "voices_battle": [{"title": "语气-01", "speech": "…"}],
  "link": "https://gf2-bbs.exiliumgf.com/wiki/doll?id=1069"
}

布局（v3 宽屏双栏 + 表格分区 + 语音填充）：
  · 总宽 1440。头部：立绘 + 名字/标签/信息；数值面板通栏；
    正文左右双栏——右栏：固键/武器/椎体/显像形态（四列表格）；
    左栏：简介/技能/羁绊 + **语音填充**（日常语音+战斗语音依次填入，
    直到左栏与右栏齐平，把空白填满，至少 6 条）。
  · 两趟：先量后画；换行按像素宽度；字体探测+内置位图字体兜底。
  · 只依赖 Pillow；立绘用 urllib 现下载（失败不影响出图）。
"""
import sys
import os
import io
import json
import urllib.request

try:
    from PIL import Image, ImageDraw, ImageFont
except Exception as exc:
    sys.stderr.write("Pillow 不可用: %s\n" % exc)
    sys.exit(2)

# ── 视觉常量 ──────────────────────────────────────────────────────────
W = 1440
PAD = 30
COL_GAP = 28
SEC_GAP = 18
COL_W = (W - PAD * 2 - COL_GAP) // 2      # 单栏宽 ≈ 676
HEADER_PAD = 20
PORTRAIT_BOX = 330          # 立绘区宽度

BG = (18, 22, 33)
PANEL = (27, 33, 48)
PANEL_2 = (31, 38, 55)
LINE = (48, 56, 78)
TEXT = (238, 242, 252)
TEXT_DIM = (150, 160, 185)
TEXT_FAINT = (110, 120, 145)
ACCENT = (92, 225, 198)     # 青色（少前2）
GOLD = (255, 198, 92)
ORANGE = (242, 145, 60)     # 表头（WIKI 表头就是橙的）
LINK = (110, 175, 255)

MAX_DESC = 200
MAX_SKILLS = 5
MAX_SKILL_DESC = 120
MAX_TALENTS = 9
MAX_TALENT_DESC = 70
MAX_WEAPON = 240
MAX_ZHUI = 12              # 椎体全档位（重要数据，不截断）
MAX_ZHUI_DESC = 90
MAX_GIFTS = 3
MAX_GIFT_DESC = 70
MAX_VOICE_DESC = 80        # 语音紧凑行式，单条上限
MAX_TOTAL_H = 3400

# 显像表格列宽（形态/等级/因子固定，效果吃剩余）
RM_COLS = (96, 64, 216)

# 语音紧凑行式：标题列宽 + 台词列
VOICE_TITLE_W = 92

UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36")

FONT_CANDIDATES = [
    ("C:/Windows/Fonts/msyh.ttc", "C:/Windows/Fonts/msyhbd.ttc"),
    ("C:/Windows/Fonts/msyh.ttf", "C:/Windows/Fonts/msyhbd.ttf"),
    ("C:/Windows/Fonts/NotoSansSC-VF.ttf", "C:/Windows/Fonts/NotoSansSC-VF.ttf"),
    ("C:/Windows/Fonts/simhei.ttf", "C:/Windows/Fonts/simhei.ttf"),
    ("C:/Windows/Fonts/Deng.ttf", "C:/Windows/Fonts/Dengb.ttf"),
]

_font_cache = {}


def pick_font_files():
    for reg, bold in FONT_CANDIDATES:
        if os.path.exists(reg):
            return reg, (bold if os.path.exists(bold) else reg)
    return None, None


REG_PATH, BOLD_PATH = pick_font_files()


def font(size, bold=False):
    key = (size, bold)
    if key in _font_cache:
        return _font_cache[key]
    path = BOLD_PATH if bold else REG_PATH
    f = None
    if path:
        try:
            f = ImageFont.truetype(path, size)
        except Exception:
            f = None
    if f is None:
        try:
            f = ImageFont.load_default()
        except Exception:
            f = None
    _font_cache[key] = f
    return f


def wrap(draw, text, fnt, max_w, max_lines=None):
    text = str(text or "").replace("\r", "")
    lines = []
    cur = ""
    for ch in text:
        if ch == "\n":
            lines.append(cur)
            cur = ""
            continue
        if draw.textlength(cur + ch, font=fnt) <= max_w:
            cur += ch
        else:
            lines.append(cur)
            cur = ch
    if cur:
        lines.append(cur)
    if max_lines and len(lines) > max_lines:
        lines = lines[:max_lines]
        last = lines[-1]
        while last and draw.textlength(last + "…", font=fnt) > max_w:
            last = last[:-1]
        lines[-1] = last + "…"
    return lines or [""]


def clip(s, n):
    t = str(s or "").strip()
    return t[:n] + "…" if len(t) > n else t


def download_portrait(url, box_w):
    """下载立绘并按盒缩放。失败返回 None（头部退化为纯文字）。"""
    if not url:
        return None
    try:
        req = urllib.request.Request(url, headers={"User-Agent": UA,
                                                   "Referer": "https://gf2-bbs.exiliumgf.com/"})
        with urllib.request.urlopen(req, timeout=15) as r:
            raw = r.read()
        if len(raw) > 12 * 1024 * 1024:
            return None
        img = Image.open(io.BytesIO(raw)).convert("RGB")
        w, h = img.size
        scale = min(box_w / w, box_w / h, 1.0)
        if scale < 1.0:
            img = img.resize((max(1, int(w * scale)), max(1, int(h * scale))), Image.LANCZOS)
        return img
    except Exception as e:
        sys.stderr.write("立绘下载失败（继续出图）：%s\n" % e)
        return None


# ── 分区测量（全部带 width 参数，双栏复用）────────────────────────────

def measure_items(draw, items, width, max_desc, name_size=18, desc_size=16):
    f_name = font(name_size, bold=True)
    f_desc = font(desc_size)
    h = 0
    for it in items:
        h += name_size + 8
        d = clip(it.get("desc"), max_desc)
        if d:
            h += len(wrap(draw, d, f_desc, width, 3)) * (desc_size + 7)
        h += 8
    return h


def measure_zhui(draw, zhui, width):
    f_desc = font(16)
    h = 0
    for z in zhui:
        h += 28
        for key in ("effect", "extra"):
            d = clip(z.get(key), MAX_ZHUI_DESC)
            if d:
                h += 20 + len(wrap(draw, d, f_desc, width, 2)) * 23
        h += 10
    return h


def measure_para(draw, text, width, size=17):
    f = font(size)
    return len(wrap(draw, text, f, width)) * (size + 8)


def measure_remould(draw, rows, width):
    """显像四列表：行高取「因子/效果」折行数的最大值。"""
    f_form = font(17, bold=True)
    f_cell = font(15)
    f_effect = font(15)
    eff_w = width - sum(RM_COLS)
    h = 34  # 表头
    for r in rows:
        lines = max(
            len(wrap(draw, clip(r.get("factor"), 40), f_cell, RM_COLS[2] - 12, 2)),
            len(wrap(draw, clip(r.get("effect"), 90), f_effect, eff_w - 12, 2)),
            1,
        )
        h += lines * 22 + 10
    return h


# ── 分区绘制（全部带 x / width 参数）─────────────────────────────────

def draw_section_head(d, x, y, width, title):
    d.rounded_rectangle([x, y + 6, x + 4, y + 6 + 22], radius=2, fill=ACCENT)
    d.text((x + 14, y + 4), title, font=font(20, bold=True), fill=TEXT)
    return y + 38


def draw_stats(d, x, y, width, stats, compact=True):
    """数值 chips。compact=头部用小号（label 14 + value 20 堆叠）；通栏用大号。"""
    f_label = font(14 if compact else 15)
    f_value = font(20 if compact else 21, bold=True)
    per_row = 3
    gap = 10 if compact else 12
    chip_h = 50 if compact else 48
    chip_w = (width - (per_row - 1) * gap) / per_row
    for i, st in enumerate(stats):
        r, c = divmod(i, per_row)
        cx = x + c * (chip_w + gap)
        yy = y + r * (chip_h + gap)
        d.rounded_rectangle([cx, yy, cx + chip_w, yy + chip_h], radius=8,
                            fill=PANEL_2, outline=LINE, width=1)
        d.text((cx + 12, yy + 5), str(st.get("label") or ""), font=f_label, fill=TEXT_DIM)
        d.text((cx + 12, yy + 22), str(st.get("value") or ""), font=f_value, fill=TEXT)
    rows = (len(stats) + per_row - 1) // per_row
    return y + rows * chip_h + (rows - 1) * gap + 8


def draw_items(d, x, y, width, items, max_desc, name_size=18, desc_size=16):
    f_name = font(name_size, bold=True)
    f_desc = font(desc_size)
    for it in items:
        name = str(it.get("name") or "").strip()
        if name:
            d.text((x, y), name, font=f_name, fill=TEXT)
            y += name_size + 8
        desc = clip(it.get("desc"), max_desc)
        if desc:
            for ln in wrap(d, desc, f_desc, width, 3):
                d.text((x, y), ln, font=f_desc, fill=TEXT_DIM)
                y += desc_size + 7
        y += 8
    return y


def draw_zhui(d, x, y, width, zhui):
    f_tier = font(15, bold=True)
    f_name = font(18, bold=True)
    f_desc = font(16)
    for z in zhui:
        tier = str(z.get("tier") or "")
        skill = str(z.get("skill") or "")
        if tier:
            bw = d.textlength(tier, font=f_tier) + 16
            d.rounded_rectangle([x, y + 1, x + bw, y + 25], radius=8, fill=(58, 48, 24))
            d.text((x + 8, y + 3), tier, font=f_tier, fill=GOLD)
            d.text((x + bw + 10, y), skill, font=f_name, fill=TEXT)
        else:
            d.text((x, y), skill, font=f_name, fill=TEXT)
        y += 28
        for key, label in (("effect", "椎体效果"), ("extra", "追加效果")):
            txt = clip(z.get(key), MAX_ZHUI_DESC)
            if txt:
                d.text((x, y), label, font=font(14, bold=True), fill=ACCENT)
                y += 20
                for ln in wrap(d, txt, f_desc, width, 2):
                    d.text((x, y), ln, font=f_desc, fill=TEXT_DIM)
                    y += 23
        y += 10
    return y


def draw_remould(d, x, y, width, rows):
    """显像四列表（照 WIKI 的列式排法）：形态 | 解锁等级 | 显像因子 | 效果。"""
    f_head = font(15, bold=True)
    f_form = font(17, bold=True)
    f_cell = font(15)
    eff_w = width - sum(RM_COLS)
    # 表头
    d.rectangle([x, y, x + width, y + 30], fill=PANEL_2)
    hx = x + 10
    for title, cw in zip(("显像形态", "解锁等级", "显像因子", "效果"), RM_COLS + (eff_w,)):
        d.text((hx, y + 6), title, font=f_head, fill=ORANGE)
        hx += cw
    y += 30
    # 数据行（斑马纹）
    for i, r in enumerate(rows):
        lines = max(
            len(wrap(d, clip(r.get("factor"), 40), f_cell, RM_COLS[2] - 12, 2)),
            len(wrap(d, clip(r.get("effect"), 90), f_cell, eff_w - 12, 2)),
            1,
        )
        rh = lines * 22 + 10
        if i % 2 == 0:
            d.rectangle([x, y, x + width, y + rh], fill=(24, 29, 43))
        d.text((x + 10, y + 5), str(r.get("form") or ""), font=f_form, fill=TEXT)
        d.text((x + RM_COLS[0] + 10, y + 5), str(r.get("level") or ""), font=f_cell, fill=TEXT_DIM)
        fx = x + RM_COLS[0] + RM_COLS[1] + 10
        for j, ln in enumerate(wrap(d, clip(r.get("factor"), 40), f_cell, RM_COLS[2] - 12, 2)):
            d.text((fx, y + 5 + j * 22), ln, font=f_cell, fill=TEXT_DIM)
        ex = x + sum(RM_COLS) + 10
        for j, ln in enumerate(wrap(d, clip(r.get("effect"), 90), f_cell, eff_w - 12, 2)):
            d.text((ex, y + 5 + j * 22), ln, font=f_cell, fill=TEXT)
        y += rh
    return y


def draw_para(d, x, y, width, text, size=17):
    f = font(size)
    for ln in wrap(d, text, f, width):
        d.text((x, y), ln, font=f, fill=TEXT_DIM)
        y += size + 8
    return y


# ── 语音（紧凑行式：标题一列、台词一列，全部展示不按栏高截断）─────────

def measure_voices_inline(draw, items, width):
    f_speech = font(15)
    h = 0
    for v in items:
        speech = clip(v.get("speech"), MAX_VOICE_DESC)
        lines = wrap(draw, speech, f_speech, width - VOICE_TITLE_W, 2) if speech else [""]
        h += max(len(lines), 1) * 21 + 6
    return h


def draw_voices_inline(d, x, y, width, items):
    f_title = font(15, bold=True)
    f_speech = font(15)
    for v in items:
        d.text((x, y), str(v.get("title") or ""), font=f_title, fill=TEXT)
        speech = clip(v.get("speech"), MAX_VOICE_DESC)
        lines = wrap(d, speech, f_speech, width - VOICE_TITLE_W, 2) if speech else [""]
        for j, ln in enumerate(lines):
            d.text((x + VOICE_TITLE_W, y + j * 21), ln, font=f_speech, fill=TEXT_DIM)
        y += max(len(lines), 1) * 21 + 6
    return y


# ── 主渲染 ───────────────────────────────────────────────────────────

def render(data, out_path):
    name = str(data.get("name") or "未知角色")
    tags = [str(t) for t in (data.get("tags") or []) if str(t).strip()]
    info_lines = [str(t) for t in (data.get("info_lines") or []) if str(t).strip()]
    desc = clip(data.get("desc"), MAX_DESC)
    stats = data.get("stats") or []
    skills = (data.get("skills") or [])[:MAX_SKILLS]
    talents = (data.get("talents") or [])[:MAX_TALENTS]
    weapon = clip(data.get("weapon"), MAX_WEAPON)
    zhui = (data.get("zhui") or [])[:MAX_ZHUI]
    remould = data.get("remould") or []
    gifts = (data.get("gifts") or [])[:MAX_GIFTS]
    voices = data.get("voices") or []
    voices_battle = data.get("voices_battle") or []
    link = str(data.get("link") or "")

    probe = ImageDraw.Draw(Image.new("RGB", (10, 10)))
    portrait = download_portrait(data.get("portrait_url"), PORTRAIT_BOX)

    # 头部：左立绘；右侧 = 名字行（名字+标签）/ 信息行（武器/配音）/ 数值面板（60级）。
    # 数值面板放进头部右侧——WIKI 就是这么排的，顺手把原来通栏那一行省掉。
    f_name = font(40, bold=True)
    f_tag = font(15, bold=True)
    f_info = font(19)
    if portrait:
        tx = PAD + 6 + portrait.width + 32
    else:
        tx = PAD + 16
    rw = W - PAD - tx if portrait else min(W - PAD - tx, 900)
    text_h = 44 + 10 + len(info_lines) * 27
    if stats:
        stat_rows = (len(stats) + 2) // 3
        text_h += 36 + stat_rows * 50 + (stat_rows - 1) * 10
    header_h = max(HEADER_PAD * 2 + text_h, HEADER_PAD * 2 + (portrait.height if portrait else 0) + 8)

    # 右栏高度（与语音无关，先算出来作为填充目标）
    def measure_right():
        h = 0
        if talents:
            h += 38 + measure_items(probe, talents, COL_W, MAX_TALENT_DESC, 17, 15) + SEC_GAP
        if weapon:
            h += 38 + measure_para(probe, weapon, COL_W) + SEC_GAP
        if zhui:
            h += 38 + measure_zhui(probe, zhui, COL_W) + SEC_GAP
        if remould:
            h += 38 + measure_remould(probe, remould, COL_W) + SEC_GAP
        return h

    def measure_left_fixed():
        h = 0
        if desc:
            h += 38 + measure_para(probe, desc, COL_W) + SEC_GAP
        if skills:
            h += 38 + measure_items(probe, skills, COL_W, MAX_SKILL_DESC) + SEC_GAP
        if gifts:
            h += 38 + measure_items(probe, gifts, COL_W, MAX_GIFT_DESC, 16, 14) + SEC_GAP
        return h

    def voice_groups():
        """语音分组：[('语音', items), ('战斗语音', items)]，只留有内容的。"""
        groups = []
        if voices:
            groups.append(("语音", voices))
        if voices_battle:
            groups.append(("战斗语音", voices_battle))
        return groups

    def measure_left_voices():
        h = 0
        for g, items in voice_groups():
            h += 38 + measure_voices_inline(probe, items, COL_W) + SEC_GAP
        return h

    def measure_left():
        return measure_left_fixed() + measure_left_voices()

    # 超长时分轮逐级减量：语音先减半再清零，然后礼物/椎体/固键/显像/技能
    while True:
        body_h = max(measure_left(), measure_right())
        total = header_h + body_h + 60
        if total <= MAX_TOTAL_H:
            break
        if len(voices) > 12:
            voices = voices[:12]
        elif len(voices_battle) > 8:
            voices_battle = voices_battle[:8]
        elif voices:
            voices = []
        elif voices_battle:
            voices_battle = []
        elif len(gifts) > 1:
            gifts = gifts[:1]
        elif len(zhui) > 6:
            zhui = zhui[:6]
        elif len(talents) > 6:
            talents = talents[:6]
        elif len(remould) > 3:
            remould = remould[:3]
        elif len(skills) > 3:
            skills = skills[:3]
        else:
            break

    body_h = max(measure_left(), measure_right())
    total_h = header_h + body_h + 60
    img = Image.new("RGB", (W, max(420, total_h)), BG)
    d = ImageDraw.Draw(img)

    # ── 头部：立绘 + 名字/标签 + 信息 + 数值面板 ──
    d.rectangle([0, 0, W, header_h], fill=PANEL)
    d.rectangle([0, header_h - 3, W, header_h], fill=ACCENT)
    px, py = PAD + 6, HEADER_PAD + 6
    if portrait:
        img.paste(portrait, (px, py))
        d.line([px + portrait.width + 16, py + 6, px + portrait.width + 16, py + portrait.height - 6],
               fill=LINE, width=1)
    ty = HEADER_PAD + 12
    d.text((tx, ty), name, font=f_name, fill=TEXT)
    # 标签跟在名字右边，放不下就换行
    cx = tx + d.textlength(name, font=f_name) + 18
    tag_y = ty + 8
    for t in tags:
        tw = d.textlength(t, font=f_tag) + 20
        if cx + tw > tx + rw:
            cx = tx
            tag_y += 34
        d.rounded_rectangle([cx, tag_y, cx + tw, tag_y + 26], radius=13, outline=ACCENT, width=1)
        d.text((cx + 10, tag_y + 4), t, font=f_tag, fill=ACCENT)
        cx += tw + 8
    ty = max(ty + 44 + 10, tag_y + 26 + 12)
    # 信息行（武器/配音）——放大到 19px，不再是小字
    for ln in info_lines:
        d.text((tx, ty), ln, font=f_info, fill=TEXT_DIM)
        ty += 27
    # 数值面板（60级）——头部右侧，填满原来的空白
    if stats:
        ty += 8
        d.rounded_rectangle([tx, ty + 4, tx + 4, ty + 4 + 18], radius=2, fill=ACCENT)
        d.text((tx + 12, ty + 2), "数值面板（60级）", font=font(18, bold=True), fill=TEXT)
        ty += 30
        draw_stats(d, tx, ty, rw, stats, compact=True)

    y = header_h + SEC_GAP

    # ── 双栏正文 ──
    top = y
    lx, rx = PAD, PAD + COL_W + COL_GAP
    ly = top
    if desc:
        ly = draw_section_head(d, lx, ly, COL_W, "角色简介")
        ly = draw_para(d, lx, ly, COL_W, desc) + SEC_GAP
    if skills:
        ly = draw_section_head(d, lx, ly, COL_W, "技能（%d）" % len(skills))
        ly = draw_items(d, lx, ly, COL_W, skills, MAX_SKILL_DESC) + SEC_GAP
    if gifts:
        ly = draw_section_head(d, lx, ly, COL_W, "羁绊礼物")
        ly = draw_items(d, lx, ly, COL_W, gifts, MAX_GIFT_DESC, 16, 14) + SEC_GAP
    # 语音（紧凑行式，按 group 分段绘制，标题带数量）
    for g, items in voice_groups():
        ly = draw_section_head(d, lx, ly, COL_W, "%s（%d）" % (g, len(items)))
        ly = draw_voices_inline(d, lx, ly, COL_W, items) + SEC_GAP

    ry = top
    if talents:
        ry = draw_section_head(d, rx, ry, COL_W, "固键 / 共键（%d）" % len(talents))
        ry = draw_items(d, rx, ry, COL_W, talents, MAX_TALENT_DESC, 17, 15) + SEC_GAP
    if weapon:
        ry = draw_section_head(d, rx, ry, COL_W, "武器")
        ry = draw_para(d, rx, ry, COL_W, weapon) + SEC_GAP
    if zhui:
        ry = draw_section_head(d, rx, ry, COL_W, "椎体（%d）" % len(zhui))
        ry = draw_zhui(d, rx, ry, COL_W, zhui) + SEC_GAP
    if remould:
        ry = draw_section_head(d, rx, ry, COL_W, "显像形态（%d）" % len(remould))
        ry = draw_remould(d, rx, ry, COL_W, remould) + SEC_GAP

    # ── 页脚 ──
    fy = img.height - 54
    d.line([PAD, fy, W - PAD, fy], fill=LINE, width=1)
    d.text((PAD, fy + 12), "来源：少女前线2：追放 官方 WIKI", font=font(14), fill=TEXT_FAINT)
    if link:
        d.text((PAD, fy + 30), link, font=font(14), fill=LINK)
    # 注意：不画「内容过长已截断」这类提示——分区标题自带数量，足够说明包含范围。

    os.makedirs(os.path.dirname(os.path.abspath(out_path)), exist_ok=True)
    img.save(out_path, "PNG", optimize=True)
    return out_path


def main():
    if len(sys.argv) < 3:
        sys.stderr.write("用法: hero_card.py <input.json> <output.png>\n")
        return 2
    with open(sys.argv[1], "r", encoding="utf-8-sig") as fh:
        data = json.load(fh)
    try:
        result = render(data, sys.argv[2])
    except Exception as exc:
        sys.stderr.write("渲染失败: %s\n" % exc)
        return 3
    if not result:
        sys.stderr.write("渲染未产出\n")
        return 3
    sys.stdout.write(result)
    return 0


if __name__ == "__main__":
    sys.exit(main())
