// 代为打招呼（greet-relay）—— 受人所托，去跟另一个人打招呼 / 带句话。
//
// 为什么放 skills/（LLM 型）而不是 plugins/（确定性型）：
//   「给阿珍打个招呼」里没有一条能写死的规则 —— 要先听懂人话、按称呼认人、
//   再把话组织成一句像人说的问候。这些是语义动作，只能交给模型判断；
//   本文件只做「认人 + 发送 + 限流」这类确定性部分，注册成工具由模型调用。
//   （反过来，如果是「关键词命中就必须执行」，才该做成 plugins/ 里的钩子。）
//
// 认人顺序：明确 QQ 号 → 好友（备注 / 昵称）→ 当前群成员（群名片 / 昵称）
//          → 最近私聊过的人。重名不猜：把人选列回去让模型问清楚。
//
// 发送遵守项目现有的安全边界：
//   · 私聊属于「跨会话发送」，必须 config.tools.crossChatSend === true，
//     且目标在私聊白名单里 —— 与内置 send_to 同一套规则，不另开旁路；
//   · 群里 @ 只在当前群、且对方确实是群成员时可用；
//   · 同一个人默认 10 分钟内只能打一次招呼、24 小时最多 3 次，防止被使唤着刷屏。
//
// 状态文件：data/greet-relay/state.json（只存发送时间戳，用来限流）

import fs from 'node:fs';
import path from 'node:path';
import { DATA_DIR, getConfig } from '../../src/config.js';

const STATE_FILE = path.join(DATA_DIR, 'greet-relay', 'state.json');
const CACHE_TTL = 3 * 60 * 1000;      // 好友 / 群成员列表缓存 3 分钟
const MAX_TEXT = 200;                  // 一条招呼最多 200 字（够说一句话，又不至于变成小作文）
const DAY = 24 * 60 * 60 * 1000;

let api = null;
const log = (...args) => {
  try { api?.log?.(...args); } catch { /* 日志失败不影响发送 */ }
};

// ─────────────────────────────── 设置 ───────────────────────────────

function num(value, fallback, lo, hi) {
  const n = Number(value);
  if (!Number.isFinite(n)) return fallback;
  return Math.min(hi, Math.max(lo, Math.round(n)));
}

function settings() {
  let raw = {};
  try { raw = api?.config?.() || {}; } catch { raw = {}; }
  return {
    onlyOwner: raw.onlyOwner === true,
    defaultGreeting: String(raw.defaultGreeting ?? '').trim() || '嗨，{name}～',
    cooldownMinutes: num(raw.cooldownMinutes, 10, 0, 1440),
    maxPerDay: num(raw.maxPerDay, 3, 1, 50)
  };
}

// ─────────────────────────────── 谁在下指令 ───────────────────────────────

/** 主人名单：优先问 owner-identity 模块；它没开或没配时直接读它的配置兜底。 */
function configuredOwnerIds() {
  try {
    const raw = getConfig().skills?.['owner-identity']?.ids;
    const list = Array.isArray(raw) ? raw : String(raw ?? '').split(/[,，;；\s]+/);
    return list.map((x) => String(x).trim()).filter((x) => /^\d{5,15}$/.test(x));
  } catch { return []; }
}

function isOwner(ctx, userId) {
  const id = String(userId ?? '').trim();
  if (!id) return false;
  try {
    const r = api?.capability?.('message.owner-check', { userId: id });
    if (r && typeof r.isOwner === 'boolean') return r.isOwner;
  } catch { /* 能力调用失败就走配置兜底 */ }
  return configuredOwnerIds().includes(id);
}

/**
 * 这条指令是谁发的。
 * 优先用本轮的触发消息（session.trigger，来自 OneBot 的 sender.user_id，不是聊天正文）；
 * 私聊场景下兜底用会话对面的 QQ 号。
 */
function requesterId(ctx) {
  const trigger = Array.isArray(ctx?.session?.trigger) ? ctx.session.trigger : [];
  for (let i = trigger.length - 1; i >= 0; i -= 1) {
    const id = String(trigger[i]?.senderId ?? '');
    if (id && id !== 'self') return id;
  }
  const chatId = String(ctx?.chatId ?? '');
  if (ctx?.kind === 'private' && /^\d{5,15}$/.test(chatId)) return chatId;
  return '';
}

// ─────────────────────────────── 认人 ───────────────────────────────

const PUNCT = /[\s@＠「」『』"'“”‘’()（）[\]【】<>《》,，。!！?？:：;；~～·|/\\_-]+/g;

/** 归一化名字：全角转半角、去掉空白/标点/@、统一小写。 */
function norm(text) {
  return String(text ?? '').normalize('NFKC').replace(PUNCT, '').toLowerCase();
}

/** 用户直接报了 QQ 号（允许「QQ123456」「qq: 123456」这种写法）。 */
function asQq(text) {
  const t = String(text ?? '').trim().replace(/^(qq|扣扣)[:：\s]*/i, '').trim();
  return /^\d{5,15}$/.test(t) ? t : '';
}

const memberCache = new Map();   // groupId -> { at, list }
let friendCache = { at: 0, list: null };

function withSource(list, source) {
  return (list || []).map((x) => ({ ...x, source }));
}

/** 当前群的成员（群名片 + 昵称）。取不到时退回存档里出现过的人。 */
async function groupMembers(ctx) {
  if (ctx?.kind !== 'group') return [];
  const key = String(ctx.chatId ?? '');
  if (!key) return [];
  const hit = memberCache.get(key);
  if (hit && Date.now() - hit.at < CACHE_TTL) return hit.list;

  let list = [];
  try {
    const data = await ctx.onebot.call('get_group_member_list', { group_id: Number(key) }, 20000);
    if (Array.isArray(data)) {
      list = data
        .map((m) => ({
          userId: String(m?.user_id ?? ''),
          names: [m?.card, m?.nickname].map((x) => String(x ?? '').trim()).filter(Boolean)
        }))
        .filter((x) => x.userId);
    }
  } catch (error) {
    log(`取群成员失败（${key}）：`, error?.message ?? error);
  }
  if (!list.length) {
    try {
      list = ctx.store.activeMembers(ctx.chatKey, 200)
        .map((m) => ({ userId: String(m.userId), names: [String(m.name ?? '').trim()].filter(Boolean) }))
        .filter((x) => x.userId);
    } catch { /* 存档也读不到就返回空 */ }
  }
  // 只缓存成功拿到的列表：协议端偶发失败时不把「空名单」钉住 3 分钟，
  // 否则接下来几分钟所有打招呼都会被误判成「不认识这个人」。
  if (list.length) memberCache.set(key, { at: Date.now(), list });
  return list;
}

/** 好友列表（备注名优先，其次昵称）。 */
async function friendList(ctx) {
  if (friendCache.list && Date.now() - friendCache.at < CACHE_TTL) return friendCache.list;
  let list = [];
  try {
    const data = await ctx.onebot.call('get_friend_list', {}, 20000);
    if (Array.isArray(data)) {
      list = data
        .map((f) => ({
          userId: String(f?.user_id ?? ''),
          names: [f?.remark, f?.nickname].map((x) => String(x ?? '').trim()).filter(Boolean)
        }))
        .filter((x) => x.userId);
    }
  } catch (error) {
    log('取好友列表失败：', error?.message ?? error);
  }
  // 同上：空结果不缓存，下一次调用立刻重试
  friendCache = { at: list.length ? Date.now() : 0, list };
  return list;
}

/** 最近私聊过的人：从存档里读 senderName —— 好友列表被协议端藏起来时的兜底。 */
function recentPrivatePool(ctx) {
  const out = [];
  let keys = [];
  try { keys = ctx?.store?.listChats?.() || []; } catch { keys = []; }
  for (const key of keys) {
    const text = String(key);
    if (!text.startsWith('private:')) continue;
    const userId = text.slice('private:'.length);
    if (!/^\d{5,15}$/.test(userId)) continue;
    let names = [];
    try {
      const recent = ctx.store.recent(text, { limit: 12 }) || [];
      names = recent
        .filter((m) => !m.self && String(m.senderId ?? '') === userId)
        .map((m) => String(m.senderName ?? '').trim())
        .filter(Boolean);
    } catch { names = []; }
    if (names.length) out.push({ userId, names: [...new Set(names)] });
  }
  return out;
}

/** 名字匹配打分：100 精确 / 80 前缀 / 60 包含。 */
function scoreOf(names, q) {
  let best = 0;
  for (const raw of names) {
    const n = norm(raw);
    if (!n) continue;
    if (n === q) return 100;
    // 太短的名字（1 个字）做模糊匹配几乎必然误伤，只允许精确命中
    if (q.length < 2 || n.length < 2) continue;
    if (n.startsWith(q)) best = Math.max(best, 80);
    else if (n.includes(q) || q.includes(n)) best = Math.max(best, 60);
  }
  return best;
}

/** 把多个来源合并成「一个人一条」，同名不同号各自保留。 */
function rankTargets(pool, who) {
  const q = norm(who);
  if (!q) return [];
  const map = new Map();
  for (const item of pool) {
    const userId = String(item?.userId ?? '');
    if (!userId) continue;
    const score = userId === q ? 100 : scoreOf(item.names || [], q);
    if (!score) continue;
    const cur = map.get(userId) || { userId, names: new Set(), sources: new Set(), score: 0 };
    cur.score = Math.max(cur.score, score);
    for (const n of item.names || []) if (n) cur.names.add(n);
    if (item.source) cur.sources.add(item.source);
    map.set(userId, cur);
  }
  return [...map.values()]
    .map((x) => ({ ...x, names: [...x.names], sources: [...x.sources] }))
    .sort((a, b) => b.score - a.score || a.userId.localeCompare(b.userId));
}

async function buildPool(ctx) {
  const pool = [];
  for (const f of withSource(await friendList(ctx), '好友')) pool.push(f);
  for (const m of withSource(await groupMembers(ctx), '群成员')) pool.push(m);
  for (const p of withSource(recentPrivatePool(ctx), '聊过')) pool.push(p);
  return pool;
}

/**
 * 决定「要跟谁说」。
 * @returns {{userId,display,sources}|{candidates:[]}|{error:string}}
 */
async function pickTarget(ctx, who, rawUserId) {
  const explicit = asQq(rawUserId) || asQq(who);
  const pool = await buildPool(ctx);

  if (explicit) {
    const hit = pool.find((p) => p.userId === explicit);
    return {
      userId: explicit,
      display: hit?.names?.[0] || explicit,
      sources: hit ? [hit.source] : []
    };
  }

  const ranked = rankTargets(pool, who);
  if (!ranked.length) {
    const known = pool
      .filter((p) => p.names?.length)
      .slice(0, 8)
      .map((p) => `${p.names[0]}（${p.userId}）`);
    return {
      error: `没找到叫「${who}」的人。`
        + (known.length ? `我认得的人里有：${known.join('、')}。` : '')
        + '可以换个叫法（群名片 / 昵称 / 备注），或者直接把 QQ 号告诉我。'
    };
  }
  // 并列第一 = 真的分不清，宁可不发也别打错招呼
  if (ranked.length > 1 && ranked[0].score === ranked[1].score) {
    return { candidates: ranked.filter((r) => r.score === ranked[0].score).slice(0, 6) };
  }
  return {
    userId: ranked[0].userId,
    display: ranked[0].names[0] || ranked[0].userId,
    sources: ranked[0].sources
  };
}

// ─────────────────────────────── 发送边界 ───────────────────────────────

/** 私聊属于跨会话发送：与内置 send_to 同一套开关 + 白名单。 */
function privateGate(userId) {
  const cfg = getConfig();
  if (cfg?.tools?.crossChatSend !== true) {
    return '私聊发送还没开放（设置 → 工具与技能 → 「允许跨会话发送」）。'
      + '如果只是想在群里当众打招呼，可以改成 where=group。';
  }
  const list = (cfg?.allow?.private || []).map(String);
  const allowed = list.includes(String(userId))
    || (list.length === 0 && cfg?.allowAllWhenEmpty === true);
  if (!allowed) {
    return `${userId} 不在私聊白名单里（设置 → 白名单），私聊发不出去。`
      + '想让 TA 也收到，得先把这个 QQ 号加进白名单。';
  }
  return '';
}

/** 群里 @ 只能 @ 当前群的真实成员。 */
async function groupGate(ctx, userId) {
  if (ctx?.kind !== 'group') {
    return '现在不在群里，没法在群里 @ 对方 —— 可以改成私聊（where=private）。';
  }
  const members = await groupMembers(ctx);
  if (!members.some((m) => m.userId === String(userId))) {
    return '对方不在当前群里，@ 不到 —— 可以改成私聊（where=private）。';
  }
  return '';
}

// ─────────────────────────────── 限流 ───────────────────────────────

function readState() {
  try {
    const raw = JSON.parse(fs.readFileSync(STATE_FILE, 'utf8'));
    if (raw && typeof raw === 'object' && raw.targets && typeof raw.targets === 'object') return raw;
  } catch { /* 首次运行 / 文件坏了都当空 */ }
  return { targets: {} };
}

function writeState(state) {
  fs.mkdirSync(path.dirname(STATE_FILE), { recursive: true });
  const tmp = `${STATE_FILE}.${process.pid}.tmp`;
  fs.writeFileSync(tmp, JSON.stringify(state, null, 1), 'utf8');
  fs.renameSync(tmp, STATE_FILE);
}

function recentHits(userId, now = Date.now()) {
  const state = readState();
  return (Array.isArray(state.targets[userId]) ? state.targets[userId] : [])
    .map(Number)
    .filter((ts) => Number.isFinite(ts) && now - ts < DAY && now - ts >= 0);
}

function checkRate(userId, s) {
  const now = Date.now();
  const hits = recentHits(userId, now);
  if (s.maxPerDay > 0 && hits.length >= s.maxPerDay) {
    return `24 小时内已经跟 TA 打过 ${hits.length} 次招呼了（上限 ${s.maxPerDay} 次），这次先不发。`;
  }
  const last = hits.length ? Math.max(...hits) : 0;
  if (last && s.cooldownMinutes > 0 && now - last < s.cooldownMinutes * 60000) {
    const mins = Math.max(1, Math.round((now - last) / 60000));
    return `${mins} 分钟前刚跟 TA 打过招呼，间隔不到 ${s.cooldownMinutes} 分钟，先别连着发。`;
  }
  return '';
}

function markSent(userId) {
  const now = Date.now();
  const state = readState();
  const hits = recentHits(userId, now);
  hits.push(now);
  state.targets[userId] = hits;
  writeState(state);
}

// ─────────────────────────────── 工具实现 ───────────────────────────────

function ok(text) { return { content: text }; }
function err(text) { return { content: text, isError: true }; }

function composeText(s, message, display) {
  const said = String(message ?? '').replace(/\s+/g, ' ').trim();
  const base = said || s.defaultGreeting.replace(/\{name\}/g, display || '你');
  return base.slice(0, MAX_TEXT);
}

async function deliver(ctx, target, text, where) {
  const chatKey = where === 'private' ? `private:${target.userId}` : String(ctx.chatKey);
  const options = where === 'group' ? { atUserId: target.userId } : {};
  const result = await ctx.sender.sendTextBatch(chatKey, [text], options);
  const sent = (result?.sent || []).filter((x) => !x.deduped);
  if (!sent.length) throw new Error('消息被发送去重窗口拦下了（几秒内发过一样的话），这次没有真的发出去');
  if (Array.isArray(ctx.session?.sent)) {
    ctx.session.sent.push(...sent.map((x) => ({
      type: 'text',
      text: x.text,
      at: x.at,
      ...(where === 'private' ? { to: chatKey } : {})
    })));
  }
  if (typeof ctx.emit === 'function') ctx.emit('session-update', ctx.session?.id);
  return sent;
}

function renderCandidates(who, list, where) {
  const lines = [
    `「${who}」匹配到 ${list.length} 个人，先别猜着发 —— 跟发指令的人确认是哪一个，再用 userId 调一次本工具：`
  ];
  for (const c of list) {
    lines.push(`- ${c.names[0] || c.userId}（${c.userId}）· ${c.sources.join(' / ') || '认识'}`);
  }
  lines.push(`（确认后记得把 where 也带上，当前是 ${where}）`);
  return lines.join('\n');
}

async function toolGreet(ctx, args) {
  const s = settings();
  const who = String(args?.who ?? '').trim();
  const rawUserId = String(args?.userId ?? '').trim();
  if (!who && !rawUserId) {
    return err('who 不能为空：把用户说的那个称呼（群名片 / 昵称 / 备注 / QQ 号）原样传进来。');
  }

  if (s.onlyOwner) {
    const uid = requesterId(ctx);
    if (!isOwner(ctx, uid)) {
      return err('这个功能设置成只接受主人的指令；这条不是主人发的，不要执行。');
    }
  }

  const where = String(args?.where ?? 'private').toLowerCase() === 'group' ? 'group' : 'private';
  const target = await pickTarget(ctx, who, rawUserId);
  if (target.error) return err(target.error);
  if (target.candidates) return ok(renderCandidates(who || rawUserId, target.candidates, where));

  if (target.userId === String(ctx?.selfId ?? '')) {
    return err('那是机器人自己，不用跟自己打招呼。');
  }
  if (target.userId === requesterId(ctx)) {
    return err('对方就是发指令的人本人 —— 有话直接在这边说就行，不用特意跑一趟。');
  }

  const gate = where === 'private' ? privateGate(target.userId) : await groupGate(ctx, target.userId);
  if (gate) return err(gate);

  const limited = checkRate(target.userId, s);
  if (limited) return err(limited);

  const text = composeText(s, args?.message, target.display);
  if (!text) return err('要说的内容是空的 —— 把想带给 TA 的那句话写进 message。');

  const sent = await deliver(ctx, target, text, where);
  markSent(target.userId);

  const head = where === 'private'
    ? `已经私聊把话发给了 ${target.display}（${target.userId}）：「${sent[0]?.text ?? text}」`
    : `已经在当前群里 @ 了 ${target.display}（${target.userId}）并说：「${sent[0]?.text ?? text}」`;
  return ok([
    head,
    where === 'private' ? '这条只有 TA 看得到。' : '群里其他人也看得到。',
    '不要把这句话再复述一遍；回发指令的人一句「发到了」就够了。'
  ].join('\n'));
}

// ─────────────────────────────── 生命周期 ───────────────────────────────

export function setup(injected) {
  api = injected;
  api.registerTool({
    id: 'greet',
    name: '去跟某人打个招呼',
    description:
      '受人所托，去跟另一个人打招呼 / 问声好 / 带句话。'
      + '当有人（通常是主人）说「跟XX打个招呼」「帮我跟XX问声好」「跟XX说一句…」时用它：'
      + '它会按你给的称呼（群名片 / 昵称 / 备注 / QQ 号）自己找到人，把话发过去。'
      + '默认私聊发送；发指令的人明确说「在群里跟他说」时才用 where=group。'
      + '只在有人明确让你去打招呼 / 带话时用，不要主动拿它去骚扰别人；同一个人不要连着打好几次。'
      + '重名时它会返回候选人，让你先问清楚再发。',
    category: 'messaging',
    icon: '👋',
    parameters: {
      type: 'object',
      properties: {
        who: {
          type: 'string',
          description: '发指令的人说的那个称呼，原样传进来（如「阿珍」「群主」「123456」）'
        },
        message: {
          type: 'string',
          description: '要带给对方的那句话：按你的人设自然地说，一句就够（最多 200 字）。不填就用默认问候语。'
        },
        where: {
          type: 'string',
          enum: ['private', 'group'],
          description: '在哪儿说：private = 私聊对方（默认）；group = 在当前群里 @ 对方'
        },
        userId: {
          type: ['string', 'integer'],
          description: '可选：已经确认的 QQ 号。重名时先问清楚，再把对方选中的号码传进来'
        }
      },
      required: ['who']
    },
    async execute(ctx, args) {
      try {
        return await toolGreet(ctx, args);
      } catch (error) {
        return err(`打招呼失败：${error?.message ?? error}`);
      }
    }
  });
  const s = settings();
  log(`代为打招呼已加载｜默认私聊｜限流 ${s.maxPerDay} 次/24h｜主人限定：${s.onlyOwner ? '是' : '否'}`);
}

/** 只依赖文件系统与配置，永远可用（真正能不能发由工具执行时再判）。 */
export function available() { return true; }

export function activate() { /* 无常驻任务 */ }
export function deactivate() { /* 无常驻任务 */ }
export function dispose() {
  memberCache.clear();
  friendCache = { at: 0, list: null };
}

/** 给验证脚本用的内部接口（不给模型）。 */
export const internals = {
  norm, asQq, scoreOf, rankTargets, settings, pickTarget, privateGate, groupGate,
  composeText, checkRate, markSent, readState, STATE_FILE
};
