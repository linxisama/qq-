// B站视频速览 —— LLM 型技能（skills/bili-digest）
// ---------------------------------------------------------------------------
// 为什么要有它：群友丢个 B站 链接过来，原来的做法是让模型 web_fetch 去"打开"网页。
// B站 视频页是 JS 渲染 + 有风控，抓回来的是空壳，模型只能回"打不开"。
//
// 这里按「越接近视频内容越优先」取三档材料，交给模型自己组织语言：
//   ① 字幕原文（AI 字幕，有就是全文）
//   ② B站 官方 AI 总结（view/conclusion，需要 WBI 签名，很多视频有）
//   ③ 弹幕抽样 + 热门评论（没有字幕、也没有官方总结时的兜底）
// 三档都没有、只剩简介时才只剩简介 —— 那种情况会明确告诉模型"依据有限，别装作看过"。
//
// 约束（本项目的硬规矩）：
//   · 只用 api.fetch（宿主给的受保护 fetch）；不 import fs / child_process / net
//   · node:crypto 只用来算 WBI 的 md5 签名（不碰进程/文件）
//   · 不直接发消息 —— 只取数，怎么回由模型按人设决定
// ---------------------------------------------------------------------------

import { createHash } from 'node:crypto'

const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36'
const REFERER = 'https://www.bilibili.com/'
const API = 'https://api.bilibili.com'

const BV_RE = /BV[0-9A-Za-z]{10}/
const URL_RE = /https?:\/\/[^\s"'<>]+/g
const DM_RE = /<d p="([^"]*)">([\s\S]*?)<\/d>/g

// WBI 混淆表（B站 前端固定写死的那张）
const MIXIN_TAB = [46, 47, 18, 2, 53, 8, 23, 32, 15, 50, 10, 31, 58, 3, 45, 35, 27, 43, 5, 49, 33, 9, 42, 19, 29, 28, 14, 39, 12, 38, 41, 13, 37, 48, 7, 16, 24, 55, 40, 61, 26, 17, 0, 1, 60, 51, 30, 4, 22, 25, 54, 21, 56, 59, 6, 63, 57, 62, 11, 36, 20, 34, 44, 52]

let api = null
let cfg = () => ({})
let keyCache = null

const md5 = (s) => createHash('md5').update(s).digest('hex')

function settings() {
  const c = cfg() || {}
  return {
    cookie: String(c.cookie || '').trim(),
    maxChars: Math.max(500, Math.min(Number(c.maxChars) || 5000, 20000)),
    withComments: Math.max(0, Math.min(Number(c.withComments) || 0, 10)),
  }
}

function cookieOf() {
  const s = settings()
  if (s.cookie) return s.cookie
  try {
    return String(api.storage?.get?.('cookie', '') || '').trim()
  } catch {
    return ''
  }
}

function headers(cookie) {
  const h = { 'user-agent': UA, referer: REFERER, accept: 'application/json, text/plain, */*' }
  if (cookie) h.cookie = cookie
  return h
}

async function getJson(url, cookie) {
  const res = await api.fetch(url, { headers: headers(cookie) })
  const text = await res.text()
  let body
  try {
    body = JSON.parse(text)
  } catch {
    throw new Error(`接口返回的不是 JSON（HTTP ${res.status}）：${text.slice(0, 120)}`)
  }
  return { status: res.status, body }
}

/** 从一段文字里找 BV 号；短链（b23.tv）跟一次跳转再找 */
async function resolveBvid(raw, cookie) {
  const direct = BV_RE.exec(raw)
  if (direct) return { bvid: direct[0] }

  const urls = raw.match(URL_RE) || []
  if (!urls.length) return { error: '没找到 BV 号，也没找到链接' }

  let lastErr = ''
  for (const url of urls.slice(0, 2)) {
    try {
      const res = await api.fetch(url, { headers: headers(cookie), redirect: 'follow' })
      const finalUrl = String(res.url || '')
      const m1 = BV_RE.exec(finalUrl)
      if (m1) return { bvid: m1[0] }
      const text = await res.text()
      const m2 = BV_RE.exec(text)
      if (m2) return { bvid: m2[0] }
      lastErr = `短链跟到了 ${finalUrl || '未知地址'}，但里面没有 BV 号（可能是番剧/动态/专栏）`
    } catch (e) {
      lastErr = `${e?.message ?? e}`
    }
  }
  return { error: lastErr || '链接里没有解析出 BV 号' }
}

/* ─────────────── WBI 签名（官方 AI 总结 / 部分接口要它） ─────────────── */

async function mixinKey(cookie) {
  if (keyCache && Date.now() - keyCache.at < 3600_000) return keyCache.key
  const nav = await getJson(`${API}/x/web-interface/nav`, cookie)
  const img = nav.body?.data?.wbi_img?.img_url || ''
  const sub = nav.body?.data?.wbi_img?.sub_url || ''
  const base = (u) => String(u).split('/').pop().split('.')[0]
  const raw = base(img) + base(sub)
  if (raw.length < 64) throw new Error('拿不到 WBI 密钥（没登录？）')
  const key = MIXIN_TAB.map((i) => raw[i] || '').join('').slice(0, 32)
  keyCache = { key, at: Date.now() }
  return key
}

async function signQuery(params, cookie) {
  const mk = await mixinKey(cookie)
  const wts = Math.floor(Date.now() / 1000)
  const all = { ...params, wts }
  const query = Object.keys(all)
    .sort()
    .map((k) => `${encodeURIComponent(k)}=${encodeURIComponent(String(all[k]).replace(/[!'()*]/g, ''))}`)
    .join('&')
  return `${query}&w_rid=${md5(query + mk)}`
}

/* ─────────────── 三档内容来源 ─────────────── */

async function fetchSubtitle(bvid, cid, cookie) {
  const { body } = await getJson(`${API}/x/player/wbi/v2?bvid=${encodeURIComponent(bvid)}&cid=${cid}`, cookie)
  if (body?.code !== 0) return { error: `字幕接口 code=${body?.code}：${body?.message || ''}` }
  const subs = body?.data?.subtitle?.subtitles || []
  if (!subs.length) return { error: 'no-subtitle' }

  const target = subs.find((s) => ['ai-zh', 'zh-CN', 'zh'].includes(s?.lan)) || subs[0]
  let subUrl = String(target?.subtitle_url || '')
  if (subUrl.startsWith('//')) subUrl = 'https:' + subUrl
  if (!subUrl) return { error: '字幕地址是空的' }

  const res = await api.fetch(subUrl, { headers: headers(cookie) })
  const data = await res.json()
  const lines = (data?.body || []).map((x) => String(x?.content || '')).filter(Boolean)
  return {
    lang: target?.lan_doc || target?.lan || '中文',
    segments: lines.length,
    text: lines.join('\n'),
  }
}

/** B站 官方 AI 总结（不是每期都有；有的话是最省 token 的内容概览） */
async function fetchConclusion(bvid, cid, upMid, cookie) {
  try {
    const q = await signQuery({ bvid, cid, up_mid: upMid }, cookie)
    const { body } = await getJson(`${API}/x/web-interface/view/conclusion/get?${q}`, cookie)
    if (body?.code !== 0) return { error: `code=${body?.code}：${body?.message || ''}` }
    const r = body?.data?.model_result || {}
    const summary = String(r.summary || '').trim()
    const outline = (r.outline || [])
      .filter((o) => o?.title)
      .slice(0, 8)
      .map((o) => `- ${o.title}${Array.isArray(o.part_outline) && o.part_outline.length ? `：${o.part_outline.slice(0, 3).join(' / ')}` : ''}`)
    if (!summary && !outline.length) return { error: 'empty' }
    return { summary, outline }
  } catch (e) {
    return { error: `${e?.message ?? e}` }
  }
}

/** 弹幕抽样：按时间排序取前 n 条（原样，不解释） */
async function fetchDanmaku(cid, n, cookie) {
  try {
    const res = await api.fetch(`${API}/x/v1/dm/list.so?oid=${cid}`, { headers: headers(cookie) })
    const xml = await res.text()
    const out = []
    const seen = new Set()
    let m
    DM_RE.lastIndex = 0
    while ((m = DM_RE.exec(xml)) && out.length < n * 3) {
      const text = m[2].replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').trim()
      if (!text || text.length > 40 || seen.has(text)) continue
      seen.add(text)
      const t = Number(String(m[1]).split(',')[0]) || 0
      out.push({ t, text })
    }
    out.sort((a, b) => a.t - b.t)
    return out.slice(0, n)
  } catch {
    return []
  }
}

async function fetchComments(aid, n, cookie) {
  if (!n) return []
  try {
    const { body } = await getJson(`${API}/x/v2/reply?type=1&oid=${aid}&sort=2&ps=${n}&pn=1`, cookie)
    return (body?.data?.replies || []).slice(0, n).map((r) => ({
      user: r?.member?.uname || '',
      text: String(r?.content?.message || '').slice(0, 120),
      like: Number(r?.like) || 0,
    }))
  } catch {
    return []
  }
}

/* ─────────────── 主流程 ─────────────── */

async function digest(raw, s) {
  const cookie = cookieOf()
  const found = await resolveBvid(raw, cookie)
  if (found.error) return { ok: false, error: found.error }
  const bvid = found.bvid

  const view = await getJson(`${API}/x/web-interface/view?bvid=${encodeURIComponent(bvid)}`, cookie)
  if (view.body?.code !== 0) {
    return { ok: false, error: `视频信息取不到（code=${view.body?.code}）：${view.body?.message || '可能被删/仅粉丝可见'}` }
  }
  const info = view.body.data || {}
  const aid = Number(info.aid) || 0
  const cid = Number(info.cid) || Number(info?.pages?.[0]?.cid) || 0
  const upMid = Number(info?.owner?.mid) || 0

  const notes = []

  // ① 字幕
  let subtitle = null
  if (cid) {
    try {
      const sub = await fetchSubtitle(bvid, cid, cookie)
      if (sub.error === 'no-subtitle') notes.push('这个视频没有 AI 字幕')
      else if (sub.error) notes.push(`字幕没取到（${sub.error}）`)
      else subtitle = sub
    } catch (e) {
      notes.push(`字幕没取到（${e?.message ?? e}）`)
    }
  }

  // ② 官方 AI 总结
  let conclusion = null
  if (cid && upMid) {
    const con = await fetchConclusion(bvid, cid, upMid, cookie)
    if (con.summary || con.outline?.length) conclusion = con
    else if (con.error && con.error !== 'empty') notes.push(`官方总结没取到（${con.error}）`)
  }

  // ③ 都没拿到内容 → 弹幕 + 评论兜底
  let danmaku = []
  let comments = []
  if (!subtitle && !conclusion) {
    if (cid) danmaku = await fetchDanmaku(cid, 80, cookie)
    comments = await fetchComments(aid, Math.max(s.withComments, 5), cookie)
  } else if (s.withComments) {
    comments = await fetchComments(aid, s.withComments, cookie)
  }

  let text = subtitle?.text || ''
  const chars = text.length
  let truncated = false
  if (chars > s.maxChars) {
    const head = Math.floor(s.maxChars * 0.72)
    const tail = s.maxChars - head
    text = text.slice(0, head) + '\n……（中间省略）……\n' + text.slice(-tail)
    truncated = true
  }

  const stat = info.stat || {}
  return {
    ok: true,
    data: {
      bvid,
      url: `https://www.bilibili.com/video/${bvid}`,
      title: info.title || '',
      owner: info?.owner?.name || '',
      duration: Number(info.duration) || 0,
      desc: String(info.desc || '').slice(0, 800),
      stat: { view: stat.view, like: stat.like, reply: stat.reply },
      subtitle: subtitle ? { lang: subtitle.lang, segments: subtitle.segments, chars, truncated, text } : null,
      conclusion,
      danmaku,
      comments,
      notes,
      loggedIn: Boolean(cookie),
    },
  }
}

function fmtDuration(sec) {
  const s = Math.max(0, Number(sec) || 0)
  return `${Math.floor(s / 60)}分${String(Math.floor(s % 60)).padStart(2, '0')}秒`
}

function fmtCount(n) {
  const v = Number(n) || 0
  if (v >= 100000000) return `${(v / 100000000).toFixed(1)}亿`
  if (v >= 10000) return `${(v / 10000).toFixed(1)}万`
  return String(v)
}

function render(d) {
  const L = []
  L.push(`《${d.title}》`)
  L.push(`UP：${d.owner || '未知'} ｜ 时长 ${fmtDuration(d.duration)} ｜ 播放 ${fmtCount(d.stat.view)} ｜ 点赞 ${fmtCount(d.stat.like)} ｜ 评论 ${fmtCount(d.stat.reply)}`)
  if (d.desc && d.desc.trim() !== '-') L.push(`简介：${d.desc.replace(/\s+/g, ' ')}`)

  if (d.conclusion) {
    L.push('B站 官方 AI 总结：')
    if (d.conclusion.summary) L.push(d.conclusion.summary)
    for (const o of d.conclusion.outline || []) L.push(o)
  }

  if (d.subtitle) {
    L.push(`字幕（${d.subtitle.lang}，${d.subtitle.segments} 段 / 共 ${d.subtitle.chars} 字${d.subtitle.truncated ? '，已截断' : ''}）：`)
    L.push(d.subtitle.text)
  }

  if (!d.subtitle && !d.conclusion) {
    if (d.danmaku?.length) {
      L.push(`弹幕抽样（${d.danmaku.length} 条，按时间）：`)
      L.push(d.danmaku.map((x) => x.text).join(' / '))
    }
    if (d.comments?.length) {
      L.push('热门评论：')
      for (const c of d.comments) L.push(`- ${c.user}（${c.like} 赞）：${c.text}`)
    }
  } else if (d.comments?.length) {
    L.push('热门评论：')
    for (const c of d.comments) L.push(`- ${c.user}（${c.like} 赞）：${c.text}`)
  }

  if (d.notes?.length) L.push(`备注：${d.notes.join('；')}`)
  L.push(`链接：${d.url}`)
  return L.join('\n')
}

export function setup(a) {
  api = a
  cfg = a.config

  a.registerTool({
    id: 'bili_digest',
    name: '读 B站 视频内容',
    category: 'media',
    icon: '📺',
    description:
      '当群里出现 B站 视频链接（bilibili.com/video/BV…、b23.tv 短链、BV 号）或有人问某个 B站 视频讲了什么时使用。'
      + '参数 url 传原链接或 BV 号。返回：标题/UP/时长/数据 + 字幕原文（有 AI 字幕时）或 B站 官方 AI 总结，'
      + '都没有时给弹幕抽样与热门评论。**依据是哪一档，返回值里写得很清楚** —— '
      + '只有简介和弹幕时，总结要说明"只看到这些"，不要装作看完了整期。',
    parameters: {
      type: 'object',
      properties: {
        url: { type: 'string', description: 'B站 视频链接、b23.tv 短链，或 BV 号（如 BV1gyJ86WECd）' },
      },
      required: ['url'],
    },
    async execute(ctx, args) {
      const raw = String(args?.url ?? '').trim()
      if (!raw) return { content: '没给链接或 BV 号', isError: true }
      try {
        const r = await digest(raw, settings())
        if (!r.ok) return { content: `没读到这个视频：${r.error}`, isError: true }
        return { content: render(r.data) }
      } catch (e) {
        return { content: `读取失败：${e?.message ?? e}`, isError: true }
      }
    },
  })

  a.log?.('[bili-digest] 已注册工具：bili_digest（字幕 → 官方 AI 总结 → 弹幕/评论 三档兜底）')
}
