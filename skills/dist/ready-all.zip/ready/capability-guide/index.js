/**
 * capability-guide —— 「能力清单」技能。
 *
 * 作用：把机器人当前**生效中**的扩展（skills/ 与 plugins/ 下的清单文件）读出来，
 * 整理成按类别排序的清单；被问及某一项时，给出它的作用、可配置项与用法说明。
 *
 * 数据来源两条，都不需要联网、不需要额外权限：
 *   1. 文件系统 —— 扫描 <app>/skills/<id>/{skill.json|plugin.json}
 *                  与 <app>/plugins/<id>/{skill.json|plugin.json}；
 *   2. 运行时状态 —— api.isSkillActive(id, ctx) 判断某一项此刻是否生效。
 * 两者都是**每次执行时现场读取**，所以新装/新停用的扩展会立刻反映到清单里。
 *
 * 为什么不去调控制台的 HTTP 接口：那需要清单里声明 permissions: ["web_fetch"]，
 * 还得自己猜端口（QQ_AGENT_PORT / 3210 + profile 偏移），失败面比读文件大得多。
 *
 * @module capability-guide
 */
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

// 本文件位于 <app>/skills/capability-guide/index.js，据此推出各根目录。
const HERE = path.dirname(fileURLToPath(import.meta.url));
const SKILLS_DIR = path.resolve(HERE, '..');        // <app>/skills
const APP_DIR = path.resolve(SKILLS_DIR, '..');     // <app>
const PLUGINS_DIR = path.join(APP_DIR, 'plugins');  // <app>/plugins

/** 清单文件名，按加载器同样的优先级尝试（先 skill.json，后 plugin.json）。 */
const MANIFEST_FILES = ['skill.json', 'plugin.json'];

/** 类别展示顺序与中文名（类别非法时按 utility 处理，与加载器口径一致）。 */
const CATEGORY_ORDER = ['media', 'message', 'knowledge', 'model', 'utility'];
const CATEGORY_LABEL = {
  media: '媒体',
  message: '消息',
  knowledge: '知识',
  model: '模型',
  utility: '工具'
};
const KIND_LABEL = { skill: '技能', plugin: '插件' };

let cfg = () => ({});
let probeActive = null;

/** 读 JSON 文件：去掉 BOM，任何异常都返回 null（坏清单不该让整个工具失败）。 */
function readJsonFile(file) {
  try {
    let text = fs.readFileSync(file, 'utf8');
    if (text.charCodeAt(0) === 0xfeff) text = text.slice(1);
    const parsed = JSON.parse(text);
    return parsed && typeof parsed === 'object' ? parsed : null;
  } catch {
    return null;
  }
}

/** 取一个扩展目录里的清单（skill.json 优先，回退 plugin.json）。 */
function readManifest(dir) {
  for (const name of MANIFEST_FILES) {
    const got = readJsonFile(path.join(dir, name));
    if (got && got.id) return got;
  }
  return null;
}

/** 扫描一个扩展根目录下的全部一级子目录，收集已安装项。 */
function scan(kind, root) {
  const rows = [];
  let entries = [];
  try {
    entries = fs.readdirSync(root, { withFileTypes: true });
  } catch {
    return rows; // 目录不存在（例如一个插件都没装）→ 空列表，不算错误
  }
  for (const ent of entries) {
    if (!ent.isDirectory()) continue;
    const dir = path.join(root, ent.name);
    const man = readManifest(dir);
    if (!man) continue; // 缺清单或清单坏了：加载器那边会报错，这里静默跳过
    const category = String(man.category || '');
    rows.push({
      kind,
      id: String(man.id),
      name: String(man.name || man.id),
      version: String(man.version || ''),
      category: CATEGORY_ORDER.includes(category) ? category : 'utility',
      description: String(man.description || '（这个扩展没有写说明）'),
      dir,
      capabilities: Array.isArray(man.capabilities) ? man.capabilities.map(String) : [],
      configSchema:
        man.configSchema && typeof man.configSchema === 'object' ? man.configSchema : {}
    });
  }
  return rows;
}

/**
 * 全部已安装的扩展（技能 + 插件）。
 *
 * ⚠️ 每次都现场扫盘、**不做缓存**：一个扩展目录里只有十几个 JSON，
 * 扫描开销极低，换来的是"刚放进 skills/ 或 plugins/ 的新扩展，
 * 下一次提问立刻就能列出来"，不会因为缓存而漏掉新装的东西。
 */
function collect() {
  return [...scan('skill', SKILLS_DIR), ...scan('plugin', PLUGINS_DIR)];
}

/** 问运行时：这一项此刻是否生效。返回 true / false / null（无法判定）。 */
function activeOf(id, ctx) {
  if (typeof probeActive !== 'function') return null;
  try {
    return probeActive(id, ctx) === true;
  } catch {
    return null;
  }
}

/** 状态文案；null 表示查询不到（控制台里仍能看到真实状态）。 */
function statusText(active) {
  if (active === true) return '✅ 生效中';
  if (active === false) return '⏸ 已停用';
  return '• 状态未知';
}

/** 压成单行并截断：清单是总览，个别扩展的说明可能上千字，不能让它淹没整张表。 */
function clipText(text, max) {
  const flat = String(text || '')
    .replace(/\s*\n+\s*/g, ' ')
    .trim();
  if (!max || flat.length <= max) return flat;
  return `${flat.slice(0, max)}…`;
}

/** 排序：按名称，或按"类别顺序 + 名称"。 */
function sortRows(rows, mode) {
  const byName = (a, b) => a.name.localeCompare(b.name, 'zh');
  if (mode === 'name') return [...rows].sort(byName);
  const rank = (row) => {
    const i = CATEGORY_ORDER.indexOf(row.category);
    return i < 0 ? CATEGORY_ORDER.length : i;
  };
  return [...rows].sort((a, b) => rank(a) - rank(b) || byName(a, b));
}

/** 把清单排版成给模型看的文本。 */
function formatList(rows, opts) {
  const includePlugins = opts.includePlugins !== false;
  const onlyActive = opts.onlyActive === true;
  const sortMode = opts.sortMode === 'name' ? 'name' : 'category';
  const descChars = Math.max(20, Math.min(500, Number(opts.descChars) || 100));

  let base = includePlugins ? rows : rows.filter((row) => row.kind === 'skill');
  base = sortRows(base, sortMode);
  const hidden = onlyActive ? base.filter((row) => row.active === false) : [];
  const list = onlyActive ? base.filter((row) => row.active !== false) : base;

  if (!list.length) {
    return includePlugins
      ? '现在还没有装任何技能或插件。'
      : '现在还没有装任何技能。';
  }

  const skillCount = list.filter((row) => row.kind === 'skill').length;
  const pluginCount = list.filter((row) => row.kind === 'plugin').length;
  const lines = [];
  lines.push(
    `机器人当前装好的扩展：共 ${list.length} 项` +
      `（技能 ${skillCount} 个、插件 ${pluginCount} 个）`
  );
  if (hidden.length) lines.push(`（另有 ${hidden.length} 项已停用或尚未生效，没有列入）`);
  lines.push('');

  let lastCategory = null;
  let index = 0;
  for (const row of list) {
    if (sortMode !== 'name' && row.category !== lastCategory) {
      lastCategory = row.category;
      lines.push(`【${CATEGORY_LABEL[row.category] || row.category}】`);
    }
    index += 1;
    const version = row.version ? ` v${row.version}` : '';
    lines.push(
      `${index}. ${row.name}（${KIND_LABEL[row.kind]} ${row.id}${version}）${statusText(row.active)}`
    );
    lines.push(`   ${clipText(row.description, descChars)}`);
  }

  lines.push('');
  lines.push('想了解某一项具体怎么用，直接问「<名字> 怎么用」。');
  return lines.join('\n');
}

/** 读取扩展自带的 README.md 摘要（不存在就返回空串）。 */
function readReadme(dir, limit) {
  try {
    const file = path.join(dir, 'README.md');
    if (!fs.existsSync(file)) return '';
    let text = fs.readFileSync(file, 'utf8');
    if (text.charCodeAt(0) === 0xfeff) text = text.slice(1);
    text = text.trim();
    if (!text) return '';
    const max = Math.max(200, Math.min(4000, Number(limit) || 1200));
    return text.length > max
      ? `${text.slice(0, max)}\n…（已截断，完整说明见该扩展目录下的 README.md）`
      : text;
  } catch {
    return '';
  }
}

/** 把单项的详情排版成给模型看的文本。 */
function formatDetail(entry, active, readmeChars) {
  const lines = [];
  lines.push(
    `【${entry.name}】${KIND_LABEL[entry.kind]} · id ${entry.id}` +
      `${entry.version ? ` · v${entry.version}` : ''}` +
      ` · ${CATEGORY_LABEL[entry.category] || entry.category} · ${statusText(active)}`
  );
  lines.push('');
  lines.push(`作用：${entry.description}`);

  if (entry.capabilities.length) {
    lines.push('');
    lines.push(`它提供的能力：${entry.capabilities.join('、')}`);
  }

  const keys = Object.keys(entry.configSchema);
  if (keys.length) {
    lines.push('');
    lines.push(
      `可配置项（在控制台「${entry.kind === 'skill' ? '技能' : '插件'}」页点它就能改）：`
    );
    for (const key of keys.slice(0, 12)) {
      const item = entry.configSchema[key] || {};
      const label = item.label || key;
      const desc = item.description ? `：${item.description}` : '';
      lines.push(`- ${label}（${key}）${desc}`);
    }
    if (keys.length > 12) {
      lines.push(`- …还有 ${keys.length - 12} 项，可在控制台里查看`);
    }
  }

  const readme = readReadme(entry.dir, readmeChars);
  if (readme) {
    lines.push('');
    lines.push('用法说明（该扩展自带的 README 摘要）：');
    lines.push(readme);
  }

  return lines.join('\n');
}

/** 按名字 / id 模糊查找一项。 */
function findEntry(query) {
  const rows = collect();
  const q = String(query || '').trim().toLowerCase();
  if (!q) return { entry: null, rows };
  const byId = rows.find((row) => row.id.toLowerCase() === q);
  if (byId) return { entry: byId, rows };
  const byName = rows.find(
    (row) => row.id.toLowerCase().includes(q) || row.name.toLowerCase().includes(q)
  );
  if (byName) return { entry: byName, rows };
  const byDesc = rows.find((row) => row.description.toLowerCase().includes(q));
  return { entry: byDesc || null, rows };
}

/** 模型可能给回字符串形式的布尔值，统一成 boolean。 */
function asBool(value, fallback) {
  if (typeof value === 'boolean') return value;
  if (typeof value === 'string') {
    const v = value.trim().toLowerCase();
    if (v === 'true' || v === '1' || v === 'yes') return true;
    if (v === 'false' || v === '0' || v === 'no') return false;
  }
  return fallback;
}

export function setup(api) {
  cfg = typeof api.config === 'function' ? api.config : () => ({});
  probeActive = typeof api.isSkillActive === 'function' ? api.isSkillActive : null;

  api.registerTool({
    id: 'list_capabilities',
    name: '列出可用能力',
    category: 'query',
    icon: '📋',
    description:
      '把机器人当前装好的技能与插件整理成一份按类别排序的清单，含每项一句话说明、版本和生效状态。' +
      '当群友问「你能做什么」「你会什么」「有什么功能」「有哪些技能或者插件」时使用。' +
      '返回的是真实清单，请据此回答，不要凭记忆编造功能。',
    parameters: {
      type: 'object',
      properties: {
        onlyActive: {
          type: 'boolean',
          description: '只看此刻生效中的项。默认跟随控制台设置；群友明确问「现在能用哪些」时可传 true'
        },
        includePlugins: {
          type: 'boolean',
          description: '是否连插件一起列。默认跟随控制台设置（一般是 true）'
        }
      }
    },
    async execute(ctx, args) {
      try {
        const c = cfg() || {};
        const rows = collect().map((row) => ({ ...row, active: activeOf(row.id, ctx) }));
        const text = formatList(rows, {
          includePlugins: asBool(args?.includePlugins, c.includePlugins !== false),
          onlyActive: asBool(args?.onlyActive, c.onlyActive === true),
          sortMode: c.sortMode === 'name' ? 'name' : 'category',
          descChars: c.listDescChars
        });
        return { content: text };
      } catch (error) {
        return { content: `读取能力清单失败：${error?.message ?? error}`, isError: true };
      }
    }
  });

  api.registerTool({
    id: 'explain_capability',
    name: '说明某项能力的用法',
    category: 'query',
    icon: '❓',
    description:
      '查询某个技能或插件的具体用法：它是干什么的、有哪些可配置项、以及它自带的用法说明。' +
      '当群友问到某个具体技能或者插件「怎么用」「是干什么的」「有什么设置」时使用。' +
      'name 传它的名字或 id（支持模糊匹配，例如「禁漫漫画下载」或「jm-suomingor」）。',
    parameters: {
      type: 'object',
      properties: {
        name: {
          type: 'string',
          description: '技能或插件的名字或 id，例如「禁漫漫画下载」「jm-suomingor」；支持部分匹配'
        }
      },
      required: ['name']
    },
    async execute(ctx, args) {
      try {
        const query = String(args?.name ?? '').trim();
        if (!query) {
          return {
            content: '请告诉我想了解哪个技能或插件的用法（名字或 id 都行）。',
            isError: true
          };
        }
        const { entry, rows } = findEntry(query);
        if (!entry) {
          const names = rows.map((row) => row.name).slice(0, 20).join('、');
          return {
            content: `没找到叫「${query}」的技能或插件。当前装好的有：${names}。需要的话我可以先列一份完整清单。`,
            isError: true
          };
        }
        const active = activeOf(entry.id, ctx);
        return { content: formatDetail(entry, active, (cfg() || {}).readmeChars) };
      } catch (error) {
        return { content: `查询用法失败：${error?.message ?? error}`, isError: true };
      }
    }
  });
}
