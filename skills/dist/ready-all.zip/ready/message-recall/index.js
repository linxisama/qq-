// 消息撤回技能
//
// ── 规则 ───────────────────────────────────────────────────────────────────
//   群聊：仅「主人QQ」名单里的账号可让机器人撤回
//   私聊：由 allowPrivateRecall 开关控制
//   主人QQ私聊：名单非空时任意撤回，不受开关限制

/** 解析主人QQ名单（兼容中英文逗号、分号、空白分隔）。 */
function parseOwnerList(raw) {
  if (!raw) return [];
  return String(raw)
    .split(/[,，;；\s]+/)
    .map((s) => s.trim())
    .filter(Boolean);
}

function normalizeId(v) {
  if (v === undefined || v === null) return '';
  return String(v).trim();
}

/** 名字只用于回执文案，取不到就退回 QQ 号。 */
function displayName(senderId, senderName) {
  const name = normalizeId(senderName);
  return name || normalizeId(senderId) || '未知';
}

/** 模型有时会照抄历史里的本地序号（消息前的 #12），把它还原成 QQ 消息 id。 */
function parseLocalSeq(raw) {
  const s = String(raw ?? '').trim();
  const m = /^#?(\d+)$/.exec(s);
  return m ? Number(m[1]) : null;
}

/**
 * 解析调用者 QQ 号。
 * 来源与 plugins/owner-identity 一致：触发批条目上的 senderId；
 * 触发批拿不到时退回「本会话最近一条人类发言」—— 群聊里紧接着被要求撤回的
 * 那一次交互，人类侧就是当前这个人。
 */
function resolveCallerId(ctx) {
  const entries = ctx?.session?.trigger;
  if (Array.isArray(entries)) {
    for (let i = entries.length - 1; i >= 0; i--) {
      const sid = normalizeId(entries[i]?.senderId);
      if (sid && sid !== 'self') return sid;
    }
  }
  try {
    const recent = ctx?.store?.recent?.(ctx.chatKey, { limit: 30, includeSelf: false }) || [];
    for (let i = recent.length - 1; i >= 0; i--) {
      const sid = normalizeId(recent[i]?.senderId);
      if (sid && sid !== 'self') return sid;
    }
  } catch { /* store 不可用就当拿不到 */ }
  return '';
}

/** 在存档中按 QQ 消息 id 找条目。 */
function findEntryByMid(ctx, mid) {
  const key = normalizeId(mid);
  if (!key) return null;
  try {
    const hit = ctx?.store?.findByMid?.(ctx.chatKey, key);
    if (hit) return hit;
  } catch { /* 继续退回线性扫描 */ }
  // findByMid 是字符串比较：消息 id 是数字时 1 与 "1" 能对上，但 ' 1 ' 之类对不上，
  // 再做一次宽松扫描兜底。
  try {
    const recent = ctx?.store?.recent?.(ctx.chatKey, { limit: 400 }) || [];
    for (let i = recent.length - 1; i >= 0; i--) {
      if (recent[i]?.mid != null && String(recent[i].mid).trim() === key) return recent[i];
    }
  } catch { /* ignore */ }
  return null;
}

/**
 * 找机器人自己最后一条「还带 QQ 消息 id」的消息。
 * 没带 mid 的（极少数发送路径拿不到 message_id）跳过 —— 没有 id 就撤不了，
 * 拿它当目标只会白白报错。
 */
function findLastSelfEntry(ctx) {
  let recent = [];
  try {
    recent = ctx?.store?.recent?.(ctx.chatKey, { limit: 60 }) || [];
  } catch { return null; }
  for (let i = recent.length - 1; i >= 0; i--) {
    const m = recent[i];
    if (m?.self && !m.recalled && m.mid != null && String(m.mid).trim() !== '') return m;
  }
  return null;
}

/** 撤回成功后把存档里的那条标记掉，之后的提示词就不会再带它。 */
function markRecalled(ctx, mid) {
  try {
    ctx?.store?.markRecalled?.(ctx.chatKey, String(mid));
  } catch { /* 标记失败不影响撤回结果 */ }
}

export function register(api) {
  api.registerTool({
    id: 'recall_message',
    name: '撤回消息',
    description:
      '撤回机器人自己刚发送的消息。群聊内只有主人QQ可以触发；私聊是否可用由「允许私聊内撤回」开关控制，'
      + '主人QQ私聊默认不受该开关限制。只能撤回机器人自己发的消息。',
    category: 'system',
    icon: '↩️',
    parameters: {
      type: 'object',
      properties: {
        targetMessageId: {
          type: 'string',
          description:
            '要撤回的消息ID（机器人自己发送的那条）。不传则撤回机器人最近发送的一条；'
            + '只有用户引用的那条消息不是机器人发的、或要撤回更早的消息时才需要显式传入。'
        }
      },
      required: []
    },

    async execute(ctx, args) {
      if (!ctx) return { content: '撤回失败：拿不到会话上下文。', isError: true };

      const cfg = (typeof api.config === 'function' && api.config()) || {};
      const owners = parseOwnerList(cfg.ownerQQ);
      const allowPrivate = cfg.allowPrivateRecall !== false;   // 未配置时默认允许

      const kind = normalizeId(ctx.kind) || (String(ctx.chatKey || '').startsWith('group:') ? 'group' : 'private');
      const isPrivate = kind === 'private';
      const callerId = resolveCallerId(ctx);
      const isOwner = owners.length > 0 && owners.includes(callerId);

      // ── 权限判定 ──
      // 群聊一律要求主人。私聊：主人放行，非主人看开关。
      if (!isPrivate && !isOwner) {
        return {
          content: owners.length === 0
            ? '撤回失败：还没配置「主人QQ账号」，群聊内无法撤回。请在「设置 → 技能 → 消息撤回」里填写主人QQ号码。'
            : `撤回失败：群聊内只有主人QQ可以让机器人撤回消息（当前触发者：${callerId || '未识别'}）。`
              + '请让主人账号操作，或把该QQ加入「主人QQ账号」。',
          isError: true
        };
      }
      if (isPrivate && !isOwner && !allowPrivate) {
        return {
          content: '撤回失败：私聊撤回功能已关闭。请在「设置 → 技能 → 消息撤回」中开启「允许私聊内撤回」。',
          isError: true
        };
      }

      // ── 确定要撤回的消息 ──
      const raw = args && args.targetMessageId != null ? String(args.targetMessageId).trim() : '';
      let targetMid = raw;
      let targetEntry = null;

      if (targetMid) {
        // 兼容模型照抄历史里的本地序号（#12）
        if (/^#?\d+$/.test(targetMid)) {
          const localId = parseLocalSeq(targetMid);
          const byLocal = localId != null ? ctx.store?.findByLocalId?.(ctx.chatKey, localId) : null;
          if (byLocal && byLocal.mid != null) {
            targetEntry = byLocal;
            targetMid = String(byLocal.mid);
          } else {
            targetEntry = findEntryByMid(ctx, targetMid);
          }
        } else {
          targetEntry = findEntryByMid(ctx, targetMid);
        }
      } else {
        targetEntry = findLastSelfEntry(ctx);
        targetMid = targetEntry?.mid != null ? String(targetEntry.mid) : '';
      }

      if (!targetMid) {
        return {
          content: '撤回失败：没有找到可撤回的消息。请回复要撤回的那条消息，或直接提供消息ID。',
          isError: true
        };
      }

      // 只允许撤回机器人自己的消息：提前拦住，比让协议端回一句
      // 「message not found or not retractable」更好解释。
      if (targetEntry && !targetEntry.self) {
        return {
          content: `撤回失败：这条消息是「${displayName(targetEntry.senderId, targetEntry.senderName)}」发的，`
            + '机器人只能撤回自己发的消息。',
          isError: true
        };
      }

      const messageId = Number(targetMid);
      if (!Number.isFinite(messageId) || messageId === 0) {
        return { content: `撤回失败：消息ID「${targetMid}」不是有效的 OneBot 消息ID。`, isError: true };
      }

      // ── 执行撤回（OneBot v11 delete_msg）──
      if (!ctx.onebot || typeof ctx.onebot.call !== 'function') {
        return { content: '撤回失败：当前运行环境没有 OneBot 调用通道（ctx.onebot.call）。', isError: true };
      }
      try {
        await ctx.onebot.call('delete_msg', { message_id: messageId });
      } catch (err) {
        const msg = err && err.message ? err.message : String(err);
        return { content: `撤回失败：${msg}`, isError: true };
      }

      markRecalled(ctx, targetMid);
      api.log?.(`${ctx.chatKey} 已撤回消息 ${messageId}（触发者 ${callerId || '未知'}）`);
      return { content: `已撤回消息（ID: ${targetMid}）。`, isError: false };
    }
  });
}
