// B站梗情报（bili-memes）—— 按关键词去 B站搜视频，用真实在用的标题当"梗的语境样本"。
//
// ── 为什么不复用「查梗百科」─────────────────────────────────────────────────
// meme-wiki 走的是萌娘百科：权威，但收录滞后。B站新梗 / 直播内部梗 / 刚火的二创梗
// 往往还没词条，而群里天天在聊的正是这一类。所以这个技能补的是「新」，不补「权威」。
//
// ── 为什么不是「通用搜索」───────────────────────────────────────────────────
// 通用搜索返回「XX是什么梗」这种二手聚合页，转述还会互相抄错。
// B站视频标题是**一手用法**（谁在用、配什么画面、什么情绪），一屏就能判断语境。
//
// ── 风控要点（实测出来的，别改坏）───────────────────────────────────────────
// 1) search/type 不带 cookie 时经常 code=-412。先 GET 首页拿 buvid3 等 cookie 再搜。
// 2) cookie 在进程内缓存一次即可，别每次搜都重新抓首页。
// 3) search/type 失败再试 search/all/v2；仍失败就退到「热搜榜 + 热门榜」做关键词匹配。
// 4) 标题里带 <em class="keyword"> 高亮标签，必须剥掉，否则模型会看到一堆 HTML。
//
// ── 截断必须按字符安全切 ────────────────────────────────────────────────────
// 按长度硬切会把 emoji 的代理对切一半，DeepSeek 会直接 400 整轮失败。用 safeSlice()。

const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
  + '(KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36';

const BILI_HEADERS = {
  'user-agent': UA,
  referer: 'https://www.bilibili.com/',
  accept: 'application/json, text/plain, */*',
  'accept-language': 'zh-CN,zh;q=0.9',
};

let cfg = () => ({});
let cookieCache = null; // 进程内缓存，'' 表示拿不到（也要缓存，避免反复重试拖慢）

const clamp = (n, lo, hi) => Math.min(hi, Math.max(lo, Math.round(Number(n) || lo)));

/** 代理对安全截断：宁可少一个字，也不能切出孤立代理项。 */
function safeSlice(s, n) {
  const t = String(s ?? '');
  if (t.length <= n) return t;
  return t.slice(0, n).replace(/[\uD800-\uDBFF]$/, '');
}

/** 去掉 <em class="keyword">…</em> 之类的标签与实体。 */
function stripTags(s) {
  return String(s ?? '')
    .replace(/<[^>]*>/g, '')
    .replace(/&quot;/g, '"')
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&#39;/g, "'")
    .replace(/\s+/g, ' ')
    .trim();
}

/**
 * 把「「哈基米」是什么意思」「牢大 梗」削成搜索词。
 * 顺序有讲究：先削引号 → 标点 → 语气词 → 疑问尾巴，再回到引号。
 * 尾巴必须**长词优先**，否则「是什么意思」会先被「什么意思」吃掉，只剩一个「是」。
 */
function cleanTerm(raw) {
  const source = String(raw ?? '').trim();
  const LEAD = /^[「『"'“”‘’【\[（(]+/;
  const TAIL = /[」』"'“”‘’】\]）)]+$/;
  const PUNCT = /[?？。！!，,、；;~～\s]+$/;
  const PARTICLE = /[啊呀呢嘛哈哦哟啦叭吧]+$/;
  const SUFFIX = /(是什么意思|是什么梗|是啥梗|什么意思|啥意思|什么梗|啥梗|这个梗|那个梗|的梗|出处是啥|出处|哪来的|梗)$/;
  let t = source;
  for (let i = 0; i < 5; i++) {
    const before = t;
    t = t.replace(LEAD, '').replace(TAIL, '').trim();
    t = t.replace(PUNCT, '');
    if (t.length > 1) t = t.replace(PARTICLE, '').trim();
    t = t.replace(SUFFIX, '').trim();
    t = t.replace(TAIL, '').trim();
    if (t === before) break;
  }
  // 削到只剩一个字（「这啥梗啊」→「这」）说明削过头了，宁可用原话
  return t.length >= 2 ? t : source;
}

function fmtPlay(n) {
  const v = Number(n) || 0;
  if (v >= 100000000) return `${(v / 100000000).toFixed(1)}亿`;
  if (v >= 10000) return `${(v / 10000).toFixed(1)}万`;
  return String(v);
}

function fmtDate(ts) {
  const n = Number(ts) || 0;
  if (!n) return '';
  try { return new Date(n * 1000).toISOString().slice(0, 10); } catch { return ''; }
}

async function getJson(url, timeoutMs, headers = {}) {
  const res = await fetch(url, {
    headers: { ...BILI_HEADERS, ...headers },
    signal: AbortSignal.timeout(timeoutMs),
  });
  const text = await res.text();
  if (!text) throw new Error(`空响应（HTTP ${res.status}）`);
  try {
    return JSON.parse(text);
  } catch {
    throw new Error(`返回不是 JSON（HTTP ${res.status}）：${safeSlice(text, 80).replace(/\s+/g, ' ')}`);
  }
}

/** 取首页 cookie（buvid3 / buvid4 / b_nut…）。拿不到也返回 ''，不抛。 */
async function ensureCookie(timeoutMs) {
  if (cookieCache !== null) return cookieCache;
  try {
    const res = await fetch('https://www.bilibili.com/', {
      headers: { 'user-agent': UA, 'accept-language': 'zh-CN,zh;q=0.9' },
      signal: AbortSignal.timeout(timeoutMs),
      redirect: 'follow',
    });
    // Node 20+ 有 getSetCookie()，旧版本只有拼起来的字符串
    const raw = typeof res.headers.getSetCookie === 'function'
      ? res.headers.getSetCookie().join('; ')
      : (res.headers.get('set-cookie') || '');
    const pairs = [...String(raw).matchAll(/(?:^|;\s*)([^=;,\s]+)=([^;]*)/g)]
      .map((m) => `${m[1]}=${m[2]}`)
      .filter((p) => !/^(path|domain|expires|max-age|samesite|secure|httponly)=/i.test(p));
    cookieCache = [...new Set(pairs)].join('; ');
    await res.body?.cancel?.().catch(() => {});
  } catch {
    cookieCache = '';
  }
  return cookieCache;
}

/** 搜索建议：不风控、极快，能补出同义词/变体（「哈基米」→「哈基米 猫」）。 */
async function suggest(term, timeoutMs) {
  try {
    const j = await getJson(
      'https://s.search.bilibili.com/main/suggest?main_ver=v1&term=' + encodeURIComponent(term),
      timeoutMs);
    const list = j?.result?.tag || j?.result || [];
    if (!Array.isArray(list)) return [];
    return list
      .map((x) => String(x?.value ?? x?.name ?? x?.term ?? '').trim())
      .filter(Boolean)
      .slice(0, 6);
  } catch {
    return [];
  }
}

/** 视频搜索（主路径）。失败抛错，由上层做降级。 */
async function searchVideos(term, count, timeoutMs) {
  const cookie = await ensureCookie(timeoutMs);
  const headers = cookie ? { cookie } : {};
  const urls = [
    'https://api.bilibili.com/x/web-interface/search/type?search_type=video&page=1&keyword='
      + encodeURIComponent(term),
    'https://api.bilibili.com/x/web-interface/search/all/v2?page=1&keyword=' + encodeURIComponent(term),
  ];
  const errs = [];
  for (const url of urls) {
    try {
      const j = await getJson(url, timeoutMs, headers);
      if (j?.code !== 0) {
        errs.push(`code=${j?.code}${j?.message ? `（${j.message}）` : ''}`);
        continue;
      }
      // search/type 是 data.result[]；search/all/v2 是 data.result[] 里再分 type
      const raw = Array.isArray(j?.data?.result) ? j.data.result : [];
      const videos = [];
      for (const item of raw) {
        if (item && Array.isArray(item?.data)) videos.push(...item.data);
        else if (item && (item.title || item.bvid)) videos.push(item);
      }
      const mapped = videos
        .filter((x) => x && x.title)
        .map((x) => ({
          title: stripTags(x.title),
          up: String(x.author || x.name || ''),
          play: Number(x.play ?? 0),
          date: fmtDate(x.pubdate ?? x.ctime),
          desc: stripTags(x.description || x.desc || ''),
          bvid: String(x.bvid || ''),
        }))
        .filter((x) => x.title);
      if (mapped.length) return mapped.slice(0, count);
      errs.push('结果为空');
    } catch (error) {
      errs.push(String(error?.message ?? error).slice(0, 80));
    }
  }
  throw new Error(errs.join('；') || 'B站搜索没有响应');
}

/** 降级路径：从热搜榜 + 热门榜里找出含关键词的条目。 */
async function fallbackBoards(term, count, timeoutMs) {
  const out = { hot: [], videos: [] };
  const [hot, popular] = await Promise.allSettled([
    getJson('https://api.bilibili.com/x/web-interface/search/square?limit=30', timeoutMs),
    getJson('https://api.bilibili.com/x/web-interface/popular?ps=20&pn=1', timeoutMs),
  ]);
  if (hot.status === 'fulfilled') {
    const list = hot.value?.data?.trending?.list || [];
    out.hot = list.map((x) => String(x.keyword || x.show_name || '')).filter(Boolean).slice(0, 15);
  }
  if (popular.status === 'fulfilled') {
    const list = popular.value?.data?.list || [];
    out.videos = list
      .map((x) => ({
        title: stripTags(x.title),
        up: String(x.owner?.name || ''),
        play: Number(x.stat?.view || 0),
        date: fmtDate(x.pubdate ?? x.pubdate),
        desc: stripTags(x.desc || ''),
      }))
      .filter((x) => x.title)
      .slice(0, count);
  }
  const lowTerm = String(term).toLowerCase();
  const hitHot = out.hot.filter((k) => String(k).toLowerCase().includes(lowTerm));
  const hitVideos = out.videos.filter((v) => `${v.title}${v.desc}`.toLowerCase().includes(lowTerm));
  return { hot: hitHot, videos: hitVideos, allHot: out.hot };
}

export function setup(api) {
  if (typeof api?.config === 'function') {
    const getCfg = api.config;
    cfg = () => { try { return getCfg() || {}; } catch { return {}; } };
  }
  if (typeof api?.registerTool !== 'function') return;

  const opts = () => {
    const c = cfg() || {};
    return {
      count: clamp(c.count ?? 5, 1, 10),
      descChars: clamp(c.descChars ?? 90, 0, 300),
      timeoutMs: clamp(c.timeoutMs ?? 15000, 3000, 60000),
    };
  };

  api.registerTool({
    id: 'ctx',
    name: 'B站梗情报',
    description: '拿一个梗词去 B站搜视频，返回真实在用的标题/UP主/播放量/时间/简介 —— 用来判断一个**新梗、直播梗、二创梗**的出处、情绪和用法。'
      + '专治萌娘百科还没收录或解释太旧的情况。用法：ctx("哈基米")、ctx("牢大")、ctx("假面骑士 梗")。'
      + '传梗本身即可，不要写成问句。它只给"语境样本"，不给你现成定义 —— 你要自己从标题里推断，然后用人话说一两句。',
    category: 'knowledge',
    icon: '📺',
    parameters: {
      type: 'object',
      properties: {
        term: { type: 'string', description: '要查的梗或关键词，例如「哈基米」「牢大」「原神 梗」' },
      },
      required: ['term'],
    },
    async execute(_ctx, args) {
      const o = opts();
      const raw = String(args?.term ?? '').trim();
      if (!raw) return { content: 'term 不能为空。', isError: true };
      const term = cleanTerm(raw);

      const [sugs, videosRes] = await Promise.allSettled([
        suggest(term, Math.min(o.timeoutMs, 8000)),
        searchVideos(term, o.count, o.timeoutMs),
      ]);
      const sugsList = sugs.status === 'fulfilled' ? sugs.value : [];

      const lines = [`【B站梗情报：${term}】`];
      if (sugsList.length) {
        lines.push(`相关搜索：${sugsList.join(' ｜ ')}`);
      }

      if (videosRes.status === 'fulfilled' && videosRes.value.length) {
        lines.push('', '正在用的视频：');
        videosRes.value.forEach((v, i) => {
          const meta = [v.up ? `UP：${v.up}` : '', v.play ? `${fmtPlay(v.play)}播放` : '', v.date]
            .filter(Boolean).join('，');
          lines.push(`${i + 1}. ${v.title}${meta ? `（${meta}）` : ''}`);
          if (v.desc && o.descChars > 0) lines.push(`   简介：${safeSlice(v.desc, o.descChars)}`);
        });
        return { content: lines.join('\n') + '\n\n（以上是 B站上真实在用的视频样本，用来判断这个梗的出处、情绪和用法；'
          + '用你自己的话概括一两句就行，别念标题、别提"根据B站"。如果这些标题互相矛盾、看不出所以然，就说不太确定。）' };
      }

      // 搜索被风控/失败 → 退到榜单匹配
      const failMsg = String(videosRes.reason?.message ?? videosRes.reason ?? '').slice(0, 120);
      try {
        const fb = await fallbackBoards(term, o.count, o.timeoutMs);
        if (fb.videos.length || fb.hot.length) {
          if (fb.hot.length) lines.push(`热搜里的相关词：${fb.hot.join(' ｜ ')}`);
          if (fb.videos.length) {
            lines.push('', '热门榜里的相关视频：');
            fb.videos.forEach((v, i) => lines.push(
              `${i + 1}. ${v.title}（UP：${v.up || '未知'}，${fmtPlay(v.play)}播放${v.desc ? `｜${safeSlice(v.desc, o.descChars)}` : ''}）`));
          }
          return { content: lines.join('\n') + '\n\n（B站搜索接口被风控了，只拿到榜单里的相关内容，样本较少 —— 判断要保守一点。）' };
        }
        return {
          content: `B站那边没搜到「${term}」的相关内容：${failMsg || '搜索被风控/无结果'}`
            + '\n（可以先用「查梗百科」试萌娘百科；两边都没有就如实说这梗你不确定，别硬编。）',
          isError: true,
        };
      } catch (error) {
        return {
          content: `B站梗情报查询失败：${String(error?.message ?? error).slice(0, 160)}`
            + '\n（如实说查不到即可，别硬猜。）',
          isError: true,
        };
      }
    },
  });

  if (typeof api.log === 'function') {
    api.log('已加载：1 个工具（B站梗情报 ctx：搜索建议 + 视频搜索 + 榜单降级）');
  }
}

export function available() { return { ok: true }; }

/** 自测用。 */
export const internals = { cleanTerm, safeSlice, stripTags, fmtPlay, suggest, searchVideos, fallbackBoards };
