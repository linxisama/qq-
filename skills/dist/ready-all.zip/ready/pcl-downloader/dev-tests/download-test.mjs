// PCL 下载器 —— dev-tests（不起 QQ Agent，直接打引擎）
//
// 起一个本地 HTTP 服务器，覆盖四种服务器行为，验证：
//   ① 支持 Range 且 ≥1MB → 分段下载 + 合并
//   ② 支持 Range 但分段请求回 200 → 整体降级单线程
//   ③ 完全不支持 Range → 单线程
//   ④ 小文件（<1MB）→ 不分段
// 再验证：sha256 校验、按路径去重、SSRF 拦截、坏源淘汰判据、文件名推断。
//
// 跑法：node skills/pcl-downloader/dev-tests/download-test.mjs
//
// 注意：测试要打 127.0.0.1，所以引擎调用一律带 allowPrivate:true
//（这个开关只存在于引擎函数参数里，工具层不会暴露它，默认值是 false）。

import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import http from 'node:http'
import crypto from 'node:crypto'
import {
  download, isPrivateIp, parseSources, safeName, nameFromHeaders,
  shouldEvictSource, totalFromContentRange, fmtBytes
} from '../index.js'

let pass = 0
let fail = 0
function ok(cond, label) {
  if (cond) { pass++; console.log(`  ✓ ${label}`) }
  else { fail++; console.log(`  ✗ ${label}`) }
}
function eq(a, b, label) { ok(a === b, `${label}（期望 ${b}，实际 ${a}）`) }

/* ── 造一份确定的样本数据 ── */
function makeData(size, seed = 1) {
  const buf = Buffer.allocUnsafe(size)
  let x = seed >>> 0
  for (let i = 0; i < size; i++) {
    x = (x * 1664525 + 1013904223) >>> 0
    buf[i] = x & 0xff
  }
  return buf
}
const BIG = makeData(3 * 1024 * 1024 + 12345, 7)   // ~3MB：够触发分段
const SMALL = makeData(100 * 1024, 3)              // 100KB：不分段
const sha = (b) => crypto.createHash('sha256').update(b).digest('hex')

/* ── 本地测试服务器 ──
   /full     支持 Range
   /lying    探大小回 206，但真正的分段请求回 200（骗人的服务器）
   /norange  完全不支持 Range
   /small    100KB，支持 Range
   /404      404
   /hop      302 → /full（验证重定向）
   /named    带 Content-Disposition 的文件名（验证文件名推断）
*/
function startServer() {
  const server = http.createServer((req, res) => {
    const url = new URL(req.url, 'http://127.0.0.1')
    const route = url.pathname
    if (route === '/404') { res.writeHead(404); res.end('nope'); return }
    if (route === '/hop') { res.writeHead(302, { location: '/full' }); res.end(); return }

    let data = null
    let mode = 'range'   // range | norange | lying
    if (route === '/full') data = BIG
    else if (route === '/small') data = SMALL
    else if (route === '/named') data = SMALL
    else if (route === '/norange') { data = BIG; mode = 'norange' }
    else if (route === '/lying') { data = BIG; mode = 'lying' }
    else { res.writeHead(404); res.end(); return }

    const headers = {}
    if (route === '/named') headers['content-disposition'] = "attachment; filename*=UTF-8''%E6%B5%8B%E8%AF%95%20file.bin"

    const rangeHeader = String(req.headers.range || '')
    const m = rangeHeader.match(/bytes=(\d+)-(\d*)/)
    const isProbe = !!m && m[1] === '0' && m[2] === '0'
    const rangeAllowed = mode === 'range' || (mode === 'lying' && isProbe)

    if (m && rangeAllowed) {
      const start = Number(m[1])
      const end = m[2] === '' ? data.length - 1 : Number(m[2])
      if (start >= data.length) { res.writeHead(416, { 'content-range': `bytes */${data.length}` }); res.end(); return }
      const slice = data.subarray(start, Math.min(end, data.length - 1) + 1)
      res.writeHead(206, {
        'content-type': 'application/octet-stream',
        'content-range': `bytes ${start}-${start + slice.length - 1}/${data.length}`,
        'content-length': String(slice.length),
        'accept-ranges': 'bytes',
        ...headers
      })
      res.end(slice)
      return
    }

    res.writeHead(200, {
      'content-type': 'application/octet-stream',
      'content-length': String(data.length),
      ...(mode === 'range' ? { 'accept-ranges': 'bytes' } : {}),
      ...headers
    })
    res.end(data)
  })
  return new Promise((resolve) => server.listen(0, '127.0.0.1', () => resolve(server)))
}

const tmpRoot = fs.mkdtempSync(path.join(os.tmpdir(), 'pcl-dl-test-'))
const outDir = (n) => path.join(tmpRoot, n)

async function main() {
  const server = await startServer()
  const port = server.address().port
  const base = `http://127.0.0.1:${port}`

  console.log('\n[纯函数]')
  eq(isPrivateIp('127.0.0.1'), true, 'isPrivateIp 127.0.0.1')
  eq(isPrivateIp('10.0.0.5'), true, 'isPrivateIp 10.x')
  eq(isPrivateIp('192.168.1.1'), true, 'isPrivateIp 192.168.x')
  eq(isPrivateIp('169.254.1.1'), true, 'isPrivateIp 链路本地')
  eq(isPrivateIp('::1'), true, 'isPrivateIp ::1')
  eq(isPrivateIp('8.8.8.8'), false, 'isPrivateIp 公网')
  eq(parseSources('http://a/1', 'http://b/1\nhttp://c/1 http://a/1').length, 3, 'parseSources 去重合并')
  eq(safeName('../../etc/passwd'), '_.._etc_passwd', 'safeName 挡路径穿越（不留分隔符、不以点开头）')
  eq(safeName('a/b:c*d?.txt'), 'a_b_c_d_.txt', 'safeName 洗非法字符')
  eq(nameFromHeaders({ 'content-disposition': "attachment; filename*=UTF-8''%E6%B5%8B.bin" }, ''), '测.bin', 'nameFromHeaders RFC5987')
  eq(nameFromHeaders({}, 'http://x/y/z.tar.gz?q=1'), 'z.tar.gz', 'nameFromHeaders 取链接末段')
  eq(totalFromContentRange('bytes 0-0/5000'), 5000, 'totalFromContentRange')
  eq(shouldEvictSource({ raw: 'http://x', failCount: 1 }, { status: 404 }), true, '404 淘汰源')
  eq(shouldEvictSource({ raw: 'http://x', failCount: 1 }, { status: 403 }), true, '403 淘汰源')
  eq(shouldEvictSource({ raw: 'http://bmclapi2.bangbang93.com/y', failCount: 1 }, { status: 403 }), false, 'bmclapi 的 403 豁免')
  eq(shouldEvictSource({ raw: 'http://x', failCount: 1 }, { status: 500 }), false, '500 不立刻淘汰')

  console.log('\n[① 支持 Range，≥1MB → 分段]')
  let r = await download([`${base}/full`], { destDir: outDir('a'), name: 'big.bin', threads: 4, allowPrivate: true, sha256: sha(BIG), onLog: () => {} })
  eq(fs.readFileSync(r.path).length, BIG.length, '分段下载字节数一致')
  ok(/segmented/.test(r.mode), `模式是分段（${r.mode}）`)
  ok(Buffer.compare(fs.readFileSync(r.path), BIG) === 0, '内容逐字节一致')
  eq(r.sha256, sha(BIG), 'sha256 校验通过')

  console.log('\n[② 骗人的服务器：探大小 206、分段回 200 → 降级单线程]')
  r = await download([`${base}/lying`], { destDir: outDir('b'), name: 'lying.bin', threads: 4, allowPrivate: true, onLog: () => {} })
  eq(r.bytes, BIG.length, '降级后字节数一致')
  eq(r.mode, 'single-fallback', '模式是 single-fallback')
  ok(Buffer.compare(fs.readFileSync(r.path), BIG) === 0, '降级后内容一致')

  console.log('\n[③ 完全不支持 Range，≥1MB → 单线程]')
  r = await download([`${base}/norange`], { destDir: outDir('c'), name: 'norange.bin', threads: 4, allowPrivate: true, onLog: () => {} })
  eq(r.mode, 'single', '模式是 single')
  ok(Buffer.compare(fs.readFileSync(r.path), BIG) === 0, '内容一致')

  console.log('\n[④ 小文件（<1MB）→ 不分段]')
  r = await download([`${base}/small`], { destDir: outDir('d'), name: 'small.bin', threads: 4, allowPrivate: true })
  eq(r.mode, 'single', '小文件单线程')
  eq(r.bytes, SMALL.length, '小文件字节数一致')

  console.log('\n[⑤ 多源轮换：坏源在前，好源兜底]')
  r = await download([`${base}/404`, `${base}/full`], { destDir: outDir('e'), name: 'multi.bin', threads: 2, allowPrivate: true, onLog: () => {} })
  ok(Buffer.compare(fs.readFileSync(r.path), BIG) === 0, '404 源被淘汰、后续源顶上')
  ok(r.retries >= 1, `有重试计数（${r.retries}）`)

  console.log('\n[⑥ 重定向]')
  r = await download([`${base}/hop`], { destDir: outDir('f'), name: 'hop.bin', threads: 1, allowPrivate: true })
  eq(r.bytes, BIG.length, '跟随 302 后拿到完整文件')

  console.log('\n[⑦ 文件名推断（Content-Disposition）]')
  r = await download([`${base}/named`], { destDir: outDir('g'), threads: 1, allowPrivate: true })
  eq(r.name, '测试 file.bin', '按 Content-Disposition 定名')

  console.log('\n[⑧ SSRF：默认禁止内网]')
  let blocked = false
  try {
    await download([`${base}/small`], { destDir: outDir('h'), name: 'x.bin' })
  } catch (e) {
    blocked = /禁止下载内网/.test(String(e?.message))
  }
  ok(blocked, 'allowPrivate=false 时拦截 127.0.0.1')

  console.log('\n[⑨ 体积上限]')
  let tooBig = false
  try {
    await download([`${base}/full`], { destDir: outDir('i'), name: 'y.bin', maxBytes: 1000, allowPrivate: true })
  } catch (e) {
    tooBig = /文件太大|超过大小上限/.test(String(e?.message))
  }
  ok(tooBig, '超过 maxBytes 被拒')

  console.log('\n[⑩ 按路径去重（PCL 的 AllFiles）]')
  const [p1, p2] = await Promise.all([
    download([`${base}/full`], { destDir: outDir('j'), name: 'same.bin', threads: 2, allowPrivate: true }),
    download([`${base}/full`], { destDir: outDir('j'), name: 'same.bin', threads: 2, allowPrivate: true })
  ])
  ok(p1 === p2, '同一落盘路径的并发调用共享同一个任务')

  server.close()
  fs.rmSync(tmpRoot, { recursive: true, force: true })

  console.log(`\n结果：${pass} 通过，${fail} 失败`)
  process.exit(fail ? 1 : 0)
}

main().catch((e) => {
  console.error('测试崩了：', e)
  try { fs.rmSync(tmpRoot, { recursive: true, force: true }) } catch { /* ignore */ }
  process.exit(1)
})
