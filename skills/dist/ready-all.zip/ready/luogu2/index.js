// 洛谷题库（luogu2）
//
// 定位：让机器人能查洛谷真题、按条件出题。归在 skills/（LLM 型）—— 「什么时候要查题、
// 出什么难度的题」完全取决于用户说的话，写不成规则，只能 registerTool 交给模型判断。
//
// ── 这个技能为什么长这样（全部来自实测，不是照文档猜的）────────────────────
//
// 1. 洛谷**没有公开 API**，但页面是服务端渲染的，完整结构化数据放在
//    <script id="lentille-context" type="application/json"> 里
//    （含 pid / name / difficulty / tags / totalSubmit / totalAccepted / limits / contenu）。
//    直接从这个 script 里取 JSON 比解析 HTML 稳，也比搜索摘要准得多。
//    实测：_contentOnly=1 参数现在拿不到 JSON，只会返回 HTML，所以不依赖它。
//
// 2. 洛谷 CDN 有 Cookie 挑战：第一次请求返回 **302 且 Location 指向同一个 URL**，
//    并下发 C3VK cookie（Max-Age 300）；带上 cookie 再请求才给 200。
//    ⚠️ 关键：必须区分两类重定向 ——
//        · Location 与当前 URL 相同  → cookie 挑战，带 cookie 重试
//        · Location 指向别的 URL     → 真跳转（如小写 p1001 → 301 → /problem/P1001）
//    不区分就会死循环（实测踩过：请求 /problem/p1001 直接卡死在重定向里）。
//
// 3. 标签要用数字 id 筛选（tag=3 才是「动态规划 DP」），而模型只会说中文标签名，
//    所以技能必须自己维护 标签名 → id 的映射（/_lfe/tags，505 个标签，缓存 12 小时）。
//
// 4. difficulty 参数是 1-8（洛谷现为九档），**传 0 等于不筛选**（返回全量），不是「暂无评定」。
//    难度名称必须从 /_lfe/config 的 ProblemDifficulty 取 —— 洛谷改过难度体系，
//    照旧资料硬编码会把整排档位译错（第一次实现就踩了这个坑）。
//
// 5. 超范围页码不报错，会返回最后一页 —— 随机抽题时要自己按 count 算页数上限。
//
// 6. 「点进去就是洛谷原题」的卡片，走的是协议端（SnowLuma）的 `share` 段：
//    它内部会转成 com.tencent.structmsg / view:news 的 JSON 卡片，jumpUrl 就是点开的链接。
//    实测（2026-10-08，SnowLuma 1.14.19）：
//      · share 段字段 url / title 必填（非空字符串），content / image 可选，字段值必须都是标量；
//      · json/share 没有像 video/poke 那样的「必须单独成条」限制，但发卡片时不夹带别的东西最稳；
//      · 把卡片发给不存在的群号，报错是 QQ 侧「你已被移出该群」而不是段校验失败 ——
//        说明卡片结构被协议端完整接受并提交到了 QQ 服务器。
//    发送走 ctx.sender.sendMedia（限频/去重/留档都在里面，不能绕过它直接调 onebot）；
//    卡片发送失败时自动降级成「标题 + 链接」的纯文本，保证对方至少能点到题。

const BASE = 'https://www.luogu.com.cn';// 带浏览器 UA 会触发 CDN 的 CC 挑战，但配合下面的 cookie 挑战处理可稳定通过（实测连发 10 次全 200）。
const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36';
const REQUEST_TIMEOUT = 20000;
const COOKIE_TTL = 240000;   // 洛谷 C3VK 的 Max-Age 是 300 秒，提前一点主动丢弃

/**
 * 洛谷难度名，下标即 difficulty 值（0-8 共九档）。
 *
 * ⚠️ 这份表**必须以 /_lfe/config 的 ProblemDifficulty 为准**（ensureMeta 每次刷新缓存时覆盖它）。
 * 洛谷改过难度体系，靠旧资料硬编码会整体错位 —— 实测官方当前定义是：
 *   0 暂无评定 / 1 入门 / 2 普及− / 3 普及 / 4 普及+/提高− / 5 提高
 *   / 6 提高+/省选− / 7 省选/NOI− / 8 NOI/NOI+/CTS
 * 下面这份只在拿不到 config 时兜底（第一次实测时正是照旧资料写错了一整排）。
 */
const DIFFICULTY_FALLBACK = ['暂无评定', '入门', '普及−', '普及', '普及+/提高−', '提高', '提高+/省选−', '省选/NOI−', 'NOI/NOI+/CTS'];
let difficultyNames = [...DIFFICULTY_FALLBACK];
const MAX_DIFFICULTY = 8;

function difficultyName(level) {
  const i = Number(level);
  if (!Number.isInteger(i) || i < 0) return '未知';
  return difficultyNames[i] ?? DIFFICULTY_FALLBACK[i] ?? `难度${i}`;
}

/** 题目类型（URL 的 type 参数）。 */
const PROBLEM_TYPES = {
  P: '洛谷原创（主站）',
  B: '入门与面试',
  CF: 'Codeforces',
  SP: 'SPOJ',
  AT: 'AtCoder',
  UVA: 'UVa',
  T: '团队题目'
};

let apiRef = null;
let cookieJar = '';
let cookieAt = 0;
let lastRequestAt = 0;
let tagCache = null;

const ok = (payload) => ({
  content: typeof payload === 'string' ? payload : JSON.stringify(payload, null, 1)
});
const err = (message) => ({ content: `错误：${message}`, isError: true });

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const clamp = (n, lo, hi) => Math.max(lo, Math.min(hi, Math.round(n)));
const norm = (s) => String(s ?? '').replace(/[\s\u3000]+/g, '').toLowerCase();
const clip = (s, n) => {
  const t = String(s ?? '').trim();
  return t.length > n ? `${t.slice(0, n)}…（已截断）` : t;
};

function toArray(v) {
  if (v === null || v === undefined || v === '') return [];
  return Array.isArray(v) ? v.filter((x) => String(x).trim() !== '') : [v];
}

function conf() {
  let raw = {};
  try {
    if (apiRef && typeof apiRef.config === 'function') raw = apiRef.config() || {};
  } catch { raw = {}; }
  const num = (v, dft, lo, hi) => {
    const n = Number(v);
    if (!Number.isFinite(n)) return dft;
    return Math.max(lo, Math.min(hi, Math.round(n)));
  };
  return {
    listLimit: num(raw.listLimit, 15, 1, 50),
    requestGapMs: num(raw.requestGapMs, 350, 100, 5000),
    tagCacheMinutes: num(raw.tagCacheMinutes, 720, 0, 10080),
    cardEnabled: raw.cardEnabled !== false,          // 显式传 false 才关，其余（含缺省）都开
    cardImage: String(raw.cardImage ?? '').trim() || 'https://fecdn.luogu.com.cn/favicon.ico',
    cardMax: num(raw.cardMax, 3, 1, 10)
  };
}

// ─────────────────────────── HTTP ───────────────────────────

function absorbCookies(res) {
  let list = [];
  try {
    if (typeof res.headers.getSetCookie === 'function') list = res.headers.getSetCookie() || [];
    else {
      const raw = res.headers.get('set-cookie');
      if (raw) list = [raw];
    }
  } catch { list = []; }
  if (!list.length) return;
  const map = new Map();
  for (const pair of cookieJar.split('; ')) {
    const i = pair.indexOf('=');
    if (i > 0) map.set(pair.slice(0, i), pair.slice(i + 1));
  }
  for (const c of list) {
    const kv = String(c).split(';')[0].trim();
    const i = kv.indexOf('=');
    if (i > 0) map.set(kv.slice(0, i), kv.slice(i + 1));
  }
  cookieJar = [...map].map(([k, v]) => `${k}=${v}`).join('; ');
  cookieAt = Date.now();
}

async function rawFetch(url, options) {
  const { requestGapMs } = conf();
  const waitFor = lastRequestAt + requestGapMs - Date.now();
  if (waitFor > 0) await sleep(waitFor);
  lastRequestAt = Date.now();

  const doFetch = apiRef?.fetch ?? globalThis.fetch;
  const ac = new AbortController();
  const timer = setTimeout(() => ac.abort(), REQUEST_TIMEOUT);
  try {
    return await doFetch(url, { ...options, signal: ac.signal });
  } finally {
    clearTimeout(timer);
  }
}

/**
 * 取一个洛谷页面，自动处理 CC cookie 挑战与真实跳转。
 * @returns {Promise<{status:number, text:string, url:string}>}
 */
async function httpGet(url, { accept = 'text/html,application/xhtml+xml,application/json;q=0.9,*/*;q=0.8' } = {}, depth = 0) {
  if (depth > 5) throw new Error('洛谷返回了过多重定向，已放弃这次请求');

  // cookie 过期就丢掉，让挑战流程重新走一遍
  if (cookieJar && Date.now() - cookieAt > COOKIE_TTL) cookieJar = '';

  const headers = {
    'user-agent': UA,
    accept,
    'accept-language': 'zh-CN,zh;q=0.9,en;q=0.8',
    referer: `${BASE}/`
  };
  if (cookieJar) headers.cookie = cookieJar;

  let res;
  try {
    res = await rawFetch(url, { headers, redirect: 'manual' });
  } catch (error) {
    const m = String(error?.message ?? error);
    if (/abort/i.test(m)) throw new Error('访问洛谷超时（20 秒），请稍后再试');
    throw new Error(`无法访问洛谷：${m}`);
  }

  absorbCookies(res);

  if (res.status >= 300 && res.status < 400) {
    const loc = res.headers.get('location');
    let next = url;
    if (loc) {
      try { next = new URL(loc, url).href; } catch { next = url; }
    }
    // 同 URL = Cookie 挑战（带新 cookie 重试）；不同 URL = 真跳转（跟随）
    await sleep(300);
    return httpGet(next, { accept }, depth + 1);
  }

  let text = '';
  try { text = await res.text(); } catch { text = ''; }
  return { status: res.status, text, url };
}

/** 从页面里取出洛谷内嵌的结构化数据。 */
function parseContext(html) {
  const m = /<script id="lentille-context" type="application\/json">([\s\S]*?)<\/script>/.exec(String(html ?? ''));
  if (!m) return null;
  try { return JSON.parse(m[1]); } catch { return null; }
}

// ─────────────────────────── 标签表 ───────────────────────────

async function ensureMeta() {
  const { tagCacheMinutes } = conf();
  const fresh = tagCache && tagCacheMinutes > 0 && Date.now() - tagCache.at < tagCacheMinutes * 60000;
  if (fresh) return tagCache;

  const res = await httpGet(`${BASE}/_lfe/tags`, { accept: 'application/json' });
  if (res.status !== 200) throw new Error(`洛谷标签表获取失败（HTTP ${res.status}）`);
  let data;
  try { data = JSON.parse(res.text); } catch { throw new Error('洛谷标签表格式异常'); }
  const list = Array.isArray(data?.tags) ? data.tags : [];
  if (!list.length) throw new Error('洛谷标签表是空的');

  // 顺便刷新难度定义。洛谷改过难度体系（现在是九档 0-8），这份表必须来自
  // 官方配置而不是硬编码 —— 拉不到就退回内置兜底表，不影响主流程。
  let difficultyLevels = 0;
  try {
    const cfgRes = await httpGet(`${BASE}/_lfe/config`, { accept: 'application/json' });
    if (cfgRes.status === 200) {
      const defs = JSON.parse(cfgRes.text)?.ProblemDifficulty;
      if (Array.isArray(defs) && defs.length) {
        const next = [...DIFFICULTY_FALLBACK];
        for (const d of defs) {
          const id = Number(d?.id);
          if (Number.isInteger(id) && id >= 0 && d?.name) next[id] = String(d.name);
        }
        difficultyNames = next;
        difficultyLevels = defs.length;
      }
    }
  } catch { /* 用兜底表 */ }

  tagCache = {
    at: Date.now(),
    list,
    byId: new Map(list.map((t) => [t.id, t])),
    types: new Map((data?.types || []).map((x) => [x.id, x.name])),
    difficultyLevels
  };
  return tagCache;
}

function tagNamesOf(ids, cache) {
  return (ids || []).map((id) => cache?.byId?.get(id)?.name ?? `#${id}`).filter(Boolean);
}

/** 中文标签名 → 洛谷标签对象。算法类（type=2）优先，避免同名歧义。 */
function resolveTag(name, cache) {
  const q = norm(name);
  if (!q) return null;
  const algorithm = cache.list.filter((t) => t.type === 2);
  const pool = [...algorithm, ...cache.list];
  let hit = pool.find((t) => norm(t.name) === q);
  if (!hit) hit = pool.find((t) => norm(t.name).includes(q));
  if (!hit) hit = pool.find((t) => q.includes(norm(t.name)) && norm(t.name).length >= 2);
  return hit || null;
}

// ─────────────────────────── 难度解析 ───────────────────────────

const DIFF_ALIAS = [
  [8, ['NOI/NOI+/CTS', 'NOI/NOI+/CTSC', 'NOI+', 'CTSC', 'CTS']],
  [7, ['省选/NOI−', '省选/NOI-', '省选/NOI', '省选']],
  [6, ['提高+/省选−', '提高+/省选-', '提高+/省选']],
  [5, ['提高']],
  [4, ['普及+/提高−', '普及+/提高-', '普及+/提高', '普及+']],
  [3, ['普及']],
  [2, ['普及−', '普及-', '普及减']],
  [1, ['入门']]
];

function matchDifficultyName(input) {
  const q = norm(input).replace(/[−–—]/g, '-');
  if (!q) return null;
  for (const [level, names] of DIFF_ALIAS) {
    if (names.some((n) => norm(n).replace(/[−–—]/g, '-') === q)) return level;
  }
  const flat = [];
  for (const [level, names] of DIFF_ALIAS) {
    for (const n of names) flat.push([level, norm(n).replace(/[−–—]/g, '-')]);
  }
  flat.sort((a, b) => b[1].length - a[1].length);
  for (const [level, n] of flat) {
    if (q.includes(n) || n.includes(q)) return level;
  }
  return null;
}

/** 难度输入 → 数字数组。接受 2 / "2,3" / ["2","3"] / "普及−" / "提高+"。 */
function parseDifficulties(input) {
  const out = [];
  const unknown = [];
  for (const raw of toArray(input).flatMap((x) => String(x).split(/[,，、;；]/).filter(Boolean))) {
    const s = String(raw).trim();
    if (!s) continue;
    const n = Number(s);
    if (Number.isInteger(n) && n >= 1 && n <= MAX_DIFFICULTY) { out.push(n); continue; }
    if (Number.isInteger(n) && n === 0) { unknown.push(`「0（暂无评定）」洛谷不支持筛选，已忽略`); continue; }
    const level = matchDifficultyName(s);
    if (level !== null) out.push(level);
    else unknown.push(s);
  }
  return { levels: [...new Set(out)].sort((a, b) => a - b), unknown };
}

// ─────────────────────────── 题号与列表 ───────────────────────────

function normalizePid(input) {
  let s = String(input ?? '').trim();
  if (!s) return '';
  const fromUrl = /\/problem\/([^/?#]+)/i.exec(s);
  if (fromUrl) s = fromUrl[1];
  if (/^\d+$/.test(s)) return `P${s}`;
  // ⚠️ 只把前缀大写：AtCoder 题号形如 AT1202Contest_a，整体大写化会变成不存在的题
  return s.replace(/^(p|b|cf|sp|uva|at)(?=[0-9a-z_])/i, (x) => x.toUpperCase());
}

function buildListUrl({ page, keyword, difficulties, tagIds, type }) {
  const qs = new URLSearchParams();
  if (keyword) qs.set('keyword', keyword);
  if (difficulties?.length) qs.set('difficulty', difficulties.join(','));
  if (tagIds?.length) qs.set('tag', tagIds.join(','));
  if (type) qs.set('type', String(type).toUpperCase());
  qs.set('page', String(page));
  return `${BASE}/problem/list?${qs.toString()}`;
}

async function fetchList(params) {
  const url = buildListUrl(params);
  const res = await httpGet(url);
  if (res.status === 404) throw new Error('洛谷说这个筛选条件不存在（404），换一组条件试试');
  const ctx = parseContext(res.text);
  if (!ctx) throw new Error('没能解析洛谷返回的页面（洛谷可能改版或被限流）');
  if (ctx.status && ctx.status !== 200) throw new Error(`洛谷返回 ${ctx.status}${ctx.data?.errorMessage ? `：${ctx.data.errorMessage}` : ''}`);
  const pd = ctx?.data?.problems;
  if (!pd) throw new Error('洛谷没有返回题目数据');
  return {
    count: Number(pd.count) || 0,
    perPage: Number(pd.perPage) || 50,
    items: Array.isArray(pd.result) ? pd.result : []
  };
}

function fmtProblem(p, cache) {
  const sub = Number(p.totalSubmit) || 0;
  const acc = Number(p.totalAccepted) || 0;
  return {
    pid: p.pid,
    name: p.name,
    difficulty: difficultyName(p.difficulty),
    difficultyLevel: p.difficulty,
    tags: tagNamesOf(p.tags, cache),
    passRate: sub > 0 ? `${((acc / sub) * 100).toFixed(1)}%` : '暂无',
    submissions: sub,
    url: `${BASE}/problem/${p.pid}`
  };
}

/** 把用户的筛选描述（中文标签名等）翻译成洛谷的查询参数。 */
async function buildFilters(args) {
  const cache = await ensureMeta();
  const { levels, unknown: unknownDiff } = parseDifficulties(args.difficulty);
  const tagIds = [];
  const tagLabels = [];
  const unknownTags = [];
  for (const t of toArray(args.tags).flatMap((x) => String(x).split(/[,，、;；]/))) {
    const s = String(t).trim();
    if (!s) continue;
    const hit = resolveTag(s, cache);
    if (hit) { tagIds.push(hit.id); tagLabels.push(hit.name); }
    else unknownTags.push(s);
  }
  const type = args.type ? String(args.type).trim().toUpperCase() : '';
  if (type && !PROBLEM_TYPES[type]) {
    return { error: `不认识的题目类型「${type}」。可用：${Object.keys(PROBLEM_TYPES).join(' / ')}` };
  }
  return {
    cache,
    keyword: String(args.keyword ?? '').trim() || undefined,
    difficulties: levels,
    tagIds: [...new Set(tagIds)],
    tagLabels: [...new Set(tagLabels)],
    type: type || undefined,
    unknownTags,
    unknownDiff
  };
}

// ─────────────────────────── 卡片 ───────────────────────────

/** 卡片文案用截断（结尾就是干净的省略号，不带 clip 的「已截断」说明）。 */
function trunc(s, n) {
  const t = String(s ?? '').trim();
  return t.length > n ? `${t.slice(0, Math.max(1, n - 1))}…` : t;
}

/** 拉取单题页面并解析（luogu2__card 用；luogu2__problem 保持原实现不动，避免回归）。 */
async function fetchProblemPage(pid) {
  const res = await httpGet(`${BASE}/problem/${encodeURIComponent(pid)}`);
  const parsed = parseContext(res.text);
  if (!parsed) throw new Error('没能解析洛谷返回的页面（洛谷可能改版或被限流），稍后再试');
  const p = parsed?.data?.problem;
  if (res.status === 404 || parsed.status === 404 || !p) return { found: false, pid };
  const cache = await ensureMeta();
  return { found: true, p, cache };
}

/**
 * 把一道题做成卡片发到当前会话。
 *
 * 走 sender.sendMedia（限频/去重/留档齐全）。卡片发送失败时降级为纯文本链接 ——
 * 唯一的例外是「刚刚发过」的去重报错：那说明卡片其实已经发出去了，再发文本就重复了。
 *
 * 返回 { sent, via, deduped?, pid, title, url, note }；完全发不出去时抛错。
 */
async function pushProblemCard(ctx, p, cache, opts = {}) {
  const c = conf();
  const tags = tagNamesOf(p.tags, cache);
  const diff = difficultyName(p.difficulty);
  const url = `${BASE}/problem/${p.pid}`;
  const title = trunc(`${p.pid} ${p.name} · ${diff}`, 60);
  const desc = trunc(tags.length ? `洛谷 · ${diff} · ${tags.slice(0, 4).join(' / ')}` : `洛谷 · ${diff}`, 80);

  if (!ctx?.sender?.sendMedia || !ctx?.chatKey) {
    throw new Error('当前会话拿不到消息发送能力，发不了卡片');
  }

  const segments = [];
  const replyId = String(opts.replyToMessageId ?? '').trim();
  if (replyId) segments.push({ type: 'reply', data: { id: replyId } });
  segments.push({
    type: 'share',
    data: { url, title, content: desc, image: c.cardImage }
  });

  try {
    await ctx.sender.sendMedia(ctx.chatKey, segments, {
      label: `[卡片] ${title}`,
      dedupeKey: `luogu-card:${p.pid}`
    });
    return {
      sent: true, via: 'card', pid: p.pid, title, url,
      note: '卡片已发到当前会话，点卡片就能打开洛谷原题。不要再把同样的链接或题面重复发一遍。'
    };
  } catch (error) {
    const msg = String(error?.message ?? error);
    if (msg.includes('刚刚发过')) {
      return { sent: true, via: 'card', deduped: true, pid: p.pid, title, url, note: '这张卡片刚刚已经发过了，跳过（防刷屏去重）。' };
    }
    // 卡片被协议端/QQ 拒了 → 降级成纯文本，链接本身也能点
    await ctx.sender.sendTextBatch(ctx.chatKey, [`${title}\n${desc}\n${url}`], {
      replyToMessageId: replyId || null
    });
    return {
      sent: true, via: 'text', pid: p.pid, title, url,
      reason: msg,
      note: `卡片没发出去（${msg}），已改发带链接的纯文本，对方同样能点进洛谷原题。`
    };
  }
}

// ─────────────────────────── 工具 ───────────────────────────

export async function setup(api) {
  apiRef = api;

  // ── 1. 按题号查题 ────────────────────────────────────────────
  api.registerTool({
    id: 'problem',
    name: '查询洛谷题目',
    description: '按题号查询洛谷题目，返回题目名称、难度分级、算法/知识点分类、通过率、时间与内存限制、题目链接。用户贴出题号（P1001 / B2001 / CF1A / SP1 / UVA100）或问「这道题是什么」时使用。',
    category: 'query',
    icon: '📗',
    parameters: {
      type: 'object',
      properties: {
        pid: { type: 'string', description: '题号，如 P1001、B2001、CF1A、SP1、UVA100，也可以直接贴题目链接' },
        withContent: { type: 'boolean', description: '是否附带题面（描述、输入输出格式、样例）。默认否，只给题目信息' }
      },
      required: ['pid']
    },
    async execute(_ctx, args = {}) {
      try {
        const pid = normalizePid(args.pid);
        if (!pid) return err('请给出题号，例如 P1001、B2001、CF1A、SP1、UVA100');

        const res = await httpGet(`${BASE}/problem/${encodeURIComponent(pid)}`);
        const ctx = parseContext(res.text);

        if (!ctx) return err('没能解析洛谷返回的页面（洛谷可能改版或被限流），稍后再试');
        const p = ctx?.data?.problem;
        if (res.status === 404 || ctx.status === 404 || !p) {
          return ok({
            found: false,
            pid,
            note: `洛谷上没有找到题目 ${pid}。常见题号格式：P1001（洛谷原创）、B2001（入门与面试）、CF1A（Codeforces）、SP1（SPOJ）、UVA100（UVa）、AT1202Contest_a（AtCoder）。如果题号没问题，也可能是这道题已被删除或编号有误。`
          });
        }

        const cache = await ensureMeta();
        const out = fmtProblem(p, cache);
        const lim = p.limits || {};
        if (Array.isArray(lim.time) && lim.time.length) out.timeLimit = `${lim.time[0]}ms`;
        if (Array.isArray(lim.memory) && lim.memory.length) out.memoryLimit = `${Math.round(lim.memory[0] / 1024)}MB`;
        if (p.fullScore) out.fullScore = p.fullScore;
        if (p.type) out.problemType = PROBLEM_TYPES[String(p.type).toUpperCase()] || p.type;

        if (args.withContent === true) {
          const c = p.contenu || p.content || {};
          const desc = String(c.description ?? '');
          out.content = {
            background: clip(c.background, 400) || undefined,
            description: clip(desc, 1500),
            inputFormat: clip(c.formatI, 500) || undefined,
            outputFormat: clip(c.formatO, 500) || undefined,
            samples: (Array.isArray(p.samples) ? p.samples : []).slice(0, 2)
              .map((s) => ({ input: clip(s?.[0], 300), output: clip(s?.[1], 300) })),
            truncated: desc.length > 1500
          };
        }

        return ok(out);
      } catch (error) {
        return err(error?.message ?? error);
      }
    }
  });

  // ── 2. 搜索 / 筛选题目 ────────────────────────────────────────
  api.registerTool({
    id: 'search',
    name: '搜索洛谷题目',
    description: '按关键词、难度、算法标签、题目来源筛选洛谷题目列表。想找「一批题」（而不是已知题号）时使用，例如「有没有关于背包的普及−题」「图论的提高题有哪些」。',
    category: 'query',
    icon: '🔎',
    parameters: {
      type: 'object',
      properties: {
        keyword: { type: 'string', description: '标题/题面关键词，如「背包」「最短路」（可选）' },
        difficulty: { type: 'string', description: '难度，数字 1-8（1 入门 / 2 普及− / 3 普及 / 4 普及+/提高− / 5 提高 / 6 提高+/省选− / 7 省选/NOI− / 8 NOI/NOI+/CTS）。多个用逗号，如 "2,3"（可选）' },
        tags: { type: 'string', description: '知识点标签，中文名，多个用逗号分隔，如「动态规划,图论」（可选）' },
        type: { type: 'string', description: '题目来源：P 洛谷原创 / B 入门与面试 / CF Codeforces / SP SPOJ / AT AtCoder / UVA UVa / T 团队题目（可选，默认全站）' },
        page: { type: 'integer', description: '页码，从 1 开始，每页 50 题。默认 1' },
        limit: { type: 'integer', description: '最多返回几道题，默认取技能设置值（15）' }
      }
    },
    async execute(_ctx, args = {}) {
      try {
        const f = await buildFilters(args);
        if (f.error) return err(f.error);

        const page = Math.max(1, Math.round(Number(args.page) || 1));
        const limit = clamp(Number(args.limit) || conf().listLimit, 1, 50);
        const { count, perPage, items } = await fetchList({
          page, keyword: f.keyword, difficulties: f.difficulties, tagIds: f.tagIds, type: f.type
        });

        const notes = [];
        if (f.unknownTags.length) {
          // 标签全没识别出来时，洛谷会返回全库结果 —— 必须点破，
          // 否则模型会以为「筛选过了」，把一堆无关题目当成筛选结果报出去。
          notes.push(f.tagIds.length
            ? `这些标签洛谷里没找到，已忽略：${f.unknownTags.join('、')}`
            : `标签「${f.unknownTags.join('、')}」在洛谷里都不存在，因此**这次没有按知识点筛选**，下面是全库结果。先用 luogu2__tags 查一下正确的标签名。`);
        }
        if (f.unknownDiff.length) notes.push(`没能识别的难度：${f.unknownDiff.join('、')}`);
        if (count === 0) notes.push('没有符合这些条件的题目，放宽一点条件再试。');

        return ok({
          total: count,
          page,
          totalPages: perPage > 0 ? Math.max(1, Math.ceil(count / perPage)) : 1,
          filter: {
            keyword: f.keyword,
            difficulty: f.difficulties.map(difficultyName),
            tags: f.tagLabels.length ? f.tagLabels : undefined,
            type: f.type ? `${f.type}（${PROBLEM_TYPES[f.type]}）` : undefined
          },
          problems: items.slice(0, limit).map((p) => fmtProblem(p, f.cache)),
          note: notes.length ? notes.join('；') : undefined
        });
      } catch (error) {
        return err(error?.message ?? error);
      }
    }
  });

  // ── 3. 随机抽题（出题）────────────────────────────────────────
  api.registerTool({
    id: 'random',
    name: '随机抽题（出题）',
    description: '从洛谷真实题库里随机抽题，抽出的题目自带洛谷的难度分级和算法分类。要给群友出题、找练习题、说「来一题」时使用。可按难度、知识点、关键词、来源限定范围。绝不要自己凭记忆编题号。',
    category: 'query',
    icon: '🎲',
    parameters: {
      type: 'object',
      properties: {
        difficulty: { type: 'string', description: '难度范围，数字 1-8（1 入门 / 2 普及− / 3 普及 / 4 普及+/提高− / 5 提高 / 6 提高+/省选− / 7 省选/NOI− / 8 NOI/NOI+/CTS），多个用逗号如 "2,3"。不传则全难度' },
        tags: { type: 'string', description: '知识点标签，中文名，多个用逗号，如「动态规划」（可选）' },
        keyword: { type: 'string', description: '标题/题面关键词（可选）' },
        type: { type: 'string', description: '题目来源 P/B/CF/SP/AT/UVA/T（可选）' },
        count: { type: 'integer', description: '抽几道，默认 1，最多 10' },
        avoid: { type: 'string', description: '不要抽到的题号，多个用逗号分隔（把刚出过的题填进来避免重复）' },
        asCard: { type: 'boolean', description: '抽到后直接把题目做成可点击卡片发到当前聊天（点卡片就打开洛谷原题）。出题时建议传 true' }
      }
    },
    async execute(ctx, args = {}) {
      try {
        const f = await buildFilters(args);
        if (f.error) return err(f.error);

        const want = clamp(Number(args.count) || 1, 1, 10);
        const avoid = new Set(toArray(args.avoid)
          .flatMap((x) => String(x).split(/[,，、\s]+/))
          .map((x) => normalizePid(x).toUpperCase())
          .filter(Boolean));

        const base = { keyword: f.keyword, difficulties: f.difficulties, tagIds: f.tagIds, type: f.type };
        const first = await fetchList({ ...base, page: 1 });
        if (first.count === 0) {
          return ok({
            total: 0,
            picks: [],
            note: '洛谷题库里没有符合这些条件的题目，把难度或知识点放宽一点再试。'
          });
        }

        const perPage = first.perPage || 50;
        const totalPages = Math.max(1, Math.ceil(first.count / perPage));

        // 候选池：第 1 页 + 至多 2 个随机页（避免请求过多，同时保证随机性）
        const pool = [...first.items];
        let extraPages = Math.min(2, totalPages - 1);
        while (extraPages-- > 0) {
          const page = Math.floor(Math.random() * totalPages) + 1;
          if (page === 1) continue;
          try {
            const r = await fetchList({ ...base, page });
            pool.push(...r.items);
          } catch { /* 某一页失败不影响整体 */ }
        }

        const seen = new Set(avoid);
        const picks = [];
        const candidates = () => pool.filter((p) => p.difficulty >= 1 && !seen.has(String(p.pid).toUpperCase()));
        while (picks.length < want) {
          const cands = candidates();
          if (!cands.length) break;
          const pick = cands[Math.floor(Math.random() * cands.length)];
          seen.add(String(pick.pid).toUpperCase());
          picks.push(pick);
        }

        const notes = [];
        if (f.unknownTags.length) {
          notes.push(f.tagIds.length
            ? `这些标签洛谷里没找到：${f.unknownTags.join('、')}`
            : `标签「${f.unknownTags.join('、')}」在洛谷里都不存在，所以这次**没有按知识点筛**，是从全库里抽的。`);
        }
        if (f.unknownDiff.length) notes.push(`没能识别的难度：${f.unknownDiff.join('、')}`);
        // 对方没指定难度、却抽到了神仙题：提醒模型这可能不合适，别直接甩给初学者
        // （7=省选/NOI−、8=NOI/NOI+/CTS；6=提高+/省选− 对多数人还算能做，不算“神仙题”）
        const tooHard = picks.filter((p) => p.difficulty >= 7);
        if (tooHard.length && !f.difficulties.length) {
          notes.push(`注意：抽到了难度很高的题（${tooHard.map((p) => p.pid).join('、')}，${tooHard.map((p) => difficultyName(p.difficulty)).join('/')}）。如果对方不是竞赛水平，建议指定 difficulty="2,3" 重新抽。`);
        }
        notes.push('把难度分级和算法分类如实报给对方（例如「P1048 采药 · 普及− · 动态规划 DP」），并附上链接。');

        // 出题顺手发卡片：对方点卡片就进洛谷原题。
        // 一次最多 cardMax 张（默认 3），多了刷屏；某一张失败不影响其余的。
        const cards = [];
        if (args.asCard === true && picks.length) {
          const c = conf();
          if (!c.cardEnabled) {
            notes.push('想在出题时直接发卡片，可在技能设置里打开 cardEnabled。');
          } else {
            const cardPicks = picks.slice(0, c.cardMax);
            if (cardPicks.length < picks.length) notes.push(`只发了前 ${c.cardMax} 张卡片（设置的上限），其余题目用文字报。`);
            for (const p of cardPicks) {
              try {
                const r = await pushProblemCard(ctx, p, f.cache);
                cards.push({ pid: r.pid, via: r.via, deduped: r.deduped ?? undefined });
              } catch (error) {
                cards.push({ pid: String(p.pid), via: 'failed', error: String(error?.message ?? error) });
                notes.push(`「${p.pid}」的卡片没发出去：${String(error?.message ?? error)}`);
              }
            }
          }
        }
        if (cards.length) notes.push(`已发 ${cards.filter((x) => x.via !== 'failed').length} 张题目卡片。`);

        return ok({
          totalInRange: first.count,
          picked: picks.length,
          cardsSent: cards.length ? cards : undefined,
          filter: {
            difficulty: f.difficulties.length ? f.difficulties.map(difficultyName) : '不限',
            tags: f.tagLabels.length ? f.tagLabels : undefined,
            keyword: f.keyword,
            type: f.type ? `${f.type}（${PROBLEM_TYPES[f.type]}）` : undefined
          },
          problems: picks.map((p) => fmtProblem(p, f.cache)),
          note: notes.join('；')
        });
      } catch (error) {
        return err(error?.message ?? error);
      }
    }
  });

  // ── 4. 分类体系 ──────────────────────────────────────────────
  api.registerTool({
    id: 'tags',
    name: '查看洛谷分类体系',
    description: '查看洛谷的难度分级表（八档）和题目标签分类（算法/来源/地区/时间/特殊）。不确定某个知识点在洛谷叫什么标签、或不确定难度怎么表达时先查这个。也可以传入关键词搜索标签名。',
    category: 'query',
    icon: '🏷️',
    parameters: {
      type: 'object',
      properties: {
        keyword: { type: 'string', description: '按名称搜索标签，如「背包」「二分」「NOIP」（可选。不传则返回难度表和分类概览）' }
      }
    },
    async execute(_ctx, args = {}) {
      try {
        const cache = await ensureMeta();
        const kw = String(args.keyword ?? '').trim();

        if (kw) {
          const q = norm(kw);
          const hits = cache.list.filter((t) => norm(t.name).includes(q)).slice(0, 40);
          return ok({
            query: kw,
            matched: hits.map((t) => ({
              name: t.name,
              category: cache.types.get(t.type) || '其他',
              id: t.id
            })),
            found: hits.length,
            note: hits.length
              ? '把这些名字直接填进 luogu2__search / luogu2__random 的 tags 参数即可（技能会自动换算成洛谷的内部编号）。'
              : `洛谷的标签里没有含「${kw}」的，换个说法再搜。`
          });
        }

        const byType = new Map();
        for (const t of cache.list) {
          const name = cache.types.get(t.type) || '其他';
          if (!byType.has(name)) byType.set(name, []);
          byType.get(name).push(t.name);
        }
        const algorithm = byType.get('算法') || [];

        return ok({
          difficulty: difficultyNames.map((name, level) => ({ level, name })).filter((d) => d.level >= 1),
          difficultyNote: 'difficulty 参数传 1-8 的数字；0 是「暂无评定」，洛谷不支持按它筛选。上面这份表直接来自洛谷官方配置。',
          totalTags: cache.list.length,
          categories: [...byType].map(([name, names]) => ({ name, count: names.length })),
          commonAlgorithmTags: algorithm.slice(0, 45),
          problemTypes: PROBLEM_TYPES,
          note: '想找具体标签就用 keyword 搜（如「背包」「二分」）；标签名可以随便写中文，技能会自动匹配到洛谷的内部标签。'
        });
      } catch (error) {
        return err(error?.message ?? error);
      }
    }
  });

  // ── 5. 题目卡片（点进去就是洛谷原题）─────────────────────────
  api.registerTool({
    id: 'card',
    name: '发洛谷题目卡片',
    description: '把一道洛谷题目做成可点击的卡片发到当前聊天——群友点一下卡片就直接打开洛谷原题页面。已经知道题号（比如刚用 luogu2__problem / luogu2__random 查到，或对方贴了题号）想让对方「点开就能做题」时使用。一次发一道；要一次出好几道并都发卡片，直接用 luogu2__random 传 asCard=true。',
    category: 'messaging',
    icon: '🎴',
    parameters: {
      type: 'object',
      properties: {
        pid: { type: 'string', description: '题号，如 P1001、B2001、CF1A、SP1、UVA100，也可以直接贴题目链接' },
        replyToMessageId: { type: ['integer', 'string'], description: '要引用/回复的消息 id（可选，卡片会以引用的形式发出）' }
      },
      required: ['pid']
    },
    async execute(ctx, args = {}) {
      try {
        const c = conf();
        if (!c.cardEnabled) return err('卡片功能已在技能设置里关闭（cardEnabled）。');
        const pid = normalizePid(args.pid);
        if (!pid) return err('请给出题号，例如 P1001、B2001、CF1A、SP1、UVA100');

        const page = await fetchProblemPage(pid);
        if (!page.found) {
          return ok({
            found: false,
            pid,
            note: `洛谷上没有找到题目 ${pid}，发不了卡片。题号格式：P1001（洛谷原创）、B2001（入门与面试）、CF1A（Codeforces）、SP1（SPOJ）、UVA100（UVa）、AT1202Contest_a（AtCoder）。`
          });
        }
        return ok(await pushProblemCard(ctx, page.p, page.cache, { replyToMessageId: args.replyToMessageId }));
      } catch (error) {
        return err(error?.message ?? error);
      }
    }
  });
}
