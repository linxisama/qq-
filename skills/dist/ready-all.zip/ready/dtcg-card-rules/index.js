// 数码宝贝卡牌对战（DTCG）规则顾问（Skill / LLM 型）。
//
// 干什么：群里有人问 DTCG 的规则、裁定、禁限卡、卡牌效果修正时，模型调用这里的检索工具，
// 从 kb/ 里 18 份官方/汉化文档的**原文**里找出相关段落，再据此回答并注明出处。
//
// 为什么是"技能"而不是"插件"：插件（plugins/）只能在核心预留的固定能力点上被动执行，
// 没有"任意一句话触发"的挂载点；只有 registerTool 能让模型在识别到意图时主动调用。
//
// 为什么原文要预先抽成 txt：这些文档是 PDF，运行时解析 PDF 又慢又要额外依赖；
// 抽取一次存成纯文本，检索是纯内存字符串匹配，毫秒级，且不依赖网络。
//
// 为什么不拆文件：宿主热重载只对入口文件做 cache-bust，相对 import 会被模块缓存
// （改了不生效还不报错），所以本技能的全部逻辑都放在这一个文件里。

import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const KB_DIR = path.join(HERE, 'kb');
const INDEX_FILE = path.join(HERE, 'index-kb.json');

let cfg = () => ({});
let log = () => {};
let warn = () => {};

// 知识库只读一次（首次检索时），之后常驻内存：18 份文档约 20 万字，检索是纯 CPU 字符串匹配。
let CACHE = null;

export function setup(api) {
  if (api && typeof api.config === 'function') cfg = api.config;
  if (api && typeof api.log === 'function') log = api.log;
  if (api && typeof api.warn === 'function') warn = api.warn;

  api.registerTool({
    id: 'search',
    name: '检索数码宝贝卡牌规则原文',
    description: '在本地收录的数码宝贝卡牌对战（DTCG）规则文档里检索原文。凡是问到规则条文、效果处理、裁定、禁限卡、卡牌修正，先调用本工具。query 填问题里的关键词（如「安防区 确认」「进化 时点」「BT1-010 修正」），不要填整句话。',
    category: 'knowledge',
    icon: '📚',
    defaultEnabled: true,
    parameters: {
      type: 'object',
      properties: {
        query: { type: 'string', description: '检索关键词：卡名/卡号/规则术语，多个关键词用空格分开' },
        topK: { type: 'number', description: '返回几段原文，默认用配置值（4）' }
      },
      required: ['query']
    },
    execute(ctx, args) {
      try {
        const query = String(args?.query || '').trim();
        if (!query) return errMsg('query 不能为空');
        const docs = loadKb();
        if (!docs.length) return errMsg('知识库为空：kb/ 目录里没有可用文档，请检查技能安装是否完整');

        const s = settings();
        const topK = clampInt(args?.topK, 1, 8, s.topK);
        const hits = search(docs, query, topK);
        if (!hits.length) {
          return ok(`没有检索到与「${query}」相关的原文。\n可以换个说法（用规则术语、卡号或卡名）再试；若确实没有，请告诉群友资料里未收录，不要自行猜测。`);
        }

        const blocks = [];
        let used = 0;
        if (hits[0].loose) {
          blocks.push('（没有精确命中，以下是低置信度参考；若不对，请告诉群友资料里没找到，不要硬套）');
          used += 40;
        }
        for (const h of hits) {
          const block = `【${h.title}】第 ${h.page} 页\n${h.snippet}`;
          if (used + block.length > s.maxChars && blocks.length) break;
          blocks.push(block);
          used += block.length;
        }
        return ok(blocks.join('\n\n---\n\n'));
      } catch (e) {
        return errMsg(`检索失败：${(e && e.message) || e}`);
      }
    }
  });

  api.registerTool({
    id: 'page',
    name: '查阅规则文档某一页',
    description: '检索结果里提到某份文档的某一页、需要看完整原文时调用。doc 填文档标题（或标题片段，如「综合规则 V2.3」），page 填页码。',
    category: 'knowledge',
    icon: '📄',
    defaultEnabled: true,
    parameters: {
      type: 'object',
      properties: {
        doc: { type: 'string', description: '文档标题或标题片段' },
        page: { type: 'number', description: '页码（从 1 开始）' }
      },
      required: ['doc', 'page']
    },
    execute(ctx, args) {
      try {
        const docs = loadKb();
        const key = String(args?.doc || '').trim();
        const pageNo = Number(args?.page);
        if (!key) return errMsg('doc 不能为空');
        const doc = matchDoc(docs, key);
        if (!doc) return errMsg(`没找到标题含「${key}」的文档。可用 dtcg-card-rules__docs 查看全部文档名。`);
        const pg = doc.pages.find((p) => p.page === pageNo);
        if (!pg) {
          const range = doc.pages.length ? `1～${doc.pages[doc.pages.length - 1].page}` : '无内容';
          return errMsg(`《${doc.title}》没有第 ${pageNo} 页（可用页码：${range}）`);
        }
        const s = settings();
        const text = pg.text.length > s.pageChars ? `${pg.text.slice(0, s.pageChars)}\n…（本页较长，已截断）` : pg.text;
        return ok(`【${doc.title}】第 ${pg.page} 页\n${text}`);
      } catch (e) {
        return errMsg(`读取失败：${(e && e.message) || e}`);
      }
    }
  });

  api.registerTool({
    id: 'docs',
    name: '列出规则文档清单',
    description: '列出本地收录了哪些数码宝贝卡牌对战规则文档（标题、类型、页数、内容简介），以及哪些官方文档是图片版未收录。不确定该查哪份文档时先调用它。',
    category: 'knowledge',
    icon: '🗂️',
    defaultEnabled: true,
    parameters: { type: 'object', properties: {} },
    execute() {
      try {
        const docs = loadKb();
        const lines = ['本地收录的规则文档：'];
        for (const d of docs.filter((x) => x.searchable)) {
          lines.push(`· ${d.title}（${d.kind}${d.date ? `，${d.date}` : ''}，${d.pages.length} 页）—— ${d.summary}`);
        }
        const note = docs.find((x) => !x.searchable);
        if (note && note.pages.length) {
          lines.push('', note.pages.map((p) => p.text).join('\n'));
        }
        return ok(lines.join('\n'));
      } catch (e) {
        return errMsg(`读取失败：${(e && e.message) || e}`);
      }
    }
  });

  log('ready（dtcg-card-rules 1.0.0，知识库待首次检索时加载）');
}

// ── 配置 ──────────────────────────────────────────────────────────────────

function settings() {
  const raw = (typeof cfg === 'function' ? cfg() : null) || {};
  return {
    topK: clampInt(raw.topK, 1, 8, 4),
    maxChars: clampInt(raw.maxChars, 600, 8000, 2400),
    pageChars: clampInt(raw.pageChars, 400, 6000, 1600)
  };
}

function clampInt(v, lo, hi, dflt) {
  const n = Number(v);
  if (!Number.isFinite(n)) return dflt;
  return Math.min(hi, Math.max(lo, Math.round(n)));
}

// ── 知识库加载 ────────────────────────────────────────────────────────────

function loadKb() {
  if (CACHE) return CACHE;
  const docs = [];
  let meta = [];
  try {
    meta = JSON.parse(fs.readFileSync(INDEX_FILE, 'utf8'));
  } catch (e) {
    warn(`读取 index-kb.json 失败：${(e && e.message) || e}`);
    meta = [];
  }
  for (const m of meta) {
    const file = path.join(KB_DIR, m.file);
    if (!fs.existsSync(file)) {
      warn(`缺少知识库文件：${m.file}`);
      continue;
    }
    let raw = '';
    try {
      raw = fs.readFileSync(file, 'utf8');
    } catch (e) {
      warn(`读取 ${m.file} 失败：${(e && e.message) || e}`);
      continue;
    }
    docs.push({
      title: m.title,
      kind: m.kind || '',
      date: m.date || '',
      summary: m.summary || '',
      searchable: m.file !== '图片版文档清单.txt',
      pages: splitPages(raw)
    });
  }
  CACHE = docs;
  log(`知识库已加载：${docs.length} 份文档，${docs.reduce((a, d) => a + d.pages.length, 0)} 页`);
  return docs;
}

/** 按 "===== 第 N 页 =====" 切页；没有标记的整份当一页。 */
function splitPages(raw) {
  const marks = [...raw.matchAll(/===== 第 (\d+) 页 =====/g)];
  const pages = [];
  if (!marks.length) {
    const text = raw.trim();
    return text ? [{ page: 1, text }] : [];
  }
  for (let i = 0; i < marks.length; i += 1) {
    const start = marks[i].index + marks[i][0].length;
    const end = i + 1 < marks.length ? marks[i + 1].index : raw.length;
    const text = raw.slice(start, end).trim();
    if (text) pages.push({ page: Number(marks[i][1]), text });
  }
  return pages;
}

// ── 检索 ──────────────────────────────────────────────────────────────────

/**
 * 中文没有空格分词，这里用"关键词组合"打分：
 *   2 字片段（低权重）→ 3 字片段（高权重）→ 整句命中（额外加分）→ 卡号/英文（最高权重）
 * 命中次数有上限（同一词刷屏不涨分），避免长文档靠篇幅取胜。
 */
function termsOf(query) {
  const q = normalizeQuery(query);
  const weights = new Map();
  const add = (term, w) => {
    if (!term) return;
    weights.set(term, Math.max(weights.get(term) || 0, w));
  };

  for (const seg of q.split(' ').filter(Boolean)) {
    // 卡号/英文/数字：BT1-010、stc-03、706 这类，最具区分度
    if (/^[a-z]{1,5}-?\d+[a-z0-9-]*$/i.test(seg)) { add(seg, 3.2); continue; }
    if (/^[a-z0-9-]{2,}$/i.test(seg)) { add(seg, 2.0); continue; }
    const cjk = seg.replace(/[^\u4e00-\u9fa5]+/g, '');
    if (!cjk) continue;
    if (cjk.length === 1) { add(cjk, 0.25); continue; }
    for (let i = 0; i + 1 < cjk.length; i += 1) add(cjk.slice(i, i + 2), 0.8);
    for (let i = 0; i + 2 < cjk.length; i += 1) add(cjk.slice(i, i + 3), 2.2);
  }
  return weights;
}

/**
 * 口语说法 → 官方文档用词。
 * 不做这一步的话，「禁限卡」「勘误」这类群友常用词在原文里一个都搜不到 ——
 * 原文写的是「禁止·限制卡牌」「卡牌修正」。
 */
const SYNONYMS = [
  [/禁限卡|禁限|禁卡|禁止卡表|限制卡表|小黑屋|banned/g, ' 禁止 限制 '],
  [/勘误|错印|印错|文本错误|效果写错/g, ' 卡牌修正 '],
  [/faq|常见问题|问答/g, ' q&a '],
  [/规则书|规则集/g, ' 综合规则 '],
  [/先后攻|先攻后攻/g, ' 先攻 '],
  [/手牌上限/g, ' 手牌 上限 ']
];

function normalizeQuery(query) {
  let q = String(query || '').toLowerCase().replace(/[\s\u3000]+/g, ' ').trim();
  for (const [re, to] of SYNONYMS) q = q.replace(re, to);
  return q.replace(/[\s\u3000]+/g, ' ').trim();
}

/** 兜底用的单字权重：整句都搜不到时，按"命中几个不同的字"粗略排序。 */
function charTermsOf(query) {
  const weights = new Map();
  for (const ch of normalizeQuery(query).replace(/[^\u4e00-\u9fa5]/g, '')) {
    if (!weights.has(ch)) weights.set(ch, 0.12);
  }
  return weights;
}

function countOccurrences(haystack, needle) {
  if (!needle) return 0;
  let count = 0;
  let idx = haystack.indexOf(needle);
  while (idx !== -1) {
    count += 1;
    if (count >= 6) break;
    idx = haystack.indexOf(needle, idx + needle.length);
  }
  return count;
}

function search(docs, query, topK) {
  const hits = rank(docs, query, termsOf(query));
  if (hits.length) return finalizeHits(hits, topK);
  // 整句/词组一个都没命中：退到单字匹配，宁可给"低置信参考"也不要直接说没有
  const loose = rank(docs, query, charTermsOf(query), true);
  return finalizeHits(loose, topK);
}

const VERSIONED_KINDS = new Set(['卡牌修正', '译名说明', '裁定变更', '规则修订', '禁限卡表']);

function rank(docs, query, weights, loose = false) {
  if (!weights.size) return [];
  const phrase = normalizeQuery(query).replace(/[\s]+/g, '');
  const hits = [];

  for (const doc of docs) {
    if (!doc.searchable) continue;
    const titleLower = `${doc.title} ${doc.kind}`.toLowerCase();
    for (const pg of doc.pages) {
      const text = pg.text.toLowerCase();
      const compact = text.replace(/\s+/g, '');
      let score = 0;
      let anchorTerm = '';
      let anchorScore = 0;
      let matchedTerms = 0;
      for (const [term, w] of weights) {
        const c = countOccurrences(text, term);
        if (!c) continue;
        matchedTerms += 1;
        score += w * Math.min(c, 4);
        if (w * Math.min(c, 4) > anchorScore) { anchorScore = w * Math.min(c, 4); anchorTerm = term; }
      }
      if (!score) continue;
      // 单字兜底：只命中一两个字不算数，至少 3 个不同字才算"可能相关"
      if (loose && matchedTerms < 3) continue;
      if (!loose && phrase.length >= 4 && compact.includes(phrase)) score += 6;
      for (const [term, w] of weights) {
        if (titleLower.includes(term)) score += w * 0.6;
      }
      // 版本加成：卡牌修正/译名说明这类文档是累积式的，旧版内容整段出现在新版里。
      // 不加这一点，命中 9.0 和命中 26.5.22 分数一样，去重后就可能留下旧版本。
      if (VERSIONED_KINDS.has(doc.kind)) {
        const year = Number(String(doc.date || '').slice(0, 4)) || 2022;
        score += Math.max(0, year - 2022) * 0.8;
      }
      hits.push({ doc, page: pg.page, text: pg.text, score, anchorTerm, loose });
    }
  }

  hits.sort((a, b) => b.score - a.score);
  return hits;
}

function finalizeHits(hits, topK) {
  const out = [];
  const seen = new Set();
  for (const h of hits) {
    const key = `${h.doc.title}#${h.page}`;
    if (seen.has(key)) continue;
    seen.add(key);
    const item = {
      title: h.doc.title,
      page: h.page,
      date: h.doc.date || '',
      score: Math.round(h.score * 10) / 10,
      loose: Boolean(h.loose),
      snippet: snippetOf(h.text, h.anchorTerm, 420)
    };
    // 官方文件是"累积式"的：卡牌修正 6.0 的内容几乎整段出现在 8.0 / 9.0 里。
    // 同一段话命中多处时只留日期最新的那份，否则一次检索会返回 3～4 块几乎一样的文字，
    // 既浪费上下文，也可能让模型引用一个已经过时的版本。
    const dup = out.find((o) => similarText(o.snippet, item.snippet) >= 0.85);
    if (dup) {
      if (item.date > dup.date) Object.assign(dup, item);
      continue;
    }
    out.push(item);
    if (out.length >= topK) break;
  }
  return out;
}

/** 粗略判断两段文字是否"同一段话"：6 字滑窗覆盖率。 */
function similarText(a, b) {
  const norm = (s) => s.replace(/[\s，。、；：！？""''（）《》【】·…—~\-]/g, '');
  const A = norm(a);
  const B = norm(b);
  if (A.length < 24 || B.length < 24) return A === B ? 1 : 0;
  const set = new Set();
  for (let i = 0; i + 6 <= B.length; i += 2) set.add(B.slice(i, i + 6));
  let hit = 0;
  let total = 0;
  for (let i = 0; i + 6 <= A.length; i += 2) {
    total += 1;
    if (set.has(A.slice(i, i + 6))) hit += 1;
  }
  return total ? hit / total : 0;
}

/** 截取命中词周围的一段，尽量在标点/换行处断开，不要从半个词开始。 */
function snippetOf(text, anchor, budget) {
  const flat = String(text).replace(/[ \t]+/g, ' ').replace(/\n{2,}/g, '\n').trim();
  if (flat.length <= budget) return flat;
  let at = anchor ? flat.toLowerCase().indexOf(anchor) : -1;
  if (at < 0) at = 0;
  let start = Math.max(0, at - Math.floor(budget / 3));
  let end = Math.min(flat.length, start + budget);
  if (start > 0) {
    const cut = flat.lastIndexOf('\n', start);
    if (cut > start - 120 && cut >= 0) start = cut + 1;
  }
  if (end < flat.length) {
    const nl = flat.indexOf('\n', end - 120);
    if (nl !== -1 && nl < end + 120) end = nl;
  }
  const head = start > 0 ? '…' : '';
  const tail = end < flat.length ? '…' : '';
  return `${head}${flat.slice(start, end).trim()}${tail}`;
}

function matchDoc(docs, key) {
  const k = key.toLowerCase();
  return docs.find((d) => d.title.toLowerCase().includes(k))
    || docs.find((d) => k.includes(d.title.toLowerCase()))
    || null;
}

// ── 工具返回约定（对齐内置工具：content 给模型看，isError 标错）──────────

function ok(payload) {
  return { content: typeof payload === 'string' ? payload : JSON.stringify(payload) };
}

function errMsg(message) {
  return { content: `错误：${message}`, isError: true };
}
