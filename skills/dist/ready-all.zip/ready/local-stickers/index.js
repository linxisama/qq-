/**
 * 本地表情包库（LLM 型技能）
 * ============================================================================
 * 解决什么问题
 * ---------------------------------------------------------------------------
 * QQ Agent 原本只能发两类图：
 *   1. QQ 收藏表情（send_sticker）—— 必须已经收藏进 QQ，或转存到受控目录；
 *   2. 网图（send_image）—— 只收 http(s) 直链，源码里明确拒绝本地文件路径。
 * 所以「硬盘上有一堆表情包、但没收藏进 QQ」是发不出去的。本技能补上这条通路。
 *
 * 判定为「技能」而不是「插件」的原因（见 plugin-loader.js 的语义约定）
 * ---------------------------------------------------------------------------
 * 插件的 providers/hooks 由核心代码按能力名取用，不经过 LLM；而"接梗、吐槽、
 * 附和时该配哪张图"必须理解语境，规则写不死 —— 只有 registerTool 注册的工具
 * 才会进模型的 function 列表，用不用、用哪张由模型自己判断。故放 skills/。
 *
 * 设计要点
 * ---------------------------------------------------------------------------
 * · 发送复用核心管道 ctx.sender.sendImage(chatKey,{file})：限频、去重、留档、
 *   file:// 失败自动回退 base64 —— 全部由核心负责，本技能不自己调 OneBot。
 * · 图片路径受控在 DATA_DIR/local-stickers/files/ 下（先复制再发），
 *   绝不把任意磁盘路径交给协议端，避免"图库被污染 → 发走宿主敏感文件"。
 * · 含义靠"看图 → 写备注"沉淀：源目录里 700+ 个文件名基本是 UUID/哈希，
 *   没有可用的语义信息，所以模型必须自己看图并写下含义，库才越用越准。
 */
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';

export const name = 'local-stickers';
export const inject = [];

const HERE = path.dirname(fileURLToPath(import.meta.url));
/** 技能位于 <APP_ROOT>/skills/<id>/，故 APP_ROOT 是上两级。 */
const APP_ROOT = path.resolve(HERE, '..', '..');

/** 图片扩展名（OneBot 能发的那几种）。 */
const IMAGE_EXTS = new Set(['.png', '.jpg', '.jpeg', '.webp', '.gif', '.bmp']);
/** 单文件上限：超过就跳过，免得一次读取把内存打爆。 */
const MAX_FILE_BYTES = 8 * 1024 * 1024;
/** 一次扫描最多收录多少张（防止误指到超大目录时卡死）。 */
const MAX_INDEX_ENTRIES = 5000;

/** 数据目录：优先环境变量，其次 <APP_ROOT>/data（多实例时 data-2 由环境变量给出）。 */
function resolveDataDir() {
  const env = String(process.env.QQ_AGENT_DATA_DIR || '').trim();
  if (env) return env;
  return path.join(APP_ROOT, 'data');
}

const DATA_DIR = resolveDataDir();
const STORE_DIR = path.join(DATA_DIR, 'local-stickers');
const FILES_DIR = path.join(STORE_DIR, 'files');
const INDEX_FILE = path.join(STORE_DIR, 'index.json');

/** 判断 target 是否在 root 目录内（防路径穿越）。 */
function isInside(root, target) {
  const rel = path.relative(path.resolve(root), path.resolve(target));
  return !!rel && !rel.startsWith('..') && !path.isAbsolute(rel);
}

function readJsonSafe(file) {
  try {
    let text = fs.readFileSync(file, 'utf8');
    if (text.charCodeAt(0) === 0xFEFF) text = text.slice(1);   // 去 BOM
    return JSON.parse(text);
  } catch {
    return null;
  }
}

function writeJsonAtomic(file, value) {
  fs.mkdirSync(path.dirname(file), { recursive: true });
  const tmp = `${file}.${process.pid}.tmp`;
  fs.writeFileSync(tmp, JSON.stringify(value, null, 2), 'utf8');
  fs.renameSync(tmp, file);
}

/** 把源目录里的一张图收进索引：id 取文件名（去扩展名），稳定且可读。 */
function entryFromFile(srcFile, rootDir) {
  const stat = fs.statSync(srcFile);
  if (stat.size > MAX_FILE_BYTES) return null;
  const ext = path.extname(srcFile).toLowerCase();
  const base = path.basename(srcFile, ext);
  const id = base.toLowerCase().replace(/[^a-z0-9_-]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 64)
    || crypto.createHash('sha1').update(srcFile).digest('hex').slice(0, 12);
  return {
    id,
    file: srcFile,
    rel: path.relative(rootDir, srcFile).replace(/\\/g, '/'),
    ext: ext.replace('.', ''),
    bytes: stat.size,
    meaning: '',
    tags: [],
    useCount: 0,
    lastUsedAt: 0,
    addedAt: new Date().toISOString()
  };
}

/** 扫描源目录（含子目录）建索引；id 冲突时加短哈希后缀。 */
function buildIndexFromDir(srcDir) {
  const out = [];
  const seen = new Set();
  const walk = (dir, depth) => {
    if (depth > 6 || out.length >= MAX_INDEX_ENTRIES) return;
    let entries;
    try { entries = fs.readdirSync(dir, { withFileTypes: true }); } catch { return; }
    for (const e of entries) {
      if (out.length >= MAX_INDEX_ENTRIES) return;
      const full = path.join(dir, e.name);
      if (e.isDirectory()) { walk(full, depth + 1); continue; }
      if (!e.isFile()) continue;
      if (!IMAGE_EXTS.has(path.extname(e.name).toLowerCase())) continue;
      let entry;
      try { entry = entryFromFile(full, srcDir); } catch { continue; }
      if (!entry) continue;
      let id = entry.id;
      if (seen.has(id)) id = `${id}-${crypto.createHash('sha1').update(full).digest('hex').slice(0, 6)}`;
      seen.add(id);
      out.push({ ...entry, id });
    }
  };
  walk(srcDir, 0);
  return out;
}

/** 索引缓存：首次访问时从磁盘恢复，避免每次工具调用都读文件。 */
let cachedIndex = null;

function loadIndex(log) {
  if (cachedIndex) return cachedIndex;
  const saved = readJsonSafe(INDEX_FILE);
  if (saved && Array.isArray(saved.stickers) && saved.stickers.length) {
    cachedIndex = saved;
    return cachedIndex;
  }
  cachedIndex = { version: 1, sourceDir: '', builtAt: '', stickers: [] };
  return cachedIndex;
}

function saveIndex(log) {
  if (!cachedIndex) return;
  writeJsonAtomic(INDEX_FILE, cachedIndex);
}

/** 取本技能的配置（manifest.settings 已由管理器合并默认值）。 */
function cfgOf(api) {
  const cfg = api.config() || {};
  return {
    sourceDir: String(cfg.sourceDir || '').trim(),
    maxViewImages: Math.max(1, Math.min(10, Number(cfg.maxViewImages) || 5)),
    sendPerRun: Math.max(0, Number(cfg.sendPerRun) || 2)
  };
}

/** 需要时按配置的源目录建/补索引。 */
function ensureIndex(api, { force = false, log = () => {} } = {}) {
  const cfg = cfgOf(api);
  const idx = loadIndex(log);
  const needBuild = force
    || !idx.stickers.length
    || (cfg.sourceDir && idx.sourceDir !== cfg.sourceDir);
  if (!needBuild) return idx;
  if (!cfg.sourceDir) { log('未配置 sourceDir 且索引为空，无法导入'); return idx; }
  if (!fs.existsSync(cfg.sourceDir)) { log(`sourceDir 不存在：${cfg.sourceDir}`); return idx; }
  const built = buildIndexFromDir(cfg.sourceDir);
  // 保留已有备注/使用统计（重建索引不该抹掉 AI 学到的含义）
  const oldById = new Map((idx.stickers || []).map((s) => [s.id, s]));
  for (const s of built) {
    const old = oldById.get(s.id);
    if (old) {
      s.meaning = old.meaning || '';
      s.tags = Array.isArray(old.tags) ? old.tags : [];
      s.useCount = Number(old.useCount) || 0;
      s.lastUsedAt = Number(old.lastUsedAt) || 0;
      s.addedAt = old.addedAt || s.addedAt;
    }
  }
  cachedIndex = { version: 1, sourceDir: cfg.sourceDir, builtAt: new Date().toISOString(), stickers: built };
  saveIndex(log);
  log(`索引已构建：${built.length} 张（源：${cfg.sourceDir}）`);
  return cachedIndex;
}

/** 对外展示的一条（不回传本机绝对路径以外的信息）。 */
function brief(s) {
  return {
    id: s.id,
    meaning: s.meaning || '',
    tags: s.tags || [],
    ext: s.ext,
    useCount: s.useCount || 0,
    hasMeaning: !!s.meaning
  };
}

/** 按 id 精确查找；也接受 md5/文件名等模糊线索。 */
function findSticker(index, ref) {
  const raw = String(ref ?? '').trim();
  if (!raw) return null;
  const lower = raw.toLowerCase();
  let hit = index.stickers.find((s) => s.id === lower);
  if (hit) return hit;
  // 允许带扩展名（如 001.webp）
  const noExt = lower.replace(/\.[a-z0-9]+$/, '');
  hit = index.stickers.find((s) => s.id === noExt);
  if (hit) return hit;
  // 允许用文件名片段
  const matches = index.stickers.filter((s) => s.id.includes(noExt));
  if (matches.length === 1) return matches[0];
  return null;
}

/** 把图收进受控目录，返回可直接交给 sender 的绝对路径。 */
function materialize(s) {
  fs.mkdirSync(FILES_DIR, { recursive: true });
  const dest = path.join(FILES_DIR, `${s.id}.${s.ext}`);
  if (!isInside(FILES_DIR, dest)) throw new Error(`非法目标路径：${dest}`);
  // 已经在本目录里就直接用（避免重复复制）
  if (path.resolve(s.file).toLowerCase() === path.resolve(dest).toLowerCase() && fs.existsSync(dest)) return dest;
  if (fs.existsSync(dest)) return dest;
  if (!fs.existsSync(s.file)) throw new Error(`源文件已不存在：${s.id}（${s.rel}）—— 请把表情包目录移回原位，或在设置里更新路径后重载技能`);
  fs.copyFileSync(s.file, dest);
  return dest;
}

/** 读图 → dataURL（看图工具用；发送不走这条，避免大文件 base64 撑爆）。 */
function toDataUrl(file, ext) {
  const buf = fs.readFileSync(file);
  const mime = ext === 'png' ? 'image/png'
    : ext === 'gif' ? 'image/gif'
      : ext === 'webp' ? 'image/webp'
        : ext === 'bmp' ? 'image/bmp'
          : 'image/jpeg';
  return `data:${mime};base64,${buf.toString('base64')}`;
}

/**
 * 注册工具。
 * @param {object} api 技能 API（registerTool / config / log …）
 */
export function setup(api) {
  const log = (...a) => api.log(...a);
  const index = ensureIndex(api, { log });
  log(`加载成功，当前索引 ${index.stickers.length} 张`);

  // ── 每次运行的发送计数（挂在本技能的模块作用域，按进程计）─────────────
  // 简单够用：核心 sender 本身还有限频与去重，这里是"本技能自己的额外闸门"。
  let sentThisProcess = 0;
  let lastSentAt = 0;

  // ── 1) 搜索/列出 ───────────────────────────────────────────────────────
  api.registerTool({
    id: 'local_sticker_list',
    name: '搜索本地表情包',
    description: '搜索本地表情包库（硬盘上那套图，与 QQ 收藏表情是两回事）。可按含义/标签/文件名关键词过滤。返回 id、已有含义、标签。想看某张图长什么样用 local_sticker_view；想发用 local_sticker_send。库里大部分图还没备注（hasMeaning=false），可以先用关键词或序号随便挑几张看。',
    category: 'sticker',
    icon: '🗂️',
    defaultEnabled: true,
    parameters: {
      type: 'object',
      properties: {
        query: { type: 'string', description: '关键词：匹配含义/标签/文件名，留空=按使用次数和顺序列出' },
        onlyWithMeaning: { type: 'boolean', description: 'true=只看已经写过含义的（选图更准）' },
        limit: { type: 'integer', description: '最多返回条数，默认 40，最大 200' },
        offset: { type: 'integer', description: '跳过前 N 条，用于翻页' }
      }
    },
    async execute(_ctx, args) {
      try {
        const idx = ensureIndex(api, { log });
        const q = String(args?.query ?? '').trim().toLowerCase();
        const onlyMeaning = args?.onlyWithMeaning === true;
        const limit = Math.max(1, Math.min(200, Number(args?.limit) || 40));
        const offset = Math.max(0, Number(args?.offset) || 0);
        let list = idx.stickers;
        if (onlyMeaning) list = list.filter((s) => s.meaning);
        if (q) {
          list = list.filter((s) => [s.id, s.meaning, ...(s.tags || [])].join(' ').toLowerCase().includes(q));
        }
        const total = list.length;
        const page = list.slice(offset, offset + limit);
        return {
          content: JSON.stringify({
            total,
            totalWithMeaning: idx.stickers.filter((s) => s.meaning).length,
            librarySize: idx.stickers.length,
            offset,
            shown: page.length,
            stickers: page.map(brief),
            note: page.some((s) => !s.meaning)
              ? '有空备注的条目：建议对候选图先 local_sticker_view 看一眼再决定，顺手 local_sticker_note 写下含义。'
              : undefined
          }, null, 1)
        };
      } catch (error) {
        return { content: `错误：${error?.message ?? error}`, isError: true };
      }
    }
  });

  // ── 2) 看图（视觉理解）─────────────────────────────────────────────────
  api.registerTool({
    id: 'local_sticker_view',
    name: '查看本地表情包图片',
    description: '直接看本地表情包库里若干张图的实际画面（视觉模型能看懂），用于搞清"这张图是什么意思、适合什么场合"。ids 传 local_sticker_list 或 local_sticker_send 返回的 id。看完请用 local_sticker_note 把含义写下来，否则下次还是不认得。',
    category: 'sticker',
    icon: '🖼️',
    defaultEnabled: true,
    requiresVision: true,
    parameters: {
      type: 'object',
      properties: {
        ids: {
          description: '要看的表情 id：字符串（单个）或字符串数组（多个，建议一次 ≤5 张）',
          oneOf: [{ type: 'string' }, { type: 'array', items: { type: 'string' } }]
        }
      },
      required: ['ids']
    },
    async execute(_ctx, args) {
      try {
        const idx = ensureIndex(api, { log });
        const cfg = cfgOf(api);
        const rawIds = Array.isArray(args?.ids) ? args.ids : [args?.ids];
        const ids = rawIds.map((v) => String(v ?? '').trim()).filter(Boolean).slice(0, cfg.maxViewImages);
        if (!ids.length) return { content: '错误：ids 不能为空', isError: true };

        const parts = [];
        const found = [];
        const missing = [];
        for (const id of ids) {
          const s = findSticker(idx, id);
          if (!s) { missing.push(id); continue; }
          let file;
          try { file = materialize(s); } catch (error) { missing.push(`${id}(${error?.message ?? error})`); continue; }
          found.push(s);
          parts.push({ type: 'image_url', image_url: { url: toDataUrl(file, s.ext) } });
        }
        if (!found.length) {
          return { content: `错误：这些 id 都没找到或无法读取：${missing.join(', ')}。先用 local_sticker_list 拿有效 id。`, isError: true };
        }
        const head = [
          `查看了 ${found.length} 张本地表情包${missing.length ? `（另有 ${missing.length} 个未找到：${missing.join(', ')}）` : ''}：`,
          ...found.map((s) => `- id=${s.id}${s.meaning ? `｜已有含义：${s.meaning}` : '｜尚无含义'}`),
          '',
          '看完请对还没含义的那几张调用 local_sticker_note 记下「表达的情绪 + 适用场合」，便于以后按语境选图。'
        ].join('\n');
        return { content: [{ type: 'text', text: head }, ...parts] };
      } catch (error) {
        return { content: `错误：${error?.message ?? error}`, isError: true };
      }
    }
  });

  // ── 3) 写备注（沉淀"懂这张图"的关键）───────────────────────────────────
  api.registerTool({
    id: 'local_sticker_note',
    name: '备注本地表情包',
    description: '给本地表情包库里的一张图写下它的含义与适用场合（下次选图就会参考）。这是让表情包库"越用越懂"的唯一途径 —— 看完 local_sticker_view 就顺手写一条。',
    category: 'sticker',
    icon: '📝',
    defaultEnabled: true,
    parameters: {
      type: 'object',
      properties: {
        id: { type: 'string', description: '表情 id（local_sticker_list/view 返回的，照抄）' },
        meaning: { type: 'string', description: '这张图表达什么情绪/意思（一句话，如"无语到翻白眼"）' },
        tags: { type: 'array', items: { type: 'string' }, description: '可选：标签，如 ["无语","嘲讽","接梗"]' }
      },
      required: ['id', 'meaning']
    },
    async execute(_ctx, args) {
      try {
        const idx = ensureIndex(api, { log });
        const s = findSticker(idx, args?.id);
        if (!s) return { content: `错误：找不到表情 ${args?.id}。先用 local_sticker_list 查有效 id。`, isError: true };
        const meaning = String(args?.meaning ?? '').trim().slice(0, 200);
        if (!meaning) return { content: '错误：meaning 不能为空', isError: true };
        s.meaning = meaning;
        if (Array.isArray(args?.tags)) {
          s.tags = [...new Set(args.tags.map((t) => String(t ?? '').trim()).filter(Boolean))].slice(0, 12);
        }
        saveIndex(log);
        return { content: JSON.stringify({ saved: true, id: s.id, meaning: s.meaning, tags: s.tags }, null, 1) };
      } catch (error) {
        return { content: `错误：${error?.message ?? error}`, isError: true };
      }
    }
  });

  // ── 4) 发送（复用核心发送管道）─────────────────────────────────────────
  api.registerTool({
    id: 'local_sticker_send',
    name: '发送本地表情包',
    description: '把本地表情包库里的一张图发到当前聊天（独立气泡，不能和图外文字同气泡；想说话先用 send_message）。id 用 local_sticker_list 返回的；不确定这张图合不合适就先 local_sticker_view 看一眼。接梗、吐槽、附和、自嘲、无语时都可以用。',
    category: 'messaging',
    icon: '🐟',
    defaultEnabled: true,
    parameters: {
      type: 'object',
      properties: {
        id: { type: 'string', description: '要发的表情 id' },
        replyToMessageId: { type: ['integer', 'string'], description: '可选：引用某条消息的 id（聊天记录里每条前的 #数字）' },
        atUserId: { type: ['integer', 'string'], description: '可选：@ 某人的 QQ 号' },
        note: { type: 'string', description: '可选：给这条图留个简短说明（只进你自己的留档，不发给群友）' }
      },
      required: ['id']
    },
    async execute(ctx, args) {
      try {
        const idx = ensureIndex(api, { log });
        const cfg = cfgOf(api);
        const s = findSticker(idx, args?.id);
        if (!s) {
          return { content: `错误：找不到表情 ${args?.id}。先用 local_sticker_list 查有效 id。`, isError: true };
        }
        if (!ctx?.sender?.sendImage) {
          return { content: '错误：发送通道不可用（ctx.sender.sendImage 缺失），请检查核心版本。', isError: true };
        }
        // 本技能的节奏闸门：同一轮里不要连发
        if (cfg.sendPerRun > 0 && sentThisProcess >= cfg.sendPerRun) {
          return { content: `错误：本次运行已发过 ${sentThisProcess} 张本地表情包，达到上限（${cfg.sendPerRun}）。先把话说完。`, isError: true };
        }
        if (Date.now() - lastSentAt < 1500) {
          return { content: '错误：刚刚才发过一张，等 1.5 秒以上再发（避免连发刷屏）。', isError: true };
        }

        const file = materialize(s);
        const result = await ctx.sender.sendImage(ctx.chatKey, { file }, {
          note: String(args?.note ?? s.meaning ?? '').slice(0, 40),
          replyToMessageId: args?.replyToMessageId ?? null,
          atUserId: args?.atUserId ?? null
        });

        // 记账：使用次数 + 最近使用时间（供排序与轮换参考）
        s.useCount = (s.useCount || 0) + 1;
        s.lastUsedAt = Date.now();
        saveIndex(log);
        sentThisProcess += 1;
        lastSentAt = Date.now();

        return {
          content: JSON.stringify({
            sent: true,
            id: s.id,
            meaning: s.meaning || '',
            messageId: result?.message_id ?? null,
            note: '表情已发出（独立气泡）。不要输出"已发送"类汇报，继续思考下一步或直接结束。'
          }, null, 1)
        };
      } catch (error) {
        return { content: `错误：${error?.message ?? error}`, isError: true };
      }
    }
  });
}

/** 热重载时清理模块级缓存（技能被重新 import 时会拿到新模块，这里主要服务同进程重扫）。 */
export function dispose() {
  cachedIndex = null;
}

export default { name, inject, setup, dispose };
