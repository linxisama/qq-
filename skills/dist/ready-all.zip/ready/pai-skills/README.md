# pai-skills 1.1.0（Pai 技能包）

> 把 16 个独立技能合成**一个**包：装一次，工具全在。
> 版本 **1.1.0** · 根上有 `skill.json` · 无真实账号/群号

## 装法

1. 解压成 `skills/pai-skills/`（目录名随意，根上要有 `skill.json` + `index.js`）；
2. 重启核心或在面板重载；
3. 面板「技能」页会出现 **pai-skills**，设置页里有「总开关 + 每个模块的小开关」。

## 里面有什么

| 模块 | 工具数 |
|---|---|
| agent-reach | 4 |
| bili-pick | 3 |
| deai-flavor | 1 |
| group-wrapped | 1 |
| hot-trends | 2 |
| interact | 4 |
| meme | 1 |
| meme-taste | 3 |
| music | 3 |
| qq-self | 1 |
| qzone-social | 3 |
| reply-meme | 1 |
| smart-image | 1 |
| trendy-memes | 3 |
| weather | 1 |
| whale-memes | 2 |

## 两条要知道的

1. **这是合并包**：一个包里只有一份 `setup` / `hooks` / `providers`，16 个技能的工具都注册到同一个包里。`_root.js` 负责告诉各模块「仓库根在哪」，必须第一个加载（构建时已排在 index.js 第一行）。
2. **细项设置留在拆分包**：合并包里只带每个模块的开关；窗口/条数/阈值这类细项在拆分包各自的设置页里调（合并后共用一个 id，细项会互相盖）。
