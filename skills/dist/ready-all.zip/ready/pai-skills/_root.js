// 由构建脚本生成：告诉各模块「仓库根在哪」。★ 必须在所有模块之前执行。
import path from 'node:path';
import { fileURLToPath } from 'node:url';
if (!globalThis.__qqAgentRoot) {
  globalThis.__qqAgentRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../..');
}
