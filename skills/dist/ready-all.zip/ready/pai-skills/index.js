// ★ pai-skills —— QQ Agent 技能整合包（自动生成，别手改）
// 构建于 2026-10-20T03:34:08.352Z · 模块 16 个
import './_root.js';   // ★ 必须第一个
import * as m0 from './lib/agent-reach/index.js';
import * as m1 from './lib/bili-pick/index.js';
import * as m2 from './lib/deai-flavor/index.js';
import * as m3 from './lib/group-wrapped/index.js';
import * as m4 from './lib/hot-trends/index.js';
import * as m5 from './lib/interact/index.js';
import * as m6 from './lib/meme/index.js';
import * as m7 from './lib/meme-taste/index.js';
import * as m8 from './lib/music/index.js';
import * as m9 from './lib/qq-self/index.js';
import * as m10 from './lib/qzone-social/index.js';
import * as m11 from './lib/reply-meme/index.js';
import * as m12 from './lib/smart-image/index.js';
import * as m13 from './lib/trendy-memes/index.js';
import * as m14 from './lib/weather/index.js';
import * as m15 from './lib/whale-memes/index.js';

const MODULES = [
  { id: "agent-reach", m: m0 },
  { id: "bili-pick", m: m1 },
  { id: "deai-flavor", m: m2 },
  { id: "group-wrapped", m: m3 },
  { id: "hot-trends", m: m4 },
  { id: "interact", m: m5 },
  { id: "meme", m: m6 },
  { id: "meme-taste", m: m7 },
  { id: "music", m: m8 },
  { id: "qq-self", m: m9 },
  { id: "qzone-social", m: m10 },
  { id: "reply-meme", m: m11 },
  { id: "smart-image", m: m12 },
  { id: "trendy-memes", m: m13 },
  { id: "weather", m: m14 },
  { id: "whale-memes", m: m15 },
];

export function setup(api) {
  for (const { id, m } of MODULES) {
    try { m.setup?.(api) } catch (e) { console.warn(`[${pkgId}] ${id}.setup 出错：`, e?.message ?? e) }
  }
}

const HOOK_NAMES = [...new Set(MODULES.flatMap(({ m }) => Object.keys(m.hooks || {})))].sort();
export const hooks = Object.fromEntries(HOOK_NAMES.map((h) => [h, async (payload, ...rest) => {
  let cur = payload;
  for (const { m } of MODULES) {
    const fn = m.hooks?.[h];
    if (typeof fn !== `function`) continue;
    try { const r = await fn(cur, ...rest); if (r !== undefined) cur = r } catch (e) { console.warn(`[${pkgId}] ${h} 出错：`, e?.message ?? e) }
  }
  return cur;
}]));

const WINNER = {"llm.request-params":"skill-gating"};
export const providers = (() => {
  const out = {};
  for (const { id, m } of MODULES) {
    for (const [cap, fn] of Object.entries(m.providers || {})) {
      if (WINNER[cap] && WINNER[cap] !== id) continue;
      out[cap] = fn;
    }
  }
  return out;
})();

export function activate(...a) { for (const { m } of MODULES) { try { m.activate?.(...a) } catch {} } }
export function deactivate(...a) { for (const { m } of MODULES) { try { m.deactivate?.(...a) } catch {} } }
export function dispose(...a) { for (const { m } of MODULES) { try { m.dispose?.(...a) } catch {} } }
export const bundled = MODULES.map(({ id, m }) => ({ id, tools: (m.hooks ? 0 : 0) }));
