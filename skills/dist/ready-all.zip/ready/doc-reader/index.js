// doc-reader —— 让机器人读懂聊天里发来的 .txt / .docx 文件。
//
// 背景（为什么需要这个技能）：
//   核心的消息渲染把 file 段压成了 `[文件1-11.docx]` 这样一个只有名字的占位符
//   （src/onebot.js 的 segmentsToText），系统提示里还明确写着「[文件] 无法查看
//   内容」。所以模型既拿不到文件 id，也被明确告知读不了 —— 这是两条独立的墙。
//
//   本技能绕开这两条墙的方式：
//   ① 存档里的每条消息都带 mid（QQ 消息 id），用 ctx.onebot.getMsg(mid) 把原始
//      消息段取回来，file 段里就有 file_id / url / 文件名；
//   ② 用 url（或 get_private_file_url / get_group_file_url 换一份新直链）把
//      文件下载下来，本地解析正文；
//   ③ 用 prompt.sections 告诉模型「现在读得到了」，覆盖核心那句"无法查看"。
//
//   ⚠️ 存档里只有文本，没有 file_id —— 所以**必须**回查 get_msg。消息太旧时
//      QQ 端会返回 1401（拿不到原文），这时只能如实告诉模型读不了。
//
// 落点：skills/（LLM 型）。是否要读、读哪一段、读来干什么由模型判断 ——
//   自动把每个文件全文塞进上下文会把 token 预算炸穿，所以必须是工具而不是钩子。

import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import crypto from 'node:crypto';
import { inflateRawSync } from 'node:zlib';

// ── 支持的格式 ────────────────────────────────────────────────────────────
// 只做**自包含**能解析的：纯文本靠解码，docx 靠自己读 zip + 剥 XML 标签。
// .doc（二进制老格式）/ .pdf / .xlsx 不做 —— 没有第三方库，硬解不可靠。
const TEXT_EXT = new Set(['txt', 'text', 'md', 'markdown', 'log', 'csv', 'json', 'ini', 'yml', 'yaml']);
const DOCX_EXT = new Set(['docx']);
const SUPPORTED_EXT = new Set([...TEXT_EXT, ...DOCX_EXT]);

const DEFAULTS = {
  maxChars: 6000,
  maxFileBytes: 10 * 1024 * 1024,
  cacheMinutes: 60,
  downloadTimeoutMs: 30000
};

let settings = { ...DEFAULTS };
let fetchFn = null;
let logger = () => {};

// ── 生命周期 ──────────────────────────────────────────────────────────────

export async function setup(api) {
  settings = { ...DEFAULTS, ...(api.config?.() || {}) };
  fetchFn = typeof api.fetch === 'function' ? api.fetch : null;
  logger = typeof api.log === 'function' ? api.log : (() => {});

  api.registerTool({
    id: 'read_document',
    name: '读取文档内容',
    description: '读取别人发在聊天里的 .txt / .docx 文件正文。消息里出现 [文件xxx.txt] / [文件xxx.docx] 时用。messageId 填那行最前面的 #数字；不填则自动取本会话最近一个能读的文件。长文档分段返回，用返回的 nextStart 填进 start 继续往下读。不支持 .zip/.pdf/.doc/.xlsx。',
    category: 'knowledge',
    icon: '📄',
    parameters: {
      type: 'object',
      properties: {
        messageId: {
          type: ['integer', 'string'],
          description: '那条文件消息的 id（聊天记录里消息行最前面的 #数字，可能为负数）。省略则自动取本会话最近一个可读取的文件。'
        },
        start: {
          type: 'integer',
          description: '从第几个字符开始读，默认 0。长文档续读时填上一次返回的 nextStart。'
        },
        maxChars: {
          type: 'integer',
          description: '本次最多返回多少字符，默认按技能设置（6000），最大 20000。'
        }
      }
    },
    async execute(ctx, args) {
      try {
        return ok(await readDocument(ctx, args || {}));
      } catch (error) {
        return err(error?.message ?? String(error));
      }
    }
  });

  logger('已加载（txt/docx，单次上限 %s 字）', settings.maxChars);
}

// ── 主流程 ────────────────────────────────────────────────────────────────

async function readDocument(ctx, args) {
  const entry = pickEntry(ctx, args);
  const seg = await pickFileSegment(ctx, entry);
  const name = seg.name || nameFromEntry(entry) || '未命名文件';

  const ext = extOf(name);
  if (ext && !SUPPORTED_EXT.has(ext)) {
    throw new Error(`暂不支持 .${ext} 文件（目前只能读 ${[...SUPPORTED_EXT].map((e) => '.' + e).join(' / ')}）`);
  }

  const buffer = await fetchBytes(ctx, entry, seg);

  let text;
  try {
    text = extractText(buffer, name);
  } catch (error) {
    throw new Error(`文件取到了，但解析失败：${error?.message ?? error}`);
  }
  if (!String(text || '').trim()) {
    throw new Error('文件里没有可读取的文字内容（可能是空文件、纯图片型 docx 或加密文档）');
  }

  // 分段：默认给前 maxChars 字，并告诉模型下一次从哪继续
  const total = text.length;
  const want = clampInt(args.maxChars, settings.maxChars, 500, 20000);
  const start = Math.max(0, clampInt(args.start, 0, 0, Math.max(0, total - 1)));
  const slice = text.slice(start, start + want);
  const end = start + slice.length;
  const truncated = end < total;

  return {
    fileName: name,
    fileSize: buffer.length,
    totalChars: total,
    start,
    chars: slice.length,
    nextStart: truncated ? end : null,
    truncated,
    hint: truncated
      ? `这是第 ${start}~${end} 字（全文共 ${total} 字）。要继续往下读，把 start 填 ${end} 再调一次。`
      : `已读到结尾（全文共 ${total} 字）。`,
    text: slice
  };
}

/** 定位到哪条消息：优先按 messageId，其次自动找本会话最近一个文件消息。 */
function pickEntry(ctx, args) {
  const raw = args.messageId;
  if (raw !== undefined && raw !== null && String(raw).trim() !== '') {
    const entry = ctx.store.findByMid(ctx.chatKey, raw);
    if (!entry) throw new Error(`当前会话找不到消息 ${raw}。${midHint(ctx)}`);
    return entry;
  }
  const list = ctx.store.recent(ctx.chatKey, { limit: 60 }) || [];
  for (let i = list.length - 1; i >= 0; i--) {
    const m = list[i];
    const n = nameFromEntry(m);
    if (n && SUPPORTED_EXT.has(extOf(n))) return m;
  }
  throw new Error('最近的消息里没有找到 .txt / .docx 文件。可以先用 get_recent_messages 找出那条文件消息的 #数字 再读。');
}

/** 回查原始消息，把 file 段取回来（存档里只剩文件名，必须回查）。 */
async function pickFileSegment(ctx, entry) {
  const mid = entry?.mid;
  if (mid === null || mid === undefined || String(mid) === '') {
    throw new Error('这条存档消息没有 QQ 消息 id，无法回查原文');
  }
  let data;
  try {
    data = typeof ctx.onebot?.getMsg === 'function'
      ? await ctx.onebot.getMsg(mid)
      : await ctx.onebot.call('get_msg', { message_id: Number(mid) });
  } catch (error) {
    const msg = String(error?.message ?? error);
    if (/1401|不存在|not exist|expired/i.test(msg)) {
      throw new Error('这条消息太旧了，QQ 已经不给原文了（只剩文件名）。让对方重新发一次就能读。');
    }
    throw new Error(`回查消息原文失败：${msg}`);
  }

  const segs = normalizeSegments(data?.message ?? data);
  const files = segs.filter((s) => s.type === 'file');
  if (!files.length) throw new Error('这条消息里没有文件（可能已被撤回或内容已过期）');

  // 多条文件时按存档里的名字对一下，免得读错
  const want = nameFromEntry(entry);
  const hit = want ? files.find((f) => (f.data?.name || f.data?.file) === want) : null;
  const d = (hit || files[0]).data || {};
  return {
    name: String(d.file_name || d.name || d.filename || d.file || ''),
    fileId: String(d.file_id || d.id || d.file || ''),
    url: String(d.url || ''),
    localPath: String(d.path || ''),
    size: Number(d.file_size || d.size || 0)
  };
}

/** 把 get_msg 返回的 message 归一化成段数组（数组 / CQ 码字符串都兼容）。 */
function normalizeSegments(message) {
  if (Array.isArray(message)) return message.filter((s) => s && typeof s === 'object');
  if (typeof message === 'string') {
    const out = [];
    const re = /\[CQ:([a-zA-Z_-]+)((?:,[^\]]*)?)\]/g;
    let m;
    while ((m = re.exec(message))) {
      const data = {};
      for (const part of String(m[2] || '').split(',')) {
        if (!part) continue;
        const i = part.indexOf('=');
        if (i < 0) continue;
        data[part.slice(0, i)] = unescapeCq(part.slice(i + 1));
      }
      out.push({ type: String(m[1]), data });
    }
    return out;
  }
  return [];
}

function unescapeCq(s) {
  return String(s)
    .replace(/&amp;/g, '&').replace(/&#91;/g, '[').replace(/&#93;/g, ']')
    .replace(/&#44;/g, ',');
}

// ── 取文件字节：本地路径 → 直链 → 换新直链 → 协议端缓存 ────────────────────

async function fetchBytes(ctx, entry, seg) {
  const cap = Math.max(1024, Number(settings.maxFileBytes) || DEFAULTS.maxFileBytes);
  if (seg.size && seg.size > cap) {
    throw new Error(`文件太大（${Math.round(seg.size / 1048576)}MB，上限 ${Math.round(cap / 1048576)}MB），没有下载。`);
  }

  const key = seg.fileId || seg.url || `${ctx.chatKey}:${entry.mid}`;
  const cached = readCache(key);
  if (cached) return cached;

  // ① 协议端直接给了本地路径
  if (seg.localPath && fs.existsSync(seg.localPath)) {
    const buf = fs.readFileSync(seg.localPath);
    writeCache(key, buf);
    return buf;
  }

  const attempts = [];

  // ② 消息里自带的直链（最常用，也最快）
  if (seg.url) {
    try { return saveAndCache(key, await download(seg.url, cap)); }
    catch (error) { attempts.push(`直链下载失败：${error?.message ?? error}`); }
  }

  // ③ 直链失效/过期：找协议端换一份新直链（私聊 / 群各有一个接口）
  if (seg.fileId) {
    const isGroup = String(ctx.kind || '').startsWith('group') || String(ctx.chatKey || '').startsWith('group:');
    const actions = isGroup
      ? [['get_group_file_url', { group_id: Number(ctx.chatId), file_id: seg.fileId }], ['get_file', { file_id: seg.fileId }]]
      : [['get_private_file_url', { file_id: seg.fileId }], ['get_file', { file_id: seg.fileId }]];
    for (const [action, params] of actions) {
      try {
        const ret = await ctx.onebot.call(action, params);
        const p = ret?.file && fs.existsSync(String(ret.file)) ? String(ret.file) : '';
        if (p) { const buf = fs.readFileSync(p); writeCache(key, buf); return buf; }
        if (ret?.url) { return saveAndCache(key, await download(String(ret.url), cap)); }
      } catch (error) {
        attempts.push(`${action} 失败：${error?.message ?? error}`);
      }
    }
  }

  throw new Error(attempts.length
    ? `取不到文件内容。${attempts.join('；')}`
    : '取不到文件内容：这条消息里既没有下载地址也没有文件 id。');
}

async function download(url, cap) {
  if (!/^https?:\/\//i.test(String(url))) throw new Error('下载地址不是 http(s)，已拒绝');
  if (!fetchFn) throw new Error('技能没有拿到 web_fetch 权限，无法下载文件');
  const timeoutMs = Math.max(1000, Number(settings.downloadTimeoutMs) || DEFAULTS.downloadTimeoutMs);
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), timeoutMs);
  try {
    const res = await fetchFn(url, { signal: ctrl.signal, redirect: 'follow' });
    if (!res || !res.ok) throw new Error(`HTTP ${res?.status ?? '无响应'}`);
    const declared = Number(res.headers?.get?.('content-length') || 0);
    if (declared && declared > cap) throw new Error(`文件超过体积上限（${declared} > ${cap} 字节）`);

    const chunks = [];
    let total = 0;
    const reader = res.body?.getReader?.();
    if (reader) {
      for (;;) {
        const { done, value } = await reader.read();
        if (done) break;
        total += value.length;
        if (total > cap) { try { await reader.cancel(); } catch { /* ignore */ } throw new Error('文件超过体积上限，已中止下载'); }
        chunks.push(Buffer.from(value));
      }
    } else {
      const buf = Buffer.from(await res.arrayBuffer());
      if (buf.length > cap) throw new Error('文件超过体积上限');
      chunks.push(buf);
    }
    const out = Buffer.concat(chunks);
    if (!out.length) throw new Error('下载到的内容是空的');
    return out;
  } finally {
    clearTimeout(timer);
  }
}

function saveAndCache(key, buf) {
  writeCache(key, buf);
  return buf;
}

// ── 缓存（系统临时目录；分页续读时不用重复下载）────────────────────────────

function cacheDir() {
  return path.join(os.tmpdir(), 'qq-agent-doc-reader');
}

function cacheFile(key) {
  const hash = crypto.createHash('sha1').update(String(key)).digest('hex');
  return path.join(cacheDir(), `${hash}.bin`);
}

function readCache(key) {
  const minutes = Number(settings.cacheMinutes);
  if (!(minutes > 0)) return null;
  try {
    const p = cacheFile(key);
    const st = fs.statSync(p);
    if (Date.now() - st.mtimeMs > minutes * 60000) return null;
    return fs.readFileSync(p);
  } catch {
    return null;
  }
}

function writeCache(key, buf) {
  const minutes = Number(settings.cacheMinutes);
  if (!(minutes > 0)) return;
  try {
    fs.mkdirSync(cacheDir(), { recursive: true });
    fs.writeFileSync(cacheFile(key), buf);
  } catch { /* 缓存写失败不影响主流程 */ }
}

// ── 文本提取 ──────────────────────────────────────────────────────────────

/** 纯文本：猜编码（BOM → 严格 UTF-8 → GBK → 兜底 UTF-8）。 */
export function decodeTextBuffer(buf) {
  if (buf.length >= 3 && buf[0] === 0xEF && buf[1] === 0xBB && buf[2] === 0xBF) {
    return buf.subarray(3).toString('utf8');
  }
  if (buf.length >= 2 && buf[0] === 0xFF && buf[1] === 0xFE) {
    return buf.subarray(2).toString('utf16le');
  }
  if (buf.length >= 2 && buf[0] === 0xFE && buf[1] === 0xFF) {
    const swapped = Buffer.from(buf.subarray(2));
    for (let i = 0; i + 1 < swapped.length; i += 2) {
      const t = swapped[i]; swapped[i] = swapped[i + 1]; swapped[i + 1] = t;
    }
    return swapped.toString('utf16le');
  }
  try {
    return new TextDecoder('utf-8', { fatal: true }).decode(buf);
  } catch { /* 不是合法 UTF-8，往下试中文编码 */ }
  try {
    return new TextDecoder('gbk').decode(buf);
  } catch { /* 运行环境没有 GBK 解码器（精简 ICU），走兜底 */ }
  return buf.toString('utf8');
}

/** docx = zip，正文在 word/document.xml。 */
export function docxToText(buf) {
  const xml = readZipEntry(buf, 'word/document.xml');
  if (!xml) throw new Error('这个 docx 里没有 word/document.xml（可能是加密文档或异常文件）');
  let s = xml.toString('utf8');
  // 先把"有语义"的标签换成控制字符，再一次性剥掉其余标签
  s = s
    .replace(/<w:br\s*\/?>/g, '\n')
    .replace(/<\/w:p>/g, '\n')
    .replace(/<w:tab\s*\/?>/g, '\t')
    .replace(/<\/w:tc>/g, '\t')
    .replace(/<\/w:tr>/g, '\n');
  s = s.replace(/<[^>]*>/g, '');
  return tidy(decodeEntities(s));
}

export function extractText(buf, name = '') {
  return DOCX_EXT.has(extOf(name)) ? docxToText(buf) : tidy(decodeTextBuffer(buf));
}

function tidy(s) {
  return String(s)
    .replace(/\r\n?/g, '\n')
    .split('\n').map((l) => l.replace(/[ \t]+$/, '')).join('\n')
    .replace(/\n{3,}/g, '\n\n')
    .trim();
}

function decodeEntities(s) {
  const named = { amp: '&', lt: '<', gt: '>', quot: '"', apos: "'" };
  return String(s).replace(/&(#x?[0-9a-fA-F]+|[a-zA-Z]+);/g, (m, e) => {
    if (e[0] === '#') {
      const code = (e[1] === 'x' || e[1] === 'X') ? parseInt(e.slice(2), 16) : parseInt(e.slice(1), 10);
      return Number.isFinite(code) && code > 0 && code <= 0x10FFFF ? String.fromCodePoint(code) : m;
    }
    return Object.prototype.hasOwnProperty.call(named, e) ? named[e] : m;
  });
}

/**
 * 极简 zip 读取：定位 EOCD → 遍历中央目录 → 取指定条目的数据。
 * 只支持 STORED(0) 与 DEFLATE(8)，够读 Word 生成的 docx；其余直接抛错而不是静默出错。
 */
export function readZipEntry(buf, wantName) {
  const want = wantName.replace(/\\/g, '/');
  let eocd = -1;
  for (let i = buf.length - 22; i >= Math.max(0, buf.length - 22 - 65536); i--) {
    if (buf.readUInt32LE(i) === 0x06054B50) { eocd = i; break; }
  }
  if (eocd < 0) throw new Error('不是有效的 zip 文件');
  const count = buf.readUInt16LE(eocd + 10);
  let ptr = buf.readUInt32LE(eocd + 16);

  for (let i = 0; i < count; i++) {
    if (ptr + 46 > buf.length || buf.readUInt32LE(ptr) !== 0x02014B50) throw new Error('zip 中央目录损坏');
    const method = buf.readUInt16LE(ptr + 10);
    const compSize = buf.readUInt32LE(ptr + 20);
    const nameLen = buf.readUInt16LE(ptr + 28);
    const extraLen = buf.readUInt16LE(ptr + 30);
    const commentLen = buf.readUInt16LE(ptr + 32);
    const localOff = buf.readUInt32LE(ptr + 42);
    const name = buf.toString('utf8', ptr + 46, ptr + 46 + nameLen).replace(/\\/g, '/');
    if (name === want) {
      if (localOff + 30 > buf.length || buf.readUInt32LE(localOff) !== 0x04034B50) throw new Error('zip 本地头损坏');
      const lNameLen = buf.readUInt16LE(localOff + 26);
      const lExtraLen = buf.readUInt16LE(localOff + 28);
      const start = localOff + 30 + lNameLen + lExtraLen;
      if (compSize === 0xFFFFFFFF) throw new Error('不支持 zip64 格式的压缩包');
      if (start + compSize > buf.length) throw new Error('zip 条目长度越界');
      const raw = buf.subarray(start, start + compSize);
      if (method === 0) return Buffer.from(raw);
      if (method === 8) return inflateRawSync(raw);
      throw new Error(`不支持的压缩方式（method=${method}）`);
    }
    ptr += 46 + nameLen + extraLen + commentLen;
  }
  return null;
}

// ── 小工具 ────────────────────────────────────────────────────────────────

function extOf(name) {
  const m = /\.([a-z0-9]{1,8})$/i.exec(String(name || '').trim());
  return m ? m[1].toLowerCase() : '';
}

function nameFromEntry(entry) {
  const m = /\[文件([^\]]+)\]/.exec(String(entry?.text || ''));
  return m ? m[1].trim() : '';
}

function clampInt(value, fallback, min, max) {
  const n = Number(value);
  if (!Number.isFinite(n)) return fallback;
  return Math.min(max, Math.max(min, Math.round(n)));
}

function midHint(ctx) {
  const mids = (ctx.store.recent(ctx.chatKey, { limit: 60 }) || [])
    .map((m) => m?.mid)
    .filter((v) => v !== null && v !== undefined && String(v) !== '');
  const uniq = [...new Set(mids.map(String))].slice(-8);
  return uniq.length ? `当前会话里能用的消息 id 有：${uniq.join('、')}` : '当前会话暂时没有可用的消息 id。';
}

function ok(payload) {
  return { content: typeof payload === 'string' ? payload : JSON.stringify(payload, null, 1) };
}

function err(message) {
  return { content: `错误：${message}`, isError: true };
}
