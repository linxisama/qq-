// Deadlock 英雄胜率查询 —— LLM 型技能 / API v1 (v1.0.0)
//
// 为什么是技能，不是插件（三问判断法）：
//   ① 规则能写死吗？不能。「查哪个英雄、要什么指标、要不要截图」都要听懂人话。
//   ② 要不要理解人话？要。英雄名可能是中文/英文/拼音/外号（如 火男、老七）。
//   ③ 何时执行由谁定？由模型决定：什么时候查、查单英雄还是查榜、要不要截图。
// 所以：注册工具 + 提示词片段，由模型自己判断何时调用。
//
// 数据源：deadlock-api.com 的公开 REST 接口（社区维护，Valve 非官方）。
//   /v1/analytics/hero-stats            -> 每个英雄的 wins/losses/matches
//   /v1/assets/heroes?language=schinese -> 英雄 id 到中文名/英文名/外号的映射
// 截图：在 Electron 主进程里用离屏 BrowserWindow 渲染统计页并 capturePage，
//   然后通过 ctx.sender.sendImage 直接发到当前群聊（协议端同机时走本地文件）。

import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';

const SKILL_ID = 'deadlock-stats';
const TOOL = (n) => `${SKILL_ID}__${n}`;
const BUILD_TAG = 'v1.3.0';

let cfg = () => ({});
let log = () => {};
let warn = () => {};
let fetchFn = (...args) => globalThis.fetch(...args);

// 英雄名映射缓存（避免每次查询都拉 1.4MB 的资产文件）
let heroesCache = { list: [], at: 0 };
let ranksCache = { list: [], at: 0 };

function str(v, dflt = '') {
  const s = String(v ?? '').trim();
  return s || dflt;
}

function num(v, dflt, min = -Infinity, max = Infinity) {
  const n = Number(v);
  if (!Number.isFinite(n)) return dflt;
  return Math.min(max, Math.max(min, n));
}

function pickValid(value, list, fallback) {
  const s = String(value ?? '').trim();
  if (s && list.includes(s)) return s;
  return list.includes(fallback) ? fallback : list[0];
}

function readSettings() {
  const c = cfg() || {};
  return {
    apiBase: str(c.apiBase, 'https://api.deadlock-api.com').replace(/\/+$/, ''),
    statsPageUrl: str(c.statsPageUrl, 'https://deadlock-api.com/analytics/heroes'),
    defaultLimit: num(c.defaultLimit, 10, 1, 30),
    cacheMinutes: num(c.cacheMinutes, 30, 1, 720)
  };
}

async function fetchJson(url, timeoutMs = 25000) {
  const res = await fetchFn(url, {
    signal: AbortSignal.timeout(timeoutMs),
    headers: {
      'user-agent': 'qq-agent-deadlock-stats/1.0',
      'accept': 'application/json'
    }
  });
  if (!res.ok) throw new Error(`数据接口 HTTP ${res.status}`);
  return res.json();
}

async function getHeroes(s) {
  const ttl = s.cacheMinutes * 60 * 1000;
  if (heroesCache.list.length && Date.now() - heroesCache.at < ttl) return heroesCache.list;
  const data = await fetchJson(`${s.apiBase}/v1/assets/heroes?language=schinese&only_active=true`, 40000);
  heroesCache.list = Array.isArray(data) ? data : [];
  heroesCache.at = Date.now();
  return heroesCache.list;
}

async function getRanks(s) {
  const ttl = s.cacheMinutes * 60 * 1000;
  if (ranksCache.list.length && Date.now() - ranksCache.at < ttl) return ranksCache.list;
  try {
    const data = await fetchJson(`${s.apiBase}/v1/assets/ranks?language=schinese`, 30000);
    ranksCache.list = Array.isArray(data) ? data : [];
    ranksCache.at = Date.now();
  } catch (error) {
    warn(`段位表拉取失败（回退为未定级）：${error?.message ?? error}`);
    ranksCache.list = [];
  }
  return ranksCache.list;
}

function heroSearchText(h) {
  return [h?.name, h?.class_name, h?.search_name].filter(Boolean).join(' ').toLowerCase();
}

function findHeroes(heroes, query) {
  const q = String(query ?? '').trim().toLowerCase();
  if (!q) return [];
  const exact = heroes.filter((h) => {
    const name = String(h?.name ?? '').toLowerCase();
    const cls = String(h?.class_name ?? '').toLowerCase();
    return name === q || cls === q || `hero_${q}` === cls;
  });
  if (exact.length) return exact;
  return heroes.filter((h) => heroSearchText(h).includes(q));
}

function buildStats(heroStats, heroes) {
  const byId = new Map(heroes.map((h) => [h.id, h]));
  const rows = [];
  let totalMatches = 0;
  for (const s of heroStats || []) {
    const heroId = Number(s?.hero_id);
    const meta = byId.get(heroId);
    if (!meta) continue;               // 只看当前可选英雄，跳过停用/开发中的
    const wins = Number(s?.wins) || 0;
    const matches = Number(s?.matches) || (wins + (Number(s?.losses) || 0));
    totalMatches += matches;
    rows.push({
      heroId,
      name: String(meta.name || `英雄${heroId}`),
      className: String(meta.class_name || '').replace(/^hero_/, ''),
      wins,
      losses: Number(s?.losses) || 0,
      matches
    });
  }
  const totalGames = Math.max(1, totalMatches / 12);   // 每局 12 名玩家
  for (const r of rows) {
    r.winrate = r.matches ? (r.wins / r.matches) * 100 : 0;
    r.pickrate = r.matches ? (r.matches / totalGames) * 100 : 0;
  }
  return rows;
}

function sortRows(rows, sort) {
  const key = sort === 'pickrate' ? 'pickrate' : sort === 'matches' ? 'matches' : 'winrate';
  return [...rows].sort((a, b) => b[key] - a[key]);
}

function fmtPct(v) {
  return `${Number(v || 0).toFixed(1)}%`;
}

function fmtNum(n) {
  if (n >= 1e8) return `${(n / 1e8).toFixed(2)}亿`;
  if (n >= 1e4) return `${(n / 1e4).toFixed(1)}万`;
  return String(Math.round(n));
}

const ROMAN = ['', 'I', 'II', 'III', 'IV', 'V', 'VI', 'VII', 'VIII', 'IX', 'X'];
function roman(n) {
  const i = Number(n) || 0;
  return ROMAN[i] || String(i);
}

function outcomeText(o) {
  const v = Number(o);
  if (v === 1) return '胜';
  if (v === 2) return '负';
  return '未计分';
}

async function searchPlayers(s, query, limit = 10) {
  const url = `${s.apiBase}/v1/players/steam-search?search_query=${encodeURIComponent(String(query ?? '').trim())}&limit=${limit}`;
  try {
    const data = await fetchJson(url, 25000);
    return Array.isArray(data) ? data : [];
  } catch (error) {
    warn(`玩家搜索失败（按未找到处理）：${error?.message ?? error}`);
    return [];
  }
}

function formatCandidates(list, query) {
  const lines = [`叫「${query}」的玩家不止一个，以下是相近的候选：`];
  list.slice(0, 8).forEach((p, i) => {
    lines.push(`${i + 1}. ${p?.personaname || '（无名）'}｜SteamID3 ${p?.account_id ?? '未知'}｜近30天 ${p?.matches_played_last_30d ?? 0} 场`);
  });
  lines.push('想精确查哪一个，直接把它的 SteamID3（纯数字那串）发我再查一次。');
  return lines.join('\n');
}

function formatPlayer(profile, matches, rank, heroes, ranks) {
  const byId = new Map(heroes.map((h) => [h.id, h]));
  const lines = [];
  lines.push(`【${profile?.personaname || '玩家'}】`);
  if (rank && Number(rank.badge) > 0) {
    const tier = Math.floor(Number(rank.badge) / 10);
    const sub = Number(rank.badge) % 10;
    const meta = ranks.find((r) => Number(r.tier) === tier);
    const name = meta?.name || `段位${tier}`;
    lines.push(`当前段位：${name}${sub ? ' ' + roman(sub) : ''}`);
  } else {
    lines.push('当前段位：未定级');
  }
  if (matches && matches.length) {
    lines.push(`最近 ${matches.length} 场：`);
    matches.forEach((m, i) => {
      const hero = byId.get(Number(m.hero_id));
      const heroName = hero?.name || `英雄${m.hero_id}`;
      const mins = Math.round((Number(m.match_duration_s) || 0) / 60);
      const d = new Date((Number(m.start_time) || 0) * 1000);
      lines.push(
        `${i + 1}. ${d.getMonth() + 1}/${d.getDate()} ${heroName} ${outcomeText(m.player_match_outcome)} ` +
        `${m.player_kills}/${m.player_deaths}/${m.player_assists}，${mins} 分钟，净经济 ${fmtNum(Number(m.net_worth) || 0)}｜局号 ${m.match_id}`
      );
    });
  } else {
    lines.push('最近没有可展示的对局记录。');
  }
  lines.push(`SteamID3：${profile?.account_id ?? '未知'}｜数据来源：deadlock-api.com`);
  return lines.join('\n');
}

function formatHero(r) {
  const en = r.className ? `（${r.className}）` : '';
  return [
    `【${r.name}${en}】`,
    `胜率：${fmtPct(r.winrate)}（${fmtNum(r.matches)} 场：胜 ${fmtNum(r.wins)} / 负 ${fmtNum(r.losses)}）`,
    `出场率：${fmtPct(r.pickrate)}`,
    `数据来源：deadlock-api.com（近 30 天，排位 + 非排位）`
  ].join('\n');
}

function formatList(rows, sort) {
  const label = sort === 'pickrate' ? '出场率榜' : sort === 'matches' ? '场次榜' : '胜率榜';
  const lines = [`Deadlock 英雄${label} Top ${rows.length}（近 30 天，排位+非排位）`];
  rows.forEach((r, i) => {
    lines.push(`${i + 1}. ${r.name}  胜率 ${fmtPct(r.winrate)}  出场 ${fmtPct(r.pickrate)}  场次 ${fmtNum(r.matches)}`);
  });
  lines.push('数据来源：deadlock-api.com');
  return lines.join('\n');
}

// ── 截图 ──────────────────────────────────────────────────────────────────

async function waitForContent(win, timeoutMs) {
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    try {
      const ok = await win.webContents.executeJavaScript(
        `(() => {
          const rows = document.querySelectorAll('table tr, [role="row"]').length;
          const imgs = document.querySelectorAll('img').length;
          return rows > 5 || imgs > 5;
        })()`,
        true
      );
      if (ok) return true;
    } catch {
      // executeJavaScript 偶发抛错（页面还没就绪），继续等
    }
    await new Promise((r) => setTimeout(r, 400));
  }
  return false;
}

/** 对局页专用：隐藏 Match timeline，并展开内层滚动容器，让 12 人战绩一次性铺开。 */
async function prepareMatchPage(win) {
  try {
    return await win.webContents.executeJavaScript(`(() => {
      // 1) 按文字定位 Match timeline，找到最近的圆角卡片并隐藏
      const all = Array.from(document.querySelectorAll('div, section, article'));
      const hits = all.filter((el) => /match\\s*timeline/i.test(el.textContent || ''));
      hits.sort((a, b) => (a.textContent || '').length - (b.textContent || '').length);
      const label = hits[0] || null;
      let hidden = false;
      if (label) {
        let node = label;
        for (let i = 0; i < 8 && node; i++) {
          const cs = getComputedStyle(node);
          const radius = parseFloat(cs.borderRadius) || 0;
          const len = (node.textContent || '').length;
          if (radius >= 4 && len < 5000) { node.style.display = 'none'; hidden = true; break; }
          node = node.parentElement;
        }
        if (!hidden) { label.style.display = 'none'; hidden = true; }
      }

      // 2) 找最高的内层滚动容器，并逐级放开高度/溢出限制
      let sc = null;
      for (const el of document.querySelectorAll('*')) {
        const cs = getComputedStyle(el);
        if ((cs.overflowY === 'auto' || cs.overflowY === 'scroll') && el.scrollHeight > el.clientHeight + 40) {
          if (!sc || el.scrollHeight > sc.scrollHeight) sc = el;
        }
      }
      let node = sc;
      for (let i = 0; i < 10 && node; i++) {
        const cs = getComputedStyle(node);
        if (node !== document.documentElement && node !== document.body) {
          node.style.height = 'auto';
          node.style.maxHeight = 'none';
        }
        if (cs.overflowY === 'auto' || cs.overflowY === 'scroll' || cs.overflow === 'hidden') {
          node.style.overflow = 'visible';
          node.style.overflowY = 'visible';
        }
        node = node.parentElement;
      }
      document.documentElement.style.height = 'auto';
      document.body.style.height = 'auto';
      document.documentElement.style.overflow = 'visible';
      document.body.style.overflow = 'visible';
      window.scrollTo(0, 0);

      return {
        hidden,
        height: Math.max(document.documentElement.scrollHeight, document.body.scrollHeight, sc ? sc.scrollHeight : 0)
      };
    })()`, true);
  } catch (error) {
    warn(`对局页预处理失败（继续按普通方式截图）：${error?.message ?? error}`);
    return null;
  }
}

/** 用 CDP 截整页（含视口外内容），失败返回 null 让调用方回退。 */
async function captureFullPage(win) {
  const dbg = win.webContents.debugger;
  try {
    if (!dbg.isAttached()) dbg.attach('1.3');
    const metrics = await dbg.sendCommand('Page.getLayoutMetrics');
    const size = metrics.cssContentSize || metrics.contentSize || {};
    const width = Math.max(1, Math.ceil(Number(size.width) || 0));
    // 12 人对局页约 2000~3000px；上限兜住异常超长页面，避免生成超大图发不出去
    const height = Math.max(1, Math.min(6000, Math.ceil(Number(size.height) || 0)));
    const shot = await dbg.sendCommand('Page.captureScreenshot', {
      format: 'png',
      fromSurface: true,
      captureBeyondViewport: true,
      clip: { x: 0, y: 0, width, height, scale: 1 }
    });
    const buf = Buffer.from(shot?.data || '', 'base64');
    return buf.length ? buf : null;
  } catch (error) {
    warn(`整页截图失败，回退普通截图：${error?.message ?? error}`);
    return null;
  } finally {
    try { if (dbg.isAttached()) dbg.detach(); } catch { /* ignore */ }
  }
}

async function captureAndSend(ctx, s, pageUrl = null, note = 'Deadlock 英雄胜率页面截图', options = {}) {
  let electron;
  try {
    electron = await import('electron');
  } catch (error) {
    warn(`截图不可用（无法加载 electron）：${error?.message ?? error}`);
    return null;
  }

  let win;
  try {
    win = new electron.BrowserWindow({
      width: 1280,
      height: 1600,
      show: false,
      webPreferences: {
        offscreen: true,
        nodeIntegration: false,
        contextIsolation: true,
        sandbox: true,
        backgroundThrottling: false
      }
    });
    await win.loadURL(pageUrl || s.statsPageUrl);
    await waitForContent(win, 9000);
    await new Promise((r) => setTimeout(r, 700));

    if (options.matchMode) {
      const info = await prepareMatchPage(win);
      await new Promise((r) => setTimeout(r, 700));
      // 再把视口临时撑到内容高度：应对外层固定高度、只靠内层滚动条的应用壳布局
      const targetH = Math.min(6000, Math.max(1600, Math.ceil(Number(info?.height) || 0)));
      try {
        const dbg = win.webContents.debugger;
        if (!dbg.isAttached()) dbg.attach('1.3');
        await dbg.sendCommand('Emulation.setDeviceMetricsOverride', {
          width: 1280,
          height: targetH,
          deviceScaleFactor: 1,
          mobile: false
        });
        await new Promise((r) => setTimeout(r, 800));
        await prepareMatchPage(win);
        await new Promise((r) => setTimeout(r, 500));
      } catch (error) {
        warn(`视口撑高失败（继续按当前布局截图）：${error?.message ?? error}`);
      }
    }

    let png = options.fullPage ? await captureFullPage(win) : null;
    if (!png || !png.length) {
      const image = await win.webContents.capturePage();
      png = image.toPNG();
    }
    if (!png || !png.length) return null;

    const file = path.join(os.tmpdir(), `deadlock-stats-${Date.now()}-${Math.floor(Math.random() * 1e6)}.png`);
    fs.writeFileSync(file, png);
    try {
      await ctx.sender.sendImage(
        ctx.chatKey,
        { file, dataUrl: `base64://${png.toString('base64')}` },
        { note }
      );
      return file;
    } finally {
      try { fs.rmSync(file, { force: true }); } catch { /* 清理失败不影响功能 */ }
    }
  } catch (error) {
    warn(`截图失败（已跳过，不影响数据回复）：${error?.message ?? error}`);
    return null;
  } finally {
    try { win?.destroy(); } catch { /* ignore */ }
  }
}

// ── 工具 ──────────────────────────────────────────────────────────────────

export function setup(api) {
  if (typeof api?.config === 'function') cfg = api.config;
  if (typeof api?.log === 'function') log = api.log;
  if (typeof api?.warn === 'function') warn = api.warn;
  if (typeof api?.fetch === 'function') fetchFn = api.fetch;

  api.registerTool({
    id: 'hero_stats',
    name: '查询 Deadlock 英雄数据',
    description: '从 deadlock-api.com 拉取英雄胜率、出场率、对局数，并排版返回。查整体榜单时一次调用（hero 留空），返回的是一整份合并好的榜单文本，直接原样一条消息发出，不要逐条拆开发。',
    category: 'web',
    icon: '📊',
    parameters: {
      type: 'object',
      properties: {
        hero: { type: 'string', description: '英雄名（中文/英文/外号均可，如 炽焱 / Infernus / 火男）。留空则返回排行榜。' },
        sort: { type: 'string', enum: ['winrate', 'pickrate', 'matches'], description: '榜单排序：winrate=胜率，pickrate=出场率，matches=场次。默认 winrate。' },
        limit: { type: 'integer', description: '榜单返回条数，默认 10，最大 30。' },
        screenshot: { type: 'boolean', description: '是否额外截取统计页图片并发到群里。群友要截图/网页图时填 true。' }
      },
      required: []
    },
    async execute(ctx, args) {
      const s = readSettings();
      const sort = pickValid(args?.sort, ['winrate', 'pickrate', 'matches'], 'winrate');
      const limit = Math.min(30, Math.max(1, Math.round(num(args?.limit, s.defaultLimit, 1, 30))));

      const [heroStats, heroes] = await Promise.all([
        fetchJson(`${s.apiBase}/v1/analytics/hero-stats`),
        getHeroes(s)
      ]);
      const rows = buildStats(heroStats, heroes);
      if (!rows.length) {
        return { content: '没查到英雄数据（数据源可能暂时没有返回结果），稍后再试。', isError: true };
      }

      let text;
      const heroArg = str(args?.hero);
      if (heroArg) {
        const found = findHeroes(heroes, heroArg);
        if (!found.length) {
          return { content: `没找到叫「${heroArg}」的英雄。可以试试中文名（炽焱、柒、薇妲…）、英文名（Infernus、Seven、Vindicta…）或常见外号（火男、老七…）。`, isError: true };
        }
        const meta = found[0];
        const row = rows.find((r) => r.heroId === meta.id);
        if (!row) {
          return { content: `「${meta.name}」暂时没有可展示的胜率数据，稍后再试。`, isError: true };
        }
        text = formatHero(row);
      } else {
        const top = sortRows(rows, sort).slice(0, limit);
        text = formatList(top, sort);
      }

      let screenshotNote = '';
      if (args?.screenshot === true) {
        const sent = await captureAndSend(ctx, s);
        screenshotNote = sent ? '\n已顺带发了一张统计页截图。' : '';
      }

      return { content: `${text}${screenshotNote}` };
    }
  });

  api.registerTool({
    id: 'player_stats',
    name: '查询玩家战绩',
    description: '按 Steam 昵称（或 SteamID3）查 Deadlock 玩家的最近战绩与当前段位：每局的英雄、胜负、K/D/A、时长、净经济。',
    category: 'web',
    icon: '🎮',
    parameters: {
      type: 'object',
      properties: {
        player: { type: 'string', description: 'Steam 昵称，或纯数字的 SteamID3。' },
        limit: { type: 'integer', description: '返回最近几场，默认 8，最大 20。' }
      },
      required: ['player']
    },
    async execute(ctx, args) {
      const s = readSettings();
      const query = str(args?.player);
      if (!query) return { content: '请告诉我要查的玩家（Steam 昵称或 SteamID3）。', isError: true };
      const limit = Math.min(20, Math.max(1, Math.round(num(args?.limit, 8, 1, 20))));

      let profile = null;
      if (/^\d+$/.test(query)) {
        // 纯数字按 SteamID3 精确查；拿不到昵称也不影响按 id 查战绩
        const found = await searchPlayers(s, query, 1);
        profile = found[0] || { account_id: Number(query), personaname: `玩家${query}` };
      } else {
        const candidates = await searchPlayers(s, query, 10);
        if (!candidates.length) {
          return { content: `没找到叫「${query}」的玩家。可以试试更完整的 Steam 昵称，或直接给 SteamID3（纯数字）。`, isError: true };
        }
        const q = query.toLowerCase();
        const exact = candidates.filter((p) => String(p?.personaname || '').toLowerCase() === q);
        if (exact.length === 1) {
          profile = exact[0];
        } else if (exact.length > 1) {
          return { content: formatCandidates(exact, query) };
        } else if (candidates.length === 1) {
          profile = candidates[0];
        } else {
          return { content: formatCandidates(candidates, query) };
        }
      }

      const [matches, rank] = await Promise.all([
        fetchJson(`${s.apiBase}/v1/players/${profile.account_id}/match-history`, 25000).catch(() => []),
        fetchJson(`${s.apiBase}/v1/players/${profile.account_id}/rank`, 20000).catch(() => null)
      ]);
      const heroes = await getHeroes(s);
      const ranks = await getRanks(s);
      const recent = (Array.isArray(matches) ? matches : []).slice(0, limit);

      return { content: formatPlayer(profile, recent, rank, heroes, ranks) };
    }
  });

  api.registerTool({
    id: 'match_screenshot',
    name: '截取某场对局页面',
    description: '截取某场 Deadlock 对局的详情页并直接发到当前群聊。会自动去掉顶部折线图并截整页，尽量把双方 12 人战绩都收进来。match_id 从「查询玩家战绩」返回的『局号』里取。',
    category: 'web',
    icon: '📸',
    parameters: {
      type: 'object',
      properties: {
        match_id: { type: ['integer', 'string'], description: '对局编号（局号），纯数字，从查询玩家战绩结果里取。' }
      },
      required: ['match_id']
    },
    async execute(ctx, args) {
      const s = readSettings();
      const matchId = String(args?.match_id ?? '').trim();
      if (!/^\d+$/.test(matchId)) {
        return { content: '请给一个有效的对局编号（纯数字）。', isError: true };
      }
      const pageUrl = `https://deadlock-api.com/matches/${matchId}`;
      const sent = await captureAndSend(ctx, s, pageUrl, `Deadlock 对局 ${matchId} 截图`, { fullPage: true, matchMode: true });
      if (!sent) {
        return { content: `对局 ${matchId} 的截图生成失败（可能是页面没加载出来），稍后再试。`, isError: true };
      }
      return { content: `已发送对局 ${matchId} 的截图。页面：${pageUrl}` };
    }
  });

  log(`Deadlock 英雄数据已加载（${BUILD_TAG}）｜工具：${TOOL('hero_stats')} / ${TOOL('player_stats')} / ${TOOL('match_screenshot')}`);
}

export function available() {
  return { ok: true };
}

/** 测试/排障用导出。 */
export const __internals = { readSettings, buildStats, findHeroes, sortRows, formatHero, formatList, searchPlayers, formatCandidates, formatPlayer };
