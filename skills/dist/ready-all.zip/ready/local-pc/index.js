// 本地电脑操作（local-pc）—— 授权用户在 QQ 里指挥这台电脑：开程序、跑命令、读写文件、截图。
//
// ── 为什么是技能（skills/，LLM 型），不是插件（plugins/）──────────────────
//   「这句话是不是在让我操作电脑」「他说的‘打开那个’是哪个」「要不要先确认一下」
//   都得理解人话，写不成死规则；而插件只能提供 providers / hooks，模型根本看不见，
//   也就无法按语义触发。所以按 §0 的判据定成 LLM 型：registerTool 交给模型决定。
//
// ── 权限：默认只认授权过的 QQ 号 ─────────────────────────────────────────
//   这是把「执行权」接进 QQ，等于给聊天窗装了一个终端。所以：
//     · 号码只从两个地方读：本技能设置里的 ownerIds，留空则沿用「主人识别」
//       插件（owner-identity）里配的主人号码；
//     · 判定只认协议字段 senderId（QQ 号）—— 正文里自称主人完全不算数；
//     · 这一批触发消息里**只要有一个人不在名单里就整条拒绝**，
//       防止「主人和路人同时说话」被顺带执行；
//     · 还有一道「意图词」闸门：触发消息本身必须含有操作动作词。
//       它挡的不是紧张过头的模型，而是**网页/图片里的注入**：那种情况下
//       触发消息往往是主人随口闲聊，正文里一个动作词都没有。
//
// ── 高危操作 ──────────────────────────────────────────────────────────────
//   删除 / 覆盖已有文件 / 关机 / 改系统设置：必须
//     ① 设置里 allowDangerous = true，且 ② 调用时带 confirmed: true。
//   删文件走回收站（SendToRecycleBin）而不是永久删 —— 手滑了还能捞回来。
//   命令里出现 format / diskpart / bcdedit / reg delete / shutdown 这类，
//   一律按高危拦下，不靠模型自觉。
//
// ── 照 src/plugin-loader.js 的规矩 ───────────────────────────────────────
//   · 工具必须在 setup(api) 执行期间注册，写到别的函数里等于静默失效；
//   · 提示词片段走 manifest.prompt.sections（api 上没有注册提示词的方法）；
//   · 缓存/日志一律落在 DATA_DIR/local-pc/ 下，绝不用 process.cwd() 当锚点。

import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import { spawn } from 'node:child_process';
import { DATA_DIR } from '../../src/config.js';
import { getSkillConfig, setSkillConfig } from '../../src/skills/config.js';

const SKILL_ID = 'local-pc';
const BASE_DIR = path.join(DATA_DIR, SKILL_ID);
const SHOT_DIR = path.join(BASE_DIR, 'shots');
const AUDIT_FILE = path.join(BASE_DIR, 'audit.jsonl');
const PS = 'powershell.exe';

/** 与 skill.json 的 settings 保持一致（这里留一份，免得加载早期读到空配置）。 */
const DEFAULTS = {
  enabled: true,
  ownerIds: '',
  allowAnyone: false,
  requireIntentInMessage: true,
  allowCommand: true,
  allowFileWrite: true,
  allowDangerous: false,
  maxRuntimeSec: 30,
  maxOutputChars: 1200,
  auditLog: true,
  apps: '',
  appCacheHours: 6,
  allowElevated: false
};

let log = () => {};
let warn = () => {};

function cfg() {
  try {
    return { ...DEFAULTS, ...(getSkillConfig(SKILL_ID, DEFAULTS) || {}) };
  } catch {
    return { ...DEFAULTS };
  }
}

const ok = (content) => ({ content: String(content ?? '') });
const bad = (content) => ({ content: String(content ?? ''), isError: true });

// ─────────────────────────────────────────────── 权限
const QQ_NUMBER = /^\d{5,15}$/;

function normalizeIds(raw) {
  const list = Array.isArray(raw) ? raw : String(raw ?? '').split(/[,，;；\s]+/);
  const out = [];
  for (const item of list) {
    const id = String(item ?? '').trim();
    if (QQ_NUMBER.test(id) && !out.includes(id)) out.push(id);
  }
  return out;
}

/** 授权号码：本技能优先，没填就沿用「主人识别」插件的配置。 */
function allowedIds() {
  const own = normalizeIds(cfg().ownerIds);
  if (own.length) return own;
  try {
    return normalizeIds(getSkillConfig('owner-identity', {}).ids);
  } catch {
    return [];
  }
}

/** 这批触发消息里的发言人（只认协议字段 senderId）。 */
function callerIds(ctx) {
  const trigger = Array.isArray(ctx?.session?.trigger) ? ctx.session.trigger : [];
  const ids = trigger
    .filter((m) => m && !m.self)
    .map((m) => String(m.senderId ?? '').trim())
    .filter(Boolean);
  return [...new Set(ids)];
}

function triggerText(ctx) {
  const trigger = Array.isArray(ctx?.session?.trigger) ? ctx.session.trigger : [];
  return trigger
    .filter((m) => m && !m.self)
    .map((m) => String(m.text ?? ''))
    .filter(Boolean)
    .join('\n');
}

/**
 * 权限判定。
 * @returns {{ok: true} | {ok: false, reason: string}}
 */
function checkPermission(ctx) {
  const conf = cfg();
  if (conf.allowAnyone === true) return { ok: true };
  const list = allowedIds();
  if (!list.length) {
    return {
      ok: false,
      reason: '还没设置允许谁操作这台电脑（技能设置里的「允许操作的 QQ 号」，或「主人识别」插件里的主人号码）'
    };
  }
  const callers = callerIds(ctx);
  if (!callers.length) return { ok: false, reason: '认不出这条指令是谁发的，不敢动' };
  const stranger = callers.filter((id) => !list.includes(id));
  if (stranger.length) return { ok: false, reason: '发指令的人不在授权名单里' };
  return { ok: true };
}

/**
 * 意图闸门：触发消息本身得像一条「操作电脑」的指令。
 * 默认开启，挡网页注入（主人随口聊天时，正文里不会有动作词）。
 */
const INTENT_WORDS = [
  '打开', '启动', '运行', '执行', '关掉', '关闭', '退出', '结束', '截图', '截屏', '截个图',
  '帮我', '帮忙', '操作', '跑一下', '跑个', '命令行', '命令', 'cmd', 'powershell',
  '删', '删掉', '保存', '写入', '存成', '新建', '创建', '列出', '列一下', '读一下',
  '文件夹', '目录', '桌面', '电脑', '本机', '复制', '移动', '重命名', '改一下',
  '应用', '刷新'
];

function hasIntent(text) {
  const t = String(text ?? '');
  if (!t) return false;
  return INTENT_WORDS.some((w) => t.includes(w));
}

// ─────────────────────────────────────────────── 进程执行
function decode(buf, encoding = 'utf-8') {
  try {
    return new TextDecoder(encoding).decode(buf);
  } catch {
    return Buffer.from(buf).toString('utf8');
  }
}

/**
 * 起一个子进程收输出。超时就强杀 —— 不能让一条卡住的命令拖死整轮对话。
 * @returns {Promise<{ok: boolean, code: number|null, stdout: string, stderr: string, timedOut: boolean}>}
 */
function run(cmd, args, { timeoutMs = 20000, maxBytes = 512 * 1024 } = {}) {
  return new Promise((resolve) => {
    let child;
    try {
      child = spawn(cmd, args, { windowsHide: true, stdio: ['ignore', 'pipe', 'pipe'] });
    } catch (error) {
      resolve({ ok: false, code: null, stdout: '', stderr: String(error?.message ?? error), timedOut: false });
      return;
    }
    const chunks = { out: [], err: [] };
    const sizes = { out: 0, err: 0 };
    let timedOut = false;
    let settled = false;

    const timer = setTimeout(() => {
      timedOut = true;
      try { child.kill('SIGKILL'); } catch { /* 已经退出 */ }
    }, Math.max(1000, timeoutMs));

    const done = (code, error) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      resolve({
        ok: !error && code === 0,
        code: code ?? null,
        stdout: decode(Buffer.concat(chunks.out)),
        stderr: error ? String(error?.message ?? error) : decode(Buffer.concat(chunks.err)),
        timedOut
      });
    };

    child.stdout.on('data', (d) => {
      if (sizes.out < maxBytes) { chunks.out.push(d); sizes.out += d.length; }
    });
    child.stderr.on('data', (d) => {
      if (sizes.err < maxBytes) { chunks.err.push(d); sizes.err += d.length; }
    });
    child.on('error', (error) => done(null, error));
    child.on('close', (code) => done(code, null));
  });
}

/** PowerShell 单引号字符串转义（字面量，不做变量展开）。 */
function psQuote(s) {
  return `'${String(s ?? '').replace(/'/g, "''")}'`;
}

/**
 * 跑一段 PowerShell。
 * 用 -EncodedCommand 而不是拼 -Command：路径里的空格、引号、& 全都不用操心，
 * 也顺带把「参数注入」这条缝堵死。
 * 脚本开头统一把输出编码设成 UTF-8，否则中文输出回来说是乱码（PS 5.1 默认是 OEM 936）。
 *
 * ⚠️ 整段脚本包在 try/catch 里，错误用 `ERR|消息` 走 **stdout** 回来。
 * 为什么必须这样：PowerShell 5.1 在 stderr 被重定向时会输出 CLIXML
 * （`#< CLIXML <Objs Version="1.1.0.1" ...`），那是一坨 XML，直接回给用户
 * 就是「#< CLIXML…（后面还有 900 字没显示）」这种天书 —— 真实原因（比如
 * 「拒绝访问」「找不到文件」）全被埋在里面。改走 stdout + 我们自己清洗，
 * 才能保证回给人的永远是「人话」。
 */
function runPs(body, timeoutMs) {
  const prelude = "[Console]::OutputEncoding=[System.Text.Encoding]::UTF8;"
    + "$ErrorActionPreference='Stop';$ProgressPreference='SilentlyContinue';\r\n";
  const script = `${prelude}try {\r\n${String(body ?? '')}\r\n} catch { 'ERR|' + $_.Exception.Message }\r\n`;
  const encoded = Buffer.from(script, 'utf16le').toString('base64');
  return run(PS, ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-EncodedCommand', encoded], { timeoutMs });
}

/**
 * 把 PowerShell 的错误文本洗成人话。
 * 认得两种脏东西：CLIXML 包壳（取 <S S="Error"> 里的正文）和 _x000D__x000A_ 转义。
 */
function cleanPsMessage(text) {
  let s = String(text ?? '');
  if (s.includes('<Objs') || s.trimStart().startsWith('#< CLIXML')) {
    const parts = [...s.matchAll(/<S S="Error">([\s\S]*?)<\/S>/g)].map((m) => m[1]);
    s = parts.length ? parts.join('') : s.replace(/<[^>]*>/g, ' ');
  }
  s = s
    .replace(/_x000D__x000A_/g, '\n')
    .replace(/_x000D_/g, '')
    .replace(/_x000A_/g, '\n')
    .replace(/#< CLIXML/g, '')
    .replace(/<[^>]*>/g, ' ');
  return s.replace(/[ \t]+/g, ' ').replace(/\s*\n\s*/g, ' ').trim();
}

/** 一次 PowerShell 调用的失败原因（优先取 ERR|，其次清洗过的 stderr）。 */
function psErrorOf(r) {
  const fromStdout = String(r?.stdout ?? '').match(/^ERR\|(.*)$/m);
  if (fromStdout) return cleanPsMessage(fromStdout[1]);
  return cleanPsMessage(r?.stderr ?? '');
}

/** stdout 里最后一条有内容的行（用来读 OK| / MISSING| 这类标记）。 */
function lastLineOf(r) {
  return String(r?.stdout ?? '').trim().split(/\r?\n/).filter(Boolean).pop() || '';
}

/** 这个错误是不是「要管理员权限」。 */
function isElevationError(text) {
  return /requires elevation|requested operation requires elevation|需要提升|请求的操作需要提升|requires administrator|administrator privileges|访问被拒绝|拒绝访问|access is denied|0x800704e8|0x80070005/i.test(String(text ?? ''));
}

/** 这个错误是不是「用户把 UAC 弹窗点了取消」。 */
function isElevationCancelled(text) {
  return /操作已被用户取消|canceled by the user|cancelled by the user|0x800704c7/i.test(String(text ?? ''));
}

function clampNum(v, lo, hi, fallback) {
  const n = Number(v);
  if (!Number.isFinite(n)) return fallback;
  return Math.max(lo, Math.min(hi, Math.round(n)));
}

function timeoutOf(args) {
  const conf = cfg();
  const base = clampNum(conf.maxRuntimeSec, 1, 120, 30);
  return clampNum(args?.timeoutSec, 1, 120, base) * 1000;
}

function trim(text, max) {
  const s = String(text ?? '').trim();
  if (!s) return '';
  return s.length <= max ? s : `${s.slice(0, max)}…（后面还有 ${s.length - max} 字没显示）`;
}

// ─────────────────────────────────────────────── 审计
function audit(entry) {
  if (cfg().auditLog === false) return;
  try {
    fs.mkdirSync(BASE_DIR, { recursive: true });
    fs.appendFileSync(AUDIT_FILE, `${JSON.stringify({ at: new Date().toISOString(), ...entry })}\n`, 'utf8');
  } catch { /* 审计写不进去不该连带执行失败 */ }
}

// ─────────────────────────────────────────────── 应用清单（自动发现 + 自定义别名）
//
// 为什么要有清单：只在开始菜单里按字面模糊找，会出「说打开 QQ音乐、结果开了 QQ」这种
// 事故 —— 旧实现按 BaseName.Length **升序**取第一个，名字短的永远优先，「QQ」(2 字)
// 必然压过「QQ音乐」(4 字)。这不是模型的锅，是匹配算法写反了。
//
// 现在的做法：
//   ① 把机器上真正装了的东西扫成一份清单（开始菜单 .lnk + 桌面 .lnk + 商店应用），
//      条目带的是用户在开始菜单里看到的名字；
//   ② 打分排序：完全相等 > 以它开头 > 包含它 > 被它包含。**同分就是歧义**，
//      歧义时把候选列出来让人挑，绝不猜 —— 宁可不做，也别把 QQ音乐 开成 QQ；
//   ③ 允许用设置里的别名表覆盖（一行一组「名字=目标」），也可以直接在聊天里让它
//      记住（add_app），记下的会写回同一份设置，界面上也能看到。

const APPS_FILE = path.join(BASE_DIR, 'apps.json');

/**
 * 清单格式版本。改了字段含义就 +1，让旧缓存自动失效。
 * v2：条目从「.lnk 路径」换成「真的 exe + 工作目录 + 参数」——
 *     旧缓存里存的是 lnk，直接用新逻辑启动会解析错，必须强制重扫。
 */
const CATALOG_VERSION = 2;

/** 归一化比较用：去全角/半角括号注释、去空白、转小写。 */
function normName(s) {
  return String(s ?? '')
    .toLowerCase()
    .replace(/（[^）]*）|\([^)]*\)/g, '')
    .replace(/\s+/g, '')
    .trim();
}

/** 解析别名表：`名字=目标; 名字2=目标2`（也认全角「＝」「：」「；」和新行）。 */
function parseAliases(raw) {
  const out = [];
  for (const chunk of String(raw ?? '').split(/[;；\n]/)) {
    const line = chunk.trim();
    if (!line) continue;
    const idx = line.search(/[=＝：]/);
    if (idx <= 0) continue;
    const name = line.slice(0, idx).trim();
    const target = line.slice(idx + 1).trim();
    if (name) out.push({ name, target: target || name });
  }
  return out;
}

let catalogCache = null;

function catalogFresh(cat) {
  if (!cat || !Array.isArray(cat.items)) return false;
  // 旧版本格式（存的是 lnk 而不是 exe）一律当过期，强制重扫
  if (Number(cat.v || 0) !== CATALOG_VERSION) return false;
  const hours = clampNum(cfg().appCacheHours, 0, 720, 6);
  if (hours <= 0) return false;
  return (Date.now() - Number(cat.at || 0)) < hours * 3600 * 1000;
}

function readCatalogFromDisk() {
  try {
    return JSON.parse(fs.readFileSync(APPS_FILE, 'utf8'));
  } catch {
    return null;
  }
}

/**
 * 扫这台电脑上能启动的应用。缓存到 data/local-pc/apps.json，
 * 默认 6 小时内不重扫（扫一次约 2~4 秒，每次都扫会把工具调用拖慢）。
 *
 * ⚠️ 清单里存的是**真正的 exe**，不是 .lnk。
 * 快捷方式只是个壳：壳坏了（程序挪了位置）它还在，点下去只会得到一句含糊的
 * 「拒绝访问」；而壳里真正有用的东西是**目标 exe + 工作目录 + 启动参数**。
 * 所以扫的时候就把三者解开、目标不存在的壳直接丢掉，清单里剩下的都是能跑的。
 * 启动时也照这三样去开 exe —— 既不依赖那个壳，又不会因为丢了工作目录/参数
 * 让程序启动不起来。
 */
async function scanApps({ force = false, timeoutMs = 25000 } = {}) {
  if (!force && catalogFresh(catalogCache)) return catalogCache;
  if (!force) {
    const disk = readCatalogFromDisk();
    if (catalogFresh(disk)) { catalogCache = disk; return disk; }
  }

  const script = `
$out = New-Object System.Collections.ArrayList
$sh = New-Object -ComObject WScript.Shell
$dirs = @(
  (Join-Path $env:APPDATA 'Microsoft\\Windows\\Start Menu\\Programs'),
  (Join-Path $env:ProgramData 'Microsoft\\Windows\\Start Menu\\Programs'),
  [Environment]::GetFolderPath('Desktop'),
  (Join-Path $env:PUBLIC 'Desktop')
)
foreach ($d in $dirs) {
  if (-not (Test-Path -LiteralPath $d)) { continue }
  Get-ChildItem -Path $d -Recurse -Filter *.lnk -ErrorAction SilentlyContinue | ForEach-Object {
    try {
      $sc = $sh.CreateShortcut($_.FullName)
      $tp = $sc.TargetPath
      if (-not $tp) { return }
      if (-not (Test-Path -LiteralPath $tp)) { return }
      [void]$out.Add('EXE' + [char]9 + $_.BaseName + [char]9 + $tp + [char]9 + $sc.WorkingDirectory + [char]9 + $sc.Arguments)
    } catch { }
  }
}
Get-StartApps -ErrorAction SilentlyContinue | ForEach-Object {
  [void]$out.Add('APP' + [char]9 + $_.Name + [char]9 + $_.AppID + [char]9 + '' + [char]9 + '')
}
$out -join "\`n"
`;

  const r = await runPs(script, timeoutMs);

  /** 快捷方式名字弄干净：「QQ音乐 - 快捷方式」「BetterGI.exe」→「QQ音乐」「BetterGI」 */
  const prettyName = (raw) => String(raw ?? '')
    .replace(/\s*[-–—]\s*(快捷方式|Shortcut)$/i, '')
    .replace(/\.(exe|lnk)$/i, '')
    .trim();

  const byExe = new Map();
  const byName = new Map();
  for (const line of String(r.stdout || '').split(/\r?\n/)) {
    const parts = line.split('\t');
    if (parts.length < 3) continue;
    const [kind, rawName, target, workdir = '', args = ''] = parts;
    const name = prettyName(rawName);
    const cleanTarget = String(target ?? '').trim();
    if (!name || !cleanTarget) continue;
    const key = normName(name);
    if (!key) continue;

    if (kind === 'EXE') {
      // 同一个 exe 被好几个快捷方式指着时，留名字最短的那个（更像原名，
      // 不是「某某 - 副本」「某某 (2)」）
      const exeKey = cleanTarget.toLowerCase();
      const existing = byExe.get(exeKey);
      if (existing && normName(existing.name).length <= key.length) continue;
      const item = { name, kind: 'exe', target: cleanTarget, workdir: String(workdir || '').trim(), args: String(args || '').trim() };
      byExe.set(exeKey, item);
      byName.set(key, item);
      continue;
    }

    // 商店应用（没有 exe，只能走 shell:AppsFolder）
    if (!byName.has(key)) {
      const item = { name, kind: 'appid', target: cleanTarget, workdir: '', args: '' };
      byName.set(key, item);
    }
  }

  // 以名字为准输出；exe 去重后可能同名的，按名字去重时已经合过
  const seen = new Set();
  const items = [];
  for (const item of byName.values()) {
    const k = `${item.kind}:${item.target.toLowerCase()}`;
    if (seen.has(k)) continue;
    seen.add(k);
    items.push(item);
  }

  if (!items.length) {
    // 扫不出来（PowerShell 被拦/超时）：宁可退回旧清单，也别把清单清空
    const disk = readCatalogFromDisk();
    if (disk && Array.isArray(disk.items) && disk.items.length) {
      catalogCache = disk;
      warn?.(`应用清单重扫失败（${r.timedOut ? '超时' : '无输出'}），改用旧清单（${disk.items.length} 个）`);
      return disk;
    }
    return { at: Date.now(), v: CATALOG_VERSION, items: [] };
  }

  const catalog = {
    at: Date.now(),
    v: CATALOG_VERSION,
    items: items.sort((a, b) => a.name.localeCompare(b.name, 'zh-CN'))
  };
  catalogCache = catalog;
  try {
    fs.mkdirSync(BASE_DIR, { recursive: true });
    fs.writeFileSync(APPS_FILE, JSON.stringify(catalog), 'utf8');
  } catch { /* 缓存写不进去不影响这次使用 */ }
  return catalog;
}

/**
 * 按匹配度排序的候选（带分数）。别名命中（score 2000）永远排最前。
 *
 * 打分口径（越大越像）：
 *   完全相等 1000 > 以它开头 700 > 包含它 400 > 被它包含 200+名字长度
 * 之所以「被它包含」要加长度：说「QQ音乐客户端」时，名字叫「QQ音乐」的比叫「QQ」的更具体，
 * 不加长度这两个会同分、被误判成歧义。
 */
function rankApps(query, catalog) {
  const nq = normName(query);
  if (!nq) return [];

  const out = [];
  // ① 自定义别名（主人亲口记下的名字，比开始菜单里的名字可信）
  for (const a of parseAliases(cfg().apps)) {
    if (normName(a.name) === nq) out.push({ it: { name: a.name, target: a.target, kind: 'custom' }, score: 2000 });
  }

  const scoreOf = (name) => {
    const n = normName(name);
    if (!n) return 0;
    if (n === nq) return 1000;
    if (n.startsWith(nq)) return 700;
    if (n.includes(nq)) return 400;
    if (nq.includes(n)) return 200 + Math.min(n.length, 90);
    return 0;
  };

  for (const it of (catalog?.items || [])) {
    const s = scoreOf(it.name);
    if (s > 0) out.push({ it, score: s });
  }
  return out.sort((a, b) => b.score - a.score);
}

/**
 * 名字 → 应用。打分排序，**同分不猜**。
 * （导出是为了自检脚本能直接验证打分逻辑；加载器不消费这个名字。）
 * @returns {{kind:'hit', item:object, via:string, ranked:object[]} | {kind:'ambiguous', candidates:object[]} | {kind:'miss'}}
 */
export function resolveApp(query, catalog) {
  const ranked = rankApps(query, catalog);
  if (!ranked.length) return { kind: 'miss' };

  const top = ranked[0].score;
  const best = ranked.filter((x) => x.score === top);
  const all = ranked.map((x) => x.it);
  if (best.length === 1) {
    return { kind: 'hit', item: best[0].it, via: top >= 2000 ? '别名' : '清单', ranked: all.slice(0, 5) };
  }
  // 同分 = 真的有多个叫得上的东西 → 列出来让人挑
  return { kind: 'ambiguous', candidates: all.slice(0, 8) };
}

/**
 * 真正启动一次，返回**结构化**结果，不拼人话（拼人话交给 launchResultText）。
 * 分层是为了让「这个快捷方式坏了 → 换下一个候选」这种补救逻辑写得出来。
 *
 * ③ 里那句 MISSING| 很关键：Windows 对「快捷方式指向的文件不存在」回的是
 * 一堆含糊的话（用户看到的就是「拒绝访问」），必须先自己 Test-Path，
 * 才能给出「它指向的 xx 文件已经不在了」这种能让人行动的解释。
 */
async function tryLaunch(item, timeoutMs) {
  const target = String(item?.target ?? '').trim();
  if (!target) return { status: 'error', message: '这个应用没有可启动的目标。' };

  const isAppId = item.kind === 'appid';
  const isLnk = /\.lnk$/i.test(target);

  const build = (elevated) => {
    if (isAppId) {
      return `Start-Process -FilePath 'explorer.exe' -ArgumentList ${psQuote(`shell:AppsFolder\\${target}`)}; 'OK|store'`;
    }
    const lines = [];
    if (isLnk) {
      // 自定义别名可能指到 .lnk 上：那就现解一层，拿到 exe / 工作目录 / 参数
      lines.push('$sh = New-Object -ComObject WScript.Shell');
      lines.push(`$sc = $sh.CreateShortcut(${psQuote(target)})`);
      lines.push('$exe = $sc.TargetPath');
      lines.push('$wd = $sc.WorkingDirectory');
      lines.push('$ar = $sc.Arguments');
    } else {
      // 清单里存的就是 exe，工作目录和参数一并带上 —— 少了它们，
      // 有些程序会找不到自己的资源文件而直接闪退
      lines.push(`$exe = ${psQuote(target)}`);
      lines.push(`$wd = ${psQuote(String(item?.workdir ?? '').trim())}`);
      lines.push(`$ar = ${psQuote(String(item?.args ?? '').trim())}`);
    }
    lines.push("if (-not $exe) { 'MISSING|（这个快捷方式没有指向任何程序）'; return }");
    lines.push("if (-not (Test-Path -LiteralPath $exe)) { 'MISSING|' + $exe; return }");
    lines.push("$p = @{ FilePath = $exe; ErrorAction = 'Stop' }");
    lines.push('if ($wd -and (Test-Path -LiteralPath $wd)) { $p.WorkingDirectory = $wd }');
    lines.push('if ($ar) { $p.ArgumentList = $ar }');
    if (elevated) lines.push("$p.Verb = 'RunAs'");
    lines.push('Start-Process @p');
    lines.push(elevated ? "'OK|elevated'" : "'OK|start'");
    return lines.join('\r\n');
  };

  const r = await runPs(build(false), timeoutMs);
  const line = lastLineOf(r);
  if (line.startsWith('OK|')) return { status: 'ok', elevated: false };
  if (line.startsWith('MISSING|')) return { status: 'missing', target: line.slice('MISSING|'.length).trim() };
  if (r.timedOut) return { status: 'timeout' };

  const err = psErrorOf(r);
  if (isElevationCancelled(err)) return { status: 'elevation-cancelled' };
  if (!isElevationError(err)) return { status: 'error', message: err };

  // 需要管理员权限
  if (cfg().allowElevated !== true) return { status: 'elevation', message: err };

  const r2 = await runPs(build(true), timeoutMs);
  const line2 = lastLineOf(r2);
  if (line2.startsWith('OK|')) return { status: 'ok', elevated: true };
  if (r2.timedOut) return { status: 'timeout' };
  const err2 = psErrorOf(r2);
  if (isElevationCancelled(err2)) return { status: 'elevation-cancelled' };
  return { status: 'error', message: err2 || err };
}

/** 把 tryLaunch 的结构化结果说成人话。 */
function launchResultText(item, res) {
  const name = item?.name || '这个程序';
  switch (res.status) {
    case 'ok':
      return res.elevated
        ? ok(`已经用管理员身份打开了「${name}」（你点的那下确认生效了）。`)
        : ok(`已经打开了「${name}」。`);
    case 'elevation':
      return bad(`「${name}」要以管理员身份才能启动。到「技能 → 本地电脑操作」里打开「允许以管理员身份启动」，我再试一次 —— 到时候 Windows 会弹一个确认框，得你点一下「是」（这个框机器人点不了）。`);
    case 'elevation-cancelled':
      return bad(`管理员确认框被取消了，所以「${name}」没打开。要开的话再说一次。`);
    case 'timeout':
      return bad(`打开「${name}」超时了，可能它卡在启动，或者弹了需要点确认的窗口。`);
    case 'missing':
      return bad(`「${name}」要启动的程序文件找不到了：${res.target}（可能被挪走或卸载了）。`);
    default:
      return bad(`打开「${name}」没成功：${trim(res.message || '没有返回原因', 120)}`);
  }
}

/** 单个目标的启动（网址 / 完整路径用；按名字找的走 doOpenApp 的多候选逻辑）。 */
async function launchTarget(item, timeoutMs) {
  return launchResultText(item, await tryLaunch(item, timeoutMs));
}

// ─────────────────────────────────────────────── 动作：开程序
async function doOpenApp(target, timeoutMs, { refresh = false } = {}) {
  const t = String(target ?? '').trim();
  if (!t) return bad('没说要打开什么。');
  if (t.length > 500) return bad('要打开的名字太长了。');

  // ① 网址：直接交给默认浏览器
  if (/^(https?|mailto):/i.test(t)) {
    return launchTarget({ name: t, target: t, kind: 'url' }, timeoutMs);
  }

  // ② 现成的路径：不查清单，直接开（用户已经说得很具体了）
  try {
    if (path.isAbsolute(t) && fs.existsSync(t)) {
      return launchTarget({ name: path.basename(t, path.extname(t)) || t, target: t, kind: 'path' }, timeoutMs);
    }
  } catch { /* 路径判断失败就走清单 */ }

  // ③ 按名字查清单
  const catalog = await scanApps({ force: refresh, timeoutMs });
  if (!catalog.items.length) {
    return bad('应用清单扫不出来（可能是 PowerShell 被限制），现在只能按完整路径打开。');
  }

  const hit = resolveApp(t, catalog);
  if (hit.kind === 'ambiguous') {
    const lines = hit.candidates.map((c, i) => `${i + 1}. ${c.name}`);
    return bad(`「${t}」能对上好几个，我不猜，让人挑一个：\n${lines.join('\n')}\n（回一句要第几个，或者直接说准确名字；也可以说「列表」看全部。）`);
  }
  if (hit.kind === 'miss') {
    return bad(`清单里没有叫「${t}」的应用。可以先用 list_apps 查一下有什么（支持按关键词搜），别硬猜。`);
  }

  // ④ 依次试前几个候选：同名快捷方式里常有坏掉的（程序挪了位置，旧快捷方式还在）
  const broken = [];
  for (const cand of (hit.ranked || [hit.item]).slice(0, 3)) {
    const res = await tryLaunch(cand, timeoutMs);
    if (res.status === 'missing') { broken.push(`${cand.name} → ${res.target}`); continue; }
    return launchResultText(cand, res);
  }
  return bad(`找到的「${t}」都指向已经不在的程序文件：${broken.join('；')}。可以用 list_apps 带 refresh=true 重扫一次，或者直接给完整路径。`);
}

/** 列出可操作的应用（带关键词搜索），让主人看一眼有什么。 */
async function doListApps(keyword, limit, timeoutMs, refresh) {
  const catalog = await scanApps({ force: refresh === true, timeoutMs });
  if (!catalog.items.length) return bad('应用清单扫不出来（可能是 PowerShell 被限制）。');

  const k = String(keyword ?? '').trim();
  let items = catalog.items;
  let title = `这台电脑上能打开的应用共 ${catalog.items.length} 个`;
  if (k) {
    const nk = normName(k);
    items = catalog.items
      .map((it) => {
        const n = normName(it.name);
        if (!nk) return { it, s: 0 };
        if (n === nk) return { it, s: 3 };
        if (n.startsWith(nk)) return { it, s: 2 };
        if (n.includes(nk)) return { it, s: 1 };
        return { it, s: 0 };
      })
      .filter((x) => x.s > 0)
      .sort((a, b) => b.s - a.s || a.it.name.localeCompare(b.it.name, 'zh-CN'))
      .map((x) => x.it);
    title = `名字里带「${k}」的应用有 ${items.length} 个`;
    if (!items.length) {
      return ok(`没找到名字里带「${k}」的应用。可以说个更短的关键词再查，或者直接给完整路径。`);
    }
  }

  const max = clampNum(limit, 1, 80, 40);
  const shown = items.slice(0, max);
  const lines = [];

  const aliases = parseAliases(cfg().apps);
  if (aliases.length) lines.push(`我记得的快捷名（说这些就能开）：${aliases.map((a) => a.name).join('、')}`);

  lines.push(`${title}：`);
  lines.push(shown.map((it, i) => `${i + 1}. ${it.name}`).join('\n'));

  const rest = items.length - shown.length;
  if (rest > 0) lines.push(`（还有 ${rest} 个没列出来，带个关键词再查就能看到）`);
  lines.push('要开哪个直接说名字就行；名字对不上就用上面列的原文。');
  return ok(lines.join('\n'));
}

/** 把一个应用记进别名表（写回技能设置，界面上也能看到）。 */
async function doAddApp(name, target, timeoutMs) {
  const n = String(name ?? '').trim();
  let t = String(target ?? '').trim();
  if (!n) return bad('得给这个应用起个名字，比如「QQ音乐」。');
  if (n.length > 40) return bad('名字太长了（最多 40 字）。');
  if (/[;,；=＝：]/.test(n)) return bad('名字里不能有 = ; ： 这些符号。');

  // 没给目标就按名字去清单里找一次，别存一个永远打不开的条目
  if (!t) {
    const catalog = await scanApps({ timeoutMs });
    const hit = resolveApp(n, catalog);
    if (hit.kind !== 'hit') {
      return bad(`不知道「${n}」对应哪个程序。让它给个完整路径（比如 D:\\软件\\QQMusic\\QQMusic.exe）再记。`);
    }
    t = hit.item.target;
  } else if (!/^(https?|mailto):/i.test(t) && !fs.existsSync(t)) {
    return bad(`这个路径不存在：${t}，记下去也是打不开。确认一下路径。`);
  }

  const aliases = parseAliases(cfg().apps).filter((a) => normName(a.name) !== normName(n));
  aliases.push({ name: n, target: t });
  const value = aliases.map((a) => `${a.name}=${a.target}`).join('; ');
  try {
    setSkillConfig(SKILL_ID, { apps: value });
  } catch (error) {
    return bad(`写进设置失败（${error?.message ?? error}）。`);
  }
  return ok(`记住了：以后说「打开${n}」就会开它（现在一共记了 ${aliases.length} 个）。`);
}

// ─────────────────────────────────────────────── 动作：关程序
const PROTECTED_PROCESSES = new Set([
  'csrss', 'winlogon', 'lsass', 'services', 'svchost', 'smss', 'wininit', 'system',
  'explorer', 'dwm', 'fontdrvhost', 'sihost', 'taskhostw', 'ctfmon', 'conhost',
  'powershell', 'pwsh', 'cmd', 'node', 'electron', 'qq', 'qqagent'
]);

async function doCloseApp(target, timeoutMs) {
  const raw = String(target ?? '').trim();
  if (!raw) return bad('没说要关掉哪个程序。');
  const base = raw.replace(/\.exe$/i, '').trim().toLowerCase();
  if (!base) return bad('没说要关掉哪个程序。');
  if (PROTECTED_PROCESSES.has(base)) {
    return bad(`「${raw}」是系统或本程序自己的进程，为了不让电脑出问题，这个不能关。`);
  }

  const script = `
$n = ${psQuote(base)}
$p = @(Get-Process -Name $n -ErrorAction SilentlyContinue)
if ($p.Count -eq 0) { 'NONE' } else {
  $p | Stop-Process -Force -ErrorAction SilentlyContinue
  'KILLED|' + $p.Count
}
`;
  const r = await runPs(script, timeoutMs);
  const line = lastLineOf(r);
  if (line === 'NONE') return ok(`「${raw}」本来就没在运行。`);
  if (line.startsWith('KILLED|')) return ok(`已经把「${raw}」关掉了。`);
  if (r.timedOut) return bad(`关「${raw}」超时了，可能它不肯退出。`);
  return bad(`关「${raw}」没成功：${trim(psErrorOf(r) || '可能名字不对，或者没有权限', 120)}`);
}

// ─────────────────────────────────────────────── 动作：跑命令
const DANGER_PATTERNS = [
  /\bformat(\.com)?\b/i,
  /\bdiskpart\b/i,
  /\bbcdedit\b/i,
  /\bvssadmin\b/i,
  /\bcipher\b[^|]*\/w/i,
  /\breg(\.exe)?\s+delete\b/i,
  /\brd\b[^|]*\/s/i,
  /\brmdir\b[^|]*\/s/i,
  /\bdel\b[^|]*\/[fsq]/i,
  /\bshutdown\b/i,
  /\b(logoff|stop-computer|restart-computer)\b/i,
  /\bnet\s+user\b[^|]*\/delete/i,
  /\bsc(\.exe)?\s+delete\b/i,
  /\bremove-item\b[^|]*-recurse/i,
  /\brm\s+-[a-z]*r[a-z]*f?\b/i,
  /\btakeown\b/i,
  /\bicacls\b/i,
  /\bstart-process\b[^|]*-verb\s+runas/i,
  /\brunas\b/i,
  /\bset-executionpolicy\b/i,
  /\bnetsh\b[^|]*firewall/i,
  /\bwmic\b[^|]*\bdelete\b/i,
  /\buninstall-|disable-windowsoptionalfeature/i
];

function looksDangerousCommand(command) {
  const c = String(command ?? '');
  return DANGER_PATTERNS.some((re) => re.test(c));
}

async function doRunCommand(command, shell, timeoutMs) {
  const cmdText = String(command ?? '').trim();
  if (!cmdText) return bad('没给要执行的命令。');
  if (cmdText.length > 4000) return bad('命令太长了。');

  const conf = cfg();
  const dangerous = looksDangerousCommand(cmdText);
  if (dangerous && conf.allowDangerous !== true) {
    return bad('这条命令属于高危操作（涉及格式化/删注册表/关机/改权限这类），当前设置不允许，没执行。');
  }

  if (String(shell || '').toLowerCase() === 'cmd') {
    // chcp 65001 让 cmd 的输出是 UTF-8，否则中文回来是乱码
    const r = await run('cmd.exe', ['/d', '/s', '/c', `chcp 65001 >nul & ${cmdText}`], { timeoutMs });
    return commandResult(r, cmdText);
  }
  const r = await runPs(cmdText, timeoutMs);
  return commandResult(r, cmdText);
}

function commandResult(r, cmdText) {
  const conf = cfg();
  const max = clampNum(conf.maxOutputChars, 100, 8000, 1200);
  // PowerShell 侧的异常走 ERR| 回显在 stdout 里（runPs 的 try/catch），要按失败处理
  const errLine = String(r.stdout || '').match(/^ERR\|(.*)$/m);
  if (errLine) return bad(`命令执行失败：${trim(cleanPsMessage(errLine[1]), max)}`);
  const out = trim(String(r.stdout || '').replace(/^ERR\|.*$/gm, ''), max);
  const err = trim(psErrorOf(r), max);
  if (r.timedOut) {
    return bad(`命令跑了 ${Math.round(timeoutOf({}) / 1000)} 秒还没结束，已经被我掐了。${out ? `\n已完成部分的输出：\n${out}` : ''}`);
  }
  if (r.ok) {
    return ok(`命令执行成功${out ? `，输出：\n${out}` : '（没有输出）'}`);
  }
  return bad(`命令执行失败（退出码 ${r.code}）${err ? `：\n${err}` : ''}${out ? `\n输出：\n${out}` : ''}`);
}

// ─────────────────────────────────────────────── 动作：看目录 / 读文件 / 写文件
async function doListDir(target, timeoutMs) {
  const p = String(target ?? '').trim() || os.homedir();
  let dir = p;
  if (!path.isAbsolute(dir)) dir = path.resolve(os.homedir(), dir);
  let stat;
  try {
    stat = fs.statSync(dir);
  } catch {
    return bad(`找不到这个目录：${p}`);
  }
  if (!stat.isDirectory()) return bad(`「${p}」不是一个目录。`);

  let names;
  try {
    names = fs.readdirSync(dir, { withFileTypes: true });
  } catch (error) {
    return bad(`这个目录读不出来（${error?.code ?? '权限不足'}）。`);
  }
  const shown = names.slice(0, 100).map((d) => {
    let size = '';
    if (d.isFile()) {
      try { size = ` ${Math.max(1, Math.round(fs.statSync(path.join(dir, d.name)).size / 1024))}KB`; } catch { size = ''; }
    }
    return `${d.isDirectory() ? '[目录]' : '[文件]'} ${d.name}${size}`;
  });
  const more = names.length > shown.length ? `\n（共 ${names.length} 项，只列了前 ${shown.length} 项）` : '';
  return ok(`${p} 里面有 ${names.length} 项：\n${shown.join('\n')}${more}`);
}

async function doReadFile(target) {
  const p = String(target ?? '').trim();
  if (!p) return bad('没说读哪个文件。');
  const abs = path.isAbsolute(p) ? p : path.resolve(os.homedir(), p);
  let stat;
  try {
    stat = fs.statSync(abs);
  } catch {
    return bad(`找不到这个文件：${p}`);
  }
  if (!stat.isFile()) return bad(`「${p}」不是文件。`);
  if (stat.size > 2 * 1024 * 1024) return bad(`文件太大了（${Math.round(stat.size / 1048576)}MB），不读。`);

  let buf;
  try {
    buf = fs.readFileSync(abs);
  } catch (error) {
    return bad(`这个文件读不出来（${error?.code ?? '权限不足'}）。`);
  }
  if (buf.includes(0)) return bad('这个像是二进制文件，不当文本读。');
  const conf = cfg();
  const max = clampNum(conf.maxOutputChars, 100, 8000, 1200);
  return ok(`${p} 的内容：\n${trim(decode(buf), max)}`);
}

async function doWriteFile(target, content, confirmed) {
  const p = String(target ?? '').trim();
  if (!p) return bad('没说写到哪个文件。');
  const abs = path.isAbsolute(p) ? p : path.resolve(os.homedir(), p);
  const text = String(content ?? '');
  if (!text) return bad('没给要写的内容。');
  if (text.length > 200 * 1024) return bad('内容太长了（超过 200KB）。');

  if (fs.existsSync(abs) && confirmed !== true) {
    return bad(`文件「${p}」已经存在了。要覆盖它得先问过用户、得到明确同意后再带 confirmed=true 调一次。`);
  }
  try {
    fs.mkdirSync(path.dirname(abs), { recursive: true });
    fs.writeFileSync(abs, text, 'utf8');
  } catch (error) {
    return bad(`写不进去（${error?.code ?? error?.message ?? error}）。`);
  }
  return ok(`已经写到 ${p}（${text.length} 字）。`);
}

// ─────────────────────────────────────────────── 动作：删除（高危）
function isProtectedPath(p) {
  const low = path.resolve(p).toLowerCase();
  const roots = [
    process.env.SystemRoot || 'C:\\Windows',
    process.env.ProgramFiles,
    process.env['ProgramFiles(x86)'],
    process.env.ProgramData
  ].filter(Boolean).map((x) => path.resolve(String(x)).toLowerCase());
  if (roots.some((r) => low === r || low.startsWith(`${r}${path.sep}`))) return true;
  const home = path.resolve(os.homedir()).toLowerCase();
  if (low === home) return true;
  const parsed = path.parse(low);
  if (low === parsed.root.toLowerCase()) return true;
  if (low.length <= 3) return true;
  if (low.includes(`${path.sep}windows${path.sep}`)) return true;
  return false;
}

async function doDelete(target, confirmed, timeoutMs) {
  const p = String(target ?? '').trim();
  if (!p) return bad('没说删什么。');
  const abs = path.isAbsolute(p) ? p : path.resolve(os.homedir(), p);
  if (!fs.existsSync(abs)) return bad(`找不到「${p}」，没删。`);
  if (isProtectedPath(abs)) return bad('这个位置在系统目录里，属于保护范围，不删。');

  const conf = cfg();
  if (conf.allowDangerous !== true) return bad('删除属于高危操作，当前设置没开「允许高危操作」，没删。');
  if (confirmed !== true) return bad(`要删「${p}」得先问过用户、得到明确同意后再带 confirmed=true 调一次。`);

  // 走回收站：手滑了还能捞回来
  const script = `
$p = ${psQuote(abs)}
Add-Type -AssemblyName Microsoft.VisualBasic
if (Test-Path -LiteralPath $p -PathType Container) {
  [Microsoft.VisualBasic.FileIO.FileSystem]::DeleteDirectory($p, 'OnlyErrorDialogs', 'SendToRecycleBin')
} else {
  [Microsoft.VisualBasic.FileIO.FileSystem]::DeleteFile($p, 'OnlyErrorDialogs', 'SendToRecycleBin')
}
'DONE'
`;
  const r = await runPs(script, timeoutMs);
  if (String(r.stdout || '').includes('DONE')) return ok(`已经把「${p}」删了（在回收站里，还想要可以捞回来）。`);
  return bad(`删「${p}」没成功：${trim(psErrorOf(r) || '可能被占用，或者没有权限', 200)}`);
}

// ─────────────────────────────────────────────── 动作：截图
async function doScreenshot(ctx, timeoutMs) {
  if (!ctx?.sender?.sendImage) return bad('当前环境没法把图发到会话里。');
  if (!ctx?.chatKey) return bad('不知道要发到哪个会话。');

  try {
    fs.mkdirSync(SHOT_DIR, { recursive: true });
  } catch {
    return bad('截图目录建不出来。');
  }
  const file = path.join(SHOT_DIR, `${Date.now().toString(36)}.png`);

  const script = `
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
$vs = [System.Windows.Forms.SystemInformation]::VirtualScreen
$w = [Math]::Max(1, $vs.Width)
$h = [Math]::Max(1, $vs.Height)
$bmp = New-Object System.Drawing.Bitmap($w, $h)
$g = [System.Drawing.Graphics]::FromImage($bmp)
$g.CopyFromScreen($vs.Left, $vs.Top, 0, 0, $bmp.Size)
$bmp.Save(${psQuote(file)}, [System.Drawing.Imaging.ImageFormat]::Png)
$g.Dispose()
$bmp.Dispose()
'OK|' + $w + 'x' + $h
`;
  const r = await runPs(script, timeoutMs);
  if (!fs.existsSync(file)) {
    return bad(`截图没成功${r.timedOut ? '（超时了）' : ''}。`);
  }
  const size = Math.max(1, Math.round(fs.statSync(file).size / 1024));
  try {
    await ctx.sender.sendImage(ctx.chatKey, { file }, { note: '屏幕截图' });
  } catch (error) {
    return bad(`截是截到了，但发不出去（${String(error?.message ?? error).slice(0, 80)}）。`);
  }
  // 与内置发送工具同口径：记进会话，让控制台会话页也能看到这张图
  try {
    ctx.session?.sent?.push({ type: 'image', text: '[图片:屏幕截图]', at: new Date().toLocaleTimeString('zh-CN', { hour12: false }) });
    ctx.emit?.('session-update', ctx.session?.id);
  } catch { /* 留档失败不影响发送结果 */ }
  return ok(`截图已经发到会话里了（${size}KB）。`);
}

// ─────────────────────────────────────────────── 动作：电脑状态
async function doSysinfo(timeoutMs) {
  const script = `
$os = Get-CimInstance Win32_OperatingSystem
$cpu = Get-CimInstance Win32_Processor | Select-Object -First 1
$ramTotal = [math]::Round($os.TotalVisibleMemorySize / 1MB, 1)
$ramFree = [math]::Round($os.FreePhysicalMemory / 1MB, 1)
$up = (Get-Date) - $os.LastBootUpTime
$lines = @()
$lines += '系统：' + $os.Caption + '（' + $os.Version + '）'
$lines += 'CPU：' + ($cpu.Name -replace '\\s+', ' ')
$lines += '内存：共 ' + $ramTotal + 'GB，可用 ' + $ramFree + 'GB'
$lines += '已开机：' + [math]::Round($up.TotalHours, 1) + ' 小时'
Get-CimInstance Win32_LogicalDisk -Filter 'DriveType=3' | ForEach-Object {
  $lines += '磁盘 ' + $_.DeviceID + '：可用 ' + [math]::Round($_.FreeSpace / 1GB, 1) + 'GB / 共 ' + [math]::Round($_.Size / 1GB, 1) + 'GB'
}
Get-CimInstance Win32_Battery | ForEach-Object { if ($_.EstimatedChargeRemaining) { $lines += '电量：' + $_.EstimatedChargeRemaining + '%' } }
$lines -join "\`n"
`;
  const r = await runPs(script, timeoutMs);
  const text = String(r.stdout || '').trim();
  if (!text) return bad(`没读到电脑状态${r.timedOut ? '（超时）' : ''}。`);
  return ok(text);
}

// ─────────────────────────────────────────────── 入口
export function setup(api) {
  log = api?.log || (() => {});
  warn = api?.warn || (() => {});

  const conf = cfg();
  log(`本地电脑操作已加载：${conf.allowAnyone === true ? '⚠️ 允许任何人' : '仅授权 QQ 号'}；`
    + `命令${conf.allowCommand === false ? '禁用' : '可用'}，高危${conf.allowDangerous === true ? '已开' : '禁用'}；`
    + `日志 data/${SKILL_ID}/audit.jsonl`);

  if (!allowedIds().length) {
    warn('还没有配置「允许操作的 QQ 号」，现在谁都用不了 —— 去技能设置里填你自己的 QQ 号（或配「主人识别」插件）。');
  }

  // 工具必须在这里注册（loader 只认 setup 执行期间注册的工具）
  api.registerTool({
    id: 'execute_local_action',
    name: '操作本地电脑',
    description:
      '在这台电脑上真的动手：打开/关闭程序、执行一条命令、列出目录、读/写文件、截屏并发到当前会话、查看电脑状态。'
      + '打开程序时用的是清单里记的**真正的程序文件**（扫描时已把快捷方式换成实际的 exe，并带上它的工作目录和启动参数），所以快捷方式坏掉也不影响。'
      + '只在对方明确要求「操作电脑」时调用 —— 单纯问用法、问概念、闲聊都不要调。'
      + '一次只做一个动作，不擅自扩大范围。'
      + '删除、覆盖已有文件、关机、改系统设置必须先问过用户并得到明确同意，再带 confirmed=true 调用；'
      + '含糊的「随便」「你看着办」不算同意。'
      + '调用后把结果用一句符合人设的短中文告诉对方，不要输出命令原文、完整路径、报错堆栈等技术细节；失败就如实说失败，绝不假装成功。',
    category: 'system',
    icon: '🖥️',
    requiresVision: false,
    parameters: {
      type: 'object',
      properties: {
        action: {
          type: 'string',
          enum: ['open_app', 'close_app', 'run_command', 'screenshot', 'list_dir', 'read_file', 'write_file', 'delete', 'sysinfo', 'list_apps', 'add_app'],
          description: '要做哪一件事：open_app 开程序/文件/网址，close_app 关程序，run_command 跑命令，screenshot 截屏发会话，list_dir 列目录，read_file 读文本文件，write_file 写文件，delete 删除（高危），sysinfo 看电脑状态，list_apps 看/搜这台电脑上能打开哪些应用，add_app 记住一个应用的快捷名。'
        },
        target: {
          type: 'string',
          description: '操作对象：应用名（如「QQ音乐」）或完整路径或网址（open_app / close_app）、目录（list_dir）、文件路径（read_file / write_file / delete）。'
        },
        command: { type: 'string', description: 'run_command 时要执行的那条命令。' },
        shell: { type: 'string', enum: ['powershell', 'cmd'], description: 'run_command 用哪个壳跑，默认 powershell。' },
        content: { type: 'string', description: 'write_file 要写进去的文本内容。' },
        confirmed: { type: 'boolean', description: '高危操作（delete、覆盖已存在的文件）必须先问过用户并得到明确同意，再传 true。' },
        timeoutSec: { type: 'number', description: '这次最多等多少秒，默认按设置（30），最多 120。' },
        keyword: { type: 'string', description: 'list_apps 用来搜应用名的关键词，不填就列全部。' },
        limit: { type: 'integer', description: 'list_apps 最多列几个，默认 40。' },
        refresh: { type: 'boolean', description: 'list_apps 时传 true 强制重扫应用清单（刚装完软件时用）。' },
        app_name: { type: 'string', description: 'add_app 要记住的名字，比如「QQ音乐」。' },
        app_target: { type: 'string', description: 'add_app 对应的启动目标（完整路径或网址）。不填就按 app_name 去应用清单里找。' }
      },
      required: ['action']
    },

    async execute(ctx, args) {
      const conf = cfg();
      if (conf.enabled === false) return bad('这个技能已经被关掉了，现在不能操作电脑。');

      // ① 权限：只有授权 QQ 号能动手
      const perm = checkPermission(ctx);
      if (!perm.ok) return bad(`没有权限：${perm.reason}。这一条不要重试，把原因如实告诉对方。`);

      // ② 意图闸门：触发消息本身得是「操作电脑」的话（挡网页注入）
      if (conf.requireIntentInMessage !== false && !hasIntent(triggerText(ctx))) {
        return bad('这条消息里看不出「操作电脑」的意思，先别动手 —— 跟用户确认一句是不是真的要在这台电脑上做。');
      }

      const action = String(args?.action ?? '').trim();
      const timeoutMs = timeoutOf(args);
      const caller = callerIds(ctx).join(',') || '-';
      const record = (result, extra = {}) => {
        audit({ chatKey: ctx?.chatKey || '', caller, action, args: { target: args?.target, command: args?.command, shell: args?.shell, confirmed: args?.confirmed }, ok: !result.isError, note: String(result.content).slice(0, 200), ...extra });
        if (result.isError) warn(`[${action}] 失败：${String(result.content).slice(0, 160)}`);
        else log(`[${action}] 成功：${String(result.content).slice(0, 160)}`);
        return result;
      };

      switch (action) {
        case 'open_app':
          return record(await doOpenApp(args?.target, timeoutMs, { refresh: args?.refresh === true }));

        case 'list_apps':
          return record(await doListApps(args?.keyword, args?.limit, timeoutMs, args?.refresh));

        case 'add_app':
          return record(await doAddApp(args?.app_name ?? args?.target, args?.app_target, timeoutMs));

        case 'close_app':
          return record(await doCloseApp(args?.target, timeoutMs));

        case 'run_command': {
          if (conf.allowCommand === false) return record(bad('执行命令这个功能被设置关掉了。'));
          const danger = looksDangerousCommand(args?.command);
          if (danger && (conf.allowDangerous !== true || args?.confirmed !== true)) {
            return record(bad('这条命令属于高危操作（格式化/删注册表/关机/改权限这类）。要执行得先问过用户、得到明确同意，并且设置里开着「允许高危操作」，再带 confirmed=true 调。'));
          }
          return record(await doRunCommand(args?.command, args?.shell, timeoutMs));
        }

        case 'screenshot':
          return record(await doScreenshot(ctx, timeoutMs));

        case 'list_dir':
          return record(await doListDir(args?.target, timeoutMs));

        case 'read_file':
          return record(await doReadFile(args?.target));

        case 'write_file': {
          if (conf.allowFileWrite === false) return record(bad('写文件这个功能被设置关掉了。'));
          return record(await doWriteFile(args?.target, args?.content, args?.confirmed));
        }

        case 'delete':
          return record(await doDelete(args?.target, args?.confirmed, timeoutMs));

        case 'sysinfo':
          return record(await doSysinfo(timeoutMs));

        default:
          return record(bad(`不认识这个动作「${action}」。可用的有：open_app / close_app / run_command / screenshot / list_dir / read_file / write_file / delete / sysinfo / list_apps / add_app。`));
      }
    }
  });

  // 预热日志目录（失败无所谓，别拖慢启动）
  try { fs.mkdirSync(BASE_DIR, { recursive: true }); } catch { /* 忽略 */ }

  // 预热应用清单：冷扫一次约 2~3 秒（实测 -Include 要 6.6s，换成 -Filter 后 1.3s），
  // 所以不 await —— 后台扫完写进缓存，等真有人说「打开XX」时就是秒回。
  // 失败静默：真调用时会再试一次，并给出明确原因。
  try { Promise.resolve(scanApps()).catch(() => {}); } catch { /* 忽略 */ }
}

/** 自检：这是 Windows 专属能力，别的系统上直接标不可用。 */
export function available() {
  return process.platform === 'win32';
}

/** 卸载/关闭时清掉内存里的应用清单缓存。 */
export function dispose() {
  catalogCache = null;
}
