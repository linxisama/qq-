/**
 * ammo-price · 三角洲子弹价格（orzice.com/v/ammo）
 *
 * 用户给的链接：`/v/ammo?a=ammo&top=2-2&p=1&grade=5&n=` —— 也就是「**5 级子弹、按当前价格从大到小**」。
 *
 * ── 这个页面和 item-slot-value 那个不一样，先记清楚（都实测过）────────────────
 *
 * ① **是服务端渲染的**：表格行直接写在 HTML 里，筛选靠 URL 参数。页面上的 `AppDataVue` 里
 *    `getData()` 全文只有一句 `window.location.href = url + '?' + 参数` —— 没有任何 XHR，
 *    所以**抓不到什么接口**（一开始我用 CDP 监听 /api/ 全空，就是这个原因）。
 *    也正因为如此，读数据有两条更省事的路：抓 HTML 解析，或者让浏览器读渲染后的 DOM 表格。
 *
 * ② URL 参数的真实含义（从页面 select 的 value 里读出来的，别猜）：
 *      a     = ammo（固定）
 *      top   = "<排序字段>-<方向>"  排序字段：1=今日涨幅 2=当前价格 3=等级 5=3日涨跌 7=7日涨跌 30=30日涨跌
 *                                    方向：2=从大到小 1=从小到大
 *      p     = 页码（每页 10 条）
 *      grade = 等级：-1=全部 5/4/3/2/1=几级子弹
 *      n     = **子弹口径**（9x19mm / 7.62x51mm / 箭矢…），留空=全部 —— 注意它不是"名字筛选"
 *
 * ③ **当前价格必须登录才有**：未登录时那一格渲染成「（登陆查看价格）」、金本位是 `-`；
 *    3日/7日/30日 的历史价和涨跌倒是匿名也能看到。所以还是要用本机已登录的浏览器。
 *
 * ④ 表格列：物品 / 金本位（≈金币 ≈鱼子酱，按 30 发一组换算）/ 当前价格 / 今日涨幅 /
 *    3日价格 / 3日涨幅 / 7日价格 / 7日涨幅 / 30日价格 / 30日涨幅。
 *    注意：3/7/30 日价格那几格在**原始 HTML 里是 Vue 模板**（`{{NumQfw(14540)}}`），
 *    浏览器渲染后才是 `14,540` —— 解析时两种都得认（见 readCellPrice）。
 *
 * 取数通道和 item-slot-value 一样：浏览器优先（登录态现成、不受"程序化请求"影响），
 * 直连抓 HTML 作备用（需要设置里填登录凭证）。解析用的是同一个纯函数，两条路都走它。
 */
import fs from 'node:fs';
import path from 'node:path';
import { spawn, execFile } from 'node:child_process';
import { promisify } from 'node:util';
import { fileURLToPath } from 'node:url';

const SITE = 'https://orzice.com';
const PAGE_PATH = '/v/ammo';
const DEFAULT_UA = 'Mozilla/5.0 (win32) AppleWebKit/537.36 (KHTML, like Gecko) jsdom/30.1.2';

// 排序字段 / 方向：值是页面 select 的 value（照抄，别自己编号）
export const SORT_FIELDS = { '今日涨幅': 1, '当前价格': 2, '价格': 2, '等级': 3, '3日涨跌': 5, '7日涨跌': 7, '30日涨跌': 30 };
export const ORDER_DIRS = { '从大到小': 2, '大到小': 2, '降序': 2, '从小到大': 1, '小到大': 1, '升序': 1 };
export const CALIBERS = ['9x19mm', '9x39mm', '.300BLK', '5.45x39mm', '5.56x45mm', '4.6x30mm', '5.7x28mm', '5.8x42mm',
  '6.8x51mm', '12.7x55mm', '7.62x39mm', '7.62x51mm', '7.62x54R', '12 Gauge', '.50 AE', '.45 ACP', '.357 Magnum', '箭矢', '45-70 Govt'];

// 用户给的链接就是这套：5 级子弹、按当前价格、从大到小
const DEFAULT_GRADE = 5;
const DEFAULT_SORT = 2;
const DEFAULT_ORDER = 2;
const PER_PAGE = 10;                 // 站点每页 10 条

// ── 运行时状态 ──────────────────────────────────────────────────────────
let cfg = () => ({});
let httpFetch = null;
let logger = { log: () => {}, warn: () => {}, error: () => {} };
let stateDir = null;
let dataRoot = null;
let mem = null;   // 已废弃（改用落盘的 diskCache）——留着只是怕别处引用
let fetchTimes = [];
let blockedUntil = 0;
let blockedNote = '';
let blockCount = 0;

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
function clamp(n, lo, hi, dflt) {
  const v = Number(n);
  if (!Number.isFinite(v)) return dflt;
  return Math.min(hi, Math.max(lo, Math.round(v)));
}
function fmtInt(n) {
  const v = Number(n);
  if (!Number.isFinite(v)) return String(n ?? '—');
  return v.toLocaleString('en-US');
}
function nowText(ts = Date.now()) { return new Date(ts).toLocaleString('zh-CN', { hour12: false }); }
function agoText(ts) {
  const s = Math.max(0, Math.round((Date.now() - ts) / 1000));
  if (s < 60) return `${s} 秒前`;
  if (s < 3600) return `${Math.round(s / 60)} 分钟前`;
  if (s < 86400) return `${Math.round(s / 3600)} 小时前`;
  return `${Math.round(s / 86400)} 天前`;
}

// ── 纯逻辑：解析表格（两条通道共用，可单独验证）─────────────────────────

/** 去掉标签取文字（顺带把 Vue 模板和多余空白收拾掉）。 */
function textOf(html) {
  return unVue(html)
    .replace(/<[^>]*>/g, ' ')
    .replace(/&nbsp;/g, ' ')
    .replace(/&amp;/g, '&')
    .replace(/\s+/g, ' ')
    .trim();
}

/**
 * 把 Vue 模板还原成值。
 * 为什么必须做（实测）：服务端渲染出来的 HTML 里，3/7/30 日价格那几格是 `{{NumQfw(14540)}}`，
 * 今日涨幅那格是 `{{-38.27}}%` —— 不还原就一个数都读不到（浏览器渲染后倒是正常的，
 * 但直连抓 HTML 时全是模板）。
 */
function unVue(html) {
  return String(html ?? '')
    .replace(/\{\{\s*NumQfw\(\s*(-?[\d.]+)\s*\)\s*\}\}/g, '$1')
    .replace(/\{\{\s*(-?[\d.]+)\s*\}\}/g, '$1');
}

/** 从一格 HTML 里读出价格。
 * 三种形态都要认（实测都是真实存在过的）：
 *   浏览器渲染后： `14,540`
 *   原始 HTML：   `{{NumQfw(14540)}}`   ← 页面里 3/7/30 日价格是 Vue 模板
 *   未登录：      `（登陆查看价格）`     ← 必须如实报"要登录"，不能当成 0 或 -
 */
export function readCellPrice(html) {
  const raw = String(html ?? '');
  if (/登陆查看价格|登录查看价格/.test(raw)) return { value: null, needLogin: true };
  const txt = textOf(raw);
  const m = txt.match(/-?[\d][\d,]*(?:\.\d+)?/);
  if (!m) return { value: null };
  const v = Number(m[0].replace(/,/g, ''));
  return { value: Number.isFinite(v) ? v : null };
}

/** 从一格 HTML 里读出百分比（今日涨幅 / 3日涨幅 …）。 */
export function readCellPercent(html) {
  const raw = String(html ?? '');
  const m = textOf(raw).match(/(-?\d+(?:\.\d+)?)\s*%/);
  if (m) return Number(m[1]);
  // 未登录时服务端把「今日涨幅」渲染成了占位符（文本就是 `- %`），但数值还留在 Vue 的
  // :class 表达式里：`:class="['ui-badge', -38.27 < 0 ? 'ui-badge-down' : 'ui-badge-up']"`。
  // 这是"能救就救"的兜底（匿名抓 HTML 时有用）；救不到就如实返回 null，不编数。
  const cls = raw.match(/:\s*class="\[[^"]*?(-?\d+(?:\.\d+)?)\s*<\s*0/);
  return cls ? Number(cls[1]) : null;
}

/**
 * 解析 /v/ammo 的表格：返回 { items, total, needLogin, rows }。
 * items[] 形状：{ name, sell, grade, jb, yzj, price, changeToday, d3:{price,change}, d7:{...}, d30:{...} }
 */
export function parseAmmoTable(html) {
  const src = String(html ?? '');
  const totalMatch = src.match(/this\.count\s*=\s*(\d+)/);
  const total = totalMatch ? Number(totalMatch[1]) : null;

  const trs = [...src.matchAll(/<tr[^>]*>([\s\S]*?)<\/tr>/g)].map((m) => m[1]).filter((r) => r.includes('ui-tname'));
  const items = [];
  let needLogin = false;

  for (const tr of trs) {
    const tds = [...tr.matchAll(/<td[^>]*>([\s\S]*?)<\/td>/g)].map((m) => m[1]);
    const name = textOf((tr.match(/<div class="ui-tname">([\s\S]*?)<\/div>/) || [])[1] || '');
    if (!name) continue;
    const sell = textOf((tr.match(/<span class="ui-sell[^"]*">([\s\S]*?)<\/span>/) || [])[1] || '');
    // 等级：图标上的 data-grade（页面自己标的）
    const gradeMatch = tr.match(/data-grade="(\d+)"/);
    const grade = gradeMatch ? Number(gradeMatch[1]) : null;
    // 金本位：≈ 金币 / ≈ 鱼子酱
    const jbMatch = tds[1] ? textOf(tds[1]).match(/≈\s*([\d.]+)[^≈]*≈\s*([\d.]+)/) : null;
    const price = tds[2] ? readCellPrice(tds[2]) : { value: null };
    if (price.needLogin) needLogin = true;
    const col = (i) => ({ price: tds[i] ? readCellPrice(tds[i]).value : null, change: tds[i + 1] ? readCellPercent(tds[i + 1]) : null });
    items.push({
      name,
      sell,
      grade,
      jb: jbMatch ? Number(jbMatch[1]) : null,
      yzj: jbMatch ? Number(jbMatch[2]) : null,
      price: price.value,
      changeToday: tds[3] ? readCellPercent(tds[3]) : null,
      d3: col(4),
      d7: col(6),
      d30: col(8)
    });
  }
  return { items, total, needLogin, rowCount: trs.length };
}

/** 拼查询串（顺序和页面 getData() 一致：a & top & p & grade & n）。 */
export function buildQuery({ sort = DEFAULT_SORT, order = DEFAULT_ORDER, grade = -1, caliber = '', page = 1 } = {}) {
  const g = Number(grade);
  return `a=ammo&top=${Number(sort)}-${Number(order)}&p=${Math.max(1, Math.round(Number(page) || 1))}&grade=${Number.isFinite(g) ? g : -1}&n=${encodeURIComponent(String(caliber ?? '').trim())}`;
}

// ── 冷却与频率闸 ────────────────────────────────────────────────────────
function nextCooldownMs(baseMs) {
  blockCount = Math.min(blockCount + 1, 6);
  return Math.min(baseMs * Math.pow(2, blockCount - 1), 120 * 60000);
}
function noteBlocked(reason, cooldownMs) {
  blockedUntil = Date.now() + cooldownMs;
  blockedNote = reason;
  logger.warn('ammo-price: 被数据源拒绝，冷却 %s 分钟：%s', Math.round(cooldownMs / 60000), reason);
}
function noteSuccess() { blockCount = 0; blockedUntil = 0; blockedNote = ''; }
function throttle(maxPerHour) {
  const now = Date.now();
  fetchTimes = fetchTimes.filter((t) => now - t < 3600000);
  return fetchTimes.length >= maxPerHour;
}

// ── 直连通道（抓 HTML）──────────────────────────────────────────────────
async function httpGet(url, { timeoutMs, accept, cookie, ua, retry = 1 } = {}) {
  const attempt = async () => {
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), timeoutMs);
    try {
      const res = await httpFetch(url, {
        method: 'GET', signal: ctrl.signal, redirect: 'follow',
        headers: {
          'User-Agent': ua || DEFAULT_UA,
          Accept: accept,
          Referer: `${SITE}${PAGE_PATH}`,      // 必需，去掉就 403（实测）
          ...(cookie ? { Cookie: cookie } : {})
        }
      });
      const body = await res.text();
      if (res.status === 403 || res.status === 429) return { error: `HTTP ${res.status}（被站点防抓取规则拦下）`, status: res.status, blocked: true };
      if (!res.ok) return { error: `HTTP ${res.status}`, status: res.status };
      if (!body) return { error: '空响应', transient: true };
      return { text: body };
    } catch (e) {
      const msg = e?.name === 'AbortError' ? `超时（${timeoutMs}ms）` : (e?.message ?? String(e));
      return { error: `网络失败：${msg}`, transient: true };
    } finally { clearTimeout(timer); }
  };
  let out = await attempt();
  if (out.transient && retry > 0) { await sleep(800); out = await attempt(); }
  return out;
}

async function httpRead(query, { timeoutMs, cookie, ua }) {
  const r = await httpGet(`${SITE}${PAGE_PATH}?${query}`, { timeoutMs, accept: 'text/html,application/xhtml+xml', cookie, ua });
  if (r.error) return r;
  const parsed = parseAmmoTable(r.text);
  return { ...parsed, channel: 'http', fetchedAt: Date.now() };
}

// ── 浏览器通道 ──────────────────────────────────────────────────────────
const BROWSER_EXE_CANDIDATES = [
  path.join(process.env['ProgramFiles(x86)'] || '', 'Microsoft/Edge/Application/msedge.exe'),
  path.join(process.env['ProgramFiles'] || '', 'Microsoft/Edge/Application/msedge.exe'),
  path.join(process.env['ProgramFiles'] || '', 'Google/Chrome/Application/chrome.exe'),
  path.join(process.env['ProgramFiles(x86)'] || '', 'Google/Chrome/Application/chrome.exe'),
  path.join(process.env.LOCALAPPDATA || '', 'Google/Chrome/Application/chrome.exe')
];

let br = null;
let brWarmTimer = null;
let brProfileDir = null;
let brKnownLoggedIn = null;
let brLockFile = null;      // 记录浏览器 pid，供"上次没关掉"的清扫用
let brExitHooked = false;   // 进程退出兜底只注册一次

// ── 浏览器进程的生命周期兜底（v1.2.2：**全部异步**，绝不阻塞主进程）────────────
//
// ⚠️ 为什么必须异步：这里是 Electron/Node 的**主进程**。v1.2.0/1.2.1 用 spawnSync 跑
//    `msedge --version` / tasklist / taskkill / powershell(CIM)，单次 0.5~3 秒，CIM 查询更久 ——
//    这期间整个应用**卡住不动**，用户看到的就是"窗口卡死、关不掉"。现在全部换成
//    异步 execFile + await：该等的等，但事件循环不被堵住（界面不卡、窗口能点能关）。
//
// 要堵的四个漏点：
//   ① 有窗口登录那条路失败时直接 return，可见窗口没关 → try/finally 保证关；
//   ② spawn 的 windowsHide 写成了 !headless（无头模式下反而不隐藏）→ 恒为 true；
//   ③ 应用退出时没人管浏览器 → 进程退出兜底（非阻塞：proc.kill() + fire-and-forget 的 taskkill）；
//   ④ --headless=new 只有 Chromium 112+ 认，老版本会带窗口启动 → 按版本挑旗标；
//      旧版本残留不写 lock → 另按"配置目录"清扫（技能加载后延迟 1.2 秒跑一次，不拖慢启动）。
const execFileAsync = promisify(execFile);

/** 浏览器主版本号（老版本不认 --headless=new，会带窗口启动）。异步 + 结果缓存。 */
const majorCache = new Map();
async function browserMajorVersion(exe) {
  if (majorCache.has(exe)) return majorCache.get(exe);
  let major = 0;
  try {
    const { stdout, stderr } = await execFileAsync(exe, ['--version'], { timeout: 5000, windowsHide: true });
    const m = String(stdout || stderr || '').match(/(\d+)\.\d+\.\d+/);
    major = m ? Number(m[1]) : 0;
  } catch { major = 0; }
  majorCache.set(exe, major);
  return major;
}
/** 按浏览器版本给 headless 旗标。 */
async function headlessFlagsFor(exe) {
  const major = await browserMajorVersion(exe);
  const flags = (major && major < 112) ? ['--headless'] : ['--headless=new'];
  return flags.concat([
    '--disable-gpu',
    '--disable-background-mode',              // 别挂在后台不退
    '--disable-backgrounding-occluded-windows',
    '--no-service-autorun'
  ]);
}
function writeBrowserLock(pid) {
  try {
    fs.mkdirSync(stateDir, { recursive: true });
    fs.writeFileSync(brLockFile, JSON.stringify({ pid: Number(pid) || 0, at: Date.now(), profileDir: brProfileDir }), 'utf8');
  } catch { /* ignore */ }
}
function clearBrowserLock() { try { fs.rmSync(brLockFile, { force: true }); } catch { /* ignore */ } }
function profileLockFiles() {
  return ['SingletonLock', 'SingletonCookie', 'SingletonSocket'].map((f) => path.join(brProfileDir || path.join(stateDir, 'browser-profile'), f));
}
/** 这个 pid 还是不是浏览器进程（防止 pid 复用误杀别人的程序）。异步。 */
async function isBrowserPid(pid) {
  try {
    const { stdout } = await execFileAsync('tasklist', ['/FI', `PID eq ${Number(pid)}`, '/FO', 'CSV', '/NH'], { timeout: 5000, windowsHide: true });
    return /msedge\.exe|chrome\.exe/i.test(String(stdout || ''));
  } catch { return false; }
}
/** 强杀**整棵进程树**（异步）：只 kill 主进程会留下 crashpad/GPU 子进程。 */
async function killTree(pid) {
  const n = Number(pid);
  if (!n) return;
  try { await execFileAsync('taskkill', ['/PID', String(n), '/T', '/F'], { timeout: 8000, windowsHide: true }); } catch { /* ignore */ }
}
/**
 * 立刻返回版：**进程退出钩子里用**。那时不能 await、更不能阻塞（阻塞 = 应用关了窗口还留着），
 * 所以 detached + unref 把它甩出去，让 taskkill 自己跑完。
 */
function killTreeDetached(pid) {
  const n = Number(pid);
  if (!n) return;
  try {
    const p = spawn('taskkill', ['/PID', String(n), '/T', '/F'], { stdio: 'ignore', windowsHide: true, detached: true });
    p.unref?.();
  } catch { /* ignore */ }
}
/** 清扫上一次没关掉的浏览器（应用被强杀留下的），并清残留单实例锁。 */
async function sweepStaleBrowser() {
  try {
    if (brLockFile && fs.existsSync(brLockFile)) {
      const j = JSON.parse(fs.readFileSync(brLockFile, 'utf8'));
      const pid = Number(j?.pid) || 0;
      if (pid && await isBrowserPid(pid)) {
        logger.warn('ammo-price: 发现上次没关掉的浏览器（PID %s），正在清掉', pid);
        await killTree(pid);
      }
      clearBrowserLock();
    }
  } catch { /* ignore */ }
  for (const f of profileLockFiles()) { try { fs.rmSync(f, { force: true }); } catch { /* ignore */ } }
}
/** 应用退出/被中断时的兜底：**非阻塞**地收掉浏览器，别留窗口。 */
function installExitHook() {
  if (brExitHooked) return;
  brExitHooked = true;
  const kill = () => {
    const pid = br?.proc?.exitCode === null ? br.proc.pid : 0;
    try { if (pid) br.proc.kill(); } catch { /* ignore */ }   // 先给主进程一发（瞬时，不阻塞）
    if (pid) killTreeDetached(pid);                            // 子树交给独立的 taskkill，不等它
    clearBrowserLock();
  };
  try { process.once('exit', kill); } catch { /* ignore */ }
  for (const sig of ['SIGINT', 'SIGTERM', 'SIGHUP']) {
    try { process.once(sig, () => { kill(); }); } catch { /* 某些信号平台不支持 */ }
  }
}
/**
 * 清扫**所有**正在使用我们这份配置目录的浏览器进程 —— 不依赖 browser.lock。
 *
 * 为什么必须有这一条：v1.1.0 及更早的版本**根本不写 lock**，只按 lock 清扫的话，
 * 那些老版本留在桌面上的窗口永远清不掉（用户报的"还有残留窗口关不掉"就是这个）。
 * 做法：查 msedge/chrome 的命令行里有没有我们这个 profile 路径，有就整棵树强杀。
 * 异步 + 调用方不 await（见 setup），所以不会拖慢应用启动。
 */
async function sweepBrowsersByProfile(profileDir) {
  const dir = profileDir || path.join(stateDir, 'browser-profile');
  if (!dir) return [];
  // ⚠️ 我们自己正在用浏览器时**不清扫**：命令行里区分不出"我们自己的子进程（渲染/GPU，
  //    同样带这个 profile）"和"上次留下的残留进程"，硬清会把正在读数据的那一次打断。
  //    那种情况下留给"用完关闭"和"下次启动的 lock 清扫"处理。
  if (br?.proc && br.proc.exitCode === null) return [];
  const esc = String(dir).replace(/'/g, "''");
  const ps = 'Get-CimInstance Win32_Process -Filter "Name=\'msedge.exe\' or Name=\'chrome.exe\'" | '
    + `Where-Object { $_.CommandLine -and $_.CommandLine.Contains('${esc}') } | `
    + 'Select-Object -ExpandProperty ProcessId';
  let stdout = '';
  try {
    const r = await execFileAsync('powershell.exe',
      ['-NoProfile', '-NonInteractive', '-WindowStyle', 'Hidden', '-Command', ps],
      { timeout: 20000, windowsHide: true, maxBuffer: 1024 * 1024 });
    stdout = String(r?.stdout || '');
  } catch { return []; }
  const pids = stdout.split(/\s+/).map((s) => Number(s)).filter((n) => Number.isInteger(n) && n > 0);
  const current = Number(br?.proc?.pid) || 0;      // 别把自己正在用的那个杀了
  const killed = [];
  for (const pid of pids) {
    if (pid === current) continue;
    if (!await isBrowserPid(pid)) continue;        // 只见 msedge/chrome 才动手（防 pid 复用误杀）
    logger.warn('ammo-price: 清掉一个还挂着的浏览器进程（PID %s）', pid);
    await killTree(pid);
    killed.push(pid);
  }
  // 顺手把可能残留的单实例锁清掉，免得下次登录被锁挡住
  for (const f of profileLockFiles()) { try { fs.rmSync(f, { force: true }); } catch { /* ignore */ } }
  return killed;
}
function findBrowserExe(override) {
  if (override && fs.existsSync(override)) return override;
  for (const p of BROWSER_EXE_CANDIDATES) if (p && fs.existsSync(p)) return p;
  return null;
}

async function wsConnect(url, timeoutMs = 8000) {
  let Impl = globalThis.WebSocket;
  if (!Impl) { try { Impl = (await import('ws')).WebSocket || (await import('ws')).default; } catch { /* 下面报错 */ } }
  if (!Impl) throw new Error('运行环境没有可用的 WebSocket（无法连接浏览器调试端口）');
  const sock = new Impl(url);
  const handlers = new Map();
  const onRaw = (raw) => {
    let m; try { m = JSON.parse(String(raw)); } catch { return; }
    const h = handlers.get(m.id);
    if (!h) return;
    handlers.delete(m.id); clearTimeout(h.timer);
    if (m.error) h.reject(new Error(m.error.message || 'CDP 报错')); else h.resolve(m.result);
  };
  await new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error('连接浏览器调试端口超时')), timeoutMs);
    const ok = () => { clearTimeout(timer); resolve(); };
    const bad = (e) => { clearTimeout(timer); reject(e instanceof Error ? e : new Error(String(e))); };
    if (typeof sock.on === 'function') { sock.on('open', ok); sock.on('error', bad); sock.on('message', onRaw); }
    else { sock.onopen = ok; sock.onerror = () => bad(new Error('连接浏览器调试端口失败')); sock.onmessage = (ev) => onRaw(ev.data); }
  });
  return { handlers, send: (s) => sock.send(s), close: () => { for (const h of handlers.values()) clearTimeout(h.timer); handlers.clear(); try { sock.close(); } catch { /* ignore */ } } };
}
function cdpCall(conn, method, params = {}, timeoutMs = 10000) {
  const id = ++cdpCall.seq;
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => { conn.handlers.delete(id); reject(new Error(`${method} 超时`)); }, timeoutMs);
    conn.handlers.set(id, { resolve, reject, timer });
    conn.send(JSON.stringify({ id, method, params }));
  });
}
cdpCall.seq = 0;

/**
 * 借用别的技能已经登录好的浏览器配置（只在本技能自己还没有 Cookie 库时拷一次）。
 * 优先借 item-slot-value 那份（它也是刚建的），再退到 teqinchu-rank 那份。
 * 只拷 `Local State`（Chrome 加密 Cookie 的密钥）+ `Default/Network/Cookies`，各技能用各自的目录，
 * 避免两个技能同时开浏览器时抢同一个配置锁。
 */
function seedLogin(profileDir) {
  if (!dataRoot) return { seeded: false, reason: '不知道数据目录' };
  if (fs.existsSync(path.join(profileDir, 'Default', 'Network', 'Cookies'))) return { seeded: false, reason: '本技能自己已有登录配置' };
  const sources = ['item-slot-value', 'teqinchu-rank'].map((n) => path.join(dataRoot, n, 'browser-profile'));
  for (const src of sources) {
    if (!fs.existsSync(path.join(src, 'Default', 'Network', 'Cookies'))) continue;
    try {
      fs.mkdirSync(path.join(profileDir, 'Default', 'Network'), { recursive: true });
      for (const rel of [['Local State', 'Local State'], [path.join('Default', 'Network', 'Cookies'), path.join('Default', 'Network', 'Cookies')]]) {
        fs.copyFileSync(path.join(src, rel[0]), path.join(profileDir, rel[1]));
      }
      logger.log('ammo-price: 已从 %s 的浏览器配置借用登录态（只拷一次）', path.basename(path.dirname(src)));
      return { seeded: true, from: src };
    } catch (e) { /* 换下一个来源 */ }
  }
  return { seeded: false, reason: '没找到可借用的已登录配置' };
}

async function ensureBrowser(exePath, keepWarmSec, timeoutMs, headless = true) {
  if (br && br.proc && br.proc.exitCode === null && br.headless === headless) return br;
  if (br) await closeBrowser();
  const exe = findBrowserExe(exePath);
  if (!exe) return { error: '没找到 Edge 或 Chrome（可在技能设置里填浏览器路径）' };
  const port = 9600 + Math.floor(Math.random() * 300);
  brProfileDir = path.join(stateDir, 'browser-profile');
  fs.mkdirSync(brProfileDir, { recursive: true });
  await sweepStaleBrowser();      // 先把上次没关掉的残留（含可见窗口）干掉
  installExitHook();        // 应用退出时兜底杀浏览器
  logger.log('ammo-price: 启动浏览器通道（%s）', headless ? '无头' : '有窗口·登录用');
  const args = [`--remote-debugging-port=${port}`, `--user-data-dir=${brProfileDir}`,
    '--no-first-run', '--no-default-browser-check', '--disable-sync', '--disable-extensions', '--window-size=1280,1200'];
  if (headless) args.push(...(await headlessFlagsFor(exe)));
  else args.push('--window-size=560,460', '--window-position=40,40');   // 登录必须可见窗口（实测）
  args.push('about:blank');
  // windowsHide 恒为 true：它只管子进程的控制台窗口，跟浏览器自己的窗口无关
  const proc = spawn(exe, args, { stdio: 'ignore', windowsHide: true });
  proc.unref?.();
  proc.on('exit', () => { if (br && br.proc === proc) br = null; });
  writeBrowserLock(proc.pid);
  const deadline = Date.now() + Math.min(timeoutMs, 20000);
  while (Date.now() < deadline) {
    await sleep(400);
    try { const r = await fetch(`http://127.0.0.1:${port}/json/version`); if (r.ok) { br = { proc, port, exe, headless }; scheduleBrowserClose(keepWarmSec); return br; } } catch { /* 还没起来 */ }
  }
  try { proc.kill(); } catch { /* ignore */ }
  await killTree(proc.pid);
  clearBrowserLock();
  return { error: '浏览器调试端口没起来（可能被安全软件拦了）' };
}

function scheduleBrowserClose(keepWarmSec) {
  if (brWarmTimer) clearTimeout(brWarmTimer);
  brWarmTimer = setTimeout(() => { closeBrowser().catch(() => {}); }, Math.max(30, keepWarmSec) * 1000);
  brWarmTimer.unref?.();
}

async function closeBrowser() {
  if (brWarmTimer) { clearTimeout(brWarmTimer); brWarmTimer = null; }
  const cur = br; br = null;
  if (!cur) return;
  // 优雅关闭：强杀会留下单实例锁，下次登录就登不上了
  try {
    const v = await (await fetch(`http://127.0.0.1:${cur.port}/json/version`)).json();
    const conn = await wsConnect(v.webSocketDebuggerUrl, 4000);
    await cdpCall(conn, 'Browser.close', {}, 3000).catch(() => {});
    conn.close();
  } catch { /* 端口已经没了 */ }
  const deadline = Date.now() + 4000;
  while (cur.proc.exitCode === null && Date.now() < deadline) await sleep(300);
  if (cur.proc.exitCode === null) await killTree(cur.proc.pid);   // 整棵树杀，别留子进程
  clearBrowserLock();
  if (brProfileDir) for (const f of ['SingletonLock', 'SingletonCookie', 'SingletonSocket']) { try { fs.rmSync(path.join(brProfileDir, f), { force: true }); } catch { /* ignore */ } }
  logger.log('ammo-price: 已关闭浏览器通道（省内存）');
}

function profileHasLoginCookie() {
  if (brKnownLoggedIn !== null) return brKnownLoggedIn;
  try {
    const p = path.join(brProfileDir || path.join(stateDir, 'browser-profile'), 'Default', 'Network', 'Cookies');
    if (!fs.existsSync(p)) return false;
    return fs.readFileSync(p).includes('cloud_token');
  } catch { return false; }
}

const readTableExpr = `(() => {
  const t = document.querySelector('table');
  const v = window.AppDataVue;
  const loggedIn = !/未登录/.test(document.body.innerText || '');
  return JSON.stringify({
    loggedIn,
    html: t ? t.outerHTML : '',
    // 总条数只在页面的 Vue 数据里（服务端写成 this.count = N），表格 HTML 里没有 ——
    // 必须单独读出来，否则备注里说不了"一共多少条、共几页"。
    count: (v && Number.isFinite(Number(v.count))) ? Number(v.count) : null,
    body: (document.body.innerText || '').slice(0, 300)
  });
})()`;

async function evalJson(conn, expr, timeoutMs = 8000) {
  const r = await cdpCall(conn, 'Runtime.evaluate', { expression: expr, returnByValue: true }, timeoutMs);
  return r?.result?.value;
}

/**
 * 用浏览器读一次：打开带参数的 URL，等表格出来，把表格 HTML 交回 Node 解析
 * （解析逻辑只有一份，就在 parseAmmoTable —— 两条通道共用）。
 */
async function pageRead({ query, timeoutMs, exePath, warmSec, headless = true, doLogin = false }) {
  const b = await ensureBrowser(exePath, warmSec, timeoutMs, headless);
  if (b.error) return { error: b.error };
  scheduleBrowserClose(warmSec);
  let conn = null; let tabId = null;
  try {
    const url = `${SITE}${PAGE_PATH}?${query}`;
    const res = await fetch(`http://127.0.0.1:${b.port}/json/new?${encodeURIComponent(doLogin ? `${SITE}/login` : url)}`, { method: 'PUT' });
    const tab = await res.json();
    tabId = tab.id;
    conn = await wsConnect(tab.webSocketDebuggerUrl);
    await cdpCall(conn, 'Runtime.enable', {}, timeoutMs);

    if (doLogin) {
      logger.log('ammo-price: 走一次登录页（自动 QQ 一键登录）…');
      await sleep(12000);
      await cdpCall(conn, 'Page.navigate', { url }, timeoutMs).catch(() => {});
    }

    const deadline = Date.now() + (doLogin ? 20000 : Math.min(timeoutMs, 15000));
    let last = null;
    while (Date.now() < deadline) {
      try {
        const raw = await evalJson(conn, readTableExpr);
        if (typeof raw === 'string' && raw.startsWith('{')) {
          const parsed = JSON.parse(raw);
          last = parsed;
          if (parsed.html && parsed.html.includes('ui-tname')) break;   // 表格出来了
        }
      } catch { /* 页面还在导航，接着等 */ }
      await sleep(600);
    }
    if (!last || !last.html) {
      const ck = await cdpCall(conn, 'Storage.getCookies', {}, 6000).catch(() => null);
      const hasToken = (ck?.cookies || []).some((c) => c.name === 'cloud_token');
      brKnownLoggedIn = hasToken ? true : false;
      return { error: hasToken ? '页面里没读到子弹表格（站点可能改版了）' : '浏览器里没有登录态', needLogin: !hasToken };
    }
    brKnownLoggedIn = last.loggedIn === true;
    const parsed = parseAmmoTable(last.html);
    // 总条数：表格 HTML 里没有（它在页面的 Vue 数据里），用页面读到的 count 补上
    if (!parsed.total && Number.isFinite(last.count)) parsed.total = last.count;
    return { ...parsed, channel: 'page', fetchedAt: Date.now(), pageText: last.body };
  } catch (e) {
    return { error: `浏览器读取失败：${e?.message ?? e}` };
  } finally {
    try { conn?.close(); } catch { /* ignore */ }
    if (tabId) { try { await fetch(`http://127.0.0.1:${b.port}/json/close/${tabId}`); } catch { /* ignore */ } }
  }
}

async function browserRead({ query, timeoutMs, exePath, warmSec }) {
  if (!profileHasLoginCookie() && cfg()?.reuseOtherLogin !== false) {
    seedLogin(path.join(stateDir, 'browser-profile'));
    brKnownLoggedIn = null;
  }
  const logged = profileHasLoginCookie();
  logger.log('ammo-price: 浏览器配置里%s登录态，用%s模式读取', logged ? '有' : '没有', logged ? '无头' : '有窗口');
  const first = await pageRead({ query, timeoutMs, exePath, warmSec, headless: logged });
  if (!first.needLogin) return first;

  logger.log('ammo-price: 没有登录态，用有窗口模式登录一次（屏幕左上角会闪一个小窗）…');
  await closeBrowser();
  let login;
  try {
    login = await pageRead({ query, timeoutMs: Math.max(timeoutMs, 30000), exePath, warmSec, headless: false, doLogin: true });
  } finally {
    // ⚠️ v1.2.0 关键修复：登录用的可见窗口必须**无论如何**都关掉
    //    （以前失败时直接 return，小窗留在桌面上 = 用户报的"关不掉的窗口"）
    await closeBrowser();
  }
  if (!login.needLogin && !login.error) {
    logger.log('ammo-price: 自动登录成功，之后继续用无头模式');
    const again = await pageRead({ query, timeoutMs, exePath, warmSec, headless: true });
    return (again.needLogin || again.error) ? login : again;
  }
  return {
    error: `子弹的「当前价格」必须登录才能看，而自动登录没成功（${login.error ?? '未知原因'}）。`
      + '（登录窗口已经关掉了。）可以再问一次试试；'
      + '或者先去用一次「物品单格价值」/「特勤处制造排名」技能（它们登录成功后，本技能可以直接借用那份登录态）。'
  };
}

// ── 缓存：8 小时只抓一次（落盘，重启也算数）─────────────────────────────
//
// 用户要「**8 小时抓取一次数据**」：8 小时内谁问都用同一份，不重复联网；过了 8 小时，
// 下一次问才真去抓。缓存写进磁盘 —— 只放内存的话应用一重启就又抓一遍，那就不叫 8 小时一次了。
let stateFile = null;
let diskCache = [];        // [{ key, at, payload, channel }]，新的在前，最多留 6 条

function loadState() {
  try {
    const raw = JSON.parse(fs.readFileSync(stateFile, 'utf8'));
    if (Array.isArray(raw?.cache)) diskCache = raw.cache.filter((x) => x && typeof x.key === 'string' && x.payload && Number.isFinite(x.at));
    if (Array.isArray(raw?.fetchTimes)) fetchTimes = raw.fetchTimes.filter((t) => Number.isFinite(t));
  } catch { /* 首次运行 */ }
}
function saveState() {
  try {
    fs.mkdirSync(path.dirname(stateFile), { recursive: true });
    const tmp = `${stateFile}.${process.pid}.tmp`;
    fs.writeFileSync(tmp, JSON.stringify({ cache: diskCache.slice(0, 6), fetchTimes: fetchTimes.slice(-40), savedAt: Date.now() }), 'utf8');
    fs.renameSync(tmp, stateFile);
  } catch (e) {
    logger.warn('ammo-price: 缓存写入失败（不影响本次结果）：%s', e?.message ?? e);
  }
}
function cacheFind(key) { return diskCache.find((x) => x.key === key) || null; }
function cachePut(key, payload, channel, at) {
  diskCache = [{ key, at, payload, channel }, ...diskCache.filter((x) => x.key !== key)].slice(0, 6);
  saveState();
}
function cacheAgeText(at, ttlMs) {
  const leftMin = Math.round(Math.max(0, ttlMs - (Date.now() - at)) / 60000);
  if (leftMin >= 120) return `${(leftMin / 60).toFixed(1)} 小时`;
  if (leftMin >= 1) return `${leftMin} 分钟`;
  return '不到 1 分钟';
}

// ── 主流程 ──────────────────────────────────────────────────────────────
async function loadAmmo(query, o) {
  const hit = cacheFind(query);
  if (hit && Date.now() - hit.at < o.ttlMs) {
    logger.log('ammo-price: 用 %s 抓的那份（8 小时窗口内不重复抓）', agoText(hit.at));
    return { ...hit.payload, fromCache: true, channel: hit.channel, fetchedAt: hit.at, leftText: cacheAgeText(hit.at, o.ttlMs) };
  }
  if (Date.now() < blockedUntil) {
    return { error: `数据源刚刚拒绝过我们，冷却中（还剩约 ${Math.ceil((blockedUntil - Date.now()) / 60000)} 分钟）：${blockedNote}`, cooldown: true };
  }
  if (throttle(o.maxPerHour)) return { error: `这一小时查得太频繁了（上限 ${o.maxPerHour} 次），先歇一会儿。`, limited: true };

  let out = null;
  if (o.browserMode !== 'off') {
    out = await browserRead({ query, timeoutMs: o.timeoutMs, exePath: o.browserExe, warmSec: o.browserWarmSec });
    if (out.error && !out.needLogin) logger.warn('ammo-price: 浏览器通道失败，回退直连：%s', out.error);
  }
  if ((!out || out.error) && o.cookie) {
    const viaHttp = await httpRead(query, { timeoutMs: o.timeoutMs, cookie: o.cookie, ua: o.ua });
    if (!viaHttp.error) out = viaHttp;
    else if (!out) out = viaHttp;
  }
  if (!out || out.error) {
    if (out?.blocked) noteBlocked(out.error, o.cooldownMs);
    const hint = (out && !out.needLogin && !o.cookie)
      ? '（直连通道需要设置里填「登录凭证」；现在只走了浏览器通道）' : '';
    return { error: (out?.error ?? '没拿到数据') + hint, blocked: out?.blocked };
  }
  noteSuccess();
  fetchTimes.push(Date.now());
  cachePut(query, { items: out.items, total: out.total, needLogin: out.needLogin === true }, out.channel, out.fetchedAt || Date.now());
  // 每次"真去抓"都留一条日志：带完整查询串和条数，事后能核对是不是真抓的
  try {
    logger.log('ammo-price: 真去抓了一次（%s）→ %s 条（通道 %s）', query, (out.items || []).length, out.channel);
  } catch { /* 日志失败不影响结果 */ }
  return out;
}

// ── 文案 ────────────────────────────────────────────────────────────────
const LINE_FORMATS = {
  name_price: '名称 + 当前价格',
  name_price_change: '名称 + 当前价格 + 今日涨幅',
  full: '名称 + 价格 + 今日涨幅 + 3日/7日/30日'
};
function pct(v) {
  if (v === null || v === undefined || !Number.isFinite(Number(v))) return '';
  const n = Number(v);
  return `${n > 0 ? '+' : ''}${n}%`;
}
function formatLine(it, style) {
  const price = it.price === null ? '价格要登录才能看' : fmtInt(it.price);
  const chg = pct(it.changeToday);
  switch (style) {
    case 'name_price_change': return `${it.name} ${price}${chg ? ` ${chg}` : ''}`;
    case 'full': return `${it.name} ${price}${chg ? ` ${chg}` : ''}`
      + `（3日 ${it.d3?.price === null ? '—' : fmtInt(it.d3?.price)} ${pct(it.d3?.change)}`
      + ` / 7日 ${it.d7?.price === null ? '—' : fmtInt(it.d7?.price)} ${pct(it.d7?.change)}`
      + ` / 30日 ${it.d30?.price === null ? '—' : fmtInt(it.d30?.price)} ${pct(it.d30?.change)}）`;
    case 'name_price':
    default: return `${it.name} ${price}`;
  }
}

function describeFilters({ sortName, orderName, grade, caliber }) {
  const bits = [];
  if (Number(grade) > 0) bits.push(`${grade}级子弹`);
  if (caliber) bits.push(caliber);
  bits.push(`按${sortName}${orderName}`);
  return bits.join('、');
}

function buildReport({ items, page, total, show, lineFormat, separateMessages, channel, fetchedAt, filters, cachedNote, needLogin, query }) {
  const lines = [];
  const notes = [];
  const shown = items.slice(0, show);
  if (!shown.length) {
    lines.push('这个筛选条件下没查到子弹（换个等级/口径试试）。');
    notes.push('返回 0 条。');
  }
  for (const it of shown) lines.push(formatLine(it, lineFormat));

  notes.unshift(`数据时间：${nowText(fetchedAt)}（来源 orzice.com 的「子弹 - 实时价格」页，服务端渲染的表格）`);
  notes.push(`筛选：${describeFilters(filters)}；本页拿到 ${items.length} 条，发出前 ${shown.length} 条。`);
  if (total) {
    const pages = Math.ceil(total / PER_PAGE);
    notes.push(`一共 ${total} 条（约 ${pages} 页，每页 10 条，当前第 ${page} 页）`
      + (pages > 1 && page === 1 ? ' —— 用户要"全部"时让他说「第 2 页」或换个筛选。' : ''));
  }
  notes.push(`每行格式：${LINE_FORMATS[lineFormat] || LINE_FORMATS.name_price}（想换去技能设置里改「每行显示什么」）`);
  notes.push(`取数通道：${channel === 'page' ? '页面渲染后的表格（真浏览器）' : '直连抓 HTML'}`);
  if (needLogin) notes.push('⚠️ 当前价格这几格显示「登陆查看价格」—— 说明这次没带登录态读到数据，请如实说"要登录才能看价格"，不要报成 0 或 -。');
  notes.push(separateMessages
    ? '发法：上面**每一行是一条单独的消息**，按顺序依次发（send_message 的消息参数支持传字符串数组）。不要合并、不要加序号、不要 @ 任何人、不要用引用回复、不要补开场白或总结。这一段不要发出去。'
    : '发法：把上面各行**合成一条消息**发出去（每行一发子弹，用换行分开；这就是"子弹价格表"，别拆成很多条刷屏）。不要加序号、不要 @ 任何人、不要用引用回复、不要补开场白或总结。这一段不要发出去。');
  if (cachedNote) notes.push(cachedNote);
  return `${lines.join('\n')}\n\n【仅参考·不要发出】\n${notes.join('\n')}`;
}

// ── 技能入口 ────────────────────────────────────────────────────────────
export async function setup(api) {
  cfg = typeof api.config === 'function' ? api.config : () => ({});
  httpFetch = typeof api.fetch === 'function' ? (...args) => api.fetch(...args) : null;
  logger = {
    log: typeof api.log === 'function' ? (...a) => api.log(...a) : () => {},
    warn: typeof api.warn === 'function' ? (...a) => api.warn(...a) : () => {},
    error: typeof api.error === 'function' ? (...a) => api.error(...a) : () => {}
  };

  stateDir = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..', '..', 'data', 'ammo-price');
  dataRoot = path.resolve(stateDir, '..');
  try {
    const m = await import('../../src/config.js');
    if (m?.DATA_DIR) { dataRoot = m.DATA_DIR; stateDir = path.join(m.DATA_DIR, 'ammo-price'); }
  } catch { /* 兜底路径 */ }
  // 缓存文件：8 小时窗口跨重启也算数
  stateFile = path.join(stateDir, 'state.json');
  brLockFile = path.join(stateDir, 'browser.lock');   // 记录浏览器 pid：应用被强杀后下次启动清扫

  // v1.2.1：**加载时就清一次**。老版本（v1.1.0 及更早）不写 lock，光靠 lock 清扫不掉它们
  // 留在桌面上的窗口；所以这里按"配置目录"把所有还在用这份 profile 的浏览器进程清掉 ——
  // 技能一加载（含热重载）就生效，不用等下一次查询。
  try {
    // 延迟 1.2 秒、且**不 await**：① 不拖慢应用启动（要清的是历史残留，不急这几百毫秒）；
    // ② 避开"启动瞬间正好在抓数据"的竞态（sweepBrowsersByProfile 内部还会跳过当前在用的那个）。
    const timer = setTimeout(() => {
      sweepBrowsersByProfile(path.join(stateDir, 'browser-profile'))
        .then((killed) => { if (killed.length) logger.warn('ammo-price: 启动检查清掉了 %s 个残留浏览器进程', killed.length); })
        .catch(() => {});
    }, 1200);
    timer.unref?.();
  } catch { /* 清理失败不影响功能 */ }
  loadState();

  api.registerTool({
    id: 'ammo_price',
    name: '子弹实时价格',
    category: 'knowledge',
    icon: '🔫',
    description: '查《三角洲行动》子弹的实时价格（orzice.com 的「子弹 - 实时价格」页）：按等级（1~5 级 / 全部）、口径、排序方式列出子弹的当前价格、今日涨幅、3日/7日/30日价格与涨跌。默认就是用户要的那一档：**5 级子弹、按当前价格从大到小**（等价于页面 /v/ammo?a=ammo&top=2-2&p=1&grade=5&n=）。'
      + '取数方式：用无头浏览器打开这个页面（服务端渲染的表格）读渲染后的表格，用本机已登录的账号 —— 因为「当前价格」这一列未登录看不到；直连抓 HTML 作备用。'
      + '可用 grade 换等级（1~5，0=全部）、caliber 换口径（如 7.62x51mm、箭矢）、sort 换排序字段（当前价格/今日涨幅/3日涨跌/7日涨跌/30日涨跌）、order 换方向（大到小/小到大）、page 翻页、topN 控制发几条、refresh=true 强制重查。'
      + '用户问「子弹价格」「5级子弹多少钱」「某某口径子弹什么价」「子弹涨价了没」「哪些子弹最贵」时使用。',
    parameters: {
      type: 'object',
      properties: {
        grade: { type: 'number', description: '可选，子弹等级 1~5；传 0 表示全部等级。不传就用设置里的默认（初始 5 级）。用户说「四级子弹」就传 4。' },
        caliber: { type: 'string', description: '可选，子弹口径，例如 7.62x51mm、5.56x45mm、.50 AE、箭矢。不传 = 全部口径。' },
        sort: { type: 'string', description: '可选，排序字段：当前价格（默认）/今日涨幅/3日涨跌/7日涨跌/30日涨跌/等级。' },
        order: { type: 'string', description: '可选，排序方向：大到小（默认）/小到大。' },
        page: { type: 'number', description: '可选，第几页，每页 10 条，默认第 1 页。用户说「下一页/后面的」时传。' },
        topN: { type: 'number', description: '可选，这次发几条，默认取设置里的值（初始 10）。用户说「只看前五」就传 5。' },
        refresh: { type: 'boolean', description: '可选，是否绕过缓存强制重查，默认 false。用户说「重新查/刷新」时才传 true。' }
      }
    },
    async execute(_ctx, args = {}) {
      if (!httpFetch) return { content: '未启用网络权限（web_fetch），无法查询子弹价格。', isError: true };

      const c = cfg() || {};
      // 等级：参数 > 设置；0/负数 = 全部（页面用 -1 表示全部）
      const gradeArg = args?.grade === undefined || args?.grade === null || args?.grade === '' ? null : Number(args.grade);
      const gradeRaw = gradeArg === null ? Number(c.gradeFilter ?? DEFAULT_GRADE) : gradeArg;
      const grade = Number.isFinite(gradeRaw) ? (gradeRaw <= 0 ? -1 : clamp(gradeRaw, 1, 5, DEFAULT_GRADE)) : DEFAULT_GRADE;

      const sortKey = String(args?.sort ?? c.sortBy ?? '当前价格').trim();
      const sort = SORT_FIELDS[sortKey] ?? (Number(sortKey) || DEFAULT_SORT);
      const orderKey = String(args?.order ?? c.orderBy ?? '从大到小').trim();
      const order = ORDER_DIRS[orderKey] ?? (Number(orderKey) || DEFAULT_ORDER);
      const caliber = String(args?.caliber ?? c.caliber ?? '').trim();
      const page = clamp(args?.page ?? 1, 1, 99, 1);
      const topN = clamp(args?.topN ?? c.topN, 1, 30, PER_PAGE);
      const lineFormatRaw = String(c.lineFormat ?? c.stdoutFormats ?? 'name_price').toLowerCase().trim();
      const lineFormat = LINE_FORMATS[lineFormatRaw] ? lineFormatRaw : 'name_price';

      const timeoutMs = clamp(c.timeoutMs, 3000, 30000, 15000);
      // 8 小时抓一次（默认）：窗口内复用磁盘上那份
      const ttlMs = clamp(c.cacheHours, 1, 72, 8) * 3600000;
      const cooldownMs = clamp(c.blockCooldownMin, 1, 240, 3) * 60000;
      const maxPerHour = clamp(c.maxFetchesPerHour, 1, 60, 12);
      const browserMode = String(c.browserMode ?? 'auto').toLowerCase() === 'off' ? 'off' : 'auto';
      const browserExe = String(c.browserPath || '').trim();
      const browserWarmSec = clamp(c.browserWarmSec, 30, 3600, 300);
      const cookie = String(c.cookie || '').trim();
      const ua = String(c.userAgent || '').trim();

      const query = buildQuery({ sort, order, grade, caliber, page });
      // 说「重新查 / 刷新」才强制重抓：把这条查询从缓存里删掉再去联网
      if (args?.refresh === true) { diskCache = diskCache.filter((x) => x.key !== query); blockedUntil = 0; }

      let out;
      try {
        out = await loadAmmo(query, { ttlMs, cooldownMs, maxPerHour, timeoutMs, browserMode, browserExe, browserWarmSec, cookie, ua });
      } catch (e) {
        logger.error('ammo-price: 查询过程异常：%s', e?.stack ?? e?.message ?? e);
        return { content: `查子弹价格时出错：${e?.message ?? e}`, isError: true };
      }
      const sortName = Object.keys(SORT_FIELDS).find((k) => SORT_FIELDS[k] === sort) || '当前价格';
      const orderName = Object.keys(ORDER_DIRS).find((k) => ORDER_DIRS[k] === order) || '大到小';
      const filters = { sortName, orderName, grade, caliber };

      if (out.error) {
        const last = cacheFind(query);
        const stale = last?.payload?.items?.length
          ? `\n\n上次查到的（${agoText(last.at)}，可能已经不是现价）：\n`
            + buildReport({ items: last.payload.items, page, total: last.payload.total, show: topN, lineFormat,
              separateMessages: false, channel: last.channel, fetchedAt: last.at, filters, query })
              .split('\n\n【仅参考')[0]
          : '';
        return { content: out.error + stale, isError: true };
      }

      const content = buildReport({
        items: out.items || [], page, total: out.total, show: topN, lineFormat,
        separateMessages: c.separateMessages === true,      // 默认合一条发（子弹有十来行，别刷屏）
        channel: out.channel, fetchedAt: out.fetchedAt || Date.now(), filters, query,
        needLogin: out.needLogin === true,
        cachedNote: out.fromCache
          ? `本次用的是 ${agoText(out.fetchedAt)} 抓的那一份（设置是「8 小时抓一次」，还有约 ${out.leftText} 才到下次抓取）。要马上要最新的就说「重新查」。`
          : `本次是真去抓的（8 小时窗口内的第一次问；下次问直接复用这一份）。`
      });
      return { content };
    }
  });
}

export function available() {
  if (!httpFetch) return { ok: false, reason: '缺少 web_fetch 权限（清单里的 permissions 被删了？）' };
  return true;
}

export function dispose() { return closeBrowser(); }
export function deactivate() { return closeBrowser(); }
