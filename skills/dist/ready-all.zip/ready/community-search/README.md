# 社区搜：米游社 / 百度贴吧 / 库街区 / 森空岛 / TapTap

给 QQ Agent 增加五个二游社区搜索源。适合查攻略、版本讨论、玩家评价、节奏和「社区怎么说」。

## 工具

`community-search__search`

| 参数 | 说明 |
|---|---|
| `query` | 搜索关键词（必填） |
| `source` | `auto`（默认，并行全查）/ `miyoushe` / `tieba` / `kuro` 库街区 / `skland` 森空岛 / `taptap` |
| `game` | 仅米游社：`auto` / `ys` 原神 / `sr` 星穹铁道 / `zzz` 绝区零 / `bh3` 崩坏3 / `wd` 未定事件簿 / `bbs` 大别野 |
| `limit` | 1~10，默认 5 |

返回每条结果的 `sourceName`、`title`、`url`、`snippet`、`author`、`forum`、`game`、`time`、`stats`（浏览量/回复/点赞）。`auto` 会并行查五个来源，单家失败不影响其它家，失败原因放在 `errors`。结果按关键词相关性过滤（标题或摘要要命中查询词），**不按浏览量截断**。

## 数据来源

- 米游社：`https://bbs-api.miyoushe.com/post/wapi/searchPosts`（公开 JSON，免登录）
- 百度贴吧：`https://tieba.baidu.com/mo/q/search/thread`（移动端 JSON，免登录；桌面版搜索页会跳安全验证）
- 库街区（库洛）：`https://api.kurobbs.com/forum/search/v2/post`（POST 表单，需带 gameId；2=战双帕弥什、3=鸣潮，两个都查）
- 森空岛（鹰角）：`https://zonai.skland.com/web/v2/search/item`，带登录态签名 `sign = MD5(hex(HMAC-SHA256(message, skToken)))`；凭据在设置页（skToken / skDId / 时间偏移）
- TapTap：`https://www.taptap.cn/webapiv2/search/v6/agg-search`（POST multipart，types=community），带 X-UA（含 UID/VID）、XSRF、登录 Cookie；凭据在设置页

## 已知限制

- 森空岛 / TapTap 的凭据来自本机 Edge 登录态：**退出登录或凭据过期后这两个源会失败**，需要重新登录对应网站并从设置页更新凭据；失败会明确写进 `errors`，不会假装「没搜到」。
- 森空岛搜索列表没有浏览量字段（stats.views=0），只有点赞/评论/转发；TapTap 有 pv_total。
- 社区内容是 UGC，版本、活动、数值等硬信息仍应以官方公告为准。

## 配置

设置 → 技能 → 社区搜：

- `timeoutMs`：单次请求超时，默认 12000ms
- `defaultLimit`：默认返回条数，默认 5
- `maxSnippetChars`：摘要字数上限，默认 320
