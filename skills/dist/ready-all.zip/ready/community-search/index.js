// 社区搜：米游社 / 贴吧 / 库街区 / 森空岛 / TapTap（community-search v1.2.0）
//
// 数据来源：
//   · 米游社：bbs-api.miyoushe.com/post/wapi/searchPosts（JSON，免登录）
//   · 贴吧：tieba.baidu.com/mo/q/search/thread（移动端 JSON，免登录）
//   · 库街区：api.kurobbs.com/forum/search/v2/post（POST 表单，带 gameId）
//   · 森空岛：zonai.skland.com/web/v2/search/item（需登录态签名：sign=MD5(HMAC-SHA256)）
//   · TapTap：www.taptap.cn/webapiv2/search/v6/agg-search（需 X-UA/XSRF/登录 cookies）
//
// 设计取舍：
//   · 只做「搜索」：返回标题/链接/摘要/作者/版块/时间，不把整页 HTML 塞进上下文。
//   · 各来源独立、并行请求；一个挂了另一个照常返回（errors 里说明原因）。
//   · 社区内容是 UGC，不是官方公告。提示词里明确要求模型区分「玩家说法」和「官方说法」。
//
// 依赖：api.fetch（skill.json 声明 web_fetch 才拿得到）。

import { createHmac, createHash } from 'node:crypto';

const MIYOUSHE_SEARCH = 'https://bbs-api.miyoushe.com/post/wapi/searchPosts';
const TIEBA_SEARCH = 'https://tieba.baidu.com/mo/q/search/thread';
const KURO_SEARCH = 'https://api.kurobbs.com/forum/search/v2/post';
const SKLAND_SEARCH = 'https://zonai.skland.com/web/v2/search/item';
const TAPTAP_AGG = 'https://www.taptap.cn/webapiv2/search/v6/agg-search';
const BING_SEARCH = 'https://www.bing.com/search';

const DESKTOP_UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
  + '(KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36';
// 贴吧的 /mo/q/search/thread 是移动端 JSON 接口；桌面 UA 会拿到安全验证页。
const MOBILE_UA = 'Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 '
  + '(KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36';

const GAMES = {
  auto: { gids: null, name: '全部游戏' },
  ys: { gids: 2, name: '原神' },
  sr: { gids: 6, name: '崩坏：星穹铁道' },
  zzz: { gids: 8, name: '绝区零' },
  bh3: { gids: 1, name: '崩坏3' },
  wd: { gids: 4, name: '未定事件簿' },
  bbs: { gids: 5, name: '大别野' }
};

const GAME_SLUG = { 1: 'bh3', 2: 'ys', 3: 'bh2', 4: 'wd', 5: 'bbs', 6: 'sr', 8: 'zzz' };
const SOURCE_NAMES = { miyoushe: '米游社', tieba: '百度贴吧', kuro: '库街区', skland: '森空岛', taptap: 'TapTap' };
const SOURCE_LABELS = { miyoushe: '米游社', tieba: '贴吧', kuro: '库街区', skland: '森空岛', taptap: 'TapTap' };

// 库街区要求带游戏 ID（2=战双帕弥什，3=鸣潮）。两个都查，避免只覆盖一个游戏。
const KURO_GAME_IDS = [2, 3];
const KURO_HEADERS = {
  'source': 'h5',
  'version': '2.5.0',
  'devCode': '0123456789abcdef0123456789abcdef',
  'Content-Type': 'application/x-www-form-urlencoded'
};

/** 森空岛 listId：网页端每次搜索随机生成 16 位字母数字。 */
function randomSkListId() {
  const chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
  let out = '';
  for (let i = 0; i < 16; i += 1) out += chars[Math.floor(Math.random() * chars.length)];
  return out;
}

let cfg = () => ({});
let httpFetch = null;
let log = () => {};

function clamp(value, min, max, fallback) {
  const n = Number(value);
  if (!Number.isFinite(n)) return fallback;
  return Math.min(max, Math.max(min, Math.floor(n)));
}

function readConfig() {
  const raw = (typeof cfg === 'function' ? cfg() : cfg) || {};
  return {
    timeoutMs: clamp(raw.timeoutMs, 3000, 30000, 12000),
    defaultLimit: clamp(raw.defaultLimit, 1, 10, 5),
    maxSnippetChars: clamp(raw.maxSnippetChars, 100, 800, 320),
    // 森空岛登录态（从本机 Edge 提取）
    skToken: String(raw.skToken ?? '').trim(),
    skDId: String(raw.skDId ?? '').trim(),
    skTimeOffset: Number(raw.sklandTimeOffset) || 1,
    // TapTap 登录态（从本机 Edge 提取）
    tapXua: String(raw.tapXua ?? '').trim(),
    tapCookie: String(raw.tapCookie ?? '').trim(),
    tapXsrf: String(raw.tapXsrf ?? '').trim()
  };
}

function decodeEntities(s) {
  return String(s ?? '')
    .replace(/&nbsp;/gi, ' ')
    .replace(/&lt;/gi, '<')
    .replace(/&gt;/gi, '>')
    .replace(/&quot;/gi, '"')
    .replace(/&#0?39;|&apos;/gi, "'")
    .replace(/&mdash;/gi, '—')
    .replace(/&amp;/gi, '&')
    .replace(/&#(\d+);/g, (_, d) => String.fromCharCode(Number(d)))
    .replace(/&#x([0-9a-f]+);/gi, (_, h) => String.fromCharCode(parseInt(h, 16)));
}

/** HTML → 单行纯文本。保留换行会让摘要更可读，但这里统一压成一行，省 token。 */
function htmlToText(html) {
  return String(html ?? '')
    .replace(/<script[\s\S]*?<\/script>/gi, ' ')
    .replace(/<style[\s\S]*?<\/style>/gi, ' ')
    .replace(/<noscript[\s\S]*?<\/noscript>/gi, ' ')
    .replace(/<!--[\s\S]*?-->/g, ' ')
    .replace(/<br\s*\/?>/gi, '\n')
    .replace(/<img\b[^>]*>/gi, '[图片]')
    .replace(/<\/(p|div|li|tr|h[1-6]|section|article|blockquote)>/gi, '\n')
    .replace(/<[^>]+>/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

function cleanText(value, maxChars) {
  const text = htmlToText(decodeEntities(value));
  const max = Math.max(1, Number(maxChars) || 120);
  return text.length > max ? `${text.slice(0, max - 1)}…` : text;
}

function formatTime(ts) {
  const n = Number(ts);
  if (!Number.isFinite(n) || n <= 0) return '';
  try {
    return new Intl.DateTimeFormat('zh-CN', {
      timeZone: 'Asia/Shanghai',
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit',
      hour12: false
    }).format(new Date(n * 1000)).replace(/\//g, '-');
  } catch {
    return '';
  }
}

async function fetchText(url, { headers = {}, timeoutMs = 12000 } = {}) {
  if (typeof httpFetch !== 'function') throw new Error('没有拿到 web_fetch 权限');
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), timeoutMs);
  try {
    const res = await httpFetch(url, {
      headers: {
        'Accept-Language': 'zh-CN,zh;q=0.9',
        ...headers
      },
      redirect: 'follow',
      signal: ctrl.signal
    });
    const text = await res.text();
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    return text;
  } catch (error) {
    if (error?.name === 'AbortError') throw new Error(`请求超时（${timeoutMs}ms）`);
    throw error;
  } finally {
    clearTimeout(timer);
  }
}

async function fetchJson(url, options, label) {
  const text = await fetchText(url, options);
  try {
    return JSON.parse(text);
  } catch {
    // 贴吧/米游社被风控时都会返回 200 + HTML 验证页，直接说清楚，别让模型以为“没结果”。
    throw new Error(`${label}返回的不是 JSON（可能被风控拦截或接口改版）`);
  }
}

/** 米游社搜索：公开 JSON 接口，免登录。 */
export async function searchMiyoushe(query, { limit = 5, game = 'auto', timeoutMs = 12000, snippetChars = 320 } = {}) {
  const g = GAMES[game] || GAMES.auto;
  const params = new URLSearchParams({
    keyword: String(query),
    size: String(clamp(limit, 1, 10, 5))
  });
  if (g.gids) params.set('gids', String(g.gids));

  const data = await fetchJson(`${MIYOUSHE_SEARCH}?${params.toString()}`, {
    timeoutMs,
    headers: {
      'User-Agent': DESKTOP_UA,
      'Referer': 'https://www.miyoushe.com/',
      'Accept': 'application/json, text/plain, */*'
    }
  }, '米游社');

  if (Number(data?.retcode) !== 0) {
    throw new Error(`米游社接口报错：${data?.message || data?.retcode || '未知'}`);
  }
  const posts = Array.isArray(data?.data?.posts) ? data.data.posts : [];
  return posts.slice(0, clamp(limit, 1, 10, 5)).map((item) => {
    const post = item?.post || {};
    const user = item?.user || {};
    const forum = item?.forum || {};
    const stat = item?.stat || {};
    const slug = GAME_SLUG[Number(post.game_id)] || 'ys';
    return {
      source: 'miyoushe',
      sourceName: SOURCE_NAMES.miyoushe,
      title: cleanText(post.subject, 120) || cleanText(post.content, 60) || '（无标题）',
      url: `https://www.miyoushe.com/${slug}/article/${encodeURIComponent(post.post_id)}`,
      snippet: cleanText(post.content, snippetChars),
      author: cleanText(user.nickname, 60),
      forum: cleanText(forum.name, 40),
      game: GAMES[slug]?.name || '',
      time: formatTime(post.created_at),
      stats: {
        views: Number(stat.view_num) || 0,
        replies: Number(stat.reply_num) || 0,
        likes: Number(stat.like_num) || 0
      }
    };
  });
}

/** 贴吧搜索：移动端 JSON 接口；桌面版 /f/search/res 会直接跳安全验证。 */
export async function searchTieba(query, { limit = 5, timeoutMs = 12000, snippetChars = 320 } = {}) {
  const data = await fetchJson(`${TIEBA_SEARCH}?word=${encodeURIComponent(String(query))}`, {
    timeoutMs,
    headers: {
      'User-Agent': MOBILE_UA,
      'Referer': 'https://tieba.baidu.com/',
      'Accept': 'application/json, text/plain, */*'
    }
  }, '贴吧');

  if (Number(data?.no) !== 0 || !data?.data) {
    throw new Error(`贴吧接口报错：${data?.error || data?.no || '未知'}`);
  }
  const posts = Array.isArray(data.data.post_list) ? data.data.post_list : [];
  return posts.slice(0, clamp(limit, 1, 10, 5)).map((item) => {
    const user = item?.user || {};
    return {
      source: 'tieba',
      sourceName: SOURCE_NAMES.tieba,
      title: cleanText(item?.title, 120) || cleanText(item?.content, 60) || '（无标题）',
      url: `https://tieba.baidu.com/p/${encodeURIComponent(item?.tid)}`,
      snippet: cleanText(item?.content, snippetChars),
      author: cleanText(user.show_nickname || user.user_name, 60),
      forum: cleanText(item?.forum_name, 40),
      time: formatTime(item?.create_time || item?.time),
      stats: {
        replies: Number(item?.post_num) || 0,
        likes: Number(item?.like_num) || 0
      }
    };
  });
}

/** POST 表单（application/x-www-form-urlencoded）。库街区搜索需要这种形态。 */
async function fetchForm(url, params, { headers = {}, timeoutMs = 12000 } = {}) {
  if (typeof httpFetch !== 'function') throw new Error('没有拿到 web_fetch 权限');
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), timeoutMs);
  try {
    const res = await httpFetch(url, {
      method: 'POST',
      headers: {
        'Accept-Language': 'zh-CN,zh;q=0.9',
        'User-Agent': DESKTOP_UA,
        ...headers
      },
      body: new URLSearchParams(params).toString(),
      redirect: 'follow',
      signal: ctrl.signal
    });
    const text = await res.text();
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    return text;
  } catch (error) {
    if (error?.name === 'AbortError') throw new Error(`请求超时（${timeoutMs}ms）`);
    throw error;
  } finally {
    clearTimeout(timer);
  }
}

/** 库街区（库洛游戏官方社区）搜索：公开接口，免登录，但要带 gameId。 */
export async function searchKuro(query, { limit = 5, timeoutMs = 12000, snippetChars = 320 } = {}) {
  const max = clamp(limit, 1, 10, 5);
  const out = [];
  for (const gameId of KURO_GAME_IDS) {
    const text = await fetchForm(KURO_SEARCH, {
      query: String(query),
      keyword: String(query),
      gameId: String(gameId),
      page: '1',
      size: String(max * 2)
    }, { headers: KURO_HEADERS, timeoutMs });
    let data;
    try {
      data = JSON.parse(text);
    } catch {
      throw new Error('库街区返回的不是 JSON（可能被风控或接口改版）');
    }
    if (Number(data?.code) !== 200) {
      throw new Error(`库街区接口报错：${data?.msg || data?.code || '未知'}`);
    }
    const posts = Array.isArray(data?.data?.postList) ? data.data.postList : [];
    for (const item of posts) {
      out.push({
        source: 'kuro',
        sourceName: SOURCE_NAMES.kuro,
        title: cleanText(item?.postTitle, 120) || cleanText(item?.postContent, 60) || '（无标题）',
        url: `https://www.kurobbs.com/forumDetail/${encodeURIComponent(item?.postId)}`,
        snippet: cleanText(item?.postContent, snippetChars),
        author: cleanText(item?.userName, 60),
        forum: cleanText(item?.gameName, 40),
        game: cleanText(item?.gameName, 40),
        time: formatTime(item?.createTimestamp ? Number(item.createTimestamp) / 1000 : 0),
        stats: {
          views: Number(item?.browseCount) || 0,
          replies: Number(item?.commentCount) || 0,
          likes: Number(item?.likeCount) || 0
        }
      });
    }
  }
  return out.slice(0, max);
}

/** TapTap 社区搜索：agg-search v6（网页端真实接口），带登录态 X-UA/XSRF/Cookie。 */
export async function searchTaptap(query, { limit = 5, timeoutMs = 12000, snippetChars = 320 } = {}) {
  const c = readConfig();
  const max = clamp(limit, 1, 10, 5);
  if (!c.tapXua) {
    return searchBingSite('www.taptap.cn', query, { limit: max, timeoutMs, snippetChars, label: 'TapTap' });
  }
  const url = `${TAPTAP_AGG}?X-UA=${encodeURIComponent(c.tapXua)}`;
  const boundary = `----WebKitFormBoundary${Math.random().toString(36).slice(2)}`;
  const body = [
    `--${boundary}`,
    'Content-Disposition: form-data; name="kw"',
    '',
    String(query),
    `--${boundary}`,
    'Content-Disposition: form-data; name="types"',
    '',
    'community',
    `--${boundary}--`
  ].join('\r\n') + '\r\n';
  const headers = {
    'User-Agent': DESKTOP_UA,
    'Referer': 'https://www.taptap.cn/search/community',
    'x-requested-with': 'XMLHttpRequest',
    'Content-Type': `multipart/form-data; boundary=${boundary}`
  };
  if (c.tapCookie) headers.Cookie = c.tapCookie;
  if (c.tapXsrf) headers['x-xsrf-token'] = c.tapXsrf;

  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), timeoutMs);
  let data;
  try {
    if (typeof httpFetch !== 'function') throw new Error('没有拿到 web_fetch 权限');
    const res = await httpFetch(url, { method: 'POST', headers, body, redirect: 'follow', signal: ctrl.signal });
    const text = await res.text();
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    try {
      data = JSON.parse(text);
    } catch {
      throw new Error('TapTap 返回的不是 JSON（可能被风控）');
    }
  } catch (error) {
    if (error?.name === 'AbortError') throw new Error(`请求超时（${timeoutMs}ms）`);
    throw error;
  } finally {
    clearTimeout(timer);
  }

  const groups = Array.isArray(data?.data?.list) ? data.data.list : [];
  const moments = [];
  for (const group of groups) {
    if (group?.type !== 'community' || !Array.isArray(group.list)) continue;
    for (const entry of group.list) {
      if (entry?.type !== 'moment' || !entry.moment) continue;
      moments.push(entry.moment);
    }
  }
  if (moments.length) {
    return moments.slice(0, max).map((m) => ({
      source: 'taptap',
      sourceName: SOURCE_NAMES.taptap,
      title: cleanText(m.title, 120) || cleanText(m.summary, 60) || '（无标题）',
      url: `https://www.taptap.cn/moment/${encodeURIComponent(m.id_str || m.id)}`,
      snippet: cleanText(m.summary, snippetChars),
      author: cleanText(m.author?.user?.name, 60),
      forum: cleanText(m.group?.name ?? '', 40),
      game: cleanText(m.app?.title ?? '', 40),
      time: formatTime(m.created_time ?? m.edited_time ?? 0),
      stats: {
        views: Number(m.stat?.pv_total) || 0,
        replies: Number(m.stat?.comments) || 0,
        likes: Number(m.stat?.ups) || 0
      }
    }));
  }
  // 直连接口空结果 → Bing site: 兜底
  return searchBingSite('www.taptap.cn', query, { limit: max, timeoutMs, snippetChars, label: 'TapTap' });
}

/**
 * 森空岛（鹰角网络官方社区）搜索。
 * 签名算法（对照网页端 4941 chunk 复刻）：
 *   sign = MD5(hex(HMAC-SHA256(message, token)))
 *   message = path + query(GET) + timestamp + JSON.stringify({platform,timestamp,dId,vName})
 * 凭据来自本机 Edge 的 localStorage（SK_TOKEN_CACHE_KEY / SK_SHUMEI_DEVICE_ID_KEY）。
 */
export async function searchSkland(query, { limit = 5, timeoutMs = 12000, snippetChars = 320 } = {}) {
  const c = readConfig();
  const max = clamp(limit, 1, 10, 5);
  if (!c.skToken || !c.skDId) {
    return searchBingSite('www.skland.com', query, { limit: max, timeoutMs, snippetChars, label: '森空岛' });
  }
  const nowSec = Math.floor(Date.now() / 1000);
  const timestamp = String(nowSec + Math.max(0, Number(c.skTimeOffset) || 1));
  const path = '/web/v2/search/item';
  const params = new URLSearchParams();
  params.set('keyword', String(query));
  params.set('pageSize', String(max * 2));
  params.set('viewKind', '0');
  params.set('sortType', '1');
  params.set('listId', randomSkListId());
  const qs = params.toString();
  const signHeaders = { platform: '3', timestamp, dId: c.skDId, vName: '1.0.0' };
  const message = path + qs + timestamp + JSON.stringify(signHeaders);
  const hmacHex = createHmac('sha256', c.skToken).update(message, 'utf8').digest('hex');
  const sign = createHash('md5').update(hmacHex, 'utf8').digest('hex');

  let data;
  try {
    data = await fetchJson(`${SKLAND_SEARCH}?${qs}`, {
      timeoutMs,
      headers: {
        'platform': '3',
        'timestamp': timestamp,
        'sign': sign,
        'dId': c.skDId,
        'vName': '1.0.0',
        'Content-Type': 'application/json',
        'Referer': 'https://www.skland.com/',
        'User-Agent': DESKTOP_UA
      }
    }, '森空岛');
  } catch (error) {
    // 登录态过期/风控 → 兜底，别让整个来源直接挂掉
    const bing = await searchBingSite('www.skland.com', query, { limit: max, timeoutMs, snippetChars, label: '森空岛' }).catch(() => null);
    if (bing?.length) return bing;
    throw new Error(`森空岛直连失败（${error?.message ?? error}）`);
  }
  if (Number(data?.code) !== 0) {
    throw new Error(`森空岛接口报错：${data?.message || data?.code || '未知'}`);
  }
  const list = Array.isArray(data?.data?.list) ? data.data.list : [];
  const out = list.slice(0, max).map((entry) => ({
    source: 'skland',
    sourceName: SOURCE_NAMES.skland,
    title: cleanText(entry?.item?.title, 120) || cleanText(entry?.item?.caption, 60) || '（无标题）',
    url: `https://www.skland.com/article/${encodeURIComponent(entry?.item?.id)}`,
    snippet: cleanText(entry?.item?.caption ?? '', snippetChars) || cleanText(entry?.item?.title ?? '', snippetChars),
    author: cleanText(entry?.user?.nickname, 60),
    forum: cleanText(entry?.tags?.map((t) => t?.name).filter(Boolean).join(' / '), 40),
    game: '',
    time: formatTime(entry?.item?.publishedAtTs ? Number(entry.item.publishedAtTs) / 1000 : 0),
    stats: {
      views: 0,
      replies: Number(entry?.itemRts?.commented) || 0,
      likes: Number(entry?.itemRts?.liked) || 0
    }
  }));
  if (!out.length) {
    const bing = await searchBingSite('www.skland.com', query, { limit: max, timeoutMs, snippetChars, label: '森空岛' }).catch(() => null);
    if (bing?.length) return bing;
    throw new Error('森空岛没有搜到相关帖子');
  }
  return out;
}

/** Bing site: 搜索兜底：抓网页结果页，按域名过滤。 */
async function searchBingSite(domain, query, { limit = 5, timeoutMs = 12000, snippetChars = 320, label = '' } = {}) {
  const max = clamp(limit, 1, 10, 5);
  const q = `site:${domain} ${String(query)}`;
  const url = `${BING_SEARCH}?q=${encodeURIComponent(q)}&count=20&setlang=zh-hans`;
  const html = await fetchText(url, {
    timeoutMs,
    headers: {
      'User-Agent': DESKTOP_UA,
      'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
      'Accept-Language': 'zh-CN,zh;q=0.9'
    }
  });
  const out = [];
  const seen = new Set();
  const blocks = String(html).split('class="b_algo"').slice(1);
  for (const block of blocks) {
    const link = (block.match(/<h2[^>]*>[\s\S]*?<a[^>]*href="([^"]+)"/i) || [])[1] || '';
    const title = cleanText((block.match(/<h2[^>]*>[\s\S]*?<a[^>]*>([\s\S]*?)<\/a>/i) || [])[1] || '', 120);
    const snippet = cleanText((block.match(/<p[^>]*>([\s\S]*?)<\/p>/i) || [])[1] || '', snippetChars);
    if (!link) continue;
    let host = '';
    try { host = new URL(link).hostname.toLowerCase(); } catch { continue; }
    if (!host.includes(String(domain).replace(/^www\./, '')) || seen.has(link)) continue;
    seen.add(link);
    out.push({
      source: label === 'TapTap' ? 'taptap' : 'skland',
      sourceName: label || SOURCE_NAMES.skland,
      title: title || '（无标题）',
      url: link,
      snippet,
      author: '',
      forum: '',
      time: '',
      stats: { views: 0, replies: 0, likes: 0 }
    });
    if (out.length >= max) break;
  }
  if (!out.length) {
    throw new Error(`${label || domain} 的站内搜索没有解析到结果（官方接口需设备签名或搜索引擎未收录）`);
  }
  return out;
}

/** 相关性过滤：标题/摘要必须命中查询里的至少一个词（2 字以上），防止答非所问。 */
function isRelevant(item, query) {
  const hay = `${item?.title ?? ''} ${item?.snippet ?? ''}`.toLowerCase();
  const tokens = String(query).toLowerCase().match(/[\u4e00-\u9fff]{2,}|[a-z0-9]{2,}/g) || [];
  if (!tokens.length) return true;
  return tokens.some((token) => hay.includes(token));
}

function normalizeSource(value) {
  const s = String(value ?? '').toLowerCase();
  return ['auto', 'miyoushe', 'tieba', 'kuro', 'skland', 'taptap'].includes(s) ? s : 'auto';
}

function normalizeGame(value) {
  const g = String(value ?? '').toLowerCase();
  return Object.prototype.hasOwnProperty.call(GAMES, g) ? g : 'auto';
}

/** 两个来源按轮次交错，避免“前 5 条全是米游社、贴吧被截掉”。 */
function interleave(groups, limit) {
  const out = [];
  let index = 0;
  while (out.length < limit) {
    let added = false;
    for (const group of groups) {
      if (group[index]) {
        out.push(group[index]);
        added = true;
        if (out.length >= limit) break;
      }
    }
    if (!added) break;
    index += 1;
  }
  return out;
}

/**
 * 统一搜索入口。source=auto 时并行查两家，单家失败不影响另一家。
 * 返回值始终包含 errors 与 perSource，模型能说清“哪个源没搜到/为什么没搜到”。
 */
export async function searchCommunity(query, {
  source = 'auto',
  game = 'auto',
  limit = 5,
  timeoutMs = 12000,
  snippetChars = 320
} = {}) {
  const q = String(query ?? '').trim();
  if (!q) throw new Error('搜索关键词为空');
  const src = normalizeSource(source);
  const gameKey = normalizeGame(game);
  const max = clamp(limit, 1, 10, 5);
  const opts = { limit: max, game: gameKey, timeoutMs, snippetChars };

  const tasks = [];
  if (src === 'auto' || src === 'miyoushe') tasks.push(['miyoushe', () => searchMiyoushe(q, opts)]);
  if (src === 'auto' || src === 'tieba') tasks.push(['tieba', () => searchTieba(q, opts)]);
  if (src === 'auto' || src === 'kuro') tasks.push(['kuro', () => searchKuro(q, opts)]);
  if (src === 'auto' || src === 'skland') tasks.push(['skland', () => searchSkland(q, opts)]);
  if (src === 'auto' || src === 'taptap') tasks.push(['taptap', () => searchTaptap(q, opts)]);

  const settled = await Promise.allSettled(tasks.map(([, run]) => run()));
  const groups = [];
  const errors = [];
  const perSource = {};

  settled.forEach((result, i) => {
    const name = tasks[i][0];
    if (result.status === 'fulfilled') {
      perSource[name] = result.value.length;
      if (result.value.length) groups.push(result.value);
    } else {
      perSource[name] = 0;
      errors.push(`${SOURCE_NAMES[name]}：${result.reason?.message ?? result.reason}`);
    }
  });

  const merged = src === 'auto' ? interleave(groups, max) : (groups[0] || []).slice(0, max);
  // 同一帖子在不同来源不会重复，但米游社偶尔会返回同 post_id 的重复项；按 URL 兜底去重。
  const seen = new Set();
  const deduped = merged.filter((item) => {
    if (!item?.url || seen.has(item.url)) return false;
    seen.add(item.url);
    return true;
  });
  // 相关性优先：先要标题/摘要命中查询词的；不够 limit 条再用来源自己判定相关的兜底补齐。
  const relevant = deduped.filter((item) => isRelevant(item, q));
  const results = [...relevant];
  for (const item of deduped) {
    if (results.length >= max) break;
    if (!results.includes(item)) results.push(item);
  }

  return {
    query: q,
    source: src,
    game: gameKey,
    gameName: GAMES[gameKey]?.name || '全部游戏',
    results,
    errors,
    perSource
  };
}

export function setup(api) {
  cfg = typeof api.config === 'function' ? api.config : () => ({});
  log = typeof api.log === 'function' ? api.log : () => {};
  httpFetch = typeof api.fetch === 'function' ? (...args) => api.fetch(...args) : null;

  api.registerTool({
    id: 'search',
    name: '搜社区（五源）',
    description:
      '按关键词搜二游社区帖子：米游社、百度贴吧、库街区（库洛）、森空岛（鹰角）、TapTap，'
      + '返回标题、链接、作者、版块、时间和摘要，只保留与关键词相关的帖子（不按浏览量截断）。'
      + 'source=auto 并行搜全部来源，也可以只搜某一个：miyoushe / tieba / kuro / skland / taptap。'
      + 'game 只对米游社生效：ys=原神、sr=星穹铁道、zzz=绝区零、bh3=崩坏3、wd=未定事件簿、bbs=大别野，auto=不限。'
      + '社区内容是 UGC，不是官方公告；版本/活动/数值要以官方为准。',
    category: 'web',
    icon: '💬',
    parameters: {
      type: 'object',
      properties: {
        query: { type: 'string', description: '搜索关键词，越具体越准；不要放整段聊天记录' },
        source: {
          type: 'string',
          enum: ['auto', 'miyoushe', 'tieba', 'kuro', 'skland', 'taptap'],
          description: 'auto=并行搜全部来源（默认）；miyoushe 米游社；tieba 百度贴吧；kuro 库街区（库洛）；skland 森空岛（鹰角）；taptap TapTap'
        },
        game: {
          type: 'string',
          enum: ['auto', 'ys', 'sr', 'zzz', 'bh3', 'wd', 'bbs'],
          description: '米游社游戏筛选：ys 原神、sr 星穹铁道、zzz 绝区零、bh3 崩坏3、wd 未定事件簿、bbs 大别野；auto 不限'
        },
        limit: { type: 'integer', description: '返回条数，1~10，默认 5' }
      },
      required: ['query']
    },
    async execute(_ctx, args = {}) {
      const c = readConfig();
      const query = String(args?.query ?? args?.keyword ?? '').trim();
      if (!query) return { content: '缺少 query：请把用户想搜的关键词提炼成一个词再调用。', isError: true };

      const source = normalizeSource(args?.source);
      const game = normalizeGame(args?.game);
      const limit = clamp(args?.limit, 1, 10, c.defaultLimit);

      try {
        const data = await searchCommunity(query, {
          source,
          game,
          limit,
          timeoutMs: c.timeoutMs,
          snippetChars: c.maxSnippetChars
        });
        const note = data.results.length
          ? '这些是社区 UGC：引用时说明来源和帖子标题；版本、活动规则、数值以官方公告为准。'
          : (data.errors.length
            ? '这次没有拿到结果，errors 里是各来源的失败原因；可以换个关键词或只查某个来源再试。'
            : '这些来源都没有搜到与关键词相关的帖子，可以换个更短/更常见的关键词再试。');
        const payload = { ...data, note };
        return {
          content: JSON.stringify(payload),
          isError: data.results.length === 0 && data.errors.length > 0
        };
      } catch (error) {
        return { content: `社区搜索失败：${error?.message ?? error}`, isError: true };
      }
    }
  });

  log('[community-search] 已注册：米游社 + 百度贴吧');
}
