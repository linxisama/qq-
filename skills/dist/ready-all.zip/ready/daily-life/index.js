// skills/daily-life/index.js
//
// 「她的日常」—— LLM 型技能（放 skills/）。
//
// ── 为什么是技能，不是插件（三问判断法）──────────────────────────────────
//   第一问：触发时机能用 if 写死吗？
//     ✗ 不能。「什么时候说这件事算合适」要看话题、语气、场合；「被问到」本身就
//       是模型在读人话。写死成定时器只能变成"每天定点播报我今天吃了啥"，
//       那不是过日子，是日程播报，群里只会觉得吵。
//   第二问：漏触发一次的代价？
//     很小。这不像问早/提醒那种"承诺过的服务"，没提就是这次没聊到，没有违约。
//   第三问：参数从哪来？
//     ✗ 不能从人话里抠。每天的内容必须由"人设 + 连续性 + 当下语境"生成 ——
//       模板化的日常（今天吃了{食物}）一眼就假，正是要避免的 AI 味。
//   三问一致指向 LLM 型 → skills/。
//
// ── 分工（这条边界别越）──────────────────────────────────────────────────
//   确定性的那半（本文件干）：日期与时段切分、时间线落盘、跨天/跨重启的连续性、
//     "哪条还没跟人提过"的去重、每天主动提的额度、历史裁剪。
//   判断的那半（模型干）：今天具体发生了什么、怎么说出口、什么时候说。
//   工具只递本子和尺子，不动笔 —— 工具替它编日常，等于把判断权收回模板里。
//
// ── 记录长什么样（data/daily-life/state.json）────────────────────────────
//   { version, days: { "YYYY-MM-DD": { date, events: [{ text, slot, at, told }] } },
//     told: { day, count }, warnedKey }
//   told=false 表示"这件事还没跟人提过"；action=share 会挑一条未提过的并标记，
//   这样同一件事不会换着说法反复讲。
//
// ── 踩坑备忘 ─────────────────────────────────────────────────────────────
//   · 日期一律用**本地时间**（localDay），不能用 toISOString —— 那是 UTC，
//     北京时间凌晨会把"今天"算成昨天，时间线直接错一天。
//   · 补记过去时段时，落盘时刻要用该时段的默认时刻（SCHEDULE.sample），
//     不能用当前时间：下午三点补记上午的事，写成 15:00 会让时间线自相矛盾。
//   · 提示词里的动态段（promptSections）内容每轮都变，必须给低 priority
//     排在所有静态片段之后（prompt.js 按 priority 降序排），否则会把后面
//     核心提示词的字节位置推来推去，系统提示词的前缀缓存全部失效。
//   · 工具 id 会拼成发给模型的 function name：注册后实际叫 daily-life__life
//     （skillId__工具id，见 plugin-loader.js 的 createSkillApi）。提示词里写的
//     必须是这个全名，写错了模型会照着叫一个不存在的工具，表现为静默失效。
//   · 不设定时器。本技能没有"到点自动执行"的需求，定时器反而会在热重载时
//     变成幽灵行为（禁用后还在跑）。

import fs from 'node:fs';
import path from 'node:path';
import { DATA_DIR } from '../../src/config.js';
import { setSkillConfig } from '../../src/skills/config.js';

const ID = 'daily-life';
const STATE_VERSION = 1;
const MAX_EVENT_CHARS = 160;      // 单条日常的字数上限：防止模型把一整篇小作文写进来
const MAX_EVENTS_PER_DAY = 30;
const MAX_PROFILE_CHARS = 600;
const DEFAULT_HISTORY_DAYS = 30;
const DEFAULT_MAX_SHARES = 2;

/**
 * 一天分六个时段。
 *   from   —— 该时段从几点开始（用于判断"现在算哪个时段""哪些时段已经过完"）
 *   sample —— 补记这个时段时使用的默认时刻（见文件头"补记过去时段"）
 */
const SCHEDULE = [
  { key: 'zao', label: '早上', from: 5, sample: '07:30' },
  { key: 'shangwu', label: '上午', from: 9, sample: '10:20' },
  { key: 'zhongwu', label: '中午', from: 12, sample: '12:40' },
  { key: 'xiawu', label: '下午', from: 14, sample: '15:40' },
  { key: 'wan', label: '晚上', from: 18, sample: '19:30' },
  { key: 'shenye', label: '深夜', from: 23, sample: '23:40' }
];
const SLOT_BY_KEY = Object.fromEntries(SCHEDULE.map((s) => [s.key, s]));

let cfg = () => ({});
let log = () => {};
let warn = () => {};

// 内存态：懒加载一次，此后以此为准
let state = { version: STATE_VERSION, days: {}, told: { day: '', count: 0 }, warnedKey: '' };
let stateLoaded = false;

// ── 落盘 ──────────────────────────────────────────────────────────────────
function statePath() { return path.join(DATA_DIR, ID, 'state.json'); }

function loadState() {
  if (stateLoaded) return;
  stateLoaded = true;
  try {
    const raw = JSON.parse(fs.readFileSync(statePath(), 'utf8'));
    if (raw && typeof raw === 'object') {
      const days = {};
      if (raw.days && typeof raw.days === 'object') {
        for (const [day, rec] of Object.entries(raw.days)) {
          if (!/^\d{4}-\d{2}-\d{2}$/.test(String(day))) continue;
          const events = Array.isArray(rec?.events) ? rec.events : [];
          const clean = events
            .map((e) => ({
              text: String(e?.text ?? '').slice(0, MAX_EVENT_CHARS),
              slot: SLOT_BY_KEY[e?.slot] ? e.slot : 'zao',
              at: /^\d{2}:\d{2}$/.test(String(e?.at ?? '')) ? String(e.at) : SLOT_BY_KEY.zao.sample,
              told: e?.told === true
            }))
            .filter((e) => e.text)
            .slice(0, MAX_EVENTS_PER_DAY);
          days[day] = { date: String(day), events: clean };
        }
      }
      state = {
        version: STATE_VERSION,
        days,
        told: {
          day: String(raw.told?.day ?? ''),
          count: Math.max(0, Number(raw.told?.count) || 0)
        },
        warnedKey: String(raw.warnedKey || '')
      };
    }
  } catch { /* 首次运行没有这个文件，属正常 */ }
}

function saveState() {
  try {
    const file = statePath();
    fs.mkdirSync(path.dirname(file), { recursive: true });
    const tmp = `${file}.${process.pid}.tmp`;
    fs.writeFileSync(tmp, JSON.stringify(state, null, 1), 'utf8');
    fs.renameSync(tmp, file);   // 原子替换：断电/崩溃不会留下半个 JSON
  } catch (e) { warn(`日常落盘失败：${e?.message ?? e}`); }
}

// ── 时间 ──────────────────────────────────────────────────────────────────
const pad = (n) => String(n).padStart(2, '0');

/** 本地日期。⚠️ 不能用 toISOString（UTC 会把北京时间的凌晨算成前一天）。 */
function localDay(d = new Date()) {
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
}

function hm(d = new Date()) { return `${pad(d.getHours())}:${pad(d.getMinutes())}`; }

function weekdayLabel(d = new Date()) { return `周${'日一二三四五六'[d.getDay()]}`; }

/** 当前时段（返回 SCHEDULE 里的一项）。 */
function slotOf(d = new Date()) {
  const h = d.getHours();
  if (h >= 23 || h < 5) return SLOT_BY_KEY.shenye;
  for (let i = SCHEDULE.length - 1; i >= 0; i -= 1) {
    if (SCHEDULE[i].key === 'shenye') continue;
    if (h >= SCHEDULE[i].from) return SCHEDULE[i];
  }
  return SLOT_BY_KEY.zao;
}

const slotLabel = (key) => SLOT_BY_KEY[key]?.label || key || '';

/**
 * 今天"已经过完但什么都没记"的时段。
 * 规则：凌晨 5 点前返回空 —— 那时候"今天"才刚开始（深夜属于新的一天），
 * 不能反过来要求她补记一整个还没过的白天。
 */
function emptyPassedSlots(day, now = new Date()) {
  const h = now.getHours();
  if (h < 5) return [];
  const cur = slotOf(now);
  const used = new Set((state.days[day]?.events || []).map((e) => e.slot));
  return SCHEDULE.filter((s) => s.key !== 'shenye' && s.key !== cur.key && s.from <= h && !used.has(s.key));
}

/** 只保留最近 N 天，避免 state.json 无限增长。 */
function pruneDays(now, historyDays) {
  const keys = Object.keys(state.days).sort();
  const keep = Math.max(3, Math.min(365, Number(historyDays) || DEFAULT_HISTORY_DAYS));
  if (keys.length <= keep) return 0;
  const drop = keys.slice(0, keys.length - keep);
  for (const k of drop) delete state.days[k];
  return drop.length;
}

// ── 设置 ──────────────────────────────────────────────────────────────────
function settings() {
  const c = cfg() || {};
  const shares = Number(c.maxSharesPerDay);
  return {
    maxShares: Number.isFinite(shares) ? Math.max(0, Math.min(8, Math.round(shares))) : DEFAULT_MAX_SHARES,
    historyDays: Math.max(3, Math.min(365, Math.round(Number(c.historyDays) || DEFAULT_HISTORY_DAYS))),
    profile: String(c.profile ?? '').trim().slice(0, MAX_PROFILE_CHARS),
    avoid: String(c.avoid ?? '').trim().slice(0, MAX_PROFILE_CHARS)
  };
}

// ── 记录读写 ──────────────────────────────────────────────────────────────
function dayRecord(day) {
  if (!state.days[day] || typeof state.days[day] !== 'object') {
    state.days[day] = { date: day, events: [] };
  }
  if (!Array.isArray(state.days[day].events)) state.days[day].events = [];
  return state.days[day];
}

/** 把一段文本拆成多条：换行 / 分号 / 竖线分隔，模型传数组也认。 */
function splitEvents(value) {
  const list = Array.isArray(value) ? value : [value];
  const out = [];
  for (const item of list) {
    for (const part of String(item ?? '').split(/[\n\r;；|]+/)) {
      const text = part.replace(/\s+/g, ' ').trim().slice(0, MAX_EVENT_CHARS);
      if (text) out.push(text);
    }
  }
  return out;
}

/**
 * 模型常常自己把时刻写在开头（"12:40 楼下麻辣烫"）。那就用它当落盘时刻，
 * 并把前缀去掉 —— 时间线本来就会显示时刻，留着会变成
 * 「13:03［中午］12:40 楼下麻辣烫」，一眼就是机器记的。
 * 解析不出来（没写 / 写了非法时刻 / 去掉后没内容）就原样返回。
 */
function extractLeadingTime(text) {
  const s = String(text ?? '');
  const m = s.match(/^(\d{1,2})[:：](\d{2})\s*/);
  if (!m) return { text: s, at: '' };
  const h = Number(m[1]);
  const mi = Number(m[2]);
  if (h > 23 || mi > 59) return { text: s, at: '' };
  const rest = s.slice(m[0].length).trim();
  if (!rest) return { text: s, at: '' };
  return { text: rest, at: `${pad(h)}:${pad(mi)}` };
}

/** 追加若干条日常。返回真正新增的条目。 */
function addEvents(texts, slotKey, now = new Date()) {
  const day = localDay(now);
  const rec = dayRecord(day);
  const slot = SLOT_BY_KEY[slotKey] || slotOf(now);
  const added = [];
  for (const rawText of texts) {
    const parsed = extractLeadingTime(rawText);
    const text = parsed.text;
    if (!text) continue;
    if (rec.events.length >= MAX_EVENTS_PER_DAY) break;
    if (rec.events.some((e) => e.text === text)) continue;   // 同一条不重复记
    // 时刻优先级：模型自己写的 > 当前时段用当前时刻 > 补记过去时段用该时段默认时刻
    const at = parsed.at || (slot.key === slotOf(now).key ? hm(now) : slot.sample);
    const ev = { text, slot: slot.key, at, told: false };
    rec.events.push(ev);
    added.push(ev);
  }
  return { day, rec, added };
}

function toldCount(day) {
  return state.told?.day === day ? Math.max(0, Number(state.told.count) || 0) : 0;
}

function setToldCount(day, count) {
  state.told = { day, count: Math.max(0, Number(count) || 0) };
}

/** 时间线文本。told 的条目标注"已提过"，模型据此避免重复念叨。 */
function renderTimeline(rec) {
  if (!rec?.events?.length) return '（还什么都没记）';
  return rec.events
    .map((e) => ` · ${e.at}［${slotLabel(e.slot)}］${e.text}${e.told ? '（已经跟人提过）' : ''}`)
    .join('\n');
}

/** action=today 的返回：模型看的就是这一段。 */
function todayText(now = new Date()) {
  const st = settings();
  const day = localDay(now);
  const rec = state.days[day] || { date: day, events: [] };
  const cur = slotOf(now);
  const untold = rec.events.filter((e) => !e.told);
  const left = Math.max(0, st.maxShares - toldCount(day));
  const L = [];
  L.push(`【她的今天】${day}（${weekdayLabel(now)}）· 现在是${cur.label}`);
  if (st.profile) L.push(`生活底子：${st.profile}`);
  if (st.avoid) L.push(`不写进日常的内容：${st.avoid}`);

  if (!rec.events.length) {
    L.push('今天还是一张白纸。这是空白的一天，需要你先想清楚今天怎么过：');
    L.push('① 先按你的设定和现在的时间点，在脑子里把今天已经过去的时段过一遍（吃了什么、在做什么、碰到什么小事），');
    L.push('② 用 action=record 记下 2~3 条（当成已经发生的事写），');
    L.push('③ 然后再照常回答/说话。不要凭空现编一个跟记录对不上的版本。');
  } else {
    L.push('今天已经记下的：');
    L.push(renderTimeline(rec));
  }

  const empty = emptyPassedSlots(day, now);
  if (empty.length) {
    L.push(`已经过完但还空着的时段：${empty.map((s) => s.label).join('、')}`
      + ' —— 要么顺手补一件小事，要么就是你确实没干什么（在忙/在睡/懒得动），别硬编。');
  }
  if (rec.events.length) {
    L.push(`还没跟人提过的：${untold.length} 条${untold.length ? `（${untold.map((e) => e.text.slice(0, 18)).join('／')}）` : ''}`);
    L.push(`今天还能主动提日常的次数：${left} 次`);
  }
  return L.join('\n');
}

/** action=recall 的返回：前 N 天。 */
function recallText(days, now = new Date()) {
  const n = Math.max(1, Math.min(30, Math.round(Number(days) || 3)));
  const today = localDay(now);
  const keys = Object.keys(state.days).filter((k) => k < today).sort().reverse().slice(0, n);
  if (!keys.length) return `前几天没有任何记录（今天用 action=today 看）。`;
  const L = [`【前几天的她】（今天 ${today}，以下不含今天）`];
  for (const k of keys) {
    const d = new Date(`${k}T12:00:00`);
    L.push(`${k}（${Number.isNaN(d.getTime()) ? '' : weekdayLabel(d)}）`);
    L.push(renderTimeline(state.days[k]));
  }
  return L.join('\n');
}

// ── 工具 ──────────────────────────────────────────────────────────────────
const fail = (message) => ({ content: `错误：${message}`, isError: true });

export function setup(api) {
  cfg = typeof api.config === 'function' ? api.config : () => ({});
  log = (...a) => api.log?.(...a);
  warn = (...a) => api.warn?.(...a);
  loadState();

  api.registerTool({
    id: 'life',                      // 注册后实际是 daily-life__life
    name: '她的日常',
    description: '你自己的日子（时间线）：今天吃了什么、干了什么、遇到什么好事或糟心事。'
      + '数据是连续的 —— 记下来的会一直算数，跨天、跨重启都在，所以你对"今天"的说法必须跟它一致。'
      + '什么时候用：① 别人问你的今天（在干嘛／吃了吗／今天怎么样／最近有什么好事／怎么没精神）→ action=today 先看一眼再随口答；'
      + '② 你想主动说一件今天的事（聊到吃、累、烦心事，或群里冷场要起话题）→ 先 action=share 取一条还没跟人提过的，再自然说出去；'
      + '③ 有新的事发生（尤其"刚刚"发生的）→ action=record 追加；'
      + '④ 别人问前几天的事 → action=recall；'
      + '⑤ 群友给你补了新设定（工作、城市、作息、宠物）→ action=background。'
      + '铁律：不要把工具名、action 名、"已记录"、"额度"这些说出来，它们只是你心里的备忘；'
      + '日常是给聊天增味的，不是话题中心，别人没问、话题不搭就别硬提，同一件事不要反复讲。',
    category: 'system',
    icon: '🌤️',
    defaultEnabled: true,
    parameters: {
      type: 'object',
      properties: {
        action: {
          type: 'string',
          enum: ['today', 'record', 'share', 'recall', 'background'],
          description: 'today=看今天（默认）；record=把今天新发生的事记下来；share=取一条还没跟人提过的今天的事，用于主动开口；recall=回看前几天；background=查看或追加长期生活底子'
        },
        events: {
          type: 'string',
          description: '仅 action=record：要记的事，一条一行或分号分隔（如「12:40 楼下麻辣烫，加双份丸子，吃撑了；下午被甲方改需求，烦」）。写具体：在哪、跟谁、什么味道、花了多少'
        },
        slot: {
          type: 'string',
          enum: ['zao', 'shangwu', 'zhongwu', 'xiawu', 'wan', 'shenye'],
          description: '仅 action=record：这条事属于哪个时段（zao早上/shangwu上午/zhongwu中午/xiawu下午/wan晚上/shenye深夜）。补记过去的事就填那个时段，不填=当前时段'
        },
        days: {
          type: 'number',
          description: '仅 action=recall：往前回看几天，默认 3，最大 30'
        },
        text: {
          type: 'string',
          description: '仅 action=background：要补充的长期设定（职业／城市／作息／宠物等）。不传=查看当前底子'
        }
      },
      required: ['action']
    },
    async execute(ctx, args = {}) {
      try {
        loadState();
        const now = new Date();
        const st = settings();
        const action = String(args?.action || 'today').trim().toLowerCase();

        if (action === 'today') {
          if (pruneDays(now, st.historyDays)) saveState();
          return { content: todayText(now) };
        }

        if (action === 'record') {
          const texts = splitEvents(args?.events ?? args?.event ?? args?.text);
          if (!texts.length) return fail('没有拿到内容：把要记的事放进 events，多条用换行或分号分隔。');
          const { day, rec, added } = addEvents(texts, String(args?.slot || ''), now);
          if (!added.length) {
            return { content: `没有新增：内容为空，或者和今天已有的记录重复了。\n今天现在是这样：\n${renderTimeline(rec)}` };
          }
          pruneDays(now, st.historyDays);
          saveState();
          return {
            content: `已记下 ${added.length} 条（${day}）：\n${added.map((e) => ` · ${e.at}［${slotLabel(e.slot)}］${e.text}`).join('\n')}`
              + `\n今天现在是：\n${renderTimeline(rec)}\n（这些不用念给群里听，是你自己的日子。）`
          };
        }

        if (action === 'share') {
          const day = localDay(now);
          const rec = state.days[day];
          if (!rec?.events?.length) {
            return { content: '今天还没有任何记录，没东西可提。先用 action=record 把今天已经发生的事记 2~3 条，再考虑要不要开口。' };
          }
          const untold = rec.events.filter((e) => !e.told);
          if (!untold.length) {
            return { content: `今天记下的 ${rec.events.length} 件事都已经跟人提过了，别再重复讲 —— 这次就好好听别人说，或者记一件刚刚新发生的事。` };
          }
          const used = toldCount(day);
          if (used >= st.maxShares) {
            return { content: `今天主动提日常的额度已经用完了（每天 ${st.maxShares} 次，可以在「她的日常」设置里调）。这次别主动往自己身上带；别人直接问你今天怎么样，还是照常回答。` };
          }
          // 优先挑"当下这个时段"的事，否则挑最近记下的一件
          const cur = slotOf(now).key;
          const pick = [...untold].reverse().find((e) => e.slot === cur) || untold[untold.length - 1];
          pick.told = true;
          setToldCount(day, used + 1);
          saveState();
          return {
            content: `这次可以说的事（已经发生过的，细节别改）：${pick.at}［${slotLabel(pick.slot)}］${pick.text}\n`
              + '用你自己的语气随口带出来（一两句就够），别报幕、别说「我跟你说个事」、别说这是记录里的。'
              + `\n今天主动提的额度还剩 ${Math.max(0, st.maxShares - used - 1)} 次。`
          };
        }

        if (action === 'recall') {
          return { content: recallText(args?.days, now) };
        }

        if (action === 'background') {
          const text = args?.text ?? args?.profile;
          if (text === undefined || text === null || String(text).trim() === '') {
            return {
              content: st.profile
                ? `目前的生活底子：${st.profile}\n（要补充就传 text，会追加在后面。）`
                : '还没有设置生活底子（职业／城市／作息／宠物等都没有）：你现在的日子完全跟着人设走。要补就传 text。'
            };
          }
          const merged = [st.profile, String(text).replace(/\s+/g, ' ').trim()]
            .filter(Boolean).join('；').slice(0, MAX_PROFILE_CHARS);
          setSkillConfig(ID, { profile: merged });
          return { content: `记下了，以后一直算数。现在的生活底子：${merged}` };
        }

        return fail(`不认识的 action「${args?.action}」，只能是 today / record / share / recall / background。`);
      } catch (error) {
        warn(`日常工具出错：${error?.message ?? error}`);
        return fail(`处理时出错：${error?.message ?? error}`);
      }
    }
  });

  loadState();
  const st = settings();
  const now = new Date();
  const rec = state.days[localDay(now)];
  log(`已加载：她的日常（${st.profile ? `底子「${st.profile.slice(0, 30)}」` : '跟随人设，未设生活底子'}，`
    + `每天最多主动提 ${st.maxShares} 次，历史保留 ${st.historyDays} 天）`
    + `｜今天${rec?.events?.length ? `已记 ${rec.events.length} 条` : '还是白纸'}`);
}

// 没有外部依赖，永远可用；绝不能因为"今天还没记录"就报不可用 —— 那样工具会被
// 隐藏，模型连记都没法记（那就成了文档里说的静默失效）。
export function available() { return { ok: true }; }

export function activate() { loadState(); log('已激活'); }

// 本技能没有定时器/监听器，禁用时不需要清理资源；留着这两个钩子是为了让
// 生命周期语义完整（将来若加了定时器，一定要在这里清掉）。
export function deactivate() { log('已停用'); }

export function dispose() { /* 无资源可回收 */ }

/**
 * 动态提示词片段：把"今天的事实"每轮喂给模型。
 *
 * 这是本技能最关键的一半 —— 没有它，模型每次开口都会现编一个"今天"，
 * 时间线就永远对不上（同一个下午能吃三顿午饭）。
 *
 * ⚠️ priority 必须**低于**静态片段（静态是 55）：动态内容每轮都变，排到所有
 *    静态片段之后才不会把核心提示词/静态片段的字节位置推来推去，
 *    系统提示词的前缀缓存才保得住（见 prompt.js buildSystemPrompt 的注释）。
 */
export function promptSections(context = {}) {
  try {
    loadState();
    const now = new Date();
    const st = settings();
    const day = localDay(now);
    const rec = state.days[day];
    const cur = slotOf(now);
    const L = [];

    L.push(`【你的今天】${day}（${weekdayLabel(now)}）· 现在是${cur.label}`
      + `${context?.proactive ? '　（这次是你自己冒泡／群里冷场，可以拿今天的一件小事当话题）' : ''}`);
    if (st.profile) L.push(`生活底子（长期不变）：${st.profile}`);
    if (st.avoid) L.push(`这些不要写进你的日常：${st.avoid}`);

    if (rec?.events?.length) {
      L.push('今天已经发生的：');
      // 只带最近 12 条：早期条目模型已经看过，全量重复注入会白烧 token
      for (const e of rec.events.slice(-12)) {
        L.push(` · ${e.at}［${slotLabel(e.slot)}］${e.text}${e.told ? '（已经跟人提过）' : ''}`);
      }
      const untold = rec.events.filter((e) => !e.told).length;
      const left = Math.max(0, st.maxShares - toldCount(day));
      L.push(`还没跟人提过 ${untold} 条；今天主动提日常的额度还剩 ${left} 次（别人问你就不受这个限制）。`);
    } else {
      L.push('今天还没安排 —— 这是空白的一天。先在脑子里把今天怎么过定下来'
        + '（当成已经发生的事：吃了什么、在忙什么、碰到什么好事或糟心事），'
        + '用 daily-life__life（action=record）记 2~3 条，之后就一直用这份记录，别再改来改去。');
    }

    const empty = emptyPassedSlots(day, now);
    if (empty.length) {
      L.push(`已经过完但还空着的时段：${empty.map((s) => s.label).join('、')} —— 顺手补一件小事，或者确实没干什么就别硬编。`);
    }
    L.push('（这段是你自己的备忘，不要念出来、也不要提到"记录"二字。）');

    return [{
      id: 'daily-life-today',
      title: '她的今天',
      content: L.join('\n'),
      priority: 20
    }];
  } catch (error) {
    warn(`生成日常片段失败：${error?.message ?? error}`);
    return [];
  }
}

// 内部函数暴露给离线测试用（不对外提供能力，别依赖）
export const internals = {
  SCHEDULE, localDay, hm, weekdayLabel, slotOf, slotLabel, emptyPassedSlots, pruneDays,
  settings, dayRecord, splitEvents, addEvents, renderTimeline, todayText, recallText,
  extractLeadingTime,
  getState: () => state,
  setState: (patch) => { state = { ...state, ...(patch || {}) }; },
  resetLoaded: () => { stateLoaded = false; },
  statePath
};
