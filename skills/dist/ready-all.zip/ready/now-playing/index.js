// 听你在放什么（now-playing）
//
// 「听到音乐」在这台电脑上最靠谱的做法不是录声音，而是问 Windows：
// 支持「媒体会话」（SMTC）的播放器会把歌名/歌手/进度报给系统，
// Biu、网易云、QQ音乐、Spotify、浏览器标签页基本都是这条路。
// 读不到时再退回播放器窗口标题（有些播放器只在标题栏写「歌名 - 歌手」）。
//
// 为什么是技能：什么时候该查、查到之后怎么自然地说，得靠模型判断。

import { execFile } from 'node:child_process';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

const appRoot = globalThis.__qqAgentRoot
  || path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../..');
const { getSkillConfig } = await import(pathToFileURL(path.join(appRoot, 'src/skills/config.js')).href);

const ID = 'now-playing';
const DEFAULTS = { includePaused: true, cacheSeconds: 10, windowFallback: true, extraPlayers: '' };

// 内置认得的播放器进程名（窗口标题兜底、以及设置里的过滤用）
const DEFAULT_PLAYERS = [
  'biu', 'cloudmusic', 'qqmusic', 'spotify', 'foobar2000', 'potplayer', 'vlc', 'mpv',
  'musicbee', 'aimp', 'aplayer', 'yesplaymusic', 'kugou', 'kuwo', 'netease', 'soda'
];

// PowerShell 5.1 + WinRT：拿所有媒体会话 + 所有窗口标题，一次性吐 JSON。
// 注意：脚本里不要出现反引号和 ${，避免和 JS 模板字符串打架。
const PS_SCRIPT = `[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$ErrorActionPreference = 'Continue'
$result = @{ ok = $true; sessions = @(); windows = @(); error = '' }
try {
  Add-Type -AssemblyName System.Runtime.WindowsRuntime
  $asTask = ([System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object {
    $_.Name -eq 'AsTask' -and $_.GetParameters().Count -eq 1 -and $_.GetParameters()[0].ParameterType.Name -like 'IAsyncOperation*'
  })[0]
  function Await($WinRtTask, $ResultType) {
    $asTaskGeneric = $asTask.MakeGenericMethod($ResultType)
    $netTask = $asTaskGeneric.Invoke($null, @($WinRtTask))
    $netTask.Wait(-1) | Out-Null
    $netTask.Result
  }
  [Windows.Media.Control.GlobalSystemMediaTransportControlsSessionManager, Windows.Media.Control, ContentType = WindowsRuntime] | Out-Null
  $mgr = Await ([Windows.Media.Control.GlobalSystemMediaTransportControlsSessionManager]::RequestAsync()) ([Windows.Media.Control.GlobalSystemMediaTransportControlsSessionManager])
  $items = @()
  foreach ($s in $mgr.GetSessions()) {
    $props = $null
    try { $props = Await ($s.TryGetMediaPropertiesAsync()) ([Windows.Media.Control.GlobalSystemMediaTransportControlsSessionMediaProperties]) } catch { }
    $info = $null
    try { $info = $s.GetPlaybackInfo() } catch { }
    $pos = 0
    $dur = 0
    try {
      $tl = $s.GetTimelineProperties()
      $pos = [int]$tl.Position.TotalSeconds
      $dur = [int]$tl.EndTime.TotalSeconds
    } catch { }
    $items += [pscustomobject]@{
      app = [string]$s.SourceAppUserModelId
      status = if ($info) { [string]$info.PlaybackStatus } else { '' }
      title = if ($props) { [string]$props.Title } else { '' }
      artist = if ($props) { [string]$props.Artist } else { '' }
      album = if ($props) { [string]$props.AlbumTitle } else { '' }
      position = $pos
      duration = $dur
    }
  }
  $result.sessions = $items
} catch {
  $result.ok = $false
  $result.error = [string]$_.Exception.Message
}
try {
  $result.windows = @(Get-Process | Where-Object { $_.MainWindowTitle } | ForEach-Object {
    [pscustomobject]@{ process = [string]$_.ProcessName; title = [string]$_.MainWindowTitle }
  })
} catch { }
$result | ConvertTo-Json -Depth 5 -Compress`;

function settings() {
  try { return getSkillConfig(ID, DEFAULTS); } catch { return { ...DEFAULTS }; }
}

const num = (v, fallback, min, max) => {
  const n = Number(v);
  return Number.isFinite(n) ? Math.max(min, Math.min(max, n)) : fallback;
};

function splitNames(raw) {
  return String(raw ?? '')
    .split(/[,，;；\n]+/)
    .map((s) => s.trim().toLowerCase())
    .filter(Boolean)
    .slice(0, 20);
}

function runPs() {
  return new Promise((resolve, reject) => {
    const b64 = Buffer.from(PS_SCRIPT, 'utf16le').toString('base64');
    execFile(
      'powershell.exe',
      ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-EncodedCommand', b64],
      { timeout: 8000, windowsHide: true, maxBuffer: 2 * 1024 * 1024 },
      (error, stdout) => {
        if (error) return reject(error);
        resolve(String(stdout || ''));
      }
    );
  });
}

let cache = { at: 0, data: null };

async function query({ refresh = false } = {}) {
  const ttl = num(settings().cacheSeconds, 10, 0, 600) * 1000;
  if (!refresh && cache.data && Date.now() - cache.at < ttl) return cache.data;
  const raw = await runPs();
  let data;
  try {
    const trimmed = raw.trim().replace(/^\uFEFF/, '');
    data = JSON.parse(trimmed.slice(trimmed.indexOf('{')));
  } catch (error) {
    throw new Error(`读不到 Windows 的播放信息（返回内容无法解析）：${String(raw).slice(0, 120)}`);
  }
  cache = { at: Date.now(), data };
  return data;
}

const lower = (v) => String(v ?? '').toLowerCase();

/** 「歌名 - 歌手」这种窗口标题里尽量拆出两段；顺手去掉「正在播放：」前缀和末尾的应用名。 */
function splitTitle(raw, appName = '') {
  const text = String(raw || '').trim().replace(/^(正在播放|正在收听|now playing)\s*[:：]\s*/i, '');
  const parts = text.split(/\s+[-–—|]\s+/).map((s) => s.trim()).filter(Boolean);
  if (parts.length >= 2) {
    if (parts.length > 2) {
      const last = lower(parts[parts.length - 1]);
      if ((appName && last.includes(lower(appName))) || /^(biu|biu音乐|音乐|music|player|播放器)$/.test(last)) parts.pop();
    }
    return { title: parts[0], artist: parts.slice(1).join(' / ') };
  }
  return { title: text, artist: '' };
}

/** 标题只是应用名 / 太短，说明它压根没在标题里写歌名。 */
function usableTitle(title, process) {
  const t = String(title || '').trim();
  if (t.length < 2) return false;
  const norm = t.toLowerCase();
  return !(norm === lower(process) || /^(biu|biu音乐|音乐|music|player|播放器)$/.test(norm));
}

/**
 * 从一次查询结果里挑出"最像正在播放"的那首。
 * 优先 Playing，其次 Paused（是否算暂停由设置决定），最后才用窗口标题兜底。
 * 导出出来是为了能单独测，不依赖真的在放歌。
 */
export function pickTrack(data, opts = {}) {
  const includePaused = opts.includePaused !== false;
  const players = Array.isArray(opts.players) && opts.players.length ? opts.players : DEFAULT_PLAYERS;
  const appFilter = lower(opts.appFilter || '');
  const rank = (s) => (s.status === 'Playing' ? 3 : s.status === 'Paused' ? 2 : 1);
  const hit = (v) => !appFilter || lower(v).includes(appFilter);

  let sessions = (Array.isArray(data?.sessions) ? data.sessions : [])
    .filter((s) => String(s?.title || '').trim());
  if (!includePaused) sessions = sessions.filter((s) => s.status === 'Playing');
  if (appFilter) sessions = sessions.filter((s) => hit(s.app) || hit(s.title) || hit(s.artist));
  sessions.sort((a, b) => rank(b) - rank(a));

  if (sessions.length) {
    const s = sessions[0];
    return {
      found: true,
      source: 'smtc',
      app: s.app,
      status: s.status || 'Unknown',
      title: String(s.title).slice(0, 120),
      artist: String(s.artist || '').slice(0, 80),
      album: String(s.album || '').slice(0, 80),
      position: Number(s.position) || 0,
      duration: Number(s.duration) || 0,
      others: sessions.slice(1, 6).map((x) => ({ app: x.app, title: x.title, artist: x.artist }))
    };
  }

  if (opts.windowFallback === false) return { found: false, reason: '没有正在播放的媒体会话' };

  const windows = (Array.isArray(data?.windows) ? data.windows : []).filter((w) => String(w?.title || '').trim());
  const known = (name) => players.some((p) => lower(name).includes(p));
  // 用户点名了某个应用（比如 biu）时，就只在这个应用里找
  const candidates = windows.filter((w) => (appFilter ? hit(w.process) || hit(w.title) : known(w.process)));
  const parsedList = candidates
    .map((w) => ({ w, p: splitTitle(w.title, w.process) }))
    .filter((x) => usableTitle(x.p.title, x.w.process));
  if (!parsedList.length) {
    return {
      found: false,
      reason: appFilter
        ? `没找到「${opts.appFilter}」的播放信息（既没有媒体会话，也没有能读出歌名的窗口标题）`
        : '没有检测到正在播放的音乐（播放器可能没向 Windows 报告，窗口标题里也没有歌名）'
    };
  }
  const { w, p: parsed } = parsedList[0];
  return {
    found: true,
    source: 'window',
    app: w.process,
    status: 'Unknown',
    title: parsed.title.slice(0, 120),
    artist: parsed.artist.slice(0, 80),
    album: '',
    raw: String(w.title).slice(0, 160),
    note: '这来自播放器窗口标题，可能只是界面文字，不一定精确'
  };
}

export function setup(api) {
  api.log?.(`「在听什么」已加载：读 Windows 媒体会话，读不到时用窗口标题兜底`);

  api.registerTool({
    id: 'now_playing',
    name: '查看正在播放的音乐',
    description: '查看这台电脑上正在播放什么（歌名、歌手、进度）。用户问「你在听什么 / 放的什么歌」或聊到音乐时用它；也可以指定 app 只看某个播放器（例如 biu）。拿不到就如实说拿不到，不要编。',
    category: 'media',
    icon: '🎧',
    parameters: {
      type: 'object',
      properties: {
        app: { type: 'string', description: '可选：只看某个播放器，填应用名或进程名的一部分，例如 biu、cloudmusic、spotify' },
        refresh: { type: 'boolean', description: '可选：忽略缓存，立刻重新读一次（用户说「刚换了歌」时用）' }
      },
      additionalProperties: false
    },
    execute: async (ctx, args = {}) => {
      const s = settings();
      const players = [...DEFAULT_PLAYERS, ...splitNames(s.extraPlayers)];
      try {
        const data = await query({ refresh: args.refresh === true });
        if (data && data.ok === false) {
          return { content: JSON.stringify({ ok: false, error: `系统媒体接口报错：${data.error || '未知原因'}` }), isError: true };
        }
        const track = pickTrack(data, {
          includePaused: s.includePaused !== false,
          windowFallback: s.windowFallback !== false,
          players,
          appFilter: String(args.app || '').trim()
        });
        return { content: JSON.stringify({ ok: true, ...track }) };
      } catch (error) {
        return {
          content: JSON.stringify({ ok: false, error: `查不到：${error?.message ?? error}。可以告诉用户「这会儿没读到正在播放的歌」。` }),
          isError: true
        };
      }
    }
  });
}
