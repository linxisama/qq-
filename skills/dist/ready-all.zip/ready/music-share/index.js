// music-share —— 群内随机点歌（网易云歌单）
//
// 场景：群友 @ 机器人，并在**同一条消息**里写上点歌指令（默认「/放歌」），
//      机器人从管理员指定的网易云歌单里随机抽一首，把歌分享到当前群。
//
// ── 为什么是「技能」（skills/）而不是「插件」（plugins/）──────────────────
// 判断依据不是"规则简不简单"，而是"这段代码由谁叫起来、又靠什么把消息发出去"：
//   · plugins/ 的模块只能提供 providers（能力）或 hooks（钩子）。本版本核心
//     **没有"收到新消息"的钩子** —— 放进 plugins/ 不会被任何代码调用，
//     只会静默失效（加载器本身也会告警"在 plugins/ 却没有提供能力或钩子"）。
//   · 这个功能要"发消息"，而安全的发送入口只在**工具上下文**里（ctx.sender，
//     带限频/去重/留档）。钩子的 payload 里没有 sender，绕过去直接调 OneBot
//     会跳过限频与留档 —— sender.js 顶部明令禁止插件这么做。
// 所以它必须是"注册工具 + 提示词规则"的 LLM 型技能：模型看到 @ + 指令时调用工具，
// 工具内部再**自检一遍**（真的被叫、真的有指令）才落发送，避免误触发。
//
// ── 失败时的表现（都往"说人话"的方向设计）────────────────────────────────
//   · 歌单没配 / 歌单不存在 / 网络失败 → 返回错误说明，模型据此如实告诉群友，
//     绝不自己编歌名（编歌名是最难被发现的假成功）。
//   · 音乐卡片不被客户端支持 → 自动退回"文字 + 链接"，链接一定在，分享不会落空。
//   · 返回内容里带 note，明确告诉模型"已经发出去了，别再复述"，避免一次点歌发两遍。

// 网易云歌单接口。三个依次回退：老接口给的字段最全，v6 与 track/all 用于兜底
// （有些歌单在老接口只返回前若干首，v6 能拿到更多）。
const API_ENDPOINTS = (id) => [
  `https://music.163.com/api/playlist/detail?id=${encodeURIComponent(id)}`,
  `https://music.163.com/api/v6/playlist/detail?id=${encodeURIComponent(id)}&n=1000&s=8`,
  `https://music.163.com/api/playlist/track/all?id=${encodeURIComponent(id)}&limit=1000&offset=0`
];

const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36';

// 歌单缓存：同一首歌单 10 分钟内不重复拉（点歌是高频动作，网络每次都走一遍太慢）
const CACHE_TTL_MS = 10 * 60 * 1000;
const playlistCache = new Map();   // playlistId -> { at, name, songs }

// 每个群最近点过的歌（避免连续抽到同一首）+ 冷却时间
const recentByChat = new Map();    // chatKey -> [songId]
const lastSendAt = new Map();      // chatKey -> ts

let cfg = () => ({});
let log = () => {};
let warn = () => {};
let fetchFn = typeof globalThis.fetch === 'function' ? globalThis.fetch : null;

// ── 生命周期 ───────────────────────────────────────────────────────────────

export function setup(api = {}) {
  cfg = typeof api.config === 'function' ? api.config : () => ({});
  log = typeof api.log === 'function' ? api.log : () => {};
  warn = typeof api.warn === 'function' ? api.warn : log;
  // ⚠️ 没有声明 web_fetch 权限时，api.fetch 是一个"一调就 reject"的桩函数。
  //    所以 skill.json 的 permissions 里必须写上 web_fetch，否则这里拿不到真 fetch。
  if (typeof api.fetch === 'function') fetchFn = api.fetch;

  api.registerTool({
    id: 'share_song',
    name: '随机点歌',
    description: '从管理员配置的网易云歌单里随机抽一首歌，分享到当前聊天（音乐卡片 + 歌名，附链接）。'
      + '只在有人 @ 你、并在同一条消息里写了任意一个点歌指令（默认「/放歌」「/来首歌」「/点歌」，实际指令见【群内随机点歌】说明）时调用，一次运行只调一次。'
      + '选哪首歌由工具随机决定，你不需要也不应该自己报歌名；调用成功后这就是最终结果，不要再复述歌名或链接。',
    category: 'media',
    icon: '🎵',
    parameters: { type: 'object', properties: {} },
    async execute(ctx, args) {
      try {
        return await runShare(ctx, args);
      } catch (error) {
        // 任何异常都变成"模型能读懂的错误"，让它如实告诉群友，而不是静默失败
        const message = error?.message ?? String(error);
        try { warn(`点歌失败：${message}`); } catch { /* 日志失败不影响主流程 */ }
        return err(`点歌失败：${message}`);
      }
    }
  });
}

/** 关闭技能时清掉内存里的会话状态（否则热重载后会带着上一份冷却/去重记录）。 */
export function dispose() {
  recentByChat.clear();
  lastSendAt.clear();
  playlistCache.clear();
}

// ── 提示词：每次运行按当前配置动态生成 ─────────────────────────────────────
//
// 用动态片段而不是 manifest 里的静态 prompt，是因为触发指令是**可配置**的：
// 管理员把「/放歌」改成「/来首歌」、或者再加几个，系统提示里的规则必须跟着变，
// 否则模型会继续等一个永远不会出现的指令（表现就是"改了设置但没反应"）。
export function promptSections() {
  const conf = cfg() || {};
  if (conf.enabled === false) return [];
  const commands = commandListOf(conf);
  const commandText = commands.map((c) => `「${c}」`).join('、');
  const requireAt = conf.requireAt !== false;
  const playlistId = playlistIdOf(conf);

  const lines = [];
  lines.push(`- 触发条件：群里有人${requireAt ? ' **@ 你**、并且' : ''}在**同一条消息**里写了下面任意一个点歌指令：${commandText}（全角斜杠、多打空格也算）。命中时就调用 music-share__share_song，一次运行只调一次。`);
  lines.push('- 只有带了上面任意一个指令才算点歌。只是说"放首歌""来点音乐"而没有指令的，按平时那样聊就行，**不要**假装已经放了歌，也不要自己编一首歌名。');
  lines.push('- 不要自己报歌名、不要先说"我去找找"，也不用问"要不要点"：挑哪首由工具随机决定，你说不出来是正常的。');
  lines.push('- 工具发出去的就是最终结果。成功后**不要**再用 send_message 复述歌名或链接，也不要发"已分享"这类汇报；群里已经看到歌了。');
  lines.push('- 如果同一句话里还有别的事（比如"顺便查下天气"），先把点歌发出去，再照常处理别的。');
  if (!playlistId) {
    lines.push('- ⚠️ 管理员还没填网易云歌单：有人点歌时，用一句话说明"还没配歌单，请管理员在技能设置里填一下"，不要编歌名。');
  } else {
    lines.push(`- 管理员已经把歌单配好了（ID ${playlistId}），直接调工具就行。`);
  }
  lines.push('- 工具报错时按错误说明如实回应（例如"刚点过，等一会"），不要假装成功。');
  lines.push('- 如果工具回的是"这次不是点歌"，说明你误判了触发条件：照常聊你的，**不要**跟群友解释工具、指令或规则。');

  return [{
    id: 'music-share',
    title: '群内随机点歌（网易云歌单）',
    priority: 62,
    content: lines.join('\n')
  }];
}

// ── 主流程 ─────────────────────────────────────────────────────────────────

async function runShare(ctx = {}, args = {}) {
  const conf = cfg() || {};
  if (conf.enabled === false) return err('点歌功能已被管理员关闭。');

  const commands = commandListOf(conf);
  const requireAt = conf.requireAt !== false;

  // ① 自检：这次真的是一次"点歌"吗
  //    提示词只是"引导"，这条才是硬校验 —— 模型偶发地在闲聊里调工具时，
  //    这里会把它拦住，避免无缘无故往群里丢一张音乐卡片。
  const gate = checkTrigger(ctx, commands, requireAt);
  if (gate === false) {
    return err(`这次不是点歌：最近的消息里没有找到「${requireAt ? '@我 + ' : ''}${commands.join(' / ')}」里的任意一个。`
      + '不要自己报歌名，等群友真的点歌再调用。');
  }

  // ② 歌单
  const playlistId = playlistIdOf(conf);
  if (!playlistId) {
    return err('管理员还没配置网易云歌单 ID（技能设置里填 playlistId 或歌单链接）。请如实告诉群友还没配歌单，不要编歌名。');
  }

  // ③ 冷却：同一群短时间内只点一次
  const cooldown = Math.max(0, Number(conf.cooldownSeconds) || 0);
  const lastAt = lastSendAt.get(String(ctx.chatKey)) || 0;
  if (cooldown && Date.now() - lastAt < cooldown * 1000) {
    const left = Math.ceil((cooldown * 1000 - (Date.now() - lastAt)) / 1000);
    return err(`这个群刚点过歌，还要等 ${left} 秒。如实说一声"刚点过，等一下"就行，不要自己编一首。`);
  }

  // ④ 取歌单 + 随机挑一首
  const { name: listName, songs } = await loadPlaylist(playlistId, conf);
  if (!songs.length) return err('这个歌单里没有可分享的歌曲（可能是空歌单）。');

  const avoidCount = Math.max(0, Number(conf.avoidRepeatCount) || 0);
  // 歌单很小时（比如自建歌单只有 10 首），"最近 8 首不重复"会把可选范围压到 2 首，
  // 听感上就是"老是那两首"。这里自动缩小到最多一半，保证至少还有一半的歌能随机到。
  const avoidCap = Math.max(0, Math.floor(songs.length / 2));
  const song = pickSong(songs, recentByChat.get(String(ctx.chatKey)) || [], Math.min(avoidCount, avoidCap));
  if (!song) return err('没能从歌单里挑出歌曲，换一首试试。');

  // ⑤ 发送（卡片 → 失败自动退回文字+链接）
  const sent = await shareSong(ctx, song, conf, listName);

  lastSendAt.set(String(ctx.chatKey), Date.now());
  const recent = recentByChat.get(String(ctx.chatKey)) || [];
  recent.push(String(song.id));
  recentByChat.set(String(ctx.chatKey), recent.slice(-40));
  log(`已分享《${song.name}》- ${song.artists || '未知歌手'}（${sent.mode === 'card' ? '音乐卡片' : '文字+链接'}，歌单「${listName || playlistId}」）`);
  if (sent.cardError) {
    log(`音乐卡片发送失败，已退回文字：${sent.cardError}`);
  }

  // 记进会话"已发出"列表，控制台的会话卡片里能看到这条（与内置工具同一口径）
  try {
    ctx.session?.sent?.push?.({ type: 'music', text: `[点歌]《${song.name}》` });
    ctx.emit?.('session-update', ctx.session?.id);
  } catch { /* 只是展示用，失败不影响发送 */ }

  return ok({
    shared: true,
    song: { name: song.name, artists: song.artists, album: song.album, id: song.id },
    playlist: listName || playlistId,
    url: `https://music.163.com/song?id=${song.id}`,
    mode: sent.mode === 'card' ? 'music-card' : 'text',
    note: '已经把这首歌分享到群里了。不要再用 send_message 复述歌名或链接，也不要发"已分享"。'
  });
}

/**
 * 发送一首歌。
 *
 * 为什么走 `ctx.sender.sendMedia` 而不是直接 `ctx.onebot.sendSegments`：
 *   sendMedia 是发"媒体段"的正式入口，带每会话串行、限频、去重、留档。
 *   绕过它会让文字配额被无记录地吃掉，并且下一次运行不知道"自己刚发过"。
 */
async function shareSong(ctx, song, conf, listName) {
  const url = `https://music.163.com/song?id=${song.id}`;
  const line = buildSongLine(song, conf, url);
  const label = `[点歌]《${song.name}》${song.artists ? ` - ${song.artists}` : ''}`;
  const sender = ctx.sender;
  const chatKey = ctx.chatKey;

  if (!sender || (typeof sender.sendMedia !== 'function' && typeof sender.sendTextBatch !== 'function')) {
    throw new Error('发送通道不可用（工具上下文里没有 sender）');
  }

  if (conf.sendAsCard !== false && typeof sender.sendMedia === 'function') {
    try {
      const segments = [
        // OneBot v11 音乐段：type=163 即网易云（QQ 内置卡片模板，不需要签名服务）
        { type: 'music', data: { type: '163', id: String(song.id) } }
      ];
      if (line) segments.push({ type: 'text', data: { text: line } });
      await sender.sendMedia(chatKey, segments, {
        label,
        // 带上时间戳：同一首歌隔一会儿可以再点，不该被"媒体去重"误杀
        dedupeKey: `music:${song.id}:${Date.now()}`
      });
      return { mode: 'card' };
    } catch (error) {
      // 客户端/协议端不支持音乐卡片时走到这里：退回纯文字，分享不能落空
      const text = line.includes(url) ? line : `${line}\n${url}`;
      await sender.sendTextBatch(chatKey, [text], {});
      return { mode: 'text', cardError: error?.message ?? String(error) };
    }
  }

  const text = line.includes(url) ? line : `${line}\n${url}`;
  await sender.sendTextBatch(chatKey, [text], {});
  return { mode: 'text' };
}

// ── 歌单接口 ───────────────────────────────────────────────────────────────

async function loadPlaylist(playlistId, conf = {}) {
  const cached = playlistCache.get(playlistId);
  if (cached && Date.now() - cached.at < CACHE_TTL_MS && cached.songs.length) {
    return { name: cached.name, songs: cached.songs };
  }

  let lastError = null;
  let lastCode = null;
  let bestSongs = [];
  let bestTrackIds = [];
  let name = '';
  let trackCount = 0;

  for (const endpoint of API_ENDPOINTS(playlistId)) {
    try {
      const data = await fetchJson(endpoint, conf);
      const code = Number(data?.code);
      if (Number.isFinite(code) && code !== 200) {
        lastCode = code;
        continue;   // 20001 = 歌单不存在/私密；换下一个接口再试
      }
      const p = data?.result || data?.playlist || {};
      const tracks = data?.result?.tracks || data?.playlist?.tracks || data?.songs || [];
      const songs = normalizeSongs(tracks);
      // trackIds 是**完整**的曲目 id 列表，tracks 常常只是前 10 首 —— 两个都记下来，
      // 谁多信谁（见下面的"按 id 补齐"）。
      const trackIds = Array.isArray(p.trackIds) ? p.trackIds.map((x) => String(x?.id ?? x ?? '')).filter(Boolean) : [];
      const count = Number(p.trackCount) || 0;
      if (p.name) name = String(p.name).trim();
      if (count > trackCount) trackCount = count;
      if (songs.length > bestSongs.length) bestSongs = songs;
      if (trackIds.length > bestTrackIds.length) bestTrackIds = trackIds;
      // 只有"完整 id 列表都拿到详情"才算拿全。⚠️ 不能拿 trackCount 判：未登录时
      // 老接口返回的 trackCount 也是被截断的（实测 370 首的歌单回 trackCount=10），
      // 用它提前 break 会让补齐逻辑永远不触发 —— 这正是"只抽到 10 首"的根因。
      if (bestTrackIds.length && bestSongs.length >= bestTrackIds.length) break;
    } catch (error) {
      lastError = error;
    }
  }

  if (!bestSongs.length && !bestTrackIds.length) {
    const reason = lastCode === 20001 || lastCode === 404
      ? `歌单 ${playlistId} 不存在，或者是私密歌单（私密歌单需要在技能设置里填网易云 Cookie）`
      : (lastError?.message || '未知原因');
    throw new Error(`拉取歌单失败：${reason}`);
  }

  // ── 按 id 补齐（这一版最关键的修正）────────────────────────────────────
  // 网易云对**未登录**请求只回前 10 首曲目详情，但 trackIds 是完整的（实测 370 首的歌单
  // 只回了 10 首）。不补齐的话，随机点歌永远只会从那 10 首里挑 —— 而且完全不报错，
  // 只有管理员自己数才发现"怎么老是这几首"。所以拿 trackIds 去 song/detail 分批取详情。
  let songs = bestSongs;
  if (bestTrackIds.length > songs.length) {
    songs = await fillSongsById(bestTrackIds, songs, conf);
  }
  if (!songs.length) throw new Error(`歌单 ${playlistId} 里没有可分享的歌曲（可能是空歌单）`);

  const missing = Math.max(0, Math.max(trackCount, bestTrackIds.length) - songs.length);
  if (missing > 0) {
    warn(`歌单「${name || playlistId}」应有 ${Math.max(trackCount, bestTrackIds.length)} 首，只取到 ${songs.length} 首（${missing} 首可能已下架/版权受限）`);
  }

  playlistCache.set(playlistId, { at: Date.now(), name, songs });
  log(`歌单已加载：「${name || playlistId}」${songs.length} 首${trackCount ? `（歌单显示共 ${trackCount} 首）` : ''}`);
  return { name, songs };
}

/**
 * 用完整曲目 id 列表补齐歌曲详情（分批，每批 200 个 id）。
 *
 * 只用已知的 songs 打底：补不到的歌（下架/版权受限）直接跳过，不影响其它歌。
 * 任何一批失败都只记日志、返回已拿到的部分 —— 少几首不影响点歌，整单失败才是事故。
 */
async function fillSongsById(trackIds, knownSongs = [], conf = {}) {
  const byId = new Map(knownSongs.map((s) => [String(s.id), s]));
  const missing = trackIds.filter((id) => !byId.has(id));
  const CHUNK = 200;
  for (let i = 0; i < missing.length; i += CHUNK) {
    const chunk = missing.slice(i, i + CHUNK);
    const url = `https://music.163.com/api/song/detail?ids=${encodeURIComponent(JSON.stringify(chunk))}`;
    try {
      const data = await fetchJson(url, conf);
      for (const song of normalizeSongs(data?.songs || [])) byId.set(String(song.id), song);
    } catch (error) {
      warn(`补全歌曲详情失败（第 ${Math.floor(i / CHUNK) + 1} 批，${chunk.length} 首）：${error?.message ?? error}`);
    }
  }
  // 按歌单顺序输出，取不到详情的 id 跳过
  return trackIds.map((id) => byId.get(String(id))).filter(Boolean);
}

async function fetchJson(url, conf = {}) {
  if (typeof fetchFn !== 'function') throw new Error('当前环境不支持网络请求');
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 15000);
  try {
    const headers = { 'User-Agent': UA, Referer: 'https://music.163.com/' };
    const cookie = String(conf.cookie || '').trim();
    if (cookie) headers.Cookie = cookie;
    const res = await fetchFn(url, { headers, signal: controller.signal });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const text = await res.text();
    try {
      return JSON.parse(text);
    } catch {
      throw new Error('接口返回的不是 JSON（可能被反爬拦截，稍后再试）');
    }
  } catch (error) {
    if (error?.name === 'AbortError') throw new Error('请求网易云超时（15 秒）');
    throw error;
  } finally {
    clearTimeout(timer);
  }
}

/** 把接口返回的曲目归一化成 {id, name, artists, album, duration}，并按 id 去重。 */
export function normalizeSongs(tracks = []) {
  const out = [];
  const seen = new Set();
  for (const t of Array.isArray(tracks) ? tracks : []) {
    const id = String(t?.id ?? '').trim();
    const name = String(t?.name ?? '').trim();
    if (!id || !/^\d+$/.test(id) || !name) continue;
    if (seen.has(id)) continue;
    seen.add(id);
    const artists = Array.isArray(t?.artists)
      ? t.artists.map((a) => String(a?.name ?? '').trim()).filter(Boolean).join('/')
      : String(t?.ar?.[0]?.name ?? '').trim();
    out.push({
      id,
      name,
      artists,
      album: String(t?.album?.name ?? t?.al?.name ?? '').trim(),
      duration: Number(t?.duration ?? t?.dt ?? 0) || 0
    });
  }
  return out;
}

// ── 触发判定 ───────────────────────────────────────────────────────────────

/**
 * 最近的消息里有没有"点歌"。
 *
 * @param {object} ctx  工具上下文
 * @param {string|string[]} command 一个指令或指令列表（任一命中即算）
 * @returns {true|false|null} null = 存档读不到（不拦，交给模型判断）
 *
 * 只看最近 2 分钟、最多 20 条：工具是在这一次运行里被调用的，
 * 触发消息必然就在刚刚；往更早看只会捞到上次的旧指令，变成"幽灵触发"。
 */
export function checkTrigger(ctx = {}, command, requireAt = true) {
  const store = ctx?.store;
  if (!store || typeof store.recent !== 'function') return null;
  let recent = [];
  try {
    recent = store.recent(ctx.chatKey, { limit: 20 }) || [];
  } catch {
    return null;
  }
  if (!recent.length) return null;

  const now = Date.now();
  const WINDOW_MS = 120000;
  for (let i = recent.length - 1; i >= 0; i--) {
    const m = recent[i];
    if (!m || m.self) continue;
    if (now - Number(m.ts || 0) > WINDOW_MS) break;   // 从新往旧扫，越过窗口就不用看了
    if (!matchCommand(m.text, command)) continue;
    if (ctx.kind === 'private') return true;           // 私聊里"跟我说话"等同于 @
    if (!requireAt) return true;
    // atMe 只在真的 @ 了机器人时为 true（以 @ 段的 QQ 号为准，不是文本匹配）；
    // 引用机器人消息也算"在叫它"。
    const calling = m.atMe === true || String(m.reply?.senderId || '') === String(ctx.selfId || '');
    if (calling) return true;
  }
  return false;
}

/**
 * 指令匹配：任一指令命中即算。
 * 忽略空白、把全角斜杠当半角，大小写不敏感（中文不受影响）。
 * command 可以是单个字符串，也可以是数组。
 */
export function matchCommand(text, command) {
  const hay = normalizeCommand(text);
  if (!hay) return false;
  for (const cmd of normalizeCommandList(command)) {
    const needle = normalizeCommand(cmd);
    if (needle.length >= 2 && hay.includes(needle)) return true;
  }
  return false;
}

function normalizeCommand(value) {
  return String(value ?? '')
    .replace(/／/g, '/')
    .replace(/＠/g, '@')
    .replace(/\s+/g, '')
    .toLowerCase();
}

/** 默认指令（管理员把设置清空时回落到它，保证功能不会因为空值彻底失效）。 */
export const DEFAULT_COMMAND = '/放歌';

/**
 * 把设置里的「指令」解析成指令列表。
 *
 * 为什么允许多个：同一个群的人说法不一样（/放歌、来首歌、点歌…），
 * 只认一条时另一批人就会觉得"这功能没反应"。
 *
 * 分隔符：逗号（中英文）、顿号、分号、竖线、空格/换行。
 * ⚠️ 因此指令本身不能带空格 —— 匹配时反正会去掉所有空白，写 "/放歌" 就够了。
 * ⚠️ 单字符指令（比如误填的 "/"）会被丢掉：它会在任何消息里命中。
 */
export function normalizeCommandList(value) {
  const raw = Array.isArray(value)
    ? value.map((v) => String(v ?? ''))
    : String(value ?? '').split(/[\s,，、;；|]+/);
  const out = [];
  const seen = new Set();
  for (const item of raw) {
    const cmd = String(item ?? '').trim();
    if (!cmd) continue;
    const key = normalizeCommand(cmd);
    if (key.length < 2) continue;          // 单字符指令会匹配一切，直接忽略
    if (seen.has(key)) continue;            // "/放歌" 与 "／放歌" 视为同一条
    seen.add(key);
    out.push(cmd);
  }
  return out.length ? out : [DEFAULT_COMMAND];
}

/** 当前生效的点歌指令列表（空值回落到默认的一条）。 */
export function commandListOf(conf = {}) {
  return normalizeCommandList(conf.command);
}

/** 从 ID 或歌单链接里认出歌单 ID（管理员两种都可能会填）。 */
export function playlistIdOf(conf = {}) {
  return parsePlaylistId(conf.playlistUrl) || parsePlaylistId(conf.playlistId);
}

export function parsePlaylistId(raw) {
  const s = String(raw ?? '').trim();
  if (!s) return '';
  if (/^\d{3,}$/.test(s)) return s;
  const byQuery = /[?&#]id=(\d+)/.exec(s);
  if (byQuery) return byQuery[1];
  const byPath = /\/playlist\/(\d+)/.exec(s);
  if (byPath) return byPath[1];
  const anyDigits = /(\d{5,})/.exec(s);
  return anyDigits ? anyDigits[1] : '';
}

/** 随机挑一首：优先避开最近 avoidCount 首；歌单太小时放开限制。 */
export function pickSong(songs = [], recentIds = [], avoidCount = 8) {
  if (!Array.isArray(songs) || !songs.length) return null;
  const n = Math.max(0, Number(avoidCount) || 0);
  const recent = new Set((Array.isArray(recentIds) ? recentIds : []).slice(-n).map(String));
  const pool = n ? songs.filter((s) => !recent.has(String(s.id))) : songs;
  const list = pool.length ? pool : songs;
  return list[Math.floor(Math.random() * list.length)] || null;
}

// ── 文案 ───────────────────────────────────────────────────────────────────

function buildSongLine(song, conf = {}, url = '') {
  const who = song.artists ? ` - ${song.artists}` : '';
  const link = conf.showLink === false ? '' : (url ? `\n${url}` : '');
  return `🎵 随机点到：《${song.name}》${who}${link}`;
}

function ok(payload) {
  return { content: typeof payload === 'string' ? payload : JSON.stringify(payload, null, 1) };
}

function err(message) {
  return { content: `错误：${message}`, isError: true };
}

// 给测试/排障直接驱动纯逻辑用（加载器不消费这个导出）
export const internals = {
  normalizeSongs, checkTrigger, matchCommand, normalizeCommandList, commandListOf,
  playlistIdOf, parsePlaylistId, pickSong, buildSongLine, loadPlaylist, fillSongsById
};
