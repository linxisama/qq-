/**
 * 「模拟器操控」技能（emulator）
 *
 * 给机器人一双能落到安卓模拟器上的手和眼：截屏（模型真的看得见图）、
 * 读控件树（点得准）、点/滑/打字/起应用。底层全走 adb，见 lib/adb.js。
 *
 * 安全边界（**改代码前先读这三条**，它们不是可选的）：
 *  ① 全部工具只在**私聊**生效。群里一律拒绝，且不说"我能操作模拟器" ——
 *     否则等于当众宣布"这台机器人的模拟器可以被人指挥"。
 *  ② 读类工具（截屏/控件树/前台应用）只要求"当前对话对象是主人"，
 *     因为模拟器画面里可能有账号、聊天记录、支付界面，泄一次就收不回。
 *  ③ 写得类工具（点/滑/打字/按键/起应用）在此之上**再查一次**主人身份（软依赖
 *     message.owner-check 能力，装了「主人识别」插件才是硬判据），并且每次调用
 *     都写审计日志：谁、什么时候、点了哪里。出事了要能复盘。
 *
 * 为什么不用 require 硬依赖主人识别：没装那个插件的用户也该能用（只是退化成
 * "配置里的 QQ 号"），软依赖降级比直接不可用更合理。
 */
import { findAdb, ensureDevice, screenshot, shell, windowSize, foregroundApp, uiDump, tap as adbTap, swipe as adbSwipe, keyEvent, inputText, startApp, killAll } from './lib/adb.js';
import { decodePng, encodePng, cropScale, pngSize } from './lib/png.js';
import { summarizeUi, findNode } from './lib/ui.js';

let cfg = () => ({});
let api = null;
let log = () => {};
let warn = () => {};

/** 单人可执行的手势类型（给模型看的一份白名单，写操作只走这几个）。 */
const GESTURES = ['tap', 'swipe', 'key', 'text'];

function num(v, dflt = 0) {
  const n = Number(v);
  return Number.isFinite(n) ? n : dflt;
}

function ownerList(c) {
  const raw = Array.isArray(c.ownerIds) ? c.ownerIds : String(c.ownerIds ?? '').split(/[,\s，、]+/);
  return raw.map((s) => String(s).trim()).filter(Boolean);
}

function chatKeyOf(ctx) {
  return String(ctx?.chatKey ?? '');
}

function selfIdOf(ctx) {
  return String(ctx?.onebot?.selfId ?? ctx?.selfId ?? '');
}

/** 当前这批消息的发言人列表（主人判定用它，不看名字只看号）。 */
function triggerEntriesOf(ctx) {
  if (Array.isArray(ctx?.session?.triggerEntries)) return ctx.session.triggerEntries;
  return [];
}

/**
 * 门禁一：只有私聊能用。
 * 返回 null 表示放行，否则返回给模型的拒绝话术。
 */
function gatePrivate(ctx) {
  const key = chatKeyOf(ctx);
  const kind = String(ctx?.kind ?? '');
  const isPrivate = kind === 'private' || key.startsWith('private:');
  if (!isPrivate) {
    return '这个工具只在私聊里能用，群里不行。';
  }
  return null;
}

/**
 * 门禁二：当前对话对象必须是主人。
 * 有「主人识别」插件就以它为准（唯一判据是 QQ 号），否则读本技能配置的 ownerIds。
 */
function gateOwner(ctx) {
  const entries = triggerEntriesOf(ctx).filter((m) => m && !m.self);
  const selfId = selfIdOf(ctx);
  const key = chatKeyOf(ctx);
  const chatId = String(ctx?.chatId ?? key.replace(/^private:/, ''));

  if (typeof api?.capability === 'function') {
    for (const m of entries) {
      try {
        const r = api.capability('message.owner-check', { userId: String(m.senderId ?? ''), kind: ctx?.kind, triggerEntries: entries, selfId });
        if (r?.isOwner === true) return null;
      } catch { /* 能力坏了就退化成配置判据 */ }
    }
    if (!entries.length) {
      try {
        const r = api.capability('message.owner-check', { userId: chatId, kind: 'private', triggerEntries: [], selfId });
        if (r?.isOwner === true) return null;
      } catch { /* 同上 */ }
    }
  }

  const list = ownerList(cfg());
  if (!list.length) {
    return '这个技能还没设置"主人 QQ 号"，为了安全先不给操作模拟器。请在控制台「技能 → 模拟器操控」里填上你自己的 QQ 号。';
  }
  const ids = new Set([chatId, ...entries.map((m) => String(m?.senderId ?? ''))].filter(Boolean));
  for (const id of ids) if (list.includes(id)) return null;
  return '只有主人能让我操作模拟器。';
}

function chatIdOf(ctx) {
  const key = chatKeyOf(ctx);
  return String(ctx?.chatId ?? key.replace(/^private:/, ''));
}

/** 写操作前的审计日志（谁在什么时候动了什么）。 */
function audit(ctx, action, detail) {
  const who = triggerEntriesOf(ctx).map((m) => m?.senderId).filter(Boolean).join(',') || chatIdOf(ctx);
  log(`[审计] ${new Date().toLocaleString('zh-CN', { hour12: false })} 私聊=${chatIdOf(ctx)} 发言=${who} 动作=${action} ${detail}`);
}

/**
 * 读类工具的门禁：默认与写类同样严（只看画面也只在主人私聊里给）。
 * 把 ownerOnlyRead 关掉才放宽成"任何私聊"——有些用户就是要拿它当投屏看。
 */
function gateRead(ctx) {
  const gate = gatePrivate(ctx);
  if (gate) return gate;
  if (cfg().ownerOnlyRead === false) return null;
  return gateOwner(ctx);
}

/** 取设备句柄；失败时返回 {error: 人话}。 */
async function device(c) {
  const dev = await ensureDevice(c);
  if (!dev.ok) return { error: dev.message || '连接不上模拟器。' };
  return { dev };
}

function toDataUrl(pngBuffer) {
  return `data:image/png;base64,${pngBuffer.toString('base64')}`;
}

/**
 * 界面的"真实像素尺寸"。
 *
 * 这里踩过一个坑，别再改回去：**以截图的 PNG 头为准，不要用 `wm size`**。
 * MuMu 12 上 `wm size` 报的是 `Physical size: 1080x1920`（竖屏数字），而实际
 * 截屏与 uiautomator 的 bounds 都在 1920x1080 的空间里 —— 拿 1080x1920 当屏幕尺寸，
 * 会把 x>1080 的控件全部误标成「在屏幕外」。
 * 优先顺序：最近一次截图的 PNG 尺寸 → `wm size` → 猜。
 */
let lastScreen = null;

async function trueScreenSize(dev) {
  if (dev) {
    const shot = await screenshot(dev, { retries: 0 });
    if (shot.ok) {
      const s = pngSize(shot.buffer);
      if (s) { lastScreen = s; return { ...s, source: 'screencap' }; }
    }
  }
  if (lastScreen) return { ...lastScreen, source: 'cache' };
  if (dev) {
    const wm = await windowSize(dev);
    if (wm) return { ...wm, source: 'wm size' };
  }
  return null;
}

/**
 * 截屏 → 缩放 → 返回给模型的图片部件 + 一行说明。
 * 说明里带**原图分辨率**和缩放比例：模型的坐标是照着缩小图猜的，
 * 缩过的图必须告诉它"你看到的坐标要乘回去"（emulator__tap 也支持按比例换算）。
 */
async function shoot(c, opts = {}) {
  const dev = await device(c);
  if (dev.error) return { ok: false, message: dev.error, reason: 'no-device' };
  const shot = await screenshot(dev.dev);
  if (!shot.ok) return { ok: false, message: shot.message || '截屏失败。', reason: shot.reason };

  const size = pngSize(shot.buffer);
  if (!size) return { ok: false, message: '截屏数据不是合法 PNG。', reason: 'bad-png' };

  const wantMax = Math.max(160, Math.min(2048, num(opts.maxDim, num(c.maxDim, 720))));
  const region = opts.region || {};
  const hasRegion = [region.x, region.y, region.width, region.height].some((v) => v !== undefined && v !== null && v !== '');
  let outBuffer = shot.buffer;
  let outSize = size;
  let scale = 1;
  let note = '';

  const needWork = hasRegion || Math.max(size.width, size.height) > wantMax;
  if (needWork) {
    try {
      const img = decodePng(shot.buffer);
      const done = cropScale(img, {
        x: num(region.x, 0),
        y: num(region.y, 0),
        w: num(region.width, 0),
        h: num(region.height, 0),
        maxDim: wantMax
      });
      outBuffer = encodePng(done);
      outSize = { width: done.width, height: done.height };
      scale = done.scaled;
      note = done.note;
    } catch (err) {
      // 缩图失败不该让"看一眼"整个失败：原样发出去，只提示体积大
      warn('截图缩放失败，改发原图：', err?.message ?? err);
      note = '缩图失败，发的是原图';
    }
  }

  return {
    ok: true,
    buffer: outBuffer,
    deviceSize: size,
    imageSize: outSize,
    scale,
    note,
    bytes: outBuffer.length,
    dev: dev.dev
  };
}

function screenHeader(c, shot, fg, extra = '') {
  const s = shot.deviceSize;
  const lines = [
    `📱 模拟器截图｜画面 ${s.width}x${s.height}｜发给你的是 ${shot.imageSize.width}x${shot.imageSize.height}${shot.note ? `（${shot.note}）` : ''}`
  ];
  if (shot.scale !== 1) {
    lines.push(`注意：这张图被等比缩小了，图上的点 (u,v) 对应画面坐标 (${(1 / shot.scale).toFixed(2)}×u, ${(1 / shot.scale).toFixed(2)}×v)。给 emulator__tap 报坐标时请报**画面坐标**（原图坐标），不要报缩略图上的像素。`);
  } else {
    lines.push('这张图与画面像素 1:1，图上量到的坐标可以直接给 emulator__tap。');
  }
  if (fg?.package) lines.push(`前台应用：${fg.package}${fg.activity ? '/' + fg.activity : ''}`);
  lines.push('要"点得准"，配 emulator__ui 拿控件中心点（控件树给的坐标和这张图同一坐标系）；emulator__screen 只适合看画面状态。');
  if (extra) lines.push(extra);
  return lines.join('\n');
}

export function setup(skillApi) {
  api = skillApi;
  cfg = skillApi.config;
  log = skillApi.log;
  warn = skillApi.warn;

  // ── 1) 截屏（视觉）────────────────────────────────────────────────────
  skillApi.registerTool({
    id: 'screen',
    name: '看模拟器画面',
    description:
      '截取安卓模拟器当前画面并发给模型看（真的能看见，不是文字描述）。'
      + '想知道"模拟器现在什么样子"、游戏/应用到了哪一步、有没有弹窗时就调它。'
      + '参数 maxDim 控制长边像素（默认 720，越小越省 token、越看不清小字）；'
      + 'region 可以只截一块（比如只看某个窗口）。'
      + '返回里会带屏幕真实分辨率和前台应用名。注意：本工具只在私聊里能用。'
      + '要精确点击请配合 emulator__ui（控件树给的是精确坐标），截图只用来"看"。',
    category: 'system',
    icon: '📱',
    defaultEnabled: true,
    requiresVision: true,
    parameters: {
      type: 'object',
      properties: {
        maxDim: { type: 'number', description: '长边最大像素，240~2048，默认 720。看不清小字就调大（更费 token）。' },
        region: {
          type: 'object',
          description: '可选：只截这一块（设备像素坐标）。四个字段都给才生效。',
          properties: {
            x: { type: 'number', description: '左上角 x' },
            y: { type: 'number', description: '左上角 y' },
            width: { type: 'number', description: '宽度' },
            height: { type: 'number', description: '高度' }
          }
        }
      }
    },
    async execute(ctx, args) {
      const gate = gateRead(ctx);
      if (gate) return { content: gate, isError: true };
      try {
        const c = cfg();
        const shot = await shoot(c, args || {});
        if (!shot.ok) return { content: shot.message, isError: true };
        const fg = await foregroundApp(shot.dev);
        return {
          content: [
            { type: 'text', text: screenHeader(c, shot, fg) },
            { type: 'image_url', image_url: { url: toDataUrl(shot.buffer) } }
          ]
        };
      } catch (error) {
        return { content: `截屏出错：${error?.message ?? error}`, isError: true };
      }
    }
  });

  // ── 2) 控件树（点得准）────────────────────────────────────────────────
  skillApi.registerTool({
    id: 'ui',
    name: '读模拟器控件树',
    description:
      '读出模拟器当前界面的控件列表：每个可点/可输入的控件带**精确中心坐标**和文字。'
      + '想点击某个按钮、往输入框填字之前先调它拿坐标，比对着截图估坐标准得多，也更省 token。'
      + '返回的 [编号] 可作为控件序号传给 emulator__tap 的 node；也可以直接用返回的 @(x,y)。'
      + '界面正在播放动画时可能读到空树，稍等再试。本工具只在私聊里能用。',
    category: 'system',
    icon: '🧭',
    defaultEnabled: true,
    parameters: {
      type: 'object',
      properties: {
        filter: { type: 'string', description: '可选：只看包含这段文字的控件（如"登录""确定"），减少输出量。' }
      }
    },
    async execute(ctx, args) {
      const gate = gateRead(ctx);
      if (gate) return { content: gate, isError: true };
      try {
        const c = cfg();
        const d = await device(c);
        if (d.error) return { content: d.error, isError: true };
        const dump = await uiDump(d.dev);
        if (!dump.ok) return { content: dump.message || '取控件树失败。', isError: true };
        const size = await trueScreenSize(d.dev);
        const sum = summarizeUi(dump.xml, size || {});
        if (!sum.ok) return { content: sum.message, isError: true };
        let lines = sum.lines;
        const filter = String(args?.filter ?? '').trim();
        if (filter) {
          const hit = lines.filter((l) => l.includes(filter));
          lines = hit.length ? hit : [`（没有文字包含「${filter}」的控件，下面是全部 ${lines.length} 个）`, ...lines];
        }
        const head = [
          `🧭 控件树｜画面 ${size ? `${size.width}x${size.height}` : '未知'}（与 emulator__screen 同一坐标系，可直接喂 emulator__tap）｜共 ${sum.kept} 个可用控件`
            + (sum.truncated ? '（已截断，只列了前面这些）' : ''),
          '格式：[序号] 类型 "文字" #id @(中心x,中心y) 宽x高 → 能干什么',
          ''
        ].join('\n');
        return { content: head + lines.join('\n') };
      } catch (error) {
        return { content: `读控件树出错：${error?.message ?? error}`, isError: true };
      }
    }
  });

  // ── 3) 前台应用 / 装了哪些应用 ─────────────────────────────────────────
  skillApi.registerTool({
    id: 'app',
    name: '查模拟器应用',
    description:
      '查模拟器里现在前台是什么应用，或者列出已安装的应用（找包名用）。'
      + '准备用 emulator__open 打开某个应用、或想确认"现在到底停在哪个界面"时用。本工具只在私聊里能用。',
    category: 'system',
    icon: '📦',
    defaultEnabled: true,
    parameters: {
      type: 'object',
      properties: {
        list: { type: 'boolean', description: 'true = 列出已安装的第三方应用包名；false/省略 = 只看当前前台应用。' }
      }
    },
    async execute(ctx, args) {
      const gate = gateRead(ctx);
      if (gate) return { content: gate, isError: true };
      try {
        const c = cfg();
        const d = await device(c);
        if (d.error) return { content: d.error, isError: true };
        const fg = await foregroundApp(d.dev);
        const size = await windowSize(d.dev);
        const lines = [
          `📱 设备 ${d.dev.serial}${d.dev.model ? `（${d.dev.model}）` : ''}｜屏幕 ${size ? `${size.width}x${size.height}` : '未知'}`,
          fg?.package ? `前台应用：${fg.package}${fg.activity ? '/' + fg.activity : ''}` : '前台应用：读不出来（可能刚切换界面）'
        ];
        if (args?.list === true) {
          const r = await shell(d.dev, ['pm', 'list', 'packages', '-3'], { timeoutMs: 20000 });
          const pkgs = String(r.stdout || '').split(/\r?\n/).map((l) => l.replace(/^package:/, '').trim()).filter(Boolean);
          lines.push('', `已安装第三方应用 ${pkgs.length} 个（emoji 或系统应用不在内）：`);
          lines.push(...pkgs.slice(0, 120));
          if (pkgs.length > 120) lines.push(`…还有 ${pkgs.length - 120} 个未列出`);
        } else {
          lines.push('（想看装了哪些应用：把 list 设为 true）');
        }
        return { content: lines.join('\n') };
      } catch (error) {
        return { content: `查应用出错：${error?.message ?? error}`, isError: true };
      }
    }
  });

  // ── 4) 点 / 滑（唯一的"动手"入口之一）─────────────────────────────────
  skillApi.registerTool({
    id: 'tap',
    name: '操作模拟器（点/滑）',
    description:
      '在模拟器里点击或滑动。这是**真的会动用户的设备**，只在私聊、且只有主人能用。'
      + '用法二选一：① 先用 emulator__ui 拿控件，把它的序号写成 node（推荐，最准）；'
      + '② 直接给 x/y 设备像素坐标。'
      + 'swipe 是按住拖动（如翻页、拉列表）：给 x1/y1/x2/y2。'
      + '做完建议用 emulator__screen 或 emulator__ui 确认结果，别连续瞎点。',
    category: 'system',
    icon: '👆',
    defaultEnabled: true,
    parameters: {
      type: 'object',
      properties: {
        gesture: { type: 'string', enum: GESTURES, description: 'tap=点击（默认）；swipe=滑动；key=按返回/主页等按键；text=往输入框打字。' },
        x: { type: 'number', description: '点击的 x（设备像素）' },
        y: { type: 'number', description: '点击的 y（设备像素）' },
        x1: { type: 'number', description: '滑动起点 x' },
        y1: { type: 'number', description: '滑动起点 y' },
        x2: { type: 'number', description: '滑动终点 x' },
        y2: { type: 'number', description: '滑动终点 y' },
        durationMs: { type: 'number', description: '滑动耗时毫秒，默认 300；越大越"慢"（用于长按拖动）。' },
        key: { type: 'string', description: 'gesture=key 时按哪个键：BACK / HOME / APP_SWITCH / ENTER / DEL 或数字。' },
        text: { type: 'string', description: 'gesture=text 时要输入的文字（先用 tap 点中输入框）。' },
        waitMs: { type: 'number', description: '操作后等待多久再返回，默认 600ms；界面切换慢的应用可以给 1500。' }
      }
    },
    async execute(ctx, args) {
      const gate = gatePrivate(ctx) || gateOwner(ctx);
      if (gate) return { content: gate, isError: true };
      try {
        const c = cfg();
        const d = await device(c);
        if (d.error) return { content: d.error, isError: true };
        const gesture = String(args?.gesture || 'tap').toLowerCase();
        const waitMs = Math.max(0, Math.min(5000, num(args?.waitMs, 600)));

        if (gesture === 'text') {
          const text = String(args?.text ?? '');
          if (!text) return { content: '要输入什么都没给（text 为空）。', isError: true };
          const r = await inputText(d.dev, text);
          audit(ctx, 'text', JSON.stringify(text.slice(0, 60)));
          if (!r.ok) return { content: `打字失败：${r.message || 'input text 没成功'}`, isError: true };
          if (waitMs) await new Promise((res) => setTimeout(res, waitMs));
          return { content: `⌨️ 已往当前焦点输入框输入「${text}」。建议 emulator__screen 确认一下再继续。` };
        }

        if (gesture === 'key') {
          const key = String(args?.key ?? '').trim();
          if (!key) return { content: '要按哪个键没给（key 为空）。常用：BACK / HOME / APP_SWITCH / ENTER。', isError: true };
          const r = await keyEvent(d.dev, key);
          audit(ctx, 'key', key);
          if (!r.ok) return { content: `按键失败：${r.message || 'input keyevent 没成功'}`, isError: true };
          if (waitMs) await new Promise((res) => setTimeout(res, waitMs));
          return { content: `⌨️ 已按下 ${key}。` };
        }

        if (gesture === 'swipe') {
          const need = [args?.x1, args?.y1, args?.x2, args?.y2];
          if (need.some((v) => v === undefined || v === null || v === '')) {
            return { content: '滑动需要 x1/y1/x2/y2 四个坐标。', isError: true };
          }
          const r = await adbSwipe(d.dev, num(args.x1), num(args.y1), num(args.x2), num(args.y2), num(args.durationMs, 300));
          audit(ctx, 'swipe', `(${num(args.x1)},${num(args.y1)})→(${num(args.x2)},${num(args.y2)}) ${num(args.durationMs, 300)}ms`);
          if (!r.ok) return { content: `滑动失败：${r.message || 'input swipe 没成功'}`, isError: true };
          if (waitMs) await new Promise((res) => setTimeout(res, waitMs));
          return { content: `👆 已滑动 (${num(args.x1)},${num(args.y1)}) → (${num(args.x2)},${num(args.y2)})。` };
        }

        if (args?.node !== undefined && args?.node !== null && args?.node !== '') {
          // 用最新的控件树把序号换成坐标 —— 比模型对着截图估坐标准得多
          const dump = await uiDump(d.dev);
          if (!dump.ok) return { content: `要用 node 得先能读控件树，但这次读失败：${dump.message || '未知原因'}。可以直接给 x/y，或稍后重试 emulator__ui。`, isError: true };
          const found = findNode(dump.xml, (await trueScreenSize(d.dev)) || {}, Math.round(num(args.node, -1)));
          if (!found.ok) return { content: `换算失败：${found.message}。重新 emulator__ui 看看新序号，或直接给 x/y。`, isError: true };
          const x = found.node.cx;
          const y = found.node.cy;
          const r = await adbTap(d.dev, x, y);
          audit(ctx, 'tap-node', `#${found.node.idx}${found.node.label ? ' ' + JSON.stringify(found.node.label) : ''}→(${x},${y})`);
          if (!r.ok) return { content: `点击失败：${r.message || 'input tap 没成功'}`, isError: true };
          await new Promise((res) => setTimeout(res, waitMs));
          return { content: `👆 已点击控件 [${found.node.idx}]${found.node.label ? `（${found.node.label}）` : ''}，坐标 ${x},${y}。要确认结果就 emulator__screen 看一眼。` };
        }
        if (args?.x === undefined || args?.y === undefined || args?.x === null || args?.y === null) {
          return { content: '点击需要 x/y，或者用 emulator__ui 拿到的 node 序号。', isError: true };
        }
        const r = await adbTap(d.dev, num(args.x), num(args.y));
        audit(ctx, 'tap', `(${num(args.x)},${num(args.y)})`);
        if (!r.ok) return { content: `点击失败：${r.message || 'input tap 没成功'}`, isError: true };
        if (waitMs) await new Promise((res) => setTimeout(res, waitMs));
        return { content: `👆 已点击 (${num(args.x)},${num(args.y)})。要确认结果就 emulator__screen 看一眼。` };
      } catch (error) {
        return { content: `操作出错：${error?.message ?? error}`, isError: true };
      }
    }
  });

  // ── 5) 起应用 / 回桌面 ────────────────────────────────────────────────
  skillApi.registerTool({
    id: 'open',
    name: '打开模拟器里的应用',
    description:
      '把模拟器切到某个应用（给包名，如 com.bilibili.azurlane），或者按 HOME 回桌面、按 BACK 返回上一级。'
      + '包名不确定就先 emulator__app 的 list=true 查。本工具只在私聊、且只有主人能用。',
    category: 'system',
    icon: '🚀',
    defaultEnabled: true,
    parameters: {
      type: 'object',
      properties: {
        package: { type: 'string', description: '要打开的应用包名，或 包名/Activity（如 com.tencent.mm/.ui.LauncherUI）。' },
        home: { type: 'boolean', description: 'true = 直接回桌面（不看 package）。' },
        back: { type: 'boolean', description: 'true = 按返回键（不看 package）。' }
      }
    },
    async execute(ctx, args) {
      const gate = gatePrivate(ctx) || gateOwner(ctx);
      if (gate) return { content: gate, isError: true };
      try {
        const c = cfg();
        const d = await device(c);
        if (d.error) return { content: d.error, isError: true };
        const waitMs = Math.max(0, Math.min(8000, num(args?.waitMs, 1200)));

        if (args?.home === true) {
          await keyEvent(d.dev, 'HOME');
          audit(ctx, 'home', '');
          if (waitMs) await new Promise((res) => setTimeout(res, waitMs));
          return { content: '🏠 已回桌面。' };
        }
        if (args?.back === true) {
          await keyEvent(d.dev, 'BACK');
          audit(ctx, 'back', '');
          if (waitMs) await new Promise((res) => setTimeout(res, waitMs));
          return { content: '↩️ 已按返回。' };
        }
        const pkg = String(args?.package ?? '').trim();
        if (!pkg) return { content: '要给包名，或者把 home/back 设成 true。', isError: true };
        const r = await startApp(d.dev, pkg);
        audit(ctx, 'open', pkg);
        if (!r.ok) return { content: `启动失败：${r.message}`, isError: true };
        if (waitMs) await new Promise((res) => setTimeout(res, waitMs));
        const fg = await foregroundApp(d.dev);
        return { content: `🚀 ${r.message}${fg?.package ? `；现在前台是 ${fg.package}` : ''}。` };
      } catch (error) {
        return { content: `打开应用出错：${error?.message ?? error}`, isError: true };
      }
    }
  });

  // ── 6) 一次拿全（截图 + 控件树）───────────────────────────────────────
  skillApi.registerTool({
    id: 'look',
    name: '看清模拟器（截图+控件树）',
    description:
      '一次性返回模拟器的截图**和**当前界面的控件树（带精确坐标），是"我要操作这个界面"最省事的起手式：'
      + '先 emulator__look 看清有什么、在哪，再用 emulator__tap 精确点。'
      + '比分别调 emulator__screen + emulator__ui 少一轮往返，代价是更费 token —— 两个都要就够了时才用。本工具只在私聊里能用。',
    category: 'system',
    icon: '👀',
    defaultEnabled: true,
    requiresVision: true,
    parameters: {
      type: 'object',
      properties: {
        maxDim: { type: 'number', description: '截图长边像素上限，默认 720（同上）。' },
        filter: { type: 'string', description: '可选：控件树只看包含这段文字的控件。' }
      }
    },
    async execute(ctx, args) {
      const gate = gateRead(ctx);
      if (gate) return { content: gate, isError: true };
      try {
        const c = cfg();
        const d = await device(c);
        if (d.error) return { content: d.error, isError: true };

        const shot = await shoot(c, { maxDim: args?.maxDim });
        const parts = [];
        let head = '';
        if (shot.ok) {
          const fg = await foregroundApp(shot.dev);
          head = screenHeader(c, shot, fg);
          parts.push({ type: 'image_url', image_url: { url: toDataUrl(shot.buffer) } });
        } else {
          head = `截图没成功（${shot.message}），下面是控件树。`;
        }

        const dump = await uiDump(d.dev);
        let uiText = '';
        if (dump.ok) {
          // 截图成功时用它的尺寸（shot.deviceSize）当坐标系，省一次额外截屏
          const size = shot.ok ? shot.deviceSize : await trueScreenSize(d.dev);
          const sum = summarizeUi(dump.xml, size || {});
          if (sum.ok) {
            let lines = sum.lines;
            const filter = String(args?.filter ?? '').trim();
            if (filter) {
              const hit = lines.filter((l) => l.includes(filter));
              lines = hit.length ? hit : [`（没有文字包含「${filter}」的控件，下面是全部 ${lines.length} 个）`, ...lines];
            }
            uiText = `\n\n🧭 控件树（共 ${sum.kept} 个可用控件${sum.truncated ? '，已截断' : ''}）：\n` + lines.join('\n');
          } else {
            uiText = `\n\n🧭 控件树读不出来：${sum.message}`;
          }
        } else {
          uiText = `\n\n🧭 控件树读不出来：${dump.message || '未知原因'}（可能这个界面是游戏画面，控件树本来就空，那就只能靠截图估坐标 + emulator__tap）`;
        }

        return { content: [{ type: 'text', text: head + uiText }, ...parts] };
      } catch (error) {
        return { content: `读取界面出错：${error?.message ?? error}`, isError: true };
      }
    }
  });

  log('模拟器操控已就绪（emulator__screen / emulator__ui / emulator__app / emulator__tap / emulator__open / emulator__look）');
}

/** 热重载/停机时把还在跑的 adb 收掉。 */
export function dispose() {
  try { killAll(); } catch { /* 无所谓 */ }
}
