// 电脑全能操控（pc-suite）—— 把分散的六个本机扩展合并成一个入口。
//
// 合并了什么（原扩展 → 本技能）
//   plugins/pc-control    截图/状态/进程/音量/开关程序/清回收站  → screen · status · volume · apps · system
//   skills/pcstatus       整机与单软件细粒度状态（含显卡）        → status
//   skills/local-pc       开始菜单应用清单 + 开/关程序 + 命令      → apps · command
//   skills/machine-work   文件读写改/列目录/找文件/搜内容/后台任务  → files · command · media
//   skills/screen-look    截图喂给模型看                          → screen(mode=look)
//   skills/mouse-control  鼠标移动/点击/拖动/滚轮                  → mouse
//
// 为什么合成一个（而不是六个各管一摊）：
//   模型每次调用都要看一遍工具清单。同一件事有多个入口时，它会在两个工具之间
//   随机选、甚至重复调用（"截屏"就有 pc_screenshot / local-pc / screen-look 三条路）。
//   合成一个后，入口唯一、选择成本低，安全闸门也只有一处要配。
//
// ── 安全：统一的一道闸，五层 ──────────────────────────────────────────────
//   ① 主人判定：ownerIds 优先，否则问「主人识别」能力；都没配 → 完全不动作。
//   ② 触发范围：scope=private（默认）| all。群聊只能按"最近一条消息"反推是谁，
//      容易被抢话顶替，所以默认只在私聊生效（与 machine-work 同一结论）。
//   ③ 只读模式 / 目录白名单 / 路径黑名单 / 命令黑名单：四道口子都在设置里。
//   ④ 高危操作（杀进程、清回收站）要 allowDangerous，且清回收站还要 confirm。
//   ⑤ 限频 + 审计：每小时 maxPerHour 次；每次落一行到 data/pc-suite-audit.log。
//      ⚠️ 日志与缓存只写 DATA_DIR —— 写进 skills/ 目录会触发热重载全量重扫
//      （项目里 health-data.json 事故的教训）。
//
// 坐标口径：mouse / screen 都用**物理像素**（PowerShell 里 SetProcessDPIAware），
// screen 返回文本带换算公式，模型看完图能直接算出 mouse 要用的坐标。

import fs from 'node:fs';
import path from 'node:path';
import { execFile, spawn } from 'node:child_process';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { DATA_DIR, getConfig } from '../../src/config.js';

const ID = 'pc-suite';

// ── 直达指令层（`\电脑 截图` 这类口令）────────────────────────────────────
//   本技能的九个工具都是"说人话 → 模型理解 → 调工具"，中间要过一次模型；
//   而 pc-control 另有一条**不走模型**的直达通道：主人发「\电脑 截图」，
//   它当场执行并回结果，快且不受模型抽风影响。这条通道不是工具，没法用工具替代，
//   所以这里把它接过来：加载 pc-control、取它的 onMessage 钩子。
//
//   ⚠️ 只取钩子，**屏蔽它的工具注册**（传一个空 registerTool）：
//   pc_screenshot / pc_status / pc_process_list / pc_set_volume /
//   pc_open_app / pc_kill_app 这六个，本技能的 screen / status / system /
//   volume / apps 已经全部覆盖且更强；都注册上只会让模型在两条路之间乱选。
//   它的直达指令内部走的是自己的 capVolume / capOpen / collectStatus 等函数，
//   不经过 registerTool —— 所以屏蔽工具不影响直达通道工作。
const DIRECT = {
  id: 'pc-control',
  prefix: 'remote',
  label: '\\电脑 直达指令',
  dir: path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..', '..', 'plugins', 'pc-control')
};

// 顶层 await：模块加载期就把来源读进来，setup 才能保持同步
// （否则加载器数工具时 import 还没回来，会被判成"没注册任何工具"）。
let directMod = null;
let directErr = null;
try {
  directMod = await import(pathToFileURL(path.join(DIRECT.dir, 'index.js')).href + `?t=${Date.now()}`);
} catch (e) {
  directErr = e?.message ?? String(e);
}
let directLive = false;

let cfg = () => ({});
let log = (...a) => {};
let apiRef = null;

// ── 配置读取 ──────────────────────────────────────────────────────────────
const num = (v, lo, hi, dflt) => {
  const n = Number(v);
  return Number.isFinite(n) ? Math.max(lo, Math.min(hi, n)) : dflt;
};
const lines = (v) => String(v ?? '').split(/\r?\n/).map((s) => s.trim()).filter(Boolean);

function workDirOf() {
  return String(cfg().workDir || '').trim() || path.resolve(DATA_DIR || process.cwd(), '..');
}
function allowedRoots() {
  return lines(cfg().allowedRoots).map((p) => path.resolve(p));
}
function denyRes() {
  return lines(cfg().denyPatterns).map((p) => {
    try { return new RegExp(p, 'i'); } catch { return null; }
  }).filter(Boolean);
}
function commandDenyList() {
  return lines(cfg().commandDeny).map((s) => s.toLowerCase());
}

// ── 主人判定 / 范围闸 / 限频 / 审计 ────────────────────────────────────────
function makeOwnerChecker() {
  const explicit = String(cfg().ownerIds || '').split(/[,，;；\s]+/).map((s) => s.trim()).filter(Boolean);
  if (explicit.length) return (uid) => explicit.includes(String(uid));
  const cap = apiRef?.capability;
  if (typeof cap !== 'function') return null;
  return (uid) => {
    let r;
    try { r = cap('message.owner-check', { userId: Number(uid) || uid }); } catch { return false; }
    return !!r && typeof r.then !== 'function' && r.isOwner === true;
  };
}

/** 谁在说话：优先用触发批最后一条，退回存档里最近一条别人发的消息。 */
function callerOf(ctx) {
  const entries = ctx?.session?.trigger || ctx?.session?.triggerEntries || [];
  const last = Array.isArray(entries) && entries.length ? entries[entries.length - 1] : null;
  const fromTrigger = String(last?.senderId ?? '').trim();
  if (fromTrigger) return { uid: fromTrigger, name: String(last?.senderName || '') };
  try {
    const list = ctx?.store?.recent?.(ctx?.chatKey, { limit: 6, includeSelf: false }) || [];
    for (let i = list.length - 1; i >= 0; i -= 1) {
      if (list[i]?.senderId) return { uid: String(list[i].senderId), name: String(list[i].senderName || '') };
    }
  } catch { /* 存档不可用就当认不出 */ }
  return { uid: '', name: '' };
}

const OWNER_TIP = '只有主人可以动这台电脑，其他人开口一律拒绝。';

function gate(ctx, toolName) {
  if (cfg().enabled === false) return { ok: false, why: '本技能已被关掉（技能设置里的总开关）' };

  // 跨路径去重：主人发「\电脑 打开 记事本」，消息一边被直达通道当场执行，
  // 一边照样流进模型 —— 模型看到"打开记事本"会再调本工具的 apps.open，
  // 于是开两次。所以工具这一侧要认直达通道记的账：这条消息它已经办过，就别动。
  // （pc-control 自己的工具本来就有这道检查，这里给本技能的九个工具补上同一个。）
  if (directLive) {
    try {
      const entries = ctx?.session?.trigger || ctx?.session?.triggerEntries;
      if (directMod?.internals?.directHandledIn?.(entries)) {
        return { ok: false, why: 'SKIP_DIRECT' };
      }
    } catch { /* 去重只是保险，查不动就照常往下走 */ }
  }

  const kind = ctx?.kind || String(ctx?.chatKey || '').split(':')[0] || '';
  if (String(cfg().scope || 'private') === 'private' && kind !== 'private') {
    return { ok: false, why: '当前触发范围是「仅主人私聊」，这条不是私聊，已拒绝（群聊里没法确认指令是谁发的）。' };
  }
  const { uid, name } = callerOf(ctx);
  if (!uid) return { ok: false, why: '没能确认是谁在说话，身份不明一律不动手。' };
  const isOwner = makeOwnerChecker();
  if (!isOwner || !isOwner(uid)) {
    return { ok: false, why: `拒绝：这次不是主人发起的（说话的人：${name || '未知'} / ${uid}）。${OWNER_TIP}` };
  }
  if (rateLimited()) return { ok: false, why: '操作太频繁，稍后再试（每小时上限可在设置里调）' };
  audit(ctx?.chatKey, uid, 'tool:' + toolName, '授权通过');
  return { ok: true, uid };
}

const execTimes = [];
function rateLimited() {
  const now = Date.now();
  while (execTimes.length && now - execTimes[0] > 3600000) execTimes.shift();
  const max = Math.max(1, Number(cfg().maxPerHour) || 40);
  if (execTimes.length >= max) return true;
  execTimes.push(now);
  return false;
}

function auditFile() {
  return path.join(DATA_DIR || path.join(process.cwd(), 'data'), `${ID}-audit.log`);
}
function audit(chatKey, uid, action, result) {
  try {
    if (cfg().audit === false) return;
    const f = auditFile();
    const line = `${new Date().toISOString()} ${chatKey || '?'} ${uid || '?'} ${action} => ${String(result).slice(0, 300)}\n`;
    try {
      if (fs.existsSync(f) && fs.statSync(f).size > 2 * 1048576) fs.renameSync(f, f.replace(/\.log$/, '.old'));
    } catch { /* 轮转失败不影响主流程 */ }
    fs.appendFileSync(f, line, 'utf8');
  } catch { /* 审计失败绝不影响执行 */ }
}

// ── PowerShell 执行器 ─────────────────────────────────────────────────────
function runPS(script, timeoutMs = 20000) {
  return new Promise((resolve) => {
    execFile('powershell.exe',
      ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-Command',
        '[Console]::OutputEncoding=[System.Text.Encoding]::UTF8\n' + script],
      { timeout: timeoutMs, windowsHide: true, maxBuffer: 8 * 1048576, encoding: 'utf8' },
      (error, stdout) => resolve({ ok: !error, out: String(stdout || '').trim(), err: error?.message || '' }));
  });
}

// ══════════════════════════════════════════════════════════════════════════
// 一、鼠标（user32 P/Invoke，坐标一律物理像素）
// ══════════════════════════════════════════════════════════════════════════
const PS_MOUSE_HEAD = `
$ErrorActionPreference = 'Stop'
if (-not ('MC' -as [type])) {
Add-Type -TypeDefinition @'
using System;using System.Runtime.InteropServices;
public class MC {
  [DllImport("user32.dll")] public static extern bool SetProcessDPIAware();
  [DllImport("user32.dll")] public static extern bool SetCursorPos(int X, int Y);
  [DllImport("user32.dll")] public static extern void mouse_event(uint dwFlags, uint dx, uint dy, uint dwData, UIntPtr dwExtraInfo);
  [DllImport("user32.dll")] public static extern bool GetCursorPos(out POINT p);
  [StructLayout(LayoutKind.Sequential)] public struct POINT { public int X; public int Y; }
}
'@
}
[MC]::SetProcessDPIAware() | Out-Null
Add-Type -AssemblyName System.Windows.Forms
$b = [System.Windows.Forms.Screen]::PrimaryScreen.Bounds
function Clamp([int]$v, [int]$max) { if ($v -lt 0) { return 0 }; if ($v -ge $max) { return $max - 1 }; return $v }
`;
const BTN = { left: { down: 2, up: 4 }, right: { down: 8, up: 16 }, middle: { down: 32, up: 64 } };

async function capMouse(action, a = {}) {
  const int = (v, lo, hi) => {
    const n = Math.round(Number(v));
    return Number.isFinite(n) ? Math.max(lo, Math.min(hi, n)) : null;
  };
  if (action === 'position') {
    const r = await runPS(PS_MOUSE_HEAD + `
$p = New-Object 'MC+POINT'
[MC]::GetCursorPos([ref]$p) | Out-Null
Write-Output ("{0},{1},{2},{3}" -f $p.X, $p.Y, $b.Width, $b.Height)
`);
    if (!r.ok || !r.out) return { err: '查询失败：' + (r.err || '无输出') };
    const [x, y, w, h] = r.out.split(',').map((n) => parseInt(n, 10));
    return { text: `当前鼠标位置 (${x || 0}, ${y || 0})，屏幕分辨率 ${w} × ${h}（物理像素）。` };
  }
  if (action === 'move') {
    const x = int(a.x, 0, 32767); const y = int(a.y, 0, 32767);
    if (x === null || y === null) return { err: '坐标必须是数字' };
    const r = await runPS(PS_MOUSE_HEAD + `
$x = Clamp ${x} $b.Width
$y = Clamp ${y} $b.Height
[MC]::SetCursorPos($x, $y) | Out-Null
Start-Sleep -Milliseconds 60
$p = New-Object 'MC+POINT'
[MC]::GetCursorPos([ref]$p) | Out-Null
Write-Output ("{0},{1}" -f $p.X, $p.Y)
`);
    if (!r.ok) return { err: '移动失败：' + r.err };
    return { text: `已把鼠标移到 (${r.out})。` };
  }
  if (['click', 'double', 'right', 'middle'].includes(action)) {
    const x = int(a.x, 0, 32767); const y = int(a.y, 0, 32767);
    if (x === null || y === null) return { err: '坐标必须是数字' };
    const btn = BTN[action === 'right' ? 'right' : action === 'middle' ? 'middle' : 'left'];
    const pair = `[MC]::mouse_event(${btn.down},0,0,0,[UIntPtr]::Zero); Start-Sleep -Milliseconds 45; [MC]::mouse_event(${btn.up},0,0,0,[UIntPtr]::Zero)`;
    const body = action === 'double' ? `${pair}; Start-Sleep -Milliseconds 90; ${pair}` : pair;
    const r = await runPS(PS_MOUSE_HEAD + `
$x = Clamp ${x} $b.Width
$y = Clamp ${y} $b.Height
[MC]::SetCursorPos($x, $y) | Out-Null
Start-Sleep -Milliseconds 90
${body}
Write-Output done
`, 20000);
    if (!r.ok || !r.out) return { err: '点击失败：' + (r.err || '无输出') };
    const label = { click: '单击左键', double: '双击左键', right: '单击右键', middle: '单击中键' }[action];
    return { text: `已在 (${x}, ${y}) ${label}。` };
  }
  if (action === 'drag') {
    const p = ['fromX', 'fromY', 'toX', 'toY'].map((k) => int(a[k], 0, 32767));
    if (p.some((v) => v === null)) return { err: '拖动需要起止两组坐标' };
    const r = await runPS(PS_MOUSE_HEAD + `
$fx = Clamp ${p[0]} $b.Width
$fy = Clamp ${p[1]} $b.Height
$tx = Clamp ${p[2]} $b.Width
$ty = Clamp ${p[3]} $b.Height
[MC]::SetCursorPos($fx, $fy) | Out-Null
Start-Sleep -Milliseconds 140
[MC]::mouse_event(2,0,0,0,[UIntPtr]::Zero)
Start-Sleep -Milliseconds 120
for ($i = 1; $i -le 24; $i++) {
  [MC]::SetCursorPos([int]($fx + ($tx - $fx) * $i / 24), [int]($fy + ($ty - $fy) * $i / 24)) | Out-Null
  Start-Sleep -Milliseconds 16
}
Start-Sleep -Milliseconds 120
[MC]::mouse_event(4,0,0,0,[UIntPtr]::Zero)
Write-Output done
`, 30000);
    if (!r.ok || !r.out) return { err: '拖动失败：' + (r.err || '无输出') };
    return { text: `已从 (${p[0]}, ${p[1]}) 拖到 (${p[2]}, ${p[3]})。` };
  }
  if (action === 'scroll') {
    const n = int(a.notches, -20, 20);
    if (!n) return { err: 'notches 必须是数字（-20 ~ 20 且不为 0）' };
    const horizontal = String(a.direction) === 'horizontal';
    const r = await runPS(PS_MOUSE_HEAD + `
[MC]::mouse_event(${horizontal ? 4096 : 2048},0,0,${n * 120},[UIntPtr]::Zero)
Start-Sleep -Milliseconds 80
Write-Output done
`);
    if (!r.ok || !r.out) return { err: '滚动失败：' + (r.err || '无输出') };
    const d = horizontal ? (n > 0 ? '向右' : '向左') : (n > 0 ? '向上' : '向下');
    return { text: `已${d}滚动 ${Math.abs(n)} 格。` };
  }
  return { err: `未知的鼠标动作：${action}` };
}

// ══════════════════════════════════════════════════════════════════════════
// 二、看屏幕（Electron 桌面捕获；look=喂模型，send=发聊天）
// ══════════════════════════════════════════════════════════════════════════
async function capScreen(mode, ctx) {
  const mod = await import('electron');
  const electron = mod?.default ?? mod;
  if (!electron?.desktopCapturer || !electron?.screen) return { err: '拿不到截图能力（机器人必须以桌面应用方式运行）' };
  const display = electron.screen.getPrimaryDisplay();
  const physW = Math.round(display.size.width * (display.scaleFactor || 1));
  const physH = Math.round(display.size.height * (display.scaleFactor || 1));
  const reqW = Math.min(physW, 3840);
  const sources = await electron.desktopCapturer.getSources({
    types: ['screen'], thumbnailSize: { width: reqW, height: Math.round(reqW * (physH / physW)) }
  });
  if (!sources.length) return { err: '没有可截取的屏幕' };
  let img = sources[0].thumbnail;
  const maxW = Math.max(320, Math.min(3840, num(cfg().screenMaxWidth, 320, 3840, 1600)));
  if (img.getSize().width > maxW) img = img.resize({ width: maxW });
  const size = img.getSize();
  const b64 = img.toPNG().toString('base64');

  if (mode === 'send') {
    if (!ctx?.sender?.sendImage) return { err: '发送通道不可用，截不了图发聊天' };
    try {
      await ctx.sender.sendImage(ctx.chatKey, { dataUrl: 'base64://' + b64 }, { note: '当前屏幕' });
      return { text: '已把当前屏幕截图发到会话里。' };
    } catch (e) {
      return { err: '发图失败：' + (e?.message ?? e) };
    }
  }
  const scale = size.width === physW
    ? '截图与屏幕物理像素 1:1，图上看到的坐标可直接用于鼠标操作。'
    : `截图 ${size.width}×${size.height}，屏幕物理分辨率 ${physW}×${physH}；换算：物理x = 图x × ${physW} ÷ ${size.width}，物理y = 图y × ${physH} ÷ ${size.height}。`;
  return {
    parts: [
      { type: 'text', text: `已截取当前屏幕（主屏）。${scale}\n请直接看这张图。` },
      { type: 'image_url', image_url: { url: 'data:image/png;base64,' + b64 } }
    ]
  };
}

// ══════════════════════════════════════════════════════════════════════════
// 三、状态（整机 / 单个软件）
// ══════════════════════════════════════════════════════════════════════════
const arr = (v) => (Array.isArray(v) ? v : v ? [v] : []);

async function capStatus(target) {
  const wantGpu = cfg().showGpuUsage !== false;
  const r = await runPS(`
$os = Get-CimInstance Win32_OperatingSystem
$cpuAvg = (Get-CimInstance Win32_Processor | Measure-Object -Property LoadPercentage -Average).Average
if ($null -eq $cpuAvg) { $cpuAvg = 0 }
$coreMax = (Get-CimInstance Win32_PerfFormattedData_PerfOS_Processor -ErrorAction SilentlyContinue | Where-Object { $_.Name -ne '_Total' } | Measure-Object -Property PercentProcessorTime -Maximum).Maximum
if ($null -eq $coreMax) { $coreMax = 0 }
$memTotal = [math]::Round($os.TotalVisibleMemorySize/1MB,2)
$memFree = [math]::Round($os.FreePhysicalMemory/1MB,2)
$up = (Get-Date) - $os.LastBootUpTime
$gpuName = (Get-CimInstance Win32_VideoController -ErrorAction SilentlyContinue | Select-Object -First 1 -ExpandProperty Name)
$gpuUse = $null
if (${wantGpu ? '1' : '0'} -eq 1) {
  try {
    $g = @(Get-CimInstance Win32_PerfFormattedData_GPUPerformanceCounters_GPUEngine -ErrorAction Stop | Where-Object { $_.Name -like '*engtype_3D*' })
    if ($g.Count -gt 0) { $gpuUse = [int](($g | Measure-Object -Property UtilizationPercentage -Sum).Sum) }
  } catch { $gpuUse = $null }
}
$disks = @(Get-PSDrive -PSProvider FileSystem -ErrorAction SilentlyContinue | Where-Object { $null -ne $_.Used } | ForEach-Object { @{ name = $_.Name; used = [math]::Round($_.Used/1GB,1); total = [math]::Round(($_.Used+$_.Free)/1GB,1) } })
$top = @(Get-Process -ErrorAction SilentlyContinue | Sort-Object WS -Descending | Select-Object -First 5 | ForEach-Object { @{ n = $_.ProcessName; mb = [math]::Round($_.WS/1MB) } })
$self = @(Get-Process -ErrorAction SilentlyContinue | Where-Object { $_.ProcessName -like '*QQ Agent*' } | ForEach-Object { @{ n = $_.ProcessName; mb = [math]::Round($_.WS/1MB); pid = $_.Id } })
@{ cpu = [int]$cpuAvg; coreMax = [int]$coreMax; memTotal = $memTotal; memFree = $memFree; upH = [int]$up.TotalHours; upM = $up.Minutes; gpu = [string]$gpuName; gpuUse = $gpuUse; disks = $disks; top = $top; self = $self; host = $env:COMPUTERNAME } | ConvertTo-Json -Compress -Depth 4
`, 25000);
  if (!r.ok || !r.out) return { err: '读取失败：' + (r.err || 'PowerShell 无输出') };
  let d;
  try { d = JSON.parse(r.out); } catch { return { err: '读取失败：返回不是合法 JSON' }; }

  if (target && !/^(system|all|整体|全部|概况|电脑|整机|overview)$/i.test(target)) {
    const q = await runPS(`
$name = '${String(target).replace(/'/g, "''")}'
$procs = @(Get-Process -ErrorAction SilentlyContinue | Where-Object { $_.ProcessName -like "*$name*" -or $_.ProcessName -eq $name })
if ($procs.Count -eq 0) { Write-Output 'none'; exit }
$mb = [math]::Round(($procs | Measure-Object -Property WS -Sum).Sum/1MB,1)
$st = ($procs | Where-Object { $_.StartTime } | Sort-Object StartTime | Select-Object -First 1).StartTime
$mins = -1
if ($st) { $mins = [int]((Get-Date) - $st).TotalMinutes }
@{ count = $procs.Count; mb = $mb; minutes = $mins } | ConvertTo-Json -Compress
`, 15000);
    if (!q.ok || !q.out) return { err: '查询失败：' + (q.err || '无输出') };
    if (q.out === 'none') return { text: `「${target}」现在没有在运行。` };
    let s;
    try { s = JSON.parse(q.out); } catch { return { err: '查询失败：返回不是合法 JSON' }; }
    const runTxt = s.minutes >= 0
      ? (s.minutes >= 60 ? `已运行 ${Math.floor(s.minutes / 60)} 小时 ${s.minutes % 60} 分` : `已运行 ${s.minutes} 分钟`)
      : '运行时长未知';
    return { text: `【${target}】进程数 ${s.count} 个，合计内存 ${s.mb} MB，${runTxt}。（本机会话实测值，请照实回答）` };
  }

  const used = Math.max(0, d.memTotal - d.memFree);
  const diskTxt = arr(d.disks).map((x) => `磁盘 ${x.name}: 剩余 ${(x.total - x.used).toFixed(1)}GB / 共 ${x.total}GB`);
  const topTxt = arr(d.top).slice(0, 5).map((p) => `${p.n} ${p.mb}MB`);
  const selfTxt = arr(d.self).map((p) => `${p.n}（pid ${p.pid}）${p.mb}MB`).join('、') || '未找到 QQ Agent 自身进程';
  const gpuTxt = [d.gpu || '未知显卡', d.gpuUse == null ? '' : `占用 ${Math.min(100, Number(d.gpuUse) || 0)}%`].filter(Boolean).join(' · ');
  return {
    text: [
      `【电脑状态（${d.host}）实测值】`,
      `CPU 负载 ${d.cpu}%（单核最高 ${d.coreMax}%）`,
      `内存 已用 ${used.toFixed(1)}GB / 共 ${d.memTotal}GB（空闲 ${d.memFree}GB）`,
      ...diskTxt,
      `显卡 ${gpuTxt}`,
      `开机时长 ${d.upH} 小时 ${d.upM} 分`,
      `最占内存：${topTxt.join('、')}`,
      `QQ Agent 自身：${selfTxt}`,
      '（以上是一次性实测，照实回答，不要复述成猜测。）'
    ].join('\n')
  };
}

async function capProcesses() {
  const r = await runPS(`Get-Process -ErrorAction SilentlyContinue | Sort-Object WS -Descending | Select-Object -First 15 | ForEach-Object { '{0}\t{1}\t{2}' -f $_.ProcessName, $_.Id, [math]::Round($_.WS/1MB) }`);
  if (!r.ok || !r.out) return { err: '查询失败：' + (r.err || '无输出') };
  const rows = r.out.split(/\r?\n/).filter(Boolean).map((l) => {
    const [n, pid, mb] = l.split('\t');
    return `  ${String(mb || '?').padStart(6)}MB  ${n || '?'}(pid ${pid || '?'})`;
  });
  return { text: '内存占用 Top 15：\n' + rows.join('\n') };
}

// ══════════════════════════════════════════════════════════════════════════
// 四、程序：开始菜单应用清单 + 打开 / 结束
// ══════════════════════════════════════════════════════════════════════════
const CATALOG_FILE = () => path.join(DATA_DIR || process.cwd(), `${ID}-apps.json`);
let catalogCache = null;

async function scanApps(force = false) {
  const hours = num(cfg().appCacheHours, 0, 720, 12);
  const fresh = (c) => !!c && Array.isArray(c.items) && c.items.length > 0
    && (hours === 0 ? false : Date.now() - (c.at || 0) < hours * 3600000);
  if (!force && fresh(catalogCache)) return catalogCache;
  if (!force) {
    try {
      const disk = JSON.parse(fs.readFileSync(CATALOG_FILE(), 'utf8'));
      if (fresh(disk)) { catalogCache = disk; return disk; }
    } catch { /* 没缓存就扫 */ }
  }
  const r = await runPS(`
$out = New-Object System.Collections.ArrayList
$sh = New-Object -ComObject WScript.Shell
$dirs = @(
  (Join-Path $env:APPDATA 'Microsoft\\Windows\\Start Menu\\Programs'),
  (Join-Path $env:ProgramData 'Microsoft\\Windows\\Start Menu\\Programs'),
  [Environment]::GetFolderPath('Desktop'),
  (Join-Path $env:PUBLIC 'Desktop')
)
foreach ($d in $dirs) {
  if (-not (Test-Path -LiteralPath $d)) { continue }
  Get-ChildItem -Path $d -Recurse -Filter *.lnk -ErrorAction SilentlyContinue | ForEach-Object {
    try {
      $sc = $sh.CreateShortcut($_.FullName)
      $tp = $sc.TargetPath
      if (-not $tp) { return }
      if (-not (Test-Path -LiteralPath $tp)) { return }
      [void]$out.Add('EXE' + [char]9 + $_.BaseName + [char]9 + $tp + [char]9 + $sc.WorkingDirectory + [char]9 + $sc.Arguments)
    } catch { }
  }
}
Get-StartApps -ErrorAction SilentlyContinue | ForEach-Object {
  [void]$out.Add('APP' + [char]9 + $_.Name + [char]9 + $_.AppID + [char]9 + '' + [char]9 + '')
}
$out -join "\`n"
`, 30000);

  const pretty = (s) => String(s ?? '').replace(/\s*[-–—]\s*(快捷方式|Shortcut)$/i, '').replace(/\.(exe|lnk)$/i, '').trim();
  const items = [];
  const seen = new Set();
  for (const line of String(r.out || '').split(/\r?\n/)) {
    const p = line.split('\t');
    if (p.length < 3) continue;
    const [kind, rawName, target, workdir = '', args = ''] = p;
    const name = pretty(rawName);
    const t = String(target ?? '').trim();
    if (!name || !t) continue;
    const key = `${kind}:${t.toLowerCase()}`;
    if (seen.has(key)) continue;
    seen.add(key);
    items.push({ name, kind: kind === 'EXE' ? 'exe' : 'appid', target: t, workdir: String(workdir || '').trim(), args: String(args || '').trim() });
  }
  const catalog = { at: Date.now(), items: items.sort((a, b) => a.name.localeCompare(b.name, 'zh-CN')) };
  if (catalog.items.length) {
    catalogCache = catalog;
    try { fs.writeFileSync(CATALOG_FILE(), JSON.stringify(catalog), 'utf8'); } catch { /* 缓存写不进不影响用 */ }
    return catalog;
  }
  return catalogCache || catalog;
}

function matchApp(name, items) {
  const key = String(name || '').trim().toLowerCase();
  if (!key) return null;
  const exact = items.find((i) => i.name.toLowerCase() === key);
  if (exact) return exact;
  const starts = items.find((i) => i.name.toLowerCase().startsWith(key));
  if (starts) return starts;
  return items.find((i) => i.name.toLowerCase().includes(key)) || null;
}

async function capApps(action, name) {
  if (action === 'list') {
    const c = await scanApps(false);
    if (!c?.items?.length) return { text: '没扫到可打开的程序（开始菜单为空或 PowerShell 被拦）。也可以直接用系统命令名（notepad、calc 等）打开。' };
    const show = c.items.slice(0, 60).map((i) => i.name);
    return {
      text: `可打开的程序共 ${c.items.length} 个${c.items.length > 60 ? `，先列出前 60 个：\n${show.join('、')}` : `：\n${show.join('、')}`}`
        + '\n（说名字就能打开，例如「打开记事本」。）'
    };
  }
  if (action === 'open') {
    if (cfg().readOnly === true) return { err: '当前是只读模式，不允许打开程序' };
    const c = await scanApps(false);
    const hit = matchApp(name, c?.items || []);
    if (hit?.kind === 'exe') {
      try {
        const child = spawn(hit.target, hit.args ? hit.args.split(/\s+/).filter(Boolean) : [], {
          cwd: hit.workdir || undefined, detached: true, stdio: 'ignore', windowsHide: true
        });
        child.on('error', () => {});
        child.unref();
        return { text: `已打开「${hit.name}」。` };
      } catch (e) {
        return { err: '启动失败：' + (e?.message ?? e) };
      }
    }
    if (hit?.kind === 'appid') {
      try {
        const child = spawn('explorer.exe', [`shell:AppsFolder\\${hit.target}`], { detached: true, stdio: 'ignore', windowsHide: true });
        child.on('error', () => {});
        child.unref();
        return { text: `已打开「${hit.name}」（商店应用）。` };
      } catch (e) {
        return { err: '启动失败：' + (e?.message ?? e) };
      }
    }
    // 没在清单里：退回系统命令名（禁止路径字符，杜绝任意路径执行）
    const raw = String(name || '').trim();
    if (!raw || raw.length > 64 || /[\\/:*?"<>|]/.test(raw)) return { err: '程序名不合法（不允许路径字符）' };
    try {
      const child = spawn('cmd.exe', ['/c', 'start', '', raw], { detached: true, stdio: 'ignore', windowsHide: true });
      child.on('error', () => {});
      child.unref();
      return { text: `已尝试打开「${raw}」（按系统命令名）。` };
    } catch (e) {
      return { err: '启动失败：' + (e?.message ?? e) };
    }
  }
  if (action === 'kill') {
    if (cfg().readOnly === true) return { err: '当前是只读模式，不允许结束程序' };
    if (cfg().allowDangerous !== true) return { err: '结束进程属于高危操作：请到技能设置里打开「允许高危操作」再来' };
    const raw = String(name || '').trim();
    if (!raw || raw.length > 64 || /[\\/:*?"<>|]/.test(raw)) return { err: '进程名不合法（不允许路径字符）' };
    const proc = raw.toLowerCase().endsWith('.exe') ? raw.slice(0, -4) : raw;
    const r = await runPS(`$p = @(Get-Process -Name '${proc.replace(/'/g, "''")}' -ErrorAction SilentlyContinue); if ($p.Count -gt 0) { $p | Stop-Process -Force; Write-Output ("已结束 " + $p.Count + " 个进程") } else { Write-Output '没有找到该进程' }`);
    return r.ok && r.out ? { text: r.out } : { err: '执行失败：' + (r.err || '无输出') };
  }
  return { err: `未知的 apps 动作：${action}` };
}

async function capVolume(action) {
  const VK = { up: 0xAF, down: 0xAE, mute: 0xAD };
  const vk = VK[action];
  if (!vk) return { err: '音量动作只支持 up / down / mute' };
  const step = Math.max(1, Math.min(25, num(cfg().volumeStep, 1, 25, 3)));
  const times = action === 'mute' ? 1 : step;
  const r = await runPS(`
Add-Type -TypeDefinition 'using System;using System.Runtime.InteropServices;public class Vk{[DllImport("user32.dll")]public static extern void keybd_event(byte bVk,byte bScan,uint dwFlags,UIntPtr dwExtraInfo);}'
for($i=0;$i -lt ${times};$i++){ [Vk]::keybd_event(${vk},0,0,[UIntPtr]::Zero); [Vk]::keybd_event(${vk},0,2,[UIntPtr]::Zero) }
Write-Output done
`, 20000);
  if (!r.ok) return { err: '执行失败：' + r.err };
  const label = action === 'up' ? `音量 +${step * 2}%` : action === 'down' ? `音量 -${step * 2}%` : '静音切换';
  return { text: `已执行：${label}` };
}

// ══════════════════════════════════════════════════════════════════════════
// 五、文件（读/写/改/列/找/搜）—— 带目录白名单与黑名单
// ══════════════════════════════════════════════════════════════════════════
function safePath(p) {
  const base = workDirOf();
  const full = path.resolve(path.isAbsolute(String(p || '')) ? String(p) : path.join(base, String(p || '')));
  for (const re of denyRes()) {
    if (re.test(full)) return { ok: false, why: `路径命中黑名单：${full}` };
  }
  const roots = allowedRoots();
  if (roots.length) {
    const inside = roots.some((r) => full.toLowerCase() === r.toLowerCase() || full.toLowerCase().startsWith(r.toLowerCase() + path.sep));
    if (!inside) return { ok: false, why: `路径不在允许的目录里（设置里的「允许访问的目录」），已拒绝：${full}` };
  }
  return { ok: true, path: full };
}

const SKIP_DIRS = new Set(['node_modules', '.git', '.svn', 'dist', '.cache', '$recycle.bin', 'system volume information']);
function walk(dir, out, limit, filterRe) {
  if (out.length >= limit) return;
  let entries = [];
  try { entries = fs.readdirSync(dir, { withFileTypes: true }); } catch { return; }
  for (const e of entries) {
    if (out.length >= limit) return;
    if (e.isDirectory()) {
      if (SKIP_DIRS.has(e.name.toLowerCase())) continue;
      walk(path.join(dir, e.name), out, limit, filterRe);
    } else if (e.isFile()) {
      const full = path.join(dir, e.name);
      if (!filterRe || filterRe.test(full)) out.push(full);
    }
  }
}

function globToRe(pattern) {
  let re = String(pattern || '');
  re = re.replace(/[.+^${}()|[\]\\]/g, '\\$&');
  re = re.replace(/\*\*\//g, '@@').replace(/\*\*/g, '@@');
  re = re.replace(/\*/g, '[^/\\\\]*').replace(/\?/g, '[^/\\\\]').replace(/@@/g, '.*');
  return new RegExp(`${re}$`, 'i');
}

async function capFiles(action, a = {}) {
  if (action === 'list') {
    const g = safePath(a.path || '');
    if (!g.ok) return { err: g.why };
    try {
      const entries = fs.readdirSync(g.path, { withFileTypes: true });
      const rows = entries.slice(0, 200).map((e) => {
        let size = '';
        try {
          const st = fs.statSync(path.join(g.path, e.name));
          size = e.isDirectory() ? '<DIR>' : `${Math.max(1, Math.round(st.size / 1024))}KB`;
        } catch { size = '?'; }
        return `  ${String(size).padStart(8)}  ${e.name}${e.isDirectory() ? '/' : ''}`;
      });
      return { text: `${g.path}（${entries.length} 项${entries.length > 200 ? '，只列前 200' : ''}）：\n${rows.join('\n')}` };
    } catch (e) {
      return { err: '列目录失败：' + (e?.message ?? e) };
    }
  }
  if (action === 'read') {
    const g = safePath(a.path);
    if (!g.ok) return { err: g.why };
    try {
      const st = fs.statSync(g.path);
      if (st.size > 2 * 1048576) return { err: '文件超过 2MB，太长了：请用 offset/limit 分段读，或先搜里面的关键词' };
      const buf = fs.readFileSync(g.path);
      if (buf.includes(0)) return { err: '这是二进制文件（不是文本），读不了内容' };
      const all = buf.toString('utf8').split(/\r?\n/);
      const from = Math.max(1, Number(a.offset) || 1);
      const cnt = Math.max(1, Math.min(2000, Number(a.limit) || 400));
      const slice = all.slice(from - 1, from - 1 + cnt);
      return {
        text: `【${g.path}】共 ${all.length} 行，第 ${from}~${from + slice.length - 1} 行（行号是显示用的，文件里没有）：\n`
          + slice.map((l, i) => `${from + i}| ${l}`).join('\n')
      };
    } catch (e) {
      return { err: '读文件失败：' + (e?.message ?? e) };
    }
  }
  if (action === 'write') {
    if (cfg().readOnly === true || cfg().allowFileWrite === false) return { err: '当前不允许写文件（只读模式或「允许写/改文件」被关）' };
    const g = safePath(a.path);
    if (!g.ok) return { err: g.why };
    try {
      if (fs.existsSync(g.path) && a.overwrite !== true) return { err: '文件已存在：请先读取确认，或传 overwrite=true 覆盖' };
      fs.mkdirSync(path.dirname(g.path), { recursive: true });
      fs.writeFileSync(g.path, String(a.content ?? ''), 'utf8');   // 无 BOM：JSON.parse 不认 BOM
      return { text: `已写入 ${g.path}（${String(a.content ?? '').length} 字符）。` };
    } catch (e) {
      return { err: '写文件失败：' + (e?.message ?? e) };
    }
  }
  if (action === 'edit') {
    if (cfg().readOnly === true || cfg().allowFileWrite === false) return { err: '当前不允许改文件（只读模式或「允许写/改文件」被关）' };
    const g = safePath(a.path);
    if (!g.ok) return { err: g.why };
    try {
      const src = fs.readFileSync(g.path, 'utf8');
      const oldStr = String(a.old_string ?? '');
      if (!oldStr) return { err: '缺少 old_string' };
      const count = src.split(oldStr).length - 1;
      if (count === 0) return { err: '没找到要替换的原文（必须和文件里一字不差，别带行号前缀）' };
      if (count > 1 && a.replace_all !== true) return { err: `这段原文出现了 ${count} 次：请把上下文写长到唯一，或传 replace_all=true 全部替换` };
      const next = a.replace_all === true ? src.split(oldStr).join(String(a.new_string ?? '')) : src.replace(oldStr, String(a.new_string ?? ''));
      fs.writeFileSync(g.path, next, 'utf8');
      return { text: `已改 ${g.path}（替换 ${a.replace_all === true ? count : 1} 处）。` };
    } catch (e) {
      return { err: '改文件失败：' + (e?.message ?? e) };
    }
  }
  if (action === 'glob') {
    const base = safePath(a.path || '');
    if (!base.ok) return { err: base.why };
    const limit = Math.max(1, Math.min(2000, Number(a.limit) || 200));
    const re = globToRe(a.pattern || '');
    const out = [];
    walk(base.path, out, limit, re);
    return { text: out.length ? `找到 ${out.length} 个：\n${out.map((p) => '  ' + p).join('\n')}` : '没有匹配的文件' };
  }
  if (action === 'search') {
    const base = safePath(a.path || '');
    if (!base.ok) return { err: base.why };
    let re;
    try { re = new RegExp(String(a.pattern || ''), a.ignoreCase === true ? 'gi' : 'g'); } catch { return { err: 'pattern 不是合法正则' }; }
    const limit = Math.max(1, Math.min(500, Number(a.limit) || 100));
    const globRe = a.glob ? globToRe(a.glob) : null;
    const files = [];
    walk(base.path, files, 800, globRe);
    const hits = [];
    for (const f of files) {
      if (hits.length >= limit) break;
      try {
        const st = fs.statSync(f);
        if (st.size > 1048576) continue;
        const buf = fs.readFileSync(f);
        if (buf.includes(0)) continue;
        const linesArr = buf.toString('utf8').split(/\r?\n/);
        for (let i = 0; i < linesArr.length && hits.length < limit; i += 1) {
          re.lastIndex = 0;
          if (re.test(linesArr[i])) hits.push(`${f}:${i + 1}: ${linesArr[i].slice(0, 300)}`);
        }
      } catch { /* 读不了的跳过 */ }
    }
    return { text: hits.length ? `命中 ${hits.length} 行：\n${hits.join('\n')}` : '没有搜到匹配内容' };
  }
  return { err: `未知的 files 动作：${action}` };
}

// ══════════════════════════════════════════════════════════════════════════
// 六、命令 + 后台任务
// ══════════════════════════════════════════════════════════════════════════
const JOBS = new Map();
let jobSeq = 0;
const jobsDir = () => path.join(DATA_DIR || process.cwd(), `${ID}-jobs`);

function killTree(pid) {
  try {
    execFile('taskkill', ['/pid', String(pid), '/t', '/f'], { windowsHide: true }, () => {});
  } catch { /* 杀不掉就算了 */ }
}

function runCommand(command, { cwd, timeoutSec }) {
  return new Promise((resolve) => {
    const started = Date.now();
    const child = spawn('powershell.exe', ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-Command', command], {
      cwd: cwd || workDirOf(), windowsHide: true
    });
    let out = '';
    let done = false;
    const finish = (text) => { if (!done) { done = true; resolve(text); } };
    const timer = setTimeout(() => {
      killTree(child.pid);
      finish(`${out}\n[已超时 ${timeoutSec} 秒，已终止该命令及其子进程]`);
    }, timeoutSec * 1000);
    const cap = num(cfg().maxOutputKB, 4, 1024, 64) * 1024;
    const push = (s) => { if (out.length < cap) out += s; };
    child.stdout?.on('data', (d) => push(String(d)));
    child.stderr?.on('data', (d) => push(String(d)));
    child.on('error', (e) => { clearTimeout(timer); finish('执行出错：' + (e?.message ?? e)); });
    child.on('close', (code) => {
      clearTimeout(timer);
      const text = out.length > cap ? out.slice(0, cap) + `\n[输出超过 ${num(cfg().maxOutputKB, 4, 1024, 64)}KB，已截断]` : out;
      finish(`${text || '（命令没有输出）'}\n[exit code: ${code}]（耗时 ${Math.round((Date.now() - started) / 1000)} 秒）`);
    });
  });
}

function startJob(command, cwd) {
  jobSeq += 1;
  const id = `j${jobSeq}`;
  const dir = jobsDir();
  try { fs.mkdirSync(dir, { recursive: true }); } catch { /* 建不了就只留内存输出 */ }
  const file = path.join(dir, `${id}.log`);
  const ws = fs.createWriteStream(file, { flags: 'a' });
  const child = spawn('powershell.exe', ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-Command', command], {
    cwd: cwd || workDirOf(), windowsHide: true
  });
  child.stdout?.pipe(ws);
  child.stderr?.pipe(ws);
  const job = { id, command, pid: child.pid, startedAt: Date.now(), file, status: 'running', cursor: 0, exit: null };
  JOBS.set(id, job);
  child.on('close', (code) => {
    job.status = 'done';
    job.exit = code;
    try { ws.end(); } catch { /* ignore */ }
  });
  child.on('error', () => { job.status = 'error'; });
  return job;
}

function readJob(id, full) {
  const job = JOBS.get(String(id || ''));
  if (!job) return { err: `没有任务 ${id}（用 jobs 看看有哪些）` };
  let text = '';
  try { text = fs.readFileSync(job.file, 'utf8'); } catch { text = ''; }
  const maxKB = 64;
  if (full === true) {
    return { text: `【任务 ${job.id} · ${job.status}】\n${text.slice(-maxKB * 1024) || '（还没有输出）'}` };
  }
  const from = job.cursor || 0;
  job.cursor = Buffer.byteLength(text, 'utf8');
  const fresh = text.slice(from);
  return {
    text: `【任务 ${job.id} · ${job.status}${job.status === 'running' ? `，已跑 ${Math.round((Date.now() - job.startedAt) / 1000)} 秒` : ''}】\n`
      + (fresh ? fresh.slice(-maxKB * 1024) : '（暂无新输出）')
  };
}

async function capCommand(action, a = {}) {
  if (action === 'jobs') {
    if (!JOBS.size) return { text: '没有后台任务。' };
    return {
      text: JOBS.size + ' 个任务：\n' + [...JOBS.values()].map((j) => `  ${j.id} · ${j.status} · ${Math.round((Date.now() - j.startedAt) / 1000)}s · ${j.command.slice(0, 60)}`).join('\n')
    };
  }
  if (action === 'output') return readJob(a.job_id, a.full === true);
  if (action === 'kill') {
    const job = JOBS.get(String(a.job_id || ''));
    if (!job) return { err: `没有任务 ${a.job_id}` };
    killTree(job.pid);
    job.status = 'killed';
    return { text: `已终止任务 ${job.id}（连同它的子进程）。` };
  }
  if (action === 'run') {
    if (cfg().readOnly === true) return { err: '当前是只读模式，不允许执行命令' };
    if (cfg().allowCommand === false) return { err: '「允许执行命令」被关掉了，当前不能跑命令' };
    const cmd = String(a.command || '').trim();
    if (!cmd) return { err: '缺少 command' };
    const low = cmd.toLowerCase();
    const hit = commandDenyList().find((w) => low.includes(w));
    if (hit) return { err: `命令命中黑名单（${hit}），已拒绝。这不是限制你，是防止误操作毁机器；被拒就如实说，不要换个写法绕。` };
    const cwd = a.cwd ? (safePath(a.cwd).ok ? safePath(a.cwd).path : undefined) : workDirOf();
    const timeoutSec = Math.max(1, Math.min(1800, Number(a.timeoutSec) || num(cfg().commandTimeoutSec, 1, 1800, 120)));
    if (a.background === true) {
      const job = startJob(cmd, cwd);
      return { text: `已转入后台，任务号 ${job.id}。用 jobs 看列表、output 看进度、kill 停掉它。` };
    }
    const out = await runCommand(cmd, { cwd, timeoutSec });
    return { text: out };
  }
  return { err: `未知的 command 动作：${action}` };
}

// ══════════════════════════════════════════════════════════════════════════
// 七、媒体：看图 / 下载
// ══════════════════════════════════════════════════════════════════════════
async function capMedia(action, a = {}) {
  if (action === 'view') {
    const g = safePath(a.path);
    if (!g.ok) return { err: g.why };
    try {
      const buf = fs.readFileSync(g.path);
      const mod = await import('electron');
      const electron = mod?.default ?? mod;
      let b64 = buf.toString('base64');
      let mime = 'image/png';
      const ext = path.extname(g.path).toLowerCase();
      if (['.jpg', '.jpeg'].includes(ext)) mime = 'image/jpeg';
      else if (ext === '.gif') mime = 'image/gif';
      else if (ext === '.webp') mime = 'image/webp';
      if (electron?.nativeImage && buf.length > 300 * 1024) {
        const img = electron.nativeImage.createFromBuffer(buf);
        const w = img.getSize().width;
        if (w > 1280) {
          b64 = img.resize({ width: 1280 }).toPNG().toString('base64');
          mime = 'image/png';
        }
      }
      return {
        parts: [
          { type: 'text', text: `已读取图片 ${g.path}（${Math.max(1, Math.round(buf.length / 1024))} KB）。请直接看这张图。` },
          { type: 'image_url', image_url: { url: `data:${mime};base64,${b64}` } }
        ]
      };
    } catch (e) {
      return { err: '读图失败：' + (e?.message ?? e) };
    }
  }
  if (action === 'download') {
    if (cfg().readOnly === true || cfg().allowFileWrite === false) return { err: '当前不允许写文件（只读模式或「允许写/改文件」被关）' };
    const g = safePath(a.path);
    if (!g.ok) return { err: g.why };
    const url = String(a.url || '').trim();
    if (!/^https?:\/\//i.test(url)) return { err: '只支持 http/https 地址' };
    const maxBytes = num(a.maxMB, 1, 2048, 64) * 1048576;
    try {
      const res = await fetch(url, { redirect: 'follow' });
      if (!res.ok) return { err: `下载失败：HTTP ${res.status}` };
      const buf = Buffer.from(await res.arrayBuffer());
      if (buf.length > maxBytes) return { err: `文件超过 ${num(a.maxMB, 1, 2048, 64)} MB 上限（实际 ${Math.round(buf.length / 1048576)} MB）` };
      fs.mkdirSync(path.dirname(g.path), { recursive: true });
      fs.writeFileSync(g.path, buf);
      return { text: `已下载到 ${g.path}（${Math.round(buf.length / 1024)} KB）。` };
    } catch (e) {
      return { err: '下载失败：' + (e?.message ?? e) };
    }
  }
  return { err: `未知的 media 动作：${action}` };
}

// ══════════════════════════════════════════════════════════════════════════
// 八、系统杂项：回收站 / 环境信息
// ══════════════════════════════════════════════════════════════════════════
async function capSystem(action) {
  if (action === 'recycle') {
    if (cfg().readOnly === true) return { err: '当前是只读模式，不能清回收站' };
    if (cfg().allowDangerous !== true) return { err: '清回收站属于高危操作：请到技能设置里打开「允许高危操作」，并在话里明确说「确认清空回收站」' };
    const r = await runPS(`Clear-RecycleBin -Force -ErrorAction SilentlyContinue; Write-Output done`, 60000);
    return r.ok ? { text: '已清空回收站。' } : { err: '执行失败：' + r.err };
  }
  if (action === 'info') {
    const roots = allowedRoots();
    return {
      text: [
        `工作目录：${workDirOf()}`,
        `只读模式：${cfg().readOnly === true ? '开（能看不能动）' : '关（可写可执行）'}`,
        `允许写文件：${cfg().allowFileWrite === false ? '否' : '是'}；允许执行命令：${cfg().allowCommand === false ? '否' : '是'}；高危操作：${cfg().allowDangerous === true ? '允许（杀进程/清回收站）' : '禁止'}`,
        `可访问目录：${roots.length ? roots.join('、') : '不限制（整机）'}`,
        `路径黑名单：${denyRes().length} 条；命令黑名单：${commandDenyList().length} 条`,
        `命令超时 ${num(cfg().commandTimeoutSec, 1, 1800, 120)} 秒；输出上限 ${num(cfg().maxOutputKB, 4, 1024, 64)} KB`,
        `后台任务 ${JOBS.size} 个；审计日志 ${auditFile()}`
      ].join('\n')
    };
  }
  return { err: `未知的 system 动作：${action}` };
}

// ══════════════════════════════════════════════════════════════════════════
// 九、工具注册（九个，全部经过同一道闸）
// ══════════════════════════════════════════════════════════════════════════
const OWNER = '只有主人可以用，其他人开口一律拒绝。';

/** pc-control 自己的清单，用来取它各项设置的默认值 */
function remoteManifest() {
  for (const f of ['plugin.json', 'skill.json']) {
    try { return JSON.parse(fs.readFileSync(path.join(DIRECT.dir, f), 'utf8')); } catch { /* 试下一个 */ }
  }
  return {};
}

/** 喂给 pc-control 的配置 = 它清单里的默认值 + 本技能卡片上 remote.* 那几项 */
function remoteConfig() {
  const mine = (typeof cfg === 'function' ? (cfg() || {}) : {});
  const out = { ...(remoteManifest().settings || {}) };
  for (const [k, v] of Object.entries(mine)) {
    if (k.startsWith('remote.')) out[k.slice('remote.'.length)] = v;
  }
  out.enabled = true;   // 启停统一由本技能的开关管，它自带的 enabled 不再单独生效
  return out;
}

function remoteStillOn() {
  const s = (getConfig().skills || {})[DIRECT.id] || {};
  return s.enabled !== false;   // 没配过 = 默认启用
}

export function setup(api) {
  cfg = () => (typeof api?.config === 'function' ? (api.config() || {}) : {});
  log = (...a) => api.log?.(...a);
  apiRef = api;

  // ── 接管「\电脑」直达指令通道 ────────────────────────────────────────────
  directLive = false;
  if (directErr) {
    log(`⚠️ 直达指令层没加载起来：${directErr}`);
  } else if (remoteStillOn()) {
    log('⚠️ 暂不接管「\\电脑」直达指令：pc-control 自己还是启用状态，两边都挂 onMessage 会执行两次。'
      + '请到控制台把「pc-control」关掉 —— 它的设置已并入「电脑全能操控」卡片的「直达指令」分组，关掉不丢配置；关掉后热重载，这里自动接管。');
  } else {
    try {
      directMod.setup({ ...api, config: remoteConfig, registerTool: () => {} });
      directLive = true;
      log('已接管「\\电脑」直达指令（截图/状态/进程/音量/开关程序/清回收站）');
    } catch (e) {
      log(`接管「\\电脑」直达指令失败：${e?.message ?? e}`);
    }
  }

  /** 统一外壳：过闸 → 执行 → 记审计 → 归一化返回 */
  const T = (def) => api.registerTool({
    category: 'system',
    ...def,
    async execute(ctx, args) {
      const g = gate(ctx, def.id);
      if (!g.ok) {
        // 不是出错，是"直达通道已经办过了"—— 平静地告诉模型别重复，别当错误报。
        if (g.why === 'SKIP_DIRECT') {
          return { content: '（这条指令已由 \\电脑 直达通道执行过，这里跳过，不要重复执行。）' };
        }
        audit(ctx?.chatKey, '', 'tool:' + def.id, g.why);
        return { content: g.why, isError: true };
      }
      let r;
      try {
        r = await def.run(ctx, args || {});
      } catch (e) {
        r = { err: '执行出错：' + (e?.message ?? e) };
      }
      const text = r?.err ? r.err : (r?.parts ? '(图片)' : r?.text || '完成');
      audit(ctx?.chatKey, g.uid, 'tool:' + def.id, r?.err ? '失败：' + text : String(text).slice(0, 120));
      if (r?.err) return { content: r.err, isError: true };
      if (r?.parts) return { content: r.parts };
      return { content: r.text };
    }
  });

  T({
    id: 'screen',
    name: '看屏幕',
    icon: '👀',
    description: '截取机器人所在电脑的当前屏幕。mode=look：图直接进你的视野（你要靠它判断点哪里，返回文本会给出截图尺寸与屏幕物理分辨率的换算公式）；mode=send：把截图发到当前会话给主人看。' + OWNER,
    parameters: {
      type: 'object',
      properties: {
        mode: { type: 'string', enum: ['look', 'send'], description: 'look=图进你视野（默认）；send=把截图发到会话里' }
      }
    },
    run: (ctx, args) => capScreen(args?.mode === 'send' ? 'send' : 'look', ctx)
  });

  T({
    id: 'mouse',
    name: '动鼠标',
    icon: '🖱',
    description: '操控机器人所在电脑的鼠标（物理像素坐标，左上角 0,0）。action：position 查当前坐标与屏幕分辨率；move 移动；click 单击左键；double 双击；right 右键；middle 中键；drag 按住左键从 from 拖到 to；scroll 滚轮（notches 正数向上/向右，负数向下/向左，direction 可选 horizontal）。先看屏幕确认目标位置再动手。' + OWNER,
    parameters: {
      type: 'object',
      properties: {
        action: { type: 'string', enum: ['position', 'move', 'click', 'double', 'right', 'middle', 'drag', 'scroll'], description: '要做什么' },
        x: { type: 'integer', description: '目标横坐标（move/click/double/right/middle 用）' },
        y: { type: 'integer', description: '目标纵坐标' },
        fromX: { type: 'integer', description: 'drag 起点横坐标' },
        fromY: { type: 'integer', description: 'drag 起点纵坐标' },
        toX: { type: 'integer', description: 'drag 终点横坐标' },
        toY: { type: 'integer', description: 'drag 终点纵坐标' },
        notches: { type: 'integer', description: 'scroll 滚几格（-20~20）' },
        direction: { type: 'string', enum: ['vertical', 'horizontal'], description: 'scroll 方向，默认 vertical' }
      },
      required: ['action']
    },
    run: (_ctx, args) => capMouse(String(args?.action || ''), args)
  });

  T({
    id: 'status',
    name: '查电脑状态',
    icon: '🖥️',
    description: '查机器人所在这台 Windows 电脑的实时状态（一次性实测值，不要凭印象猜）。target 填 system（或留空）= 整机：CPU 负载与单核最高、内存、各盘剩余、显卡型号与占用、开机时长、最占内存的五个程序、QQ Agent 自身占用；target 填软件名（如「微信」「Chrome」）= 只看该软件的进程数、合计内存、开了多久。' + OWNER,
    parameters: {
      type: 'object',
      properties: {
        target: { type: 'string', description: 'system=整机概况（默认）；或填软件名看单个软件' }
      }
    },
    run: (_ctx, args) => capStatus(String(args?.target || 'system'))
  });

  T({
    id: 'apps',
    name: '开关程序',
    icon: '🚀',
    description: '管理机器人所在电脑上的程序（会扫描开始菜单做成清单）。action=list 列出可打开的程序；open 按名字打开（也接受 notepad/calc 这类系统命令名）；kill 按进程名结束（需要设置里允许高危操作）。' + OWNER,
    parameters: {
      type: 'object',
      properties: {
        action: { type: 'string', enum: ['list', 'open', 'kill'], description: 'list=列清单；open=打开；kill=结束' },
        name: { type: 'string', description: '程序名或进程名（open/kill 必填）' }
      },
      required: ['action']
    },
    run: (_ctx, args) => capApps(String(args?.action || ''), args?.name)
  });

  T({
    id: 'volume',
    name: '调音量',
    icon: '🔊',
    description: '调机器人所在电脑的系统音量。action：up 调大、down 调小、mute 静音切换。' + OWNER,
    parameters: {
      type: 'object',
      properties: { action: { type: 'string', enum: ['up', 'down', 'mute'], description: 'up/down/mute' } },
      required: ['action']
    },
    run: (_ctx, args) => capVolume(String(args?.action || 'up'))
  });

  T({
    id: 'files',
    name: '文件读写',
    icon: '📁',
    description: '在机器人所在电脑上处理文件。action：read 读文本（带行号，可用 offset/limit 分段）；write 新建或覆盖（已存在需 overwrite=true）；edit 局部替换（old_string→new_string，默认要求唯一）；list 列目录；glob 按通配符找文件（如 **/*.js）；search 按正则搜文件内容。受设置里的目录白名单与黑名单约束。' + OWNER,
    parameters: {
      type: 'object',
      properties: {
        action: { type: 'string', enum: ['read', 'write', 'edit', 'list', 'glob', 'search'], description: '要做什么' },
        path: { type: 'string', description: '文件或目录路径（相对路径以工作目录为基准）' },
        content: { type: 'string', description: 'write 时要写入的完整内容' },
        overwrite: { type: 'boolean', description: 'write 时覆盖已存在文件' },
        old_string: { type: 'string', description: 'edit 时要被替换的原文（一字不差）' },
        new_string: { type: 'string', description: 'edit 时替换成什么（删掉就传空）' },
        replace_all: { type: 'boolean', description: 'edit 时全部替换' },
        pattern: { type: 'string', description: 'glob 的通配符 或 search 的正则表达式' },
        glob: { type: 'string', description: 'search 时把范围收窄到匹配的文件' },
        offset: { type: 'integer', description: 'read 从第几行开始（从 1 开始）' },
        limit: { type: 'integer', description: 'read 最多读几行；glob/search 最多返回多少条' },
        ignoreCase: { type: 'boolean', description: 'search 忽略大小写' }
      },
      required: ['action']
    },
    run: (_ctx, args) => capFiles(String(args?.action || ''), args)
  });

  T({
    id: 'command',
    name: '跑命令',
    icon: '⚙️',
    description: '在机器人所在电脑上执行 PowerShell 命令（真跑，不是模拟）。action=run：等它跑完拿结果；可能很久的任务传 background=true 转后台，立刻拿到任务号，再用 jobs/output/kill 管理。命中命令黑名单会被拒绝（被拒就如实说，不要绕）。' + OWNER,
    parameters: {
      type: 'object',
      properties: {
        action: { type: 'string', enum: ['run', 'jobs', 'output', 'kill'], description: 'run=执行；jobs=列后台任务；output=看输出；kill=终止' },
        command: { type: 'string', description: 'run 时要执行的命令（PowerShell 语法）' },
        cwd: { type: 'string', description: '在哪个目录执行，默认工作目录' },
        timeoutSec: { type: 'integer', description: '超时秒数（默认取设置，最长 1800）' },
        background: { type: 'boolean', description: 'true=转后台跑，立刻返回任务号' },
        job_id: { type: 'string', description: 'output/kill 用的任务号，如 j1' },
        full: { type: 'boolean', description: 'output 时 true=从头看全部（默认只看新内容）' }
      },
      required: ['action']
    },
    run: (_ctx, args) => capCommand(String(args?.action || ''), args)
  });

  T({
    id: 'media',
    name: '看图与下载',
    icon: '🖼️',
    description: 'action=view 读本机一张图片让**你自己看**（进视野，超过 1280 宽会自动压缩）；action=download 把一个 http/https 文件下载到本机指定路径（有大小上限）。' + OWNER,
    parameters: {
      type: 'object',
      properties: {
        action: { type: 'string', enum: ['view', 'download'], description: 'view=看图；download=下载' },
        path: { type: 'string', description: 'view 的图片路径 / download 的保存路径' },
        url: { type: 'string', description: 'download 的地址' },
        maxMB: { type: 'integer', description: 'download 大小上限 MB（默认 64）' }
      },
      required: ['action']
    },
    run: (_ctx, args) => capMedia(String(args?.action || ''), args)
  });

  T({
    id: 'system',
    name: '系统杂项',
    icon: '🧰',
    description: 'action=processes 看内存占用最高的 15 个进程；action=info 看当前工作目录与安全开关（只读模式、可访问目录、黑名单、审计位置）；action=recycle 清空回收站（需要设置里允许高危操作，且主人明确要求）。' + OWNER,
    parameters: {
      type: 'object',
      properties: { action: { type: 'string', enum: ['processes', 'info', 'recycle'], description: 'processes/info/recycle' } },
      required: ['action']
    },
    run: async (_ctx, args) => {
      const act = String(args?.action || '');
      if (act === 'processes') return capProcesses();
      return capSystem(act);
    }
  });

  log('电脑全能操控已加载（范围：%s；只读：%s；工作目录：%s）',
    cfg().scope === 'all' ? '私聊+群' : '仅主人私聊',
    cfg().readOnly === true ? '开' : '关',
    workDirOf());
}

/** 直达指令转发：主人发「\电脑 截图」这类口令时，不经过模型，当场执行。 */
export const hooks = {
  onMessage: (ctx) => {
    if (!directLive) return;
    try { return directMod.hooks?.onMessage?.(ctx); } catch (e) {
      log(`\\电脑 直达指令出错：${e?.message ?? e}`);
    }
  }
};

function stopDirect(why) {
  if (!directLive) return;
  directLive = false;
  try { directMod.deactivate?.(why); } catch { /* ignore */ }
  try { directMod.dispose?.(); } catch { /* ignore */ }
}

export function deactivate() {
  for (const j of JOBS.values()) {
    if (j.status === 'running') killTree(j.pid);
  }
  JOBS.clear();
  stopDirect('技能被停用/重载');
}

export function dispose() { deactivate(); }

export const internals = { gate, safePath, capMouse, capScreen, capStatus, capApps, capFiles, capCommand, capMedia, capSystem, scanApps, matchApp };
