# 全局记忆查询（global-short-memory-lookup）

让机器人能主动翻「全局短期记忆」：白名单里的其它群/私聊最近说过的话。

## 做什么

提供一个只读工具 `short_memory_query`：

- `chatKey`：只看某个会话（`group:群号` / `private:QQ号`）
- `keyword`：关键词过滤（正文 / 发送者 / 会话名）
- `since`：只看某时间之后（毫秒时间戳或 ISO 时间）
- `limit`：返回条数，默认 30
- `includeSelf`：是否包含机器人自己的发言，默认包含

查不到时会明确告诉你**为什么**空：白名单没配 / 还没攒到 / 过滤没命中。

## 安装

把本目录放进 QQ-Agent 的 `resources/app/skills/global-short-memory-lookup/`，重启应用。

## 依赖

- 需要同时安装 **global-short-memory** 插件才有数据；不装也能装，只是永远返回「还没记录」。

## 设置

| 设置 | 说明 |
|---|---|
| `defaultLimit` | 调用时没指定 limit 时用这个值，默认 30 |

## 隐私

- 只读本地文件 `data/global-short-memory.json`
- 不联网、不上传
