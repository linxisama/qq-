// global-short-memory-lookup —— 让模型主动翻「全局短期记忆」
//
// 只读：只读 data/global-short-memory.json（由 global-short-memory 插件写入）。记录永远归插件管。
import fs from 'node:fs';
import path from 'node:path';
import { DATA_DIR, getConfig } from '../../src/config.js';

const SKILL_ID = 'global-short-memory-lookup';
const TOOL_ID = 'short_memory_query';
const DATA_FILE = path.join(DATA_DIR, 'global-short-memory.json');

let apiRef = null;
let toolId = '';
let log = (...args) => console.warn(`[${SKILL_ID}]`, ...args);
const clamp = (v, lo, hi) => Math.min(hi, Math.max(lo, v));

function settings() {
  const raw = (apiRef && typeof apiRef.config === 'function' ? apiRef.config() : null) || {};
  return { defaultLimit: clamp(Math.round(Number(raw.defaultLimit) || 30), 1, 200) };
}

/** 插件的配置（白名单、模式）用于"为什么是空的"的诊断，不参与过滤逻辑。 */
function pluginConfig() {
  try {
    const c = getConfig() || {};
    return (c.skills || {})['global-short-memory'] || {};
  } catch {
    return {};
  }
}

const splitIds = (raw) => String(raw ?? '').split(/[,，、;；\s]+/).map((x) => x.trim()).filter((x) => /^\d+$/.test(x));

function loadEntries() {
  try {
    const raw = JSON.parse(fs.readFileSync(DATA_FILE, 'utf8'));
    return raw && Array.isArray(raw.entries) ? raw.entries.filter((e) => e && typeof e === 'object') : [];
  } catch {
    return [];
  }
}

const pad2 = (n) => String(n).padStart(2, '0');
const timeText = (ms) => {
  const d = new Date(ms);
  return `${pad2(d.getMonth() + 1)}-${pad2(d.getDate())} ${pad2(d.getHours())}:${pad2(d.getMinutes())}`;
};

function formatEntry(e) {
  const who = e.isSelf ? '我' : `${e.senderName || e.senderId || '未知'}${e.senderId ? `(${e.senderId})` : ''}`;
  const tag = e.isOwner ? '【机主】' : (e.senderRole === 'owner' ? '【群主】' : (e.senderRole === 'admin' ? '【管理员】' : ''));
  return `[${timeText(e.time)}] ${e.chatName || e.chatKey}｜${tag}${who}：${e.text}`;
}

function toTime(value) {
  if (value === undefined || value === null || value === '') return null;
  if (typeof value === 'number' && Number.isFinite(value)) return value;
  const parsed = Date.parse(String(value));
  return Number.isFinite(parsed) ? parsed : null;
}

async function runQuery(ctx = {}, args = {}) {
  try {
    const all = loadEntries();
    const limit = clamp(Math.round(Number(args?.limit) || settings().defaultLimit), 1, 200);
    const since = toTime(args?.since);
    const keyword = String(args?.keyword ?? '').trim().toLowerCase();
    const chatKey = String(args?.chatKey ?? '').trim();
    const includeSelf = args?.includeSelf !== false;
    const hits = all.filter((e) => {
      if (!includeSelf && e.isSelf) return false;
      if (chatKey && e.chatKey !== chatKey) return false;
      if (since !== null && Number(e.time) < since) return false;
      if (keyword) {
        const hay = `${e.text}\n${e.senderName}\n${e.chatName}`.toLowerCase();
        if (!hay.includes(keyword)) return false;
      }
      return true;
    });
    const rows = hits.slice(-limit);
    if (rows.length) {
      return { content: `最近的 ${rows.length} 条（总共 ${all.length} 条）：\n${rows.map(formatEntry).join('\n')}` };
    }
    // 空结果要说清"为什么空"，否则很容易被当成功能坏了
    const cfg = pluginConfig();
    const groups = splitIds(cfg.allowGroups);
    const privates = splitIds(cfg.allowPrivate);
    let hint;
    if (!all.length) {
      hint = (!groups.length && !privates.length)
        ? '短期记忆的白名单是空的（插件「全局短期记忆」里没配群/私聊），所以什么都没记。'
        : `白名单已配（groups=[${groups.join(',')}] private=[${privates.join(',')}]），但还没有记录：日志从插件启用后开始攒。`;
    } else {
      hint = '有记录，但当前过滤条件没命中（可以去掉 chatKey/keyword/since 再试）。';
    }
    return { content: `（没有匹配的记录）\n${hint}` };
  } catch (error) {
    return { content: `查全局记忆失败：${error?.message ?? error}`, isError: true };
  }
}

export function setup(api = {}) {
  apiRef = api;
  if (typeof api.log === 'function') log = (...args) => api.log(...args);
  try {
    const registered = api.registerTool({
      id: TOOL_ID,
      name: '查全局记忆',
      description: '翻「全局短期记忆」：白名单里的其它群/私聊最近说过的话（按时间滚动保存，超出上限会丢最旧的）。'
        + '当有人问「别的群在聊什么」「他们那边怎么说」、你想举例或对比别处情况时用它；拿不准某件事是不是在别处聊过也查一下。'
        + '只读；返回的是记录原文，引用时说清是哪个群、谁说的，别把别处的私聊内容搬到当前群。',
      category: 'query',
      icon: '🗂️',
      parameters: {
        type: 'object',
        properties: {
          chatKey: { type: 'string', description: '只看某个会话，格式 group:群号 或 private:QQ号' },
          keyword: { type: 'string', description: '关键词过滤（在正文/发送者/会话名里找）' },
          since: { type: ['integer', 'string'], description: '只看这个时间之后的（毫秒时间戳或 ISO 时间）' },
          limit: { type: 'number', description: '最多返回多少条，默认 30' },
          includeSelf: { type: 'boolean', description: '是否包含机器人自己说的话，默认包含' }
        }
      },
      async execute(ctx, args) {
        return runQuery(ctx, args);
      }
    });
    if (typeof registered === 'string' && registered.trim()) toolId = registered.trim();
    log(`v1.0.0 已启用：工具 ${toolId || TOOL_ID}，数据 ${DATA_FILE}`);
  } catch (error) {
    log('注册工具失败：', error?.message ?? error);
  }
}

export function available() {
  return { ok: true };
}

export function dispose() {
  toolId = '';
}

export { runQuery, formatEntry, loadEntries };
