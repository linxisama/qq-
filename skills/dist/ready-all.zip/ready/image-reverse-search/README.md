# 以图搜图（找原图出处·多引擎）

别人发图问「这图哪来的 / 求出处 / 画师是谁」时，把图**同时**丢给多个搜图引擎，结果**跨引擎按相似度统一排序并标注来源**，并把相似度最高的那张图取回来发出去。

## 引擎

- **SauceNAO**（免 API key，网页版）
- **IQDB**（图库互补：Danbooru / Gelbooru / yande.re）
- 3D-IQDB（可选，默认关，收手办/3D 图）
- ascii2d 全站 Cloudflare 挡自动化，只保留人工直链

## 用法

发一张图，说「这图哪来的」即可。工具会自己把结论 + 图发到当前会话。

## 特点

- **诚实标注**：引擎自己写着「没有精确匹配」时，结果会标 `[IQDB·相似]` 并说明「只是长得像、不能当出处」；
- **取原图**：匹配到 Pixiv / Danbooru 作品时优先取原图，取不到才退回缩略图（并注明）；
- **降级**：某一家限流/挂了只记一条 ⚠️，其余引擎照常出结果；
- 附 Google Lens / Yandex / TinEye / IQDB / 3D-IQDB / Bing / trace.moe 直链。

## 主要设置

| 键 | 默认 | 说明 |
|---|---|---|
| `maxResults` | 5 | 最多回几条 |
| `minSimilarity` | 50 | 相似度门槛（%） |
| `useIqdb` / `useIqdb3d` | true / false | 是否合并 IQDB / 3D-IQDB |
| `showEngineLinks` | true | 附搜图直链 |

## 注意

- 需要联网（直连即可，家里代理在路由器上时不用填代理）；
- SauceNAO 连测会被限流（HTTP 429），多引擎架构下不影响出图。
