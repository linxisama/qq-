// 以图搜图（LLM 型技能 · registerTool）
//
// 做法：把消息里的图取下来 → POST 给 SauceNAO 网页版（**不需要 API key**，匿名可用）→
// 解析结果（相似度 / 标题 / 出处链接 / 作者）。
//
// 关键发现（2026-10-09 实测）：SauceNAO 会把**上传的图公开托管**几小时，
// 结果页里就有 `https://saucenao.com/userdata/xxx.jpg.png`。而 Google Lens / Yandex / TinEye /
// IQDB / ascii2d / trace.moe **都支持按 URL 搜图** —— 所以只要拿到这个公开链接，
// 就能一次性生成整套搜图直链，**不用自己搭图床**（那个 Telegram bot 的"详细搜索 url"就是这么来的）。
//
// 注意：本机（用户家）代理在**路由器**上 → 这里一律**直连**，不要填本地代理。
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';

let cfg = () => ({});
let log = () => {};
let warn = () => {};

const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36';

function dataDir() {
  return process.env.QQ_AGENT_DATA_DIR || path.resolve(process.cwd(), 'data');
}

function mediaDir() {
  const d = path.join(dataDir(), 'image-reverse-search');
  fs.mkdirSync(d, { recursive: true });
  return d;
}

function num(v, lo, hi, dflt) {
  const n = Number(v);
  if (!Number.isFinite(n)) return dflt;
  return Math.min(hi, Math.max(lo, Math.round(n)));
}

function unescapeHtml(s) {
  return String(s ?? '')
    .replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/&nbsp;/g, ' ')
    .replace(/\s+/g, ' ').trim();
}

/** fetch 的代理参数：只认 http(s) 代理；socks5 直接忽略（Node 的 fetch 不支持）。 */
function proxyOf(c) {
  const p = String(c?.proxy || '').trim();
  if (!p) return null;
  if (/^socks/i.test(p)) { warn(`技能设置里的代理是 ${p}，但 Node 的 fetch 不支持 socks5，本次按直连处理`); return null; }
  return p;
}

// ── 找图：从会话存档里定位消息的图片 ────────────────────────────────────

/** 读某个会话的存档（群 group_<id>.json / 私聊 private_<id>.json）。 */
export function readChatStore(chatKey) {
  try {
    const [kind, id] = String(chatKey || '').split(':');
    if (!kind || !id) return [];
    const f = path.join(dataDir(), 'messages', `${kind}_${id}.json`);
    const j = JSON.parse(fs.readFileSync(f, 'utf8'));
    return Array.isArray(j?.messages) ? j.messages : [];
  } catch (error) {
    warn(`读会话存档失败：${error?.message ?? error}`);
    return [];
  }
}

/**
 * 找要搜的那张图：
 *  - 给了 messageId → 找那条消息里的第一张图
 *  - 没给 → 找这个会话里**最近的**一张（别人发的优先）
 * 返回 { url, mid, senderName } 或 null。
 */
export function findImage(chatKey, messageId) {
  const list = readChatStore(chatKey);
  const pick = (m) => {
    const media = Array.isArray(m?.media) ? m.media : [];
    const img = media.find((x) => x && x.kind === 'image' && x.url);
    return img ? { url: img.url, mid: m.mid, senderName: m.senderName } : null;
  };
  if (messageId !== undefined && messageId !== null && String(messageId).trim() !== '') {
    const want = String(messageId).trim();
    const hit = [...list].reverse().find((m) => String(m?.mid) === want);
    return hit ? pick(hit) : null;
  }
  for (let i = list.length - 1; i >= 0; i -= 1) {
    if (list[i]?.self) continue;                 // 优先别人发的图
    const got = pick(list[i]);
    if (got) return got;
  }
  for (let i = list.length - 1; i >= 0; i -= 1) {  // 退一步：自己发的图也行
    const got = pick(list[i]);
    if (got) return got;
  }
  return null;
}

// ── 下载图片 ─────────────────────────────────────────────────────────────

export async function downloadImage(url, { timeoutMs = 60000 } = {}) {
  const r = await fetch(url, {
    headers: { 'User-Agent': UA, Accept: 'image/*,*/*' },
    signal: AbortSignal.timeout(timeoutMs),
    redirect: 'follow'
  });
  if (!r.ok) throw new Error(`下载图片失败：HTTP ${r.status}`);
  const buf = Buffer.from(await r.arrayBuffer());
  if (buf.length < 512) throw new Error('下载到的内容太小，不像图片');
  const head = buf.subarray(0, 4).toString('hex');
  const kind = head.startsWith('ffd8') ? 'jpg'
    : head.startsWith('89504e47') ? 'png'
      : buf.subarray(8, 12).toString('ascii') === 'WEBP' ? 'webp'
        : buf.subarray(4, 8).toString('ascii') === 'ftyp' ? 'mp4' : 'bin';
  return { buf, kind };
}

// ── SauceNAO 上传 + 解析 ─────────────────────────────────────────────────

/** 上传给 SauceNAO 网页版，返回结果页 HTML。 */
export async function sauceUpload(buf, kind, { timeoutMs = 90000 } = {}) {
  const form = new FormData();
  form.append('file', new Blob([buf], { type: kind === 'png' ? 'image/png' : 'image/jpeg' }), `upload.${kind === 'bin' ? 'jpg' : kind}`);
  form.append('db', '999');
  const r = await fetch('https://saucenao.com/search.php?numres=6&db=999', {
    method: 'POST',
    body: form,
    headers: { 'User-Agent': UA, Referer: 'https://saucenao.com/' },
    signal: AbortSignal.timeout(timeoutMs)
  });
  if (!r.ok) throw new Error(`SauceNAO 返回 HTTP ${r.status}`);
  return await r.text();
}

/**
 * 解析 SauceNAO 结果页：
 *  - matches：每个 <div class="result"> 一条（相似度/标题/出处链接/作者/索引名）
 *  - publicUrl：SauceNAO 托管的那张图（其它搜图引擎靠它按 URL 搜）
 */
export function parseSauce(html) {
  const out = { matches: [], publicUrl: '' };
  const pu = String(html).match(/src="\/userdata\/([^"]+)"/);
  if (pu) out.publicUrl = `https://saucenao.com/userdata/${pu[1]}`;

  const blocks = String(html).split('<div class="result">').slice(1);
  for (const b of blocks) {
    const sim = Number((b.match(/class="resultsimilarityinfo">\s*([\d.]+)%/) || [])[1] || 0);
    const title = unescapeHtml((b.match(/class="resulttitle"><strong>([\s\S]*?)<\/strong>/) || [])[1] || '');
    // 出处链接：pixiv（新旧两种写法）/ twitter / 其它
    let link = '';
    const pid = (b.match(/illust_id=(\d+)/) || [])[1] || (b.match(/pixiv\.net\/artworks\/(\d+)/) || [])[1];
    if (pid) link = `https://www.pixiv.net/artworks/${pid}`;
    if (!link) {
      const other = b.match(/href="(https?:\/\/(?:www\.)?(?:twitter|x)\.com\/[^"]+)"/);
      if (other) link = other[1];
    }
    if (!link) {
      const any = b.match(/class="linkify"[^>]*href="(https?:\/\/[^"]+)"/);
      if (any && !/saucenao\.com/.test(any[1])) link = any[1];
    }
    const author = unescapeHtml((b.match(/<strong>Member: <\/strong>\s*<a[^>]*>([^<]*)</) || [])[1] || '');
    const db = unescapeHtml((b.match(/title="Index #\d+: ([^"]+)"/) || [])[1] || '');
    // SauceNAO 自己缓存的那张匹配图（所有库都有，Pixiv 拿不到原图时就用它兜底）
    const thumb = (b.match(/src="(https:\/\/img\d*\.saucenao\.com\/[^"]+)"/) || [])[1] || '';
    if (sim || title) out.matches.push({ similarity: sim, title, link, author, db, thumb, pixivId: pid || '' });
  }
  out.matches.sort((a, b) => (b.similarity || 0) - (a.similarity || 0));   // 相似度最高的排最前
  return out;
}

// ── IQDB（多引擎合并的第二家；2026-10-09 打通）────────────────────────────
//
// 旧记录说「POST iqdb.org 只返回 101 字节空壳」—— 实测那是**没跟 307 跳转**、
// 表单字段也不完整造成的。正确姿势（本机直连实测 200 + 21KB 结果页）：
//   · GET https://iqdb.org/ 会 307 跳一下（curl 不加 -L 就只能拿到 180 字节的跳转页）；
//   · POST 到根路径，multipart 带 `file` + **`service[]=1..6`**（不传 service[] 才是空壳）；
//   · 结果页里每张图是一个 `<div><table>`，末尾一行写着「74% similarity」。
//
// ascii2d 也试过：**全站在 Cloudflare 后面**（curl 403 挑战页；无头 Edge 和真浏览器都卡在
// 「正在进行安全验证」），自动化过不去 → 只保留人工点开的直链，不参与相似度排序。

/** 把图上传给 IQDB（或 3D-IQDB），返回结果页 HTML。 */
export async function iqdbUpload(buf, kind, { host = 'https://iqdb.org/', timeoutMs = 60000 } = {}) {
  const form = new FormData();
  form.append('file', new Blob([buf], { type: kind === 'png' ? 'image/png' : 'image/jpeg' }),
    `upload.${kind === 'bin' ? 'jpg' : kind}`);
  for (const s of ['1', '2', '3', '4', '5', '6']) form.append('service[]', s);
  const r = await fetch(host, {
    method: 'POST',
    body: form,
    headers: { 'User-Agent': UA, Referer: host, Accept: 'text/html' },
    signal: AbortSignal.timeout(timeoutMs),
    redirect: 'follow'
  });
  if (!r.ok) throw new Error(`${host} 返回 HTTP ${r.status}`);
  return await r.text();
}

/**
 * 解析 IQDB 结果页。
 * 返回 { matches, noRelevant, uploadThumb }：
 *   · 每张结果都在 `<div><table>` 里，含 缩略图链接 / 服务名 / 尺寸 / 「N% similarity」；
 *   · `noRelevant` = 页面写着 "No relevant matches"（说明这些只是"看着像"，
 *     必须如实标成"相似、非精确"，不能当出处报给用户）。
 */
export function parseIqdb(html, { source = 'IQDB' } = {}) {
  const s = String(html || '');
  const out = { matches: [], noRelevant: /No relevant matches/i.test(s), uploadThumb: '' };
  const ut = s.match(/<img[^>]+src='(\/thu\/thu_[^']+)'/);
  if (ut) out.uploadThumb = `https://iqdb.org${ut[1]}`;

  for (const b of s.split(/<div>\s*<table>/).slice(1)) {
    const sim = Number((b.match(/([\d.]+)%\s*similarity/) || [])[1] || 0);
    if (!sim) continue;
    const href = (b.match(/<td class='image'>\s*<a href="([^"]+)"/) || b.match(/<td class="image">\s*<a href="([^"]+)"/) || [])[1] || '';
    const thumb = (b.match(/<td class='image'>[\s\S]*?<img src='([^']+)'/) || [])[1] || '';
    const svc = unescapeHtml((b.match(/class="service-icon"[^>]*>\s*([^<]*)/) || [])[1] || '');
    const dim = b.match(/>(\d+)×(\d+)\s*\[?/);
    const alt = unescapeHtml((b.match(/alt="([^"]*)"/) || [])[1] || '');
    const rating = unescapeHtml((b.match(/\[(Safe|Ero|Unrated|Questionable|Explicit)\]/i) || [])[1] || '');
    if (!href && !thumb) continue;
    out.matches.push({
      similarity: sim,
      title: svc ? `${svc} 上的图` : '匹配到的图',
      link: href.startsWith('//') ? `https:${href}` : href,
      // ⚠️ IQDB 给的是**根相对路径**（`/gelbooru/d/9/a/xxx.jpg`），不补域名 fetch 会直接报
      // "Failed to parse URL" —— 实测踩过，别再踩。
      thumb: thumb.startsWith('//') ? `https:${thumb}` : (thumb.startsWith('/') ? `https://iqdb.org${thumb}` : thumb),
      author: '',
      db: svc || source,
      source,
      approx: out.noRelevant,          // true = IQDB 自己都说"没有精确匹配"
      rating,
      size: dim ? `${dim[1]}×${dim[2]}` : '',
      tagHint: (alt.match(/Tags:\s*([^"]*)/) || [])[1] ? alt : alt.slice(0, 120),
      pixivId: (href.match(/pixiv\.net\/(?:artworks|member_illust\.php\?.*?illust_id=)(\d+)/) || [])[1] || ''
    });
  }
  out.matches.sort((a, b) => b.similarity - a.similarity);
  return out;
}

/**
 * 匹配到的是**图站作品**时，去图站把原图拿回来（比引擎缓存图清楚得多）。
 * 目前支持 Danbooru（免 key，`/posts/<id>.json` 就给 file_url）。
 * 拿不到就返回 null，让调用方退回缓存图 —— 不算失败。
 *
 * ⚠️ UA 必须用**带名字的机器人 UA**，不能用浏览器 UA：实测同样两个作品，
 *    `Mozilla/5.0 … Chrome/124 …` → HTTP 403，`QQAgent-danbooru/1.0 (local QQ bot)` → HTTP 200。
 *    Danbooru 是故意挡浏览器 UA 的（防抓取），别以为是网络问题。
 */
const BOORU_UA = 'QQAgent-danbooru/1.0 (local QQ bot)';

export async function fetchBooruOriginal(link, { timeoutMs = 45000, maxMB = 8 } = {}) {
  const m = /danbooru\.donmai\.us\/posts\/(\d+)/.exec(String(link || ''));
  if (!m) return null;
  const id = m[1];
  const r = await fetch(`https://danbooru.donmai.us/posts/${id}.json`, {
    headers: { 'User-Agent': BOORU_UA, Accept: 'application/json', Referer: 'https://danbooru.donmai.us/' },
    signal: AbortSignal.timeout(timeoutMs)
  });
  if (!r.ok) throw new Error(`Danbooru 接口 HTTP ${r.status}`);
  const j = await r.json();
  // 原图太大就退回它的 sample（速度快、QQ 里也够看）
  const size = Number(j?.file_size) || 0;
  const url = (size > maxMB * 1048576 && j?.large_file_url) ? j.large_file_url : (j?.file_url || j?.large_file_url || '');
  if (!url) throw new Error('Danbooru 没给图片地址');
  const img = await fetch(url, {
    headers: { 'User-Agent': BOORU_UA, Referer: 'https://danbooru.donmai.us/' },
    signal: AbortSignal.timeout(timeoutMs)
  });
  if (!img.ok) throw new Error(`Danbooru 图片 HTTP ${img.status}`);
  const buf = Buffer.from(await img.arrayBuffer());
  if (buf.length < 512) throw new Error('下到的内容太小，不像图片');
  const head = buf.subarray(0, 4).toString('hex');
  const kind = head.startsWith('ffd8') ? 'jpg' : head.startsWith('89504e47') ? 'png' : 'bin';
  return { buf, kind, url, from: `Danbooru 原图 #${id}${size > maxMB * 1048576 ? '（转 sample）' : ''}` };
}

/**
 * 取 Pixiv 作品的**原图**（SauceNAO 给的是缩略图；Pixiv 的 ajax 接口能拿到 original）。
 * 需要带 Referer，否则 Pixiv 直接 403。
 */
export async function fetchPixivOriginal(illustId, { timeoutMs = 45000 } = {}) {
  const id = String(illustId || '').replace(/\D/g, '');
  if (!id) return null;
  const api = `https://www.pixiv.net/ajax/illust/${id}?lang=zh`;
  const r = await fetch(api, {
    headers: { 'User-Agent': UA, Referer: `https://www.pixiv.net/artworks/${id}`, Accept: 'application/json' },
    signal: AbortSignal.timeout(timeoutMs)
  });
  if (!r.ok) throw new Error(`Pixiv 接口 HTTP ${r.status}`);
  const j = await r.json();
  const url = j?.body?.urls?.original || j?.body?.urls?.regular || '';
  if (!url) throw new Error('Pixiv 接口没给原图地址');
  const img = await fetch(url, {
    headers: { 'User-Agent': UA, Referer: 'https://www.pixiv.net/' },
    signal: AbortSignal.timeout(timeoutMs)
  });
  if (!img.ok) throw new Error(`Pixiv 原图 HTTP ${img.status}`);
  const buf = Buffer.from(await img.arrayBuffer());
  const head = buf.subarray(0, 4).toString('hex');
  const kind = head.startsWith('ffd8') ? 'jpg' : head.startsWith('89504e47') ? 'png' : 'bin';
  return { buf, kind, url };
}

/** 由 SauceNAO 的公开图链接生成整套搜图直链（和它结果页里给的一模一样）。 */
export function engineLinks(publicUrl) {
  if (!publicUrl) return [];
  const e = encodeURIComponent(publicUrl);
  return [
    ['Google Lens', `https://lens.google.com/uploadbyurl?url=${e}`],
    ['Yandex', `https://yandex.com/images/search?rpt=imageview&url=${e}`],
    ['TinEye', `https://www.tineye.com/search/?url=${e}`],
    ['IQDB', `https://iqdb.org?url=${e}`],
    ['3D-IQDB', `https://3d.iqdb.org/?url=${e}`],
    ['ascii2d', `https://ascii2d.net/search/url/${e}`],
    ['Bing 以图搜图', `https://www.bing.com/images/search?view=detailv2&iss=sbi&q=imgurl:${e}`],
    ['trace.moe（查动画）', `https://trace.moe/?auto&url=${e}`]
  ];
}

// ── 主流程 ───────────────────────────────────────────────────────────────

export async function lookUp(ctx, args = {}) {
  const c = cfg() || {};
  const timeoutMs = num(c.timeoutMs, 10000, 300000, 90000);
  const maxResults = num(c.maxResults, 1, 10, 3);
  const minSim = num(c.minSimilarity, 0, 100, 50);

  const found = findImage(ctx?.chatKey, args?.messageId);
  if (!found) return { ok: false, error: '这个会话里没找到图片（让他先发一张，或者把消息前的 #数字 给我）' };

  let img;
  try {
    img = await downloadImage(found.url, { timeoutMs: Math.min(timeoutMs, 60000) });
  } catch (error) {
    return { ok: false, error: `取图失败：${error?.message ?? error}` };
  }
  // 存一份本地副本（方便复查；也避免同一条消息反复下载）
  let localPath = '';
  try {
    const hash = crypto.createHash('sha1').update(img.buf).digest('hex').slice(0, 16);
    localPath = path.join(mediaDir(), `${hash}.${img.kind === 'bin' ? 'jpg' : img.kind}`);
    if (!fs.existsSync(localPath)) fs.writeFileSync(localPath, img.buf);
  } catch { /* 存不下也不影响搜索 */ }

  if (img.kind === 'webp' || img.kind === 'bin') {
    // SauceNAO 对 webp 不友好（实测会判失败），如实说明
    return { ok: false, error: `这张图是 ${img.kind} 格式，SauceNAO 只吃 jpg/png —— 让他重发一次（QQ 里转发/另存再发通常会转成 jpg）` };
  }

  // ── 多引擎并行（2026-10-09）：SauceNAO 为主，IQDB / 3D-IQDB 补 ──────────
  // 三家都是 POST 上传同一张图，互不影响；谁挂了就只记一条 warn，不拖垮整次搜索。
  const wantIqdb = c.useIqdb !== false;
  const wantIqdb3d = c.useIqdb3d === true;
  const [sauceR, iqdbR, iqdb3dR] = await Promise.allSettled([
    sauceUpload(img.buf, img.kind, { timeoutMs }).then(parseSauce),
    wantIqdb
      ? iqdbUpload(img.buf, img.kind, { host: 'https://iqdb.org/', timeoutMs }).then((h) => parseIqdb(h, { source: 'IQDB' }))
      : Promise.reject(new Error('__off__')),
    wantIqdb3d
      ? iqdbUpload(img.buf, img.kind, { host: 'https://3d.iqdb.org/', timeoutMs }).then((h) => parseIqdb(h, { source: '3D-IQDB' }))
      : Promise.reject(new Error('__off__'))
  ]);

  const warnings = [];
  const take = (r, name) => {
    if (r.status === 'fulfilled') return r.value;
    const msg = String(r.reason?.message ?? r.reason);
    if (msg !== '__off__') { warnings.push(`${name} 没查成（${msg}）`); warn(`${name} 失败：${msg}`); }
    return { matches: [], noRelevant: false, uploadThumb: '' };
  };
  const parsed = take(sauceR, 'SauceNAO');
  const iqdb = take(iqdbR, 'IQDB');
  const iqdb3d = take(iqdb3dR, '3D-IQDB');

  // 合并 + 按相似度统一排序（这就是用户要的"跨引擎取最高相似度"）
  const all = [
    ...parsed.matches.map((m) => ({ ...m, source: 'SauceNAO', approx: false })),
    ...iqdb.matches,
    ...iqdb3d.matches
  ];
  const byKey = new Map();                    // 同一个链接只留相似度最高的那条
  for (const m of all) {
    const k = (m.link || m.thumb || `${m.source}:${m.title}`).replace(/^https?:/, '').replace(/\/+$/, '');
    const prev = byKey.get(k);
    if (!prev || (Number(m.similarity) || 0) > (Number(prev.similarity) || 0)) byKey.set(k, m);
  }
  const merged = [...byKey.values()].sort((a, b) => (Number(b.similarity) || 0) - (Number(a.similarity) || 0));
  const good = merged.filter((m) => (Number(m.similarity) || 0) >= minSim).slice(0, maxResults);

  // ── 把相似度最高的那张图取回来 ────────────────────────────────────────
  // 取图顺序（2026-10-09 改进）：**按相似度从高到低逐条试**，而不是"只试第一条"。
  // 原因：IQDB 缓存图常常只有 3KB（150px 的缩略图），而它下面那条 Danbooru 作品能拿到真原图；
  // 一条兜底失败就放弃的话，群里收到的就是张糊图。谁能给出真图就用谁，取到就停。
  let best = null;
  const order = (good.length ? good : merged).slice(0, Math.max(3, maxResults));
  for (const m of order) {
    // ① 有 Pixiv id → 原图（SauceNAO 的 Pixiv Historical 库里可能是**已删除**的作品 → 会 404）
    if (m.pixivId) {
      try {
        const o = await fetchPixivOriginal(m.pixivId, { timeoutMs });
        const hash = crypto.createHash('sha1').update(o.buf).digest('hex').slice(0, 16);
        const f = path.join(mediaDir(), `best_${m.pixivId}_${hash}.${o.kind === 'bin' ? 'jpg' : o.kind}`);
        if (!fs.existsSync(f)) fs.writeFileSync(f, o.buf);
        best = { path: f, kind: o.kind, bytes: o.buf.length, from: `Pixiv 原图 #${m.pixivId}`, similarity: m.similarity };
        break;
      } catch (error) {
        warn(`Pixiv 原图取不到（#${m.pixivId}）：${error?.message ?? error}`);
      }
    }
    // ② 匹配到 Danbooru 作品 → 去图站取原图（比引擎缓存图清楚得多）
    if (/danbooru\.donmai\.us\/posts\/\d+/.test(String(m.link || ''))) {
      try {
        const o = await fetchBooruOriginal(m.link, { timeoutMs, maxMB: 8 });
        if (o) {
          const hash = crypto.createHash('sha1').update(o.buf).digest('hex').slice(0, 16);
          const f = path.join(mediaDir(), `best_booru_${hash}.${o.kind === 'bin' ? 'jpg' : o.kind}`);
          if (!fs.existsSync(f)) fs.writeFileSync(f, o.buf);
          best = { path: f, kind: o.kind, bytes: o.buf.length, from: o.from, similarity: m.similarity };
          break;
        }
      } catch (error) {
        warn(`图站原图取不到（${m.link}）：${error?.message ?? error}`);
      }
    }
  }
  // ③ 一条真图都拿不到 → 用引擎自己缓存的缩略图（有总比没有强，且在 note 里说明是缩略图）
  if (!best) {
    const top = order.find((m) => m.thumb) || null;
    if (top) {
      try {
        const d = await downloadImage(top.thumb, { timeoutMs: 45000 });
        const hash = crypto.createHash('sha1').update(d.buf).digest('hex').slice(0, 16);
        const f = path.join(mediaDir(), `best_thumb_${hash}.${d.kind === 'bin' ? 'jpg' : d.kind}`);
        if (!fs.existsSync(f)) fs.writeFileSync(f, d.buf);
        best = {
          path: f, kind: d.kind, bytes: d.buf.length, similarity: top.similarity, thumbOnly: true,
          from: `${top.source || 'SauceNAO'} 缓存缩略图（${top.db || '未知库'}，只有 ${Math.round(d.buf.length / 1024)}KB）`
        };
      } catch (error) {
        warn(`缓存图也取不到：${error?.message ?? error}`);
      }
    }
  }

  // 公开图链接：SauceNAO 会把上传的图托管几小时；它没成时用 IQDB 的（两家都是公开可访问的）
  const publicUrl = parsed.publicUrl || iqdb.uploadThumb || iqdb3d.uploadThumb || '';

  return {
    ok: true,
    localPath,
    publicUrl,
    total: merged.length,
    matches: good,
    best,
    warnings,
    sources: {
      sauce: parsed.matches.length,
      iqdb: iqdb.matches.length,
      iqdb3d: iqdb3d.matches.length,
      iqdbNoRelevant: iqdb.noRelevant,
      iqdb3dNoRelevant: iqdb3d.noRelevant
    },
    lowConfidence: good.length === 0 && merged.length > 0,
    senderName: found.senderName,
    engineLinks: c.showEngineLinks === false ? [] : engineLinks(publicUrl)
  };
}

function buildText(r) {
  const lines = [];
  if (!r.matches.length) {
    lines.push(r.lowConfidence ? '没找到确切出处，只找到相似度很低的图（不敢当出处报给你）：' : '几个搜图引擎都没搜到匹配。');
  } else {
    lines.push('搜到的出处（多家引擎，按相似度排序）：');
    for (const m of r.matches) {
      const bits = [`${m.similarity}%`];
      bits.push(`[${m.source}${m.approx ? '·相似' : ''}]`);
      if (m.title) bits.push(m.title.slice(0, 40));
      if (m.size) bits.push(m.size);
      if (m.author) bits.push(`作者 ${m.author}`);
      if (m.link) bits.push(m.link);
      else if (m.db) bits.push(`（${m.db}）`);
      lines.push('· ' + bits.join(' ｜ '));
    }
    // IQDB 自己写着 "No relevant matches" 时，那些只是"看着像"，必须说清楚
    const approxOnly = r.matches.every((m) => m.source !== 'SauceNAO' && m.approx);
    if (approxOnly) {
      lines.push('（这几条来自 IQDB，它自己标了"没有精确匹配"——只是长得像，**不能当出处**，说话时要如实讲。）');
    }
  }
  if (r.best) {
    const topSim = r.matches[0]?.similarity;
    if (r.best.thumbOnly) {
      lines.push(`（附的图是引擎缓存的缩略图，只有 ${Math.round(r.best.bytes / 1024)}KB —— 别当原图说。）`);
    } else if (topSim !== undefined && r.best.similarity !== topSim) {
      lines.push(`（附的图取自相似度 ${r.best.similarity}% 那条：只有它能拿到真图。）`);
    }
  }
  if (r.warnings && r.warnings.length) {
    lines.push('');
    for (const w of r.warnings) lines.push(`⚠️ ${w}`);
  }
  if (r.engineLinks && r.engineLinks.length) {
    lines.push('');
    lines.push('想自己再挖：');
    for (const [name, url] of r.engineLinks) lines.push(`${name}：${url}`);
  }
  return lines.join('\n');
}

// ── 工具注册 ─────────────────────────────────────────────────────────────

function ok(payload) { return { content: JSON.stringify(payload, null, 1) }; }
function err(message) { return { content: String(message), isError: true }; }

export function setup(api) {
  cfg = api.config;
  log = api.log;
  warn = api.warn;

  api.registerTool({
    id: 'image_source',
    name: '以图搜图（找原图出处）',
    description: '把**当前会话里别人刚发的那张图**（或指定消息里的图）**同时丢给多个搜图引擎**'
      + '（SauceNAO + IQDB + 可选 3D-IQDB），把结果**按相似度统一排序、标注来源**，'
      + '回出处链接 + 作者 + 相似度（默认最多 5 条），'
      + '**并把相似度最高的那张图直接取回来发出来**（是 Pixiv 作品就拿原图，其它站用引擎缓存图）；'
      + '另附一整排搜图直链（Google Lens / Yandex / TinEye / IQDB / 3D-IQDB / ascii2d / Bing / trace.moe）。'
      + '适用：有人发图问「这图哪来的 / 求出处 / 画师是谁 / 帮你搜搜这张图」。'
      + '参数 messageId 填消息前的 #数字（不填就用最近的图）。'
      + '**工具会自己把结论发到当前会话**；你拿到结果后用 send_message 回一句就行（例如「搜到了，是 Pixiv 上 xxx 的作品」）。'
      + '注意：结果里带「·相似」标记、或 note 里说 approxOnly 的，表示引擎自己认定**没有精确匹配** ——'
      + '那只是长得像，必须如实说「只找到相似的」，绝不能冒充原图。'
      + '（ascii2d 全站被 Cloudflare 挡着，自动化进不去，只给直链。）',
    category: 'media',
    icon: '🔎',
    parameters: {
      type: 'object',
      properties: {
        messageId: { type: 'string', description: '要搜的那条消息的 id（聊天记录里每条前面的 #数字）。不填就用这个会话里最近的图。' }
      }
    },
    async execute(ctx, args) {
      try {
        const r = await lookUp(ctx, args || {});
        if (!r.ok) return err(`以图搜图失败：${r.error}`);
        const text = buildText(r);
        // 文字在上、图在下（用户偏好）；图 = 相似度最高的那张（Pixiv 作品拿的是原图）
        const segs = [{ type: 'text', data: { text } }];
        if (r.best?.path && fs.existsSync(r.best.path)) segs.push({ type: 'image', data: { file: r.best.path } });
        let sent = null;
        try {
          sent = await ctx.sender.sendMedia(ctx.chatKey, segs, {
            label: '[以图搜图]',
            dedupeKey: `imgsrc:${path.basename(r.best?.path || '')}:${String(text).slice(0, 30)}`
          });
        } catch (error) {
          warn(`结果发不出去：${error?.message ?? error}`);
        }
        const sentN = Array.isArray(sent?.sent) ? sent.sent.length : 0;
        const approxOnly = r.matches.length > 0 && r.matches.every((m) => m.source !== 'SauceNAO' && m.approx);
        return ok({
          found: r.matches.length,
          total: r.total,
          sources: r.sources,
          warnings: r.warnings,
          top: r.matches[0] ? { similarity: r.matches[0].similarity, source: r.matches[0].source, approx: r.matches[0].approx, title: r.matches[0].title, author: r.matches[0].author, link: r.matches[0].link } : null,
          matches: r.matches.map((m) => ({ similarity: m.similarity, source: m.source, approx: m.approx, title: m.title, link: m.link })),
          bestImage: r.best ? { from: r.best.from, similarity: r.best.similarity, kind: r.best.kind, kb: Math.round(r.best.bytes / 1024) } : null,
          lowConfidence: r.lowConfidence,
          approxOnly,
          publicImageUrl: r.publicUrl,
          sentToChat: sentN > 0,
          note: sentN > 0
            ? '【已发送】结论和**相似度最高的那张图**都发到会话里了。用一句话回应（例如「搜到了，是 Pixiv 上 xxx 的作品，图也给你找来了」）；'
              + (approxOnly
                ? '这批结果引擎自己标了「没有精确匹配」，**必须**如实说「只找到长得像的，不敢当出处」。'
                : '相似度低就如实说只找到相似的。')
            : '【注意】结果**没能发出去**，请把 top/matches 的内容用 send_message 转述给对方。'
        });
      } catch (error) {
        warn(`image_source 异常：${error?.stack ?? error}`);
        return err(`以图搜图出错：${error?.message ?? error}`);
      }
    }
  });

  log('以图搜图技能已加载（SauceNAO + IQDB [+ 3D-IQDB] 多引擎合并，免 API key；直连）');
}

export function available() { return true; }

export const internals = {
  findImage, downloadImage, sauceUpload, parseSauce, iqdbUpload, parseIqdb, engineLinks,
  lookUp, readChatStore, mediaDir, fetchPixivOriginal, fetchBooruOriginal
};
