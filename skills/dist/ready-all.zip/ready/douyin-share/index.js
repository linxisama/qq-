// 分享抖音视频/图文（LLM 型技能 · 注册工具）
//
// ── 为什么必须用"无头 Edge 渲染"这一步 ──────────────────────────────────────
// 实测（2026-10-07 本机）抖音的服务端路子全被堵死：
//   · /web/api/v2/aweme/iteminfo、aweme/v1/aweme/detail、/aweme/v1/web/aweme/detail
//     一律 HTTP 200 但**正文 0 字节**（静默拦截）；
//   · 分享页 HTML 里只有页面骨架（_ROUTER_DATA 里没有媒体地址）；
//   · yt-dlp 能解析短链，但明确不支持 /note/（图文）；
//   · agent-reach 的 web_read 是普通抓取，同样过不去。
// 而用 Edge 的**无头模式**渲染一次（页面自己跑 JS）就能拿到真实资源地址：
// DOM 里含 `...~tplv-dy-aweme-images:q75.webp?biz_tag=aweme_images&from=...` 这类图床地址，
// 视频则有 douyinvod.com 的源。所以本技能的做法是：无头渲染 → 解析 → 本机下载 → 交给核心发送。
//
// ── 为什么"原图"是把 ~tplv 模板去掉 ────────────────────────────────────────
// 图床地址形如 <path>~tplv-dy-aweme-images:q75.webp（q75 = 有损压缩模板）。
// 去掉 `~tplv...` 那一段通常就是原图；取不到（403/404）再退回页面里那一版，
// 两个都试、**挑体积大的**，这样"尽量原图"是实测出来的而不是猜的。
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import { execFile } from 'node:child_process';
import { getConfig } from '../../src/config.js';
import { skillManager } from '../../src/skills/manager.js';

let cfg = () => ({});
let log = () => {};
let warn = () => {};

const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36';
const REFERER = 'https://www.douyin.com/';
const EDGE_CANDIDATES = [
  'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe',
  'C:\\Program Files\\Microsoft\\Edge\\Application\\msedge.exe',
  path.join(process.env.LOCALAPPDATA || '', 'Microsoft\\Edge\\Application\\msedge.exe'),
  '/usr/bin/microsoft-edge',
  '/usr/bin/google-chrome'
];

function dataDir() {
  return process.env.QQ_AGENT_DATA_DIR || path.resolve(process.cwd(), 'data');
}

function mediaDir() {
  const d = path.join(dataDir(), 'douyin-media');
  fs.mkdirSync(d, { recursive: true });
  return d;
}

function num(v, lo, hi, dflt) {
  const n = Number(v);
  if (!Number.isFinite(n)) return dflt;
  return Math.min(hi, Math.max(lo, Math.round(n)));
}

// ── 链接识别 ─────────────────────────────────────────────────────────────

/** 从一段文字里抠出抖音链接（分享口令那种整段文字也能处理）。 */
export function extractLink(text) {
  const s = String(text ?? '');
  const m = s.match(/https?:\/\/v\.douyin\.com\/[A-Za-z0-9_\-]+/i)
    || s.match(/https?:\/\/(?:www\.)?douyin\.com\/(?:video|note)\/\d+/i)
    || s.match(/https?:\/\/www\.iesdouyin\.com\/share\/(?:video|note)\/\d+/i);
  return m ? m[0] : '';
}

/** 解析短链，返回 { url, kind: 'video'|'note'|'', id }。 */
export async function resolveLink(link, timeoutMs = 30000) {
  let url = String(link || '').trim();
  if (!url) return { ok: false, error: '没有链接' };
  if (/v\.douyin\.com/i.test(url)) {
    try {
      const r = await fetch(url, { redirect: 'follow', headers: { 'User-Agent': UA }, signal: AbortSignal.timeout(timeoutMs) });
      url = r.url || url;
    } catch (error) {
      return { ok: false, error: `短链解析失败：${error?.message ?? error}` };
    }
  }
  const m = url.match(/\/(video|note)\/(\d+)/i) || url.match(/share\/(video|note)\/(\d+)/i);
  if (!m) return { ok: false, error: `认不出这是视频还是图文：${url.slice(0, 120)}` };
  const kind = m[1].toLowerCase();
  const id = m[2];
  return { ok: true, kind, id, url: `https://www.douyin.com/${kind}/${id}` };
}

// ── 无头渲染取 DOM ────────────────────────────────────────────────────────

function findEdge(configured) {
  const list = [configured, ...EDGE_CANDIDATES].filter(Boolean);
  for (const p of list) {
    try { if (p && fs.existsSync(p)) return p; } catch { /* 继续 */ }
  }
  return '';
}

/**
 * 用 Edge 无头模式渲染页面，返回 DOM 文本。
 * 测试口子：环境变量 DOUYIN_DOM_FILE 指向一个已渲染好的 DOM 文件时直接读它
 * （DSH 的沙箱里子进程管道会 EPERM，所以自动化测试走这条路）。
 */
export async function renderDom(url, { timeoutMs = 45000 } = {}) {
  if (process.env.DOUYIN_DOM_FILE && fs.existsSync(process.env.DOUYIN_DOM_FILE)) {
    log('用预渲染的 DOM（测试模式）');
    return { ok: true, dom: fs.readFileSync(process.env.DOUYIN_DOM_FILE, 'utf8'), via: 'file' };
  }
  const edge = findEdge(cfg()?.edgePath);
  if (!edge) {
    return { ok: false, error: '没找到 Edge。请在技能设置里填「Edge 程序路径」（一般在 C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe）' };
  }
  const profile = path.join(os.tmpdir(), `dyprof_${Date.now().toString(36)}`);
  const args = [
    '--headless=new', '--disable-gpu', '--no-first-run', '--disable-extensions',
    `--user-data-dir=${profile}`,
    '--virtual-time-budget=9000',
    '--dump-dom', url
  ];
  try {
    const dom = await new Promise((resolve, reject) => {
      execFile(edge, args, { maxBuffer: 128 * 1024 * 1024, timeout: timeoutMs, windowsHide: true }, (err, stdout) => {
        if (err && !stdout) reject(err);
        else resolve(stdout || '');
      });
    });
    if (!dom || dom.length < 2000) return { ok: false, error: `渲染结果太小（${dom ? dom.length : 0} 字节），可能被反爬拦了` };
    return { ok: true, dom, via: 'edge' };
  } catch (error) {
    return { ok: false, error: `无头渲染失败：${error?.message ?? error}` };
  } finally {
    try { fs.rmSync(profile, { recursive: true, force: true }); } catch { /* 忽略 */ }
  }
}

// ── 从 DOM 里抽资源地址 ──────────────────────────────────────────────────

function unescapeHtml(s) {
  return String(s).replace(/&amp;/g, '&').replace(/&#38;/g, '&').replace(/\\u002F/g, '/');
}

/**
 * 图文图片：按**路径**分组成"一张图"。
 * 同一张图在页面里会挂多个 CDN 域名（p3-/p9-）和多个压缩模板（~tplv-...），
 * 只按"域名+路径"去重会把同一张算成好几张（实测：5 张的图文被算成 52 张，
 * 于是发出去一堆重复图）。所以键用 pathname，候选里同时给出页面原地址和去掉模板的原图地址。
 */
export function imagesFromDom(dom) {
  const all = String(dom).match(/https:\/\/p[0-9a-z-]*\.douyinpic\.com\/[^"'\s<>\\]+/gi) || [];
  const groups = new Map();
  for (const raw of all) {
    const u = unescapeHtml(raw);
    const i = u.indexOf('~');
    if (i < 0) continue;                                  // 没有压缩模板的（头像/图标之类）不要
    // 只要"作品图"那类模板：页面里还有推荐位、活动图、表情等同样带模板的图床地址，
    // 不过滤就会把别的作品也当成这篇的图发出去（实测：5 张的图文被算成 39 张）。
    if (!/~tplv-dy-aweme-images/i.test(u)) continue;
    const stem = u.slice(0, i);                            // 去掉模板 = 原图地址
    let key = stem;
    try { key = new URL(stem).pathname; } catch { /* 退回原串当键 */ }
    if (!groups.has(key)) groups.set(key, { key, candidates: [] });
    const g = groups.get(key);
    g.candidates.push(u);      // 页面里那一版（确定能下）
    g.candidates.push(stem);   // 无模板的原图（体积更大就用它）
  }
  return [...groups.values()].map((g) => ({ key: g.key, candidates: [...new Set(g.candidates)] }));
}

/** 视频源：douyinvod.com 的地址。 */
export function videoFromDom(dom) {
  const all = String(dom).match(/https:\/\/[^"'\s<>\\]*douyinvod\.com[^"'\s<>\\]+/gi) || [];
  const seen = new Set();
  const out = [];
  for (const raw of all) {
    const u = unescapeHtml(raw);
    const key = u.split('?')[0];
    if (seen.has(key)) continue;
    seen.add(key);
    out.push(u);
  }
  return out;
}

// ── 下载 ─────────────────────────────────────────────────────────────────

function sniff(buf) {
  if (buf.length > 3 && buf[0] === 0xff && buf[1] === 0xd8) return 'jpg';
  if (buf.length > 8 && buf.subarray(0, 8).toString('hex') === '89504e470d0a1a0a') return 'png';
  if (buf.length > 12 && buf.subarray(8, 12).toString('ascii') === 'WEBP') return 'webp';
  if (buf.length > 12 && buf.subarray(4, 8).toString('ascii') === 'ftyp') return 'mp4';
  return 'bin';
}

async function downloadBest(candidates, destBase, { maxBytes, timeoutMs, label }) {
  let best = null;
  const tried = [];
  for (const url of candidates.filter(Boolean)) {
    try {
      const r = await fetch(url, { headers: { 'User-Agent': UA, Referer: REFERER, Accept: '*/*' }, signal: AbortSignal.timeout(timeoutMs) });
      if (!r.ok) { tried.push(`${r.status}`); continue; }
      const buf = Buffer.from(await r.arrayBuffer());
      const kind = sniff(buf);
      if (kind === 'bin' || buf.length < 2048) { tried.push('内容不是媒体'); continue; }
      if (buf.length > maxBytes) { tried.push(`${(buf.length / 1048576).toFixed(1)}MB 超上限`); continue; }
      tried.push(`ok ${(buf.length / 1024).toFixed(0)}KB`);
      if (!best || buf.length > best.buf.length) best = { buf, kind };
    } catch (error) {
      tried.push(String(error?.name || error?.message || error).slice(0, 40));
    }
  }
  if (!best) return { ok: false, error: `${label} 下载失败（${tried.join(' / ') || '没有候选地址'}）` };
  const dest = `${destBase}.${best.kind}`;
  fs.writeFileSync(dest, best.buf);
  return { ok: true, path: dest, bytes: best.buf.length, kind: best.kind, tried };
}

/** 清理过期媒体（每次运行顺手做）。 */
export function pruneMedia(keepHours = 6) {
  const dir = mediaDir();
  const maxAge = keepHours * 3600 * 1000;
  let n = 0;
  try {
    for (const f of fs.readdirSync(dir)) {
      const p = path.join(dir, f);
      const st = fs.statSync(p);
      if (Date.now() - st.mtimeMs > maxAge) { fs.unlinkSync(p); n += 1; }
    }
  } catch { /* 忽略 */ }
  if (n) log(`清理了 ${n} 个过期媒体文件`);
  return n;
}

// ── 发送 helpers ─────────────────────────────────────────────────────────

function escapeCq(text) {
  return String(text ?? '').replace(/\[CQ:/gi, '[CQ：');
}

/** 把一批图片 + 文案作为一条消息发出（图在前、文案在后）。chatKey 由调用方决定（可能是跨会话目标）。 */
async function sendImages(ctx, files, caption, chatKey) {
  const target = chatKey || ctx.chatKey;
  const segments = files.map((f) => ({ type: 'image', data: { file: f } }));
  if (caption) segments.push({ type: 'text', data: { text: escapeCq(`\n${caption}`) } });
  const r = await ctx.sender.sendMedia(target, segments, {
    label: `[抖音图文]:${files.length}张`,
    dedupeKey: `douyin:${files.length}:${path.basename(files[0] || '')}`
  });
  // ⚠️ 核心的 sender 返回的是 { sent, failed }，**没有 ok 字段**。
  //    早先按 r.ok 判断 → 明明发出去了也报失败（实测：群里能看到视频，模型却说"发不出去"）。
  const sentN = Array.isArray(r?.sent) ? r.sent.length : 0;
  const failN = Array.isArray(r?.failed) ? r.failed.length : 0;
  const firstFail = failN ? String(r.failed[0]?.error || '部分失败') : '';
  // 同视频那条注释：没报 failed 就算成功（投递成功时 sent 也可能是空的）
  return { ok: failN === 0 && r !== undefined, sent: sentN, error: firstFail };
}

// ── 主流程 ───────────────────────────────────────────────────────────────

export async function handle(link, opts = {}) {
  const c = cfg() || {};
  const timeoutMs = num(c.timeoutMs, 5000, 180000, 45000);
  const maxBytes = num(c.maxMB, 1, 500, 100) * 1048576;
  const maxImages = num(c.maxImages, 1, 35, 9);
  const keepHours = num(c.keepHours, 1, 168, 6);

  const picked = extractLink(link) || String(link || '').trim();
  if (!picked) return { ok: false, error: '没找到抖音链接（把分享文字整段发我也行）' };
  const resolved = await resolveLink(picked, timeoutMs);
  if (!resolved.ok) return resolved;

  const rendered = await renderDom(resolved.url, { timeoutMs });
  if (!rendered.ok) return rendered;
  const dom = rendered.dom;

  pruneMedia(keepHours);

  if (resolved.kind === 'note') {
    const items = imagesFromDom(dom);
    if (!items.length) {
      return { ok: false, error: '渲染出来了但没解析到图片（抖音页面结构可能变了）' };
    }
    const take = items.slice(0, maxImages);
    const files = [];
    const details = [];
    for (const [i, it] of take.entries()) {
      // 候选顺序：页面里那版（确定能下）+ 去掉模板的原图（体积更大就用它）
      const cands = c.origImages === false ? [it.candidates[0]] : it.candidates;
      // eslint-disable-next-line no-await-in-loop
      const got = await downloadBest(cands, path.join(mediaDir(), `note_${resolved.id}_${i + 1}`), { maxBytes, timeoutMs, label: `第 ${i + 1} 张` });
      if (got.ok) { files.push({ path: got.path, bytes: got.bytes }); details.push({ i: i + 1, kb: Math.round(got.bytes / 1024) }); }
      else warn(got.error);
    }
    if (!files.length) return { ok: false, error: '一张图都没下下来（可能是限流或链接过期）' };
    return {
      ok: true,
      kind: 'note',
      id: resolved.id,
      desc: descFromDom(dom),
      images: files.length,
      total: items.length,
      skipped: items.length - files.length,
      details,
      files: files.map((f) => f.path)
    };
  }

  // 视频
  const vids = videoFromDom(dom);
  if (!vids.length) return { ok: false, error: '渲染出来了但没解析到视频源（页面结构可能变了）' };
  const got = await downloadBest(vids.slice(0, 4), path.join(mediaDir(), `video_${resolved.id}`), { maxBytes, timeoutMs, label: '视频' });
  if (!got.ok) return got;
  return { ok: true, kind: 'video', id: resolved.id, desc: descFromDom(dom), files: [got.path], bytes: got.bytes, candidates: vids.length };
}

// ── 工具注册 ─────────────────────────────────────────────────────────────

function ok(payload) { return { content: JSON.stringify(payload, null, 1) }; }
function err(message) { return { content: String(message), isError: true }; }

// ── 跨会话发送（只在主人的私聊里允许）────────────────────────────────────
//
// 场景：主人在私聊里说「把这个图文里的图片发到某个群里」。媒体比文字敏感得多
// （发错群、被别人借手都很难看），所以口径跟"撤回别人的消息"一致：
// **只有主人的私聊**里才能指定别的会话，群里一律只能发当前会话。

function ownerQq() {
  try {
    const entry = (skillManager.list() || []).find((s) => s.id === 'owner-console');
    const v = String(entry?.settings?.ownerQq || '').trim();
    if (v) return v;
  } catch { /* 退回配置 */ }
  try {
    return String(getConfig()?.skills?.['owner-console']?.ownerQq || '').trim();
  } catch {
    return '';
  }
}

/** 把「群名/群号」解析成 chatKey（只认允许说话的群）。 */
export async function resolveChat(ctx, raw) {
  const s = String(raw ?? '').trim();
  if (!s) return { ok: false, error: '没说要发到哪个群' };
  // 私聊也可以指定（private:QQ号）
  if (/^private[:：]\d{5,15}$/i.test(s)) {
    const id = s.replace(/[^\d]/g, '');
    return { ok: true, chatKey: `private:${id}`, name: id };
  }
  let allow = [];
  try { allow = (getConfig()?.allow?.groups || []).map(String); } catch { allow = []; }
  if (/^\d{5,15}$/.test(s)) {
    if (allow.length && !allow.includes(s)) return { ok: false, error: `群 ${s} 不在允许说话的名单里（${allow.join('、') || '空'}）` };
    return { ok: true, chatKey: `group:${s}`, name: s };
  }
  let list = [];
  try { list = (await ctx.onebot.call('get_group_list', {})) || []; } catch (error) {
    return { ok: false, error: `拿群列表失败：${error?.message ?? error}` };
  }
  const norm = (x) => String(x ?? '').toLowerCase().replace(/\s/g, '');
  const inAllow = list.filter((g) => !allow.length || allow.includes(String(g.group_id)));
  const t = norm(s);
  const hit = inAllow.find((g) => norm(g.group_name) === t)
    || inAllow.find((g) => norm(g.group_name).includes(t) || t.includes(norm(g.group_name)));
  if (!hit) return { ok: false, error: `没找到叫「${raw}」的群。可用的有：${inAllow.map((g) => `${g.group_name}(${g.group_id})`).join('、') || '（无）'}` };
  return { ok: true, chatKey: `group:${hit.group_id}`, name: hit.group_name };
}

/**
 * 决定这次媒体发到哪个会话：
 * to 为空 → 当前会话（谁都能用）；给了 to → 必须是**主人的私聊**（跨会话发媒体只有主人能做）。
 */
export async function pickTarget(ctx, to) {
  const want = String(to ?? '').trim();
  if (!want) return { ok: true, chatKey: String(ctx?.chatKey || '') };
  const owner = ownerQq();
  const isOwnerPrivate = ctx?.kind === 'private' && String(ctx?.chatId || '') === owner;
  if (!owner || !isOwnerPrivate) {
    return { ok: false, error: '跨会话发媒体只能在主人的私聊里指定（群里/别人私聊里只能发当前会话）' };
  }
  const r = await resolveChat(ctx, want);
  if (!r.ok) return r;
  return { ok: true, chatKey: r.chatKey, name: r.name, cross: true };
}

// ── "这条在这个会话发过了"的记账 ─────────────────────────────────────────
//
// 为什么需要：模型看到工具返回不理想时会**自己重试**（实测：同一个视频链接它连调了 3 次工具，
// 两次发送都成功 → 群里出现两条一样的视频 ✗）。发送管道本身没有错，是重复调用。
// 所以按 (会话, 作品 id) 记账，24 小时内发过就直接跳过并明确告诉模型"已发过"。
const SENT_TTL_MS = 24 * 60 * 60 * 1000;

function stateFile() {
  return path.join(dataDir(), 'douyin-share-state.json');
}

function readSent() {
  try {
    const parsed = JSON.parse(fs.readFileSync(stateFile(), 'utf8'));
    if (parsed && typeof parsed.sent === 'object') return parsed.sent;
  } catch { /* 首次运行 */ }
  return {};
}

/** 这个会话最近发过这条作品吗？（**按形态区分**：视频 / 原文件 是两回事） */
export function hasSent(chatKey, id, form) {
  try {
    const list = readSent()[String(chatKey)] || [];
    const f = String(form || '');
    return list.some((x) => x && String(x.id) === String(id) && String(x.kind || '') === f && Date.now() - (x.at || 0) < SENT_TTL_MS);
  } catch {
    return false;
  }
}

/** 记一笔（发送成功后调用）。 */
export function markSent(chatKey, id, kind) {
  try {
    const all = readSent();
    const now = Date.now();
    const list = (all[String(chatKey)] || []).filter((x) => x && now - (x.at || 0) < SENT_TTL_MS && String(x.id) !== String(id));
    list.push({ id: String(id), kind: String(kind || ''), at: now });
    all[String(chatKey)] = list.slice(-100);
    fs.writeFileSync(stateFile(), JSON.stringify({ sent: all, at: now }, null, 1), 'utf8');
    return true;
  } catch (error) {
    warn(`发送记账失败：${error?.message ?? error}`);
    return false;
  }
}

/** 把抖音分享口令洗成人话：去掉链接和"5.12 复制打开抖音…:8pm 05/23 ipD:/ T@Y.Zz"这类碎片。 */
export function cleanShareText(text) {
  let s = String(text ?? '');
  s = s.replace(/https?:\/\/\S+/g, ' ');                                    // 链接
  s = s.replace(/\d+(?:\.\d+)?\s*复制打开抖音[，,、]?\s*/g, ' ');              // 口令开头
  s = s.replace(/[（(]?看看[）)]?\s*/g, ' ');                                 // "看看【…】"里的看看
  s = s.replace(/\b\d{1,2}\s*\/\s*\d{1,2}\b[\s\S]*$/g, ' ');                 // 尾部 "05/23 …"
  s = s.replace(/[:：]?\s*\d{1,2}\s*[:：]\s*\d{2}\s*(?:am|pm)?[\s\S]*$/gi, ' '); // 尾部 ":8pm …"
  s = s.replace(/[:：]\s*\d{1,2}\s*(?:am|pm)\b[\s\S]*$/gi, ' ');              // 尾部 ":8pm …"（无分钟的形态）
  s = s.replace(/[a-z]{1,2}@[a-z.]+|[a-z]@[a-z]+\.[A-Za-z]{2,}/gi, ' ');     // "T@Y.Zz" 这类随机串
  s = s.replace(/[A-Za-z]{1,2}:\/{1,2}/g, ' ');
  s = s.replace(/\s+/g, ' ').trim();
  return s.replace(/^[，,、:：\s]+|[，,、:：\s]+$/g, '').trim();
}

/** 本次运行的**触发原文**（核心通过 ctx.session.triggerText / trigger 提供）。 */
export function triggerText(ctx) {
  const s = ctx?.session || {};
  const cands = [s.triggerText, s.trigger, s.triggerSummary];
  return cands.map((x) => String(x ?? '')).filter(Boolean).join(' | ');
}

/** 会话存档里最近 10 分钟内、用户说过的最后几条（存档只是兜底/补充，可能晚于本轮）。 */
export function recentUserText(chatKey, minutes = 10) {
  try {
    const [kind, id] = String(chatKey || '').split(':');
    if (!kind || !id) return '';
    const f = path.join(dataDir(), 'messages', `${kind}_${id}.json`);
    const j = JSON.parse(fs.readFileSync(f, 'utf8'));
    const list = Array.isArray(j?.messages) ? j.messages : [];
    const since = Date.now() - minutes * 60 * 1000;
    return list.filter((m) => m && !m.self && String(m.text || '').trim() && Number(m.ts || 0) >= since)
      .map((m) => String(m.text)).join(' | ');
  } catch {
    return '';
  }
}

/** 用户是不是明确说了"不要文字"？（工具自己判断，模型漏传也没关系） */
export function wantsNoText(text) {
  const s = String(text || '');
  return /不要文字|不带文字|别带文字|没有文字|不要文案|不带文案|别带文案|不要说明|不带说明|只(?:要|发|给)?图(?:片)?(?:就|即可|就行)?|只发图|仅图片|不要那(?:些)?字/.test(s);
}

/**
 * 作品**自己的文案**（抖音那条作品的标题/描述）。
 * 页面 meta 里最干净：`<meta name="description" content="作品文案 - 作者于20261006发布在抖音，…来抖音，记录美好生活！">`
 * 要把尾部那段"作者/日期/来抖音记录美好生活"的宣传语去掉。
 */
export function descFromDom(dom) {
  const s0 = String(dom);
  const m = s0.match(/<meta\s+name="description"\s+content="([^"]*)"/i)
    || s0.match(/<meta\s+property="og:description"\s+content="([^"]*)"/i);
  let s = m ? m[1] : '';
  if (!s) {
    const t = s0.match(/<title>([^<]*)<\/title>/i);
    s = t ? t[1] : '';
  }
  s = unescapeHtml(s);
  s = s.replace(/\s*-\s*[^\-]{0,24}于\d{6,8}发布在抖音[\s\S]*$/i, '');   // 去掉"- 作者于20261006发布在抖音，…"
  s = s.replace(/\s*-\s*抖音\s*$/i, '');
  s = s.replace(/\s+/g, ' ').trim();
  return s;
}

function registerTools(api) {
  api.registerTool({
    id: 'douyin_media',
    name: '抖音提取并发送',
    description: '把抖音链接里的**视频**或**图文图片**提取出来并发到当前会话（图片尽量原图）。'
      + 'url 可以只给链接，也可以整段分享文字（"7.12 复制打开抖音…https://v.douyin.com/xxxx/"）。'
      + '适用：有人发抖音链接并让你把图/视频发出来、或说"看看这个"。'
      + '**发法**：默认当**视频**发（方便、能直接点播）；**只有对方明确说"要高清/原画/原始文件"时**，'
      + '才传 asFile=true 把视频当**文件**发（QQ 不转码 = 原画，但要点开下载才能看）。'
      + '**发到哪**：默认发当前会话；**主人在私聊里说"发到某个群"时**传 to="群名或群号"（跨会话发媒体只有主人的私聊能做，工具自己校验）。'
      + '**重复也要发**：只要对方要求发（哪怕这条刚才已经发过），就照发，不要以"已经发过了"为理由拒绝。'
      + '**只发媒体本身**；文字带**作品自己的文案**（工具会自动取好），对方说"不要文字"时才不带。"',
    category: 'media',
    icon: '🎬',
    parameters: {
      type: 'object',
      properties: {
        url: { type: 'string', description: '**把用户那条消息的完整文字原样放进来**（含链接、口令、以及他说的"发到X群/不带文字"等），不要只截链接 —— 工具要从里面读他的要求。' },
        say: { type: 'string', description: '如果用户说了"不带文字/只要图片/别带文案"，把这句原话也放进来（可留空）。' },
        noText: { type: 'boolean', description: '用户明确说"不要文字/只要图片/别带文案"时必须传 true。' },
        asFile: { type: 'boolean', description: '视频是否当文件发（原画、不被 QQ 转码）。只有对方明确说"要高清/原画/要原文件"时才传 true；平时不要传。' },
        to: { type: 'string', description: '要发到哪个会话（群名或群号，如"某个群"）。**只有主人的私聊里**才能用；群里不传（就发当前会话）。主人在私聊里说"发到某个群"时传它。' }
      },
      required: ['url']
    },
    async execute(ctx, args) {
      try {
        // 目标会话：默认当前会话；主人在私聊里给了 to 就发到那个群/会话
        const target = await pickTarget(ctx, args?.to);
        if (!target.ok) return err(target.error);
        const chatKey = target.chatKey;
        // 先花很小的代价解析出作品 id，用来判断"这条在本会话发过没有"（避免重复下载 + 重复发送）
        const wantFile = args?.asFile === true || (cfg() || {}).videoAsFile === true;
        const picked = extractLink(args?.url) || String(args?.url || '').trim();
        if (picked) {
          const quick = await resolveLink(picked, num((cfg() || {}).timeoutMs, 5000, 180000, 45000));
          const quickForm = quick.kind === 'note' ? 'note' : (wantFile ? 'video-file' : 'video');
          // 去重规则（用户定的，2026-10-07）：**用户要求发的，重复也照发** —— 这里不做任何拦截。
          // “只发一次”只适用于**机器人自己主动推送**的场景（B 站动态推送那种，在插件里管）。
          // 之前这里拦过，结果他说“要原视频”被拒 → 只能回“发不出第二遍” ✗，等于不理人。
          if (false && quick.ok && hasSent(chatKey, quick.id, quickForm)) {
            return ok({
              skipped: true,
              kind: quick.kind,
              id: quick.id,
              note: '这条**已经在这个会话里发过了**（24 小时内不重复发），所以我没有再发。直接告诉他"这条刚才发过了"即可，不要再试。'
            });
          }
        }
        const r = await handle(args?.url, {});
        if (!r.ok) return err(`抖音提取失败：${r.error}`);
        // "要不要文字"：**把所有可能拿到用户原话的地方全接上**（用户要求"能用就行"）。
        // 关键：只要模型把**用户那条完整消息**放进 url（哪怕带一堆口令文字），就能扫到"不带文字"。
        const sources = [
          args?.url, args?.caption, args?.say,
          ctx?.session?.triggerText, ctx?.session?.trigger, ctx?.session?.triggerSummary,
          ctx?.triggerText, ctx?.trigger, ctx?.lastUserMessage, ctx?.text, ctx?.message,
          recentUserText(chatKey, 5)
        ].map((x) => (typeof x === 'string' ? x : '')).filter(Boolean);
        const hit = sources.find((x) => wantsNoText(x));
        const noText = Boolean(hit) || args?.noText === true;
        if (noText) log(`判定"不要文字"（来源片段：${String(hit || args?.noText).slice(0, 50)}）`);
        else if (!sources.length) warn('拿不到任何用户原话，按"带文字"处理');
        const caption = cleanShareText(args?.caption);
        if (r.kind === 'note') {
          // （旧的 captionText 行已删除：与新规则重复声明，导致语法错误）          // 规则（用户定的）：默认带文字 = **抖音那条作品自己的文案**（从页面 meta 取）；
          // 只有用户明确说"不要文字/只发图"时才不带。模型塞进来的分享口令只在没有文案时兜底。
          const captionText = noText ? '' : (r.desc || cleanShareText(args?.caption) || `【抖音图文】${r.images} 张`);
          const sent = await sendImages(ctx, r.files, captionText, chatKey);
          if (!sent?.ok) return err(`图片已下好但发送失败：${sent?.error || '未知原因'}`);
          // markSent 已停用：用户要求发的重复也要发（记账只留给"机器人自己推送"的场景）
          void markSent;
          return ok({
            sent: true, kind: 'note', images: r.images, totalImages: r.total,
            sizeKB: r.details.map((d) => d.kb),
            note: `图文已发到会话里（${r.images} 张，含说明文字，一条消息）。用一句话回应即可，别复述。`
          });
        }
        // ⚠️ 视频段必须独占一条消息（bili-share 实测过：拼上文字会被协议端拒）
        // 默认**当文件发**：QQ 收到视频消息会自己再转码压缩（通常压到 480p），
        // 而当文件发不转码、点开下载就是原画（代价：不能直接点播）。
        // 发法：**默认当视频发**（方便、可直接点播，但画质受抖音省流版 + QQ 转码限制）；
        // 只有两种情况当**文件**发（QQ 不转码 = 原画）：① 模型按用户明确要求传了 asFile=true；
        // ② 设置里把「视频当文件发」打开（全局偏好）。
        const asFile = args?.asFile === true || (cfg() || {}).videoAsFile === true;        const fname = `抖音_${r.id}.mp4`;
        const seg = asFile
          ? { type: 'file', data: { file: r.files[0], name: fname } }
          : { type: 'video', data: { file: r.files[0] } };
        const rv = await ctx.sender.sendMedia(chatKey, [seg], {
          label: asFile ? `[抖音视频·原文件]:${r.id}` : `[抖音视频]:${r.id}`,
          dedupeKey: `douyin-video:${r.id}`
        });
        // 同 sendImages：核心返回 { sent, failed }，不能看 .ok
        const vSent = Array.isArray(rv?.sent) ? rv.sent.length : 0;
        const vFail = Array.isArray(rv?.failed) ? rv.failed.length : 0;
        // ⚠️ 判定口径：核心返回 { sent, failed }，而且**投递成功时 sent 也可能是空数组**
        //    （实测：协议端日志明确 "video upload completed / 发送：[视频]"，但这里 sent=0）。
        //    所以只有"明确报了 failed"才算失败；没报失败就当成功——否则就会像之前那样，
        //    视频明明发出去了，它却回群里说"发不出去"。
        if (vFail > 0) return err(`视频发送失败：${rv?.failed?.[0]?.error || '协议端返回失败'}`);
        // markSent 已停用（同上：用户要求发的重复也要发）
        // 视频：默认附**作品自己的文案**；用户明确说"不要文字"时不附
        const vCaption = noText ? '' : (r.desc || caption);
        if (vCaption) {
          try { await ctx.sender.sendTextBatch(chatKey, [vCaption]); } catch { /* 说明发失败不影响视频 */ }
        }
        return ok({
          sent: true, kind: 'video', asFile, sizeMB: +(r.bytes / 1048576).toFixed(1),
          note: asFile
            ? '【发送成功】视频已经当**原文件**发到会话里了（QQ 不会转码，点开下载就是原画）。'
              + '**直接说"视频发上来啦（原文件，画质没压）"就行，绝对不要说"发不出去/卡在发送"**。'
            : '【发送成功】视频已经发到会话里了（协议端已上传完成，群里能看到 [视频]）。'
              + '**直接说"视频发上来啦"就行，绝对不要说"发不出去/卡在发送"** —— 那是误报。'
        });
      } catch (error) {
        warn(`douyin_media 异常：${error?.stack ?? error}`);
        return err(`抖音提取出错：${error?.message ?? error}`);
      }
    }
  });

  api.registerTool({
    id: 'douyin_info',
    name: '抖音链接信息',
    description: '只解析抖音链接（是视频还是图文、几张图），**不发任何东西**。'
      + '适用：有人问"这个链接里是什么""有几张图"，但没让你把文件发出来时。',
    category: 'media',
    icon: '🔎',
    parameters: {
      type: 'object',
      properties: { url: { type: 'string', description: '抖音链接或包含链接的文字' } },
      required: ['url']
    },
    async execute(ctx, args) {
      try {
        const picked = extractLink(args?.url) || String(args?.url || '').trim();
        if (!picked) return err('没找到抖音链接');
        const resolved = await resolveLink(picked, num((cfg() || {}).timeoutMs, 5000, 180000, 45000));
        if (!resolved.ok) return err(resolved.error);
        const rendered = await renderDom(resolved.url, { timeoutMs: num((cfg() || {}).timeoutMs, 5000, 180000, 45000) });
        if (!rendered.ok) return err(rendered.error);
        if (resolved.kind === 'note') {
          const imgs = imagesFromDom(rendered.dom);
          return ok({ kind: 'note', id: resolved.id, images: imgs.length, note: '是图文，实际张数以页面为准；要发出来请用 douyin_media。' });
        }
        const vids = videoFromDom(rendered.dom);
        return ok({ kind: 'video', id: resolved.id, sources: vids.length, note: '是视频；要发出来请用 douyin_media。' });
      } catch (error) {
        return err(`解析出错：${error?.message ?? error}`);
      }
    }
  });
}

export function setup(api) {
  cfg = api.config;
  log = api.log;
  warn = api.warn;
  registerTools(api);
  const edge = findEdge((cfg() || {}).edgePath);
  log(`抖音分享技能已加载（无头渲染用：${edge ? edge.split('\\').pop() : '⚠️ 没找到 Edge，需在设置里填路径'}）`);
}

export function available() { return true; }

// 供测试/排障（加载器不消费）
export const internals = { extractLink, resolveLink, renderDom, imagesFromDom, videoFromDom, pruneMedia, handle, mediaDir, findEdge, hasSent, markSent };
