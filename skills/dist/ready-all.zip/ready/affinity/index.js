/**
 * affinity —— 好感度系统（LLM 型技能 / skills/）
 *
 * 分工（与 plugins/affinity-proactive 成对）：
 *   本技能：状态存档 + 计分引擎调用 + 三个工具（记分/查状态/特殊事件）+ 按等级动态注入语气与边界尺度
 *           + 提供 affinity.send 能力（用捕获到的发送通道发主动消息）
 *   插件：  定时按等级间隔/概率主动开话题（调用 chatCompletion 生成，再走 affinity.send）
 *
 * 为什么分两型：会不会让机器人说话、说什么，是「判断题」→ 工具由模型决定调用；
 * 到点该不该主动冒一句，是「机械动作」→ 插件定时器。判据见 src/skills/manifest.js 的 DIR_KIND。
 *
 * ── 关键实现约定（踩过的坑都在这里）────────────────────────────────────────
 *  · 计分全在 engine.js（纯函数），本文件只做 I/O 与工具外壳 —— 规则可以脱离宿主单测。
 *  · engine.js 用 `?t=` 动态 import：热重载只给 index.js 换 URL，静态 import 的
 *    engine.js 会走模块缓存，改了不生效（开发期反复调规则时会撞上）。
 *  · hook 的 ctx **没有** sender（orchestrator 只在工具执行 ctx 里给 sender/emit）：
 *    发送通道只能在工具 execute 里"顺手捡"，缓存起来给 affinity.send 用。
 *  · 提示词的动态部分用 promptSections(context)（context 带 chatKey/sessionId）：
 *    说话人 uid 在 before-context 从 triggerEntries 捕获，按 sessionId 暂存 ——
 *    promptSections 本身拿不到本轮说话人。
 *  · after-response 每轮都会跑（不管有没有调工具）：在这里刷新"最近互动"、
 *    惰性结算 7 天规则、以及「被她主动找·当天首次 +1」。
 *
 * 存档：data/affinity.json（原子写：tmp + rename），结构见 engine.newState()。
 * 插件在 data/affinity-proactive.json 里记「她今天主动找过谁」，本技能只读它。
 */

import fs from 'node:fs';
import path from 'node:path';
import { DATA_DIR, getConfig } from '../../src/config.js';

export const BUILD_TAG = 'v1.3.0';

let api = null;
let engine = null;

/** 存档读缓存：{ file, mtimeMs, state } —— 每次读盘太重，按 mtime 失效。 */
let cache = { file: '', mtimeMs: 0, state: null };
/** 发送通道缓存（工具执行时顺手捡）。 */
let chSender = null;
let chEmit = null;
let chStore = null;
/** 本轮说话人：sessionId -> [uid]（before-context 收集，promptSections 消费）。 */
const pendingSpeakers = new Map();
/** 读档时发现旧 v1（按会话分裂）结构 → 置位，尽快备份并落盘 v2。 */
let migrationPending = false;

const stateFile = () => path.join(DATA_DIR, 'affinity.json');
const proactiveFile = () => path.join(DATA_DIR, 'affinity-proactive.json');

/* ───────────────────────────── 存档 I/O ───────────────────────────── */

function readState() {
  const file = stateFile();
  let mtimeMs = 0;
  try { mtimeMs = fs.statSync(file).mtimeMs; } catch { /* 没文件 */ }
  if (cache.state && cache.file === file && cache.mtimeMs === mtimeMs) return cache.state;

  let raw = null;
  try { raw = JSON.parse(fs.readFileSync(file, 'utf8')); } catch (error) {
    if (mtimeMs) api?.warn?.(`好感度存档读取失败（当作空档）：${error?.message ?? error}`);
  }
  // v1（按会话分裂）→ v2（跨会话按人共享）：每次读档都在内存里升级，幂等
  migrationPending = Boolean(raw && engine.isLegacyLayout(raw));
  const state = engine.migrateState(raw);
  cache = { file, mtimeMs, state };
  return state;
}

/** 原子写存档（tmp + rename）。首次覆盖 v1 档前会先留备份。 */
function saveState(state) {
  const file = stateFile();
  try {
    fs.mkdirSync(DATA_DIR, { recursive: true });
    // 旧 v1 档第一次被覆盖前先留个备份（无论谁先触发写入都能兜住）
    if (migrationPending) {
      migrationPending = false;
      try { if (fs.existsSync(file)) fs.copyFileSync(file, `${file}.bak-v1`); } catch { /* 备份失败不拦写入 */ }
    }
    state.savedAt = Date.now();
    const tmp = `${file}.${process.pid}.tmp`;
    fs.writeFileSync(tmp, JSON.stringify(state, null, 1), 'utf8');
    fs.renameSync(tmp, file);
    cache = { file: '', mtimeMs: 0, state: null }; // 下次读取重新加载
    return true;
  } catch (error) {
    api?.warn?.(`好感度存档写入失败：${error?.message ?? error}`);
    return false;
  }
}

/** 发现旧 v1 档时尽快落盘 v2（幂等）。 */
function persistMigration(state) {
  if (!migrationPending) return false;
  if (!saveState(state)) return false;
  api?.log?.('好感度存档已升级 v1 → v2：同一个人跨群/私聊共用一份记录（原档备份 affinity.json.bak-v1）');
  return true;
}

/** 只读插件的「她主动找过谁」标记。 */
function readProactiveMarks() {
  try {
    const j = JSON.parse(fs.readFileSync(proactiveFile(), 'utf8'));
    return (j && typeof j === 'object' && j.chats && typeof j.chats === 'object') ? j.chats : {};
  } catch { return {}; }
}

/* ───────────────────────────── 上下文小工具 ───────────────────────────── */

function lastNonSelfUid(ctx) {
  try {
    const entries = Array.isArray(ctx?.session?.trigger) ? ctx.session.trigger : [];
    for (let i = entries.length - 1; i >= 0; i--) {
      const m = entries[i];
      if (m && !m.self && m.senderId) return String(m.senderId);
    }
  } catch { /* 拿不到就算了 */ }
  return '';
}

/** 目标 QQ：显式 target > 私聊对端 > 本轮最后说话的人。 */
function resolveTarget(ctx, targetArg) {
  const t = String(targetArg ?? '').trim();
  if (/^\d+$/.test(t)) return t;
  const ck = String(ctx?.chatKey || '');
  if (ck.startsWith('private:')) return ck.slice('private:'.length);
  return lastNonSelfUid(ctx);
}

function labelOf(uid) {
  try { return String(getConfig()?.memberNotes?.[uid] || '').trim() || `QQ:${uid}`; } catch { return `QQ:${uid}`; }
}

/** 「备注名(QQ:xxx)」；没有备注名时只留 QQ:xxx，避免出现 QQ:xxx(QQ:xxx)。 */
function labelWithId(uid) {
  const name = labelOf(uid);
  return name.startsWith('QQ:') ? name : `${name}(QQ:${uid})`;
}

/** 工具执行时顺手捡发送通道（hook ctx 里没有 sender/emit）。 */
function captureChannel(ctx) {
  if (ctx?.sender && typeof ctx.sender.sendTextBatch === 'function') chSender = ctx.sender;
  if (typeof ctx?.emit === 'function') chEmit = ctx.emit;
  if (ctx?.store) chStore = ctx.store;
}

function parseArgs(args) {
  if (typeof args === 'string') { try { return JSON.parse(args); } catch { return {}; } }
  return args || {};
}

/* ───────────────────────────── 渲染 ───────────────────────────── */

function renderLogResult(uid, res, meta = {}) {
  const info = engine.levelInfo(res.level);
  const dir = meta.direction === 'down' ? 'down' : 'up';
  const sLabel = engine.STRENGTH_LABELS[engine.clampStrength(meta.strength)] || '';
  const tagText = meta.tag ? `·${meta.tag}` : '';
  const head = dir === 'down'
    ? `好感-${sLabel}${meta.trust ? '（辜负信任）' : ''}${tagText}`
    : `好感+${sLabel}${tagText}`;
  const L = [];
  if (res.applied) {
    const sign = res.delta > 0 ? `+${res.delta}` : String(res.delta);
    L.push(`已记录「${head}」于 ${labelWithId(uid)}：${sign} 分 → 当前 ${res.score} 分（Lv${res.level} ${info.name}）。`);
  } else {
    L.push(`未计分（${head}，${labelWithId(uid)}）：${res.reasons.join('；') || '未生效'}。`);
  }
  if (res.upgraded) L.push(`⬆️ 关系升到 Lv${res.level}「${info.name}」——此后态度与边界尺度都按新等级处理（注意观察期：24 小时内加分减半）。`);
  if (res.downgraded) L.push(`⬇️ 关系降到 Lv${res.level}「${info.name}」——此后态度与边界尺度都按新等级处理。`);
  if (res.applied && !res.upgraded && !res.downgraded && res.reasons.length) L.push(`（${res.reasons.join('；')}）`);
  L.push('提醒：结果只给你自己看，不要在回复里提分数/等级/系统。');
  return L.join('\n');
}

function renderStatus(uid, sum) {
  const info = engine.levelInfo(sum.level);
  const L = [];
  L.push(`【好感度状态】${labelWithId(uid)}`);
  L.push(`· 等级：Lv${sum.level} ${info.name}（${sum.min}~${sum.max} 分）｜当前 ${sum.effectiveScore} 分`
    + `${sum.sick ? `（生病临时 +5 表现，真实 ${sum.score} 分）` : ''}`);
  L.push(sum.nextMin == null ? '· 已到最高级（260 分封顶）' : `· 距下一级还需 ${sum.toNext} 分（Lv${sum.level + 1} 起于 ${sum.nextMin} 分）`);
  L.push(`· 今日加分：${sum.gainUsed}/${sum.gainCap}${sum.inCooldown ? '｜冷却期中（加分减半）' : ''}`
    + `${sum.observeUntil > Date.now() ? '｜升级观察期中（加分减半）' : ''}`);
  L.push(`· 特殊状态：${[sum.sick ? '生病' : '', sum.perfAfter ? '演出后' : '', sum.exposed ? '被戳穿' : ''].filter(Boolean).join('、') || '正常'}`);
  if (sum.flags?.secretEdge) L.push('· 已触发过「秘密边缘」事件');
  if (sum.history?.length) {
    L.push('· 最近记录：');
    for (const h of sum.history.slice(-5).reverse()) {
      L.push(`   - ${h.label || h.event}（${h.delta > 0 ? '+' : ''}${h.delta} → ${h.score}）`);
    }
  }
  L.push('（这些只给你自己看，不要在回复里透露。）');
  return L.join('\n');
}

/* ───────────────────────────── 工具 ───────────────────────────── */

function toolLog() {
  return {
    id: 'log',
    name: '记录好感度变化',
    description:
      '记录一次她对某人的好感变化。**你只判断「方向 + 强度」，具体加/扣多少由系统按当前好感等级换算**：'
      + '好感低时，普通、自然的聊天也算涨；好感高时普通聊天不再涨，只有更深入的相处才算（扣分同理：好感高时小事不计较，但「辜负信任」照样伤）。'
      + '参数：direction=up（加分）或 down（扣分）；strength=1（轻）/2（中）/3（重）；reason=一句话说明发生了什么（必填）；tag=这类行为的短标签（同类会递减/冷却，请复用同一个词）；target=对方 QQ（群里必填）；trust=true 仅用于「辜负信任」的扣分，不受高好感衰减。'
      + '强度参考：轻=普通善意、自然聊天、礼貌的距离感；中=有质量的互动（记得她说过的小事、尊重她的边界、安静陪着）；重=关键/稀有、真切感人的行为。'
      + 'tag 建议复用（也可自拟短词）——加分：chat 闲聊 / listen 听歌练声 / remember 记住小事 / boundary 尊重边界 / accompany 陪着 / humor 顺着玩 / care 帮她小事 / keep_secret 守密；'
      + '扣分：press_secret 追问隐私 / press_leave 逼问留下理由 / seller 当售票员 / nag 总提水妖唱歌 / dismiss 敷衍 / spam 刷屏 / joke_identity 身份玩笑过火 / force_relation 定义关系 / dump 倒情绪垃圾 / disrespect 不尊重奥黛塔。'
      + '判定要点（越界线随好感外移）：好感低时，打听私事 / 套近乎 / 追问身份就算越界（可 down）；好感高时这些无所谓，真正伤她的是情感怠慢和辜负信任。拿不准就先调 affinity__status 看当前等级。'
      + '一次真实的事只记一次，不要为刷分反复记；结果只给你自己看，绝不要说给用户。',
    category: 'model',
    icon: '💗',
    defaultEnabled: true,
    parameters: {
      type: 'object',
      properties: {
        direction: { type: 'string', enum: ['up', 'down'], description: 'up=加分；down=扣分。' },
        strength: { type: 'number', enum: [1, 2, 3], description: '强度：1 轻 / 2 中 / 3 重（由你判断）。' },
        reason: { type: 'string', description: '一句话说明发生了什么（必填，写进记录便于复盘）。' },
        tag: { type: 'string', description: '这类行为的短标签（同类会递减/冷却，请复用同一个词，如 chat / listen / press_secret）。' },
        trust: { type: 'boolean', description: '仅扣分时用：true=辜负信任（泄密/背叛/强行定义关系/不尊重奥黛塔），不受高好感衰减。' },
        target: { type: 'string', description: '对方 QQ 号。群里多人时**必须**填（从「名字(QQ:123456)」里取）；私聊可不填。' }
      },
      required: ['direction', 'strength', 'reason']
    },
    async execute(ctx, args) {
      captureChannel(ctx);
      const raw = parseArgs(args);
      const chatKey = String(ctx?.chatKey || '');
      if (!chatKey) return { content: '错误：没有会话上下文', isError: true };
      const uid = resolveTarget(ctx, raw.target);
      if (!uid) return { content: '错误：拿不到对方 QQ 号（群里请显式填 target）。', isError: true };

      const direction = raw.direction === 'down' ? 'down' : 'up';
      const strength = engine.clampStrength(raw.strength);
      const tag = String(raw.tag || (direction === 'down' ? 'other' : 'chat')).slice(0, 40);
      const trust = raw.trust === true;

      const now = Date.now();
      const state = readState();
      const user = engine.ensureUser(state, chatKey, uid);
      const idle = engine.applyIdleRules(user, now);   // 先用旧的 lastInteraction 判断 7 天
      engine.touchInteraction(user, now);              // 再刷新互动时间

      const res = engine.applyImpression(user, { direction, strength, tag, trust, now });
      if (raw.reason && res.applied && user.history.length) {
        user.history[user.history.length - 1].note = String(raw.reason).slice(0, 120);
      }
      saveState(state);

      const head = idle.notes.length ? `${idle.notes.join('；')}\n` : '';
      return { content: head + renderLogResult(uid, res, { direction, strength, tag, trust }) };
    }
  };
}

function toolSpecial() {
  return {
    id: 'special',
    name: '记录好感度特殊事件',
    description:
      '记录一次"特殊事件"（不走分数曲线，按各自规则处理）：'
      + 'apology=对方踩过界后真诚道歉（恢复上次扣分的 50%）；'
      + 'perf_after=她刚演出完（当天每次加分额外 +1）；'
      + 'sick_on / sick_off=生病状态开始 / 结束（生病时临时 +5 表现、会黏人）；'
      + 'exposed_on / exposed_off=被奥黛塔戳穿后短暂破防的开始 / 结束（只有好感 3 级以上能察觉）；'
      + 'invite_song=邀她唱一段/合唱（固定 +2）、gift=送礼/打赏（固定 +3）、'
      + 'festival=节日/生日问候（固定 +2）、defend=替她解围（固定 +3）'
      + '—— 这四个是"一次性加分事件"：每人每类 24 小时只能记一次、计入当日加分上限，真实的才记，别当刷分按钮。'
      + '这些通常由剧情触发，不要凭空调用。结果只给你自己看，不要透露给用户。',
    category: 'model',
    icon: '🎭',
    defaultEnabled: true,
    parameters: {
      type: 'object',
      properties: {
        action: { type: 'string', enum: ['apology', 'perf_after', 'sick_on', 'sick_off', 'exposed_on', 'exposed_off', 'invite_song', 'gift', 'festival', 'defend'], description: '要设置/结束的特殊事件。' },
        target: { type: 'string', description: '对方 QQ 号。群里多人时填；私聊可不填（默认对端）。' },
        note: { type: 'string', description: '一句备注（可选）。' }
      },
      required: ['action']
    },
    async execute(ctx, args) {
      captureChannel(ctx);
      const raw = parseArgs(args);
      const action = String(raw.action || '').trim();
      const chatKey = String(ctx?.chatKey || '');
      if (!chatKey) return { content: '错误：没有会话上下文', isError: true };
      if (!engine.SPECIALS.includes(action)) return { content: `错误：未知 action「${action}」。`, isError: true };
      const uid = resolveTarget(ctx, raw.target);
      if (!uid) return { content: '错误：拿不到对方 QQ 号（群里请显式填 target）。', isError: true };

      const now = Date.now();
      const state = readState();
      const user = engine.ensureUser(state, chatKey, uid);
      const idle = engine.applyIdleRules(user, now);
      engine.touchInteraction(user, now);

      const res = action === 'apology' ? engine.applyApology(user, now) : engine.applySpecial(user, action, now);
      if (raw.note && res.applied && user.history.length) {
        user.history[user.history.length - 1].note = String(raw.note).slice(0, 120);
      }
      saveState(state);

      const info = engine.levelInfo(user.level);
      const line = res.applied
        ? `已记录特殊事件「${action}」于 ${labelWithId(uid)}：${res.reasons.join('；')}（当前 ${user.score} 分 · Lv${user.level} ${info.name}）。`
        : `未生效（${action}，${labelWithId(uid)}）：${res.reasons.join('；') || '无变化'}。`;
      const head = idle.notes.length ? `${idle.notes.join('；')}\n` : '';
      return { content: `${head}${line}\n提醒：这些只给你自己看，不要透露给用户。` };
    }
  };
}

function toolStatus() {
  return {
    id: 'status',
    name: '查看好感度状态',
    description: '查看某个人的好感度等级、当前分数、距下一级还差多少、今日加分用量、冷却/观察期、特殊状态与最近记录。'
      + '拿不准某个行为算不算加分、或想确认当前等级该用什么语气时先查一下。结果只给你自己看，不要透露给用户。',
    category: 'model',
    icon: '📊',
    defaultEnabled: true,
    parameters: {
      type: 'object',
      properties: {
        target: { type: 'string', description: '对方 QQ 号。群里多人时填；私聊可不填（默认对端）。' }
      }
    },
    async execute(ctx, args) {
      captureChannel(ctx);
      const raw = parseArgs(args);
      const chatKey = String(ctx?.chatKey || '');
      if (!chatKey) return { content: '错误：没有会话上下文', isError: true };
      const uid = resolveTarget(ctx, raw.target);
      if (!uid) return { content: '错误：拿不到对方 QQ 号（群里请显式填 target）。', isError: true };
      const now = Date.now();
      const state = readState();
      const user = engine.ensureUser(state, chatKey, uid);
      const idle = engine.applyIdleRules(user, now);
      if (idle.changed) saveState(state);
      const sum = engine.summarize(user, now);
      return { content: renderStatus(uid, sum) };
    }
  };
}

/* ───────────────────────────── 生命周期 ───────────────────────────── */

export async function setup(a) {
  api = a;
  // engine 用带时间戳的动态 import：热重载时能拿到改动后的规则（静态 import 会命中模块缓存）
  engine = await import(`./engine.js?t=${Date.now()}`);
  a.registerTool(toolLog());
  a.registerTool(toolStatus());
  a.registerTool(toolSpecial());
  try { persistMigration(readState()); } catch { /* 首次迁移失败不影响加载，下次写档再升 */ }
  a.log(`好感度系统已加载（${BUILD_TAG}）｜跨会话按人共享｜工具 affinity__log / affinity__status / affinity__special｜存档 ${stateFile()}`);
}

export function activate() {
  const st = readState();
  persistMigration(st);
  const people = Object.keys(st.users || {}).length;
  const chats = Object.keys(st.chats || {}).length;
  api?.log?.(`好感度已启用（同一个人跨会话共用一份）：${people} 人 / ${chats} 个会话有成员记录`);
}

/* ───────────────────────────── 钩子 ───────────────────────────── */

export const hooks = {
  /** 记下 store（发送兜底用）+ 本轮说话人（动态语气注入用）。 */
  async 'before-context'(ctx = {}) {
    try {
      if (ctx.store) chStore = ctx.store;
      const entries = Array.isArray(ctx.triggerEntries) ? ctx.triggerEntries : [];
      const uids = [];
      const seen = new Set();
      for (const e of entries) {
        const uid = String(e?.senderId ?? '');
        if (!uid || e?.self || seen.has(uid)) continue;
        seen.add(uid); uids.push(uid);
      }
      const key = String(ctx.sessionId || ctx.chatKey || '');
      if (key) {
        pendingSpeakers.set(key, uids);
        if (pendingSpeakers.size > 50) {
          const first = pendingSpeakers.keys().next().value;
          pendingSpeakers.delete(first);
        }
      }
    } catch { /* 收集失败只是少几行语气注入 */ }
  },

  /**
   * 每轮跑完：刷新"最近互动" + 惰性 7 天规则 + 结算「被她主动找·当天首次 +1」。
   * 不看本轮有没有调工具 —— 只要发生了对话，就算互动。
   */
  async 'after-response'(ctx = {}) {
    try {
      const chatKey = String(ctx?.chatKey || '');
      if (!chatKey) return;
      const uid = resolveTarget(ctx, '');
      if (!uid) return;
      const now = Date.now();
      const state = readState();
      const user = engine.ensureUser(state, chatKey, uid);
      const idle = engine.applyIdleRules(user, now);
      engine.touchInteraction(user, now);

      // 插件今天是否主动找过这个人 → 当天首次互动 +1
      // （跨会话：她在群里主动找过，他改在私聊里回话也照样算）
      const marks = readProactiveMarks();
      const day = engine.dayKeyOf(now);
      let sheInit = null;
      for (const m of Object.values(marks || {})) {
        if (m && m.dayKey === day && (!m.uid || String(m.uid) === uid)) {
          sheInit = engine.applySheInitBonus(user, now);
          break;
        }
      }
      saveState(state);
      if (idle.changed) api?.log?.(`${chatKey} ${uid}：${idle.notes.join('；')}`);
      if (sheInit?.applied) api?.log?.(`${chatKey} ${uid}：${sheInit.reasons.join('；')}`);
    } catch (error) {
      api?.warn?.(`after-response 结算失败：${error?.message ?? error}`);
    }
  }
};

/* ───────────────────────────── 动态提示词 ───────────────────────────── */

/**
 * 按本轮说话人注入各等级的语气指令。
 * context = skillContext（含 chatKey / sessionId），说话人 uid 由 before-context 暂存。
 */
export function promptSections(context = {}) {
  if (!engine) return [];
  const chatKey = String(context.chatKey || '');
  if (!chatKey) return [];
  const key = String(context.sessionId || chatKey);
  const uids = [];
  const seen = new Set();
  for (const uid of (pendingSpeakers.get(key) || [])) { if (!seen.has(uid)) { seen.add(uid); uids.push(uid); } }
  if (chatKey.startsWith('private:')) {
    const p = chatKey.slice('private:'.length);
    if (!seen.has(p)) { seen.add(p); uids.push(p); }
  }
  if (!uids.length) return [];

  const now = Date.now();
  const state = readState();
  const lines = [];
  for (const uid of uids.slice(0, 3)) {
    const user = engine.getUser(state, chatKey, uid);
    const sum = user ? engine.summarize(user, now) : { level: 0, effectiveScore: 0, sick: false, perfAfter: false, exposed: false };
    const a = engine.ATTITUDES[sum.level] || engine.ATTITUDES[0];
    const b = engine.BOUNDARY_BY_LEVEL[sum.level] || engine.BOUNDARY_BY_LEVEL[0];
    const extra = [];
    if (sum.sick) extra.push('生病中：距离感下降、会黏人（临时表现分已计入态度）');
    if (sum.perfAfter) extra.push('刚演出完：对观众温柔、对 3 级以上的人会多说一句');
    if (sum.exposed) extra.push('刚被奥黛塔戳穿：短暂破防（3 级以上才看得出）');
    lines.push(`· ${labelWithId(uid)}：Lv${sum.level} ${engine.levelInfo(sum.level).name} —— `
      + `语气${a.tone}；回复${a.reply}；主动${a.initiate}；玩笑${a.joke}；温柔${a.gentle}；边界${a.boundary}。`
      + `\n  当前等级下的越界尺度：值得加分的是「${b.respect}」；可能越界的是「${b.breach}」。`
      + (extra.length ? `\n  ［${extra.join('；')}］` : ''));
  }

  const block = [
    '【当前好感度·按此调整你对每个人的态度】',
    ...lines,
    '对不同的人用不同亲疏，别对谁都一个态度。这些只是你自己的感觉：**绝不要**在回复里提分数、等级、档次或系统。'
  ].join('\n');
  return [{ id: 'affinity-live', title: '', priority: 67, content: block }];
}

/* ───────────────────────────── 能力 ───────────────────────────── */

/** 单个用户的好感度摘要（给记忆页/控制台用）。 */
function userSummary(uid, user, now) {
  const sum = engine.summarize(user, now);
  return {
    uid: String(uid),
    name: labelOf(uid),
    score: sum.score,
    effectiveScore: sum.effectiveScore,
    level: sum.level,
    levelName: sum.name,
    scoreLevel: sum.scoreLevel,
    min: sum.min,
    max: sum.max,
    nextMin: sum.nextMin,
    toNext: sum.toNext,
    gainUsed: sum.gainUsed,
    gainCap: sum.gainCap,
    inCooldown: sum.inCooldown,
    sick: sum.sick,
    perfAfter: sum.perfAfter,
    exposed: sum.exposed,
    secretEdge: Boolean(sum.flags?.secretEdge),
    lastInteractionAt: sum.lastInteractionAt,
    history: sum.history.slice(-5)
  };
}

export const providers = {
  /**
   * 只读好感度。
   * · 不带 chatKey：全局概览（总人数 + 各会话的成员数与最高关系）。
   * · 带 chatKey：`users` 是**全局名单**（徽标按 uid 查同一份，跨会话一致），
   *              `chatMates` 是"在这个会话出现过的人"——UI 用它限定本页补充行只列本会话的人。
   */
  'affinity.state': (args = {}) => {
    const now = Date.now();
    const state = readState();
    const chatKey = String(args?.chatKey || '');
    if (!chatKey) {
      const users = state.users || {};
      const chats = Object.entries(state.chats || {}).map(([ck, cv]) => {
        const uids = Object.keys(cv?.members || {});
        let top = null;
        for (const uid of uids) {
          const u = users[uid];
          if (!u) continue;
          const lv = Number(u.level) || 0;
          if (!top || lv > top.level || (lv === top.level && (Number(u.score) || 0) > top.score)) {
            top = { uid: String(uid), level: lv, score: Number(u.score) || 0 };
          }
        }
        return {
          chatKey: ck,
          count: uids.filter((uid) => Boolean(users[uid])).length,
          top: top ? { ...top, levelName: engine.levelInfo(top.level).name } : null
        };
      });
      return { ok: true, totalUsers: Object.keys(users).length, chats };
    }
    const chatMates = engine.membersOfChat(state, chatKey);
    const list = Object.entries(state.users || {}).map(([uid, u]) => userSummary(uid, u, now));
    list.sort((a, b) => b.level - a.level || b.score - a.score);
    return { ok: true, chatKey, users: list, chatMates };
  },

  /**
   * 手动调整：delta 加减分 / score 设分 / level 设等级（优先级 level > score > delta）。
   * 改的是**全局那一份**记录（chatKey 只用来顺带登记会话成员）。
   */
  'affinity.set': (args = {}) => {
    const chatKey = String(args?.chatKey || '');
    const uid = String(args?.uid || '').trim();
    if (!chatKey || !/^\d+$/.test(uid)) return { ok: false, error: '需要 chatKey 与数字 uid' };
    const now = Date.now();
    const state = readState();
    const user = engine.ensureUser(state, chatKey, uid);
    const res = engine.applyManual(user, { delta: args?.delta, score: args?.score, level: args?.level }, now);
    saveState(state);
    return { ok: true, result: res, user: userSummary(uid, user, now) };
  },

  /**
   * 发送一条主动消息（插件 affinity-proactive 用）。
   * 优先走核心发送队列（限频/去重/留档），本技能在工具执行时捕获过通道；没有则交给插件走 HTTP 兜底。
   */
  'affinity.send': async (args = {}) => {
    const chatKey = String(args?.chatKey || '');
    const text = String(args?.text || '').trim();
    if (!chatKey || !text) return { ok: false, reason: '缺少 chatKey 或 text' };
    if (!chSender) return { ok: false, reason: '还没有捕获到发送通道（该会话还没跑过带好感度工具的对话）' };
    try {
      const r = await chSender.sendTextBatch(chatKey, [text]);
      if (typeof chEmit === 'function') chEmit('chat-update', chatKey);
      return { ok: true, via: 'sender', sent: r?.sent?.length ?? 0 };
    } catch (error) {
      return { ok: false, reason: String(error?.message ?? error) };
    }
  }
};

/** 测试/排障出口。 */
export const __internals = { readState, saveState, readProactiveMarks, resolveTarget, stateFile, proactiveFile };
