/**
 * affinity/engine.js —— 好感度计分引擎（纯函数，无 I/O、无依赖）
 *
 * 把《沃雅妮莎·水妖歌者版 好感度系统设计文档》的全部规则实现成一组
 * **确定性纯函数**：同样输入必得同样输出，可脱离 QQ Agent 单独 node 跑测试。
 * index.js 负责落盘/读取/工具外壳，本文件只管算分。
 *
 * 规则来源与实现落点（2026-10 改版：从固定分值表 → 大方向 + 分级难度）：
 *   一、六级分级（0~260）              → LEVELS / levelOf（名字：陌生/面熟/熟络/亲近/交心/挚友）
 *   二、各等级态度                      → ATTITUDES（给提示词用）
 *   三、模型只给「方向 + 强度」          → applyImpression({direction,strength,tag,trust})
 *   四、加分难度随等级（低易高难）        → gainValue / dailyGainCap
 *   五、扣分难度随等级（高好感衰减）      → deductValue（trust 类不衰减）
 *   六、同类递减 / 冷却 / 观察期 / 每日上限 → applyUp / applyDown
 *   七、边界尺度随等级漂移（提示词用）    → BOUNDARY_BY_LEVEL
 *   八、特殊状态（生病/演出后/被戳穿）    → sickUntil/perfAfterUntil/exposedUntil + applySpecial
 *   九、特殊修正                        → applyIdleRules / applySheInitBonus / applyApology
 *   十、控制台手动调整                  → applyManual
 *   十一、跨会话按人全局唯一             → newState(v2) / ensureUser / membersOfChat / migrateState
 *   十二、一次性加分特殊事件（2026-10 放宽增长）→ SPECIAL_BONUS / awardBonus
 *
 * 设计上的两处取舍（文档未明确、这里定死并留痕）：
 *   · 「减半不叠加」：冷却期减半与观察期减半同时命中时只减半一次（取单一减弱），
 *     而不是叠成四分之一 —— 否则连续扣分 + 刚升级会让玩家几乎加不动分。
 *   · 「连续7天不互动 -2 不降级」：这次扣分**跳过当次等级重算**（分数照扣），
 *     后续正常事件照常按分数重算等级 —— 忠实于"扣分但不因此降级"。
 */

export const SCORE_MAX = 260;

/** 六级分级（文档 §一）。min 为进入该级的分数下限；name 为展示名（用户选定的 A 套）。 */
export const LEVELS = [
  { level: 0, name: '陌生', min: 0 },
  { level: 1, name: '面熟', min: 20 },
  { level: 2, name: '熟络', min: 50 },
  { level: 3, name: '亲近', min: 90 },
  { level: 4, name: '交心', min: 140 },
  { level: 5, name: '挚友', min: 200 }
];

/** 各级态度（文档 §二，压缩成给模型的一段指令；示例各留一条最典型的）。 */
export const ATTITUDES = {
  0: {
    tone: '礼貌、简短、有距离但不冷',
    reply: '功能性为主，短句（"嗯。""好。""演出在晚上。"）',
    initiate: '几乎不主动',
    joke: '不接，最多一个"哈哈"',
    gentle: '不体现，不会对陌生人顺手关心',
    boundary: '问私人问题直接模糊带过',
    example: '“你唱得真好。”→“谢谢。” / “你住哪？”→“不告诉你。”'
  },
  1: {
    tone: '稍微放松，会多给半句',
    reply: '短句为主，偶尔一个轻调侃',
    initiate: '极少，可能你出现时先说一句"来了"',
    joke: '可以接一句，但不追',
    gentle: '只在明显场景体现，一句就收（"外面冷"）',
    boundary: '私人问题仍然绕开',
    example: '“今天好累。”→“那早点睡。”'
  },
  2: {
    tone: '自然、友好、接得住话',
    reply: '可以连续 2~3 句，有来有回',
    initiate: '偶尔，但话说一半（"今天练声想到一件事。"）',
    joke: '顺手逗一下，一句就收',
    gentle: '注意到状态提一句，不追问',
    boundary: '允许绕着说，不机械拒绝，核心仍不透露',
    example: '“我干了一件蠢事。”→“哈哈，行。……所以你到底怎么想的？”'
  },
  3: {
    tone: '明显放松，有温度但不黏',
    reply: '可以主动分享日常，连续 3~5 句（自然节奏）',
    initiate: '会主动发消息，频率低但有分量（"外面雪很大，你那边呢。"）',
    joke: '可以故意逗你，看你上钩再碰一下',
    gentle: '顺手做小事，关心完就收（"到了说一声。"）',
    boundary: '偶尔泄露一点真实情绪，但不完整解释',
    example: '“你今天怎么主动找我了？”→“……不行吗？”'
  },
  4: {
    tone: '亲近、自然，偶尔有短暂的柔软',
    reply: '会记着你的事，会主动问，但不高频',
    initiate: '会记挂你（几天没出现会说"最近没见你。"）',
    joke: '可以互相吐槽，被戳穿时短暂破防',
    gentle: '做具体的事，不只是说（"你声音不太对，先去喝水。"）',
    boundary: '允许你靠近秘密边缘，但仍不会全说',
    example: '“你是不是在担心我？”→“……你想多了。”'
  },
  5: {
    tone: '真实、坦率、不端着',
    reply: '可以沉默，可以只说"嗯"，也可以忽然说一句重的',
    initiate: '稀有但真诚（突然一句"今天想到你了。"，然后不解释）',
    joke: '小腹黑还在，但底色是干净的温柔',
    gentle: '不围着你转，但你知道她在',
    boundary: '允许你问一些别人不能问的；可能不答，但不会用"变回水里"挡你',
    example: '“你为什么留下？”→“……因为还有人听。”'
  }
};

/**
 * 计分哲学（2026-10 改版）：不再用固定行为分值表。
 * 模型只给「方向 + 强度」做**大方向**判断，实际分值与难度由引擎按**当前等级**决定：
 *   · 低好感易涨（普通自然聊天就算）；高好感难涨（只认深度，且幅度小）。
 *   · 扣分在高好感衰减；但"辜负信任"类不衰减（信任是真正的软肋）。
 * 强度语义（模型判断）：1 轻 / 2 中 / 3 重。
 */
export const STRENGTH_LABELS = { 1: '轻', 2: '中', 3: '重' };

export function clampStrength(strength) {
  const s = Math.round(Number(strength) || 0);
  return s < 1 ? 1 : (s > 3 ? 3 : s);
}

/** 加分曲线：Lv0-1 → 2/3/5；Lv2-3 → 1/2/3；Lv4-5 → 1/1/2（2026-10 放宽：高好感「轻」也给一点点）。 */
export function gainValue(level, strength) {
  const s = clampStrength(strength);
  const lv = Math.max(0, Math.min(5, Math.round(Number(level) || 0)));
  const table = lv <= 1 ? [2, 3, 5] : (lv <= 3 ? [1, 2, 3] : [1, 1, 2]);
  return table[s - 1];
}

/** 扣分曲线：Lv0-3 → 1/2/3；Lv4 → 1/1/2；Lv5 → 0/1/1；trust=true（辜负信任）全程 1/2/3 不衰减。 */
export function deductValue(level, strength, { trust = false } = {}) {
  const s = clampStrength(strength);
  if (trust) return s;
  const lv = Math.max(0, Math.min(5, Math.round(Number(level) || 0)));
  if (lv <= 3) return s;
  return (lv === 4 ? [1, 1, 2] : [0, 1, 1])[s - 1];
}

/** 每日加分上限：低好感放宽、高好感收紧。 */
export function dailyGainCap(level) {
  const lv = Math.max(0, Math.min(5, Math.round(Number(level) || 0)));
  if (lv <= 1) return 8;
  if (lv <= 3) return 6;
  return 4;
}

/**
 * 「边界尺度」随等级漂移（给提示词用；具体判定由模型做，这里只给方向）：
 *   respect：当前等级下"尊重边界"通常指什么（值得记 up）
 *   breach： 当前等级下"触碰边界"通常指什么（可记 down）
 * 低好感：隐私/靠近类容易算越界；高好感：这些已无所谓，只有"情感怠慢/辜负信任"才伤。
 */
export const BOUNDARY_BY_LEVEL = {
  0: { respect: '保持礼貌距离、不打听私事', breach: '问私事 / 套近乎 / 追问身份或水妖 / 提售票' },
  1: { respect: '保持礼貌距离，她不愿说的不追', breach: '私人问题、过度亲近' },
  2: { respect: '绕着打听时见好就收', breach: '继续追问核心隐私' },
  3: { respect: '一般私人话题自然聊、不硬挖', breach: '追问呼啸社 / 逼她解释留下的理由' },
  4: { respect: '触及秘密边缘但忍住不追问', breach: '情感怠慢：敷衍她唱歌 / 倒情绪垃圾 / 拿她身份开过火的玩笑' },
  5: { respect: '可以问别人不能问的（她可能不答，但不当冒犯）', breach: '辜负信任：把秘密往外说 / 强行定义关系 / 对奥黛塔不尊重（记 down 时 trust=true）' }
};

/**
 * 一次性加分型特殊事件（2026-10 放宽增长限制新增）：
 * 固定值 + 每人每类 24 小时一次 + 计入每日加分上限；
 * **不吃**同类递减 / 冷却减半 / 观察期减半 / 演出后 +1（固定值，行为可预期）。
 */
export const SPECIAL_BONUS = {
  invite_song: { value: 2, label: '邀她唱一段/合唱' },
  gift: { value: 3, label: '送礼/打赏' },
  festival: { value: 2, label: '节日/生日问候' },
  defend: { value: 3, label: '替她解围' }
};

/** 特殊动作（不按分数表，按各自规则处理）。 */
export const SPECIALS = ['apology', 'sick_on', 'sick_off', 'perf_after', 'exposed_on', 'exposed_off', ...Object.keys(SPECIAL_BONUS)];

export const OBSERVE_MS = 24 * 3600 * 1000;
export const WEEK_MS = 7 * 86400 * 1000;
export const SPECIAL_BONUS_MS = 24 * 3600 * 1000;
const BJ_OFFSET_MS = 8 * 3600 * 1000;
const SICK_MS = 48 * 3600 * 1000;
const EXPOSED_MS = 6 * 3600 * 1000;

/** 扣分后冷却时长：好感度 4 级及以上为 72 小时，否则 48 小时。 */
export function deductCooldownMs(level) {
  return Number(level) >= 4 ? 72 * 3600 * 1000 : 48 * 3600 * 1000;
}

export function clampScore(n) {
  const v = Math.round(Number(n) || 0);
  return v < 0 ? 0 : (v > SCORE_MAX ? SCORE_MAX : v);
}

/** 分数 → 等级（文档 §一）。 */
export function levelOf(score) {
  const s = Number(score) || 0;
  let lv = 0;
  for (const L of LEVELS) if (s >= L.min) lv = L.level;
  return lv;
}

export function levelInfo(level) {
  const lv = Math.max(0, Math.min(5, Math.round(Number(level) || 0)));
  const cur = LEVELS[lv];
  const next = LEVELS[lv + 1] || null;
  return { level: lv, name: cur.name, min: cur.min, max: next ? next.min - 1 : SCORE_MAX, nextMin: next ? next.min : null };
}

/** 北京时间 dayKey（与 hot-trend-tracker 的 bjParts 同口径；中国无夏令时）。 */
export function dayKeyOf(ts = Date.now()) {
  const d = new Date(ts + BJ_OFFSET_MS);
  return `${d.getUTCFullYear()}-${String(d.getUTCMonth() + 1).padStart(2, '0')}-${String(d.getUTCDate()).padStart(2, '0')}`;
}

/** 北京时间小时（0~23）。 */
export function hourOf(ts = Date.now()) {
  return new Date(ts + BJ_OFFSET_MS).getUTCHours();
}

/** 当天 23:59:59（北京时间）的时间戳 —— 「演出后当天」的截止点。 */
export function endOfBjDay(ts = Date.now()) {
  const d = new Date(ts + BJ_OFFSET_MS);
  const endUtc = Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate(), 23, 59, 59, 999);
  return endUtc - BJ_OFFSET_MS;
}

export function newUserState() {
  return {
    score: 0,
    level: 0,
    updatedAt: 0,
    lastInteractionAt: 0,      // 最近一次真实互动（由 after-response 刷新）
    lastLevelUpAt: 0,          // 最近一次升级（观察期用）
    lastDeductAt: 0,
    lastDeductUntil: 0,        // 冷却期截止（此前加分减半）
    lastDeductAmount: 0,
    lastDeductForApology: 0,   // 最近一次扣分额度（道歉恢复用）
    apologyRestoredAt: 0,      // 已经为哪次扣分恢复过
    lastIdleDeductAt: 0,       // 最近一次 7 天惩罚
    behaviorDay: '',
    behaviorCounts: {},        // eventKey -> 当天重复次数
    gainDay: '',
    gainUsed: 0,               // 当天已获得的正分
    deductCooldowns: {},       // eventKey -> ts（同行为不重复扣）
    specialCooldowns: {},      // eventKey -> ts（一次性加分事件 24h 不重复）
    flags: { secretEdge: false },
    sheInitBonusDay: '',       // 已为哪天结算过"她主动找你"
    sickUntil: 0,
    perfAfterUntil: 0,
    exposedUntil: 0,
    history: []
  };
}

/**
 * 全局状态（v2）。
 * v1 是按会话分裂的 `chats[chatKey].users[uid]`；v2 改成 **按人全局唯一**：
 *   users[uid]              —— 同一个人在群、私聊、多群共用同一份好感度
 *   chats[chatKey].members  —— 只记"谁在这个会话出现过"（展示/挑主动对象用）
 * 旧档由 migrateState() 无损升级，幂等。
 */
export function newState() {
  return { version: 2, savedAt: 0, users: {}, chats: {} };
}

/** 把旧存档缺的字段补齐（版本升级/手改文件容错）。 */
export function normalizeUser(raw) {
  const u = { ...newUserState(), ...(raw && typeof raw === 'object' ? raw : {}) };
  u.score = clampScore(u.score);
  // 尊重存档里的 level（"连续 7 天不互动 -2 不降级"要靠它跨重启保留）；
  // 老档没有 level 时才按分数推。
  u.level = Number.isFinite(Number(raw?.level)) ? Math.max(0, Math.min(5, Number(raw.level))) : levelOf(u.score);
  u.behaviorCounts = (u.behaviorCounts && typeof u.behaviorCounts === 'object') ? u.behaviorCounts : {};
  u.deductCooldowns = (u.deductCooldowns && typeof u.deductCooldowns === 'object') ? u.deductCooldowns : {};
  u.specialCooldowns = (u.specialCooldowns && typeof u.specialCooldowns === 'object') ? u.specialCooldowns : {};
  u.flags = (u.flags && typeof u.flags === 'object') ? u.flags : { secretEdge: false };
  if (typeof u.flags.secretEdge !== 'boolean') u.flags.secretEdge = Boolean(u.flags.secretEdge);
  u.history = Array.isArray(u.history) ? u.history.slice(-50) : [];
  return u;
}

/** 合并同一个人的两份记录（v1→v2 迁移用）：取分数更高那份为底，其余吸收，不丢进度。 */
function mergeUsers(a, b) {
  const aScore = Number(a?.score) || 0;
  const bScore = Number(b?.score) || 0;
  const win = (bScore > aScore)
    || (bScore === aScore && (Number(b?.lastInteractionAt) || 0) > (Number(a?.lastInteractionAt) || 0)) ? b : a;
  const lose = win === a ? b : a;
  const out = { ...win };

  // 历史：两边并起来按时间排序，只留最近 50 条
  out.history = [...(Array.isArray(win.history) ? win.history : []), ...(Array.isArray(lose.history) ? lose.history : [])]
    .sort((x, y) => (Number(x?.at) || 0) - (Number(y?.at) || 0))
    .slice(-50);

  // 时间戳一律取最大：最近互动 / 升级观察期 / 扣分冷却 / 特殊状态都不能被覆盖掉
  for (const k of ['updatedAt', 'lastInteractionAt', 'lastLevelUpAt', 'lastDeductAt', 'lastDeductUntil', 'lastIdleDeductAt', 'sickUntil', 'perfAfterUntil', 'exposedUntil']) {
    out[k] = Math.max(Number(win[k]) || 0, Number(lose[k]) || 0);
  }

  // 扣分/道歉相关字段属于"最近那次扣分"，跟着 lastDeductAt 的归属走
  const owner = (Number(lose.lastDeductAt) || 0) > (Number(win.lastDeductAt) || 0) ? lose : win;
  out.lastDeductAmount = Number(owner.lastDeductAmount) || 0;
  out.lastDeductForApology = Number(owner.lastDeductForApology) || 0;
  out.apologyRestoredAt = Number(owner.apologyRestoredAt) || 0;

  // 递减计数 / 同类扣分冷却 / 特殊加分冷却：按 key 取大（合并不能把"已重复过/冷却中"抹掉）
  out.behaviorCounts = {};
  out.deductCooldowns = {};
  out.specialCooldowns = {};
  for (const k of new Set([...Object.keys(win.behaviorCounts || {}), ...Object.keys(lose.behaviorCounts || {})])) {
    out.behaviorCounts[k] = Math.max(Number(win.behaviorCounts?.[k]) || 0, Number(lose.behaviorCounts?.[k]) || 0);
  }
  for (const k of new Set([...Object.keys(win.deductCooldowns || {}), ...Object.keys(lose.deductCooldowns || {})])) {
    out.deductCooldowns[k] = Math.max(Number(win.deductCooldowns?.[k]) || 0, Number(lose.deductCooldowns?.[k]) || 0);
  }
  for (const k of new Set([...Object.keys(win.specialCooldowns || {}), ...Object.keys(lose.specialCooldowns || {})])) {
    out.specialCooldowns[k] = Math.max(Number(win.specialCooldowns?.[k]) || 0, Number(lose.specialCooldowns?.[k]) || 0);
  }

  // 按天滚动的字段：日期较新的那份说了算
  const dayGe = (x, y) => String(x || '') >= String(y || '');
  const gainSrc = dayGe(win.gainDay, lose.gainDay) ? win : lose;
  out.gainDay = String(gainSrc.gainDay || '');
  out.gainUsed = Number(gainSrc.gainUsed) || 0;
  out.behaviorDay = String((dayGe(win.behaviorDay, lose.behaviorDay) ? win : lose).behaviorDay || '');
  out.sheInitBonusDay = String((dayGe(win.sheInitBonusDay, lose.sheInitBonusDay) ? win : lose).sheInitBonusDay || '');

  out.flags = { ...(win.flags || {}), secretEdge: Boolean(win.flags?.secretEdge || lose.flags?.secretEdge) };
  out.level = Math.max(Number(win.level) || 0, Number(lose.level) || 0);   // 不丢进度（含"7天不降级"保留的等级）
  out.score = clampScore(Math.max(aScore, bScore));
  return out;
}

/** 档里是否还是 v1 的"按会话存法"（用于判断要不要备份 + 落盘新格式）。 */
export function isLegacyLayout(raw) {
  if (!raw || typeof raw !== 'object') return false;
  for (const cv of Object.values(raw.chats || {})) {
    if (cv && typeof cv === 'object' && cv.users && typeof cv.users === 'object') return true;
  }
  return false;
}

/**
 * 存档升级（幂等、纯函数，可脱离宿主单测）：
 *   v1  chats[chatKey].users[uid]  →  v2  users[uid] + chats[chatKey].members
 * 同一人在多个会话都有记录时按 mergeUsers 合并（取分数更高那份）。
 * 对已是 v2 的档再跑一遍结果不变。
 */
export function migrateState(raw) {
  const state = newState();
  if (!raw || typeof raw !== 'object') return state;
  state.savedAt = Number(raw.savedAt) || 0;
  state.version = 2;

  const byUid = new Map();
  const put = (uid, uv) => {
    const id = String(uid);
    if (!id || !uv || typeof uv !== 'object') return;
    const u = normalizeUser(uv);
    const prev = byUid.get(id);
    byUid.set(id, prev ? mergeUsers(prev, u) : u);
  };

  for (const [uid, uv] of Object.entries(raw.users || {})) put(uid, uv);
  for (const [ck, cv] of Object.entries(raw.chats || {})) {
    if (!cv || typeof cv !== 'object') continue;
    const chat = ensureChat(state, ck);
    const members = (cv.members && typeof cv.members === 'object') ? cv.members : {};
    for (const uid of Object.keys(members)) chat.members[String(uid)] = 1;
    const legacy = (cv.users && typeof cv.users === 'object') ? cv.users : {};
    for (const [uid, uv] of Object.entries(legacy)) {
      chat.members[String(uid)] = 1;
      put(uid, uv);
    }
  }
  for (const [uid, u] of byUid) state.users[uid] = u;
  return state;
}

/** 会话骨架：chats[ck].members = { [uid]: 1 }，只作"谁在这里出现过"的成员索引。 */
function ensureChat(state, chatKey) {
  const ck = String(chatKey);
  if (!state.chats || typeof state.chats !== 'object') state.chats = {};
  if (!state.chats[ck]) state.chats[ck] = { members: {} };
  if (!state.chats[ck].members || typeof state.chats[ck].members !== 'object') state.chats[ck].members = {};
  return state.chats[ck];
}

/**
 * 取（或创建）**全局唯一**的好感度记录，并顺手把这个人登记进该会话的成员索引。
 * chatKey 只用来记"在哪里见过面"，不再决定记录归属 —— 同一个 QQ 号在群/私聊/多群共用一份。
 */
export function ensureUser(state, chatKey, uid) {
  const id = String(uid);
  if (!state.users || typeof state.users !== 'object') state.users = {};
  if (!state.users[id]) state.users[id] = newUserState();
  ensureChat(state, chatKey).members[id] = 1;
  return state.users[id];
}

/** 全局记录（chatKey 参数保留以兼容旧调用点，不再参与查找）。 */
export function getUser(state, chatKey, uid) {
  return state.users?.[String(uid)] || null;
}

/** 某个会话里出现过的人（成员索引，不保证都有好感度记录）。 */
export function membersOfChat(state, chatKey) {
  return Object.keys(state.chats?.[String(chatKey)]?.members || {});
}

/** 按天滚动 behaviorCounts / gainUsed。 */
function rollDay(user, now) {
  const day = dayKeyOf(now);
  if (user.behaviorDay !== day) { user.behaviorDay = day; user.behaviorCounts = {}; }
  if (user.gainDay !== day) { user.gainDay = day; user.gainUsed = 0; }
}

/** 「加分递减」：第1次全额、第2/3次减半向上取整、第4次起 +0。 */
export function diminishingFactor(count) {
  if (count <= 0) return 1;
  if (count <= 2) return 0.5;
  return 0;
}

function pushHistory(user, entry) {
  user.history.push(entry);
  if (user.history.length > 50) user.history = user.history.slice(-50);
}

function recomputeLevel(user, now) {
  const before = user.level;
  const after = levelOf(user.score);
  user.level = after;
  if (after > before) user.lastLevelUpAt = now;
  return { before, after, upgraded: after > before, downgraded: after < before };
}

/** 有效分/等级：生病临时 +5 只影响"表现"（态度、提示词、状态展示），不动真实分。 */
export function sickActive(user, now = Date.now()) {
  return Number(user?.sickUntil || 0) > now;
}
export function perfActive(user, now = Date.now()) {
  return Number(user?.perfAfterUntil || 0) > now;
}
export function exposedActive(user, now = Date.now()) {
  return Number(user?.exposedUntil || 0) > now;
}
export function effectiveScore(user, now = Date.now()) {
  return clampScore(user.score + (sickActive(user, now) ? 5 : 0));
}
/** 展示等级 = 权威等级（存档里的 level）。生病只改"表现分"，不改等级。 */
export function effectiveLevel(user, now = Date.now()) {
  return user.level;
}

/**
 * 结算一次好感变化（改版主入口，取代旧的 applyPositive/applyNegative）。
 *
 * @param {{direction?:'up'|'down', strength?:1|2|3, tag?:string, trust?:boolean, now?:number}} p
 *   direction 方向；strength 强度（轻/中/重，**由模型判断**）；tag 行为类别（同类递减/冷却的键）；
 *   trust=true 表示"辜负信任"类越界（泄露秘密/背叛/强行定义关系/不尊重奥黛塔，不受高好感衰减）。
 * @returns {{applied:boolean, delta:number, score:number, level:number, levelBefore:number,
 *            upgraded:boolean, downgraded:boolean, count:number, halved:boolean, reasons:string[]}}
 */
export function applyImpression(user, { direction, strength, tag = 'general', trust = false, now = Date.now() } = {}) {
  const s = clampStrength(strength);
  const key = String(tag || 'general').slice(0, 40) || 'general';
  rollDay(user, now);
  return direction === 'down'
    ? applyDown(user, key, s, Boolean(trust), now)
    : applyUp(user, key, s, now);
}

function applyUp(user, key, s, now) {
  const reasons = [];
  const cap = dailyGainCap(user.level);
  const count = user.behaviorCounts[key] || 0;
  user.behaviorCounts[key] = count + 1;

  // 基础分：按当前等级 + 强度曲线
  let value = gainValue(user.level, s);
  if (value <= 0) {
    return finish(user, {
      applied: false, delta: 0, count: count + 1, halved: false,
      reasons: ['当前好感阶段，这种程度的互动不再加分（好感高了，只认更深入的相处）'], now
    });
  }

  // 同类递减：低好感（Lv0-1）不递减，让前期好涨；Lv2+ 起 1 全额/2,3 减半/4+ 归零
  if (user.level >= 2) value = Math.ceil(value * diminishingFactor(count));

  // 冷却期 / 升级观察期减半（取单一减弱，不叠加）
  let halved = false;
  if (now < user.lastDeductUntil) { halved = true; reasons.push('冷却期内·加分减半'); }
  if (user.lastLevelUpAt > 0 && now - user.lastLevelUpAt < OBSERVE_MS) { halved = true; reasons.push('升级观察期内·加分减半'); }
  if (halved) value = Math.ceil(value / 2);

  // 演出后当天 +1
  if (value > 0 && perfActive(user, now)) { value += 1; reasons.push('演出后当天·+1'); }

  // 每日加分上限（按等级：低 8 / 中 6 / 高 4）
  if (value > 0) {
    const remaining = Math.max(0, cap - user.gainUsed);
    if (remaining <= 0) { value = 0; reasons.push(`当日加分已达上限 +${cap}`); }
    else if (value > remaining) { value = remaining; reasons.push(`当日加分接近上限，本次只 +${remaining}`); }
  }
  if (value === 0 && count >= 3 && !reasons.length) reasons.push('同一类行为已重复多次（+0，只维持不扣）');

  const before = user.score;
  user.score = clampScore(user.score + value);
  const applied = value > 0;
  if (applied) { user.gainUsed += value; if (user.gainUsed > cap) user.gainUsed = cap; }
  user.updatedAt = now;
  if (applied) pushHistory(user, { at: now, event: 'up', tag: key, strength: s, label: `好感+${value}（${STRENGTH_LABELS[s]}·${key}）`, delta: value, score: user.score });
  return finish(user, { applied, delta: value, count: count + 1, halved, reasons, now, prevScore: before });
}

function applyDown(user, key, s, trust, now) {
  const reasons = [];

  // 同一类行为冷却期不重复扣
  const last = user.deductCooldowns[key] || 0;
  const window = deductCooldownMs(user.level);
  if (last && now - last < window) {
    const left = Math.ceil((window - (now - last)) / 3600000);
    return finish(user, { applied: false, delta: 0, count: 0, halved: false, reasons: [`冷却期未过：同一类行为约 ${left} 小时后才能再扣`], now });
  }

  const base = deductValue(user.level, s, { trust });
  if (base <= 0) {
    return finish(user, { applied: false, delta: 0, count: 0, halved: false, reasons: ['当前好感阶段，这种程度的冒犯不扣分（好感高了，小事不再计较）'], now });
  }

  const before = user.score;
  user.score = clampScore(user.score - base);
  const applied = Math.min(base, Math.max(0, before));

  user.deductCooldowns[key] = now;
  user.lastDeductAt = now;
  user.lastDeductUntil = now + window;
  user.lastDeductAmount = base;
  user.lastDeductForApology = base;
  user.apologyRestoredAt = 0;
  user.updatedAt = now;
  pushHistory(user, {
    at: now, event: 'down', tag: key, strength: s, trust,
    label: `好感-${base}（${STRENGTH_LABELS[s]}${trust ? '·辜负信任' : ''}·${key}）`,
    delta: -applied, score: user.score
  });

  reasons.push(`进入冷却期（${Math.round(window / 3600000)} 小时内同一类行为不再扣，期间加分减半）`);
  if (trust) reasons.push('属于「辜负信任」，不受高好感衰减');
  return finish(user, { applied: true, delta: -applied, count: 0, halved: false, reasons, now, prevScore: before });
}

/**
 * 道歉恢复（§十）：恢复最近一次扣分的 50%，向上取整；每次扣分只能恢复一次。
 * 恢复不计入每日加分上限（它不是"新得的分"，而是拿回被扣的分）。
 */
export function applyApology(user, now = Date.now()) {
  if (!user.lastDeductForApology || user.apologyRestoredAt >= user.lastDeductAt) {
    return { applied: false, delta: 0, score: user.score, level: user.level, levelBefore: user.level, upgraded: false, downgraded: false, reasons: ['没有可恢复的扣分（还没踩过界，或这次已经恢复过）'] };
  }
  const restore = Math.ceil(user.lastDeductForApology / 2);
  const before = user.score;
  user.score = clampScore(user.score + restore);
  user.apologyRestoredAt = now;
  user.updatedAt = now;
  pushHistory(user, { at: now, event: 'apology', label: '道歉·恢复', delta: restore, score: user.score });
  return finish(user, { applied: true, delta: restore, count: 0, halved: false, reasons: ['道歉恢复被扣分的 50%'], now, prevScore: before });
}

/**
 * 一次性加分型特殊事件的结算（SPECIAL_BONUS 各 key）：
 *   固定值；每人每类 24 小时一次；计入每日加分上限（不足则取剩余）；
 *   不吃同类递减 / 冷却减半 / 观察期减半 / 演出后 +1。
 * 每日上限已满时直接拒绝且**不写冷却**（否则上限满还会把这把锁白锁 24 小时）。
 */
function awardBonus(user, key, now) {
  const cfg = SPECIAL_BONUS[key];
  const base = { applied: false, delta: 0, score: user.score, level: user.level, levelBefore: user.level, upgraded: false, downgraded: false, reasons: [] };
  if (!cfg) return { ...base, reasons: ['未知特殊动作'] };

  const last = Number(user.specialCooldowns?.[key]) || 0;
  if (last && now - last < SPECIAL_BONUS_MS) {
    const left = Math.ceil((SPECIAL_BONUS_MS - (now - last)) / 3600000);
    return { ...base, reasons: [`${cfg.label}：每 24 小时只能记一次（约 ${left} 小时后可再记）`] };
  }

  const cap = dailyGainCap(user.level);
  const remaining = Math.max(0, cap - user.gainUsed);
  if (remaining <= 0) return { ...base, reasons: [`当日加分已达上限 +${cap}，${cfg.label}未记入`] };
  const value = Math.min(cfg.value, remaining);

  const before = user.score;
  user.specialCooldowns[key] = now;
  user.score = clampScore(user.score + value);
  user.gainUsed += value;
  if (user.gainUsed > cap) user.gainUsed = cap;
  user.updatedAt = now;
  pushHistory(user, { at: now, event: 'special_bonus', tag: key, label: `${cfg.label}·+${value}`, delta: value, score: user.score });
  return finish(user, { applied: true, delta: value, count: 0, halved: false, reasons: [`${cfg.label} +${value}`], now, prevScore: before });
}

/** 特殊状态设置（§九）：生病 / 演出后 / 被戳穿；以及一次性加分事件（SPECIAL_BONUS）。 */
export function applySpecial(user, key, now = Date.now()) {
  if (Object.prototype.hasOwnProperty.call(SPECIAL_BONUS, key)) return awardBonus(user, key, now);
  const base = { applied: false, delta: 0, score: user.score, level: user.level, levelBefore: user.level, upgraded: false, downgraded: false, reasons: [] };
  switch (key) {
    case 'sick_on':
      user.sickUntil = now + SICK_MS; user.updatedAt = now;
      return { ...base, applied: true, reasons: [`已进入生病状态（临时 +5 表现，48 小时内自动恢复；可用 sick_off 提前结束）`] };
    case 'sick_off':
      user.sickUntil = 0; user.updatedAt = now;
      return { ...base, applied: true, reasons: ['生病状态已结束（恢复原表现分）'] };
    case 'perf_after':
      user.perfAfterUntil = endOfBjDay(now); user.updatedAt = now;
      return { ...base, applied: true, reasons: ['演出后状态已记录：今天内每次加分额外 +1'] };
    case 'exposed_on':
      user.exposedUntil = now + EXPOSED_MS; user.updatedAt = now;
      return { ...base, applied: true, reasons: ['已标记：短暂被戳穿状态（仅 3 级及以上能察觉）'] };
    case 'exposed_off':
      user.exposedUntil = 0; user.updatedAt = now;
      return { ...base, applied: true, reasons: ['被戳穿状态已结束'] };
    default:
      return { ...base, reasons: ['未知特殊动作'] };
  }
}

/**
 * 手动调整（控制台「记忆」页管理员操作）：加减分 / 直接设分 / 直接设等级。
 * 优先级 level > score > delta，三者只生效一个。
 * 手动动作**不占用**每日加分上限、不吃递减/冷却/门槛；只写一条「手动」history。
 * level 分支会把分数对齐到该级进入分（否则下次按分重算就弹回去了）。
 */
export function applyManual(user, { delta, score, level } = {}, now = Date.now()) {
  const base = { applied: false, delta: 0, score: user.score, level: user.level, levelBefore: user.level, upgraded: false, downgraded: false, reasons: [] };
  const beforeLevel = user.level;
  const beforeScore = user.score;
  let mode = '';

  const hasLevel = level !== undefined && level !== null && level !== '';
  const hasScore = score !== undefined && score !== null && score !== '';
  const hasDelta = delta !== undefined && delta !== null && delta !== '';

  if (hasLevel) {
    const lv = Math.max(0, Math.min(5, Math.round(Number(level))));
    user.score = clampScore(LEVELS[lv].min);
    user.level = lv;
    mode = `设为 Lv${lv} ${LEVELS[lv].name}（分数=${LEVELS[lv].min}）`;
  } else if (hasScore) {
    user.score = clampScore(score);
    user.level = levelOf(user.score);
    mode = `设分为 ${user.score}`;
  } else if (hasDelta) {
    const d = Math.round(Number(delta) || 0);
    user.score = clampScore(user.score + d);
    user.level = levelOf(user.score);
    mode = `手动 ${d >= 0 ? '+' : ''}${d}`;
  } else {
    return { ...base, reasons: ['没有可执行的调整（需要 level / score / delta 之一）'] };
  }

  user.updatedAt = now;
  pushHistory(user, { at: now, event: 'manual', label: `手动调整（${mode}）`, delta: user.score - beforeScore, score: user.score });
  return {
    applied: true,
    delta: user.score - beforeScore,
    score: user.score,
    level: user.level,
    levelBefore: beforeLevel,
    upgraded: user.level > beforeLevel,
    downgraded: user.level < beforeLevel,
    reasons: [mode]
  };
}

/** 刷新最近互动时间（after-response 每次跑完会话调用，不区分是否用工具）。 */
export function touchInteraction(user, now = Date.now()) {
  user.lastInteractionAt = now;
  user.updatedAt = now;
}

/**
 * 惰性结算"连续 7 天不互动 -2"（§十）：每次读/写状态时顺带检查，
 * 每满 7 天只扣一次。扣分跳过当次等级重算（不降级但扣分）。
 */
export function applyIdleRules(user, now = Date.now()) {
  const notes = [];
  let changed = false;
  if (user.lastInteractionAt > 0 && now - user.lastInteractionAt >= WEEK_MS) {
    const since = user.lastIdleDeductAt || 0;
    if (!since || now - since >= WEEK_MS) {
      user.score = clampScore(user.score - 2);
      user.lastIdleDeductAt = now;
      // 不调用 recomputeLevel：扣分但不因此降级（level 保留，下次真实互动再按分数重算）
      user.updatedAt = now;
      notes.push('连续 7 天未互动：-2（按规则暂不降级）');
      changed = true;
      pushHistory(user, { at: now, event: 'idle_7d', label: '连续7天未互动', delta: -2, score: user.score });
    }
  }
  return { changed, notes };
}

/**
 * 「被她主动找 当天首次互动 +1」（§十 + §七 门槛 ≥3 级）：当天只结算一次。
 * 由 after-response 在插件标记"她今天主动找过你"时调用。
 */
export function applySheInitBonus(user, now = Date.now()) {
  const base = { applied: false, delta: 0, score: user.score, level: user.level, levelBefore: user.level, upgraded: false, downgraded: false, reasons: [] };
  const day = dayKeyOf(now);
  if (user.sheInitBonusDay === day) return { ...base, reasons: ['今天已结算过"被她主动找"'] };
  if (user.level < 3) return { ...base, reasons: ['等级未达 3 级，暂不结算'] };
  const remaining = Math.max(0, dailyGainCap(user.level) - user.gainUsed);
  if (remaining <= 0) { user.sheInitBonusDay = day; return { ...base, reasons: ['当日加分已达上限，未结算'] }; }
  user.sheInitBonusDay = day;
  const before = user.score;
  user.score = clampScore(user.score + 1);
  user.gainUsed += 1;
  user.updatedAt = now;
  pushHistory(user, { at: now, event: 'she_initiates', label: '被她主动找·当天首次互动', delta: 1, score: user.score });
  return finish(user, { applied: true, delta: 1, count: 0, halved: false, reasons: ['她主动找你，当天首次互动 +1'], now, prevScore: before });
}

/** 统一收尾：重算等级 + 拼返回结构。 */
function finish(user, { applied, delta, count, halved, reasons, now, prevScore }) {
  const r = recomputeLevel(user, now);
  const levelBefore = r.before;
  const upgraded = r.upgraded;
  const downgraded = r.downgraded;
  return {
    applied, delta,
    score: user.score,
    level: user.level,
    levelBefore,
    upgraded, downgraded,
    count: count || 0,
    halved: Boolean(halved),
    reasons: reasons || []
  };
}

/** 状态汇总（给工具/提示词用）。 */
export function summarize(user, now = Date.now()) {
  rollDay(user, now);
  const eff = effectiveScore(user, now);
  const lv = user.level;                       // 权威等级（idle 扣分不降级时高于 scoreLevel）
  const info = levelInfo(lv);
  const next = info.nextMin == null ? null : Math.max(0, info.nextMin - eff);
  return {
    score: user.score,
    effectiveScore: eff,
    level: lv,
    scoreLevel: levelOf(user.score),           // 按分数本应处的等级（调试用）
    name: info.name,
    min: info.min,
    max: info.max,
    nextMin: info.nextMin,
    toNext: next,
    sick: sickActive(user, now),
    perfAfter: perfActive(user, now),
    exposed: exposedActive(user, now),
    gainUsed: user.gainUsed,
    gainCap: dailyGainCap(user.level),
    cooldownUntil: user.lastDeductUntil,
    inCooldown: now < (user.lastDeductUntil || 0),
    observeUntil: user.lastLevelUpAt ? user.lastLevelUpAt + OBSERVE_MS : 0,
    flags: { ...user.flags },
    lastInteractionAt: user.lastInteractionAt,
    history: user.history.slice(-8)
  };
}
