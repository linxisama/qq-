# QQ Agent 迁移与恢复说明（无痛换电脑）

本说明配合 `skills\auto-backup` 使用：在那台电脑上也能每天自动备份，并且可以拿现在的备份
直接在一台新电脑上恢复出同样的设置、记忆和聊天记录。

- QQ Agent 版本：0.4.0 及以上（当前 0.4.0）
- 系统：Windows 10/11（备份用 QQ Agent 自带的 Node 运行时，不需要装 PowerShell 模块或任何外部程序）
- QQ Agent 默认安装路径：`C:\qqagent\QQ Agent`（装在别处也可以，脚本会按自身位置推断）

---

## 一、搬迁这套备份技能（只带备份，不带数据）

1. 在**新电脑**装好同版本 QQ Agent，先启动一次再退出（让它生成 `data` 目录）。
2. 把旧电脑的整个文件夹：

   ```
   C:\qqagent\QQ Agent\resources\app\skills\auto-backup
   ```

   复制到新电脑的同一位置：

   ```
   <新电脑 QQ Agent 根目录>\resources\app\skills\auto-backup
   ```

3. 启动 QQ Agent → 控制台「技能」页应出现 **自动备份（每天存桌面 · 每周发QQ）**，状态为启用。
4. 打开设置检查：
   - 每天几点（默认 00:00）
   - 备份目录（**留空 = 当前用户桌面**，换电脑/换用户名都不用改）
   - 文件名（默认 `QQAgent备份.zip`）
5. 在 QQ 里对机器人说「立即备份一下」，或调用 `backup_now`，确认桌面出现 zip；
   再说「备份状态」，应能看到下次运行时间和上次结果。

> 这个技能不写死盘符、用户名、安装路径，也没有外部依赖；复制过去即可用。

---

## 二、整机迁移（把机器人整体搬到新电脑）

目标：新电脑上的设置、AI 记忆、聊天记录、插件行为与旧电脑一致。

### 1. 旧电脑：先做一次最新备份

在 QQ 里让机器人「立即备份」（工具 `backup_now`），或在控制台「技能 → 自动备份」里点保存后
直接让机器人执行；备份完成后桌面会出现 `QQAgent备份.zip`。
得到桌面上的 `QQAgent备份.zip`（约 30–40 MB）。

### 2. 新电脑：装同版本 QQ Agent

- 安装同版本（版本差异过大时，配置字段可能对不上）
- **先启动一次再完全退出**（生成默认 `data` 和 `resources\app`）

### 3. 恢复数据

1. 完全退出 QQ Agent（托盘也要退）
2. 解压 `QQAgent备份.zip`
3. 把解压出来的 `data` 覆盖到：

   ```
   <新电脑 QQ Agent 根目录>\data
   ```

4. 备份里的 `plugins`、`skills` 覆盖到：

   ```
   <新电脑 QQ Agent 根目录>\resources\app\plugins
   <新电脑 QQ Agent 根目录>\resources\app\skills
   ```

   （至少要把 `skills\auto-backup` 放回去，否则新电脑没有自动备份）

### 4. 启动并检查

按下面「四、迁移后检查清单」逐项过一遍。

---

## 三、从备份恢复（本机出问题时）

1. 完全退出 QQ Agent
2. 解压 `QQAgent备份.zip`
3. `data` 覆盖回 `C:\qqagent\QQ Agent\data`
4. 需要时把 `plugins` / `skills` 覆盖回 `resources\app\` 下
5. 重新启动

> 覆盖前建议把当前 `data` 改名为 `data.broken-日期` 留一手；确认没问题再删。

---

## 四、迁移后检查清单

- [ ] 控制台能打开，模型/API Key、渠道配置正确（`data\config.json` 已带过来）
- [ ] 人设、白名单、群/私聊开关与旧机一致
- [ ] 「技能 / 插件」页：没有「缺少 skill.json / plugin.json」；自动备份为启用
- [ ] 私聊机器人，它能记得之前聊过的事（记忆与会话已恢复）
- [ ] 自动备份：`backup_status` 显示下次时间；桌面上 zip 时间是刚才
- [ ] 每周发 QQ：`backup_status` 显示下次发送时间；说「把备份发我」能收到 `backup_send` 发出的 zip
- [ ] B 站相关：`bili-account` 可能需要重新扫码（登录态与设备/会话绑定，换机后常失效），
      扫码后把新的 `SESSDATA` 同步给 `bili-browse`（或直接在插件设置里填）
- [ ] QQ 协议端 / 机器人账号在新电脑上登录正常（这部分不在 QQ Agent 数据里，需要单独装）
- [ ] 如果旧机设置里填过**绝对路径**（例如语音临时目录、知识库路径），改成新机对应路径

---

## 五、常见问题

**Q：到点了没备份？**
QQ Agent 必须开着。若 00:00 时没开，启动约 90 秒后会补跑；当天已经备份过则不补。
看 `data\auto-backup\backup.log` 与 `state.json` 确认。

**Q：提示"无法覆盖备份文件（可能被占用）"？**
zip 正被解压软件/预览窗口打开。关掉后下一天会自动成功；也可手动 `backup_now`。
旧备份在失败时不会被删除。

**Q：备份包里为什么没有 `electron-user-data`、`whale-memes\tmp`？**
那是浏览器缓存和表情包临时图，可再生产；排除它们能把包从 100 MB 压到 ~32 MB。

**Q：应用自动更新后插件/技能不见了？**
更新会覆盖 `resources\app`。把备份里的 `plugins`、`skills` 覆盖回去即可；
`data`（设置与记忆）不受影响。升级前先跑一次备份最稳。

**Q：备份里有敏感信息吗？**
有：`data\config.json` 含 API Key、`data\bili-account\session.json` 含 B 站登录态。
不要把 zip 发给别人或放到公共网盘。

---

## 六、附：备份技能涉及的文件

```
resources\app\skills\auto-backup\
  ├─ index.js            排班、补跑、备份实现、每周发 QQ、工具注册
  ├─ skill.json          清单与设置
  ├─ README.md           技能自身说明
  └─ MIGRATION-GUIDE.md  本文件

data\auto-backup\
  ├─ backup.log          每次备份的日志
  ├─ state.json          上次结果（供 backup_status 读取）
  └─ run.lock            备份进行中的互斥锁（正常结束后自动删除）
```
