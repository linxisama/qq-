// auto-backup —— 把 QQ Agent 的 data / plugins / skills 每天备份到桌面（覆盖前一天）
//
// 设计要点：
//   · 纯 Node 实现（fs + zlib），不依赖 PowerShell / 7-Zip / 任何外部程序；
//   · 所有路径都从本文件位置推断（<QQ Agent>\resources\app\skills\auto-backup），
//     整个文件夹复制到另一台电脑的同名位置即可工作，不写死盘符、用户名、安装目录；
//   · 先写临时包，成功后原子替换；失败不破坏旧备份。

import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import zlib from 'node:zlib'
import { fileURLToPath } from 'node:url'

const HERE = path.dirname(fileURLToPath(import.meta.url))
// HERE = <AppRoot>\resources\app\skills\auto-backup → 上四级就是 QQ Agent 根目录
const APP_ROOT = path.resolve(HERE, '..', '..', '..', '..')
const DATA_DIR = path.join(APP_ROOT, 'data')
const PLUGINS_DIR = path.join(APP_ROOT, 'resources', 'app', 'plugins')
const SKILLS_DIR = path.join(APP_ROOT, 'resources', 'app', 'skills')
const WORK_DIR = path.join(DATA_DIR, 'auto-backup')
const STATE_FILE = path.join(WORK_DIR, 'state.json')
const LOG_FILE = path.join(WORK_DIR, 'backup.log')

const LOG_TAG = '自动备份'
const DEFAULTS = {
  enabled: true,
  time: '00:00',
  destDir: '',
  zipName: 'QQAgent备份.zip',
  catchUpOnStart: true,
  qqEnabled: true,
  qqTo: '',
  emailWeekday: 7,
  emailTime: '09:00'
}

// 不备份的缓存：可再生，且可能有打开中的句柄
const EXCLUDE_DIRS = new Set([
  path.join(DATA_DIR, 'electron-user-data'),
  path.join(DATA_DIR, 'whale-memes', 'tmp')
])
const EXCLUDE_FILES = new Set([path.join(DATA_DIR, 'qq-agent.lock')])

let api = null
let fileLog = null
let timer = null
let catchUpTimer = null
let weeklyTimer = null
let currentRun = null
let nextRunAt = 0
let nextEmailAt = 0

function logLine(msg) {
  const text = String(msg)
  try { fileLog?.(text) } catch { /* ignore */ }
  try { api?.log?.(text) } catch { /* ignore */ }
}

function settings() {
  const c = (typeof api?.config === 'function' ? api.config() : null) || {}
  const str = (k, d) => (c[k] === undefined || c[k] === null ? d : String(c[k]))
  const bool = (k, d) => (typeof c[k] === 'boolean' ? c[k] : d)
  const num = (k, d, min, max) => {
    const n = Number(c[k])
    if (!Number.isFinite(n)) return d
    return Math.max(min, Math.min(max, n))
  }
  const rawTime = str('time', DEFAULTS.time).trim()
  const time = /^([01]?\d|2[0-3]):([0-5]\d)$/.test(rawTime) ? rawTime : DEFAULTS.time
  const rawWeekTime = str('emailTime', DEFAULTS.emailTime).trim()
  const emailTime = /^([01]?\d|2[0-3]):([0-5]\d)$/.test(rawWeekTime) ? rawWeekTime : DEFAULTS.emailTime
  return {
    enabled: bool('enabled', DEFAULTS.enabled),
    time,
    destDir: str('destDir', DEFAULTS.destDir).trim(),
    zipName: str('zipName', DEFAULTS.zipName).trim() || DEFAULTS.zipName,
    catchUpOnStart: bool('catchUpOnStart', DEFAULTS.catchUpOnStart),
    qqEnabled: bool('qqEnabled', DEFAULTS.qqEnabled),
    qqTo: str('qqTo', DEFAULTS.qqTo).trim(),
    emailWeekday: Math.round(num('emailWeekday', DEFAULTS.emailWeekday, 1, 7)),
    emailTime
  }
}

function desktopDir() {
  const home = os.homedir()
  const candidates = [
    path.join(home, 'Desktop'),
    path.join(home, 'OneDrive', 'Desktop'),
    path.join(home, 'OneDrive - 个人', 'Desktop')
  ]
  for (const p of candidates) { try { if (fs.statSync(p).isDirectory()) return p } catch { } }
  return path.join(home, 'Desktop')
}

function readState() {
  try { return JSON.parse(fs.readFileSync(STATE_FILE, 'utf8')) } catch { return {} }
}

function writeState(patch) {
  try {
    fs.mkdirSync(WORK_DIR, { recursive: true })
    fs.writeFileSync(STATE_FILE, JSON.stringify(patch, null, 2), 'utf8')
  } catch { /* ignore */ }
}

function appendLog(msg) {
  try {
    fs.mkdirSync(WORK_DIR, { recursive: true })
    const d = new Date()
    const p = (n) => String(n).padStart(2, '0')
    const ts = `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())} ${p(d.getHours())}:${p(d.getMinutes())}:${p(d.getSeconds())}`
    fs.appendFileSync(LOG_FILE, `[${ts}] ${msg}\r\n`, 'utf8')
  } catch { /* ignore */ }
}

/** 下一次 HH:MM（本地时间）；已经过了就顺延到明天。 */
function nextOccurrence(now = Date.now()) {
  const [h, m] = settings().time.split(':').map(Number)
  const d = new Date(now)
  d.setHours(h, m, 0, 0)
  if (d.getTime() <= now) d.setDate(d.getDate() + 1)
  return d.getTime()
}

/** 最近一次已经过去的 HH:MM（开机补跑判断用）。 */
function lastOccurrence(now = Date.now()) {
  const [h, m] = settings().time.split(':').map(Number)
  const d = new Date(now)
  d.setHours(h, m, 0, 0)
  if (d.getTime() > now) d.setDate(d.getDate() - 1)
  return d.getTime()
}

function fmt(ts) {
  if (!ts) return '—'
  const d = new Date(ts)
  const p = (n) => String(n).padStart(2, '0')
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())} ${p(d.getHours())}:${p(d.getMinutes())}`
}

// ── 目录复制 ──────────────────────────────────────────────────────────────

function copyTree(src, dst) {
  if (!fs.existsSync(src)) return 0
  let count = 0
  fs.mkdirSync(dst, { recursive: true })
  for (const ent of fs.readdirSync(src, { withFileTypes: true })) {
    const s = path.join(src, ent.name)
    const d = path.join(dst, ent.name)
    if (ent.isDirectory()) {
      if (EXCLUDE_DIRS.has(s)) continue
      count += copyTree(s, d)
    } else if (ent.isFile()) {
      if (EXCLUDE_FILES.has(s)) continue
      fs.copyFileSync(s, d)
      count += 1
    }
  }
  return count
}

function walkFiles(dir, base = dir, out = []) {
  for (const ent of fs.readdirSync(dir, { withFileTypes: true })) {
    const p = path.join(dir, ent.name)
    if (ent.isDirectory()) walkFiles(p, base, out)
    else if (ent.isFile()) out.push({ full: p, rel: path.relative(base, p).split(path.sep).join('/') })
  }
  return out
}

// ── 极简 ZIP 写入（deflate + UTF-8 文件名）───────────────────────────────
// 不引第三方库：Node 自带 zlib 足够；UTF-8 标志位必须置上，否则中文文件名到别的
// 解压工具里会乱码（这是本机实测踩过的坑）。

const CRC_TABLE = (() => {
  const t = new Uint32Array(256)
  for (let n = 0; n < 256; n++) {
    let c = n
    for (let k = 0; k < 8; k++) c = c & 1 ? (0xEDB88320 ^ (c >>> 1)) : (c >>> 1)
    t[n] = c >>> 0
  }
  return t
})()

function crc32(buf) {
  let c = 0xFFFFFFFF
  for (let i = 0; i < buf.length; i++) c = CRC_TABLE[(c ^ buf[i]) & 0xFF] ^ (c >>> 8)
  return (c ^ 0xFFFFFFFF) >>> 0
}

function dosDateTime(date) {
  const d = date || new Date()
  return {
    time: ((d.getHours() & 31) << 11) | ((d.getMinutes() & 63) << 5) | (Math.floor(d.getSeconds() / 2) & 31),
    date: (((d.getFullYear() - 1980) & 127) << 9) | (((d.getMonth() + 1) & 15) << 5) | (d.getDate() & 31)
  }
}

function writeZip(entries, outPath) {
  const fd = fs.openSync(outPath, 'w')
  const central = []
  let offset = 0
  try {
    for (const e of entries) {
      const nameBuf = Buffer.from(e.name, 'utf8')
      const raw = fs.readFileSync(e.full)
      const crc = crc32(raw)
      const deflated = zlib.deflateRawSync(raw, { level: 6 })
      const useDeflate = deflated.length < raw.length
      const data = useDeflate ? deflated : raw
      const method = useDeflate ? 8 : 0
      const { time, date } = dosDateTime(fs.statSync(e.full).mtime)
      const local = Buffer.alloc(30)
      local.writeUInt32LE(0x04034b50, 0)
      local.writeUInt16LE(20, 4)
      local.writeUInt16LE(0x0800, 6)
      local.writeUInt16LE(method, 8)
      local.writeUInt16LE(time, 10)
      local.writeUInt16LE(date, 12)
      local.writeUInt32LE(crc, 14)
      local.writeUInt32LE(data.length, 18)
      local.writeUInt32LE(raw.length, 22)
      local.writeUInt16LE(nameBuf.length, 26)
      local.writeUInt16LE(0, 28)
      fs.writeSync(fd, local)
      fs.writeSync(fd, nameBuf)
      fs.writeSync(fd, data)
      central.push({ nameBuf, crc, method, time, date, comp: data.length, raw: raw.length, offset })
      offset += 30 + nameBuf.length + data.length
    }
    const cdStart = offset
    for (const c of central) {
      const h = Buffer.alloc(46)
      h.writeUInt32LE(0x02014b50, 0)
      h.writeUInt16LE(20, 4)
      h.writeUInt16LE(20, 6)
      h.writeUInt16LE(0x0800, 8)
      h.writeUInt16LE(c.method, 10)
      h.writeUInt16LE(c.time, 12)
      h.writeUInt16LE(c.date, 14)
      h.writeUInt32LE(c.crc, 16)
      h.writeUInt32LE(c.comp, 20)
      h.writeUInt32LE(c.raw, 24)
      h.writeUInt16LE(c.nameBuf.length, 28)
      h.writeUInt16LE(0, 30)
      h.writeUInt16LE(0, 32)
      h.writeUInt16LE(0, 34)
      h.writeUInt16LE(0, 36)
      h.writeUInt32LE(0, 38)
      h.writeUInt32LE(c.offset, 42)
      fs.writeSync(fd, h)
      fs.writeSync(fd, c.nameBuf)
      offset += 46 + c.nameBuf.length
    }
    const eocd = Buffer.alloc(22)
    eocd.writeUInt32LE(0x06054b50, 0)
    eocd.writeUInt16LE(0, 4)
    eocd.writeUInt16LE(0, 6)
    eocd.writeUInt16LE(central.length, 8)
    eocd.writeUInt16LE(central.length, 10)
    eocd.writeUInt32LE(offset - cdStart, 12)
    eocd.writeUInt32LE(cdStart, 16)
    eocd.writeUInt16LE(0, 20)
    fs.writeSync(fd, eocd)
  } finally {
    fs.closeSync(fd)
  }
}

// ── 备份主流程 ────────────────────────────────────────────────────────────

function noteText() {
  return [
    'QQ Agent 整体备份',
    `时间：${fmt(Date.now())}`,
    `来源：${APP_ROOT}`,
    '',
    '包含：data（设置/记忆/会话/聊天记录/插件状态）、plugins、skills',
    '不含：data\\electron-user-data、data\\whale-memes\\tmp（可再生的缓存）、qq-agent.lock',
    '',
    '恢复方法：',
    '  1) 完全退出 QQ Agent',
    `  2) 解压本包；把 data 覆盖到 "${path.join(APP_ROOT, 'data')}"`,
    `  3) 需要时把 plugins / skills 覆盖到 "${path.join(APP_ROOT, 'resources', 'app')}" 下对应目录`,
    '  4) 重新启动 QQ Agent'
  ].join('\r\n')
}

async function doBackup(reason) {
  const s = settings()
  const destDir = s.destDir || desktopDir()
  fs.mkdirSync(destDir, { recursive: true })
  const finalZip = path.join(destDir, s.zipName)
  const tmpRoot = fs.mkdtempSync(path.join(os.tmpdir(), 'qqagent-backup-'))
  const stage = path.join(tmpRoot, 'stage')
  const tmpZip = path.join(tmpRoot, s.zipName)
  const started = Date.now()
  appendLog(`开始备份（reason=${reason}，dest=${finalZip}）`)

  try {
    fs.mkdirSync(stage, { recursive: true })
    let files = 0
    files += copyTree(DATA_DIR, path.join(stage, 'data'))
    files += copyTree(PLUGINS_DIR, path.join(stage, 'plugins'))
    files += copyTree(SKILLS_DIR, path.join(stage, 'skills'))
    fs.writeFileSync(path.join(stage, 'README-backup.txt'), noteText(), 'utf8')

    const entries = walkFiles(stage).map((e) => ({ full: e.full, name: e.rel }))
    writeZip(entries, tmpZip)

    const sizeMB = Math.round((fs.statSync(tmpZip).size / 1048576) * 10) / 10
    if (sizeMB < 1) throw new Error(`备份包异常（${sizeMB} MB），不覆盖旧备份`)

    // 原子替换：旧包先挪开，成功后删除；失败把它挪回来
    const prev = `${finalZip}.prev`
    const hadOld = fs.existsSync(finalZip)
    try { fs.rmSync(prev, { force: true }) } catch { /* ignore */ }
    if (hadOld) fs.renameSync(finalZip, prev)
    try {
      fs.renameSync(tmpZip, finalZip)
    } catch (error) {
      if (hadOld) { try { fs.renameSync(prev, finalZip) } catch { /* ignore */ } }
      throw error
    }
    if (hadOld) { try { fs.rmSync(prev, { force: true }) } catch { /* ignore */ } }

    const secs = Math.round((Date.now() - started) / 100) / 10
    const state = {
      ok: true,
      lastRun: new Date().toISOString(),
      lastFile: finalZip,
      lastSizeMB: sizeMB,
      seconds: secs,
      files,
      appRoot: APP_ROOT,
      error: ''
    }
    writeState(state)
    appendLog(`备份完成：${finalZip}（${sizeMB} MB，${secs}s，${files} 个文件）`)
    logLine(`备份完成（${reason}）：${finalZip}（${sizeMB} MB，${secs}s）`)
    return { ok: true, file: finalZip, sizeMB, seconds: secs, reason, state }
  } catch (error) {
    const msg = error?.message ?? String(error)
    writeState({ ok: false, lastAttempt: new Date().toISOString(), lastFile: finalZip, error: msg, appRoot: APP_ROOT })
    appendLog(`备份失败：${msg}`)
    logLine(`备份失败（${reason}）：${msg}`)
    throw new Error(msg)
  } finally {
    try { fs.rmSync(tmpRoot, { recursive: true, force: true }) } catch { /* ignore */ }
  }
}

/** 跨实例/跨重载互斥锁：防止定时与手动、或热重载留下的旧实例同时打包。 */
function acquireLock() {
  const lock = path.join(WORK_DIR, 'run.lock')
  try {
    fs.mkdirSync(WORK_DIR, { recursive: true })
    try {
      const st = fs.statSync(lock)
      if (Date.now() - st.mtimeMs < 10 * 60 * 1000) return false
      fs.rmSync(lock, { force: true })
    } catch { /* 没有锁文件 */ }
    fs.writeFileSync(lock, String(process.pid), { flag: 'wx' })
    return true
  } catch { return false }
}

function releaseLock() {
  try { fs.rmSync(path.join(WORK_DIR, 'run.lock'), { force: true }) } catch { /* ignore */ }
}

/** 跑一次备份。同一实例复用 Promise；跨实例靠 run.lock。 */
export async function runBackup(reason = '手动') {
  if (currentRun) return currentRun
  if (!acquireLock()) {
    logLine(`跳过本次备份（${reason}）：已有一次备份在进行中`)
    return { ok: false, skipped: true, reason }
  }
  currentRun = doBackup(reason).finally(() => { releaseLock(); currentRun = null })
  return currentRun
}

function scheduleNext() {
  if (timer) { clearTimeout(timer); timer = null }
  nextRunAt = nextOccurrence()
  const delay = Math.max(1000, nextRunAt - Date.now())
  timer = setTimeout(async () => {
    try { await runBackup('定时') } catch { /* 已写日志 */ }
    scheduleNext()
  }, delay)
  timer.unref?.()
}

/** 开机/重载补跑：错过了最近一次 00:00 且上次成功更早，就跑一次。 */
function maybeCatchUp() {
  const last = lastOccurrence()
  const st = readState()
  const lastRun = st?.lastRun ? Date.parse(st.lastRun) : 0
  if (lastRun >= last) return
  catchUpTimer = setTimeout(async () => {
    catchUpTimer = null
    // 90 秒里可能已经手动备份过 / 别的实例补过了：再确认一次
    const now = readState()
    const ranAt = now?.lastRun ? Date.parse(now.lastRun) : 0
    if (ranAt >= lastOccurrence()) return
    try { await runBackup('补跑') } catch { /* 已写日志 */ }
  }, 90 * 1000)
  catchUpTimer.unref?.()
}

/** 下一次「周几 HH:MM」（1=周一 … 7=周日）。 */
function nextWeeklyAt(now = Date.now()) {
  const s = settings()
  const [h, m] = s.emailTime.split(':').map(Number)
  const d = new Date(now)
  d.setHours(h, m, 0, 0)
  const jsDow = d.getDay() === 0 ? 7 : d.getDay()
  let diff = s.emailWeekday - jsDow
  if (diff < 0 || (diff === 0 && d.getTime() <= now)) diff += 7
  d.setDate(d.getDate() + diff)
  return d.getTime()
}

const WEEKDAY_NAMES = ['', '周一', '周二', '周三', '周四', '周五', '周六', '周日']

/** 把文件切成 <= maxBytes 的分卷（返回路径数组）。 */
function splitFile(file, maxBytes) {
  const parts = []
  const fd = fs.openSync(file, 'r')
  try {
    const size = fs.fstatSync(fd).size
    const count = Math.ceil(size / maxBytes)
    for (let i = 0; i < count; i++) {
      const offset = i * maxBytes
      const len = Math.min(maxBytes, size - offset)
      const buf = Buffer.alloc(len)
      fs.readSync(fd, buf, 0, len, offset)
      const part = `${file}.part${String(i + 1).padStart(2, '0')}of${String(count).padStart(2, '0')}`
      fs.writeFileSync(part, buf)
      parts.push(part)
    }
  } finally {
    fs.closeSync(fd)
  }
  return parts
}

/** 直接读主配置（不用核心 getConfig：在独立进程里它可能解析到别的数据目录）。 */
function mainConfig() {
  try { return JSON.parse(fs.readFileSync(path.join(DATA_DIR, 'config.json'), 'utf8')) } catch { return {} }
}

function ownerQq() {
  const s = settings()
  if (s.qqTo) return String(s.qqTo).replace(/[^0-9]/g, '')
  try {
    const c = mainConfig()
    const ids = String(c?.skills?.['owner-identity']?.ids || '').split(/[,，\s]+/).filter(Boolean)
    if (ids[0]) return ids[0].replace(/[^0-9]/g, '')
    const priv = (c?.allow?.private || [])[0]
    if (priv) return String(priv).replace(/[^0-9]/g, '')
  } catch { /* ignore */ }
  return ''
}

function onebotHttp() {
  let base = ''
  let token = ''
  try {
    const c = mainConfig().snowluma || {}
    base = String(c.httpUrl || '').trim()
    if (!base) {
      const ws = String(c.wsUrl || 'ws://127.0.0.1:3001')
      base = ws.replace(/^ws/, 'http').replace(/:3001(\/|$)/, ':3000$1')
    }
    token = String(c.httpAccessToken || c.accessToken || '')
  } catch { /* ignore */ }
  if (!base) base = 'http://127.0.0.1:3000'
  return { base: base.replace(/\/+$/, ''), token }
}

/** 把一个文件直接发到主人私聊（OneBot upload_private_file；本机协议端直接读路径，不传内容）。 */
export async function sendFileToOwner(filePath, name) {
  const qq = ownerQq()
  if (!qq) throw new Error('找不到主人 QQ：owner-identity 的 ids 为空，且没有私聊白名单')
  if (!fs.existsSync(filePath)) throw new Error('文件不存在：' + filePath)
  const { base, token } = onebotHttp()
  const res = await fetch(base + '/upload_private_file', {
    method: 'POST',
    headers: {
      'content-type': 'application/json; charset=utf-8',
      ...(token ? { authorization: 'Bearer ' + token } : {})
    },
    body: JSON.stringify({ user_id: Number(qq), file: filePath, name: name || path.basename(filePath) }),
    signal: AbortSignal.timeout(5 * 60 * 1000)
  })
  const body = await res.json().catch(() => null)
  if (!res.ok || !body || Number(body.retcode) !== 0) {
    const detail = body ? `retcode=${body.retcode} ${body.message || body.wording || ''}` : `HTTP ${res.status}`
    throw new Error(`发送到 QQ 失败（${detail}）`)
  }
  return { ok: true, qq, data: body.data }
}

async function qqBackup(reason) {
  const s = settings()
  if (!s.qqEnabled) return { ok: false, skipped: 'disabled' }
  let backup = null
  try {
    backup = await runBackup('周备份')
  } catch (error) {
    const msg = error?.message ?? String(error)
    writeState({ ...readState(), lastQqAt: new Date().toISOString(), lastQqOk: false, lastQqError: '备份失败：' + msg })
    logLine('周备份失败，未能发送：' + msg)
    return { ok: false, error: msg }
  }
  try {
    const r = await sendFileToOwner(backup.file, path.basename(backup.file))
    writeState({
      ...readState(),
      lastQqAt: new Date().toISOString(),
      lastQqOk: true,
      lastQqTo: r.qq,
      lastQqSizeMB: backup.sizeMB,
      lastQqError: ''
    })
    logLine(`每周备份已发到主人 QQ（${r.qq}）：${backup.file}（${backup.sizeMB} MB）`)
    return { ok: true, qq: r.qq, file: backup.file }
  } catch (error) {
    const msg = error?.message ?? String(error)
    writeState({ ...readState(), lastQqAt: new Date().toISOString(), lastQqOk: false, lastQqError: msg })
    logLine('发到主人 QQ 失败：' + msg)
    return { ok: false, error: msg }
  }
}

function scheduleWeekly() {
  if (weeklyTimer) { clearTimeout(weeklyTimer); weeklyTimer = null }
  const s = settings()
  if (!s.qqEnabled) { nextEmailAt = 0; return }
  nextEmailAt = nextWeeklyAt()
  const delay = Math.max(1000, nextEmailAt - Date.now())
  weeklyTimer = setTimeout(async () => {
    try { await qqBackup('周定时') } catch (error) { logLine('周备份发送异常：' + (error?.message ?? error)) }
    scheduleWeekly()
  }, delay)
  weeklyTimer.unref?.()
}

export async function setup(a = {}) {
  api = a
  try {
    const { logger } = await import('../../src/logger.js')
    if (logger?.info) fileLog = (m) => logger.info(LOG_TAG, String(m))
  } catch { /* 拿不到就只走 console */ }

  a.registerTool({
    id: 'backup_now',
    name: '立即备份',
    description: '立刻把 QQ Agent 的 data/plugins/skills 打包备份到桌面（覆盖旧备份），返回文件路径与大小。',
    category: 'system',
    icon: '💾',
    parameters: { type: 'object', properties: {}, additionalProperties: false },
    async execute() {
      try {
        const r = await runBackup('手动')
        return `备份完成：${r.file}（${r.sizeMB} MB，${r.seconds}s）`
      } catch (error) {
        return `备份失败：${error?.message ?? error}`
      }
    }
  })

  a.registerTool({
    id: 'backup_status',
    name: '备份状态',
    description: '查看自动备份是否启用、下次运行时间、上一次备份的时间/文件/大小/是否成功。',
    category: 'system',
    icon: '🗄️',
    parameters: { type: 'object', properties: {}, additionalProperties: false },
    async execute() {
      const s = settings()
      const st = readState()
      const lines = [
        `自动备份：${s.enabled ? '已启用' : '已停用'}`,
        `每天：${s.time}（下次 ${fmt(nextRunAt || nextOccurrence())}）`,
        `目标：${s.destDir || desktopDir()}\\${s.zipName}`,
        `上次成功：${st.lastRun ? fmt(Date.parse(st.lastRun)) : '还没有'}`,
        `上次结果：${st.ok === false ? `失败（${st.error || '未知原因'}）` : (st.lastRun ? `成功，${st.lastSizeMB ?? '?'} MB` : '—')}`,
        `文件：${st.lastFile || '—'}`,
        '',
        `每周发 QQ：${s.qqEnabled ? '已启用' : '已停用'}（${WEEKDAY_NAMES[s.emailWeekday] || '周日'} ${s.emailTime}，下次 ${s.qqEnabled ? fmt(nextEmailAt || nextWeeklyAt()) : '—'}）`,
        `收件：${ownerQq() || '找不到主人 QQ'}`,
        `上次发送：${st.lastQqAt ? fmt(Date.parse(st.lastQqAt)) + (st.lastQqOk === false ? `（失败：${st.lastQqError || '未知'}）` : '（成功）') : '还没有'}`
      ]
      return lines.join('\n')
    }
  })

  a.registerTool({
    id: 'backup_send',
    name: '把备份发到主人QQ',
    description: '立即做一次最新备份，并把这个 zip 直接发到主人的 QQ 私聊。',
    category: 'system',
    icon: '📤',
    parameters: { type: 'object', properties: {}, additionalProperties: false },
    async execute() {
      try {
        const r = await qqBackup('手动')
        if (r.ok) return `已发到主人 QQ（${r.qq}）：${path.basename(r.file)}`
        return `发送失败：${r.error || r.skipped || '未知原因'}`
      } catch (error) {
        return `发送失败：${error?.message ?? error}`
      }
    }
  })
}

export function activate() {
  const s = settings()
  if (!s.enabled) {
    logLine('自动备份在设置里是关的，不排班')
  } else {
    scheduleNext()
    if (s.catchUpOnStart) maybeCatchUp()
    logLine(`自动备份已启用：每天 ${s.time} → ${s.destDir || desktopDir()}\\${s.zipName}`)
  }
  if (s.qqEnabled) {
    scheduleWeekly()
    logLine(`每周备份将发到主人 QQ（${ownerQq() || '找不到主人 QQ'}）：每${WEEKDAY_NAMES[s.emailWeekday] || '周日'} ${s.emailTime}`)
  }
}

export function deactivate() {
  if (timer) { clearTimeout(timer); timer = null }
  if (catchUpTimer) { clearTimeout(catchUpTimer); catchUpTimer = null }
  if (weeklyTimer) { clearTimeout(weeklyTimer); weeklyTimer = null }
}

export function dispose() {
  deactivate()
}

export function available() {
  return { ok: true }
}

export const internals = { APP_ROOT, DATA_DIR, WORK_DIR, STATE_FILE, LOG_FILE, nextOccurrence, lastOccurrence, nextWeeklyAt, readState, desktopDir, writeZip, crc32, splitFile, qqBackup, sendFileToOwner }
