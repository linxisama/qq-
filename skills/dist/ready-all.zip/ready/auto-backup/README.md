# 自动备份（桌面 + 每周发 QQ）

每天定时把 QQ Agent 的 **data（设置 / AI 记忆 / 会话 / 聊天记录 / 插件状态）**、**plugins**、**skills**
打包成一个 zip 放到桌面，第二天覆盖同一个文件；每周再把这份备份直接发到主人 QQ。
目的是"出事了能整体换回来"，平时不用管。

## 放在哪

```
<QQ Agent 根目录>\resources\app\skills\auto-backup\
  ├─ index.js            技能入口（排班 + 备份实现 + 两个工具）
  ├─ skill.json          清单与设置项
  ├─ README.md           本文件
  └─ MIGRATION-GUIDE.md  迁移 / 恢复 / 换电脑的完整说明
```

## 怎么用

装好并重启 QQ Agent 后：

- 控制台「技能」页会出现 **自动备份（每天存桌面 · 每周发QQ）**，默认启用
- 设置里可以改：启用开关、每天几点、备份目录（留空 = 当前用户桌面）、文件名、错过是否补跑
- 机器人有三个工具（你也可以直接在 QQ 里让它做）：
  - `backup_now` —— 立即备份一次
  - `backup_status` —— 看是否启用、下次时间、上次结果（含每周发送状态）
  - `backup_send` —— 立即备份并把 zip 发到主人 QQ

## 每周发到主人 QQ（默认开）

- 每周日 09:00（可改星期与时间）先做一次最新备份，再把 zip **直接发到主人 QQ 私聊**
- 收件人自动认：优先「主人识别」插件里的 `ids`，其次私聊白名单第一个；也可在设置里填「收件 QQ」
- 走机器人自己的协议端（OneBot `upload_private_file`），不需要邮箱、不需要授权码
- 本机实测 32 MB 的包约 20 秒传完；失败只写日志，本地备份不受影响
- `backup_status` 能看到上次发送的时间、对象与结果

## 备份内容

| 包含 | 不包含（可再生的缓存） |
|---|---|
| `data\` 全部（config.json、memory、sessions、messages、各插件状态） | `data\electron-user-data` |
| `resources\app\plugins\` | `data\whale-memes\tmp` |
| `resources\app\skills\` | `data\qq-agent.lock` |

zip 里附一份 `README-backup.txt`，写着恢复步骤。

## 行为细节

- **只留一份**：文件名固定（默认 `QQAgent备份.zip`），每天覆盖
- **不会把旧备份弄丢**：先写临时包，确认大小正常才替换；失败只写日志，旧包原样保留
- **补跑**：00:00 时 QQ Agent 没开着的话，启动约 90 秒后补一次（当天已备份过就不补）
- **并发保护**：同一实例复用同一次运行；跨实例/热重载用 `data\auto-backup\run.lock` 互斥，
  定时与手动撞车不会同时打两个包
- 日志：`data\auto-backup\backup.log`；状态：`data\auto-backup\state.json`

## 实现方式

纯 Node（`fs` + `zlib`）：递归复制到临时目录，再自己写 ZIP（deflate + UTF-8 文件名标志位），
不依赖 PowerShell、7-Zip 或任何外部程序；也不需要装 Node —— 用的就是 QQ Agent 自带的运行时。

## 注意

- 备份里有 `SESSDATA` 等登录凭据，不要外传。
- 需要 QQ Agent 正在运行才会触发定时；已删除旧的 Windows 计划任务，避免同一时间跑两份。
- 想手动备份：在 QQ 里让它「立即备份」，或调用工具 `backup_now`。
