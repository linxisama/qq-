// 浏览器控制（browser-control）—— LLM 型技能，放 skills/。
//
// ── 它是什么 ─────────────────────────────────────────────────────────────
//   把桌面上那套 bsk（BrowserSkill / Tencent BrowserSkill）的浏览器能力接到 QQ 机器人身上：
//   开页、看页面、点、填、按键、截图、读控制台/网络。**浏览器是你的**（你登着的账号、你的登录态），
//   机器人只是被允许在你开出来的那个 Agent 窗口里动。
//
// ── 为什么是技能，不是插件 ───────────────────────────────────────────────
//   「打开什么、点哪个、填什么」全靠看懂人话。插件那套"条件满足必跑"在这里是灾难：
//   没有任何一条正则能判断"帮我看看这个页面"该点哪里。所以注册工具，让模型自己决定。
//
// ── 传输链路（这是移植的关键，别绕过）─────────────────────────────────────
//   本技能 = `bsk.exe` 的薄壳客户端。真正的活由常驻守护进程干：
//     QQ Agent(本进程) --spawn--> bsk.exe --IPC(命名管道)--> bsk daemon --WS--> Chrome 扩展
//   所以：
//   · 必须能找到 bsk.exe（设置里的路径，或 PATH，或 ~/.local/bin）
//   · 必须有一个**会话**（session id）：所有页面级命令都要 --session。本技能自己管会话，
//     模型不用碰 session id（那是内部 id，让模型记只会记错）。
//   · 参数一律显式传：`@e1` 这类 ref 在 PowerShell 里会被吃掉，一律用 `--ref`；
//     URL / 选择器 / JS 一律用 `--` 之外的显式选项或位置参数（见 runBsk 的注释）。
//
// ── 安全边界（在代码里，不靠提示词）─────────────────────────────────────
//   1. 域名白名单（allowHosts）：非空时，navigate / 借来的标签页只允许白名单域名。
//      空 = 不限制（默认），但那时仍受下面两条约束。
//   2. 敏感页拦截（denyPatterns）：登录、支付、后台、邮箱这类页面可以直接
//      navigate 上去看，但**不许在它们的输入框里填东西**（fill），除非用户显式放行。
//   3. 只在 Agent 窗口里动：默认 scope=agent，不碰用户自己开着的标签页；
//      要借用用户页签必须显式 borrow，借完必须归还（return）。
//   4. 浏览器登录态即用户身份：evaluate 能读 document.cookie。所以每次运行有次数上限，
//      且 screenshot/提取内容发到群里之前，模型必须自己确认里面没有别人的隐私
//      （privacy-guard 插件的底线同样覆盖这里）。
//
// ── 踩坑备忘 ─────────────────────────────────────────────────────────────
//   · daemon 在沙箱/JOB 里可能起不来（os error 5）：必须能识别并给出人能照做的提示，
//     而不是把 exit code 2 原样抛给模型。
//   · 会话要复用：每轮新建会堆出无数 Agent 窗口，用户桌面会被窗口占满。
//   · 会话可能"活着但浏览器断了"：复用前先 ping 一次（tab list），失败就重建。
//   · 输出必须截断：observe 在长页面上能吐出几万字符，塞进上下文就是烧钱。
//   · 命令超时要比 bsk 自己的 --timeout 长：bsk 超时会返回结构化 JSON，
//     我们这边先杀掉进程就拿不到原因了。

import { execFile } from 'node:child_process';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const BUILD_TAG = 'v1.0.0';

const APP_ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..', '..');
const WORK_ROOT = path.resolve(APP_ROOT, 'data', 'browser-control');

const DEFAULTS = {
  enabled: true,
  bskPath: '',
  browserInstance: '',
  allowHosts: '',
  denyFillPatterns: 'login,登录,signin,sign-in,passport,pay,支付,checkout,order,admin,后台,mail,邮箱,bank,网银',
  allowFillOnSensitive: false,
  maxCharsPerCall: 6000,
  maxEvalPerRun: 8,
  maxScreenshotPerRun: 3,
  screenshotToChat: true,
  idleCloseMinutes: 30
};

let api = null;
let cfg = () => ({ ...DEFAULTS });
let log = () => {};
let warn = () => {};

/** chatKey → { sessionId, browser, startedAt, lastUsedAt, evals, shots } */
const sessions = new Map();

export const SKILL_ID = 'browser-control';

export function setup(injected) {
  api = injected;
  cfg = injected.config;
  log = injected.log || (() => {});
  warn = injected.warn || (() => {});

  fs.mkdirSync(WORK_ROOT, { recursive: true });
  log(`浏览器控制已加载（${BUILD_TAG}）｜bsk: ${resolveBsk() || '（没找到，见设置）'}`);

  // ── 1. 打开页面 ────────────────────────────────────────────────────────
  api.registerTool({
    id: 'open',
    name: '浏览器打开网页',
    description: '在浏览器里打开一个网址，等页面加载完，返回标题 + 简化的页面结构（可点/可填的元素带 @eN 编号）。'
      + '什么时候用：群友给了一个链接让你看看、要你查页面上的东西、或者要在网站上完成一步操作。'
      + '不需要用：只是要摘要一个网页内容，优先用 web_fetch（更快、不占你的屏幕）；'
      + '页面需要登录、要点击要填表、或者 web_fetch 拿不到内容时才来用它。'
      + '打开后想看清结构用 browser-control__observe，确认元素编号再点击/填写。',
    category: 'web',
    icon: '🌐',
    defaultEnabled: true,
    parameters: {
      type: 'object',
      properties: {
        url: { type: 'string', description: '完整网址（http/https）' },
        tab: { type: 'string', description: '可选：用已有标签页的 id（来自 browser-control__tabs）' }
      },
      required: ['url']
    },
    async execute(ctx, args) {
      const c = settings();
      const raw = String(args?.url ?? '').trim();
      if (!raw) return fail('url 不能为空');
      const url = normalizeUrl(raw);
      if (!url) return fail(`这不像一个网址：${raw}（要 http/https 开头）`);
      const guard = checkHost(url);
      if (!guard.ok) return fail(guard.reason);

      const s = await ensureSession(ctx);
      if (s.error) return fail(s.error);
      ctx.__browserRun = ctx.__browserRun || { evals: 0, shots: 0 };

      const r = await runBsk(s.exe, ['navigate', url, '--session', s.sessionId, '--json', '--timeout', '45s'], ctx);
      if (!r.ok) return fail(friendlyBskError(r, '打开网页失败'));
      const p = safeJson(r.stdout);
      await runBsk(s.exe, ['wait-for-element', 'body', '--state', 'attached', '--timeout', '10s',
        '--session', s.sessionId, '--json'], ctx).catch(() => null);
      // ⚠️ 顺序很重要：先取正文、再取结构。
      //   observe 只要输出偏大，之后同一标签页上的 evaluate 就会把非拉丁文（阿拉伯文、
      //   波斯文…）返回成 `?`；而 navigate / reload 之后会恢复。所以正文必须先拿。
      //   结构是给模型看交互元素的，放在最后，用户拿到 @eN 也正好可以直接点。
      const text = await readPageText(s, Math.min(c.maxCharsPerCall, 1500), ctx);
      const obs = await observeText(s, c, ctx);
      const textPart = text.ok && text.text
        ? `\n\n—— 正文（前 1500 字，要更多用 browser-control__text）——\n${text.text}`
        : '';
      return {
        content: `已打开：${p?.url || url}\n最终地址：${p?.final_url || url}${textPart}\n\n—— 可交互结构 ——\n${obs}`
      };
    }
  });

  // ── 2. 看页面结构 ──────────────────────────────────────────────────────
  api.registerTool({
    id: 'observe',
    name: '看当前页面',
    description: '看当前标签页现在长什么样：简化的可交互结构 + @eN 编号（点击/填写都用这个编号）。'
      + '什么时候用：刚打开页面后、点完一个按钮后、页面没按预期变化时。'
      + '要的是"页面上写了什么字"用 browser-control__text；要交互元素用这个。',
    category: 'web',
    icon: '👀',
    defaultEnabled: true,
    parameters: { type: 'object', properties: {} },
    async execute(ctx, args) {
      const c = settings();
      const s = await ensureSession(ctx);
      if (s.error) return fail(s.error);
      return { content: await observeText(s, c, ctx) };
    }  });

  // ── 3. 读正文 ──────────────────────────────────────────────────────────
  api.registerTool({
    id: 'text',
    name: '读页面正文',
    description: '把当前页面（或某个 @eN 区域）的正文文字读出来，适合"这个页面说了什么""帮我看这段话"。'
      + '比 observe 短、比 get-html 干净。读不到内容（比如全在 iframe 里、还没加载完）时，'
      + '可以改用 browser-control__html 看结构。',
    category: 'web',
    icon: '📄',
    defaultEnabled: true,
    parameters: {
      type: 'object',
      properties: {
        ref: { type: 'string', description: '可选：只看某个区域，传 @eN 编号' },
        max_chars: { type: 'number', description: '最多读多少字，默认 4000' }
      }
    },
    async execute(ctx, args) {
      const s = await ensureSession(ctx);
      if (s.error) return fail(s.error);
      const cap = Math.min(12000, Math.max(400, Number(args?.max_chars) || 4000));
      const ref = cleanRef(args?.ref);
      const got = await readPageTextWithRecovery(s, cap, ctx, ref);
      if (!got.ok) return fail(got.error);
      if (!got.text) return { content: '这一页没读到正文（可能是空白页、内容全在 iframe 里，或还没加载完）。试试 browser-control__observe 看结构。' };
      const note = ref ? `\n（ref=@${ref}）` : '';
      return { content: `${got.text}${got.truncated ? `\n…（已截断，本次只取前 ${cap} 字）` : ''}${note}` };
    }
  });

  // ── 4. 点击 ────────────────────────────────────────────────────────────
  api.registerTool({
    id: 'click',
    name: '点击元素',
    description: '点击页面上的一个元素。用 observe 给出的 @eN 编号，或 CSS 选择器。'
      + '点完建议用 browser-control__observe 看有没有变化；点了链接会跳转，地址用 browser-control__info 查。'
      + '不要点「删除/支付/确认下单/退出登录」这类会造成真实后果的按钮，除非群友明确要求。',
    category: 'web',
    icon: '👆',
    defaultEnabled: true,
    parameters: {
      type: 'object',
      properties: {
        target: { type: 'string', description: '@eN 编号（如 @e3）或 CSS 选择器' },
        button: { type: 'string', description: 'left（默认）/ middle / right' },
        click_count: { type: 'number', description: '连点几次，双击填 2' }
      },
      required: ['target']
    },
    async execute(ctx, args) {
      const t = String(args?.target ?? '').trim();
      if (!t) return fail('target 不能为空（用 @eN 或 CSS 选择器）');
      const s = await ensureSession(ctx);
      if (s.error) return fail(s.error);
      const argv = ['click', '--session', s.sessionId, '--json', '--timeout', '30s'];
      if (/^@?e\d+$/i.test(t)) argv.push('--ref', t.replace(/^@/, ''));
      else argv.push('--selector', t);
      if (args?.button) argv.push('--button', String(args.button).toLowerCase());
      if (Number(args?.click_count) >= 2) argv.push('--click-count', String(Math.min(3, Math.floor(Number(args.click_count)))));
      const r = await runBsk(s.exe, argv, ctx);
      if (!r.ok) return fail(friendlyBskError(r, '点击失败'));
      const p = safeJson(r.stdout);
      // 点击常触发跳转/异步渲染：等一拍再看地址，能省模型一次往返
      await runBsk(s.exe, ['wait-ms', '600', '--session', s.sessionId], ctx).catch(() => null);
      const info = await pageInfo(s, ctx);
      return { content: `已点击 ${p?.used_ref ? '@' + p.used_ref : (p?.used_selector || t)}\n${info}` };
    }
  });

  // ── 5. 填表 ────────────────────────────────────────────────────────────
  api.registerTool({
    id: 'fill',
    name: '填写输入框',
    description: '往一个输入框 / 文本域 / 可编辑区域里填字。target 用 @eN 或 CSS 选择器。'
      + '登录、支付、后台、邮箱这类敏感页面的输入框默认**不许填**（防误操作他人账号）；'
      + '确实需要时让管理员在设置里打开"允许在敏感页填写"。'
      + '填完通常还要点提交或按 Enter：用 browser-control__click 或 browser-control__press。',
    category: 'web',
    icon: '⌨️',
    defaultEnabled: true,
    parameters: {
      type: 'object',
      properties: {
        target: { type: 'string', description: '@eN 编号或 CSS 选择器' },
        value: { type: 'string', description: '要填进去的文字' },
        clear: { type: 'boolean', description: 'true（默认）= 先清空再填；false = 追加' }
      },
      required: ['target', 'value']
    },
    async execute(ctx, args) {
      const c = settings();
      const t = String(args?.target ?? '').trim();
      const value = String(args?.value ?? '');
      if (!t) return fail('target 不能为空');
      if (!value) return fail('value 不能为空（要填什么？）');
      const s = await ensureSession(ctx);
      if (s.error) return fail(s.error);

      if (!c.allowFillOnSensitive) {
        const info = await pageUrl(s, ctx);
        const hit = sensitiveHit(info, c.denyFillPatterns);
        if (hit) {
          return fail(`当前页面看起来是敏感页（命中「${hit}」：${info}）。在登录/支付/后台/邮箱这类页面里代填输入框，`
            + `默认是关掉的。确实要填，请管理员在「技能 → 浏览器控制 → 允许在敏感页填写」打开。`);
        }
      }
      const argv = ['fill', '--session', s.sessionId, '--value', value, '--json', '--timeout', '30s'];
      if (/^@?e\d+$/i.test(t)) argv.push('--ref', t.replace(/^@/, ''));
      else argv.push('--selector', t);
      if (args?.clear === false) argv.push('--no-clear');
      const r = await runBsk(s.exe, argv, ctx);
      if (!r.ok) return fail(friendlyBskError(r, '填写失败'));
      const p = safeJson(r.stdout);
      return { content: `已填入 ${p?.value_length ?? value.length} 个字${args?.clear === false ? '（追加）' : '（已先清空）'}。` };
    }
  });

  // ── 6. 按键 ────────────────────────────────────────────────────────────
  api.registerTool({
    id: 'press',
    name: '按键',
    description: '发送一次键盘操作，如 Enter、Escape、Tab、Ctrl+A、ArrowDown。'
      + '常用：填完搜索框按 Enter 提交；关弹窗用 Escape。',
    category: 'web',
    icon: '⎎',
    defaultEnabled: true,
    parameters: {
      type: 'object',
      properties: {
        key: { type: 'string', description: '键名或组合，如 Enter / Escape / Ctrl+A' },
        target: { type: 'string', description: '可选：先聚焦到这个 @eN 或选择器再按键' }
      },
      required: ['key']
    },
    async execute(ctx, args) {
      const key = String(args?.key ?? '').trim();
      if (!key) return fail('key 不能为空');
      const s = await ensureSession(ctx);
      if (s.error) return fail(s.error);
      const argv = ['press', key, '--session', s.sessionId, '--json', '--timeout', '30s'];
      const t = String(args?.target ?? '').trim();
      if (t) {
        if (/^@?e\d+$/i.test(t)) argv.push('--ref', t.replace(/^@/, ''));
        else argv.push('--selector', t);
      }
      const r = await runBsk(s.exe, argv, ctx);
      if (r.ok) return { content: `已按键：${key}` };
      // `--ref` 偶发失效：页面在 observe 之后重渲染过，旧的 node 已经不属于当前 frame，
      // bsk 会报 "node frame does not belong to its target"。这时退回"先聚焦再按键"，
      // 用户在群里等的是一次回车，不该因为内部引用过期就让这一步失败。
      if (t && /^@?e\d+$/i.test(t)) {
        const fallback = ['press', key, '--session', s.sessionId, '--json', '--timeout', '30s'];
        const focused = await runBsk(s.exe, ['focus', '--ref', t.replace(/^@/, ''), '--session', s.sessionId, '--json'], ctx, { timeoutMs: 20000 });
        if (focused.ok) {
          const r2 = await runBsk(s.exe, fallback, ctx);
          if (r2.ok) return { content: `已按键：${key}（@${t.replace(/^@/, '')} 的引用已过期，改为先聚焦再发送）` };
        }
        // 再退一步：用 activeElement 直接派发键盘事件
        const r3 = await runBsk(s.exe, ['evaluate',
          `(() => { const el = document.activeElement || document.body; `
          + `const ev = (t) => new KeyboardEvent(t, { key: ${JSON.stringify(key)}, bubbles: true, cancelable: true }); `
          + `el.dispatchEvent(ev('keydown')); el.dispatchEvent(ev('keyup')); return 'sent'; })()`,
          '--session', s.sessionId, '--json'], ctx, { timeoutMs: 20000 });
        if (r3.ok && safeJson(r3.stdout)?.ok) {
          return { content: `已按键：${key}（原引用失效，已改为在当前焦点元素上派发）` };
        }
      }
      return fail(friendlyBskError(r, `按键 ${key} 失败`));
    }
  });

  // ── 7. 截图 ────────────────────────────────────────────────────────────
  api.registerTool({
    id: 'screenshot',
    name: '截图',
    description: '给当前页面截一张图。可以用来「发张截图给群友看」，也可以自己看布局。'
      + '默认会顺手发到当前聊天（设置里可关）。每次运行有张数上限，别刷屏。'
      + '截图包含你的浏览器登录态内容：发之前自己确认里面没有别人的隐私、没有验证码、没有被登录的账号信息。',
    category: 'web',
    icon: '📸',
    defaultEnabled: true,
    requiresVision: false,
    parameters: {
      type: 'object',
      properties: {
        full_page: { type: 'boolean', description: 'true = 整页长图（会慢一些）' },
        send: { type: 'boolean', description: '是否发到当前聊天，默认按设置' },
        ref: { type: 'string', description: '可选：只截某个 @eN 区域' }
      }
    },
    async execute(ctx, args) {
      const c = settings();
      const s = await ensureSession(ctx);
      if (s.error) return fail(s.error);
      ctx.__browserRun = ctx.__browserRun || { evals: 0, shots: 0 };
      if (ctx.__browserRun.shots >= c.maxScreenshotPerRun) {
        return fail(`本次运行已经截了 ${ctx.__browserRun.shots} 张图，到上限了（设置里可调）。`);
      }
      const out = path.join(WORK_ROOT, `shot-${Date.now()}.png`);
      const argv = ['screenshot', '--session', s.sessionId, '--out', out, '--json'];
      if (args?.full_page === true) argv.push('--full-page', '--timeout', '90s');
      const ref = cleanRef(args?.ref);
      if (ref) argv.push('--ref', ref);
      const r = await runBsk(s.exe, argv, ctx, { timeoutMs: 120000 });
      if (!r.ok) return fail(friendlyBskError(r, '截图失败'));
      ctx.__browserRun.shots += 1;
      const p = safeJson(r.stdout);
      const shouldSend = args?.send === undefined ? c.screenshotToChat : args.send === true;
      if (shouldSend && ctx?.sender && ctx?.chatKey) {
        try {
          await ctx.sender.sendImage(ctx.chatKey, { file: p?.path || out }, { note: '浏览器截图' });
        } catch (error) {
          return { content: `截图已保存：${p?.path || out}（${p?.width}×${p?.height}），但发到聊天失败：${error?.message ?? error}` };
        }
      }
      return {
        content: `截图完成：${p?.width}×${p?.height}，${Math.round((Number(p?.byte_size) || 0) / 1024)}KB`
          + `${shouldSend && ctx?.sender ? '，已发到聊天' : ''}。\n文件：${p?.path || out}`
      };
    }
  });

  // ── 8. 当前地址与标题 ──────────────────────────────────────────────────
  api.registerTool({
    id: 'info',
    name: '当前页面信息',
    description: '拿当前标签页的地址和标题。判断"点击后跳没跳"、确认现在在哪一页时用。',
    category: 'web',
    icon: 'ℹ️',
    defaultEnabled: true,
    parameters: { type: 'object', properties: {} },
    async execute(ctx, args) {
      const s = await ensureSession(ctx);
      if (s.error) return fail(s.error);
      return { content: await pageInfo(s, ctx) };
    }
  });

  // ── 9. 标签页管理 ──────────────────────────────────────────────────────
  api.registerTool({
    id: 'tabs',
    name: '标签页管理',
    description: '列出 / 新建 / 切换 / 关闭标签页。scope=agent 只看机器人自己那个窗口（默认，推荐）；'
      + 'user 是用户自己开着的标签页（只读列表，别乱碰）；all 全看。'
      + 'action=borrow 会把用户的一个标签页借到机器人窗口里（需要用户在场确认），用完用 action=return 还回去。',
    category: 'web',
    icon: '🗂️',
    defaultEnabled: true,
    parameters: {
      type: 'object',
      properties: {
        action: { type: 'string', description: 'list（默认）/ create / select / close / borrow / return' },
        tab: { type: 'string', description: 'tab id 或索引（list 结果里的 tabId）' },
        url: { type: 'string', description: 'action=create 时的初始地址' },
        scope: { type: 'string', description: 'list 的范围：agent / user / all，默认 agent' }
      }
    },
    async execute(ctx, args) {
      const c = settings();
      const s = await ensureSession(ctx);
      if (s.error) return fail(s.error);
      const action = String(args?.action || 'list').toLowerCase();
      let argv;
      if (action === 'list') {
        const scope = ['agent', 'user', 'all'].includes(String(args?.scope)) ? String(args.scope) : 'agent';
        argv = ['tab', 'list', '--session', s.sessionId, '--scope', scope, '--json'];
      } else if (action === 'create') {
        const raw = String(args?.url ?? '').trim();
        argv = ['tab', 'create', '--session', s.sessionId, '--json'];
        if (raw) {
          const url = normalizeUrl(raw);
          if (!url) return fail(`这不像一个网址：${raw}`);
          const guard = checkHost(url);
          if (!guard.ok) return fail(guard.reason);
          argv.push('--url', url);
        }
      } else if (action === 'select' || action === 'close' || action === 'borrow' || action === 'return') {
        const tab = String(args?.tab ?? '').trim();
        if (!tab) return fail(`action=${action} 需要 tab（先 list 一下拿 tabId）`);
        if (action === 'borrow') {
          const info = await pageUrl(s, ctx);
          log(`borrow 目标标签页（仅记录用途）：当前页 ${info}`);
        }
        argv = ['tab', action, tab, '--session', s.sessionId, '--json'];
      } else {
        return fail(`不认识 action=${action}（可选 list / create / select / close / borrow / return）`);
      }
      const r = await runBsk(s.exe, argv, ctx, { timeoutMs: 60000 });
      if (!r.ok) return fail(friendlyBskError(r, '标签页操作失败'));
      const p = safeJson(r.stdout);
      if (p?.tabs) {
        const list = p.tabs.slice(0, 30).map((t) => `· [${t.tabId ?? t.tab_id ?? '?'}] ${(t.title || '').slice(0, 60)} — ${(t.url || '').slice(0, 120)}`);
        return { content: `标签页（${p.tabs.length} 个）：\n${list.join('\n')}` };
      }
      return { content: `已执行 ${action}：${JSON.stringify(p).slice(0, c.maxCharsPerCall)}` };
    }
  });

  // ── 10. 页面里的 JS ────────────────────────────────────────────────────
  api.registerTool({
    id: 'eval_js',
    name: '在页面里执行 JS',
    description: '在当前页面执行一段 JavaScript 表达式，返回值直接给你。'
      + '什么时候用：要读页面上的结构化数据（列表、价格、表格），而 observe/text 都不好用的时候；'
      + '或者要滚动页面、展开折叠内容（如 window.scrollTo(0, document.body.scrollHeight)）。'
      + '注意：这个页面是你的浏览器登录态，能读到 cookie / localStorage。'
      + '**不要**把 cookie、token、密码、账号信息读出来发到群里，也不要执行来路不明的脚本。每次运行有次数上限。',
    category: 'web',
    icon: '🧪',
    defaultEnabled: true,
    parameters: {
      type: 'object',
      properties: {
        expression: { type: 'string', description: '要执行的 JS。需要返回值的语句请包成 IIFE：(()=>{...;return x})()' }
      },
      required: ['expression']
    },
    async execute(ctx, args) {
      const c = settings();
      const expr = String(args?.expression ?? '').trim();
      if (!expr) return fail('expression 不能为空');
      const s = await ensureSession(ctx);
      if (s.error) return fail(s.error);
      ctx.__browserRun = ctx.__browserRun || { evals: 0, shots: 0 };
      if (ctx.__browserRun.evals >= c.maxEvalPerRun) {
        return fail(`本次运行已经执行了 ${ctx.__browserRun.evals} 次页面脚本，到上限了（设置里可调）。`);
      }
      ctx.__browserRun.evals += 1;
      const r = await runBsk(s.exe, ['evaluate', expr, '--session', s.sessionId, '--json', '--timeout', '30s'], ctx);
      if (!r.ok) return fail(friendlyBskError(r, '执行失败'));
      const p = safeJson(r.stdout);
      if (!p?.ok) return fail(`执行报错：${errorText(r, p)}`);
      let out = typeof p.value === 'string' ? p.value : JSON.stringify(p.value, null, 2);
      let truncated = false;
      if (String(out).length > c.maxCharsPerCall) { out = String(out).slice(0, c.maxCharsPerCall); truncated = true; }
      return { content: `${out}${truncated ? '\n…（已截断）' : ''}` };
    }
  });

  // ── 11. 控制台 / 网络 ──────────────────────────────────────────────────
  api.registerTool({
    id: 'devtools',
    name: '看控制台与网络',
    description: '读当前页面的 console 日志 / JS 报错，或者网络请求（哪个接口失败、返回什么状态码）。'
      + '什么时候用：页面白屏、按钮点了没反应、接口 404/500、要确认请求真的发出去了。'
      + '普通"看看这页写了什么"不需要用它。',
    category: 'web',
    icon: '🐞',
    defaultEnabled: true,
    parameters: {
      type: 'object',
      properties: {
        kind: { type: 'string', description: 'console（默认）/ network' },
        limit: { type: 'number', description: '最多几条，默认 20' }
      }
    },
    async execute(ctx, args) {
      const c = settings();
      const s = await ensureSession(ctx);
      if (s.error) return fail(s.error);
      const kind = String(args?.kind || 'console').toLowerCase() === 'network' ? 'network' : 'console';
      const limit = Math.min(50, Math.max(1, Number(args?.limit) || 20));
      const r = await runBsk(s.exe, [kind, '--session', s.sessionId, '--json', '--limit', String(limit), '--max-text-chars', '300'], ctx);
      if (!r.ok) return fail(friendlyBskError(r, '读取失败'));
      const p = safeJson(r.stdout);
      const entries = Array.isArray(p?.entries) ? p.entries : [];
      if (!entries.length) return { content: `${kind === 'network' ? '网络' : '控制台'}没有记录（页面可能还没触发任何请求）。` };
      const lines = entries.slice(-limit).map((e) => kind === 'network'
        ? `· ${e.method || ''} ${e.status ?? e.kind} ${String(e.url || '').slice(0, 140)}`
        : `· [${e.level || e.kind}] ${String(e.text || '').slice(0, 200)}`);
      let out = `${kind === 'network' ? '网络' : '控制台'}最近 ${entries.length} 条：\n${lines.join('\n')}`;
      if (out.length > c.maxCharsPerCall) out = `${out.slice(0, c.maxCharsPerCall)}\n…（已截断）`;
      return { content: out };
    }
  });
}

// ── 生命周期 ─────────────────────────────────────────────────────────────

export function available() {
  return { ok: true };
}

export function activate() {
  startReaper();
}

export function deactivate() {
  stopReaper();
}

export function dispose() {
  stopReaper();
  for (const [key, s] of sessions) {
    runBsk(s.exe, ['session', 'stop', s.sessionId, '--json'], {}, { timeoutMs: 15000 }).catch(() => {});
    sessions.delete(key);
  }
  api = null;
}

/** 能力（只读）：排障面板/别的模块看一眼"浏览器那套是不是活着"。 */
export const providers = {
  'browser.status': () => {
    const c = settings();
    const bsk = resolveBsk();
    return {
      enabled: c.enabled,
      bskPath: bsk,
      bskFound: Boolean(bsk),
      sessions: [...sessions.entries()].map(([chatKey, s]) => ({
        chatKey, sessionId: s.sessionId, startedAt: s.startedAt, lastUsedAt: s.lastUsedAt
      })),
      allowHosts: c.allowHosts.length ? c.allowHosts : null
    };
  }
};

// ── 设置 ────────────────────────────────────────────────────────────────

function settings() {
  const raw = cfg() || {};
  const hosts = String(raw.allowHosts ?? '').split(/[,，\s|]+/).map((s) => s.trim().toLowerCase()
    .replace(/^https?:\/\//, '').replace(/\/.*$/, '').replace(/^\.+|\.+$/g, '')).filter(Boolean).slice(0, 200);
  return {
    enabled: !(raw.enabled === false || raw.enabled === 'false'),
    bskPath: String(raw.bskPath ?? '').trim(),
    browserInstance: String(raw.browserInstance ?? '').trim(),
    allowHosts: hosts,
    denyFillPatterns: String(raw.denyFillPatterns ?? DEFAULTS.denyFillPatterns).split(/[,，\s]+/).map((s) => s.trim()).filter(Boolean),
    allowFillOnSensitive: raw.allowFillOnSensitive === true,
    maxCharsPerCall: Math.min(40000, Math.max(500, Number(raw.maxCharsPerCall) || DEFAULTS.maxCharsPerRun)),
    maxEvalPerRun: Math.min(50, Math.max(0, Number(raw.maxEvalPerRun ?? DEFAULTS.maxEvalPerRun) || 0)),
    maxScreenshotPerRun: Math.min(20, Math.max(0, Number(raw.maxScreenshotPerRun ?? DEFAULTS.maxScreenshotPerRun) || 0)),
    screenshotToChat: raw.screenshotToChat !== false,
    idleCloseMinutes: Math.min(240, Math.max(1, Number(raw.idleCloseMinutes) || DEFAULTS.idleCloseMinutes))
  };
}

/** bsk.exe 在哪：设置 → PATH → 常见安装位。找到第一个存在的。 */
function resolveBsk() {
  const c = settings();
  if (c.bskPath && fs.existsSync(c.bskPath)) return c.bskPath;
  const names = process.platform === 'win32' ? ['bsk.exe'] : ['bsk'];
  const dirs = String(process.env.PATH || '').split(path.delimiter).filter(Boolean);
  dirs.push(path.join(os.homedir(), '.local', 'bin'));
  for (const d of dirs) {
    for (const n of names) {
      const p = path.join(d, n);
      try { if (fs.existsSync(p)) return p; } catch { /* 无权限就跳过 */ }
    }
  }
  return '';
}

// ── 会话管理 ─────────────────────────────────────────────────────────────

let reaper = null;
function startReaper() {
  if (reaper) return;
  reaper = setInterval(() => {
    const c = settings();
    const now = Date.now();
    for (const [key, s] of sessions) {
      if (now - s.lastUsedAt < c.idleCloseMinutes * 60000) continue;
      runBsk(s.exe, ['session', 'stop', s.sessionId, '--json'], {}, { timeoutMs: 15000 }).catch(() => {});
      sessions.delete(key);
      log(`会话 ${s.sessionId}（${key}）空闲超时，已关闭`);
    }
  }, 60000);
  if (typeof reaper.unref === 'function') reaper.unref();
}
function stopReaper() {
  if (reaper) { clearInterval(reaper); reaper = null; }
}

/**
 * 拿到（或建立）本会话对应的浏览器会话。
 * 复用前先 ping：会话可能"记录还在但浏览器已经断开"，直接复用会让每个命令都报错。
 */
async function ensureSession(ctx) {
  const c = settings();
  if (!c.enabled) return { error: '浏览器控制在设置里被关掉了。' };
  const bsk = resolveBsk();
  if (!bsk) {
    return {
      error: '没找到 bsk.exe。请确认 BrowserSkill 已经装好（`bsk` 能在终端里跑），'
        + '或在「技能 → 浏览器控制」里把 bsk.exe 的完整路径填上。'
    };
  }
  const chatKey = String(ctx?.chatKey || 'default');
  const now = Date.now();

  let s = sessions.get(chatKey);
  if (s) {
    const alive = await runBsk(bsk, ['tab', 'list', '--session', s.sessionId, '--scope', 'agent', '--json'], ctx, { timeoutMs: 15000 });
    if (!alive.ok && /session|unknown|not found|expired/i.test(String(alive.stderr || alive.stdout || alive.error || ''))) {
      sessions.delete(chatKey);
      s = null;
    } else {
      s.lastUsedAt = now;
      s.bsk = bsk;
      return s;
    }
  }

  const browser = await pickBrowser(bsk, c, ctx);
  if (browser.error) return browser;

  const started = await runBsk(bsk, ['session', 'start', '--browser', browser.id, '--json',
    '--name', `QQAgent ${String(chatKey).slice(0, 20)}`], ctx, { timeoutMs: 60000 });
  if (!started.ok) return { error: friendlyBskError(started, '打开浏览器会话失败') };
  const p = safeJson(started.stdout);
  if (!p?.session_id) return { error: `bsk 没有返回 session_id：${String(started.stdout || started.stderr).slice(0, 300)}` };
  // ⚠️ exe 和浏览器实例 id 是两个完全不同的东西，字段名必须分开：
  //    早先把两者塞进同一个 `browser` 字段，结果每个命令都变成 `spawn 71e1302f ENOENT`。
  s = {
    exe: bsk,
    browserId: String(p.browser_instance_id || browser.id),
    sessionId: p.session_id,
    startedAt: now,
    lastUsedAt: now
  };
  sessions.set(chatKey, s);
  log(`新建浏览器会话 ${s.sessionId}（浏览器 ${s.browserId}）`);
  return s;
}

/** 选定浏览器实例：设置优先，否则要求只有一个已连接的浏览器（不猜）。 */
async function pickBrowser(bsk, c, ctx) {
  const r = await runBsk(bsk, ['browsers', '--json'], ctx, { timeoutMs: 20000 });
  if (!r.ok) return { error: friendlyBskError(r, '查询浏览器列表失败') };
  const list = safeJson(r.stdout) || [];
  if (!Array.isArray(list) || !list.length) {
    return {
      error: '没有检测到已连接的浏览器。需要两件事同时成立：① bsk 守护进程在跑；'
        + '② 你的 Chrome 里装了 BrowserSkill 扩展且是启用状态。装好后重试。'
    };
  }
  if (c.browserInstance) {
    const hit = list.find((b) => String(b.instance_id) === c.browserInstance);
    if (!hit) return { error: `设置里指定的浏览器实例 ${c.browserInstance} 不在线（当前在线：${list.map((b) => b.instance_id).join(', ')}）` };
    return { id: String(hit.instance_id) };
  }
  if (list.length > 1) {
    return {
      error: `当前有 ${list.length} 个浏览器在线（${list.map((b) => `${b.instance_id}=${b.label || b.browser_name}`).join('，')}）。`
        + '请在「技能 → 浏览器控制 → 指定浏览器实例」里填一个 id，避免操作错浏览器。'
    };
  }
  return { id: String(list[0].instance_id) };
}

// ── 调 bsk ───────────────────────────────────────────────────────────────

/**
 * 执行一次 bsk 命令。
 *
 * 为什么不用 shell：Windows 上走 cmd/PowerShell 会把 `@e1` 当特殊符号、把中文 URL 编码坏、
 * 还会被 cmd 引号规则坑到。execFile 直接调 exe，参数原样传，不经过 shell 解析。
 *
 * @param {string} bsk exe 路径
 * @param {string[]} args 参数数组（每个独立元素，不要自己拼引号）
 * @param {object} ctx 运行上下文（只用它的 chatKey 做日志）
 * @param {{timeoutMs?:number}} [opts]
 * @returns {Promise<{ok:boolean, code:number, stdout:string, stderr:string, error?:string, timedOut?:boolean}>}
 */
function runBsk(bsk, args, ctx = {}, opts = {}) {
  // 命令超时给 bsk 自己的 --timeout 留出余量：先让 bsk 自己超时并返回结构化 JSON，
  // 我们这边抢先生会把原因一起杀掉。
  const timeout = Math.max(5000, Number(opts.timeoutMs) || 90000);
  return new Promise((resolve) => {
    let settled = false;
    const done = (v) => { if (!settled) { settled = true; resolve(v); } };
    try {
      const child = execFile(bsk, args, {
        timeout,
        windowsHide: true,
        maxBuffer: 16 * 1024 * 1024,
        // ⚠️ 这里**不要**写死 BSK_AUTO_START=0。
        //   早先为了绕开本开发机（Windows 沙箱 Job Object）的限制把它关了，代价是：
        //   任何机器上都不会自动拉起守护进程，用户必须自己手动起 —— 移植到别人电脑
        //   就成了"装完还是用不了"。正确做法是让 bsk 按默认行为去试（普通机器上
        //   `bsk daemon start` 是能后台起起来的），真起不来时由 friendlyBskError
        //   把 os error 5 翻译成人能照做的三步提示。
        //   只有设置里显式要求"我不自动起"时才传 0。
        env: { ...process.env, NO_COLOR: '1', ...(opts.autoStart === false ? { BSK_AUTO_START: '0' } : {}) },
        encoding: 'utf8'
      }, (error, stdout, stderr) => {
        const code = typeof error?.code === 'number' ? error.code : (error ? 1 : 0);
        if (error && error.killed) {
          return done({ ok: false, timedOut: true, code, stdout: String(stdout || ''), stderr: String(stderr || ''), error: `命令超过 ${Math.round(timeout / 1000)} 秒没返回，已中止` });
        }
        // bsk 用 exit 2 表示"可读的失败"（JSON 里有 message/hint），那不是崩溃
        const ok = !error || code === 2 ? looksOk(stdout, stderr, code) : false;
        done({
          ok,
          code,
          stdout: String(stdout || ''),
          stderr: String(stderr || ''),
          error: error && code !== 2 ? String(error.message || error) : ''
        });
      });
      child.on('error', (error) => done({ ok: false, code: 1, stdout: '', stderr: '', error: String(error?.message ?? error) }));
    } catch (error) {
      done({ ok: false, code: 1, stdout: '', stderr: '', error: String(error?.message ?? error) });
    }
  });
}

function looksOk(stdout, stderr, code) {
  if (code !== 0 && code !== 2) return false;
  const text = String(stdout || '').trim();
  if (!text) return code === 0;
  // bsk 失败时也输出 JSON，但带 message + exit_code；成功时要么没有 exit_code，要么 ok:true
  if (text.startsWith('{') || text.startsWith('[')) {
    const p = safeJson(text);
    if (!p || typeof p !== 'object') return code === 0;
    if (p.exit_code !== undefined && p.exit_code !== 0) return false;
    if (typeof p.message === 'string' && p.code === null && p.exit_code !== undefined) return false;
    if (p.ok === false) return false;
    return true;
  }
  return code === 0 || !/error|failed/i.test(String(stderr || ''));
}

function safeJson(text) {
  const t = String(text || '').trim();
  if (!t) return null;
  try { return JSON.parse(t); } catch { /* 有的命令会先打一行人类可读的再打 JSON */ }
  const start = t.search(/^[[{]/m);
  if (start < 0) return null;
  try { return JSON.parse(t.slice(start)); } catch { return null; }
}

function friendlyBskError(r, prefix) {
  const msg = String(r?.error || '').trim();
  const payload = safeJson(r?.stderr) || safeJson(r?.stdout);
  const detail = payload?.message || payload?.error || msg || String(r?.stderr || r?.stdout || '').slice(0, 400);
  const hint = payload?.hint ? `\n提示：${payload.hint}` : '';
  if (/os error 5|Job Object|breakaway|daemon/i.test(String(detail))) {
    return `${prefix}：bsk 守护进程没在跑，而且在这个宿主里自动拉起被系统挡住了（os error 5）。\n`
      + '这是 Windows 作业对象（Job Object）的已知限制，不是配置写错了。解决顺序：\n'
      + '① 在**独立终端**里运行一次 `bsk daemon start`（或 `bsk daemon start --foreground` 后保持窗口不关）；\n'
      + '② 确认 `bsk status` 里 browsers 至少有一个在线；\n'
      + '③ 回到这里重试。详细原因：https://github.com/Tencent/BrowserSkill\n'
      + `原始报错：${String(detail).slice(0, 300)}${hint}`;
  }
  return `${prefix}：${String(detail).slice(0, 500)}${hint}`;
}

function errorText(r, payload) {
  if (payload?.message) return String(payload.message).slice(0, 400);
  if (payload?.error) return String(payload.error).slice(0, 400);
  return String(r?.error || r?.stderr || r?.stdout || '未知错误').slice(0, 400);
}

// ── 页面辅助 ─────────────────────────────────────────────────────────────

/**
 * ⚠️ 实测踩到的硬限制（重要，改之前先读）
 *
 * bsk 的 `evaluate` 在**单次返回值超过约 210 个字符**时，会把非拉丁文（阿拉伯文、
 * 波斯文这类 RTL，以及部分非 BMP 字符）统统替换成 `?` —— 中文和英文不受影响。
 * 也就是说：
 *   · 页面里 indexOf('???') === -1     → 页面本身是干净的
 *   · slice(0,205)  取回来正常
 *   · slice(0,210)  取回来 127 个问号
 * 这不是编码问题，也不是我们这边 UTF-8 解码的问题（同样的字节在 205 以内就完好）。
 * 结论：**大段正文必须切片取**，每片控制在 200 个字符以内，再在本地拼回去。
 *
 * 片长取 160 留余量（中文按字符算，一个中文字在 JSON 里仍是 1 个字符）。
 */
const TEXT_SLICE_CHARS = 160;

const TEXT_LEN_JS = `(() => {
  const pick = document.querySelector('article, main, [role=main]') || document.body;
  return String(pick && pick.innerText ? pick.innerText : '').length;
})()`;

function textSliceJs(start, ref) {
  // ref 只影响取哪棵子树；innerText 仍然靠分片输出（见 TEXT_SLICE_CHARS 的注释）
  const pickExpr = ref
    ? `document.querySelector('[data-bsk-ref="${ref}"]') || document.getElementById('${ref}') || (document.querySelector('article, main, [role=main]') || document.body)`
    : `(document.querySelector('article, main, [role=main]') || document.body)`;
  return `(() => {
    const pick = ${pickExpr};
    const all = String(pick && pick.innerText ? pick.innerText : '');
    return all.slice(${start}, ${start + TEXT_SLICE_CHARS});
  })()`;
}

function textLenJs(ref) {
  const pickExpr = ref
    ? `document.querySelector('[data-bsk-ref="${ref}"]') || document.getElementById('${ref}') || (document.querySelector('article, main, [role=main]') || document.body)`
    : `(document.querySelector('article, main, [role=main]') || document.body)`;
  return `(() => { const pick = ${pickExpr}; return String(pick && pick.innerText ? pick.innerText : '').length; })()`;
}

/**
 * 分片取正文（绕开 bsk 单次 210 字符的非拉丁文劫持）。
 * @returns {Promise<{ok:boolean, text?:string, error?:string, truncated?:boolean}>}
 */
async function readPageText(s, maxChars, ctx, ref = '') {
  const lenR = await runBsk(s.exe, ['evaluate', textLenJs(ref), '--session', s.sessionId, '--json', '--timeout', '30s'], ctx, { timeoutMs: 40000 });
  if (!lenR.ok) return { ok: false, error: friendlyBskError(lenR, '读正文失败') };
  const lenP = safeJson(lenR.stdout);
  if (!lenP?.ok) return { ok: false, error: `读正文失败：${errorText(lenR, lenP)}` };
  const total = Number(lenP.value) || 0;
  if (!total) return { ok: true, text: '', truncated: false };

  const want = Math.min(total, maxChars);
  const parts = [];
  for (let start = 0; start < want; start += TEXT_SLICE_CHARS) {
    const r = await runBsk(s.exe, ['evaluate', textSliceJs(start, ref), '--session', s.sessionId, '--json', '--timeout', '30s'], ctx, { timeoutMs: 40000 });
    if (!r.ok) return { ok: false, error: friendlyBskError(r, '读正文失败') };
    const p = safeJson(r.stdout);
    if (!p?.ok) return { ok: false, error: `读正文失败：${errorText(r, p)}` };
    parts.push(String(p.value ?? ''));
  }
  let text = parts.join('');
  if (text.length > maxChars) text = text.slice(0, maxChars);
  // ⚠️ 只压空格和多余空行。**不要**用 \s 或任何会匹配换行的字符类——
  // 早先在模板字符串里写这类正则，反斜杠被吃成真换行，正则直接语法错。
  text = text.replace(/[ \t]{2,}/g, ' ').replace(/\n{3,}/g, '\n\n').trim();
  // 兜底自检：整篇里出现成片的 ?，说明这个标签页已经被 observe/get-html 的
  // 大输出"污染"过（bsk 会把非拉丁文替换成问号，navigate / reload 才恢复）。
  // 这时候宁可告诉调用方"先刷新一下"，也别把一屏问号当正文喂给模型。
  const qRun = /(\?{6,})/.exec(text);
  if (qRun) {
    return {
      ok: false,
      polluted: true,
      error: '这个标签页刚做过结构化提取，正文里的非拉丁文字被浏览器侧替换成了问号。'
        + '请重新打开一次这个网址（browser-control__open）再读正文；或者在 open 之后立刻读正文。'
    };
  }
  return { ok: true, text, truncated: total > text.length };
}

/** 恢复是"最后手段"：它会重新加载页面（丢掉表单内容、滚动位置、懒加载的东西），
 *  所以只在正文确实被污染时才用，并且要求刷新后仍在同一站点。 */
async function readPageTextWithRecovery(s, maxChars, ctx, ref = '') {
  const urlBefore = await pageUrl(s, ctx);
  let got = await readPageText(s, maxChars, ctx, ref);
  if (got.ok || !got.polluted) return got;
  const ok = await refreshTab(s, ctx, urlBefore);
  if (!ok) return got;   // 连刷新都没起来，把原来的污染提示给出去
  const urlAfter = await pageUrl(s, ctx);
  // 刷新后跳到了别处（断网、登录墙、错误页）：别再拿它的正文冒充原页面。
  // pageUrl 返回的是 "href | title"，先按 " | " 切出 href 再解析。
  const hostOf = (v) => {
    const href = String(v).split(' | ')[0].trim();
    try { return new URL(href).host; } catch { return ''; }
  };
  const before = hostOf(urlBefore);
  const after = hostOf(urlAfter);
  if (!before || !after || before !== after) {
    return {
      ok: false,
      error: `为了绕开浏览器侧的字符替换重新加载了一次页面，结果跳到了别的地方（${String(urlAfter).slice(0, 120) || '取不到地址'}）。`
        + '当前正文不可信，请重新打开目标网址再读。'
    };
  }
  got = await readPageText(s, maxChars, ctx, ref);
  return got;
}

async function observeText(s, c, ctx) {
  const r = await runBsk(s.exe, ['observe', '--session', s.sessionId, '--json',
    '--max-tokens', String(Math.min(8000, Math.max(500, Math.round(c.maxCharsPerCall / 4))))], ctx, { timeoutMs: 60000 });
  if (!r.ok) return friendlyBskError(r, '读页面结构失败');
  const p = safeJson(r.stdout);
  let text = String(p?.text || '').trim();
  if (!text) return '页面结构是空的（可能是空白页、还在加载，或内容全在 iframe 里）。可以试试 browser-control__devtools 看有没有报错。';
  if (text.length > c.maxCharsPerCall) text = `${text.slice(0, c.maxCharsPerCall)}\n…（已截断）`;
  const head = p?.truncated ? '（页面较长，下面是截断后的结构）\n' : '';
  return `${head}${text}`;
}

async function pageUrl(s, ctx) {
  const r = await runBsk(s.exe, ['evaluate', 'location.href + " | " + document.title', '--session', s.sessionId, '--json'], ctx, { timeoutMs: 20000 });
  const p = safeJson(r.stdout);
  return String(p?.value || '').trim();
}

async function pageInfo(s, ctx) {
  const v = await pageUrl(s, ctx);
  return v ? `当前页面：${v}` : '（取不到当前地址）';
}

/**
 * 把这个标签页"洗干净"。
 *
 * 背景：bsk 在一次 observe / get-html 之后，**同一标签页**上的后续 evaluate 会把
 * 非拉丁文（阿拉伯文、波斯文…）返回成 `?`。实测：
 *   · `reload`        —— 不管用，等多久都是问号
 *   · `navigate 同址`  —— 管用，立刻恢复干净
 * 所以这里必须用 navigate 而不是 reload。
 *
 * ⚠️ 刷完必须**等正文真的有内容**再走：只等 `body` attach 不够，那一刻 innerText
 * 还是空，读出来会误判成"这一页没读到正文"。
 */
async function refreshTab(s, ctx, url) {
  const target = String(url || '').split(' | ')[0].trim();
  if (!target) return false;
  await runBsk(s.exe, ['navigate', target, '--session', s.sessionId, '--quiet'], ctx, { timeoutMs: 60000 }).catch(() => null);
  await runBsk(s.exe, ['wait-for-element', 'body', '--state', 'attached', '--timeout', '15s',
    '--session', s.sessionId, '--json'], ctx, { timeoutMs: 30000 }).catch(() => null);
  // 轮询到 innerText 非空为止，最多等 8 秒（页面在重写、首屏慢都能覆盖）
  for (let i = 0; i < 16; i += 1) {
    const r = await runBsk(s.exe, ['evaluate', textLenJs(''), '--session', s.sessionId, '--json'], ctx, { timeoutMs: 15000 }).catch(() => null);
    const len = Number(safeJson(r?.stdout)?.value) || 0;
    if (len > 0) return true;
    await new Promise((ok) => setTimeout(ok, 500));
  }
  return false;
}

function sensitiveHit(urlTitle, patterns) {
  const hay = String(urlTitle || '').toLowerCase();
  if (!hay) return '';
  return patterns.find((p) => p && hay.includes(String(p).toLowerCase())) || '';
}

// ── 安全边界 ─────────────────────────────────────────────────────────────

function checkHost(url) {
  const c = settings();
  if (!c.allowHosts.length) return { ok: true };
  let host = '';
  try { host = new URL(url).hostname.toLowerCase(); } catch { return { ok: false, reason: `网址解析失败：${url}` } };
  const hit = c.allowHosts.some((d) => host === d || host.endsWith(`.${d}`));
  if (hit) return { ok: true };
  return {
    ok: false,
    reason: `域名 ${host} 不在白名单里（当前允许：${c.allowHosts.join(', ')}）。`
      + '需要放开的话，在「技能 → 浏览器控制 → 允许访问的域名」里加上它。'
  };
}

function normalizeUrl(raw) {
  const s = String(raw || '').trim();
  if (!s) return '';
  if (/^(javascript|data|file|about|chrome|edge):/i.test(s)) return '';   // 只走后门的东西一律拒绝
  if (/^https?:\/\//i.test(s)) return s;
  if (/^[\w-]+(\.[\w-]+)+([/?#]|$)/.test(s)) return `https://${s}`;
  if (s.includes(' ') || !s.includes('.')) {
    return `https://www.bing.com/search?q=${encodeURIComponent(s)}`;
  }
  return `https://${s}`;
}

function cleanRef(v) {
  const s = String(v ?? '').trim().replace(/^@/, '');
  return /^e\d+$/i.test(s) ? s : '';
}

function fail(message) {
  return { content: `错误：${message}`, isError: true };
}

export const internals = {
  settings, resolveBsk, normalizeUrl, checkHost, sensitiveHit, cleanRef, safeJson, runBsk,
  sessionCount: () => sessions.size, BUILD_TAG, WORK_ROOT
};
