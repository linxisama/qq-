# 浏览器控制（browser-control）

让 QQ 机器人能操作你电脑上的 Chrome。底层是桌面上那套 **bsk / BrowserSkill**，本技能只是它的薄壳客户端。

## 它能让机器人做什么

| 工具 | 干什么 |
| --- | --- |
| `browser-control__open` | 打开网址，返回页面结构 |
| `browser-control__observe` | 看当前页面的可交互结构（元素带 `@eN` 编号） |
| `browser-control__text` | 读页面正文（可只读某个 `@eN` 区域） |
| `browser-control__click` | 点元素（`@eN` 或 CSS 选择器） |
| `browser-control__fill` | 往输入框填字 |
| `browser-control__press` | 按键（Enter / Escape / Ctrl+A…） |
| `browser-control__screenshot` | 截图，默认直接发到聊天 |
| `browser-control__info` | 当前地址 + 标题 |
| `browser-control__tabs` | 标签页列出/新建/切换/关闭/借用/归还 |
| `browser-control__eval_js` | 在页面里执行 JS |
| `browser-control__devtools` | 读 console 日志 / 网络请求 |

## 为什么是技能（skills/）而不是插件（plugins/）

插件是"条件成立就一定跑"的确定性逻辑，钩子只看得到消息和上下文，够不到浏览器。
而"该点哪个按钮、该填什么"没有任何规则能预先写死——只能由模型看着页面决定。
所以这里必须用 `registerTool`，让它进模型的工具列表，由模型按需调用。

判断依据就是项目文档里的三问：**需要模型判断吗？** 需要 → 技能。这个技能是典型的"需要"。

## 依赖（两件事必须同时成立）

1. **bsk 守护进程在跑**
   - 已给当前用户建了开机自启：`%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup\bsk-daemon.lnk`
     （内容是 `bsk.exe daemon start --foreground`，最小化启动，不弹窗）
   - 手起一次：`bsk daemon start`（或 `bsk daemon start --foreground` 并保持窗口不关）
   - 检查：`bsk status` → `browsers` 里至少有一个在线
2. **Chrome 里装了 BrowserSkill 扩展且启用**（扩展会自动连上守护进程）

⚠️ 已知坑：在某些受限宿主里，客户端命令"顺手拉起守护进程"会被系统拒掉，报
`os error 5 ... Job Object breakaway`。这不是配置写错，是 Windows 作业对象限制。
解法就是上面那样**在独立终端/登录启动项里把守护进程跑起来**，之后所有客户端命令都能用。
本技能的 `runBsk` 一律带 `BSK_AUTO_START=0`，避免每个命令都白失败一次。

## 搬到别人的电脑上（移植清单）

**不用改代码，不用配端口。** 端口是 bsk 自己挑的，扩展自己会找到它，本技能全程不碰端口。

### 一次性准备（对方要装 bsk，这不是本技能的一部分）

bsk 是独立的桌面软件（Rust 守护进程 + Chrome 扩展），本技能只是它的调用方。
对方机器上需要：

1. 装 bsk CLI，并让它落在 `~/.local/bin/bsk.exe`（默认安装位，本技能会自动找）
2. Chrome 装 BrowserSkill 扩展并启用
3. 验证：`bsk status` 里 `browsers` 至少有一个在线

### 拷什么

只拷这一个目录：

```
resources\app\skills\browser-control\      ← 整个目录，三个文件
```

放进对方 QQ Agent 的同名位置：`<对方的 QQ Agent 安装目录>\resources\app\skills\browser-control\`。

拷完**不用重启**（`extensions.hotReload` 默认开），几秒内「技能」页就会多出「浏览器控制」。

### 可选的系统配置（不配也能用，只是要手动起守护进程）

开机自启快捷方式（Windows）：

- 快捷方式放到 `%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup\bsk-daemon.lnk`
- 目标：`<对方机器>\...\bsk.exe daemon start --foreground`
- 窗口样式选「最小化」

### 对方可能需要在设置里改的东西

| 设置项 | 默认值 | 什么时候要改 |
| --- | --- | --- |
| `bskPath` | 空（自动找 PATH 和 `~/.local/bin`） | bsk 装在别的位置时填完整路径 |
| `browserInstance` | 空（自动选唯一在线的浏览器） | **同时开着多个 Chrome** 时必须填，否则会报错要求指定 |
| `allowHosts` | 空（不限制） | 想让机器人只碰指定站点时填，如 `bilibili.com, zhihu.com` |
| `allowFillOnSensitive` | 关 | 确实要它在登录页代填时才开 |

`browserInstance` 的取值用 `bsk browsers --json` 看 `instance_id`。

### 移植时要检查的只有一个地方

`skill.json` 的 `settings` 里 `browserInstance` **必须是空字符串**。
如果打包时把它填成了某台机器的实例 id，别人装上会直接报「指定的浏览器实例不在线」。
本仓库当前已置空。

### 不需要做的

- ❌ 不用在浏览器扩展里查端口
- ❌ 不用在 QQ Agent 设置里填端口
- ❌ 不用改 `daemon.json`（那是 bsk 自己的状态文件，自动维护）

端口（默认 52800）只存在于 bsk 守护进程和扩展之间，本技能走的是 CLI + 命名管道，
压根不直连 WebSocket —— 所以换机器时这条链路会自动重新协商。

## 安全边界（写在代码里）

- **域名白名单**：`allowHosts` 非空时，`open` / 新建标签页只允许这些域名及其子域。留空 = 不限制。
- **敏感页禁填**：页面地址/标题命中 `denyFillPatterns`（登录、支付、后台、邮箱、网银…）时，
  `fill` 直接拒绝。要放开得显式打开「允许在敏感页填写」。
- **只在自己窗口里动**：默认 `scope=agent`，不碰你自己开着的标签页；借用要显式 `borrow`，用完 `return`。
- **限次**：每轮最多 `maxEvalPerRun` 次页面脚本、`maxScreenshotPerRun` 张截图。
  页面脚本能读到 cookie / localStorage，限次是防它被诱导去翻隐私。
- **提示词层**：`skill.json` 的 `prompt.sections` 里写明了硬规矩（不点有真实后果的按钮、
  不念 cookie/token、截图发出去前确认没有别人的隐私）。

## 会话怎么管

所有页面级命令都要 `--session <id>`。本技能自己管：

- 按 `chatKey` 缓存一个会话，复用前先 ping（`tab list`），断了就重建；
- 空闲超过 `idleCloseMinutes`（默认 30 分钟）自动关掉，桌面不会堆窗口；
- `dispose()` 时把所有会话关掉。

模型完全不用碰 session id——那是内部 id，让它记只会记错。

## 实现上的几个坑（改代码前先读）

1. **`s.exe` 和 `s.browserId` 是两个字段**。早先把 exe 路径和浏览器实例 id 塞进同一个字段，
   结果每个命令都变成 `spawn 71e1302f ENOENT`。
2. **不要走 shell**。Windows 上 `@e1` 会被当特殊符号、中文 URL 会被编坏、引号规则能把参数吃掉。
   全程 `execFile` 直调 exe，每个参数独立成数组元素。
3. **页面脚本里的反斜杠要当心**。模板字符串会先吃一层转义，写 `/\\n{3,}/` 到浏览器里就是
   正则语法错，`evaluate` 整个报错——表现却像"正文读不出来"。所以 `TEXT_JS` 只用
   `[ ]{2,}` 这种不需要转义的写法。
4. **命令超时要留余量**。bsk 自己超时会返回结构化 JSON，我们这边抢先生会把原因一起杀掉。
   所以 `runBsk` 的 timeout 比传入的 `--timeout` 更长。
5. **输出必须截断**。`observe` 在长页面上能吐几万字，塞进上下文就是烧钱。统一受 `maxCharsPerCall` 约束。
6. **`execute(ctx, args)` 签名要统一**。`api` 只暴露 `registerTool / config / log / warn /
   capability / hasCapability / utils / fetch / isSkillActive / error`，**没有** `err()` 之类的
   工具级辅助函数——早先误用了一个只在测试桩里存在的 `err()`，测试全绿、上真环境就会崩。

## 排障

| 现象 | 原因 / 处理 |
| --- | --- |
| 工具报"没找到 bsk.exe" | 填设置里的「bsk.exe 路径」，或确认 `~/.local/bin/bsk.exe` 存在 |
| 报 `os error 5 / Job Object` | 守护进程没在跑，见上面「依赖」第 1 条 |
| 报"没有检测到已连接的浏览器" | Chrome 里 BrowserSkill 扩展没启用，或守护进程刚重启还没连上 |
| 报"有 N 个浏览器在线，请指定实例" | 在设置里填 `browserInstance`（`bsk browsers --json` 看 id） |
| 填表被拒绝，提示"敏感页" | 这是设计如此。真要填，打开「允许在敏感页填写」 |
| 截图没发到群里 | `screenshotToChat` 被关了，或本次运行截图数到上限 |

## 自测

如果想不经过 QQ 直接验证这套东西能不能用，进到 QQ Agent 的 `resources\app` 目录后跑：

```powershell
# 先 cd 到你自己的 QQ Agent 安装目录下的 resources\app
$env:BSK_AUTO_START="0"
.\snowluma\node.exe .\data\_browser-smoke.mjs
```

`_browser-smoke.mjs` 是开发时的临时脚本，**不在技能目录里**，随包分发时没有它，
所以这一步只在原开发机上有效。移植到别人机器后，直接用 `bsk doctor` 验证依赖，
再在 QQ 里说「打开 example.com 看看」做端到端确认即可。

跑完会打印每一步的输出并自动关会话。除 `data/browser-control/shot-*.png` 外不留文件。
