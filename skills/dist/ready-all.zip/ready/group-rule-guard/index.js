// 群规执法（Skill / LLM 型）—— 群主定规矩，机器人看见违规消息自动撤回/禁言。
//
// 为什么是 Skill 而不是插件（plugins/）：
//   插件的"确定性"路线只能挂到核心预留的几个能力点上（reply.local-policy、
//   media.download、chat.ban-state …），全部发生在"已经决定要回某句话"之后；
//   没有"每条新消息进来先看一眼"这种挂载点，插件也拿不到模型的语义判断。
//   而"这条消息是不是在发广告/是不是那张图"只能由模型理解内容后回答，所以只能
//   做成 registerTool 的技能：模型识别规矩 → 存规矩；模型看见违规 → 调执法工具。
//
// 安全设计（因为"做错代价高"）：
//   · 执法必须绑定一条已经存在的、群主/管理员立下的规则（ruleId），模型不能凭空处罚；
//   · 群主、管理员、机器人自己永不被处理（protectStaff，默认开）；
//   · 单次禁言时长有上限（maxMuteMinutes，默认 1 天）；
//   · 支持演练模式（dryRun）与全部操作的审计日志；
//   · 同一 (规则, 消息) 10 分钟内只执行一次，避免模型重复调用叠加处罚。
//
// 为什么全部写在一个文件里：宿主热重载只对入口 index.js 做 cache-bust，
// 相对 import 的子模块会被模块缓存（改了不生效、也不报错）。

import fs from 'node:fs/promises';
import path from 'node:path';
import os from 'node:os';

const SKILL_ID = 'group-rule-guard';
const MAX_IMAGES_PER_RULE = 2;      // 每条规则最多存几张范例图
const MAX_REF_BYTES = 3 * 1024 * 1024; // 单张范例图上限，超过就不缓存
const DEDUPE_TTL = 10 * 60 * 1000;  // 同一(规则,消息)去重窗口
const IMG_TOTAL_LIMIT = 4;          // 一次 rule_list 最多回几张范例图（省 token）

let cfg = () => ({});
let log = () => {};
let warn = () => {};

// key: `${groupId}|${ruleId}|${messageId}` -> 时间戳
const done = new Map();

export function setup(api) {
  if (api && typeof api.config === 'function') cfg = api.config;
  if (api && typeof api.log === 'function') log = api.log;
  if (api && typeof api.warn === 'function') warn = api.warn;

  api.registerTool(ruleAddTool);
  api.registerTool(ruleListTool);
  api.registerTool(ruleRemoveTool);
  api.registerTool(ruleEnforceTool);
}

// ── 配置 ──────────────────────────────────────────────────────────────────

function settings() {
  const raw = cfg() || {};
  const num = (key, def, lo, hi) => {
    const n = Number(raw[key]);
    if (!Number.isFinite(n)) return def;
    return Math.min(hi, Math.max(lo, Math.round(n)));
  };
  return {
    defaultMuteMinutes: num('defaultMuteMinutes', 10, 1, 43200),
    maxMuteMinutes: num('maxMuteMinutes', 1440, 1, 43200),
    maxRules: num('maxRules', 20, 1, 100),
    protectStaff: raw.protectStaff !== false,
    notify: raw.notify !== false,
    dryRun: raw.dryRun === true
  };
}

// ── 数据目录与规则存储 ────────────────────────────────────────────────────

function dataDir() {
  const env = process.env || {};
  if (env.QQ_AGENT_DATA_DIR) {
    return path.join(path.resolve(env.QQ_AGENT_DATA_DIR), 'plugin-data', SKILL_ID);
  }
  const profile = String(env.QQ_AGENT_PROFILE || '1').replace(/[^a-zA-Z0-9_-]/g, '_');
  return path.join(os.homedir(), '.qq-agent', 'plugin-data-' + profile, SKILL_ID);
}

function rulesFile() {
  return path.join(dataDir(), 'rules.json');
}

async function loadStore() {
  try {
    const text = await fs.readFile(rulesFile(), 'utf8');
    const json = JSON.parse(text);
    if (json && typeof json === 'object' && json.groups && typeof json.groups === 'object') {
      return { groups: json.groups };
    }
  } catch (error) {
    if (error && error.code !== 'ENOENT') warn('读取群规失败：' + String(error.message || error));
  }
  return { groups: {} };
}

async function saveStore(store) {
  await fs.mkdir(dataDir(), { recursive: true });
  const tmp = rulesFile() + '.tmp';
  await fs.writeFile(tmp, JSON.stringify(store, null, 2), 'utf8');
  await fs.rename(tmp, rulesFile());
}

function groupRules(store, gid) {
  const key = String(gid);
  const list = store.groups[key];
  return Array.isArray(list) ? list : [];
}

function nextRuleId(list) {
  let n = 1;
  const used = new Set(list.map((r) => String(r.id)));
  while (used.has('r' + n)) n += 1;
  return 'r' + n;
}

async function appendAudit(line) {
  try {
    await fs.mkdir(dataDir(), { recursive: true });
    const stamp = new Date().toISOString();
    await fs.appendFile(path.join(dataDir(), 'audit.log'), `${stamp} ${line}\n`, 'utf8');
  } catch (error) {
    warn('写执法日志失败：' + String(error && error.message ? error.message : error));
  }
}

// ── 小工具 ────────────────────────────────────────────────────────────────

function ok(payload) {
  return { content: typeof payload === 'string' ? payload : JSON.stringify(payload) };
}

function fail(message) {
  return { content: '错误：' + message, isError: true };
}

function isGroup(ctx) {
  return String(ctx && ctx.chatKey ? ctx.chatKey : '').startsWith('group:');
}

function groupIdOf(ctx) {
  return String(ctx.chatKey).slice('group:'.length);
}

async function sendText(ctx, text) {
  try {
    await ctx.sender.sendTextBatch(ctx.chatKey, [text], {});
    pushSent(ctx, 'text', text);
    return true;
  } catch (error) {
    warn('发送群消息失败：' + String(error && error.message ? error.message : error));
    return false;
  }
}

function pushSent(ctx, type, text) {
  try {
    if (ctx && ctx.session && Array.isArray(ctx.session.sent)) {
      ctx.session.sent.push({ type, text, at: new Date().toLocaleTimeString('zh-CN', { hour12: false }) });
      if (typeof ctx.emit === 'function') ctx.emit('session-update', ctx.session.id);
    }
  } catch (error) { /* 记录失败不影响主流程 */ }
}

// 查群身份：owner / admin / member；查不到返回 ''（调用方按"不敢动"处理）
async function memberRole(onebot, gid, uid, noCache = true) {
  const info = await onebot.call('get_group_member_info', {
    group_id: Number(gid),
    user_id: Number(uid),
    no_cache: noCache === true
  }, 8000);
  return String((info && info.role) || 'member');
}

async function verifyRequester(ctx, requesterId) {
  const gid = groupIdOf(ctx);
  const id = String(requesterId || '').trim();
  if (!/^\d+$/.test(id)) {
    return { ok: false, reason: '没拿到下令人的 QQ 号。请从那条消息的「昵称(QQ:xxxxx)」里取，填进 requesterId。' };
  }
  let role = '';
  try {
    role = await memberRole(ctx.onebot, gid, id, true);
  } catch (error) {
    return { ok: false, reason: '查你的群身份失败（' + String(error && error.message ? error.message : error) + '），为了安全这次不执行。可稍后重试。' };
  }
  if (role !== 'owner' && role !== 'admin') {
    return { ok: false, reason: `只有群主/管理员能定群规、改群规（你是 ${role || '普通成员'}）。` };
  }
  return { ok: true, role };
}

function shortDesc(rule) {
  const d = String(rule && rule.description ? rule.description : '未描述');
  return d.length > 40 ? d.slice(0, 40) + '…' : d;
}

function actionText(action) {
  if (action === 'recall') return '撤回';
  if (action === 'ban') return '禁言';
  return '撤回并禁言';
}

// 把一条消息的图片缓存成本地文件，供以后 rule_list 给模型"看图对规则"
async function cacheSampleImages(entry, ruleId) {
  const media = Array.isArray(entry && entry.media) ? entry.media : [];
  const urls = media.filter((m) => m && m.kind === 'image' && m.url).map((m) => String(m.url)).slice(0, MAX_IMAGES_PER_RULE);
  const saved = [];
  if (!urls.length) return saved;
  const dir = path.join(dataDir(), 'refs');
  try {
    await fs.mkdir(dir, { recursive: true });
  } catch (error) {
    warn('创建范例图目录失败：' + String(error && error.message ? error.message : error));
    return saved;
  }
  for (let i = 0; i < urls.length; i += 1) {
    const ac = new AbortController();
    const timer = setTimeout(() => ac.abort(), 15000);
    try {
      const res = await fetch(urls[i], { signal: ac.signal, headers: { 'user-agent': 'QQAgent-group-rule-guard/1.0' } });
      if (!res.ok) continue;
      const buf = Buffer.from(await res.arrayBuffer());
      if (!buf.length || buf.length > MAX_REF_BYTES) continue;
      const ext = imageExt(res.headers.get('content-type'), urls[i]);
      const file = path.join(dir, `${ruleId}-${i + 1}.${ext}`);
      await fs.writeFile(file, buf);
      saved.push({ file, ext, bytes: buf.length });
    } catch (error) {
      warn('缓存范例图失败：' + String(error && error.message ? error.message : error));
    } finally {
      clearTimeout(timer);
    }
  }
  return saved;
}

function imageExt(contentType, url) {
  const ct = String(contentType || '').toLowerCase();
  if (ct.includes('png')) return 'png';
  if (ct.includes('webp')) return 'webp';
  if (ct.includes('gif')) return 'gif';
  if (ct.includes('jpeg') || ct.includes('jpg')) return 'jpg';
  const m = /\.(png|jpe?g|webp|gif)(?:\?|$)/i.exec(String(url || ''));
  return m ? m[1].toLowerCase().replace('jpeg', 'jpg') : 'jpg';
}

function mimeOf(ext) {
  if (ext === 'png') return 'image/png';
  if (ext === 'webp') return 'image/webp';
  if (ext === 'gif') return 'image/gif';
  return 'image/jpeg';
}

// ── 工具 1：立规矩 ────────────────────────────────────────────────────────

const ruleAddTool = {
  id: 'rule_add',
  name: '记录群规',
  description:
    '把群主/管理员口述的群规记下来（例如「以后谁发广告就撤回并禁言 10 分钟」「发这张图的人直接踢/禁言」）。'
    + '只有群主或管理员能调用。requesterId 必填，取下令那条消息前缀里的 QQ 号。'
    + 'action：recall=只撤回、ban=只禁言、both=撤回并禁言。如果规则针对某种特定图片，'
    + '把那条示范图片消息的 #消息号填进 sampleMessageId，机器人会把它存成范例图，以后用来比对。',
  category: 'message',
  icon: '📜',
  defaultEnabled: true,
  parameters: {
    type: 'object',
    properties: {
      requesterId: { type: ['string', 'integer'], description: '下令人的 QQ 号（那条消息前缀「昵称(QQ:xxxx)」里的数字）' },
      description: { type: 'string', description: '规则内容：什么内容算违规。写具体一点，例如「发任何加群/引流二维码图片」「发带「代刷」字样的广告」' },
      action: { type: 'string', enum: ['recall', 'ban', 'both'], description: '命中后怎么处理，默认 both（撤回并禁言）' },
      muteMinutes: { type: 'number', description: '禁言时长（分钟）。对方没说就不填，用默认值' },
      sampleMessageId: { type: ['string', 'integer'], description: '可选：作为范例的那条消息的 #消息号（规则针对某种图片时必须给）' }
    },
    required: ['requesterId', 'description']
  },
  async execute(ctx, args) {
    if (!isGroup(ctx)) return fail('只有群聊里才能立群规。');
    const s = settings();
    const check = await verifyRequester(ctx, args && args.requesterId);
    if (!check.ok) return fail(check.reason);

    const description = String((args && args.description) || '').trim();
    if (description.length < 2) return fail('规则内容太短，请写清「什么算违规」。');
    let action = String((args && args.action) || 'both').toLowerCase();
    if (!['recall', 'ban', 'both'].includes(action)) action = 'both';

    const gid = groupIdOf(ctx);
    const store = await loadStore();
    const list = groupRules(store, gid);
    if (list.length >= s.maxRules) {
      return fail(`这个群已经有 ${list.length} 条群规了（上限 ${s.maxRules} 条）。先删掉不用的（rule_remove）再加。`);
    }

    let minutes = Number(args && args.muteMinutes);
    if (!Number.isFinite(minutes) || minutes <= 0) minutes = s.defaultMuteMinutes;
    minutes = Math.min(s.maxMuteMinutes, Math.max(1, Math.round(minutes)));

    const ruleId = nextRuleId(list);
    const rule = {
      id: ruleId,
      description,
      action,
      muteMinutes: minutes,
      enabled: true,
      createdAt: new Date().toISOString(),
      createdBy: String(args.requesterId),
      createdByRole: check.role,
      sampleMessageId: args && args.sampleMessageId != null ? String(args.sampleMessageId) : '',
      refs: [],
      hits: 0
    };

    // 示例图：规则针对图片时，把示范消息里的图下载下来长期保存
    if (rule.sampleMessageId) {
      const entry = findMessage(ctx, rule.sampleMessageId);
      if (entry) {
        rule.refs = await cacheSampleImages(entry, ruleId);
        rule.sampleText = String(entry.text || '').slice(0, 200);
        if (!rule.refs.length) {
          warn('范例消息里没有可缓存的图片，仅记录文字描述');
        }
      } else {
        warn(`找不到范例消息 ${rule.sampleMessageId}，只记录文字描述`);
      }
    }

    list.push(rule);
    store.groups[gid] = list;
    await saveStore(store);
    await appendAudit(`[add] group=${gid} rule=${ruleId} action=${action} minutes=${minutes} by=${rule.createdBy} desc=${description}`);

    const refNote = rule.refs.length
      ? `（已存下 ${rule.refs.length} 张范例图）`
      : (rule.sampleMessageId ? '（没能存下范例图，只按文字描述判断）' : '');

    if (s.notify) {
      await sendText(ctx, `📜 已记下第 ${ruleId} 条群规：${description} → ${actionText(action)}${action === 'recall' ? '' : ` ${minutes} 分钟`}${refNote}`);
    }

    return ok(
      `已记录群规 ${ruleId}：${description}｜处理方式=${actionText(action)}`
      + (action === 'recall' ? '' : `｜禁言 ${minutes} 分钟`)
      + `${refNote}。群主/管理员和机器人自己不会被处理。`
      + '回复里简短确认一句即可（第几条、管什么、怎么处理），不要复述这条说明。'
    );
  }
};

// ── 工具 2：看规矩 ────────────────────────────────────────────────────────

const ruleListTool = {
  id: 'rule_list',
  name: '查看本群群规',
  description: '列出当前群已经生效的群规（编号、内容、处理方式、禁言时长）。带图片范例的规则会把范例图一起返回，方便你比对刚看到的消息是否命中。',
  category: 'message',
  icon: '📋',
  defaultEnabled: true,
  parameters: { type: 'object', properties: {}, required: [] },
  async execute(ctx) {
    if (!isGroup(ctx)) return fail('群规只在群聊里生效。');
    const gid = groupIdOf(ctx);
    const store = await loadStore();
    const list = groupRules(store, gid).filter((r) => r && r.enabled !== false);
    if (!list.length) {
      return ok('当前群还没有群规。群主/管理员说「以后谁发 XX 就撤回/禁言」时，用 rule_add 记下来。');
    }
    const lines = list.map((r) => {
      const parts = [`${r.id}. ${r.description}`];
      parts.push(`→ ${actionText(r.action)}${r.action === 'recall' ? '' : ` ${r.muteMinutes || 10} 分钟`}`);
      if (r.sampleMessageId) parts.push(`[范例消息 #${r.sampleMessageId}]`);
      if (r.hits) parts.push(`（已处理 ${r.hits} 次）`);
      return parts.join(' ');
    });
    const text = `本群共 ${list.length} 条群规：\n${lines.join('\n')}`;

    // 附带范例图（最多 IMG_TOTAL_LIMIT 张），让模型能"看图对规则"
    const withRefs = list.filter((r) => Array.isArray(r.refs) && r.refs.length);
    if (!withRefs.length) return ok(text);
    const parts = [{ type: 'text', text }];
    let used = 0;
    for (const r of withRefs) {
      for (const ref of r.refs) {
        if (used >= IMG_TOTAL_LIMIT) break;
        try {
          const buf = await fs.readFile(ref.file);
          const ext = String(ref.ext || 'jpg');
          parts.push({ type: 'text', text: `规则 ${r.id} 的范例图：` });
          parts.push({ type: 'image_url', image_url: { url: `data:${mimeOf(ext)};base64,${buf.toString('base64')}` } });
          used += 1;
        } catch (error) {
          warn('读取范例图失败：' + String(error && error.message ? error.message : error));
        }
      }
      if (used >= IMG_TOTAL_LIMIT) break;
    }
    return { content: parts };
  }
};

// ── 工具 3：删规矩 ────────────────────────────────────────────────────────

const ruleRemoveTool = {
  id: 'rule_remove',
  name: '删除群规',
  description: '删除本群某一条群规（群主/管理员才能调用）。ruleId 是规则编号，如 r2。',
  category: 'message',
  icon: '🗑️',
  defaultEnabled: true,
  parameters: {
    type: 'object',
    properties: {
      requesterId: { type: ['string', 'integer'], description: '下令删规则的人 QQ 号' },
      ruleId: { type: 'string', description: '规则编号，如 r2' }
    },
    required: ['requesterId', 'ruleId']
  },
  async execute(ctx, args) {
    if (!isGroup(ctx)) return fail('只有群聊里有群规。');
    const check = await verifyRequester(ctx, args && args.requesterId);
    if (!check.ok) return fail(check.reason);
    const gid = groupIdOf(ctx);
    const want = String((args && args.ruleId) || '').trim().replace(/^#/, '');
    const store = await loadStore();
    const list = groupRules(store, gid);
    const idx = list.findIndex((r) => String(r && r.id) === want);
    if (idx < 0) {
      return fail(`没有编号 ${want} 的群规。现有：${list.map((r) => r.id).join('、') || '（空）'}`);
    }
    const [removed] = list.splice(idx, 1);
    store.groups[gid] = list;
    await saveStore(store);
    await appendAudit(`[remove] group=${gid} rule=${removed.id} by=${args.requesterId} desc=${removed.description}`);
    if (settings().notify) await sendText(ctx, `🗑️ 已删除群规 ${removed.id}（${shortDesc(removed)}）`);
    return ok(`已删除群规 ${removed.id}。简短确认一句即可。`);
  }
};

// ── 工具 4：执法 ──────────────────────────────────────────────────────────

const ruleEnforceTool = {
  id: 'rule_enforce',
  name: '按群规处理违规消息',
  description:
    '当你确认某条群消息违反了本群已有的某条规则时调用：撤回该消息、并/或禁言发送者。'
    + 'ruleId 必须是 rule_list 里真实存在的规则编号；messageId 用聊天记录里那条消息前的 #数字。'
    + '拿不准是否命中规则时不要调用。群主、管理员、机器人自己会被拒绝。'
    + '支持一次只处理一条消息；多条违规请分别调用。',
  category: 'message',
  icon: '⚖️',
  defaultEnabled: true,
  parameters: {
    type: 'object',
    properties: {
      ruleId: { type: 'string', description: '命中的规则编号，如 r2' },
      messageId: { type: ['string', 'integer'], description: '违规消息的 #消息号（聊天记录里 # 后的数字，可能为负数）' },
      reason: { type: 'string', description: '可选：一句话说明为什么算命中（写进日志）' }
    },
    required: ['ruleId', 'messageId']
  },
  async execute(ctx, args) {
    if (!isGroup(ctx)) return fail('群规执法只在群聊里生效。');
    const s = settings();
    const gid = groupIdOf(ctx);
    const ruleId = String((args && args.ruleId) || '').trim().replace(/^#/, '');
    const mid = String(args && args.messageId != null ? args.messageId : '').trim();

    if (!ruleId) return fail('缺少 ruleId。先用 rule_list 看本群规则编号。');
    if (!mid) return fail('缺少 messageId。用聊天记录里那条消息前面的 #数字。');

    const store = await loadStore();
    const rule = groupRules(store, gid).find((r) => String(r && r.id) === ruleId && r.enabled !== false);
    if (!rule) {
      return fail(`本群没有生效中的群规 ${ruleId}。不能用不存在的规则处理人；如果确实该立规矩，先让群主/管理员说清楚，再用 rule_add 记录。`);
    }

    // 去重：同一规则 + 同一消息，10 分钟内只执行一次
    const dedupeKey = `${gid}|${ruleId}|${mid}`;
    const last = done.get(dedupeKey);
    if (last && Date.now() - last < DEDUPE_TTL) {
      return ok(`这条消息已经按群规 ${ruleId} 处理过了，不要重复执行。回一句话说明即可。`);
    }

    const entry = findMessage(ctx, mid);
    if (!entry) {
      return fail(`当前会话里找不到消息 #${mid}。可能太久了；请用聊天记录里真实存在的 #消息号，找不到就不要动。`);
    }

    const targetId = String(entry.senderId || '');
    if (!targetId || targetId === 'self' || !/^\d+$/.test(targetId)) {
      return fail('拿不到这条消息发送者的 QQ 号（可能是机器人自己或系统消息），不处理。');
    }
    if (targetId === String(ctx.selfId || '')) return fail('这是机器人自己的消息，不处理。');

    // 群主/管理员/机器人自己：永不处理
    if (s.protectStaff) {
      let role = '';
      try {
        role = await memberRole(ctx.onebot, gid, targetId, true);
      } catch (error) {
        return fail('查对方群身份失败（' + String(error && error.message ? error.message : error) + '），为了安全这次不处理。');
      }
      if (role === 'owner') return fail('对方是群主，不能撤回/禁言。');
      if (role === 'admin') return fail('对方是管理员，不能撤回/禁言。');
    }

    const doRecall = rule.action === 'recall' || rule.action === 'both';
    const doBan = rule.action === 'ban' || rule.action === 'both';
    let minutes = Number(rule.muteMinutes);
    if (!Number.isFinite(minutes) || minutes <= 0) minutes = s.defaultMuteMinutes;
    minutes = Math.min(s.maxMuteMinutes, Math.max(1, Math.round(minutes)));

    if (s.dryRun) {
      await appendAudit(`[dry-run] group=${gid} rule=${ruleId} mid=${mid} target=${targetId} wouldRecall=${doRecall} wouldBan=${doBan ? minutes + 'min' : 'no'} reason=${String(args.reason || '')}`);
      return ok(`演练模式：本该撤回${doBan ? `并禁言 ${minutes} 分钟` : ''}，按设置没有真的执行（已记日志）。回一句话说明即可。`);
    }

    const results = [];
    const errors = [];

    if (doRecall) {
      try {
        await ctx.onebot.call('delete_msg', { message_id: Number(mid) }, 10000);
        results.push('撤回成功');
      } catch (error) {
        const msg = String(error && error.message ? error.message : error);
        // retcode 100 = 消息不存在/已撤回/超过时限，属于可接受的失败
        if (/retcode=100\b/.test(msg)) results.push('消息已不存在（无需撤回）');
        else errors.push('撤回失败：' + msg);
      }
      try {
        if (ctx.store && typeof ctx.store.markRecalled === 'function') ctx.store.markRecalled(ctx.chatKey, mid);
      } catch (error) { /* 标记失败不影响 */ }
    }

    if (doBan) {
      try {
        await ctx.onebot.call('set_group_ban', {
          group_id: Number(gid),
          user_id: Number(targetId),
          duration: minutes * 60
        }, 10000);
        results.push(`禁言 ${minutes} 分钟成功`);
      } catch (error) {
        errors.push('禁言失败：' + String(error && error.message ? error.message : error));
      }
    }

    const who = String(entry.senderName || targetId);
    if (results.length) {
      rule.hits = Number(rule.hits || 0) + 1;
      rule.lastHitAt = new Date().toISOString();
      await saveStore(store);
      done.set(dedupeKey, Date.now());
      await appendAudit(`[enforce] group=${gid} rule=${ruleId} mid=${mid} target=${targetId} result=${results.join(';')} errors=${errors.join(';')} reason=${String(args.reason || '')}`);
      if (s.notify) {
        const bits = [];
        if (doRecall) bits.push('撤回消息');
        if (doBan) bits.push(`禁言 ${minutes} 分钟`);
        await sendText(ctx, `⚠️ 已按群规 ${ruleId} ${bits.join('，')}（${who}）`);
      }
    } else {
      await appendAudit(`[enforce-failed] group=${gid} rule=${ruleId} mid=${mid} target=${targetId} errors=${errors.join(';')}`);
    }

    if (errors.length && !results.length) {
      return fail(errors.join('；') + '。多半是机器人不是管理员，或者这条消息超过可撤回时限。如实告诉群主，不要声称已处理。');
    }
    if (errors.length) {
      return ok(`部分完成：${results.join('，')}；${errors.join('；')}。回复里只用一句话说明结果，不要夸张。`);
    }
    return ok(`已执行：${results.join('，')}（规则 ${ruleId}，对象 ${who}）。回复里只用一句话说明，不要展开细节。`);
  }
};

// ── 消息查找 ──────────────────────────────────────────────────────────────

function findMessage(ctx, mid) {
  try {
    if (ctx.store && typeof ctx.store.findByMid === 'function') {
      const hit = ctx.store.findByMid(ctx.chatKey, mid);
      if (hit) return hit;
    }
  } catch (error) { /* 继续尝试其他来源 */ }
  return null;
}
