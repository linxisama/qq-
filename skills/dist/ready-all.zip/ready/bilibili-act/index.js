// B站互动（LLM 型 / skills/）
//
// ── 它能做什么 ────────────────────────────────────────────────────────────
// 用你自己的 B 站账号，对**明确指定**的视频做少量互动：点赞、投币、关注 UP 主、
// 发一条评论。不做自动逛、不批量、不连播 —— 这些不是技术做不到，是不该做。
//
// ── 为什么是技能 ──────────────────────────────────────────────────────────
// 什么时候该点赞/评论只能由对话决定（"给这个视频点个赞"），没有固定触发条件，
// 所以是 skills/（注册工具、模型判断），而不是 plugins/ 的定时器。
//
// ── 硬限制（能用代码保证的，不交给提示词）────────────────────────────────
//   · 只接受明确的 BV 号 / UID，不做"随便找一个视频"的模糊操作
//   · 每天每类动作都有上限，超了直接拒绝
//   · 默认演练模式：只记录、不调接口
//   · 评论必须先出草稿、发到会话里、等人确认（token 有效期默认 30 分钟）
//   · 不做任何绕过风控的事（不改指纹、不换 IP、不多账号）—— 账号自动化本身
//     违反 B 站用户协议，风险由使用者承担，本扩展只做到"少而透明"。
//
// ── 接口说明 ──────────────────────────────────────────────────────────────
// 全部走 B 站 Web 接口，需要 Cookie 里的 SESSDATA（登录态）和 bili_jct（CSRF）。
// 写操作是 POST 表单 + csrf 字段；读视频信息用 view 接口。

import fs from 'node:fs';
import path from 'node:path';
import { DATA_DIR } from '../../src/config.js';

const STATE_DIR = path.join(DATA_DIR, 'bilibili-act');
const USAGE_FILE = path.join(STATE_DIR, 'usage.json');
const PENDING_FILE = path.join(STATE_DIR, 'pending.json');
const LOG_FILE = path.join(STATE_DIR, 'actions.jsonl');

const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36';
const REFERER = 'https://www.bilibili.com/';
const BV_RE = /^BV[0-9A-Za-z]{8,12}$/;

const DEFAULTS = {
  enabled: true,
  cookie: '',
  dryRun: true,
  ownerUid: '',
  ownerName: '',
  maxLike: 10,
  maxCoin: 3,
  maxFollow: 2,
  maxComment: 3,
  commentTtlMin: 30
};

let api = null;
let log = () => {};
let warn = () => {};

// ── 基础工具 ──────────────────────────────────────────────────────────────

const pad2 = (n) => String(n).padStart(2, '0');
const dayKey = (d = new Date()) => `${d.getFullYear()}-${pad2(d.getMonth() + 1)}-${pad2(d.getDate())}`;

function num(v, min, max, fallback) {
  const n = Number(v);
  if (!Number.isFinite(n)) return fallback;
  return Math.min(max, Math.max(min, Math.round(n)));
}

function settings() {
  const raw = (typeof api?.config === 'function' ? api.config() : null) || {};
  return {
    enabled: raw.enabled !== false,
    cookie: String(raw.cookie || '').trim(),
    dryRun: raw.dryRun !== false,
    ownerUid: String(raw.ownerUid || '').trim(),
    ownerName: String(raw.ownerName || '').trim(),
    maxLike: num(raw.maxLike, 0, 50, DEFAULTS.maxLike),
    maxCoin: num(raw.maxCoin, 0, 20, DEFAULTS.maxCoin),
    maxFollow: num(raw.maxFollow, 0, 20, DEFAULTS.maxFollow),
    maxComment: num(raw.maxComment, 0, 20, DEFAULTS.maxComment),
    commentTtlMin: num(raw.commentTtlMin, 5, 240, DEFAULTS.commentTtlMin)
  };
}

function readJson(file, fallback) {
  try { return JSON.parse(fs.readFileSync(file, 'utf8')); } catch { return fallback; }
}

function writeJson(file, data) {
  fs.mkdirSync(STATE_DIR, { recursive: true });
  const tmp = `${file}.tmp`;
  fs.writeFileSync(tmp, JSON.stringify(data, null, 2), 'utf8');
  fs.renameSync(tmp, file);
}

function audit(entry) {
  try {
    fs.mkdirSync(STATE_DIR, { recursive: true });
    fs.appendFileSync(LOG_FILE, JSON.stringify({ ts: Date.now(), ...entry }) + '\n', 'utf8');
  } catch { /* 记账失败不影响动作 */ }
}

// ── 当日额度 ──────────────────────────────────────────────────────────────

const CAP_KEY = { like: 'maxLike', coin: 'maxCoin', follow: 'maxFollow', comment: 'maxComment' };
const CAP_LABEL = { like: '点赞', coin: '投币', follow: '关注', comment: '评论' };

function loadUsage() {
  const u = readJson(USAGE_FILE, null);
  const today = dayKey();
  if (!u || u.day !== today) return { day: today, like: 0, coin: 0, follow: 0, comment: 0 };
  return u;
}

/** 检查额度并在真正执行前占用一次。演练模式不占额度。 */
function takeQuota(kind, s) {
  const cap = s[CAP_KEY[kind]];
  if (cap <= 0) throw new Error(`今天的${CAP_LABEL[kind]}已被设置为禁止（上限 0）`);
  const u = loadUsage();
  if ((u[kind] || 0) >= cap) throw new Error(`今天的${CAP_LABEL[kind]}次数用完了（上限 ${cap}）`);
  u[kind] = (u[kind] || 0) + 1;
  writeJson(USAGE_FILE, u);
}

// ── Cookie / 请求 ─────────────────────────────────────────────────────────

function cookieHeader(s) {
  const raw = String(s.cookie || '').replace(/^cookie\s*:\s*/i, '').replace(/[\r\n]+/g, ' ').trim();
  if (!raw) throw new Error('还没有配置 B 站 Cookie：请在「技能 → B站互动」里填入 SESSDATA 和 bili_jct');
  if (!/SESSDATA=/.test(raw)) throw new Error('Cookie 里没有 SESSDATA，等于没登录');
  if (!/bili_jct=/.test(raw)) throw new Error('Cookie 里没有 bili_jct（CSRF），写操作会被拒绝');
  return raw;
}

function csrfOf(cookie) {
  const m = /(?:^|;\s*)bili_jct=([^;]+)/.exec(cookie);
  return m ? m[1] : '';
}

async function biliApi(url, { method = 'GET', form = null, s } = {}) {
  const cfg = s || settings();
  const cookie = cookieHeader(cfg);
  const headers = {
    'user-agent': UA,
    referer: REFERER,
    origin: 'https://www.bilibili.com',
    cookie
  };
  let body;
  if (form) {
    headers['content-type'] = 'application/x-www-form-urlencoded';
    body = new URLSearchParams({ ...form, csrf: csrfOf(cookie) }).toString();
  }
  const res = await fetch(url, { method, headers, body, signal: AbortSignal.timeout(15000) });
  if (!res.ok) throw new Error(`B站接口 HTTP ${res.status}`);
  const json = await res.json().catch(() => null);
  if (!json || typeof json !== 'object') throw new Error('B站返回了无法解析的内容');
  if (json.code !== 0) throw new Error(`B站返回 ${json.code}：${json.message || '未知错误'}`);
  return json.data;
}

/** 取视频信息（顺带解析 aid 和 UP 主 mid）。 */
async function videoInfo(bvid, s) {
  const data = await biliApi(`https://api.bilibili.com/x/web-interface/view?bvid=${encodeURIComponent(bvid)}`, { s });
  return { aid: data?.aid, mid: data?.owner?.mid, title: data?.title || '', owner: data?.owner?.name || '' };
}

// ── 工具实现 ──────────────────────────────────────────────────────────────

async function doLike({ bvid, undo = false }, s) {
  if (!BV_RE.test(bvid)) throw new Error(`BV 号格式不对：${bvid}`);
  if (s.dryRun) {
    audit({ action: undo ? 'unlike' : 'like', bvid, dryRun: true });
    return `演练模式：本来要给 ${bvid} ${undo ? '取消点赞' : '点赞'}，没有真的执行。`;
  }
  await biliApi('https://api.bilibili.com/x/web-interface/archive/like', {
    method: 'POST', form: { bvid, like: undo ? 2 : 1 }, s
  });
  audit({ action: undo ? 'unlike' : 'like', bvid, dryRun: false, ok: true });
  return `已经给 ${bvid} ${undo ? '取消点赞' : '点了赞'}。`;
}

async function doCoin({ bvid, count = 1 }, s) {
  if (!BV_RE.test(bvid)) throw new Error(`BV 号格式不对：${bvid}`);
  const n = Math.min(2, Math.max(1, Number(count) || 1));
  if (s.dryRun) {
    audit({ action: 'coin', bvid, count: n, dryRun: true });
    return `演练模式：本来要给 ${bvid} 投 ${n} 个币，没有真的执行。`;
  }
  await biliApi('https://api.bilibili.com/x/web-interface/coin/add', {
    method: 'POST', form: { bvid, multiply: n, select_like: 0 }, s
  });
  audit({ action: 'coin', bvid, count: n, dryRun: false, ok: true });
  return `已经给 ${bvid} 投了 ${n} 个币。`;
}

async function doFollow({ uid, bvid }, s) {
  let mid = String(uid || '').trim();
  if (!mid && bvid) {
    if (!BV_RE.test(bvid)) throw new Error(`BV 号格式不对：${bvid}`);
    const info = await videoInfo(bvid, s);
    mid = String(info.mid || '');
  }
  if (!/^\d{3,12}$/.test(mid)) throw new Error('要关注的 UID 不对（需要纯数字 UID，或给一个能查到 UP 主的 BV 号）');
  if (s.dryRun) {
    audit({ action: 'follow', mid, dryRun: true });
    return `演练模式：本来要关注 UID ${mid}，没有真的执行。`;
  }
  await biliApi('https://api.bilibili.com/x/relation/modify', {
    method: 'POST', form: { fid: mid, act: 1, re_src: 11 }, s
  });
  audit({ action: 'follow', mid, dryRun: false, ok: true });
  return `已经关注 UID ${mid}。`;
}

function prunePending(ttlMin) {
  const pending = readJson(PENDING_FILE, {});
  const cutoff = Date.now() - ttlMin * 60000;
  let changed = false;
  for (const [token, item] of Object.entries(pending)) {
    if (!item || Number(item.createdAt || 0) < cutoff) { delete pending[token]; changed = true; }
  }
  if (changed) writeJson(PENDING_FILE, pending);
  return pending;
}

/** 取主人的 B站昵称（@ 用）。优先手填，其次查 card 接口；查不到返回空串。 */
async function resolveOwnerName(s) {
  if (s.ownerName) return s.ownerName;
  const uid = s.ownerUid;
  if (!/^\d{3,12}$/.test(uid)) return '';
  try {
    const data = await biliApi(`https://api.bilibili.com/x/web-interface/card?mid=${uid}&photo=false`, { s });
    return String(data?.card?.name || '').trim();
  } catch { return ''; }
}

async function doCommentDraft(ctx, { bvid, text }, s) {
  if (!BV_RE.test(bvid)) throw new Error(`BV 号格式不对：${bvid}`);
  const uid = s.ownerUid;
  if (!/^\d{3,12}$/.test(uid)) {
    throw new Error('还没配置主人的 B站 UID：请到「技能 → B站互动」里填写（评论必须 @ 主人）');
  }
  const ownerName = await resolveOwnerName(s);
  if (!ownerName) {
    throw new Error(`配置了主人 UID ${uid}，但查不到昵称；请把主人的 B站昵称也填进设置，否则 @ 不出来`);
  }

  let body = String(text || '').trim();
  if (!body) throw new Error('评论内容为空');
  // 强制 @ 主人：已经带了的就不重复加
  const mention = `@${ownerName}`;
  if (!body.includes(mention)) body = `${mention} ${body}`;
  if (body.length > 200) throw new Error('评论太长（含 @ 后超过 200 字）');

  const pending = prunePending(s.commentTtlMin);
  const token = Math.random().toString(16).slice(2, 10);
  pending[token] = { bvid, text: body, ownerName, ownerUid: uid, createdAt: Date.now(), chatKey: ctx?.chatKey || '' };
  writeJson(PENDING_FILE, pending);

  const draft = `【评论草稿 · 待确认】\n视频：${bvid}\n内容：${body}\n\n已 @ 主人（${ownerName}）。确认要发请回复“发”，或让机器人调用 bili_comment_confirm（token ${token}）。${s.commentTtlMin} 分钟内有效。`;
  if (ctx?.sender?.sendTextBatch && ctx.chatKey) {
    await ctx.sender.sendTextBatch(ctx.chatKey, [draft]);
    return `草稿已发到当前会话，等对方确认后再调用 bili_comment_confirm（token: ${token}）。`;
  }
  return `${draft}\n（发送器不可用，没发出去；把这段念给对方听，确认后再调用 bili_comment_confirm，token: ${token}）`;
}

async function doCommentConfirm({ token }, s) {
  const pending = prunePending(s.commentTtlMin);
  const item = pending[String(token || '').trim()];
  if (!item) throw new Error('没有找到这条评论草稿（可能已过期或已发过）');

  // 演练模式不需要 Cookie：能查到标题就用，查不到也照常
  let info = { aid: 0, title: '' };
  try { info = await videoInfo(item.bvid, s); } catch { /* 演练模式没配置 Cookie 时忽略 */ }

  if (s.dryRun) {
    delete pending[token];
    writeJson(PENDING_FILE, pending);
    audit({ action: 'comment', bvid: item.bvid, text: item.text, dryRun: true });
    const title = info.title ? `（${info.title}）` : '';
    return `演练模式：本来要在 ${item.bvid}${title} 下发评论「${item.text}」，没有真的执行。`;
  }

  await biliApi('https://api.bilibili.com/x/v2/reply/add', {
    method: 'POST', form: { oid: info.aid, type: 1, message: item.text, at_name: item.ownerName || '' }, s
  });
  delete pending[token];
  writeJson(PENDING_FILE, pending);
  audit({ action: 'comment', bvid: item.bvid, text: item.text, dryRun: false, ok: true });
  return `已经在 ${item.bvid}（${info.title}）下发出评论。`;
}

// ── 工具注册 ──────────────────────────────────────────────────────────────

function toolGuard() {
  const s = settings();
  if (!s.enabled) throw new Error('「B站互动」在设置里被关掉了');
  return s;
}

const bvidParam = { type: 'string', description: '视频 BV 号，例如 BV1GJ411x7h7（不要传链接）' };

export function setup(a = {}) {
  api = a;
  log = (...args) => { try { a.log?.(...args); } catch { /* ignore */ } };
  warn = (...args) => { try { a.warn?.(...args); } catch { /* ignore */ } };

  a.registerTool?.({
    id: 'bili_like',
    name: 'B站点个赞',
    category: 'web',
    icon: '👍',
    description: '给指定 BV 号的视频点赞（或取消）。只在群友明确要求时用；默认演练模式不会真执行。',
    parameters: {
      type: 'object',
      properties: { bvid: bvidParam, undo: { type: 'boolean', description: 'true = 取消点赞' } },
      required: ['bvid']
    },
    async execute(_ctx, args = {}) {
      try { return { content: await guarded(() => doLike(args, settings())), isError: false }; }
      catch (error) { return { content: fail(error), isError: true }; }
    }
  });

  a.registerTool?.({
    id: 'bili_coin',
    name: 'B站投币',
    category: 'web',
    icon: '🪙',
    description: '给指定 BV 号的视频投币（1 或 2 个）。只在群友明确要求时用；默认演练模式不会真执行。',
    parameters: {
      type: 'object',
      properties: { bvid: bvidParam, count: { type: 'number', description: '投几个币，1 或 2，默认 1' } },
      required: ['bvid']
    },
    async execute(_ctx, args = {}) {
      try { return { content: await guarded(() => doCoin(args, settings())), isError: false }; }
      catch (error) { return { content: fail(error), isError: true }; }
    }
  });

  a.registerTool?.({
    id: 'bili_follow',
    name: 'B站关注',
    category: 'web',
    icon: '➕',
    description: '关注一个 B站 UP 主（传 UID，或传他视频的 BV 号让工具自己查）。只在群友明确要求时用；默认演练模式不会真执行。',
    parameters: {
      type: 'object',
      properties: {
        uid: { type: 'string', description: 'UP 主的数字 UID' },
        bvid: { type: 'string', description: '或者给一个该 UP 主的 BV 号' }
      }
    },
    async execute(_ctx, args = {}) {
      try { return { content: await guarded(() => doFollow(args, settings())), isError: false }; }
      catch (error) { return { content: fail(error), isError: true }; }
    }
  });

  a.registerTool?.({
    id: 'bili_comment',
    name: 'B站评论草稿',
    category: 'web',
    icon: '💬',
    description: '为指定视频生成一条评论草稿，并把草稿发到当前会话等确认；确认后才真正发出。只在群友明确要求时用。',
    parameters: {
      type: 'object',
      properties: { bvid: bvidParam, text: { type: 'string', description: '评论内容（200 字以内），用群友的口吻，不要写广告' } },
      required: ['bvid', 'text']
    },
    async execute(ctx, args = {}) {
      try { return { content: await guarded(() => doCommentDraft(ctx, args, settings())), isError: false }; }
      catch (error) { return { content: fail(error), isError: true }; }
    }
  });

  a.registerTool?.({
    id: 'bili_comment_confirm',
    name: '确认发B站评论',
    category: 'web',
    icon: '✅',
    description: '对方确认后，用草稿 token 真正发出那条评论。token 由 bili_comment 返回。',
    parameters: {
      type: 'object',
      properties: { token: { type: 'string', description: 'bili_comment 返回的 token' } },
      required: ['token']
    },
    async execute(_ctx, args = {}) {
      try { return { content: await guarded(() => doCommentConfirm(args, settings())), isError: false }; }
      catch (error) { return { content: fail(error), isError: true }; }
    }
  });

  a.registerTool?.({
    id: 'bili_status',
    name: 'B站互动状态',
    category: 'web',
    icon: '📊',
    description: '查看今天已经用掉多少互动额度、是不是演练模式、Cookie 是否已配置。',
    parameters: { type: 'object', properties: {} },
    async execute() {
      try {
        const s = settings();
        const u = loadUsage();
        const cookieOk = /SESSDATA=/.test(s.cookie) && /bili_jct=/.test(s.cookie);
        return {
          content: [
            `演练模式：${s.dryRun ? '开（不会真执行）' : '关（会真的操作账号）'}`,
            `Cookie：${cookieOk ? '已配置' : '未配置'}`,
            `今天：点赞 ${u.like || 0}/${s.maxLike}，投币 ${u.coin || 0}/${s.maxCoin}，关注 ${u.follow || 0}/${s.maxFollow}，评论 ${u.comment || 0}/${s.maxComment}`
          ].join('\n'),
          isError: false
        };
      } catch (error) { return { content: fail(error), isError: true }; }
    }
  });

  log('B站互动已加载：点赞/投币/关注/评论（默认演练模式）');
}

async function guarded(fn) {
  const s = toolGuard();
  return fn(s);
}

function fail(error) {
  const msg = String(error?.message ?? error);
  return `B站互动失败：${msg}`;
}

export function available() {
  try {
    const s = settings();
    if (!s.enabled) return { ok: false, reason: '设置里关掉了' };
    if (!s.dryRun) {
      const c = String(s.cookie || '');
      if (!/SESSDATA=/.test(c) || !/bili_jct=/.test(c)) {
        return { ok: false, reason: '演练模式已关，但 Cookie 不完整（需要 SESSDATA 和 bili_jct）' };
      }
    }
    return true;
  } catch { return true; }
}

export function dispose() {
  api = null;
  log = () => {};
  warn = () => {};
}

export const internals = {
  settings, loadUsage, takeQuota, dayKey, BV_RE, cookieHeader, csrfOf, prunePending
};
