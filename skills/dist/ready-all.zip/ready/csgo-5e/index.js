// 5E CS2 赛事与阵容技能（LLM 型）
//
// 数据源：5EPlay 赛事中心（中文站），全部实测可用。
//
// ── 接口清单（踩了很多坑才挖出来，别再乱改）─────────────────────────
//   ⚠️ 5E 是纯 JS 单页应用，HTML 里没有任何数据，必须调它的内部接口。
//
//   队名搜索（注意是另一个主机）：
//     https://ya-api-app.5eplay.com/v1/search/team?keyword=X&limit=10&page=1
//
//   数据主机：https://esports-data.5eplaycdn.com
//     · 战队阵容  /v1/api/csgo/teams/<队ID>/overview?time_type=30
//                 → data.team_info（教练/排名/国家/地区）+ data.overview.players（首发五人）
//     · 比赛列表  /v1/api/csgo/matches?game_status=<0|1|2>&game_type=1&limit=&page=
//                 game_status=1 今天前后 / =2 已结束 / =0,3 较远的未来
//     · 战队比赛  /v1/api/csgo/team/matches_v1/<队ID>   （只给最近一场摘要，列表不用它）
//
//   ⚠️ 每场比赛的 mc_info 里【没有赛事名称】，只有 stage 描述。别去编赛事名。
//   ⚠️ 5E 的队 ID 形如 csgo_tm_4863；比赛里的队 ID 却是 hltv_team_xxxx。
//      两套 ID 不通用，所以比赛按【队名】匹配，不能按 ID 关联。
//
// 零第三方依赖：api.fetch + 原生解析。

let cfg = () => ({});
let httpFetch = null;

const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36';
const DATA_HOST = 'https://esports-data.5eplaycdn.com';
const SEARCH_HOST = 'https://ya-api-app.5eplay.com';
const TZ = 'Asia/Shanghai';

// ⚠️ 5E 的队名搜索【完全不支持中文】——实测「天禄/绿龙/猎鹰/小蜜蜂…」全部 0 命中，
//    只认英文队名。所以中文叫法必须先过这张表转成英文再搜。
const TEAM_ALIASES = {
  '天禄': 'TYLOO', 'tyloo': 'TYLOO',
  '绿龙': 'Spirit', '绿龙队': 'Spirit', 'spirit': 'Spirit', 'team spirit': 'Spirit',
  '猎鹰': 'Falcons', '猎鹰队': 'Falcons', 'falcons': 'Falcons',
  '小蜜蜂': 'Vitality', '蜜蜂': 'Vitality', 'vitality': 'Vitality', 'team vitality': 'Vitality',
  '老鼠': 'MOUZ', '大老鼠': 'MOUZ', 'mouz': 'MOUZ',
  '液体': 'Team Liquid', 'liquid': 'Team Liquid', 'team liquid': 'Team Liquid',
  '黑豹': 'FURIA', '黑豹队': 'FURIA', 'furia': 'FURIA',
  '蒙古': 'The MongolZ', 'mongolz': 'The MongolZ', 'the mongolz': 'The MongolZ',
  '极光': 'Aurora', 'aurora': 'Aurora',
  '永恒之火': 'Eternal Fire', 'eternal fire': 'Eternal Fire',
  '天生赢家': 'Natus Vincere', 'navi': 'Natus Vincere', 'natus vincere': 'Natus Vincere',
  '银河战舰': 'G2', 'g2': 'G2', 'g2 esports': 'G2',
  '法泽': 'FaZe', 'faze': 'FaZe', 'faze clan': 'FaZe',
  '星队': 'Astralis', 'astralis': 'Astralis',
  '云九': 'Cloud9', 'cloud9': 'Cloud9', 'c9': 'Cloud9',
  'vp': 'Virtus.pro', 'virtus.pro': 'Virtus.pro',
  '绿盾': 'GamerLegion', 'gamerlegion': 'GamerLegion',
  'nip': 'Ninjas in Pyjamas', 'ninjas in pyjamas': 'Ninjas in Pyjamas',
  'fnatic': 'fnatic', 'big': 'BIG', 'heroic': 'Heroic', 'legacy': 'Legacy',
  'complexity': 'Complexity', 'col': 'Complexity', 'liquid': 'Team Liquid'
};

/** 中文/简写队名 → 5E 能搜到的英文名。 */
function toSearchName(input) {
  const raw = String(input ?? '').trim();
  if (!raw) return raw;
  return TEAM_ALIASES[raw] || TEAM_ALIASES[raw.toLowerCase()] || raw;
}

// 选手的中文外号 → 英文 ID。5E 的选手搜索同样只认英文 ID。
// 只收确定无误的，拿不准的宁可让它搜不到、由工具提示换英文写法，也不要写错映射。
const PLAYER_ALIASES = {
  '载物': 'ZywOo', '大番薯': 'ZywOo', '薯薯': 'ZywOo',
  '小孩': 'm0NESY',
  '简单男孩': 's1mple'
};

function toPlayerSearchName(input) {
  const raw = String(input ?? '').trim();
  if (!raw) return raw;
  return PLAYER_ALIASES[raw] || PLAYER_ALIASES[raw.toLowerCase()] || raw;
}

function timeoutMs() {
  const n = Number(cfg().timeoutMs);
  return Number.isFinite(n) && n >= 2000 ? n : 15000;
}

async function getJson(url) {
  if (typeof httpFetch !== 'function') throw new Error('缺少 web_fetch 权限（skill.json 的 permissions）');
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), timeoutMs());
  try {
    const res = await httpFetch(url, {
      headers: { 'User-Agent': UA, Accept: 'application/json', Referer: 'https://event.5eplay.com/' },
      signal: ctrl.signal
    });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    return await res.json();
  } finally {
    clearTimeout(timer);
  }
}

/** POST JSON（5E 的排名接口只吃 POST，GET 会 404）。 */
async function postJson(url, body) {
  if (typeof httpFetch !== 'function') throw new Error('缺少 web_fetch 权限（skill.json 的 permissions）');
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), timeoutMs());
  try {
    const res = await httpFetch(url, {
      method: 'POST',
      headers: {
        'User-Agent': UA, Accept: 'application/json',
        'Content-Type': 'application/json', Referer: 'https://event.5eplay.com/'
      },
      body: JSON.stringify(body),
      signal: ctrl.signal
    });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    return await res.json();
  } finally {
    clearTimeout(timer);
  }
}

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

/**
 * 5E 的搜索接口在连续请求时会**限流**——返回 `success:true` 但列表是空的。
 * 实测在完整测试里连打十几条请求后就会复现（界面表现成"搜不到这支队/这个人"）。
 * 所以空结果不能马上下结论，要退避重试几次。
 */
async function searchWithRetry(url, listKey) {
  let last = null;
  for (let i = 0; i < 3; i += 1) {
    last = await getJson(url);
    const n = last?.data?.[listKey]?.length ?? 0;
    if (n > 0) return last;
    if (i < 2) await sleep(700 * (i + 1));   // 700ms → 1400ms
  }
  return last;
}

/** 归一化队名：小写 + 去空格标点，用于匹配。 */
function norm(s) {
  return String(s ?? '').toLowerCase().replace(/[^a-z0-9\u4e00-\u9fa5]+/g, '');
}

/** 去掉 5E 的高亮标签，如 "<SF-HL>TYLOO</SF-HL>" → "TYLOO"。 */
function stripHl(s) {
  return String(s ?? '').replace(/<\/?SF-HL>/gi, '').trim();
}

/** 秒级时间戳 → 北京时间字符串。 */
function fmtBeijing(ts) {
  const sec = Number(ts);
  if (!Number.isFinite(sec) || sec <= 0) return '时间待定';
  return new Intl.DateTimeFormat('zh-CN', {
    timeZone: TZ, month: 'numeric', day: 'numeric', weekday: 'short',
    hour: '2-digit', minute: '2-digit', hour12: false
  }).format(new Date(sec * 1000));
}

/** 统计已打完的小局胜负数。 */
function countWins(bs) {
  let w1 = 0, w2 = 0;
  for (const b of bs ?? []) {
    const r = String(b?.result || '');
    if (r === 't1') w1 += 1; else if (r === 't2') w2 += 1;
  }
  return { w1, w2 };
}

/**
 * 按 5E 给的分档区间判断某项指标属于「好 / 中 / 差」。
 *
 * 结构形如：
 *   { avg_value:"1.07", value:"1.47", lower_better:false,
 *     range:{ bad:{start,end}, middle:{...}, good:{...} } }
 *
 * ⚠️ 坑 1：`avg_value` 是**全站基准值，所有选手都一样**，别拿它当选手数据；
 *    **选手本人的数值在 `value` 字段**。之前取错，导致不同选手显示出完全相同的指标。
 * ⚠️ 坑 2：start/end 不一定从小到大（差档是 "72.5~64.0" 这种降序），要比就两端取 min/max。
 * ⚠️ 坑 3：选手的数值可能**超出三档区间之外**（比如 rating 1.47 高出「好」档上限 1.30），
 *    这时要按 lower_better 的方向兜底判成「好」或「差」，不能返回空。
 */
function gradeOf(metric) {
  const cur = toNum(metric?.value);
  if (!Number.isFinite(cur)) return '';
  const rg = metric?.range || {};
  const lo = (r) => Math.min(toNum(r?.start), toNum(r?.end));
  const hi = (r) => Math.max(toNum(r?.start), toNum(r?.end));
  for (const [g, label] of [['good', '好'], ['middle', '中'], ['bad', '差']]) {
    const r = rg[g];
    if (!r) continue;
    const a = lo(r), b = hi(r);
    if (!Number.isFinite(a) || !Number.isFinite(b)) continue;
    if (cur >= a && cur <= b) return label;
  }
  const lowerBetter = metric?.lower_better === true;
  if (rg.good) {
    if (lowerBetter ? cur < lo(rg.good) : cur > hi(rg.good)) return '好';
  }
  if (rg.bad) {
    if (lowerBetter ? cur > hi(rg.bad) : cur < lo(rg.bad)) return '差';
  }
  return '';
}

/** 把 "1.47" / "+4.90%" / "-0.346" 这类字符串安全转成数字。 */
function toNum(x) {
  const s = String(x ?? '').replace(/%/g, '').replace(/^\+/, '').trim();
  const n = Number(s);
  return Number.isFinite(n) ? n : NaN;
}

/** 判断一场比赛的状态：finished / live / upcoming。 */
function matchState(m) {
  const bs = m?.state?.bout_states ?? [];
  if (!bs.length) return 'upcoming';
  if (!bs.every((b) => String(b.status) === '2')) return 'live';
  // ⚠️ 所有小局都标 status=2 也不代表比赛结束：
  //    实测 BO5 只打到 2:2（第 5 张图还没开出）时也会全部标成 2，
  //    这时比赛其实还在进行。所以必须再确认赢局数够不够——
  //    BO3 要 2 胜、BO5 要 3 胜。
  const need = Math.floor((Number(m?.mc_info?.format) || 3) / 2) + 1;
  const { w1, w2 } = countWins(bs);
  return Math.max(w1, w2) >= need ? 'finished' : 'live';
}

/** 取比赛双方队名（兼容两种字段命名）。 */
function matchTeams(m) {
  const mi = m?.mc_info ?? {};
  const a = mi.t1_info?.disp_name ?? mi.home_info?.disp_name ?? '';
  const b = mi.t2_info?.disp_name ?? mi.opponent_info?.disp_name ?? '';
  return [stripHl(a), stripHl(b)];
}

/** 按队名判断这场比赛是否涉及目标队。keywords 是归一化后的候选词。 */
function involvesTeam(m, keywords) {
  const names = matchTeams(m).map(norm).filter(Boolean);
  return names.some((n) => keywords.some((k) => n.includes(k) || k.includes(n)));
}

/** 从 bout_states 算大比分与地图小分。 */
function scoreText(m) {
  const bs = m?.state?.bout_states ?? [];
  const maps = [];
  for (const b of bs) {
    if (b.map_name) maps.push(`${b.map_name} ${b.t1_score ?? '?'}-${b.t2_score ?? '?'}`);
  }
  const { w1, w2 } = countWins(bs);
  return { big: bs.length ? `${w1} : ${w2}` : '', maps };
}

/** 拉比赛列表（合并若干 game_status，按比赛 id 去重）。 */
async function fetchMatches(statuses, pageLimit = 50) {
  const byId = new Map();
  for (const gs of statuses) {
    const url = `${DATA_HOST}/v1/api/csgo/matches?game_status=${gs}&game_type=1&limit=${pageLimit}&page=1`;
    let j;
    try { j = await getJson(url); } catch { continue; }
    const list = [...(j?.data?.live_matches ?? []), ...(j?.data?.matches ?? [])];
    for (const m of list) {
      const id = m?.mc_info?.id;
      if (id && !byId.has(id)) byId.set(id, m);
    }
  }
  return [...byId.values()];
}

/** 用队名搜 5E，返回最匹配的 CS 队。 */
async function searchTeam(name) {
  const q = toSearchName(name);          // 中文先转英文，5E 不认中文
  const url = `${SEARCH_HOST}/v1/search/team?keyword=${encodeURIComponent(q)}&limit=10&page=1`;
  const j = await searchWithRetry(url, 'teams');
  const all = j?.data?.teams ?? [];
  const cs = all.filter((t) => String(t.game_type ?? '').toUpperCase() === 'CS');
  if (!cs.length) return null;
  const target = norm(q);
  const cand = cs.map((t) => ({ raw: t, name: stripHl(t.disp_name), key: norm(stripHl(t.disp_name)) }));
  return (cand.find((c) => c.key === target)
    || cand.find((c) => c.key.startsWith(target) || target.startsWith(c.key))
    || cand[0]);
}

/** 用选手名搜 5E，返回最匹配的 CS 选手（含 player_id）。 */
async function searchPlayer(name) {
  const q = toPlayerSearchName(name);    // 中文外号先转英文
  const url = `${SEARCH_HOST}/v1/search/player?keyword=${encodeURIComponent(q)}&limit=10&page=1`;
  const j = await searchWithRetry(url, 'players');
  const all = j?.data?.players ?? [];
  const cs = all.filter((p) => String(p.game_type ?? '').toUpperCase() === 'CS');
  if (!cs.length) return null;
  const target = norm(q);
  const cand = cs.map((p) => ({ raw: p, name: stripHl(p.disp_name), key: norm(stripHl(p.disp_name)) }));
  // 精确同名优先（"donk" 会搜出 donk566 / bedonka / donk 等 8 个，必须挑对）
  return (cand.find((c) => c.key === target)
    || cand.find((c) => c.key.startsWith(target) || target.startsWith(c.key))
    || cand[0]);
}

/** 北京时间日期字符串 YYYY-MM-DD，用于拼 time_value。 */
function bjDateStr(d) {
  const p = new Intl.DateTimeFormat('en-CA', {
    timeZone: TZ, year: 'numeric', month: '2-digit', day: '2-digit'
  }).format(d);
  return p;
}

export function setup(api) {
  cfg = api.config;
  httpFetch = typeof api.fetch === 'function' ? (...a) => api.fetch(...a) : null;

  // ── 工具 1：战队阵容 ─────────────────────────────────────────
  api.registerTool({
    id: 'team_roster',
    name: 'CS2 战队阵容',
    description:
      '查某支 CS2 战队的当前阵容：首发五人、教练，以及每名选手的位置和国籍。'
      + '当用户问「XX 阵容是什么」「XX 现在谁打」「XX 谁是指挥」「XX 的狙击手是谁」「XX 教练是谁」时使用。'
      + '数据来自 5EPlay 赛事中心（中文站），中文队名和选手名可以直接用，不需要翻译成英文。'
      + '返回里会附带这支队的当前世界排名和所属地区。'
      + '不要用它查比赛比分或赛程——那是另外两个工具的职责。',
    category: 'query',
    icon: '👥',
    parameters: {
      type: 'object',
      properties: {
        team: { type: 'string', description: '战队名，中文直接写（如「天禄」「TYLOO」「绿龙」「猎鹰」）。' }
      },
      required: ['team']
    },
    async execute(ctx, args) {
      const team = String(args?.team ?? '').trim();
      if (!team) return { content: '需要告诉我查哪支队的阵容。', isError: true };
      try {
        const hit = await searchTeam(team);
        if (!hit) {
          return { content: `在 5E 上搜不到「${team}」这支队。可以让用户换个写法（中文全名或英文全名），或者确认一下队名。`, isError: false };
        }
        const id = hit.raw.obj_id || hit.raw.tm_id;
        const url = `${DATA_HOST}/v1/api/csgo/teams/${encodeURIComponent(id)}/overview?time_type=30`;
        const j = await getJson(url);
        const ti = j?.data?.team_info ?? {};
        const players = j?.data?.overview?.players ?? [];

        if (!players.length) {
          return { content: `5E 上有「${hit.name}」这支队，但没给出阵容数据。`, isError: false };
        }

        const starters = players.filter((p) => String(p.position ?? '').includes('首发'));
        const subs = players.filter((p) => !String(p.position ?? '').includes('首发'));

        const line = (p) => {
          const roles = Array.isArray(p.positions) && p.positions.length ? p.positions.join('/') : '';
          const country = p.country_en && p.country_en !== 'China' ? `（${p.country_en}）` : '';
          return `· ${p.name || '?'}${roles ? ` —— ${roles}` : ''}${country}`;
        };

        const head = [
          `${ti.disp_name || hit.name}`,
          [
            // 与 team_ranking 保持一致，用 V社排名（不是 ti.rank 那个 HLTV 排名）
            ti.v_club_rank ? `世界第 ${ti.v_club_rank}` : '',
            ti.region_name || '',
            ti.country_name || '',
            ti.average_player_age ? `平均 ${ti.average_player_age} 岁` : ''
          ].filter(Boolean).join(' · ')
        ].filter(Boolean).join('\n');

        const parts = [head];
        const coach = ti.coach || j?.data?.overview?.coach;
        if (coach) parts.push(`教练：${coach}`);
        if (starters.length) parts.push(`首发：\n${starters.map(line).join('\n')}`);
        if (subs.length) parts.push(`替补/其他：\n${subs.map(line).join('\n')}`);

        return { content: parts.join('\n') };
      } catch (e) {
        return { content: `查阵容失败：${e?.message ?? e}`, isError: true };
      }
    }
  });

  // ── 工具 2：近期赛程 ─────────────────────────────────────────
  api.registerTool({
    id: 'recent_schedule',
    name: 'CS2 赛程查询',
    description:
      '查 CS2 即将进行的比赛。'
      + '当用户问「今天有什么比赛」「明天谁打谁」「XX 接下来打谁」「最近有什么赛程」时使用。'
      + '可以按战队筛选（中文直接写，如「天禄」）。'
      + '返回北京时间、对阵双方、赛制（BO几）和赛事阶段。'
      + '注意：5E 的赛程只覆盖近期几天，很久以后的比赛查不到是正常的。'
      + '不要用它查已经打完的比赛结果——用 recent_results。',
    category: 'query',
    icon: '📅',
    parameters: {
      type: 'object',
      properties: {
        team: { type: 'string', description: '可选：只看这支队，中文直接写（如「天禄」）。' },
        limit: { type: 'integer', description: '可选：最多返回几场，默认 10，最多 30。' }
      }
    },
    async execute(ctx, args) {
      try {
        const maxLimit = Math.min(30, Math.max(1, Number(cfg().maxLimit) || 30));
        const defLimit = Math.max(1, Number(cfg().defaultLimit) || 10);
        const limit = Math.min(maxLimit, Math.max(1, Number(args?.limit) || defLimit));

        let keywords = null;
        if (args?.team) {
          const hit = await searchTeam(String(args.team).trim());
          const key = norm(hit ? hit.name : args.team);
          keywords = [key];
        }

        const all = await fetchMatches([1, 0]);
        let list = all.filter((m) => matchState(m) !== 'finished');
        if (keywords) list = list.filter((m) => involvesTeam(m, keywords));
        list.sort((a, b) => Number(a.mc_info?.plan_ts ?? 0) - Number(b.mc_info?.plan_ts ?? 0));
        list = list.slice(0, limit);

        if (!list.length) {
          return {
            content: keywords
              ? `5E 近期赛程里没有「${String(args.team).trim()}」的比赛。可能它这几天没安排，也可能 5E 没收录。`
              : '5E 近期赛程里没有拿到比赛数据。',
            isError: false
          };
        }

        const lines = list.map((m) => {
          const mi = m.mc_info ?? {};
          const [a, b] = matchTeams(m);
          const st = matchState(m);
          const tag = st === 'live' ? '【进行中】' : '';
          const stage = mi.tt_stage_desc || mi.tt_stage || '';
          const meta = [`BO${mi.format || '?'}`, stage].filter(Boolean).join(' · ');
          return `${fmtBeijing(mi.plan_ts)}${tag}\n${a} vs ${b}（${meta}）`;
        });

        return { content: `5E 近期赛程：\n\n${lines.join('\n\n')}` };
      } catch (e) {
        return { content: `查赛程失败：${e?.message ?? e}`, isError: true };
      }
    }
  });

  // ── 工具 3：近期赛果 ─────────────────────────────────────────
  api.registerTool({
    id: 'recent_results',
    name: 'CS2 赛果查询',
    description:
      '查 CS2 已经打完的比赛比分。'
      + '当用户问「XX 昨天赢了吗」「最近比分」「某场比赛结果」时使用。'
      + '返回大比分，并能拿到每张地图的小分。可以按战队筛选。'
      + '注意：5E 只保留近期赛果，太早的比赛查不到是正常的。'
      + '不要用它查还没开始的比赛——用 recent_schedule。',
    category: 'query',
    icon: '🏁',
    parameters: {
      type: 'object',
      properties: {
        team: { type: 'string', description: '可选：只看这支队，中文直接写（如「天禄」）。' },
        limit: { type: 'integer', description: '可选：最多返回几场，默认 10，最多 30。' }
      }
    },
    async execute(ctx, args) {
      try {
        const maxLimit = Math.min(30, Math.max(1, Number(cfg().maxLimit) || 30));
        const defLimit = Math.max(1, Number(cfg().defaultLimit) || 10);
        const limit = Math.min(maxLimit, Math.max(1, Number(args?.limit) || defLimit));

        let keywords = null;
        if (args?.team) {
          const hit = await searchTeam(String(args.team).trim());
          keywords = [norm(hit ? hit.name : args.team)];
        }

        const all = await fetchMatches([2]);
        let list = all.filter((m) => matchState(m) === 'finished');
        if (keywords) list = list.filter((m) => involvesTeam(m, keywords));
        list.sort((a, b) => Number(b.mc_info?.plan_ts ?? 0) - Number(a.mc_info?.plan_ts ?? 0));
        list = list.slice(0, limit);

        if (!list.length) {
          return {
            content: keywords
              ? `5E 近期赛果里没有「${String(args.team).trim()}」的比赛记录。可能这几天没打，也可能 5E 没收录。`
              : '5E 近期赛果里没有拿到数据。',
            isError: false
          };
        }

        const lines = list.map((m) => {
          const mi = m.mc_info ?? {};
          const [a, b] = matchTeams(m);
          const sc = scoreText(m);
          const stage = mi.tt_stage_desc || mi.tt_stage || '';
          const meta = [`BO${mi.format || '?'}`, stage].filter(Boolean).join(' · ');
          const maps = sc.maps.length ? `\n  ${sc.maps.join(' / ')}` : '';
          return `${fmtBeijing(mi.plan_ts)}\n${a} ${sc.big || '—'} ${b}（${meta}）${maps}`;
        });

        return { content: `5E 近期赛果：\n\n${lines.join('\n\n')}` };
      } catch (e) {
        return { content: `查赛果失败：${e?.message ?? e}`, isError: true };
      }
    }
  });

  // ── 工具 4：战队排名 ─────────────────────────────────────────
  api.registerTool({
    id: 'team_ranking',
    name: 'CS2 战队排名',
    description:
      '查 CS2 战队的世界排名（5EPlay 的战队榜）。'
      + '当用户问「XX 排第几」「现在世界第一是谁」「前二十有哪些队」「XX 排名多少」时使用。'
      + '不传 team 时返回榜单前若干名；传 team 时直接回答这支队的排名。'
      + '数据来自 5EPlay 赛事中心，中文队名直接可用（如「天禄」「绿龙」）。'
      + '不要用它查比赛比分或阵容——那是另外几个工具的职责。',
    category: 'query',
    icon: '🏆',
    parameters: {
      type: 'object',
      properties: {
        team: { type: 'string', description: '可选：要看排名的战队，中文直接写（如「天禄」）。填了就只回答这一支队。' },
        limit: { type: 'integer', description: '可选：返回前几名，默认 20，最多 100。用户问「前十」就传 10。' }
      }
    },
    async execute(ctx, args) {
      try {
        // 查单支队：用 overview 的 v_club_rank（V社排名），一次请求搞定，不用翻页
        if (args?.team) {
          const teamName = String(args.team).trim();
          const hit = await searchTeam(teamName);
          if (!hit) {
            return { content: `在 5E 上搜不到「${teamName}」这支队，查不了它的排名。`, isError: false };
          }
          const url = `${DATA_HOST}/v1/api/csgo/teams/${encodeURIComponent(hit.raw.obj_id || hit.raw.tm_id)}/overview?time_type=30`;
          const j = await getJson(url);
          const ti = j?.data?.team_info ?? {};
          // ⚠️ 只用 v_club_rank（V社排名）。ti.rank 是 HLTV 排名，两个榜不一样：
          //    实测 Vitality 的 v_club_rank=1 而 rank=2，Spirit 的 v_club_rank=3 而 rank=1。
          if (!ti.v_club_rank) {
            return { content: `5E 上「${ti.disp_name || teamName}」没有 V社排名数据（可能不在榜上）。`, isError: false };
          }
          const extra = [ti.region_name, ti.country_name].filter(Boolean).join(' · ');
          return { content: `${ti.disp_name || teamName}\n世界第 ${ti.v_club_rank}${extra ? ` · ${extra}` : ''}` };
        }

        // 查榜单：POST + rank_type=valve_rank（GET 会 404）
        // ⚠️ 名次取【数组下标】，不能取 x.rank —— 那个字段装的是 HLTV 排名！
        const maxLimit = Math.min(100, Math.max(1, Number(cfg().maxLimit) || 100));
        const limit = Math.min(maxLimit, Math.max(1, Number(args?.limit) || 20));
        const items = [];
        for (let page = 1; page <= 5 && items.length < limit; page += 1) {
          const j = await postJson(`${DATA_HOST}/v1/api/csgo/new/rank/team_list`, {
            sort_value: 'desc', rank_type: 'valve_rank', sort_key: 'valve_rank', region: '全部赛区',
            team_options: {
              tt_ids: [], time_value: '', grade: [], team_id: '',
              time_type: 'self', tt_series: [], maps: [], page
            }
          });
          const got = j?.data?.items ?? [];
          if (!got.length) break;
          items.push(...got);
        }
        if (!items.length) return { content: '5E 没返回排名数据。', isError: false };

        const lines = items.slice(0, limit).map((x, i) => `#${i + 1} ${x.team_name || x.name}`);
        return { content: `5E CS2 战队排名（V社排名）：\n${lines.join('\n')}` };
      } catch (e) {
        return { content: `查排名失败：${e?.message ?? e}`, isError: true };
      }
    }
  });

  // ── 工具 5：选手近期表现 ─────────────────────────────────────
  api.registerTool({
    id: 'player_recent',
    name: 'CS2 选手近期表现',
    description:
      '查某位 CS2 选手近期的整体表现，并给出各指标在同档选手中属于哪一档。'
      + '当用户问「XX 最近打得怎么样」「评价一下 XX」「XX 最近状态如何」「XX 最近的数据」时使用。'
      + '返回三部分：① 近期战绩（比赛/地图胜负数与胜率、MVP 次数）'
      + '② 核心数据（K/D、KD 差、爆头率、助攻）'
      + '③ 进阶指标与分档（Rating / ADR / KAST / KPR / DPR / Impact / Swing 的当前值，以及 5E 给出的「好/中/差」区间），另外还附最近几场对手与比分。'
      + '数据来自 5EPlay 赛事中心。'
      + '注意：这是「最近一段时间」的汇总表现，不是某一场的比赛数据；用户问具体某一场时要如实说明这个限制。',
    category: 'query',
    icon: '📊',
    parameters: {
      type: 'object',
      properties: {
        player: { type: 'string', description: '选手名，中英文都行（如「载物」「ZywOo」「donk」「JamYoung」）。英文 ID 通常更准。' },
        days: { type: 'integer', description: '可选：回看多少天，默认 30，最多 365。' }
      },
      required: ['player']
    },
    async execute(ctx, args) {
      const player = String(args?.player ?? '').trim();
      if (!player) return { content: '需要告诉我查哪位选手。', isError: true };
      try {
        const hit = await searchPlayer(player);
        if (!hit) {
          return {
            content: `在 5E 上搜不到选手「${player}」。5E 的选手搜索基本只认英文 ID，`
              + `中文外号认得的很少——可以让用户给一下英文 ID 试试。`,
            isError: false
          };
        }
        const pid = hit.raw.player_id || hit.raw.obj_id;
        const days = Math.min(365, Math.max(1, Number(args?.days) || 30));
        const end = new Date();
        const start = new Date(end.getTime() - days * 86400000);
        const playerOptions = {
          player_id: pid,
          time_type: 'recent',
          time_value: `${bjDateStr(start)} 00:00:00_${bjDateStr(end)} 23:59:59`
        };

        const [statsRes, listRes] = await Promise.all([
          postJson(`${DATA_HOST}/v1/api/csgo/mfilter/player/stats`, { player_options: playerOptions }),
          postJson(`${DATA_HOST}/v1/api/csgo/mfilter/player/match/list`, { player_options: playerOptions })
        ]);

        const d = statsRes?.data ?? {};
        const pd = d.player_data ?? {};
        const ms = d.match_stats ?? {};
        const mp = d.map_stats ?? {};
        const perf = d.player_performance ?? {};
        const teamName = stripHl(hit.raw.team?.team_name || hit.raw.team_name || '');
        const country = hit.raw.country?.country_name || hit.raw.country_zh || '';

        const parts = [`${hit.name}${teamName || country ? `（${[teamName, country].filter(Boolean).join(' · ')}）` : ''}`];

        if (ms.total) {
          parts.push(`近期战绩（近 ${days} 天）\n`
            + `· 比赛 ${ms.win} 胜 ${ms.loss} 负，胜率 ${ms.win_rate}`
            + `${ms.mvp_count ? `，MVP ${ms.mvp_count} 次` : ''}`
            + (mp.total ? `\n· 地图 ${mp.win} 胜 ${mp.loss} 负，胜率 ${mp.win_rate}` : ''));
        }

        const core = [];
        if (pd.kd) core.push(`K/D ${pd.kd}`);
        if (pd.kddiff) core.push(`KD 差 ${Number(pd.kddiff) > 0 ? '+' : ''}${pd.kddiff}`);
        if (pd.hs_rate) core.push(`爆头率 ${pd.hs_rate}`);
        if (pd.total_assist) core.push(`助攻 ${pd.total_assist}`);
        if (core.length) parts.push(`核心数据\n· ${core.join('  ')}`);

        // ⚠️ 这里**故意不含 impact**：实测该字段接口没填数据，所有选手都是 0.00，
        //    显示出来会被误判成「差档」，反而误导。等 5E 填了再加回来。
        const METRIC_NAMES = { rating: 'Rating', adr: 'ADR', kast: 'KAST', kpr: 'KPR', dpr: 'DPR', swing: 'Swing' };
        const metricLines = [];
        for (const key of Object.keys(METRIC_NAMES)) {
          const v = perf[key];
          // ⚠️ 用 v.value（选手本人），不是 v.avg_value（全站基准，所有人都一样）
          if (!v || v.value === undefined || v.value === '') continue;
          const grade = gradeOf(v);
          metricLines.push(`· ${METRIC_NAMES[key]} ${v.value}${grade ? `（${grade}档）` : ''}`);
        }
        if (metricLines.length) parts.push(`进阶指标（5E 分档）\n${metricLines.join('\n')}`);

        const matches = listRes?.data?.items?.matches ?? [];
        const mLines = [];
        for (const m of matches) {
          const mi = m?.mc_info ?? {};
          const home = stripHl(mi.home_info?.disp_name);
          const opp = stripHl(mi.opponent_info?.disp_name);
          if (!home || !opp) continue;
          const ts = Number(mi.ts);
          const tt = m?.tt_info?.disp_name || m?.tt_info?.abbr_zh || '';
          mLines.push(`· ${ts ? fmtBeijing(ts) : ''} ${home} ${mi.home_score || '-'}:${mi.opponent_score || '-'} ${opp}${tt ? `（${tt}）` : ''}`);
          if (mLines.length >= 8) break;
        }
        if (mLines.length) parts.push(`近期比赛\n${mLines.join('\n')}`);

        if (parts.length <= 1) {
          return { content: `5E 上「${hit.name}」在近 ${days} 天内没有比赛数据。`, isError: false };
        }
        return { content: parts.join('\n\n') };
      } catch (e) {
        return { content: `查选手表现失败：${e?.message ?? e}`, isError: true };
      }
    }
  });
}

/** 自检：没有网络权限时明确报出来。 */
export function available() {
  if (!httpFetch) return { ok: false, reason: '缺少 web_fetch 权限（清单里的 permissions 被删了？）' };
  return true;
}
