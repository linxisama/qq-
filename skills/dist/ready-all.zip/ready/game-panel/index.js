// ══════════════════════════════════════════════════════════════════════════════
// game-panel —— 原神 / 崩坏：星穹铁道 练度面板（出图）+ B站 wiki 养成建议
//
// 数据源（全部免登录、免 Cookie、不碰玩家账号）：
//   · 原神：《角色展柜》公开数据   → https://enka.network/api/uid/{uid}
//   · 星铁：公开角色数据           → https://api.mihomo.me/sr_info_parsed/{uid}?lang=chs
//   · 建议：B站游戏 Wiki（MediaWiki）→ wiki.biligame.com/{ys|sr}/api.php
// 渲染：Electron 离线窗口把 HTML 截成 PNG（与 plugins/genshin-card 同一套做法，不引额外依赖）
// 发送：ctx.sender.sendImage（优先本地文件路径，base64 兜底 —— 见 src/sender.js 的注释）
//
// ⚠️ 热重载坑：plugin-loader 只给入口加时间戳，入口静态 import 的子模块会命中 ESM 缓存。
//    所以所有逻辑都写在这一个文件里，不拆子模块（与 genshin-card 同）。
// ⚠️ Wiki 反爬：biligame 的 prop=text（渲染后的 HTML）会返回 HTTP 567，只有 prop=wikitext
//    稳定可用；所以建议全部从 wikitext 里解析，绝不请求渲染页。
// ⚠️ 星铁图标：api.mihomo.me 本身不提供图片（/icon/... 一律 404），图标要按接口返回的相对路径
//    去 Mar-7th/StarRailRes 取，代码里做了多 CDN 兜底。
// ══════════════════════════════════════════════════════════════════════════════

import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';

let api = null;
const DIR = import.meta.dirname;
const DATA_DIR = path.join(DIR, 'data');

const readJson = (file, fallback = {}) => {
  try { return JSON.parse(fs.readFileSync(path.join(DATA_DIR, file), 'utf8')); } catch { return fallback; }
};
// 原神中文名 / 图标库（从 genshin-card 沿用：Enka 只给角色 id，名字和图标得自己查）
const AVATARS = readJson('avatars.json');      // id → { n 名, i 图标, e 元素, w 武器类型, q 品质, k 天赋映射 }
const WEAPONS = readJson('weapons.json');      // id → { n 名, i 图标, r 星级 }
const RELIQUARY = readJson('reliquary.json');  // setId → 套装中文名

/**
 * 元素/属性图标（用户提供的素材，已复制进 data/attr/）：原神 7 元素、星铁 7 属性各 7 张。
 * 原神这 7 张的对应关系**以用户确认为准**（他提供的素材、他熟悉的编号）：
 *   1 火 / 2 水 / 3 草 / 4 雷 / 5 冰 / 6 风 / 7 岩
 * 星铁按主色认（bt1 #969697 灰=物理、bt2 #DFCE45 金=虚数、bt3 #469BCB 青=冰、
 * bt4 #6761C9 靛=量子（椭圆）、bt5 #60C594 绿=风、bt6 #B352CD 紫=雷（尖刺）、bt7 #E04037 红=火）。
 * 原神这套原始素材是**白色线稿**，不够醒目，所以按上面的对应用元素色重新上过色，
 * 存在 data/attr/ys-color/（原始白色版留在 data/attr/ys/ 备查）。
 */
const ATTR_ICON_DIR = { genshin: 'ys-color', starrail: 'bt' };
const GS_ELEMENT_ATTR = { Fire: 1, Water: 2, Grass: 3, Electric: 4, Ice: 5, Wind: 6, Rock: 7 };
// 星铁元素 id 实测是 Thunder 而不是 Lightning（mihomo 的取值），两个都收进来免得漏
const SR_ELEMENT_ATTR = { Physical: 1, Imaginary: 2, Ice: 3, Quantum: 4, Wind: 5, Thunder: 6, Lightning: 6, Fire: 7 };
const attrIconCache = new Map();

const CARD_W = 760;                    // CSS 像素宽（截图时按实测 DPR 出高清图）
const ADVICE_TTL_MS = 6 * 60 * 60 * 1000;
const WIKI_MIN_GAP_MS = 900;           // 两次 wiki 请求的最小间隔（防反爬 567）
const REQ_TIMEOUT_MS = 25000;

/* ── 主题 / 静态表 ─────────────────────────────────────────────────────────── */
const THEMES = {
  dark: { pageBg: '#0e1014', cardBg: '#14171d', border: '#262b35', text: '#e8ecf3', dim: '#aab3c2', dim2: '#6f7a8d', chip: '#1b2028', sec: '#8b95a7' },
  light: { pageBg: '#eef1f5', cardBg: '#ffffff', border: '#dfe4ec', text: '#1a1f29', dim: '#5b6675', dim2: '#8b95a7', chip: '#f3f5f9', sec: '#7a8494' }
};

const GAMES = {
  genshin: {
    key: 'genshin',
    label: '原神',
    wiki: 'ys',
    aliases: ['原神', 'genshin', 'ys', '提瓦特', 'yuanshen'],
    source: '数据来自游戏内公开「角色展柜」（Enka.Network）'
  },
  starrail: {
    key: 'starrail',
    label: '星铁',
    labelFull: '崩坏：星穹铁道',
    wiki: 'sr',
    aliases: ['星铁', '星穹铁道', '崩坏星穹铁道', '崩坏：星穹铁道', 'starrail', 'hsr', 'sr', 'xingtie'],
    source: '数据来自公开角色数据（api.mihomo.me）'
  }
};

// 原神元素 / 武器中文
const GS_ELEMENTS = {
  Fire: { name: '火', color: '#ff7a45' }, Water: { name: '水', color: '#4cc9f0' },
  Wind: { name: '风', color: '#5fd6a5' }, Electric: { name: '雷', color: '#b47cf0' },
  Ice: { name: '冰', color: '#7fd4ff' }, Rock: { name: '岩', color: '#f0c14b' },
  Grass: { name: '草', color: '#8ed15a' }, None: { name: '无', color: '#98a2b3' }
};
const GS_WEAPON_CN = {
  WEAPON_SWORD_ONE_HAND: '单手剑', WEAPON_CLAYMORE: '双手剑', WEAPON_POLE: '长柄武器',
  WEAPON_BOW: '弓', WEAPON_CATALYST: '法器',
  Sword: '单手剑', Claymore: '双手剑', Polearm: '长柄武器', Bow: '弓', Catalyst: '法器'
};
const GS_TALENT_LABEL = { A: '普通攻击', S: '元素战技', E: '元素爆发' };
const GS_STAT_ROWS = [
  ['2000', '生命上限', 'int'], ['2001', '攻击力', 'int'], ['2002', '防御力', 'int'],
  ['28', '元素精通', 'int'], ['20', '暴击率', 'pct'], ['22', '暴击伤害', 'pct'],
  ['23', '元素充能效率', 'pct']
];
const GS_ELEM_DMG_KEY = { Fire: '40', Electric: '41', Water: '42', Grass: '43', Wind: '44', Rock: '45', Ice: '46' };
// 圣遗物主词条：mainPropId → [中文名, 是否百分比]
// 名字用**短标签**：格子只有 ~78px 宽，"冰元素伤害加成"这种会把格子挤爆
const GS_MAIN_PROP = {
  FIGHT_PROP_BASE_ATTACK: ['基础攻击力', false],
  FIGHT_PROP_HP: ['生命值', false], FIGHT_PROP_HP_PERCENT: ['生命值', true],
  FIGHT_PROP_ATTACK: ['攻击力', false], FIGHT_PROP_ATTACK_PERCENT: ['攻击力', true],
  FIGHT_PROP_DEFENSE: ['防御力', false], FIGHT_PROP_DEFENSE_PERCENT: ['防御力', true],
  FIGHT_PROP_ELEMENT_MASTERY: ['元素精通', false],
  FIGHT_PROP_CRITICAL: ['暴击率', true], FIGHT_PROP_CRITICAL_HURT: ['暴击伤害', true],
  FIGHT_PROP_CHARGE_EFFICIENCY: ['充能效率', true], FIGHT_PROP_HEAL_ADD: ['治疗加成', true],
  FIGHT_PROP_PHYSICAL_ADD_HURT: ['物伤加成', true],
  FIGHT_PROP_FIRE_ADD_HURT: ['火伤加成', true], FIGHT_PROP_WATER_ADD_HURT: ['水伤加成', true],
  FIGHT_PROP_GRASS_ADD_HURT: ['草伤加成', true], FIGHT_PROP_ELEC_ADD_HURT: ['雷伤加成', true],
  FIGHT_PROP_WIND_ADD_HURT: ['风伤加成', true], FIGHT_PROP_ICE_ADD_HURT: ['冰伤加成', true],
  FIGHT_PROP_ROCK_ADD_HURT: ['岩伤加成', true]
};
// 部位顺序与游戏内面板一致：生之花 → 死之羽 → 时之沙 → 空之杯 → 理之冠
const GS_RELIC_SLOTS = ['EQUIP_BRACER', 'EQUIP_NECKLACE', 'EQUIP_SHOES', 'EQUIP_RING', 'EQUIP_DRESS'];
// 图标取不到时用它兜底占位，免得格子里是一片空白
const GS_RELIC_SHORT = { EQUIP_BRACER: '花', EQUIP_NECKLACE: '羽', EQUIP_SHOES: '沙', EQUIP_RING: '杯', EQUIP_DRESS: '冠' };
const GS_RELIC_NAME = { EQUIP_BRACER: '生之花', EQUIP_NECKLACE: '死之羽', EQUIP_SHOES: '时之沙', EQUIP_RING: '空之杯', EQUIP_DRESS: '理之冠' };

/** 主词条数值：接口对百分比有给小数(0.466)也有给百分数(46.6)的情况，用 1.5 当分界两种情况都能对上。 */
function fmtMainProp(id, v) {
  const spec = GS_MAIN_PROP[id];
  const val = num(v);
  if (spec && spec[1]) {
    const pct = val < 1.5 ? val * 100 : val;
    return `${pct.toFixed(1)}%`;
  }
  return String(Math.round(val));
}

/**
 * 副词条「强化命中」次数。
 * Enka 的 appendPropIdList 编码没公开（8 个 6 位数字，试了多种拆法都对不上），
 * 所以改用**数值反推**：5★ 副词条每档的取值就那么 4 个，用它们做「最少几条 roll 能凑出这个值」的搜索。
 * 实测校验过：茜特菈莉那件花（充能 16.8 / 爆伤 14 / 精通 16 / 暴击 7）= 3/2/1/2 条，
 * 总 roll 数 8 = appendPropIdList 的长度，自洽。
 */
const GS_ROLL_TIERS = {
  FIGHT_PROP_HP: [209, 239, 269, 299],
  FIGHT_PROP_ATTACK: [14, 16, 18, 19],
  FIGHT_PROP_DEFENSE: [16, 19, 21, 23],
  FIGHT_PROP_HP_PERCENT: [4.1, 4.7, 5.3, 5.8],
  FIGHT_PROP_ATTACK_PERCENT: [4.1, 4.7, 5.3, 5.8],
  FIGHT_PROP_DEFENSE_PERCENT: [5.1, 5.8, 6.6, 7.3],
  FIGHT_PROP_ELEMENT_MASTERY: [16, 19, 21, 23],
  FIGHT_PROP_CHARGE_EFFICIENCY: [4.5, 5.2, 5.8, 6.5],
  FIGHT_PROP_CRITICAL: [2.7, 3.1, 3.5, 3.9],
  FIGHT_PROP_CRITICAL_HURT: [5.4, 6.2, 7.0, 7.8]
};

function canSumTo(tiers, k, target, tol) {
  if (k === 0) return Math.abs(target) <= tol;
  for (const t of tiers) if (canSumTo(tiers, k - 1, target - t, tol)) return true;
  return false;
}

/** 返回「强化命中次数」（= 总 roll 数 - 1，第一档是初始词条）。算不出就返回 0。 */
function countRollHits(propId, value) {
  const tiers = GS_ROLL_TIERS[propId];
  const v = num(value);
  if (!tiers || !(v > 0)) return 0;
  const tol = 0.06 + v * 0.004;
  for (let k = 1; k <= 6; k++) {
    if (canSumTo(tiers, k, v, tol)) return Math.max(0, k - 1);
  }
  const avg = tiers.reduce((a, b) => a + b, 0) / tiers.length;
  return Math.max(0, Math.round(v / avg) - 1);
}
// 圣遗物按「最强套装的件数」给分：4 件套 = 满分（与 genshin-card 口径一致）
const GS_ART_SCORE = { 0: 0, 1: 4, 2: 8, 3: 13, 4: 20 };

// 星铁面板属性：接口里的字段名 → 面板上的中文标签（接口自带的 name 是「基础生命值」这类，面板上叫生命值更合适）
const SR_STAT_LABELS = {
  hp: '生命值', atk: '攻击力', def: '防御力', spd: '速度',
  crit_rate: '暴击率', crit_dmg: '暴击伤害', break_dmg: '击破特攻',
  effect_hit: '效果命中', effect_res: '效果抵抗', sp_rate: '能量恢复效率',
  heal_rate: '治疗量加成', real_hp: '生命值', real_atk: '攻击力', real_def: '防御力'
};
const SR_SKILL_TYPES = [['Normal', '普攻'], ['BPSkill', '战技'], ['Ultra', '终结技'], ['Talent', '天赋']];
// 遗器 6 个部位：1 头 / 2 手 / 3 躯干 / 4 脚 / 5 位面球 / 6 连结绳（图标取不到时兜底占位用）
const SR_RELIC_SHORT = { 1: '头', 2: '手', 3: '躯', 4: '脚', 5: '球', 6: '绳' };
const SR_RELIC_NAME = { 1: '头部', 2: '手部', 3: '躯干', 4: '脚部', 5: '位面球', 6: '连结绳' };
/**
 * 星铁图标源（按顺序尝试，运行期会按实测延迟自动重排 + 封禁坏源）。
 * 2026-10-16 本机实测：raw 808ms / gh-proxy 1016ms / fastly.jsdelivr 1970ms / ghfast 4862ms / gcore 6295ms；
 * cdn.jsdelivr、testingcf.jsdelivr、raw.gitmirror、ghproxy.net、ghproxy.cc、moeyy、kkgithub 均超时或报错，故不收录。
 * 放国内反代在前面：GitHub 直连一旦被墙，先试慢一点的镜像也比先等 9 秒超时强；
 * 直连可用时，第一次成功后会按实测延迟把 raw 自动挪到最前。
 */
const SR_ICON_BASES = [
  'https://gh-proxy.com/https://raw.githubusercontent.com/Mar-7th/StarRailRes/master/',
  'https://raw.githubusercontent.com/Mar-7th/StarRailRes/master/',
  'https://fastly.jsdelivr.net/gh/Mar-7th/StarRailRes@master/',
  'https://ghfast.top/https://raw.githubusercontent.com/Mar-7th/StarRailRes/master/',
  'https://gcore.jsdelivr.net/gh/Mar-7th/StarRailRes@master/'
];

/**
 * 原神素材源。实测（2026-10-16）：
 *   Yatta（gi.yatta.moe）—— 武器 / 头像 / 皮肤头像 / 立绘 全部命中，且快 3~8 倍（武器 713ms vs Enka 3692ms）；
 *                          但**完全没有圣遗物图标**（UI_RelicIcon_* 一律 404）。
 *   Enka（enka.network）—— 全都有，但慢，且容易被限速。
 * 所以两者互补：Yatta 打头阵，Enka 兜底。也查过 GitHub 上的原神全量素材仓库（forMyReason/GenshinTextures 已 DMCA 下架，
 * Zerite/genshin-assets 只有按英文套装名分类的少量图、没有 UI_* 游戏原名），所以原神这块没有可用的 GitHub 源。
 */
const GS_ASSET_BASES = ['https://gi.yatta.moe/assets/UI/', 'https://enka.network/ui/'];

/**
 * 素材源分组。关键区别在 stopOn404：
 *   · stopOn404=true —— 多个镜像指向**同一个仓库**，404 就是"这图真不存在"，不必浪费请求问下一个；
 *   · stopOn404=false —— 源之间**内容不同**（Yatta 缺圣遗物），404 只代表"这个源没有"，要继续问下一个源。
 */
const ASSET_GROUPS = {
  enka: { bases: GS_ASSET_BASES, stopOn404: false },
  srres: { bases: SR_ICON_BASES, stopOn404: true }
};

/* ── 配置 / 小工具 ─────────────────────────────────────────────────────────── */
function cfg() {
  const raw = (typeof api?.config === 'function' ? api.config() : null) || {};
  cacheDirOverride = String(raw.cacheDir ?? '').trim();
  const dg = ['genshin', 'starrail'].includes(String(raw.defaultGame)) ? String(raw.defaultGame) : 'ask';
  // app/classic 是 1.0.0 的旧值，1.0.1 起叫 portrait/landscape（竖版/横版），旧配置照样认
  const style = ['landscape', 'classic'].includes(String(raw.cardStyle)) ? 'landscape' : 'portrait';
  return {
    cardStyle: style,
    defaultGame: dg,
    adviceOnPanel: raw.adviceOnPanel !== false,
    showGearIcon: raw.showGearIcon !== false,
    theme: raw.theme === 'light' ? 'light' : 'dark',
    bgBlur: clamp(num(raw.bgBlur, 30), 0, 40),
    panelBlur: clamp(num(raw.panelBlur, 8), 0, 20),
    // 横版卡片本身不带 wiki 配装（版式放不下），可以额外发一张建议图
    landAdviceImage: raw.landAdviceImage !== false,
    rosterSort: ['cv', 'level', 'cons', 'hp', 'atk', 'def', 'er', 'crit'].includes(String(raw.rosterSort))
      ? String(raw.rosterSort) : 'cv'
  };
}

const num = (v, d = 0) => (Number.isFinite(Number(v)) ? Number(v) : d);
const clamp = (n, lo, hi) => Math.min(hi, Math.max(lo, n));
const escapeHtml = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const stars = (n) => '★'.repeat(clamp(Math.round(num(n)), 0, 5));
const fmtInt = (v) => Math.round(num(v)).toLocaleString('en-US');
const fmtPct = (v) => (num(v) * 100).toFixed(1) + '%';
const truncate = (s, n) => {
  const t = String(s ?? '').trim();
  return t.length > n ? t.slice(0, n - 1) + '…' : t;
};
/** 尽量在句号/分号处截断，别把一句话切一半（卡片上读起来更像人话）。 */
const truncateSmart = (s, n) => {
  const t = String(s ?? '').trim();
  if (t.length <= n) return t;
  const head = t.slice(0, n);
  const cut = Math.max(head.lastIndexOf('。'), head.lastIndexOf('；'), head.lastIndexOf('！'), head.lastIndexOf('？'));
  return cut >= n * 0.6 ? head.slice(0, cut + 1) : head.slice(0, n - 1) + '…';
};
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

/** 联网走 api.fetch（受 web_fetch 权限门禁，内含 SSRF 防护）；万一某版本没提供就退回全局 fetch。 */
const httpFetch = (...args) => (typeof api?.fetch === 'function' ? api.fetch(...args) : globalThis.fetch(...args));

function resolveGame(raw) {
  const s = String(raw ?? '').trim().toLowerCase();
  if (!s) return null;
  const list = Object.values(GAMES);
  for (const g of list) if (g.key === s || g.aliases.some((a) => a.toLowerCase() === s)) return g;
  for (const g of list) if (s.includes(g.key) || g.aliases.some((a) => s.includes(a.toLowerCase()))) return g;
  return null;
}

function gradeOf(total) {
  if (total >= 90) return { g: 'S', color: '#ffcc4d' };
  if (total >= 78) return { g: 'A', color: '#7ee787' };
  if (total >= 62) return { g: 'B', color: '#79c0ff' };
  if (total >= 45) return { g: 'C', color: '#d2a8ff' };
  return { g: 'D', color: '#8b95a7' };
}

/* ── 原神：取数与解析 ─────────────────────────────────────────────────────── */
async function fetchGenshin(uid) {
  const url = `https://enka.network/api/uid/${encodeURIComponent(uid)}`;
  let res;
  try {
    res = await httpFetch(url, {
      headers: { accept: 'application/json', 'user-agent': 'qq-agent-game-panel/1.0' },
      signal: AbortSignal.timeout(REQ_TIMEOUT_MS)
    });
  } catch (error) {
    return { error: `连不上 Enka.Network：${error?.message ?? error}` };
  }
  if (res.status === 404) return { error: `查不到 UID ${uid}：UID 不存在，或该玩家没有公开的角色展柜。` };
  if (res.status === 424) return { error: '数据源正在维护（Enka 返回 424），稍后再试。' };
  if (res.status === 429) return { error: '数据源限流了（429），等一分钟再查。' };
  if (!res.ok) return { error: `数据源返回 HTTP ${res.status}。` };
  const data = await res.json().catch(() => null);
  if (!data) return { error: '数据源返回的内容解析失败。' };
  return { data };
}

function parseGenshinCharacter(av) {
  const id = String(av.avatarId);
  const info = AVATARS[id] || {};
  const propMap = av.propMap || {};
  const level = num(propMap['4001']?.ival ?? propMap['4001']?.val, 0);
  const cons = Array.isArray(av.talentIdList) ? av.talentIdList.length : 0;

  const skills = [];
  for (const [sid, lvlRaw] of Object.entries(av.skillLevelMap || {})) {
    // 天赋类型：老角色查数据表里的映射；新角色（表里还没有的）按 id 尾号判定 ——
    // 实测 1=普通攻击、2=元素战技、5=元素爆发（如 11331/11332/11335）。
    let kind = (info.k && info.k[sid]) || '';
    if (!kind) {
      const last = String(sid).slice(-1);
      kind = last === '1' ? 'A' : (last === '2' ? 'S' : (last === '5' ? 'E' : ''));
    }
    // 命座加天赋等级是全局规则：C3 → 元素战技 +3，C5 → 元素爆发 +3。
    const bonus = (kind === 'S' && cons >= 3 ? 3 : 0) + (kind === 'E' && cons >= 5 ? 3 : 0);
    skills.push({ kind, label: GS_TALENT_LABEL[kind] || '天赋', base: num(lvlRaw), bonus });
  }
  const order = { A: 0, S: 1, E: 2 };
  skills.sort((a, b) => (order[a.kind] ?? 9) - (order[b.kind] ?? 9));

  const fp = av.fightPropMap || {};
  const stats = [];
  for (const [k, label, kind] of GS_STAT_ROWS) {
    const raw = fp[k];
    if (raw === undefined) continue;
    stats.push({ label, value: kind === 'pct' ? fmtPct(raw) : fmtInt(raw) });
  }
  const elemKey = GS_ELEM_DMG_KEY[info.e];
  if (elemKey && num(fp[elemKey]) > 0) stats.push({ label: '元素伤害加成', value: fmtPct(fp[elemKey]) });
  if (num(fp['30']) > 0) stats.push({ label: '物理伤害加成', value: fmtPct(fp['30']) });

  let weapon = null;
  const setCounts = new Map();
  const relics = [];
  for (const eq of Array.isArray(av.equipList) ? av.equipList : []) {
    const itemType = String(eq?.flat?.itemType || '');
    if (itemType === 'ITEM_WEAPON' && !weapon) {
      const affix = eq?.weapon?.affixMap ? Object.values(eq.weapon.affixMap)[0] : 0;
      const dbw = WEAPONS[String(eq.itemId)] || null;
      weapon = {
        name: dbw?.n || String(eq?.flat?.name || ''),
        level: num(eq?.weapon?.level, 0),
        refine: num(affix, 0) + 1,
        stars: num(dbw?.r ?? eq?.flat?.rankLevel, 0),
        img: { kind: 'enka', ref: String(dbw?.i || eq?.flat?.icon || '').replace(/\.png$/, '') },
        // 武器面板：基础攻击力 + 副属性（v2 卡片用来画「基础攻击力 542 · 元素精通 265」）
        stats: (Array.isArray(eq?.flat?.weaponStats) ? eq.flat.weaponStats : []).slice(0, 2).map((st) => ({
          label: (GS_MAIN_PROP[st.appendPropId] || [String(st.appendPropId || '')])[0],
          value: fmtMainProp(st.appendPropId, st.statValue)
        }))
      };
    } else if (itemType === 'ITEM_RELIQUARY') {
      const sid = String(eq?.flat?.setId ?? '');
      if (sid && sid !== 'undefined') setCounts.set(sid, (setCounts.get(sid) || 0) + 1);
      // 圣遗物明细：图标名接口直接给（flat.icon），主词条给 mainPropId + statValue
      // ⚠️ Enka 的 reliquary.level **从 1 起计**：游戏里 +20 满级它报 21、+0 它报 1。
      //    证据①：报 21 的那几件，主词条数值正好是 +20 的硬上限（花 4780 / 羽 311 / 攻击% 46.6% / 暴击率 31.1%）——
      //          真要是 +21，数值必然超过上限。
      //    证据②：报 1 的那件是「5★ 生命值% = 7%」+ 只有 4 条副词条，正是官方 +0 的样子。
      //    武器等级和角色等级没有这个偏移（满级 90 就报 90），只有圣遗物这一项要减 1。
      const main = eq?.flat?.reliquaryMainstat || {};
      relics.push({
        slot: String(eq?.flat?.equipType || ''),
        slotShort: GS_RELIC_SHORT[String(eq?.flat?.equipType || '')] || '',
        slotName: GS_RELIC_NAME[String(eq?.flat?.equipType || '')] || '',
        icon: { kind: 'enka', ref: String(eq?.flat?.icon || '') },
        set: RELIQUARY[sid] || '',
        mainLabel: (GS_MAIN_PROP[main.mainPropId] || [String(main.mainPropId || '主词条')])[0],
        mainValue: fmtMainProp(main.mainPropId, main.statValue),
        // 副词条（v2 卡片的圣遗物卡片会逐条列出来）
        substats: (Array.isArray(eq?.flat?.reliquarySubstats) ? eq.flat.reliquarySubstats : []).slice(0, 4).map((st) => ({
          label: (GS_MAIN_PROP[st.appendPropId] || [String(st.appendPropId || '')])[0],
          value: fmtMainProp(st.appendPropId, st.statValue),
          hits: countRollHits(st.appendPropId, st.statValue)
        })),
        level: Math.max(0, num(eq?.reliquary?.level, 1) - 1),
        rarity: num(eq?.flat?.rankLevel, 0)
      });
    }
  }
  relics.sort((a, b) => GS_RELIC_SLOTS.indexOf(a.slot) - GS_RELIC_SLOTS.indexOf(b.slot));
  const sets = [...setCounts.entries()]
    .map(([sid, n]) => ({ name: RELIQUARY[sid] || `套装#${sid}`, n }))
    .sort((a, b) => b.n - a.n);

  // 五维评分（满分 100）：等级 25 + 命座 15 + 武器 15 + 天赋 25 + 圣遗物 20（4 件套即满分）
  const lvScore = (Math.min(level, 90) / 90) * 25;
  const consScore = (Math.min(cons, 6) / 6) * 15;
  const talSum = skills.reduce((a, s) => a + Math.min(s.base + s.bonus, 13), 0);
  const talScore = Math.min(talSum / 30, 1) * 25;
  const wpScore = weapon ? (Math.min(weapon.level, 90) / 90) * 9 + (Math.min(weapon.refine, 5) / 5) * 6 : 0;
  const artTop = sets.reduce((m, x) => Math.max(m, x.n), 0);
  const gearScore = GS_ART_SCORE[Math.min(artTop, 4)] ?? 0;
  const total = lvScore + consScore + talScore + wpScore + gearScore;

  const el = GS_ELEMENTS[info.e] || GS_ELEMENTS.None;
  const qStars = { SUPER_RARE: 5, RARE: 4, ORANGE: 5, PURPLE: 4, BLUE: 3 }[String(info.q || '').replace('QUALITY_', '')] || 4;
  const icon = info.i || '';
  const iconBase = icon.replace(/^UI_AvatarIcon_/, '');

  return {
    id,
    name: info.n || `未知角色#${id}`,
    img: {
      icon: { kind: 'enka', ref: icon },
      splash: { kind: 'enka', ref: icon ? icon.replace(/^UI_AvatarIcon_/, 'UI_Gacha_AvatarImg_') : '' }
    },
    // 皮肤：接口只给数字 costumeId（如 210701），素材名要用 Enka 页面里的 CostumeXxx 后缀，
    // 解析在 genshinPanel 里补齐（resolveCostume）；缺省就是默认皮肤的高清抽卡立绘。
    costumeId: num(av.costumeId, 0) || 0,
    costumeAsset: null,
    iconBase,
    artRef: icon ? icon.replace(/^UI_AvatarIcon_/, 'UI_Gacha_AvatarImg_') : '',
    artMode: 'splash',
    gameKey: 'genshin',
    elementAttrIdx: GS_ELEMENT_ATTR[info.e] || 0,
    // 已激活命座的 talentId（和 Yatta 的 constellation[].talentId 精确比对，决定点亮哪几个）
    consTalentIds: (Array.isArray(av.talentIdList) ? av.talentIdList : []).map((x) => num(x)),
    elementName: el.name,
    elementColor: el.color,
    subLabel: GS_WEAPON_CN[info.w] || '',
    rarityStars: qStars,
    level,
    cons,
    consLabel: '命座',
    gearLabel: '精炼',
    sectionLabels: { talent: '天赋等级', gear: '武器', sets: '圣遗物' },
    chips: [{ label: '等级', value: `Lv.${level}` }, { label: '命座', value: `${cons} 命` }, { label: '天赋', value: `${talSum}/30` }],
    stats,
    talents: skills.map((s) => ({ label: s.label, main: String(s.base + s.bonus), sub: s.bonus ? `+${s.bonus}` : '' })),
    // 技能图标：普攻是通用图（Skill_A_01），战技/爆发按角色图标名拼（Skill_S_<名>_01 / Skill_E_<名>_01）
    skillIcons: skills.map((s) => ({
      label: s.label,
      level: s.base + s.bonus,
      sub: s.bonus ? `+${s.bonus}` : '',
      img: {
        kind: 'enka',
        ref: s.kind === 'A' ? 'Skill_A_01'
          : (s.kind === 'S' ? `Skill_S_${iconBase}_01`
            : (s.kind === 'E' ? `Skill_E_${iconBase}_01` : ''))
      }
    })),
    weapon,
    sets,
    relics,
    score: {
      total,
      dims: [
        { label: '等级', score: lvScore, max: 25, color: '#4cc9f0' },
        { label: '命座', score: consScore, max: 15, color: '#ffcc4d' },
        { label: '武器', score: wpScore, max: 15, color: '#7ee787' },
        { label: '天赋', score: talScore, max: 25, color: '#d2a8ff' },
        { label: '圣遗物', score: gearScore, max: 20, color: '#ffa657' }
      ],
      note: `等级 25 + 命座 15 + 武器 15 + 天赋 25 + 圣遗物 20 = 100（圣遗物 4 件套即满分）｜ S≥90 A≥78 B≥62 C≥45`,
      gearDetail: `${artTop} 件套`
    }
  };
}

async function genshinPanel(uid) {
  const got = await fetchGenshin(uid);
  if (got.error) return { error: got.error };
  const data = got.data;
  const list = Array.isArray(data.avatarInfoList) ? data.avatarInfoList : [];
  if (!list.length) {
    return {
      error: `UID ${uid}（${data.playerInfo?.nickname || '未知'}）读不到角色数据：对方**没开角色展柜**`
        + '（游戏内：设置 → 其他 → 展示柜，把要展示的角色放上去），或者展柜里没有角色。'
    };
  }
  const player = {
    uid,
    nickname: String(data.playerInfo?.nickname || ''),
    meta: data.playerInfo?.level ? `冒险等阶 ${num(data.playerInfo.level)}` : '',
    source: GAMES.genshin.source
  };
  const characters = list.map(parseGenshinCharacter).sort((a, b) => b.score.total - a.score.total);
  await resolveCostumes(uid, characters);
  return { player, characters };
}

/* ── 皮肤：costumeId（数字）→ 素材名（如 CitlaliCostumeXia）───────────────
 * Enka 的接口只给数字 costumeId，素材名却是 `UI_AvatarIcon_<角色><CostumeXxx>`。
 * 这层映射没在接口里，但**Enka 的角色页 HTML 里正好带着**：
 *   <figure style="background-image: url(/ui/UI_AvatarIcon_Side_CitlaliCostumeXia.png)">
 * 所以按「基础名 + Costume 前缀」去匹配即可，不依赖顺序，也不用维护映射表。
 * 代价：只有当有人穿了皮肤时才多请求一次页面（192KB），并按 UID 缓存 10 分钟。
 * ⚠️ 皮肤没有高清抽卡立绘（UI_Gacha_AvatarImg_*Costume* 全是 404），
 *    所以皮肤版只能退用 256×256 头像（RGBA，带透明通道，放深色卡上不会出现白底方块）。
 */
const costumeCache = new Map();          // uid -> { at, map: Map<基础名, 皮肤素材名> }
const COSTUME_CACHE_MS = 10 * 60 * 1000;

async function fetchCostumeMap(uid, baseNames) {
  const map = new Map();
  try {
    const res = await httpFetch(`https://enka.network/u/${encodeURIComponent(uid)}/`, {
      headers: { 'user-agent': 'qq-agent-game-panel/1.0', accept: 'text/html' },
      signal: AbortSignal.timeout(REQ_TIMEOUT_MS)
    });
    if (!res.ok) return map;
    const html = await res.text();
    const names = [...new Set((html.match(/\/ui\/UI_AvatarIcon_Side_[A-Za-z0-9_]+\.png/g) || [])
      .map((s) => s.replace(/^\/ui\/UI_AvatarIcon_Side_/, '').replace(/\.png$/, '')))];
    for (const base of baseNames) {
      if (!base) continue;
      const hit = names.find((n) => n !== base && n.startsWith(`${base}Costume`));
      if (hit) map.set(base, hit);
    }
  } catch { /* 拉不到就算了，退回默认立绘，不影响出卡 */ }
  return map;
}

/** 给穿了皮肤的角色挂上皮肤信息。
 *  注意：**主立绘仍然用默认皮肤的高清抽卡立绘**（2048×1024 好看），
 *  皮肤本身只在角落挂一个小头像做标识 —— 因为游戏里没有"皮肤的高清立绘"这个文件，
 *  把 256 头像放大当主图会很空。 */
async function resolveCostumes(uid, characters) {
  const withCostume = characters.filter((c) => c.costumeId && c.iconBase);
  if (!withCostume.length) return;
  const cached = costumeCache.get(uid);
  let map = cached && Date.now() - cached.at < COSTUME_CACHE_MS ? cached.map : null;
  if (!map) {
    map = await fetchCostumeMap(uid, withCostume.map((c) => c.iconBase));
    costumeCache.set(uid, { at: Date.now(), map });
  }
  for (const c of withCostume) {
    const asset = map.get(c.iconBase);
    if (!asset) continue;
    c.costumeAsset = asset;
    c.costumeImg = { kind: 'enka', ref: `UI_AvatarIcon_${asset}` };
  }
}

/* ── 星铁：取数与解析 ─────────────────────────────────────────────────────── */
async function fetchStarRail(uid) {
  const url = `https://api.mihomo.me/sr_info_parsed/${encodeURIComponent(uid)}?lang=chs`;
  let res;
  try {
    res = await httpFetch(url, {
      headers: { accept: 'application/json', 'user-agent': 'qq-agent-game-panel/1.0' },
      signal: AbortSignal.timeout(REQ_TIMEOUT_MS)
    });
  } catch (error) {
    return { error: `连不上 api.mihomo.me：${error?.message ?? error}` };
  }
  const body = await res.json().catch(() => null);
  if (res.status === 400) return { error: `UID「${uid}」不合法：星铁 UID 是 9 位数字（例如 101000001）。` };
  if (res.status === 404) return { error: `查不到 UID ${uid}：UID 不存在，或该玩家没公开角色数据（游戏内：设置 → 其他 → 展示设置）。` };
  if (res.status === 429) return { error: '数据源限流了（429），等一分钟再查。' };
  if (!res.ok) return { error: `数据源返回 HTTP ${res.status}${body?.detail ? `（${body.detail}）` : ''}。` };
  if (!body?.player) return { error: `数据源没返回玩家数据${body?.detail ? `（${body.detail}）` : ''}。` };
  return { data: body };
}

function parseStarRailCharacter(c) {
  const skills = [];
  for (const [type, label] of SR_SKILL_TYPES) {
    // 接口的 skills 里会混进忆灵技能与重复项，按 type 取第一个即可（普攻/战技/终结技/天赋各一个）
    const hit = (Array.isArray(c.skills) ? c.skills : []).find((s) => s?.type === type);
    if (!hit) continue;
    skills.push({ label, level: num(hit.level), max: num(hit.max_level, 10), icon: String(hit.icon || '') });
  }
  const stats = [];
  const seen = new Set();
  for (const s of Array.isArray(c.statistics) ? c.statistics : []) {
    const label = SR_STAT_LABELS[s?.field] || String(s?.name || s?.field || '');
    if (!label || seen.has(label)) continue;
    seen.add(label);
    stats.push({ label, value: String(s?.display ?? s?.value ?? '') });
  }

  const seenSets = new Map();
  const relics = [];
  for (const r of Array.isArray(c.relics) ? c.relics : []) {
    const name = String(r?.set_name || '').trim();
    if (!name) continue;
    seenSets.set(name, (seenSets.get(name) || 0) + 1);
    // 遗器明细：接口已经给好图标路径（icon/relic/...）和主词条中文显示值
    relics.push({
      slot: String(r?.type ?? ''),
      slotShort: SR_RELIC_SHORT[num(r?.type)] || '',
      slotName: SR_RELIC_NAME[num(r?.type)] || '',
      icon: { kind: 'srres', ref: String(r?.icon || '') },
      set: name,
      mainLabel: String(r?.main_affix?.name || ''),
      mainValue: String(r?.main_affix?.display || ''),
      substats: (Array.isArray(r?.sub_affix) ? r.sub_affix : []).slice(0, 4).map((x) => ({
        label: String(x?.name || ''),
        value: String(x?.display ?? x?.value ?? ''),
        // 星铁接口的 count 是**总 roll 数**（初始那一条也算），和原神的口径统一成「额外命中次数」要减 1
        hits: Math.max(0, num(x?.count, 0) - 1)
      })),
      level: num(r?.level, 0),
      rarity: num(r?.rarity, 0)
    });
  }
  relics.sort((a, b) => num(a.slot) - num(b.slot));
  const sets = [...seenSets.entries()].map(([name, n]) => ({ name, n })).sort((a, b) => b.n - a.n);

  const lc = c.light_cone || null;
  const weapon = lc ? {
    name: String(lc.name || ''),
    level: num(lc.level),
    refine: num(lc.rank, 1),
    stars: num(lc.rarity),
    img: { kind: 'srres', ref: String(lc.icon || '') },
    stats: (Array.isArray(lc.attributes) ? lc.attributes : []).slice(0, 2).map((a) => ({
      label: String(a?.name || ''),
      value: String(a?.display ?? a?.value ?? '')
    }))
  } : null;

  // 五维评分（满分 100）：等级 25 + 星魂 15 + 光锥 15 + 行迹 25 + 遗器 20
  const level = num(c.level);
  const rank = num(c.rank);
  const lvScore = (Math.min(level, 80) / 80) * 25;
  const consScore = (Math.min(rank, 6) / 6) * 15;
  const wpScore = weapon ? (Math.min(weapon.level, 80) / 80) * 9 + (Math.min(weapon.refine, 5) / 5) * 6 : 0;
  const talRatio = skills.length ? skills.reduce((a, s) => a + Math.min(s.max > 0 ? s.level / s.max : 0, 1), 0) / skills.length : 0;
  const talScore = talRatio * 25;
  const relicList = Array.isArray(c.relics) ? c.relics : [];
  const relicLvSum = relicList.reduce((a, r) => a + Math.min(num(r?.level), 15) / 15, 0);
  const gearScore = (relicLvSum / 6) * 20;   // 6 个部位全 15 级 = 满分
  const total = lvScore + consScore + talScore + wpScore + gearScore;
  const talSum = skills.reduce((a, s) => a + s.level, 0);
  const talMax = skills.reduce((a, s) => a + s.max, 0);
  const fullRelics = relicList.filter((r) => num(r?.level) >= 15).length;

  const el = c.element || {};
  return {
    id: String(c.id || ''),
    name: String(c.name || `未知角色#${c.id}`),
    img: {
      icon: { kind: 'srres', ref: String(c.icon || '') },
      splash: { kind: 'srres', ref: String(c.preview || c.portrait || c.icon || '') }
    },
    gameKey: 'starrail',
    elementAttrIdx: SR_ELEMENT_ATTR[String(el.id || '')] || 0,
    rankIcons: Array.isArray(c.rank_icons) ? c.rank_icons.map(String) : [],
    elementName: String(el.name || ''),
    elementColor: String(el.color || '#98a2b3'),
    subLabel: String(c.path?.name || ''),
    rarityStars: num(c.rarity),
    level,
    cons: rank,
    consLabel: '星魂',
    gearLabel: '叠影',
    sectionLabels: { talent: '行迹 / 技能等级', gear: '光锥', sets: '遗器' },
    chips: [{ label: '等级', value: `Lv.${level}` }, { label: '星魂', value: `${rank} 魂` }, { label: '行迹', value: `${talSum}/${talMax}` }],
    stats,
    talents: skills.map((s) => ({ label: s.label, main: String(s.level), sub: `/${s.max}` })),
    // 技能图标：接口直接给路径（icon/skill/...）
    skillIcons: skills.map((k) => ({
      label: k.label,
      level: k.level,
      sub: '',
      img: { kind: 'srres', ref: k.icon }
    })),
    weapon,
    sets,
    relics,
    score: {
      total,
      dims: [
        { label: '等级', score: lvScore, max: 25, color: '#4cc9f0' },
        { label: '星魂', score: consScore, max: 15, color: '#ffcc4d' },
        { label: '光锥', score: wpScore, max: 15, color: '#7ee787' },
        { label: '行迹', score: talScore, max: 25, color: '#d2a8ff' },
        { label: '遗器', score: gearScore, max: 20, color: '#ffa657' }
      ],
      note: `等级 25 + 星魂 15 + 光锥 15 + 行迹 25 + 遗器 20 = 100（六件遗器全 15 级即满分）｜ S≥90 A≥78 B≥62 C≥45`,
      gearDetail: `${fullRelics}/${relicList.length || 6} 满级`
    }
  };
}

async function starrailPanel(uid) {
  const got = await fetchStarRail(uid);
  if (got.error) return { error: got.error };
  const data = got.data;
  const list = Array.isArray(data.characters) ? data.characters : [];
  if (!list.length) {
    return { error: `UID ${uid}（${data.player?.nickname || '未知'}）读不到角色数据：对方可能关掉了角色展示，或没有任何公开角色。` };
  }
  const player = {
    uid: String(data.player?.uid || uid),
    nickname: String(data.player?.nickname || ''),
    meta: data.player?.level ? `开拓等级 ${num(data.player.level)}${data.player.world_level ? ` · 均衡等级 ${num(data.player.world_level)}` : ''}` : '',
    source: GAMES.starrail.source
  };
  const characters = list.map(parseStarRailCharacter).sort((a, b) => b.score.total - a.score.total);
  return { player, characters };
}

/* ── 图标 → data URI（离线窗口里不能指望它联网，必须内联）───────────────────── */
const imgCache = new Map();
const IMG_TIMEOUT_MS = 9000;
const SPLASH_TIMEOUT_MS = 20000;         // 抽卡立绘 1.5~2.5MB，给宽一点；取不到就退头像（不裁）
const RELIC_TIMEOUT_MS = 12000;          // 圣遗物图标只有 Enka 有，实测偶发 7s+，9 秒会误杀
// 图标/立绘磁盘缓存：一旦取到就落盘，重启后不用再等 Enka（"偶尔空白"主要是 Enka 慢/限速）
// ⚠️ 默认放**安装目录的 data/cache 下**，不放 %TEMP%（会被系统清理掉），也不能放 skills/ 里
//    （这个技能要上传，包体积不能超 30MB，缓存是运行时数据）
const DEFAULT_CACHE_DIR = (() => {
  const env = String(process.env.QQ_AGENT_DATA_DIR || '').trim();
  if (env) return path.join(env, 'cache', 'game-panel');
  // skills/game-panel → 往上四层就是安装根目录（…/QQ Agent），数据都放它的 data/ 下
  return path.resolve(DIR, '../../../../data/cache/game-panel');
})();
let cacheDirOverride = '';
const cacheDir = () => cacheDirOverride || DEFAULT_CACHE_DIR;
const BASE_BAN_MS = 20 * 60 * 1000;      // 坏源封 20 分钟，之后自动再试
const BASE_FAIL_LIMIT = 2;               // 连续失败几次就封
const BASE_UNKNOWN_MS = 6000;            // 没测过的源按 6 秒估，排在中游
const baseStats = new Map([...GS_ASSET_BASES, ...SR_ICON_BASES].map((b) => [b, { ok: 0, fail: 0, avgMs: 0, banUntil: 0 }]));

/** 某个素材组的源，按实测延迟排序（快的在前），跳过被封禁的；全被封了就都试一遍用于恢复。 */
function orderedBases(group = 'srres') {
  const bases = ASSET_GROUPS[group]?.bases || [];
  const now = Date.now();
  const all = bases.map((b) => ({ b, s: baseStats.get(b) || { ok: 0, fail: 0, avgMs: 0, banUntil: 0 } }));
  const alive = all.filter((x) => x.s.banUntil <= now);
  const pool = alive.length ? alive : all;
  return pool.sort((x, y) => (x.s.avgMs || BASE_UNKNOWN_MS) - (y.s.avgMs || BASE_UNKNOWN_MS)).map((x) => x.b);
}

/** 记录一次取图结果：成功的源按延迟做滑动平均，失败的源累计到封禁。 */
function markBase(base, okFlag, ms = 0) {
  const s = baseStats.get(base);
  if (!s) return;
  if (okFlag) {
    s.ok += 1;
    s.fail = 0;
    s.avgMs = s.avgMs ? Math.round(s.avgMs * 0.6 + ms * 0.4) : ms;
    s.banUntil = 0;
    return;
  }
  s.fail += 1;
  if (s.fail >= BASE_FAIL_LIMIT) { s.banUntil = Date.now() + BASE_BAN_MS; s.fail = 0; s.avgMs = 0; }
}

/**
 * 取一张图并内联成 data URI。
 * 多源兜底 + 健康度自管理：
 *   · 404 = 文件本身不存在，换源也没用 → 立刻放弃（不冤枉任何源）
 *   · 超时 / 连不上 / 5xx / 200 但不是图片（反代返回的 HTML 错误页）→ 记这个源一次失败
 *   · 失败结果不缓存：网络恢复后下一次还能补上，不会"进程活着就永远缺图"
 */
async function loadImg(img, minBytes = 200, timeoutMs = IMG_TIMEOUT_MS) {
  if (!img?.ref) return '';
  const group = ASSET_GROUPS[img.kind] || ASSET_GROUPS.srres;
  const key = `${img.kind}:${img.ref}:${minBytes}`;
  if (imgCache.has(key)) return imgCache.get(key);
  // 磁盘缓存命中直接返回：图标是一次性资产，没必要每次出卡都去问 Enka
  const onDisk = readIconFromDisk(img, minBytes);
  if (onDisk) { imgCache.set(key, onDisk); return onDisk; }
  // 原神的 ref 是素材名（要补 .png 并转义）；星铁的 ref 是仓库里的相对路径（自带宽斜杠，原样拼）
  const suffix = img.kind === 'enka' ? `${encodeURIComponent(img.ref)}.png` : String(img.ref).replace(/^\/+/, '');
  const tries = orderedBases(img.kind).map((b) => ({ url: b + suffix, base: b }));
  let uri = '';
  for (const { url, base } of tries) {
    const t0 = Date.now();
    try {
      const res = await httpFetch(url, {
        headers: { 'user-agent': 'qq-agent-game-panel/1.0', accept: 'image/*' },
        signal: AbortSignal.timeout(timeoutMs)
      });
      // 404：镜像同仓库时说明"真没有"，直接放弃；源之间内容不同时（Yatta 缺圣遗物）要接着问下一个源
      if (res.status === 404) { if (group.stopOn404) break; continue; }
      const type = String(res.headers.get('content-type') || '');
      if (!res.ok || (type && !type.includes('image'))) { markBase(base, false); continue; }
      const buf = Buffer.from(await res.arrayBuffer());
      if (buf.length <= minBytes) { markBase(base, false); continue; }
      markBase(base, true, Date.now() - t0);
      uri = `data:image/png;base64,${buf.toString('base64')}`;
      writeIconToDisk(img, await shrinkForCache(buf));
      break;
    } catch { markBase(base, false); }
  }
  if (uri) imgCache.set(key, uri);
  return uri;
}

/** 图标/立绘磁盘缓存（文件名按 kind+ref 生成；目录可在设置里改）。 */
function iconCachePath(img) {
  const safe = String(img.ref).replace(/[^A-Za-z0-9_.-]/g, '_').slice(0, 120);
  return path.join(cacheDir(), `${img.kind}__${safe}.png`);
}

function readIconFromDisk(img, minBytes) {
  try {
    const buf = fs.readFileSync(iconCachePath(img));
    if (buf.length > minBytes && buf[0] === 0x89) return `data:image/png;base64,${buf.toString('base64')}`;
  } catch { /* 没有缓存，正常走网络 */ }
  return '';
}

function writeIconToDisk(img, buf) {
  try {
    fs.mkdirSync(cacheDir(), { recursive: true });
    fs.writeFileSync(iconCachePath(img), buf);
  } catch { /* 写不进去就只靠内存缓存，不影响出卡 */ }
}

/**
 * 立绘（2MB 级的 PNG）落盘前缩小到 1400px 宽：卡片最宽 1180px，够用，单张从 ~2MB 降到 ~400KB。
 * 用 Electron 自带的 nativeImage，不引第三方库；拿不到 Electron 就原样存。
 */
async function shrinkForCache(buf) {
  if (buf.length < 500 * 1024) return buf;
  try {
    const mod = await import('electron');
    const el = mod?.default ?? mod;
    const img = el?.nativeImage?.createFromBuffer?.(buf);
    if (!img || img.isEmpty()) return buf;
    const { width } = img.getSize();
    if (width <= 1400) return buf;
    const small = img.resize({ width: 1400, quality: 'good' }).toPNG();
    return small && small.length && small.length < buf.length ? small : buf;
  } catch { return buf; }
}

/** 本地元素图标 → data URI（离线窗口不能外链，必须内联）。同步读，文件很小。 */
function readAttrIcon(gameKey, idx) {
  const dir = ATTR_ICON_DIR[gameKey];
  if (!dir || !idx) return '';
  const key = `${dir}:${idx}`;
  if (attrIconCache.has(key)) return attrIconCache.get(key);
  let uri = '';
  try {
    const buf = fs.readFileSync(path.join(DATA_DIR, 'attr', dir, `${idx}.png`));
    if (buf.length > 200) uri = `data:image/png;base64,${buf.toString('base64')}`;
  } catch { /* 没有这张图就画文字标签 */ }
  attrIconCache.set(key, uri);
  return uri;
}

/* ── 命座 ──────────────────────────────────────────────────────────────────
 * 原神：命座图标名（UI_Talent_S_<名>_0X / U_<名>_0X）**无法从文件名推出顺序**（S/U 段是按"加成哪个技能"分的），
 * 所以从 Yatta 的角色详情接口取权威顺序（它直接给 6 条，含 talentId 与 icon）。
 * 激活判定用 talentId 精确比对 Enka 的 talentIdList —— 比"前 N 个"准（万一有跳级的异常数据）。
 * 星铁：mihomo 的 rank_icons 本来就是 6 个星魂图标，按 order 前 N 个点亮。
 */
const consCache = new Map();

async function fetchGenshinConstellations(avatarId) {
  const key = String(avatarId || '');
  if (!key) return [];
  if (consCache.has(key)) return consCache.get(key);
  let out = [];
  try {
    const res = await httpFetch(`https://gi.yatta.moe/api/v2/chs/avatar/${encodeURIComponent(key)}`, {
      headers: { accept: 'application/json', 'user-agent': 'qq-agent-game-panel/1.0' },
      signal: AbortSignal.timeout(REQ_TIMEOUT_MS)
    });
    if (res.ok) {
      const j = await res.json().catch(() => null);
      const c = j?.data?.constellation;
      if (c && typeof c === 'object') {
        out = Object.values(c)
          .sort((a, b) => num(a?.id, 0) - num(b?.id, 0))
          .map((x) => ({ icon: String(x?.icon || ''), name: String(x?.name || ''), talentId: num(x?.talentId, 0) }))
          .filter((x) => x.icon);
      }
    }
  } catch { /* 拿不到就退化成"只显示命座数" */ }
  consCache.set(key, out);
  return out;
}

/** 给角色挂上命座列表（含亮/暗）。失败就当没有，卡片照常出。 */
async function attachConstellations(char) {
  if (!char || char.constellations) return char;
  try {
    if (char.gameKey === 'genshin') {
      const list = await fetchGenshinConstellations(char.id);
      if (!list.length) return char;
      const active = new Set((char.consTalentIds || []).map(Number));
      const useIds = active.size > 0;
      char.constellations = list.map((c, i) => ({
        index: i + 1,
        name: c.name,
        img: { kind: 'enka', ref: c.icon },
        active: useIds ? active.has(Number(c.talentId)) : i < char.cons
      }));
    } else {
      const icons = char.rankIcons || [];
      if (!icons.length) return char;
      char.constellations = icons.slice(0, 6).map((ref, i) => ({
        index: i + 1,
        name: '',
        img: { kind: 'srres', ref },
        active: i < char.cons
      }));
    }
  } catch { /* 命座拿不到不影响主流程 */ }
  return char;
}

/* ── Wiki：wikitext → 配装建议 ────────────────────────────────────────────── */
const ADVICE_MAP = {
  genshin: {
    template: '简易配装',
    setGroups: [{ label: '圣遗物', keys: ['圣遗物1', '圣遗物2', '圣遗物3'], descKeys: ['圣遗物描述1', '圣遗物描述2', '圣遗物描述3'] }],
    stats: [['沙', '沙'], ['杯', '杯'], ['头', '头']],
    subStatsKey: '副词条',
    weaponGroups: [
      { label: '毕业武器', keys: ['毕业武器', '毕业武器2', '毕业武器3'], descKeys: ['毕业武器描述', '毕业武器描述2', '毕业武器描述3'] },
      { label: '可选武器', keys: ['可选武器1', '可选武器2', '可选武器3'], descKeys: ['可选武器描述1', '可选武器描述2', '可选武器描述3'] }
    ],
    tips: [['技能加点', '技能升级推荐']]
  },
  starrail: {
    template: '角色/配装推荐/简表',
    setGroups: [
      { label: '隧洞遗器', keys: ['隧洞遗器1', '隧洞遗器2', '隧洞遗器3'], descKeys: ['隧洞遗器描述1', '隧洞遗器描述2', '隧洞遗器描述3'] },
      { label: '位面饰品', keys: ['位面饰品1', '位面饰品2', '位面饰品3'], descKeys: ['位面饰品描述1', '位面饰品描述2', '位面饰品描述3'] }
    ],
    stats: [['躯干', '躯干'], ['脚部', '脚部'], ['位面球', '位面球'], ['连结绳', '连结绳']],
    subStatsKey: '副词条',
    weaponGroups: [
      { label: '毕业光锥', keys: ['毕业光锥', '毕业光锥2', '毕业光锥3'], descKeys: ['毕业光锥描述', '毕业光锥描述2', '毕业光锥描述3'] },
      { label: '可选光锥', keys: ['可选光锥1', '可选光锥2', '可选光锥3'], descKeys: ['可选光锥描述1', '可选光锥描述2', '可选光锥描述3'] }
    ],
    tips: [['词条理由', '词条推荐理由']]
  }
};

const escapeRe = (s) => String(s).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

/** 按「顶层」分隔符切分（{{}} 与 [[]] 内部的 | 不算分隔）。 */
function splitTopLevel(src, sep = '|') {
  const out = [];
  let depth = 0;
  let buf = '';
  const s = String(src ?? '');
  for (let i = 0; i < s.length; i++) {
    const two = s.slice(i, i + 2);
    if (two === '{{' || two === '[[') { depth++; buf += two; i++; continue; }
    if (two === '}}' || two === ']]') { depth = Math.max(0, depth - 1); buf += two; i++; continue; }
    if (s[i] === sep && depth === 0) { out.push(buf); buf = ''; continue; }
    buf += s[i];
  }
  out.push(buf);
  return out;
}

/** 取出 wikitext 里第一个 `{{name ...}}` 的模板体（花括号配平；注释先剥掉，否则注释里的 | 会把参数切碎）。 */
function findTemplateBody(wikitext, name) {
  const src = String(wikitext || '').replace(/<!--[\s\S]*?-->/g, '');
  const re = new RegExp(`\\{\\{\\s*${escapeRe(name)}`);
  const m = re.exec(src);
  if (!m) return '';
  let depth = 0;
  for (let p = m.index; p < src.length - 1; p++) {
    const two = src.slice(p, p + 2);
    if (two === '{{') { depth++; p++; continue; }
    if (two === '}}') { depth--; p++; if (depth === 0) return src.slice(m.index + 2, p - 1); continue; }
  }
  return '';
}

/** 模板体 → 命名参数表（位置参数忽略）。 */
function parseTemplateParams(body) {
  const params = {};
  for (const part of splitTopLevel(body, '|').slice(1)) {
    // 只认顶层第一个 = 作为键值分隔（值里的嵌套模板可能自带参数，但已在 depth 内，不会被切到这里）
    let depth = 0;
    let eq = -1;
    for (let i = 0; i < part.length; i++) {
      const two = part.slice(i, i + 2);
      if (two === '{{' || two === '[[') { depth++; i++; continue; }
      if (two === '}}' || two === ']]') { depth = Math.max(0, depth - 1); i++; continue; }
      if (part[i] === '=' && depth === 0) { eq = i; break; }
    }
    if (eq < 0) continue;
    const k = part.slice(0, eq).trim();
    const v = part.slice(eq + 1).trim();
    if (k) params[k] = v;
  }
  return params;
}

/** 把 wiki 标记洗成人话：{{图标|圣遗物|追忆之注连|||4件套}} → 追忆之注连 4件套。 */
function unwrapWiki(raw) {
  let t = String(raw ?? '').replace(/<!--[\s\S]*?-->/g, '');
  for (let pass = 0; pass < 8; pass++) {
    const before = t;
    t = t.replace(/\{\{([^{}]*)\}\}/g, (_m, inner) => {
      const parts = String(inner).split('|').map((x) => x.trim());
      const name = (parts[0] || '').replace(/^模板:/, '');
      if (/^图标(\/|$)/.test(name)) {
        const main = parts[2] || parts[1] || '';
        const suffix = parts.slice(3).filter(Boolean).join(' ');
        return suffix ? `${main} ${suffix}` : main;
      }
      if (['颜色', '效果', '黑幕', '说明框', '折叠框'].includes(name)) return parts[parts.length - 1] || '';
      const tail = [...parts.slice(1)].reverse().find((p) => p && !/^[^=]{1,14}=/.test(p));
      return tail || '';
    });
    if (t === before) break;
  }
  t = t.replace(/\[\[File:[^\]]*\]\]/gi, ' ');
  t = t.replace(/\[\[(?:[^\]|]*\|)?([^\]]*)\]\]/g, '$1');
  t = t.replace(/'''?/g, '');
  t = t.replace(/<br\s*\/?>/gi, ' ');
  t = t.replace(/<[^>]+>/g, ' ');
  t = t.replace(/&nbsp;/g, ' ');
  t = t.replace(/^[*#:;]+\s*/gm, ' ');   // wiki 列表/缩进标记（* # : ;）不是正文
  return t.replace(/\s+/g, ' ').trim();
}

/** 取一个二级标题（==X==）下的正文，直到下一个二级标题。 */
function sectionOf(wikitext, title) {
  const src = String(wikitext || '');
  const m = new RegExp(`^==\\s*${escapeRe(title)}\\s*==\\s*$`, 'm').exec(src);
  if (!m) return '';
  const rest = src.slice(m.index + m[0].length);
  const next = rest.search(/^==[^=\n]/m);
  return next < 0 ? rest : rest.slice(0, next);
}

let lastWikiAt = 0;
async function wikiApi(wiki, params) {
  const gap = Date.now() - lastWikiAt;
  if (gap < WIKI_MIN_GAP_MS) await sleep(WIKI_MIN_GAP_MS - gap);
  lastWikiAt = Date.now();
  const qs = new URLSearchParams({ format: 'json', ...params }).toString();
  const res = await httpFetch(`https://wiki.biligame.com/${wiki}/api.php?${qs}`, {
    headers: { accept: 'application/json', 'user-agent': 'qq-agent-game-panel/1.0' },
    signal: AbortSignal.timeout(REQ_TIMEOUT_MS)
  });
  if (!res.ok) throw new Error(`wiki 返回 HTTP ${res.status}`);
  const body = await res.json().catch(() => null);
  // 把 MediaWiki 的错误码带出来：missingtitle = 页面确实不存在，其它都算临时失败
  if (!body || body.error) {
    throw new Error(`wiki 返回异常${body?.error?.code ? `[${body.error.code}]` : ''}${body?.error?.info ? `：${body.error.info}` : ''}`);
  }
  return body;
}

/** 只要 wikitext —— prop=text（渲染 HTML）会被反爬拦成 567，别用。
 *  返回：'' = 页面确实不存在；null = 临时失败（限流/超时），**不能当结论缓存**。 */
async function wikiWikitext(wiki, title) {
  try {
    const body = await wikiApi(wiki, { action: 'parse', page: title, prop: 'wikitext', redirects: '1' });
    return body?.parse?.wikitext?.['*'] || '';
  } catch (error) {
    return /missingtitle|页面不存在/i.test(String(error?.message || '')) ? '' : null;
  }
}

async function wikiSearch(wiki, keyword) {
  try {
    const body = await wikiApi(wiki, { action: 'query', list: 'search', srsearch: keyword, srlimit: '5' });
    const list = body?.query?.search || [];
    if (!list.length) return '';
    const guide = list.find((p) => String(p.title).endsWith('/攻略'));
    return String((guide || list[0]).title || '');
  } catch { return ''; }
}

const adviceCache = new Map();

async function fetchAdvice(game, character) {
  const map = ADVICE_MAP[game.key];
  let title = `${character}/攻略`;
  let wt = await wikiWikitext(game.wiki, title);
  // 临时失败（限流/超时）：直接返回 transient，别当成"没有页面"缓存下来，
  // 否则一次抖动会把 6 小时内的建议全变成“这个角色 wiki 上没有攻略页”。
  if (wt === null) return { ok: false, transient: true, reason: 'wiki 请求失败（限流或超时），过一会儿再查' };
  if (!wt) {
    const alt = await wikiSearch(game.wiki, `${character} 攻略`);
    if (alt && alt !== title) {
      title = alt;
      wt = await wikiWikitext(game.wiki, title);
      if (wt === null) return { ok: false, transient: true, reason: 'wiki 请求失败（限流或超时），过一会儿再查' };
    }
  }
  if (!wt) return { ok: false, reason: `B站 wiki 上没有「${character}/攻略」页面` };

  const positioning = truncateSmart(unwrapWiki(sectionOf(wt, '角色定位')), 190);
  // ⚠️ 不能只在「==配装推荐==」小节里找模板：部分角色的攻略页（如沃雅妮莎）把这个二级标题省掉了，
  //    正文直接就是 `===简易推荐===`，按小节切会切出空字符串 —— 表现就是卡片上只有「定位」没有配装。
  //    所以优先全文找模板（配装模板每页只有一个），小节只作为兜底。
  const tplBody = findTemplateBody(wt, map.template) || findTemplateBody(sectionOf(wt, '配装推荐'), map.template);
  const params = parseTemplateParams(tplBody);
  // ⚠️ wiki 上有些角色页的配装参数是**空壳**：{{图标/遗器||||4件套}} —— 只填了件数没填名字。
  //    不去掉的话卡片上会出现「4件套 4件套 4件套」这种残片（藿藿就是）。
  const realName = (raw) => {
    const t = unwrapWiki(raw || '');
    return t.replace(/\s*\d+\s*件套\s*$/, '').trim() ? t : '';
  };
  const setGroups = map.setGroups.map((grp) => ({
    label: grp.label,
    items: grp.keys
      .map((k, i) => ({ name: realName(params[k]), note: unwrapWiki(params[grp.descKeys[i]] || '') }))
      .filter((x) => x.name)
  })).filter((g) => g.items.length);
  const stats = map.stats
    .map(([label, k]) => ({ label, value: unwrapWiki(params[k] || '') }))
    .filter((x) => x.value);
  const subStats = unwrapWiki(params[map.subStatsKey] || '');
  const weaponGroups = map.weaponGroups.map((grp) => ({
    label: grp.label,
    items: grp.keys
      .map((k, i) => ({ name: realName(params[k]), note: unwrapWiki(params[grp.descKeys[i]] || '') }))
      .filter((x) => x.name)
  })).filter((g) => g.items.length);
  const tips = map.tips.map(([label, k]) => ({ label, value: unwrapWiki(params[k] || '') })).filter((x) => x.value);
  const hasBuild = Boolean(setGroups.length || stats.length || subStats || weaponGroups.length);

  if (!positioning && !hasBuild) {
    // 页面存在但只有空白模板（藿藿就是这种：连角色定位都没写）
    return { ok: false, reason: `wiki 上「${character}」的攻略页还没写内容（只有空白模板）` };
  }
  return {
    ok: true,
    // partial = 只拿到角色定位、没有配装（攻略页还没写，新角色常见）——卡片上要如实标出来，
    // 不能默默只显示一段定位，让人以为"建议就这么点"
    partial: !hasBuild,
    reason: hasBuild ? '' : 'wiki 攻略页还没写配装推荐（新角色常见）',
    character,
    title,
    positioning,
    setGroups,
    stats,
    subStats,
    weaponGroups,
    tips,
    // url 给模型/复制用（合法可点）；urlText 给卡片上显示（中文可读）
    url: `https://wiki.biligame.com/${game.wiki}/${encodeURIComponent(title)}`,
    urlText: `wiki.biligame.com/${game.wiki}/${title}`
  };
}

async function getAdvice(game, character) {
  const key = `${game.key}:${character}`;
  const hit = adviceCache.get(key);
  if (hit && Date.now() - hit.at < ADVICE_TTL_MS) return hit.value;
  let value;
  try {
    value = await fetchAdvice(game, character);
  } catch (error) {
    value = { ok: false, transient: true, reason: `wiki 请求失败：${error?.message ?? error}` };
  }
  // ⚠️ 临时失败不进缓存：否则一次限流会把 6 小时内的结果全钉死成"没建议"
  if (!value?.transient) adviceCache.set(key, { at: Date.now(), value });
  return value;
}

/* ── 样式 ────────────────────────────────────────────────────────────────── */
function styleBlock(t) {
  return `
  * { margin:0; padding:0; box-sizing:border-box; }
  html { overflow:hidden; background:${t.cardBg}; }
  body { width:${CARD_W}px; padding:0; margin:0; background:${t.cardBg}; color:${t.text};
         font-family:"Microsoft YaHei","PingFang SC","Noto Sans CJK SC",sans-serif; }
  /* 整张图就是卡片本身：不留外边距 / 圆角 / 外框，免得群里看到一圈黑边 */
  .card { background:${t.cardBg}; overflow:hidden; }
  .head { padding:13px 16px; border-bottom:1px solid ${t.border}; display:flex; align-items:baseline; gap:10px; }
  .head .t { font-size:19px; font-weight:700; }
  .head .u { font-size:13px; color:${t.dim2}; }
  .head .c { margin-left:auto; font-size:13px; color:${t.dim2}; }
  .el { font-size:12px; padding:1px 7px; border-radius:9px; }
  .stars { font-size:12px; color:#ffcc4d; }
  .dim { font-size:12px; color:${t.dim2}; }
  .chip { background:${t.chip}; border:1px solid ${t.border}; border-radius:7px; padding:3px 9px; font-size:13px; color:${t.dim}; }
  .chip b { color:${t.text}; font-size:14px; }
  .chip em { color:#7ee787; font-style:normal; font-size:11px; margin-left:1px; }
  .sec { font-size:12px; color:${t.sec}; margin:12px 0 6px; letter-spacing:1px; }
  .sec::before { content:'▍'; color:#4cc9f0; margin-right:4px; }
  .bar { height:7px; border-radius:4px; background:${t.chip}; display:flex; overflow:hidden; }
  .bar i { display:block; height:100%; }
  .foot { padding:8px 16px; font-size:12px; color:${t.dim2}; border-top:1px solid ${t.border}; }
  /* 养成建议区 */
  .adv { background:${t.chip}; border:1px solid ${t.border}; border-radius:8px; padding:9px 11px; }
  .adv .pos { font-size:13px; color:${t.dim}; line-height:1.55; }
  .adv .row { font-size:13px; color:${t.dim}; margin-top:7px; line-height:1.6; }
  .adv .row > b { color:${t.text}; font-weight:700; margin-right:9px; }
  .adv .row .note { color:${t.dim2}; font-size:12px; }
  .adv .missing { font-size:12px; color:${t.dim2}; }
  /* 穿皮肤时用 256×256 透明头像当立绘：居中按原比例显示，不拉伸不变形。
     ⚠️ 选择器必须写成 .art.art--icon —— 权重不够会被后面的 .art img（cover 拉满）反盖掉，
        表现就是"只剩一张放大的脸"。 */
  .art.art--icon { display:flex; align-items:center; justify-content:center;
                   background:radial-gradient(circle at 50% 50%, #2b3446 0%, #1b2230 48%, #0f1218 100%); }
  .art.art--icon img { width:300px; height:300px; object-fit:contain; object-position:center; display:block; margin:0;
                       /* 半身像底部是硬切边，用遮罩渐隐掉，免得像被剪断 */
                       -webkit-mask-image:linear-gradient(to bottom, #000 80%, transparent 100%);
                       mask-image:linear-gradient(to bottom, #000 80%, transparent 100%); }
  .art.art--icon .badge { bottom:16px; }`;
}

/* ── 面板卡（HTML）──────────────────────────────────────────────────────── */
function buildPanelHtml(char, player, s, advice) {
  const t = THEMES[s.theme] || THEMES.dark;
  const grade = gradeOf(char.score.total);
  const el = char.elementColor || '#98a2b3';
  const chips = (char.chips || []).map((x) => `<span class="chip">${escapeHtml(x.label)} <b>${escapeHtml(x.value)}</b></span>`).join('');
  const grid = (char.stats || []).map((x) => `<div class="it"><span>${escapeHtml(x.label)}</span><b>${escapeHtml(x.value)}</b></div>`).join('');
  const talents = (char.talents || []).map((x) => `<span class="chip">${escapeHtml(x.label)} <b>${escapeHtml(x.main)}</b>${x.sub ? `<em>${escapeHtml(x.sub)}</em>` : ''}</span>`).join('');
  const sets = (char.sets || []).length
    ? char.sets.map((x) => `${escapeHtml(x.name)} <b>×${x.n}</b>`).join('　·　')
    : '（没读到套装数据）';
  // 圣遗物 / 遗器逐部位明细：图标 + 主词条 + 等级
  const relicList = char.relics || [];
  const relicGrid = relicList.length
    ? `<div class="relrow" style="grid-template-columns:repeat(${relicList.length},1fr)">${relicList.map((r) => `
        <div class="rel" title="${escapeHtml(`${r.set || ''}${r.mainLabel ? ` · ${r.mainLabel}` : ''}`)}">
          ${r.iconData ? `<img src="${r.iconData}" alt="">` : `<span class="relno">${escapeHtml(r.slotShort || '·')}</span>`}
          <div class="rv">${escapeHtml(r.mainValue || '')}</div>
          <div class="rn">${escapeHtml(r.mainLabel || '')}</div>
          <div class="rl">+${r.level}</div>
        </div>`).join('')}</div>`
    : '';
  const w = char.weapon;
  const wRow = w
    ? `<div class="wprow">
        ${s.showGearIcon && w.iconData ? `<img src="${w.iconData}" alt="">` : ''}
        <div><div class="wn">${escapeHtml(w.name || '（未知）')}</div><div class="dim">${stars(w.stars)}</div></div>
        <div class="wd">Lv.${w.level}<br>${escapeHtml(char.gearLabel)} ${w.refine}</div>
      </div>`
    : '<div class="wprow"><span class="dim">（没读到武器数据）</span></div>';
  const bar = char.score.dims
    .map((d) => `<i style="width:${(clamp(d.score / d.max, 0, 1) * 100).toFixed(1)}%;background:${d.color}"></i>`)
    .join('');
  const dimText = char.score.dims.map((d) => `${d.label} ${d.score.toFixed(1)}/${d.max}`).join('　');
  const art = char.splashData || char.iconData;
  const artIconMode = char.artMode === 'icon';
  // 每个游戏用自己的术语（原神叫武器/圣遗物/天赋，星铁叫光锥/遗器/行迹）
  const sec = char.sectionLabels || {};
  const talentSec = sec.talent || '天赋等级';
  const gearSec = sec.gear || '武器';
  const setsSec = sec.sets || '圣遗物';
  // 穿了皮肤就在名字后面挂个标记（皮肤素材只有 256 头像，没有高清立绘）
  const costumeChip = char.costumeAsset
    ? '<span class="el" style="background:#ffcc4d22;color:#ffcc4d;border:1px solid #ffcc4d55">皮肤</span>'
    : '';
  // 皮肤小头像：挂在立绘角落，让人一眼看出穿的是哪套皮肤。
  // 主立绘仍然是默认皮肤的高清抽卡立绘 —— 游戏里没有"皮肤的高清立绘"这个文件。
  const skinBadge = char.costumeIconData && !char.artIconMode && char.artMode !== 'icon'
    ? `<div class="skinbadge" title="已穿皮肤"><img src="${char.costumeIconData}" alt=""></div>`
    : '';

  return `<!DOCTYPE html><html><head><meta charset="utf-8"><style>${styleBlock(t)}
  .one { display:flex; }
  .art { width:300px; flex:0 0 300px; background:linear-gradient(160deg,#1b2230,#0f1218); position:relative; overflow:hidden; }
  .art img { width:300px; height:100%; object-fit:cover; object-position:top center; display:block; }
  .art .badge { position:absolute; left:12px; bottom:12px; background:#000000aa; border:1px solid #ffffff22;
                border-radius:10px; padding:6px 12px; }
  .art .badge b { font-size:24px; }
  .art .badge span { font-size:15px; margin-left:4px; }
  /* 皮肤小头像（右下角），与左下角的练度徽章对称；尺寸要够大，缩成小图后在群里也能看清 */
  .art .skinbadge { position:absolute; right:14px; bottom:14px; width:78px; height:78px; border-radius:16px;
                    overflow:hidden; border:2px solid #ffffff45; background:#0b0d12cc; box-shadow:0 3px 14px #0009; }
  .art .skinbadge img { width:100%; height:100%; object-fit:cover; display:block; border-radius:0; }
  .panel { flex:1; min-width:0; padding:14px 16px; }
  .nm { display:flex; align-items:center; gap:8px; flex-wrap:wrap; }
  .nm .n { font-size:22px; font-weight:700; }
  .chips { display:flex; gap:8px; margin-top:9px; flex-wrap:wrap; }
  .grid { display:grid; grid-template-columns:1fr 1fr; gap:7px 14px; margin-top:4px; }
  .grid .it { display:flex; align-items:baseline; justify-content:space-between; background:${t.chip};
              border:1px solid ${t.border}; border-radius:8px; padding:6px 10px; }
  .grid .it span { font-size:13px; color:${t.dim}; }
  .grid .it b { font-size:15px; }
  .talrow { display:flex; gap:8px; flex-wrap:wrap; }
  .wprow { display:flex; align-items:center; gap:9px; background:${t.chip}; border:1px solid ${t.border};
           border-radius:8px; padding:7px 10px; }
  .wprow img { width:40px; height:40px; border-radius:6px; display:block; }
  .wprow .wn { font-size:14px; font-weight:700; }
  .wprow .wd { font-size:12px; color:${t.dim}; margin-left:auto; text-align:right; }
  /* 圣遗物 / 遗器：每个部位一格（图标 + 主词条数值 + 主词条名 + 等级） */
  .relrow { display:grid; gap:6px; margin-top:7px; }
  .rel { background:${t.chip}; border:1px solid ${t.border}; border-radius:8px; padding:5px 3px 4px; text-align:center; }
  .rel img, .rel .relno { width:30px; height:30px; display:block; margin:0 auto 2px; border-radius:5px; }
  /* 图标没取到时的占位：画个部位名（花/羽/沙/杯/冠），别留一片白 */
  .rel .relno { display:flex; align-items:center; justify-content:center; font-size:13px;
                color:${t.dim2}; background:${t.border}; border:1px dashed ${t.dim2}55; }
  .rel .rv { font-size:12px; font-weight:700; color:${t.text}; line-height:1.2; white-space:nowrap; }
  .rel .rn { font-size:10px; color:${t.dim}; line-height:1.25; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
  .rel .rl { font-size:10px; color:${t.dim2}; line-height:1.2; }
  </style></head><body>
  <div class="card">
    <div class="head">
      <span class="t">🎴 练度面板</span>
      <span class="u">${escapeHtml(player.nickname || '')} · UID ${escapeHtml(player.uid || '')}</span>
      <span class="c">${escapeHtml(player.meta || '')}</span>
    </div>
    <div class="one">
      ${art ? `<div class="art${artIconMode ? ' art--icon' : ''}">
        <img src="${art}" alt="">
        <div class="badge"><b style="color:${grade.color}">${char.score.total.toFixed(1)}</b><span style="color:${grade.color}">${grade.g}</span><span class="dim"> 练度</span></div>
        ${skinBadge}
      </div>` : ''}
      <div class="panel">
        <div class="nm">
          <span class="n">${escapeHtml(char.name)}</span>
          ${char.elementName ? `<span class="el" style="background:${el}22;color:${el};border:1px solid ${el}55">${escapeHtml(char.elementName)}</span>` : ''}
          ${costumeChip}
          <span class="stars">${stars(char.rarityStars)}</span>
          <span class="dim">${escapeHtml(char.subLabel || '')}</span>
        </div>
        <div class="chips">${chips}</div>
        ${grid ? '<div class="sec">面板属性</div>' : ''}
        <div class="grid">${grid}</div>
        ${talents ? `<div class="sec">${escapeHtml(talentSec)}</div>` : ''}
        <div class="talrow">${talents}</div>
        <div class="sec">${escapeHtml(gearSec)}</div>
        ${wRow}
        <div class="sec">${escapeHtml(setsSec)}</div>
        <div class="chip" style="display:block;padding:7px 10px">${sets}</div>
        ${relicGrid}
        <div class="sec">练度评分明细</div>
        <div class="bar">${bar}</div>
        <div class="dim" style="margin-top:6px">${dimText}</div>
        ${adviceBoxHtml(advice)}
      </div>
    </div>
    <div class="foot">${escapeHtml(char.score.note)}　|　${escapeHtml(char.score.gearDetail)}　|　${escapeHtml(player.source || '')}</div>
  </div></body></html>`;
}

function adviceBoxHtml(advice) {
  if (!advice) return '';
  if (!advice.ok) {
    return `<div class="sec">养成建议</div>
      <div class="adv"><div class="missing">这次没取到 wiki 建议（${escapeHtml(advice.reason || '未知原因')}）。</div></div>`;
  }
  const setRows = advice.setGroups.map((g) => {
    const items = g.items.map((x) => `${escapeHtml(x.name)}${x.note ? ` <span class="note">（${escapeHtml(x.note)}）</span>` : ''}`).join('　·　');
    return `<div class="row"><b>${escapeHtml(g.label)}</b>${items}</div>`;
  }).join('');
  const statRow = advice.stats.length
    ? `<div class="row"><b>主词条</b>${advice.stats.map((x) => `${escapeHtml(x.label)} ${escapeHtml(x.value)}`).join('　|　')}</div>`
    : '';
  const subRow = advice.subStats
    ? `<div class="row"><b>副词条</b>${escapeHtml(advice.subStats)}</div>`
    : '';
  const wpRows = advice.weaponGroups.map((g) => {
    const items = g.items.map((x) => `${escapeHtml(x.name)}${x.note ? ` <span class="note">（${escapeHtml(x.note)}）</span>` : ''}`).join('　·　');
    return `<div class="row"><b>${escapeHtml(g.label)}</b>${items}</div>`;
  }).join('');
  const tipRows = advice.tips.map((x) => `<div class="row"><b>${escapeHtml(x.label)}</b>${escapeHtml(x.value)}</div>`).join('');
  const partialNote = advice.partial
    ? `<div class="row"><span class="note">${escapeHtml(advice.reason || 'wiki 攻略页还没写配装推荐')}</span></div>`
    : '';
  return `<div class="sec">养成建议（B站 wiki）</div>
    <div class="adv">
      ${advice.positioning ? `<div class="pos">定位：${escapeHtml(advice.positioning)}</div>` : ''}
      ${setRows}${statRow}${subRow}${wpRows}${tipRows}${partialNote}
    </div>`;
}

/* ── v2 卡片：移动端 App 风格（参考米游社 / 小黑盒的角色详情页）───────────────
 * 纵向信息流：立绘头图 → 技能图标 → 面板属性 → 武器 → 圣遗物卡片 → 评分 → wiki 建议（置底）
 * 属性小图标用**内联 SVG**：Enka 没有这套属性图标（试了 20 个候选全 404），
 * 用 SVG 不依赖网络、任意尺寸都清晰，颜色还能跟着主题走。
 */
/** 把颜色压暗（浅色主题下当文字色用） */
const shadeHex = (hex, k = 0.45) => {
  const m = /^#?([0-9a-f]{6})$/i.exec(String(hex || ''));
  if (!m) return hex;
  const n = parseInt(m[1], 16);
  const f = (v) => Math.max(0, Math.min(255, Math.round(v * (1 - k))));
  return `#${[f(n >> 16), f((n >> 8) & 255), f(n & 255)].map((v) => v.toString(16).padStart(2, '0')).join('')}`;
};
/** 全幅背景层：角色立绘 + 模糊（强度可配）+ 按比例裁剪（cover），卡片多高都铺满 */
const bgLayers = (art, blur = 30) => (art
  ? `<div class="bgfull" style="background-image:url('${art}');filter:blur(${blur}px) saturate(1.25)"></div><div class="bgveil"></div>`
  : '');
const SVG = (d) => `<svg viewBox="0 0 16 16" width="14" height="14" fill="none" stroke="currentColor" stroke-width="1.35" stroke-linecap="round" stroke-linejoin="round">${d}</svg>`;
const ATTR_ICON = {
  hp: SVG('<path d="M8 13.4S2.6 10.2 2.6 6.4A2.7 2.7 0 0 1 8 5.2 2.7 2.7 0 0 1 13.4 6.4c0 3.8-5.4 7-5.4 7Z"/>'),
  atk: SVG('<path d="M12.6 3.4 6.2 9.8"/><path d="M10.2 3h2.4v2.4"/><path d="M6.4 9.6 4 12"/><path d="M3.2 10.4 5.6 12.8"/>'),
  def: SVG('<path d="M8 2.4l4.4 1.7v4c0 2.9-2.1 4.8-4.4 5.7-2.3-.9-4.4-2.8-4.4-5.7v-4L8 2.4Z"/>'),
  em: SVG('<path d="M8 2.6 9.3 6.7 13.4 8 9.3 9.3 8 13.4 6.7 9.3 2.6 8 6.7 6.7Z"/>'),
  spd: SVG('<path d="M9.2 2.4 4.6 9h3l-1 4.6L12.4 6.6H9l.2-4.2Z"/>'),
  crit: SVG('<path d="M8 2.8v10.4"/><path d="M2.8 8h10.4"/><path d="M4.6 4.6l6.8 6.8"/><path d="M11.4 4.6l-6.8 6.8"/>'),
  critdmg: SVG('<path d="M8 2.2 9.5 5.6 13 6.2 10.4 8.6 11 12.2 8 10.4 5 12.2 5.6 8.6 3 6.2 6.5 5.6Z"/>'),
  er: SVG('<path d="M13 8a5 5 0 1 1-1.7-3.8"/><path d="M13.2 2.6v2.8h-2.8"/>'),
  break: SVG('<path d="M8 2.4 9 6.4 12.6 5.4 10 8 13 10.6 9 10 8 13.6 7 10 3 10.6 6 8 3.4 5.4 7 6.4Z"/>'),
  hit: SVG('<circle cx="8" cy="8" r="4.6"/><path d="M8 6.4v3.2"/><path d="M6.4 8h3.2"/>'),
  res: SVG('<circle cx="8" cy="8" r="4.6"/><path d="M4.8 4.8l6.4 6.4"/>'),
  heal: SVG('<circle cx="8" cy="8" r="4.8"/><path d="M8 5.6v4.8"/><path d="M5.6 8h4.8"/>'),
  dmg: SVG('<path d="M8 2.4c2.6 2.6 3.6 4.2 3.6 6a3.6 3.6 0 1 1-7.2 0c0-1.8 1-3.4 3.6-6Z"/>'),
  dot: SVG('<circle cx="8" cy="8" r="2.2"/>')
};

function attrIconKey(label) {
  const s = String(label || '');
  if (/生命/.test(s)) return 'hp';
  if (/攻击/.test(s)) return 'atk';
  if (/防御/.test(s)) return 'def';
  if (/精通/.test(s)) return 'em';
  if (/速度/.test(s)) return 'spd';
  if (/暴击伤害/.test(s)) return 'critdmg';
  if (/暴击/.test(s)) return 'crit';
  if (/充能|能量恢复/.test(s)) return 'er';
  if (/击破/.test(s)) return 'break';
  if (/效果命中/.test(s)) return 'hit';
  if (/效果抵抗/.test(s)) return 'res';
  if (/治疗/.test(s)) return 'heal';
  if (/伤害加成/.test(s)) return 'dmg';
  return 'dot';
}

function styleV2(t, accent, s = {}) {
  // 主题令牌：深浅色共用同一套规则，只换变量值
  const light = String(t.cardBg).toLowerCase() === '#ffffff';
  /** 把元素色压暗一点，浅色底上当文字色才看得清 */
  const shade = shadeHex;
  const accentText = light ? shade(accent, 0.42) : accent;
  // 信息框毛玻璃：0 = 实心面板（原样），>0 = 半透明（背景立绘已经糊过，透出来就是磨砂）
  // ⚠️ 不能只靠 backdrop-filter：Electron 离屏截图（offscreen + capturePage）不生效，会"设置没反应"
  const pb = clamp(num(s.panelBlur, 0), 0, 20);
  const pa = Math.max(0.16, 0.84 - pb * 0.032);
  const pbg = pb > 0 ? `rgba(${light ? '255,255,255' : '20,29,41'},${pa.toFixed(2)})` : null;
  const V = light ? {
    page: '#eef2f8', vbg: 'linear-gradient(180deg,#f8fbfe 0%,#eef2f8 100%)',
    pnl: '#ffffff', pnl2: '#f6f9fd', bd: '#dbe4f0', bd2: '#e9eff7',
    tx: '#16202e', dim: '#5b6879', dim2: '#8794a6', gold: '#a1730a',
    bar: '#e6edf7', chip: '#f0f5fb', artbd: '#d8e2ee', shadow: '#0b1a2a14',
    scrim: '248,251,254', nm2: '#ffffffaa', foot: '#8b98ab',
    // 图标瓦片：命座/技能图标都是浅色线稿，浅色主题下必须保留深底，否则整片糊掉
    icbg: '#242e3c', icbd: '#354154'
  } : {
    page: '#0b111b', vbg: 'linear-gradient(180deg,#0e1622 0%,#0b111b 46%,#0a0f18 100%)',
    pnl: '#141d29', pnl2: '#111823', bd: '#222e3e', bd2: '#1e2836',
    tx: '#eef3fa', dim: '#9aa7ba', dim2: '#7b879a', gold: '#e8d5a8',
    bar: '#1a2431', chip: '#0e141d', artbd: '#26313f', shadow: '#00000066',
    scrim: '11,17,27', nm2: '#000000cc', foot: '#5f6b7d',
    icbg: '#0e141d', icbd: '#222e3e'
  };
  return `
  * { margin:0; padding:0; box-sizing:border-box; }
  :root { --pnl:${V.pnl}; --pnl2:${pbg || V.pnl2}; --bd:${V.bd}; --bd2:${V.bd2}; --tx:${V.tx};
          --dim:${V.dim}; --dim2:${V.dim2}; --gold:${V.gold}; --bar:${V.bar}; --chip:${V.chip}; }
  html { overflow:hidden; background:${V.page}; }
  body { width:${CARD_W}px; margin:0; background:${V.page}; color:var(--tx);
         font-family:"Microsoft YaHei","PingFang SC","Noto Sans CJK SC",sans-serif; }
  .v2 { position:relative; overflow:hidden; background:${V.vbg}; }
  /* ── 全幅背景：角色立绘 + 模糊 + cover 裁剪（卡片高度每次都不一样，靠 cover 铺满）── */
  .bgfull { position:absolute; inset:-42px; background-size:cover; background-position:center 14%;
            background-repeat:no-repeat; filter:blur(30px) saturate(1.25); opacity:${light ? '.5' : '.62'}; }
  .bgveil { position:absolute; inset:0;
            background:linear-gradient(180deg,rgba(${V.scrim},.74) 0%,rgba(${V.scrim},.9) 55%,rgba(${V.scrim},.96) 100%); }
  .vbody { position:relative; z-index:1; }
  /* ── 头图：立绘在左，面板基础信息在右（参考小黑盒/米游社）── */
  .hero { position:relative; display:flex; align-items:stretch; gap:16px; padding:18px 22px 6px; overflow:hidden; }
  .hero .lbox { position:relative; width:380px; flex:0 0 380px; min-height:430px; border-radius:14px;
                overflow:hidden; border:1px solid ${V.artbd}; background:${V.chip}; box-shadow:0 6px 22px ${V.shadow}; }
  .hero .lbox .art { width:100%; height:100%; object-fit:cover; object-position:center 18%; display:block; }
  .hero .lbox .skin { position:absolute; right:8px; bottom:8px; display:flex; align-items:center; gap:5px;
                      background:rgba(${light ? '255,255,255' : '9,13,20'},.82); border:1px solid ${V.gold}66;
                      border-radius:9px; padding:3px 7px 3px 3px; }
  .hero .lbox .skin img { width:30px; height:30px; border-radius:7px; display:block; }
  .hero .lbox .skin span { font-size:10.5px; color:var(--gold); }
  .hero .rbox { position:relative; flex:1; min-width:0; }
  /* 玩家名 / 等级：右上角 */
  .hero .pinfo { display:flex; justify-content:flex-end; align-items:baseline; gap:8px;
                 font-size:11.5px; color:var(--dim2); margin-bottom:2px; }
  .hero .pinfo b { color:var(--dim); font-size:12px; font-weight:600; }
  .hero .nameline { display:flex; align-items:center; gap:8px; flex-wrap:wrap; }
  .hero .nm { font-size:26px; font-weight:700; letter-spacing:1px; text-shadow:0 2px 12px ${V.nm2}; }
  .hero .el { display:inline-flex; align-items:center; gap:4px; font-size:12px; padding:3px 9px;
              border-radius:20px; border:1px solid ${accentText}66; background:${accent}1f; color:${accentText}; }
  .hero .el img { width:15px; height:15px; display:block; }
  .hero .grade { margin-left:auto; text-align:right; line-height:1.05; }
  .hero .grade b { font-size:23px; font-weight:800; }
  .hero .grade i { font-style:normal; font-size:13px; margin-left:3px; }
  .hero .grade u { display:block; font-size:9.5px; color:var(--dim2); text-decoration:none; margin-top:1px; }
  .hero .meta { font-size:12px; color:var(--dim); margin-top:5px; }
  /* ── 段落标题 ── */
  .bar { display:flex; align-items:baseline; gap:8px; padding:14px 22px 7px; }
  .bar .tt { font-size:13px; font-weight:700; color:var(--tx); letter-spacing:1px; }
  .bar .tt::before { content:''; display:inline-block; width:3px; height:12px; border-radius:2px;
                     background:${accent}; margin-right:7px; vertical-align:-1px; }
  .bar .hint { margin-left:auto; font-size:11px; color:var(--dim2); }
  .pad { padding:0 22px; }
  /* ── 技能（放在头图右栏）── */
  .sks { display:flex; gap:9px; margin-top:13px; }
  .sk { text-align:center; }
  .sk .ic { position:relative; width:46px; height:46px; margin:0 auto 3px; border-radius:12px;
            background:${V.icbg}; border:1px solid ${V.icbd}; overflow:hidden; }
  .sk .ic img { width:46px; height:46px; object-fit:cover; display:block; }
  .sk .ic i { position:absolute; right:1px; bottom:1px; min-width:17px; height:17px; line-height:15px;
              border-radius:5px; background:rgba(7,10,16,.86); border:1px solid #ffffff33; color:#eef3fa;
              font-style:normal; font-size:10px; font-weight:700; text-align:center; padding:0 2px; }
  .sk .lb { font-size:10px; color:var(--dim2); }
  .sk .bonus { font-size:9px; color:${light ? '#2f8f4e' : '#7ee787'}; }
  /* ── 属性（右栏单列，参考小黑盒）── */
  .attrs { display:grid; grid-template-columns:1fr; gap:0; margin-top:13px; }
  .at { display:flex; align-items:center; gap:8px; height:31px; border-bottom:1px dashed var(--bd2); }
  .at svg { color:var(--dim2); flex:0 0 15px; width:15px; height:15px; }
  .at span { font-size:13px; color:var(--dim); }
  .at b { margin-left:auto; font-size:15.5px; font-weight:700; color:var(--tx); font-variant-numeric:tabular-nums; }
  /* ── 命座 + 武器 并排 ── */
  .duo { display:flex; gap:14px; padding:0 22px; align-items:flex-start; }
  .duo-l { flex:0 0 auto; }
  .duo-r { flex:1; min-width:0; }
  .duo .bar { padding:14px 0 7px; }
  .cons { display:flex; gap:7px; }
  /* 命座：边框 2px + 元素色发光，激活/未激活一眼能分（暗底上 1px 细边几乎看不见） */
  .ci { position:relative; width:56px; height:56px; border-radius:11px; overflow:hidden;
        background:${V.icbg}; border:2px solid ${light ? '#d3dce8' : '#3a4759'};
        box-shadow:0 0 0 1px rgba(0,0,0,${light ? '.04' : '.5'}) inset; }
  .ci img { width:100%; height:100%; object-fit:cover; display:block; }
  .ci.off img { filter:grayscale(1) brightness(${light ? '1' : '.55'}); opacity:${light ? '.4' : '.7'}; }
  .ci.off { opacity:1; }
  .ci.on { border-color:${light ? accentText : accent};
           box-shadow:0 0 0 1px ${accent}44, 0 0 14px ${accent}66, 0 4px 14px ${V.shadow}; }
  .ci.on img { filter:none; opacity:1; }
  .ci span { display:flex; align-items:center; justify-content:center; height:100%; font-size:12px; color:#8794a6; }
  .ci u { position:absolute; left:0; right:0; bottom:0; text-align:center; font-size:9.5px; text-decoration:none;
          color:#cfd9e6; background:rgba(7,10,16,.68); padding:1px 0; }
  /* ── 武器（放在命座右侧，紧凑排版）── */
  .wcard { padding:9px 10px; background:var(--pnl2); border:1px solid var(--bd); border-radius:11px; }
  .wcard .wtop { display:flex; align-items:center; gap:9px; }
  .wcard .wi { width:48px; height:48px; border-radius:9px; overflow:hidden; flex:0 0 48px;
               background:var(--chip); border:1px solid var(--bd); }
  .wcard .wi img { width:48px; height:48px; object-fit:cover; display:block; }
  .wcard .wmid { min-width:0; }
  .wcard .wn { font-size:13.5px; font-weight:700; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
  .wcard .ws { font-size:10.5px; color:var(--gold); margin-top:2px; }
  .wcard .wr { margin-left:auto; text-align:right; flex:0 0 auto; }
  .wcard .wr b { font-size:13px; }
  .wcard .wr div { font-size:10px; color:var(--dim2); }
  .wstat { display:flex; gap:12px; margin-top:7px; padding-top:6px; border-top:1px dashed var(--bd2);
           font-size:11px; color:var(--dim); }
  .wstat b { color:var(--tx); font-size:11.5px; margin-left:4px; }
  /* ── 圣遗物：4 列 + 副词条竖排 + 强化命中 ── */
  .rcards { display:grid; grid-template-columns:repeat(4,1fr); gap:8px; padding:0 22px; align-items:stretch; }
  .rc { background:var(--pnl2); border:1px solid var(--bd); border-radius:11px; padding:8px 9px; }
  .rc .rh { display:flex; align-items:center; gap:7px; }
  .rc .ri { width:38px; height:38px; flex:0 0 38px; border-radius:8px; overflow:hidden; background:var(--chip); border:1px solid var(--bd); }
  .rc .ri img { width:38px; height:38px; object-fit:cover; display:block; }
  .rc .ri .ph { width:38px; height:38px; display:flex; align-items:center; justify-content:center;
                font-size:13px; color:var(--dim2); }
  .rc .rnm { font-size:11.5px; color:var(--tx); white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
  .rc .rset { font-size:9.5px; color:var(--dim2); margin-top:1px; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
  .rc .rlv { margin-left:auto; font-size:10px; color:var(--gold); flex:0 0 auto; }
  .rc .rm { display:flex; align-items:baseline; gap:5px; margin:7px 0 5px; padding-top:6px; border-top:1px dashed var(--bd2); }
  .rc .rm span { font-size:11px; color:var(--dim); white-space:nowrap; }
  .rc .rm b { margin-left:auto; font-size:16px; font-weight:700; color:var(--tx); font-variant-numeric:tabular-nums; }
  .rc .rs { display:grid; grid-template-columns:1fr; gap:1px; }
  .rc .rs div { display:flex; align-items:baseline; gap:4px; font-size:10.5px; color:var(--dim); }
  .rc .rs em { font-style:normal; font-size:9px; color:var(--gold); }
  .rc .rs b { margin-left:auto; color:var(--tx); font-weight:600; font-variant-numeric:tabular-nums; }
  /* ── 评分：塞进圣遗物那行剩下的格子里 ── */
  .scorecard { display:flex; flex-direction:column; justify-content:center; padding:10px 12px;
               background:var(--pnl2); border:1px solid var(--bd); border-radius:11px; }
  .scorecard .scttl { font-size:10.5px; color:var(--dim2); letter-spacing:1px; }
  .scorecard .top { display:flex; align-items:baseline; gap:7px; margin-top:2px; }
  .scorecard .top b { font-size:22px; font-weight:800; line-height:1; }
  .scorecard .top i { font-style:normal; font-size:12px; }
  .scorecard .top span { margin-left:auto; font-size:10px; color:var(--dim2); }
  .scorecard .bar2 { height:7px; border-radius:4px; background:var(--bar); display:flex; overflow:hidden; margin-top:7px; }
  .scorecard .bar2 i { display:block; height:100%; }
  .scorecard .dims { display:flex; flex-wrap:wrap; gap:3px 12px; margin-top:6px; font-size:10.5px; color:var(--dim); }
  /* ── 建议 ── */
  .adv2 { margin:0 22px; background:var(--pnl2); border:1px solid var(--bd); border-radius:11px; padding:11px 13px; }
  .adv2 .pos { font-size:12.5px; line-height:1.7; color:var(--dim); }
  .adv2 .g { margin-top:9px; }
  .adv2 .g > t { display:block; font-size:11px; color:var(--gold); letter-spacing:1px; margin-bottom:4px; }
  .adv2 .row { font-size:12.5px; line-height:1.65; color:var(--dim); }
  .adv2 .row > b { color:var(--tx); font-weight:700; margin-right:8px; }
  .adv2 .row .nt { color:var(--dim2); font-size:11px; }
  .adv2 .miss { font-size:11.5px; color:var(--dim2); }
  .foot { margin-top:12px; padding:10px 22px 14px; border-top:1px solid var(--bd2);
          font-size:11px; color:${V.foot}; display:flex; gap:10px; }
  .foot .r { margin-left:auto; }
  /* ── 信息框毛玻璃（panelBlur > 0 时生效）── */
  ${pb > 0 ? `
  .vbody .rc, .vbody .wcard, .vbody .scorecard, .vbody .adv2, .vbody .attrs2,
  .vbody .weapon2, .vbody .footbar, .vbody .rt .row, .vbody .land .rl {
    background:${pbg}; backdrop-filter:blur(${pb}px) saturate(1.15); -webkit-backdrop-filter:blur(${pb}px) saturate(1.15);
  }
  .vbody .rt { background:${pbg}; backdrop-filter:blur(${pb}px) saturate(1.15); -webkit-backdrop-filter:blur(${pb}px) saturate(1.15); border-radius:12px; }` : ''}`;
}

function buildPanelHtmlV2(char, player, s, advice) {
  const t = THEMES[s.theme] || THEMES.dark;
  const accent = char.elementColor || '#4cc9f0';
  const grade = gradeOf(char.score.total);
  const art = char.splashData || char.iconData;

  const skills = (char.skillIcons || []).map((k) => `
    <div class="sk">
      <div class="ic">${k.iconData ? `<img src="${k.iconData}" alt="">` : ''}<i>${escapeHtml(String(k.level))}</i></div>
      <div class="lb">${escapeHtml(k.label)}</div>
      ${k.sub ? `<div class="bonus">${escapeHtml(k.sub)}</div>` : ''}
    </div>`).join('');

  const attrs = (char.stats || []).map((x) => `
    <div class="at">${ATTR_ICON[attrIconKey(x.label)] || ATTR_ICON.dot}<span>${escapeHtml(x.label)}</span><b>${escapeHtml(x.value)}</b></div>`).join('');

  const w = char.weapon;
  // 武器：紧凑版，放在命座右侧（宽度只有 ~330px，所以数值那行折到卡片内部）
  const weaponBlock = w ? `
    <div class="wcard">
      <div class="wtop">
        <div class="wi">${w.iconData ? `<img src="${w.iconData}" alt="">` : ''}</div>
        <div class="wmid">
          <div class="wn">${escapeHtml(w.name || '（未知）')}</div>
          <div class="ws">${stars(w.stars)} · ${escapeHtml(char.gearLabel)} ${w.refine}</div>
        </div>
        <div class="wr"><b>Lv.${w.level}</b></div>
      </div>
      ${(w.stats || []).length ? `<div class="wstat">${w.stats.map((x) => `<span>${escapeHtml(x.label)}<b>${escapeHtml(x.value)}</b></span>`).join('')}</div>` : ''}
    </div>` : '';

  const relicCards = (char.relics || []).map((r) => `
    <div class="rc">
      <div class="rh">
        <div class="ri">${r.iconData ? `<img src="${r.iconData}" alt="">` : `<div class="ph">${escapeHtml(r.slotShort || '·')}</div>`}</div>
        <div style="min-width:0">
          <div class="rnm">${escapeHtml(r.slotName || r.slotShort || '')}</div>
          <div class="rset">${escapeHtml(r.set || '')}</div>
        </div>
        <div class="rlv">+${r.level}</div>
      </div>
      <div class="rm"><span>${escapeHtml(r.mainLabel || '主词条')}</span><b>${escapeHtml(r.mainValue || '')}</b></div>
      ${(r.substats || []).length ? `<div class="rs">${r.substats.map((x) => `<div><span>${escapeHtml(x.label)}</span>${x.hits > 0 ? `<em>+${x.hits}</em>` : ''}<b>${escapeHtml(x.value)}</b></div>`).join('')}</div>` : ''}
    </div>`).join('');

  const setsLine = (char.sets || []).length
    ? char.sets.map((x) => `${escapeHtml(x.name)} <b style="color:var(--gold)">×${x.n}</b>`).join('　·　')
    : '（没读到套装）';
  const light = String(t.cardBg).toLowerCase() === '#ffffff';
  // 评级颜色也要跟主题：浅色底上 #ffcc4d 会糊成一片
  const GRADE_TONE = light
    ? { S: '#a87200', A: '#2f8f4e', B: '#2b6cb0', C: '#7b4fb5', D: '#6b7280' }
    : { S: '#ffcc4d', A: '#7ee787', B: '#79c0ff', C: '#d2a8ff', D: '#8b95a7' };
  const gradeColor = GRADE_TONE[grade.g] || grade.g;
  const barSeg = char.score.dims.map((d) => `<i style="width:${(clamp(d.score / d.max, 0, 1) * 100).toFixed(1)}%;background:${d.color}"></i>`).join('');
  const dims = char.score.dims.map((d) => `<span>${escapeHtml(d.label)} ${d.score.toFixed(0)}/${d.max}</span>`).join('');
  // 评分卡塞进圣遗物网格剩下的格子：原神 5 件 → 剩 3 格，星铁 6 件 → 剩 2 格
  const relicCount = (char.relics || []).length;
  const rem = relicCount % 4;
  const scoreSpan = rem === 0 ? 4 : 4 - rem;
  const scoreCard = `<div class="scorecard" style="grid-column:span ${scoreSpan}">
      <div class="scttl">练度评分</div>
      <div class="top"><b style="color:${gradeColor}">${char.score.total.toFixed(1)}</b><i style="color:${gradeColor}">${grade.g}</i><span>${escapeHtml(char.score.gearDetail || '')}</span></div>
      <div class="bar2">${barSeg}</div>
      <div class="dims">${dims}</div>
    </div>`;
  const skillHint = (char.chips || []).slice(-1).map((c) => `${c.label} ${c.value}`).join('');
  const elIcon = readAttrIcon(char.gameKey, char.elementAttrIdx);
  const consList = char.constellations || [];
  const consRow = consList.length
    ? `<div class="cons">${consList.map((c) => `
        <div class="ci${c.active ? ' on' : ' off'}" title="C${c.index}${c.name ? `　${c.name}` : ''}（${c.active ? '已激活' : '未激活'}）">
          ${c.iconData ? `<img src="${c.iconData}" alt="">` : `<span>C${c.index}</span>`}
          <u>C${c.index}</u>
        </div>`).join('')}</div>`
    : '';

  const adviceBlock = advice
    ? (advice.ok ? `
      <div class="adv2">
        ${advice.positioning ? `<div class="pos">${escapeHtml(advice.positioning)}</div>` : ''}
        ${advice.setGroups.map((g) => `<div class="g"><t>${escapeHtml(g.label)}</t>${g.items.map((x) => `<div class="row"><b>${escapeHtml(x.name)}</b>${x.note ? `<span class="nt">${escapeHtml(x.note)}</span>` : ''}</div>`).join('')}</div>`).join('')}
        ${advice.stats.length ? `<div class="g"><t>主词条</t><div class="row">${advice.stats.map((x) => `<b>${escapeHtml(x.label)}</b>${escapeHtml(x.value)}`).join('　')}</div></div>` : ''}
        ${advice.subStats ? `<div class="g"><t>副词条优先级</t><div class="row">${escapeHtml(advice.subStats)}</div></div>` : ''}
        ${advice.weaponGroups.map((g) => `<div class="g"><t>${escapeHtml(g.label)}</t>${g.items.map((x) => `<div class="row"><b>${escapeHtml(x.name)}</b>${x.note ? `<span class="nt">${escapeHtml(x.note)}</span>` : ''}</div>`).join('')}</div>`).join('')}
        ${advice.tips.map((x) => `<div class="g"><t>${escapeHtml(x.label)}</t><div class="row">${escapeHtml(x.value)}</div></div>`).join('')}
        ${advice.partial ? `<div class="g"><div class="miss">${escapeHtml(advice.reason || 'wiki 还没写配装')}</div></div>` : ''}
      </div>`
      : `<div class="pad"><div class="adv2"><div class="miss">${escapeHtml(advice.reason || '这次没取到 wiki 建议')}</div></div></div>`)
    : '';

  return `<!DOCTYPE html><html><head><meta charset="utf-8"><style>${styleV2(t, accent)}</style></head><body><div class="v2">${bgLayers(art)}<div class="vbody">
    <div class="hero">
      <div class="lbox">
        ${art ? `<img class="art" src="${art}" alt="">` : ''}
        ${char.costumeIconData ? `<div class="skin"><img src="${char.costumeIconData}" alt=""><span>皮肤</span></div>` : ''}
      </div>
      <div class="rbox">
        <div class="pinfo"><b>${escapeHtml(player.nickname || '未知')}</b><span>UID ${escapeHtml(player.uid || '')}</span><span>${escapeHtml(player.meta || '')}</span></div>
        <div class="nameline">
          <span class="nm">${escapeHtml(char.name)}</span>
          ${char.elementName ? `<span class="el">${elIcon ? `<img src="${elIcon}" alt="">` : ''}${escapeHtml(char.elementName)}</span>` : ''}
          <span class="grade"><b style="color:${gradeColor}">${char.score.total.toFixed(1)}</b><i style="color:${gradeColor}">${grade.g}</i><u>练度</u></span>
        </div>
        <div class="meta">Lv.${char.level}　${escapeHtml(char.consLabel)} ${char.cons}　${escapeHtml(char.subLabel || '')}　${stars(char.rarityStars)}</div>
        <div class="sks">${skills}</div>
        <div class="attrs">${attrs}</div>
      </div>
    </div>

    ${(consRow || weaponBlock) ? `<div class="duo">
      ${consRow ? `<div class="duo-l">
        <div class="bar"><span class="tt">${escapeHtml(char.consLabel)}</span><span class="hint">${char.cons}/6</span></div>
        ${consRow}
      </div>` : ''}
      ${weaponBlock ? `<div class="duo-r">
        <div class="bar"><span class="tt">${escapeHtml(char.sectionLabels?.gear || '武器')}</span><span class="hint">${escapeHtml(char.gearLabel)} ${char.weapon?.refine || ''}</span></div>
        ${weaponBlock}
      </div>` : ''}
    </div>` : ''}

    <div class="bar"><span class="tt">${escapeHtml(char.sectionLabels?.sets || '圣遗物')}</span><span class="hint">${setsLine}</span></div>
    <div class="rcards">${relicCards}${scoreCard}</div>

    <div class="bar"><span class="tt">养成建议</span><span class="hint">B站 wiki</span></div>
    ${adviceBlock}

    <div class="foot"><span>${escapeHtml(player.source || '')}</span><span class="r">${escapeHtml(char.score.note)}</span></div>
  </div></div></body></html>`;
}


/* ── 横版卡片（宽幅）───────────────────────────────────────────────────────
 * 参照游戏内/米游社的横版角色详情：左=立绘+名字等级命座+技能等级竖排，
 * 中=武器卡+面板属性，右=圣遗物 5 件竖排明细，底部一条评分/套装汇总。
 */
const LAND_W = 1180;

function styleLand(t, accent, s = {}) {
  const light = String(t.cardBg).toLowerCase() === '#ffffff';
  return styleV2(t, accent, s) + `
  body { width:${LAND_W}px; }
  .v2 { width:${LAND_W}px; }
  .land { display:grid; grid-template-columns:452px 306px 1fr; gap:12px; padding:14px 16px 6px; align-items:stretch; }
  .land .lc1 { display:flex; gap:8px; min-width:0; }
  .land .lc1 { display:flex; gap:8px; min-width:0; position:relative; z-index:2; }
  /* 立绘不套框，向右铺到中间信息栏底下（面板半透明，所以能透出立绘），右缘蒙版溶解不留硬边 */
  .land .artbox { position:relative; flex:1; min-width:0; min-height:560px; }
  .land .artbox img { position:absolute; left:0; top:0; height:100%; width:calc(100% + 245px);
                      object-fit:cover; object-position:54% 3%; display:block;
                      -webkit-mask-image:linear-gradient(90deg,#000 0%,#000 55%,rgba(0,0,0,.5) 82%,rgba(0,0,0,0) 100%);
                      mask-image:linear-gradient(90deg,#000 0%,#000 55%,rgba(0,0,0,.5) 82%,rgba(0,0,0,0) 100%); }
  /* 高清立绘没取到、退回头像时：按原比例居中摆放，别拉成大脸 */
  .land .artbox.iconmode img { left:50%; top:50%; width:auto; height:auto;
                               max-width:76%; max-height:74%; transform:translate(-50%,-50%);
                               object-fit:contain; border-radius:14px; box-shadow:0 8px 26px ${light ? '#0b1a2a22' : '#0007'};
                               -webkit-mask-image:none; mask-image:none; }
  .land .artgrad { position:absolute; left:0; right:-245px; bottom:0; height:210px; z-index:1;
                   background:linear-gradient(180deg,rgba(${light ? '248,251,254' : '9,14,22'},0) 0%,rgba(${light ? '248,251,254' : '9,14,22'},.86) 100%);
                   -webkit-mask-image:linear-gradient(90deg,#000 0%,#000 55%,rgba(0,0,0,.5) 82%,rgba(0,0,0,0) 100%);
                   mask-image:linear-gradient(90deg,#000 0%,#000 55%,rgba(0,0,0,.5) 82%,rgba(0,0,0,0) 100%); }
  .land .artname { position:absolute; left:4px; bottom:8px; right:6px; z-index:3; }
  .land .artname .n { font-size:23px; font-weight:800; letter-spacing:1px; text-shadow:0 2px 10px ${light ? '#fff' : '#000c'}; }
  .land .artname .m { font-size:11px; color:${light ? '#4a5768' : '#c2cddc'}; margin-top:3px; display:flex; gap:8px; flex-wrap:wrap; }
  .land .artname .m b { font-weight:600; }
  .land .artname .m .el { color:${light ? shadeHex(accent, .42) : accent}; font-weight:600;
                          display:inline-block; padding-left:18px; line-height:16px;
                          background-repeat:no-repeat; background-position:left center; background-size:14px 14px; }
  .land .footfoot b { color:var(--tx); font-weight:600; }
  .land .cchip { display:inline-block; padding:1px 7px; border-radius:6px; font-size:10.5px; font-weight:700;
                 background:${accent}26; color:${light ? shadeHex(accent, .42) : accent}; border:1px solid ${accent}66; }
  /* ── 命座（基础面板下面）/ 技能（圣遗物下面），横排 ── */
  .land .crow, .land .krow { display:flex; align-items:center; gap:7px; padding:7px 8px;
                             background:var(--pnl2); border:1px solid var(--bd); border-radius:11px; }
  .land .crow .rt, .land .krow .rt2 { font-size:10.5px; color:var(--dim2); letter-spacing:.5px; flex:0 0 auto; margin-right:2px; }
  .land .crow .ci { position:relative; width:44px; height:44px; border-radius:10px; overflow:hidden;
                    background:${light ? '#242e3c' : '#0e141d'}; border:2px solid ${light ? '#d3dce8' : '#3a4759'}; }
  .land .crow .ci img { width:100%; height:100%; object-fit:cover; display:block; }
  .land .crow .ci.off img { filter:grayscale(1) brightness(${light ? '1' : '.55'}); opacity:${light ? '.4' : '.7'}; }
  .land .crow .ci.on { border-color:${light ? shadeHex(accent, .42) : accent}; box-shadow:0 0 10px ${accent}55; }
  .land .krow .ic { position:relative; width:44px; height:44px; border-radius:10px; overflow:hidden;
                    background:${light ? '#242e3c' : '#0e141d'}; border:1px solid ${light ? '#354154' : '#222e3e'}; }
  .land .krow .ic img { width:44px; height:44px; object-fit:cover; display:block; }
  .land .krow .ic i { position:absolute; right:1px; bottom:1px; min-width:16px; height:16px; line-height:14px;
                      border-radius:5px; background:rgba(7,10,16,.88); border:1px solid #ffffff33; color:#eef3fa;
                      font-style:normal; font-size:10px; font-weight:700; text-align:center; padding:0 2px; }
  .land .lc2 { display:flex; flex-direction:column; gap:10px; min-width:0; position:relative; z-index:3; }
  .land .weapon2 { padding:9px 10px; background:var(--pnl2); border:1px solid var(--bd); border-radius:11px; }
  .land .weapon2 .wp-top { display:flex; align-items:center; gap:9px; }
  .land .weapon2 .wi { width:52px; height:52px; flex:0 0 52px; border-radius:9px; overflow:hidden;
                       background:${light ? '#eef3fa' : '#0e141d'}; border:1px solid var(--bd); }
  .land .weapon2 .wi img { width:52px; height:52px; object-fit:cover; display:block; }
  .land .weapon2 .wn { font-size:14.5px; font-weight:700; }
  .land .weapon2 .ws { font-size:11px; color:var(--gold); margin-top:2px; }
  .land .weapon2 .wstats2 { display:flex; gap:7px; margin-top:7px; }
  .land .weapon2 .wstats2 span { flex:1; background:${light ? '#eef3fa' : '#0f1720'}; border:1px solid var(--bd2);
                                 border-radius:7px; padding:3px 7px; font-size:10.5px; color:var(--dim); }
  .land .weapon2 .wstats2 b { display:block; font-size:13.5px; color:var(--tx); margin-top:1px; }
  .land .attrs2 { padding:8px 10px; background:var(--pnl2); border:1px solid var(--bd); border-radius:11px; flex:0 0 auto; }
  .land .attrs2 .row { display:flex; align-items:center; gap:6px; height:29px; border-bottom:1px dashed var(--bd2); }
  .land .attrs2 .row:last-child { border-bottom:0; }
  .land .attrs2 .row svg { color:var(--dim2); flex:0 0 15px; width:15px; height:15px; }
  .land .attrs2 .row .lbl { font-size:12.5px; color:var(--dim); }
  .land .attrs2 .row .vv { margin-left:auto; text-align:right; }
  .land .attrs2 .row .vv b { font-size:15px; font-variant-numeric:tabular-nums; }
  .land .attrs2 .row .vv i { display:block; font-style:normal; font-size:9.5px; color:var(--dim2); }
  .land .lc3 { display:flex; flex-direction:column; gap:7px; min-width:0; position:relative; z-index:3; }
  .land .rl { display:flex; gap:10px; padding:11px 12px; background:var(--pnl2); border:1px solid var(--bd); border-radius:11px; }
  .land .rl .ri { position:relative; width:48px; height:48px; flex:0 0 48px; border-radius:9px; overflow:hidden;
                  background:${light ? '#eef3fa' : '#0e141d'}; border:1px solid var(--bd); }
  .land .rl .ri img { width:48px; height:48px; object-fit:cover; display:block; }
  .land .rl .ri .lv { position:absolute; left:0; right:0; bottom:0; text-align:center; font-size:9px; color:#fff;
                      background:rgba(7,10,16,.72); }
  .land .rl .body { min-width:0; flex:1; }
  .land .rl .mainline { display:flex; align-items:baseline; gap:6px; }
  .land .rl .mainline .mn { font-size:11px; color:var(--dim2); white-space:nowrap; }
  .land .rl .mainline .mv { margin-left:auto; font-size:17px; font-weight:800; font-variant-numeric:tabular-nums; }
  .land .rl .subs { display:grid; grid-template-columns:1fr 1fr; gap:3px 14px; margin-top:5px; }
  .land .rl .subs div { display:flex; align-items:baseline; gap:4px; font-size:11.5px; color:var(--dim); }
  .land .rl .subs em { font-style:normal; font-size:9.5px; color:var(--gold); }
  .land .rl .subs b { margin-left:auto; color:var(--tx); font-weight:700; font-size:12px; }
  .land .footbar { grid-column:1 / -1; display:flex; align-items:center; gap:10px; margin-top:2px;
                   padding:9px 12px; background:var(--pnl2); border:1px solid var(--bd); border-radius:11px; }
  .land .footbar .grade2 { display:flex; align-items:baseline; gap:6px; flex:0 0 auto; }
  .land .footbar .grade2 b { font-size:21px; font-weight:800; }
  .land .footbar .grade2 i { font-style:normal; font-size:12px; }
  .land .footbar .bar3 { flex:1; height:7px; border-radius:4px; background:var(--bar); display:flex; overflow:hidden; }
  .land .footbar .bar3 i { display:block; height:100%; }
  .land .footbar .dims3 { display:flex; gap:10px; font-size:10px; color:var(--dim); flex:0 0 auto; }
  .land .footbar .sets3 { font-size:10px; color:var(--dim); flex:0 0 auto; max-width:300px; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
  .land .footfoot { grid-column:1 / -1; display:flex; gap:10px; font-size:10px; color:var(--footc, #5f6b7d); padding:0 4px; }
  .land .footfoot .r { margin-left:auto; }`;
}

function buildPanelHtmlLand(char, player, s, advice) {
  const t = THEMES[s.theme] || THEMES.dark;
  const light = String(t.cardBg).toLowerCase() === '#ffffff';
  const accent = char.elementColor || '#7fd4ff';
  const grade = gradeOf(char.score.total);
  const GRADE_TONE = light
    ? { S: '#a87200', A: '#2f8f4e', B: '#2b6cb0', C: '#7b4fb5', D: '#6b7280' }
    : { S: '#ffcc4d', A: '#7ee787', B: '#79c0ff', C: '#d2a8ff', D: '#8b95a7' };
  const gradeColor = GRADE_TONE[grade.g] || grade.g;
  const art = char.splashData || char.iconData;
  const elIcon = readAttrIcon(char.gameKey, char.elementAttrIdx);

  const skillsV = (char.skillIcons || []).slice(0, 4).map((k) => `
    <div class="ic" title="${escapeHtml(k.label)} ${escapeHtml(String(k.level))}">${k.iconData ? `<img src="${k.iconData}" alt="">` : ''}<i>${escapeHtml(String(k.level))}</i></div>`).join('');
  // 命座/星魂图标：亮 = 已激活，暗 = 未激活
  const consV = (char.constellations || []).map((c) => `
    <div class="ci${c.active ? ' on' : ' off'}" title="C${c.index}${c.name ? `　${c.name}` : ''}（${c.active ? '已激活' : '未激活'}）">${c.iconData ? `<img src="${c.iconData}" alt="">` : ''}</div>`).join('');

  const w = char.weapon;
  const weaponCard = w ? `
    <div class="weapon2">
      <div class="wp-top">
        <div class="wi">${w.iconData ? `<img src="${w.iconData}" alt="">` : ''}</div>
        <div style="min-width:0">
          <div class="wn">${escapeHtml(w.name || '（未知）')}</div>
          <div class="ws">${stars(w.stars)} · ${escapeHtml(char.gearLabel)} ${w.refine} · Lv.${w.level}</div>
        </div>
      </div>
      ${(w.stats || []).length ? `<div class="wstats2">${w.stats.map((x) => `<span>${escapeHtml(x.label)}<b>${escapeHtml(x.value)}</b></span>`).join('')}</div>` : ''}
    </div>` : '';

  const attrs = (char.stats || []).map((x) => {
    const extra = x.sub ? `<i>${escapeHtml(x.sub)}</i>` : '';
    return `<div class="row">${ATTR_ICON[attrIconKey(x.label)] || ATTR_ICON.dot}<span class="lbl">${escapeHtml(x.label)}</span><span class="vv"><b>${escapeHtml(x.value)}</b>${extra}</span></div>`;
  }).join('');

  const relics = (char.relics || []).map((r) => `
    <div class="rl">
      <div class="ri">${r.iconData ? `<img src="${r.iconData}" alt="">` : ''}<div class="lv">+${r.level}</div></div>
      <div class="body">
        <div class="mainline"><span class="mn">${escapeHtml(r.slotName || '')}</span><span class="mv">${escapeHtml(r.mainValue || '')}</span></div>
        <div class="subs">${(r.substats || []).map((x) => `<div><span>${escapeHtml(x.label)}</span>${x.hits > 0 ? `<em>${x.hits}</em>` : ''}<b>${escapeHtml(x.value)}</b></div>`).join('')}</div>
      </div>
    </div>`).join('');

  const barSeg = char.score.dims.map((d) => `<i style="width:${(clamp(d.score / d.max, 0, 1) * 100).toFixed(1)}%;background:${d.color}"></i>`).join('');
  const dims = char.score.dims.map((d) => `<span>${escapeHtml(d.label)} ${d.score.toFixed(0)}/${d.max}</span>`).join('');
  const setsLine = (char.sets || []).length ? char.sets.map((x) => `${escapeHtml(x.name)}×${x.n}`).join(' · ') : '';

  return `<!DOCTYPE html><html><head><meta charset="utf-8"><style>${styleLand(t, accent, s)}</style></head><body><div class="v2">${bgLayers(art, s.bgBlur)}<div class="vbody">
    <div class="land">
      <div class="lc1">
        <div class="artbox${char.artMode === 'icon' ? ' iconmode' : ''}">
          ${art ? `<img src="${art}" alt="">` : ''}
          <div class="artgrad"></div>
          <div class="artname">
            <div class="n">${escapeHtml(char.name)}</div>
            <div class="m">
              <span>Lv.${char.level}</span>
              <span>${escapeHtml(char.consLabel)} ${char.cons}</span>
              ${char.elementName ? `<span class="el"${elIcon ? ` style="background-image:url('${elIcon}')"` : ''}>${escapeHtml(char.elementName)}</span>` : ''}
            </div>
          </div>
        </div>
      </div>
      <div class="lc2">${weaponCard}<div class="attrs2">${attrs}</div></div>
      <div class="lc3">${relics}${consV ? `<div class="crow"><span class="rt">${escapeHtml(char.consLabel)}</span>${consV}</div>` : ''}${skillsV ? `<div class="krow"><span class="rt2">技能</span>${skillsV}</div>` : ''}</div>
      <div class="footbar">
        <div class="grade2"><b style="color:${gradeColor}">${char.score.total.toFixed(1)}</b><i style="color:${gradeColor}">${grade.g}</i><span style="font-size:10px;color:var(--dim2)">练度</span></div>
        <div class="bar3">${barSeg}</div>
        <div class="dims3">${dims}</div>
        <div class="sets3">${setsLine}</div>
      </div>
      <div class="footfoot"><span><b>${escapeHtml(player.nickname || '未知')}</b> · UID ${escapeHtml(player.uid || '')} · ${escapeHtml(player.meta || '')}</span><span>${escapeHtml(player.source || '')}</span><span class="r">${escapeHtml(char.score.note)}</span></div>
    </div>
  </div></div></body></html>`;
}

/* ── 全部角色列表（宽幅表格）─────────────────────────────────────────────── */
const ROSTER_W = 1180;

function styleRoster(t, accent, s = {}) {
  const light = String(t.cardBg).toLowerCase() === '#ffffff';
  return styleV2(t, accent, s) + `
  body { width:${ROSTER_W}px; }
  .v2 { width:${ROSTER_W}px; }
  .rt { padding:14px 18px 16px; }
  .rt .rt-head { display:flex; align-items:baseline; gap:10px; margin-bottom:9px; }
  .rt .rt-head .h1 { font-size:17px; font-weight:800; letter-spacing:1px; }
  .rt .rt-head .h2 { font-size:11px; color:var(--dim); }
  .rt .rt-head .h3 { margin-left:auto; font-size:11px; color:var(--dim2); }
  .rt .hd, .rt .row { display:grid; grid-template-columns:34px 40px 1fr 46px 64px 1fr 92px 74px 78px 74px 74px 62px 62px; gap:6px; align-items:center; }
  .rt .hd { padding:0 8px 6px; font-size:10px; color:var(--dim2); border-bottom:1px solid var(--bd); }
  .rt .row { padding:5px 8px; border-bottom:1px solid var(--bd2); }
  .rt .row:nth-child(even) { background:rgba(${light ? '15,23,42' : '255,255,255'},.03); }
  .rt .rank { font-size:11px; color:var(--dim2); font-variant-numeric:tabular-nums; }
  .rt .av { width:30px; height:30px; border-radius:8px; overflow:hidden; background:${light ? '#e9eff7' : '#0e141d'}; border:1px solid var(--bd); }
  .rt .av img { width:30px; height:30px; object-fit:cover; display:block; }
  .rt .nm { font-size:12.5px; font-weight:600; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
  .rt .nm em { font-style:normal; font-size:10px; color:var(--dim2); margin-left:5px; }
  .rt .cc { display:inline-block; min-width:26px; text-align:center; padding:1px 5px; border-radius:5px; font-size:10.5px; font-weight:700;
            background:${accent}22; border:1px solid ${accent}55; color:${light ? shadeHex(accent, .42) : accent}; }
  .rt .cc.c0 { background:transparent; border-color:var(--bd); color:var(--dim2); }
  .rt .wg { display:flex; align-items:center; gap:4px; min-width:0; }
  .rt .wg img { width:22px; height:22px; border-radius:5px; object-fit:cover; display:block; background:${light ? '#e9eff7' : '#0e141d'}; }
  .rt .wg span { font-size:10px; color:var(--gold); }
  .rt .set { font-size:10.5px; color:var(--dim); white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
  .rt .crit { font-size:12px; font-variant-numeric:tabular-nums; }
  .rt .crit i { font-style:normal; color:var(--dim2); }
  .rt .cv { font-size:12.5px; font-weight:700; font-variant-numeric:tabular-nums; }
  /* 按哪一列排序就高亮哪一列 */
  .rt .row .hot { color:${light ? '#a87200' : '#ffcc4d'}; font-weight:800; }
  .rt .hd .hot { color:${light ? '#a87200' : '#ffcc4d'}; }
  .rt .eb { font-size:11px; color:var(--dim); }
  .rt .num { font-size:11.5px; text-align:right; font-variant-numeric:tabular-nums; color:var(--dim); }
  .rt .foot2 { margin-top:9px; display:flex; gap:10px; font-size:10px; color:var(--dim2); }`;
}

function buildRosterHtml(rows, player, game, s) {
  const t = THEMES[s.theme] || THEMES.dark;
  const accent = game.key === 'genshin' ? '#9fd6e3' : '#b47cf0';
  // 按哪个字段排序，就把那一列高亮出来（不再固定高亮 CV）
  const sortKey = s.rosterSort || 'cv';
  const hot = (k) => (sortKey === k ? ' hot' : '');
  const SORT_LABEL = {
    cv: '暴击词条 CV（暴击率×2 + 暴击伤害）', level: '等级', cons: '命座 / 星魂',
    hp: '生命值', atk: '攻击力', def: '防御力', er: '元素充能效率', crit: '暴击率'
  };
  const body = rows.map((r, i) => `
    <div class="row">
      <div class="rank">${i + 1}</div>
      <div class="av">${r.icon ? `<img src="${r.icon}" alt="">` : ''}</div>
      <div class="nm">${escapeHtml(r.name)}<em${sortKey === 'level' ? ' class="hot"' : ''}>Lv.${r.level}</em></div>
      <div><span class="cc${r.cons ? '' : ' c0'}${hot('cons')}">${r.consLabel}${r.cons}</span></div>
      <div class="wg">${r.weaponIcon ? `<img src="${r.weaponIcon}" alt="">` : ''}<span>${r.refine ? `${r.gearLabel}${r.refine}` : ''}</span></div>
      <div class="set">${escapeHtml(r.sets || '')}</div>
      <div class="crit${hot('crit')}">${r.crit}<i> : </i>${r.cdmg}</div>
      <div class="cv${hot('cv')}">${r.cv.toFixed(1)}</div>
      <div class="eb">${escapeHtml(r.elemBonus || '—')}</div>
      <div class="num${hot('hp')}">${escapeHtml(r.hp)}</div>
      <div class="num${hot('atk')}">${escapeHtml(r.atk)}</div>
      <div class="num${hot('def')}">${escapeHtml(r.def)}</div>
      <div class="num${hot('er')}">${escapeHtml(r.er)}</div>
    </div>`).join('');

  return `<!DOCTYPE html><html><head><meta charset="utf-8"><style>${styleRoster(t, accent, s)}</style></head><body><div class="v2"><div class="vbody">
    <div class="rt">
      <div class="rt-head">
        <span class="h1">${escapeHtml(game.label)} 全部角色</span>
        <span class="h2">${escapeHtml(player.nickname || '')} · UID ${escapeHtml(player.uid || '')}</span>
        <span class="h3">共 ${rows.length} 个角色 · 按「${escapeHtml(SORT_LABEL[sortKey] || 'CV')}」排序（金色 = 当前排序列）</span>
      </div>
      <div class="hd">
        <div>#</div><div>头像</div><div class="${sortKey === 'level' ? 'hot' : ''}">角色</div><div class="${hot('cons').trim()}">${rows[0]?.consLabel || '命座'}</div><div>武器</div><div>套装</div>
        <div class="${hot('crit').trim()}">暴击 : 爆伤</div><div class="${hot('cv').trim()}">CV</div><div>元素增伤</div>
        <div class="${hot('hp').trim()}" style="text-align:right">生命</div>
        <div class="${hot('atk').trim()}" style="text-align:right">攻击</div><div class="${hot('def').trim()}" style="text-align:right">防御</div><div class="${hot('er').trim()}" style="text-align:right">充能</div>
      </div>
      ${body}
      <div class="foot2"><span>${escapeHtml(player.source || '')}</span><span>${escapeHtml(player.meta || '')}</span></div>
    </div>
  </div></div></body></html>`;
}

/** 列表一行需要的字段（数值从面板属性里抠，两个游戏通用） */
function rosterRow(char) {
  const find = (re) => (char.stats || []).find((x) => re.test(x.label));
  const valOf = (x) => (x ? Number(String(x.value).replace(/[^\d.-]/g, '')) || 0 : 0);
  const crit = valOf(find(/暴击率/));
  const cdmg = valOf(find(/暴击伤害/));
  const elem = find(/元素伤害加成|属性伤害提高|伤害加成/);
  const sets = (char.sets || []).length
    ? char.sets.map((x) => `${x.name}×${x.n}`).join(' ')
    : '';
  const hpV = (find(/^生命/) || {}).value || '—';
  const atkV = (find(/^攻击/) || {}).value || '—';
  const defV = (find(/^防御/) || {}).value || '—';
  // 充能没列出来说明就是基础 100%（星铁接口只给有加成的属性）
  const erV = (find(/充能|能量恢复/) || {}).value || '100.0%';
  return {
    name: char.name,
    level: char.level,
    cons: char.cons,
    consLabel: char.consLabel,
    icon: char.iconData,
    weaponIcon: char.weapon?.iconData,
    refine: char.weapon?.refine || 0,
    // 原神叫精炼、星铁叫叠影
    gearLabel: char.gearLabel || '精炼',
    sets,
    crit: `${crit.toFixed(1)}%`,
    cdmg: `${cdmg.toFixed(1)}%`,
    cv: crit * 2 + cdmg,
    elemBonus: elem ? elem.value : '',
    hp: hpV,
    atk: atkV,
    def: defV,
    er: erV,
    // 排序用的数值（列表展示的是字符串，排序必须用数字）
    n: {
      hp: Number(String(hpV).replace(/[^\d.-]/g, '')) || 0,
      atk: Number(String(atkV).replace(/[^\d.-]/g, '')) || 0,
      def: Number(String(defV).replace(/[^\d.-]/g, '')) || 0,
      er: Number(String(erV).replace(/[^\d.-]/g, '')) || 0
    }
  };
}

/** 列表排序：设置里选什么就按什么从大到小 */
function sortRoster(rows, key) {
  const pick = {
    cv: (r) => r.cv,
    level: (r) => r.level,
    cons: (r) => r.cons,
    hp: (r) => r.n.hp,
    atk: (r) => r.n.atk,
    def: (r) => r.n.def,
    er: (r) => r.n.er,
    crit: (r) => r.cv - (r.n.crit || 0)
  };
  const f = pick[key] || pick.cv;
  return rows.slice().sort((a, b) => f(b) - f(a) || b.cv - a.cv);
}


function buildAdviceHtml(game, character, advice, s, art) {
  const t = THEMES[s.theme] || THEMES.dark;
  const accent = game.key === 'genshin' ? '#9fd6e3' : '#b47cf0';
  // 建议卡也走 v2 那套（主题 / 毛玻璃 / 立绘背景都跟面板卡一致）
  const head = `<div class="bar"><span class="tt">${escapeHtml(game.label)} 配装建议</span><span class="hint">${escapeHtml(character)}${advice.title ? ` · ${escapeHtml(advice.title)}` : ''} · B站 wiki</span></div>`;
  const foot = `<div class="foot"><span>资料来自 B站游戏 wiki（玩家编辑维护，可能滞后于最新版本）</span><span class="r">${escapeHtml(advice.urlText || advice.url || '')}</span></div>`;
  const shell = (inner) => `<!DOCTYPE html><html><head><meta charset="utf-8"><style>${styleV2(t, accent, s)}</style></head><body><div class="v2">${bgLayers(art, s.bgBlur)}<div class="vbody">${head}${inner}${foot}</div></div></body></html>`;

  if (!advice.ok) {
    return shell(`<div class="pad"><div class="adv2"><div class="miss">${escapeHtml(advice.reason || '没取到建议')}</div></div></div>`);
  }
  const grp = (g) => `<div class="g"><t>${escapeHtml(g.label)}</t>${g.items.map((x) => `<div class="row"><b>${escapeHtml(x.name)}</b>${x.note ? `<span class="nt">${escapeHtml(x.note)}</span>` : ''}</div>`).join('')}</div>`;
  const inner = `<div class="pad"><div class="adv2">
      ${advice.positioning ? `<div class="pos">${escapeHtml(advice.positioning)}</div>` : ''}
      ${advice.setGroups.map(grp).join('')}
      ${advice.stats.length ? `<div class="g"><t>主词条</t><div class="row">${advice.stats.map((x) => `<b>${escapeHtml(x.label)}</b>${escapeHtml(x.value)}`).join('　')}</div></div>` : ''}
      ${advice.subStats ? `<div class="g"><t>副词条优先级</t><div class="row">${escapeHtml(advice.subStats)}</div></div>` : ''}
      ${advice.weaponGroups.map(grp).join('')}
      ${advice.tips.map((x) => `<div class="g"><t>${escapeHtml(x.label)}</t><div class="row">${escapeHtml(x.value)}</div></div>`).join('')}
      ${advice.partial ? `<div class="g"><div class="miss">${escapeHtml(advice.reason || 'wiki 还没写配装')}</div></div>` : ''}
    </div></div>`;
  return shell(inner);
}

/* ── HTML → PNG（Electron 离线窗口，与 genshin-card 同一套做法）────────────── */
let rendering = false;
async function renderHtmlPng(html, theme, width) {
  const t = THEMES[theme] || THEMES.dark;
  const cssW = Math.max(300, Number(width) || CARD_W);
  let electron = null;
  try {
    const mod = await import('electron');
    electron = mod?.default ?? mod;
  } catch { return null; }
  if (!electron || typeof electron.BrowserWindow !== 'function') return null;
  if (rendering) {
    const t0 = Date.now();
    while (rendering && Date.now() - t0 < 2000) await sleep(50);
    if (rendering) return null;
  }
  rendering = true;
  let win = null;
  try {
    win = new electron.BrowserWindow({
      show: false, skipTaskbar: true, frame: false, useContentSize: true,
      // ⚠️ 这里必须用 CSS 尺寸（DIP）建窗，**不能乘 DPR**：
      //    显示器缩放 != 100%（如 125%、150%）时，乘完的宽度是"设备无关像素"，
      //    实际像素会再乘一次 DPR，卡片只占左边一部分，右侧露出一大片背景色 —— 用户看到"卡片右边一坨黑"。
      width: cssW, height: 260,
      backgroundColor: t.pageBg,
      webPreferences: { offscreen: true, backgroundThrottling: false, sandbox: false, contextIsolation: true, nodeIntegration: false }
    });
    const tmp = path.join(os.tmpdir(), `qq-agent-game-panel-${process.pid}.html`);
    fs.writeFileSync(tmp, html);
    await win.loadFile(tmp);
    await new Promise((resolve) => {
      let done = false;
      const finish = () => { if (!done) { done = true; resolve(); } };
      win.webContents.once('paint', finish);
      setTimeout(finish, 700);
    });
    const h = await win.webContents.executeJavaScript(`(() => {
      const b = document.body; const card = document.querySelector('.card');
      const pad = parseFloat(getComputedStyle(b).paddingBottom || 0);
      const bottom = card ? card.getBoundingClientRect().bottom + pad : 0;
      return Math.ceil(Math.max(b.scrollHeight, b.offsetHeight, bottom));
    })()`);
    const contentH = Math.max(120, (Number(h) || 600) + 2);
    win.setContentSize(cssW, contentH);
    await sleep(140);
    let img = await win.webContents.capturePage();
    // 按**实测像素比**裁切：截图宽 / CSS 宽 = DPR。这样无论显示器缩放多少，图里都只有卡片本身。
    try {
      const size = img.getSize();
      const dpr = size.width / cssW || 1;
      img = img.crop({ x: 0, y: 0, width: size.width, height: Math.min(size.height, Math.round(contentH * dpr)) });
    } catch { /* 裁切失败就用原图 */ }
    const png = img.toPNG();
    if (!png || png.length < 1000) throw new Error('截图为空');
    return png;
  } catch (e) {
    api?.warn?.(`游戏面板卡片渲染失败：${e?.message ?? e}`);
    return null;
  } finally {
    try { win?.destroy?.(); } catch { /* 忽略 */ }
    rendering = false;
  }
}

/* ── 文字摘要（模型看不见图片，追问全靠这段）───────────────────────────── */
function panelSummary(char, player, game, advice) {
  const tal = (char.talents || []).map((x) => `${x.label}${x.main}${x.sub || ''}`).join('/');
  const st = (char.stats || []).map((x) => `${x.label}${x.value}`).join(' ');
  const sets = (char.sets || []).map((x) => `${x.name}×${x.n}`).join('+') || '无套装数据';
  const w = char.weapon
    ? `${game.key === 'genshin' ? '武器' : '光锥'}${char.weapon.name}Lv${char.weapon.level}${char.gearLabel}${char.weapon.refine}`
    : '武器未知';
  const head = `UID ${player.uid}（${player.nickname || '未知昵称'}） ${game.label} ${char.name}${char.costumeAsset ? '（已穿皮肤）' : ''}：`;
  const consText = char.consLabel === '命座' ? `${char.cons}命` : `${char.consLabel}${char.cons}`;
  const main = `${head}练度${char.score.total.toFixed(1)}(${gradeOf(char.score.total).g}) 等级${char.level} ${consText} `
    + `${tal} ${w} ${sets} ${st}`;
  let advText = '';
  if (advice?.ok) {
    const lines = [];
    if (advice.positioning) lines.push(`定位：${advice.positioning}`);
    for (const g of advice.setGroups) lines.push(`${g.label}：` + g.items.map((x) => `${x.name}${x.note ? `（${x.note}）` : ''}`).join('；'));
    if (advice.stats.length) lines.push('主词条：' + advice.stats.map((x) => `${x.label} ${x.value}`).join('；'));
    if (advice.subStats) lines.push(`副词条优先级：${advice.subStats}`);
    for (const g of advice.weaponGroups) lines.push(`${g.label}：` + g.items.map((x) => `${x.name}${x.note ? `（${x.note}）` : ''}`).join('；'));
    for (const x of advice.tips) lines.push(`${x.label}：${x.value}`);
    if (advice.partial) lines.push(`（${advice.reason}）`);
    advText = `\nwiki 养成建议（同样别复述，只用于追问）：${truncate(lines.join(' '), 700)}`;
  } else if (advice) {
    advText = `\n（wiki 建议这次没取到：${advice.reason}）`;
  }
  return main + advText;
}

function adviceSummary(advice) {
  if (!advice?.ok) return advice?.reason || '没取到建议';
  const lines = [];
  if (advice.positioning) lines.push(`定位：${advice.positioning}`);
  for (const g of advice.setGroups) lines.push(`${g.label}：` + g.items.map((x) => `${x.name}${x.note ? `（${x.note}）` : ''}`).join('；'));
  if (advice.stats.length) lines.push('主词条：' + advice.stats.map((x) => `${x.label} ${x.value}`).join('；'));
  if (advice.subStats) lines.push(`副词条优先级：${advice.subStats}`);
  for (const g of advice.weaponGroups) lines.push(`${g.label}：` + g.items.map((x) => `${x.name}${x.note ? `（${x.note}）` : ''}`).join('；'));
  for (const x of advice.tips) lines.push(`${x.label}：${x.value}`);
  if (advice.partial) lines.push(`（${advice.reason}）`);
  return lines.join('\n');
}

/* ── 出图 + 发送（两个工具共用）────────────────────────────────────────── */
async function renderAndSend(ctx, html, theme, fileTag, note, width) {
  const png = await renderHtmlPng(html, theme, width);
  if (!png) return false;
  let ok = false;
  try {
    const pngPath = path.join(os.tmpdir(), `qq-agent-game-panel-${fileTag}-${Date.now()}.png`);
    fs.writeFileSync(pngPath, png);
    await ctx.sender.sendImage(ctx.chatKey, { file: pngPath, dataUrl: 'base64://' + png.toString('base64') }, { note });
    ok = true;
    try { ctx.session?.sent?.push({ type: 'image', text: `[${note}]`, at: new Date().toLocaleTimeString('zh-CN', { hour12: false }) }); } catch { /* 留档失败不影响 */ }
  } catch (e) {
    api?.warn?.(`游戏面板卡片发送失败：${e?.message ?? e}`);
  }
  return ok;
}

const NO_SEND_CHANNEL = '当前环境没有可用的发图通道。';

/* ── 工具 ────────────────────────────────────────────────────────────────── */
export function setup(a) {
  api = a;

  api.registerTool({
    id: 'panel',
    name: '查游戏练度面板',
    description:
      '查某个 UID 的《原神》或《崩坏：星穹铁道》角色练度面板，并**直接发一张卡片图到当前会话**：'
      + '等级 / 命座（星魂）/ 武器（光锥）等级与精炼叠影 / 天赋（行迹）等级 + 面板属性（生命、攻击、防御、速度、暴击率、暴击伤害、击破特攻、效果命中、充能效率等）+ 圣遗物（遗器）套装 + 五维练度评分明细，卡片底部还附该角色在 B站 wiki 的配装建议。'
      + '当群友说「查面板 / 练度 / 我的原神面板 / 星铁面板 / 某个角色练得怎么样」时使用。'
      + 'game 必须给（genshin=原神，starrail=星穹铁道）；没确定是哪个游戏就先反问群友，不要瞎猜。'
      + 'uid 必须给；没给就先反问群友要 UID，绝对不要自己编一个 UID 去查。'
      + 'character 填群友点名的角色名，没点名就留空（会画公开数据里练度最高的那个）。'
      + '数据来自公开接口，不需要登录，查不到大多是对方没公开角色数据，这时如实说明。',
    category: 'query',
    icon: '🎴',
    parameters: {
      type: 'object',
      properties: {
        game: { type: 'string', enum: ['genshin', 'starrail'], description: '游戏：genshin=原神，starrail=崩坏星穹铁道。没确定就先问群友，别猜。' },
        uid: { type: 'string', description: '游戏 UID（9~10 位数字，例如 101000001）。群友没给就反问他要。' },
        character: { type: 'string', description: '要看哪个角色（中文名，例如「胡桃」「黄泉」）。不填=练度最高的那个。' },
        advice: { type: 'boolean', description: '卡片底部是否附上 wiki 配装建议，默认跟设置一致（默认开启）。' }
      }
    },
    async execute(ctx, args) {
      try {
        const s = cfg();
        const game = resolveGame(args?.game) || (s.defaultGame !== 'ask' ? GAMES[s.defaultGame] : null);
        if (!game) {
          return {
            content: '还没确定查的是哪个游戏。请先问群友一句「原神还是星铁？」，拿到答复后带上 game 参数（genshin=原神，starrail=星铁）再调一次。',
            isError: true
          };
        }
        // 容错：模型可能把「101000001 胡桃」整段塞进 uid —— 抠出数字当 UID，剩下的当角色名
        const rawUid = String(args?.uid ?? '').trim();
        const uidHit = rawUid.match(/\d{9,10}/);
        const leftover = rawUid.replace(/\d{9,10}/g, ' ').trim();
        const uid = uidHit ? uidHit[0] : '';
        if (!uid) {
          return { content: `还没给 UID。请群友发一下他的${game.label} UID（9~10 位数字），例如「查${game.label}面板 101000001」。`, isError: true };
        }
        if (!/^\d{9,10}$/.test(uid)) {
          return { content: `UID 格式不对：「${rawUid || uid}」里找不到 9~10 位数字的 UID。`, isError: true };
        }
        if (!ctx?.sender || typeof ctx.sender.sendImage !== 'function' || !ctx?.chatKey) {
          return { content: NO_SEND_CHANNEL, isError: true };
        }

        const got = game.key === 'genshin' ? await genshinPanel(uid) : await starrailPanel(uid);
        if (got.error) return { content: got.error, isError: true };
        const { player, characters } = got;

        const wantName = String(args?.character ?? '').trim() || leftover;
        let picked = characters;
        if (wantName) {
          picked = characters.filter((c) => c.name === wantName || c.name.includes(wantName) || wantName.includes(c.name));
          if (!picked.length) {
            return {
              content: `公开数据里没有「${wantName}」。读到的是：${characters.slice(0, 20).map((c) => c.name).join('、')}${characters.length > 20 ? ' 等' : ''}`,
              isError: true
            };
          }
        }
        const target = picked[0];
        // 三张图并发取（立绘、头像、武器图标互不依赖），坏源有封禁兜底，不会叠成三倍超时
        // 立绘优先用 artRef：原神穿了皮肤时它是 256×256 皮肤头像，否则是 2048×1024 抽卡立绘
        const artImg = target.artRef ? { kind: 'enka', ref: target.artRef } : target.img.splash;
        await attachConstellations(target);
        // 圣遗物部位图标 / 技能图标 / 命座图标 一起并发取（都是小题图，缺哪张都不影响出卡）
        const relicTasks = (target.relics || []).map((r) => loadImg(r.icon, 100, RELIC_TIMEOUT_MS).then((v) => { r.iconData = v; }));
        const skillTasks = (target.skillIcons || []).map((k) => loadImg(k.img, 100).then((v) => { k.iconData = v; }));
        const consTasks = (target.constellations || []).map((c) => loadImg(c.img, 100, RELIC_TIMEOUT_MS).then((v) => { c.iconData = v; }));
        const [iconData, splashData, gearIcon, skinData] = await Promise.all([
          loadImg(target.img.icon),
          loadImg(artImg, 1000, SPLASH_TIMEOUT_MS),
          target.weapon?.img ? loadImg(target.weapon.img) : Promise.resolve(''),
          target.costumeImg ? loadImg(target.costumeImg, 200) : Promise.resolve('')
        ]);
        await Promise.all([...relicTasks, ...skillTasks, ...consTasks]);
        target.iconData = iconData;
        target.costumeIconData = skinData;
        if (splashData) {
          target.splashData = splashData;
        } else if (skinData || iconData) {
          // 高清立绘没取到 → 退用小图，**同时切成不裁切的布局**，否则会被拉成一张大脸
          target.splashData = skinData || iconData;
          target.artMode = 'icon';
        }
        if (target.weapon) target.weapon.iconData = gearIcon;

        const wantAdvice = args?.advice === undefined ? s.adviceOnPanel : args.advice !== false;
        const advice = wantAdvice ? await getAdvice(game, target.name) : null;

        const note = `${game.label} ${target.name}${wantName ? ' 面板' : '（练度最高）'}`;
        const isLand = s.cardStyle === 'landscape';
        const html = isLand
          ? buildPanelHtmlLand(target, player, s, advice)
          : buildPanelHtmlV2(target, player, s, advice);
        const sent = await renderAndSend(ctx, html, s.theme, `${game.key}-${uid}`, note, isLand ? LAND_W : CARD_W);
        // 横版：版式里放不下 wiki 配装，按设置额外补一张建议图（失败不影响主卡）
        let adviceSent = false;
        if (sent && isLand && s.landAdviceImage && advice?.ok) {
          try {
            adviceSent = await renderAndSend(
              ctx,
              buildAdviceHtml(game, target.name, advice, s, target.splashData),
              s.theme,
              `${game.key}-advice-${encodeURIComponent(target.name)}`,
              `${game.label} ${target.name} 配装建议`,
              CARD_W
            );
          } catch (e) { api?.warn?.(`建议图发送失败：${e?.message ?? e}`); }
        }
        const rest = !wantName && characters.length > 1
          ? `\n（公开数据里还有：${characters.filter((c) => c.id !== target.id).slice(0, 12).map((c) => c.name).join('、')} —— 想看别的说名字就行）`
          : '';
        return {
          content: (sent ? '卡片已发出。下面这段是给追问用的文字摘要，**不要再复述一遍**：\n' : '卡片渲染/发送失败，用文字汇报：\n')
            + panelSummary(target, player, game, advice) + rest
        };
      } catch (error) {
        return { content: `查练度面板失败：${error?.message ?? error}`, isError: true };
      }
    }
  });

  api.registerTool({
    id: 'roster',
    name: '查全部角色列表',
    description:
      '把一个 UID 的《原神》或《崩坏：星穹铁道》**全部角色**列成一张表并直接发图：'
      + '按暴击词条 CV 排序（CV = 暴击率×2 + 暴击伤害），每行含 头像 / 角色 / Lv / 命座（星魂）/ 武器精炼 / 圣遗物（遗器）套装 / 暴击:爆伤 / CV / 元素增伤 / 生命 / 攻击 / 防御 / 充能。'
      + '当群友说「看看我的角色 / 我都有谁 / 全部角色 / 谁练得最好 / 排个练度 / 词条最好的是谁」时使用。'
      + 'game 必须给（genshin=原神，starrail=星穹铁道）；uid 必须给，没给就先反问群友。'
      + '只想看某一个角色的详细面板时用 panel 工具，不要用这个。',
    category: 'query',
    icon: '📋',
    parameters: {
      type: 'object',
      properties: {
        game: { type: 'string', enum: ['genshin', 'starrail'], description: '游戏：genshin=原神，starrail=崩坏星穹铁道。' },
        uid: { type: 'string', description: '游戏 UID（9~10 位数字）。群友没给就反问他要。' },
        limit: { type: 'number', description: '最多列多少个角色，默认全部（展柜通常 8~25 个）。' }
      }
    },
    async execute(ctx, args) {
      try {
        const s = cfg();
        const game = resolveGame(args?.game) || (s.defaultGame !== 'ask' ? GAMES[s.defaultGame] : null);
        if (!game) {
          return { content: '还没确定查的是哪个游戏。请先问群友一句「原神还是星铁？」，再用 game 参数（genshin / starrail）调一次。', isError: true };
        }
        const rawUid = String(args?.uid ?? '').trim();
        const uidHit = rawUid.match(/\d{9,10}/);
        if (!uidHit) {
          return { content: `还没给 UID。请群友发一下他的${game.label} UID（9~10 位数字），例如「看看我的${game.label}角色 123456789」。`, isError: true };
        }
        const uid = uidHit[0];
        if (!ctx?.sender || typeof ctx.sender.sendImage !== 'function' || !ctx?.chatKey) {
          return { content: NO_SEND_CHANNEL, isError: true };
        }

        const got = game.key === 'genshin' ? await genshinPanel(uid) : await starrailPanel(uid);
        if (got.error) return { content: got.error, isError: true };
        const { player, characters } = got;
        const cap = Math.max(1, Math.min(60, num(args?.limit, 0) || characters.length));

        // 头像 + 武器图标：列表里只用到这两张，并发取（取不到就留空，不阻塞）
        await Promise.all(characters.slice(0, cap).map(async (c) => {
          const [av, wp] = await Promise.all([
            c.img?.icon ? loadImg(c.img.icon) : Promise.resolve(''),
            c.weapon?.img ? loadImg(c.weapon.img) : Promise.resolve('')
          ]);
          c.iconData = av;
          if (c.weapon) c.weapon.iconData = wp;
        }));

        const rows = sortRoster(characters.slice(0, cap).map((c) => rosterRow(c)), s.rosterSort);
        if (!rows.length) return { content: `${game.label} UID ${uid} 的公开角色列表是空的，可能对方没公开角色数据。`, isError: true };

        const note = `${game.label} 全部角色（${rows.length}）`;
        const html = buildRosterHtml(rows, player, game, s);
        const sent = await renderAndSend(ctx, html, s.theme, `${game.key}-${uid}-roster`, note, ROSTER_W);
        const top = rows.slice(0, 6).map((r, i) => `${i + 1}. ${r.name}（Lv.${r.level} ${r.consLabel}${r.cons}，CV ${r.cv.toFixed(1)}，${r.crit}/${r.cdmg}）`).join('\n');
        return {
          content: (sent ? '角色列表已发出。下面是给追问用的摘要，**不要再复述一遍**：\n' : '列表渲染/发送失败，用文字汇报：\n')
            + `${game.label} UID ${uid}（${player.nickname || '未知'}）共 ${rows.length} 个角色，按 CV 排序前 6：\n${top}`
        };
      } catch (error) {
        return { content: `查角色列表失败：${error?.message ?? error}`, isError: true };
      }
    }
  });

  api.registerTool({
    id: 'build_advice',
    name: '查角色配装建议',
    description:
      '查《原神》或《崩坏：星穹铁道》某个角色的配装 / 养成建议，数据来自 B站游戏 wiki 的攻略页，并**默认直接发一张建议卡到当前会话**：'
      + '角色定位、圣遗物（遗器）套装推荐与理由、主词条、副词条优先级、毕业与可选武器（光锥）。'
      + '当群友问「XX 怎么配装 / 带什么圣遗物（遗器）/ 用什么武器（光锥）/ 主词条副词条怎么选 / 这个角色怎么养」而**没有给 UID** 时使用（给了 UID 想看他自己练得怎么样，用 panel 工具）。'
      + 'game 必须给（genshin=原神，starrail=星穹铁道）。角色名要用游戏里的中文名，wiki 上查不到这个角色的攻略页时会如实说明。',
    category: 'knowledge',
    icon: '📖',
    parameters: {
      type: 'object',
      properties: {
        game: { type: 'string', enum: ['genshin', 'starrail'], description: '游戏：genshin=原神，starrail=崩坏星穹铁道。' },
        character: { type: 'string', description: '角色中文名，例如「胡桃」「黄泉」「流萤」。' }
      },
      required: ['game', 'character']
    },
    async execute(ctx, args) {
      try {
        const s = cfg();
        const game = resolveGame(args?.game);
        if (!game) return { content: '没确定是哪个游戏。请先问群友「原神还是星铁？」，再用 game 参数（genshin / starrail）调一次。', isError: true };
        const character = String(args?.character ?? '').trim();
        if (!character) return { content: '缺少 character 参数：请把群友问的那个角色中文名填进来。', isError: true };
        if (!ctx?.sender || typeof ctx.sender.sendImage !== 'function' || !ctx?.chatKey) {
          return { content: NO_SEND_CHANNEL, isError: true };
        }

        const advice = await getAdvice(game, character);
        const note = `${game.label} ${character} 配装建议`;
        const sent = advice.ok
          ? await renderAndSend(ctx, buildAdviceHtml(game, character, advice, s), s.theme, `${game.key}-advice-${encodeURIComponent(character)}`, note)
          : false;
        const text = adviceSummary(advice);
        const hint = advice.ok
          ? (sent ? '建议卡已发出。下面这段资料供你组织回答，别整段照抄，只讲群友问到的部分：\n' : '建议卡渲染/发送失败，用下面这段资料回答：\n')
          : '没取到 wiki 建议，如实告诉群友，不要凭记忆编具体数值：\n';
        return {
          content: hint + text + (advice.ok ? `\n（wiki 页面：${advice.url}｜玩家编辑维护，可能滞后于最新版本）` : '')
        };
      } catch (error) {
        return { content: `查配装建议失败：${error?.message ?? error}`, isError: true };
      }
    }
  });

  api.log?.(
    `游戏练度面板已加载（原神中文名库 ${Object.keys(AVATARS).length} 条 / 武器 ${Object.keys(WEAPONS).length} 把 / 套装 ${Object.keys(RELIQUARY).length} 套；`
    + '原神数据源 Enka.Network，星铁数据源 api.mihomo.me，建议源 B站游戏 wiki）'
  );
}

export function available() {
  try {
    if (!Object.keys(AVATARS).length && !Object.keys(WEAPONS).length) {
      return { ok: false, reason: 'data/avatars.json 与 data/weapons.json 都读不到（原神中文名 / 图标库缺失，原神面板会显示不出角色名）' };
    }
    return { ok: true };
  } catch (e) {
    return { ok: false, reason: `数据文件读取失败：${e?.message ?? e}` };
  }
}

// 纯函数导出：给自测脚本用（不影响运行期）
export const internals = {
  cfg, resolveGame, gradeOf,
  parseGenshinCharacter, parseStarRailCharacter,
  genshinPanel, starrailPanel, fetchGenshin, fetchStarRail, loadImg, orderedBases, SR_ICON_BASES, GS_ASSET_BASES, ASSET_GROUPS, baseStats,
  resolveCostumes, fetchCostumeMap, costumeCache, fmtMainProp,
  attachConstellations, fetchGenshinConstellations, readAttrIcon, consCache,
  wikiWikitext, getAdvice, fetchAdvice, countRollHits,
  buildPanelHtml, buildAdviceHtml, buildPanelHtmlV2, panelSummary, adviceSummary,
  buildPanelHtmlLand, buildRosterHtml, rosterRow, sortRoster, styleV2, styleLand, styleRoster, CARD_W, LAND_W, ROSTER_W,
  sectionOf, findTemplateBody, parseTemplateParams, unwrapWiki, fetchAdvice
};
