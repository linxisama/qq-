// 卡拉彼丘知识库 —— 从 biligame wiki（klbq）抓取条目，整理成可读文本交给模型回答。
//
// 数据来源（MediaWiki，公开可读，无需登录 / Cookie）：
//   https://wiki.biligame.com/klbq/api.php
//   · 搜索：  action=query&list=search&srsearch=<关键词>
//   · 取正文：action=parse&page=<标题>&prop=text[&section=N]  → 渲染后 HTML，再去标签成纯文本
//
// 与 sgs-knowledge 的差别（卡拉彼丘 wiki 的实际结构）：
//   ① 角色是「主条目 + 子页面」：`芙拉薇娅` / `芙拉薇娅/档案馆` / `芙拉薇娅/语音台词` / `芙拉薇娅/画廊`
//      → 抓正文时**优先主条目**，把子页面列成"相关条目"让模型按需用 klbq_page 取。
//   ② 搜索结果里常混进 `剧情故事/…`、`官方视频/…`、`…更新公告` 这类噪音
//      → 给它们降权，正文优先取主条目，噪音只在没有更好选择时才用。
//
// 韧性设计（biligame 全站都限流，实测连打十几次就整片 HTTP 567）：
//   请求间隔 ≥1.2s；每分钟最多 6 次；撞 567 整体冷却 5 分钟；
//   冷却/断网时优先用过期缓存兜底，最后才退回"让模型凭常识回答"。

const KLBQ_API = 'https://wiki.biligame.com/klbq/api.php';
const KLBQ_BASE = 'https://wiki.biligame.com/klbq/';

const DEFAULT_MAX_CHARS = 1800;
const DEFAULT_TIMEOUT = 15000;
const DEFAULT_CACHE_MIN = 30;
const SEARCH_LIMIT = 8;
const TOP_INTRO = 2;

let cfg = () => ({});
let apiFetch = null;

// ---------- 文本处理 ----------

function decodeEntities(s) {
  return String(s)
    .replace(/&nbsp;|&#160;/gi, ' ')
    .replace(/&lt;/gi, '<')
    .replace(/&gt;/gi, '>')
    .replace(/&quot;/gi, '"')
    .replace(/&#39;|&apos;/gi, "'")
    .replace(/&mdash;/gi, '—')
    .replace(/&amp;/gi, '&');
}

/** 把渲染后的 HTML 压成纯文本（去样式/脚本/标签，顺手清掉引用角标 [1]）。 */
function htmlToText(html) {
  return decodeEntities(
    String(html)
      .replace(/<style[\s\S]*?<\/style>/gi, ' ')
      .replace(/<script[\s\S]*?<\/script>/gi, ' ')
      .replace(/<[^>]+>/g, ' ')
  )
    .replace(/\[[\d, ]*\]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

function truncate(s, n) {
  const t = String(s || '');
  if (t.length <= n) return t;
  const cut = t.slice(0, n).replace(/\s+\S*$/, '');
  return `${cut}…`;
}

function clamp(n, lo, hi) {
  const v = Number(n);
  if (!Number.isFinite(v)) return lo;
  return Math.min(hi, Math.max(lo, Math.round(v)));
}

/** 清掉 wiki 固定标语与坏模板噪音。 */
function cleanWikiNoise(text) {
  return String(text || '')
    .replace(/欢迎来到[^！!。]{0,24}页面！[\s\S]{0,160}?刷新页面。?/g, ' ')
    .replace(/表\s*编\s*刷\s*历/g, ' ')
    .replace(/您的查询中有未匹配[^。]{0,20}。?/g, ' ')
    .replace(/查询描述有空条件。?/g, ' ')
    .replace(/MediaWiki:[A-Za-z]+\.js/g, ' ')
    .replace(/\(function\(\)\s*\{[\s\S]{0,200}?\}\)\(\);?/g, ' ')
    .replace(/\[\[[^\]]{0,120}\]\]/g, ' ')
    .replace(/\s{2,}/g, ' ')
    .trim();
}

const NOISE_TITLE = /^(剧情故事|官方视频|音乐|活动|公告)\//;

/** 正文候选排序：主条目优先，子页面其次，剧情/视频/公告最后。 */
function pickForIntro(results, query) {
  const q = String(query || '').trim();
  const rank = (t) => {
    if (t === q) return 0;                                   // 完全命中
    if (t.includes('/')) return NOISE_TITLE.test(t) ? 3 : 2; // 角色子页面 vs 剧情/视频
    if (/更新公告|赛季更新/.test(t)) return 3;                // 补丁公告
    return 1;                                                // 其它正常条目
  };
  return [...results]
    .map((r) => ({ r, k: rank(String(r.title || '')), w: Number(r.wordcount) || 0 }))
    .sort((a, b) => a.k - b.k || b.w - a.w)
    .filter((x, _i, arr) => x.k < 3 || arr.every((y) => y.k >= 3))  // 有正常条目就不用噪音
    .slice(0, TOP_INTRO)
    .map((x) => x.r);
}

/** 与查询同名的主条目的子页面（如 芙拉薇娅/档案馆）。 */
function subpagesOf(query, results) {
  const q = String(query || '').trim();
  if (!q) return [];
  return results
    .map((r) => String(r.title || ''))
    .filter((t) => t.startsWith(`${q}/`));
}

// ---------- 缓存（内存，进程内） ----------

const cache = new Map(); // key -> { at, value }

function cacheGet(key, { stale = false } = {}) {
  const hit = cache.get(key);
  if (!hit) return null;
  if (stale) return hit.value;              // 限流/断网时允许拿过期副本兜底
  const ttl = clamp(Number(cfg().cacheMinutes ?? DEFAULT_CACHE_MIN), 0, 1440) * 60000;
  if (ttl <= 0) return null;
  if (Date.now() - hit.at > ttl) { cache.delete(key); return null; }
  return hit.value;
}

function cacheSet(key, value) {
  cache.set(key, { at: Date.now(), value });
  if (cache.size > 300) {
    for (const k of [...cache.keys()].slice(0, 100)) cache.delete(k);
  }
}

// ---------- 抓取（节流 + 冷却） ----------

const MIN_REQ_GAP_MS = 1500;
const MAX_REQ_PER_MIN = 4;                  // 与 sgs 技能共用同一个 IP，故意压得很保守
const COOLDOWN_AFTER_LIMIT_MS = 5 * 60000;
let lastReqAt = 0;
let cooldownUntil = 0;
const reqTimes = [];
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

async function waitTurn() {
  for (;;) {
    const now = Date.now();
    while (reqTimes.length && now - reqTimes[0] > 60000) reqTimes.shift();
    const gapWait = lastReqAt + MIN_REQ_GAP_MS - Date.now();
    const quotaWait = reqTimes.length >= MAX_REQ_PER_MIN ? (reqTimes[0] + 60000 - Date.now()) : 0;
    const wait = Math.max(gapWait, quotaWait, 0);
    if (wait <= 0) break;
    await sleep(Math.min(wait, 5000));
  }
  const now = Date.now();
  lastReqAt = now;
  reqTimes.push(now);
}

function fetchOptions() {
  const ms = clamp(Number(cfg().timeoutMs) || DEFAULT_TIMEOUT, 3000, 60000);
  const headers = { 'User-Agent': 'QQAgent-Skill/1.0 (klbq-knowledge)' };
  try { return { signal: AbortSignal.timeout(ms), headers }; } catch { return { headers }; }
}

async function getJson(params, { retries = 1 } = {}) {
  if (Date.now() < cooldownUntil) {
    throw new Error(`wiki 正在限流冷却（还剩 ${Math.ceil((cooldownUntil - Date.now()) / 1000)} 秒）`);
  }
  const url = `${KLBQ_API}?${new URLSearchParams(params).toString()}`;
  const doFetch = apiFetch || globalThis.fetch;
  let lastError = null;
  for (let attempt = 0; attempt <= retries; attempt++) {
    await waitTurn();
    try {
      const res = await doFetch(url, fetchOptions());
      if (res.status === 567 || res.status === 429 || res.status === 503) {
        cooldownUntil = Date.now() + COOLDOWN_AFTER_LIMIT_MS;
        throw new Error(`wiki 限流（HTTP ${res.status}），已进入 ${Math.round(COOLDOWN_AFTER_LIMIT_MS / 60000)} 分钟冷却`);
      }
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const json = await res.json();
      if (json?.error) throw new Error(json.error.info || json.error.code || 'API 返回错误');
      return json;
    } catch (error) {
      lastError = error;
      const transient = /Timeout|fetch failed|ECONN|socket|HTTP 5\d\d/.test(String(error?.name || '') + String(error?.message || ''));
      const limiter = /限流|冷却/.test(String(error?.message || ''));
      if (attempt < retries && transient && !limiter) { await sleep(2000); continue; }
      throw error;
    }
  }
  throw lastError || new Error('请求失败');
}

async function searchWiki(q) {
  const key = `s:${q}`;
  const cached = cacheGet(key);
  if (cached) return cached;
  try {
    const json = await getJson({
      action: 'query', list: 'search', srsearch: q,
      srlimit: SEARCH_LIMIT, format: 'json', formatversion: '2'
    });
    const out = json?.query?.search || [];
    cacheSet(key, out);
    return out;
  } catch (error) {
    const stale = cacheGet(key, { stale: true });
    if (stale) return stale;
    throw error;
  }
}

async function getPageText(title, section) {
  const key = `p:${title}:${section ?? ''}`;
  const cached = cacheGet(key);
  if (cached) return cached;
  const params = { action: 'parse', page: title, prop: 'text', format: 'json', formatversion: '2' };
  if (section !== undefined && section !== null && section !== '' && section !== 'all') {
    params.section = String(section);
  }
  try {
    const json = await getJson(params);
    const html = json?.parse?.text;
    if (!html) throw new Error('页面没有返回内容');
    const text = cleanWikiNoise(htmlToText(html));
    cacheSet(key, text);
    return text;
  } catch (error) {
    const stale = cacheGet(key, { stale: true });
    if (stale) return stale;
    throw error;
  }
}

// ---------- 技能入口 ----------

export function setup(api) {
  cfg = api.config;
  apiFetch = typeof api.fetch === 'function' ? api.fetch : null;

  // ── ① 按关键词查（搜 + 优先抓主条目正文）───────────────────────────────
  api.registerTool({
    id: 'klbq_query',
    name: '查卡拉彼丘知识',
    description:
      '查询《卡拉彼丘》（卡丘 / Strinova）相关知识，数据来自 biligame 官方 wiki。'
      + '被问到超弦体（角色/技能/觉醒/大招）、武器与枪械改装、战术道具、地图、模式、'
      + '弦化机制与弦能量/弦能增幅网络、时装皮肤、剧情世界观、赛季与版本更新公告时使用。'
      + '参数 query 写要查的关键词（如「芙拉薇娅」「弦化」「信标」「心夏」），拿不准的专有名词直接传。'
      + '注意：角色 wiki 是「主条目 + 子页面」，本工具优先给主条目；'
      + '想看档案/语音/画廊等子页面，用 klbq_page 传完整标题（如「芙拉薇娅/档案馆」）。'
      + '工具只给 wiki 资料，由你据此组织自然口语回答，不要编造 wiki 里没有的数值。',
    category: 'knowledge',
    icon: '🎯',
    defaultEnabled: true,
    parameters: {
      type: 'object',
      properties: {
        query: { type: 'string', description: '要查的卡拉彼丘关键词：角色名、武器名、地图名、机制名词等' }
      },
      required: ['query']
    },
    async execute(_ctx, args) {
      const query = String(args?.query || '').trim();
      if (!query) {
        return { content: '缺少 query 参数：把要查的卡拉彼丘内容（角色名、武器名、机制关键词）告诉我。', isError: true };
      }
      const maxChars = clamp(Number(cfg().maxChars) || DEFAULT_MAX_CHARS, 200, 4000);
      try {
        const results = await searchWiki(query);
        if (!results.length) {
          return {
            content: `卡拉彼丘 wiki 上没有搜到与「${query}」相关的条目。`
              + '请基于你自身对卡拉彼丘的了解回答，并说明这是基于常识、非官方实时资料。'
          };
        }
        const picks = pickForIntro(results, query);
        const blocks = [];
        const titles = [];
        const failures = [];
        for (const r of picks) {
          titles.push(r.title);
          try {
            const text = await getPageText(r.title, '0');
            if (!text) continue;
            blocks.push(`■ ${r.title}（${KLBQ_BASE}?curid=${r.pageid}）\n${truncate(text, maxChars)}`);
          } catch (error) {
            failures.push(`${r.title}（${error?.message ?? error}）`);
          }
        }
        const related = results.map((r) => r.title);
        const subs = subpagesOf(query, results);
        const tail = `相关条目：${related.join('、')}`
          + (subs.length ? `\n（同名子页面：${subs.join('、')} —— 要哪一份就用 klbq_page 传完整标题；这类子页面的正文多在后面章节，取页时建议 section 传 "all"。）` : '')
          + (failures.length ? `\n（有 ${failures.length} 条正文没抓到：${failures.join('；')}）` : '');

        if (!blocks.length) {
          const snips = results.slice(0, 3)
            .map((r) => `■ ${r.title}\n${decodeEntities(r.snippet || '')}`).join('\n\n');
          return {
            content: `（wiki 正文抓取失败，以下是搜索摘要）\n${snips}\n\n${tail}\n\n`
              + `请结合以上线索与你的常识回答「${query}」。`
          };
        }
        return {
          content: `以下是从卡拉彼丘 biligame wiki 查到的资料（来源条目：${titles.join('、')}），`
            + `请据此用自然口语回答，不要照抄大段原文，只给与问题相关的关键信息：\n\n`
            + `${blocks.join('\n\n')}\n\n${tail}`
        };
      } catch (error) {
        const reason = error?.name === 'TimeoutError' ? '抓取超时' : (error?.message ?? error);
        return {
          content: `联网查询卡拉彼丘 wiki 失败（${reason}）。`
            + '请基于你自身对卡拉彼丘的了解回答，并说明这是基于常识、非官方实时资料。'
        };
      }
    }
  });

  // ── ② 按精确标题取页（主条目 / 子页面 / 指定章节）───────────────────────
  api.registerTool({
    id: 'klbq_page',
    name: '取卡拉彼丘词条',
    description:
      '按**准确标题**取卡拉彼丘 wiki 的某个词条正文（klbq_query 给出候选标题后用）。'
      + '适合：取角色的子页面（「芙拉薇娅/档案馆」「芙拉薇娅/语音台词」「芙拉薇娅/画廊」）、'
      + '取某张地图/武器的完整条目、或按章节号取某个长页的某一节。'
      + '参数 title 必须写准（含斜杠、括号等原样照抄）；section 传章节号（从 0 开始），留空取第 0 节。'
      + '⚠️ 档案馆/画廊/语音台词这类子页面的第 0 节往往只有导航条，正文在后面章节 —— 取这类页面请传 section:"all"，或依次传 1、2…。',
    category: 'knowledge',
    icon: '📄',
    defaultEnabled: true,
    parameters: {
      type: 'object',
      properties: {
        title: { type: 'string', description: '词条准确标题，如「芙拉薇娅」「芙拉薇娅/档案馆」「弦化」' },
        section: { type: 'string', description: '可选：章节号（0、1、2…）或 all 取整页；默认 0' }
      },
      required: ['title']
    },
    async execute(_ctx, args) {
      const title = String(args?.title || '').trim();
      if (!title) return { content: '缺少 title 参数。', isError: true };
      const section = args?.section === undefined || args?.section === null || args?.section === ''
        ? '0' : String(args.section).trim();
      const maxChars = clamp(Number(cfg().maxChars) || DEFAULT_MAX_CHARS, 200, 4000);
      try {
        const text = await getPageText(title, section);
        if (!text) return { content: `词条「${title}」没有取到正文（可能是空页或章节号不存在）。`, isError: true };
        const url = `${KLBQ_BASE}${encodeURIComponent(title.replace(/ /g, '_'))}`;
        return {
          content: `卡拉彼丘 wiki 词条「${title}」（${url}，第 ${section} 节）：\n\n`
            + `${truncate(text, maxChars)}\n\n请据此用自然口语回答，只给相关的关键信息。`
        };
      } catch (error) {
        const raw = error?.name === 'TimeoutError' ? '抓取超时' : (error?.message ?? error);
        const reason = /doesn't exist|missingtitle|invalidtitle|badtitle/i.test(String(raw))
          ? 'wiki 上没有这个条目（标题要写准，含斜杠/括号原样照抄）'
          : raw;
        return { content: `取词条「${title}」失败（${reason}）。标题要写准，或先用 klbq_query 搜一下拿候选标题。`, isError: true };
      }
    }
  });
}

export function dispose() {
  cache.clear();
}

export default { setup, dispose };
