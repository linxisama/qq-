// 深度思考（deep-think）—— 关键词触发，临时卸下角色卡，答完自动戴回
//
// ── 为什么是技能（skills/，LLM 型）而不是插件 ──────────────────────────────
//   判据（src/skills/manifest.js 的 DIR_KIND 与两种目录语义）：
//     plugins/ 确定性型 —— 提供**能力**（providers）或**钩子**（hooks），核心按能力名取用；
//     skills/  LLM 型   —— 注册**工具**（registerTool）+ 提示词片段，进模型的 function 列表。
//   这里要做的事是"改变模型这一次怎么说话"——本质是**提示词层的加工**，必须由
//   模型自己带着新身份去组织语言，没有任何"确定性执行"能替代（不能把嘴替模型动）。
//   同时它要按语境判断"这句『深度思考』到底是不是在让我出戏"（比如群里在聊
//   『那个深度思考功能』就不是触发），这需要理解人话。两个理由都指向 skills/。
//
// 它做三件事（全在 hooks 里，都在本轮回复之前/之后发生）：
//   1. before-llm-messages：本轮消息命中关键词 → 把 system 角色卡临时换成助手人设；
//   2. after-response：本轮答完 → 标记"该恢复"，让下一轮回到原角色卡；
//   3. promptSections：给模型一份说明书，让她自己也知道"深度思考"是什么意思。
//
// ⚠️ 照 src/plugin-loader.js 的规矩办的几件事（做错了会**静默失效**，不报错）：
//   · hooks / promptSections 必须**模块顶层 export** —— api 上没有注册钩子的方法；
//     写成 `api.registerHook(...)` 之类是不存在的，功能会悄无声息地不生效。
//   · 钩子从文件**顶层导出**，但不要在模块顶层读配置/碰磁盘 —— setup() 才是安全时机。
//   · 配置一律走 getSkillConfig(id, DEFAULTS)，别自己读文件。
//
// ── 关键设计：不改用户的配置，只在提示词这一层"临时换帽子" ────────────────
//   曾经考虑过直接写 personaByChat 来换角色卡 —— 那是**破坏性**的：一旦回答完
//   进程崩了/被关掉，用户自己配的角色卡就永久被助手人设覆盖了，而他没改过任何
//   设置，根本查不出为什么。所以这里绝不写 config，原角色卡始终原封不动地留在
//   设置里；我们只在**这一次请求的 messages 数组**里替换 system 内容。
//   messages 是同一个数组引用、允许原地修改（见 orchestrator 的 before-llm-messages）。
//
// ── 为什么必须"答完立刻恢复"────────────────────────────────────────────────
//   状态只在**内存**里按 chatKey 记一个 tick，且带 TTL。回复完成（after-response）
//   就清掉，所以下一轮自然回到原角色卡；即使 after-response 因为异常没跑到，
//   TTL 到期也会自动失效 —— 不会出现"永久卡在助手口吻"的状态。

import { getSkillConfig } from '../../src/skills/config.js';

const SKILL_ID = 'deep-think';
const PREFIX = `${SKILL_ID}__`;

/** 与 skill.json 的 settings 保持一致（留一份是为了加载顺序与容错）。 */
const DEFAULTS = {
  enabled: true,
  keywords: '深度思考,深度思考一下,认真想想,认真思考',
  assistantPrompt: '你现在处于「深度思考」模式：暂时卸下群友角色扮演，以通用 AI 助手的身份认真、严谨地回答这个问题。要求：逻辑清晰、条理分明、该展开就展开，不要为了「像群友」而刻意短句或玩梗；不确定的地方要说明不确定，不要编造。只回答这一个问题，回答完毕后会自动恢复原来的角色。',
  announceSwitch: true
};

/**
 * 已经切到"思考模式"的会话（chatKey → 过期时间戳）。
 *
 * 只影响**被触发的那一轮**：after-response 立刻删掉，下一轮就是原角色卡。
 * TTL 是兜底 —— 万一 after-response 没跑到（请求异常中止等），
 * 也不会把会话永久卡在助手口吻里。
 */
const thinkingUntil = new Map();
const THINK_TTL_MS = 5 * 60 * 1000;

/**
 * 记录本轮"命中关键词"的会话，after-response 时据此清理。
 * 单独一张表的原因：进入思考模式后会替换 system，不能再靠 system 里有没有
 * 标记来判断"这一轮是不是思考轮"——得在替换之前先记下来。
 */
const thinkingThisRound = new Set();

const host = { api: null };
let log = () => {};
let warn = () => {};

// ─────────────────────────────────────────────── 小工具
function cfg() {
  try {
    return { ...DEFAULTS, ...(getSkillConfig(SKILL_ID, DEFAULTS) || {}) };
  } catch {
    return { ...DEFAULTS };
  }
}

/** 关键词表：允许中英文逗号、顿号、换行分隔，去掉空白与空项。 */
function keywordList(raw) {
  return String(raw || '')
    .split(/[,，、\n\r]+/)
    .map((s) => s.trim())
    .filter(Boolean);
}

/**
 * 从 messages 里取出"这一轮**新进来的**消息"文本。
 *
 * ⚠️ 为什么不能扫全部非 system 内容（2026-10-05 修）：
 *   用户提示词里除了【未读信息】（这一轮的新消息），还包含【已读信息】——
 *   整个会话的最近聊天记录，其中**机器人自己的历史发言**是被标成"我"的。
 *   如果无差别扫描，"她自己以前说过一次『深度思考』"会在之后每一轮都被重新
 *   匹配到，表现为"这个词只出现过一次，之后却一直出戏"——极难排查的幽灵触发。
 *   所以只认最后一条 user 消息里的【未读信息】段（那才是"别人刚说的话"）。
 *   拿不到该段时退回"只扫最后一条 user 消息"，仍能避开历史与她自己的发言。
 */
function incomingTextOf(messages) {
  const list = Array.isArray(messages) ? messages : [];
  // 从后往前找最后一条 user 消息（tool 结果也是 role:tool，不会被当成用户发言）
  for (let i = list.length - 1; i >= 0; i--) {
    const m = list[i];
    if (!m || m.role !== 'user') continue;
    const text = typeof m.content === 'string'
      ? m.content
      : (Array.isArray(m.content) ? m.content.map((p) => (p && typeof p.text === 'string' ? p.text : '')).join('') : '');
    // 优先只取【未读信息】段：那一段才是"这一轮别人刚说的话"。
    // 【已读信息】/【记忆】等同一条消息里的其它段要排除掉。
    const idx = text.indexOf('【未读信息】');
    if (idx >= 0) return text.slice(idx);
    // 没有分段结构（如主动机会/精简提示词）→ 整条当作新内容
    return text;
  }
  return '';
}

/**
 * 关键词是否出现。
 *
 * 故意做得**宽松**（不做"是不是在聊这个功能"的语义判断）：判断该不该出戏这件事
 * 交给模型 —— 我们只把"出现了这个词"作为强提示递给她，同时在 playbook 里写清楚
 * "如果群友只是在讨论这个功能本身，就不用出戏"。硬编码语义判断只会误伤。
 */
function matchedKeyword(text, keywords) {
  const hay = String(text || '');
  if (!hay) return '';
  for (const k of keywords) if (k && hay.includes(k)) return k;
  return '';
}

function clean(s, max = 400) {
  return String(s ?? '').replace(/\s+/g, ' ').trim().slice(0, max);
}

function liveThinking(chatKey) {
  const until = thinkingUntil.get(String(chatKey || ''));
  if (!until) return false;
  if (Date.now() > until) { thinkingUntil.delete(String(chatKey || '')); return false; }
  return true;
}

/** 组装"思考模式"的 system 内容：助手说明书 + 一段临时身份声明。 */
function buildThinkingSystem(originalSystem, assistantPrompt, keyword) {
  const guide = clean(assistantPrompt, 2000) || DEFAULTS.assistantPrompt;
  return [
    '# 当前模式：深度思考（临时）',
    `群友说了「${keyword}」，你在这一轮里**暂时卸下**平时的角色扮演，改用下面这套身份来回答。`,
    '',
    guide,
    '',
    '⚠️ 这一轮只针对上面这一个问题。回答完之后你**立刻**恢复原来的角色设定，',
    '不要在这条回复里解释你的身份切换，也不要预告"我马上要变回去了"。',
    '',
    '──── 以下是你原本的角色卡，本轮**暂停生效**（仅供参考，不要照着它说话）────',
    String(originalSystem || '')
  ].join('\n');
}

// ─────────────────────────────────────────────── 生命周期
export async function setup(api) {
  host.api = api || null;
  log = typeof api?.log === 'function' ? api.log : () => {};
  warn = typeof api?.warn === 'function' ? api.warn : log;

  // 工具也必须**在 setup 执行期间**注册（写在别的函数里等于静默失效）。
  //
  // ⚠️ 字段名照抄 src/tool-registry.js 的规矩：必须有 id / name / execute，
  //   否则 registerTool 会**直接抛错**（"工具 X 必须提供 name"）。
  //   参数在 execute(ctx, args)，返回值必须是 { content, isError } 形态 ——
  //   返回 { ok: true } 这种自定义形状会让模型拿到一串 "undefined"。
  //
  // 这个工具是给模型的"主动"入口：即使群里没人打关键词，她判断这问题值得认真对待时
  // 也能自己切进思考模式。
  //
  // ⚠️⚠️ 最大的坑（2026-10-05 实测，用户原话"这直接不思考了"）：
  //   工具**改不了本轮**已经组装好的 system（ctx 里没有 messages），所以它天然
  //   只能影响"下一轮"。我一开始在描述和返回值里老老实实写了
  //   "切换从下一轮开始生效，本轮先用平时的角色把话接住" —— 模型**严格照做**了：
  //   它调完工具、发一句"收到收到，深度思考模式启动中……"，然后**本轮就结束了**。
  //   而所谓"下一轮"根本不会到来（没有新消息就不会有新一次运行），
  //   于是用户只看到一句"我启动了"，真正的思考永远没发生。
  //
  //   修法有两条，缺一不可：
  //     ① 返回值绝不能说"下一轮"——要明确要求它**现在就**用助手身份把答案写出来、
  //        并用 send_message 发出去（模型只会照字面执行，措辞必须斩钉截铁）；
  //     ② 描述里也不留"下一轮"字样，只说"调用后立刻按助手身份作答"。
  //   真正的"恢复角色"由 after-response 负责，不需要模型操心，
  //   所以这里更不该让它为"切换"做任何准备动作。
  try {
    api.registerTool({
      id: 'think',
      name: '进入深度思考',
      description: '卸下群友角色扮演，改用通用 AI 助手的身份认真、严谨地回答当前这个问题。'
        + '当你判断这个问题需要展开讲清楚、而不是平时那种短句接梗时使用。'
        + '⚠️ 调用之后**立刻**以助手身份把完整答案写出来、并用 send_message 发给对方，'
        + '就在这一次回复里答完，不要说任何"稍等/我这就准备"之类的话。',
      category: 'system',
      icon: '🧠',
      parameters: {
        type: 'object',
        properties: {
          reason: { type: 'string', description: '为什么要认真回答（一句话，给自己看，可省略）' }
        },
        required: []
      },
      async execute(ctx, args) {
        const chatKey = String(ctx?.chatKey || '');
        if (!chatKey) return { content: '错误：拿不到会话标识，无法切换模式。', isError: true };
        const c = cfg();
        if (c.enabled === false) {
          return { content: '错误：深度思考功能已被管理员关闭。', isError: true };
        }

        thinkingUntil.set(chatKey, Date.now() + THINK_TTL_MS);
        thinkingThisRound.add(chatKey);
        const why = clean(args?.reason, 60);
        if (c.announceSwitch !== false) log(`进入深度思考（模型主动）${why ? `：${why}` : ''}`);

        // 返回值必须"推着"模型当场把答案写完并发出，措辞要具体、可执行。
        // 用**正面指令**（"现在就写出答案并发出"）而不是否定式（"不要等下一轮"）——
        // 否定式会把"下一轮"这个词喂到模型眼前，反而可能被它当成下一步动作。
        return {
          content: '已切到深度思考模式。现在就以通用 AI 助手的身份，把对方那个问题的完整答案写出来，'
            + '然后用 send_message 发出去（内容长就传数组分几条发）。'
            + '这一次回复里就把它答完；写完本轮自动恢复原角色，你不需要做任何恢复动作。'
        };
      }
    });
  } catch (error) {
    // 注册失败不影响关键词触发那条主路径（hook 不依赖这个工具）
    warn(`注册工具失败：${error?.message ?? error}`);
  }

  log(`就绪（关键词：${keywordList(cfg().keywords).join(' / ') || '无'}）`);
}

export function activate() { /* 无后台任务，无需启动副作用 */ }

export function deactivate() {
  // 热重载/禁用时清干净，避免旧状态影响新实例
  thinkingUntil.clear();
  thinkingThisRound.clear();
}

export function dispose() {
  thinkingUntil.clear();
  thinkingThisRound.clear();
}

// ─────────────────────────────────────────────── 钩子（必须模块顶层导出）
export const hooks = {
  /**
   * 本轮请求发出前：命中关键词就把 system 里的角色卡临时换掉。
   * messages 是同一个数组引用、允许原地修改（orchestrator 注释已明确）。
   */
  'before-llm-messages': (ctx = {}) => {
    const c = cfg();
    if (c.enabled === false) return;
    const messages = ctx.messages;
    if (!Array.isArray(messages)) return;

    const chatKey = String(ctx.chatKey || '');
    const keywords = keywordList(c.keywords);
    // 只扫"这一轮新进来的消息"——扫全量会把历史和她自己的旧发言也算进来（见函数注释）
    const hit = matchedKeyword(incomingTextOf(messages), keywords);

    // 没命中，且上一轮的思考状态也已过期 → 什么都不做
    if (!hit) {
      if (!liveThinking(chatKey)) return;
      // 命中过、状态还活着：说明是多步工具调用中的后续请求，保持思考模式
    } else {
      thinkingUntil.set(chatKey, Date.now() + THINK_TTL_MS);
    }
    thinkingThisRound.add(chatKey);

    const sys = messages.find((m) => m && m.role === 'system');
    if (!sys) return;
    // 已经是思考模式的内容就别重复叠加（多步工具调用会多次进这个钩子）
    if (typeof sys.content === 'string' && sys.content.startsWith('# 当前模式：深度思考（临时）')) return;

    sys.content = buildThinkingSystem(sys.content, c.assistantPrompt, hit || '深度思考');
    if (c.announceSwitch !== false) log(`进入深度思考（命中「${hit || '延续'}」）：${chatKey}`);
  },

  /**
   * 本轮答完：立刻标记恢复 —— 下一轮就是原角色卡。
   * 这是"回答完自动回到角色卡"的落点。
   */
  'after-response': (ctx = {}) => {
    const chatKey = String(ctx.chatKey || '');
    if (!thinkingThisRound.has(chatKey)) return;
    thinkingThisRound.delete(chatKey);
    thinkingUntil.delete(chatKey);
    if (cfg().announceSwitch !== false) log(`退出深度思考，已恢复原角色卡：${chatKey}`);
  }
};

/**
 * 给模型的说明书（进系统提示词）。
 * 用动态片段而不是只写死在 skill.json 里，是因为要**按当前状态**告诉她：
 * 这一轮是"正在思考"还是"平时的角色扮演"。
 */
export function promptSections(ctx = {}) {
  const c = cfg();
  if (c.enabled === false) return [];
  const chatKey = String(ctx.chatKey || '');
  const active = liveThinking(chatKey);
  const kws = keywordList(c.keywords);

  if (active) {
    return [{
      id: 'deep-think-active',
      title: '正在深度思考',
      priority: 90,
      content: '这一轮你处于「深度思考」模式：以通用 AI 助手的身份认真、严谨地回答，'
        + '不要用平时的群友短句/玩梗风格。\n'
        + '⚠️ 答案必须**用 send_message 发出去**（长就传数组分几条发）——'
        + '只写在文本里对方是看不到的。这一次就把问题答完。\n'
        + '⚠️ 不要用 Markdown（**、#、|-| 表格在 QQ 上会变成乱码），'
        + '要分点就用「1. 2. 3.」或短横线。\n'
        + '只答这一个问题，回答完会自动恢复原来的角色。'
    }];
  }

  return [{
    id: 'deep-think-playbook',
    title: '深度思考（临时卸下角色）',
    priority: 58,
    content: `群友说「${kws.join('」「') || '深度思考'}」之类的话时，是想让你**暂时卸下群友角色扮演**，`
      + '以通用 AI 助手的身份认真回答问题。\n\n'
      + '触发之后这一轮：不要再短句玩梗、不要傲娇、不要"像群友"；用清晰、严谨、有条理的方式把问题讲透。\n\n'
      + '⚠️ 关键：答案必须**用 send_message 发出去**，而且**在这一轮就答完**。'
      + '你的普通文本输出不会发到 QQ —— 把分析写进文本里、只回一句"我这就认真想想"，'
      + '对方什么都收不到。宁可分几条发，也要把真正的答案发出来。\n\n'
      + '⚠️ 不要用 Markdown（**、#、代码块、|表格| 在 QQ 上会显示成乱码）。'
      + '要分点就用「1. 2. 3.」或「- 」开头。\n\n'
      + '⚠️ 但也要看语境：如果群友只是在**讨论这个功能本身**（比如"你那个深度思考是怎么实现的"），'
      + '那不是让你出戏，照常按角色回答。\n\n'
      + '答完会**自动**戴回原来的角色卡，不需要你解释或预告。'
  }];
}
