// 记事本记忆（notebook）—— 两级记忆：
//   · 记事本：进提示词、有硬容量上限；写满后模型必须先 promote（挪长期）或 drop（删），
//     才能继续写。这是"逼它做取舍"的机制 —— 无限容量的记忆等于没有记忆。
//   · 长期库：**不进提示词**，只有模型主动调 recall 查的时候才出现在上下文里。
//     所以它能一直攒、不占每轮 token。
//
// 为什么放 skills/：记事本是"模型判断什么重要"的语义动作，属于 LLM 型技能；
// 而"每轮把内容塞进请求"用的是 before-llm-messages 钩子（技能也支持钩子，
// 和 plugins/ 走同一个 loadSkillRoot）。
//
// 存储（都在 data/notebook/ 下，每个会话独立一本）：
//   <key>.json           记事本 { nextId, entries:[{id, at, text, tags}] }
//   <key>.longterm.json  长期库 { nextId, entries:[{id, at, text, tags, promotedAt}] }
//   key 由 chatKey 净化而来：group:123456789 → group_123456789
//
// 为什么记事本不能放系统提示词：系统提示词是**全局共享**的，而记事本是按会话的 ——
// 放进去会把 A 会话的备忘泄给 B 会话。所以走钩子追加到"最后一条 user 消息"末尾，
// 顺带也落在前缀缓存的尾段（内容不变时字节不变，命中不受影响）。

import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { DATA_DIR as HOST_DATA_DIR } from '../../src/config.js';

const ID = 'notebook';
const HERE = path.dirname(fileURLToPath(import.meta.url));
const APP_ROOT = path.resolve(HERE, '..', '..');
const DATA_DIR = HOST_DATA_DIR || path.resolve(APP_ROOT, '..', '..', 'data');
const NOTE_DIR = path.join(DATA_DIR, 'notebook');

/** 追加到 user 消息里的块标记（去重用：钩子可能因为重试跑两遍）。 */
const MARK = '【记事本';

let api = null;
let log = () => {};
let warn = () => {};
let conf = () => ({});

// ─────────────────────────────── 设置 ───────────────────────────────

function num(v, d, lo, hi) {
  const n = Number(v);
  if (!Number.isFinite(n)) return d;
  return Math.min(hi, Math.max(lo, Math.round(n)));
}

function settings() {
  let raw = {};
  try { raw = conf() || {}; } catch { raw = {}; }
  const scope = String(raw.scope ?? 'all').trim().toLowerCase();
  return {
    enabled: raw.enabled !== false,
    capacity: num(raw.capacity, 20, 3, 100),
    maxCharsPerEntry: num(raw.maxCharsPerEntry, 200, 20, 1000),
    scope: ['all', 'private', 'group'].includes(scope) ? scope : 'all',
    longtermKeep: num(raw.longtermKeep, 500, 50, 5000),
    recallLimit: num(raw.recallLimit, 6, 1, 20),
    showEmptyHint: raw.showEmptyHint !== false,
    // [[local-patch:notebook-aging]] 超时降级：
    //   staleDays > 0 → 记事本里超过这么多天没动过的条目，会在提示词里被标 ⏳ 提醒整理（不自动动）
    //   autoPromoteDays > 0 → 超过这么多天**自动挪进长期库**（长期库不进提示词，等于降级到冷存储，
    //     一条都不会丢，但会腾出格子）。默认 0 = 不自动降级。
    staleDays: num(raw.staleDays, 30, 0, 3650),
    autoPromoteDays: num(raw.autoPromoteDays, 0, 0, 3650)
  };
}

/** 这个会话要不要用记事本（按 scope 过滤）。 */
function inScope(chatKey, s) {
  const k = String(chatKey || '');
  if (!k) return false;
  if (s.scope === 'private') return k.startsWith('private:');
  if (s.scope === 'group') return k.startsWith('group:');
  return true;
}

// ─────────────────────────────── 存储 ───────────────────────────────

function keyOf(chatKey) {
  return String(chatKey || '')
    .replace(/[^a-zA-Z0-9]+/g, '_')
    .replace(/^_+|_+$/g, '') || 'unknown';
}

const noteFile = (chatKey) => path.join(NOTE_DIR, `${keyOf(chatKey)}.json`);
const longFile = (chatKey) => path.join(NOTE_DIR, `${keyOf(chatKey)}.longterm.json`);

function readState(file, kind) {
  let raw = null;
  try { raw = JSON.parse(fs.readFileSync(file, 'utf8')); } catch { raw = null; }
  const st = raw && typeof raw === 'object' ? raw : {};
  if (!Array.isArray(st.entries)) st.entries = [];
  st.entries = st.entries
    .filter((e) => e && typeof e === 'object' && String(e.text || '').trim())
    .map((e) => ({
      id: Number(e.id) || 0,
      at: Number(e.at) || 0,
      text: String(e.text || ''),
      tags: String(e.tags || ''),
      ...(kind === 'longterm' ? { promotedAt: Number(e.promotedAt) || 0 } : {})
    }));
  const maxId = st.entries.reduce((m, e) => Math.max(m, e.id), 0);
  st.nextId = Math.max(Number(st.nextId) || 1, maxId + 1);
  return st;
}

/** 写盘走"临时文件 + rename"，避免写到一半崩掉把整本记事本读坏。 */
function writeState(file, st) {
  fs.mkdirSync(NOTE_DIR, { recursive: true });
  const tmp = `${file}.${process.pid}.tmp`;
  fs.writeFileSync(tmp, JSON.stringify(st, null, 1), 'utf8');
  fs.renameSync(tmp, file);
}

const loadNote = (chatKey) => readState(noteFile(chatKey), 'notebook');
const loadLong = (chatKey) => readState(longFile(chatKey), 'longterm');

const DAY = 86400000;

/**
 * [[local-patch:notebook-aging]] 超时降级维护。
 *   · autoPromoteDays > 0：把"超过这么多天"的条目**自动挪进长期库**（不是删除！长期库不进提示词，
 *     所以这等于降级到冷存储 —— 一条都不会丢，只是腾出记事本的格子）。
 *   · 没有任何条目超期时**不写盘**，所以每轮调用也不会有 IO 抖动。
 * 返回 { moved, st }：moved = 本次自动挪走的条数（用于在提示词里告诉模型）。
 */
function maintain(chatKey, s) {
  const st = loadNote(chatKey);
  if (!st.entries.length || !(s.autoPromoteDays > 0)) return { moved: 0, st };
  const limit = Date.now() - s.autoPromoteDays * DAY;
  const keep = [];
  const toLong = [];
  for (const e of st.entries) ((Number(e.at) || 0) > 0 && Number(e.at) < limit ? toLong : keep).push(e);
  if (!toLong.length) return { moved: 0, st };

  const lt = loadLong(chatKey);
  for (const e of toLong) {
    lt.entries.push({
      id: lt.nextId++, at: e.at, text: e.text, tags: e.tags,
      promotedAt: Date.now(), auto: true
    });
  }
  while (lt.entries.length > s.longtermKeep) lt.entries.shift();
  writeState(longFile(chatKey), lt);
  st.entries = keep;
  writeState(noteFile(chatKey), st);
  return { moved: toLong.length, st };
}

/** 哪些条目"陈旧"了（只标注，不动它们）。 */
function staleIdsOf(st, s) {
  if (!(s.staleDays > 0)) return new Set();
  const limit = Date.now() - s.staleDays * DAY;
  const set = new Set();
  for (const e of st.entries) if (Number(e.at) > 0 && Number(e.at) < limit) set.add(e.id);
  return set;
}

// ─────────────────────────────── 工具函数 ───────────────────────────────

function ok(text) { return { content: text }; }
function err(text) { return { content: `status: error\n${text}`, isError: true }; }

function fmtDay(ts) {
  if (!ts) return '—';
  const d = new Date(ts);
  if (Number.isNaN(d.getTime())) return '—';
  return `${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

function brief(text, n = 26) {
  const t = String(text || '').replace(/\s+/g, ' ').trim();
  return t.length > n ? `${t.slice(0, n)}…` : t;
}

/** 把 id 解析成条目下标；找不到返回 -1。支持 "#3"、"3"、3。 */
function findIndex(entries, rawId) {
  const id = Number(String(rawId ?? '').replace(/^#/, '').trim());
  if (!Number.isFinite(id)) return -1;
  return entries.findIndex((e) => e.id === id);
}

/** 长期库检索分词：整词 + 空格切分 + 中文双字切分（提高中文召回）。 */
function tokensOf(query) {
  const raw = String(query || '').trim().toLowerCase();
  if (!raw) return [];
  const out = new Set([raw]);
  for (const part of raw.split(/[\s,，、;；/|]+/)) {
    if (part) out.add(part);
    const cjk = part.replace(/[^\u4e00-\u9fa5]/g, '');
    for (let i = 0; i + 2 <= cjk.length; i += 1) out.add(cjk.slice(i, i + 2));
  }
  return [...out].filter((t) => t.length >= 1);
}

function scoreEntry(e, toks) {
  const hay = `${e.text} ${e.tags}`.toLowerCase();
  let s = 0;
  for (const t of toks) {
    if (!t || !hay.includes(t)) continue;
    // 长词权重更高（"承诺"比"承"更有判别力），但封顶避免长句霸榜
    s += Math.min(4, t.length);
  }
  return s;
}

// ─────────────────────────────── 提示词块 ───────────────────────────────

/**
 * 渲染本轮要追加的记事本块。
 * 满格时给出"必须做减法"的明确指令 —— 这是整个设计的关键：
 * 不靠模型自觉，而是让它看见"没有格子了"，并知道只有两个出口。
 */
function renderBlock(st, s, extra = {}) {
  const n = st.entries.length;
  const head = `${MARK} ${n}/${s.capacity}】`;
  const stale = extra.staleIds instanceof Set ? extra.staleIds : new Set();
  const movedNote = Number(extra.autoMoved) > 0
    ? [`（已自动把 ${extra.autoMoved} 条太旧的挪进长期库 —— 没丢，用 notebook__recall 还能查到）`]
    : [];
  if (!n) {
    if (!s.showEmptyHint) return [...movedNote, `${head}空的。`].join('\n');
    return [...movedNote, `${head}空的。遇到以后还用得上的事（某人的雷点/偏好、答应过的事、重要日期、正在等的消息），`
      + '用 notebook__write 记一条短句；不重要的事别记，格子有限。'].join('\n');
  }
  const lines = [...movedNote];
  if (n >= s.capacity) {
    lines.push(`${head}已满 —— 写不进新的了，先做减法：`);
    for (const e of st.entries) lines.push(`#${e.id} [${fmtDay(e.at)}]${stale.has(e.id) ? ' ⏳' : ''} ${e.text}`);
    lines.push('· notebook__promote <id>：挪进长期库（不进提示词，以后用 notebook__recall 查）');
    lines.push('· notebook__drop <id>：直接删掉（过时的、记错的）');
    lines.push('腾出格子之后才能再 notebook__write。');
    return lines.join('\n');
  }
  lines.push(`${head}（还剩 ${s.capacity - n} 格）`);
  for (const e of st.entries) lines.push(`#${e.id} [${fmtDay(e.at)}]${stale.has(e.id) ? ' ⏳' : ''} ${e.text}`);
  lines.push('· 满了要先 notebook__promote（挪长期）或 notebook__drop（删），腾格子再写。');
  if (stale.size) {
    lines.push(`· ⏳ 标了 ${[...stale].map((x) => '#' + x).join(' ')} 的已经很多天没动过了：`
      + '值得长期留就 notebook__promote，过时了就 notebook__drop。');
  }
  return lines.join('\n');
}

// ─────────────────────────────── 工具实现 ───────────────────────────────

function toolWrite(ctx, args) {
  const s = settings();
  if (!s.enabled) return err('记事本功能已关闭（设置 → 工具与技能 → 记事本记忆）。');
  const chatKey = String(ctx?.chatKey || '');
  if (!inScope(chatKey, s)) return err('这个会话不在记事本的作用范围内（设置里的「作用范围」）。');

  let text = String(args?.text ?? '').replace(/\s+/g, ' ').trim();
  if (!text) return err('text 不能为空 —— 要记的那句话直接传进来。');
  let clipped = '';
  if (text.length > s.maxCharsPerEntry) {
    clipped = text.slice(s.maxCharsPerEntry);
    text = text.slice(0, s.maxCharsPerEntry);
  }
  const tags = String(args?.tags ?? '').replace(/\s+/g, ' ').trim().slice(0, 80);

  const st = loadNote(chatKey);
  if (st.entries.length >= s.capacity) {
    const list = st.entries.map((e) => `#${e.id} [${fmtDay(e.at)}] ${brief(e.text)}`).join('\n');
    return err(
      `记事本满了（${st.entries.length}/${s.capacity}），这条没有写进去。\n`
      + `现在记着：\n${list}\n`
      + '先做减法，二选一：\n'
      + '· notebook__promote <id> → 挪进长期库（不进提示词，以后用 notebook__recall 查）\n'
      + '· notebook__drop <id> → 直接删掉（过时的、记错的）\n'
      + '腾出格子后再调 notebook__write 重试。'
    );
  }

  const id = st.nextId;
  st.nextId += 1;
  st.entries.push({ id, at: Date.now(), text, tags });
  writeState(noteFile(chatKey), st);

  const lines = [`已记下 #${id}（${st.entries.length}/${s.capacity}）：${text}`];
  if (clipped) lines.push(`（超出单条上限 ${s.maxCharsPerEntry} 字，后半段被截掉了）`);
  if (st.entries.length >= s.capacity) {
    lines.push(`⚠️ 记事本现在满了。下次要记新东西之前，得先 notebook__promote 或 notebook__drop 腾格子。`);
  } else if (st.entries.length >= Math.ceil(s.capacity * 0.8)) {
    lines.push(`（快到上限了，还剩 ${s.capacity - st.entries.length} 格）`);
  }
  return ok(lines.join('\n'));
}

function toolPromote(ctx, args) {
  const s = settings();
  if (!s.enabled) return err('记事本功能已关闭。');
  const chatKey = String(ctx?.chatKey || '');
  if (!inScope(chatKey, s)) return err('这个会话不在记事本的作用范围内。');

  const st = loadNote(chatKey);
  const i = findIndex(st.entries, args?.id ?? args?.text);
  if (i < 0) {
    return err(`记事本里没有 #${String(args?.id ?? '')}。现在记着：\n`
      + (st.entries.length ? st.entries.map((e) => `#${e.id} ${brief(e.text)}`).join('\n') : '（空）'));
  }
  const entry = st.entries[i];
  const newText = String(args?.text ?? '').trim() || entry.text;
  // 标签去重：promote 时补的标签常和原有的重叠（"某人 承诺" + "某人"），重复写会污染检索
  const newTags = [...new Set(
    `${entry.tags} ${String(args?.tags ?? '').trim()}`
      .split(/\s+/)
      .map((x) => x.trim())
      .filter(Boolean)
  )].join(' ');

  const lt = loadLong(chatKey);
  const ltId = lt.nextId;
  lt.nextId += 1;
  lt.entries.push({ id: ltId, at: entry.at || Date.now(), text: newText, tags: newTags, promotedAt: Date.now() });

  let dropped = 0;
  while (lt.entries.length > s.longtermKeep) { lt.entries.shift(); dropped += 1; }

  st.entries.splice(i, 1);
  writeState(noteFile(chatKey), st);
  writeState(longFile(chatKey), lt);

  const lines = [
    `已把 #${entry.id} 挪进长期库（长期库 #${ltId}，共 ${lt.entries.length} 条）`,
    `· 记事本现在 ${st.entries.length}/${s.capacity}，腾出 ${s.capacity - st.entries.length} 格`,
    '· 长期库不进提示词；以后要回忆就用 notebook__recall 查'
  ];
  if (dropped) lines.push(`（长期库超过上限 ${s.longtermKeep}，自动丢掉了最旧的 ${dropped} 条）`);
  return ok(lines.join('\n'));
}

function toolDrop(ctx, args) {
  const s = settings();
  if (!s.enabled) return err('记事本功能已关闭。');
  const chatKey = String(ctx?.chatKey || '');
  if (!inScope(chatKey, s)) return err('这个会话不在记事本的作用范围内。');

  const st = loadNote(chatKey);
  const i = findIndex(st.entries, args?.id);
  if (i < 0) {
    return err(`记事本里没有 #${String(args?.id ?? '')}。现在记着：\n`
      + (st.entries.length ? st.entries.map((e) => `#${e.id} ${brief(e.text)}`).join('\n') : '（空）'));
  }
  const [removed] = st.entries.splice(i, 1);
  writeState(noteFile(chatKey), st);
  return ok(`已删掉 #${removed.id}：${brief(removed.text)}\n记事本现在 ${st.entries.length}/${s.capacity}。`);
}

/**
 * [[local-patch:notebook-show]] 把记事本念给用户看。
 * 为什么需要它：记事本本来就在提示词里，但那是"给模型看的紧凑块"（带 #id、带指令行），
 * 直接复述会很怪。这个工具返回一份**面向用户**的清爽清单，模型可以照着说。
 */
function toolShow(ctx, args) {
  const s = settings();
  if (!s.enabled) return err('记事本功能已关闭。');
  const chatKey = String(ctx?.chatKey || '');
  if (!inScope(chatKey, s)) return err('这个会话不在记事本的作用范围内。');

  const { moved, st } = maintain(chatKey, s);
  const lt = loadLong(chatKey);
  const stale = staleIdsOf(st, s);
  const limit = Math.min(s.capacity, Math.max(1, Number(args?.limit) || s.capacity));
  const shown = st.entries.slice(-limit);

  const lines = [];
  lines.push(`📒 记事本（${st.entries.length}/${s.capacity} 条；长期库另有 ${lt.entries.length} 条，只在需要时查）`);
  if (moved) lines.push(`（刚自动把 ${moved} 条太旧的挪进长期库了，没丢）`);
  if (!st.entries.length) {
    lines.push('（还是空的 —— 说过值得长期记住的事，我才会记一条。）');
    return ok(lines.join('\n'));
  }
  for (const [i, e] of shown.entries()) {
    lines.push(`${i + 1}. [${fmtDay(e.at)}]${stale.has(e.id) ? ' ⏳' : ''} ${e.text}`);
  }
  if (st.entries.length > shown.length) lines.push(`（只列了最近 ${shown.length} 条）`);
  if (stale.size) lines.push('⏳ = 很多天没动过的，可以考虑清一清。');
  return ok(lines.join('\n'));
}

function toolRecall(ctx, args) {
  const s = settings();
  if (!s.enabled) return err('记事本功能已关闭。');
  const chatKey = String(ctx?.chatKey || '');
  if (!inScope(chatKey, s)) return err('这个会话不在记事本的作用范围内。');

  const query = String(args?.query ?? '').trim();
  if (!query) return err('query 不能为空 —— 说清要找什么（人名、事情、关键词都行）。');
  const limit = Math.min(s.recallLimit, Math.max(1, Number(args?.limit) || s.recallLimit));

  const lt = loadLong(chatKey);
  if (!lt.entries.length) {
    return ok(`长期库还是空的（共 0 条）。记事本里有值得长期留的，可以先用 notebook__promote 挪进来。`);
  }

  const toks = tokensOf(query);
  const scored = lt.entries
    .map((e) => ({ e, score: scoreEntry(e, toks) }))
    .filter((x) => x.score > 0)
    .sort((a, b) => b.score - a.score || (b.e.promotedAt || b.e.at) - (a.e.promotedAt || a.e.at))
    .slice(0, limit);

  if (!scored.length) {
    return ok(
      `长期库里没有和「${query}」对得上的（共 ${lt.entries.length} 条）。\n`
      + '可以换个关键词再查（人名、地名、当时说过的原话都行），或者直接问对方。别硬猜。'
    );
  }
  const lines = [`长期库命中 ${scored.length} 条（共 ${lt.entries.length} 条）：`];
  for (const { e } of scored) {
    lines.push(`#${e.id} [${fmtDay(e.at)}] ${e.text}${e.tags ? `（标签：${e.tags}）` : ''}`);
  }
  return ok(lines.join('\n'));
}

// ─────────────────────────────── 生命周期 ───────────────────────────────

export function setup(injected) {
  api = injected;
  conf = typeof api?.config === 'function' ? api.config : () => ({});
  log = typeof api?.log === 'function' ? api.log : () => {};
  warn = typeof api?.warn === 'function' ? api.warn : log;

  api.registerTool({
    id: 'write',
    name: '往记事本记一条',
    description:
      '把一件你认为以后还用得上的事记进记事本（一句话）。记事本每轮都会出现在你的上下文里，'
      + '所以只记会影响以后对话的：某人的雷点/偏好、答应过的事、重要日期、正在等的消息。'
      + '它有容量上限，满了会被拒绝，并让你先 notebook__promote（挪长期）或 notebook__drop（删）腾格子。',
    category: 'memory',
    icon: '📝',
    parameters: {
      type: 'object',
      properties: {
        text: { type: 'string', description: '一句话（尽量 40 字内）：谁 + 什么事 + 为什么重要。' },
        tags: { type: 'string', description: '可选：几个关键词，方便以后在长期库里搜到。' }
      },
      required: ['text']
    },
    async execute(ctx, args) {
      try { return toolWrite(ctx, args); } catch (e) { return err(`写记事本失败：${e?.message ?? e}`); }
    }
  });

  api.registerTool({
    id: 'promote',
    name: '把记事本的一条挪进长期库',
    description:
      '记事本满了、或想腾格子时用它：把记事本里 #id 那一条移到长期记忆库。'
      + '长期库不进提示词，只有之后用 notebook__recall 查才会看到 —— 适合放「不常用但不想丢」的事。'
      + '（这条会从记事本里消失，格子腾出来。）',
    category: 'memory',
    icon: '📚',
    parameters: {
      type: 'object',
      properties: {
        id: { type: ['integer', 'string'], description: '记事本里那条的编号（#3 就填 3）' },
        text: { type: 'string', description: '可选：挪过去时改写得更精炼（不填就原样搬）' },
        tags: { type: 'string', description: '可选：补充关键词，方便以后检索' }
      },
      required: ['id']
    },
    async execute(ctx, args) {
      try { return toolPromote(ctx, args); } catch (e) { return err(`挪进长期库失败：${e?.message ?? e}`); }
    }
  });

  api.registerTool({
    id: 'drop',
    name: '从记事本删掉一条',
    description: '记错了、过时了、或纯粹想腾格子时用：把记事本里 #id 那条直接删掉。删掉不会进长期库。',
    category: 'memory',
    icon: '🗑️',
    parameters: {
      type: 'object',
      properties: { id: { type: ['integer', 'string'], description: '记事本里那条的编号（#3 就填 3）' } },
      required: ['id']
    },
    async execute(ctx, args) {
      try { return toolDrop(ctx, args); } catch (e) { return err(`删记事本条目失败：${e?.message ?? e}`); }
    }
  });

  // [[local-patch:notebook-show]] 把记事本念给用户看（给用户看的清爽格式，不是内部块）
  api.registerTool({
    id: 'show',
    name: '把记事本念给用户看',
    description:
      '当群友问「你都记着我什么」「你的记事本里有什么」「你还记得哪些事」时用它，'
      + '返回一份适合直接说给人听的清单（带日期）。'
      + '只列记事本里的；长期库另有条数，要翻长期库用 notebook__recall。',
    category: 'memory',
    icon: '📒',
    parameters: {
      type: 'object',
      properties: {
        limit: { type: 'integer', description: '最多列几条（不填就全列，上限等于记事本容量）' }
      },
      required: []
    },
    async execute(ctx, args) {
      try { return toolShow(ctx, args); } catch (e) { return err(`读记事本失败：${e?.message ?? e}`); }
    }
  });

  api.registerTool({
    id: 'recall',
    name: '从长期库里查',
    description:
      '在长期记忆库里按关键词找以前挪进去的事。长期库不进提示词，所以需要回忆「很久以前的事」时用它。'
      + '返回命中条目（带日期与标签）。查不到就照实说，别编。',
    category: 'memory',
    icon: '🔎',
    parameters: {
      type: 'object',
      properties: {
        query: { type: 'string', description: '要找什么：人名、事情、关键词都行（可空格分开多个词）' },
        limit: { type: 'integer', description: '最多返回几条（不填用设置默认 6）' }
      },
      required: ['query']
    },
    async execute(ctx, args) {
      try { return toolRecall(ctx, args); } catch (e) { return err(`查长期库失败：${e?.message ?? e}`); }
    }
  });

  log('log', `记事本记忆已加载｜容量 ${settings().capacity} 条｜长期库 ${settings().longtermKeep} 条｜范围 ${settings().scope}`);
}

/**
 * 每轮把记事本追加到最后一条 user 消息末尾。
 * 为什么不在系统提示词里：系统提示词是全局共享的，记事本按会话独立 —— 放进去会串会话。
 * 为什么追加在末尾而不是开头：内容不变时它字节不变，前缀缓存照样命中；变了也只影响尾部。
 */
export const hooks = {
  async 'before-llm-messages'(ctx = {}) {
    try {
      const s = settings();
      if (!s.enabled) return;
      const chatKey = String(ctx?.chatKey || '');
      if (!inScope(chatKey, s)) return;
      const msgs = Array.isArray(ctx?.messages) ? ctx.messages : [];
      if (!msgs.length) return;

      // [[local-patch:notebook-aging]] 先做超时降级（有超期条目才会写盘），再渲染
      const { moved, st } = maintain(chatKey, s);
      const block = renderBlock(st, s, { staleIds: staleIdsOf(st, s), autoMoved: moved });
      if (!block) return;

      // 去重：重试路径会让钩子跑第二遍，别把同一块追加两次
      for (let i = msgs.length - 1; i >= 0; i -= 1) {
        const m = msgs[i];
        if (m?.role !== 'user') continue;
        const cur = String(m.content ?? '');
        if (cur.includes(MARK)) return;
        m.content = `${cur}\n\n${block}`;
        return;
      }
    } catch (e) {
      warn(`追加记事本失败：${e?.message ?? e}`);
    }
  }
};

/** 加载器读它判断"能不能用"：记事本只依赖文件系统，永远可用。 */
export function available() { return true; }

export function activate() { /* 无常驻任务 */ }
export function deactivate() { /* 无常驻任务 */ }
export function dispose() { /* 无定时器/监听器 */ }

/** 给验证脚本用的内部接口（不暴露给模型）。 */
export const internals = { settings, renderBlock, keyOf, tokensOf, scoreEntry, noteFile, longFile, MARK, maintain, staleIdsOf };
