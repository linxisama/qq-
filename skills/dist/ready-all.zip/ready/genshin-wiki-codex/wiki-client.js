// B站原神 Wiki（wiki.biligame.com/ys）只读客户端。
//
// 设计要点（都是踩过的坑）：
//   1. **只读 + 只允许一个域**：URL 自己拼，host 不在白名单直接拒绝，
//      避免这个技能被当成"任意网页抓取器"用。
//   2. **串行 + 最小请求间隔**：B站 Wiki 前面挂着腾讯 EdgeOne，
//      短时间并发/连发会被返回 HTTP 567（一个 HTML 反爬页，不是 JSON）。
//      所以所有请求走同一条队列，间隔不小于 requestIntervalMs。
//   3. **磁盘缓存 + 失败回落旧缓存**：命中缓存不联网（快、不触发限流）；
//      联网失败时若有旧缓存就带 warning 返回，而不是让机器人"什么都不知道"。
//   4. **HTML → 干净正文**：页面源码 200~400KB，里面大量是内联 CSS 和整站导航。
//      直接把源码丢给模型等于烧钱，所以先按 <h2>/<h3> 切节、去掉样板文字，
//      再按字数上限截断。
//
// 本文件不 import 应用内部模块，可以独立测试。

import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';

export const SITE_ORIGIN = 'https://wiki.biligame.com';
export const SITE_API_PATH = '/ys/api.php';
export const SITE_HOST = 'wiki.biligame.com';
export const SITE_LABEL = 'B站原神Wiki（wiki.biligame.com/ys）';

/**
 * 常用分类名 → wiki 上的真实分类名。
 * 全部对着线上分类核对过（2026-10 实测 Category:xxx 均能取到成员），
 * 改这里之前请先用 list_category 试一次，写错分类的表现是"查出来是空的"。
 */
export const CATEGORY_MAP = {
  角色: '角色',
  武器: '武器',
  圣遗物: '圣遗物套装',
  敌人: '怪物',
  怪物: '怪物',
  材料: '素材',
  素材: '素材',
  特产: '特产',
  食物: '食物',
  料理: '食物',
  书籍: '书籍',
  NPC: 'NPC',
  任务: '任务',
  秘境: '秘境',
  版本: '版本更新',
  配队: '配队攻略',
  攻略: '角色攻略',
};

/** 任务分类下还有这些子分类，也允许直接当参数传。 */
export const SUBCATEGORIES = {
  魔神任务: '魔神任务',
  传说任务: '传说任务',
  世界任务: '世界任务',
  委托任务: '委托任务',
  活动任务: '活动任务',
  活动事件: '活动事件',
  邀约事件: '邀约事件',
  系列任务: '系列任务',
  隐藏任务: '隐藏任务',
};

const USER_AGENT =
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36';
const MAX_BYTES = 6 * 1024 * 1024;
const RETRY_DELAYS_MS = [1500, 4000];
const STALE_MAX_AGE_MS = 30 * 86400000;
const MEMORY_CACHE_MAX = 64;

export class WikiError extends Error {
  constructor(code, message) {
    super(message);
    this.name = 'WikiError';
    this.code = code;
  }
}

export const pageUrl = (title) => `${SITE_ORIGIN}/ys/${encodeURIComponent(String(title).replace(/ /g, '_'))}`;
const iso = (ms) => new Date(ms).toISOString();
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const clamp = (v, lo, hi, d) => (Number.isFinite(Number(v)) ? Math.min(hi, Math.max(lo, Number(v))) : d);
const norm = (s) =>
  String(s ?? '')
    .normalize('NFKC')
    .toLowerCase()
    .replace(/[\s·・•（）()〔〕【】\[\]_-]+/g, '');

// ── HTML → 文本 ──────────────────────────────────────────────────────

function decodeEntities(s) {
  const named = {
    amp: '&', lt: '<', gt: '>', quot: '"', apos: "'", nbsp: ' ',
    ndash: '–', mdash: '—', times: '×', middot: '·', hellip: '…', le: '≤', ge: '≥',
  };
  return String(s || '').replace(/&(#x[0-9a-f]+|#\d+|[a-z]+);/gi, (m, x) => {
    if (x[0] !== '#') return named[x.toLowerCase()] ?? m;
    const n = x[1].toLowerCase() === 'x' ? parseInt(x.slice(2), 16) : Number(x.slice(1));
    return n > 0 && n <= 0x10ffff ? String.fromCodePoint(n) : '';
  });
}

/** 把一段 HTML 压成纯文本；表格用 ｜ 分隔，保留换行。 */
export function htmlToText(html) {
  return decodeEntities(
    String(html || '')
      .replace(/<style[\s\S]*?<\/style>/gi, ' ')
      .replace(/<script[\s\S]*?<\/script>/gi, ' ')
      .replace(/<!--[\s\S]*?-->/g, ' ')
      .replace(/<br\s*\/?>/gi, '\n')
      .replace(/<\/(p|div|tr|li|h[1-6]|table|dl|dt|dd|caption)>/gi, '\n')
      .replace(/<\/(td|th)>/gi, ' | ')
      .replace(/<[^>]+>/g, ''),
  )
    .replace(/[ \t\u00a0]+/g, ' ')
    .replace(/ *\n */g, '\n')
    .replace(/\n{3,}/g, '\n\n')
    .trim();
}

/** 页面顶部的编辑/收藏提示、页尾的整站导航 —— 对回答没用，白烧 token。 */
const DROP_LINE_RES = [
  /^阅\s*编\s*刷\s*历$/,
  /^首页\s*[>＞]/,
  /^如果是第一次来/,
  /^按右上角/,
  /^展开\s*\/\s*折叠$/,
  /^本页面内容待补充完善/,
  /^大家如果看到空缺的地方/,
  /^请大家不要添加游戏内未实装/,
  /^MediaWiki:/,
  /^\|$/,
  /^\|(\s*\|)+$/,
];

export function cleanupText(text) {
  let t = String(text || '');
  t = t
    .split('\n')
    .map((l) => l.trim())
    .filter((l) => l && !DROP_LINE_RES.some((re) => re.test(l)))
    .join('\n');
  // 页尾的「原神WIKI导航 ……」后面全是全站链接清单，从这里截断
  const navIdx = t.search(/\n(?:原神)?\s*WIKI\s*导航/);
  if (navIdx > 200) t = t.slice(0, navIdx);
  return t
    .replace(/(?:\s*\|\s*){2,}/g, ' | ')
    .replace(/[ \t]{2,}/g, ' ')
    .replace(/\n{3,}/g, '\n\n')
    .trim();
}

/**
 * 按 <h1>~<h6> 把页面正文切成节。
 * @returns {Array<{level:number,title:string,text:string}>}
 */
export function splitSections(html) {
  const clean = String(html || '')
    .replace(/<style[\s\S]*?<\/style>/gi, ' ')
    .replace(/<script[\s\S]*?<\/script>/gi, ' ')
    .replace(/<!--[\s\S]*?-->/g, ' ');
  const parts = clean.split(/<h([1-6])[^>]*>([\s\S]*?)<\/h\1>/i);
  const out = [];
  const head = cleanupText(htmlToText(parts[0] || ''));
  if (head) out.push({ level: 0, title: '(页面开头)', text: head });
  for (let i = 1; i + 2 < parts.length + 1; i += 3) {
    const level = Number(parts[i]) || 2;
    // 标题里会带「[编辑]」链接文字，去掉
    const title = htmlToText(parts[i + 1] || '')
      .replace(/\[\s*编辑\s*\]/g, '')
      .replace(/\s+/g, ' ')
      .trim();
    const text = cleanupText(htmlToText(parts[i + 2] || ''));
    if (title) out.push({ level, title, text });
  }
  return out.filter((s) => s.text || s.title);
}

/** 按字数上限截断，尽量不切断整行。 */
export function cutText(text, maxChars) {
  const t = String(text || '');
  if (t.length <= maxChars) return { text: t, truncated: false };
  const slice = t.slice(0, maxChars);
  const nl = slice.lastIndexOf('\n');
  const cut = nl >= maxChars * 0.6 ? slice.slice(0, nl) : slice;
  return { text: cut.trimEnd(), truncated: true };
}

/** 猜测条目类型，帮模型判断"这条结果是不是我要的"。 */
export function guessType(title) {
  const t = String(title || '');
  if (/^卡牌[:：]/.test(t)) return '七圣召唤卡牌';
  if (/图鉴|一览$|筛选$|属性$/.test(t)) return '索引页';
  if (/^\d+\.\d+版本/.test(t)) return '版本专题';
  if (/^《原神》|^【原神|带你|实况|录播|直播|首播|视频|首杀|试玩|二测|三测/.test(t)) return '视频/外部内容';
  if (/攻略|配队|推荐|思路|评测|指南/.test(t)) return '攻略';
  if (/\//.test(t) && /(语音|逸闻|考据|考究|故事集|攻略)$/.test(t)) return '附属页面';
  if (/语音|逸闻/.test(t)) return '附属页面';
  return '条目';
}

/**
 * 查询里的"意图词"——带着它们搜索经常会一条都搜不到
 * （MediaWiki 全文搜索对长尾组合词很严格，比如「枫原万叶配队」）。
 * 搜不到时剥掉尾巴再搜一次。
 */
const INTENT_SUFFIXES = [
  '怎么配队', '配队推荐', '怎么搭配', '搭配', '阵容', '配队', '怎么练', '培养',
  '攻略', '推荐', '突破材料', '材料', '位置', '在哪里', '在哪', '怎么获得',
  '获取方式', '掉落', '值得抽吗', '强度', '测评', '评测', '怎么样', '是什么',
];

export function stripIntent(query) {
  let s = String(query ?? '').trim();
  for (const w of INTENT_SUFFIXES) {
    if (s.length > w.length && s.endsWith(w)) {
      s = s.slice(0, -w.length).trim();
      break;
    }
  }
  return s;
}

// ── 客户端 ───────────────────────────────────────────────────────────

export class GenshinWikiClient {
  constructor({ cacheDir = null, settings = () => ({}), fetchImpl = fetch, logger = {} } = {}) {
    this.cacheDir = cacheDir;
    this.settings = settings;
    this.fetch = fetchImpl;
    this.log = logger.log || (() => {});
    this.warn = logger.warn || (() => {});
    this.memory = new Map();
    this.inflight = new Map();
    this.chain = Promise.resolve();
    this.lastRequestAt = 0;
  }

  // 设置（每次读，用户在界面上改了立刻生效）
  #cfg() {
    const s = this.settings() || {};
    return {
      pageTtlMs: clamp(s.pageCacheHours, 1, 24 * 30, 168) * 3600000,
      searchTtlMs: clamp(s.searchCacheMinutes, 1, 24 * 60, 30) * 60000,
      catTtlMs: clamp(s.categoryCacheMinutes, 1, 24 * 60, 60) * 60000,
      maxChars: clamp(s.maxChars, 400, 8000, 2500),
      maxCharsCap: 8000,
      maxResults: clamp(s.maxResults, 1, 15, 6),
      categoryLimit: clamp(s.categoryLimit, 5, 200, 40),
      intervalMs: clamp(s.requestIntervalMs, 0, 10000, 1200),
      timeoutMs: clamp(s.timeoutMs, 3000, 60000, 30000),
      serveStale: s.serveStaleOnError !== false,
    };
  }

  // ── 缓存 ────────────────────────────────────────────────────────────

  #cacheFile(key) {
    if (!this.cacheDir) return null;
    return path.join(this.cacheDir, crypto.createHash('sha256').update(key).digest('hex') + '.json');
  }

  #cacheGet(key) {
    if (this.memory.has(key)) return this.memory.get(key);
    const file = this.#cacheFile(key);
    if (!file) return null;
    try {
      const item = JSON.parse(fs.readFileSync(file, 'utf8'));
      if (item && typeof item.fetchedAt === 'number') {
        this.memory.set(key, item);
        return item;
      }
    } catch { /* 缓存坏了就当没有 */ }
    return null;
  }

  #cachePut(key, item) {
    if (this.memory.size >= MEMORY_CACHE_MAX) this.memory.delete(this.memory.keys().next().value);
    this.memory.set(key, item);
    const file = this.#cacheFile(key);
    if (!file) return;
    try {
      fs.mkdirSync(this.cacheDir, { recursive: true });
      const tmp = `${file}.tmp`;
      fs.writeFileSync(tmp, JSON.stringify(item));
      fs.renameSync(tmp, file);
    } catch (e) {
      this.warn(`写缓存失败：${String(e?.message || e)}`);
    }
  }

  async #cached(key, ttlMs, refresh, load) {
    const old = this.#cacheGet(key);
    if (!refresh && old && Date.now() - old.fetchedAt < ttlMs) {
      this.log(`缓存命中（${Math.round((Date.now() - old.fetchedAt) / 1000)} 秒前抓的）：${key.slice(0, 60)}`);
      return { data: old.data, fetchedAt: old.fetchedAt, cacheHit: true, stale: false };
    }
    if (this.inflight.has(key)) return this.inflight.get(key);
    const p = (async () => {
      try {
        const data = await load();
        const item = { data, fetchedAt: Date.now() };
        this.#cachePut(key, item);
        return { data, fetchedAt: item.fetchedAt, cacheHit: false, stale: false };
      } catch (e) {
        const cfg = this.#cfg();
        if (cfg.serveStale && old && Date.now() - old.fetchedAt < STALE_MAX_AGE_MS) {
          const ageH = Math.round((Date.now() - old.fetchedAt) / 3600000);
          this.warn(`实时抓取失败（${String(e?.message || e)}），改用 ${ageH} 小时前的缓存`);
          return {
            data: old.data,
            fetchedAt: old.fetchedAt,
            cacheHit: true,
            stale: true,
            warning: `实时抓取失败（${String(e?.message || e)}），以下是 ${ageH} 小时前的缓存资料，可能不是最新。`,
          };
        }
        throw e;
      }
    })();
    this.inflight.set(key, p);
    try { return await p; } finally { this.inflight.delete(key); }
  }

  // ── HTTP（串行 + 限速 + 重试）───────────────────────────────────────

  #enqueue(fn) {
    const run = async () => {
      const wait = Math.max(0, this.#cfg().intervalMs - (Date.now() - this.lastRequestAt));
      if (wait) await sleep(wait);
      this.lastRequestAt = Date.now();
      return fn();
    };
    const p = this.chain.then(run, run);
    this.chain = p.then(() => {}, () => {});
    return p;
  }

  async #getJson(params) {
    const cfg = this.#cfg();
    const query = new URLSearchParams({ format: 'json', formatversion: '2', ...params });
    const url = `${SITE_ORIGIN}${SITE_API_PATH}?${query}`;
    if (new URL(url).hostname !== SITE_HOST) throw new WikiError('host', '只允许访问 B站原神Wiki');

    return this.#enqueue(async () => {
      let lastError = null;
      for (let attempt = 0; attempt <= RETRY_DELAYS_MS.length; attempt += 1) {
        try {
          this.log(`GET ${url.slice(0, 160)}`);
          const r = await this.fetch(url, {
            redirect: 'error',
            signal: AbortSignal.timeout(cfg.timeoutMs),
            headers: {
              'User-Agent': USER_AGENT,
              Accept: 'application/json, text/plain, */*',
              'Accept-Language': 'zh-CN,zh;q=0.9',
              Referer: `${SITE_ORIGIN}/ys/`,
            },
          });
          const ctype = String(r.headers.get('content-type') || '');
          // 限流页：HTTP 567 + HTML（腾讯 EdgeOne 的反爬拦截）
          if (r.status === 567 || ctype.includes('text/html')) {
            throw new WikiError('waf', `B站Wiki 触发了反爬限流（HTTP ${r.status}），需要等一会儿再试`);
          }
          if (!r.ok) {
            const e = new WikiError('http', `B站Wiki 返回 HTTP ${r.status}`);
            if (r.status >= 500 || r.status === 429) { lastError = e; throw e; }
            throw new WikiError('fatal-http', e.message);
          }
          const text = await r.text();
          if (!text) throw new WikiError('empty', 'B站Wiki 返回了空响应');
          try {
            const json = JSON.parse(text);
            this.log(`OK（${text.length} 字节）`);
            return json;
          } catch {
            throw new WikiError('waf', 'B站Wiki 返回的不是 JSON（多半是限流页）');
          }
        } catch (e) {
          lastError = e;
          const fatal = e?.code === 'fatal-http';
          if (fatal || attempt >= RETRY_DELAYS_MS.length) break;
          const delay = RETRY_DELAYS_MS[attempt];
          this.warn(`第 ${attempt + 1} 次请求失败（${String(e?.message || e)}），${delay}ms 后重试`);
          await sleep(delay);
        }
      }
      if (lastError instanceof WikiError) throw lastError;
      throw new WikiError('network', `访问 B站Wiki 失败：${String(lastError?.message || lastError)}`);
    });
  }

  #fail(e) {
    const message = e instanceof WikiError ? e.message : `访问 B站原神Wiki 失败：${String(e?.message || e)}`;
    const hint = e?.code === 'waf'
      ? '这是站点的反爬限流，不是条目不存在；过几十秒再用同样的参数试一次通常就好了。'
      : e?.code === 'missing'
        ? '换个名字试试：先用 lookup 搜，再按返回的标题读。'
        : '可以稍后重试；重试仍失败就如实告诉群友「wiki 暂时查不到」，不要自己编内容。';
    return { ok: false, error: message, code: e?.code || 'error', hint };
  }

  // ── 对外能力 ────────────────────────────────────────────────────────

  /**
   * 页面没有小节标题时的降级：在正文里找到关键词，返回它附近的一段。
   * 只在"正文里确实出现了这个词"时生效，找不到返回 null（交给调用方报 no-section）。
   */
  #sectionWindow(data, want, maxChars) {
    for (const b of data.blocks) {
      const text = String(b.text || '');
      const at = text.indexOf(want);
      if (at < 0) continue;
      const lineStart = text.lastIndexOf('\n', at);
      const start = Math.max(0, lineStart >= 0 ? lineStart + 1 : at);
      const cut = cutText(text.slice(start), maxChars);
      return {
        ok: true,
        title: data.title,
        url: pageUrl(data.title),
        sections: data.blocks.map((x) => x.title),
        matchedKeyword: want,
        text: `## ${want}（该条目没有分节标题，以下是关键词附近的正文）\n${cut.text}`,
        truncated: cut.truncated,
        note: `条目「${data.title}」在 wiki 上没有分节标题，已按关键词「${want}」截取上下文，开头未必正好是该小节的第一句。`,
      };
    }
    return null;
  }

  /** 关键词搜索条目。 */
  async search(query, { limit, refresh = false } = {}) {
    const cfg = this.#cfg();
    const q = String(query ?? '').trim();
    if (!q) return { ok: false, error: 'query 不能为空', code: 'bad-arg', hint: '给出要查的关键词，例如「和璞鸢」。' };
    const n = clamp(limit, 1, 15, cfg.maxResults);
    const runSearch = (term) => async () => {
      const json = await this.#getJson({ action: 'query', list: 'search', srsearch: term, srlimit: String(n) });
      return (json?.query?.search || [])
        .map((x) => ({ title: String(x.title || ''), snippet: htmlToText(String(x.snippet || '')).slice(0, 220) }))
        .filter((x) => x.title);
    };
    try {
      let c = await this.#cached(`search:${q}:${n}`, cfg.searchTtlMs, refresh, runSearch(q));
      let usedQuery = q;
      // 「枫原万叶配队」这类长尾组合词在 MediaWiki 全文搜索里经常 0 命中：
      // 剥掉意图词再搜一次，比让模型自己猜关键词更省一轮对话。
      if (!c.data.length) {
        const shorter = stripIntent(q);
        if (shorter && shorter !== q) {
          const c2 = await this.#cached(`search:${shorter}:${n}`, cfg.searchTtlMs, refresh, runSearch(shorter));
          if (c2.data.length) {
            c = c2;
            usedQuery = shorter;
            this.log(`「${q}」搜不到，用「${shorter}」重搜命中 ${c2.data.length} 条`);
          }
        }
      }
      const allowCards = /卡牌|七圣召唤/.test(usedQuery);
      const base = norm(usedQuery);
      const ranked = c.data
        .map((x, i) => ({ ...x, type: guessType(x.title), url: pageUrl(x.title), _i: i }))
        .filter((x) => allowCards || !/^卡牌[:：]/.test(x.title))
        .map((x) => {
          const nt = norm(x.title);
          x._score = (nt === base ? 100 : nt.startsWith(base) || base.startsWith(nt) ? 40 : 0)
            + (x.type === '索引页' ? -15 : 0)
            + (x.type === '附属页面' ? -5 : 0)
            + (x.type === '视频/外部内容' ? -20 : 0)
            + (10 - x._i);
          return x;
        })
        .sort((a, b) => b._score - a._score)
        .map(({ _i, _score, ...rest }) => rest);
      return {
        ok: true,
        query: usedQuery,
        ...(usedQuery !== q ? { originalQuery: q, note: `「${q}」一条都没搜到，已用更短的关键词「${usedQuery}」重搜。` } : {}),
        count: ranked.length,
        results: ranked,
        source: SITE_LABEL,
        fetchedAt: iso(c.fetchedAt),
        cacheHit: c.cacheHit,
        ...(c.stale ? { stale: true } : {}),
        ...(c.warning ? { warning: c.warning } : {}),
        ...(ranked.length ? {} : { note: '搜索没有结果：换个更短/更常见的关键词试试，比如只留名词。' }),
      };
    } catch (e) {
      return this.#fail(e);
    }
  }

  /** 读一个条目的正文。 */
  async read(title, { section = '', maxChars, refresh = false } = {}) {
    const cfg = this.#cfg();
    const t = String(title ?? '').trim();
    if (!t) return { ok: false, error: 'title 不能为空', code: 'bad-arg', hint: '给出条目名，例如「绝缘之旗印」。' };
    try {
      const c = await this.#cached(`page:${t}`, cfg.pageTtlMs, refresh, async () => {
        const json = await this.#getJson({
          action: 'parse', page: t, prop: 'text|sections|displaytitle', redirects: '1',
        });
        if (json?.error) {
          if (json.error.code === 'missingtitle') {
            throw new WikiError('missing', `B站原神Wiki 没有「${t}」这个条目`);
          }
          throw new WikiError('api', `B站原神Wiki 报错：${json.error.info || json.error.code}`);
        }
        const html = json?.parse?.text;
        if (!html) throw new WikiError('empty', `条目「${t}」没有正文内容`);
        const blocks = splitSections(html);
        if (!blocks.length) throw new WikiError('empty', `条目「${t}」没有可读正文`);
        return { title: String(json.parse.title || t), blocks, revid: json.parse.revid ?? null };
      });

      const data = c.data;
      const names = data.blocks.map((b) => b.title);
      let picked = data.blocks;
      if (String(section).trim()) {
        const want = String(section).trim();
        const w = norm(want);
        let idx = -1;
        if (/^\d+$/.test(want)) {
          idx = Number(want) - 1;
        } else {
          idx = data.blocks.findIndex((b) => norm(b.title) === w);
          if (idx < 0) idx = data.blocks.findIndex((b) => norm(b.title).includes(w) || (w.length >= 2 && w.includes(norm(b.title))));
        }
        if (idx < 0 || idx >= data.blocks.length) {
          // 有些条目（例如圣遗物套装）整页根本没有小节标题，
          // 这时 section 就只能退化成"按关键词截一段上下文"，而不是直接报错。
          const win = this.#sectionWindow(data, want, clamp(maxChars, 200, cfg.maxCharsCap, cfg.maxChars));
          if (win) {
            return {
              ...win,
              source: SITE_LABEL,
              fetchedAt: iso(c.fetchedAt),
              cacheHit: c.cacheHit,
              ...(c.stale ? { stale: true } : {}),
              ...(c.warning ? { warning: c.warning } : {}),
            };
          }
          return {
            ok: false,
            code: 'no-section',
            title: data.title,
            url: pageUrl(data.title),
            error: `条目「${data.title}」里没有叫「${want}」的小节`,
            sections: names,
            hint: '用返回的 sections 里的名字重试，或留空 section 读全文。',
          };
        }
        picked = [data.blocks[idx]];
        // 命中父小节时把它的子小节一起带上
        for (let i = idx + 1; i < data.blocks.length && data.blocks[i].level > data.blocks[idx].level; i += 1) {
          picked.push(data.blocks[i]);
        }
      }

      const body = picked
        .map((b) => `## ${b.title}\n${b.text || '（本节无正文）'}`)
        .join('\n\n');
      const max = clamp(maxChars, 200, cfg.maxCharsCap, cfg.maxChars);
      const cut = cutText(body, max);
      const usedTitles = new Set(picked.map((b) => b.title));
      const rest = data.blocks.filter((b) => !usedTitles.has(b.title)).map((b) => b.title);
      return {
        ok: true,
        title: data.title,
        url: pageUrl(data.title),
        source: SITE_LABEL,
        fetchedAt: iso(c.fetchedAt),
        cacheHit: c.cacheHit,
        ...(c.stale ? { stale: true } : {}),
        ...(c.warning ? { warning: c.warning } : {}),
        sections: names,
        text: cut.text,
        truncated: cut.truncated,
        ...(cut.truncated
          ? { note: `正文超过 ${max} 字已截断；要完整内容就指定 section 读某一节，或用更大的 maxChars（上限 ${cfg.maxCharsCap}）。` }
          : {}),
        ...(rest.length ? { otherSections: rest } : {}),
      };
    } catch (e) {
      return this.#fail(e);
    }
  }

  /**
   * 一步到位：搜索 → 挑最像的条目 → 读它的正文。
   * 模型少一次往返：群里问「和璞鸢突破材料」时通常一次调用就够。
   */
  async lookup(topic, { section = '', maxChars, refresh = false } = {}) {
    const q = String(topic ?? '').trim();
    if (!q) return { ok: false, error: 'topic 不能为空', code: 'bad-arg', hint: '给出要查的东西，例如「绝缘之旗印」。' };
    const s = await this.search(q, { limit: this.#cfg().maxResults, refresh });
    if (!s.ok) return s;
    if (!s.results.length) {
      return { ok: false, code: 'not-found', query: q, error: `B站原神Wiki 搜不到「${q}」相关条目`, hint: '换个关键词再试，或直接告诉群友没有查到。' };
    }
    const target = s.results[0].title;
    const r = await this.read(target, { section, maxChars, refresh });
    if (!r.ok) return { ...r, query: q, triedTitle: target };
    return {
      ...r,
      query: q,
      picked: { title: r.title, url: r.url, type: s.results[0].type },
      alternatives: s.results.slice(1).map((x) => ({ title: x.title, type: x.type, url: x.url })),
    };
  }

  /** 列某个分类下有哪些条目（"有哪些五星长柄武器"这类问题用）。 */
  async listCategory(category, { limit, refresh = false } = {}) {
    const cfg = this.#cfg();
    const raw = String(category ?? '').trim();
    if (!raw) return { ok: false, error: 'category 不能为空', code: 'bad-arg', hint: `可用分类：${Object.keys(CATEGORY_MAP).join('、')}` };
    const mapped = CATEGORY_MAP[raw] || SUBCATEGORIES[raw] || (raw.startsWith('Category:') ? raw.slice(9) : raw);
    const catTitle = `Category:${mapped}`;
    const n = clamp(limit, 1, 500, cfg.categoryLimit);
    try {
      const c = await this.#cached(`cat:${catTitle}:${n}`, cfg.catTtlMs, refresh, async () => {
        const json = await this.#getJson({
          action: 'query', list: 'categorymembers', cmtitle: catTitle, cmlimit: String(n), cmtype: 'page|subcat',
        });
        if (json?.error) throw new WikiError('api', `B站原神Wiki 报错：${json.error.info || json.error.code}`);
        const members = json?.query?.categorymembers || [];
        return {
          pages: members.filter((m) => !String(m.title).startsWith('分类:')).map((m) => String(m.title)),
          subcats: members.filter((m) => String(m.title).startsWith('分类:')).map((m) => String(m.title).slice(3)),
          hasMore: Boolean(json?.continue?.cmcontinue),
          raw: members.length,
        };
      });
      const d = c.data;
      if (!d.pages.length && !d.subcats.length) {
        return {
          ok: false,
          code: 'empty-category',
          category: raw,
          categoryPage: catTitle,
          error: `分类「${mapped}」下面没有取到条目`,
          hint: `确认分类名；常用分类：${Object.keys(CATEGORY_MAP).join('、')}`,
        };
      }
      return {
        ok: true,
        category: raw,
        wikiCategory: mapped,
        categoryPage: `${SITE_ORIGIN}/ys/${encodeURIComponent(catTitle)}`,
        source: SITE_LABEL,
        fetchedAt: iso(c.fetchedAt),
        cacheHit: c.cacheHit,
        ...(c.stale ? { stale: true } : {}),
        ...(c.warning ? { warning: c.warning } : {}),
        count: d.pages.length,
        hasMore: d.hasMore,
        entries: d.pages.map((title) => ({ title, url: pageUrl(title) })),
        ...(d.subcats.length ? { subcategories: d.subcats } : {}),
        ...(d.hasMore ? { note: '这个分类条目很多，只列了前一批；要更多就加大 limit。' } : {}),
      };
    } catch (e) {
      return this.#fail(e);
    }
  }
}
