// 原神 Wiki 条目速查（B站原神Wiki 数据源）
//
// 类型：skills/ = LLM 型（注册工具，模型自己决定什么时候查）
// 与隔壁 genshin-wiki 技能的关系（后者可能被用户关掉，本技能不依赖它）：
//   genshin-wiki      角色「数据」——技能、命座、每级倍率、突破材料、基础面板（本地角色库）
//   本技能            全部「百科条目」——武器、圣遗物、材料、敌人、任务剧情、版本、配队攻略，
//                     也包括角色条目本身（属性数据/天赋/命座/角色搭配推荐等小节）
// 两者都指向同一个 wiki，互不覆盖；模型侧的优先级写在 skill.json 的 prompt 里。

import path from 'node:path';
import { DATA_DIR as CORE_DATA_DIR } from '../../src/config.js';
import { GenshinWikiClient, CATEGORY_MAP, SUBCATEGORIES, SITE_LABEL } from './wiki-client.js';

// 运行时数据目录：QQ_AGENT_DATA_DIR（electron 主进程会设置）优先，
// 拿不到再用核心 config.js 算出来的值 —— 与项目里其它技能同一约定。
const DATA_DIR = process.env.QQ_AGENT_DATA_DIR || CORE_DATA_DIR;

let client = null;
let readConfig = () => ({});
let log = () => {};
let warn = () => {};

const string = (description) => ({ type: 'string', description });
const integer = (description) => ({ type: 'integer', description });
const refresh = {
  type: 'boolean',
  description: 'true = 忽略缓存重新抓一次。只在你明确知道缓存太旧时才用，默认 false。',
};

const CATEGORY_HELP = `可用分类：${Object.keys(CATEGORY_MAP).join('、')}；任务子类：${Object.keys(SUBCATEGORIES).join('、')}。`;

const j = (obj) => ({ content: JSON.stringify(obj) });
const jErr = (obj) => ({ isError: true, content: JSON.stringify(obj) });

export function setup(api) {
  readConfig = api.config || (() => ({}));
  log = api.log || (() => {});
  warn = api.warn || (() => {});

  client = new GenshinWikiClient({
    cacheDir: path.join(DATA_DIR, 'genshin-wiki-codex-cache'),
    settings: () => readConfig(),
    fetchImpl: api.fetch,
    logger: { log, warn },
  });

  api.registerTool({
    id: 'lookup',
    name: '查原神Wiki条目',
    description:
      `在${SITE_LABEL}搜索并读取最匹配的条目正文，返回整理好的纯文本资料。` +
      '适用：武器、圣遗物、材料、特产、敌人/怪物、任务与剧情、版本更新、配队与培养攻略、书籍、NPC，以及角色条目本身（属性数据/天赋/命座/角色搭配推荐）。' +
      '如果你的工具列表里还有 genshin-wiki 的工具，角色的技能/命座/倍率优先用它；没有就直接用本工具读角色条目。' +
      '一次调用即可回答大多数问题；返回里带 sections（章节名）和 alternatives（其它候选条目）。',
    category: 'knowledge',
    icon: '📖',
    parameters: {
      type: 'object',
      properties: {
        topic: string('要查的东西，用游戏里的正式名字最好。例如「和璞鸢」「绝缘之旗印」「若陀龙王」「5.0版本」「枫原万叶配队」。'),
        section: string('可选：只读某一节，例如「突破材料」「推荐角色」「BOSS技能」。留空读全文。'),
        max_chars: integer('可选：返回正文字数上限，默认按设置（约 2500）。要更全就加大。'),
        refresh: refresh,
      },
      required: ['topic'],
    },
    async execute(ctx, args) {
      try {
        const r = await client.lookup(args?.topic, {
          section: args?.section,
          maxChars: args?.max_chars,
          refresh: !!args?.refresh,
        });
        return r.ok ? j(r) : jErr(r);
      } catch (e) {
        return jErr({ ok: false, error: String(e?.message || e), hint: '工具内部异常，如实告诉群友没查到即可。' });
      }
    },
  });

  api.registerTool({
    id: 'read',
    name: '读原神Wiki指定条目',
    description:
      '按**准确条目名**读取正文，可用 section 只读其中一节（先用 lookup 拿到 sections 列表再读）。' +
      '适合：已经知道条目名、或只想深挖某一节（例如某武器的「推荐角色」）。',
    category: 'knowledge',
    icon: '📄',
    parameters: {
      type: 'object',
      properties: {
        title: string('条目名，要和 wiki 上一致，例如「绝缘之旗印」。'),
        section: string('可选：小节名或序号，例如「故事」「2」。留空读全文。'),
        max_chars: integer('可选：返回正文字数上限。'),
        refresh: refresh,
      },
      required: ['title'],
    },
    async execute(ctx, args) {
      try {
        const r = await client.read(args?.title, {
          section: args?.section,
          maxChars: args?.max_chars,
          refresh: !!args?.refresh,
        });
        return r.ok ? j(r) : jErr(r);
      } catch (e) {
        return jErr({ ok: false, error: String(e?.message || e), hint: '工具内部异常，如实告诉群友没查到即可。' });
      }
    },
  });

  api.registerTool({
    id: 'list_category',
    name: '列原神Wiki分类条目',
    description:
      '列出某个分类下有哪些条目。适合「有哪些五星长柄武器」「5.x 都更新了什么」「某个地区特产有哪些」这类**列举型**问题。' +
      CATEGORY_HELP,
    category: 'knowledge',
    icon: '🗂️',
    parameters: {
      type: 'object',
      properties: {
        category: string(`分类名，例如「武器」「圣遗物」「敌人」「材料」「特产」「食物」「书籍」「NPC」「任务」「版本」「秘境」「配队」。`),
        limit: integer('可选：最多列几条，默认 40。'),
        refresh: refresh,
      },
      required: ['category'],
    },
    async execute(ctx, args) {
      try {
        const r = await client.listCategory(args?.category, {
          limit: args?.limit,
          refresh: !!args?.refresh,
        });
        return r.ok ? j(r) : jErr(r);
      } catch (e) {
        return jErr({ ok: false, error: String(e?.message || e), hint: '工具内部异常，如实告诉群友没查到即可。' });
      }
    },
  });

  log(`已加载（数据源：${SITE_LABEL}）`);
}

export function activate() {
  log('已启用：模型可以在需要时查原神 Wiki 条目');
}

export function deactivate() {
  log('已停用');
}

/** 不需要任何外部依赖（密钥/二进制），永远可用。 */
export function available() {
  return { ok: true };
}
