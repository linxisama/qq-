// dd2-relationship-lookup —— 让模型主动查「我和某人现在什么关系」
//
// 为什么单独做成技能而不是塞进 dd2-relationship 插件：
//   · 插件负责"结算"（钩子 + 发送层补丁），是确定性的；
//   · 技能负责"按需查询"，是模型可以主动调的工具。
//   QQ-Agent 里这两类东西分开放，混在一起会让插件变成一个又大又难验收的东西。
//
// 只读：只读 data/dd2-relationship.json，绝不写。点数结算仍然只归插件。
import fs from 'node:fs';
import path from 'node:path';
import { DATA_DIR, getConfig } from '../../src/config.js';

const SKILL_ID = 'dd2-relationship-lookup';
const TOOL_ID = 'relationship_query';
const DATA_FILE = path.join(DATA_DIR, 'dd2-relationship.json');

/** 与插件保持一致的默认七档（插件没配 bandsJson 时用这个）。 */
const DEFAULT_BANDS = [
  { min: 0, max: 0, name: '最低和睦', negative: 1 },
  { min: 1, max: 4, name: '非常不友好', negative: 0.65 },
  { min: 5, max: 8, name: '不友好', negative: 0.33 },
  { min: 9, max: 13, name: '中性' },
  { min: 14, max: 16, name: '友好', positive: 0.33 },
  { min: 17, max: 19, name: '非常友好', positive: 0.65 },
  { min: 20, max: 20, name: '最高和睦', positive: 1 }
];

let apiRef = null;
let toolId = '';
let log = (...args) => console.warn(`[${SKILL_ID}]`, ...args);

const clamp = (v, lo, hi) => Math.min(hi, Math.max(lo, v));

function settings() {
  const raw = (apiRef && typeof apiRef.config === 'function' ? apiRef.config() : null) || {};
  return { maxList: clamp(Math.round(Number(raw.maxList) || 10), 1, 50) };
}

/** 关系系统的配置来自插件（不是本技能），这样两边的档位/上限永远是同一套。 */
function relationshipConfig() {
  try {
    const c = getConfig() || {};
    const raw = (c.skills || {})['dd2-relationship'] || {};
    const min = Number.isFinite(Number(raw.min)) ? Number(raw.min) : 0;
    const max = Number.isFinite(Number(raw.max)) ? Number(raw.max) : 20;
    return {
      min,
      max,
      bands: parseBands(raw.bandsJson, min, max),
      privilegedAlwaysMax: raw.privilegedAlwaysMax !== false,
      ownerIds: ownerIdsOf(c, raw)
    };
  } catch {
    return { min: 0, max: 20, bands: DEFAULT_BANDS.map((b) => ({ ...b })), privilegedAlwaysMax: true, ownerIds: new Set() };
  }
}

function parseBands(rawText, min, max) {
  const text = String(rawText || '').trim();
  if (!text) return DEFAULT_BANDS.map((b) => ({ ...b }));
  try {
    const list = JSON.parse(text);
    if (!Array.isArray(list) || !list.length) return DEFAULT_BANDS.map((b) => ({ ...b }));
    const out = [];
    for (const b of list) {
      if (!b || typeof b !== 'object') continue;
      const lo = Number(b.min);
      const hi = Number(b.max);
      const name = String(b.name || '').trim();
      if (!Number.isFinite(lo) || !Number.isFinite(hi) || hi < lo || !name) continue;
      const band = { min: clamp(Math.round(lo), min, max), max: clamp(Math.round(hi), min, max), name };
      if (Number(b.negative) > 0) band.negative = clamp(Number(b.negative), 0, 1);
      if (Number(b.positive) > 0) band.positive = clamp(Number(b.positive), 0, 1);
      out.push(band);
    }
    return out.length ? out.sort((a, b) => a.min - b.min) : DEFAULT_BANDS.map((x) => ({ ...x }));
  } catch {
    return DEFAULT_BANDS.map((b) => ({ ...b }));
  }
}

function ownerIdsOf(cfg, pluginCfg = {}) {
  const out = new Set();
  const push = (raw) => {
    if (Array.isArray(raw)) { raw.forEach(push); return; }
    String(raw ?? '').split(/[,，、;；\s]+/).map((x) => x.trim()).filter((x) => /^\d{5,}$/.test(x)).forEach((x) => out.add(x));
  };
  push(pluginCfg.ownerQQ);
  if (!out.size) push(cfg?.skills?.['owner-identity']?.ids);
  return out;
}

function bandOf(score, bands) {
  const v = Number(score) || 0;
  let hit = bands[0];
  for (const b of bands) {
    if (v >= b.min && v <= b.max) return b;
    if (v > b.max) hit = b;
  }
  return hit;
}

function loadPeople() {
  try {
    const raw = JSON.parse(fs.readFileSync(DATA_FILE, 'utf8'));
    return raw && typeof raw.people === 'object' && raw.people ? raw.people : {};
  } catch {
    return {};
  }
}

function describe(userId) {
  const cfg = relationshipConfig();
  const people = loadPeople();
  const id = String(userId || '').trim();
  if (!/^\d+$/.test(id)) return null;
  const person = people[id];
  if (!person) return { missing: true, id };
  const privileged = cfg.ownerIds.has(id) && cfg.privilegedAlwaysMax;
  const score = privileged ? cfg.max : clamp(Number(person.score) || 0, cfg.min, cfg.max);
  const band = bandOf(score, cfg.bands);
  const rel = person.relation && typeof person.relation === 'object' ? person.relation : null;
  return { missing: false, id, score, max: cfg.max, band, relation: rel, privileged };
}

function lineOf(info) {
  if (!info || info.missing) return '';
  const parts = [`QQ:${info.id} 关系 ${info.score}/${info.max}（${info.band.name}）`];
  if (info.privileged) parts.push('（机主·恒满档）');
  if (info.relation) {
    const polarity = info.relation.polarity === 'positive' ? '正面' : '负面';
    const text = info.relation.pending ? '（还没写描述）' : (info.relation.text || '（无描述）');
    parts.push(`｜${polarity}关系：${text}`);
  }
  return parts.join('');
}

async function runQuery(ctx = {}, args = {}) {
  try {
    const cfg = relationshipConfig();
    const userId = String(args?.userId ?? '').trim();
    if (userId) {
      const info = describe(userId);
      if (!info) return { content: '错误：userId 不是合法 QQ 号。', isError: true };
      if (info.missing) {
        return { content: `还没有关于 QQ:${userId} 的关系记录（第一次互动之后才会建档）。`, isError: true };
      }
      const bandNote = info.band.negative
        ? '这个档位容易产生负面关系。'
        : info.band.positive
          ? '这个档位容易巩固正面关系。'
          : '这是中性档，没有额外效果。';
      return { content: `${lineOf(info)}\n（${bandNote}点数由系统按互动结算，你只读不改。）` };
    }
    // 没指定人：列出有档案的（按最近活跃排序），只给档位与关系，不带太多细节
    const people = loadPeople();
    const ids = Object.keys(people);
    if (!ids.length) return { content: '还没有任何关系记录（还没和谁互动过）。' };
    const sorted = ids
      .sort((a, b) => (Number(people[b]?.updatedAt) || 0) - (Number(people[a]?.updatedAt) || 0))
      .slice(0, settings().maxList);
    const lines = [];
    for (const id of sorted) {
      const info = describe(id);
      if (info && !info.missing) lines.push(`· ${lineOf(info)}`);
    }
    const head = `最近有记录的 ${lines.length} 个人（最多列 ${settings().maxList} 个，按最近活跃排序）：`;
    return { content: `${head}\n${lines.join('\n')}` };
  } catch (error) {
    return { content: `查关系失败：${error?.message ?? error}`, isError: true };
  }
}

export function setup(api = {}) {
  apiRef = api;
  if (typeof api.log === 'function') log = (...args) => api.log(...args);
  try {
    const registered = api.registerTool({
      id: TOOL_ID,
      name: '查关系',
      description: '查「我和某个人现在是什么关系」：关系点数、档位（最低和睦…最高和睦）、有没有正面/负面关系以及那段关系的描述。'
        + '被问到「你还记得我吗」「我在你这儿算什么」「你跟他关系怎么样」这类问题时用它，不要凭印象编。'
        + 'userId 不填则列出最近有记录的人。只读——点数由系统按互动结算，你改不了。',
      category: 'query',
      icon: '🔗',
      parameters: {
        type: 'object',
        properties: {
          userId: { type: ['integer', 'string'], description: '要查的人 QQ 号（不填则列出最近有记录的人）' }
        }
      },
      async execute(ctx, args) {
        return runQuery(ctx, args);
      }
    });
    if (typeof registered === 'string' && registered.trim()) toolId = registered.trim();
    log(`v1.0.0 已启用：工具 ${toolId || TOOL_ID}，存档 ${DATA_FILE}`);
  } catch (error) {
    log('注册工具失败：', error?.message ?? error);
  }
}

export function available() {
  return { ok: true };
}

export function dispose() {
  toolId = '';
}

export { runQuery, describe, bandOf, relationshipConfig };
