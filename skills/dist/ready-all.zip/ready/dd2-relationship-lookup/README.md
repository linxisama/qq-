# 关系查询（dd2-relationship-lookup）

让机器人能主动查「我和某个人现在是什么关系」。

## 做什么

提供一个只读工具 `relationship_query`：

- 传 `userId` → 返回那个人的关系点数、档位、有没有正面/负面关系、以及那段关系的描述
- 不传 → 列出最近有记录的人（按最近活跃排序）

数据来自 **关系系统（dd2-relationship）** 插件；本技能只读，不改任何东西。

## 安装

把本目录放进 QQ-Agent 的 `resources/app/skills/dd2-relationship-lookup/`，重启应用。

## 依赖

- 需要同时安装 **dd2-relationship** 插件才有数据；不装也能装，只是永远返回「还没有记录」。

## 设置

| 设置 | 说明 |
|---|---|
| `maxList` | 不指定 QQ 号时最多列几个人，默认 10 |

## 隐私

- 只读本地文件 `data/dd2-relationship.json`
- 不联网、不上传
