# Danbooru 找图（标签检索）

按角色 / 作品从 **Danbooru** 找图并发到当前会话。免 API key、免登录、直连。

## 用法

群里直接说「来张 XX 的图」「找三张 XX」即可，机器人会调用 `danbooru_image_tag` 工具。

- 角色名可以是中文（技能内置词典：普瑞赛斯、阿米娅、凯尔希、拉普兰德、东方角色等 50 条左右）；
- 模型知道自己填英文标签（如 `priestess_(arknights)`）时也会自动记进词典，越用越准；
- 默认把 `general`（全年龄）和 `sensitive`（轻微暗示）两种都算进候选，从高分窗口里**随机**挑，`questionable`/`explicit` 不发。

## 主要设置

| 键 | 默认 | 说明 |
|---|---|---|
| `count` | 1 | 默认发几张（1~5） |
| `ratings` | general,sensitive | 内容分级 |
| `pickMode` | random | random=随机挑；top=永远取最高分 |
| `randomPool` | 24 | 随机窗口（分数前 N 名） |
| `balanceRatings` | true | 两种分级各占一半窗口 |
| `maxMB` / `preferSampleOverMB` | 12 / 8 | 大图退 sample 的体积阈值 |
| `allowRepost` | false | 发过的图默认不重发 |

## 数据文件

- `<数据目录>/danbooru/tag-dict.json`：中文名 → Danbooru 标签词典（可手工扩充）
- `<数据目录>/danbooru/index.json`：发过的图索引（去重）

## 注意

- 抓 Danbooru 必须用**带名字的机器人 UA**（浏览器 UA 会被 403），技能内已处理；
- 图床速度差异很大，技能内置「大图退 sample、失败换下一张候选」。

## 镜像备用（2026-10-22）

本机网络下 `danbooru.donmai.us` 的 TLS 会被挡（DNS 解析到 fake-IP、握手失败），技能会**自动切换**到 `safebooru.donmai.us` 镜像（API 相同，仅全年龄图）。日志里会写「API 切换到镜像」。图片仍走 cdn.donmai.us。
