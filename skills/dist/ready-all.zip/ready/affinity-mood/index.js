/**
 * 好感度与语气（affinity-mood）—— LLM 型技能
 *
 * 机制：
 *  - 记分：模型在识别到「被夸 / 被骂」时调用 adjust_affinity（配额由代码强制截断）
 *  - 查询：check_affinity
 *  - 语气：before-context 钩子认出「这句话是谁说的」，promptSections 按这个人的分数
 *          注入一段当前语气说明（冷淡 / 正常 / 亲近 / 黏人）
 *  - 数据：data/affinity-mood.json（跟随 QQ_AGENT_DATA_DIR，默认项目根 data/）
 *
 * 遵守 skill-reference.md §14 的硬约束：
 *  - promptSections / available 同步返回；钩子里不发消息、不发网络请求、不重试
 *  - 配置在执行时用 cfg() 读，不在 setup 时快照
 *  - 失败路径返回 { content, isError: true }，不把异常抛给上层
 *  - 工具 id 只用 [a-zA-Z0-9_-]
 */

import fs from 'node:fs';
import fsp from 'node:fs/promises';
import path from 'node:path';

const MIN_SCORE = -100;
const MAX_SCORE = 100;
const TARGET_TTL = 10 * 60 * 1000; // 触发者缓存 10 分钟

const DEFAULTS = {
  plusCap: 2,
  minusCap: 50,
  personaSwitch: true
};

let cfg = () => ({});
let log = () => {};
let warn = () => {};

let db = null;
let dbFile = '';
let dirty = false;

/** chatKey -> { userId, name, at }：这条消息是谁触发的 */
const lastTarget = new Map();

// ───────────────────────────── 生命周期 ─────────────────────────────

export function setup(api) {
  cfg = typeof api?.config === 'function' ? api.config : () => ({});
  log = typeof api?.log === 'function' ? api.log : () => {};
  warn = typeof api?.warn === 'function' ? api.warn : () => {};

  api.registerTool({
    id: 'adjust_affinity',
    name: '调整好感度',
    description:
      '记录某个群友对机器人好感度的变化。当有人明确夸机器人、感谢机器人、对机器人示好时，delta 填 1（特别真诚可填 2）；' +
      '当有人明确辱骂、羞辱、人身攻击机器人时，delta 填 -2（很恶劣填 -5，极端填 -10）。' +
      '普通调侃、玩笑、一次不同意见不要调用。每天加分和扣分都有上限，超出的部分系统会自动截断，不需要你计算。' +
      'target 不填表示刚刚说话的那个人；要给指定的人记，才填 QQ 号或群昵称。',
    category: 'system',
    icon: '💗',
    parameters: {
      type: 'object',
      properties: {
        delta: {
          type: 'number',
          description: '变化量：夸奖用 1~2，辱骂用 -2 / -5 / -10。不能为 0。'
        },
        target: {
          type: 'string',
          description: '要记的人，QQ 号或群昵称。不填表示刚刚说话的人。'
        },
        reason: {
          type: 'string',
          description: '一句话说明原因（如“夸可爱”“持续人身攻击”），仅用于日志。'
        }
      },
      required: ['delta']
    },
    async execute(ctx, args) {
      try {
        const chatKey = chatKeyOf(ctx);
        if (!chatKey) return { content: '拿不到当前会话标识，无法记录好感度。', isError: true };

        const delta = clampDelta(Number(args?.delta));
        if (!delta) {
          return { content: 'delta 不合法：夸奖填 1~2，辱骂填 -2 / -5 / -10。', isError: true };
        }

        const targetText = String(args?.target ?? '').trim();
        let userId = '';
        let name = '';

        if (targetText) {
          const hit = findMember(chatKey, targetText);
          if (!hit) {
            return {
              content: `没有找到「${targetText}」的好感度记录。可以让对方先说句话，或改用 QQ 号。`,
              isError: true
            };
          }
          if (hit.ambiguous) {
            return { content: `「${targetText}」能匹配到好几个人，请改用 QQ 号。`, isError: true };
          }
          userId = hit.userId;
        } else {
          const ent = await resolveRequester(ctx);
          if (!ent?.userId) {
            return { content: '没认出这句话是谁说的，请在 target 里填对方 QQ 号或群昵称。', isError: true };
          }
          userId = ent.userId;
          name = ent.name || '';
        }

        const s = currentSettings();
        const rec = getRec(chatKey, userId);
        if (name && !rec.name) rec.name = name;

        const before = clampScore(rec.score);
        const applied = applyDelta(rec, delta, s);
        rec.updatedAt = Date.now();
        dirty = true;
        await save();

        const tier = tierOf(rec.score);
        const capText = `今天已加 ${rec.dayPlus}/${capOf(s.plusCap)}，已扣 ${rec.dayMinus}/${capOf(s.minusCap)}`;
        if (!applied) {
          return {
            content:
              `没有变化：${rec.name || userId} 的好感度已经是 ${rec.score}，或今天的额度用完了（${capText}）。` +
              '这是正常的，不用向对方解释额度。',
            isError: false
          };
        }

        log(
          `好感度 ${rec.name || userId}：${before} → ${rec.score}（${applied > 0 ? '+' : ''}${applied}，` +
            `${args?.reason || '未写原因'}）`
        );
        return {
          content:
            `已记录：${rec.name || userId}（QQ ${userId}）的好感度 ${before} → ${rec.score}，` +
            `本次 ${applied > 0 ? '+' : ''}${applied}；当前档位「${tier.label}」；${capText}。` +
            '不要主动把分数念出来，除非对方明确问。'
        };
      } catch (error) {
        return { content: `记录好感度失败：${error?.message ?? error}`, isError: true };
      }
    }
  });

  api.registerTool({
    id: 'check_affinity',
    name: '查询好感度',
    description:
      '查询某个群友对机器人的好感度分数、当前档位和今天的加减分额度。' +
      '当有人问「我好感度多少」「你跟我多熟」「查一下某某的好感度」时使用。' +
      'target 不填表示查正在提问的这个人。数据由系统保存，你无法凭空知道，必须调用本工具。',
    category: 'query',
    icon: '🔍',
    parameters: {
      type: 'object',
      properties: {
        target: {
          type: 'string',
          description: '要查的人，QQ 号或群昵称。不填表示查正在提问的人。'
        }
      }
    },
    async execute(ctx, args) {
      try {
        const chatKey = chatKeyOf(ctx);
        if (!chatKey) return { content: '拿不到当前会话标识，无法查询好感度。', isError: true };

        const targetText = String(args?.target ?? '').trim();
        let userId = '';
        let name = '';

        if (targetText) {
          const hit = findMember(chatKey, targetText);
          if (!hit) {
            return {
              content: `没有找到「${targetText}」的好感度记录。对方可能还没在这个群说过话，或名字写错了。`,
              isError: true
            };
          }
          if (hit.ambiguous) {
            return { content: `「${targetText}」能匹配到好几个人，请改用 QQ 号。`, isError: true };
          }
          userId = hit.userId;
        } else {
          const ent = await resolveRequester(ctx);
          if (!ent?.userId) {
            return { content: '没认出提问的人是谁，请在 target 里填 QQ 号或昵称。', isError: true };
          }
          userId = ent.userId;
          name = ent.name || '';
        }

        const s = currentSettings();
        const rec = getRec(chatKey, userId);
        if (name && !rec.name) rec.name = name;
        const score = clampScore(rec.score);
        const tier = tierOf(score);

        return {
          content:
            `${rec.name || userId}（QQ ${userId}）的好感度：${score}（范围 -100 ~ +100）；` +
            `档位「${tier.label}」；今天已加 ${rec.dayPlus}/${capOf(s.plusCap)}，已扣 ${rec.dayMinus}/${capOf(s.minusCap)}。` +
            '用你自己的语气说出来即可，不要主动报精确分数，除非对方问。'
        };
      } catch (error) {
        return { content: `查询好感度失败：${error?.message ?? error}`, isError: true };
      }
    }
  });

  log('好感度与语气已加载');
}

/** 可用性自检：必须同步返回 */
export function available() {
  return true;
}

// ───────────────────────────── 钩子与动态提示词 ─────────────────────────────

export const hooks = {
  /**
   * 组装提示词之前：认出这条消息是谁发的，缓存起来给 promptSections 用。
   * 只做本地读写，不发消息、不发网络请求。
   */
  'before-context': async (payload) => {
    try {
      const chatKey = chatKeyOf(payload);
      if (!chatKey) return;
      const selfId = String(payload?.selfId || '');
      const ent = pickSpeaker(payload?.triggerEntries, selfId);
      if (!ent) return;

      const rec = getRec(chatKey, ent.userId);
      if (ent.name) rec.name = ent.name;
      lastTarget.set(chatKey, { userId: ent.userId, name: ent.name, at: Date.now() });
      dirty = true;
      await save();
    } catch (error) {
      warn(`好感度上下文记录失败：${error?.message ?? error}`);
    }
  }
};

/**
 * 按“正在说话的这个人”的好感度，注入当前语气说明。
 * 必须同步返回；任何异常都退回「不注入」，不能影响主流程。
 */
export function promptSections(ctx) {
  try {
    const s = currentSettings();
    if (s.personaSwitch === false) return [];

    const chatKey = String(ctx?.chatKey || '');
    if (!chatKey) return [];

    const t = lastTarget.get(chatKey);
    if (!t || Date.now() - t.at > TARGET_TTL) return [];

    const rec = getRec(chatKey, t.userId);
    const score = clampScore(rec.score);
    const tier = tierOf(score);
    const name = formatName(rec.name || t.name);

    return [
      {
        id: 'affinity-mood-persona',
        title: '当前语气',
        priority: 60,
        content: tier.prompt(score, name)
      }
    ];
  } catch {
    return [];
  }
}

// ───────────────────────────── 语气档位 ─────────────────────────────

const TIERS = [
  {
    id: 'cold',
    label: '冷淡',
    test: (score) => score <= -50,
    prompt: (score, name) =>
      `你对 ${name} 的好感度偏低（${score}）。跟 TA 说话时冷淡、简短、爱答不理：能一句说完就不说第二句，` +
      '不主动找话题，不接梗，不讨好。可以有一点不耐烦或阴阳，但不许辱骂、不许人身攻击、' +
      '不许拿家人开玩笑、不许地域歧视、不许威胁、不许碰政治。对方正常问事时仍然把事答了，只是态度冷。'
  },
  {
    id: 'normal',
    label: '正常',
    test: (score) => score <= 50,
    prompt: (score, name) =>
      `你对 ${name} 的好感度是 ${score}，正常相处。像熟人一样短句聊天，保持小鲸鱼的语气：` +
      '可以吐槽、接梗、偶尔小傲娇，但别刻意讨好，也别莫名其妙发火。'
  },
  {
    id: 'warm',
    label: '亲近',
    test: (score) => score < 100,
    prompt: (score, name) =>
      `你对 ${name} 的好感度偏高（${score}）。语气明显更软：愿意主动关心、接话、夸回去，` +
      '可以撒娇、可以黏一点，但保持简短，别腻歪，也别刷屏。'
  },
  {
    id: 'close',
    label: '黏人',
    test: () => true,
    prompt: (score, name) =>
      `你对 ${name} 的好感度是满值（${score}）。你很黏 TA：主动找话说、分享小事、撒娇、偶尔吃醋，` +
      '但每条仍然很短，不刷屏、不重复；对方忙或不想聊时能看出来并收住。'
  }
];

function tierOf(score) {
  const v = clampScore(score);
  for (const tier of TIERS) {
    if (tier.test(v)) return tier;
  }
  return TIERS[TIERS.length - 1];
}

function formatName(name) {
  const text = String(name ?? '')
    .replace(/[\r\n\t]+/g, ' ')
    .trim()
    .slice(0, 24);
  return text || '这个群友';
}

// ───────────────────────────── 记分 ─────────────────────────────

function applyDelta(rec, delta, s) {
  const plusCap = capOf(s.plusCap);
  const minusCap = capOf(s.minusCap);
  const before = clampScore(rec.score);

  let applied = 0;
  if (delta > 0) {
    const room = Math.max(0, plusCap - (Number(rec.dayPlus) || 0));
    applied = Math.min(delta, room, MAX_SCORE - before);
  } else {
    const room = Math.max(0, minusCap - (Number(rec.dayMinus) || 0));
    applied = Math.max(delta, -room, MIN_SCORE - before);
  }
  applied = Math.round(applied);

  rec.score = clampScore(before + applied);
  if (applied > 0) rec.dayPlus = (Number(rec.dayPlus) || 0) + applied;
  else if (applied < 0) rec.dayMinus = (Number(rec.dayMinus) || 0) + Math.abs(applied);
  return applied;
}

function clampDelta(n) {
  if (!Number.isFinite(n)) return 0;
  const v = Math.round(n);
  if (!v) return 0;
  if (v > 2) return 2;
  if (v < -10) return -10;
  return v;
}

function clampScore(n) {
  const v = Math.round(Number(n));
  if (!Number.isFinite(v)) return 0;
  return Math.min(MAX_SCORE, Math.max(MIN_SCORE, v));
}

function capOf(n) {
  const v = Math.round(Number(n));
  if (!Number.isFinite(v) || v < 0) return 0;
  return Math.min(100, v);
}

/** 生效设定 = 内置默认 < 控制台/用户设置 */
function currentSettings() {
  const out = { ...DEFAULTS };
  let c = {};
  try {
    c = cfg() || {};
  } catch {
    c = {};
  }
  for (const [k, v] of Object.entries(c)) {
    if (v === undefined || v === null) continue;
    if (!Object.prototype.hasOwnProperty.call(DEFAULTS, k)) continue;
    if (k === 'personaSwitch') out[k] = v !== false;
    else out[k] = Number(v);
  }
  return out;
}

// ───────────────────────────── 会话与成员 ─────────────────────────────

function chatKeyOf(obj) {
  if (!obj) return '';
  if (obj.chatKey) return String(obj.chatKey);
  if (obj.kind && obj.chatId) return `${obj.kind}:${obj.chatId}`;
  return '';
}

/** 找触发这条消息的人（跳过机器人自己） */
function pickSpeaker(entries, selfId) {
  if (!Array.isArray(entries)) return null;
  for (let i = entries.length - 1; i >= 0; i -= 1) {
    const ent = normalizeEntry(entries[i], selfId);
    if (ent && !ent.isSelf) return ent;
  }
  return null;
}

/** 工具里确认“是谁在说话”：私聊直接用 chatId，群聊取触发消息/最近记录 */
async function resolveRequester(ctx) {
  if (ctx?.kind === 'private' && ctx?.chatId) {
    return { userId: String(ctx.chatId), name: '' };
  }

  const selfId = String(ctx?.selfId || '');
  const fromTrigger = pickSpeaker(ctx?.session?.triggerEntries, selfId);
  if (fromTrigger) return fromTrigger;

  try {
    const got = await ctx?.store?.recent?.(ctx?.chatKey, { limit: 30 });
    const list = Array.isArray(got) ? got : [];
    for (let i = list.length - 1; i >= 0; i -= 1) {
      const ent = normalizeEntry(list[i], selfId);
      if (ent && !ent.isSelf) return ent;
    }
  } catch {
    /* 拿不到记录就放弃，不影响主流程 */
  }
  return null;
}

function normalizeEntry(raw, selfId) {
  if (!raw || typeof raw !== 'object') return null;
  const e = raw.entry && typeof raw.entry === 'object' ? Object.assign({}, raw, raw.entry) : raw;
  const sender = e.sender && typeof e.sender === 'object' ? e.sender : null;

  const userId = String(
    firstVal([
      e.userId,
      e.user_id,
      e.senderId,
      e.senderUserId,
      e.fromUserId,
      e.qq,
      sender?.user_id,
      sender?.userId,
      sender?.id
    ]) ?? ''
  ).trim();

  if (!userId) return null;

  const name = String(
    firstVal([e.groupCard, e.card, e.senderName, e.nickname, sender?.card, sender?.nickname, sender?.name]) ?? ''
  ).trim();

  const role = String(sender?.role ?? '');
  const isSelf =
    e.self === true ||
    e.fromSelf === true ||
    e.isSelf === true ||
    e.outgoing === true ||
    role === 'self' ||
    Boolean(selfId && userId === String(selfId));

  return { userId, name, isSelf };
}

function firstVal(list) {
  for (const v of list) {
    if (v === null || v === undefined) continue;
    if (typeof v === 'string' && !v.trim()) continue;
    return v;
  }
  return undefined;
}

/** 按 QQ 号 / 群昵称找人 */
function findMember(chatKey, target) {
  const q = String(target ?? '').trim();
  if (!q) return null;

  const members = db?.chats?.[chatKey]?.members || {};

  // 纯数字 → 当 QQ 号；已有记录或 5~12 位都接受（可能还没发过言）
  if (/^\d{5,12}$/.test(q)) {
    return { userId: q, rec: getRec(chatKey, q) };
  }
  if (members[q]) return { userId: q, rec: getRec(chatKey, q) };

  const list = Object.entries(members);
  const key = q.toLowerCase();
  const exact = list.find(([, rec]) => String(rec.name || '').trim().toLowerCase() === key);
  if (exact) return { userId: exact[0], rec: getRec(chatKey, exact[0]) };

  const fuzzy = list.filter(([, rec]) => {
    const n = String(rec.name || '').trim().toLowerCase();
    return n && (n.includes(key) || key.includes(n));
  });
  if (fuzzy.length === 1) return { userId: fuzzy[0][0], rec: getRec(chatKey, fuzzy[0][0]) };
  if (fuzzy.length > 1) return { ambiguous: true };

  return null;
}

// ───────────────────────────── 持久化 ─────────────────────────────

function dataFile() {
  if (dbFile) return dbFile;
  const dir = process.env.QQ_AGENT_DATA_DIR || path.resolve(process.cwd(), 'data');
  dbFile = path.join(dir, 'affinity-mood.json');
  return dbFile;
}

function ensureDb() {
  if (db) return db;
  db = { version: 1, chats: {} };
  try {
    const raw = fs.readFileSync(dataFile(), 'utf8');
    const parsed = JSON.parse(raw);
    if (parsed && typeof parsed === 'object' && parsed.chats && typeof parsed.chats === 'object') {
      db.chats = parsed.chats;
    }
  } catch (error) {
    if (error?.code !== 'ENOENT') {
      warn(`读取好感度数据失败，将从空数据开始：${error?.message ?? error}`);
    }
  }
  return db;
}

function getRec(chatKey, userId) {
  const d = ensureDb();
  const key = String(chatKey);
  const uid = String(userId);

  if (!d.chats[key] || typeof d.chats[key] !== 'object') d.chats[key] = { members: {} };
  const chat = d.chats[key];
  if (!chat.members || typeof chat.members !== 'object') chat.members = {};

  let rec = chat.members[uid];
  if (!rec || typeof rec !== 'object') {
    rec = chat.members[uid] = {
      name: '',
      score: 0,
      dayKey: '',
      dayPlus: 0,
      dayMinus: 0,
      updatedAt: 0
    };
  }

  const today = dayKey(Date.now());
  if (rec.dayKey !== today) {
    rec.dayKey = today;
    rec.dayPlus = 0;
    rec.dayMinus = 0;
  }
  rec.score = clampScore(rec.score);
  return rec;
}

function dayKey(ts) {
  const d = new Date(ts);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

async function save() {
  if (!dirty || !db) return;
  dirty = false;
  try {
    const file = dataFile();
    await fsp.mkdir(path.dirname(file), { recursive: true });
    await fsp.writeFile(file, JSON.stringify(db), 'utf8');
  } catch (error) {
    dirty = true;
    warn(`写入好感度数据失败：${error?.message ?? error}`);
  }
}
