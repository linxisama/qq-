// 颜文字（kaomoji）—— 让机器人说话时按语气顺手带一个颜文字
//
// ── 为什么是技能（skills/，LLM 型），不是插件（plugins/）────────────────────
//   按 doc/extend_development/skill-development.md §0 的三问判据：
//   ① 触发时机能用 if 描述吗？——不能。「这句话该不该配颜文字」取决于语气、对象、
//      话题是否正经，没有一条规则能写死；像「用户提到天气」那种半死条件都不成立。
//   ② 漏触发一次的代价？——只是少个花活，不丢数据、不坏事。
//   ③ 参数从哪来？——要从人话里抠（「来个委屈的」→ 语气=委屈）。
//   三问一致指向**技能**：用 registerTool 把「取颜文字」交给模型自己判断要不要调。
//   如果做成插件（providers/hooks），模型根本看不见它，就不会在任何一句话里带颜文字
//   —— 那正是文档里说的「静默失效」。
//   （另外「让说话方式变一变」这个诉求本身，主力机制是 prompt.sections；
//    工具只负责保证颜文字**质量**：库里的是验过的，模型现拼的经常缺半边括号。）
//
// ── 设计取舍 ──────────────────────────────────────────────────────────────
//   · 工具**只返回候选文本**，不自己发消息。颜文字要嵌在模型这句话里才自然；
//     自己去发一条只会变成刷屏，还会绕过「模型怎么说」这层判断。
//   · 去重状态只放内存（Map）：这是说话习惯，不是数据。重启后重置完全可接受，
//     也就不需要碰 DATA_DIR、不需要 fs、不需要任何 import —— 掉盘即干净。
//   · 没有 export activate/deactivate：本技能不起定时器、不订阅事件，
//     多写一对空钩子只会给「关掉后还有行为」留隐患。

const SKILL_ID = 'kaomoji';

/** 与 skill.json 的 settings 保持一致（留一份是为了 cfg 取不到时的兜底）。 */
const DEFAULTS = {
  density: 'normal',
  maxPerMessage: 1,
  avoidRepeat: true
};

const DENSITY_LABEL = {
  rare: '很少（只有情绪很明显时才来一个）',
  normal: '正常（有情绪时带一个）',
  rich: '多带（有情绪就带）'
};

/**
 * 颜文字库。按语气分组，每组带同义词（aliases）——
 * 因为群友说的是「难过」「想哭」「emo」，而分组叫「委屈」，
 * 不做同义扩展就会「明明有图却说没有」。
 */
const GROUPS = [
  {
    key: '开心',
    aliases: ['开心', '高兴', '快乐', '笑', '哈哈', '愉快', '兴奋', '好耶', '喜', '乐'],
    items: [
      '(๑˃̵ᴗ˂̵)و',
      '(≧▽≦)',
      '(๑>؂<๑)',
      'ヽ(•̀ω•́ )ゝ',
      '(ﾉ◕ヮ◕)ﾉ*:･ﾟ✧',
      'ヽ(✿ﾟ▽ﾟ)ノ',
      '(☆▽☆)',
      '(๑˘ ˘๑)',
      '(*´▽`*)',
      '(๑>ᴗ<๑)'
    ]
  },
  {
    key: '得意',
    aliases: ['得意', '骄傲', '炫耀', '厉害', '牛', '拿捏', '小意思', '自信', '赢了'],
    items: [
      '(￣▽￣)~*',
      'ヾ(≧▽≦*)o',
      '(๑•̀ㅂ•́)و✧',
      '(☞ﾟ∀ﾟ)☞',
      'ᕦ(ò_óˇ)ᕤ',
      'ヽ(°〇°)ﾉ',
      '(๑•̀ㅁ•́๑)✧',
      '(⌐■_■)',
      'ᕦ(•̀∀•́)ᕤ'
    ]
  },
  {
    key: '委屈',
    aliases: ['委屈', '难过', '伤心', '哭', '泪', '呜呜', '可怜', '惨', '难受', 'emo', '想哭'],
    items: [
      '(｡•́︿•̀｡)',
      '(╥﹏╥)',
      '(ಥ_ಥ)',
      '(｡í _ ì｡)',
      '(｡╯︵╰｡)',
      '(ノ﹏ヽ)',
      '(μ_μ)',
      '(个_个)',
      '(´；ω；`)',
      '(っ﹏-)'
    ]
  },
  {
    key: '无语',
    aliases: ['无语', '无奈', '算了', '服了', '麻了', '离谱', '吐槽', '扶额', '摊手'],
    items: [
      '(￣_￣|||)',
      '╮(╯▽╰)╭',
      '(；￣Д￣)',
      '(・_・;)',
      '┑(￣Д￣)┍',
      '(￣ー￣)',
      '(¯_¯٥)',
      '(-_-;)',
      '(￣ω￣;)',
      '(￢_￢)'
    ]
  },
  {
    key: '生气',
    aliases: ['生气', '怒', '恼', '炸', '暴躁', '不爽', '气愤', '抗议', '掀桌'],
    items: [
      '(╯°□°）╯︵ ┻━┻',
      '(｀皿´＃)',
      '(╬ Ò﹏Ó)',
      'ヽ(ˋДˊ)ノ',
      '(#ﾟДﾟ)',
      '(๑•̀д•́๑)',
      '凸(￣ヘ￣)',
      '(ノಠ益ಠ)ノ彡┻━┻',
      '(╯‵□′)╯︵┻━┻'
    ]
  },
  {
    key: '疑惑',
    aliases: ['疑惑', '问号', '不懂', '懵', '迷惑', '奇怪', '不解', '啥', '为什么'],
    items: [
      '(・∀・)?',
      '( •_•)?',
      '(○´･д･)ﾉ',
      '(￣～￣;)',
      '(・・?)',
      '(゜-゜)',
      '(´･ω･`)?',
      '┐(￣ヘ￣)┌',
      '(๑•̌.•̑๑)ˀ̣ˀ̣',
      '(°ー°〃)'
    ]
  },
  {
    key: '害羞',
    aliases: ['害羞', '脸红', '不好意思', '羞', '腼腆', '紧张'],
    items: [
      '(⁄ ⁄•⁄ω⁄•⁄ ⁄)',
      '(*/ω＼*)',
      '(〃▽〃)',
      '(๑//́▽//̀๑)',
      '(´,,•ω•,,)♡',
      '(灬º‿º灬)',
      '(⁄˘⁄ ⁄ω⁄ ⁄˘⁄)',
      '(๑•́ ₃ •̀๑)'
    ]
  },
  {
    key: '加油',
    aliases: ['加油', '鼓励', '努力', '冲', '打气', '支持', '坚持', '干'],
    items: [
      '٩(๑•̀ω•́๑)۶',
      '٩(ˊᗜˋ*)و',
      '(ง •̀_•́)ง',
      '(*ﾟ▽ﾟ)ﾉ',
      'ᕙ(⇀‸↼‶)ᕗ',
      '(๑و•̀ω•́)و',
      '٩(๑❛ᴗ❛๑)۶',
      '(ง •̀ω•́)ง'
    ]
  },
  {
    key: '卖萌',
    aliases: ['卖萌', '可爱', '贴贴', '求', '撒娇', '抱', '萌'],
    items: [
      '(๑´ㅂ`๑)',
      '(人 •͈ᴗ•͈)',
      '(づ｡◕‿‿◕｡)づ',
      'ฅ( ̳• ◡ • ̳)ฅ',
      '(っ˘ω˘ς)',
      '(๑¯ω¯๑)',
      '(人´ω`)',
      '(๑>◡<๑)'
    ]
  },
  {
    key: '累',
    aliases: ['累', '困', '摸鱼', '躺平', '摆烂', '睡', '下班', '疲惫', '没力气'],
    items: [
      '(´-ω-`)',
      '(￣o￣) . z Z',
      '(っ- ‸ - ς)',
      '(´△｀)…',
      '(－_－) zzZ',
      '(=_=)',
      '(´～`)',
      '(›´ω`‹ )'
    ]
  },
  {
    key: '惊讶',
    aliases: ['惊讶', '震惊', '不敢信', '卧槽', '天', '哇', '吓'],
    items: [
      '(⊙_⊙)',
      'Σ(°△°|||)︴',
      '(○o○)',
      '(ﾟДﾟ;)',
      '(°ロ°) !',
      '(๑°ㅁ°๑)‼',
      '(☉_☉)',
      '(；ﾟДﾟ)'
    ]
  },
  {
    key: '无奈',
    aliases: ['无奈', '叹气', '唉', '没辙', '认命', '心累', '好吧'],
    items: [
      '(ーー;)',
      '(´･_･`)',
      '(￣ε￣)',
      '(ヽ´ω`)',
      '(＿ ＿*)',
      '(´-﹏-`；)',
      '( ˘･з･)',
      '(´。＿。`)'
    ]
  },
  {
    key: '赞同',
    aliases: ['赞同', '同意', '点赞', '好', '可以', '行', '赞', 'ok', '好的'],
    items: [
      'd(๑•̀ㅂ•́)d',
      '(ゝ∀･)b',
      '(・∀・)b',
      '(*´∀`)b',
      '(๑˃ᴗ˂)ﻭ',
      '(￣▽￣)b'
    ]
  },
  {
    key: '道歉',
    aliases: ['道歉', '对不起', '抱歉', '错了', '认错', '求饶', '原谅'],
    items: [
      'm( _ _ )m',
      '(シ_ _)シ',
      '(＿ ＿*)ゞ',
      '(人´∀｀).☆.。.:*',
      '(っ´ω`)ﾉ',
      '(m´･ω･`)m'
    ]
  },
  {
    key: '喜欢',
    aliases: ['喜欢', '爱', '比心', '心动', '亲', '么么', '爱你'],
    items: [
      '(｡♥‿♥｡)',
      '(♡˙︶˙♡)',
      '(づ￣3￣)づ╭❤～',
      '(๑˘ ³˘)♡',
      '(´｡• ᵕ •｡`)♡',
      '(灬♥ω♥灬)'
    ]
  },
  {
    key: '招呼',
    aliases: ['你好', '招呼', '在吗', '哈喽', '拜拜', '再见', '晚安', '早'],
    items: [
      '(｡･ω･｡)ﾉ',
      'ヾ(＾∇＾)',
      '(・ω・)ノ',
      '(￣▽￣)ノ',
      '(´▽`ʃ♡ƪ)',
      '(ノ・∀・)ノ',
      '(´･ω･`)ﾉ'
    ]
  }
];

let cfg = () => ({ ...DEFAULTS });
let log = () => {};
let warn = () => {};

// ─────────────────────────────────────────────── 索引（一次性展开 + 全局去重）
/** 扁平索引：[{ text, group }]。同一串出现在多个分组时只保留第一次。 */
const ITEMS = (() => {
  const seen = new Set();
  const out = [];
  for (const g of GROUPS) {
    for (const text of g.items) {
      if (!text || seen.has(text)) continue;
      seen.add(text);
      out.push({ text, group: g.key });
    }
  }
  return out;
})();

const GROUP_NAMES = GROUPS.map((g) => g.key);

// ─────────────────────────────────────────────── 小工具
function clean(s, max = 200) {
  return String(s ?? '').replace(/\s+/g, ' ').trim().slice(0, max);
}

function clamp(n, lo, hi) {
  const v = Number(n);
  if (!Number.isFinite(v)) return lo;
  return Math.max(lo, Math.min(hi, Math.round(v)));
}

function shuffle(arr) {
  const a = arr.slice();
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

/** 把「难过」「emo」这类说法映射到实际分组（同义扩展，避免"明明有却说没有"）。 */
function resolveGroups(mood) {
  const q = clean(mood, 20).toLowerCase();
  if (!q) return [];
  return GROUPS.filter((g) => {
    if (g.key === q) return true;
    if (g.key.includes(q) || q.includes(g.key)) return true;
    return g.aliases.some((a) => {
      const t = String(a).toLowerCase();
      return t === q || q.includes(t) || (q.length >= 2 && t.includes(q));
    });
  });
}

// ─────────────────────────────────────────────── 同会话去重（只放内存）
/** chatKey -> 最近用过的颜文字（新→旧） */
const used = new Map();
const USED_CAP = 40;
const CHAT_CAP = 300;

function usedOf(chatKey) {
  return used.get(String(chatKey || '')) || [];
}

function remember(chatKey, texts) {
  const k = String(chatKey || '');
  if (!k || !texts.length) return;
  const next = [...texts, ...usedOf(k)].slice(0, USED_CAP);
  used.set(k, next);
  // 会话数量兜底：Map 不会自己回收，多群长期运行要有个上限
  if (used.size > CHAT_CAP) {
    const oldest = used.keys().next().value;
    if (oldest !== undefined) used.delete(oldest);
  }
}

// ─────────────────────────────────────────────── 选词
/**
 * 挑 count 个候选：同会话没发过的优先，不够才允许重复。
 * @returns {{items: Array, matched: string[], unknown: boolean}}
 */
function pickCandidates({ mood, count, chatKey }) {
  const matchedGroups = resolveGroups(mood);
  const pool = matchedGroups.length
    ? ITEMS.filter((it) => matchedGroups.some((g) => g.key === it.group))
    : ITEMS;

  const avoid = cfg().avoidRepeat !== false;
  const recent = new Set(avoid ? usedOf(chatKey) : []);
  const fresh = pool.filter((it) => !recent.has(it.text));

  const chosen = shuffle(fresh).slice(0, count);
  if (chosen.length < count) {
    const taken = new Set(chosen.map((c) => c.text));
    const fill = shuffle(pool.filter((it) => !taken.has(it.text))).slice(0, count - chosen.length);
    chosen.push(...fill);
  }

  return {
    items: chosen,
    matched: matchedGroups.map((g) => g.key),
    unknown: Boolean(clean(mood, 20)) && matchedGroups.length === 0
  };
}

// ─────────────────────────────────────────────── 工具实现
function doFind(ctx, args) {
  const conf = cfg();
  const mood = clean(args?.mood ?? args?.tone ?? args?.emotion ?? '', 20);
  const count = clamp(args?.count ?? 2, 1, 3);
  const chatKey = ctx?.chatKey || '';

  const { items, matched, unknown } = pickCandidates({ mood, count, chatKey });

  if (!items.length) {
    // 正常不可能走到这里（库是写死的），真走到说明代码被改坏了
    return { content: '颜文字库这会儿是空的，这次就先不带颜文字了，正常回复即可。', isError: true };
  }

  const maxPer = clamp(conf.maxPerMessage ?? DEFAULTS.maxPerMessage, 1, 3);
  const lines = [];

  if (unknown) {
    lines.push(`库里没有「${mood}」这个语气分组，下面是从全部颜文字里随机挑的（别硬安上这个语气用）：`);
  } else if (matched.length) {
    lines.push(`按「${matched.join(' / ')}」挑了 ${items.length} 个：`);
  } else {
    lines.push(`没指定语气，随机挑了 ${items.length} 个（挑一个最贴你这句的用）：`);
  }

  items.forEach((it, i) => {
    lines.push(`  ${i + 1}. ${it.text}　（${it.group}）`);
  });

  lines.push('');
  lines.push(`用法：把其中**一个**直接写进你这句话的尾巴上（单条回复最多 ${maxPer} 个），顺着这个语气说话。`);
  lines.push('不要在回复里罗列这些候选、不要解释颜文字是什么意思、不要说“我给你挑了”。颜文字是嵌在话里的，不是单独发一条消息。');
  lines.push(`如果这里没有合适的，可以换个 mood 再调一次；可用语气：${GROUP_NAMES.join('、')}。`);

  // 记进去重表：下次同一会话尽量不重复（选哪个是模型决定的，这里只能先按"给过的"记）
  remember(chatKey, items.map((it) => it.text));

  log(`给出 ${items.length} 个候选（${matched.join('/') || '随机'}）→ ${chatKey || '未知会话'}`);
  return { content: lines.join('\n') };
}

// ─────────────────────────────────────────────── 提示词（动态部分：反映当前设置）
export function promptSections() {
  try {
    const conf = cfg();
    const density = DENSITY_LABEL[conf.density] || DENSITY_LABEL.normal;
    const maxPer = clamp(conf.maxPerMessage ?? DEFAULTS.maxPerMessage, 1, 3);
    return [{
      id: `${SKILL_ID}-live`,
      title: '颜文字（当前设置）',
      priority: 45,
      content: [
        `当前频率：${density}；单条回复最多 ${maxPer} 个颜文字。`,
        conf.avoidRepeat === false
          ? '同一会话里重复用到同一个没关系。'
          : '同一个会话里尽量别连着用同一个。'
      ].join('\n')
    }];
  } catch (e) {
    warn(`生成颜文字提示失败：${e?.message ?? e}`);
    return [];
  }
}

// ─────────────────────────────────────────────── 入口
export function setup(api) {
  cfg = typeof api?.config === 'function' ? api.config : () => ({ ...DEFAULTS });
  log = api?.log || (() => {});
  warn = api?.warn || (() => {});

  const conf = cfg();
  log(`颜文字已加载：${ITEMS.length} 个 / ${GROUPS.length} 种语气；频率 ${conf.density || DEFAULTS.density}，单条最多 ${clamp(conf.maxPerMessage ?? 1, 1, 3)} 个`);

  // 工具必须在 setup 执行期间注册（加载器只认这个时机）
  api.registerTool({
    id: 'find',
    name: '找颜文字',
    description:
      '从内置颜文字库里取 1~3 个贴当下语气的颜文字，用来嵌进你自己的回复里（不是单独发一条消息）。'
      + '什么时候用：① 你这句话有明显情绪、想顺手带一个时；② 群友点名要某种情绪的颜文字（「来个委屈的」「发个开心的颜文字」）。'
      + 'mood 填语气词，例如 开心/得意/委屈/无语/生气/疑惑/害羞/加油/卖萌/累/惊讶/无奈/赞同/道歉/喜欢/招呼；不填就随机给几个不同语气的。'
      + '不要自己现拼颜文字 —— 现拼的经常缺半边括号，发出去像乱码。'
      + '正经问事、要数据、报错求助时不要为了配而配，不带完全正常。',
    category: 'sticker',
    icon: '🎭',
    parameters: {
      type: 'object',
      properties: {
        mood: {
          type: 'string',
          description: '想要的语气，例如「委屈」「无语」「开心」「炸毛」。不填则从全部语气里随机挑。'
        },
        count: {
          type: 'integer',
          description: '要几个候选，1~3，默认 2。候选是给你挑的，最终只用其中一个。'
        }
      }
    },
    async execute(ctx, args) {
      try {
        return doFind(ctx, args);
      } catch (error) {
        // 失败也返回人话，不让异常冒泡成通用错误
        return { content: `取颜文字失败：${error?.message ?? error}。这次就不带颜文字了，正常回复即可。`, isError: true };
      }
    }
  });
}

/** 自检：库里必须有东西；纯内存实现，不依赖任何 Key / 网络 / 二进制。同步返回。 */
export function available() {
  return ITEMS.length > 0 ? true : { ok: false, reason: '颜文字库是空的' };
}

/** 卸载 / 热重载时清掉内存去重表。 */
export function dispose() {
  used.clear();
}
