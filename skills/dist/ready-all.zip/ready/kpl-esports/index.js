// 王者荣耀赛事（KPL）查询技能（LLM 型）
//
// 为什么是技能（skills/）而不是插件（plugins/）：
//   「群友问 KPL」没有能写死的触发条件 —— 要靠模型听懂自然语言
//   （"今晚有比赛吗" / "狼队首发给谁" / "梦岚去哪队了" / "最近有啥乐子"），
//   再决定查哪一类、怎么组织回答。这是 LLM 型，走 registerTool + 提示词片段。
//
// ── 以下每一条都是 2026-10-07 实抓实测的结果，不是推测 ────────────────
//
// ① 官方赛事站抓不到内容（所以"摘要优先 + 可用性判定"）：
//      · kpl.qq.com        → 前端渲染 SPA，直抓仅 ~2.4KB JS 外壳，正文 0 条赛程
//      · pvp.qq.com/matchdata/ → 服务端有 HTML，但数据靠 AJAX 拉，直抓是模板占位
//                              （会看到"抱歉，暂无该类数据"）
//    ⇒ 把"抓到空壳"和"真的没内容"混为一谈就会答错。因此每页都返回
//      usable / textLength，摘要（snippet）才是主力信息源。
//    ⇒ 已知是空壳的门户域名直接不抓（省时间），并在 note 里说明。
//
// ② 检索词**语序**决定成败（所以一律以 KPL 开头）：
//      · 「重庆狼队 KPL 首发 阵容」→ 返回重庆市百度百科、重庆旅游攻略（串到城市）
//      · 「2026 KPL 转会期 …」    → 返回「2026年_百度百科」（串到年份）
//      · 「KPL 首发 阵容 重庆狼队」→ 才是赛事结果
//    ⇒ 检索词永远以 KPL 起头；年份只在用户显式填了赛季提示时**追加在末尾**。
//
// ③ 宽泛查询会掉进"门户导航结果"陷阱（所以加一个 site: 变体）：
//      「KPL 赛程 对阵 比赛时间」每次几乎都只返回 kpl.qq.com / pvp.qq.com /
//      bilibili直播 / 虎牙 这四五个门户首页 —— 那是实体导航，不是答案。
//      而「site:weibo.com KPL 赛程」能直接捞到 KPL 官微发布的赛程与赛事日历；
//      「site:… 阵容」能捞到第三方 KPL 数据站与知乎讨论。
//    ⇒ 每个主题都配一条 site: 限定变体来提高命中真实内容的概率。
//
// ── 与核心的耦合 ────────────────────────────────────────────────────
//   优先复用核心 src/web-search.js（含管理员选的搜索服务）与 src/safe-fetch.js
//   （SSRF 全防护 + 逐跳重定向校验 + 浏览锁定）。两处都用**动态 import + 降级**：
//   核心模块路径若在将来升级中变了，技能本身仍能正常加载，只在调用时退回内置实现并告警。
//   ⚠️ 浏览锁定必须尊重 —— 核心 web_fetch 曾因漏传 browseLocked 让白名单形同虚设，
//      本技能显式读取 browseLockState().enabled 传下去。

import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

// ⚠️ 以模块自身位置为锚点：skills/kpl-esports/index.js → ../.. = resources/app
const HERE = path.dirname(fileURLToPath(import.meta.url));
const APP_ROOT = path.resolve(HERE, '..', '..');
const CORE_DIR = path.join(APP_ROOT, 'src');

const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36';

/** 实测抓不到内容（前端渲染 / AJAX 占位）的门户域名：不浪费时间抓，只在摘要里用。 */
const PORTAL_HOSTS = [
  'kpl.qq.com', 'pvp.qq.com', 'live.bilibili.com', 'huya.com',
  'douyu.com', 'egame.qq.com', 'www.qq.com', 'game.qq.com'
];

const TOPIC_LABELS = {
  schedule: '赛程与比赛时间',
  team: '战队与战队名单',
  roster: '首发与替补阵容',
  transfer: '选手转会与变动',
  player: '选手所属战队',
  trivia: '趣事与名场面',
  general: '综合'
};

/** 正文短于此长度基本就是 SPA 空壳或模板占位页。 */
const USABLE_TEXT_MIN = 400;

/** 同一轮内两条检索之间留的间隔：连续快速打搜索引擎会被降级成门户导航结果。 */
const SEARCH_GAP_MS = 700;

let cfg = () => ({});
let api = null;
let core = null;
let coreErr = '';

function ok(payload) { return { content: JSON.stringify(payload, null, 1) }; }
function err(message) { return { content: String(message), isError: true }; }

function clamp(n, lo, hi) {
  const v = Number(n);
  if (!Number.isFinite(v)) return lo;
  return Math.max(lo, Math.min(hi, Math.round(v)));
}

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

function hostOf(url) {
  try { return new URL(String(url)).hostname.toLowerCase(); } catch { return ''; }
}

function isPortalHost(host) {
  const h = String(host || '').toLowerCase();
  return PORTAL_HOSTS.some((p) => h === p || h.endsWith(`.${p}`));
}

/** HTML 实体解码（含数字实体）。Bing 摘要里满是 &ensp; / &#0183; 这类残留。 */
function decodeEntities(s) {
  return String(s ?? '')
    .replace(/&#x([0-9a-f]+);/gi, (_m, h) => { try { return String.fromCodePoint(parseInt(h, 16)); } catch { return ''; } })
    .replace(/&#(\d+);/g, (_m, d) => { try { return String.fromCodePoint(parseInt(d, 10)); } catch { return ''; } })
    .replace(/&nbsp;|&ensp;|&emsp;|&thinsp;|&zwnj;|&zwj;/g, ' ')
    .replace(/&mdash;/g, '—').replace(/&ndash;/g, '–').replace(/&hellip;/g, '…')
    .replace(/&quot;/g, '"').replace(/&apos;|&#39;/g, "'")
    .replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&amp;/g, '&');
}

/** 去标签 + 解实体 + 压空白，用于标题/摘要这类短文本。 */
function plain(html) {
  const noTags = String(html ?? '').replace(/<[^>]*>/g, ' ');
  return decodeEntities(noTags).replace(/\s+/g, ' ').trim();
}

/** 正文提炼（核心 extractPageDigest 不可用时的降级实现）。 */
function stripTags(html, maxChars) {
  const cleaned = String(html ?? '')
    .replace(/<script[\s\S]*?<\/script>/gi, ' ')
    .replace(/<style[\s\S]*?<\/style>/gi, ' ')
    .replace(/<noscript[\s\S]*?<\/noscript>/gi, ' ')
    .replace(/<!--[\s\S]*?-->/g, ' ');
  const text = plain(cleaned.replace(/<[^>]*>/g, ' '));
  const cap = Math.max(200, Number(maxChars) || 2000);
  return text.length > cap ? `${text.slice(0, cap)}…（已截断）` : text;
}

/** 降级路径下的简易内网拦截（核心 safeFetch 不在时兜底）。 */
function isPrivateHost(raw) {
  const h = hostOf(raw);
  if (!h) return true;
  if (h === 'localhost' || h.endsWith('.localhost') || h.endsWith('.local')) return true;
  if (h === '::1' || h === '[::1]') return true;
  if (/^\d{1,3}(\.\d{1,3}){3}$/.test(h)) {
    const p = h.split('.').map(Number);
    if (p.some((x) => !Number.isFinite(x) || x < 0 || x > 255)) return true;
    if (p[0] === 0 || p[0] === 10 || p[0] === 127 || p[0] >= 224) return true;
    if (p[0] === 192 && p[1] === 168) return true;
    if (p[0] === 172 && p[1] >= 16 && p[1] <= 31) return true;
    if (p[0] === 169 && p[1] === 254) return true;
  }
  return false;
}

// ── 核心模块（可选依赖，动态加载 + 缓存）──────────────────────────────

async function loadCore() {
  if (core) return core;
  if (coreErr) return null;
  try {
    const ws = await import(pathToFileURL(path.join(CORE_DIR, 'web-search.js')).href);
    const sf = await import(pathToFileURL(path.join(CORE_DIR, 'safe-fetch.js')).href);
    core = {
      webSearch: ws.webSearch,
      bingSearch: ws.bingSearch,
      extractPageDigest: ws.extractPageDigest,
      safeFetch: sf.safeFetch,
      browseLockState: sf.browseLockState
    };
    return core;
  } catch (error) {
    coreErr = String(error?.message ?? error);
    api?.warn?.(`核心联网模块不可用，已切到内置降级实现：${coreErr}`);
    return null;
  }
}

// ── 检索 ────────────────────────────────────────────────────────────

/** 无核心模块时的 Bing HTML 检索（与核心 parseBingResults 同口径）。 */
async function fallbackSearch(query) {
  const url = `https://cn.bing.com/search?q=${encodeURIComponent(query)}`;
  const res = await api.fetch(url, {
    headers: { 'user-agent': UA, 'accept-language': 'zh-CN,zh;q=0.9' },
    signal: AbortSignal.timeout(15000)
  });
  if (!res.ok) throw new Error(`搜索服务 HTTP ${res.status}`);
  const html = await res.text();
  const results = [];
  for (const block of String(html).split('<li class="b_algo"').slice(1)) {
    const href = block.match(/<a[^>]+href="(https?:\/\/[^"]+)"/i);
    if (!href) continue;
    const titleM = block.match(/<h2[^>]*>([\s\S]*?)<\/h2>/i);
    const snipM = block.match(/<p[^>]*>([\s\S]*?)<\/p>/i);
    const title = plain(titleM ? titleM[1] : '');
    if (!title) continue;
    results.push({ title, url: href[1], snippet: plain(snipM ? snipM[1] : '') });
    if (results.length >= 10) break;
  }
  if (!results.length) throw new Error('搜索没有解析到结果（引擎页面结构可能已改版）');
  return { query, results };
}

/** 单次检索：核心统一入口 → 核心 Bing → 内置实现，逐级降级。 */
async function searchOne(query) {
  const c = await loadCore();
  if (c) {
    try {
      const r = await c.webSearch(query);
      return { results: Array.isArray(r?.results) ? r.results : [], via: 'core' };
    } catch (primary) {
      try {
        const r = await c.bingSearch(query);
        return { results: Array.isArray(r?.results) ? r.results : [], via: 'core-bing' };
      } catch (secondary) {
        throw new Error(`${String(primary?.message ?? primary)}；Bing 兜底也失败：${String(secondary?.message ?? secondary)}`);
      }
    }
  }
  const r = await fallbackSearch(query);
  return { results: r.results, via: 'fallback' };
}

/** 抓一页正文。核心 safeFetch 走 SSRF 全防护 + 浏览锁定；降级走 api.fetch + 简易拦截。 */
async function fetchOne(url, cap) {
  const c = await loadCore();
  if (c) {
    const locked = Boolean(c.browseLockState?.()?.enabled);
    const r = await c.safeFetch(url, { browseLocked: locked });
    const html = String(r?.body ?? '');
    const text = c.extractPageDigest
      ? String(c.extractPageDigest(html, '', { maxChars: cap, maxLinks: 0 })?.text ?? '')
      : stripTags(html, cap);
    return { url: String(r?.url || url), statusCode: Number(r?.statusCode) || 0, text, locked };
  }
  if (isPrivateHost(url)) throw new Error('拒绝访问内网/本机地址');
  const res = await api.fetch(url, {
    headers: { 'user-agent': UA, 'accept-language': 'zh-CN,zh;q=0.9' },
    signal: AbortSignal.timeout(20000)
  });
  const html = await res.text();
  return { url, statusCode: res.status, text: stripTags(html, cap), locked: false };
}

// ── 检索词构造 ──────────────────────────────────────────────────────
// ⚠️ 铁律：一律以 KPL 开头。实测把「重庆狼队」「2026」放开头会串到城市/年份词条。

/** 只有用户显式填了赛季提示才追加在**末尾**（放开头会把查询带偏）。 */
function seasonSuffix() {
  const hint = String(cfg().seasonHint ?? '').trim();
  return hint ? ` ${hint}` : '';
}

function buildQueries(topic, keyword) {
  const k = String(keyword ?? '').trim();
  const s = seasonSuffix();
  const withK = (base) => `${base}${k ? ` ${k}` : ''}${s}`;
  switch (topic) {
    case 'schedule':
      return [withK('KPL 赛程 对阵 比赛时间'), `site:weibo.com KPL 赛程${k ? ` ${k}` : ''}`];
    case 'team':
      return [withK('KPL 战队 队员 名单'), withK('KPL 战队 大名单')];
    case 'roster':
      return [withK('KPL 首发 名单 阵容'), `site:weibo.com KPL 首发名单${k ? ` ${k}` : ''}`];
    case 'transfer':
      return [withK('KPL 转会 官宣 选手'), `site:weibo.com KPL 转会${k ? ` ${k}` : ''}`];
    case 'player':
      return [withK('KPL 选手 所属战队'), withK('KPL 选手 战队 阵容')];
    case 'trivia':
      return [withK('KPL 趣事 名场面'), withK('KPL 选手 采访 花絮')];
    default:
      return [withK('KPL'), withK('KPL 王者荣耀职业联赛')];
  }
}

/** 判定一条结果是否"真的带了这一类的具体信息"（而不是门户导航）。 */
function isSpecific(item, topic, keyword) {
  const hay = `${item.title} ${item.snippet}`;
  if (keyword && hay.includes(keyword)) return true;
  if (isPortalHost(item.host)) return false;
  const signals = {
    schedule: /赛程|对阵|比赛时间|赛事日历|:\s*\d|vs|BO\d/i,
    team: /战队|队员|名单|大名单|阵容|选手/,
    roster: /首发|替补|阵容|大名单|名单/,
    transfer: /转会|加盟|离队|官宣|挂牌|签约/,
    player: /战队|选手|所属|加盟|转会/,
    trivia: /趣事|名场面|采访|花絮|搞笑|梗/,
    general: /KPL|王者荣耀/i
  };
  return (signals[topic] || signals.general).test(hay);
}

/** 去重 + 排序：门户导航降权，具体内容与关键词命中加权。 */
function rankResults(items, topic, keyword, preferDomains) {
  const preferred = preferDomains.map((s) => String(s).toLowerCase()).filter(Boolean);
  const seen = new Set();
  const out = [];
  for (const it of items || []) {
    const url = String(it?.url ?? '').trim();
    if (!/^https?:\/\//i.test(url)) continue;
    const key = url.split('#')[0];
    if (seen.has(key)) continue;
    seen.add(key);
    const host = hostOf(url);
    const title = plain(it?.title ?? '') || String(it?.title ?? '').trim();
    const snippet = plain(it?.snippet ?? '') || String(it?.snippet ?? '').trim();
    const item = { title, url, snippet, host };
    const hay = `${title} ${snippet}`;
    let score = 0;
    if (isPortalHost(host)) score -= 3;                                   // 门户导航结果降权
    if (preferred.some((d) => host.includes(d))) score += 1;              // 优先域名轻微加权
    if (keyword && hay.includes(keyword)) score += 3;                     // 命中关键词
    if (isSpecific(item, topic, keyword)) score += 2;                     // 带本主题具体信息
    if (/kpl|王者荣耀/i.test(hay)) score += 1;
    out.push({ ...item, score, specific: isSpecific(item, topic, keyword) });
  }
  out.sort((a, b) => b.score - a.score);
  return out;
}

// ── 工具 1：KPL 查询 ────────────────────────────────────────────────

function toolQuery() {
  return {
    id: 'kpl_query',
    name: 'KPL 赛事查询',
    description: '查王者荣耀职业联赛（KPL）信息：赛程与比赛时间、战队、首发与替补阵容、选手转会变动、某选手现在在哪支队、圈内趣事。会联网检索并返回搜索结果（含摘要）与页面正文提炼；还给出 searchQuality 与每页 usable/textLength，用来判断「真拿到具体信息」还是「只拿到门户首页/前端渲染的空壳」。群友问 KPL 相关问题时用它，不要凭记忆作答。',
    category: 'web',
    icon: '🏆',
    requiresSearch: true,
    parameters: {
      type: 'object',
      properties: {
        topic: {
          type: 'string',
          enum: ['schedule', 'team', 'roster', 'transfer', 'player', 'trivia', 'general'],
          description: '查询类型。schedule=赛程/比赛时间/结果；team=战队及战队名单；roster=首发与替补阵容；transfer=选手转会/变动；player=某选手现在在哪支队；trivia=趣事/名场面；general=不确定时用。'
        },
        keyword: {
          type: 'string',
          description: '具体对象：战队名（如 重庆狼队、成都AG超玩会）、选手赛场ID（如一诺、梦岚、花海）、赛季（如 2026年度总决赛）。可留空；留空则查该主题的整体情况。'
        },
        maxPages: {
          type: 'integer',
          description: '额外抓取正文的页数，0~4。不填则用技能设置里的值。摘要通常已够用，不必调大。'
        }
      },
      required: ['topic']
    },
    async execute(ctx, args) {
      try {
        const topic = TOPIC_LABELS[String(args?.topic)] ? String(args.topic) : 'general';
        const keyword = String(args?.keyword ?? '').trim();
        const c = cfg();
        const maxResults = clamp(Number(c.maxResults) || 8, 4, 10);
        const maxPages = args?.maxPages === undefined
          ? clamp(Number(c.maxPages ?? 2), 0, 4)
          : clamp(Number(args.maxPages) || 0, 0, 4);
        const pageChars = Math.max(500, Number(c.pageChars) || 2000);
        const preferDomains = String(c.preferDomains ?? '').split(/[,\s]+/).map((s) => s.trim()).filter(Boolean);
        const queries = buildQueries(topic, keyword);

        api?.log?.(`KPL 查询：topic=${topic} keyword=${keyword || '(无)'} 会话=${ctx?.chatKey ?? '-'}`);

        // ── 检索（逐条串行 + 间隔，避免连续快速请求被搜索引擎降级）──
        const errors = [];
        const pool = [];
        for (let i = 0; i < queries.length; i++) {
          if (i > 0) await sleep(SEARCH_GAP_MS);
          try {
            const r = await searchOne(queries[i]);
            pool.push(...r.results);
          } catch (error) {
            errors.push(`「${queries[i]}」：${String(error?.message ?? error)}`);
          }
        }

        const ranked = rankResults(pool, topic, keyword, preferDomains);
        const picked = ranked.slice(0, maxResults);
        const results = picked.map((r) => ({
          title: r.title, url: r.url, snippet: r.snippet, host: r.host,
          specific: r.specific,
          portal: isPortalHost(r.host) ? '门户/导航页，通常抓不到正文' : ''
        }));

        // ── 抓正文：跳过实测为空壳的门户页 ──
        const targets = picked.filter((r) => !isPortalHost(r.host)).slice(0, maxPages);
        const skippedPortal = picked.length - picked.filter((r) => !isPortalHost(r.host)).length;
        const pages = [];
        for (const r of targets) {
          try {
            const f = await fetchOne(r.url, pageChars);
            const text = String(f.text ?? '');
            const usable = text.length >= USABLE_TEXT_MIN;
            pages.push({
              url: f.url, host: r.host, statusCode: f.statusCode,
              textLength: text.length, usable, text,
              note: usable
                ? ''
                : '正文极短：该页多半是前端渲染(SPA)或数据由 JS/AJAX 拉取，抓不到真实内容 —— 这不代表「没有比赛」，请改用 results[].snippet。'
            });
          } catch (error) {
            pages.push({
              url: r.url, host: r.host, statusCode: 0, textLength: 0, usable: false, text: '',
              error: String(error?.message ?? error)
            });
          }
        }

        if (!results.length && !pages.length) {
          return err(
            `KPL 查询没拿到任何结果（topic=${topic}${keyword ? `，keyword=${keyword}` : ''}）。`
            + `${errors.length ? `失败原因：${errors.join('；')}。` : ''}`
            + '请改用内置 web_search 换关键词再试（把 KPL 放在最前面，例如「KPL 首发 名单」）；'
            + '仍查不到就如实告诉群友没查到，不要凭记忆编造赛程、阵容或转会。'
          );
        }

        // ── 检索质量判定：让模型知道"看到的是答案还是门户首页" ──
        const specificCount = picked.filter((r) => r.specific).length;
        const searchQuality = specificCount >= 2 ? 'good' : (specificCount === 1 ? 'partial' : 'poor');

        const notes = [];
        if (searchQuality === 'poor') {
          notes.push('本次只搜到门户/导航类结果，没有具体信息（官方赛事站是前端渲染，抓不到内容）。'
            + '可以再调一次本工具换个说法，或用内置 web_search 试「site:weibo.com KPL …」这类站点限定检索；'
            + '仍拿不到就如实说没查到，不要编造。');
        } else if (searchQuality === 'partial') {
          notes.push('只找到少量相关信息，作答时以能核对到的部分为准，不确定的直接说不确定。');
        }
        if (keyword && !picked.some((r) => `${r.title} ${r.snippet}`.includes(keyword))) {
          notes.push(`没有任何结果包含「${keyword}」，很可能没搜到它的具体信息 —— 不要据此编造该队/该选手的阵容或动向。`);
        }
        if (skippedPortal > 0) notes.push(`已跳过 ${skippedPortal} 个实测抓不到正文的门户页，只用它们的摘要。`);
        if (errors.length) notes.push(`部分检索失败：${errors.join('；')}`);
        notes.push('阵容/转会/赛程时效性极强：只用这里的结果与摘要作答，不要用记忆里的旧名单、旧战队归属；抓不到就如实说没查到。');

        return ok({
          topic, topicLabel: TOPIC_LABELS[topic], keyword,
          searchQuality,
          queries,
          resultCount: results.length,
          results,
          pages,
          errors,
          note: notes.join(' ')
        });
      } catch (error) {
        return err(`KPL 查询失败：${String(error?.message ?? error)}`);
      }
    }
  };
}

// ── 工具 2：权威信息源清单 ──────────────────────────────────────────
// 返回的是实测结论（不联网、不消耗额度），用来回答"该去哪看"以及
// "为什么搜到了链接却抓不到内容"——这两个问题靠搜索是答不好的。

const SOURCE_GUIDE = [
  {
    name: '王者荣耀职业联赛官网（KPL）',
    entry: 'https://kpl.qq.com/',
    schedulePage: 'https://kpl.qq.com/#/Schedule',
    fetchable: false,
    why: '实测 2026-10-07 直接抓只拿到约 2.4KB 的 JS 外壳，正文 0 条赛程 —— 前端渲染的 SPA。赛程/比分请依赖搜索摘要，或让能执行 JS 的浏览器打开。'
  },
  {
    name: '王者荣耀官网 · 赛事数据',
    entry: 'https://pvp.qq.com/matchdata/',
    fetchable: 'partial',
    why: '服务端有 HTML，但赛季/战队/选手数据由 AJAX 拉取，直抓多为模板占位（会看到「抱歉，暂无该类数据」）。可当入口，别当数据源。'
  },
  {
    name: 'KPL 官方微博',
    entry: 'https://weibo.com/',
    fetchable: 'partial',
    why: '实测「site:weibo.com KPL 赛程」能直接捞到官微发布的赛程与赛事日历、首发名单（这类内容官方倾向先发微博）。微博页面抓取需登录、不稳定，用搜索摘要最省事。'
  },
  {
    name: '腾讯新闻（KPL 相关报道）',
    entry: 'https://new.qq.com/',
    fetchable: true,
    why: '实测图文报道页可正常抓正文，适合赛事规划、转会官宣、赛后评论、选手采访这类内容。'
  }
];

const QUERY_TIPS = {
  schedule: '『KPL 赛程 对阵 比赛时间』；想更准就加站点限定：『site:weibo.com KPL 赛程』',
  team: '『KPL 战队 队员 名单』『KPL 战队 大名单』',
  roster: '『KPL 首发 名单 阵容』『site:weibo.com KPL 首发名单』',
  transfer: '『KPL 转会 官宣 选手』『site:weibo.com KPL 转会』',
  player: '『KPL 选手 所属战队』＋选手ID',
  trivia: '『KPL 趣事 名场面』『KPL 选手 采访 花絮』',
  any: '『KPL <关键词>』——KPL 一定要放最前面'
};

function toolSources() {
  return {
    id: 'kpl_sources',
    name: 'KPL 信息源清单',
    description: '返回 KPL 权威信息入口、每个入口「能不能直接抓正文」的实测结论，以及实测有效的检索词写法（含站点限定技巧）。当群友问「去哪看」、或 kpl_query 返回 searchQuality=poor、或你不确定某个官方站能不能抓时用它。本工具不联网，返回的是固定结论。',
    category: 'web',
    icon: '📚',
    requiresSearch: false,
    parameters: {
      type: 'object',
      properties: {
        topic: {
          type: 'string',
          enum: ['schedule', 'team', 'roster', 'transfer', 'trivia', 'any'],
          description: '想看哪一类问题的信息源与检索词，默认 any。'
        }
      }
    },
    async execute(ctx, args) {
      const topic = ['schedule', 'team', 'roster', 'transfer', 'trivia'].includes(String(args?.topic))
        ? String(args.topic)
        : 'any';
      return ok({
        topic,
        sources: SOURCE_GUIDE,
        queryTips: QUERY_TIPS[topic],
        searchRules: [
          '检索词一律以 KPL 开头。实测「重庆狼队 首发」会返回重庆旅游攻略、「2026 KPL 转会」会返回 2026年百度百科 —— 地名/年份放开头会把查询带偏。',
          '宽泛查询容易掉进「门户导航结果」：只返回 kpl.qq.com / pvp.qq.com / bilibili直播 / 虎牙 这几个首页，那不是答案。加 site: 限定（site:weibo.com、site:bbs.hupu.com）实测能显著提高命中真实内容的概率。',
          '官方赛事站是前端渲染，直接抓正文拿不到数据；优先读搜索摘要，再考虑第三方报道页。'
        ],
        note: '以上「能不能抓」结论来自 2026-10-07 实测；站点改版后可能变化，实际以 kpl-esports__kpl_query 返回的 usable / searchQuality 为准。'
      });
    }
  };
}

// ── 生命周期 ────────────────────────────────────────────────────────

export function setup(a) {
  api = a;
  cfg = a.config;

  a.registerTool(toolQuery());
  a.registerTool(toolSources());

  const c = cfg();
  a.log(`王者荣耀赛事查询已加载（候选 ${Number(c.maxResults) || 8} 条 / 抓正文 ${Number(c.maxPages ?? 2)} 页 / 赛季提示 ${String(c.seasonHint || '').trim() || '未设（不拼年份）'}）`);
}
