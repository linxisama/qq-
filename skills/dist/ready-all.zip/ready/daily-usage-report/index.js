// 用量日报：每天到设定时刻，把累计用量发到指定会话。
//
// ── 为什么用 after-tool 钩子，而不是定时器 ──────────────────────────────
// 技能在 setup/activate/钩子里**都拿不到 sender**（发送队列）：
//   · setup(api)           → api 里没有 sender（plugin-loader.js）
//   · activate(ctx)        → 无参调用（app.js）
//   · 钩子的 skillContext   → 只有 chatKey/kind/model 等（orchestrator.js）
//   · 只有**工具执行**时的 ctx 才带 sender
// 所以本技能挂在 after-tool 上：每次有工具调用（即每次有消息活动）时检查是否到点。
// 代价：设 00:00 时，报告会在"当天第一条消息到来时"发出，不是 00:00 整点。
// 好处：不改核心、装进 skills/ 就能用、报告走完整发送管道（限频/去重/留档）。
//
// ── 数据来源 ────────────────────────────────────────────────────────────
// 走应用自己的 HTTP 接口 GET /api/usage/stats?range=all（用量页用的同一份数据）。
// 本地调用实测 4.7KB / 24ms，远在钩子 5 秒超时之内。响应不含密钥。

import fs from 'node:fs';
import path from 'node:path';
import http from 'node:http';
import { fileURLToPath } from 'node:url';

const DEFAULT_PORT = 3210;
const PORT_SCAN = 10;            // 应用端口被占时会往上让位，扫描 3210..3219
const STATE_FILE = 'daily-usage-report.json';
const HTTP_TIMEOUT_MS = 3000;
const REPORT_TITLE = '用量日报';

let cfg = () => ({});
let sending = false;             // 重入保护：避免同一轮多个工具调用并发发送

export function setup(api) {
  cfg = api.config;
  api.log('用量日报已加载（每天到点后由消息活动触发发送）');

  api.registerTool({
    id: 'usage_report',
    name: '查询累计用量',
    description: '取机器人的真实用量数据：估算成本、调用次数、搜索次数、输入 token、缓存命中率，并按模型列出。'
      + '当用户问「用量」「花了多少钱」「今天用了多少 token」「调用了几次」「缓存命中率」时使用本工具，'
      + '不要凭印象估算。range 可选：all（默认，全部累计）/ today / 24h / 数字（最近 N 天）。',
    category: 'query',
    icon: '📊',
    parameters: {
      type: 'object',
      properties: {
        range: { type: 'string', description: '时间范围：all（全部，默认）/ today（今天）/ 24h（最近24小时）/ 数字如 7（最近7天）' }
      }
    },
    async execute(ctx, args) {
      const range = String(args?.range ?? 'all').trim() || 'all';
      let stats;
      try {
        stats = await fetchUsage(range);
      } catch (error) {
        return { content: '读用量数据失败：' + (error?.message ?? error), isError: true };
      }
      return { content: renderReport(stats) };
    }
  });
}

/**
 * 每天到点后的首次消息活动 → 发一次报告。
 * 用 after-tool（工具执行之后）：此时 ctx 带 sender，且本轮对话已有内容。
 */
export const hooks = {
  'after-tool': async (ctx) => {
    if (sending) return;                       // 并发保护
    const c = cfg();
    const now = Date.now();
    if (!shouldSendNow(c.sendTime, now)) return;

    const target = resolveTarget(c.targetChatKey, ctx);
    if (!target.ok) return;                    // 目标没配好或不在白名单 → 静默跳过

    sending = true;
    try {
      const stats = await fetchUsage('all');
      const text = renderReport(stats, { triggeredAt: now });
      await ctx.sender.sendTextBatch(target.chatKey, [text], { label: REPORT_TITLE });
      markSent(now);                           // 只有真发成功才记状态
    } catch {
      // 发送失败不写状态：下一条消息会再试一次，而不是整天不再尝试
    } finally {
      sending = false;
    }
  }
};

/** 没有定时器要清；钩子是每轮临时调用。 */
export function deactivate() { sending = false; }

// ══ 到点判断 ═══════════════════════════════════════════════════════════════

/** 是否该发：今天已过设定时刻，且今天还没发过。 */
function shouldSendNow(sendTime, now) {
  const hm = parseSendTime(sendTime);
  if (!hm) return false;
  const d = new Date(now);
  const todayAt = new Date(d);
  todayAt.setHours(hm.h, hm.m, 0, 0);
  if (now < todayAt.getTime()) return false;   // 今天还没到点
  const st = readState();
  const last = Number(st.lastSentAt) || 0;
  return last < todayAt.getTime();             // 今天这个时刻之后还没发过
}

/** 'HH:MM' → {h,m}；非法返回 null。 */
function parseSendTime(v) {
  const m = /^(\d{1,2}):(\d{2})$/.exec(String(v ?? '').trim());
  if (!m) return null;
  const h = Number(m[1]);
  const mi = Number(m[2]);
  if (h < 0 || h > 23 || mi < 0 || mi > 59) return null;
  return { h, m: mi };
}

// ══ 发送目标 ═══════════════════════════════════════════════════════════════

/**
 * 决定发到哪。留空 → 发到触发时所在会话（最稳，不需要用户知道群号）。
 * 配了目标 → 校验格式与白名单（与核心 send_to 同一口径）。
 */
function resolveTarget(configured, ctx) {
  const want = String(configured ?? '').trim();
  if (!want) {
    const cur = String(ctx?.chatKey ?? '');
    return /^(group|private):\d+$/.test(cur) ? { ok: true, chatKey: cur } : { ok: false };
  }
  if (!/^(group|private):\d+$/.test(want)) return { ok: false };

  const g = readGlobalConfig();
  if (!g) return { ok: false };                       // 读不到全局配置 → 不敢发
  if (g.tools?.crossChatSend !== true) return { ok: false };
  const parts = want.split(':');
  const kind = parts[0];
  const id = parts[1];
  const list = (kind === 'group' ? g.allow?.groups : g.allow?.private) || [];
  const allowedAll = list.length === 0 && g.allowAllWhenEmpty === true;
  if (!(list.map(String).includes(id) || allowedAll)) return { ok: false };
  return { ok: true, chatKey: want };
}

// ══ 取用量数据 ═════════════════════════════════════════════════════════════

/** 并行探端口，返回第一个能应答的端口。 */
async function detectPort() {
  const candidates = [];
  const pinned = Number(process.env.QQ_AGENT_PORT) || 0;
  if (pinned) candidates.push(pinned);
  for (let i = 0; i < PORT_SCAN; i++) candidates.push(DEFAULT_PORT + i);
  const probes = await Promise.all(candidates.map(async (p) => {
    try { await httpGetJson(p, '/api/usage/stats?range=all'); return p; } catch { return null; }
  }));
  return probes.find((p) => p != null) ?? null;
}

let cachedPort = null;

async function fetchUsage(range) {
  const q = '/api/usage/stats?range=' + encodeURIComponent(range);
  if (cachedPort != null) {
    try { return await httpGetJson(cachedPort, q); } catch { cachedPort = null; }
  }
  const port = await detectPort();
  if (port == null) {
    throw new Error('连不上 QQ Agent 的本地服务（尝试过 ' + DEFAULT_PORT + '-' + (DEFAULT_PORT + PORT_SCAN - 1) + '）');
  }
  cachedPort = port;
  return await httpGetJson(port, q);
}

function httpGetJson(port, urlPath) {
  return new Promise((resolve, reject) => {
    const req = http.get({ host: '127.0.0.1', port, path: urlPath, timeout: HTTP_TIMEOUT_MS }, (res) => {
      let d = '';
      res.setEncoding('utf8');
      res.on('data', (c) => { d += c; });
      res.on('end', () => {
        if (res.statusCode !== 200) return reject(new Error('HTTP ' + res.statusCode));
        try {
          const j = JSON.parse(d);
          if (!j || j.ok !== true) return reject(new Error('接口返回异常'));
          resolve(j);
        } catch (e) { reject(new Error('响应不是合法 JSON')); }
      });
    });
    req.on('timeout', () => req.destroy(new Error('请求超时')));
    req.on('error', reject);
  });
}

// ══ 渲染报告 ═══════════════════════════════════════════════════════════════
// ⚠️ 发送管道会做 mdToPlain 转换，所以这里刻意只用纯文本，不用任何 markdown 语法。

const money = (v) => '¥' + (Number(v) || 0).toFixed(4);
const pct = (v) => ((Number(v) || 0) * 100).toFixed(1) + '%';
const int = (v) => String(Math.round(Number(v) || 0));
const kTok = (v) => (Number(v) || 0).toLocaleString('en-US');

function renderReport(stats, opts) {
  const triggeredAt = (opts && opts.triggeredAt) || Date.now();
  const t = stats.totals || {};
  const models = Array.isArray(stats.models) ? stats.models : [];
  const days = Array.isArray(stats.days) ? stats.days : [];

  const todayKey = localDayKey(triggeredAt);
  const today = days.find((d) => d.day === todayKey) || null;

  const lines = [];
  lines.push('【' + REPORT_TITLE + '】截至 ' + formatTime(triggeredAt));
  lines.push('');
  lines.push('累计（' + (stats.rangeLabel || '全部') + '）');
  lines.push('· 估算成本：' + money(t.cost));
  lines.push('· 调用次数：' + int(t.runs) + ' 次');
  lines.push('· 搜索次数：' + int(stats.searchCount) + ' 次');
  lines.push('· 输入 token：' + kTok(t.promptTokens));
  lines.push('· 缓存命中率：' + pct(t.cacheHitRate));
  lines.push('· 总 token：' + kTok(t.totalTokens)
    + '（缓存 ' + kTok(t.cachedTokens) + ' / 输出 ' + kTok(t.completionTokens) + '）');

  if (today) {
    lines.push('');
    lines.push('今天（' + todayKey + '）');
    lines.push('· 成本：' + money(today.cost)
      + '　调用：' + int(today.runs) + ' 次'
      + '　搜索：' + int(today.searchCount) + ' 次');
    lines.push('· 输入 token：' + kTok(today.promptTokens)
      + '　缓存命中率：' + pct(today.cacheHitRate));
  }

  lines.push('');
  lines.push('按模型');
  if (!models.length) {
    lines.push('（暂无调用记录）');
  } else {
    const top = models.slice().sort((a, b) => (Number(b.cost) || 0) - (Number(a.cost) || 0)).slice(0, 10);
    for (const m of top) {
      lines.push('· ' + (m.key || '(未知模型)'));
      lines.push('  成本 ' + money(m.cost)
        + '　调用 ' + int(m.runs) + ' 次'
        + '　缓存命中 ' + pct(m.cacheHitRate));
      lines.push('  输入 ' + kTok(m.promptTokens) + ' token');
    }
    if (models.length > top.length) {
      lines.push('（共 ' + models.length + ' 个模型，仅列成本前 ' + top.length + '）');
    }
  }

  return lines.join('\n');
}

function localDayKey(ts) {
  const d = new Date(Number(ts) || Date.now());
  return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
}

function formatTime(ts) {
  const d = new Date(Number(ts) || Date.now());
  const p = (n) => String(n).padStart(2, '0');
  return localDayKey(ts) + ' ' + p(d.getHours()) + ':' + p(d.getMinutes());
}

// ══ 状态与配置读取 ═════════════════════════════════════════════════════════

function projectRoot() {
  try {
    const here = fileURLToPath(import.meta.url);       // …/skills/daily-usage-report/index.js
    return path.resolve(path.dirname(here), '..', '..');
  } catch { return null; }
}

function statePath() {
  const root = projectRoot();
  if (!root) return null;
  const dir = path.join(root, 'data');
  try { fs.mkdirSync(dir, { recursive: true }); } catch { /* 已存在或不可写 */ }
  return path.join(dir, STATE_FILE);
}

function readState() {
  try {
    const p = statePath();
    if (!p || !fs.existsSync(p)) return {};
    return JSON.parse(fs.readFileSync(p, 'utf8')) || {};
  } catch { return {}; }
}

function markSent(ts) {
  try {
    const p = statePath();
    if (!p) return;
    fs.writeFileSync(p, JSON.stringify({ lastSentAt: Number(ts) || Date.now() }, null, 2), 'utf8');
  } catch { /* 写失败最坏是下一条消息再发一次 */ }
}

// ── 全局配置：先用 import 拿内存里的实时配置，失败再读 data/config.json ──
let moduleCfg = null;
try {
  const m = await import('../../src/config.js');
  if (typeof m.getConfig === 'function') moduleCfg = () => m.getConfig();
} catch { /* 结构不同 → 走文件兜底 */ }

function fileCfg() {
  try {
    const root = projectRoot();
    if (!root) return null;
    const f = path.join(root, 'data', 'config.json');
    if (!fs.existsSync(f)) return null;
    return JSON.parse(fs.readFileSync(f, 'utf8'));
  } catch { return null; }
}

function readGlobalConfig() {
  if (moduleCfg) {
    try { const v = moduleCfg(); if (v) return v; } catch { /* 落到文件 */ }
  }
  return fileCfg();
}
