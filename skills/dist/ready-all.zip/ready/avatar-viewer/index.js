// 群友头像查看（LLM 型技能，放 skills/ 而不是 plugins/）
//
// 为什么是技能：触发条件是「有人问头像相关的话」，要靠模型读懂自然语言才能判断，
// 写不成 if。所以它注册一个工具进模型的 tools 列表，用不用由模型决定。
//
// 它解决的问题：模型平时拿不到群友的头像（头像不在聊天记录里），被问到时只能
// 回「我看不到图片」或者瞎编。这个工具把 QQ 头像原图取回来，以 image_url 部件
// 交给模型——模型这才真的"看见"了。
//
// 走的是公开头像接口（qlogo），只读、不碰 QQ 账号状态，所以没有权限风险。

let cfg = () => ({});
// 联网统一走 api.fetch（清单里已声明 permissions: ["web_fetch"]）。
// 拿不到 api.fetch 时退回全局 fetch，保证工具不会因为宿主版本差异而直接崩。
let httpFetch = (...args) => globalThis.fetch(...args);

const MAX_BYTES = 4 * 1024 * 1024;   // 单张头像上限，防止被超大响应拖死
const TIMEOUT_MS = 12000;            // 单次抓取超时

// 头像源：主接口失败就换备用接口（两家返回的是同一张图，q1 偶发 5xx）
const AVATAR_URLS = [
  (uin, size) => `https://q1.qlogo.cn/g?b=qq&nk=${uin}&s=${size}`,
  (uin, size) => `https://q.qlogo.cn/headimg_dl?dst_uin=${uin}&spec=${size}&img_type=jpg`
];

// 「我」「自己」这类词 = 问的人自己，不当成昵称去找
const SELF_WORDS = new Set(['我', '自己', '我的', '我自己', '本人', '俺']);

// qlogo 只认这几档尺寸，填 200/320 之类会直接回 HTTP 400（实测），
// 所以用户配的数字要就近吸附到支持的档位，不能原样拼进 URL。
const SIZE_STEPS = [40, 100, 140, 160, 640];

function clampSize(value) {
  const n = Number(value);
  const wanted = Number.isFinite(n) ? n : 640;
  return SIZE_STEPS.reduce((best, s) => (Math.abs(s - wanted) < Math.abs(best - wanted) ? s : best), 640);
}

/** 按文件头判断真实类型（qlogo 的 content-type 有时不准） */
function sniffMime(buf) {
  if (!buf || buf.length < 12) return null;
  if (buf[0] === 0x89 && buf[1] === 0x50) return 'image/png';
  if (buf[0] === 0xff && buf[1] === 0xd8) return 'image/jpeg';
  if (buf.toString('ascii', 0, 3) === 'GIF') return 'image/gif';
  if (buf.toString('ascii', 0, 4) === 'RIFF' && buf.toString('ascii', 8, 12) === 'WEBP') return 'image/webp';
  return null;
}

/** 把模型给的「12345678」「@12345678」「qq:12345678」都收敛成纯数字 QQ 号 */
function asQqNumber(raw) {
  const s = String(raw ?? '').trim().replace(/^@+/, '').replace(/^(qq|uin)\s*[:：]?\s*/i, '');
  return /^\d{5,12}$/.test(s) ? s : '';
}

/**
 * 谁在问？
 * ctx 里没有"当前发言者"字段（见 skill-reference.md §10），但聊天存档里有：
 * 取最近一条**非自己发的**消息的 senderId。私聊直接就是 chatId。
 */
function askerQq(ctx) {
  try {
    const list = ctx.store?.recent?.(ctx.chatKey, { limit: 20, includeSelf: false }) || [];
    for (let i = list.length - 1; i >= 0; i -= 1) {
      const id = String(list[i]?.senderId ?? '');
      if (/^\d{5,12}$/.test(id)) return id;
    }
  } catch { /* 存档读不到就走下面的兜底 */ }
  if (ctx.kind === 'private') return asQqNumber(ctx.chatId);
  return '';
}

/** 收集当前会话里能对上号的人：聊天记录 + 活跃成员 +（群里）完整群成员列表 */
async function memberPool(ctx) {
  const pool = [];
  try {
    for (const m of ctx.store?.recent?.(ctx.chatKey, { limit: 120 }) || []) {
      pool.push({ userId: m.senderId, senderName: m.senderName });
    }
  } catch { /* 忽略 */ }
  try {
    for (const m of ctx.store?.activeMembers?.(ctx.chatKey, 20) || []) {
      pool.push({ userId: m.userId, senderName: m.name });
    }
  } catch { /* 忽略 */ }
  if (ctx.kind === 'group') {
    try {
      const list = await ctx.onebot.call('get_group_member_list', { group_id: Number(ctx.chatId) });
      for (const m of Array.isArray(list) ? list : []) {
        pool.push({ userId: m.user_id, senderName: m.card || m.nickname });
      }
    } catch { /* 协议端不给就算了，用聊天记录里的人兜底 */ }
  }
  return pool;
}

/** 昵称 → QQ 号。先全等匹配，全等没有才退回包含匹配（避免「小」匹配到一堆人） */
function matchByName(pool, name) {
  const q = String(name ?? '').trim().toLowerCase();
  if (!q) return [];
  const exact = [];
  const fuzzy = [];
  const seen = new Set();
  for (const m of pool) {
    const uid = String(m?.userId ?? '');
    if (!/^\d{5,12}$/.test(uid) || seen.has(uid)) continue;
    const n = String(m?.senderName ?? '').trim();
    if (!n) continue;
    if (n.toLowerCase() === q) {
      exact.push({ userId: uid, name: n });
      seen.add(uid);
    } else if (n.toLowerCase().includes(q)) {
      fuzzy.push({ userId: uid, name: n });
      seen.add(uid);
    }
  }
  return exact.length ? exact : fuzzy;
}

/** 抓头像 → data URL。多个源依次试，全失败才抛错。 */
async function fetchAvatar(uin, size) {
  const errors = [];
  for (const build of AVATAR_URLS) {
    const url = build(uin, size);
    try {
      const res = await httpFetch(url, {
        signal: AbortSignal.timeout(TIMEOUT_MS),
        headers: { 'User-Agent': 'Mozilla/5.0 (compatible; QQ-Agent/avatar-viewer)' }
      });
      if (!res.ok) {
        errors.push(`${new URL(url).host} → HTTP ${res.status}`);
        continue;
      }
      const buf = Buffer.from(await res.arrayBuffer());
      if (!buf.length) {
        errors.push(`${new URL(url).host} → 空响应`);
        continue;
      }
      if (buf.length > MAX_BYTES) {
        errors.push(`${new URL(url).host} → 图片过大（${Math.round(buf.length / 1024)}KB）`);
        continue;
      }
      const mime = sniffMime(buf) || String(res.headers.get('content-type') || 'image/jpeg').split(';')[0].trim();
      if (!mime.startsWith('image/')) {
        errors.push(`${new URL(url).host} → 返回的不是图片（${mime}）`);
        continue;
      }
      return { dataUrl: `data:${mime};base64,${buf.toString('base64')}`, bytes: buf.length, mime };
    } catch (error) {
      errors.push(`${new URL(url).host} → ${error?.message || error}`);
    }
  }
  throw new Error(errors.join('；') || '所有头像源都失败了');
}

function memberListHint(pool) {
  const seen = new Set();
  const lines = [];
  for (const m of pool) {
    const uid = String(m?.userId ?? '');
    const n = String(m?.senderName ?? '').trim();
    if (!n || !/^\d{5,12}$/.test(uid) || seen.has(uid)) continue;
    seen.add(uid);
    lines.push(`- ${n}（${uid}）`);
    if (lines.length >= 8) break;
  }
  return lines.length ? `\n当前能对上号的人有：\n${lines.join('\n')}` : '';
}

export function setup(api) {
  cfg = api.config;   // 每次执行时读，改了设置立刻生效
  if (typeof api.fetch === 'function') httpFetch = api.fetch;

  api.registerTool({
    id: 'view_avatar',
    name: '看群友头像',
    description:
      '取某个人的 QQ 头像原图并直接"看"这张图。当有人问「我的头像是什么样」「我头像换了没」「看看 TA 的头像」「这个人的头像是什么」这类关于头像的问题时使用。'
      + '不是给机器人换头像，是让机器人看见别人的头像。'
      + 'target 填 QQ 号最准；也可以填群昵称/昵称（会在当前会话里找）；留空表示问这句话的人自己。'
      + '调用后你会收到一张图片，请真的看图描述（主体、配色、风格、有无文字），看不清的细节就说看不清。',
    category: 'media',
    icon: '🖼️',
    requiresVision: true,   // 模型不能看图时这个工具就没意义，直接不可用
    parameters: {
      type: 'object',
      properties: {
        target: {
          type: 'string',
          description: '要看谁的头像：QQ 号最准；也可以是群昵称/昵称；留空或不填 = 提问的人自己。'
        }
      }
    },
    async execute(ctx, args) {
      const raw = String(args?.target ?? '').trim();

      // ── 1. 定人 ──────────────────────────────────────────────────
      let userId = '';
      let how = '';
      if (raw && !SELF_WORDS.has(raw.toLowerCase())) {
        userId = asQqNumber(raw);
        if (userId) {
          how = `按 QQ 号 ${userId}`;
        } else {
          const pool = await memberPool(ctx);
          const hits = matchByName(pool, raw);
          if (hits.length === 1) {
            userId = hits[0].userId;
            how = `按昵称「${hits[0].name}」`;
          } else if (hits.length > 1) {
            const names = hits.slice(0, 6).map((h) => `${h.name}（${h.userId}）`).join('、');
            return {
              content: `「${raw}」对上了好几个人：${names}。请问清楚是哪个，或者直接用 QQ 号重试。`,
              isError: true
            };
          } else {
            return {
              content: `没在当前会话里找到叫「${raw}」的人。可以直接用 QQ 号重试。${memberListHint(pool)}`,
              isError: true
            };
          }
        }
      } else {
        userId = askerQq(ctx);
        if (!userId) {
          return {
            content: '拿不到提问者的 QQ 号（这个会话还没有收到过对方的消息）。让对方把 QQ 号说一下，再用 QQ 号查。',
            isError: true
          };
        }
        how = '按提问的人';
      }

      // ── 2. 取图 ──────────────────────────────────────────────────
      const size = clampSize(cfg().size);
      let avatar;
      try {
        avatar = await fetchAvatar(userId, size);
      } catch (error) {
        return { content: `头像下载失败：${error?.message || error}。可以稍后再试一次。`, isError: true };
      }

      // ── 3. 可选：把图也发到聊天里（默认关）──────────────────────
      let echoed = false;
      if (cfg().echoImage === true) {
        try {
          await ctx.sender.sendImage(ctx.chatKey, { dataUrl: avatar.dataUrl }, { note: `${userId} 的头像` });
          echoed = true;
        } catch (error) {
          // 发图失败不影响"看图"，只在给模型的说明里提一句
          api.warn?.('头像发到聊天失败：%s', error?.message || error);
        }
      }

      // ── 4. 交图给模型看 ─────────────────────────────────────────
      // 图片必须走 parts（image_url），绝不能把 base64 拼进文本。
      const kb = Math.max(1, Math.round(avatar.bytes / 1024));
      const head = `这是 QQ ${userId} 的头像原图（${how}，${size}px，${avatar.mime}，约 ${kb}KB）。`
        + (echoed ? '这张图已经发到聊天里了，回答时不要再复述「发给你了」这类话。' : '')
        + '请看着这张图，用你自己的话讲清楚它长什么样：主体/人物、主色调、风格、有没有文字或边框，'
        + '细节看不清就说看不清，不要编。';

      return {
        content: [
          { type: 'text', text: head },
          { type: 'image_url', image_url: { url: avatar.dataUrl } }
        ]
      };
    }
  });

  api.log?.('头像查看已加载：工具 view_avatar');
}
