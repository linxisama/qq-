// 图生图 Skill —— 参考当前会话里已有的一张图片 + 文字要求，生成新图并直接发到当前会话。
//
// 以 skills/image-generate（文生图）为模板改写：交付链路完全一致
// （下载/解码 → 魔数校验 → 落地留档 → sender.sendImage），差异只有两处：
//   · 接口走 OpenAI 兼容的 /images/edits（multipart 表单：参考图 + 改图要求）
//   · 参考图来自消息本身：按 messageId 精确取；省略时自动取触发本次会话的
//     消息里的图，再退到最近一条带图消息 —— 群友「发张图 + 说一句要改成什么」
//     这个最常见用法不需要模型传任何 id，选错图的概率最低。
//
// 沿用模板里用真实事故换来的三条铁律（改动前先读懂，别删）：
//   · 超时/断连一律不重试：图可能已生成并计费，重试 = 花两份钱（与"明确 4xx/5xx
//     可安全重试"相反，两者绝不能混）
//   · 读完响应 body 之前不能清超时计时器 —— 接口常见"响应头秒回、body 慢慢滴"，
//     清早了这一步就永久挂起（无超时、无报错、会话不返回）
//   · available() 必须是同步函数（可用性判定走同步调用链）；配置每次执行现读，
//     setup 时快照会导致「改了设置不生效」

import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';

let cfg = () => ({});
let log = () => {};
let warn = () => {};
// api.fetch：只有清单声明了 permissions: ["web_fetch"] 才是真的 fetch。
// 这是能力引用不是配置，可以 setup 时存；配置仍然每次执行现读。
let apiFetch = null;

const BUILD_TAG = 'v1.0.0-img2img';

const MAX_COUNT = 4;
const MAX_PROMPT_CHARS = 2000;
// 图生图比文生图慢（先把参考图喂进去），默认放宽到 3 分钟
const DEFAULT_TIMEOUT_MS = 180000;
const MIN_TIMEOUT_MS = 5000;
const MAX_TIMEOUT_MS = 600000;
// 结果图下载超时（图床链路问题，与生成超时分开容忍）
const DEFAULT_DOWNLOAD_TIMEOUT_MS = 60000;
const MIN_DOWNLOAD_TIMEOUT_MS = 5000;
const MAX_DOWNLOAD_TIMEOUT_MS = 300000;
// 参考图下载超时（QQ 图床，国内链路，30 秒足够）
const DEFAULT_REF_TIMEOUT_MS = 30000;
const MIN_REF_TIMEOUT_MS = 5000;
const MAX_REF_TIMEOUT_MS = 120000;
const DEFAULT_MAX_IMAGE_MB = 8;        // 结果图上限
const DEFAULT_MAX_REF_MB = 20;         // 参考图上限（QQ 原图可能很大）
const MAX_MB_CEIL = 50;
const DEFAULT_MAX_RETRIES = 1;
const RETRY_DELAY_MS = 2500;
const KEEP_FILES = 20;                 // 本地留档保留最近多少张
const RESPONSE_FORMATS = ['auto', 'url', 'b64_json'];
// /images/edits 官方只认这三类参考图
const REF_MIME_ALLOWED = new Set(['image/png', 'image/jpeg', 'image/webp']);
const RECENT_SCAN_LIMIT = 30;          // 自动找图时最多往前翻多少条

/** 构建标记：加载时打进日志，用于区分「修复没生效」和「修复不对」。 */
export function setup(api) {
  cfg = api.config;
  log = api.log || (() => {});
  warn = api.warn || (() => {});
  apiFetch = api.fetch;
  log(`图生图技能已加载（${BUILD_TAG}）`);

  api.registerTool({
    id: 'redraw',                      // 注册后实际是 image-to-image__redraw
    name: '参考图生成',
    description: '图生图/改图：参考当前会话里一张已有的图片，按文字要求生成新图并直接发到当前会话。当群友发了图片并说「把这张变成XX风格」「照着这张画XX」「把图里的XX改成XX」时用它。prompt 写清楚怎么改（保留什么、改什么）；messageId 填带图那条消息的 #数字，不确定就省略（会自动用最近发的图）。图片由本工具直接发出，不需要再调发送工具。',
    category: 'media',
    icon: '🖌️',
    parameters: {
      type: 'object',
      properties: {
        prompt: { type: 'string', description: '改图要求（中英文都可以）：保留什么（主体/画风/构图），改成什么' },
        messageId: { type: ['integer', 'string'], description: '可选：参考图所在消息的 QQ 消息 id（聊天记录里的 #数字）。省略时自动用触发消息/最近一条带图消息' },
        imageIndex: { type: 'number', description: '可选：那条消息里的第几张图（从 1 开始，默认第 1 张）' },
        size: { type: 'string', description: '可选：输出尺寸，如 1024x1024 / 1536x1024 / 1024x1536；留空用接口默认' },
        count: { type: 'number', description: '可选：一次生成几张，1~4，默认 1' }
      },
      required: ['prompt']
    },
    async execute(ctx, args) {
      // ── 1) 先校验参数：模型可能给空值、超长或越界值 ──────────────────────
      const prompt = String(args?.prompt ?? '').trim();
      if (!prompt) return fail('缺少 prompt：请把要怎么改这张图写清楚（保留什么、改成什么）');
      if (prompt.length > MAX_PROMPT_CHARS) {
        return fail(`prompt 太长（${prompt.length} 字），请压到 ${MAX_PROMPT_CHARS} 字以内再试`);
      }

      const settings = readSettings();
      const missing = missingConfig(settings);
      if (missing.length) {
        return fail(`图生图还没配置：缺 ${missing.join(' / ')}。请到控制台设置页的「图生图」里填好。`);
      }

      const count = clamp(Number(args?.count) || 1, 1, MAX_COUNT);
      const size = String(args?.size ?? '').trim() || settings.defaultSize;

      try {
        // ── 2) 找到并下载参考图（QQ 图床 / 协议端本地文件兜底）──────────────
        const ref = await loadReference(ctx, args, settings);
        if (!REF_MIME_ALLOWED.has(ref.mime)) {
          return fail(`参考图是 ${ref.mime || '未知格式'}，画图接口只认 png / jpg / webp 静态图（GIF 动图不行）。请让群友直接发这三种格式之一的图片。`);
        }

        // ── 3) 调接口（瞬时故障自动重试，见 callWithRetry 的安全性说明）──────
        const { payload, retried } = await callWithRetry(settings, buildForm(settings, ref, prompt, size, count));

        // ── 4) 解析出图片引用（可能是 url，也可能是 base64）─────────────────
        const refs = extractImages(payload);
        if (!refs.length) {
          return fail(`接口没有返回图片。原始响应（截断）：${truncate(JSON.stringify(payload), 300)}`);
        }

        // ── 5) 逐张「物化」：下载 / 解码 + 校验 + 落地留档 ──────────────────
        const ready = [];
        const prepFailed = [];
        for (const [index, item] of refs.entries()) {
          try {
            ready.push(await materialize(settings, item, index));
          } catch (error) {
            // humanizeError 而不是 describeError：后者会把原始 DOMException
            // 渲染成 `[23] The operation was aborted...` 直接给用户看（真实事故）。
            prepFailed.push(humanizeError(error));
          }
        }
        if (!ready.length) {
          return fail(`图片拿到了但无法使用：${prepFailed.join('；') || '未知原因'}`);
        }

        // ── 6) 逐张发送：一律走 sender（队列 / 限频 / 去重都在它里面）────────
        let sent = 0;
        const sendFailed = [];
        for (const image of ready) {
          try {
            // 优先传本地路径：图已落盘，让协议端自己读文件，body 从 MB 级降到百字节级。
            // dataUrl 作为回退，协议端不同机/路径不可读时用。
            await ctx.sender.sendImage(
              ctx.chatKey,
              { file: image.filePath, dataUrl: image.dataUrl },
              { note: 'AI改图' }
            );
            sent += 1;
            ctx.session?.sent?.push({
              type: 'image',
              text: '[图片:AI改图]',
              at: new Date().toLocaleTimeString('zh-CN', { hour12: false })
            });
          } catch (error) {
            // 发送失败时把本地留档路径给出去，省得白画一张
            sendFailed.push(`${humanizeError(error)}（图已存本地：${image.filePath}）`);
          }
        }
        if (sent) {
          log(`参考 ${ref.origin} 生成并发送 ${sent} 张（模型 ${settings.model}${size ? `，尺寸 ${size}` : ''}${retried ? '，重试后成功' : ''}）`);
          try { ctx.emit?.('session-update', ctx.session?.id); } catch { /* 上报失败不影响已发出的图 */ }
        }
        if (!sent) {
          return fail(`图画出来了但发送失败：${sendFailed.join('；')}。`
            + '这通常是协议端到 QQ 的链路问题（不是画图的问题），不要为此重新生成图片 —— 那只会再花一次钱。'
            + '把上面的原因告诉群友即可。');
        }

        const notes = [];
        if (retried) notes.push('（接口第一次失败，重试后成功）');
        if (prepFailed.length) notes.push(`（另有 ${prepFailed.length} 张无效：${prepFailed.join('；')}）`);
        if (sendFailed.length) notes.push(`（另有 ${sendFailed.length} 张发送失败：${sendFailed.join('；')}）`);
        return {
          content: `已按参考图（${ref.origin}）生成 ${sent} 张图片并直接发到当前会话（模型 ${settings.model}${size ? `，尺寸 ${size}` : ''}）${notes.join('')}。`
            + '注意：你看不到生成的画面，所以不要描述画面细节、也不要编造内容，更不要再调用发图工具；'
            + '一句自然的收尾就够了。'
        };
      } catch (error) {
        // ── 失败也返回人话，绝不让异常冒泡 ─────────────────────────────────
        log(`图生图失败：${describeError(error)}`);
        return fail(`图生图失败：${humanizeError(error)}`);
      }
    }
  });
}

// ── 供别的 Skill / 核心按能力名取用（它们不需要 import 这个文件）──────────
export const providers = {
  'image.edit': async ({ prompt, image, size, count } = {}) => {
    try {
      const settings = readSettings();
      const missing = missingConfig(settings);
      if (missing.length) return { ok: false, error: `图生图未配置：缺 ${missing.join(' / ')}` };

      const text = String(prompt || '').trim();
      if (!text) return { ok: false, error: '缺少 prompt' };

      const ref = await refFromProviderImage(image, settings);
      if (!REF_MIME_ALLOWED.has(ref.mime)) {
        return { ok: false, error: `参考图是 ${ref.mime || '未知格式'}，只支持 png/jpg/webp` };
      }

      const { payload } = await callWithRetry(
        settings,
        buildForm(settings, ref, text, String(size || '').trim() || settings.defaultSize, clamp(Number(count) || 1, 1, MAX_COUNT))
      );
      const refs = extractImages(payload);
      if (!refs.length) return { ok: false, error: '接口没有返回图片' };

      const images = [];
      const problems = [];
      for (const [index, item] of refs.entries()) {
        try {
          const done = await materialize(settings, item, index);
          images.push({ dataUrl: done.dataUrl, filePath: done.filePath, mime: done.mime, bytes: done.bytes });
        } catch (error) {
          // 逐张带上原因，排障线索才不会丢
          const reason = humanizeError(error);
          problems.push(`第 ${index + 1} 张：${reason}`);
          warn(`能力调用中有一张图不可用：${reason}`);
        }
      }
      if (!images.length) {
        return { ok: false, error: `图片拿到了但无法使用：${problems.join('；') || '未知原因'}` };
      }
      return { ok: true, images };
    } catch (error) {
      return { ok: false, error: humanizeError(error) };
    }
  }
};

/**
 * 依赖自检：缺配置就直说，别让界面显示「生效中」而调用时才发现画不了。
 * ⚠️ 必须是同步函数 —— 可用性判定走同步调用链，返回 Promise 会被当成「可用」。
 * 这里只读内存里的配置，没有 IO，所以同步判断是安全的。
 */
export function available() {
  const missing = missingConfig(readSettings());
  if (missing.length) return { ok: false, reason: `还没配置：${missing.join(' / ')}（在设置页「图生图」里填）` };
  return { ok: true };
}

/** 动态提示词片段：配置好了才告诉模型「你有改图工具」，没配就不占 token。 */
export function promptSections() {
  if (missingConfig(readSettings()).length) return [];
  return [{
    id: 'image-to-image-note',
    title: '图生图',
    priority: 35,
    content: '群友发了图片并要求「照着改 / 变成某风格 / 参考这张生成」时，用 redraw 工具：prompt 写清楚保留什么、改成什么；带图消息的 #数字 填进 messageId，不确定就省略（自动用最近的图）。'
      + '它会把图直接发到当前会话；你看不到生成结果，所以不要描述画面细节，也不要再调发图工具。'
      + '图生图又慢又贵，接口失败最多重试一次，不要连着试好几次；发不出去时更不要重新生成。'
      + '没有参考图、纯靠文字想象画面时，用文生图（draw），不要用 redraw。'
  }];
}

// ── 参考图：定位 + 下载 ───────────────────────────────────────────────────
/**
 * 定位参考图并取回字节。
 * 优先级：messageId 精确指定 → 触发本次会话的消息里的图 → 最近消息里的图。
 * （自动兜底覆盖「发图 + 一句话要求」这个主用法；messageId 覆盖引用旧图的场景。）
 */
async function loadReference(ctx, args, settings) {
  const wantIndex = Math.max(0, (Number(args?.imageIndex) || 1) - 1);

  let entry = null;
  const mid = args?.messageId;
  if (mid !== undefined && mid !== null && String(mid).trim() !== '') {
    entry = ctx.store.findByMid(ctx.chatKey, mid);
    if (!entry) throw new Error(`当前会话找不到消息 ${mid}。${midHint(ctx)}`);
  }

  let candidates;
  if (entry) {
    candidates = [entry];
  } else {
    const trigger = Array.isArray(ctx.session?.trigger) ? ctx.session.trigger.filter(Boolean) : [];
    // 触发消息里没有图，才往前翻最近的消息；recent() 返回旧→新，从尾部倒着扫 = 最近优先
    candidates = trigger.some((m) => imageMedias(m).length)
      ? trigger
      : (ctx.store.recent(ctx.chatKey, { limit: RECENT_SCAN_LIMIT }) || []);
  }

  let chosen = null;
  let chosenMid = null;
  let total = 0;
  for (let i = candidates.length - 1; i >= 0; i -= 1) {
    const images = imageMedias(candidates[i]);
    if (!images.length) continue;
    chosen = images[Math.min(wantIndex, images.length - 1)];
    chosenMid = candidates[i].mid ?? null;
    total = images.length;
    break;
  }
  if (!chosen) {
    if (entry) {
      throw new Error(`消息 ${entry.mid} 里没有图片。请确认 #数字 指的是带图的那条消息，或让群友重新发图。`);
    }
    throw new Error(`最近 ${RECENT_SCAN_LIMIT} 条消息里没有找到图片。请让群友先发一张图，再 @ 我说要怎么改。`);
  }

  const buffer = await fetchReferenceBuffer(ctx, chosen, settings);
  const mime = detectMime(buffer);
  if (!mime) throw new Error('参考图下载下来不是图片（多半是链接过期或防盗链页），请让群友重新发一张');
  const pickedIndex = Math.min(wantIndex, total - 1) + 1;
  const origin = (chosenMid !== null && chosenMid !== undefined)
    ? `消息 #${chosenMid}${total > 1 ? ` 的第 ${pickedIndex} 张图` : ''}`
    : '当前会话最近的图片';
  return { buffer, mime, origin };
}

/** 存档条目里可用的图片引用列表（url 优先，file id 兜底）。 */
function imageMedias(entry) {
  return ((entry?.media || []))
    .filter((m) => m?.kind === 'image')
    .map((m) => ({ url: String(m.url || '').trim(), file: String(m.file || '').trim() }))
    .filter((m) => m.url || m.file);
}

async function fetchReferenceBuffer(ctx, media, settings) {
  if (media.url) {
    // QQ 图床直链。限制与结果图分开：参考图是群友发的原图，可能大得多
    return downloadImage(media.url, {
      timeoutMs: settings.refDownloadTimeoutMs,
      maxBytes: settings.maxRefBytes,
      what: '参考图'
    });
  }
  // 没有 url 只有 file id：问协议端要本地文件（OneBot get_image），读不到就如实报错
  if (media.file && ctx?.onebot && typeof ctx.onebot.call === 'function') {
    try {
      const r = await ctx.onebot.call('get_image', { file: media.file });
      const local = String(r?.file ?? r?.path ?? '').trim().replace(/^file:\/\//i, '');
      if (local && fs.existsSync(local)) {
        const buffer = fs.readFileSync(local);
        if (buffer.length) return buffer;
      }
    } catch (error) {
      warn(`get_image 兜底失败：${describeError(error)}`);
    }
  }
  throw new Error('这张图既没有可下载的链接，也取不到本地文件 —— 通常是因为图床链接已过期，请让群友重新发一张');
}

/** 能力调用入口的参考图参数：{ buffer, mime } | { dataUrl } | { url }。 */
async function refFromProviderImage(image, settings) {
  if (!image) throw new Error('缺少参考图 image（传 { dataUrl } / { url } / { buffer, mime }）');
  if (Buffer.isBuffer(image.buffer)) {
    return { buffer: image.buffer, mime: detectMime(image.buffer) || String(image.mime || '') };
  }
  const dataUrl = typeof image === 'string' ? image : image.dataUrl;
  if (dataUrl) {
    const buffer = decodeBase64(dataUrl, { maxBytes: settings.maxRefBytes });
    return { buffer, mime: detectMime(buffer) };
  }
  if (image.url) {
    const buffer = await downloadImage(image.url, {
      timeoutMs: settings.refDownloadTimeoutMs,
      maxBytes: settings.maxRefBytes,
      what: '参考图'
    });
    return { buffer, mime: detectMime(buffer) };
  }
  throw new Error('image 参数不认识：传 { dataUrl }、{ url } 或 { buffer, mime }');
}

// ── 配置读取（每次执行现读，用户改完设置立刻生效）─────────────────────────
function readSettings() {
  const c = cfg() || {};
  const baseUrl = String(c.baseUrl || '').trim();
  const format = String(c.responseFormat || '').trim();
  const retries = (c.maxRetries === undefined || c.maxRetries === null || c.maxRetries === '')
    ? DEFAULT_MAX_RETRIES : Number(c.maxRetries);
  return {
    baseUrl,
    endpoint: resolveEndpoint(baseUrl),
    apiKey: String(c.apiKey || '').trim(),
    model: String(c.model || '').trim(),
    defaultSize: String(c.defaultSize || '').trim(),
    responseFormat: RESPONSE_FORMATS.includes(format) ? format : 'auto',
    extraBody: parseExtraBody(c.extraBody),
    timeoutMs: clamp(Number(c.timeoutMs) || DEFAULT_TIMEOUT_MS, MIN_TIMEOUT_MS, MAX_TIMEOUT_MS),
    downloadTimeoutMs: clamp(
      Number(c.downloadTimeoutMs) || DEFAULT_DOWNLOAD_TIMEOUT_MS,
      MIN_DOWNLOAD_TIMEOUT_MS,
      MAX_DOWNLOAD_TIMEOUT_MS
    ),
    refDownloadTimeoutMs: clamp(
      Number(c.refDownloadTimeoutMs) || DEFAULT_REF_TIMEOUT_MS,
      MIN_REF_TIMEOUT_MS,
      MAX_REF_TIMEOUT_MS
    ),
    maxRetries: clamp(Number.isFinite(retries) ? retries : DEFAULT_MAX_RETRIES, 0, 3),
    maxImageBytes: clamp(Number(c.maxImageMB) || DEFAULT_MAX_IMAGE_MB, 1, MAX_MB_CEIL) * 1024 * 1024,
    maxRefBytes: clamp(Number(c.maxRefMB) || DEFAULT_MAX_REF_MB, 1, MAX_MB_CEIL) * 1024 * 1024
  };
}

function missingConfig(settings) {
  const missing = [];
  if (!settings.baseUrl) missing.push('Base URL');
  if (!settings.apiKey) missing.push('API Key');
  if (!settings.model) missing.push('模型 id');
  return missing;
}

/**
 * 用户可能填 /v1、完整地址，也可能手滑填成 generations —— 这里统一补/纠成 /images/edits。
 * 图生图走的是编辑接口， generations 是纯文生图，喂参考图必然 400。
 */
function resolveEndpoint(raw) {
  const url = String(raw || '').trim().replace(/\/+$/, '');
  if (!url) return '';
  if (/\/images\/edits$/i.test(url)) return url;
  if (/\/images\/generations$/i.test(url)) return url.replace(/\/images\/generations$/i, '/images/edits');
  if (/\/v\d+(?:\.\d+)?$/i.test(url)) return `${url}/images/edits`;
  return `${url}/v1/images/edits`;
}

function parseExtraBody(raw) {
  const text = String(raw || '').trim();
  if (!text) return {};
  const parsed = safeParse(text);
  if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) {
    warn(`extraBody 不是合法的 JSON 对象，已忽略：${truncate(text, 80)}`);
    return {};
  }
  return parsed;
}

/** multipart 表单。顺序有讲究：额外字段放前面，核心字段后面覆盖 —— */
function buildForm(settings, ref, prompt, size, count) {
  const form = new FormData();
  for (const [key, value] of Object.entries(settings.extraBody)) {
    form.append(key, typeof value === 'string' ? value : JSON.stringify(value));
  }
  form.append('model', settings.model);
  form.append('image', new Blob([ref.buffer], { type: ref.mime }), `reference.${extOf(ref.mime)}`);
  form.append('prompt', prompt);
  form.append('n', String(count));
  if (size) form.append('size', size);
  if (settings.responseFormat !== 'auto') form.append('response_format', settings.responseFormat);
  return form;
}

function extOf(mime) {
  if (mime === 'image/jpeg') return 'jpg';
  return String(mime || 'image/png').split('/')[1] || 'png';
}

// ── 请求 + 瞬时故障重试 ───────────────────────────────────────────────────
/**
 * 只对「确定没被处理」的失败重试，绝不重试超时和网络中断。
 *
 * 为什么必须这么区分（对用户是钱的问题）：
 *   · 接口明确回 4xx/5xx（比如中转站的「上游服务暂时不可用」）→ 这次请求没被受理，
 *     重试不会产生第二次计费，安全。
 *   · 超时 / 连接中断 → 图**可能已经生成并计费**了，再试就是花双份钱换一张图。
 *     这种情况宁可把失败如实报出去。
 */
async function callWithRetry(settings, body) {
  let lastError = null;
  const attempts = Math.max(1, settings.maxRetries + 1);
  for (let attempt = 1; attempt <= attempts; attempt += 1) {
    try {
      return { payload: await requestEdits(settings, body), retried: attempt > 1 };
    } catch (error) {
      lastError = error;
      if (error?.retryable !== true || attempt >= attempts) break;
      warn(`第 ${attempt} 次请求失败（${describeError(error)}），${RETRY_DELAY_MS}ms 后重试`);
      await new Promise((resolve) => setTimeout(resolve, RETRY_DELAY_MS));
    }
  }
  throw lastError;
}

async function requestEdits(settings, form) {
  if (typeof apiFetch !== 'function') {
    throw new Error('联网能力不可用：清单需声明 permissions: ["web_fetch"]');
  }
  if (typeof FormData === 'undefined') {
    throw new Error('运行环境缺少 FormData（Electron/Node 过旧），无法上传参考图');
  }
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), settings.timeoutMs);
  let res;
  try {
    // 不手动设 Content-Type：fetch 会自动带 boundary，手动写死反而必炸
    res = await apiFetch(settings.endpoint, {
      method: 'POST',
      headers: {
        Accept: 'application/json',
        Authorization: `Bearer ${settings.apiKey}`
      },
      body: form,
      signal: controller.signal
    });
  } catch (error) {
    // 连不上 / 被中断：结果未知，不重试（图可能已经生成并计费）
    if (controller.signal.aborted || isTimeoutLike(error)) {
      throw new Error(`接口超时（${Math.round(settings.timeoutMs / 1000)} 秒没返回）。`
        + '超时不重试：图可能已经生成并计费了，不想让你花两份钱。等一会再决定要不要重来。');
    }
    throw new Error(`连不上接口：${humanizeError(error)}`);
  }
  // ⚠️ 计时器**不能在这里清**：生成接口常见"响应头先回、结果 JSON 后到"，
  // 清早了等于给读 body 这一步摘掉超时，对方一卡住这轮就永久挂起。
  // 清 timer 的动作放到读完 body 之后。

  let text = '';
  try {
    text = await res.text();
  } catch (error) {
    if (controller.signal.aborted) {
      throw new Error(`接口超时（${Math.round(settings.timeoutMs / 1000)} 秒：响应头已返回但响应体没读完）。`
        + '超时不重试：图可能已经生成并计费了，等一会再决定要不要重来。');
    }
    throw new Error(`读取接口响应失败：${humanizeError(error)}`);
  } finally {
    clearTimeout(timer);
  }

  if (!res.ok) {
    const error = new Error(`接口返回 HTTP ${res.status}：${errorText(text)}`);
    // 明确失败 → 没被受理 → 可以安全重试
    error.retryable = isTransientStatus(res.status, text);
    throw error;
  }

  const json = safeParse(text);
  if (!json || typeof json !== 'object') throw new Error(`接口返回的不是 JSON：${truncate(text, 200)}`);
  return json;
}

/**
 * 判断「这次失败要不要重试」。
 * 5xx / 429 一律可重试；400 要看文案 —— 中转站的「上游服务暂时不可用」也是 400，
 * 但它本质是瞬时故障，和「模型名写错了」这种参数错误必须区别对待。
 */
function isTransientStatus(status, text) {
  if (status === 429) return true;
  if (status >= 500) return true;
  if (status !== 400 && status !== 402 && status !== 408) return false;
  return /上游|暂时不可用|稍后重试|请重试|try again|later|timeout|timed out|overload|繁忙|拥挤|rate.?limit|temporar|upstream|unavailable|无可用|切换固定商家|智能路由/i
    .test(String(text || ''));
}

function errorText(text) {
  const json = safeParse(text);
  const raw = json?.error?.message ?? json?.error ?? json?.message ?? json?.msg ?? json?.detail;
  const message = typeof raw === 'string' ? raw : (raw ? JSON.stringify(raw) : '');
  return truncate(message || String(text || '').trim() || '接口没有返回错误详情', 300);
}

// ── 解析：兼容 url / b64_json / data[].image 等常见形状 ────────────────────
function extractImages(payload) {
  const candidates = [];
  if (Array.isArray(payload)) candidates.push(...payload);
  for (const key of ['data', 'images', 'output', 'results', 'artifacts']) {
    const value = payload?.[key];
    if (Array.isArray(value)) candidates.push(...value);
    else if (value && typeof value === 'object') candidates.push(value);
  }
  const refs = [];
  for (const item of candidates) {
    const ref = toImageRef(item);
    if (ref) refs.push(ref);
  }
  return refs;
}

function toImageRef(item) {
  if (typeof item === 'string') return refFromValue(item);
  if (!item || typeof item !== 'object') return null;

  // base64 优先：接口给的链接常常带防盗链或很快过期
  const rawB64 = firstString(item.b64_json, item.base64, item.image_base64, item.b64);
  if (rawB64) return { kind: 'base64', value: rawB64 };

  const rawUrl = firstString(
    item.url,
    item.image_url && typeof item.image_url === 'object' ? item.image_url.url : item.image_url,
    item.image,
    item.file,
    item.url_path
  );
  return rawUrl ? refFromValue(rawUrl) : null;
}

function refFromValue(value) {
  const text = String(value || '').trim();
  if (!text) return null;
  if (/^https?:\/\//i.test(text)) return { kind: 'url', value: text };
  return { kind: 'base64', value: text };   // 裸 base64 或 data:image/png;base64,xxx
}

// ── 物化：把 ref 变成协议端能直接用的 base64:// 数据，并落地留档 ────────────
async function materialize(settings, ref, index) {
  const buffer = ref.kind === 'url'
    ? await downloadImage(ref.value, { timeoutMs: settings.downloadTimeoutMs, maxBytes: settings.maxImageBytes, what: '结果图' })
    : decodeBase64(ref.value, { maxBytes: settings.maxImageBytes });

  if (!buffer.length) throw new Error('图片内容为空');
  if (buffer.length > settings.maxImageBytes) {
    throw new Error(`图片 ${(buffer.length / 1048576).toFixed(1)}MB 超过上限 `
      + `${(settings.maxImageBytes / 1048576).toFixed(0)}MB。请换更小的尺寸，或换成输出 jpg 的模型/接口。`);
  }

  const mime = detectMime(buffer);
  if (!mime) throw new Error('拿到的不是图片（可能是防盗链页或错误页），已丢弃');

  const filePath = saveLocal(buffer, mime, index);
  return { dataUrl: `base64://${buffer.toString('base64')}`, filePath, mime, bytes: buffer.length };
}

/**
 * 下载一张图（带一次免费重试）。
 *
 * 超时覆盖响应头与响应体两个阶段，并明确报出**阶段**与**已收字节数**：
 *   · 响应头都没回  → 多半是路由/被墙，换网络或换图床
 *   · body 只收到一点 → 对方是活的只是慢，调大下载超时有意义
 * 下载是幂等且免费的（花钱的只有生成），所以这里重试是净收益 ——
 * 与生成请求「超时不重试」是相反的规则，别混。
 */
async function downloadImage(url, { timeoutMs, maxBytes, what = '图片' } = {}) {
  if (typeof apiFetch !== 'function') throw new Error('联网能力不可用');

  // 防御性兜底：调用方漏传时给安全默认值，绝不能让 setTimeout 收到 undefined
  //（undefined 会被当成 1ms，表现为"每个下载瞬间超时"）
  const timeout = Number(timeoutMs) > 0 ? Number(timeoutMs) : 30000;
  const limit = Number(maxBytes) > 0 ? Number(maxBytes) : 32 * 1048576;

  let problem = null;
  const attempts = 2;
  for (let attempt = 1; attempt <= attempts; attempt += 1) {
    const startedAt = Date.now();
    const progress = { bytes: 0 };
    try {
      return await downloadOnce(url, timeout, limit, progress, what);
    } catch (error) {
      const secs = Math.max(1, Math.round((Date.now() - startedAt) / 1000));
      problem = { readable: describeDownloadError(error, timeoutMs, progress.bytes, what), retryable: error?.retryable === true };

      // 诊断日志：定位根因需要 name/code/是否有 cause 链/卡在哪个阶段
      const o = error?.original || {};
      log(`下载失败诊断：phase=${error?.phase || '?'} bytes=${progress.bytes}`
        + ` name=${o.name || error?.name || '?'} code=${o.code ?? error?.code ?? '?'}`
        + ` msg=${String(o.message || error?.message || '').slice(0, 160)}`);

      if (!problem.retryable || attempt >= attempts) break;
      warn(`${problem.readable}（用了 ${secs}s）→ 重试下载 ${attempt + 1}/${attempts}`);
      await new Promise((resolve) => setTimeout(resolve, 1200));
    }
  }

  if (what === '结果图') {
    // 必须让用户和模型都明白：**图已经生成并计费了**，失败只在"下载"这一环。
    // 否则模型的自然反应是"重新生成一张"——那是再花一份钱，而问题根本不在生成。
    log(`结果图下载失败，原始链接（可手动重试下载）：${url}`);
    throw new Error(`${problem.readable}。图已生成（可能已计费），**不要重新生成**；`
      + `下载失败不影响图片本身，稍后可用这个链接重取：${url}`);
  }
  throw new Error(`${problem.readable}。链接有时效的话让群友重新发一张即可`);
}

/**
 * 判定一个错误是否为「超时 / 中断」语义（含 cause 链）。
 * abort 可能不是我们自己的 timer 触发的（底层 undici / 对端断开 / 代理），
 * 这些情况下 signal.aborted 仍是 false —— 所以判定要同时看
 * 信号与错误语义两条证据（name / DOMException.code / message，逐层挖 cause）。
 */
function isTimeoutLike(error) {
  const TIMEOUT_CODES = new Set([23, 20]);                  // DOMException: TIMEOUT_ERR / ABORT_ERR
  const TIMEOUT_NAMES = new Set(['TimeoutError', 'AbortError']);
  const TIMEOUT_TEXT = /aborted due to timeout|operation was aborted|timed?\s?out/i;
  let current = error;
  const seen = new Set();
  while (current && !seen.has(current)) {
    seen.add(current);
    if (TIMEOUT_NAMES.has(current.name)) return true;
    if (TIMEOUT_CODES.has(current.code)) return true;
    if (TIMEOUT_TEXT.test(String(current.message || ''))) return true;
    current = current.cause;                                // ⚠️ fetch 只给一句 "fetch failed"，真因在 cause 里
  }
  return false;
}

/**
 * 统一的人话入口：超时语义永不裸露原始错误码。
 * 用于所有会写进用户可见文案的地方（工具返回值、能力返回值）。
 */
function humanizeError(error) {
  if (!error) return '未知错误';
  const msg = String(error.message || '');
  // "无信息 message" 必须挖 cause，不能原样返回：fetch 网络层失败时
  // message 恒为 "fetch failed"，真因全在 cause 里 —— 直接返回等于把
  // 排查线索扔掉（实测：用户看到的就是一句光秃秃的 "fetch failed"）。
  const VAGUE = /^(fetch failed|terminated|other side closed|socket hang up|network error|the operation was aborted)$/i;
  if (msg && !/^\[\d+\]/.test(msg) && !VAGUE.test(msg.trim())) return msg;
  if (isTimeoutLike(error)) return `操作超时（${describeError(error)}）`;
  return describeError(error);
}

/** 把下载失败的原始错误翻译成"能据此做决定"的一句话。 */
function describeDownloadError(error, timeoutMs, receivedBytes, what) {
  // 条件里带 isTimeoutLike：万一 phaseTimeout 没被标记（abort 来自底层），
  // 也要给出可读的处置建议，而不是把原始错误码透出去。
  if (error?.phaseTimeout || isTimeoutLike(error)) {
    const limit = Math.round(timeoutMs / 1000);
    const where = error?.phase === 'headers'
      ? '没返回响应头，可能是网络到不了图床'
      : `响应体只收到 ${formatBytes(receivedBytes)}，图床太慢，可在设置页调大下载超时`;
    return `下载${what}超时（${limit} 秒内${where}）`;
  }
  return `下载${what}失败：${humanizeError(error)}`;
}

/** 人类可读的字节数。小字节数一律用 MB 会渲染成 0.00MB，等于什么都没说。 */
function formatBytes(bytes) {
  const n = Math.max(0, Number(bytes) || 0);
  if (n < 1024) return `${n}B`;
  if (n < 1024 * 1024) return `${(n / 1024).toFixed(1)}KB`;
  return `${(n / 1048576).toFixed(2)}MB`;
}

/** 单次下载。超时覆盖响应头与响应体两个阶段，分阶段标记 phase。 */
async function downloadOnce(url, timeoutMs, maxBytes, progress, what = '图片') {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  let phase = 'headers';

  const asTimeout = (error) => {
    if (!controller.signal.aborted && !isTimeoutLike(error)) return null;
    const wrapped = new Error(`timeout during ${phase}`);
    wrapped.phaseTimeout = true;
    wrapped.phase = phase;
    wrapped.retryable = true;
    wrapped.signalAborted = controller.signal.aborted;
    wrapped.original = { name: error?.name, code: error?.code, message: String(error?.message || '').slice(0, 200) };
    return wrapped;
  };

  try {
    let res;
    try {
      res = await apiFetch(url, {
        redirect: 'follow',
        headers: { Accept: 'image/*,*/*;q=0.8' },
        signal: controller.signal
      });
    } catch (error) {
      const timeout = asTimeout(error);
      if (timeout) throw timeout;
      // 连接类错误（ECONNRESET / DNS）也重试：下载幂等且免费
      const wrapped = new Error(humanizeError(error));
      wrapped.retryable = true;
      throw wrapped;
    }

    if (!res.ok) throw new Error(`HTTP ${res.status}`);   // 状态码已明确 → 重试没意义

    const declared = Number(res.headers.get('content-length') || 0);
    if (declared && declared > maxBytes) {
      throw new Error(`${what ?? '图片'} ${(declared / 1048576).toFixed(1)}MB 超过上限 ${(maxBytes / 1048576).toFixed(0)}MB`);
    }

    phase = 'body';
    try {
      return await readLimited(res, maxBytes, progress);
    } catch (error) {
      if (error?.tooLarge) throw error;          // 体积超限：换更小的图才有用，重试无用
      const timeout = asTimeout(error);
      if (timeout) throw timeout;
      const wrapped = new Error(`传输中断（已收到 ${formatBytes(progress.bytes)}）：${humanizeError(error)}`);
      wrapped.retryable = true;
      throw wrapped;
    }
  } finally {
    clearTimeout(timer);
  }
}

/** 边读边限流：避免无 content-length 的超大响应把内存打爆。 */
async function readLimited(res, maxBytes, progress = { bytes: 0 }) {
  if (!res.body || typeof res.body.getReader !== 'function') {
    const buffer = Buffer.from(await res.arrayBuffer());
    progress.bytes = buffer.length;
    if (buffer.length > maxBytes) throw tooLargeError(maxBytes, true);
    return buffer;
  }
  const reader = res.body.getReader();
  const chunks = [];
  try {
    for (;;) {
      const { done, value } = await reader.read();
      if (done) break;
      if (!value?.byteLength) continue;
      progress.bytes += value.byteLength;
      if (progress.bytes > maxBytes) {
        throw tooLargeError(maxBytes, true);
      }
      chunks.push(Buffer.from(value));
    }
  } finally {
    try { await reader.cancel(); } catch { /* 已读完或已中止（中止时 cancel 也会抛） */ }
  }
  return Buffer.concat(chunks);
}

function tooLargeError(maxBytes, midway = false) {
  const error = new Error(`图片超过体积上限 ${(maxBytes / 1048576).toFixed(0)}MB${midway ? '（下载中途截断）' : ''}`);
  error.tooLarge = true;
  return error;
}

function decodeBase64(value, { maxBytes } = {}) {
  const text = String(value || '').trim();
  const marked = /^data:[^;,]*;base64,(.*)$/is.exec(text);
  const b64 = (marked ? marked[1] : text).replace(/\s+/g, '');
  if (!b64) throw new Error('图片 base64 为空');
  if (!/^[A-Za-z0-9+/]+={0,2}$/.test(b64)) throw new Error('图片 base64 格式不合法');
  // 先按长度估算，避免为一个超限的大图白白解码出几十 MB 内存
  const estimated = Math.floor(b64.length * 3 / 4);
  if (maxBytes && estimated > maxBytes * 1.2) {
    throw new Error(`图片约 ${(estimated / 1048576).toFixed(1)}MB，超过上限 ${(maxBytes / 1048576).toFixed(0)}MB`);
  }
  return Buffer.from(b64, 'base64');
}

function detectMime(buf) {
  if (!buf || buf.length < 12) return null;
  if (buf[0] === 0xFF && buf[1] === 0xD8 && buf[2] === 0xFF) return 'image/jpeg';
  if (buf.subarray(0, 8).equals(Buffer.from([0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A]))) return 'image/png';
  const head6 = buf.subarray(0, 6).toString('latin1');
  if (head6 === 'GIF87a' || head6 === 'GIF89a') return 'image/gif';
  if (buf.subarray(0, 4).toString('latin1') === 'RIFF' && buf.subarray(8, 12).toString('latin1') === 'WEBP') return 'image/webp';
  return null;
}

/** 本地留档：发送失败时这张图还能捞回来，也方便人工排查。 */
function saveLocal(buffer, mime, index) {
  try {
    const dir = path.join(os.tmpdir(), 'qq-agent-image-to-image');
    fs.mkdirSync(dir, { recursive: true });
    const ext = extOf(mime);
    const name = `${new Date().toISOString().replace(/[:.]/g, '-')}-${index + 1}.${ext}`;
    const filePath = path.join(dir, name);
    fs.writeFileSync(filePath, buffer);
    pruneLocal(dir);
    return filePath;
  } catch (error) {
    warn(`本地留档失败（不影响发送）：${error?.message ?? error}`);
    return '(未能留档)';
  }
}

function pruneLocal(dir) {
  try {
    const files = fs.readdirSync(dir).filter((f) => /\.(png|jpg|jpeg|webp)$/i.test(f)).sort();
    for (const stale of files.slice(0, Math.max(0, files.length - KEEP_FILES))) {
      fs.unlinkSync(path.join(dir, stale));
    }
  } catch { /* 清不动就算了，不该影响主流程 */ }
}

/** 找不到消息 id 时，把当前会话真实可见的 id 告诉模型，避免它继续瞎猜。 */
function midHint(ctx) {
  const mids = (ctx.store.recent(ctx.chatKey, { limit: 60 }) || [])
    .map((m) => m.mid)
    .filter((v) => v !== null && v !== undefined && String(v) !== '');
  const uniq = [...new Set(mids.map(String))].slice(-8);
  return uniq.length
    ? `消息 id 只能用聊天记录里每条消息前的 #数字（最近可见：${uniq.join(' ')}），不要自己编`
    : '聊天记录里还没有带 #id 的消息';
}

// ── 错误描述：把 cause 链挖出来 ───────────────────────────────────────────
/**
 * Node 的 fetch 失败只会给一句「fetch failed」，真正的原因（ECONNRESET /
 * 连接被对端关闭 / DNS 失败）藏在 error.cause 里 —— 不挖出来就没法定位。
 */
function describeError(error, depth = 0) {
  if (!error) return '未知错误';
  if (depth > 3) return String(error?.message ?? error);

  const parts = [];
  const seen = new Set();
  let current = error;
  while (current && !seen.has(current) && parts.length < 4) {
    seen.add(current);
    if (Array.isArray(current.errors) && current.errors.length) {
      for (const inner of current.errors) {
        const text = describeError(inner, depth + 1);
        if (text && !parts.includes(text)) parts.push(text);
      }
      break;
    }
    const code = current.code ? `[${current.code}] ` : '';
    const message = String(current.message || current.name || current).trim();
    const piece = `${code}${message}`.trim();
    if (piece && !parts.includes(piece)) parts.push(piece);
    current = current.cause;
  }
  return parts.join(' ← ') || '未知错误';
}

// ── 小工具（纯函数，方便单测）────────────────────────────────────────────
function fail(message) { return { content: `错误：${message}`, isError: true }; }
function clamp(n, lo, hi) {
  const value = Number.isFinite(n) ? Math.round(n) : lo;
  return Math.min(hi, Math.max(lo, value));
}
function truncate(text, max) {
  const s = String(text ?? '');
  return s.length > max ? `${s.slice(0, max)}…` : s;
}
function firstString(...values) {
  for (const value of values) {
    if (typeof value === 'string' && value.trim()) return value.trim();
  }
  return '';
}
function safeParse(text) {
  try { return JSON.parse(text); } catch { return null; }
}

// 给测试用的出口
export const internals = {
  resolveEndpoint, buildForm, extractImages, detectMime, decodeBase64, clamp,
  readSettings, isTransientStatus, describeError, materialize, readLimited,
  downloadImage, downloadOnce, describeDownloadError, formatBytes,
  isTimeoutLike, humanizeError, imageMedias, extOf
};
