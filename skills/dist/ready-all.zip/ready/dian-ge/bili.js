// B 站只读客户端（点歌技能自包含副本）。
//
// 为什么复制一份而不是 import 别的技能：
//   技能目录是独立的，用户删掉/停用 bili-share 不该让点歌跟着坏掉。
//
// 实测要点（2026-10）：
//   · 搜索接口没有 buvid 指纹会 412，先领 /x/frontend/finger/spi 的 b_3/b_4。
//   · 音频走 playurl 的 DASH（fnval=16）→ dash.audio[].baseUrl（m4a）。
//   · CDN 必须带 Referer: https://www.bilibili.com/，否则 403。
//   · 有些视频没有 DASH，只剩 fnval=1 的 durl（mp4），留作兜底。

import fs from 'node:fs';
import path from 'node:path';

const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
  + '(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36';
const REFERER = 'https://www.bilibili.com/';
const API = 'https://api.bilibili.com';

let fetchImpl = typeof globalThis.fetch === 'function' ? globalThis.fetch.bind(globalThis) : null;

/** 由 setup(api) 注入带权限的 fetch。 */
export function setFetch(fn) {
  if (typeof fn === 'function') fetchImpl = fn;
}

function requireFetch() {
  if (!fetchImpl) throw new Error('当前运行环境没有可用的 fetch');
  return fetchImpl;
}

function uniqueUrls(list) {
  const out = [];
  const seen = new Set();
  for (const raw of list || []) {
    const url = String(raw ?? '').trim();
    if (!url || seen.has(url)) continue;
    seen.add(url);
    out.push(url);
  }
  return out;
}

function cleanTitle(raw) {
  return String(raw ?? '')
    .replace(/<[^>]*>/g, '')
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/[\u200b-\u200f\u2060\ufeff]/g, '')
    .replace(/\s+/g, ' ')
    .trim();
}

/** B 站封面字段有 //i0.hdslb.com/... 的协议相对形态，统一补成 https。 */
export function normalizePic(raw) {
  let s = String(raw ?? '').trim();
  if (!s) return '';
  if (s.startsWith('//')) s = `https:${s}`;
  if (s.startsWith('http://')) s = `https://${s.slice('http://'.length)}`;
  return s;
}

export function parseDuration(raw) {
  if (typeof raw === 'number' && Number.isFinite(raw)) return Math.max(0, Math.round(raw));
  const s = String(raw ?? '').trim();
  if (!s) return 0;
  if (/^\d+$/.test(s)) return Number(s);
  const parts = s.split(':').map((x) => Number(x));
  if (parts.some((n) => !Number.isFinite(n))) return 0;
  return parts.reduce((acc, n) => acc * 60 + n, 0);
}

export function formatDuration(sec) {
  const total = Math.max(0, Math.round(Number(sec) || 0));
  const h = Math.floor(total / 3600);
  const m = Math.floor((total % 3600) / 60);
  const s = total % 60;
  if (h > 0) return `${h}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
  return `${m}:${String(s).padStart(2, '0')}`;
}

async function getJson(url, { headers = {}, timeoutMs = 15000 } = {}) {
  let res;
  try {
    res = await requireFetch()(url, {
      headers: { 'User-Agent': UA, Referer: REFERER, ...headers },
      signal: AbortSignal.timeout(timeoutMs)
    });
  } catch (error) {
    return { ok: false, error: `网络请求失败：${error?.message ?? error}` };
  }
  let text;
  try {
    text = await res.text();
  } catch (error) {
    return { ok: false, error: `读取响应失败：${error?.message ?? error}` };
  }
  if (res.status !== 200) {
    return { ok: false, status: res.status, error: `HTTP ${res.status}`, raw: text.slice(0, 160) };
  }
  let body;
  try {
    body = JSON.parse(text);
  } catch {
    return { ok: false, error: 'B 站返回的不是 JSON', raw: text.slice(0, 160) };
  }
  if (body?.code !== 0) {
    return { ok: false, code: body?.code, error: body?.message || `B 站业务码 ${body?.code}` };
  }
  // 普通接口是 data，番剧接口是 result。
  return { ok: true, data: body?.data !== undefined ? body.data : body?.result };
}

// ── 指纹（搜索必需） ──────────────────────────────────────────────────────

let fingerprint = { cookie: '', at: 0 };

async function ensureFingerprint({ timeoutMs = 10000, force = false } = {}) {
  if (!force && fingerprint.cookie && Date.now() - fingerprint.at < 25 * 60 * 1000) {
    return fingerprint.cookie;
  }
  const r = await getJson(`${API}/x/frontend/finger/spi`, { timeoutMs });
  if (!r.ok) return '';
  const b3 = String(r.data?.b_3 ?? '').trim();
  const b4 = String(r.data?.b_4 ?? '').trim();
  fingerprint = {
    cookie: [b3 ? `buvid3=${b3}` : '', b4 ? `buvid4=${b4}` : ''].filter(Boolean).join('; '),
    at: Date.now()
  };
  return fingerprint.cookie;
}

// ── 搜索 ──────────────────────────────────────────────────────────────────

/**
 * 关键词搜视频。返回字段：bvid/title/author/durationSec/duration/play/pic。
 * 搜索结果不保证第一条最合适，排序交给调用方的 rankCandidates。
 */
export async function searchVideos(keyword, { limit = 20, timeoutMs = 15000 } = {}) {
  const kw = String(keyword ?? '').trim();
  if (!kw) return { ok: false, error: '歌名是空的' };
  const url = `${API}/x/web-interface/search/type?search_type=video&page=1&keyword=${encodeURIComponent(kw)}`;
  let cookie = await ensureFingerprint({ timeoutMs });
  let r = await getJson(url, { headers: cookie ? { Cookie: cookie } : {}, timeoutMs });
  if (!r.ok && (r.status === 412 || r.code === -412)) {
    cookie = await ensureFingerprint({ timeoutMs, force: true });
    r = await getJson(url, { headers: cookie ? { Cookie: cookie } : {}, timeoutMs });
  }
  if (!r.ok) return { ok: false, error: r.error };

  const raw = Array.isArray(r.data?.result) ? r.data.result : [];
  const items = raw
    .filter((it) => it && it.bvid)
    .map((it) => {
      const durationSec = parseDuration(it.duration);
      return {
        bvid: String(it.bvid),
        title: cleanTitle(it.title),
        author: cleanTitle(it.author),
        durationSec,
        duration: formatDuration(durationSec),
        play: Number(it.play) || 0,
        pic: normalizePic(it.pic),
        // 歌曲识别用：B 站搜索自带分区与标签，比标题可靠
        typeid: String(it.typeid ?? ''),
        typename: cleanTitle(it.typename ?? it.tname ?? ''),
        tag: String(it.tag ?? ''),
        description: cleanTitle(it.description ?? '').slice(0, 200)
      };
    });

  return { ok: true, items: items.slice(0, Math.max(1, Number(limit) || 20)), total: raw.length };
}

// ── 视频信息 / 音频流 ─────────────────────────────────────────────────────

export async function fetchVideoInfo(bvid, { timeoutMs = 15000 } = {}) {
  const id = String(bvid ?? '').trim();
  if (!/^BV[0-9A-Za-z]{10}$/.test(id)) return { ok: false, error: `BV 号格式不对：${id || '(空)'}` };
  const r = await getJson(`${API}/x/web-interface/view?bvid=${encodeURIComponent(id)}`, { timeoutMs });
  if (!r.ok) return { ok: false, error: r.error };
  const d = r.data || {};
  const cid = Number(d.cid) || 0;
  if (!cid) return { ok: false, error: '这个视频没有可用的 cid（可能是番剧/直播回放）' };
  return {
    ok: true,
    bvid: String(d.bvid || id),
    cid,
    title: cleanTitle(d.title) || id,
    author: cleanTitle(d.owner?.name),
    durationSec: Number(d.duration) || 0,
    pic: normalizePic(d.pic),
    desc: cleanTitle(d.desc).slice(0, 160),
    typeid: String(d.tid ?? ''),
    typename: cleanTitle(d.tname ?? '')
  };
}

/**
 * 取音频直链。优先 DASH 的纯音频流（m4a），没有就退回 360P 单文件 mp4。
 * 返回 { ok, kind:'audio'|'video', ext, urls:[主,备用...] }。
 */
export async function fetchAudioSource(bvid, cid, { timeoutMs = 20000 } = {}) {
  const base = `${API}/x/player/playurl?bvid=${encodeURIComponent(bvid)}`
    + `&cid=${encodeURIComponent(cid)}&fnver=0&fourk=1`;
  const cookie = await ensureFingerprint({ timeoutMs });
  const headers = cookie ? { Cookie: cookie } : {};

  const dashRes = await getJson(`${base}&fnval=16`, { headers, timeoutMs });
  if (dashRes.ok) {
    const audios = Array.isArray(dashRes.data?.dash?.audio) ? dashRes.data.dash.audio : [];
    if (audios.length) {
      const best = [...audios].sort((a, b) => (Number(b.bandwidth) || 0) - (Number(a.bandwidth) || 0))[0];
      const backups = Array.isArray(best?.backupUrl) ? best.backupUrl
        : (Array.isArray(best?.backup_url) ? best.backup_url : []);
      const urls = uniqueUrls([best?.baseUrl || best?.base_url, ...backups]);
      if (urls.length) {
        return { ok: true, kind: 'audio', ext: 'm4a', urls, bandwidth: Number(best.bandwidth) || 0 };
      }
    }
  }

  const mp4Res = await getJson(`${base}&fnval=1`, { headers, timeoutMs });
  if (mp4Res.ok) {
    const durl = Array.isArray(mp4Res.data?.durl) ? mp4Res.data.durl : [];
    const urls = uniqueUrls(durl.flatMap((it) => (Array.isArray(it?.url) ? it.url : [it?.url])));
    if (urls.length) return { ok: true, kind: 'video', ext: 'mp4', urls };
  }

  const reason = dashRes.ok
    ? (mp4Res.error || '接口没有返回音频流（可能需要登录或该视频受限）')
    : dashRes.error;
  return { ok: false, error: reason || '没有可用的音频流' };
}

/**
 * 下载到本地。必须带 Referer（B 站 CDN 不带就 403）。
 * urls 可以是数组，会按顺序回退到备用地址。
 */
export async function downloadToFile(urls, destPath, {
  maxBytes = 30 * 1024 * 1024,
  referer = REFERER,
  timeoutMs = 90000
} = {}) {
  const list = uniqueUrls(Array.isArray(urls) ? urls : [urls]);
  if (!list.length) return { ok: false, error: '下载地址为空' };
  fs.mkdirSync(path.dirname(destPath), { recursive: true });

  let lastError = '';
  for (const url of list) {
    try {
      const res = await requireFetch()(url, {
        headers: { 'User-Agent': UA, Referer: referer || REFERER },
        signal: AbortSignal.timeout(timeoutMs)
      });
      if (res.status !== 200 && res.status !== 206) {
        lastError = `下载被拒（HTTP ${res.status}）—— Referer 可能没生效`;
        continue;
      }
      const ctype = String(res.headers.get('content-type') || '');
      if (/text\/html|application\/json/i.test(ctype)) {
        lastError = `下载到的不是音频（Content-Type: ${ctype}）`;
        continue;
      }
      const bytes = Buffer.from(await res.arrayBuffer());
      if (bytes.length === 0) {
        lastError = '下载内容为空';
        continue;
      }
      if (bytes.length > maxBytes) {
        lastError = `文件 ${(bytes.length / 1048576).toFixed(1)}MB 超过上限 ${Math.round(maxBytes / 1048576)}MB`;
        continue;
      }
      fs.writeFileSync(destPath, bytes);
      return { ok: true, bytes: bytes.length };
    } catch (error) {
      lastError = error?.message ? String(error.message) : String(error);
    }
  }
  return { ok: false, error: lastError || '下载失败' };
}
