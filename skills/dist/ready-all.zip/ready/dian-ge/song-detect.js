// 歌曲识别：判断一条 B 站搜索结果"到底是不是一首歌"。
//
// 为什么需要它：只按标题关键词扣分不可靠。「点歌 生日快乐」会搜到刺绣教程、
// 游戏攻略；「点歌 起风了」会搜到 64 分钟循环歌单和 MAD。发错一次，群里听到的
// 就是一段教程人声/游戏解说。
//
// 判据（全部来自 B 站返回的元数据，不额外烧模型 token）：
//   ① 分区 typename —— 音乐综合 / MV / 音乐现场 / 翻唱 / 原创音乐 / 演奏 / 乐评盘点
//   ② 标签 tag      —— 歌曲 / 无损 / 高音质 / OST / 原唱 / 动态歌词 …
//   ③ 标题结构      —— 《歌名》、歌手-歌名、无损/官方/完整版 …
//   ④ 时长          —— 45 秒 ~ 10 分钟才像一首歌
//   ⑤ 反向信号      —— 教程 / 谱 / 伴奏 / 解说 / 游戏 / 电台 / 手工 / 鬼畜 …
//
// 输出 ok=false 时调用方**不要发**，宁可让模型回一句"没找到歌曲版本"。
// 这比"硬塞一段不是歌的音频"体验好得多。

const MUSIC_TYPES = new Set([
  '音乐综合', 'MV', '音乐现场', '翻唱', '原创音乐', '演奏',
  '乐评盘点', 'VOCALOID·UTAU', '电音', '说唱', '音乐剧', '音乐', '音乐选集'
]);

/** 明显不是"一首歌"的分区（命中会加重反向分）。 */
const NON_MUSIC_TYPE_RE = /手工|游戏|电竞|搞笑|动画|特摄|社科|法律|校园学习|科学|科普|财经|影视|电影|电视剧|纪录片|综艺|相声|脱口秀|亲子|美食|健身|时尚|汽车|三农|动物|知识|科技|体育|篮球|足球|数码|家居|资讯|新闻|时政|军事|历史|情感|美妆|穿搭|摄影|绘画|设计|编程|教程|教学|舞蹈|日常|生活/i;

const MUSIC_TAG_WORDS = [
  '音乐', '歌曲', '歌单', 'mv', '无损', '高音质', 'hi-res', 'hires', 'hifi',
  '听歌', '华语音乐', '流行', '原唱', 'ost', '主题曲', '单曲循环', '动态歌词',
  '歌词', '翻唱', '现场', '演唱会', '演奏', '纯音乐', 'bgm', '儿歌', '说唱',
  '电音', '古风', '民谣', '摇滚', '爵士', '古典', '音乐选集', '歌曲名'
];

const NON_MUSIC_TAG_WORDS = [
  '教程', '教学', '谱', '鼓谱', '吉他谱', '钢琴谱', '指弹', '乐理', '考级',
  '伴奏', '游戏', '攻略', '解说', '测评', '开箱', '学习', '考试', '法考',
  '考研', '高考', '英语', '单词', '手工', '美食', '健身', '瑜伽', '冥想',
  '白噪音', '助眠', '音效', '相声', '小品', '脱口秀', '演讲', '访谈', '播客',
  '有声书', '广播剧', '新闻', '时政', '历史', '科普', '鬼畜',
  '搞笑', '沙雕', '整活', '挑战', '采访', '街访', 'reaction', '影视', '电影',
  '电视剧', '综艺', '亲子', '萌娃', '刺绣'
];

const MUSIC_TITLE_RE = /无损|hi-?res|高音质|音质|完整版|官方|mv|4k|动态歌词|歌词版|纯享|收藏级|原版|现场版|演唱会|歌曲|单曲|原唱|作词|作曲|演唱|专辑|ost|主题曲/i;

/** 标题里出现这些词，基本可以确定不是"一首歌"（教程/谱子/解说/相声…），直接重罚。 */
const HARD_NON_TITLE_RE = /教程|教学|学会弹|学会唱|教你|教唱|入门|零基础|速成|保姆级|从零|指法|手型|简谱|五线谱|跟练|学钢琴|学吉他|学唱歌|学琴|谱子|歌谱|乐谱|曲谱|伴奏|鼓谱|吉他谱|钢琴谱|指弹教学|乐理|考级|解说|影评|解析|攻略|实况|录播|直播回放|vlog|吃播|探店|做饭|菜谱|健身|减肥|瑜伽|冥想|白噪音|助眠|音效|测评|开箱|对比|科普|鬼畜|恶搞|沙雕|整活|街访|采访|reaction|相声|小品|脱口秀|演讲|访谈|播客|有声书|广播剧|手工|刺绣|亲子|萌娃|法考|考研|高考|英语|单词|课程|网课|讲座/i;

/** 标题里只是"话题"、不一定不是歌（歌名本身就可能叫《游戏》《故事》《挑战》），轻罚。 */
const SOFT_NON_TITLE_RE = /游戏|历史|政治|军事|财经|股票|新闻|时政|故事|小说|挑战/i;

/** 标签里出现这些词，基本可以确定不是"一首歌"（伴奏/谱子/教程/考试）。 */
const HARD_NON_TAG_RE = /伴奏|教程|教学|谱|鼓谱|吉他谱|钢琴谱|指弹|解说|游戏|攻略|法考|考试|相声|小品|脱口秀|有声书|广播剧|课程|网课/i;

function splitTags(raw) {
  return String(raw ?? '')
    .split(/[,，、|]/)
    .map((x) => x.trim().toLowerCase())
    .filter(Boolean);
}

function safeText(value) {
  return String(value ?? '').trim();
}

/**
 * 给一条搜索结果打分并判定。
 * @param {object} item { bvid,title,author,durationSec,play,typename,tag,description }
 * @returns {{ok:boolean,score:number,music:number,nonMusic:number,reasons:string[]}}
 */
export function analyzeSong(item) {
  const title = safeText(item?.title);
  const type = safeText(item?.typename);
  const durationSec = Number(item?.durationSec) || 0;
  const reasons = [];

  let music = 0;
  let nonMusic = 0;

  // ① 分区
  if (MUSIC_TYPES.has(type)) {
    music += 10;
    reasons.push(`分区:${type}`);
  } else {
    if (/音乐教学|音乐教程/.test(type)) {
      nonMusic += 10;
      reasons.push(`分区:${type}(教学)`);
    } else if (type) {
      nonMusic += 3;
    }
    if (NON_MUSIC_TYPE_RE.test(type)) {
      nonMusic += 3;
      reasons.push(`非音乐分区:${type}`);
    }
    if (/电台/.test(type)) {
      nonMusic += 2;
      reasons.push('分区:电台');
    }
  }

  // ② 标签
  const tags = splitTags(item?.tag);
  let musicTagHits = 0;
  let nonTagHits = 0;
  let hardTagHits = 0;
  for (const tag of tags) {
    if (MUSIC_TAG_WORDS.some((w) => tag.includes(w)) || /歌$|曲$/.test(tag)) {
      musicTagHits += 1;
    }
    if (NON_MUSIC_TAG_WORDS.some((w) => tag.includes(w))) nonTagHits += 1;
    if (HARD_NON_TAG_RE.test(tag)) hardTagHits += 1;
  }
  if (musicTagHits) {
    music += Math.min(8, musicTagHits * 2);
    reasons.push(`音乐标签×${musicTagHits}`);
  }
  if (nonTagHits) {
    nonMusic += Math.min(10, nonTagHits * 2);
    reasons.push(`非音乐标签×${nonTagHits}`);
  }
  if (hardTagHits) {
    nonMusic += Math.min(24, hardTagHits * 12);
    reasons.push(`硬否决标签×${hardTagHits}`);
  }

  // ③ 标题
  const quoteCount = (title.match(/《[^》]{1,30}》/g) || []).length;
  if (quoteCount) {
    music += Math.min(4, quoteCount * 3);
    reasons.push('标题带《歌名》');
  }
  if (MUSIC_TITLE_RE.test(title)) {
    music += 3;
    reasons.push('标题像歌');
  }
  if (HARD_NON_TITLE_RE.test(title)) {
    // 教程/谱子/伴奏/解说：标题已经明说了不是歌，直接重罚，
    // 不能靠"分区是音乐"或"播放量高"翻盘。
    nonMusic += 20;
    reasons.push('标题像非歌曲');
  } else if (SOFT_NON_TITLE_RE.test(title)) {
    // 歌名本身可能叫《游戏》《故事》，只轻罚，不否决
    nonMusic += 6;
    reasons.push('标题偏非歌曲话题');
  }
  if (/合集|串烧|循环歌单|歌单/.test(title)) {
    nonMusic += 3;
    reasons.push('合集/歌单');
  }
  if (/\bai\b|ai音乐|ai mv|ai翻唱/i.test(title)) {
    // AI 生成/翻唱版通常不是用户点的那首歌，排序上压下去（不硬拒）
    nonMusic += 10;
    reasons.push('AI 版本');
  } else if (/改编|鬼畜/i.test(title)) {
    nonMusic += 2;
  }

  // ④ 时长：一首歌通常 45 秒 ~ 10 分钟；超过 15 分钟基本是合集/直播回放
  let hardDuration = false;
  if (durationSec >= 45 && durationSec <= 600) {
    music += 2;
  } else if (durationSec > 0 && durationSec < 45) {
    nonMusic += 4;
    reasons.push('时长过短');
  } else if (durationSec > 900) {
    nonMusic += 20;
    hardDuration = true;
    reasons.push('超长合集/回放');
  } else if (durationSec > 600) {
    nonMusic += 8;
    reasons.push('时长过长');
  }

  // ⑤ 简介补强
  const desc = safeText(item?.description);
  if (/作词|作曲|演唱|原唱|专辑|歌曲|歌词|音乐/i.test(desc)) music += 2;
  if (/教程|课程|讲解|攻略|法考|考试/i.test(desc)) nonMusic += 3;

  // ⑥ 播放量只做排序，不决定是不是歌
  const playScore = Math.log10((Number(item?.play) || 0) + 1) * 1.5;
  const score = music * 2 - nonMusic * 1.5 + playScore;

  const ok = !hardDuration && music >= 8 && music > nonMusic + 2;
  if (!ok) reasons.push(`判定非歌曲(music=${music}, non=${nonMusic})`);

  return { ok, score, music, nonMusic, reasons };
}

/** 过滤 + 排序：只返回判定为歌曲的候选。 */
export function pickSongs(items, keyword = '') {
  const kw = safeText(keyword).toLowerCase().replace(/\s+/g, '');
  return (Array.isArray(items) ? items : [])
    .map((item) => ({ ...item, ...analyzeSong(item) }))
    .filter((item) => item.ok)
    .map((item) => {
      const title = safeText(item.title).toLowerCase();
      const hit = kw && (title.includes(kw) || kw.split(/\s+/).filter(Boolean).every((p) => title.includes(p)));
      return { ...item, score: item.score + (hit ? 2 : 0) };
    })
    .sort((a, b) => b.score - a.score);
}

/** 给日志/排障用的一句话。 */
export function explainSong(item) {
  const a = analyzeSong(item);
  return `${a.ok ? '歌曲' : '非歌曲'}｜music=${a.music} non=${a.nonMusic}｜${a.reasons.join(' / ')}`;
}
