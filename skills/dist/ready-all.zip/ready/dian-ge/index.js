// 点歌（LLM 型技能）
//
// 群友说「点歌 晴天」→ 模型调用本技能注册的 dian_ge 工具：
//   ① B 站搜索，按"像不像一首歌"排序（不是简单取第一条）
//   ② 取 DASH 纯音频（m4a）并下载
//   ③ 超过 60 秒的歌解码成 WAV 后精确截断（QQ 语音条上限）
//   ④ 用 ctx.sender.sendMedia 发 record 语音条（失败退回音频文件）
//   ⑤ 发视频封面图
//
// 为什么必须是技能（skills/）而不是插件（plugins/）：
//   这个项目只有工具执行上下文 ctx 里才有 sender / chatKey / onebot
//   （orchestrator.js 的 ctx）。插件的 5 个钩子都不带 sender，做不成"发语音"。
//
// 触发：除了模型看工具说明自己判断，本技能还会在 activate 时把「点歌」写进
//   store.keywords（关键词触发），并在 before-llm-messages 里对本轮点歌请求做
//   一次强注入 —— 否则响应档位是"随机命中"时，点歌会被随机忽略。

import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { pathToFileURL } from 'node:url';
import { getConfig, updateConfig } from '../../src/config.js';
import {
  setFetch, searchVideos, fetchVideoInfo, fetchAudioSource, downloadToFile, formatDuration
} from './bili.js';
import { pickSongs, analyzeSong, explainSong } from './song-detect.js';
import { decodeToWav, trimWav, cleanupFiles } from './audio.js';

const INJECT_TAG = '【点歌请求】';
const UNREAD_MARKER = '【未读信息】';
const CORE_SECTION_RE = /\n【(?:记忆|已读信息|新已读信息|未读信息|新加入成员|当前时间|角色设定|表情包|引导说明)/;
const TEMP_DIR_NAME = 'qq-agent-dian-ge';

let cfg = () => ({});
let log = () => {};
let warn = () => {};
let toolId = 'dian-ge__dian_ge';

/** chatKey → 上次点歌时间（防连点）。 */
const cooldown = new Map();
/** sessionId → 本轮已经成功发过语音的时间（用来拦后续多余的 send_message）。 */
const sentTurns = new Map();

export function setup(api) {
  cfg = typeof api?.config === 'function' ? api.config : () => ({});
  log = typeof api?.log === 'function' ? api.log : () => {};
  warn = typeof api?.warn === 'function' ? api.warn : log;
  if (typeof api?.fetch === 'function') setFetch(api.fetch);

  toolId = api.registerTool({
    id: 'dian_ge',
    name: '点歌（B站音频+封面）',
    description: '点歌：群友说「点歌 <歌名>」「点一首 <歌名>」时调用。去 B 站搜索一首歌，'
      + '自动识别并跳过教程、解说、电台、谱子等非歌曲视频，'
      + '把音频做成一个语音条发到当前会话（默认整首；QQ 拒收时自动回退 60 秒片段），并附一张视频封面。'
      + 'keyword 传歌名（可带歌手，如「晴天 周杰伦」）；如果群友直接给了 B 站 BV 号，用 bvid。'
      + '不要用它查非歌曲内容，也不要编造没搜到的歌。',
    category: 'media',
    icon: '🎵',
    parameters: {
      type: 'object',
      properties: {
        keyword: {
          type: 'string',
          description: '歌名，可带歌手，例如「晴天」「晴天 周杰伦」'
        },
        bvid: {
          type: 'string',
          description: '可选：群友直接给了 B 站 BV 号时填这里，填了就跳过搜索'
        }
      },
      required: []
    },
    execute: doDianGe
  });

  const s = readSettings();
  log(`点歌技能已加载（工具 ${toolId}；整首=${s.fullSongVoice ? '开' : '关'}；回退片段=${s.voiceMaxSeconds}s；歌曲识别=${s.strictSongCheck ? '严格' : '宽松'}）`);
}

/** 纯同步自检：不做 IO，避免拖慢启动。 */
export function available() {
  return { ok: true };
}

/** 每次启动/热重载都会跑：把「点歌」补进关键词触发列表（只增不删）。 */
export function activate() {
  ensureTriggerKeyword();
}

export function deactivate() {
  // 没有定时器/监听器需要收尾；清掉内存态即可。
  cooldown.clear();
  sentTurns.clear();
}

export function dispose() {
  deactivate();
}

export const hooks = {
  /**
   * 本轮消息里出现「点歌 X」时，在最后一条 user 消息末尾追加硬指令。
   * 只加指令，不改存档；模型仍然拥有最终决定权，但不会再"看见了当没看见"。
   */
  'before-llm-messages': async (payload) => {
    try {
      injectSongRequest(payload);
    } catch (error) {
      warn(`点歌指令注入失败（本次不注入）：${describe(error)}`);
    }
  },

  /**
   * 语音条+封面已经发出后，拦掉多余的 send_message。
   * 不然模型很容易再补一句"点好了"——用户要的是语音条，不是文字刷屏。
   */
  'before-tool': async (payload) => {
    if (payload?.toolName !== 'send_message') return;
    const id = String(payload?.session?.id || '');
    const at = sentTurns.get(id);
    if (!at) return;
    if (Date.now() - at > 10 * 60 * 1000) {
      sentTurns.delete(id);
      return;
    }
    return { block: true, reason: '语音条和封面已经发出，这一轮不要再补文字，直接结束。' };
  }
};

// ── 主流程 ────────────────────────────────────────────────────────────────

async function doDianGe(ctx, args) {
  const chatKey = String(ctx?.chatKey || '');
  if (!/^(group|private):\S+$/.test(chatKey)) {
    return fail('拿不到当前会话信息，先别点歌。');
  }
  if (!ctx?.sender || typeof ctx.sender.sendMedia !== 'function') {
    return fail('当前环境没有媒体发送能力，先别点歌。');
  }

  const s = readSettings();
  const keyword = cleanKeyword(args?.keyword);
  const bvid = String(args?.bvid || '').trim();
  if (!keyword && !bvid) {
    return fail('缺少歌名：把群友想听的歌名放进 keyword（例如「晴天 周杰伦」）。');
  }

  const left = cooldownLeft(chatKey, s.cooldownSec);
  if (left > 0) {
    return fail(`刚点过歌，${Math.ceil(left / 1000)} 秒后才能再点。`);
  }

  markCooldown(chatKey);
  const tempFiles = [];
  let ok = false;

  try {
    // ① 找视频
    let info = null;
    if (bvid) {
      const r = await fetchVideoInfo(bvid);
      if (!r.ok) return fail(`这个 BV 号取不到视频：${r.error}`);
      info = r;
    } else {
      // 只搜用户给的词。**不要**自动加“歌曲/无损”再搜：
      // 「三国演义」会搜出《曹操》、《钢琴教程》会搜出钢琴曲——那是另一首歌，
      // 比"没找到"更糟。没有可靠歌曲就直接拒绝，让用户补歌手名或给 BV。
      const search = await searchVideos(keyword, { limit: 20 });
      if (!search.ok) return fail(`B 站搜索失败：${search.error}`);

      const pool = search.items.filter((it) => it.durationSec >= 40 && it.durationSec <= s.maxDurationSec);
      const ranked = s.strictSongCheck ? pickSongs(pool, keyword) : rankCandidates(pool, keyword);

      if (!ranked.length) {
        return fail(`没找到像「${keyword}」这首歌的版本：搜到的多是教程、解说、电台、游戏之类的非歌曲内容。`
          + `换个写法（比如加上歌手名），或者直接把 B 站 BV 号给我。`);
      }

      // 搜索结果的分区/标签偶尔和详情不一致：取前几个详情，用详情再复核一次。
      for (const candidate of ranked.slice(0, 6)) {
        const detail = await fetchVideoInfo(candidate.bvid);
        if (!detail.ok) continue;
        const merged = {
          ...candidate,
          ...detail,
          tag: candidate.tag,
          typename: detail.typename || candidate.typename
        };
        if (s.strictSongCheck && !analyzeSong(merged).ok) {
          log(`跳过非歌曲候选：${detail.title}（${explainSong(merged)}）`);
          continue;
        }
        info = detail;
        break;
      }
      if (!info) return fail(`搜到了「${keyword}」，但前几个都不是歌曲（教程/解说/电台之类）。换一个写法或直接给 BV 号。`);
    }

    if (info.durationSec && info.durationSec > s.maxDurationSec) {
      return fail(`《${info.title}》时长 ${formatDuration(info.durationSec)}，超过上限 `
        + `${formatDuration(s.maxDurationSec)}，换一个短一点的版本。`);
    }

    // ② 取音频直链并下载
    const source = await fetchAudioSource(info.bvid, info.cid);
    if (!source.ok) return fail(`《${info.title}》取音频失败：${source.error}`);

    const dir = ensureTempDir();
    const stamp = `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 6)}`;
    const rawPath = path.join(dir, `${info.bvid}-${stamp}.${source.ext}`);
    tempFiles.push(rawPath);

    const download = await downloadToFile(source.urls, rawPath, {
      maxBytes: s.maxAudioMB * 1024 * 1024,
      referer: `https://www.bilibili.com/video/${info.bvid}`,
      timeoutMs: 90000
    });
    if (!download.ok) return fail(`《${info.title}》音频下载失败：${download.error}`);

    // ③ 准备语音文件：默认整首；只有「关掉整首」或「整首被 QQ 拒收」时才截片段
    let voicePath = rawPath;
    let voiceKind = 'full';
    let clipSeconds = 0;
    let clipPath = '';
    const needClip = info.durationSec > s.voiceMaxSeconds + 1;

    const buildClip = async () => {
      if (clipPath) return clipPath;
      const wavPath = path.join(dir, `${info.bvid}-${stamp}.wav`);
      tempFiles.push(wavPath);
      const decoded = await decodeToWav(rawPath, wavPath);
      if (!decoded.ok) {
        log(`音频解码失败，无法生成 ${s.voiceMaxSeconds} 秒片段：${decoded.error}`);
        return '';
      }
      const cutPath = path.join(dir, `${info.bvid}-${stamp}-cut.wav`);
      tempFiles.push(cutPath);
      const trimmed = trimWav(wavPath, cutPath, s.voiceMaxSeconds);
      if (!trimmed.ok || !trimmed.trimmed) {
        log(`WAV 截断失败，无法生成片段：${trimmed.error || '原曲本来就不长'}`);
        return '';
      }
      clipPath = cutPath;
      clipSeconds = Math.round(trimmed.seconds);
      return clipPath;
    };

    if (!s.fullSongVoice && needClip) {
      const clip = await buildClip();
      if (clip) {
        voicePath = clip;
        voiceKind = 'clip';
      }
    }

    // ④ 发语音条：整首优先 → 整首被拒回退片段 → 还不行就发音频文件
    const dedupe = `dian-ge:${info.bvid}:${Math.floor(Date.now() / 60000)}`;
    const sendRecord = (filePath, key) => ctx.sender.sendMedia(
      chatKey,
      [{ type: 'record', data: { file: pathToFileURL(filePath).href } }],
      { label: `[点歌] ${info.title}`, dedupeKey: key }
    );

    let delivery = 'record';
    let sent = false;
    try {
      await sendRecord(voicePath, voiceKind === 'clip' ? `${dedupe}:clip` : dedupe);
      sent = true;
    } catch (fullError) {
      log(`整首语音条发送失败：${describe(fullError)}`);
      // 只有"本来想发整首"时才值得回退截断；已经发片段还失败就直接走文件。
      if (s.fullSongVoice && voiceKind === 'full' && needClip) {
        const clip = await buildClip();
        if (clip) {
          try {
            await sendRecord(clip, `${dedupe}:clip`);
            voicePath = clip;
            voiceKind = 'clip';
            sent = true;
          } catch (clipError) {
            log(`回退片段发送也失败：${describe(clipError)}`);
          }
        }
      }
    }

    if (!sent) {
      delivery = 'file';
      try {
        const ext = path.extname(voicePath).slice(1) || source.ext || 'm4a';
        await ctx.sender.sendMedia(chatKey, [{
          type: 'file',
          data: { file: pathToFileURL(voicePath).href, name: `${safeFileName(info.title)}.${ext}` }
        }], {
          label: `[点歌文件] ${info.title}`,
          dedupeKey: `${dedupe}:file`
        });
      } catch (fileError) {
        return fail(`点歌音频发送失败：${describe(fileError)}`);
      }
    }

    // ⑤ 发封面
    let coverSent = false;
    if (s.sendCover && info.pic) {
      const coverPath = path.join(dir, `${info.bvid}-${stamp}-cover.jpg`);
      tempFiles.push(coverPath);
      const cover = await downloadToFile([info.pic], coverPath, {
        maxBytes: 8 * 1024 * 1024,
        referer: `https://www.bilibili.com/video/${info.bvid}`,
        timeoutMs: 30000
      });
      if (cover.ok) {
        try {
          await ctx.sender.sendImage(chatKey, { file: coverPath }, { note: `点歌封面：${info.title}` });
          coverSent = true;
        } catch (error) {
          log(`封面发送失败：${describe(error)}`);
        }
      } else {
        log(`封面下载失败：${cover.error}`);
      }
    }

    markSentTurn(ctx?.session?.id);
    ok = true;

    const voiceText = delivery === 'file'
      ? '语音条发送失败，已改发音频文件'
      : (voiceKind === 'clip'
        ? (s.fullSongVoice
          ? `已发语音条（前 ${clipSeconds} 秒；整首被 QQ 拒收后自动回退）`
          : `已发语音条（前 ${clipSeconds} 秒）`)
        : `已发语音条（整首 ${formatDuration(info.durationSec)}）`);

    const summary = [
      `已点歌《${info.title}》`,
      `UP：${info.author || '未知'}｜${formatDuration(info.durationSec)}｜${info.bvid}`,
      voiceText,
      coverSent ? '封面已附上' : '封面没发出去'
    ];
    return {
      content: `${summary.join('；')}。\n`
        + '不要再调用 send_message 复述，也不要点评歌曲；直接结束这一轮。'
        + (voiceKind === 'clip' && s.fullSongVoice
          ? '\n（整首语音条被 QQ 拒收，已自动回退到能播放的片段。）'
          : '')
    };
  } catch (error) {
    log(`点歌异常：${describe(error)}`);
    return fail(`点歌失败：${describe(error)}`);
  } finally {
    cleanupFiles(tempFiles);
    if (!ok) clearCooldown(chatKey);
  }
}

// ── 选歌排序 ──────────────────────────────────────────────────────────────

/**
 * 搜索结果排序：播放量打底，标题像"歌"的加分，教程/翻唱/伴奏扣分。
 * 不做语义模型调用 —— 这一步零 token，排序稳定可解释。
 */
function rankCandidates(items, keyword) {
  const kw = String(keyword || '').toLowerCase().replace(/\s+/g, '');
  return items.map((it) => {
    const title = String(it.title || '').toLowerCase();
    let score = Math.log10((Number(it.play) || 0) + 1) * 3;

    if (kw) {
      const parts = kw.split(/\s+/).filter(Boolean);
      if (parts.length && parts.every((p) => title.includes(p))) score += 2;
      else if (title.includes(kw)) score += 1;
    }
    if (/(无损|hi.?res|高音质|音质|音频|完整版)/i.test(it.title)) score += 4.5;
    if (/(官方|mv|4k|8k)/i.test(it.title)) score += 1.5;
    if (/(教程|教学|钢琴|吉他|尤克里里|谱|伴奏|翻唱|cover|鬼畜|reaction|解说|合集|串烧|dj|remix|剪辑|混剪)/i.test(it.title)) score -= 8;
    if (it.durationSec < 30) score -= 6;
    if (it.durationSec > 720) score -= 3;

    return { ...it, score };
  }).sort((a, b) => b.score - a.score);
}

// ── 触发注入 ──────────────────────────────────────────────────────────────

function injectSongRequest(payload) {
  const messages = payload?.messages;
  if (!Array.isArray(messages) || !messages.length) return;
  const msg = messages[messages.length - 1];
  if (!msg || msg.role !== 'user' || typeof msg.content !== 'string') return;
  if (msg.content.includes(INJECT_TAG)) return;

  const tail = unreadTail(msg.content);
  if (!tail) return;

  const req = parseSongRequest(tail);
  if (!req.matched) return;

  if (!req.name) {
    msg.content += `\n\n${INJECT_TAG}群友想点歌，但没说歌名。`
      + '请用 send_message 问一句"想听什么歌"，不要调用点歌工具。';
    return;
  }

  msg.content += `\n\n${INJECT_TAG}群友点了《${req.name}》。`
    + `请立即调用 ${toolId} 工具，参数 {"keyword":${JSON.stringify(req.name)}}。\n`
    + '硬规矩：① 必须调用工具，不要自己编歌名，也不要推荐别的歌；'
    + '② 工具会直接发语音条和封面，不要再用 send_message 发文字；'
    + '③ 调用完立即结束这一轮。';
}

function unreadTail(content) {
  const i = content.lastIndexOf(UNREAD_MARKER);
  if (i < 0) return '';
  const rest = content.slice(i + UNREAD_MARKER.length);
  const cut = rest.search(CORE_SECTION_RE);
  return cut >= 0 ? rest.slice(0, cut) : rest;
}

/** 从"点歌 晴天"里抠出歌名；只认本轮未读，避免拿历史聊天里的点歌反复触发。 */
function parseSongRequest(tail) {
  const m = /(点歌|点一首|来一首|放一首)\s*[:：,，、]?\s*([^\n\r]{0,60})/.exec(tail);
  if (!m) return { matched: false, name: '' };

  let name = String(m[2] || '')
    .replace(/^[\s《》“”"'「」【】]+/, '')
    .replace(/[\s》”"'」】]+$/, '');
  name = name.split(/[，,。.!！?？~～;；:：]/)[0] || '';
  name = name.replace(/(谢谢|谢啦|吧|呗|呀|啊|拜托|麻烦了|可以吗|好不好).*$/, '').trim();

  return { matched: true, name: name.slice(0, 50) };
}

// ── 设置 / 小工具 ─────────────────────────────────────────────────────────

function readSettings() {
  const c = cfg() || {};
  return {
    fullSongVoice: c.fullSongVoice !== false,
    voiceMaxSeconds: num(c.voiceMaxSeconds, 60, 10, 120),
    strictSongCheck: c.strictSongCheck !== false,
    sendCover: c.sendCover !== false,
    maxDurationSec: num(c.maxDurationSec, 600, 30, 1800),
    maxAudioMB: num(c.maxAudioMB, 30, 1, 80),
    cooldownSec: num(c.cooldownSec, 20, 0, 600),
    autoAddKeyword: c.autoAddKeyword !== false,
    triggerWords: str(c.triggerWords, '点歌,点一首')
  };
}

function ensureTriggerKeyword() {
  const s = readSettings();
  if (!s.autoAddKeyword) return;
  try {
    const words = splitKeywords(s.triggerWords);
    if (!words.length) return;
    const current = getConfig()?.store?.keywords;
    const list = Array.isArray(current) ? current.map((x) => String(x)).filter(Boolean) : [];
    const missing = words.filter((w) => !list.includes(w));
    if (!missing.length) return;
    updateConfig({ store: { keywords: [...list, ...missing] } });
    log(`已把「${missing.join('」「')}」加入关键词触发列表（设置→聊天 里可改）`);
  } catch (error) {
    warn(`自动添加点歌关键词失败：${describe(error)}`);
  }
}

function cleanKeyword(raw) {
  let s = String(raw ?? '').trim();
  if (!s) return '';
  s = s.replace(/^(点歌|点一首|来一首|放一首)\s*[:：,，]?\s*/, '');
  s = s.replace(/[\u200b-\u200f\u2060\ufeff]/g, '').replace(/\s+/g, ' ').trim();
  return s.slice(0, 60);
}

function splitKeywords(raw) {
  const out = [];
  const seen = new Set();
  for (const piece of String(raw ?? '').split(/[,，、;；|]+/)) {
    const kw = piece.trim();
    if (!kw || seen.has(kw)) continue;
    seen.add(kw);
    out.push(kw);
  }
  return out;
}

function ensureTempDir() {
  const dir = path.join(os.tmpdir(), TEMP_DIR_NAME);
  fs.mkdirSync(dir, { recursive: true });
  return dir;
}

function safeFileName(raw) {
  return String(raw || '点歌')
    .replace(/[\\/:*?"<>|\r\n]+/g, '_')
    .replace(/\s+/g, ' ')
    .trim()
    .slice(0, 60) || '点歌';
}

function cooldownLeft(chatKey, seconds) {
  const at = cooldown.get(chatKey);
  if (!at) return 0;
  return Math.max(0, at + seconds * 1000 - Date.now());
}

function markCooldown(chatKey) {
  cooldown.set(chatKey, Date.now());
  if (cooldown.size > 200) {
    for (const [k, v] of cooldown) {
      if (Date.now() - v > 10 * 60 * 1000) cooldown.delete(k);
    }
  }
}

function clearCooldown(chatKey) {
  cooldown.delete(chatKey);
}

function markSentTurn(sessionId) {
  const id = String(sessionId || '');
  if (!id) return;
  sentTurns.set(id, Date.now());
  if (sentTurns.size > 200) {
    for (const [k, v] of sentTurns) {
      if (Date.now() - v > 10 * 60 * 1000) sentTurns.delete(k);
    }
  }
}

function fail(content) {
  return { content, isError: true };
}

function describe(error) {
  return error?.message ? String(error.message) : String(error);
}

function num(value, fallback, min, max) {
  const n = Number(value);
  if (!Number.isFinite(n)) return fallback;
  return Math.min(max, Math.max(min, n));
}

function str(value, fallback) {
  const s = String(value ?? '').trim();
  return s || fallback;
}
