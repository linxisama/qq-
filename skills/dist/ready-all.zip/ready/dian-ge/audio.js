// 音频处理：把 B 站 m4a 解码成 WAV，再精确截到指定秒数。
//
// 为什么要截：QQ 普通用户的语音条上限约 60 秒，整首 3~5 分钟的歌直接发，
// 客户端可能拒收/只显示 0:00。截成 60 秒的副歌片段才是真正能播的"语音条"。
//
// 为什么用 SnowLuma 自带的 ffmpeg addon：
//   · 应用里没有独立的 ffmpeg.exe，只有 snowluma/native/ffmpeg/*.node；
//   · 它导出的 decodeAudioToFmt 能把 m4a 解成 WAV（实测 270 秒的歌 123ms 解完）；
//   · 截断在 WAV PCM 上做，纯 JS 改字节即可，不需要重新编码，也不会走音。
//
// 整条链路都有兜底：addon 缺失/解码失败 → 调用方直接发原始音频，不会哑火。

import fs from 'node:fs';
import path from 'node:path';
import { createRequire } from 'node:module';
import { fileURLToPath } from 'node:url';

const HERE = path.dirname(fileURLToPath(import.meta.url));

let addon;
let addonError = '';
let addonTried = false;

/** 懒加载 ffmpeg addon；失败只记原因，不抛错（调用方会退化成"发完整音频"）。 */
export function loadAddon() {
  if (addonTried) return addon;
  addonTried = true;
  const name = `ffmpegAddon.${process.platform}.${process.arch}.node`;
  const candidates = [
    path.resolve(HERE, '../../snowluma/native/ffmpeg', name),
    path.resolve(HERE, '../../../snowluma/native/ffmpeg', name)
  ];
  for (const file of candidates) {
    try {
      if (!fs.existsSync(file)) continue;
      const require = createRequire(path.join(HERE, 'index.js'));
      addon = require(file);
      if (addon && typeof addon.decodeAudioToFmt === 'function') return addon;
      addon = null;
      addonError = '音频组件缺少 decodeAudioToFmt';
    } catch (error) {
      addon = null;
      addonError = String(error?.message ?? error);
    }
  }
  if (!addon && !addonError) addonError = `找不到音频组件：${name}`;
  return addon;
}

/** m4a/mp4/mp3 → wav（16bit PCM）。 */
export async function decodeToWav(inputPath, outputPath) {
  const a = loadAddon();
  if (!a) return { ok: false, error: addonError || '音频组件不可用' };
  try {
    fs.rmSync(outputPath, { force: true });
    const r = await a.decodeAudioToFmt(inputPath, outputPath, 'wav');
    if (!r?.result || !fs.existsSync(outputPath)) {
      return { ok: false, error: '音频解码没有产出文件' };
    }
    return { ok: true, sampleRate: Number(r.sampleRate) || 0, channels: Number(r.channels) || 0 };
  } catch (error) {
    return { ok: false, error: String(error?.message ?? error) };
  }
}

/**
 * 把 WAV 截到前 seconds 秒（PCM 字节级截断，不重编码）。
 * 保留原采样率/声道/位深，只改 RIFF 与 data 的长度字段。
 *
 * @returns {{ok:boolean, seconds?:number, trimmed?:boolean, error?:string}}
 */
export function trimWav(inputPath, outputPath, seconds) {
  let buf;
  try {
    buf = fs.readFileSync(inputPath);
  } catch (error) {
    return { ok: false, error: `读不到 WAV：${error?.message ?? error}` };
  }
  if (buf.length < 44 || buf.toString('ascii', 0, 4) !== 'RIFF' || buf.toString('ascii', 8, 12) !== 'WAVE') {
    return { ok: false, error: '不是有效的 WAV 文件' };
  }

  let offset = 12;
  let fmt = null;
  let dataOffset = -1;
  let dataSize = 0;
  while (offset + 8 <= buf.length) {
    const id = buf.toString('ascii', offset, offset + 4);
    const size = buf.readUInt32LE(offset + 4);
    if (id === 'fmt ' && size >= 16) {
      fmt = {
        channels: buf.readUInt16LE(offset + 10),
        sampleRate: buf.readUInt32LE(offset + 12),
        byteRate: buf.readUInt32LE(offset + 16),
        blockAlign: buf.readUInt16LE(offset + 20),
        bits: buf.readUInt16LE(offset + 22)
      };
    }
    if (id === 'data') {
      dataOffset = offset;
      dataSize = size;
      break;
    }
    offset += 8 + size + (size % 2);
  }

  if (!fmt || !fmt.byteRate || !fmt.blockAlign) return { ok: false, error: 'WAV 的 fmt 块不完整' };
  if (dataOffset < 0) return { ok: false, error: 'WAV 缺少 data 块' };

  const wanted = Math.max(1, Math.floor(Number(seconds) || 60)) * fmt.byteRate;
  const aligned = wanted - (wanted % fmt.blockAlign);
  const cut = Math.min(dataSize, aligned);

  if (cut >= dataSize) {
    fs.copyFileSync(inputPath, outputPath);
    return { ok: true, seconds: dataSize / fmt.byteRate, trimmed: false };
  }

  const head = Buffer.from(buf.subarray(0, dataOffset));
  // RIFF size = 整文件字节数 - 8
  head.writeUInt32LE(head.length + 8 + cut - 8, 4);
  const dataHeader = Buffer.alloc(8);
  dataHeader.write('data', 0, 'ascii');
  dataHeader.writeUInt32LE(cut, 4);

  fs.writeFileSync(outputPath, Buffer.concat([head, dataHeader, buf.subarray(dataOffset + 8, dataOffset + 8 + cut)]));
  return { ok: true, seconds: cut / fmt.byteRate, trimmed: true };
}

/** 删除临时文件；失败静默（清理不该反过来影响主流程）。 */
export function cleanupFiles(paths) {
  for (const file of paths || []) {
    if (!file) continue;
    try { fs.rmSync(file, { force: true }); } catch { /* ignore */ }
  }
}
