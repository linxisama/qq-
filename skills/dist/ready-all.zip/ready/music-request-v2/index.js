// 点歌（多平台）：网易云优先 → 酷狗兜底，发封面 + 歌名/歌手/平台链接
//
// 2026-10-19 实测各平台接口：
//   · 网易云搜索   https://music.163.com/api/search/get/web         ✅ 200（无需登录）
//   · 网易云播放URL  /api/song/enhance/player/url                    ✗ 无 cookie 一律 url:null（拿不到音频文件）
//   · 酷狗搜索     https://songsearch.kugou.com/song_search_v2      ✅ 200（无需登录）
//   · QQ音乐搜索    c.y.qq.com / u.y.qq.com musicu                   ✗ 500 / 500001（签名风控）
//   · 酷我          www.kuwo.cn/api/www/search/...                   ✗ "The request is illegal"
//   · 咪咕          m.music.migu.cn/.../scr_search_tag               ✗ 重定向到网页
// 所以：能"直接搜"的只有网易云 + 酷狗；其余平台只能给搜索链接兜底（QQ 里点开自己选）。
// 音频文件拿不到（都要登录/签名），故只发封面 + 链接，不硬造"播放"。
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { DATA_DIR } from '../../src/config.js';

const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36';
const PLATFORM_LABEL = { netease: '网易云音乐', kugou: '酷狗音乐', qq: 'QQ音乐', kuwo: '酷我音乐', migu: '咪咕音乐' };
const HOT_CHART_ID = 3778678;   // 网易云「热歌榜」

const DEFAULTS = { withCover: true, platformOrder: 'netease,kugou', limit: 10, timeoutMs: 15000, maxMB: 8, coverDir: '', officialCard: true, signService: 'http://106.55.0.102:10087/', leadTemplate: '🎵 给你找了《{name}》—— {artists}', songDelivery: 'card+voice', neteaseCookie: '' };

let cfg;
let log;
let warn;
let errorLog;

function S() {
  let cur = {};
  try { cur = cfg?.() || {}; } catch { cur = {}; }
  return { ...DEFAULTS, ...cur };
}

function coverDir() {
  const s = S();
  const dir = s.coverDir && String(s.coverDir).trim()
    ? String(s.coverDir).trim()
    : path.join(DATA_DIR, 'music-covers');
  try { fs.mkdirSync(dir, { recursive: true }); } catch { /* ignore */ }
  return dir;
}

const unescapeHtml = (s) => String(s ?? '')
  .replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>')
  .replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/&#(\d+);/g, (_, n) => String.fromCodePoint(Number(n)));

const norm = (s) => unescapeHtml(s).toLowerCase().replace(/[\s\-_/.,，。·:：（）()【】\[\]「」《》"'!?！？~～]/g, '');

function cookieHeader() {
  const raw = String(S().neteaseCookie || '').trim();
  if (!raw) return '';
  return /MUSIC_U\s*=/.test(raw) ? raw : `MUSIC_U=${raw}`;
}

async function fetchJson(url, { referer = '', timeout = 15000 } = {}) {
  const headers = { 'User-Agent': UA, Accept: 'application/json, text/plain, */*' };
  if (referer) headers.Referer = referer;
  const ck = cookieHeader();
  if (ck && /music\.163\.com/.test(url)) headers.Cookie = ck;
  const res = await fetch(url, { headers, signal: AbortSignal.timeout(timeout) });
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  const text = await res.text();
  try { return JSON.parse(text); } catch {
    // 有些老接口返回 JSONP / 前导注释
    const m = text.match(/\{[\s\S]*\}/);
    if (!m) throw new Error('返回的不是 JSON');
    return JSON.parse(m[0]);
  }
}

// ── 各平台搜索 ────────────────────────────────────────────────────────────

async function searchNetease(kw) {
  const s = S();
  const limit = Math.max(3, Number(s.limit) || 10);
  const timeout = Number(s.timeoutMs) || 15000;
  // ① cloudsearch：字段更全，带封面图（al.picUrl）
  try {
    const url = 'https://music.163.com/api/cloudsearch/pc'
      + `?s=${encodeURIComponent(kw)}&type=1&limit=${limit}&offset=0`;
    const j = await fetchJson(url, { referer: 'https://music.163.com/', timeout });
    const songs = (j?.result?.songs) || [];
    if (songs.length) {
      return songs.map((x) => ({
        platform: 'netease',
        id: String(x.id),
        name: unescapeHtml(x.name || ''),
        artists: (x.ar || x.artists || []).map((a) => unescapeHtml(a.name || '')).filter(Boolean).join(' / ') || '未知歌手',
        album: unescapeHtml(x.al?.name || x.album?.name || ''),
        cover: x.al?.picUrl || x.album?.picUrl || '',
        link: `https://music.163.com/#/song?id=${x.id}`,
        durationMs: Number(x.dt) || Number(x.duration) || 0,
        pop: Number(x.pop) || 0,
        aliases: [...(x.alia || []), ...(x.tns || [])].filter(Boolean)
      }));
    }
  } catch (e) {
    warn(`网易云 cloudsearch 失败，退回旧接口：${e?.message ?? e}`);
  }
  // ② 旧接口（没有封面、且匿名下原唱常被版权过滤，仅作兜底）
  const url = 'https://music.163.com/api/search/get/web?csrf_token=&hlpretag=&hlposttag='
    + `&s=${encodeURIComponent(kw)}&type=1&offset=0&total=true&limit=${limit}`;
  const j = await fetchJson(url, { referer: 'https://music.163.com/', timeout });
  const songs = (j?.result?.songs) || [];
  return songs.map((x) => ({
    platform: 'netease',
    id: String(x.id),
    name: unescapeHtml(x.name || ''),
    artists: (x.artists || []).map((a) => unescapeHtml(a.name || '')).filter(Boolean).join(' / ') || '未知歌手',
    album: unescapeHtml(x.album?.name || ''),
    cover: x.album?.picUrl || '',
    link: `https://music.163.com/#/song?id=${x.id}`,
    durationMs: Number(x.duration) || 0,
    pop: Number(x.pop) || 0,
    aliases: [...(x.alia || []), ...(x.tns || [])].filter(Boolean)
  }));
}

async function searchKugou(kw) {
  const s = S();
  const url = 'https://songsearch.kugou.com/song_search_v2'
    + `?keyword=${encodeURIComponent(kw)}&page=1&pagesize=${Math.max(3, Number(s.limit) || 10)}`;
  const j = await fetchJson(url, { timeout: Number(s.timeoutMs) || 15000 });
  const lists = (j?.data?.lists) || [];
  return lists.map((x) => {
    const hash = String(x.FileHash || '');
    const mixId = x.EMixSongID ? String(x.EMixSongID) : '';
    return {
      platform: 'kugou',
      id: hash || mixId,
      name: unescapeHtml(x.SongName || ''),
      artists: unescapeHtml(x.SingerName || '') || '未知歌手',
      album: unescapeHtml(x.AlbumName || ''),
      cover: x.Image ? String(x.Image).replace('{size}', '400') : '',
      link: mixId ? `https://www.kugou.com/mixsong/${mixId}.html`
        : (hash ? `https://www.kugou.com/song/#hash=${hash}` : 'https://www.kugou.com/'),
      durationMs: (Number(x.Duration) || 0) * 1000
    };
  });
}

const SEARCHERS = { netease: searchNetease, kugou: searchKugou };
const PLATFORM_LINKS = {
  netease: (kw) => `https://music.163.com/#/search/m/?s=${encodeURIComponent(kw)}&type=1`,
  qq: (kw) => `https://y.qq.com/n/ryqq/search?w=${encodeURIComponent(kw)}`,
  kugou: (kw) => `https://www.kugou.com/yy/html/search.html#searchType=song&searchKeyWord=${encodeURIComponent(kw)}`,
  kuwo: (kw) => `https://www.kuwo.cn/search/list?key=${encodeURIComponent(kw)}`,
  migu: (kw) => `https://music.migu.cn/v3/search?keyword=${encodeURIComponent(kw)}`
};

function order() {
  const raw = String(S().platformOrder || 'netease,kugou');
  const list = raw.split(/[,，\s]+/).map((x) => x.trim().toLowerCase()).filter((x) => SEARCHERS[x]);
  return list.length ? [...new Set(list)] : ['netease', 'kugou'];
}

/** 挑最合适的一首：歌名完全匹配 > 前缀 > 包含；带 Live/伴奏/翻唱 的轻微降权。
 *  查询里可以带歌手（「晴天 周杰伦」）：拆成词，歌名命中给分、歌手命中再给分，
 *  这样不会被排在前面的翻唱版抢走（2026-10-19 实测踩过）。 */
function bestMatch(list, kw) {
  const q = norm(kw);
  const tokens = String(kw).split(/\s+/).map(norm).filter(Boolean);
  const first = tokens[0] || q;
  const mentionCover = /翻唱|live|现场|伴奏|dj|remix/i.test(kw);
  let best = list[0] || null;
  let bestScore = -Infinity;
  for (const x of list) {
    const name = norm(x.name);
    const artist = norm(x.artists);
    let sc = 0;
    if (name === q) sc += 120;
    if (first && (name === first)) sc += 80;
    else if (first && name.startsWith(first)) sc += 50;
    else if (first && name.includes(first)) sc += 30;
    for (const t of tokens.slice(1)) {
      if (artist.includes(t)) sc += 60;
      else if (name.includes(t)) sc += 25;
    }
    const aliasList = Array.isArray(x.aliases) ? x.aliases.map(norm) : [];
    if (first && aliasList.some((a) => a === first)) sc += 130;
    else if (first && aliasList.some((a) => a.includes(first) || first.includes(a))) sc += 50;
    if (tokens.length > 1 && artist.includes(q)) sc += 40;
    if (!mentionCover && /live|现场|伴奏|翻自|cover|翻唱|remix|dj/i.test(`${x.name} ${x.album}`)) sc -= 25;
    if (sc > bestScore) { bestScore = sc; best = x; }
  }
  return { song: best, score: bestScore, total: list.length };
}

// ── 只给歌名时优先原唱（2026-10-20 用户要求）──────────────────────────────
const COVER_RE = /翻唱|cover|翻自|深情版|烟嗓版|女声版|男声版|童声|dj版|慢摇|钢琴版|吉他版|伴奏|纯音乐|karaoke|remix|加速版|慢速版|片段|试听/i;

/** 判断一首歌是不是翻唱/搬运用。 */
function coverish(x) {
  const blob = `${x.name} ${x.album}`;
  if (COVER_RE.test(blob)) return true;
  const m = blob.match(/原唱[：:\s]*([^)\]）】]+)/);
  if (m) {
    const who = m[1].trim();
    if (who && !String(x.artists || '').includes(who)) return true;
  }
  return false;
}

/** 用 QQ音乐 smartbox（免签名联想接口）查「歌名 → 原唱歌手」。实测 2026-10-20 可用。 */
async function qqOriginalArtist(name) {
  try {
    const q = encodeURIComponent(name);
    const r = await fetch('https://c.y.qq.com/splcloud/fcgi-bin/smartbox_new.fcg?key=' + q + '&format=json', {
      headers: { 'User-Agent': UA, Referer: 'https://y.qq.com/' },
      signal: AbortSignal.timeout(10000)
    });
    if (!r.ok) return '';
    const j = await r.json();
    const list = (j && j.data && j.data.song && j.data.song.itemlist) || [];
    const want = norm(name);
    for (const x of list) {
      if (norm(x.name) === want && x.singer) return String(x.singer).split('/')[0].trim();
    }
    return '';
  } catch { return ''; }
}
/** 只给歌名且最佳候选像翻唱/热度低时：到**所有平台的候选池**里找一个非翻唱、名字对得上的。 */
function preferOriginal(pools, kw, picked) {
  const tokens = String(kw).split(/\s+/).map(norm).filter(Boolean);
  if (tokens.length > 1) return null;
  if (!picked) return null;
  const pop = Number(picked.pop) || 0;
  const bad = coverish(picked) || (pop < 90 && pop > 0) || (pop === 0 && picked.platform === 'netease');
  if (!bad) return null;
  const first = tokens[0] || '';
  const alts = [];
  for (const [platform, list] of Object.entries(pools)) {
    for (const x of list) {
      if (String(x.id) === String(picked.id)) continue;
      const n = norm(x.name);
      if (!n.includes(first)) continue;
      if (coverish(x)) continue;
      alts.push({ ...x, platform, score: Number(x.pop) || 0 });
    }
  }
  if (!alts.length) return null;
  alts.sort((a, b) => ((b.platform === 'kugou' ? 1 : 0) - (a.platform === 'kugou' ? 1 : 0)) || (b.score - a.score));
  const pick = alts[0];
  log('只给歌名：' + picked.name + ' 像翻唱/热度低，换成 ' + pick.name + ' - ' + pick.artists + '（' + pick.platform + '）');
  return pick;
}

// ── 热歌榜（没指定歌名时随机挑） ─────────────────────────────────────────

async function hotChart() {
  const s = S();
  const url = `https://music.163.com/api/playlist/detail?id=${HOT_CHART_ID}&n=100&s=0`;
  const j = await fetchJson(url, { referer: 'https://music.163.com/', timeout: Number(s.timeoutMs) || 15000 });
  const tracks = (j?.result?.tracks) || [];
  return tracks.map((x) => ({
    platform: 'netease',
    id: String(x.id),
    name: unescapeHtml(x.name || ''),
    artists: (x.artists || []).map((a) => unescapeHtml(a.name || '')).filter(Boolean).join(' / ') || '未知歌手',
    album: unescapeHtml(x.album?.name || ''),
    cover: x.album?.picUrl || '',
    link: `https://music.163.com/#/song?id=${x.id}`,
    durationMs: Number(x.duration) || 0,
    pop: Number(x.pop) || 0
  }));
}

// ── 封面下载 ──────────────────────────────────────────────────────────────

async function downloadCover(song) {
  if (!S().withCover || !song?.cover) return null;
  const dir = coverDir();
  const key = crypto.createHash('md5').update(`${song.platform}:${song.id}`).digest('hex');
  const base = path.join(dir, key);
  for (const ext of ['.jpg', '.png', '.webp']) {
    try { if (fs.statSync(base + ext).size > 1024) return base + ext; } catch { /* 继续找 */ }
  }
  try {
    const res = await fetch(song.cover, { headers: { 'User-Agent': UA, Referer: song.link }, signal: AbortSignal.timeout(15000) });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const buf = Buffer.from(await res.arrayBuffer());
    const max = Math.max(1, Number(S().maxMB) || 8) * 1024 * 1024;
    if (!buf.length || buf.length > max) throw new Error('封面体积不合适');
    const ct = String(res.headers.get('content-type') || '');
    const ext = ct.includes('png') ? '.png' : ct.includes('webp') ? '.webp' : '.jpg';
    fs.writeFileSync(base + ext, buf);
    return base + ext;
  } catch (e) {
    warn(`封面下载失败：${e?.message ?? e}`);
    return null;
  }
}

/** 音频外链是否真的能播（很多歌的网易云 outer 外链会 302 到 /404 页）。 */
async function audioOk(url) {
  if (!url) return false;
  try {
    const res = await fetch(url, {
      method: 'GET',
      headers: { 'User-Agent': UA, Range: 'bytes=0-1' },
      redirect: 'follow',
      signal: AbortSignal.timeout(12000)
    });
    const ct = String(res.headers.get('content-type') || '');
    return (res.status === 200 || res.status === 206) && /audio|mpeg|mp3|octet-stream/i.test(ct);
  } catch { return false; }
}

const audioUrlOf = (id) => `https://music.163.com/song/media/outer/url?id=${id}.mp3`;

// 同会话最近点过的歌（避免同一群连着收到同一首）
let stateCache = null;
function stateFile() { return path.join(DATA_DIR, 'music-request-state.json'); }
function loadState() {
  if (stateCache) return stateCache;
  try { stateCache = JSON.parse(fs.readFileSync(stateFile(), 'utf8')) || {}; } catch { stateCache = {}; }
  if (!stateCache.lastByChat || typeof stateCache.lastByChat !== 'object') stateCache.lastByChat = {};
  return stateCache;
}
function saveState() {
  try { fs.mkdirSync(path.dirname(stateFile()), { recursive: true }); fs.writeFileSync(stateFile(), JSON.stringify(stateCache, null, 1), 'utf8'); } catch { /* ignore */ }
}
/** 通过 GD 音乐台取 320k 直链（免费聚合 API，网易云可用）；失败退回网易云 outer 外链。 */

/** 用公共 Meting 实例拿网易云直链（GD 没地址时的后备）。返回最终可下载 URL 或空串。 */
async function metingAudio(id) {
  const endpoints = [
    'https://api.injahow.cn/meting/?server=netease&type=url&id=',
    'https://api.moeyao.cn/meting/?server=netease&type=url&id='
  ];
  for (const base of endpoints) {
    try {
      const r = await fetch(base + encodeURIComponent(id), {
        headers: { 'User-Agent': UA, Range: 'bytes=0-1' },
        redirect: 'follow',
        signal: AbortSignal.timeout(15000)
      });
      const ct = String(r.headers.get('content-type') || '');
      if ((r.status === 200 || r.status === 206) && /audio|mpeg|mp3|octet/i.test(ct) && r.url) return r.url;
    } catch { /* 换下一个实例 */ }
  }
  return '';
}

async function resolveAudioUrl(id) {
  const api = String((S().gdApi) || 'https://music-api.gdstudio.xyz/api.php').trim();
  try {
    const r = await fetch(`${api}?types=url&source=netease&id=${encodeURIComponent(id)}&br=320`, {
      headers: { 'User-Agent': UA },
      signal: AbortSignal.timeout(12000)
    });
    if (r.ok) {
      const j = await r.json();
      if (j && j.url) { log(`音频源：GD 320k（完整版）id=${id}`); return j.url; }
    }
  } catch { /* 回退 */ }
  try {
    const mu = await metingAudio(id);
    if (mu) { log('音频源：Meting 网易云直链 id=' + id); return mu; }
  } catch { /* 继续回退 */ }
  log(`音频源：网易云外链（GD 不可用）id=${id}`);
  return audioUrlOf(id);
}


/** 下载可播放音频到本地（发语音/文件用）。 */
async function downloadAudio(song, audioUrl) {
  try {
    const dir = path.join(DATA_DIR, 'music-audio');
    fs.mkdirSync(dir, { recursive: true });
    const file = path.join(dir, `${String(song.id).replace(/[^\w-]/g, '_')}.mp3`);
    try { if (fs.statSync(file).size > 1024) return file; } catch { /* 还没下 */ }
    const res = await fetch(audioUrl, { headers: { 'User-Agent': UA }, redirect: 'follow', signal: AbortSignal.timeout(40000) });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const buf = Buffer.from(await res.arrayBuffer());
    if (!buf.length || buf.length > 40 * 1024 * 1024) throw new Error('文件大小不合适');
    fs.writeFileSync(file, buf);
    return file;
  } catch (e) { warn(`音频下载失败：${e?.message ?? e}`); return null; }
}

/** 按「发送方式」把歌作为语音（record）或文件（file）发出去。 */

/** QQ 群文件/私聊文件对文件名有字符限制，统一清洗成安全名。 */
function safeFileName(name) {
  const s = String(name || 'song.mp3')
    .replace(/[\\/:*?"<>|[\]{}()（）【】]/g, '_')
    .replace(/\s+/g, ' ')
    .trim()
    .slice(0, 80);
  return s || 'song.mp3';
}

async function deliverAudio(ctx, chatKey, song, audioUrl, delivery) {
  if (!audioUrl) return { ok: false, skipped: '没有可播放的音频' };
  const mode = String(delivery || 'card');
  const wantVoice = mode.includes('voice');
  const wantFile = mode.includes('file');
  if (!wantVoice && !wantFile) return { ok: false, skipped: '只发卡片' };
  const file = await downloadAudio(song, audioUrl);
  if (!file) return { ok: false, error: '音频下载失败' };
  const out = { ok: false };
  if (wantVoice) {
    try { await ctx.sender.sendMedia(chatKey, [{ type: 'record', data: { file } }], {}); out.voice = true; out.ok = true; }
    catch (e) { warn(`语音发送失败：${e?.message ?? e}`); }
  }
  if (wantFile) {
    try { await ctx.sender.sendMedia(chatKey, [{ type: 'file', data: { file, name: safeFileName(`${song.name}.mp3`) } }], {}); out.file = true; out.ok = true; }
    catch (e) { warn(`文件发送失败：${e?.message ?? e}`); }
  }
  return out;
}

const fmtDuration = (ms) => {
  const total = Math.round((Number(ms) || 0) / 1000);
  if (!total) return '';
  return `${Math.floor(total / 60)}:${String(total % 60).padStart(2, '0')}`;
};


/**
 * 卡片里嵌的播放地址：优先网易云**稳定外链**（/song/media/outer/url，会自己重新签名，不失效），
 * 网易云拿不到（会员歌 404）才退回聚合站直链（GD，带时效）。
 */
async function cardAudioFor(id, gdUrl) {
  const outer = `https://music.163.com/song/media/outer/url?id=${id}.mp3`;
  try {
    if (await audioOk(outer)) return outer;
  } catch { /* 继续 */ }
  warn('网易云外链不可用，卡片改用聚合站直链');
  return gdUrl;
}

// ── 官方音乐卡片（Ark 签名）──────────────────────────────────────────────────
//
// 为什么需要签名：QQ 客户端的 Ark 卡片必须带 `config.token`，否则协议端（SnowLuma）
// 会退回**本地残卡**，群里显示「发送者版本过低，无法展示内容」。
// 公开的签名服务（星之阁）已于 2026-08-04 永久关停；现在可用的免费服务是 yibai：
//   POST {type, id, title, content, image, url, audio} → 返回带 token 的 Ark JSON
// 关键：必须带 **audio 外链**，否则服务会退化成 tuwen 图文卡（本模块按 app 名拒绝）。
// 网易云公开外链（无需登录）：
//   https://music.163.com/song/media/outer/url?id=<id>.mp3
// 不可用的歌会 404/未授权 → 签名服务退化 → 我们校验失败后降级为「封面 + 链接」。
const SIGN_TIMEOUT_MS = 8000;
const SIGN_RETRIES = 2;

function looksLikeMusicArk(o) {
  if (!o || typeof o !== 'object' || Array.isArray(o)) return false;
  const app = String(o.app ?? '');
  if (/^com\.tencent\.music/.test(app)) return true;
  if (/^com\.tencent\.structmsg$/.test(app) && String(o?.view ?? '').toLowerCase() === 'music') return true;
  return false;
}

/** 把响应文本解析到对象（兼容「JSON 字符串里再套一份 Ark」的双重编码）。 */
function parseDeep(text) {
  let cur = String(text ?? '').trim();
  if (!cur) return undefined;
  for (let i = 0; i < 3; i += 1) {
    try { cur = JSON.parse(cur); } catch { return typeof cur === 'object' ? cur : undefined; }
    if (typeof cur !== 'string') return cur;
  }
  return undefined;
}

function extractArk(text) {
  const parsed = parseDeep(text);
  if (looksLikeMusicArk(parsed)) return parsed;
  if (parsed && typeof parsed === 'object' && looksLikeMusicArk(parsed.data)) return parsed.data;
  const desc = parsed && typeof parsed === 'object'
    ? `app=${parsed.app ?? '?'}`
    : (String(text ?? '') || '空响应').slice(0, 40);
  throw new Error(`签名服务返回的不是音乐卡片（${desc}）`);
}

/** 调签名服务拿一份「带 token 的 Ark JSON」。失败抛错，由调用方降级。 */
async function signMusicCard(payload) {
  const url = String(S().signService || '').trim();
  if (!url) throw new Error('未配置签名服务地址（signService）');
  let lastError = '';
  for (let attempt = 0; attempt <= SIGN_RETRIES; attempt += 1) {
    if (attempt > 0) await new Promise((r) => setTimeout(r, 800));
    let resp;
    try {
      // eslint-disable-next-line no-await-in-loop
      resp = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
        signal: AbortSignal.timeout(SIGN_TIMEOUT_MS)
      });
    } catch (e) { lastError = `签名服务连不上（${e?.message ?? e}）`; continue; }
    if (!resp.ok) { lastError = `签名服务 HTTP ${resp.status}`; continue; }
    // eslint-disable-next-line no-await-in-loop
    const text = await resp.text();
    if (!String(text).trim()) { lastError = '签名服务返回空响应（服务已失效）'; continue; }
    try { return extractArk(text); } catch (e) { lastError = String(e?.message ?? e); }
  }
  throw new Error(`${lastError}（${url}）`);
}

// ── 工具 ──────────────────────────────────────────────────────────────────

export function setup(api) {
  cfg = api.config;
  log = api.log;
  warn = api.warn;
  errorLog = api.error;

  api.registerTool({
    id: 'music_request',
    name: '点歌',
    description:
      '点一首歌并发到当前会话：**先在网易云搜，搜不到再用酷狗**，找到后发「封面图 + 歌名/歌手/平台链接」。'
      + '适用：群友说「点首歌」「来首 XX」「放一首 XX」「听听 XX」。'
      + 'query 填歌名（可带歌手，如「假如 徐剑秋」）；用户没给具体歌名时**留空**，会从网易云热歌榜随机挑一首。'
      + '找不到时会给网易云/QQ音乐/酷狗/酷我/咪咕的搜索链接兜底（QQ音乐和酷我的搜索接口被官方风控，只能给链接）。'
      + '工具会自己把内容发到当前会话；用户要求「发文件/完整版/下载」时传 delivery=card+file，要「直接听/语音」时传 card+voice；'
      + '你拿到结果后用 send_message 回一句短话，别复述链接。',
    category: 'media',
    icon: '🎵',
    parameters: {
      type: 'object',
      properties: {
        query: { type: 'string', description: '歌名（可带歌手）。用户只说「随便来首」「点首歌」时留空。' },
        platform: {
          type: 'string',
          description: '可选：指定优先平台 netease / kugou（默认按设置里的顺序：网易云 → 酷狗）。'
        },
        delivery: {
          type: 'string',
          description: '可选：这次怎么发。用户明确要「文件/完整版/下载/原曲」时传 file 或 card+file；'
            + '要「在群里直接听/语音」传 voice 或 card+voice；不传则按技能设置（默认 card+voice）。'
        }
      }
    },
    async execute(ctx, args) {
      try {
        const s = S();
        const chatKey = String(ctx?.chatKey || '');
        const kw = String(args?.query ?? '').trim();
        const explicit = String(args?.platform ?? '').trim().toLowerCase();
        const orderList = explicit && SEARCHERS[explicit]
          ? [explicit, ...order().filter((p) => p !== explicit)]
          : order();

        let picked = null;
        let fromChart = false;
        const tried = [];

        let neteasePool = [];
        const pools = {};
        if (kw) {
          const cands = [];
          for (const p of orderList) {
            try {
              // eslint-disable-next-line no-await-in-loop
              const list = await SEARCHERS[p](kw);
              tried.push(`${p}:${list.length}`);
              if (!list.length) continue;
              pools[p] = list;
              if (p === 'netease') neteasePool = list;
              const m = bestMatch(list, kw);
              if (m.song) cands.push({ ...m, platform: p });
            } catch (e) {
              warn(`[${p}] 搜索「${kw}」失败：${e?.message ?? e}`);
              tried.push(`${p}:err`);
            }
          }
          // 跨平台比分数：同分时按平台顺序优先（网易云在前）
          cands.sort((a, b) => (b.score - a.score) || (orderList.indexOf(a.platform) - orderList.indexOf(b.platform)));
          if (cands.length) picked = cands[0].song;
          const orig = preferOriginal(pools, kw, picked);
          if (orig) picked = orig;
        } else {
          const list = await hotChart();
          if (list.length) {
            neteasePool = list;
            const dayIdx = Math.floor(Date.now() / 86400000);
            picked = list[dayIdx % list.length];
            fromChart = true;
          }
        }

        // 音频外链校验：很多歌的网易云外链已失效（跳到 /404 页），卡片点开会没声音。
        // 这里先验证，死了就换候选里能播的一首；全都不行就不发卡片，降级封面+链接。
        let audioUrl = '';
        if (picked && picked.platform === 'netease') {
          audioUrl = await resolveAudioUrl(picked.id);
          // eslint-disable-next-line no-await-in-loop
          if (!(await audioOk(audioUrl))) {
            let swapped = false;
            for (const x of neteasePool.filter((it) => it.id !== picked.id).slice(0, 4)) {
              const u = await resolveAudioUrl(x.id);
              // eslint-disable-next-line no-await-in-loop
              if (await audioOk(u)) { picked = x; audioUrl = u; swapped = true; break; }
            }
            if (!swapped) {
              audioUrl = '';
              warn(`《${picked.name}》的音频外链都失效了，这次只发封面+链接`);
            }
          }
        }

        // 只给歌名时：先问 QQ音乐「这首歌的原唱是谁」，再按「歌名 + 原唱」去平台找
        // 中文名 → 日文原名（tns 别名）完全匹配时直接优先
        try {
          if (picked && kw && String(kw).split(/\s+/).filter(Boolean).length === 1) {
            const want = norm(kw);
            const aliasHit = (neteasePool || [])
              .filter((x) => Array.isArray(x.aliases) && x.aliases.some((a) => norm(a) === want) && !coverish(x))
              .sort((a, b) => (Number(b.pop) || 0) - (Number(a.pop) || 0))[0];
            if (aliasHit && String(aliasHit.id) !== String(picked.id)) {
              log('按翻译名命中原曲：' + kw + ' → ' + aliasHit.name + ' - ' + aliasHit.artists);
              picked = aliasHit;
            }
          }
        } catch { /* 忽略 */ }

        let origArtist = '';
        const strongPick = picked && kw && (
          (Array.isArray(picked.aliases) && picked.aliases.some((a) => norm(a) === norm(kw)))
          || (!coverish(picked) && (Number(picked.pop) || 0) >= 90 && norm(picked.name) === norm(kw))
        );
        if (picked && kw && !strongPick) {
          const tokens = String(kw).split(/\s+/).filter(Boolean);
          if (tokens.length === 1) {
            try { origArtist = await qqOriginalArtist(kw); } catch { origArtist = ''; }
            if (origArtist) {
              log('原唱识别：' + kw + ' → ' + origArtist);
              if (!norm(picked.artists).includes(norm(origArtist))) {
                const extra = [];
                for (const p of orderList) {
                  try {
                    const list2 = await SEARCHERS[p](kw + ' ' + origArtist);
                    for (const x of list2) {
                      if (!coverish(x) && norm(x.artists).includes(norm(origArtist))) extra.push({ ...x, platform: p });
                    }
                  } catch { /* 忽略 */ }
                }
                if (extra.length) {
                  const better = bestMatch(extra, kw + ' ' + origArtist).song;
                  picked = better || extra[0];
                  log('改用原唱版本：' + picked.name + ' - ' + picked.artists + '（' + picked.platform + '）');
                }
              }
            }
          }
        }

        // 选到酷狗的歌时，回查网易云有没有同版本（网易云才有 320k 音频）
        if (picked && picked.platform === 'kugou') {
          try {
            const alt = await SEARCHERS.netease(picked.name + ' ' + String(picked.artists).split('/')[0].trim());
            const firstArtist = norm(String(picked.artists).split('/')[0]);
            const match = (alt || []).find((x) => {
              const n = norm(x.name);
              const pn = norm(picked.name);
              const alias = Array.isArray(x.aliases) ? x.aliases.map(norm) : [];
              const nameHit = n === pn || n.includes(pn) || pn.includes(n) || alias.includes(pn);
              const artistHit = firstArtist && norm(x.artists).includes(firstArtist);
              return nameHit && artistHit && !coverish(x) && (Number(x.pop) || 0) >= 40;
            });
            if (match) {
              log('酷狗结果在网易云有同版本，改用网易云：' + match.name + ' - ' + match.artists);
              picked = match;
            }
          } catch { /* 回查失败不影响出歌 */ }
        }

        // 同会话刚发过的歌不再连发（换一个候选）
        try {
          if (chatKey && picked) {
            const st = loadState();
            const last = st.lastByChat[chatKey];
            if (last && String(last.id) === String(picked.id)) {
              const alt = (neteasePool || []).find((x) => String(x.id) !== String(picked.id) && !coverish(x));
              if (alt) {
                log(`本会话刚发过《${picked.name}》，换成《${alt.name}》- ${alt.artists}`);
                picked = alt;
              }
            }
          }
        } catch { /* 去重失败不影响出歌 */ }

        if (!picked) {
          const links = Object.entries(PLATFORM_LINKS)
            .map(([k, fn]) => `· ${PLATFORM_LABEL[k]}：${fn(kw || '热歌')}`)
            .join('\n');
          const out = `没搜到「${kw || '（随便）'}」（试过：${tried.join('，') || '热歌榜'}）。\n可以点下面任一链接自己找：\n${links}\n`
            + '直接把歌名/歌手告诉我，我再试一次。';
          if (chatKey) { try { await ctx.sender.sendTextBatch(chatKey, [out]); } catch { /* ignore */ } }
          return { content: out, isError: true };
        }

        const label = PLATFORM_LABEL[picked.platform] || picked.platform;
        const dur = fmtDuration(picked.durationMs);
        const text = `🎵 《${picked.name}》\n🎤 ${picked.artists}${picked.album ? `\n💿 ${picked.album}` : ''}`
          + `${dur ? ` · ${dur}` : ''}\n▶ ${label}：${picked.link}`;

        let coverPath = null;
        let cardSent = false;
        let lead = '';
        const wantDelivery = String(args?.delivery || '').trim();
        const delivery = wantDelivery || String(S().songDelivery || 'card');
        // ① 官方音乐卡片（网易云 + 签名成功时）：先发一句短话，再发卡片
        if (S().officialCard && picked.platform === 'netease' && delivery.includes('card')) {
          try {
            const ark = await signMusicCard({
              type: '163',
              id: picked.id,
              title: picked.name,
              content: picked.artists,
              image: picked.cover,
              url: picked.link,
              audio: await cardAudioFor(picked.id, audioUrl || audioUrlOf(picked.id))
            });
            if (chatKey) {
              // ⚠️ 模型经常在"工具已经发了内容"之后就不说话了（实测 2026-10-19：只收到卡片、没有一句话）。
              //    所以这里由技能自己补一句，保证"发歌时一定有人说话"。
              lead = String(S().leadTemplate || '🎵 给你找了《{name}》—— {artists}').replace('{name}', picked.name).replace('{artists}', picked.artists);
              await ctx.sender.sendTextBatch(chatKey, [lead]);
              await ctx.sender.sendMedia(chatKey, [{ type: 'json', data: { data: JSON.stringify(ark) } }], {});
              cardSent = true;
            }
          } catch (e) {
            warn(`音乐卡片签名失败，降级为封面+链接：${e?.message ?? e}`);
          }
        }
        // 语音 / 文件（QQ 会把 mp3 转成 SILK 语音；文件则原样发 MP3）
        let audioSent = { ok: false };
        if (chatKey && picked.platform === 'netease' && audioUrl) {
          try { audioSent = await deliverAudio(ctx, chatKey, picked, audioUrl, delivery); } catch (e) { warn(`音频发送失败：${e?.message ?? e}`); }
        }
        if (!cardSent) {
          try { coverPath = await downloadCover(picked); } catch (e) { warn(`封面处理失败：${e?.message ?? e}`); }
          if (chatKey) {
            const audioOnly = delivery.includes('file') || delivery.includes('voice');
            // 网易云的歌已经发过卡片 → 不再发带链接的文字
            if (cardSent) {
              // 已发卡片，不再重复发文字
            } else if (coverPath && !audioOnly) {
              // 文字 + 封面合成**同一条消息**（用户 2026-10-20 要求：别把封面单独发一条）
              try {
                await ctx.sender.sendMedia(chatKey, [
                  { type: 'text', data: { text } },
                  { type: 'image', data: { file: coverPath } }
                ], {});
              } catch (e) { warn(`图文发送失败，退回纯文字：${e?.message ?? e}`); await ctx.sender.sendTextBatch(chatKey, [text]); }
            } else {
              // 文件/语音已在前面发过 → 只在后面接一句话
              await ctx.sender.sendTextBatch(chatKey, [text]);
            }
          }
        }

        const summary = `【已发送】《${picked.name}》- ${picked.artists}（${label}${fromChart ? '，热歌榜随机' : ''}`
          + `${cardSent ? '，官方音乐卡片（QQ 内可点播）+ 一句说明' : (coverPath ? '，带封面' : '，无封面')}`
          + (audioSent.voice ? '，语音' : '') + (audioSent.file ? '，文件' : '')
          + '） —— 内容都已经发到会话里了，**不用再补充说明**；如果用户接着聊别的再说。'
          + (picked.platform === 'kugou' ? '注意：这是酷狗的结果，可能是翻唱/现场版。' : '');
        try {
          if (chatKey) { const st = loadState(); st.lastByChat[chatKey] = { id: picked.id, name: picked.name, at: Date.now() }; saveState(); }
        } catch { /* ignore */ }
        log(`点歌「${kw || '随便'}」→ 《${picked.name}》- ${picked.artists}（${label}）`);
        return { content: summary, isError: false };
      } catch (e) {
        errorLog?.(`点歌异常：${e?.stack ?? e}`);
        return { content: `点歌出错：${e?.message ?? e}`, isError: true };
      }
    }
  });

  log('点歌已注册（网易云 → 酷狗，发封面 + 歌名/链接）');
}

export function available() { return true; }

// 供测试/排障（加载器不消费）
export const internals = { searchNetease, searchKugou, hotChart, bestMatch, order, downloadCover };
