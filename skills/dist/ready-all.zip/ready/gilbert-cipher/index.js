// Gilbert 曲线图片混淆 / 解混淆（skill 本体）。
//
// ── 这是什么 ──────────────────────────────────────────────────────────────
// 用空间填充曲线把图片的**像素位置**按曲线顺序重排：
//   · 混淆后：图像变成一片高频噪声样子的图，尺寸不变；
//   · 解混淆：逐字节还原成原图（无损，PNG 往返）。
//
// ── 曲线算法不分发像素，它只重排像素 ──────────────────────────────────────
// 常见误解是把这条曲线当成密码学工具。它**不是**：曲线顺序是公开的，
// 拿到混淆图的人知道算法就能试出来。它的实际价值是：
//   ① 让图片的结构在**降采样/缩略图/上采样**过程中被彻底打散（曲线把相邻像素
//      摊到很远，重采样时不会留下可辨认的低频轮廓）；
//   ② 做「看一眼不知道是什么」的贴图，而**不需要**任何密钥分发；
//   ③ shift 参数提供一组"排序起点"，不同 shift 出的图互不相同 —— 属于
//      **可混淆性**而不是**安全性**。别把它当加密：真正需要保密的场合应该先加密。
//
// ── 为什么往返必须无损 ────────────────────────────────────────────────────
// 中间与产物一律 PNG：混淆后的图是高频噪点，JPEG 会改变像素值，解混淆就还原
// 不回去。所以本 skill 的往返是**逐字节精确**的（已由 lib/_selftest.js 与
// 端到端测试证明）。

import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { decodeToRgba, encodePng, outDir, ensureFfmpeg } from './lib/image-io.js';
import { applyPermutation, buildPermutation, orderFor } from './lib/permute.js';
// ⚠️ 相对路径深度：本文件在 skills/<id>/ 下，app 根在**两层**之上。
//    lib/ 下的文件则要三层（见 lib/image-io.js 的注释）。
import { validateImageUrl, safeFetchBinaryToFile } from '../../src/safe-fetch.js';
import {
  fingerprintOf, saveEntry, findByFingerprint, getEntry, restoreOriginal, prune, WEAK_STD
} from './lib/vault.js';
import { xfqPermute } from './lib/xfq.js';

const DEFAULTS = {
  enabled: true,
  autoSend: true,
  maxPixels: 12000000,     // 超过这个像素数拒绝（避免大图卡住会话）
  maxUploadMB: 20,
  matchTolerance: 0.6,     // 指纹匹配阈值（标定值，见 lib/vault.js）
  vaultMaxEntries: 200,    // 留档条数上限
  vaultMaxMB: 512          // 留档总字节上限
};

const ok = (payload) => ({ content: typeof payload === 'string' ? payload : JSON.stringify(payload, null, 1) });
const err = (message) => ({ content: `错误：${message}`, isError: true });

let api = null;
let manifestSettings = null;

function manifestDefaults() {
  if (manifestSettings) return manifestSettings;
  try {
    const raw = JSON.parse(fs.readFileSync(new URL('./skill.json', import.meta.url), 'utf8'));
    manifestSettings = raw?.settings && typeof raw.settings === 'object' ? raw.settings : {};
  } catch { manifestSettings = {}; }
  return manifestSettings;
}

function settings() {
  const raw = (api && typeof api.config === 'function' ? api.config() : null) || {};
  const out = { ...DEFAULTS };
  for (const layer of [manifestDefaults(), raw]) {
    for (const [k, v] of Object.entries(layer)) {
      if (v === undefined || v === null) continue;
      out[k] = v;
    }
  }
  return out;
}

/**
 * 从**消息存档**里找图片。
 *
 * ⚠️ 这里踩过一个真实的坑：我最初写的是 `ctx.session.triggerSegments` ——
 *    那是**凭空猜的字段名**，根本不存在。结果工具永远回"抓不到图"，
 *    而代码本身不报错，看起来像"用户没发图"。
 *    真实契约（见 src/store.js 的 appendIncoming({media}) 与
 *    src/tools.js 的 get_message_images）是：
 *      图片存在 **store 的消息记录** 上，字段是 `entry.media[]`，
 *      每项形如 { kind: 'image', file, url, summary }。
 *    所以取图的唯一正确入口是 ctx.store。
 *
 * @param {object} ctx 工具上下文（必须带 store 与 chatKey）
 * @param {number|string} [messageId] 指定消息（聊天记录里的 #数字）；不填则回溯最近的消息
 * @returns {{entry:object, media:object}|null}
 */
function findImageEntry(ctx, messageId) {
  const store = ctx?.store;
  const chatKey = ctx?.chatKey;
  if (!store || !chatKey) return null;

  const hasImage = (m) => (m?.media || []).find((x) => x?.kind === 'image' && (x.url || x.file));

  const mid = messageId === undefined || messageId === null ? '' : String(messageId).trim();
  if (mid) {
    const entry = store.findByMid(chatKey, mid);
    if (!entry) return { missingMessage: mid };
    const media = hasImage(entry);
    return media ? { entry, media } : { entry, noImage: true };
  }

  // 不指定消息：从最近往回找第一条带图的（recent() 返回的是「由旧到新」的切片，
  // 所以从尾部往回扫才是"最近的图"）。
  const recent = store.recent(chatKey, { limit: 30 }) || [];
  for (let i = recent.length - 1; i >= 0; i--) {
    const media = hasImage(recent[i]);
    if (media) return { entry: recent[i], media };
  }
  return null;
}

/** 把本地路径 / file:// / base64 统一成磁盘上的真实文件路径。 */
function localPathOf(rawFile) {
  const f = String(rawFile ?? '').trim();
  if (!f) return null;
  if (f.startsWith('file://')) {
    try { return fileURLToPath(f); } catch { return null; }
  }
  // 绝对路径（Windows 盘符或 POSIX）且确实存在，才算可用
  if (/^[a-zA-Z]:[\\/]/.test(f) || f.startsWith('/')) return fs.existsSync(f) ? f : null;
  return null;
}

/**
 * 把 media 条目落成 ffmpeg 能读的磁盘文件。
 *
 * 顺序：① 已经是本地文件 → 直接用；② base64 → 落盘；③ 远程 URL → 走项目自带的
 * **安全下载**（safeFetchBinaryToFile：逐跳重定向校验、禁内网、限制字节数）。
 * 不自己写 fetch：那会绕过整套 SSRF 防护，而这个 URL 来自群聊（不可信）。
 */
async function materialize(media, maxBytes) {
  const direct = localPathOf(media?.file);
  if (direct) return direct;

  const raw = String(media?.file ?? '').trim();
  if (raw.startsWith('base64://')) {
    const buf = Buffer.from(raw.slice('base64://'.length), 'base64');
    if (!buf.length) throw new Error('图片 base64 为空');
    const p = path.join(outDir(), 'inbox', `in-${Date.now()}-${Math.random().toString(36).slice(2)}.img`);
    fs.mkdirSync(path.dirname(p), { recursive: true });
    fs.writeFileSync(p, buf);
    return p;
  }

  const url = String(media?.url ?? '').trim();
  if (!url) throw new Error('这条消息的图片既没有本地文件也没有可下载的地址');
  const safeUrl = await validateImageUrl(url);
  const dst = path.join(outDir(), 'inbox', `in-${Date.now()}-${Math.random().toString(36).slice(2)}.img`);
  await safeFetchBinaryToFile(safeUrl, dst, maxBytes, { timeoutMs: 30000 });
  return dst;
}

/** 输出路径：data/gilbert/ 下。 */
function makeOutPath(tag, ext = '.png') {
  const d = outDir();
  fs.mkdirSync(d, { recursive: true });
  return path.join(d, `${tag}-${Date.now()}-${Math.random().toString(36).slice(2, 8)}${ext}`);
}

/**
 * 两套置换方案。
 *
 * ── 'xfq'（默认）：小番茄混淆那一套 ─────────────────────────────────────────
 * 移植自 xiaofanqiehunxiao.com 的前端实现，已用**他们自己的代码当 oracle
 * 逐点比对过**（25 个尺寸、最大 260 万点，序列完全一致；连 777×402 那处孤立
 * 跳步都在同一索引复现）。要点：
 *   · 曲线**直接按矩形**递归生成 → 无画布空格，也就不会因"跳过外部格子"
 *     而切断邻域
 *   · 置换是**曲线空间里的整体旋转** L = round(0.618·d) → 相邻像素仍相邻
 *   · 因此**抗 JPEG**（他们的产物本身就是 JPEG q0.95），
 *     这正是"经 QQ 来回还能还原"的关键 —— 也修掉了我这套的老毛病
 * ── 'raster'：我原来的方案（保留，兼容旧产物）────────────────────────────
 * 读光栅序、写曲线序。邻域被打散成高频噪点 → 一压就坏，必须靠留档才能还原。
 */
function permuteByScheme(scheme, src, dst, w, h, { invert, shift, times }) {
  if (scheme === 'raster') {
    applyPermutation(src, dst, w, h, { invert, shift });
    return { scheme };
  }
  const r = xfqPermute(src, dst, w, h, { invert, times });
  return { scheme: 'xfq', shift: r.shift, times: r.times };
}

async function processOne(chatKey, srcPath, { decrypt, shift, tag, scheme = 'xfq', times = 1 }) {
  const img = await decodeToRgba(srcPath);
  const px = img.w * img.h;
  const s = settings();
  if (px > Number(s.maxPixels)) {
    throw new Error(`图片太大（${img.w}×${img.h} = ${px} 像素，上限 ${s.maxPixels}）`);
  }
  const out = Buffer.alloc(img.buf.length);
  const info = permuteByScheme(scheme, img.buf, out, img.w, img.h, { invert: decrypt, shift, times });
  // ── 退化检测：极小/极窄的图，曲线顺序可能恰好等于逐行顺序，置换退化成恒等 ──
  // 静默"成功但没变"比报错更糟 —— 用户会以为工具坏了或以为自己发错图。
  // 还原方向遇到恒等是正常的（那就是没被混淆过），只在混淆方向拦。
  if (!decrypt && out.equals(img.buf)) {
    throw new Error(`这张图太窄/太小（${img.w}×${img.h}）：置换退化成了恒等，混淆等于没做。换一张正常尺寸的图。`);
  }
  const dst = makeOutPath(tag);
  await encodePng(out, img.w, img.h, dst);
  // ⚠️ 指纹必须算**混淆后的图**，不是原图！
  //    会从 QQ 发回来的是混淆图，还原时也是拿它去匹配。
  const fp = fingerprintOf(out, img.w, img.h);
  return { dst, w: img.w, h: img.h, px, fp, scheme: info.scheme };
}

/**
 * 还原：**先查留档，再退回数学**。
 *
 * 为什么顺序是这样：纯数学的逆置换要求混淆图逐字节回到本机，而 QQ 默认会
 * 重编码图片、大图还可能缩放 —— 任何一次改动都会让逆置换输出乱码。
 * 留档方案把**原图本体**存在本地，按指纹把发回来的图认出来直接给原图，
 * 于是传输是否有损都不影响结果。
 *
 * 两条路都要如实回报给模型（`via` 字段），让它可以对用户说实话：
 *   via='vault' —— 命中留档，还原的是原图本体（逐字节精确）
 *   via='math'  —— 没命中留档，用的是数学逆置换；图若被重编码过，结果会很差
 *
 * @returns {Promise<{dst:string, via:'vault'|'math', w:number, h:number, px:number, distance?:number}>}
 */
async function restoreOne(srcPath, { shift, vaultId, scheme = 'xfq', times = 1 }) {
  const s = settings();
  let img;
  try {
    img = await decodeToRgba(srcPath);
  } catch (e) {
    throw new Error(`读图失败：${e?.message ?? e}`);
  }
  const px = img.w * img.h;
  if (px > Number(s.maxPixels)) {
    throw new Error(`图片太大（${img.w}×${img.h} = ${px} 像素，上限 ${s.maxPixels}）`);
  }

  // ── ① 指定 id：显式命中，不走指纹（出问题时最可控的一条路）──
  if (vaultId) {
    const entry = getEntry(vaultId);
    if (!entry) throw new Error(`留档里没有 ${vaultId} 这个编号。`);
    const dst = restoreOriginal(entry, outDir());
    if (!dst) throw new Error(`留档 ${vaultId} 的原图文件已丢失（可能被清理了）。`);
    return { dst, via: 'vault', w: img.w, h: img.h, px, distance: 0, scheme };
  }

  // ── ② 指纹匹配留档 ──
  const fp = fingerprintOf(img.buf, img.w, img.h);
  const hit = findByFingerprint(fp, { tolerance: Number(s.matchTolerance) || undefined });
  if (hit) {
    const dst = restoreOriginal(hit.entry, outDir());
    if (dst) {
      return {
        dst, via: 'vault', w: img.w, h: img.h, px, scheme,
        distance: Number(hit.distance.toFixed(3))
      };
    }
    // 原图文件被删了：不静默退化，记一笔然后走数学还原
    try { api?.warn?.(`[gilbert] 留档 ${hit.entry.id} 的原图已丢失，退回数学还原`); } catch { /* ignore */ }
  }

  // ── ③ 数学逆置换（尽力而为）──
  const out = Buffer.alloc(img.buf.length);
  const info = permuteByScheme(scheme, img.buf, out, img.w, img.h, { invert: true, shift, times });
  const dst = makeOutPath('dec');
  await encodePng(out, img.w, img.h, dst);
  // 区分两种"没命中"，好让模型对用户说准原因：
  //   weak  —— 图在大尺度上几乎没有结构，指纹不可靠，主动放弃匹配（不是找不到）
  //   none  —— 结构清楚，但留档里没有对应的原图（多半不是本机混淆的，或留档被清了）
  const weak = fp.flat || (fp.rawStd ?? 0) < WEAK_STD;
  return {
    dst, via: 'math', w: img.w, h: img.h, px, scheme: info.scheme,
    reason: weak ? 'weak' : 'none'
  };
}

export function setup(a) {
  api = a;

  a.registerTool({
    id: 'gilbert_image',
    name: 'Gilbert 曲线图片混淆',
    description: '用 Gilbert（空间填充）曲线把图片的像素按曲线顺序重排，得到一张尺寸不变、看起来像噪声的图；'
      + '也可以把这样的图**还原**成原图。\n'
      + '· 群友发了一张图说「帮我混淆/打乱一下」「把这张图转成看不懂的样子」→ action=encrypt（默认）。\n'
      + '· 群友发了一张被混淆过的图说「还原/解混淆/变回来」→ action=decrypt。\n'
      + '· 结果直接发到当前会话（可在设置里关掉自动发送）。\n'
      + '**还原有两种路径，结果里 via 字段会说明**：\n'
      + '  via=vault —— 命中了本地留档（混淆时存下的原图），**逐字节精确**。这是正常情况。\n'
      + '  via=math  —— 没命中留档，只能做数学逆置换。图上只要有一次重编码/缩放就会是乱码。\n'
      + '  **via=math 时必须如实告诉群友"没找到对应原图，还原不了"，绝不能声称还原成功。**\n'
      + '**它不是加密工具**：曲线顺序是公开的，别向群友宣称「加密了」或「安全」。\n'
      + '失败就说清原因（比如"没看到图片"），不要编造成果。',
    category: 'media',
    icon: '🌀',
    parameters: {
      type: 'object',
      properties: {
        action: {
          type: 'string',
          enum: ['encrypt', 'decrypt'],
          description: 'encrypt = 混淆（默认）；decrypt = 解混淆还原'
        },
        shift: {
          type: 'integer',
          description: '曲线起点偏移（同图多版本用）。默认 0。还原时必须与混淆时相同'
        },
        messageId: {
          type: ['integer', 'string'],
          description: '要处理哪条消息的图片（聊天记录里带 [图片] 的那条，前面的 #数字）。'
            + '不填则自动取当前会话最近一条带图的消息 —— 群友刚发的图通常不用填'
        },
        vaultId: {
          type: 'string',
          description: '还原时指定用哪条本地留档（可疑时用于精确指定）。通常不用填 —— '
            + '不填会按指纹自动匹配最近混淆过的原图'
        },
        scheme: {
          type: 'string',
          enum: ['xfq', 'raster'],
          description: '置换方案。默认 xfq = 小番茄混淆那一套（曲线空间旋转，抗 JPEG，'
            + '能还原 xiaofanqiehunxiao.com 的产物）。raster = 本工具旧方案（高频噪点，'
            + '只在还原旧产物时才用）'
        },
        times: {
          type: 'integer',
          description: '混淆/还原叠加次数，默认 1。对方说"混淆了很多次"、或一次解不开时，'
            + '试着把次数调大（2、3…）。混淆侧传几次，还原侧就要传几次'
        }
      },
      required: []
    },
    async execute(ctx, args) {
      const s = settings();
      if (s.enabled === false) return err('这个功能被管理员关掉了。');

      const action = String(args?.action ?? 'encrypt').toLowerCase();
      const decrypt = action === 'decrypt';
      if (!['encrypt', 'decrypt'].includes(action)) {
        return err(`action 只支持 encrypt / decrypt（收到的是 ${JSON.stringify(args?.action)}）`);
      }
      const shift = Number.isFinite(Number(args?.shift)) ? Math.trunc(Number(args.shift)) : 0;
      const scheme = args?.scheme === 'raster' ? 'raster' : 'xfq';
      const times = Math.min(50, Math.max(1, Math.trunc(Number(args?.times) || 1)));

      const ff = await ensureFfmpeg();
      if (!ff.ffmpeg) return err('没找到 ffmpeg，无法解码/编码图片（请先安装 ffmpeg 并在 PATH 里）。');

      const seg = findImageEntry(ctx, args?.messageId);
      if (!seg) {
        return err('最近 30 条消息里没找到图片。让群友先发一张图（或把图和指令一起发），'
          + '也可以用 messageId 指定聊天记录里带 [图片] 的那条（消息前的 #数字）。');
      }
      if (seg.missingMessage) return err(`当前会话找不到消息 ${seg.missingMessage}。`);
      if (seg.noImage) return err(`消息 ${seg.missingMessage ?? ''} 里没有图片。`);

      let srcPath;
      try {
        srcPath = await materialize(seg.media, Number(s.maxUploadMB) * 1024 * 1024);
      } catch (e) {
        return err(`取图失败：${e?.message ?? e}`);
      }
      if (!srcPath || !fs.existsSync(srcPath)) return err('图片文件不存在（可能已经被清理）。');

      const size = fs.statSync(srcPath).size;
      if (size > Number(s.maxUploadMB) * 1024 * 1024) {
        return err(`图片太大（${(size / 1048576).toFixed(1)}MB，上限 ${s.maxUploadMB}MB）。`);
      }

      try {
        let r;
        if (decrypt) {
          r = await restoreOne(srcPath, { shift, vaultId: args?.vaultId, scheme, times });
        } else {
          r = await processOne(ctx.chatKey, srcPath, { decrypt: false, shift, tag: 'enc', scheme, times });
          // 留档原图 + 指纹：这是"经 QQ 来回还能精确还原"的唯一依靠。
          // 留档失败不能拖垮混淆本身 —— 图已经做出来了，照发，只是记一条警告。
          try {
            const entry = saveEntry({
              originalFile: srcPath,
              scrambledFile: r.dst,
              fp: r.fp            // ← 混淆图的指纹（见 processOne 的注释）
            });
            r.vaultId = entry.id;
            const pruned = prune({
              maxEntries: Number(s.vaultMaxEntries) || 200,
              maxBytes: (Number(s.vaultMaxMB) || 512) * 1024 * 1024
            });
            if (pruned.removed) api?.log?.(`[gilbert] 留档清理：删除 ${pruned.removed} 条，保留 ${pruned.kept} 条`);
          } catch (e) {
            api?.warn?.(`[gilbert] 留档失败（还原将只能走数学路径）：${e?.message ?? e}`);
          }
        }
        if (s.autoSend !== false && ctx?.sender?.sendImage) {
          await ctx.sender.sendImage(ctx.chatKey, { file: r.dst }, {});
          ctx.session?.sent?.push({ type: 'image', text: '[图片:Gilbert 曲线图]' });
          ctx.emit?.('session-update', ctx.session?.id);
        }
        const canvas = 1 << orderFor(r.w, r.h);
        // 还原路径如实回报：模型要据此决定怎么说话（命中留档 = 精确；数学 = 可能很差）
        const viaNote = !decrypt ? ''
          : (r.via === 'vault'
            ? '走的是本地留档的原图，逐字节精确。'
            : (r.reason === 'weak'
              ? '⚠️ 这张图在大尺度上几乎没有结构（近似纯色/均匀噪点），指纹不可靠，'
                + '为了不认错图我主动放弃了匹配。**必须如实告诉群友还原不了**，不要声称成功。'
              : '⚠️ 没有命中本地留档，用的是数学逆置换 —— 如果这张图经过任何重编码/缩放，结果会是乱码。'
                + '这种情况要如实告诉群友"没找到对应的原图，还原不了"，不要声称已还原成功。'));
        return ok({
          ok: true,
          action,
          shift,
          scheme: r.scheme,
          times,
          via: r.via ?? undefined,
          matchDistance: r.distance ?? undefined,
          vaultId: r.vaultId ?? undefined,
          size: `${r.w}×${r.h}`,
          canvas: `${canvas}×${canvas}`,
          file: r.dst,
          note: (s.autoSend !== false ? '已发到当前会话，不要复述路径与算法细节。' : '（自动发送已关闭，仅生成文件）') + viaNote
        });
      } catch (e) {
        return err(`${decrypt ? '解混淆' : '混淆'}失败：${e?.message ?? e}`);
      }
    }
  });
}

export function dispose() { /* 无后台状态 */ }
export { buildPermutation };
