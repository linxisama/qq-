// 算法竞赛助手（acmbot）
//
// 定位：让机器人能查算法竞赛选手的资料、画 rating 变化曲线、报近期比赛。
// 归在 skills/（LLM 型）——「什么时候要查、查谁」完全取决于用户说的话，写不成规则，
// 只能 registerTool 交给模型判断。
//
// ── 密钥怎么存（本技能的核心设计，也是它能上架分享的前提）────────────────
// 用户要求：API 密钥绝不能明文落盘，且这个技能要能分享给别人。
// 所以密钥不进技能目录（分享的是整个 skills/acmbot/，里面一个字节的密钥都没有），
// 而是走「系统钥匙串」：
//   · 密文放 data/acmbot/credentials.enc，用 Electron safeStorage 加密
//     （Windows 上底层是 DPAPI，绑定当前登录用户；换个用户或换台机器都解不开）。
//   · 设置窗口里粘贴的明文，会被立刻加密保存，然后立刻把配置项抹成哨兵值 '******'，
//     不在 data/config.json 里留明文。
//   · 拿不到 safeStorage 时（非 Electron 环境），宁可只有内存里的明文跑这一次，
//     也绝不明文写盘 —— fail-safe，不是 fail-open。
//
// ── 数据来源（全部实测过，不是照文档猜的）──────────────────────────────
//  · Codeforces：官方 API，user.info / user.rating 匿名可用，不需要 key 签名。
//  · AtCoder：没有公开 API，读用户页 HTML(?lang=en)，rating 历史在页面内嵌的
//             var rank_history=[...] 里。
//  · 比赛列表：clist.by v4 API，需要 Authorization: ApiKey 用户名:apikey。
//             ⚠️ resource__in 必须写完整域名（codeforces.com），写短名会静默返回空数组。
//             ⚠️ 返回的 start 是 UTC 且不带时区后缀，必须补 Z 再换算，否则差 8 小时。
//  · 曲线出图：quickchart.io 返回真 PNG。
//
// ── 目录布局（全部在 data/ 下，不进技能目录）─────────────────────────────
//   data/acmbot/credentials.enc   加密后的密钥（safeStorage）
//   data/acmbot/keys.txt          可选的一次性投放文件（读完立刻抹除）
//   data/acmbot/charts/           rating 曲线 PNG（只留最近 20 张）

import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import zlib from 'node:zlib';
import { createRequire } from 'node:module';
import { DATA_DIR } from '../../src/config.js';
import { setSkillConfig } from '../../src/skills/config.js';

const SKILL_ID = 'acmbot';
const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36';
const REQUEST_TIMEOUT = 20000;
const SCRUB = '******';
const SECRET_KEYS = ['codeforcesKey', 'codeforcesSecret', 'clistToken'];
const SPARK_CHARS = '\u2581\u2582\u2583\u2584\u2585\u2586\u2587\u2588';
const CHART_KEEP = 20;

let apiRef = null;
let watchdog = null;
let backendPromise = null;
let backend = null;
let memSecrets = {};
let lastRequestAt = 0;

// ─────────────────────────── 小工具 ───────────────────────────

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const ok = (payload) => ({ content: typeof payload === 'string' ? payload : JSON.stringify(payload, null, 1) });
const err = (message) => ({ content: '错误：' + String(message), isError: true });
const clipText = (s, n) => {
  const t = String(s === null || s === undefined ? '' : s).trim();
  return t.length > n ? t.slice(0, n) + '…（已截断）' : t;
};
const toArray = (v) => {
  if (v === null || v === undefined || v === '') return [];
  return Array.isArray(v) ? v.filter((x) => String(x).trim() !== '') : [v];
};
const fp = (v) => (v ? crypto.createHash('sha256').update(String(v)).digest('hex').slice(0, 8) : '');
const num = (v, dft, lo, hi) => {
  const n = Number(v);
  if (!Number.isFinite(n)) return dft;
  return Math.max(lo, Math.min(hi, Math.round(n)));
};
const strOr = (v, dft) => {
  const s = String(v === null || v === undefined ? '' : v).trim();
  return s || dft;
};

function stripTags(s) {
  return String(s === null || s === undefined ? '' : s)
    .replace(/<[^>]*>/g, '')
    .replace(/&nbsp;/g, ' ')
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/\s+/g, ' ')
    .trim();
}

const WD_CN = ['周日', '周一', '周二', '周三', '周四', '周五', '周六'];

/**
 * 把一个毫秒时间戳按指定 UTC 偏移算成本地日期时间。
 * 必须用 Date.UTC + offset 手算：服务器时区可能是任意值，直接用 Date 的本地方法是错的。
 */
function localParts(ms, utcOffset) {
  const off = Number.isFinite(utcOffset) ? utcOffset : 8;
  const d = new Date(Number(ms) + off * 3600000);
  const y = d.getUTCFullYear();
  const mo = d.getUTCMonth() + 1;
  const da = d.getUTCDate();
  const hh = String(d.getUTCHours()).padStart(2, '0');
  const mi = String(d.getUTCMinutes()).padStart(2, '0');
  const wd = WD_CN[d.getUTCDay()];
  const now = new Date(Date.now() + off * 3600000);
  const dayDiff = Math.round(
    (Date.UTC(y, mo - 1, da) - Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate())) / 86400000
  );
  let rel = '';
  if (dayDiff === 0) rel = '今天';
  else if (dayDiff === 1) rel = '明天';
  else if (dayDiff === 2) rel = '后天';
  else if (dayDiff === -1) rel = '昨天';
  else if (dayDiff > 0 && dayDiff < 7) rel = dayDiff + '天后';
  else if (dayDiff < 0 && dayDiff > -7) rel = (-dayDiff) + '天前';
  return {
    date: y + '-' + String(mo).padStart(2, '0') + '-' + String(da).padStart(2, '0'),
    time: hh + ':' + mi,
    wd,
    rel,
    monthDay: mo + '月' + da + '日'
  };
}

function sparkline(values) {
  const arr = (values || []).map(Number).filter((n) => Number.isFinite(n));
  if (arr.length < 2) return '';
  let lo = Math.min.apply(null, arr);
  let hi = Math.max.apply(null, arr);
  if (hi === lo) hi = lo + 1;
  return arr
    .map((v) => SPARK_CHARS[Math.max(0, Math.min(SPARK_CHARS.length - 1, Math.round((v - lo) / (hi - lo) * (SPARK_CHARS.length - 1))))])
    .join('');
}

function conf() {
  let raw = {};
  try {
    if (apiRef && typeof apiRef.config === 'function') raw = apiRef.config() || {};
  } catch (e) {
    raw = {};
  }
  const off = Number(raw.utcOffset);
  return {
    raceLimit: num(raw.raceLimit, 10, 1, 50),
    ratingChart: raw.ratingChart === 'text' ? 'text' : 'image',
    chartPoints: num(raw.chartPoints, 40, 5, 200),
    requestGapMs: num(raw.requestGapMs, 400, 100, 5000),
    utcOffset: Number.isFinite(off) ? Math.max(-12, Math.min(14, off)) : 8,
    platforms: strOr(raw.platforms, 'codeforces,atcoder,leetcode,luogu,nowcoder'),
    // 默认留空 = 本地渲染（不依赖任何外部服务）；填了 http(s) 地址才走在线出图
    chartService: strOr(raw.chartService, '')
  };
}

// ─────────────────────────── 密钥存取（加密层）───────────────────────────

const pathsOf = () => {
  const base = path.join(DATA_DIR || path.join(process.cwd(), 'data'), 'acmbot');
  return {
    dir: base,
    creds: path.join(base, 'credentials.enc'),
    keysFile: path.join(base, 'keys.txt'),
    charts: path.join(base, 'charts')
  };
};

/**
 * 拿系统级加密后端。Electron 的 safeStorage 在 Windows 上就是 DPAPI。
 * 两种引入方式都试：createRequire（CJS 解析，主进程最稳）+ 动态 import（ESM）。
 * 都失败就返回 null —— 调用方据此决定"绝不落盘明文"。
 */
async function ensureBackend() {
  if (backendPromise) return backendPromise;
  backendPromise = (async () => {
    const mods = [];
    try {
      const req = createRequire(import.meta.url);
      mods.push(req('electron'));
    } catch (e) { /* 不是 Electron 环境 */ }
    try {
      const m = await import('electron');
      mods.push(m && m.default ? m.default : m);
    } catch (e) { /* 同上 */ }
    for (const mod of mods) {
      const ss = mod && mod.safeStorage;
      try {
        if (ss && typeof ss.isEncryptionAvailable === 'function' && ss.decryptString && ss.encryptString && ss.isEncryptionAvailable()) {
          backend = ss;
          return backend;
        }
      } catch (e) { /* 换下一个候选 */ }
    }
    backend = null;
    return null;
  })();
  return backendPromise;
}

async function loadSecrets() {
  const p = pathsOf();
  try {
    if (!fs.existsSync(p.creds)) return {};
    const raw = JSON.parse(fs.readFileSync(p.creds, 'utf8'));
    const b = await ensureBackend();
    if (!b) {
      warn('检测到已加密的密钥文件，但当前环境拿不到系统加密后端，本次读不到密钥。');
      return {};
    }
    const json = b.decryptString(Buffer.from(String(raw && raw.data ? raw.data : ''), 'base64'));
    const obj = JSON.parse(json);
    return obj && typeof obj === 'object' ? obj : {};
  } catch (e) {
    warn('读取加密密钥失败（可能是换了 Windows 账户或换了机器）：' + (e && e.message ? e.message : e));
    return {};
  }
}

async function saveSecrets(obj) {
  const p = pathsOf();
  const b = await ensureBackend();
  if (!b) return false;
  try {
    fs.mkdirSync(p.dir, { recursive: true });
    const cipher = b.encryptString(JSON.stringify(obj || {}));
    const payload = JSON.stringify({
      v: 1,
      enc: 'safeStorage',
      at: new Date().toISOString(),
      data: Buffer.from(cipher).toString('base64')
    });
    const tmp = p.creds + '.tmp';
    fs.writeFileSync(tmp, payload, 'utf8');
    try { fs.chmodSync(tmp, 0o600); } catch (e) { /* Windows 上无所谓 */ }
    try { fs.rmSync(p.creds, { force: true }); } catch (e) { /* 忽略 */ }
    fs.renameSync(tmp, p.creds);
    return true;
  } catch (e) {
    warn('加密保存密钥失败：' + (e && e.message ? e.message : e));
    return false;
  }
}

/** 覆写 + 删除：先写全 0，再写随机字节，最后删掉。 */
async function shredFile(f) {
  try {
    if (!fs.existsSync(f)) return;
    let size = 512;
    try { size = Math.max(512, fs.statSync(f).size); } catch (e) { /* 用默认值 */ }
    try { fs.writeFileSync(f, Buffer.alloc(size, 0)); } catch (e) { /* 忽略 */ }
    try { fs.writeFileSync(f, crypto.randomBytes(size)); } catch (e) { /* 忽略 */ }
    fs.rmSync(f, { force: true });
  } catch (e) {
    try { fs.rmSync(f, { force: true }); } catch (e2) { /* 忽略 */ }
  }
}

const KEY_ALIASES = {
  codeforces_key: 'codeforcesKey',
  codeforceskey: 'codeforcesKey',
  cf_key: 'codeforcesKey',
  cfkey: 'codeforcesKey',
  codeforces_secret: 'codeforcesSecret',
  codeforcessecret: 'codeforcesSecret',
  cf_secret: 'codeforcesSecret',
  cfsecret: 'codeforcesSecret',
  clist_token: 'clistToken',
  clisttoken: 'clistToken',
  clist_key: 'clistToken',
  clistkey: 'clistToken',
  clist: 'clistToken'
};

/** 解析 "codeforces_key = xxx" / "clist_token: ApiKey a:b" 这类一行一条的文本。 */
function parseKeysText(text) {
  const out = {};
  for (const line of String(text || '').split(/\r?\n/)) {
    const t = line.trim();
    if (!t || t.startsWith('#') || t.startsWith('//')) continue;
    const m = /^([^:=]+?)\s*[:=]\s*(.+)$/.exec(t);
    if (!m) continue;
    const name = m[1].trim().toLowerCase().replace(/[\s-]+/g, '_');
    const key = KEY_ALIASES[name] || KEY_ALIASES[name.replace(/_/g, '')];
    if (!key) continue;
    out[key] = m[2].trim();
  }
  return out;
}

/** 一次性投放文件：data/acmbot/keys.txt → 加密保存 → 抹除原文件。 */
async function ingestPlaintextFile() {
  const p = pathsOf();
  if (!fs.existsSync(p.keysFile)) return null;
  let text = '';
  try { text = fs.readFileSync(p.keysFile, 'utf8'); } catch (e) { return null; }
  const parsed = parseKeysText(text);
  if (!Object.keys(parsed).length) {
    warn('data/acmbot/keys.txt 里没解析到任何已知字段（支持 codeforces_key / codeforces_secret / clist_token），文件原样保留。');
    return null;
  }
  const saved = await saveSecrets(parsed);
  if (saved) {
    await shredFile(p.keysFile);
    log('已把 keys.txt 里的密钥加密保存，并把原文件抹除。');
  } else {
    warn('系统加密不可用，keys.txt 没有处理（也绝不明文复制到别处）。');
  }
  return parsed;
}

/** 把设置窗口里粘贴的明文：加密保存 → 配置项抹成哨兵值。 */
async function absorbFromConfig(saved) {
  let raw = {};
  try {
    if (apiRef && typeof apiRef.config === 'function') raw = apiRef.config() || {};
  } catch (e) { raw = {}; }
  const found = {};
  for (const k of SECRET_KEYS) {
    const v = raw[k];
    if (typeof v === 'string' && v.trim() && v.trim() !== SCRUB) found[k] = v.trim();
  }
  if (!Object.keys(found).length) return null;
  const merged = Object.assign({}, saved || {}, found);
  if (!(await saveSecrets(merged))) {
    warn('系统加密不可用：设置里填的密钥不会明文写盘，只在本次运行的内存里生效，重启后需要重填。');
    return merged;
  }
  const patch = {};
  for (const k of Object.keys(found)) patch[k] = SCRUB;
  try { setSkillConfig(SKILL_ID, patch); }
  catch (e) { warn('密钥已加密保存，但没能把配置里的明文抹掉，请手动到技能设置里清空一次。'); }
  return merged;
}

async function refreshSecrets(first) {
  const ingested = await ingestPlaintextFile();
  let saved = await loadSecrets();
  if (ingested) saved = Object.assign({}, saved, ingested);
  const merged = await absorbFromConfig(saved);
  if (merged) saved = merged;
  memSecrets = saved || {};
  if (first) {
    const bits = SECRET_KEYS.map((k) => k + '=' + (fp(memSecrets[k]) || '未配置'));
    log('密钥状态：' + bits.join(' / ') + (memSecrets.codeforcesKey || memSecrets.codeforcesSecret ? '（CF 密钥可选，匿名也能查）' : ''));
  }
  return memSecrets;
}

const secret = (k) => {
  const v = memSecrets && memSecrets[k];
  return v ? String(v).trim() : '';
};

function warn(...args) {
  try { if (apiRef && apiRef.warn) apiRef.warn(...args); } catch (e) { /* 忽略 */ }
}
function log(...args) {
  try { if (apiRef && apiRef.log) apiRef.log(...args); } catch (e) { /* 忽略 */ }
}

// ─────────────────────────── HTTP ───────────────────────────

async function rawRequest(url, opts) {
  const o = opts || {};
  if (!apiRef || typeof apiRef.fetch !== 'function') throw new Error('本技能没有联网权限（清单缺 permissions: [web_fetch]）');
  const gap = Number.isFinite(o.gapMs) ? o.gapMs : conf().requestGapMs;
  const wait = Math.max(0, lastRequestAt + gap - Date.now());
  if (wait > 0) await sleep(wait);
  lastRequestAt = Date.now();

  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), Number.isFinite(o.timeoutMs) ? o.timeoutMs : REQUEST_TIMEOUT);
  try {
    const res = await apiRef.fetch(url, {
      method: o.method || 'GET',
      headers: Object.assign({
        'User-Agent': UA,
        Accept: o.accept || 'application/json, text/plain, */*'
      }, o.headers || {}),
      signal: controller.signal
    });
    if (o.binary) {
      const buf = Buffer.from(await res.arrayBuffer());
      return { status: res.status, ok: res.ok, buf };
    }
    const text = await res.text();
    return { status: res.status, ok: res.ok, text };
  } finally {
    clearTimeout(timer);
  }
}

// ─────────────────────────── Codeforces ───────────────────────────

function cfTier(rating) {
  const r = Number(rating);
  if (!Number.isFinite(r) || r <= 0) return { label: '未定级', en: 'Unrated', color: '#808080' };
  if (r >= 3000) return { label: '传奇特级大师', en: 'Legendary Grandmaster', color: '#aa0000' };
  if (r >= 2600) return { label: '国际特级大师', en: 'International Grandmaster', color: '#ff0000' };
  if (r >= 2400) return { label: '特级大师', en: 'Grandmaster', color: '#ff0000' };
  if (r >= 2300) return { label: '国际大师', en: 'International Master', color: '#ff8c00' };
  if (r >= 2100) return { label: '大师', en: 'Master', color: '#ff8c00' };
  if (r >= 1900) return { label: '候选大师', en: 'Candidate Master', color: '#aa00aa' };
  if (r >= 1600) return { label: '专家', en: 'Expert', color: '#0000ff' };
  if (r >= 1400) return { label: '熟练', en: 'Specialist', color: '#03a89e' };
  if (r >= 1200) return { label: '学徒', en: 'Pupil', color: '#008000' };
  return { label: '新手', en: 'Newbie', color: '#808080' };
}

async function cfApi(method, params) {
  const qs = new URLSearchParams(params || {}).toString();
  const url = 'https://codeforces.com/api/' + method + (qs ? '?' + qs : '');
  const r = await rawRequest(url, { accept: 'application/json' });
  let data = null;
  try { data = JSON.parse(r.text); } catch (e) { throw new Error('Codeforces 返回了非 JSON 内容（HTTP ' + r.status + '）'); }
  if (!data || data.status !== 'OK') {
    const comment = String((data && data.comment) || '');
    if (/not found/i.test(comment)) return { found: false, reason: comment };
    if (r.status === 429 || /limit/i.test(comment)) throw new Error('Codeforces 限流了（请求太密），过一会儿再试');
    throw new Error('Codeforces 返回错误：' + (comment || ('status=' + (data && data.status))));
  }
  return { found: true, result: data.result };
}

async function fetchCfUser(handle) {
  const r = await cfApi('user.info', { handles: handle });
  if (!r.found) return { found: false };
  const u = Array.isArray(r.result) ? r.result[0] : r.result;
  if (!u || !u.handle) return { found: false };
  return { found: true, user: u };
}

async function fetchCfRating(handle) {
  const r = await cfApi('user.rating', { handle: handle });
  if (!r.found) return { found: false };
  return { found: true, rows: Array.isArray(r.result) ? r.result : [] };
}

function fmtCfUser(u) {
  const c = conf();
  const tier = cfTier(u.rating);
  const maxTier = cfTier(u.maxRating);
  return {
    platform: 'Codeforces',
    handle: u.handle,
    nickname: u.firstName ? [u.firstName, u.lastName].filter(Boolean).join(' ') : '',
    rating: u.rating !== undefined ? u.rating : '未定级',
    rank: tier.label,
    maxRating: u.maxRating !== undefined ? u.maxRating : '未定级',
    maxRank: maxTier.label,
    contribution: u.contribution,
    friends: u.friendOfCount,
    organization: u.organization || undefined,
    country: u.country || undefined,
    registered: localParts(Number(u.registrationTimeSeconds) * 1000, c.utcOffset).date,
    lastSeen: u.lastOnlineTimeSeconds ? localParts(Number(u.lastOnlineTimeSeconds) * 1000, c.utcOffset).date : undefined,
    avatar: u.titlePhoto || u.avatar || undefined,
    url: 'https://codeforces.com/profile/' + u.handle
  };
}

// ─────────────────────────── AtCoder ───────────────────────────

function atTier(rating) {
  const r = Number(rating);
  if (!Number.isFinite(r) || r <= 0) return { label: '未定级', color: '#808080' };
  if (r >= 2800) return { label: '红', color: '#ff0000' };
  if (r >= 2400) return { label: '橙', color: '#ff8000' };
  if (r >= 2000) return { label: '黄', color: '#c0c000' };
  if (r >= 1600) return { label: '蓝', color: '#0000ff' };
  if (r >= 1200) return { label: '青', color: '#00c0c0' };
  if (r >= 800) return { label: '绿', color: '#008000' };
  if (r >= 400) return { label: '茶', color: '#804000' };
  return { label: '灰', color: '#808080' };
}

/** AtCoder 用户页的资料是 <tr><th>标签</th><td>值</td></tr> 的通用结构，直接扫。 */
function parseLabelTable(html) {
  const out = {};
  const re = /<tr[^>]*>\s*<th[^>]*>([\s\S]*?)<\/th>\s*<td[^>]*>([\s\S]*?)<\/td>\s*<\/tr>/gi;
  let m;
  while ((m = re.exec(html))) {
    const k = stripTags(m[1]);
    if (!k) continue;
    if (out[k] === undefined) out[k] = stripTags(m[2]);
  }
  return out;
}

function parseAtRankHistory(html) {
  const m = /var\s+rank_history\s*=\s*(\[[\s\S]*?\])\s*;/.exec(String(html || ''));
  if (!m) return [];
  try {
    const arr = JSON.parse(m[1]);
    return Array.isArray(arr) ? arr : [];
  } catch (e) {
    return [];
  }
}

function parseAtUser(html, handle) {
  const table = parseLabelTable(html);
  const pick = (name) => {
    const want = name.toLowerCase();
    for (const k of Object.keys(table)) {
      if (k.toLowerCase() === want) return table[k];
    }
    return '';
  };
  const exists = Boolean(table['Rating']) || Boolean(table['Rated Matches']);
  if (!exists) return { exists: false };
  const firstInt = (s) => {
    const m = /(\d{1,4})/.exec(String(s || ''));
    return m ? Number(m[1]) : null;
  };
  const rating = firstInt(pick('Rating'));
  const highest = firstInt(pick('Highest Rating'));
  return {
    exists: true,
    handle,
    rating,
    rank: firstInt(pick('Rank')),
    highestRating: highest,
    ratedMatches: firstInt(pick('Rated Matches')),
    lastCompeted: pick('Last Competed') || undefined,
    country: pick('Country') || undefined,
    birthYear: firstInt(pick('Birth Year')) || undefined,
    url: 'https://atcoder.jp/users/' + handle
  };
}

async function fetchAtUser(handle) {
  const url = 'https://atcoder.jp/users/' + encodeURIComponent(handle) + '?lang=en';
  const r = await rawRequest(url, { accept: 'text/html' });
  if (r.status === 404) return { found: false };
  if (!r.ok) throw new Error('AtCoder 返回 HTTP ' + r.status);
  const html = r.text || '';
  const info = parseAtUser(html, handle);
  if (!info.exists) return { found: false };
  return { found: true, info, history: parseAtRankHistory(html) };
}

function fmtAtUser(info) {
  const tier = atTier(info.rating);
  const maxTier = atTier(info.highestRating);
  return {
    platform: 'AtCoder',
    handle: info.handle,
    rating: info.rating === null ? '未定级' : info.rating,
    colorRank: tier.label,
    highestRating: info.highestRating === null ? '未定级' : info.highestRating,
    highestColorRank: maxTier.label,
    internalRank: info.rank,
    ratedMatches: info.ratedMatches,
    lastCompeted: info.lastCompeted,
    country: info.country,
    birthYear: info.birthYear,
    url: info.url
  };
}

// ─────────────────────────── 比赛列表（clist.by）───────────────────────────

const RACE_PLATFORMS = [
  { key: 'cf', label: 'Codeforces', resource: 'codeforces.com', aliases: ['cf', 'codeforces', 'codeforces.com'] },
  { key: 'at', label: 'AtCoder', resource: 'atcoder.jp', aliases: ['at', 'atc', 'atcoder', 'atcoder.jp'] },
  { key: 'lc', label: 'LeetCode', resource: 'leetcode.com', aliases: ['lc', '力扣', 'leetcode', 'leetcode.com'] },
  { key: 'lg', label: '洛谷', resource: 'luogu.com.cn', aliases: ['lg', 'luogu', '洛谷', 'luogu.com.cn'] },
  { key: 'nk', label: '牛客', resource: 'nowcoder.com', aliases: ['nk', 'nowcoder', '牛客', 'nowcoder.com'] }
];

function resolveRacePlatforms(specs) {
  const wanted = toArray(specs).map((x) => String(x).trim().toLowerCase()).filter(Boolean);
  if (!wanted.length) return [];
  const hit = [];
  for (const spec of wanted) {
    const p = RACE_PLATFORMS.find((rp) => rp.key === spec || rp.aliases.indexOf(spec) >= 0);
    if (p && hit.indexOf(p) < 0) hit.push(p);
  }
  return hit;
}

function defaultRacePlatforms() {
  const fromCfg = resolveRacePlatforms(conf().platforms.split(/[,，]/));
  return fromCfg.length ? fromCfg : RACE_PLATFORMS.slice();
}

function platformLabelByResource(resource) {
  const p = RACE_PLATFORMS.find((rp) => rp.resource === resource);
  return p ? p.label : String(resource || '其他');
}

async function fetchRaces(opts) {
  const o = opts || {};
  const token = secret('clistToken');
  if (!token) {
    throw new Error('比赛列表需要 Clist 的 api key：去 https://clist.by 登录后在 /api/ 页面拿 apikey，'
      + '格式形如 "ApiKey 用户名:apikey"，填进本技能的设置项 clistToken。');
  }
  const platforms = (o.platforms && o.platforms.length) ? o.platforms : defaultRacePlatforms();
  const params = new URLSearchParams();
  params.set('upcoming', 'true');
  params.set('order_by', 'start');
  params.set('limit', String(o.limit || 10));
  params.set('offset', String(o.offset || 0));
  params.set('resource__in', platforms.map((p) => p.resource).join(','));
  const url = 'https://clist.by/api/v4/contest/?' + params.toString();
  const r = await rawRequest(url, { headers: { Authorization: token }, accept: 'application/json' });
  if (r.status === 401 || r.status === 403) throw new Error('Clist 鉴权失败（HTTP ' + r.status + '）：token 可能写错了，或漏了 "ApiKey " 前缀');
  if (r.status === 429) throw new Error('Clist 限流了，过一会儿再试');
  if (!r.ok) throw new Error('Clist 返回 HTTP ' + r.status);
  let data = null;
  try { data = JSON.parse(r.text); } catch (e) { throw new Error('Clist 返回了非 JSON 内容'); }
  const objs = Array.isArray(data && data.objects) ? data.objects : [];
  const c = conf();
  return objs.map((o2) => {
    // clist 的 start 是 UTC 但没有时区后缀，必须补 Z 才能正确换算
    const ms = Date.parse(String(o2.start || '').replace(' ', 'T') + 'Z');
    const lp = Number.isFinite(ms) ? localParts(ms, c.utcOffset) : null;
    const durSec = Number(o2.duration);
    return {
      name: o2.event || o2.href || '(未命名)',
      platform: platformLabelByResource(o2.resource),
      start: lp ? (lp.date + ' ' + lp.time) : String(o2.start || ''),
      weekday: lp ? lp.wd : '',
      relative: lp ? lp.rel : '',
      durationHours: Number.isFinite(durSec) && durSec > 0 ? Math.round(durSec / 360) / 10 : undefined,
      url: o2.href
    };
  });
}

// ─────────────────────────── rating 曲线 ───────────────────────────

function collectCfSeries(rows) {
  const out = [];
  for (const r of rows || []) {
    if (!r) continue;
    out.push({
      at: Number(r.ratingUpdateTimeSeconds) * 1000,
      value: Number(r.newRating),
      delta: Number(r.newRating) - Number(r.oldRating),
      rank: Number(r.rank),
      name: r.contestName || ('比赛 ' + r.contestId)
    });
  }
  return out.filter((p) => Number.isFinite(p.at) && Number.isFinite(p.value)).sort((a, b) => a.at - b.at);
}

function collectAtSeries(history) {
  const out = [];
  for (const h of history || []) {
    if (!h) continue;
    out.push({
      at: Number(h.EndTime) * 1000,
      value: Number(h.Rating),
      rank: Number(h.Rank),
      name: h.ContestName || '',
      url: h.ContestUrl || ''
    });
  }
  return out.filter((p) => Number.isFinite(p.at) && Number.isFinite(p.value)).sort((a, b) => a.at - b.at);
}

function chartUrl(points, title, color) {
  const c = conf();
  const pts = points.slice(Math.max(0, points.length - c.chartPoints));
  const labels = pts.map((p) => localParts(p.at, c.utcOffset).date.slice(5));
  const chart = {
    type: 'line',
    data: {
      labels: labels,
      datasets: [{
        label: title,
        data: pts.map((p) => p.value),
        borderColor: color || '#3b82f6',
        backgroundColor: 'rgba(59,130,246,0.15)',
        fill: true,
        borderWidth: 2,
        pointRadius: pts.length > 60 ? 0 : 3,
        tension: 0.25
      }]
    },
    options: {
      legend: { display: false },
      title: { display: true, text: title, fontSize: 16 },
      scales: { yAxes: [{ ticks: { precision: 0, maxTicksLimit: 8 } }] }
    }
  };
  return c.chartService + '?w=680&h=320&bkg=white&f=png&c=' + encodeURIComponent(JSON.stringify(chart));
}

function pruneCharts(dir, keep) {
  try {
    const files = fs.readdirSync(dir)
      .filter((f) => f.toLowerCase().endsWith('.png'))
      .map((f) => {
        const full = path.join(dir, f);
        let mtime = 0;
        try { mtime = fs.statSync(full).mtimeMs; } catch (e) { mtime = 0; }
        return { full, mtime };
      })
      .sort((a, b) => b.mtime - a.mtime);
    for (const f of files.slice(keep || CHART_KEEP)) {
      try { fs.rmSync(f.full, { force: true }); } catch (e) { /* 忽略 */ }
    }
  } catch (e) { /* 忽略 */ }
}

async function sendChartImage(ctx, url, fileName) {
  const p = pathsOf();
  fs.mkdirSync(p.charts, { recursive: true });
  const r = await rawRequest(url, { binary: true, timeoutMs: 30000 });
  if (!r.ok) throw new Error('出图服务返回 HTTP ' + r.status);
  const buf = r.buf;
  if (!buf || buf.length < 8 || buf[0] !== 0x89 || buf[1] !== 0x50 || buf[2] !== 0x4e || buf[3] !== 0x47) {
    throw new Error('出图服务没返回 PNG（可能被限流了）');
  }
  const file = path.join(p.charts, fileName);
  fs.writeFileSync(file, buf);
  pruneCharts(p.charts, CHART_KEEP);
  if (!ctx || !ctx.sender || typeof ctx.sender.sendImage !== 'function' || !ctx.chatKey) {
    throw new Error('当前会话拿不到发图能力');
  }
  await ctx.sender.sendImage(ctx.chatKey, { file: file, dataUrl: 'base64://' + buf.toString('base64') }, { note: 'rating 曲线' });
  try {
    if (ctx.session && Array.isArray(ctx.session.sent)) {
      ctx.session.sent.push({ type: 'image', text: '[图片:rating 曲线]', at: new Date().toLocaleTimeString('zh-CN', { hour12: false }) });
    }
  } catch (e) { /* 忽略 */ }
  return file;
}

// ────────────────── 本地出图：零依赖 PNG 折线图（离线可用）──────────────────
// 为什么要有它：quickchart.io 这类公共出图服务在有些网络里压根连不上
// （实测本机连 quickchart 的 Cloudflare IP 全部连接超时），而曲线图是 rating 工具的核心输出。
// 所以在本地自己画：手写 PNG 编码 + 5x7 点阵字，零依赖、离线可用，分享给别人也不会因为
// 「对方网络连不上出图服务」而变成只发文字。配置里填了 http(s) 出图服务地址才走远程，
// 远程失败会自动回落到本地渲染。

const PNG_SIG = Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]);
let CRC_TABLE = null;

function crcTable() {
  if (CRC_TABLE) return CRC_TABLE;
  const t = new Int32Array(256);
  for (let n = 0; n < 256; n++) {
    let c = n;
    for (let k = 0; k < 8; k++) c = (c & 1) ? (0xedb88320 ^ (c >>> 1)) : (c >>> 1);
    t[n] = c;
  }
  CRC_TABLE = t;
  return t;
}

function crc32(buf) {
  const t = crcTable();
  let c = -1;
  for (let i = 0; i < buf.length; i++) c = t[(c ^ buf[i]) & 0xff] ^ (c >>> 8);
  return (c ^ -1) >>> 0;
}

function pngChunk(type, data) {
  const len = Buffer.alloc(4);
  len.writeUInt32BE(data.length, 0);
  const body = Buffer.concat([Buffer.from(type, "latin1"), data]);
  const crc = Buffer.alloc(4);
  crc.writeUInt32BE(crc32(body), 0);
  return Buffer.concat([len, body, crc]);
}

/** 把 RGB 像素缓冲编码成 PNG（8bit truecolor，zlib 压缩，无第三方依赖）。 */
function encodePng(width, height, rgb) {
  const stride = width * 3;
  const raw = Buffer.alloc((stride + 1) * height);
  for (let y = 0; y < height; y++) {
    raw[y * (stride + 1)] = 0; // filter: none
    rgb.copy(raw, y * (stride + 1) + 1, y * stride, (y + 1) * stride);
  }
  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(width, 0);
  ihdr.writeUInt32BE(height, 4);
  ihdr[8] = 8;  // bit depth
  ihdr[9] = 2;  // color type: truecolor
  return Buffer.concat([
    PNG_SIG,
    pngChunk('IHDR', ihdr),
    pngChunk('IDAT', zlib.deflateSync(raw, { level: 9 })),
    pngChunk('IEND', Buffer.alloc(0))
  ]);
}

// 5x7 点阵字（大写 + 数字 + 常用符号），够写标题和坐标轴。
const FONT = {
  '0': '01110,10001,10011,10101,11001,10001,01110',
  '1': '00100,01100,00100,00100,00100,00100,01110',
  '2': '01110,10001,00001,00010,00100,01000,11111',
  '3': '11111,00010,00100,00010,00001,10001,01110',
  '4': '00010,00110,01010,10010,11111,00010,00010',
  '5': '11111,10000,11110,00001,00001,10001,01110',
  '6': '00110,01000,10000,11110,10001,10001,01110',
  '7': '11111,00001,00010,00100,01000,01000,01000',
  '8': '01110,10001,10001,01110,10001,10001,01110',
  '9': '01110,10001,10001,01111,00001,00010,01100',
  'A': '01110,10001,10001,11111,10001,10001,10001',
  'B': '11110,10001,10001,11110,10001,10001,11110',
  'C': '01110,10001,10000,10000,10000,10001,01110',
  'D': '11100,10010,10001,10001,10001,10010,11100',
  'E': '11111,10000,10000,11110,10000,10000,11111',
  'F': '11111,10000,10000,11110,10000,10000,10000',
  'G': '01110,10001,10000,10111,10001,10001,01111',
  'H': '10001,10001,10001,11111,10001,10001,10001',
  'I': '01110,00100,00100,00100,00100,00100,01110',
  'J': '00111,00010,00010,00010,00010,10010,01100',
  'K': '10001,10010,10100,11000,10100,10010,10001',
  'L': '10000,10000,10000,10000,10000,10000,11111',
  'M': '10001,11011,10101,10101,10001,10001,10001',
  'N': '10001,11001,10101,10011,10001,10001,10001',
  'O': '01110,10001,10001,10001,10001,10001,01110',
  'P': '11110,10001,10001,11110,10000,10000,10000',
  'Q': '01110,10001,10001,10001,10101,10010,01101',
  'R': '11110,10001,10001,11110,10100,10010,10001',
  'S': '01111,10000,10000,01110,00001,00001,11110',
  'T': '11111,00100,00100,00100,00100,00100,00100',
  'U': '10001,10001,10001,10001,10001,10001,01110',
  'V': '10001,10001,10001,10001,10001,01010,00100',
  'W': '10001,10001,10001,10101,10101,11011,10001',
  'X': '10001,10001,01010,00100,01010,10001,10001',
  'Y': '10001,10001,01010,00100,00100,00100,00100',
  'Z': '11111,00001,00010,00100,01000,10000,11111',
  ' ': '00000,00000,00000,00000,00000,00000,00000',
  '-': '00000,00000,00000,11111,00000,00000,00000',
  '.': '00000,00000,00000,00000,00000,01100,01100',
  ':': '00000,01100,01100,00000,01100,01100,00000',
  '/': '00001,00010,00010,00100,01000,01000,10000',
  '+': '00000,00100,00100,11111,00100,00100,00000',
  '(': '00010,00100,01000,01000,01000,00100,00010',
  ')': '01000,00100,00010,00010,00010,00100,01000',
  '!': '00100,00100,00100,00100,00100,00000,00100',
  ',': '00000,00000,00000,00000,01100,00100,01000',
  '?': '01110,10001,00001,00110,00100,00000,00100',
  '*': '00000,10101,01110,11111,01110,10101,00000',
  '%': '11001,11010,00010,00100,01000,01011,10011'
};

/** 极简画布：填色 / 线段 / 点阵文字，够画折线图。 */
class Canvas {
  constructor(w, h, bg) {
    this.w = w;
    this.h = h;
    this.buf = Buffer.alloc(w * h * 3);
    this.fill(0, 0, w, h, bg || [255, 255, 255]);
  }
  px(x, y, c) {
    const xi = Math.round(x), yi = Math.round(y);
    if (xi < 0 || yi < 0 || xi >= this.w || yi >= this.h) return;
    const i = (yi * this.w + xi) * 3;
    this.buf[i] = c[0];
    this.buf[i + 1] = c[1];
    this.buf[i + 2] = c[2];
  }
  fill(x0, y0, x1, y1, c) {
    for (let y = Math.round(y0); y < Math.round(y1); y++) {
      for (let x = Math.round(x0); x < Math.round(x1); x++) this.px(x, y, c);
    }
  }
  line(x0, y0, x1, y1, c, th) {
    const t = Math.max(1, Math.round(th || 1));
    const dx = x1 - x0, dy = y1 - y0;
    const steps = Math.max(1, Math.ceil(Math.max(Math.abs(dx), Math.abs(dy))));
    const half = (t - 1) / 2;
    for (let s = 0; s <= steps; s++) {
      const cx = x0 + (dx * s) / steps, cy = y0 + (dy * s) / steps;
      for (let oy = 0; oy < t; oy++) for (let ox = 0; ox < t; ox++) this.px(cx - half + ox, cy - half + oy, c);
    }
  }
  textWidth(str, scale) { return String(str).length * 6 * (scale || 2); }
  text(x, y, str, c, scale) {
    const s = Math.max(1, scale || 2);
    let cx = Math.round(x);
    const cy = Math.round(y);
    for (const raw of String(str)) {
      const ch = raw === "·" ? "." : raw.toUpperCase();
      const g = FONT[ch] || FONT['?'];
      const rows = g.split(',');
      for (let ry = 0; ry < rows.length; ry++) {
        for (let rx = 0; rx < rows[ry].length; rx++) {
          if (rows[ry][rx] !== '1') continue;
          for (let oy = 0; oy < s; oy++) for (let ox = 0; ox < s; ox++) this.px(cx + rx * s + ox, cy + ry * s + oy, c);
        }
      }
      cx += 6 * s;
    }
  }
}

const CHART_W = 680;
const CHART_H = 320;

function hexToRgb(hex) {
  const m = /^#?([0-9a-f]{6})$/i.exec(String(hex || '').trim());
  if (!m) return [59, 130, 246];
  const n = parseInt(m[1], 16);
  return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
}

/** 用本地渲染器画一张 rating 折线图，返回 PNG Buffer。points: [{ at, value }]。 */
function renderRatingPng(points, opts) {
  const o = opts || {};
  const cv = new Canvas(CHART_W, CHART_H, [255, 255, 255]);
  const ink = [17, 24, 39], faint = [226, 232, 240], mid = [100, 116, 139], areaC = [219, 234, 254];
  const lineC = hexToRgb(o.color || '#3b82f6'), dotC = [30, 64, 175];
  const L = 78, R = 18, T = 50, B = 42;
  const px0 = L, px1 = CHART_W - R, py0 = T, py1 = CHART_H - B;
  const vals = points.map((p) => Number(p.value));
  let mn = Math.min.apply(null, vals), mx = Math.max.apply(null, vals);
  const padv = Math.max(25, Math.round((mx - mn) * 0.15));
  mn = Math.floor((mn - padv) / 50) * 50;
  mx = Math.ceil((mx + padv) / 50) * 50;
  if (mx - mn < 100) mx = mn + 100;
  const xAt = (i) => (points.length < 2 ? (px0 + px1) / 2 : px0 + ((px1 - px0) * i) / (points.length - 1));
  const yAt = (v) => py1 - ((v - mn) / (mx - mn)) * (py1 - py0);

  // 折线下方淡色填充
  if (points.length > 1) {
    for (let x = px0; x <= px1; x++) {
      const t = (x - px0) / Math.max(1, px1 - px0);
      const idx = t * (points.length - 1);
      const i0 = Math.floor(idx), i1 = Math.min(points.length - 1, i0 + 1);
      const v = vals[i0] + (vals[i1] - vals[i0]) * (idx - i0);
      const y = Math.round(yAt(v));
      for (let yy = y; yy <= py1; yy++) cv.px(x, yy, areaC);
    }
  }
  // 横向网格 + y 轴刻度
  const TICKS = 4;
  for (let i = 0; i <= TICKS; i++) {
    const v = mn + ((mx - mn) * i) / TICKS;
    const y = Math.round(yAt(v));
    for (let x = px0; x <= px1; x++) cv.px(x, y, faint);
    const label = String(Math.round(v));
    cv.text(L - 12 - cv.textWidth(label), y - 7, label, mid);
  }
  // 折线 + 数据点
  for (let i = 1; i < points.length; i++) cv.line(xAt(i - 1), yAt(vals[i - 1]), xAt(i), yAt(vals[i]), lineC, 2);
  if (points.length <= 90) {
    for (let i = 0; i < points.length; i++) cv.fill(xAt(i) - 2, yAt(vals[i]) - 2, xAt(i) + 3, yAt(vals[i]) + 3, dotC);
  }
  // 标题（左上）
  cv.text(70, 14, String(o.title || ""), ink);
  // 首尾日期
  if (points.length) {
    const f = localParts(points[0].at, o.utcOffset).date.slice(5);
    const l = localParts(points[points.length - 1].at, o.utcOffset).date.slice(5);
    cv.text(px0, py1 + 14, f, mid);
    cv.text(px1 - cv.textWidth(l), py1 + 14, l, mid);
  }
  // 当前值（最后一个点旁边）
  if (points.length) {
    const cur = String(vals[vals.length - 1]);
    const cx = Math.min(px1 - cv.textWidth(cur), xAt(points.length - 1) + 8);
    cv.text(cx, yAt(vals[vals.length - 1]) + 8, cur, ink);
  }
  return encodePng(CHART_W, CHART_H, cv.buf);
}

/** 本地渲染 + 发图。和 sendChartImage 同签名语义，失败抛错由调用方降级。 */
async function sendLocalChart(ctx, points, title, color, fileName, utcOffset) {
  const p = pathsOf();
  fs.mkdirSync(p.charts, { recursive: true });
  const buf = renderRatingPng(points, { title: title, color: color, utcOffset: utcOffset });
  const file = path.join(p.charts, fileName);
  fs.writeFileSync(file, buf);
  pruneCharts(p.charts, CHART_KEEP);
  if (!ctx || !ctx.sender || typeof ctx.sender.sendImage !== "function" || !ctx.chatKey) {
    throw new Error('当前会话拿不到发图能力');
  }
  await ctx.sender.sendImage(ctx.chatKey, { file: file, dataUrl: 'base64://' + buf.toString('base64') }, { note: 'rating 曲线' });
  try {
    if (ctx.session && Array.isArray(ctx.session.sent)) {
      ctx.session.sent.push({ type: 'image', text: '[图片:rating 曲线]', at: new Date().toLocaleTimeString('zh-CN', { hour12: false }) });
    }
  } catch (e) { /* 忽略 */ }
  return file;
}

// ─────────────────────────── 工具 ───────────────────────────

export async function setup(api) {
  apiRef = api;

  // 密钥：读一次性投放文件 → 读密文 → 吸收设置里新填的明文（并立刻抹成哨兵值）
  try { await refreshSecrets(true); } catch (e) { warn('初始化密钥出错：' + (e && e.message ? e.message : e)); }

  // 看门狗：用户在设置窗口填了新的密钥，5 秒内自动加密保存并把明文抹掉
  startWatchdog(api);

  // ── 1. 查 Codeforces 选手 ──────────────────────────────────
  api.registerTool({
    id: 'cf',
    name: '查询 Codeforces 选手',
    description: '查询 Codeforces（codeforces.com）选手的资料：当前 rating、段位（含中文段位名）、最高 rating、最大段位、贡献值、加入时间、最近一次在线等，并给出主页链接。当用户给出一个 Codeforces 用户名（handle），或问「某人的 CF 分是多少 / 什么段位 / tourist 多少分」时使用。只读查询，匿名即可，不需要密钥。',
    category: 'query',
    icon: '🔵',
    parameters: {
      type: 'object',
      properties: {
        handle: { type: 'string', description: 'Codeforces 用户名（handle），例如 tourist、Petr、Benq。大小写不敏感。' }
      },
      required: ['handle']
    },
    async execute(_ctx, args) {
      try {
        const handle = String((args && args.handle) || '').trim();
        if (!handle) return err('请给出 Codeforces 用户名（handle），例如 tourist');
        const got = await fetchCfUser(handle);
        if (!got.found) {
          return ok({
            found: false,
            handle,
            note: 'Codeforces 上没有这个用户（handle 拼错、或该账号不存在/已改名）。以工具返回为准，不要凭印象编 rating。'
          });
        }
        return ok({ found: true, user: fmtCfUser(got.user) });
      } catch (error) {
        return err((error && error.message) ? error.message : error);
      }
    }
  });

  // ── 2. 查 AtCoder 选手 ─────────────────────────────────────
  api.registerTool({
    id: 'at',
    name: '查询 AtCoder 选手',
    description: '查询 AtCoder（atcoder.jp）选手的资料：当前 rating、色带（灰茶绿青蓝黄橙红）、最高 rating、参加过的 rated 比赛场数、最后参赛时间、国家等，并给出主页链接。当用户给出 AtCoder 用户名，或问「某人的 atcoder 分 / ABC 打到什么颜色了」时使用。注意 AtCoder 与 Codeforces 是两个站，用户名不通用。',
    category: 'query',
    icon: '🟡',
    parameters: {
      type: 'object',
      properties: {
        handle: { type: 'string', description: 'AtCoder 用户名（例如 chokudai、tourist、rng_58）。注意区分大小写。' }
      },
      required: ['handle']
    },
    async execute(_ctx, args) {
      try {
        const handle = String((args && args.handle) || '').trim();
        if (!handle) return err('请给出 AtCoder 用户名，例如 chokudai');
        const got = await fetchAtUser(handle);
        if (!got.found) {
          return ok({
            found: false,
            handle,
            note: 'AtCoder 上没有这个用户（拼错、或该账号不存在）。以工具返回为准，别凭印象编 rating。'
          });
        }
        return ok({ found: true, user: fmtAtUser(got.info), ratedHistoryCount: Array.isArray(got.history) ? got.history.length : 0 });
      } catch (error) {
        return err((error && error.message) ? error.message : error);
      }
    }
  });

  // ── 3. 画 rating 变化曲线（直接发图）────────────────────────
  api.registerTool({
    id: 'rating',
    name: '画 rating 变化曲线',
    description: '把某个选手的历史 rating 变化画成折线图并直接发到当前聊天（Codeforces / AtCoder 均可）。当用户说「画一下他的 rating 曲线」「看看分数变化」「rating 走势」时使用。默认发图；发图失败会自动降级成文字 + 迷你走势图。',
    category: 'messaging',
    icon: '📈',
    parameters: {
      type: 'object',
      properties: {
        platform: { type: 'string', enum: ['codeforces', 'atcoder'], description: '选手所在的平台：codeforces 或 atcoder。默认 codeforces。' },
        handle: { type: 'string', description: '选手用户名（handle）' },
        replyToMessageId: { type: ['integer', 'string'], description: '要引用/回复的消息 id（可选）' }
      },
      required: ['handle']
    },
    async execute(ctx, args) {
      try {
        const handle = String((args && args.handle) || '').trim();
        if (!handle) return err('请给出要画曲线的用户名（handle）');
        const raw = String((args && args.platform) || 'codeforces').trim().toLowerCase();
        const platform = (raw === 'atcoder' || raw === 'at') ? 'atcoder' : 'codeforces';
        const c = conf();

        let points = [];
        let title = '';
        let color = '#3b82f6';
        if (platform === 'codeforces') {
          const got = await fetchCfRating(handle);
          if (!got.found) return ok({ found: false, handle, note: 'Codeforces 上没有这个用户，画不了曲线。' });
          points = collectCfSeries(got.rows);
          title = handle + ' · Codeforces';
          color = '#3b82f6';
        } else {
          const got = await fetchAtUser(handle);
          if (!got.found) return ok({ found: false, handle, note: 'AtCoder 上没有这个用户，画不了曲线。' });
          points = collectAtSeries(got.history);
          title = handle + ' · AtCoder';
          color = '#f59e0b';
        }

        if (!points.length) {
          return ok({ found: true, handle, platform, note: '这个选手还没有打过 rated 比赛（没有 rating 历史），画不出曲线。' });
        }

        const first = points[0].value;
        const last = points[points.length - 1].value;
        const summary = {
          platform,
          handle,
          contests: points.length,
          from: first,
          to: last,
          change: last - first,
          peak: Math.max.apply(null, points.map((p) => p.value)),
          recent: points.slice(-8).map((p) => ({ date: localParts(p.at, c.utcOffset).date, rating: p.value, rank: p.rank, name: clipText(p.name, 40) })),
          trend: sparkline(points.map((p) => p.value))
        };

        if (c.ratingChart === 'text') {
          return ok(Object.assign({ sent: false, mode: 'text' }, summary));
        }

        const fileName = SKILL_ID + '-' + platform + '-' + handle.replace(/[^a-zA-Z0-9_-]/g, '_') + '.png';
        const svc = String(c.chartService || '').trim();
        const remoteOn = /^https?:\/\//i.test(svc);
        let file = '';
        let imgErr = '';
        let usedRemote = false;
        // ① 配了在线出图服务就先试它（兼容 quickchart 那种 ?c=<JSON> 的格式）
        if (remoteOn) {
          try {
            file = await sendChartImage(ctx, chartUrl(points, title, color), fileName);
            usedRemote = !!file;
          } catch (e) { imgErr = (e && e.message) ? e.message : String(e); }
        }
        // ② 没配 / 远程失败 → 本地画（离线可用，没有外部依赖）
        if (!file) {
          try {
            file = await sendLocalChart(ctx, points, title, color, fileName, c.utcOffset);
          } catch (e) {
            const m = (e && e.message) ? e.message : String(e);
            imgErr = imgErr ? (imgErr + ' / ' + m) : m;
          }
        }
        if (file) {
          return ok(Object.assign({ sent: true, mode: 'image', renderer: usedRemote ? 'remote' : 'local', remoteFailed: usedRemote ? undefined : (imgErr || undefined), savedTo: file, note: '曲线图已经发到聊天里了，不要再把同一组数值复述一遍。' }, summary));
        }
        return ok(Object.assign({
          sent: false,
          mode: 'text',
          imageFailed: imgErr,
          imageUrl: remoteOn ? chartUrl(points, title, color) : '',
          note: '图没出成，已降级成上面的文字 + 迷你走势图。'
        }, summary));
      } catch (error) {
        return err((error && error.message) ? error.message : error);
      }
    }
  });

  // ── 4. 查近期算法竞赛 ──────────────────────────────────────
  api.registerTool({
    id: 'race',
    name: '查近期算法竞赛',
    description: '查询近期即将开始的算法竞赛（Codeforces / AtCoder / LeetCode / 洛谷 / 牛客），返回比赛名、平台、北京时间、星期、还有多久、时长和链接。当用户问「最近有什么比赛」「这周有 CF 吗」「下周有 atcoder 吗」时使用。需要 Clist 的 api key（在本技能设置里填）。',
    category: 'query',
    icon: '🗓️',
    parameters: {
      type: 'object',
      properties: {
        platforms: { type: 'array', items: { type: 'string' }, description: '只看哪些平台，可选值：cf / at / lc / lg / nk（或 codeforces / atcoder / leetcode / luogu / nowcoder / 力扣 / 洛谷 / 牛客）。不填则用设置里的默认平台。' },
        limit: { type: 'integer', description: '最多返回几场，1~50，默认取设置里的值。' },
        offset: { type: 'integer', description: '跳过前几场，用于「还有别的吗」翻页。默认 0。' }
      }
    },
    async execute(_ctx, args) {
      try {
        const c = conf();
        const picked = resolveRacePlatforms((args && args.platforms) || []);
        const platforms = picked.length ? picked : defaultRacePlatforms();
        const limit = num((args && args.limit), c.raceLimit, 1, 50);
        const offset = num((args && args.offset), 0, 0, 9999);
        const list = await fetchRaces({ platforms, limit, offset });
        return ok({
          count: list.length,
          platforms: platforms.map((p) => p.label),
          timezone: '北京时间（UTC+' + c.utcOffset + '）',
          contests: list,
          note: list.length ? '' : '这段时间没有符合条件的比赛。可以换几个平台再看看。'
        });
      } catch (error) {
        return err((error && error.message) ? error.message : error);
      }
    }
  });

  // ── 5. 自检 ────────────────────────────────────────────────
  api.registerTool({
    id: 'status',
    name: '算法竞赛助手自检',
    description: '检查算法竞赛助手各项能力是否就绪：Codeforces / AtCoder 是否可达、Clist 比赛列表的密钥有没有配好。当用户问「竞赛助手能用吗」「比赛查询怎么没反应」「密钥配好了吗」时使用。',
    category: 'system',
    icon: '🩺',
    parameters: { type: 'object', properties: {} },
    async execute() {
      const out = { secretStorage: null, codeforces: null, atcoder: null, clist: null };
      const b = await ensureBackend();
      out.secretStorage = b ? '可用（系统加密，密钥不会明文落盘）' : '不可用（拿不到系统加密后端，密钥只存在内存里）';
      out.secrets = SECRET_KEYS.map((k) => k + '=' + (fp(secret(k)) || '未配置')).join(' / ');
      try {
        const r = await fetchCfUser('tourist');
        out.codeforces = r.found ? '正常' : '能连上但没查到数据';
      } catch (e) { out.codeforces = '异常：' + ((e && e.message) ? e.message : e); }
      try {
        const r = await fetchAtUser('tourist');
        out.atcoder = r.found ? '正常' : '能连上但没查到数据';
      } catch (e) { out.atcoder = '异常：' + ((e && e.message) ? e.message : e); }
      if (!secret('clistToken')) {
        out.clist = '未配置密钥（比赛列表需要 Clist 的 apikey）';
      } else {
        try {
          const list = await fetchRaces({ limit: 1 });
          out.clist = '正常（返回 ' + list.length + ' 条）';
        } catch (e) { out.clist = '异常：' + ((e && e.message) ? e.message : e); }
      }
      return ok(out);
    }
  });
}

export function dispose() {
  if (watchdog) {
    clearInterval(watchdog);
    watchdog = null;
  }
}

function startWatchdog(api) {
  if (watchdog) clearInterval(watchdog);
  watchdog = setInterval(() => {
    try {
      const raw = (typeof api.config === 'function') ? (api.config() || {}) : {};
      for (const k of SECRET_KEYS) {
        const v = raw[k];
        if (typeof v === 'string' && v.trim() && v.trim() !== SCRUB) {
          refreshSecrets(false).catch(function () { /* 忽略 */ });
          return;
        }
      }
    } catch (e) { /* 忽略 */ }
  }, 5000);
  if (watchdog && typeof watchdog.unref === 'function') watchdog.unref();
}
