// memory-recall — 把很久以前聊过的事翻出来。
//
// 数据源：<app>/data/memory-v2/chunks/hour_*.json
//   conversation-memory 插件每 10 分钟巩固一次，产出「每小时一个块」：
//   { id, kind:'hour', chatKey:'group:1071556222', dayKey:'2026-10-17', hourKey:'16',
//     title, summary, keywords:[...], snippets:[{when,ts,who,text}], msgCount }
//
// 平常不读盘、不进提示词；只有模型调用 memory_recall 时才扫一遍（65 块 ≈ 1.8 MB，几毫秒）。
//
// 为什么自己读块文件、而不是走能力接口：
//   conversation-memory 的 plugin.json 声明了 memory.search / memory.archive 能力，
//   但 index.js 没有导出 providers，api.capability('memory.search') 拿不到实现；
//   若在 manifest 里写 requires:["memory.search"]，本技能会永远显示「依赖未就绪」。
//   所以这里做软降级：有能力就先问能力接口，拿不到就直接读块文件（本技能自足）。

import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const APP_ROOT = path.resolve(HERE, '..', '..');

const DEFAULTS = {
  defaultDays: 30,
  defaultLimit: 5,
  showSnippets: 3,
  maxChunkFiles: 4000,
  maxFileKb: 512
};

let api = null;

function settings() {
  let raw = {};
  try {
    raw = (typeof api?.config === 'function' ? api.config() : null) || {};
  } catch { raw = {}; }
  const n = (v, d, lo, hi) => {
    const x = Number(v);
    return Number.isFinite(x) ? Math.min(hi, Math.max(lo, x)) : d;
  };
  return {
    defaultDays: n(raw.defaultDays, DEFAULTS.defaultDays, 0, 3650),
    defaultLimit: n(raw.defaultLimit, DEFAULTS.defaultLimit, 1, 20),
    showSnippets: n(raw.showSnippets, DEFAULTS.showSnippets, 0, 10),
    maxChunkFiles: n(raw.maxChunkFiles, DEFAULTS.maxChunkFiles, 50, 20000),
    maxFileKb: n(raw.maxFileKb, DEFAULTS.maxFileKb, 64, 4096)
  };
}

/** 候选数据目录：env 覆盖优先，其次 <app>/data、<app>/data-xxx（profile 后缀）。 */
function dataDirs() {
  const out = [];
  const env = String(process.env.QQ_AGENT_DATA_DIR || '').trim();
  if (env) out.push(env);
  try {
    for (const name of fs.readdirSync(APP_ROOT)) {
      if (name === 'data' || /^data[-_].+/.test(name)) out.push(path.join(APP_ROOT, name));
    }
  } catch { /* 拿不到 app 根目录时只剩 env 一条路 */ }
  return out;
}

function chunksDir() {
  for (const d of dataDirs()) {
    const p = path.join(d, 'memory-v2', 'chunks');
    try {
      if (fs.statSync(p).isDirectory()) return p;
    } catch { /* 下一个 */ }
  }
  return null;
}

/** 拆词：英文/数字按词，中文按「整词 + 相邻二字」，跟块里的 keywords 口径接近。 */
function tokens(text) {
  const out = new Set();
  const s = String(text || '').toLowerCase();
  for (const w of s.split(/[^a-z0-9\u4e00-\u9fff]+/)) {
    if (!w) continue;
    if (/^[a-z0-9]+$/.test(w)) {
      if (w.length >= 2) out.add(w);
      continue;
    }
    if (w.length >= 2) {
      out.add(w);
      for (let i = 0; i + 1 < w.length; i++) out.add(w.slice(i, i + 2));
    }
  }
  return [...out].slice(0, 24);
}

function dayAgo(days) {
  const d = new Date(Date.now() - days * 86400000);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

function chatLabel(key) {
  const k = String(key || '');
  const g = /^group:(.+)$/.exec(k);
  if (g) return `群 ${g[1]}`;
  const p = /^private:(.+)$/.exec(k);
  if (p) return `与 ${p[1]} 的私聊`;
  return k || '未知会话';
}

function score(ch, toks, q) {
  const lower = (s) => String(s ?? '').toLowerCase();
  const kw = new Set((Array.isArray(ch.keywords) ? ch.keywords : []).map(lower));
  const title = lower(ch.title);
  const summary = lower(ch.summary);
  const snips = (Array.isArray(ch.snippets) ? ch.snippets : []).map((s) => lower(s?.text));
  let total = 0;
  const hits = [];
  for (const t of toks) {
    let s = 0;
    if (kw.has(t)) s += 3;
    if (title.includes(t)) s += 2;
    if (summary.includes(t)) s += 1;
    const n = snips.filter((x) => x.includes(t)).length;
    if (n) {
      s += 2 + Math.min(2, n - 1);
      hits.push(t);
    }
    total += s;
  }
  const ql = lower(q);
  if (ql.length >= 2 && summary.includes(ql)) total += 4;
  if (ql.length >= 2 && snips.some((x) => x.includes(ql))) total += 4;
  return { score: total, hits };
}

function render(ch, hits, showSnippets) {
  const when = ch.dayKey ? `${ch.dayKey}${ch.hourKey ? ` ${String(ch.hourKey).slice(-2)} 点` : ''}` : '';
  const lines = [`【${when || '时间不明'} · ${chatLabel(ch.chatKey)}${ch.msgCount ? ` · ${ch.msgCount} 条` : ''}】`];
  if (ch.title) lines.push(`话题：${ch.title}`);
  if (Array.isArray(ch.keywords) && ch.keywords.length) lines.push(`关键词：${ch.keywords.slice(0, 10).join('、')}`);
  const snips = Array.isArray(ch.snippets) ? ch.snippets.filter((s) => s && s.text) : [];
  const want = Math.max(0, showSnippets);
  const picked = [];
  for (const s of snips) {
    if (picked.length >= want) break;
    const t = String(s.text).toLowerCase();
    if (!hits.length || hits.some((h) => t.includes(h))) picked.push(s);
  }
  for (const s of snips) {
    if (picked.length >= want) break;
    if (!picked.includes(s)) picked.push(s);
  }
  for (const s of picked) {
    const t = String(s.text).replace(/\s+/g, ' ').slice(0, 140);
    lines.push(`· ${s.who ? `${s.who}: ` : ''}${t}`);
  }
  if (!picked.length && ch.summary) lines.push(String(ch.summary).replace(/\s+/g, ' ').slice(0, 300));
  return lines.join('\n');
}

const TOOL = {
  id: 'memory_recall',
  name: '回忆往事',
  category: 'memory',
  icon: '🧠',
  description: '检索她的「长时记忆」：很久以前在群里/私聊里聊过的事（每小时一块的摘要，不是逐条原文）。当有人问「你还记得…」「前几天/上次/以前说过…」「那天那个…」，或者需要很久以前的上下文（人名、梗、约定、喜好），先调这个再回答，比凭印象编靠谱。返回命中的记忆块：时间、会话、关键词、几条原文片段。没命中就如实说想不起来，不要编。',
  parameters: {
    type: 'object',
    properties: {
      query: {
        type: 'string',
        description: '要回忆的关键词/人名/话题/短句，例如「钓鱼」「那只猫」「上次说的显卡」。越具体越准。'
      },
      days: {
        type: 'integer',
        description: '往回看多少天，默认 30；0 = 不限（全量扫）。'
      },
      limit: {
        type: 'integer',
        description: '最多返回几个记忆块，默认 5，最大 20。'
      }
    },
    required: ['query']
  },
  async execute(ctx, args) {
    const q = String(args?.query ?? '').trim();
    if (!q) return { content: '错误：query 不能为空', isError: true };

    const st = settings();
    const dir = chunksDir();
    if (!dir) {
      return {
        content: '这台机器上没有找到长时记忆（data/memory-v2/chunks 不存在）。可能是 conversation-memory 插件没在跑，或者还没攒够一个小时的记忆块。',
        isError: false
      };
    }

    const daysArg = args?.days;
    const days = daysArg === undefined || daysArg === null || daysArg === ''
      ? st.defaultDays
      : Math.max(0, Math.min(3650, Number(daysArg) || 0));
    const limit = Math.max(1, Math.min(20, Number(args?.limit) || st.defaultLimit));
    const toks = tokens(q);
    const minDay = days > 0 ? dayAgo(days) : '';

    let names = [];
    try {
      names = fs.readdirSync(dir).filter((f) => f.endsWith('.json'));
    } catch (e) {
      return { content: `读取记忆目录失败：${e?.message || e}`, isError: true };
    }

    const files = [];
    for (const f of names) {
      try {
        const s = fs.statSync(path.join(dir, f));
        files.push({ f, m: s.mtimeMs, size: s.size });
      } catch { /* 跳过读不到的文件 */ }
    }
    files.sort((a, b) => b.m - a.m);
    const maxBytes = st.maxFileKb * 1024;
    const scored = [];
    for (const it of files.slice(0, st.maxChunkFiles)) {
      if (it.size > maxBytes) continue;
      let ch;
      try {
        ch = JSON.parse(fs.readFileSync(path.join(dir, it.f), 'utf8'));
      } catch { continue; }
      if (!ch || typeof ch !== 'object') continue;
      if (minDay && ch.dayKey && String(ch.dayKey) < minDay) continue;
      const s = score(ch, toks, q);
      if (s.score > 0) scored.push({ ch, score: s.score, hits: s.hits });
    }

    if (!scored.length) {
      return {
        content: `没翻到相关记忆（关键词：${q}${days ? `，回看 ${days} 天` : ''}）。可能是那段时间没有记忆块，或者换个说法/人名/更短的关键词再试。`,
        isError: false
      };
    }

    scored.sort((a, b) => (b.score - a.score) || String(b.ch.dayKey || '').localeCompare(String(a.ch.dayKey || '')));
    const top = scored.slice(0, limit);
    return {
      content: `回忆检索（关键词：${q}，命中 ${scored.length} 块，显示前 ${top.length} 块）：\n\n`
        + top.map((h) => render(h.ch, h.hits, st.showSnippets)).join('\n\n')
        + '\n\n（这些是每小时的摘要，不是完整聊天记录；要逐条原文可以用 get_recent_messages 之类的工具往前翻。）',
      isError: false
    };
  }
};

export function setup(skillApi) {
  api = skillApi;
  api.registerTool(TOOL);
}

export default { setup };
