// 私聊好感度：1-10 分，一对一，跨天延续。
// 状态存 DATA_DIR/affinity-private/state.json，原子写。

import fs from 'node:fs';
import path from 'node:path';
import { DATA_DIR } from '../../src/config.js';

const SKILL_ID = 'affinity-private';
const DIR = path.join(DATA_DIR, SKILL_ID);
const FILE = path.join(DIR, 'state.json');

const TIERS = [
  { min: 9, name: '最喜欢', note: '已经很黏了，会主动、会偏心' },
  { min: 7, name: '老友', note: '熟得很，说话不用客气' },
  { min: 5, name: '熟人', note: '聊得开，会主动找话' },
  { min: 3, name: '眼熟', note: '还行，不排斥' },
  { min: 1, name: '陌生', note: '客气，话不多' }
];

let cfg = () => ({});

function settings() {
  let c = {};
  try { c = (typeof cfg === 'function' ? cfg() : null) || {}; } catch { c = {}; }
  const num = (v, d) => (Number.isFinite(Number(v)) ? Number(v) : d);
  return {
    enabled: c.enabled !== false,
    startScore: Math.min(10, Math.max(1, num(c.startScore, 2))),
    maxScore: Math.min(10, Math.max(1, num(c.maxScore, 10))),
    dailyDecay: Math.max(0, num(c.dailyDecay, 0.2))
  };
}

function tierOf(score) {
  return TIERS.find((t) => score >= t.min) || TIERS[TIERS.length - 1];
}

function ensureDir() {
  try { fs.mkdirSync(DIR, { recursive: true }); } catch { /* ignore */ }
}

function readState() {
  try {
    const j = JSON.parse(fs.readFileSync(FILE, 'utf8'));
    if (j && typeof j === 'object') {
      return {
        score: Number(j.score) || 0,
        updatedAt: Number(j.updatedAt) || Date.now(),
        lastReason: String(j.lastReason || ''),
        history: Array.isArray(j.history) ? j.history.slice(-20) : []
      };
    }
  } catch { /* ignore */ }
  return { score: 0, updatedAt: Date.now(), lastReason: '', history: [] };
}

function writeState(s) {
  ensureDir();
  const tmp = FILE + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(s, null, 2), 'utf8');
  fs.renameSync(tmp, FILE);
}

/** 按天数自然回落。 */
function decayed(state, s) {
  const days = Math.max(0, (Date.now() - state.updatedAt) / 86400000);
  if (days <= 0 || s.dailyDecay <= 0) return { ...state, score: Math.max(1, state.score) };
  const drop = days * s.dailyDecay;
  return { ...state, score: Math.max(1, Math.round((state.score - drop) * 10) / 10) };
}

function describe(state, s) {
  const cur = decayed(state, s);
  const t = tierOf(cur.score);
  const lines = [
    `当前好感度：${cur.score.toFixed(1)} / ${s.maxScore}`,
    `关系阶段：${t.name}（${t.note}）`
  ];
  if (state.lastReason) lines.push(`上次变化原因：${state.lastReason}`);
  const days = Math.max(0, (Date.now() - state.updatedAt) / 86400000);
  if (days >= 1) lines.push(`距上次更新 ${Math.round(days)} 天，有自然回落。`);
  return lines.join('\n');
}

export function setup(api) {
  cfg = api.config;
  api.log('私聊好感度已加载');

  api.registerTool({
    id: 'get_affinity',
    name: '查对他的好感度',
    description: '读你和他之间的好感度（1-10）和当前关系阶段。不确定的时候先查。',
    category: 'query',
    icon: '💗',
    parameters: { type: 'object', properties: {} },
    async execute() {
      const s = settings();
      if (!s.enabled) return { content: '好感度功能已关闭。' };
      const st = readState();
      const cur = decayed(st, s);
      if (cur.score !== st.score) writeState({ ...cur, updatedAt: Date.now() });
      return { content: describe(cur, s) };
    }
  });

  api.registerTool({
    id: 'adjust_affinity',
    name: '调整好感度',
    description: '当他做了让你心动、走心的事，或者敷衍、伤到你了，用这个加减好感度。一次最多 ±1，原因写一句话。没变化别调。',
    category: 'utility',
    icon: '💞',
    parameters: {
      type: 'object',
      properties: {
        delta: { type: 'number', description: '变化量，+1 或 -1，最多 ±1' },
        reason: { type: 'string', description: '一句话说明为什么，比如"他记得我说过的事"' }
      },
      required: ['delta']
    },
    async execute(_ctx, args) {
      const s = settings();
      if (!s.enabled) return { content: '好感度功能已关闭。' };
      let delta = Number(args?.delta);
      if (!Number.isFinite(delta)) delta = 0;
      delta = Math.max(-1, Math.min(1, Math.round(delta * 10) / 10));
      const reason = String(args?.reason || '').slice(0, 120);
      const st = decayed(readState(), s);
      const before = st.score;
      const after = Math.min(s.maxScore, Math.max(1, Math.round((st.score + delta) * 10) / 10));
      const next = {
        score: after,
        updatedAt: Date.now(),
        lastReason: reason || st.lastReason,
        history: [...(st.history || []), { at: Date.now(), delta, after, reason }].slice(-20)
      };
      writeState(next);
      const tBefore = tierOf(before);
      const tAfter = tierOf(after);
      let msg = `好感度 ${before.toFixed(1)} → ${after.toFixed(1)}（${delta > 0 ? '+' : ''}${delta}）`;
      if (tBefore.name !== tAfter.name) msg += `\n关系阶段变了：${tBefore.name} → ${tAfter.name}`;
      return { content: msg };
    }
  });
}
