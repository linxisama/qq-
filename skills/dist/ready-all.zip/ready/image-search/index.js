// 以图搜图（LLM 型技能，skills/image-search）
//
// ── 为什么做成「技能」而不是「插件」─────────────────────────────────────────
// 按项目文档 §0 的三问判断法：
//   ① 触发时机能用 if 写死吗？ —— 「@机器人 + 一张图，让它去搜」里的关键词是
//      **人话**：有人发图直接问「这是哪来的」、有人 @ 机器人说「帮我搜这张图」、
//      也有人只是发图聊天（这时**不该**搜）。要不要搜只有模型判断得了。
//   ② 漏一次的代价？ —— 只是这次没搜，对方再说一句就行，不丢数据、不改状态。
//   ③ 参数从哪来？ —— 「搜哪张图」「要几张」都要从人话里理解。
//   三问全部指向 LLM 型 → skills/。做成插件的话模型根本看不到这个工具，
//   而"满足条件必跑"的插件形态只会变成"每来一张图都自动搜"，那是骚扰不是功能。
//
// ── 一个文件装完 ────────────────────────────────────────────────────────────
// 宿主热重载只给**入口文件**加时间戳（plugin-loader.js 的 `?t=`），相对 import
// 的兄弟文件会留在模块缓存里 —— 改了子文件没反应、也不报错。所以逻辑全写在
// index.js 里，不拆文件。
//
// ── 各家识图源的实测结论（2026-10-09 在本机逐条验证过，别再踩一遍）─────────
//   · Yandex  images/search?rpt=imageview&url=<图片地址>  ← **唯一真正能出结果的**
//       服务端渲染页里有：识别标签（"Image appears to contain …"）、相似图
//       （avatars.mds.yandex.net）、来源站点、"其他尺寸"清单。
//       ⚠️ 两个坑：(a) 必须走代理，直连会拿到 "under construction" 占位页或空壳页；
//                  (b) 数据藏在 HTML 属性的 data-bem="…&quot;…&quot;" 里，
//                      要先做实体反转义再解析，否则一条都匹配不到。
//   · 百度识图 graph.baidu.com/upload —— 三条路全是死路（实测）：
//       图片 URL → {"status":1,"msg":"Reject"}；multipart 传字节 → 同样 Reject；
//       base64 → {"status":1002,"msg":"Params illegal"}。
//       details?image= 只会打开通用拍照识别页（"未找到相关结果"）；
//       s?image= 是纯 JS 渲染页，服务端没有数据。
//       → 只保留"点开自己搜"的链接，不再假装它是结果来源。
//   · Google Lens uploadbyurl?url= —— 上传确实成功（302 到
//       google.com/search?vsrid=…&udm=26），但那个结果页是"需要 JS"页，
//       服务端解析不到相似图 → 只把最终链接交给用户点开。
//   · 必应 —— 老上传接口国内版 404；退回的"按图直链搜图页"会把图片当**关键词**搜
//       （实测返回过"世界旅游胜地"图集）。已从自动链路摘除，只留链接。
//
// ── 代理（为什么不用宿主 dispatcher）────────────────────────────────────────
// 本机 Clash 在 127.0.0.1:7890，项目「网络代理」插件也开着。但实测：
//   · undici ProxyAgent 走代理 → 可用；
//   · 直连 / 某些 Agent 用法 → UND_ERR_CONNECT_TIMEOUT（先卡十几秒再失败）；
//   · 所以**不能只依赖全局 dispatcher**（它可能把请求判成直连）。
// 这里改成自己读「网络代理」插件的设置，用 node:net + node:tls 手写
// CONNECT 隧道 —— 走不走代理由本技能说了算，确定、可见、不依赖宿主实现
// （与技能 pinterest-finder 里那套是同一思路）。
//
// ── 多图 ────────────────────────────────────────────────────────────────────
//   对方说了要几张（count），够阈值（默认 3）就先逐张传到**机器人自己的私聊**
//   （合并转发的前提：卡片里每个节点必须在 QQ 上真实存在），再用 sendMedia 发一张
//   【合并转发】卡片；少于 3 张就直接交回直链，让模型用自带 send_image 发。
//
// ⚠️ 图片地址必须是公网可达的：识图引擎是**它自己的服务器**去拉这张图。

import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import net from 'node:net';
import tls from 'node:tls';
import zlib from 'node:zlib';
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
  + ' (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36';

// 与 plugin-loader.js 同一约定：以模块自身位置为锚点推应用根目录（不用 cwd）。
const APP_ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');

const YANDEX_SEARCH = 'https://yandex.com/images/search';
const BAIDU_UPLOAD = 'https://graph.baidu.com/upload';
const LENS_UPLOAD = 'https://lens.google.com/uploadbyurl';
// 免费图床（实测可用：走代理上传成功、公网可回读、内容一致）。
// 用途：QQ 图片直链几分钟就失效，而我们交给用户的那些"点开自己搜"的链接里嵌的正是它 ——
// 先转存一份稳定地址，链接才能长期点得开，识图引擎抓图也更稳。
const IMAGE_HOST = 'https://uguu.se/upload.php';

const DIGEST_MAX = 700;            // 交回模型的"结果页文字"上限
const MAX_BODY = 4 * 1024 * 1024;  // 单页最多收这么多字节（Yandex 正常 0.6MB）

const ENGINE_LABEL = {
  'baidu-browser': '百度识图（浏览器）',
  yandex: 'Yandex 识图',
  baidu: '百度识图（接口）',
  google: 'Google Lens',
  bing: '必应'
};

// 真图魔数：识图引擎拿不到图（图床过期/防盗链）时会返回 HTML 错误页，
// 那种字节传上去只会白跑，先在本地判死。
const MAGIC = [
  { mime: 'image/jpeg', ok: (b) => b[0] === 0xff && b[1] === 0xd8 && b[2] === 0xff },
  { mime: 'image/png', ok: (b) => b[0] === 0x89 && b[1] === 0x50 && b[2] === 0x4e && b[3] === 0x47 },
  { mime: 'image/gif', ok: (b) => /^GIF8[79]a$/.test(b.slice(0, 6).toString('latin1')) },
  { mime: 'image/bmp', ok: (b) => b[0] === 0x42 && b[1] === 0x4d },
  {
    mime: 'image/webp',
    ok: (b) => b.slice(0, 4).toString('latin1') === 'RIFF' && b.slice(8, 12).toString('latin1') === 'WEBP'
  },
  { mime: 'image/avif', ok: (b) => b.slice(4, 12).toString('latin1').includes('ftypavif') }
];

/* ─────────────────────── 诊断日志（写进 data/） ─────────────────────── */
// 失败时"哪一步断了"必须有据可查：哪家、什么状态码、响应多大、有没有数据标记。

const DEBUG = { enabled: true, maxBytes: 256 * 1024, file: '', buf: [] };

function debugFile() {
  if (DEBUG.file) return DEBUG.file;
  try {
    // 目录结构：<安装目录>/data/… 与 <安装目录>/resources/app/skills/image-search/
    // 所以从 APP_ROOT（= …/resources/app）往上两级才是 <安装目录>。
    const dataDir = path.join(APP_ROOT, '..', '..', '..', 'data');
    fs.mkdirSync(dataDir, { recursive: true });
    DEBUG.file = path.join(dataDir, 'image-search-debug.log');
  } catch {
    DEBUG.file = path.join(process.cwd(), 'image-search-debug.log');
  }
  return DEBUG.file;
}

function dbg(line) {
  if (!DEBUG.enabled) return;
  const text = `${new Date().toISOString()} ${line}`;
  DEBUG.buf.push(text);
  console.log(`[skill:image-search] ${text}`);
}

function clipText(s, n = 200) {
  return String(s || '').replace(/\s+/g, ' ').slice(0, n);
}

/** 只记长度和标记，不存整页 HTML，日志才不会爆掉。 */
function briefHtml(html) {
  const t = String(html || '');
  const marks = [];
  if (/serp-item|avatars\.mds\.yandex/.test(t)) marks.push('yandex-data');
  if (/objURL|thumbURL|middleURL/.test(t)) marks.push('baidu-similar');
  if (/AF_initDataCallback|encrypted-tbn0/.test(t)) marks.push('google-data');
  if (/captcha|unusual traffic|not a robot|SmartCaptcha|人机验证/i.test(t)) marks.push('captcha');
  if (/consent\.google|before you continue/i.test(t)) marks.push('google-consent');
  if (/enablejs|如果您在几秒钟内没有被重定向/i.test(t)) marks.push('google-needs-js');
  if (/under construction/i.test(t)) marks.push('yandex-under-construction');
  return `len=${t.length} marks=[${marks.join(',') || 'none'}]`;
}

function flushDebug(reason) {
  if (!DEBUG.enabled || !DEBUG.buf.length) return '';
  const file = debugFile();
  try {
    let prev = '';
    try { prev = fs.readFileSync(file, 'utf8'); } catch { /* 首次没有 */ }
    let text = `${prev}\n───── ${reason} ─────\n${DEBUG.buf.join('\n')}\n`;
    if (text.length > DEBUG.maxBytes) text = text.slice(text.length - DEBUG.maxBytes);
    fs.writeFileSync(file, text, 'utf8');
    return file;
  } catch (e) {
    console.warn('[skill:image-search] 诊断日志写入失败：' + clipText((e && e.message) || e, 120));
    return '';
  } finally {
    DEBUG.buf = [];
  }
}

/* ─────────────────────────── 配置 ─────────────────────────── */

let cfg = () => ({});
let log = () => {};
let warn = () => {};
let apiRef = null;          // setup 时记住，用于每次现读「网络代理」插件的设置

function num(value, dflt, lo, hi) {
  const n = Number(value);
  if (!Number.isFinite(n)) return dflt;
  return Math.min(hi, Math.max(lo, n));
}

// 旧版本写进用户配置里的默认引擎顺序 —— 见到就迁移成新顺序。
// 原因：宿主把"技能默认值"和"用户存的值"浅合并（config.js 的 getSkillConfig），
// 旧版首次加载时会把旧默认写进 config.json，之后**永远覆盖**新默认值。
// 用户自己改过的（不在这个名单里）一律尊重，不动。
const LEGACY_ENGINE_ORDERS = new Set([
  'baidu,google,yandex,bing',
  'baidu,google,yandex',
  'bing,baidu,google,yandex',
  'yandex,baidu,google',
  'yandex,baidu,google,bing'
]);
// 默认顺序：**百度浏览器**排第一 —— 实测它是唯一能给出
// 「识别结论 + 相关商品 + 图片来源 + 相似图片（百度自己 CDN，国内发得出去）」的源，
// 代价是每次多十几秒（要起一次无头浏览器）。它失败就退 Yandex（快）。
const RECOMMENDED_ENGINES = 'baidu-browser,yandex,baidu,google';

function settings() {
  const c = (typeof cfg === 'function' ? cfg() : null) || {};
  let order = String(c.engines || '').trim();
  if (!order || LEGACY_ENGINE_ORDERS.has(order.replace(/\s+/g, ''))) {
    if (order) dbg(`settings: 旧默认引擎顺序「${order}」→ 迁移成「${RECOMMENDED_ENGINES}」`);
    order = RECOMMENDED_ENGINES;
  }
  const list = order.split(/[,;\s]+/)
    .map((x) => x.trim().toLowerCase())
    .filter((x) => ENGINE_LABEL[x]);
  // proxy：设置里留空 → 每次现读「网络代理」插件（改端口/开关立即生效）；填 none → 强制直连
  const configured = String(c.proxy || '').trim();
  let proxy = '';
  if (configured === 'none') proxy = '';
  else if (configured) proxy = configured;
  else {
    try { proxy = resolveProxy(apiRef); } catch { proxy = ''; }
  }
  return {
    engines: [...new Set(list.length ? list : ['yandex', 'baidu', 'google'])],
    maxImages: Math.round(num(c.maxImages, 6, 1, 12)),
    forwardThreshold: Math.round(num(c.forwardThreshold, 3, 2, 12)),
    imagesPerNode: Math.round(num(c.imagesPerNode, 1, 1, 4)),
    timeoutMs: Math.round(num(c.timeoutMs, 30000, 5000, 90000)),
    proxyMs: Math.round(num(c.proxyTimeoutMs, 40000, 5000, 120000)),
    maxBytes: Math.round(num(c.maxSizeMB, 10, 1, 50)) * 1048576,
    scanMessages: Math.round(num(c.scanMessages, 30, 5, 200)),
    allowGroup: c.allowGroup !== false,
    // 图床转存：uguu = 把图转存到免费图床（交给用户的链接才不会被 QQ 直链过期拖死）；off = 不转存
    // 浏览器驱动百度：browserPath 可手动指定 Edge/Chrome；browserWaitMs 是等结果的上限
    browserPath: String(c.browserPath || '').trim(),
    browserWaitMs: Math.round(num(c.browserWaitMs, 30000, 8000, 90000)),
    imageHost: String(c.imageHost === undefined ? 'uguu' : c.imageHost).trim().toLowerCase(),
    proxy   // '' = 直连；'http://host:port' = 走这个代理
  };
}

/* ─────────────────────────── HTTP ─────────────────────────── */

function sniffImage(buf) {
  if (!buf || buf.length < 12) return '';
  for (const s of MAGIC) {
    try { if (s.ok(buf)) return s.mime; } catch { /* 下一个 */ }
  }
  return '';
}

function looksLikeHtml(buf) {
  const head = buf.slice(0, 300).toString('utf8').trim().toLowerCase();
  return head.startsWith('<!doctype html') || head.startsWith('<html') || head.includes('<head>');
}

function dechunk(buf) {
  const parts = [];
  let pos = 0;
  for (;;) {
    const nl = buf.indexOf('\r\n', pos);
    if (nl < 0) break;
    const size = parseInt(buf.slice(pos, nl).toString('latin1').trim(), 16);
    if (!Number.isFinite(size) || size <= 0) break;
    parts.push(buf.slice(nl + 2, nl + 2 + size));
    pos = nl + 2 + size + 2;
  }
  return parts.length ? Buffer.concat(parts) : buf;
}

function proxyParts(proxy) {
  const text = String(proxy || '').trim().replace(/^[a-z]+:\/\//i, '');
  const at = text.lastIndexOf('@');
  const auth = at > 0 ? text.slice(0, at) : '';
  const hostPort = at > 0 ? text.slice(at + 1) : text;
  const i = hostPort.lastIndexOf(':');
  const host = i > 0 ? hostPort.slice(0, i) : hostPort;
  const port = Number(i > 0 ? hostPort.slice(i + 1) : 8080) || 8080;
  let user = '';
  let pass = '';
  if (auth) {
    const j = auth.indexOf(':');
    user = j >= 0 ? auth.slice(0, j) : auth;
    pass = j >= 0 ? auth.slice(j + 1) : '';
    try { user = decodeURIComponent(user); pass = decodeURIComponent(pass); } catch { /* 原样 */ }
  }
  return { host, port, user, pass };
}

/** 手写 CONNECT 隧道：走不走代理由本技能决定，不受宿主 dispatcher 影响。 */
function connectViaProxy(proxy, host, port, timeoutMs) {
  return new Promise((resolve, reject) => {
    const p = proxyParts(proxy);
    const sock = net.connect({ host: p.host, port: p.port });
    let buf = '';
    let done = false;
    const fail = (e) => { if (!done) { done = true; try { sock.destroy(); } catch { /* ignore */ } reject(e); } };
    const timer = setTimeout(() => fail(new Error('连接代理超时')), Math.min(timeoutMs, 15000));
    sock.once('error', fail);
    sock.once('connect', () => {
      const lines = [`CONNECT ${host}:${port} HTTP/1.1`, `Host: ${host}:${port}`];
      if (p.user || p.pass) {
        lines.push('Proxy-Authorization: Basic ' + Buffer.from(`${p.user}:${p.pass}`).toString('base64'));
      }
      sock.write(lines.join('\r\n') + '\r\n\r\n');
    });
    const onData = (chunk) => {
      buf += chunk.toString('latin1');
      if (!buf.includes('\r\n\r\n')) return;
      done = true;
      clearTimeout(timer);
      sock.removeListener('data', onData);
      const m = /^HTTP\/1\.[01] (\d{3})/.exec(buf);
      const status = m ? Number(m[1]) : 0;
      if (status !== 200) {
        try { sock.destroy(); } catch { /* ignore */ }
        reject(new Error(`代理拒绝 CONNECT（HTTP ${status}）`));
        return;
      }
      resolve(sock);
    };
    sock.on('data', onData);
  });
}

/** 在分块缓冲里找响应头结束位置（零拷贝：一般落在第一块里）。 */
function findHeaderEnd(chunks) {
  let base = 0;
  for (const c of chunks) {
    const i = c.indexOf('\r\n\r\n');
    if (i >= 0) return base + i;
    // 跨块边界的情况（极少）：把最后 3 字节留到下一轮一起看
    base += c.length;
    if (base > 64 * 1024) return -1;
  }
  return -1;
}

function formUrlEncoded(pairs) {
  const b = new URLSearchParams();
  for (const [k, v] of Object.entries(pairs)) b.append(k, String(v));
  return b.toString();
}

/**
 * 一次 HTTPS 请求（可走代理隧道）。返回 { status, headers, body, url }。
 * 自动处理：chunked、gzip/deflate、最多 maxRedirects 跳重定向。
 */
function httpRequest(url, {
  method = 'GET',
  proxy = '',
  timeoutMs = 30000,
  referer = '',
  headers = {},
  body = null,
  maxRedirects = 5
} = {}) {
  const send = (target, hop, refererNow) => {
    const u = new URL(target);
    if (u.protocol !== 'https:') return Promise.reject(new Error('只支持 https：' + u.protocol));
    const port = Number(u.port || 443);
    // body 支持字符串（表单）和 Buffer（multipart 上传图床用）
    const bodyBuf = body == null ? null
      : (Buffer.isBuffer(body) ? body : Buffer.from(String(body), 'utf8'));
    const open = proxy && proxy !== 'none'
      ? connectViaProxy(proxy, u.hostname, port, timeoutMs)
      : Promise.resolve(null);
    return open.then((tunnel) => new Promise((resolve, reject) => {
      const sock = tunnel
        ? tls.connect({ socket: tunnel, servername: u.hostname, rejectUnauthorized: false }, onReady)
        : tls.connect({ host: u.hostname, port, servername: u.hostname, rejectUnauthorized: false }, onReady);
      const chunks = [];
      let total = 0;
      let settled = false;
      const joined = () => Buffer.concat(chunks, total);
      const head = [
        `${method} ${u.pathname}${u.search} HTTP/1.1`,
        // Host 的写法跟 undici 一致（带非默认端口），有些站点的 CDN 对不带端口的 Host 处理不同
        `Host: ${u.hostname}${port === 443 ? '' : `:${port}`}`,
        'Connection: keep-alive',
        'accept-encoding: gzip, deflate',
        `user-agent: ${UA}`,
        'accept-language: zh-CN,zh;q=0.9,en;q=0.8',
        'accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8'
      ];
      if (refererNow) head.push(`referer: ${refererNow}`);
      for (const [k, v] of Object.entries(headers)) head.push(`${k}: ${v}`);
      if (bodyBuf && !headers['content-type'] && !headers['Content-Type'] && typeof body === 'string') {
        head.push('content-type: application/x-www-form-urlencoded');
      }
      if (bodyBuf) head.push(`content-length: ${bodyBuf.length}`);

      function onReady() {
        const full = head.join('\r\n') + '\r\n\r\n';
        sock.write(bodyBuf ? Buffer.concat([Buffer.from(full, 'latin1'), bodyBuf]) : full);
      }
      const timer = setTimeout(() => {
        if (settled) return;
        settled = true;
        try { sock.destroy(); } catch { /* ignore */ }
        reject(new Error(`请求超时（${timeoutMs}ms）`));
      }, timeoutMs);

      const settle = () => {
        if (settled || !chunks.length) return;
        const sep = findHeaderEnd(chunks);
        if (sep < 0) return;                       // 还没拿到响应头
        const rawHead = chunks[0].length >= sep
          ? chunks[0].slice(0, sep).toString('latin1')
          : Buffer.concat(chunks, total).slice(0, sep).toString('latin1');
        const rest = total - (sep + 4);
        const h = {};
        for (const line of rawHead.split('\r\n').slice(1)) {
          const i = line.indexOf(':');
          if (i > 0) h[line.slice(0, i).trim().toLowerCase()] = line.slice(i + 1).trim();
        }
        const cl = Number(h['content-length']);
        if (Number.isFinite(cl) && cl >= 0) {
          if (rest >= cl) finish();
          return;
        }
        if (String(h['transfer-encoding'] || '').toLowerCase().includes('chunked')) {
          // chunked 的结束标志：最后一个 0 长度块（"0\r\n\r\n"）。
          // ⚠️ 不判这个的话，keep-alive 连接不会自己关，请求会一直挂到超时
          //（实测 Yandex 的 600KB 结果页就是这样被拖死的）。
          const tailLen = Math.min(total - sep, 16);
          if (tailLen >= 5) {
            const tail = Buffer.concat(chunks, total).slice(total - tailLen).toString('latin1');
            if (/(^|\r\n)0\r\n\r\n$/.test(tail)) finish();
          }
          return;
        }
        finish();                                   // 没长度也没 chunked：只能等连接结束
      };

      const finish = () => {
        if (settled) return;
        settled = true;
        clearTimeout(timer);
        try { sock.destroy(); } catch { /* ignore */ }
        const buf = joined();
        const sep = buf.indexOf('\r\n\r\n');
        if (sep < 0) {
          reject(new Error(buf.length ? '响应不完整（没拿到响应头）' : '连接被断开，没收到数据'));
          return;
        }
        const rawHead = buf.slice(0, sep).toString('latin1');
        let raw = buf.slice(sep + 4);
        const h = {};
        for (const line of rawHead.split('\r\n').slice(1)) {
          const i = line.indexOf(':');
          if (i > 0) h[line.slice(0, i).trim().toLowerCase()] = line.slice(i + 1).trim();
        }
        if (String(h['transfer-encoding'] || '').toLowerCase().includes('chunked')) raw = dechunk(raw);
        const enc = String(h['content-encoding'] || '').toLowerCase();
        try {
          if (enc.includes('gzip')) raw = zlib.gunzipSync(raw);
          else if (enc.includes('deflate')) raw = zlib.inflateSync(raw);
        } catch { /* 解不开就用原始字节 */ }
        const m = /^HTTP\/1\.[01] (\d{3})/.exec(rawHead);
        resolve({ status: m ? Number(m[1]) : 0, headers: h, body: raw, url: target });
      };

      sock.on('data', (c) => {
        if (settled) return;
        chunks.push(c);
        total += c.length;
        if (total > MAX_BODY * 2) { finish(); return; }
        settle();
      });
      sock.on('error', (e) => {
        if (settled) return;
        settled = true;
        clearTimeout(timer);
        reject(e);
      });
      sock.on('end', finish);
      sock.on('close', () => { if (!settled) finish(); });
    })).then((res) => {
      if (res.status >= 300 && res.status < 400 && res.headers.location && hop > 0) {
        return send(new URL(res.headers.location, target).toString(), hop - 1, target);
      }
      return res;
    });
  };
  return send(String(url), maxRedirects, referer);
}

function httpGet(url, opts) {
  return httpRequest(url, { ...(opts || {}), method: 'GET' });
}

/* ─────────────────────── 图床转存（让链接不失效） ─────────────────────── */

/**
 * 把图片字节传到免费图床，拿一个**稳定的公网地址**。
 *
 * 为什么值得做（实测）：QQ 图片直链几分钟就失效，而我们最后交给用户的是
 * 「Yandex / Google Lens / 百度识图 的结果页链接」，那些链接的参数里**嵌的就是图片地址** ——
 * 用 QQ 直链的话，用户过一会儿再点就废了。转存到图床后链接能长期用。
 *
 * ⚠️ 这会把图片上传到第三方（uguu.se）。识图本身就是把图交给搜索引擎，
 *    所以不算额外泄露，但这是**可在设置里关掉**的（imageHost: off）。
 * 失败一律返回空串，不影响主流程。
 */
async function hostImage(bytes, mime, s) {
  if (!s.imageHost || s.imageHost === 'off') return '';
  const proxy = s.proxy && s.proxy !== 'none' ? s.proxy : '';
  const boundary = '----qqagent' + Math.random().toString(36).slice(2, 12);
  const head = Buffer.from(
    `--${boundary}\r\n`
    + `Content-Disposition: form-data; name="files[]"; filename="qq-agent.${(mime || 'image/jpeg').split('/')[1] || 'jpg'}"\r\n`
    + `Content-Type: ${mime || 'image/jpeg'}\r\n\r\n`,
    'utf8'
  );
  const tail = Buffer.from(`\r\n--${boundary}--\r\n`, 'utf8');
  const body = Buffer.concat([head, bytes, tail]);
  try {
    const res = await httpRequest(IMAGE_HOST, {
      method: 'POST',
      proxy,
      timeoutMs: Math.min(s.timeoutMs + 10000, 60000),
      referer: 'https://uguu.se/',
      headers: { 'content-type': `multipart/form-data; boundary=${boundary}` },
      body,
      maxRedirects: 2
    });
    const text = res.body.toString('utf8');
    let url = '';
    try {
      const j = JSON.parse(text);
      url = String((j && j.files && j.files[0] && j.files[0].url) || '');
    } catch {
      const m = /"url"\s*:\s*"(https?:\\?\/\\?\/[^"]+)"/.exec(text);
      url = m ? m[1].replace(/\\\//g, '/') : '';
    }
    if (!/^https?:\/\//i.test(url)) {
      dbg(`hostImage: 图床没返回可用地址（status=${res.status} body=${clipText(text, 120)}）`);
      return '';
    }
    dbg(`hostImage: 已转存 → ${url}`);
    return url;
  } catch (e) {
    dbg(`hostImage 失败：${clipText((e && e.message) || e, 120)}`);
    return '';
  }
}

/* ─────────────────────────── 找图 ─────────────────────────── */

function imagesInEntry(entry) {
  const media = Array.isArray(entry?.media) ? entry.media : [];
  return media.filter((m) => m && m.kind === 'image' && (m.url || m.file));
}

function locateImage(ctx, messageId) {
  const store = ctx?.store;
  if (!store) return { error: '拿不到聊天记录（store 没就绪），没法定位图片' };
  const want = String(messageId ?? '').trim();
  if (want) {
    const entry = store.findByMid(ctx.chatKey, want);
    if (!entry) return { error: `当前会话里找不到消息 ${want}。请用聊天记录里那条消息前的 #数字（不要自己编）。` };
    const list = imagesInEntry(entry);
    if (!list.length) return { error: `消息 ${want} 里没有图片。` };
    return { entry, media: list[0] };
  }
  const recent = store.recent(ctx.chatKey, { limit: settings().scanMessages }) || [];
  for (let i = recent.length - 1; i >= 0; i -= 1) {
    const list = imagesInEntry(recent[i]);
    if (list.length) return { entry: recent[i], media: list[0], scanned: true };
  }
  return { error: '最近的消息里没有找到图片。让对方直接发一张图，或者把那条带图消息前的 #数字告诉我。' };
}

/** 下载图片字节：http 直链优先（直连最快），失败退回协议端缓存（get_image）。 */
async function imageBytes(ctx, media, s) {
  const notes = [];
  const url = String(media?.url || '').trim();
  const file = String(media?.file || '').trim();

  if (url && /^https?:\/\//i.test(url)) {
    try {
      const res = await httpGet(url, { timeoutMs: Math.min(s.timeoutMs, 25000) });
      if (res.status === 200) {
        const buf = res.body;
        if (buf.length) {
          const mime = sniffImage(buf);
          if (!mime) {
            notes.push(looksLikeHtml(buf) ? '直链返回的是网页（图床链接可能已过期）' : '直链返回的不是图片');
          } else if (buf.length > s.maxBytes) {
            notes.push(`图片太大（${Math.round(buf.length / 1048576)}MB，上限 ${Math.round(s.maxBytes / 1048576)}MB）`);
          } else {
            return { buffer: buf, mime, via: 'QQ 图片直链', url };
          }
        } else {
          notes.push('直链返回空内容');
        }
      } else {
        notes.push(`直链下载失败：HTTP ${res.status}`);
      }
    } catch (e) {
      notes.push('直链下载失败：' + clipText((e && e.message) || e, 120));
    }
  } else {
    notes.push('这条消息里没有可用的 http 图片地址');
  }

  if (file) {
    try {
      const ret = await ctx.onebot.call('get_image', { file });
      const raw = ret?.buffer || ret?.data || ret?.file || null;
      if (raw) {
        const bytes = Buffer.isBuffer(raw) ? raw : Buffer.from(raw);
        const mime = sniffImage(bytes);
        if (mime && bytes.length && bytes.length <= s.maxBytes) {
          return { buffer: bytes, mime, via: '协议端缓存（get_image）', url };
        }
        notes.push('协议端缓存里的内容不是可用图片');
      } else {
        notes.push('协议端没有这张图的缓存');
      }
    } catch (e) {
      notes.push('get_image 失败：' + clipText((e && e.message) || e, 120));
    }
  }

  return { error: notes.join('；') || '图片拿不到' };
}

/* ─────────────────────────── 解析小工具 ─────────────────────────── */

function unescapeJs(s) {
  return String(s || '')
    .replace(/\\u([0-9a-fA-F]{4})/g, (_, h) => String.fromCharCode(parseInt(h, 16)))
    .replace(/\\\//g, '/')
    .replace(/\\"/g, '"');
}

function decodeEntities(s) {
  return String(s || '')
    .replace(/&quot;/g, '"')
    .replace(/&#0?39;|&apos;|&#x27;/gi, '\'')
    .replace(/&nbsp;/g, ' ')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&amp;/g, '&')
    .replace(/&#(\d+);/g, (_, d) => String.fromCharCode(Number(d)))
    .replace(/&#x([0-9a-f]+);/gi, (_, h) => String.fromCharCode(parseInt(h, 16)));
}

function isRealImageUrl(u) {
  const s = String(u || '').trim();
  if (!/^https?:\/\//i.test(s)) return false;
  return !/^https?:\/\/[^/]*$/.test(s) && !/\s/.test(s) && s.length < 1200;
}

function dedupe(list, key = (x) => x) {
  const seen = new Set();
  const out = [];
  for (const item of list) {
    const k = key(item);
    if (!k || seen.has(k)) continue;
    seen.add(k);
    out.push(item);
  }
  return out;
}

function chunk(arr, size) {
  const out = [];
  const n = Math.max(1, Number(size) || 1);
  for (let i = 0; i < arr.length; i += n) out.push(arr.slice(i, i + n));
  return out;
}

function textDigest(html, maxChars = DIGEST_MAX) {
  const raw = String(html || '')
    .replace(/<script[\s\S]*?<\/script>/gi, ' ')
    .replace(/<style[\s\S]*?<\/style>/gi, ' ')
    .replace(/<noscript[\s\S]*?<\/noscript>/gi, ' ')
    .replace(/<!--[\s\S]*?-->/g, ' ');
  const text = decodeEntities(raw.replace(/<[^>]+>/g, ' ')).replace(/\s+/g, ' ').trim();
  return text.length > maxChars ? `${text.slice(0, maxChars)}…（已截断）` : text;
}

function blockedReason(html) {
  const t = String(html || '').slice(0, 20000);
  if (/captcha|unusual traffic|not a robot|SmartCaptcha|人机验证|验证码/i.test(t)) return '被人机校验拦了';
  if (/consent\.google|before you continue/i.test(t)) return '卡在 Google 的 Cookie 同意页';
  if (/enablejs|如果您在几秒钟内没有被重定向/i.test(t)) return '结果页要求 JS 渲染，服务端拿不到数据';
  if (/under construction/i.test(t)) return '拿到的是占位页（说明这条需要走代理）';
  return '';
}

/* ─────────────────────── Yandex（唯一能出结果的源） ─────────────────────── */

/**
 * Yandex 识别结果页。实测：
 *   · 走代理才有数据（直连是 "under construction" 或空壳页）；
 *   · 数据在 data-bem="…&quot;…&quot;" 里，必须先 decodeEntities 再解析；
 *   · 相似图在 avatars.mds.yandex.net，来源站点带 url/title。
 */
async function yandexRun(imageUrl, s) {
  // ⚠️ 地址里**不能带 cbir_id=**（哪怕值是空的）：
  //    实测同一张图、同一时刻 —— 带 "&cbir_id=" 时 Yandex 返回 224KB 的空壳页
  //    （cbirSites 为空、连一张相似图都没有）；去掉它则是 692KB 的真结果页
  //    （58 张相似图 + 30 个来源页）。这个空参数会让 Yandex 跳过 CBIR 计算。
  const pageUrl = `${YANDEX_SEARCH}?rpt=imageview&url=${encodeURIComponent(imageUrl)}`;
  const proxy = s.proxy && s.proxy !== 'none' ? s.proxy : '';
  const tried = [];
  // 实测：同一地址不同时刻会拿到**两种**响应 ——
  //   ① 620KB 左右：有 cbirSites / 相似图 → 有数据
  //   ② 220KB 左右：空壳（"站点还在算"或这个后端实例没算）→ 解析为空
  // 而且**完全随机**（同一分钟测 4 个地址：两个出一、两个不出；同一个地址过几分钟又变了）。
  // 空壳回得很快（3~4 秒），所以多试几次是最划算的办法。
  const plans = [];
  if (proxy) for (let i = 1; i <= 3; i += 1) plans.push({ proxy, label: `proxy#${i}`, ms: s.proxyMs });
  plans.push({ proxy: '', label: 'direct', ms: s.timeoutMs });

  for (const a of plans) {
    try {
      const res = await httpGet(pageUrl, {
        proxy: a.proxy,
        timeoutMs: a.ms,
        referer: 'https://yandex.com/images/'
      });
      const html = res.body.toString('utf8');
      const parsed = parseYandex(html);
      dbg(`yandex[${a.label}] status=${res.status} ${briefHtml(html)} → 图 ${parsed.images.length} 缩略图 ${(parsed.thumbs || []).length} 来源 ${parsed.pages.length}`);
      if (res.status !== 200) { tried.push(`${a.label}: HTTP ${res.status}`); continue; }
      if (parsed.images.length || parsed.pages.length) {
        return {
          engine: 'Yandex 识图',
          pageUrl,
          html,
          parsed,
          note: a.label === 'direct' ? '（这次是直连拿到的，结果可能不全）' : ''
        };
      }
      tried.push(`${a.label}: ${blockedReason(html) || '这个后端实例还没算出来（换一个再试）'}`);
    } catch (e) {
      tried.push(`${a.label}: ${clipText((e && e.message) || e, 100)}`);
    }
    // 换后端之前稍等一下，别把同一台又打一遍
    // eslint-disable-next-line no-await-in-loop
    await new Promise((r) => setTimeout(r, 700));
  }
  throw new Error(`Yandex 走不通（${tried.join('；')}）`);
}

/**
 * Yandex 结果页解析。
 * 真实结构（实测 page 里 cbirSites.sites[]）：
 *   "cbirSites":{"sites":[{"title":"…","description":"…","url":"…","domain":"…",
 *                           "thumb":{"url":"//avatars.mds.yandex.net/i?id=…"},
 *                           "originalImage":{"url":"https://来源站/xxx.jpg"}}]}
 * 所以优先按这个结构取值；取不到再退回正则捞图床链接。
 */
function parseYandex(html) {
  const out = { images: [], pages: [], text: '', thumbs: [] };
  const text = decodeEntities(String(html || ''));   // ← 关键一步：数据在 HTML 转义里
  const seen = new Set();

  // ① 主路径：从 cbirSites 里拿"来源站点 + 它们上面的原图"
  const start = text.indexOf('"cbirSites"');
  if (start >= 0) {
    const slice = text.slice(start, start + 400000);
    for (const m of slice.matchAll(/"originalImage"\s*:\s*\{\s*"url"\s*:\s*"(https?:\/\/[^"]{8,800})"/g)) {
      const u = unescapeJs(m[1]).replace(/&amp;/g, '&');
      if (!isRealImageUrl(u) || seen.has(u)) continue;
      seen.add(u);
      out.images.push(u);
      if (out.images.length >= 60) break;
    }
    for (const m of slice.matchAll(/\{"title":"((?:[^"\\]|\\.){0,160})","description":"((?:[^"\\]|\\.){0,400})","url":"(https?:\/\/[^"]{8,600})"/g)) {
      const title = unescapeJs(m[1]).trim();
      const desc = unescapeJs(m[2]).trim();
      const url = unescapeJs(m[3]);
      if (!/^https?:\/\//i.test(url)) continue;
      out.pages.push({ url, title: title || desc || '' });
      if (out.pages.length >= 30) break;
    }
    // ①b 另一条途径：**来源站的缩略图存在 Yandex 自己图床**（//avatars.mds.yandex.net/i?id=…）。
    //     为什么要它：实测大量来源站的原图其实**已经失效**（Pinterest 的 CDN 直接回
    //     AccessDenied，换 referer/UA 都没用），而 Yandex 缓存的那份**还活着、发得出去** ——
    //     这正是"图发不出来"时能救场的那条路。
    const thumbs = [];
    for (const m of slice.matchAll(/"thumb"\s*:\s*\{\s*"url"\s*:\s*"(\/\/[^"]{10,600})"/g)) {
      const u = 'https:' + unescapeJs(m[1]).replace(/&amp;/g, '&');
      if (!isRealImageUrl(u) || seen.has(u)) continue;
      seen.add(u);
      thumbs.push(u);
      if (thumbs.length >= 40) break;
    }
    out.thumbs = thumbs;
  }

  // ② 兜底：图床链接（缩略图/相似图）。要**带引号终止**，否则会把 URL 截断成垃圾前缀。
  if (!out.images.length) {
    for (const m of text.matchAll(/https?:\/\/avatars\.mds\.yandex\.net\/[^"'\\\s<>()]{5,400}(?=["'\\\s<>])/g)) {
      const u = unescapeJs(m[0]).replace(/&amp;/g, '&');
      if (!isRealImageUrl(u) || seen.has(u)) continue;
      if (/yapic|\/0-0\/|\/ocr$|\/ocr\?/.test(u)) continue;      // 头像 / OCR 图不要
      // ⚠️ 只要"带尺寸参数"的缩略图（cdn 上的图都有 ?id=…&n=13），
      //    站点自身 UI 的静态图（/blocks-and-captchas/…）不带参数，别收进来
      if (!/[?&](id|n)=/.test(u)) {
        if (!/get-images-cbir|get-mimages/.test(u)) continue;
      }
      seen.add(u);
      out.images.push(u);
      if (out.images.length >= 60) break;
    }
  }
  if (!out.pages.length) {
    for (const m of text.matchAll(/"url"\s*:\s*"(https?:\/\/[^"]{8,500})"/g)) {
      const u = unescapeJs(m[1]);
      if (!/^https?:\/\//i.test(u)) continue;
      if (/yandex\.(com|net|ru)|yandexcloud|yastatic\.net|avatars\.mds|mc\.yandex/i.test(u)) continue;
      out.pages.push({ url: u, title: '' });
      if (out.pages.length >= 30) break;
    }
  }

  // ③ 结论文字：识别标签 + 来源页标题（"这图出现在哪些页面"本身就是最有用的线索）
  const tags = [];
  const appears = /Image appears to contain([\s\S]{0,200}?)(?:<|"|$)/i.exec(text);
  if (appears) {
    const t = appears[1].replace(/\s+/g, ' ').trim();
    if (t && t.length > 1) tags.push(t);
  }
  for (const p of out.pages) {
    const t = String(p.title || '').trim();
    if (t && !tags.includes(t)) tags.push(t);
    if (tags.length >= 6) break;
  }
  out.text = tags.join(' / ').slice(0, 250);

  // ④ 去跟踪参数 + 去掉"同一张图的不同代理形态"（wp.com 的 i0/i1/i2… 前缀）
  out.pages = dedupe(out.pages.map((p) => ({ ...p, url: stripTrackers(p.url) })), (p) => p.url);
  const byKey = new Map();
  for (const u of out.images) {
    const key = u.replace(/^https?:\/\/i\d+\.wp\.com\//, 'https://').split('?')[0];
    if (!byKey.has(key)) byKey.set(key, u);
  }
  out.images = [...byKey.values()];

  dbg(`parseYandex: 可用图 ${out.images.length}，来源 ${out.pages.length}，tags=${tags.length}`);
  return out;
}

/** 去掉来源链接里的跟踪参数，让模型发出去的链接干净点。 */
function stripTrackers(url) {
  try {
    const u = new URL(String(url));
    for (const k of [...u.searchParams.keys()]) {
      if (/^(utm_|yclid|gclid|fbclid|_openstat|from|spm)/i.test(k)) u.searchParams.delete(k);
    }
    return u.toString();
  } catch {
    return String(url || '');
  }
}

/* ─────────────────────── 百度（真浏览器驱动） ─────────────────────── */
//
// 为什么需要这条路（实测，2026-10-09）：
//   百度的识图上传接口 /upload 对「图片 URL」和「图片字节」**一律回 Reject**，
//   带上 BAIDUID Cookie + Origin/Referer 也一样拒 —— 它要的是一段由网页 JS 算出来的签名。
//   唯一能拿到真实结果的办法就是**像人一样点那一下**：用本机 Edge/Chrome 打开
//   百度识图入口页，把图片文件塞进它的 <input type=file>，它自己会上传并跳结果页。
//   ⚠️ 必须塞**文件**而不是粘贴网址：实测百度抓不到第三方图床（uguu 直接"图片上传失败"），
//      而文件是浏览器直接 POST 上去的，不经过"百度能不能抓到这个 URL"这一关。
//
// 拿到的结果（实测）：识别结论（"图中可能是…"）、相关商品（价格/标题/平台）、
//   图片来源（网页）、相似图片（百度自己 CDN 上的图 → 国内可发，比 Pinterest 那些死链强）。

const BAIDU_ENTRY = 'https://graph.baidu.com/pcpage/index?tpl_from=pc';

/** 找本机 Chromium 系浏览器（Edge 在 Windows 上必定存在）。 */
function findBrowser(override = '') {
  const cands = [];
  if (override) cands.push(String(override));
  const pf = process.env.ProgramFiles || 'C:\\Program Files';
  const pf86 = process.env['ProgramFiles(x86)'] || 'C:\\Program Files (x86)';
  const local = process.env.LOCALAPPDATA || '';
  if (process.platform === 'win32') {
    cands.push(
      path.join(pf86, 'Microsoft', 'Edge', 'Application', 'msedge.exe'),
      path.join(pf, 'Microsoft', 'Edge', 'Application', 'msedge.exe'),
      path.join(pf, 'Google', 'Chrome', 'Application', 'chrome.exe'),
      path.join(pf86, 'Google', 'Chrome', 'Application', 'chrome.exe'),
      local ? path.join(local, 'Google', 'Chrome', 'Application', 'chrome.exe') : ''
    );
  } else if (process.platform === 'darwin') {
    cands.push('/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',
      '/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge');
  } else {
    cands.push('/usr/bin/google-chrome', '/usr/bin/chromium', '/usr/bin/microsoft-edge');
  }
  for (const p of cands.filter(Boolean)) {
    try { if (fs.existsSync(p) && fs.statSync(p).size > 1024) return p; } catch { /* 下一个 */ }
  }
  return '';
}

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

/** 极小的 CDP 客户端：只用到 Page/Runtime/DOM 三个域。 */
async function cdpSession(wsUrl) {
  let WS = null;
  try {
    const m = await import('ws');                    // 项目自带 ws（resources/app/node_modules）
    WS = m.default || m.WebSocket || m;
  } catch {
    WS = globalThis.WebSocket;                       // 退到运行时自带
  }
  if (!WS) throw new Error('拿不到 WebSocket 实现（ws 包与全局 WebSocket 都没有）');

  const sock = new WS(wsUrl);
  const on = (ev, fn) => (typeof sock.on === 'function' ? sock.on(ev, fn) : sock.addEventListener(ev, fn));
  await new Promise((res, rej) => {
    on('open', res);
    on('error', rej);
  });

  let id = 0;
  const pending = new Map();
  on('message', (raw) => {
    let m = null;
    try { m = JSON.parse(typeof raw === 'string' ? raw : (raw.data || raw.toString())); } catch { return; }
    if (m && m.id && pending.has(m.id)) { pending.get(m.id)(m); pending.delete(m.id); }
  });

  const send = (method, params = {}, timeoutMs = 30000) => new Promise((resolve, reject) => {
    const i = ++id;
    pending.set(i, (m) => (m.error ? reject(new Error(`${method}: ${JSON.stringify(m.error)}`)) : resolve(m.result)));
    try { sock.send(JSON.stringify({ id: i, method, params })); } catch (e) { reject(e); return; }
    setTimeout(() => { if (pending.has(i)) { pending.delete(i); reject(new Error(`${method} 超时`)); } }, timeoutMs);
  });

  return { send, close: () => { try { sock.close(); } catch { /* ignore */ } } };
}

/** 等 CDP 端口起来，返回版本信息。 */
async function waitCdp(port, timeoutMs) {
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    try {
      const r = await fetch(`http://127.0.0.1:${port}/json/version`);
      if (r.ok) return await r.json();
    } catch { /* 还没起来 */ }
    await sleep(400);
  }
  throw new Error('浏览器调试端口没起来');
}

/** 页面上要执行的提取脚本（在浏览器里跑，拿到结构化结果）。 */
const BAIDU_EXTRACT_JS = `(() => {
  const out = { guess: '', similar: [], goods: [], sources: [] };
  const abs = (u) => { try { return new URL(u, location.href).toString(); } catch { return ''; } };
  const text = document.body.innerText || '';
  const g = /图中可能是([^\\n]{1,40})/.exec(text);
  if (g) out.guess = g[1].trim();
  for (const img of document.querySelectorAll('img')) {
    const u = abs(img.getAttribute('data-src') || img.src || '');
    if (/\\/\\/(t\\d+|mms\\d*)\\.baidu\\.com\\/it\\//.test(u)) out.similar.push(u);
  }
  out.similar = [...new Set(out.similar)];
  const priceRe = /¥\\s*([\\d.]+)/;
  const seen = new Set();
  for (const el of document.querySelectorAll('div,li,a')) {
    const t = (el.innerText || '').trim();
    if (!t || t.length > 220) continue;
    const m = priceRe.exec(t);
    if (!m) continue;
    const plat = (t.match(/淘宝|京东|天猫|拼多多|闲鱼/) || [''])[0];
    const lines = t.split('\\n').map((x) => x.trim()).filter(Boolean);
    const title = lines.find((l) => !priceRe.test(l) && !/^(淘宝|京东|天猫|拼多多|闲鱼)$/.test(l)) || '';
    const key = m[1] + '|' + title.slice(0, 40);
    if (seen.has(key)) continue;
    seen.add(key);
    out.goods.push({ price: m[1], title: title.slice(0, 80), platform: plat });
    if (out.goods.length >= 8) break;
  }
  const seenUrl = new Set();
  for (const a of document.querySelectorAll('a[href]')) {
    const h = abs(a.getAttribute('href'));
    if (!/^https?:\\/\\//.test(h) || /baidu\\.com/.test(h)) continue;
    const t = (a.innerText || '').trim();
    if (!t || t.length > 90 || seenUrl.has(h)) continue;
    seenUrl.add(h);
    out.sources.push({ url: h, title: t });
    if (out.sources.length >= 12) break;
  }
  return JSON.stringify(out);
})()`;

/**
 * 用真浏览器跑一次百度识图。需要图片字节（写临时文件交给它的文件框）。
 * 全程自己收尾：关连接、杀进程、删临时目录。
 */
async function baiduBrowserRun(imageUrl, s, bin) {
  if (!bin || !bin.buffer || !bin.buffer.length) throw new Error('没有图片字节，浏览器这条路走不了');
  const browser = findBrowser(s.browserPath);
  if (!browser) throw new Error('本机没找到 Edge / Chrome（可在设置里手动指定路径）');

  const workDir = fs.mkdtempSync(path.join(os.tmpdir(), 'qqagent-baidu-'));
  const extMap = { 'image/jpeg': 'jpg', 'image/png': 'png', 'image/gif': 'gif', 'image/webp': 'webp', 'image/bmp': 'bmp' };
  const file = path.join(workDir, `query.${extMap[bin.mime] || 'jpg'}`);
  fs.writeFileSync(file, bin.buffer);

  const port = 9300 + Math.floor(Math.random() * 600);
  const profile = fs.mkdtempSync(path.join(os.tmpdir(), 'qqagent-cdp-'));
  let child = null;
  let cdp = null;
  try {
    child = spawn(browser, [
      '--headless=new', `--remote-debugging-port=${port}`, `--user-data-dir=${profile}`,
      '--no-first-run', '--no-default-browser-check', '--disable-gpu', '--disable-extensions',
      '--disable-background-networking', '--window-size=1400,1000', 'about:blank'
    ], { stdio: 'ignore', windowsHide: true });

    await waitCdp(port, 25000);
    const tabRes = await fetch(`http://127.0.0.1:${port}/json/new?about:blank`, { method: 'PUT' })
      .catch(() => fetch(`http://127.0.0.1:${port}/json/new?about:blank`));
    const tab = await tabRes.json();
    cdp = await cdpSession(tab.webSocketDebuggerUrl);

    await cdp.send('Page.enable');
    await cdp.send('Runtime.enable');
    await cdp.send('DOM.enable');

    const evaluate = async (expr, timeoutMs) => {
      const r = await cdp.send('Runtime.evaluate', { expression: expr, returnByValue: true, awaitPromise: true }, timeoutMs);
      return r && r.result ? r.result.value : undefined;
    };

    await cdp.send('Page.navigate', { url: BAIDU_ENTRY });
    await sleep(4500);
    // 关掉"文字提取"那个引导浮层，否则可能挡住输入框
    await evaluate(`(()=>{const b=[...document.querySelectorAll('button,a,span,div')].find(x=>String(x.textContent||'').trim()==='知道啦'); if(b)b.click(); return 1;})()`);

    const doc = await cdp.send('DOM.getDocument', { depth: 1 });
    const q = await cdp.send('DOM.querySelector', { nodeId: doc.root.nodeId, selector: 'input[type=file]' });
    if (!q || !q.nodeId) throw new Error('百度识图页面上没找到上传入口（页面结构可能变了）');
    await cdp.send('DOM.setFileInputFiles', { files: [file], nodeId: q.nodeId });
    dbg('baidu-browser: 已把图片文件交给百度识图，等结果…');

    const waitMs = Math.max(8000, s.browserWaitMs || 30000);
    let state = null;
    for (let waited = 0; waited < waitMs; waited += 1500) {
      // eslint-disable-next-line no-await-in-loop
      await sleep(1500);
      // eslint-disable-next-line no-await-in-loop
      const raw = await evaluate(`JSON.stringify({
        goods: /相关商品/.test(document.body.innerText),
        similar: /相似图片/.test(document.body.innerText),
        fail: /图片上传失败|上传失败/.test(document.body.innerText),
        href: location.href.slice(0, 80)
      })`);
      try { state = JSON.parse(raw || '{}'); } catch { state = null; }
      if (state && state.fail) throw new Error('百度说"图片上传失败"（这张图它不收）');
      if (state && (state.goods || state.similar)) break;
    }
    if (!state || !(state.goods || state.similar)) {
      throw new Error(`等 ${Math.round(waitMs / 1000)} 秒没等到百度结果页`);
    }

    const rawOut = await evaluate(BAIDU_EXTRACT_JS, 20000);
    let data = {};
    try { data = JSON.parse(rawOut || '{}'); } catch { data = {}; }

    const goodsLines = (data.goods || []).map((g) => `¥${g.price}${g.platform ? `(${g.platform})` : ''} ${g.title}`);
    const digest = [data.guess ? `识别结论：图中可能是${data.guess}` : '', ...goodsLines].filter(Boolean).join('\n').slice(0, 600);
    const finalUrl = await evaluate('location.href', 8000).catch(() => BAIDU_ENTRY);
    dbg(`baidu-browser: 相似图 ${(data.similar || []).length} 张、商品 ${(data.goods || []).length} 条、来源 ${(data.sources || []).length} 条`);

    return {
      engine: '百度识图（浏览器）',
      pageUrl: String(finalUrl || BAIDU_ENTRY),
      html: '',
      parsed: { images: data.similar || [], pages: data.sources || [], text: digest, thumbs: [] },
      note: ''
    };
  } finally {
    // 收尾三件套。⚠️ 只 kill 顶层进程在 Windows 上**杀不掉 Edge 的子进程树**
    // （它会留下 renderer/gpu 等一堆进程 + 临时 profile 删不掉），
    // 所以先用 CDP 的 Browser.close 让它自己体面退出，再 taskkill /T /F 兜底。
    try { if (cdp) { await cdp.send('Browser.close', {}, 5000).catch(() => {}); cdp.close(); } } catch { /* ignore */ }
    try { if (child && !child.killed) child.kill(); } catch { /* ignore */ }
    if (process.platform === 'win32' && child && child.pid) {
      try {
        spawn('taskkill', ['/PID', String(child.pid), '/T', '/F'], { stdio: 'ignore', windowsHide: true });
      } catch { /* ignore */ }
    }
    // 等它落盘再删目录（不然 profile 可能还被占着）
    await sleep(600);
    for (const dir of [workDir, profile]) {
      try { fs.rmSync(dir, { recursive: true, force: true }); } catch { /* 下次开机自己清 */ }
    }
  }
}

/* ─────────────────────── 百度（HTTP 接口，基本走不通） ─────────────────────── */

/** 百度识图页（点开自己搜）。⚠️ 不要用 /details（那是通用拍照识别页）。 */
function baiduUrlPage(imageUrl) {
  return `https://graph.baidu.com/details?isfromtusoupc=1&tn=pc&image=${encodeURIComponent(imageUrl)}`;
}

/**
 * 百度识图：实测"按 URL / 按字节 / base64"三条全被拒。
 * 仍然各试一次（万一哪天放开），失败就抛错，让上层退下一家并给链接。
 */
async function baiduRun(imageUrl, s, bin) {
  const proxy = s.proxy && s.proxy !== 'none' ? s.proxy : '';
  const tried = [];
  const tryPost = async (label, pairs) => {
    try {
      const res = await httpRequest(BAIDU_UPLOAD, {
        method: 'POST',
        proxy,
        timeoutMs: s.timeoutMs,
        referer: 'https://graph.baidu.com/',
        headers: { 'content-type': 'application/x-www-form-urlencoded' },
        body: formUrlEncoded(pairs),
        maxRedirects: 0
      });
      const text = res.body.toString('utf8');
      dbg(`baidu[${label}] status=${res.status} loc=${res.headers.location || '-'} body=${clipText(text, 200)}`);
      if (res.headers.location) {
        const r2 = await httpGet(new URL(res.headers.location, BAIDU_UPLOAD).toString(), {
          proxy, timeoutMs: s.timeoutMs, referer: 'https://graph.baidu.com/'
        });
        const html = r2.body.toString('utf8');
        dbg(`baidu page status=${r2.status} ${briefHtml(html)}`);
        return { engine: '百度识图', pageUrl: r2.url, html, parsed: parseBaidu(html), note: '' };
      }
      tried.push(`${label}: ${clipText(text, 70) || `HTTP ${res.status}`}`);
      return null;
    } catch (e) {
      tried.push(`${label}: ${clipText((e && e.message) || e, 100)}`);
      return null;
    }
  };

  const r1 = await tryPost('url', {
    image: imageUrl, image_source: 'PC_UPLOAD_SEARCH_URL', from: 'pc', tn: 'pc'
  });
  if (r1) return r1;

  // 按字节：multipart 需要 undici 的 fetch（FormData 手写太脆），单独走一次
  if (bin && bin.buffer && bin.buffer.length) {
    try {
      const fd = new FormData();
      fd.append('image', new Blob([bin.buffer], { type: bin.mime || 'image/jpeg' }), 'query.jpg');
      fd.append('image_source', 'PC_UPLOAD');
      fd.append('tn', 'pc');
      const ac = new AbortController();
      const timer = setTimeout(() => ac.abort(), s.timeoutMs);
      const res = await fetch(BAIDU_UPLOAD, {
        method: 'POST',
        headers: { referer: 'https://graph.baidu.com/', 'user-agent': UA },
        body: fd,
        signal: ac.signal
      });
      clearTimeout(timer);
      const text = await res.text();
      dbg(`baidu[bytes] status=${res.status} body=${clipText(text, 200)}`);
      tried.push(`bytes: ${clipText(text, 70) || `HTTP ${res.status}`}`);
    } catch (e) {
      tried.push(`bytes: ${clipText((e && e.message) || e, 100)}`);
    }
  }

  throw new Error(`百度识图走不通（${tried.join('；')}）`);
}

function parseBaidu(html) {
  const out = { images: [], pages: [], text: '' };
  const text = String(html || '');
  const seen = new Set();
  for (const key of ['objURL', 'thumbURL', 'middleURL', 'hoverURL']) {
    const re = new RegExp(`"${key}"\\s*:\\s*"([^"]+)"`, 'g');
    for (const m of text.matchAll(re)) {
      const u = unescapeJs(m[1]);
      if (!isRealImageUrl(u) || seen.has(u)) continue;
      seen.add(u);
      out.images.push(u);
    }
  }
  for (const m of text.matchAll(/"fromURL"\s*:\s*"([^"]+)"/g)) {
    const u = unescapeJs(m[1]);
    if (isRealImageUrl(u)) out.pages.push({ url: u, title: '' });
  }
  if (!out.images.length) out.text = textDigest(text, 300);
  return out;
}

/* ─────────────────────── Google Lens（只能给链接） ─────────────────────── */

async function googleRun(imageUrl, s) {
  const proxy = s.proxy && s.proxy !== 'none' ? s.proxy : '';
  const start = `${LENS_UPLOAD}?url=${encodeURIComponent(imageUrl)}&hl=zh-CN`;
  const res = await httpGet(start, {
    proxy,
    timeoutMs: proxy ? s.proxyMs : s.timeoutMs,
    referer: 'https://lens.google.com/',
    maxRedirects: 5
  });
  const html = res.body.toString('utf8');
  const finalUrl = res.url || start;    // 跟完重定向的地址（google.com/search?vsrid=…）
  dbg(`google status=${res.status} ${briefHtml(html)} final=${clipText(finalUrl, 160)}`);
  const parsed = parseLens(html);
  if (parsed.images.length) return { engine: 'Google Lens', pageUrl: finalUrl, html, parsed, note: '' };
  throw new Error(`Google Lens 结果页需要 JS 渲染，服务端拿不到数据（链接可用：${finalUrl}）`);
}

function parseLens(html) {
  const out = { images: [], pages: [], text: '' };
  const text = decodeEntities(String(html || ''));
  const seen = new Set();
  for (const m of text.matchAll(/https:\/\/[^"'\\\s]*?(?:encrypted-tbn0\.gstatic\.com|tbn\d?\.google\.com)[^"'\\\s]*/g)) {
    const norm = unescapeJs(m[0]);
    if (!isRealImageUrl(norm) || seen.has(norm)) continue;
    seen.add(norm);
    out.images.push(norm);
  }
  for (const m of text.matchAll(/href="\/url\?q=([^"&]+)[^"]*"/g)) {
    try {
      const u = decodeURIComponent(m[1]);
      if (/^https?:\/\//i.test(u)) out.pages.push({ url: u, title: '' });
    } catch { /* 跳过坏链接 */ }
  }
  out.text = textDigest(text, 250);
  return out;
}

/* ─────────────────────── 必应（永不采纳结果） ─────────────────────── */

function bingUrlPage(imageUrl) {
  const enc = encodeURIComponent(imageUrl);
  return 'https://www.bing.com/images/search?view=detailv2&iss=sbi'
    + `&imgurl=${enc}&q=imgurl:${enc}&idpbck=1`;
}

function lensUrlPage(imageUrl) {
  return `${LENS_UPLOAD}?url=${encodeURIComponent(imageUrl)}&hl=zh-CN`;
}

function yandexUrlPage(imageUrl) {
  // 与 yandexRun 保持一致：不要带空的 cbir_id（带了会拿到空壳页）
  return `${YANDEX_SEARCH}?rpt=imageview&url=${encodeURIComponent(imageUrl)}`;
}

/* ─────────────────────────── 结果渲染 ─────────────────────────── */

/**
 * 发的顺序：先把"肯定拉不动"的图源排到最后。
 * 实测 i.pinimg.com 在本机经代理也拉不动（Pinterest 全域被挡），
 * 而 Yandex 对"森林/风景"这类图给出的候选**大半是 Pinterest** ——
 * 不排序的话前面每张都要白等一次超时。
 */
const FLAKY_HOST_RE = /pinimg\.com|pinterest\.|tiktokcdn|instagram\.|fbcdn\.|twimg\.com|staticflickr/i;

// 近似去重的容差：粗指纹 32 位十六进制，容差 5 位 ≈ 允许 15% 的采样差异。
// 同一张图的 736x / 564x / original 三种尺寸实测差异在这个范围内；
// 而"另一张看着像的图"通常差 10 位以上，不会被误合并。
const GRAM_TOLERANCE = 5;

function rankByHost(list) {
  const good = [];
  const flaky = [];
  for (const u of list) (FLAKY_HOST_RE.test(hostOf(u)) ? flaky : good).push(u);
  return [...good, ...flaky];
}

/** 两个粗指纹的差异位数（0 = 完全一致）。 */
function gramDistance(a, b) {
  if (!a || !b || a.length !== b.length) return 99;
  let d = 0;
  for (let i = 0; i < a.length; i += 1) if (a[i] !== b[i]) d += 1;
  return d;
}

/** 取一张图做校验：直连优先，失败再走代理；只做「能不能拿到真图」的判断。 */
async function fetchImageForVerify(url, { proxy = '', timeoutMs = 12000 } = {}) {
  for (const p of [proxy, '']) {
    try {
      // eslint-disable-next-line no-await-in-loop
      const res = await httpGet(url, { proxy: p, timeoutMs, referer: '' });
      if (res.status === 200 && res.body.length >= 8 * 1024 && sniffImage(res.body)) {
        return { buffer: res.body, viaProxy: !!p };
      }
    } catch { /* 换下一种方式 */ }
  }
  return null;
}

function hostOf(url) {
  try { return new URL(url).hostname.toLowerCase(); } catch { return ''; }
}

/**
 * 粗指纹：拿字节的 4 个采样点做 16 字节摘要。
 * 用途只是"同一张图的不同尺寸"去重（Pinterest 上同一张图常有 736x/564x/originals 多份），
 * 所以不需要真图像解码 —— 采样点会随缩放一起"搬家"，但同一来源的图往往差异极小，
 * 配合下面的尺寸前缀归一化就够用了。
 */
function coarseGram(buf) {
  if (!buf || buf.length < 4096) return '';
  const parts = [];
  for (const p of [0.1, 0.35, 0.6, 0.85]) {
    const at = Math.floor(buf.length * p);
    parts.push(buf.subarray(at, at + 512));
  }
  const cat = Buffer.concat(parts);
  // 归一化：丢掉像素级噪声，只留"块平均值"的粗轮廓
  const out = Buffer.alloc(32);
  for (let i = 0; i < 32; i += 1) {
    let sum = 0;
    const from = Math.floor((cat.length / 32) * i);
    const to = Math.floor((cat.length / 32) * (i + 1));
    for (let j = from; j < to && j < cat.length; j += 1) sum += cat[j];
    out[i] = Math.round(sum / Math.max(1, to - from));
  }
  // 量化成 16 档，抵消重编码带来的小抖动
  return [...out].map((v) => (v >> 4).toString(16)).join('');
}

function renderLines({ engine, pageUrl, images, pages, digest, notes, imagesLabel }) {
  const lines = [];
  lines.push(`搜索引擎：${engine}`);
  lines.push(`结果页（点开可自己看）：${pageUrl}`);
  for (const n of (notes || [])) lines.push(`说明：${n}`);
  if (images.length) {
    lines.push(`${imagesLabel || `图片直链（${images.length} 条，已验证可发）`}：`);
    for (const u of images) lines.push(`- ${u}`);
  } else {
    lines.push('图片直链：这一轮没有能发出去的图片（见上面的说明）。');
  }
  const pgs = dedupe(pages.filter((p) => p.url), (p) => p.url).slice(0, 8);
  if (pgs.length) {
    lines.push('可能的来源网页：');
    for (const p of pgs) lines.push(`- ${p.title ? p.title + ' — ' : ''}${p.url}`);
  }
  if (digest) lines.push(`结果页文字（识图结论通常在这里，可以据此总结）：\n${digest}`);
  return lines.join('\n');
}

/* ─────────────────── 多图：先自聊，再合并转发 ─────────────────── */
// 合并转发的前提：卡片里每个节点都必须在 QQ 上**真实存在**。
// 所以先把图逐张传到「机器人自己的私聊」，再用 sender.sendMedia 发整张卡片。
// ⚠️ 数组里必须**全是 node 段**：混进一个非 node，SnowLuma 会把整条退化成普通消息。
//
// ⚠️⚠️ 实测教训（2026-10-09，两次踩到）：**不要用"我自己能不能下载这张图"来判断
//    "这张图能不能发"**。工具侧下载图用的是别的通道（走不走代理、超时多久都不一样），
//    Pinterest 这种图床我这边校验通过、真正发送时却 100% 超时 —— 模型拿着"已验证"的
//    地址连撞三次 60 秒。**唯一可靠的验证就是"传到自聊"这一步本身**：
//    上传成功的才算数，卡片只用上传成功的那些图来拼。

/**
 * 近似去重（只做去重，不宣称"能不能发"）。
 * Yandex 给的是「同一张图在多个站的原图」，同一张画常有 736x/564x/original 多份；
 * 这里用粗指纹把近似版本合并掉。**下载失败的一律保留**——因为下载走的是我这条通道，
 * 发送走的是宿主那条，"我下不到"不等于"发不了"（这个错我犯过两次）。
 */
async function dedupeNearIdentical(urls, s, need) {
  const { createHash } = await import('node:crypto');
  const proxy = s.proxy && s.proxy !== 'none' ? s.proxy : '';
  const out = [];
  const seeds = new Set();
  const grams = [];
  const cap = Math.max(1, Math.min(12, Number(need) || 6));
  for (const u of rankByHost(urls)) {
    if (out.length >= cap) break;
    // eslint-disable-next-line no-await-in-loop
    const res = await fetchImageForVerify(u, { proxy, timeoutMs: Math.min(s.timeoutMs, 10000) });
    if (!res) { out.push(u); continue; }             // 下不到也先留着，交给发送那一步判
    const seed = createHash('sha1').update(res.buffer.subarray(0, 8192)).digest('hex');
    if (seeds.has(seed)) continue;
    const g = coarseGram(res.buffer);
    if (g && grams.some((x) => gramDistance(x, g) <= GRAM_TOLERANCE)) continue;
    seeds.add(seed);
    if (g) grams.push(g);
    out.push(u);
  }
  dbg(`dedupeNearIdentical: ${urls.length} → ${out.length}（上限 ${cap}）`);
  return out;
}

/**
 * 按顺序试着把候选图传到机器人自己的私聊，凑够 need 张为止，然后拼一张合并转发卡片。
 * 返回 { ok, uploaded:[url…], failed:[{url,error}…], nodes, reason }
 *
 * ⚠️ 三重闸门，防止"每张都白等一分钟"把一轮对话拖死：
 *   ① 最多尝试 maxAttempts 次；② 同一图床连失败 2 次就整片跳过；③ 总的尝试预算 90 秒。
 */
async function uploadAndForward(ctx, candidates, caption, need) {
  const sender = ctx?.sender;
  if (!sender || typeof sender.sendImage !== 'function' || typeof sender.sendMedia !== 'function') {
    return { ok: false, uploaded: [], failed: [], nodes: 0, reason: '当前版本没提供发送器（sender），发不了合并转发' };
  }
  const selfId = String(ctx.selfId || '');
  if (!selfId) return { ok: false, uploaded: [], failed: [], nodes: 0, reason: '拿不到机器人自己的 QQ 号（selfId）' };
  const botName = String(ctx.selfNickname || (ctx.onebot && ctx.onebot.selfNickname) || 'bot');
  const selfKey = `private:${selfId}`;
  const s = settings();
  const want = Math.max(1, Math.min(12, Number(need) || s.forwardThreshold));
  const maxAttempts = Math.min(candidates.length, Math.max(want + 1, 4));
  const deadline = Date.now() + 90000;
  const HOST_FAIL_LIMIT = 2;

  const uploaded = [];
  const failed = [];
  const hostFails = new Map();
  let attempts = 0;

  for (const url of rankByHost(candidates)) {
    if (uploaded.length >= want || attempts >= maxAttempts || Date.now() > deadline) break;
    const h = hostOf(url);
    if (h && (hostFails.get(h) || 0) >= HOST_FAIL_LIMIT) continue;   // 这个图床明显不通，整片跳过
    attempts += 1;
    try {
      // eslint-disable-next-line no-await-in-loop
      await sender.sendImage(selfKey, { url }, { note: '以图搜图的相似图' });
      uploaded.push(url);
    } catch (e) {
      failed.push({ url, error: clipText((e && e.message) || e, 80) });
      if (h) hostFails.set(h, (hostFails.get(h) || 0) + 1);
      warn(`传到自聊失败：${clipText(url, 60)} → ${clipText((e && e.message) || e, 80)}`);
    }
  }
  dbg(`uploadAndForward: 尝试 ${attempts} 次 → 成功 ${uploaded.length}，失败 ${failed.length}（图源 ${[...hostFails.keys()].join(',') || '无'}）`);

  if (!uploaded.length) {
    return { ok: false, uploaded, failed, nodes: 0, reason: '候选图一张都没能传到自聊（图床拉不动或撞上限频）' };
  }

  const nodes = [];
  for (const group of chunk(uploaded, s.imagesPerNode)) {
    nodes.push({
      type: 'node',
      data: {
        user_id: Number(selfId),
        nickname: botName,
        content: group.map((u) => ({ type: 'image', data: { file: u } }))
      }
    });
  }
  nodes.push({
    type: 'node',
    data: {
      user_id: Number(selfId),
      nickname: botName,
      content: [{ type: 'text', data: { text: caption } }]
    }
  });

  const firstLine = String(caption).split('\n')[0];
  await sender.sendMedia(ctx.chatKey, nodes, {
    label: `[${uploaded.length} 张] ${firstLine}`.slice(0, 60),
    dedupeKey: `img-search-fwd:${Date.now()}:${Math.random().toString(36).slice(2, 8)}`
  });
  return { ok: true, uploaded, nodes: nodes.length, failed };
}

/* ─────────────────────────── 工具 ─────────────────────────── */

export function setup(api) {
  apiRef = api;
  cfg = api.config || (() => ({}));
  log = api.log || (() => {});
  warn = api.warn || (() => {});

  let proxyNow = '';
  try { proxyNow = resolveProxy(api); } catch { proxyNow = ''; }
  log('已加载：以图搜图（引擎 ' + settings().engines.join(' → ')
    + '；代理 ' + (proxyNow || '未取到，Yandex 可能拿不到数据') + '）');

  api.registerTool({
    id: 'find',
    name: '以图搜图',
    description: '拿一张【聊天里出现过的图片】去搜索引擎做反向搜图（以图搜图）。'
      + '会自动从消息里取出那张图的字节，按设置顺序逐家试（默认 百度识图（浏览器）→ Yandex → …）。'
      + '百度那条用本机 Edge/Chrome 无头驱动，能给出**识别结论 + 相关商品（价格/平台）+ 图片来源网页 + 相似图片**，'
      + '每次多花十几秒；Yandex 那条走代理，给"这张图出现在哪些网页"。'
      + '当有人 @ 你说「帮我搜这张图」「这图是哪来的」「找一下相似的图」「这图出处/原图是什么」'
      + '这类**以图找图**的请求时用它（对方刚发的图一般不用传 messageId；'
      + '要搜的不是最新那张，就把聊天记录里那条消息前的 #数字放进 messageId）。'
      + '⚠️ 工具返回的"图片直链"里，标了**已发**的就是已经真的发出去的（在合并转发卡片里）；'
      + '标了**发不出去/已跳过**的地址**绝对不要再调 send_image**（那些图床在境内拉不动，'
      + '实测每次都要白等一分钟超时，用户会看到一串失败）。'
      + '⚠️ 只是让你"看看这张图"、请求聊天或点评图片时**不要**调用它 —— 那是看图工具的事。',
    category: 'media',
    icon: '🔍',
    requiresSearch: true,
    parameters: {
      type: 'object',
      properties: {
        messageId: {
          type: ['integer', 'string'],
          description: '可选：要搜的那张图所在消息的 id（聊天记录里每条消息前的 #数字）。不填就用本会话最近一张图片。'
        },
        imageUrl: {
          type: 'string',
          description: '可选：直接用某个 http(s) 图片直链来搜（对方口头给了图链时用）。填了它就不用 messageId。'
        },
        count: {
          type: 'integer',
          description: '可选：要几张相似图。**对方在人话里说了数字就填它**（「来 5 张」「多找几张」→ 6）、'
            + '没说就不填（用设置里的默认值）。数量达到阈值（默认 3 张）时，工具会自己把图'
            + '传到机器人私聊再合并转发出去，你不用再逐张发。'
        }
      }
    },
    async execute(ctx, args) {
      const s = settings();
      const want = Math.max(1, Math.min(s.maxImages, Math.round(Number(args && args.count) || s.maxImages)));
      if (!s.allowGroup && ctx && String(ctx.kind) === 'group') {
        return { content: '以图搜图现在被设置成只在私聊可用（设置 → 技能 → 以图搜图 里可以改）。', isError: true };
      }

      try {
        // ① 定位图片
        const direct = String((args && args.imageUrl) || '').trim();
        let media = null;
        let sourceNote = '';
        if (direct) {
          if (!/^https?:\/\//i.test(direct)) return { content: 'imageUrl 必须是 http(s) 图片直链。', isError: true };
          media = { url: direct, file: '' };
          sourceNote = '使用你给的图片直链';
        } else {
          const found = locateImage(ctx, args && args.messageId);
          if (found.error) return { content: found.error, isError: true };
          media = found.media;
          const who = found.entry && !found.entry.self
            ? `${found.entry.senderName || found.entry.senderId || '对方'} 的消息`
            : '最近一条带图的消息';
          sourceNote = `取自${who}${found.entry && found.entry.mid != null ? `（#${found.entry.mid}）` : ''}`;
        }

        // ② 取字节
        const got = await imageBytes(ctx, media, s);
        if (got.error) {
          return {
            content: '拿不到这张图的字节，没法搜：' + got.error
              + '。QQ 图片直链几分钟就会失效，让对方**重新发一次**这张图，然后马上再搜一次。'
              + '（不要编造搜索结果。）',
            isError: true
          };
        }
        const qqUrl = String(got.url || media.url || '').trim();
        if (!/^https?:\/\//i.test(qqUrl)) {
          return { content: '这张图没有公网直链（只有本地文件），识图引擎读不到。让对方重新发一次图再搜。', isError: true };
        }

        const failures = [];
        const notes = [];

        // ②b 转存到图床，拿一个**不会几分钟就失效**的地址（用户提的思路，实测可行）。
        //     QQ 直链只活几分钟，而最后交给用户的链接里嵌的就是图片地址 ——
        //     用 QQ 直链的话，用户过一会儿再点那条链接就废了。
        const hosted = await hostImage(got.buffer, got.mime, s);
        const publicUrl = hosted || qqUrl;
        if (hosted) {
          notes.push(`图片已转存到图床（${hostOf(hosted)}）：${hosted} —— `
            + '下面那些链接里用的就是它，比 QQ 直链稳（QQ 那条几分钟就过期）。');
        }

        // ③ 逐家引擎
        let hit = null;
        for (const name of s.engines) {
          if (name === 'bing') continue;   // 必应不提供识图结果，只留链接
          try {
            let r = null;
            if (name === 'baidu-browser') {
              r = await baiduBrowserRun(publicUrl, s, { buffer: got.buffer, mime: got.mime });
            } else if (name === 'yandex') r = await yandexRun(publicUrl, s);
            else if (name === 'baidu') r = await baiduRun(publicUrl, s, { buffer: got.buffer, mime: got.mime });
            else if (name === 'google') r = await googleRun(publicUrl, s);
            else continue;
            const imgs = dedupe(r.parsed.images || []);
            const hasPages = (r.parsed.pages || []).length > 0;
            if (imgs.length || hasPages) { hit = r; break; }
            failures.push(`${ENGINE_LABEL[name]}：认了图但没解析出相似图/来源`);
            if (!hit) hit = r;
            break;
          } catch (e) {
            const msg = clipText((e && e.message) || e, 180);
            failures.push(`${ENGINE_LABEL[name]}：${msg}`);
            warn(`${name} 失败：${msg}`);
          }
        }

        const candidates = hit ? dedupe(hit.parsed.images || []) : [];
        // 另一条途径：把 Yandex **自己图床上缓存的来源站缩略图**也作为候选排在后面。
        // 来源站的原图可能已经失效（Pinterest 就是 AccessDenied），但 Yandex 缓存那份还活着，
        // 这样"图发不出来"时至少还能把"这图出现在哪些页面"的视觉证据发出去。
        const thumbs = hit ? dedupe(hit.parsed.thumbs || []) : [];
        const pages = hit ? (hit.parsed.pages || []) : [];
        if (s.proxy) notes.push(`走代理：${s.proxy}`);
        else notes.push('未走代理（Yandex 这条可能拿不到数据；检查「网络代理」插件是否开启）');

        // ④ 没有可用结果：给"能点开自己搜"的链接，绝不编造
        if (!hit || !candidates.length) {
          const links = [
            `Yandex 识图：${yandexUrlPage(publicUrl)}`,
            `Google Lens：${lensUrlPage(publicUrl)}`,
            `百度识图：${baiduUrlPage(publicUrl)}`
          ];
          const head = hit
            ? `「${hit.engine}」这次认了图，但没解析出可用内容。`
            : '这次没有一个识图源给出可用的识别结果。';
          const dbgFile = flushDebug('未成功');
          return {
            content: head
              + '把下面这些**能直接点开自己搜**的链接发出去（挑 1~2 条，别一口气全刷），'
              + '并如实说明"自动识图没成功，点开链接自己看一下"。不要编造搜到了什么。\n'
              + links.join('\n')
              + (failures.length ? `\n（这次各家的情况：${failures.join('；')}）` : '')
              + (dbgFile ? `\n（诊断日志：${dbgFile}）` : '')
          };
        }

        if (failures.length) notes.push(`其他源没成：${failures.join('；')}`);

        // ⑤ + ⑥ 直接进入"上传即验证"：
        //   ⚠️ 关键认知一（实测）：Yandex 给的图**不是"另一批长得像的图"**，而是
        //      "这张图本身在别的网站上的原图"（cbirSites[].originalImage）——
        //      同一张画在 10 个站上是 10 条，重复度极高。
        //   ⚠️ 关键认知二（两次踩坑）：**不能用"我自己能不能下载"来判断"能不能发"**。
        //      所以这里按"同图近似去重 → 逐张传到自聊 → 上传成功的才算数"来做；
        //      卡片只用真正上传成功的图拼。
        const deduped = await dedupeNearIdentical(candidates, s, Math.max(want + 2, s.forwardThreshold));
        const dupNote = candidates.length > deduped.length
          ? `去重：${candidates.length} 张候选里，另有 ${candidates.length - deduped.length} 张是同图的不同尺寸/重复，已去掉。`
          : '';
        if (dupNote) notes.push(dupNote);
        // 不同引擎给的图含义完全不同，必须说清（否则模型会把"同一张图的原图"说成"一堆相似图"）：
        notes.push(hit.engine.includes('百度')
          ? '上面这些是**百度给的相似图片**（放在百度自己的图床上，国内能正常发送），'
            + '不是"同一张图的不同来源"。另外「相关商品」如果有，就是识别出的同款商品（含价格与平台）。'
          : '上面这些图是**这张图本身在其他网站上的原图**（不同来源站/尺寸），'
            + '不是另一批「内容相似」的图。真正回答「出处」的是下面的来源网页列表。');

        const links = [`结果页（${hit.engine}）：${hit.pageUrl}`];
        for (const p of dedupe(pages.filter((x) => x.url), (x) => x.url).slice(0, 5)) {
          links.push(`- ${p.title ? p.title + ' — ' : ''}${p.url}`);
        }
        const caption = `以图搜图（${hit.engine}）· 这张图在 ${pages.length} 个来源页出现过\n${links.join('\n')}`;

        let forwardNote = '';
        let shown = [];
        let sentOk = false;
        try {
          // 先用"来源站原图"，不够再补"Yandex 缓存的缩略图"（后者几乎总能传到）。
          let r = await uploadAndForward(ctx, deduped, caption, want);
          if (r.uploaded.length < Math.max(want, s.forwardThreshold) && thumbs.length) {
            const more = await uploadAndForward(
              ctx,
              thumbs.filter((u) => !r.uploaded.includes(u)),
              caption,
              Math.max(want, s.forwardThreshold) - r.uploaded.length
            );
            r = {
              ok: r.uploaded.length + more.uploaded.length > 0,
              uploaded: [...r.uploaded, ...more.uploaded],
              failed: [...r.failed, ...more.failed],
              nodes: more.nodes || r.nodes,
              reason: more.reason || r.reason
            };
            if (more.uploaded.length) {
              notes.push(`来源站的原图大多拉不动，改用 **Yandex 图床缓存的那份缩略图**补上了 ${more.uploaded.length} 张`
                + '（图是同一张，只是尺寸小一点）—— 这就是「图发不出来」时的备用途径。');
            }
          }
          shown = r.uploaded;
          const failHosts = dedupe(r.failed.map((f) => hostOf(f.url)).filter(Boolean));
          if (r.ok && shown.length >= s.forwardThreshold) {
            sentOk = true;
            forwardNote = `已把 ${shown.length} 张用【合并转发】卡片发到当前会话（先在机器人私聊落了 ${shown.length} 张节点）`
              + '，来源页与结果页写在卡片最后一个节点里。'
              + '回一句很短的话就行（例：「图发你了，这个链接里有它的出处」），'
              + '**不要**再调 send_image。'
              + (r.failed.length
                ? `另有 ${r.failed.length} 张没传上去（${failHosts.join('、') || '未知图源'}），`
                  + '这些地址**别再试**。'
                : '');
          } else if (shown.length) {
            // 只传上去少数几张：不用卡片了，让模型发这几张（是**真的能发**的）
            forwardNote = `这次只成功传到自聊 ${shown.length} 张（其余${failHosts.length ? `来自 ${failHosts.join('、')} 等` : ''}拉不动，已丢弃），`
              + '就不发合并转发了：把下面这 ' + shown.length + ' 张用 send_image 逐张发出去，'
              + '并用 send_message 把结果页链接 + 来源页发给对方。'
              + '**只发这些已在「图片直链」里标为"已发到自聊"的地址**，别的不要试。';
          } else {
            forwardNote = '这次一张图都没能传到自聊（候选图床在境内拉不动）：'
              + '只把结果页链接 + 来源页发给对方，如实说明「图片直链这边拉不下来，点开链接自己看」，'
              + '**一张图都不要发**。';
          }
        } catch (e) {
          forwardNote = `合并转发/上传出错（${clipText((e && e.message) || e, 100)}）：`
            + '只把结果页链接 + 来源页发给对方，说明图片没发出去。';
        }
        const shownForRender = shown.slice(0, want);

        const summary = [
          '以图搜图完成，材料如下（你看不到这些图，不要凭想象描述画面）。',
          `取图方式：${got.via}；${sourceNote}；图片类型 ${got.mime || '未知'}，约 ${Math.round(got.buffer.length / 1024)}KB。`,
          renderLines({
            engine: hit.engine,
            pageUrl: hit.pageUrl,
            // ⚠️ 只列"真的已经发出去/真的能发"的地址 —— 不通过的一律不出现，
            //    免得模型拿着注定超时的地址去调 send_image。
            images: shownForRender,
            pages,
            digest: hit.parsed.text,
            notes,
            imagesLabel: sentOk
              ? `图片直链（${shownForRender.length} 条，**已经用上面的合并转发卡片发出，无需再发**）`
              : `图片直链（${shownForRender.length} 条，**已成功传到机器人自聊、可直接 send_image 发**）`
          })
        ].join('\n');

        const dbgFile = flushDebug(`成功（${hit.engine}）`);
        return {
          content: summary + '\n\n' + forwardNote
            + '\n（来源网页里有看着相关的可以说一句「可能是这个页面」，但**不要**编造图片的具体内容。）'
            + (dbgFile ? `\n（诊断日志：${dbgFile}）` : '')
        };
      } catch (error) {
        const msg = String((error && error.stack) || (error && error.message) || error);
        warn('以图搜图出错：' + msg);
        flushDebug('异常');
        return { content: '以图搜图出错：' + clipText((error && error.message) || error, 200), isError: true };
      }
    }
  });
}

/**
 * 从宿主的「网络代理」插件设置里解析出代理地址。三条路依次试：
 *   ① api.capability('network.proxy-config') —— 插件自己判断"启用/填完整"，
 *      但它只在本技能加载时"已生效"才给得到（插件比技能后加载，所以不能只靠它）；
 *   ② 直接读 config.json 里 skills['net-proxy']（最稳，本机 Clash 就是这么配的）；
 *   ③ 本机 7890 常见端口兜底（很多机器默认就在跑 Clash）。
 * 拿不到就返回空串 = 直连（此时 Yandex 那条会拿不到数据，但不会崩）。
 */
function resolveProxy(api) {
  // ① 能力优先
  try {
    const info = api?.capability?.('network.proxy-config', {});
    if (info && info.url) return normalizeProxy(info.url);
  } catch { /* 退 ② */ }
  // ② 读 config.json 里「网络代理」插件的设置（最稳，本机 Clash 就是这么配的）
  try {
    const file = path.join(APP_ROOT, '..', '..', '..', 'data', 'config.json');
    const raw = JSON.parse(fs.readFileSync(file, 'utf8'));
    const np = (raw && raw.skills && (raw.skills['net-proxy'] || raw.skills.netProxy)) || null;
    if (np && np.host && Number(np.port) > 0 && np.enabled !== false) {
      return normalizeProxy(`${np.protocol || 'http'}://${np.host}:${Number(np.port)}`);
    }
  } catch { /* 退 ③ */ }
  // ③ 兜底：本机 7890（Clash 默认混合端口）。连不上时隧道那步会失败，代价只是一次尝试
  const guess = normalizeProxy('http://127.0.0.1:7890');
  if (guess) dbg('resolveProxy: 没读到插件设置，退回猜 127.0.0.1:7890');
  return guess;
}

function normalizeProxy(url) {
  const s = String(url || '').trim();
  if (!s) return '';
  const withProto = /^[a-z]+:\/\//i.test(s) ? s : `http://${s}`;
  try {
    const u = new URL(withProto);
    if (!u.hostname || !u.port) return '';
    if (/socks/i.test(u.protocol)) return '';   // 本应用不支持 SOCKS，别把请求塞进去
    return `${u.protocol === 'https:' ? 'https' : 'http'}://${u.hostname}:${u.port}`;
  } catch { return ''; }
}

/* ─────────────────────────── 生命周期 ─────────────────────────── */

export function available() {
  return { ok: true };   // 必须同步返回
}

export function activate() {
  try {
    const s = settings();
    log('已启用：引擎 ' + s.engines.join(' → ')
      + '，最多 ' + s.maxImages + ' 张；到 ' + s.forwardThreshold + ' 张走"先自聊再合并转发"'
      + '；代理 ' + (s.proxy || '直连'));
  } catch (e) { /* 自检失败不影响启用 */ }
}

export function deactivate() {
  // 不持有定时器 / 监听器
}

export const dispose = deactivate;

/* ─────────────────── 自测用的内部函数 ─────────────────── */

export const internals = {
  settings,
  sniffImage,
  looksLikeHtml,
  textDigest,
  decodeEntities,
  unescapeJs,
  blockedReason,
  isRealImageUrl,
  imagesInEntry,
  locateImage,
  parseYandex,
  parseBaidu,
  parseLens,
  baiduUrlPage,
  bingUrlPage,
  lensUrlPage,
  yandexUrlPage,
  yandexRun,
  baiduRun,
  googleRun,
  baiduBrowserRun,
  findBrowser,
  cdpSession,
  waitCdp,
  httpGet,
  httpRequest,
  formUrlEncoded,
  proxyParts,
  connectViaProxy,
  resolveProxy,
  dedupe,
  chunk,
  dedupeNearIdentical,
  fetchImageForVerify,
  rankByHost,
  hostOf,
  coarseGram,
  gramDistance,
  uploadAndForward,
  renderLines,
  dbg,
  briefHtml,
  debugFile,
  flushDebug
};
