// 怪猎天尊（monster-hunter）—— 怪物猎人黑话 / 基础知识 / 梗
//
// ── 为什么是技能（skills/，LLM 型），不是插件（plugins/）────────────────────
// 文档 §0 的三问：
//   ① 触发时机能写成 if 吗？——不能。「这句『猫车』是在自嘲还是问东西」「这是怪猎
//      还是别的游戏」「该不该接梗」都必须读懂人话；
//   ② 漏一次代价？——只是没接上一个梗，下一句补回来就行，不丢数据；
//   ③ 参数从哪来？——一个词、一句话，得从自然语言里抠。
// 三问一致指向 LLM 型 → 放 skills/，用 registerTool 把决定权交给模型。
// （反过来，如果做成"命中关键词就自动回复"的插件，就是插件该干的活；这里不是。）
//
// ── 用户要的是「低浓度知识库」──────────────────────────────────────────────
// 人设浓度由 skill.json 的提示词片段控制：默认不主动甩梗，只在聊到怪猎时启用。
// 这个文件只负责"查得准"：术语/机制/历代作品/梗，全部按关键词检索返回原文。
//
// ── 数据从哪来 ────────────────────────────────────────────────────────────
// data/*.json 放在本技能目录内（自包含，删目录即卸载）。
// ⚠️ 用 fs 读而不是 `import './data/x.json'`：
//   加载器热重载只给 index.js 加时间戳（plugin-loader.js 的 `?t=`），静态 import
//   的子模块会一直命中旧缓存 —— forward-reader 的注释里踩过同一个坑。
//   用 fs 读每次 setup 都是最新的，改完 json 保存就生效。
//
// ⚠️ 路径锚点用 new URL('.', import.meta.url) 而不是直接 fileURLToPath(import.meta.url)：
//   index.js 是用 `index.js?t=时间戳` 导入的，import.meta.url 带 query。
//   `new URL('.', ...)` 解析后 query 会被丢掉，fileURLToPath 才不会因为
//   "URL 带 search" 抛错。也不能用 process.cwd()（见 plugin-loader.js 顶部注释）。

import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const SKILL_ID = 'monster-hunter';
const HERE = fileURLToPath(new URL('.', import.meta.url));
const DATA_DIR = path.join(HERE, 'data');

const DEFAULTS = { maxResults: 6, maxMemeChars: 240 };

let log = () => {};
let warn = () => {};
let cfgFn = () => ({});

let GLOSSARY = { categories: [], terms: [] };
let MEMES = { memes: [] };
let BASICS = { titles: [], mechanics: [], guides: [] };

function cfg() {
  try {
    const c = cfgFn ? cfgFn() : null;
    return { ...DEFAULTS, ...(c && typeof c === 'object' ? c : {}) };
  } catch {
    return { ...DEFAULTS };
  }
}

// ─────────────────────────────────────────── 小工具
function clean(s, max = 200) {
  return String(s ?? '').replace(/\s+/g, ' ').trim().slice(0, max);
}

/**
 * 归一化：去掉空白与标点，统一小写。
 * 目的：群里没人会把「肉质」打成「肉质 」或者加个句号，
 * 但模型传进来的参数经常带标点，不归一就会查不到。
 */
function norm(s) {
  return String(s ?? '')
    .toLowerCase()
    .replace(/[\s\u3000]+/g, '')
    .replace(/[，。、；：！？""''（）【】《》〈〉「」『』·~～\-_/\\|,+.;:!?()[\]{}<>"'`]/g, '');
}

/** 读 JSON，失败只告警不抛错：知识库缺一个文件不该让整个技能加载失败。 */
function readJson(file) {
  try {
    let text = fs.readFileSync(file, 'utf8');
    // Windows 编辑器常写 BOM，JSON.parse 会直接抛 "Unexpected token"
    if (text.charCodeAt(0) === 0xfeff) text = text.slice(1);
    return JSON.parse(text);
  } catch (error) {
    warn(`读取 ${path.basename(file)} 失败：${error?.message ?? error}`);
    return null;
  }
}

function asArray(v) {
  return Array.isArray(v) ? v : [];
}

// ─────────────────────────────────────────── 检索
/**
 * 给一个条目打分。参数顺序即优先级：
 *   完全命中词条 > 完全命中别名 > 词条包含 query > 别名包含 query >
 *   query 包含词条 > 描述包含 query > 分类命中
 * 分数差设计得足够大，让"精确"永远排在"沾边"前面。
 */
function scoreText(q, primary, aliases = [], desc = '') {
  const p = norm(primary);
  const al = asArray(aliases).map(norm).filter(Boolean);
  if (!q) return 0;
  if (p && p === q) return 100;
  if (al.includes(q)) return 96;
  if (p && p.includes(q)) return 88 - Math.min(18, p.length - q.length);
  if (al.some((a) => a.includes(q))) return 76;
  if (p && p.length >= 2 && q.includes(p)) return 70;
  if (al.some((a) => a.length >= 2 && q.includes(a))) return 64;
  if (desc) {
    const d = norm(desc);
    if (q.length >= 2 && d.includes(q)) return 30;
  }
  return 0;
}

/** 全库检索：术语 / 基础机制 / 历代作品 / 梗 一起查，统一排序。 */
function searchAll(query, { limit = 6 } = {}) {
  const q = norm(query);
  if (!q) return [];
  const hits = [];

  for (const e of asArray(GLOSSARY.terms)) {
    const s = scoreText(q, e.term, e.aliases, e.desc);
    if (s > 0) hits.push({ s, kind: 'term', e });
  }
  for (const e of asArray(BASICS.mechanics)) {
    const s = scoreText(q, e.name, e.aliases, e.desc);
    if (s > 0) hits.push({ s, kind: 'mechanic', e });
  }
  for (const e of asArray(BASICS.titles)) {
    const s = scoreText(q, e.name, [...asArray(e.aliases), e.en], e.note);
    if (s > 0) hits.push({ s, kind: 'title', e });
  }
  for (const e of asArray(BASICS.guides)) {
    const s = scoreText(q, e.title, [], e.desc);
    if (s > 0) hits.push({ s, kind: 'guide', e });
  }
  for (const e of asArray(MEMES.memes)) {
    const s = scoreText(q, e.title, asArray(e.tags), `${e.text} ${e.use}`);
    if (s > 0) hits.push({ s, kind: 'meme', e });
  }

  // 同分时：术语 > 机制 > 作品 > 攻略 > 梗（解释优先于玩梗）
  const rank = { term: 0, mechanic: 1, title: 2, guide: 3, meme: 4 };
  hits.sort((a, b) => (b.s - a.s) || (rank[a.kind] - rank[b.kind]));
  return hits.slice(0, Math.max(1, Math.min(12, limit)));
}

function fmtHit(hit, i) {
  const e = hit.e;
  if (hit.kind === 'term') {
    const alt = asArray(e.aliases).length ? `（也叫：${asArray(e.aliases).join('、')}）` : '';
    const usage = e.usage ? `\n   例：${clean(e.usage, 80)}` : '';
    return `${i}. 【${e.term}】${e.category || ''}${alt}\n   ${clean(e.desc, 220)}${usage}`;
  }
  if (hit.kind === 'mechanic') {
    const tip = e.tip ? `\n   要点：${clean(e.tip, 120)}` : '';
    return `${i}. 【${e.name}】基础机制\n   ${clean(e.desc, 220)}${tip}`;
  }
  if (hit.kind === 'title') {
    return `${i}. 《${e.name}》${e.en || ''}｜${e.year || '?'}年｜${e.platform || ''}\n   ${clean(e.note, 220)}`;
  }
  if (hit.kind === 'guide') {
    return `${i}. 【${e.title}】攻略\n   ${clean(e.desc, 260)}`;
  }
  const maxChars = Number(cfg().maxMemeChars) || DEFAULTS.maxMemeChars;
  return `${i}. 梗「${e.title}」\n   ${clean(e.text, maxChars)}${e.use ? `\n   用法：${clean(e.use, 80)}` : ''}`;
}

/** 没给 query 时返回知识库目录：让模型知道"这库里有什么"，而不是瞎猜。 */
function catalogText() {
  const terms = asArray(GLOSSARY.terms);
  const cats = asArray(GLOSSARY.categories).length
    ? asArray(GLOSSARY.categories)
    : [...new Set(terms.map((t) => t.category).filter(Boolean))];
  const counts = cats.map((c) => `${c} ${terms.filter((t) => t.category === c).length}`).join('、');
  const sample = terms.slice(0, 12).map((t) => t.term).join('、');
  return [
    `怪猎知识库（共 ${terms.length} 条黑话/术语、${asArray(BASICS.mechanics).length} 条基础机制、${asArray(BASICS.guides).length} 条攻略、${asArray(BASICS.titles).length} 部作品、${asArray(MEMES.memes).length} 条梗）`,
    `分类：${counts || '（空）'}`,
    `示例词条：${sample || '（空）'}`,
    '用法：把要查的词/句传进来（如「猫车」「肉质」「水龙胯撞」「荒野」「登龙」）；查某部作品也可以用 series 工具。'
  ].join('\n');
}

// ─────────────────────────────────────────── 生命周期
/**
 * 读数据。放在 setup 里而不是模块顶层：
 * 顶层抛错会让整个 import 失败、技能显示"加载失败"；
 * 放 setup 里还能在热重载时重新读盘。
 */
function loadData() {
  const g = readJson(path.join(DATA_DIR, 'glossary.json'));
  const m = readJson(path.join(DATA_DIR, 'memes.json'));
  const b = readJson(path.join(DATA_DIR, 'basics.json'));
  GLOSSARY = g && Array.isArray(g.terms) ? { categories: asArray(g.categories), terms: g.terms } : { categories: [], terms: [] };
  MEMES = m && Array.isArray(m.memes) ? { memes: m.memes } : { memes: [] };
  BASICS = {
    titles: asArray(b?.titles),
    mechanics: asArray(b?.mechanics),
    guides: asArray(b?.guides)
  };
  return {
    terms: GLOSSARY.terms.length,
    mechanics: BASICS.mechanics.length,
    guides: BASICS.guides.length,
    titles: BASICS.titles.length,
    memes: MEMES.memes.length
  };
}

export async function setup(api) {
  cfgFn = api.config || (() => ({}));
  log = api.log || (() => {});
  warn = api.warn || (() => {});

  const stats = loadData();
  log(`怪猎知识库已载入：黑话 ${stats.terms} / 机制 ${stats.mechanics} / 攻略 ${stats.guides} / 作品 ${stats.titles} / 梗 ${stats.memes}`);

  // ── 工具 1：查黑话/术语/机制/作品/梗 ──────────────────────────────────
  api.registerTool({
    id: 'lookup',
    name: '怪猎黑话查询',
    description: '查怪物猎人的黑话、术语、基础机制、历代作品和梗。query 传一个词或一句话（「猫车」「肉质」「水龙胯撞」「世界」「见切」「HR」「大剑」）。群里出现听不懂的怪猎黑话、有人问怪猎名词/机制/某作是哪年出的、想确认某个梗的来历，都先查它；不传 query 返回知识库目录。查不到时再用你自己的知识回答，并说明不确定。',
    category: 'knowledge',
    icon: '🏹',
    parameters: {
      type: 'object',
      properties: {
        query: { type: 'string', description: '要查的词或一句话，例如「猫车」「肉质」「水龙胯撞」「荒野」「见切」。省略则返回知识库目录。' },
        limit: { type: 'integer', description: '最多返回几条，1~12，默认用设置里的值（6）。' }
      }
    },
    async execute(_ctx, args) {
      try {
        const q = clean(args?.query, 60);
        const limit = Number(args?.limit);
        const n = Number.isFinite(limit) ? Math.max(1, Math.min(12, Math.trunc(limit))) : Number(cfg().maxResults) || DEFAULTS.maxResults;
        if (!q) return { content: catalogText() };

        const hits = searchAll(q, { limit: n });
        if (!hits.length) {
          return {
            content: [
              `知识库里没有「${q}」这一条。`,
              '可以：① 换个更短的词（如「猫车」而不是「我昨天又猫车了」）；② 不传 query 看目录；',
              '③ 直接用你自己的怪猎知识回答，但不要编造怪物名/技能名/年份，也不确定的官方译名就说「以游戏内为准」。'
            ].join('\n')
          };
        }
        const lines = [`查到 ${hits.length} 条（query：${q}）：`];
        hits.forEach((h, i) => lines.push(fmtHit(h, i + 1)));
        return { content: lines.join('\n') };
      } catch (error) {
        return { content: `查询失败：${error?.message ?? error}`, isError: true };
      }
    }
  });

  // ── 工具 2：随机梗 ────────────────────────────────────────────────────
  api.registerTool({
    id: 'meme',
    name: '来条怪猎梗',
    description: '随机给一条怪物猎人的梗/经典吐槽，可以直接拿去群里用。topic 可按关键词过滤（「猫车」「太刀」「老作品」「大剑」）。有人让机器人来点怪猎的梗、想活跃气氛、或你想接一句怪猎相关的话时用它。返回的是素材，发不发、怎么改得看语境。',
    category: 'knowledge',
    icon: '😹',
    parameters: {
      type: 'object',
      properties: {
        topic: { type: 'string', description: '关键词过滤，例如「猫车」「太刀」「队友」「老作品」。省略则从全部梗里随机。' }
      }
    },
    async execute(_ctx, args) {
      try {
        const topic = clean(args?.topic, 20);
        const all = asArray(MEMES.memes);
        if (!all.length) return { content: '梗库是空的（data/memes.json 没读到）。', isError: true };
        const q = norm(topic);
        const pool = q
          ? all.filter((m) => scoreText(q, m.title, asArray(m.tags), `${m.text} ${m.use}`) > 0)
          : all;
        const pick = pool.length ? pool[Math.floor(Math.random() * pool.length)] : null;
        if (!pick) {
          return { content: `没有和「${topic}」相关的梗。可用的主题比如：${all.slice(0, 8).map((m) => m.title).join('、')}。` };
        }
        const maxChars = Number(cfg().maxMemeChars) || DEFAULTS.maxMemeChars;
        return {
          content: [
            `「${pick.title}」`,
            clean(pick.text, maxChars),
            pick.use ? `（适合：${clean(pick.use, 80)}｜可用主题：${asArray(pick.tags).join('、')}）` : ''
          ].filter(Boolean).join('\n')
        };
      } catch (error) {
        return { content: `取梗失败：${error?.message ?? error}`, isError: true };
      }
    }
  });

  // ── 工具 3：历代作品 ──────────────────────────────────────────────────
  api.registerTool({
    id: 'series',
    name: '怪猎历代作品',
    description: '查怪物猎人历代作品年表。不传参数返回全部正传/外传的年份与平台；传 game 返回某一作的别名、平台和特点。有人问「怪猎有哪些作品」「世界是哪年出的」「XX 和 P3 是什么」「物语是什么」时用它。',
    category: 'knowledge',
    icon: '📅',
    parameters: {
      type: 'object',
      properties: {
        game: { type: 'string', description: '作品名或别名，例如「世界」「冰原」「崛起」「P2G」「Wilds」。省略则返回年表。' }
      }
    },
    async execute(_ctx, args) {
      try {
        const titles = asArray(BASICS.titles);
        if (!titles.length) return { content: '作品表没读到（data/basics.json）。', isError: true };
        const q = norm(args?.game);
        if (!q) {
          const sorted = [...titles].sort((a, b) => (Number(a.year) || 0) - (Number(b.year) || 0));
          return {
            content: [
              `怪物猎人历代作品（${sorted.length} 部，按年份）：`,
              ...sorted.map((t) => `${t.year || '?'}  《${t.name}》${t.platform ? `（${t.platform}）` : ''}`),
              '',
              '要某一作的详情就传 game（如「冰原」「XX」「物语」）。'
            ].join('\n')
          };
        }
        const hits = titles
          .map((t) => ({ t, s: scoreText(q, t.name, [...asArray(t.aliases), t.en], t.note) }))
          .filter((x) => x.s > 0)
          .sort((a, b) => b.s - a.s)
          .slice(0, 4);
        if (!hits.length) {
          return { content: `没找到和「${args?.game}」对应的作品。不传 game 可以看完整年表。` };
        }
        return {
          content: hits.map(({ t }) => [
            `《${t.name}》${t.en || ''}`,
            `发售：${t.year || '?'} 年｜平台：${t.platform || '未记'}`,
            t.aliases?.length ? `别名：${asArray(t.aliases).join('、')}` : '',
            `特点：${clean(t.note, 220)}`
          ].filter(Boolean).join('\n')).join('\n\n')
        };
      } catch (error) {
        return { content: `查作品失败：${error?.message ?? error}`, isError: true };
      }
    }
  });
}

// 热重载：模块被重新 import 时旧实例的定时器/监听在这里清（本技能没有，留空便于以后扩展）
export function deactivate() {}

