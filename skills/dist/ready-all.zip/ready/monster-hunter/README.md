# 怪猎天尊（monster-hunter）

给 QQ Agent 加的一套怪物猎人知识：黑话、基础机制、历代作品、梗。
默认**只当知识库**——聊到怪猎才用，平时不主动甩梗、不掉书袋。

## 为什么是技能（skills/）而不是插件（plugins/）

按 `doc/extend_development/` 的两型定义，判据是「规则能写死 → 插件；要理解人话 → 技能」：

| 三问 | 本功能 |
|---|---|
| 触发时机能写成 if 吗？ | 不能。「这句『猫车』是在自嘲还是在问东西」「这是怪猎还是别的游戏」都要读懂人话 |
| 漏一次代价多大？ | 只是没接上一个梗，下一句补回来就行 |
| 参数从哪来？ | 一个词、一句话，得从自然语言里抠 |

三问一致 → LLM 型 → `skills/`，用 `registerTool` 把「用不用、什么时候用」交给模型。

## 文件

```
skills/monster-hunter/
  skill.json          清单：id/分类/开关/设置项/提示词片段（人设浓度在这里）
  index.js            入口：setup(api) 里注册 3 个工具，读 data/*.json
  data/glossary.json  黑话与术语（105 条）
  data/basics.json    历代作品 23 部 + 基础机制 18 条 + 攻略 4 条
  data/memes.json     梗 35 条
  README.md           本文件
```

## 三个工具（模型侧看到的名字带前缀）

| 工具 | 用途 |
|---|---|
| `monster-hunter__lookup` | 查黑话/术语/机制/作品/梗/攻略；不传 query 返回知识库目录 |
| `monster-hunter__meme` | 随机一条梗，可按 topic 过滤（如「太刀」「猫车」） |
| `monster-hunter__series` | 历代作品年表；传 game 查某一作详情 |

## 想加词条 / 改内容

直接改 `data/*.json`，保存即热重载（加载器用 `fs` 读盘，不吃 import 缓存）。

词条格式：

```json
{
  "term": "猫车",
  "aliases": ["猫了", "三猫"],
  "category": "玩家黑话",
  "desc": "力尽后随从猫用担架把你推回营地。",
  "usage": "「先猫为敬」"
}
```

`category` 用 `data/glossary.json` 里 `categories` 已有的值，否则目录页的分类计数会多出一项。

## 注意（踩过的坑）

- **清单必须是 UTF-8，别存成 GBK**：加载器读 `utf8`，GBK 会解析失败并显示「清单解析失败」。
  带 BOM 能救（加载器会剥掉），但不带更干净。
- **工具 id 只能用 `[a-zA-Z0-9_-]`**：会拼成 OpenAI 的 function name，用 `:`/`.` 会被严格端点 400 拒掉整个请求。
- **数据文件用 `fs` 读，不要 `import './data/x.json'`**：热重载只给 index.js 加时间戳，静态 import 的子模块会命中旧缓存（forward-reader 的注释里记过这个坑）。
- 没注册任何工具的技能放进 `skills/` 会静默失效（模型根本看不到），加载器启动时会警告。

## 排障

| 现象 | 原因 |
|---|---|
| 技能页显示「加载失败：清单解析失败」 | skill.json 编码/JSON 语法错（少逗号、多了尾逗号） |
| 技能页显示「加载失败：入口文件不存在」 | 缺 index.js，或 `entry` 写错 |
| 显示「注册失败：工具必须提供 id/name/execute」 | index.js 里 registerTool 少字段 |
| 技能在、但模型从不调用 | 工具 `category` 被关了（设置 → 工具与技能 → 知识库），或 `config.skills.monster-hunter.enabled` 为 false |
| 查词返回「知识库里没有」 | 那个词确实没收录；或 json 没读到（看日志里 `怪猎知识库已载入` 的数字是不是 0） |
