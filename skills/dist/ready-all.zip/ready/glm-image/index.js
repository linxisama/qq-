import { Buffer } from 'node:buffer';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

// 智谱 GLM-Image 图像生成技能
// 两种用途：
//   purpose=chat  生成后直接发到当前 QQ 聊天（默认）
//   purpose=qzone 生成后落盘，返回一个 #gen:<文件名> 引用，供 qqzone__post_mood 附加到说说

const BASE_URL = 'https://open.bigmodel.cn/api/paas/v4';
const HERE = path.dirname(fileURLToPath(import.meta.url)); // …/skills/glm-image

let cfg = () => ({});

function dataDir() {
  const env = String(process.env.QQ_AGENT_DATA_DIR || '').trim();
  if (env) return env;
  return path.resolve(HERE, '..', '..', 'data'); // 标准布局 <repo>/data
}

function genDir() {
  return path.join(dataDir(), 'glm-image', 'generated');
}

function extOf(mime) {
  const m = String(mime || '').toLowerCase();
  if (m.includes('jpeg') || m.includes('jpg')) return 'jpg';
  if (m.includes('webp')) return 'webp';
  if (m.includes('gif')) return 'gif';
  return 'png';
}

export function setup(api) {
  cfg = api.config;

  api.registerTool({
    id: 'generate_image',
    name: '生成图片',
    description:
      '用智谱 GLM-Image 模型按文字提示词生成一张图片。' +
      '当用户要求「画图 / 生成图片 / 来张图 / 画一张 XX」时使用。' +
      '如果要发 QQ 空间说说并配图，用 purpose=qzone：生成后返回一个 #gen: 引用，把该引用放进 qqzone__post_mood 的 images 数组里即可附加到说说。' +
      '生成需要几秒，属正常，不要催促。',
    category: 'media',
    icon: '🎨',
    parameters: {
      type: 'object',
      properties: {
        prompt: {
          type: 'string',
          description: '图片的文字描述（提示词）。越具体越好：画面主体、风格、氛围、细节。可中可英。'
        },
        size: {
          type: 'string',
          description: '可选，图片尺寸，如 1280x1280、1024x1024、1568x1056。不填用默认值。'
        },
        purpose: {
          type: 'string',
          description: '用途：chat=生成后直接发到聊天（默认）；qzone=生成后落盘、只返回 #gen: 引用（用于发空间说说配图）。',
          enum: ['chat', 'qzone']
        }
      },
      required: ['prompt']
    },
    async execute(ctx, args) {
      const apiKey = String(cfg().apiKey || '').trim();
      if (!apiKey) {
        return {
          content: '智谱 API Key 还没填。请在 QQ Agent 控制台「技能 → 智谱画图」设置里填上 bigmodel.cn 的 API Key。',
          isError: true
        };
      }

      const purpose = String(args?.purpose || 'chat').trim().toLowerCase() === 'qzone' ? 'qzone' : 'chat';
      if (ctx.kind === 'group' && cfg().allowInGroup === false) {
        return { content: '当前技能只在私聊可用（群聊已关闭）。', isError: true };
      }

      const model = String(cfg().model || 'glm-image').trim();
      const size = String(args?.size || cfg().size || '1280x1280').trim();
      const prompt = String(args?.prompt || '').trim();

      if (!prompt) {
        return { content: '提示词不能为空。', isError: true };
      }
      if (prompt.length > 1000) {
        return { content: '提示词太长（最多 1000 字），请精简后再试。', isError: true };
      }

      try {
        // 1) 调智谱图像生成接口
        const genRes = await fetch(`${BASE_URL}/images/generations`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${apiKey}`
          },
          body: JSON.stringify({
            model,
            prompt,
            size,
            quality: model === 'glm-image' ? 'hd' : 'standard',
            watermark_enabled: cfg().watermark !== false
          })
        });

        if (!genRes.ok) {
          const errText = await genRes.text().catch(() => '');
          return { content: `画图接口返回 HTTP ${genRes.status}：${errText.slice(0, 400)}`, isError: true };
        }

        const genJson = await genRes.json();
        const url = genJson?.data?.[0]?.url;
        if (!url) {
          return { content: '画图接口没返回图片 URL，可能被内容审核拦下了，换个提示词再试。', isError: true };
        }

        // 2) 下载临时图片（官方说明：临时链接需立即下载）
        const imgRes = await fetch(url);
        if (!imgRes.ok) {
          return { content: `下载图片失败：HTTP ${imgRes.status}。`, isError: true };
        }
        const buf = Buffer.from(await imgRes.arrayBuffer());
        const mime = imgRes.headers.get('content-type') || 'image/png';
        const dataUrl = `data:${mime};base64,${buf.toString('base64')}`;

        // 3) 落盘，生成一个稳定的短引用（供 qqzone 附加到说说）
        const filename = `${Date.now()}.${extOf(mime)}`;
        const dir = genDir();
        try {
          fs.mkdirSync(dir, { recursive: true });
          fs.writeFileSync(path.join(dir, filename), buf);
        } catch (saveErr) {
          // 落盘失败不致命：qzone 用途才必须成功，chat 用途继续发图
          if (purpose === 'qzone') {
            return { content: `图片生成后落盘失败：${saveErr?.message ?? saveErr}`, isError: true };
          }
        }
        const genRef = `#gen:${filename}`;

        // 4) qzone 用途：不往聊天发，只返回引用
        if (purpose === 'qzone') {
          return { content: `图片已生成并落盘。引用标识：${genRef}。把它放进 qqzone__post_mood 的 images 数组即可附加到说说。` };
        }

        // 5) chat 用途：发到当前聊天
        try {
          await ctx.sender.sendImage(ctx.chatKey, { dataUrl }, { note: `智谱画图：${prompt.slice(0, 30)}` });
        } catch (sendErr) {
          return { content: `图片已生成但发送失败：${sendErr?.message ?? sendErr}`, isError: true };
        }

        return { content: `已按提示词生成图片并发送到当前聊天。` };
      } catch (e) {
        return { content: `画图失败：${e?.message ?? e}`, isError: true };
      }
    }
  });
}

export function available() {
  const key = String(cfg().apiKey || '').trim();
  if (!key) return { ok: false, reason: '还没填智谱 API Key' };
  return { ok: true };
}
