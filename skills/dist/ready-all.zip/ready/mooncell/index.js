import path from 'node:path';
import {DATA_DIR} from '../../src/config.js';
import {MooncellClient} from './mooncell.js?v=mooncell-1.0.0';
let client;
const string=(description)=>({type:'string',description});
const refresh={type:'boolean',description:'需要最新数据时true，忽略正常缓存；失败时会明确标出旧缓存。'};
const pagination={offset:{type:'integer',description:'接着读取时填返回的nextOffset，初次0。'},limit:{type:'integer',description:'返回数量/字符上限。'}};
export function setup(api) {
  client=new MooncellClient({cacheDir:path.join(DATA_DIR,'mooncell-cache'),settings:()=>api.config?.()||{},fetchImpl:api.fetch});
  const register=(id,name,description,parameters,method)=>api.registerTool({id,name,description,category:'query',parameters,
    async execute(ctx,args){try{return {content:JSON.stringify(await client[method](args||{}))};}catch(e){return {isError:true,content:JSON.stringify({ok:false,error:String(e.message||e),source:'Mooncell',note:'读取失败，不能冒称已查到或编造结果。'})};}}});
  register('search_mooncell','搜索Mooncell','按从者名字、编号、站内别名检索Mooncell，返回具体页面和候选版本；scope=wiki搜索全站主命名空间，适合活动、礼装、素材等。',
    {type:'object',properties:{query:string('名字/编号/别名或站内关键词'),scope:{type:'string',enum:['auto','servants','wiki'],description:'默认auto：先匹配图鉴，再搜全站；servants仅英灵图鉴。'},limit:{type:'integer',description:'1～12，默认8。'},refresh},required:['query']},'search');
  register('filter_servants','筛选英灵图鉴','筛选Mooncell英灵图鉴，可按职阶、星级、宝具色卡、单体/全体/辅助和获取途径分页列出从者。',
    {type:'object',properties:{class:string('Saber/Archer/Lancer/Rider/Caster/Assassin/Berserker/Ruler/Avenger等，或剑/弓/枪/骑/术/杀/狂。'),rarity:{type:'integer',minimum:0,maximum:5},npCard:{type:'string',enum:['Quick','Arts','Buster','绿卡','蓝卡','红卡']},npType:{type:'string',enum:['单体','全体','辅助']},obtain:string('获取途径关键词，如期间限定、活动赠送、常驻。'),...pagination,refresh}},'filter');
  register('read_mooncell','读取Mooncell资料','读取Mooncell具体页面/从者，支持编号或别名；section选宝具、技能、素材需求、资料等，返回可用目录、正文、来源和更新时间。同名返回候选；正文截断时使用nextOffset继续读。',
    {type:'object',properties:{title:string('搜索结果的title、从者编号/别名，或https://fgo.wiki/w/页面链接。'),section:string('目录里的章节名或index。留空从者读基础数值，其他页面读全文。'),exactTitle:{type:'boolean',description:'title已经是确定的Mooncell页面名时true，跳过图鉴别名匹配。'},...pagination,refresh},required:['title']},'read');
}
export function available(){return {ok:true};}
