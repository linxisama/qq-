// EVE 市场查询技能（LLM 型）。
//
// 群友问「jita 阿贝拉」这类问题时，输出报价卡片：
//
//   阿贝拉 SW-900-I
//   -出售：45,000,000.00 ISK(1)
//   -收购：22,390,000.00 ISK(15)
//   -中间：33,695,000.00 ISK
//   ----------------
//   服务器：晨曦
//
// ⚠️ 卡片正文里**没有 @**（上面这个示例就是完整形态）。@ 由发送层以协议级
// at 段加在消息开头，指向**提问的人** —— 早期版本曾把地点当 @ 对象写进正文，
// 那是错的（既提醒不到人，又看着像在叫某个群友），早改掉了。
//
// 四个工具（注册 id 会被宿主加上技能前缀，模型看到的是 eve-market__xxx）：
//   eve-market__market_quote   主入口：物品名 → 出售/收购/中间价
//   eve-market__market_book    看盘口明细（前 5 档买卖单 + 空间站）
//   eve-market__market_search  名字对不上时先搜物品 ID
//   eve-market__market_chart   近一年走势图（最高/最低价 + 真实成交量）
//
// ───────────────── 数据源：官方 ESI ─────────────────
//
// 晨曦走**网易官方 ESI**（ali-esi.evepc.163.com），欧服走 CCP 官方 ESI。
// 之前用的是第三方镜像 ceve-market.org，换成官方之后拿到两个实质改进：
//
//   1) **真正的逐日历史**（402 天）。ceve 只保留约 80 天的聚合值，而且价格序列
//      不管怎么切片都只有 5~6 个不同值 —— 所以当时"近一年走势图"是画不出来的，
//      只能靠差分反推、曲线是锯齿。现在高/低/均价/成交量/成交笔数都是逐日原值。
//   2) **成交量是真实成交量**（股数）。ceve 的 volume 是订单簿**挂单深度**，
//      口径完全不同，当时只能在图里标"挂单量"。
//
// 代价：官方 ESI **没有开放按名字搜索**（`/search/` 返回 404），所以中文品名
// 靠本地索引解决（见 lib-v5/names.js）—— 首次约 35 秒建好、缓存 24 小时，
// 技能启动时会后台预热，不占用群友的等待时间。
//
// 设计取舍：
//   · 报价**默认由工具直接发出**（autoSend）。报价是一段格式固定的播报，
//     让模型转述只会引入幻觉（数字抄错一位、少个千分位），所以文本由代码生成、
//     由代码发出；模型只负责判断"该不该报"和挑对物品名。
//   · 图与文**分开发**：走势图只在群友明确要看趋势时才画（约 2~3 秒渲染），
//     报价不走画图路径。

/**
 * 用一个**稳定的**查询串导入库文件，让"改了库内容"能真正生效。
 *
 * 为什么需要这一层：Node 的 ESM 按 **URL** 缓存模块，而技能重载只是给
 * **入口**加时间戳重新 import（loader 里是 `import(`${entryUrl}?t=${Date.now()}`)`）。
 * 入口里静态 `import './lib-vX/xxx.js'` 的 URL 永远不会变 —— 于是改了库内容、
 * 只点「刷新」，拿到的还是进程里那份老模块，报
 *   `does not provide an export named ...`
 * （这个坑在本项目里踩过四次，前三次靠把目录名从 lib → lib-v2 → v3 → v4 硬扛）。
 *
 * 这里的做法：查询串用**文件自己的 mtime**。内容没变 → URL 不变 → 照常命中缓存；
 * 内容一变 → mtime 变 → URL 变 → 自动加载新版。不用再手工升目录名。
 *
 * 拿不到 mtime 时（权限、沙箱）回退成普通静态导入：行为退化回"需要手工升版本"，
 * 但不会让技能加载失败。
 */
// node:fs / node:url 的导入放在 try 外面：不只为 loadLib 用，readSkillVersion()
// 也要读 skill.json。放在 try 里会让后者拿不到（之前就是这样，踩空了）。
const { statSync, readFileSync } = await import('node:fs');
const { fileURLToPath } = await import('node:url');
const { dirname, join } = await import('node:path');

/**
 * 库版本查询串 —— 由 `lib-v5/lib-version.js` 计算，这里只是转发。
 *
 * ⚠️⚠️ 这里有两个**必须同时成立**的条件，缺一个就会"改了没生效"：
 *
 * **① 库内互相导入必须带版本串**（见 `lib-v5/lib-version.js` 顶部说明）。
 * 否则父模块被缓存时会拖出旧的子模块。
 *
 * **② `lib-version.js` 自己必须每次都重新求值** —— 这一条是最隐蔽的：
 * 它原来是 `await import(new URL('./lib-v5/lib-version.js', import.meta.url).href)`，
 * **裸 URL、无查询串**。于是它被缓存一次之后，`QS` 这个常量就**永久冻结**在
 * 首次加载时的值；此后每次「刷新」，`loadLib()` 都拿着这个旧串去导入，
 * 拿到的永远是旧的 `chart.js` / `render.js`。
 *
 * 症状极具迷惑性：`index.js` 因为宿主给它加了 `?t=`，**每次都是新的**
 * （所以新注册的工具会出现、版本号会更新），而库**始终是旧的**
 * （所以画出来的图还是老样子）。表现为"日志显示加载了新版本，图上却没变化"。
 *
 * 修法：把**入口自己的查询串**（宿主每次给的 `?t=Date.now()`）传给
 * `lib-version.js`，让它跟着入口一起失效。
 *
 * 这个 bug 是同一进程内连按两次刷新才复现的；用两个独立进程测**测不出来**
 * （我第一版复现就是那么写的，结论无效，白绕了一轮）。
 * 回归测试见 `test/lib-version-test.mjs` 的"同进程二次刷新"那组。
 */
const ENTRY_QS = new URL(import.meta.url).search;      // 宿主给入口的 ?t=…
const libVersionUrl = new URL('./lib-v5/lib-version.js', import.meta.url);
libVersionUrl.search = ENTRY_QS;                        // ← 关键：继承入口的失效标记
const { QS: LIB_QS } = await import(libVersionUrl.href);

let loadLib;
try {
  loadLib = async (relative) => {
    if (!LIB_QS) return import(relative);        // 取不到 mtime 就退回静态导入
    const url = new URL(relative, import.meta.url);
    return import(`${url.href}${LIB_QS}`);
  };
} catch {
  loadLib = async (relative) => import(relative);
}

const esi = await loadLib('./lib-v5/esi.js');
const triggers = await loadLib('./lib-v5/triggers.js');
const names = await loadLib('./lib-v5/names.js');
const chart = await loadLib('./lib-v5/chart.js');

// 把渲染自检接到宿主日志。
//
// 起因：出现过"文件落盘了、宿主加载日志也显示新版本，但画出来的图仍是旧格式"的情况，
// 只能靠文件 mtime / 加载记录**间接推断**，排查方向全靠猜。
// 接上之后，app 的日志页里每次画图都会留下一行：
//     [chart] 1680x1000 238104B 日期样式="2025-10" 标签数=365 参考线=4 裁剪=已裁 2 个离群点
// 一眼就能判断**运行中真实生效的代码**是哪一版。


const {
  SERVERS, DEFAULT_SERVER, resolveServer, serverAliases,
  HUBS, LOCTABLE, resolveHub,
  marketHistory, regionOrders, typeInfo, referencePrice
} = esi;
const { buildPrefixes, matchPrefix, describePrefixes, FALLBACK_HUB } = triggers;
const { ensureIndex, searchByName, indexStatus } = names;
const { generateChart } = chart;

/** 千分位 + 两位小数。报价卡片里的所有金额都走它。 */
function formatIsk(value) {
  const n = Number(value);
  if (!Number.isFinite(n)) return '—';
  return n.toLocaleString('zh-CN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

/**
 * 读自己的版本号（来自 skill.json），只用于启动日志。
 *
 * **刻意不在代码里写第二遍**：版本号有唯一来源（清单），代码里再写一个常量
 * 迟早和清单对不上 —— 那时候日志会显示一个错的版本，比不显示更糟。
 * 读不到就返回 '?'，绝不让它影响加载。
 */
function readSkillVersion() {
  try {
    const here = dirname(fileURLToPath(import.meta.url));
    const raw = readFileSync(join(here, 'skill.json'), 'utf8');
    return String(JSON.parse(raw).version ?? '?');
  } catch {
    return '?';
  }
}

/**
 * 中文服务器名 → 服务器 key。
 * 批次里存的是 `server.label`（「晨曦」），但画图要基址，得反查出 key。
 * 由 SERVERS 生成，避免手写第二份映射将来漂移。
 */
const SERVER_KEY_OF = Object.fromEntries(
  Object.values(SERVERS).map((s) => [s.label, s.key])
);

/** 走势图看多少天。（曾做成设置项，精简掉了：一年是唯一有意义的口径。） */
const CHART_DAYS = 365;
function chartDays() { return CHART_DAYS; }

/** 地点 key → hub 对象（认不出就按默认 hub，不抛错）。 */
function resolveLocation(input) {
  return resolveHub(input);
}

let api = null;
let cfg = () => ({});
let fetcher = null;

/**
 * 合并窗口。
 *
 * 线上真实案例（这次改动的由来）：群友问「月矿呢」，模型一件一件地问，最后群里
 * 刷了 **18 条**卡片（跨 11 轮）；问「7种基础矿」刷了 7 条。核心是一轮里
 * `for (const call of toolCalls) await executeTool(...)` 串行调用本工具，
 * 每次调用各发一条 —— 所以必须在插件内部把同一批查询攒成一条。
 *
 * 关键事实：模型**不是**一次把 7 个调用丢过来，而是拆成多轮（每轮一次工具调用，
 * 轮与轮之间隔着一次模型请求）。所以窗口必须**跨轮**才有意义 —— 用 400ms 那种
 * 短窗口等于没合并。实测把 IDLE 设成 2.2s 时，7 件仍然发了 7 条。
 *
 * 两条规则（不是"固定时长"，而是"看起来还没问完就继续等"）：
 *   · IDLE（5s）：最后一次查询之后再静默这么久就发。模型两轮之间通常 2~4s
 *     （一次模型请求 + 一次工具执行），5s 能把这些轮收进同一批；
 *     单件查询也就多等这几秒，属于聊天机器人可接受的量级。
 *   · BUDGET（20s）：从第一件算起最多攒这么久。防止模型"边想边查"几十秒时
 *     群友一直等不到回复 —— 到点先把已有的发出去，剩下的重新攒。
 *     这也给刷屏设了上界：最密也不过每 20 秒一条。
 *     且 BUDGET 会被强制取成 ≥ IDLE（见 mergeBudgetMs），否则预算先到点、
 *     静默窗口永远等不到，用户在设置里调 IDLE 会感觉"完全没用"。
 *
 * 兜底不止定时器：
 *   · 开新一轮（before-context）时，**已过期**的草稿一定发出去，消息不会永久卡住；
 *   · 技能被停用/卸载时也会放掉（见文件尾的 deactivate / dispose）。
 */
const MERGE_IDLE_MS = 5000;
const MERGE_BUDGET_MS = 20000;

/**
 * 这两个窗口**已从设置里移除**（设置页精简掉了，实测没人会调它们）。
 *
 * 保留读取 `cfg()` 的能力是为了兼容老配置文件里残留的键 —— 读得到就沿用，
 * 读不到就用上面的常量。这样升级不会让老用户的既有调参突然失效。
 */
function mergeIdleMs() {
  const n = Number(cfg().mergeIdleMs);
  return Number.isFinite(n) && n >= 0 ? Math.min(60000, n) : MERGE_IDLE_MS;
}

/**
 * 一批最多攒多久。
 *
 * ⚠️ 必须兜住的边界：预算若**短于**静默窗口，预算会先到点、静默窗口永远等不到，
 * 用户会以为"调了静默时间完全没用"。所以预算至少不低于静默窗口。
 */
function mergeBudgetMs() {
  const n = Number(cfg().mergeBudgetMs);
  const configured = Number.isFinite(n) && n >= 1000 ? Math.min(300000, n) : MERGE_BUDGET_MS;
  return Math.max(configured, mergeIdleMs());
}
const BATCH_MAX_ITEMS = 40;      // 合并后的卡片最多列这么多件，兜住极端刷屏

/**
 * 伊甸币（PLEX）。
 *
 * ⚠️ 它是**特殊物品**：不在常规挂单市场里 —— 两个服的所有星域查挂单都是 0 条
 * （实测伏尔戈前 30000 条挂单里一条都没有）。ESI 只在 `/markets/prices/`
 * 给它一个**参考均价**，所以报价卡片必须用"参考均价"的措辞，
 * 不能写成"出售/收购"（那会让群友以为能按这个价成交）。
 *
 * 两个服的数值差很多，别搞混（实测）：
 *   晨曦 23,435,746 ISK   /   欧服 4,712,023 ISK
 *
 * `伊甸币` 在本地中文索引里能搜到（type_id 44992），但英文名 `PLEX` 搜不到
 * ——索引只收中文名，而 ESI 的中文名是"伊甸币"。所以下面另配一份别名。
 */
const PLEX_TYPE_ID = 44992;
const PLEX_PER_MONTH = 500;      // 500 伊甸币 = 1 张月卡（用户给的换算）

/**
 * 伊甸币的**专用星域** `19000001`（GPMR-01）。
 *
 * ⚠️ 这是个特殊星域：里面**只有伊甸币一种物品**（实测 `/markets/19000001/types/`
 * 返回 1 种），是全星系独立市场，和吉他/伏尔戈完全无关。
 *
 * 我第一版把它当成普通物品查伏尔戈，得到"挂单 0 条"就下了"ESI 没有伊甸币挂单"的结论
 * —— **错的**。用户指出它是独立市场后扫了全部 116 个星域才找到这里：
 *
 *   晨曦：85 条挂单，最低卖 24,500,000，**历史 378 天**（到今天）
 *   欧服：1000 条挂单，最低卖 4,870,000，**历史 402 天**
 *
 * 所以它既有完整挂单、也有整年历史，只是不在常规星域里。
 */
const PLEX_REGION_ID = 19000001;

/** 伊甸币的别名 —— 群友可能说这几种，都要能查到。 */
const PLEX_ALIASES = ['plex', '伊甸币', '月卡', 'plex价格', '伊甸币价格', 'eve月卡'];

/** sessionId/chatKey → { chatKey, serverLabel, sections, count, timer, startedAt, … } */
const batches = new Map();

/**
 * 本轮问价的人（sessionId/chatKey → { userId, name }）。
 *
 * 为什么走 `before-context` 钩子而不是直接读全局聊天存档：存档里最后一条消息
 * 未必是触发本轮的那条（群里可能已经又聊了两句），而触发批 triggerEntries
 * 正是"把机器人叫起来的那几条"，挂在这里最准。
 * 卡片要把 @ 打给提问的人，而不是 @ 地点或 @ 全场，所以这层归属必须有。
 */
const askers = new Map();
const ASKER_CACHE_MAX = 100;

/**
 * 会话键。**两套上下文的字段名不一样，必须都认**：
 *   钩子（before-context）给的是 `ctx.sessionId`（顶层字符串）
 *   工具（execute）拿到的是 `ctx.session.id`（对象里的字段）
 * 早先只读 sessionId，于是钩子存进 's1'、工具去查 'group:xxx'，永远查不到 ——
 * 表现就是"@ 目标为空"这种静默失效。
 */
function askerKey(ctx = {}) {
  return String(ctx.sessionId || ctx.session?.id || ctx.chatKey || '');
}

function noteAsker(ctx = {}) {
  try {
    const entries = Array.isArray(ctx.triggerEntries) ? ctx.triggerEntries : [];
    let picked = null;
    // 倒序取最后一条"人说的"消息：一轮里可能有好几条，回的是最新的那个
    for (let i = entries.length - 1; i >= 0; i--) {
      const e = entries[i];
      if (!e || e.self || e.isPoke) continue;
      const userId = String(e.senderId ?? '').trim();
      if (!userId || userId === 'self' || userId === '0') continue;
      picked = { userId, name: String(e.senderName ?? '').trim() };
      break;
    }
    if (!picked) return;
    const key = askerKey(ctx);
    if (!key) return;
    askers.set(key, picked);
    if (askers.size > ASKER_CACHE_MAX) {
      askers.delete(askers.keys().next().value);
    }
  } catch { /* 记不下只是这次 @ 不到人，不该影响查询 */ }
}

/** 取本轮提问的人；钩子没覆盖到就退回"存档里最后一条别人说的话"。 */
function currentAsker(ctx = {}) {
  const fromHook = askers.get(askerKey(ctx));
  if (fromHook?.userId) return fromHook;
  try {
    const chatKey = ctx.chatKey;
    const recent = chatKey ? (ctx.store?.peekUnread?.(chatKey, 5) ?? []) : [];
    for (let i = recent.length - 1; i >= 0; i--) {
      const e = recent[i];
      if (!e || e.self) continue;
      const userId = String(e.senderId ?? '').trim();
      if (userId && userId !== 'self') return { userId, name: String(e.senderName ?? '').trim() };
    }
  } catch { /* 拿不到就算了 */ }
  return null;
}

export const hooks = {
  /**
   * 开新一轮前：先记下"谁问的"，再把**已经过期**的草稿放出去。
   *
   * 这里只放"过期"的（静默超过 IDLE），不是无脑全放 —— 模型拆成多轮一件件问时
   * （「月矿呢」就是这种），每一轮都会走到这个钩子；如果每轮都 flush，就回到
   * 一次一条的刷屏老路了。合并窗口要跨轮攒，靠的是时间判据而不是轮次边界。
   *
   * 顺序也不能反：残留批次要用**它自己那轮**的提问者来 @，而不是新这轮的。
   */
  'before-context': (ctx) => {
    flushStale('turn-boundary').catch(() => {});
    noteAsker(ctx);
  }
};

/** 把某个物品并进本会话的草稿。 */
function enqueueQuote(batchKey, ctx, { chatKey, serverLabel, locationLabel, items }) {
  let batch = batches.get(batchKey);
  if (!batch) {
    batch = {
      chatKey,
      serverLabel,
      sections: new Map(),
      count: 0,
      timer: null,
      session: ctx.session,
      sender: ctx.sender,
      emit: ctx.emit,
      // 提问者与序号都**在入队时定下来**：
      //   · 提问者：flush 时上下文可能已经换轮/换会话，那时再查就查不到了
      //     （尤其"钩子没跑到、靠存档兜底"的路径）。
      //   · 序号：核心是 `for (const call of toolCalls) await executeTool(...)` ——
      //     同一批工具调用**串行**执行，所以入队顺序就是模型的调用顺序，
      //     也就是群友的提问顺序。并发跑测试时这个顺序会退化，卡片顺序随之不稳，
      //     但生产路径是稳定的。
      asker: null,
      seq: 0,
      startedAt: Date.now()
    };
    batches.set(batchKey, batch);
  }
  if (!batch.asker) {
    const asker = currentAsker(ctx);
    if (asker?.userId) batch.asker = asker;
  }
  const order = batch.seq++;

  // 同一件物品在一轮里被问了两遍 → 后者覆盖前者，不重复列
  for (const it of items) {
    batch.sections.set(String(it.typeId), {
      // 再兜一道：卡片是要发到群里的，名字绝不能是 undefined
      typeName: displayName(it.typeName, it.typeId),
      locationLabel,
      quote: it.quote,
      order,
      // 图表所需信息也**在入队时记下**：flush 时上下文可能已经换轮/换会话，
      // 那会儿再去问"这件物品在哪个星域"就查不到了。空盘（无挂单）的不记 ——
      // 没成交的冷门货画出来是空白，不如不画。
      //
      // ⚠️ 伊甸币（`quote.plex`）要**单独放行**：它永远没有挂单（sell/buy 都空），
      // 但**有逐日历史**（晨曦 25 天）—— 只按 sell/buy 判会把它的图漏掉（实测）。
      // 欧服伊甸币没有历史，画图那步会自行失败并跳过，不影响文本卡片。
      chart: it.quote && (it.quote.sell || it.quote.buy || it.quote.plex) ? it.chart : null
    });
  }
  batch.count += 1;
  batch.lastAt = Date.now();
  batch.serverLabel = serverLabel || batch.serverLabel;
  if (!batch.chatKey) batch.chatKey = chatKey;
  // 发送三件套以最新一次调用为准（同一轮里它们是同一个会话对象）
  if (ctx.session) batch.session = ctx.session;
  if (ctx.sender) batch.sender = ctx.sender;
  if (ctx.emit) batch.emit = ctx.emit;

  if (batch.timer) clearTimeout(batch.timer);
  scheduleFlush(batchKey, batch);
  return batch.sections.size;
}

/**
 * 安排发送：取"静默 1.5s 后发"和"最迟从第一件算起 12s"里更早的那个。
 * 每次有新查询进来都重排一次 —— 这就是"还在问就继续等"的实现。
 */
function scheduleFlush(batchKey, batch) {
  const now = Date.now();
  const idleAt = now + mergeIdleMs();
  const budgetAt = batch.startedAt + mergeBudgetMs();
  const wait = Math.max(80, Math.min(idleAt, budgetAt) - now);
  batch.timer = setTimeout(() => { flushBatch(batchKey, 'timer').catch(() => {}); }, wait);
}

/**
 * 物品名兜底显示。
 *
 * 线上事故：某次调用没解析出物品名（`typeName` 为空），卡片文本里就出现了
 * 字面量 "undefined 在吉他（晨曦）..."。任何要进消息的字符串都必须经过它，
 * 宁可不写名字，也不能把 undefined 甩给群友。
 */
function displayName(...candidates) {
  for (const c of candidates) {
    const s = String(c ?? '').trim();
    if (s && s !== 'undefined' && s !== 'null') return s;
  }
  return '该物品';
}

/** 把草稿发成一条消息（一轮一条）。 */

async function flushBatch(key, reason = 'manual') {
  const batch = batches.get(key);
  if (!batch) return { sent: false, reason: 'no-batch' };
  if (batch.timer) { clearTimeout(batch.timer); batch.timer = null; }
  batches.delete(key);
  if (!batch.sections.size) return { sent: false, reason: 'empty' };

  const asker = batch.asker ?? null;
  const chatKey = batch.chatKey;
  if (!chatKey) return { sent: false, reason: 'no-chat' };

  // 按入队序号排：并发查询的返回顺序不定，但卡片顺序要是提问顺序
  const entries = [...batch.sections.values()]
    .sort((a, b) => (a.order - b.order))
    .slice(0, BATCH_MAX_ITEMS);
  const omitted = Math.max(0, batch.sections.size - entries.length);

  // 按地点分组：一轮里可能既查了吉他、又查了艾玛，标出来才分得清
  const groups = [];
  for (const entry of entries) {
    const label = String(entry.locationLabel ?? '').trim();
    let group = groups.find((g) => g.locationLabel === label);
    if (!group) { group = { locationLabel: label, entries: [] }; groups.push(group); }
    group.entries.push(entry);
  }

  const text = buildQuoteText({
    sections: groups,
    server: { label: batch.serverLabel || '晨曦' },
    multi: entries.length > 1
  });
  if (omitted) {
    api?.log?.(`合并卡片超过 ${BATCH_MAX_ITEMS} 件，另有 ${omitted} 件未列出`);
  }

  // 上下文在 flush 时可能已经换轮/换会话，所以 chatKey 用发起时记下的那个
  const sender = batch.sender;
  if (!sender) return { sent: false, reason: 'no-sender' };

  const atUserId = asker?.userId ? String(asker.userId) : '';
  const archived = atUserId ? `[@${asker.name || atUserId}] ${text}` : text;

  // ── 发送 ──────────────────────────────────────────────────────────────
  //
  // 分两种走法，取决于要不要附图：
  //
  //  A) **附图**（chartWithQuote 开、且这一轮有可画的物品）→ 一条消息搞定。
  //     OneBot 的消息是**段数组**，所以 `@ + 文本 + 图片` 能塞进同一条：
  //     群里看到的是一个气泡，@ 在上一行、卡片和走势图紧随其后。
  //     （早先是"发文本 → 再发图"两条，中间还隔着 2~3 秒渲染，看起来就是
  //       两条不相干的消息。用户明确要求"图片和信息一起发"，这条路径就是为此。）
  //
  //  B) **不附图**（或宿主没提供 sendMedia）→ 仍然只发文本。
  //
  // 两种路径都**只发一条消息**，不改变"不刷屏"的既有约定。
  const chartSegments = cfg().chartWithQuote
    ? await renderBatchCharts(entries, batch)
    : [];

  if (chartSegments.length && typeof sender.sendMedia === 'function') {
    const segments = [];
    if (atUserId) segments.push({ type: 'at', data: { qq: atUserId } });
    // @ 与正文之间空一行：@ 段是独立的前置段，紧跟正文会挤成 "@某人三钛合金"，
    // 看着像名字和物品名连在一起。用户要求 @ 后空一行。
    segments.push({ type: 'text', data: { text: escapeCqText(`\n${text}`) } });
    segments.push(...chartSegments);

    try {
      await sender.sendMedia(chatKey, segments, {
        label: `${text}\n[走势图]`,
        // ⚠️ 必须显式给 dedupeKey：sendMedia 的默认去重键会拿段里的 `file`
        //    拼字符串，而我们的图是 base64（几十万字符）—— 既浪费又荒谬。
        //    用"物品 ID + 当天"做键：同一天同一件不重复发，跨天自然放行。
        dedupeKey: `chart-${entries.map((e) => e.chart?.typeId ?? e.typeId).join('-')}-${new Date().toISOString().slice(0, 10)}`
      });
      batch.session?.sent?.push({ type: 'image', text: archived + '\n[走势图]' });
      batch.emit?.('session-update', batch.session?.id);
      api?.log?.(`报价合并发出（${reason}）：${entries.length} 件 / 消息 ${text.length} 字 + 走势图 ${chartSegments.length} 张（同一条消息）`);
      return { sent: true, count: entries.length, omitted, merged: batch.count, charts: chartSegments.length, combined: true };
    } catch (error) {
      // 合并发送失败要退回纯文本 —— 群友要的价格不能因为图发不出去而丢掉
      api?.warn?.(`合并发送（文本+图）失败，退回纯文本：${error?.message ?? error}`);
      await sender.sendTextBatch(chatKey, [text], atUserId ? { atUserId } : {});
      batch.session?.sent?.push({ type: 'text', text: archived });
      batch.emit?.('session-update', batch.session?.id);
      return { sent: true, count: entries.length, omitted, merged: batch.count, charts: 0, combined: false };
    }
  }

  await sender.sendTextBatch(chatKey, [text], atUserId ? { atUserId } : {});
  batch.session?.sent?.push({ type: 'text', text: archived });
  batch.emit?.('session-update', batch.session?.id);
  api?.log?.(`报价合并发出（${reason}）：${entries.length} 件 / 消息 ${text.length} 字`);

  // 宿主没有 sendMedia 时的退路：图单独发。走到这里说明是**降级**路径，
  // 正常安装不会进（ctx.sender 就是 SendQueue，一定有 sendMedia）。
  if (chartSegments.length) {
    await sendChartSegmentsOneByOne(sender, chatKey, chartSegments, batch);
  }
  return { sent: true, count: entries.length, omitted, merged: batch.count, charts: chartSegments.length, combined: false };
}

/** 一轮最多附几张图。每张约 200KB，一轮查 8 件就是 1.6MB —— 上限必须有。 */
const CHART_MAX_PER_BATCH = 2;

/** OneBot 文本段要转义 `[CQ:`，否则底层网关会把它当 CQ 码解析（与宿主同一规则）。 */
function escapeCqText(text) {
  return String(text ?? '').replace(/\[CQ:/gi, '[CQ：');
}

/**
 * 画这一批要附的走势图，返回 OneBot 图片段数组（不发送）。
 *
 * 设计取舍：
 *   · **只在合并卡片里发**，不为每件单独发 —— 否则又回到刷屏。
 *   · 一次最多 CHART_MAX_PER_BATCH 张（默认 2），按提问顺序取前几张。
 *   · 图比文本**小一号**（1180×660）：多张连着看小些更清爽、传输也省。
 *   · 空盘（无挂单）的不画：没有成交的冷门货画出来是空白。
 *   · **单张失败只记日志并跳过**，绝不抛出去 —— 文本才是群友要的答案，
 *     画图失败不能把它拖下水。
 */
async function renderBatchCharts(entries, batch) {
  const serverKey = SERVER_KEY_OF[batch.serverLabel];
  const server = SERVERS[serverKey] ?? SERVERS[DEFAULT_SERVER];
  const days = chartDays();
  const targets = entries.filter((e) => e.chart).slice(0, CHART_MAX_PER_BATCH);
  if (!targets.length) return [];

  const settled = await Promise.all(targets.map(async (entry) => {
    try {
      const png = await generateChart(fetcher, {
        typeId: entry.chart.typeId,
        itemName: entry.typeName,
        base: server.base,
        regionId: entry.chart.regionId,
        days,
        caption: normalizeTail(cfg().quoteContent),
        // 附图尺寸：1180x660 → 1480x880 → **1680x1000**（用户两次说"还是有点小"）。
        // 尺寸演进的原因：
        //   · 1180 宽时左边距占比过高（纵轴刻度把绘图区挤扁，横轴只放得下 9 个日期）
        //   · 1480 时观感正常，但用户仍觉得小
        //   · 1680x1000 在 ss=2 下是 3360x2000，没超 3600x2400 上限，**仍是 2 倍超采样**
        //     （再大就会被降级成 ss=1、画质反而变差 —— 这是上限的由来）
        width: 1680,
        height: 1000,
        updatedAt: new Date().toLocaleString('zh-CN', { hour12: false })
      });
      return { type: 'image', data: { file: `base64://${png.base64}` } };
    } catch (error) {
      const msg = String(error?.message ?? error);
      // "历史不足 2 天"是**正常情况**（冷门货、欧服伊甸币没有逐日数据），不是故障：
      // 用 log 而不是 warn，免得每次查询都刷一条告警。
      if (/不足 2 天|历史数据不足/.test(msg)) api?.log?.(`跳过走势图（${entry.typeName}）：${msg}`);
      else api?.warn?.(`附走势图失败（${entry.typeName}）：${msg}`);
      return null;
    }
  }));

  const ok = settled.filter(Boolean);
  if (ok.length) api?.log?.(`走势图已画好 ${ok.length} 张（${server.label} / ${days} 天）`);
  return ok;
}

/** 降级路径：宿主没有 sendMedia 时，图只能一张一条地发。 */
async function sendChartSegmentsOneByOne(sender, chatKey, segments, batch) {
  for (const seg of segments) {
    try {
      await sender.sendImage(chatKey, { dataUrl: seg.data.file });
      batch.session?.sent?.push({ type: 'image', text: '[走势图]' });
    } catch (error) {
      api?.warn?.(`补发走势图失败：${error?.message ?? error}`);
    }
  }
  batch.emit?.('session-update', batch.session?.id);
}

/** 兜底：把所有会话的草稿都发出去（技能停用/卸载、显式调用时）。 */
async function flushAllPending(reason) {
  const keys = [...batches.keys()];
  for (const key of keys) {
    try { await flushBatch(key, reason); } catch { /* 单条失败不影响其它 */ }
  }
}

/**
 * 只放"已经静默够久"的草稿（开新一轮时的兜底）。
 * 判据与定时器一致：静默超过 IDLE，或已经攒到 BUDGET 上限。
 */
async function flushStale(reason) {
  const now = Date.now();
  for (const [key, batch] of [...batches.entries()]) {
    const quietFor = now - (batch.lastAt ?? batch.startedAt ?? now);
    const aged = now - (batch.startedAt ?? now);
    if (quietFor >= mergeIdleMs() || aged >= mergeBudgetMs()) {
      try { await flushBatch(key, reason); } catch { /* 单条失败不影响其它 */ }
    }
  }
}

/** 给测试与外部调用：立刻合并发出。 */
export async function flushQuotes() {
  await flushAllPending('explicit');
  return batches.size === 0;
}

/**
 * 宿主日志函数。模块顶层拿不到 `api`（那是 setup 的参数），
 * 所以这里留一个可替换的引用，由 setup 赋值。
 *
 * ⚠️ 我第一版直接写了 `chart.setChartLogSink?.((m) => skillApi.log?.(m))` 放在顶层：
 * `skillApi` 在模块作用域**根本不存在**，那一行被可选链短路成死代码，
 * 表现是"自检日志怎么都不进 app 日志"，又白查一轮。绑定必须在 setup 里做。
 */
let logSink = () => {};

export function setup(skillApi) {
  logSink = (m) => { try { skillApi.log?.(m); } catch { /* 日志失败不影响功能 */ } };
  chart.setChartLogSink?.(logSink);
  api = skillApi;
  cfg = skillApi.config;
  fetcher = (...args) => skillApi.fetch(...args);

  // 启动日志带上**版本号**。排查时第一件事就是确认"跑的是哪一版"——
  // 没有版本号的话，只能靠改了什么、什么时候改的来推，很容易看错版本。
  // 版本号不在代码里写第二遍：从 skill.json 读，避免两处定义漂移。
  const version = readSkillVersion();
  api.log(`EVE 市场技能 v${version} 已加载（官方 ESI：晨曦 / 欧服）`);

  // 后台预热中文名索引（首次约 35 秒／57 页 + 批量反查）。
  // **不阻塞加载** —— 群友第一次问价时若索引还没好，报价工具会如实回一句
  // "稍后再问"，而不是拿不准的名字硬查。索引 24 小时有效，每天最多预热一次。
  ensureIndex(fetcher, { log: (m) => api.log(m) })
    .then((r) => { if (r.built) api.log(`中文名索引就绪（${r.count} 个物品）`); })
    .catch((e) => api.warn('中文名索引预热失败：' + (e?.message ?? e)));

  skillApi.registerTool({
    id: 'market_quote',
    name: 'EVE市场报价',
    description: [
      '查询 EVE 国服（晨曦服务器）某物品在吉他等贸易 hub 的实时市场价，并把报价卡片发到群里。',
      '触发场景：群友问「jita 阿贝拉」「XX 多少钱」「XX 什么价」「吉他 XX 价格」「帮我查下 XX 市场」等。',
      '参数 item 只填物品名本身（如「阿贝拉」「三钛合金」「地狱天使级」），把 jita/吉他/晨曦/多少钱 这类词剥掉；地点写进 location。',
      '名称与物品完全一致时只报这一个；否则（如「胡蜂」对「胡蜂 I / 胡蜂 II / 集成型胡蜂」）会把所有相关物品一次全报，无需你再逐个调用。',
      '查不到时如实说明，绝对不要凭记忆编造价格。',
      '⚠️ 不要自己复述价格、也不要自己 @ 人：工具已经把报价卡片 @ 给提问者发出去了，之后说一句简短的话即可（或直接结束）。'
    ].join(''),
    category: 'query',
    icon: '📈',
    parameters: {
      type: 'object',
      properties: {
        item: { type: 'string', description: '物品名称，如「阿贝拉」（可带型号后缀，如「阿贝拉 SW-900-I」）；也可以直接给物品 ID' },
        location: { type: 'string', description: "贸易 hub：'jita'（吉他，默认）/ 'amarr'（艾玛）/ 'dodixie' / 'rens' / 'hek'，或直接给星系 ID" },
        server: {
          type: 'string',
          description: [
            "服务器：'chenxi'（晨曦/国服，默认）/ 'tq'（欧服）。",
            '群友用指令前缀指服务器时（如「ojita 三钛合金」），把前缀对应的服务器填到这里，并把前缀从 item 里去掉。',
            prefixHint()
          ].filter(Boolean).join('')
        }
      },
      required: ['item']
    },
    async execute(ctx, args) {
      try {
        const rawItem = String(args?.item ?? '').trim();
        if (!rawItem) return err('没给物品名。请把群友说的物品名传给 item。');

        // 指令前缀（jita/ojita/sjita…）在这里被认成服务器+地点，并从物品名里剥掉
        const { server, item: query, location } = resolveQuery(rawItem, args?.server, args?.location);

        const resolved = await resolveItem(query, { server: server.key });
        if (resolved.error) return err(resolved.error);

        // 逐个取价。命中多件时全部取（并发），单件时就是一次请求。
        //
        // ⚠️ 这里**不能把错误吞掉**：早先只是 `quote: null`，结果"取数全失败"和
        // "这个物品没挂单"在返回里长得一模一样（都是 found:false），排查时完全
        // 看不出是哪一步断的。现在失败原因一路带到返回里，同时打日志。
        const entries = await Promise.all(resolved.items.map(async (item) => {
          try {
            // ── 伊甸币（PLEX）走独立分支 ──
            // 它在**专用星域 19000001**（GPMR-01）交易 —— 全星系独立市场，
            // 跟吉他/伏尔戈无关。所以这里**不能用 location**：直接查那个星域，
            // 也不按星系过滤（市场是全局的，没有"哪个星系的价格"这回事）。
            //
            // 踩过的坑：第一版按普通物品查伏尔戈 → 0 条挂单 → 误判成"ESI 没有伊甸币数据"，
            // 只好退回 /markets/prices/ 的参考均价。实际上它有完整挂单和整年历史，
            // 只是不在常规星域里（用户指出后扫了全部 116 个星域才找到）。
            if (Number(item.typeId) === PLEX_TYPE_ID) {
              const orders = await regionOrders(fetcher, PLEX_TYPE_ID, {
                regionId: PLEX_REGION_ID, base: server.base
              });
              const quote = summarizeOrders(orders);
              if (!quote.sell && !quote.buy) {
                api?.warn?.(`伊甸币在专用星域没有挂单（${server.label}）`);
                return { ...item, quote: null, empty: false, error: '伊甸币当前没有挂单' };
              }
              // 月卡的两个方向都在 quoteLines 里按 sell/buy 现算（见那里的注释），
              // 这里只标记这是伊甸币，交给渲染层走月卡分支。
              return { ...item, quote: { ...quote, plex: true }, empty: false };
            }
            const orders = await fetchOrders(item.typeId, location, server.key);
            const quote = summarizeOrders(orders);
            return { ...item, quote, empty: !quote.sell && !quote.buy };
          } catch (error) {
            const msg = String(error?.message ?? error);
            api?.warn?.(`取挂单失败（${item.typeName} / ${server.label} / ${location.label}）：${msg}`);
            return { ...item, quote: null, empty: false, error: msg };
          }
        }));

        const usable = entries.filter((e) => e.quote);
        const quoted = usable.filter((e) => !e.empty);
        const emptyNames = usable.filter((e) => e.empty).map((e) => displayName(e.typeName, e.typeId));
        const failed = entries.filter((e) => !e.quote);
        // 物品名可能因搜索异常而缺失，任何进消息的字符串都要过 displayName
        const subject = displayName(resolved.typeName, resolved.items?.[0]?.typeName, query);

        if (!quoted.length) {
          // ⚠️ 这里**绝不自动发消息**。
          //
          // 线上事故（2026-09-30）：这个分支早先把 note 直接发到了群里，而 note 是
          // 写给模型看的说明，于是群里出现了一条
          //   「undefined 在吉他（晨曦）当前没有任何挂单。如实告诉群友"…"，可以顺带
          //     说一句换个 hub 试试；不要编造价格。」
          // —— 模型把"给它的指示"当成消息发出去了，而且物品名是 undefined。
          // 教训：工具返回里凡是"对模型的指示"，都可能被模型当内容转发；这类文案
          // 一旦被自动发出，就是误发。所以只把**结论**给模型，由它自己组织人话。
          return ok({
            found: false,
            sent: false,
            typeName: subject,
            location: location.label,
            server: server.label,
            emptyNames,
            failed: failed.map((f) => ({ typeName: displayName(f.typeName, f.typeId), error: f.error })),
            note: `${subject} 在${location.label}（${server.label}）没有挂单。`
              + '请用一句人话告诉群友（例如"这个地点现在没货，换个 hub 试试"）—— 群友在等你回话，'
              + '但不要把这段说明原文复制出去，也不要编造价格。'
          });
        }

        // 无挂单的物品也并进卡片（如实写「无挂单」），而不是单独发一句说明 ——
        // 这样"哪几件没货"由卡片自己承载，不用模型转述，也就没有转述出错的机会。
        const emptyItems = usable.filter((e) => e.empty).map((e) => ({
          typeId: e.typeId,
          typeName: displayName(e.typeName, e.typeId),
          quote: { sell: null, buy: null, mid: null },
          empty: true
        }));
        const items = [
          ...quoted.map((e) => ({ typeId: e.typeId, typeName: displayName(e.typeName, e.typeId), quote: e.quote })),
          ...emptyItems
        ];
        const text = buildQuoteText({
          entries: items,
          location,
          server,
          multi: resolved.multi
        });

        // @ 提问的人（而不是 @ 地点）。atUserId 是**协议级** @ ——
        // 消息段里带一个 at 段，对方真会被提醒到；纯文本写个 "@某人" 不会有这个效果。
        const asker = currentAsker(ctx);
        const mention = asker?.userId ?? null;

        // 不立刻发：先并入本会话草稿，短窗口内的多次查询会合并成**一条**消息。
        // 模型一轮里连查几件（皮特姆多谱 A型、B型…）时，群里只多一条卡片而不是 N 条。
        const autoSend = cfg().autoSend !== false;
        const batchKey = askerKey(ctx);
        let queued = 0;
        let sent = false;
        if (autoSend) {
          queued = enqueueQuote(batchKey, ctx, {
            chatKey: ctx.chatKey,
            serverLabel: server.label,
            locationLabel: location.label,
            // 每件带上画图所需信息：附带走势图时（设置里可开）要用。
            // 记在入队时而不是 flush 时，因为 flush 时上下文可能已经换轮。
            items: items.map((it) => ({
              ...it,
              // 伊甸币用**专用星域**（全星系独立市场），不能用 location 的 ——
// 否则图会去查伏尔戈的历史，只有 25 天且是旧的（实测）。
      chart: { typeId: it.typeId, regionId: Number(it.typeId) === PLEX_TYPE_ID ? PLEX_REGION_ID : location.regionId }
            }))
          });
          sent = true;   // 语义上"已安排发出"，避免模型自己再补一条
        }

        const note = [
          sent
            ? [
              '报价卡片已交给插件发出（同一轮的多次查询会自动合并成一条，不要重复发）。',
              '不要再重复价格，说一句简短的话或直接结束即可。'
            ].join('')
            : [
              '报价文本见 reply 字段，请原样发送（数字与千分位不要改动）。',
              mention ? `发送时请 @ 提问的人：tools 的 send_message 传 atUserId=${mention}。` : ''
            ].filter(Boolean).join(''),
          emptyNames.length ? `（${emptyNames.join('、')} 在当地无挂单，卡片里已经写成「无挂单」，不要替它们编价格。）` : '',
          resolved.truncated ? `（匹配到的物品超过上限，只报前 ${quoted.length} 个。）` : '',
          failed.length ? `（${failed.length} 个物品取价失败、没进卡片，不要把技术错误发到群里。）` : ''
        ].filter(Boolean).join('');

        return ok({
          reply: text,
          sent,
          mergedInto: queued,
          asker: asker ? { userId: asker.userId, name: asker.name || null } : null,
          reported: quoted.length,
          items: quoted.map((e) => ({
            typeId: e.typeId,
            typeName: displayName(e.typeName, e.typeId),
            sell: e.quote.sell,
            buy: e.quote.buy,
            mid: e.quote.mid
          })),
          noOrders: emptyItems.map((e) => e.typeName),
          location: location.label,
          server: server.label,
          alternates: resolved.alternates ?? [],
          note
        });
      } catch (error) {
        return err(`市场查询失败：${error?.message ?? error}`);
      }
    }
  });

  skillApi.registerTool({
    id: 'market_book',
    name: 'EVE市场盘口',
    description: '查看某物品在指定贸易 hub 的前 5 档买单/卖单明细（价格、数量、空间站）。群友想看盘口深度、问「挂单什么情况」「买一卖一多少」时用。',
    category: 'query',
    icon: '📊',
    parameters: {
      type: 'object',
      properties: {
        item: { type: 'string', description: '物品名称或物品 ID' },
        location: { type: 'string', description: "'jita'（默认）/ 'amarr' / 'dodixie' / 'rens' / 'hek'" },
        server: {
          type: 'string',
          description: [
            "'chenxi'（晨曦/国服，默认）/ 'tq'（欧服）。",
            '群友用指令前缀指服务器时（如「ojita 三钛合金」），把前缀对应的服务器填到这里，并把前缀从 item 里去掉。',
            prefixHint()
          ].filter(Boolean).join('')
        },
        region: { type: 'boolean', description: 'true = 看整个星域（伏尔戈）的汇总统计，而不是单星系挂单' }
      },
      required: ['item']
    },
    async execute(_ctx, args) {
      try {
        const rawItem = String(args?.item ?? '').trim();
        if (!rawItem) return err('没给物品名。');
        const { server, item: query, location } = resolveQuery(rawItem, args?.server, args?.location);
        // 盘口是"细看某一个物品"，命中多件时只取最匹配的那个 ——
        // 想一次看一族用 eve-market__market_quote。
        const resolved = await resolveItem(query, { server: server.key });
        if (resolved.error) return err(resolved.error);
        const target = resolved.items[0];

        if (args?.region === true) {
          // ⚠️ 星域必须跟着 location 走。早先这里硬编码 10000002（伏尔戈），
          // 于是「艾玛 + region:true」拿到的是吉他的星域数据，而且返回里
          // scope 也写死「伏尔戈星域（含吉他）」，看起来完全正常 —— 静默错误。
          const regionId = location.regionId ?? 10000002;
          const regionLabel = location.regionId ? `${location.label}所在星域` : '伏尔戈星域（含吉他）';
          // 星域汇总从逐日历史里取：ESI 没有 ceve 那种"星域 marketstat"接口，
          // 但历史接口本身就是**整个星域**的逐日汇总，口径更准（是真成交，不是挂单）。
          const history = await marketHistory(fetcher, target.typeId, { base: server.base, regionId });
          const recent = history.slice(-7);
          const stat = recent.length ? {
            days: recent.length,
            span: `${recent[0].date} ~ ${recent[recent.length - 1].date}`,
            lastAverage: recent[recent.length - 1].average,
            lastHighest: recent[recent.length - 1].highest,
            lastLowest: recent[recent.length - 1].lowest,
            volumeSum: recent.reduce((a, r) => a + r.volume, 0),
            orderCountLast: recent[recent.length - 1].order_count
          } : null;
          return ok({
            typeId: target.typeId,
            typeName: target.typeName,
            scope: regionLabel,
            regionId,
            stat,
            note: '这是整个星域最近 7 天的**真实成交**汇总（不是挂单）。用一两句话概括即可，别把整张表贴出去。'
          });
        }

        const orders = await fetchOrders(target.typeId, location, server.key);
        const quote = summarizeOrders(orders);
        return ok({
          typeId: target.typeId,
          typeName: target.typeName,
          location: location.label,
          server: server.label,
          sellTop: quote.sell ? { price: quote.sell.price, volume: quote.sell.volume } : null,
          buyTop: quote.buy ? { price: quote.buy.price, volume: quote.buy.volume } : null,
          mid: quote.mid,
          sellCount: quote.sellCount,
          buyCount: quote.buyCount,
          // 前 5 档明细（空间站名要另查，这里给 locationId，模型不必念出来）
          sellBook: quote.sortedSells.slice(0, 5).map((o) => ({ price: o.price, volume: o.volumeRemain, locationId: o.locationId })),
          buyBook: quote.sortedBuys.slice(0, 5).map((o) => ({ price: o.price, volume: o.volumeRemain, locationId: o.locationId })),
          others: resolved.items.length > 1 ? resolved.items.slice(1).map((i) => i.typeName) : [],
          note: '用文字简报前几档即可，不要把整张表贴出去。'
        });
      } catch (error) {
        return err(`盘口查询失败：${error?.message ?? error}`);
      }
    }
  });

  skillApi.registerTool({
    id: 'market_search',
    name: 'EVE物品搜索',
    description: '按名称模糊搜索 EVE 物品，返回候选物品 ID。群友说的名字查不到、或有多个同名/近名物品时用。',
    category: 'query',
    icon: '🔎',
    parameters: {
      type: 'object',
      properties: {
        name: { type: 'string', description: '物品名关键词' },
        server: {
          type: 'string',
          description: [
            "'chenxi'（晨曦/国服，默认）/ 'tq'（欧服）。",
            '群友用指令前缀指服务器时（如「ojita 三钛合金」），把前缀对应的服务器填到这里，并把前缀从 name 里去掉。',
            prefixHint()
          ].filter(Boolean).join('')
        }
      },
      required: ['name']
    },
    async execute(_ctx, args) {
      try {
        const rawName = String(args?.name ?? '').trim();
        if (!rawName) return err('没给关键词。');
        const { item: name } = resolveQuery(rawName, args?.server, args?.location);

        if (!indexStatus().ready) {
          const built = await ensureIndex(fetcher, { log: (m) => api?.log?.(m) });
          if (!built.ok) {
            return err(`物品名索引还没就绪（${built.error ?? '正在后台建立'}），大约需要半分钟，请稍后再试。`);
          }
        }

        const items = searchByName(name, { limit: 20 });
        return ok({
          count: items.length,
          items,
          note: items.length
            ? '挑最匹配的那个，再用 eve-market__market_quote 按名称或 ID 查价。'
            : '没搜到，换个关键词（中文全名）再试。'
        });
      } catch (error) {
        return err(`物品搜索失败：${error?.message ?? error}`);
      }
    }
  });

  // ── 走势图 ────────────────────────────────────────────────────────────
  //
  // 只在群友**明确想看趋势**时才画（约 2~3 秒渲染 + 200KB 图片）。
  // 报价不走这条路：报个价不该等几秒、也不该发一张图。
  skillApi.registerTool({
    id: 'market_chart',
    name: 'EVE市场走势图',
    description: [
      '生成某物品近一年的价格走势图（最高价/最低价两条线 + 每日真实成交量柱状图），并直接发到群里。',
      '触发场景：群友说「画个图」「看下走势」「最近价格趋势」「涨了还是跌了」「行情怎么样」等**明确想看历史变化**的话。',
      '只是问「多少钱」「什么价」时**不要**用这个工具 —— 那是 eve-market__market_quote 的活。',
      '数据来自官方 ESI 的逐日成交记录（晨曦/欧服各有各的行情），上子图是当日最高/最低成交价区间，下子图是当日真实成交量（股数）。',
      '图由本工具直接发群，所以**不要在回复里再描述一遍图里的数字**（会重复且容易抄错），一句话带过即可。'
    ].join(''),
    category: 'query',
    icon: '📈',
    parameters: {
      type: 'object',
      properties: {
        item: { type: 'string', description: '物品名称或物品 ID' },
        location: { type: 'string', description: "'jita'（默认）/ 'amarr' / 'dodixie' / 'rens' / 'hek'" },
        server: {
          type: 'string',
          description: [
            "服务器：'chenxi'（晨曦/国服，默认）/ 'tq'（欧服）。",
            '群友用指令前缀指服务器时（如「ojita 三钛合金」），把前缀对应的服务器填到这里，并把前缀从 item 里去掉。',
            prefixHint()
          ].filter(Boolean).join('')
        },
        days: { type: 'number', description: '画最近多少天，默认 365（一年）。最多也就到 402 天。' }
      },
      required: ['item']
    },
    async execute(ctx, args) {
      try {
        const rawItem = String(args?.item ?? '').trim();
        if (!rawItem) return err('没给物品名。');
        const { server, item: query, location } = resolveQuery(rawItem, args?.server, args?.location);

        const resolved = await resolveItem(query, { server: server.key });
        if (resolved.error) return err(resolved.error);
        // 走势图只画一件：多件叠在一张图上分不清谁是谁，画多张又会刷屏。
        // 命中多件时取最匹配的那个，并在返回里告诉模型还有哪些备选。
        const target = resolved.items[0];

        const days = Math.max(7, Math.min(402, Number(args?.days) || 365));
        const png = await generateChart(fetcher, {
          typeId: target.typeId,
          itemName: target.typeName,
          base: server.base,
          regionId: location.regionId,
          days,
          caption: normalizeTail(cfg().quoteContent)
        });

        // 图直接发群（与报价卡片同一套"由代码发、不让模型转述"的理由：
        // 图片没法转述，让模型"描述"只会变成编造）。
        const chatKey = ctx?.chatKey;
        const sender = ctx?.sender;
        let sent = false;
        let sendError = '';
        if (chatKey && typeof sender?.sendImage === 'function') {
          try {
            await sender.sendImage(chatKey, { dataUrl: `base64://${png.base64}` });
            sent = true;
            ctx?.session?.sent?.push({ type: 'image', text: `${target.typeName} 近一年走势图` });
            ctx?.emit?.('session-update', ctx?.session?.id);
          } catch (error) {
            sendError = String(error?.message ?? error);
          }
        } else {
          sendError = '当前上下文不支持发图';
        }

        return ok({
          typeId: target.typeId,
          typeName: target.typeName,
          server: server.label,
          location: location.label,
          scope: `${png.spec.stats.first} ~ ${png.spec.stats.last}（${png.spec.stats.days} 天）`,
          peak: png.spec.stats.peak,
          trough: png.spec.stats.trough,
          average: Math.round(png.spec.stats.avg * 100) / 100,
          peakAt: png.spec.stats.peakAt,
          troughAt: png.spec.stats.troughAt,
          imageSent: sent,
          imageError: sendError || undefined,
          others: resolved.items.length > 1 ? resolved.items.slice(1, 6).map((i) => i.typeName) : [],
          note: sent
            ? '图已经由本工具发到群里了。请用一句话带过（例如"图里能看到最近一年的高低区间"），'
              + '不要复述图里的具体数字，也不要说"我画了图"这种过程描述。'
            : `图画好了但没发出去（${sendError}）。请如实告诉群友这次发图失败，不要凭记忆编造行情。`
        });
      } catch (error) {
        return err(`生成走势图失败：${error?.message ?? error}`);
      }
    }
  });
}

// ── 内部实现 ──────────────────────────────────────────────────────────────

/** 这次查询用哪个服务器（决定打哪个域名）。 */
function serverOf(serverKey) {
  return SERVERS[serverKey] ?? SERVERS[DEFAULT_SERVER];
}

/**
 * 取挂单。
 *
 * ⚠️ ESI 与 ceve 的一个关键差异：**没有 `usesystem` 参数**，星域级接口返回
 * 整个星域的挂单（每条带 `system_id`），所以"看吉他的价"必须自己筛。
 * 这一步在 lib-v5/esi.js 的 regionOrders 里做（传 systemId）。
 */
function fetchOrders(typeId, location, serverKey) {
  const server = serverOf(serverKey);
  return regionOrders(fetcher, typeId, {
    base: server.base,
    regionId: location.regionId ?? 10000002,
    systemId: location.systemId
  });
}

/**
 * 把原始挂单汇总成报价用的四项。
 *
 * 口径与 ceve 那版保持一致（卡片格式不能变）：
 *   卖一 = 最低卖单价、买一 = 最高收购价、中间 = 两者的中值。
 * 卖一是"想立刻买到要付多少"，买一是"想立刻卖掉能拿到多少"，中间价用来给一个
 * 谈判基准 —— 三个数一起看才知道现在的价差有多大。
 */
export function summarizeOrders(orders) {
  const sells = (orders ?? []).filter((o) => !o.isBuy && Number.isFinite(o.price) && o.price > 0);
  const buys = (orders ?? []).filter((o) => o.isBuy && Number.isFinite(o.price) && o.price > 0);

  const bestSell = sells.length ? sells.reduce((a, b) => (b.price < a.price ? b : a)) : null;
  const bestBuy = buys.length ? buys.reduce((a, b) => (b.price > a.price ? b : a)) : null;

  const sell = bestSell ? { price: bestSell.price, volume: bestSell.volumeRemain } : null;
  const buy = bestBuy ? { price: bestBuy.price, volume: bestBuy.volumeRemain } : null;
  const mid = sell && buy ? (sell.price + buy.price) / 2 : null;

  // 按价格排序，供盘口明细用
  const sortedSells = [...sells].sort((a, b) => a.price - b.price);
  const sortedBuys = [...buys].sort((a, b) => b.price - a.price);

  return { sell, buy, mid, sortedSells, sortedBuys, sellCount: sells.length, buyCount: buys.length };
}

/** 按 ID 查一件物品（含中文名）。索引里有名字就直接用，少打一次网络。 */
async function itemById(typeId, serverKey) {
  const server = serverOf(serverKey);
  const cached = names.nameOf(typeId);
  if (cached) return { typeId, typeName: cached };
  try {
    const info = await typeInfo(fetcher, typeId, { base: server.base });
    return { typeId, typeName: info.name || `物品 ${typeId}` };
  } catch {
    return { typeId, typeName: `物品 ${typeId}` };
  }
}

/**
 * 名称 → 物品列表。
 *
 * 命中多件时**全部返回**：群友说「胡蜂」多半想看的是这一族（胡蜂 I / II /
 * 集成型 / 加强型 / 蓝图…），只回一个最像的会逼着他再问一遍，而另一个机器人
 * 一次给全 —— 对比之下就显得"不全"。
 *
 * 但只有**全名**才触发"全报"：说「阿贝拉 SW-900-I」就只报这一件，
 * 不要因为搜索接口还返回了别的阿贝拉把无关的东西也刷出去。
 */
async function resolveItem(query, { server }) {
  // ── 伊甸币别名先过一遍 ──
  // 本地中文索引里只有"伊甸币"这个名字，搜 `plex` 会命中一堆
  // "Warpath Complex"（英文名里含 plex），搜"月卡"则一条都没有。
  // 所以这三个词在这里直接落到 PLEX_TYPE_ID，不走模糊搜索。
  // 只认**整串匹配**（去掉空白后），避免"plex价格多少"这种被误吞。
  {
    const bare = String(query ?? '').trim().toLowerCase().replace(/\s+/g, '');
    if (PLEX_ALIASES.includes(bare)) {
      const item = await itemById(PLEX_TYPE_ID, server);
      return { items: [item], multi: false, plexAlias: bare };
    }
  }
  if (/^\d+$/.test(query)) {
    return { items: [await itemById(Number(query), server)], multi: false };
  }

  // 中文名搜索走本地索引（官方 ESI 没有按名搜索接口）。
  // 索引没就绪时要**如实说**，而不是硬查一个错的 —— 首次建索引约 35 秒。
  if (!indexStatus().ready) {
    const built = await ensureIndex(fetcher, { log: (m) => skillApi?.log?.(m) });
    if (!built.ok) {
      return {
        error: `物品名索引还没就绪（${built.error ?? '正在后台建立'}），大约需要半分钟。`
          + '请用一句人话让群友稍后再问一次 —— 不要猜价格，也不要把这句提示原文发出去。'
      };
    }
  }

  const found = searchByName(query, { limit: 40 });
  if (!found.length) {
    return {
      error: `没搜到「${query}」。`
        + '请用一句人话回群友（例如"这个名字没查到，换个说法或直接给物品 ID"）—— 群友在等你回话，'
        + '但不要把这句提示原文复制出去，也不要凭记忆编造价格。'
    };
  }

  const ranked = rankMatches(found, query);
  const best = ranked[0];
  if (best.score === 0) {
    // 全名精确命中 → 只报这一件（其余同族留给群友自己问）
    return {
      items: [{ typeId: best.typeId, typeName: best.typeName }],
      multi: false,
      alternates: ranked.slice(1, 5).map((s) => s.typeName)
    };
  }

  // 只保留"确实相关"的（前缀命中或整体包含）。
  const related = ranked.filter((s) => s.score <= 2);
  // 上限固定在代码里：8 是实测下来够用又不刷屏的值。（曾做成设置项，后来精简掉了。）
  const cap = Math.max(1, Math.min(20, Number(cfg().maxItemsPerQuery) || 8));
  const picked = related.slice(0, cap);
  // 防御：搜索有结果、但一条都没通过相关性过滤 —— 这是**内部异常**（例如两边
  // 字段名对不上），必须报出来。早先这种情况会静默返回空列表，群里表现成"查不到"，
  // 排查时看不出任何线索（实测踩过）。
  //
  // ⚠️ 日志里**不写群友的原话（query）**。那是群友说的话，会进 app 的日志文件被
  // 长期留存 —— 而这个技能不该记录任何群聊内容。排查这个异常只需要知道
  // "搜到几条、名字长什么样"，那些都是 ESI 的游戏数据（物品名），不是隐私。
  // 返回给模型的 error 里可以带 query（那是当轮对话内的事，不落盘）。
  if (!picked.length) {
    const sample = found.slice(0, 3).map((f) => `${f.name}(score=${f.score})`).join(' | ');
    api?.warn?.(`物品匹配异常：搜索到 ${found.length} 条但无一条通过相关性过滤；`
      + `候选样本=${sample}；query 长度=${String(query).length}（内容不记录）`);
    return {
      error: `「${query}」匹配失败，换个写法或直接给物品 ID 试试。`
        + '请用一句人话回群友，不要凭记忆编造价格。'
    };
  }
  return {
    items: picked.map((s) => ({ typeId: s.typeId, typeName: s.typeName })),
    multi: picked.length > 1,
    truncated: related.length > cap,
    alternates: related.slice(cap, cap + 4).map((s) => s.typeName)
  };
}

/**
 * 名字匹配排序：完全一致(0) > 前缀(1) > 包含(2) > 其它(3)；
 * 同一档内按**名称字典序** —— 这样「胡蜂 I / 胡蜂 II / 胡蜂蓝图 I / 胡蜂EC-900」
 * 会按大家习惯的顺序挨着排，而不是按名字长短把 I、II 拆散到列表两端。
 *
 * ⚠️ 字段名要兼容两种来源：本地索引给的是 `name`（lib-v5/names.js），
 * 而这里的返回值历史上用 `typeName`。**踩过**：只读 `typeName` 时，
 * 索引来的条目 name 全是 undefined → 所有条目都判成"其它(3)" → 被
 * `score <= 2` 过滤光 → resolveItem 返回空列表且**不报错**，
 * 群里表现为"查不到"，排查时完全看不出原因。
 */
export function rankMatches(items, query) {
  const norm = (s) => String(s ?? '').toLowerCase().replace(/\s+/g, ' ').trim();
  const q = norm(query);
  return items.map((it) => {
    const typeName = it.typeName ?? it.name ?? '';
    const name = norm(typeName);
    let score = 3;
    if (name === q) score = 0;
    else if (name.startsWith(q)) score = 1;
    else if (name.includes(q)) score = 2;
    return { ...it, typeName, name, score };
  }).sort((a, b) => (a.score - b.score)
    || a.name.localeCompare(b.name, 'zh-Hans-CN')
    || (a.typeId - b.typeId));
}

/** 兼容旧调用：只取最匹配的一个。 */
export function pickBestMatch(items, query) {
  const ranked = rankMatches(items, query);
  const best = ranked[0];
  return {
    typeId: best?.typeId,
    typeName: best?.typeName,
    alternates: ranked.slice(1, 5).map((s) => s.typeName)
  };
}

/** 单件的四行报价。 */
function quoteLines(quote) {
  // 伊甸币（PLEX）多一段月卡折算（1 张月卡 = 500 个）。
  //
  // 月卡那一段用**和上面完全一样的三个词**（出售 / 收购 / 中间），
  // 只是数值都 ×500。用户明确要求这么写 —— 自造"买入成本/卖出收入"那种
  // 说法反而要多想一层，而且漏掉了中间价。
  //
  // `-月卡：伊甸币×500` 那一行充当小标题，说明下面三个数是同口径的折算。
  // 三个数缺哪一边就不出哪一行，不编数字。
  //
  // 不标注市场来源 —— 用户明确说不需要（卡片形态和普通物品保持一致更好读）。
  if (quote?.plex) {
    const lines = [
      `-出售：${quote.sell ? `${formatIsk(quote.sell.price)} ISK(${quote.sell.volume})` : '无挂单'}`,
      `-收购：${quote.buy ? `${formatIsk(quote.buy.price)} ISK(${quote.buy.volume})` : '无挂单'}`,
      `-中间：${quote.mid === null || quote.mid === undefined ? '—' : `${formatIsk(quote.mid)} ISK`}`,
      `-月卡：伊甸币×${PLEX_PER_MONTH}`
    ];
    if (quote.sell) lines.push(`-出售：${formatIsk(quote.sell.price * PLEX_PER_MONTH)} ISK`);
    if (quote.buy) lines.push(`-收购：${formatIsk(quote.buy.price * PLEX_PER_MONTH)} ISK`);
    if (quote.mid !== null && quote.mid !== undefined) {
      lines.push(`-中间：${formatIsk(quote.mid * PLEX_PER_MONTH)} ISK`);
    }
    return lines;
  }
  const sell = quote.sell;
  const buy = quote.buy;
  const mid = quote.mid;
  return [
    `-出售：${sell ? `${formatIsk(sell.price)} ISK(${sell.volume})` : '无挂单'}`,
    `-收购：${buy ? `${formatIsk(buy.price)} ISK(${buy.volume})` : '无挂单'}`,
    `-中间：${mid === null || mid === undefined ? '—' : `${formatIsk(mid)} ISK`}`
  ];
}

/**
 * 报价文本。
 *
 * 卡片里**不写 @**：@ 由发送层以协议 @ 段的形式加在消息开头（见 flushBatch 里
 * 传的 atUserId），这样提醒的是**提问的人**，而不是文本里一个没有提醒效果的假 @。
 *
 * 结构：
 *   单地点：[地点]（可选表头）/ 物品名 + 三行价 / … / 分隔线 / 服务器
 *   多地点：每组前标 [地点]，便于分辨哪几行是哪个 hub 的
 *
 * 物品名顶格、价格缩进两格 —— 缩进比横线更能看出"这几行属于上一件"。
 * 价格一律两位小数。
 */
export function buildQuoteText({ sections, entries, quote, location, server, typeName, multi }) {
  const groups = Array.isArray(sections) && sections.length
    ? sections
    : [{
      // 兼容旧形态调用（单组、整批一个地点）
      locationLabel: location?.label ?? '',
      entries: entries ?? [{ typeName, quote }]
    }];
  const all = groups.flatMap((g) => g.entries ?? []);
  const total = all.length;
  const locations = [...new Set(groups.map((g) => String(g.locationLabel ?? '').trim()).filter(Boolean))];
  const singleLocation = locations.length === 1 ? locations[0] : '';
  const showGroupLabel = groups.length > 1 && !singleLocation;
  const lines = [];

  if (total === 1 && groups[0].entries.length === 1 && multi !== true) {
    // 最简形态：一件物品、没说多地点 → 不夹带任何多余行
    const only = groups[0].entries[0];
    if (singleLocation && groups.length > 1) lines.push(`[${singleLocation}]`);
    lines.push(only.typeName);
    lines.push(...quoteLines(only.quote));
  } else {
    if (singleLocation) lines.push(`[${singleLocation}]`);
    for (const group of groups) {
      const label = showGroupLabel ? String(group.locationLabel ?? '').trim() : '';
      if (label) lines.push(`[${label}]`);
      for (const entry of group.entries ?? []) {
        lines.push(entry.typeName);
        for (const line of quoteLines(entry.quote)) lines.push(`  ${line}`);
      }
    }
  }

  lines.push('----------------');
  lines.push(`服务器：${server.label}`);

  // 卡片尾部：配置里填什么就追加什么，留空则不加任何尾行。
  // 早先是个布尔开关（固定三行小程序推广 + 来源声明），换成文本框后自由度更大 ——
  // 想写群号、想写自己的小程序、想留空都由填的人决定。
  const tail = normalizeTail(cfg().quoteContent);
  if (tail) lines.push(...tail);

  return lines.join('\n');
}

/**
 * 把配置里的"卡片尾部内容"整理成若干行。
 *
 * 文本框里直接回车换行最自然，但通过配置文件/接口写入时往往是转义的 `\n`
 * 两个字符 —— 两种都认，否则用户会看到字面量 `\n` 挂在卡片上。
 * 顺带去掉首尾空行与多余的行尾空格。
 */
export function normalizeTail(text) {
  const raw = String(text ?? '');
  if (!raw.trim()) return [];
  const lines = raw
    .replace(/\\r\\n|\\n|\\r/g, '\n')     // 转义的 \n → 真换行（配置里手写常见）
    .replace(/\r\n?/g, '\n')             // 真 CRLF → LF
    .split('\n')
    .map((line) => line.replace(/\s+$/, ''));
  // 去掉首尾空行（中间的空行保留，那是用户自己的排版）
  while (lines.length && !lines[0].trim()) lines.shift();
  while (lines.length && !lines[lines.length - 1].trim()) lines.pop();
  return lines;
}

function ok(payload) { return { content: JSON.stringify(payload, null, 1) }; }
function err(message) { return { content: String(message), isError: true }; }

/**
 * 解析出这次查询用哪个服务器、哪个地点、物品名是什么。
 *
 * 两个服务器用**各自的指令前缀**区分（设置里两项）：
 *
 *     jita 三钛合金    → 晨曦（国服）的吉他
 *     ojita 三钛合金   → 欧服的吉他
 *
 * 地点三级回退：
 *   1. 工具参数 location（群友自己说了地点，最明确）
 *   2. 前缀里带出的地点（`ojita`→吉他、`oamarr`→艾玛）
 *   3. FALLBACK_HUB（吉他）—— 「国服」这种不含地点信息的前缀用它
 * 全局 defaultLocation 只在前两步都没走通时兜底（例如地点名认不出来）。
 *
 * 为什么第 3 步是**常量**而不是设置项：要求就是"默认地点是吉他"，这是个固定约定。
 * 做成设置项只会让设置页更长，而它们几乎不会被改；真要换默认地点，
 * 往那个服的前缀里加带地点的词就行（`oamarr` 查艾玛）。
 *
 * 服务器优先级：工具参数 server > 指令前缀 > 默认服务器。
 */
function resolveQuery(rawItem, argServer, argLocation) {
  const conf = cfg();
  const prefixes = buildPrefixes(conf);
  const hit = matchPrefix(rawItem, prefixes, LOCTABLE);

  // 模型可能把**整个前缀**填进 server 参数（`ojita`），而不只是服务器名。
  // resolveServer 对认不出的输入会静默退回默认服务器 —— 那就是"查出来是别的服的
  // 价格、还不报错"。所以这里先拿用户配的前缀表兜一层。
  const byPrefix = argServer
    ? prefixes.find((p) => p.prefix === String(argServer).trim().toLowerCase())
    : null;

  const groupKey = byPrefix ? byPrefix.server : (hit ? hit.server : null);
  const server = groupKey
    ? resolveServer(groupKey)
    : (argServer ? resolveServer(argServer) : resolveServer(conf.defaultServer ?? DEFAULT_SERVER));

  const item = hit ? hit.rest : rawItem;

  const locationInput = argLocation
    ?? hit?.location
    ?? (groupKey ? FALLBACK_HUB : null)
    ?? conf.defaultLocation
    ?? FALLBACK_HUB;
  const location = resolveLocation(locationInput);

  return { server, item, location, prefix: hit?.prefix ?? '', prefixServer: hit?.server ?? '' };
}

/** 前缀提示串，写进工具参数描述里，模型才知道前缀对应哪个服务器。 */
function prefixHint() {
  const desc = describePrefixes(buildPrefixes(cfg()));
  return desc ? `本群用这些指令前缀区分服务器：${desc}` : '';
}

/**
 * 技能被停用/卸载时，把还没发出去的草稿放掉 —— 否则"刚查完就被关掉"会让
 * 群友永远等不到那张卡片（合并窗口只有几百毫秒，这种情况很少但确实存在）。
 */
export function deactivate() {
  flushAllPending('deactivate').catch(() => {});
}

export function dispose() {
  flushAllPending('dispose').catch(() => {});
}

export const __test__ = {
  resolveItem, rankMatches, pickBestMatch, buildQuoteText, flushQuotes,
  summarizeOrders, resolveQuery
};
