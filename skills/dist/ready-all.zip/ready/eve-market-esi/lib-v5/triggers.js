// 「指令前缀 → 服务器」解析。
//
// ───────────────── 模型 ─────────────────
//
// 两个服务器**各配一个前缀**（设置里两项，逗号/空格分隔可填多个）：
//
//     jita 三钛合金    → 晨曦（国服）的吉他
//     ojita 三钛合金   → 欧服的吉他
//     wjita 三钛合金   → 欧服的吉他（同一个服的第二个前缀，只是例子）
//
// 前缀剥掉开头的标记字母（`o` / `w` / `s`）后如果是个地点名，就按那个地点查：
//     `ojita` → 吉他、`oamarr` → 艾玛
// 认不出地点也不要紧 —— 那就走该服务器的默认 hub（固定在代码里，见 FALLBACK_HUB）。
//
// ───────────────── 为什么不像以前那样做成三个设置项 ─────────────────
//
// 原来三个服时是三个设置项。但现在只剩两个服，而且**曙光服已确认不存在可用的
// ESI 数据源**（试过多个域名都是 ENOTFOUND），所以那一项必须去掉 ——
// 留着就是"设置里能配、实际永远查不到"的坑。
//
// 各服的默认 hub 也**刻意不做成设置项**：约定就是"默认查吉他"，
// 做成配置项只会让设置页更长，而它们几乎不会被改。要换地点就往前缀里加带地点的词。

/** 标记字母：前缀剥完还剩一截时，再剥一层认地点（oamarr → amarr）。 */
const DEFAULT_MARKS = ['o', 's', 'w'];

/**
 * 前缀认不出地点时用哪个 hub。
 * 固定为吉他 —— 这是"两个服务器的默认地点都是吉他"这个要求的落点。
 */
export const FALLBACK_HUB = 'jita';

/** 把设置里的一行文本拆成前缀列表（逗号/顿号/分号/斜杠/空白都算分隔）。 */
export function parsePrefixes(text) {
  return String(text ?? '')
    .split(/[\s,，、;；|/]+/)
    .map((s) => s.trim())
    .filter(Boolean);
}

/**
 * 由设置构造前缀表。
 *
 * 服务器按**固定顺序**声明，用于解决"同一个前缀被两项都配了"的归属：
 * 先声明的赢（晨曦优先于欧服）。
 *
 * @param {{serverPrefixChenxi?:string, serverPrefixTq?:string}} config
 * @returns {Array<{prefix:string, server:string}>} 按前缀长度降序（长的先匹配）
 */
export function buildPrefixes(config = {}) {
  const groups = [
    ['chenxi', config.serverPrefixChenxi],
    ['tq', config.serverPrefixTq]
  ];
  const seen = new Set();
  const list = [];
  for (const [server, text] of groups) {
    for (const prefix of parsePrefixes(text)) {
      const key = prefix.toLowerCase();
      if (seen.has(key)) continue;   // 同一个前缀只归第一个声明它的服务器
      seen.add(key);
      list.push({ prefix: key, server });
    }
  }
  // 长前缀优先：同时配了 `jita` 和 `jita2` 时，`jita2 xxx` 要认 `jita2`。
  // 等长时按键名排序，保证同一个输入永远得到同一个结果（排序必须稳定，否则
  // 群友每次问同一句话可能得到不同结果）。
  return list.sort((a, b) => (b.prefix.length - a.prefix.length)
    || a.prefix.localeCompare(b.prefix, 'en'));
}

/**
 * 从候选文本里认出地点 key。
 *
 * 三级判断，全都是"认得出才用"，认不出返回 null（由调用方回退到 FALLBACK_HUB）：
 *   1. 整串就是地点名              → amarr
 *   2. 剥掉开头一个标记字母后是     → oamarr → amarr、ojita → jita
 *   3. 剥完前缀剩下的那截是空的      → 那就拿前缀自己再试一遍（第 2 条）
 */
function pickLocation(rest, prefix, loctable) {
  for (const candidate of [rest, prefix]) {
    if (!candidate) continue;
    const s = String(candidate).toLowerCase().replace(/\s+/g, '');
    if (!s) continue;
    if (loctable[s]) return s;
    for (const mark of DEFAULT_MARKS) {
      if (!s.startsWith(mark)) continue;
      const inner = s.slice(mark.length);
      if (inner && loctable[inner]) return inner;
    }
  }
  return null;
}

/**
 * 从群友原话里认出服务器（和可能的地点），并返回**剥掉指令前缀后**的剩余文本。
 *
 * 只剥**词首**出现的前缀：「ojita 三钛合金」→「三钛合金」。
 * 前缀在中间时不剥 —— 无法可靠区分"指令"和"物品名的一部分"，
 * 宁可让搜索多带一个词，也不误删物品名里的字。
 *
 * @param {string} query 群友原话（或模型给的 item）
 * @param {Array} prefixes buildPrefixes() 的结果
 * @param {object} loctable 地点对照表（由调用方从 esi.js 传入，避免这里强依赖）
 * @returns {{prefix:string, server:string, location:string|null, rest:string}|null}
 */
export function matchPrefix(query, prefixes, loctable = {}) {
  const text = String(query ?? '').trim();
  if (!text) return null;
  const lower = text.toLowerCase();

  for (const p of prefixes ?? []) {
    if (!p?.prefix || !lower.startsWith(p.prefix)) continue;
    const rest = text.slice(p.prefix.length).trim();
    // 认地点要试两截：剥完前缀剩下的（'ojita 三钛合金' → ''）和前缀本身（'ojita'）。
    // ⚠️ 两截都要试 —— 前缀自己就是完整地点词时（jita/ojita），剩下那截是空的，
    //    只试它会一律得到 null（实测踩过）。
    const location = pickLocation(rest, p.prefix, loctable);
    return { prefix: p.prefix, server: p.server, location, rest: rest || p.prefix };
  }
  return null;
}

/** 给模型看的提示串：写进工具参数描述里，模型才知道前缀对应哪个服务器。 */
export function describePrefixes(prefixes) {
  return (prefixes ?? []).map((p) => `${p.prefix}=${p.server}`).join('，');
}
