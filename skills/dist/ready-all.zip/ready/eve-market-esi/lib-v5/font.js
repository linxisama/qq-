// font.js —— 纯 JS 的 TrueType/TTC 字体解析 + 字形栅格化
//
// 只依赖 node:fs / node:buffer。没有第三方包。
//
// 为什么需要它：图上要写中文（物品名、「最高价」「成交量」…），而运行环境里
// 没有任何图像库、也不允许往磁盘落 .ps1/.exe。所以自己解析系统字体、自己光栅化。
//
// 覆盖到的表：head / maxp / hhea / hmtx / cmap(格式 4、6、12) / loca / glyf
//
// 实测可用的 Windows 字体（本机 Windows 10 19041）：
//   simhei.ttf       黑体      standalone TTF  upem=256   28562 字形
//   msyh.ttc         微软雅黑  TTC(2 个)       upem=2048  30209 字形
//   msyhbd.ttc       雅黑粗体  TTC              upem=2048
//   simsun.ttc       宋体      TTC(2 个)       upem=256   28905 字形
//   Deng.ttf         等线      standalone TTF  upem=2048  29624 字形
//   simkai.ttf       楷体      standalone TTF  upem=256   28562 字形
//   NotoSansSC-VF.ttf 思源黑 可变字体 TTF      upem=1000  31036 字形
// 全部能被本模块解析（见 README 的字体表）。

import fs from 'node:fs';

// ══════════════════════════════════════════════════════════════════════
//  一、SFNT 容器解析
// ══════════════════════════════════════════════════════════════════════

/** 一个 sfnt（TrueType）字体。TTC 里每个子字体各是一个 Font。 */
export class Font {
  /**
   * @param {Buffer} buf 整个字体文件
   * @param {number} off 该子字体的 offset table 在文件中的偏移（TTC 用）
   * @param {string} label 诊断用名字
   * @param {number} index TTC 内的索引
   */
  constructor(buf, off, label, index = 0) {
    this.buf = buf;
    this.label = label;
    this.index = index;
    this.file = label;

    this.sfntVersion = buf.toString('latin1', off, off + 4);
    this.numTables = buf.readUInt16BE(off + 4);

    /** @type {Record<string,{offset:number,length:number}>} */
    this.tables = {};
    for (let i = 0; i < this.numTables; i++) {
      const p = off + 12 + i * 16;
      const tag = buf.toString('latin1', p, p + 4);
      this.tables[tag] = { offset: buf.readUInt32BE(p + 8), length: buf.readUInt32BE(p + 12) };
    }

    // 'OTTO' = CFF/PostScript 轮廓，没有 glyf 表；本模块只做 TrueType 轮廓。
    this.hasGlyf = !!this.tables.glyf;
    this.isTrueType = this.sfntVersion !== 'OTTO' && this.hasGlyf;

    this._parseHead();
    this._parseMaxp();
    this._parseHhea();
    this._parseCmap();

    // 字形位图缓存：key = `${gid}|${size}|${angle}`。
    // 这是**性能关键**：一张图里字形高度重复（365 个日期、刻度的数字、固定标签），
    // 实测 456 个字形只对应 78 个不同的 (gid,size,angle)。加缓存前文字部分 293ms，
    // 加缓存后同一批字形 3ms（72x）。
    this._maskCache = new Map();
    this._cacheHits = 0;
    this._cacheMisses = 0;
  }

  has(tag) { return !!this.tables[tag]; }

  _parseHead() {
    const t = this.tables.head;
    if (!t) throw new Error('缺 head 表');
    const b = this.buf, o = t.offset;
    this.unitsPerEm = b.readUInt16BE(o + 18);
    this.indexToLocFormat = b.readInt16BE(o + 50);
    this.xMin = b.readInt16BE(o + 36);
    this.yMin = b.readInt16BE(o + 38);
    this.xMax = b.readInt16BE(o + 40);
    this.yMax = b.readInt16BE(o + 42);
    if (!(this.unitsPerEm > 0)) throw new Error(`head.unitsPerEm 非法: ${this.unitsPerEm}`);
  }

  _parseMaxp() {
    const t = this.tables.maxp;
    if (!t) throw new Error('缺 maxp 表');
    this.numGlyphs = this.buf.readUInt16BE(t.offset + 4);
    if (!(this.numGlyphs > 0)) throw new Error(`maxp.numGlyphs 非法: ${this.numGlyphs}`);
  }

  _parseHhea() {
    const t = this.tables.hhea;
    if (!t) throw new Error('缺 hhea 表');
    const b = this.buf, o = t.offset;
    this.ascender = b.readInt16BE(o + 4);
    this.descender = b.readInt16BE(o + 6);
    this.numberOfHMetrics = b.readUInt16BE(o + 34);
    this.lineGap = b.readInt16BE(o + 8);
  }

  // ── cmap：格式 4 / 6 / 12 ──────────────────────────────────────────
  //
  // 格式 4 是 BMP（U+0000..U+FFFF）的段映射，Windows 上几乎所有老字体都有。
  // 格式 12 是 UCS-4（含增补平面），微软雅黑/等线/思源黑体都有。
  // 中文字符都在 BMP 内，所以格式 4 就够；但有格式 12 时优先用它（覆盖更全）。
  _parseCmap() {
    const t = this.tables.cmap;
    if (!t) throw new Error('缺 cmap 表');
    const b = this.buf, o = t.offset;
    const n = b.readUInt16BE(o + 2);

    /** @type {Array<{platformID:number,encodingID:number,format:number,offset:number}>} */
    this.cmapSubtables = [];
    for (let i = 0; i < n; i++) {
      const p = o + 4 + i * 8;
      const platformID = b.readUInt16BE(p);
      const encodingID = b.readUInt16BE(p + 2);
      const subOff = o + b.readUInt32BE(p + 4);
      if (subOff + 2 > b.length) continue;
      this.cmapSubtables.push({ platformID, encodingID, format: b.readUInt16BE(subOff), offset: subOff });
    }

    // 打分挑最优子表：Win(3)/UCS-4(10) fmt12 > 其他 fmt12 > Win(3)/BMP(1) fmt4 > 其余
    const score = (s) => {
      if (s.format === 12) return (s.platformID === 3 && s.encodingID === 10) ? 100 : 90;
      if (s.format === 4) return (s.platformID === 3 && s.encodingID === 1) ? 80 : (s.platformID === 0 ? 70 : 60);
      if (s.format === 6) return 40;
      return 10;
    };
    this.cmapSubtables.sort((a, b2) => score(b2) - score(a));
    this.bestCmap = this.cmapSubtables[0] || null;

    /** @type {Map<number,number>} 码点 -> gid */
    this.cmap = new Map();
    if (!this.bestCmap) throw new Error('cmap 里没有可用的子表');
    if (this.bestCmap.format === 4) this._buildCmap4(this.bestCmap.offset);
    else if (this.bestCmap.format === 12) this._buildCmap12(this.bestCmap.offset);
    else if (this.bestCmap.format === 6) this._buildCmap6(this.bestCmap.offset);
    else throw new Error(`不支持的 cmap 格式 ${this.bestCmap.format}`);
  }

  _buildCmap4(o) {
    const b = this.buf;
    const segCount = b.readUInt16BE(o + 6) / 2;
    const endO = o + 14;
    const startO = endO + segCount * 2 + 2;   // +2 跳过 reservedPad
    const deltaO = startO + segCount * 2;
    const rangeO = deltaO + segCount * 2;
    const map = this.cmap;

    for (let s = 0; s < segCount; s++) {
      const end = b.readUInt16BE(endO + s * 2);
      const start = b.readUInt16BE(startO + s * 2);
      const delta = b.readInt16BE(deltaO + s * 2);
      const rangeOffset = b.readUInt16BE(rangeO + s * 2);
      if (start === 0xffff) continue;          // 规范要求的结尾段
      for (let c = start; c <= end && c <= 0xfffe; c++) {
        let gid;
        if (rangeOffset === 0) {
          gid = (c + delta) & 0xffff;
        } else {
          // ⚠️ idRangeOffset 是**相对于它自己那个槽位的字节偏移**，不是相对于表头。
          //    写错这里会读到完全无关的字节，表现为"部分汉字映射到乱码字形"。
          const gi = rangeO + s * 2 + rangeOffset + (c - start) * 2;
          if (gi + 1 >= b.length) continue;
          gid = b.readUInt16BE(gi);
          if (gid !== 0) gid = (gid + delta) & 0xffff;
        }
        if (gid !== 0) map.set(c, gid);
      }
    }
  }

  _buildCmap12(o) {
    const b = this.buf;
    const nGroups = b.readUInt32BE(o + 12);
    for (let g = 0; g < nGroups; g++) {
      const p = o + 16 + g * 12;
      const sc = b.readUInt32BE(p), ec = b.readUInt32BE(p + 4), sg = b.readUInt32BE(p + 8);
      for (let c = sc; c <= ec; c++) this.cmap.set(c, sg + (c - sc));
    }
  }

  _buildCmap6(o) {
    const b = this.buf;
    const first = b.readUInt16BE(o + 6), count = b.readUInt16BE(o + 8);
    for (let i = 0; i < count; i++) {
      const gid = b.readUInt16BE(o + 10 + i * 2);
      if (gid) this.cmap.set(first + i, gid);
    }
  }

  /** 码点 -> 字形 id（0 = .notdef / 未映射） */
  glyphId(cp) { return this.cmap.get(cp) ?? 0; }

  // ── loca / glyf ───────────────────────────────────────────────────
  _loca(gid) {
    const t = this.tables.loca;
    if (!t) throw new Error('缺 loca 表（CFF/OTF 字体没有 glyf）');
    // ⚠️ indexToLocFormat 0 = 短格式（uint16，值要 ×2），1 = 长格式（uint32）。
    //    搞反了会读到完全错位的字形数据。
    return this.indexToLocFormat === 0
      ? this.buf.readUInt16BE(t.offset + gid * 2) * 2
      : this.buf.readUInt32BE(t.offset + gid * 4);
  }

  /**
   * 水平前进宽度（字体单位）。gid 超过 numberOfHMetrics 时，规范规定所有
   * 后续字形共用最后一条 metric —— 中文字体常见（SimHei 只有 855 条 metric
   * 但有 28562 个字形，全部 CJK 共用第 855 条 = 256 units = 全宽）。
   */
  advanceWidth(gid) {
    const t = this.tables.hmtx;
    if (!t) return this.unitsPerEm;
    const n = Math.max(1, this.numberOfHMetrics);
    return this.buf.readUInt16BE(t.offset + Math.min(gid, n - 1) * 4);
  }

  /**
   * 取一个码点的轮廓。
   * @returns {{gid:number,contours:Array<Array<{x:number,y:number,on:boolean}>>,
   *            xMin:number,yMin:number,xMax:number,yMax:number,
   *            advance:number,compound:boolean,empty:boolean}}
   */
  glyphFor(cp) {
    const gid = this.glyphId(cp);
    const g = this._outline(gid, 0);
    return { gid, ...g };
  }

  _outline(gid, depth) {
    if (depth > 6) throw new Error(`复合字形嵌套过深 (gid=${gid})`);   // 防自引用死循环
    const g = this.tables.glyf;
    if (!g) throw new Error('缺 glyf 表');
    const advance = this.advanceWidth(gid);
    const start = this._loca(gid), end = this._loca(gid + 1);

    // 空字形（空格、零宽字符）：loca 里长度为 0
    if (end <= start) {
      return { contours: [], xMin: 0, yMin: 0, xMax: 0, yMax: 0, advance, compound: false, empty: true };
    }

    const o = g.offset + start;
    const numberOfContours = this.buf.readInt16BE(o);
    const xMin = this.buf.readInt16BE(o + 2), yMin = this.buf.readInt16BE(o + 4);
    const xMax = this.buf.readInt16BE(o + 6), yMax = this.buf.readInt16BE(o + 8);

    // numberOfContours < 0 => 复合字形（带音标的拉丁字母、部分 CJK 兼容字）
    if (numberOfContours < 0) {
      return this._compound(o, xMin, yMin, xMax, yMax, advance, depth);
    }
    return {
      contours: this._simple(o, numberOfContours),
      xMin, yMin, xMax, yMax, advance, compound: false, empty: false,
    };
  }

  _simple(o, nContours) {
    const b = this.buf;
    let p = o + 10;

    const endPts = [];
    for (let i = 0; i < nContours; i++) { endPts.push(b.readUInt16BE(p)); p += 2; }
    const nPts = nContours > 0 ? endPts[nContours - 1] + 1 : 0;

    const instructionLength = b.readUInt16BE(p); p += 2;
    p += instructionLength;            // 跳过 hinting 指令：我们做的是无 hint 的轮廓光栅化

    // flags：0x08 = REPEAT，表示"这一个 flag 重复 N 次"
    const flags = new Uint8Array(nPts);
    for (let i = 0; i < nPts;) {
      const f = b[p++];
      flags[i++] = f;
      if (f & 0x08) {
        let r = b[p++];
        while (r-- > 0 && i < nPts) flags[i++] = f;
      }
    }

    // x 坐标：增量编码。0x02=X_SHORT（1 字节），0x10=正负号（配合 X_SHORT 表示正；
    // 不配合 X_SHORT 时表示"与上一个 x 相同"）。
    const xs = new Int32Array(nPts);
    let x = 0;
    for (let i = 0; i < nPts; i++) {
      const f = flags[i];
      if (f & 0x02) {
        const d = b[p++];
        x += (f & 0x10) ? d : -d;
      } else if (!(f & 0x10)) {
        x += b.readInt16BE(p); p += 2;
      }
      xs[i] = x;
    }

    const ys = new Int32Array(nPts);
    let y = 0;
    for (let i = 0; i < nPts; i++) {
      const f = flags[i];
      if (f & 0x04) {
        const d = b[p++];
        y += (f & 0x20) ? d : -d;
      } else if (!(f & 0x20)) {
        y += b.readInt16BE(p); p += 2;
      }
      ys[i] = y;
    }

    const contours = [];
    let s = 0;
    for (let c = 0; c < nContours; c++) {
      const e = endPts[c];
      const pts = [];
      for (let i = s; i <= e; i++) pts.push({ x: xs[i], y: ys[i], on: (flags[i] & 0x01) !== 0 });
      contours.push(pts);
      s = e + 1;
    }
    return contours;
  }

  /**
   * 复合字形：由若干组件（各带 2x2 变换 + 偏移）拼成。
   * ⚠️ 这里**只应用平移**，忽略缩放/旋转矩阵 —— 中文字体里的复合字形基本都是
   *    纯平移拼装（部件叠加），照搬足够。若哪天遇到靠缩放拼的字（某些藏文/阿拉伯文），
   *    字形会明显偏大或偏小，到时候再把 0x0008/0x0040/0x0080 三个分支补上。
   */
  _compound(o, xMin, yMin, xMax, yMax, advance, depth) {
    const b = this.buf;
    let p = o + 10;
    const contours = [];
    for (;;) {
      const flags = b.readUInt16BE(p);
      const glyphIndex = b.readUInt16BE(p + 2);
      p += 4;

      let dx, dy;
      if (flags & 0x0001) { dx = b.readInt16BE(p); dy = b.readInt16BE(p + 2); p += 4; }   // ARG_1_AND_2_ARE_WORDS
      else { dx = b.readInt8(p); dy = b.readInt8(p + 1); p += 2; }

      if (flags & 0x0008) p += 2;        // WE_HAVE_A_SCALE
      else if (flags & 0x0040) p += 4;   // WE_HAVE_AN_X_AND_Y_SCALE
      else if (flags & 0x0080) p += 8;   // WE_HAVE_A_TWO_BY_TWO

      try {
        const sub = this._outline(glyphIndex, depth + 1);
        for (const c of sub.contours) {
          contours.push(c.map((q) => ({ x: q.x + dx, y: q.y + dy, on: q.on })));
        }
      } catch { /* 坏组件就跳过，别让整个字形挂掉 */ }

      if (!(flags & 0x0020)) break;      // MORE_COMPONENTS
    }
    return { contours, xMin, yMin, xMax, yMax, advance, compound: true, empty: contours.length === 0 };
  }

  // ══════════════════════════════════════════════════════════════════
  //  二、字形位图（带缓存）
  // ══════════════════════════════════════════════════════════════════

  /**
   * 取一个码点的**覆盖率位图**，原点在 (0,0)、基线在 y=0、笔位置在 x=0，
   * 已按 angle 绕原点旋转。返回的是整数包围盒内的小位图，可直接 blit。
   *
   * 相同 (gid, size, angle) 会命中缓存 —— 这是文字渲染的主要加速来源。
   *
   * @returns {{mask:Uint8Array,x:number,y:number,w:number,h:number}|null}
   *          null 表示空字形（空格等）
   */
  glyphMask(cp, sizePx, angle = 0) {
    const gid = this.glyphId(cp);
    if (!gid) return null;
    const key = gid + '|' + sizePx.toFixed(2) + '|' + angle.toFixed(4);
    const hit = this._maskCache.get(key);
    if (hit !== undefined) { this._cacheHits++; return hit; }

    this._cacheMisses++;
    let m = null;
    try {
      const g = this._outline(gid, 0);
      if (!g.empty && g.contours.length) {
        const sc = sizePx / this.unitsPerEm;
        let paths = flattenContours(g.contours, sc, 0, 0);
        if (angle !== 0) paths = rotatePaths(paths, angle);
        m = fillPaths(paths, 4);
      }
    } catch {
      m = null;                       // 单个字形失败不该炸掉整张图
    }
    this._maskCache.set(key, m);
    return m;
  }

  /** 单个码点的前进宽度（像素） */
  advance(cp, sizePx) {
    const gid = this.glyphId(cp);
    const u = gid ? this.advanceWidth(gid) : this.unitsPerEm;
    return u * sizePx / this.unitsPerEm;
  }

  /** 字串宽度（像素）。空格按 0.3em 估。 */
  measure(text, sizePx) {
    let w = 0;
    for (const ch of text) {
      if (ch === ' ') { w += sizePx * 0.3; continue; }
      w += this.advance(ch.codePointAt(0), sizePx);
    }
    return w;
  }

  /** 行高（像素）：GDI+ 的 Font.GetHeight 近似 —— (ascender - descender + lineGap) 缩放 */
  lineHeight(sizePx) {
    const u = this.ascender - this.descender + (this.lineGap || 0);
    return u * sizePx / this.unitsPerEm;
  }

  /**
   * 基线相对"版面顶"的偏移（像素）。
   * GDI+ 的 DrawString(text, font, brush, x, y) 把**版面框左上角**放在 (x,y)，
   * 而本模块按**基线**定位，所以要加这个偏移。
   * 实测（SimHei 64px，与 GDI+ 逐像素比对）用 hhea.ascender 换算能对上：
   *   baseline = top + ascender/upem*size
   */
  ascent(sizePx) { return this.ascender * sizePx / this.unitsPerEm; }

  /**
   * 把一个字符串画进位图目标。
   *
   * @param {{width:number,height:number,raw:Buffer,rowOff:(y:number)=>number}} target
   *        任何提供 raw + rowOff(y) 的画布（png.js 的 Canvas 就是）
   * @param {string} text
   * @param {number} sizePx  字号（像素，= 字体的 em 尺寸）
   * @param {number} x       版面框左上角 x（旋转时是旋转中心）
   * @param {number} y       版面框左上角 y（旋转时是旋转中心）
   * @param {number[]} rgb   [r,g,b]
   * @param {{angle?:number, alpha?:number, maskAlpha?:number}} [opts]
   *        angle: 弧度，画布 y 向下，负值 = 向右上倾斜（对应 GDI+ RotateTransform(-45)）
   *        maskAlpha: >0 时先在文字底下垫一层白色底衬（斜排日期需要，否则网格线穿透）
   * @returns {number} 实际着色的像素数（诊断用）
   */
  drawText(target, text, sizePx, x, y, rgb, opts = {}) {
    const angle = opts.angle || 0;
    const alpha = opts.alpha == null ? 1 : opts.alpha;
    const ca = Math.cos(angle), sa = Math.sin(angle);
    const ascent = this.ascent(sizePx);
    const [cr, cg, cb] = rgb;

    // 白色底衬：局部坐标里的一个矩形，随文字一起旋转
    if (opts.maskAlpha > 0) {
      const w = this.measure(text, sizePx);
      const pad = sizePx * 0.10;
      const local = rectPath(-pad, -ascent - pad, w + pad * 2, ascent + sizePx * 0.30 + pad * 2);
      paintMask(target, rotatePaths([local], angle), x, y,
        [255, 255, 255], opts.maskAlpha, 2);
    }

    let penX = 0;
    let painted = 0;
    for (const ch of text) {
      if (ch === ' ') { penX += sizePx * 0.3; continue; }
      const cp = ch.codePointAt(0);
      const m = this.glyphMask(cp, sizePx, angle);
      if (m) {
        // 笔位置沿（旋转后的）基线方向前进；基线本身还要从版面顶下沉 ascent
        const ax = penX * ca - ascent * sa;
        const ay = penX * sa + ascent * ca;
        // ⚠️ 必须加 m.x / m.y —— 那是覆盖率位图相对"字形原点"的偏移。
        //    glyphMask 返回的是**包围盒裁剪过**的小位图，它的 (0,0) 并不对应字形原点：
        //      · m.y 一般是负数（字形在基线之上，而位图左上角在 bbox 顶）
        //      · m.x 是左边距，对全角标点可以大到 20px（如 '（' 的 m.x=19）
        //    漏加 m.y 的后果：整行字**整体下沉约一个 ascent**，看起来"全部掉到基线下面、
        //    底部被裁掉"；漏加 m.x 的后果：标点挤向左侧。这两个都是很隐蔽的排版错误 ——
        //    字形本身完全正常，只有位置不对，单看 mask dump 根本发现不了。
        painted += blitMask(target, m,
          Math.round(x + ax) + m.x, Math.round(y + ay) + m.y,
          cr, cg, cb, alpha);
      }
      penX += this.advance(cp, sizePx);
    }
    return painted;
  }

  cacheStats() {
    return {
      entries: this._maskCache.size,
      hits: this._cacheHits,
      misses: this._cacheMisses,
      hitRate: (this._cacheHits + this._cacheMisses) > 0
        ? this._cacheHits / (this._cacheHits + this._cacheMisses) : 0,
    };
  }

  clearCache() { this._maskCache.clear(); this._cacheHits = 0; this._cacheMisses = 0; }
}

// ══════════════════════════════════════════════════════════════════════
//  三、打开文件 / TTC 选字体 / 回退链
// ══════════════════════════════════════════════════════════════════════

/** 解析字体文件（TTF 或 TTC），返回所有子字体。解析失败抛异常。 */
export function openContainer(buf, label = '<buffer>') {
  if (buf.length < 12) throw new Error('文件太小，不是字体');
  const tag = buf.toString('latin1', 0, 4);

  if (tag === 'ttcf') {
    // TTC：'ttcf' + version(4) + numFonts(4) + offsets[numFonts](4 each)
    const numFonts = buf.readUInt32BE(8);
    if (numFonts <= 0 || numFonts > 64) throw new Error(`TTC numFonts 非法: ${numFonts}`);
    const fonts = [];
    for (let i = 0; i < numFonts; i++) {
      const off = buf.readUInt32BE(12 + i * 4);
      if (off + 12 > buf.length) continue;
      try { fonts.push(new Font(buf, off, label, i)); } catch { /* 跳过坏子字体 */ }
    }
    if (!fonts.length) throw new Error('TTC 里没有可解析的子字体');
    return { kind: 'TTC', numFonts, fonts };
  }

  // 单字体：'true' / 0x00010000 / 'OTTO'
  return { kind: 'TTF', numFonts: 1, fonts: [new Font(buf, 0, label, 0)] };
}

/** 用来判断"这个字体到底能不能写中文"的探针字符（覆盖常用字 + 数字 + 拉丁） */
const CJK_PROBE = '最高价成交量日期钛合金0123456789ABC';

function pickUsableFont(container, { requireCJK = true } = {}) {
  let lastErr = null;
  for (const f of container.fonts) {
    try {
      if (!f.isTrueType) throw new Error(`非 TrueType 轮廓 (sfntVersion=${JSON.stringify(f.sfntVersion)})，CFF/OTF 不支持`);
      if (requireCJK) {
        let mapped = 0;
        for (const ch of CJK_PROBE) if (f.glyphId(ch.codePointAt(0))) mapped++;
        // 中文字体应该几乎全命中；命不中说明 cmap 选错或字体不含中文
        if (mapped < CJK_PROBE.length * 0.8) throw new Error(`cmap 只映射了 ${mapped}/${CJK_PROBE.length} 个探针字符，可能不含中文`);
      }
      return f;
    } catch (e) {
      lastErr = e;
    }
  }
  throw lastErr || new Error('没有可用的子字体');
}

/**
 * 加载字体。传文件路径或 Buffer 都行。
 * @param {string|Buffer} pathOrBuffer
 * @param {{index?:number, requireCJK?:boolean}} [opts]
 * @returns {Font}
 */
export function loadFont(pathOrBuffer, opts = {}) {
  let buf, label;
  if (typeof pathOrBuffer === 'string') {
    buf = fs.readFileSync(pathOrBuffer);
    label = pathOrBuffer;
  } else {
    buf = pathOrBuffer;
    label = opts.label || '<buffer>';
  }
  const container = openContainer(buf, label);
  if (opts.index != null) {
    const f = container.fonts.find((x) => x.index === opts.index);
    if (!f) throw new Error(`${label}: TTC 里没有 index=${opts.index}`);
    return f;
  }
  return pickUsableFont(container, opts);
}

/**
 * 默认字体回退链。存在且能解析的**第一个**被采用。
 * 顺序考虑：雅黑最好看 -> 雅黑粗体 -> 黑体（standalone TTF，最省事最稳）
 *          -> 宋体 -> 等线 -> 思源黑（可变字体，取默认实例）
 */
export const DEFAULT_FONT_CHAIN = [
  'C:\\Windows\\Fonts\\msyh.ttc',          // 微软雅黑
  'C:\\Windows\\Fonts\\msyhbd.ttc',        // 微软雅黑 Bold
  'C:\\Windows\\Fonts\\simhei.ttf',        // 黑体（standalone TTF）
  'C:\\Windows\\Fonts\\simsun.ttc',        // 宋体
  'C:\\Windows\\Fonts\\Deng.ttf',          // 等线
  'C:\\Windows\\Fonts\\NotoSansSC-VF.ttf', // 思源黑体（可变字体，用默认实例）
];

/**
 * 按回退链加载字体。**任何一个候选失败都静默跳到下一个**，
 * 并返回完整的尝试记录，方便调用方诊断（而不是抛一个"字体加载失败"了事）。
 *
 * @param {Array<string|{path:string,index?:number}>} [chain]
 * @returns {{font:Font, picked:string, tried:Array<{path:string,ok:boolean,reason?:string,upem?:number,glyphs?:number}>}}
 * @throws 全部失败时抛出，错误信息里列出每个候选的失败原因
 */
export function loadFontChain(chain = DEFAULT_FONT_CHAIN) {
  const tried = [];
  for (const entry of chain) {
    const spec = typeof entry === 'string' ? { path: entry } : entry;
    const rec = { path: spec.path, ok: false };
    try {
      if (!fs.existsSync(spec.path)) {
        rec.reason = '文件不存在';
        tried.push(rec);
        continue;
      }
      const buf = fs.readFileSync(spec.path);
      const container = openContainer(buf, spec.path);
      let font = null, lastErr = null;

      const candidates = spec.index != null
        ? container.fonts.filter((f) => f.index === spec.index)
        : container.fonts;

      for (const f of candidates) {
        try {
          if (!f.isTrueType) throw new Error(`非 TrueType 轮廓（${JSON.stringify(f.sfntVersion)}），跳过`);
          let mapped = 0;
          for (const ch of CJK_PROBE) if (f.glyphId(ch.codePointAt(0))) mapped++;
          if (mapped < CJK_PROBE.length * 0.8) {
            throw new Error(`cmap 未覆盖中文（探针 ${mapped}/${CJK_PROBE.length}）`);
          }
          font = f;
          break;
        } catch (e) { lastErr = e; }
      }
      if (!font) throw lastErr || new Error('没有可用子字体');

      rec.ok = true;
      rec.index = font.index;
      rec.container = container.kind;
      rec.upem = font.unitsPerEm;
      rec.glyphs = font.numGlyphs;
      rec.cmapFormat = font.bestCmap ? font.bestCmap.format : 0;
      tried.push(rec);
      return { font, picked: spec.path, tried };
    } catch (e) {
      rec.reason = e.message;
      tried.push(rec);
    }
  }

  const detail = tried.map((t) => `  ${t.path}  ->  ${t.ok ? 'OK' : t.reason}`).join('\n');
  throw new Error(`没有找到可用的中文字体。候选逐个尝试结果：\n${detail}`);
}

// ══════════════════════════════════════════════════════════════════════
//  四、轮廓 -> 折线（二次贝塞尔展平）
// ══════════════════════════════════════════════════════════════════════

/**
 * TrueType 二次样条展平。返回**已闭合**的折线数组（首尾点相同）。
 *
 * ⚠️⚠️ 这里有个非常隐蔽的坑，本项目实际踩过：
 *
 * TrueType 允许**连续两个 off-curve 点**，此时"两点的中点"是一个隐含的 on-curve 点。
 * 更极端的是**整个轮廓全部都是 off-curve 点** —— SimHei 的 '0' 就是这样
 * （2 个轮廓、12+10 个点、on-curve 数 = 0）。
 *
 * 如果按"找第一个 on-curve 点当起点，找不到就退回 index 0"来写，就会把一个
 * off-curve 点当成锚点，整条轮廓**系统性变形**。现象极具迷惑性：
 * '0' 被画成"上面一个三角 + 下面一个碗"，但字宽、字距、包围盒全都正常，
 * 只有肉眼盯着放大图才看得出来（我当时是靠 6x 放大才发现的）。
 *
 * 正确做法分三步：
 *   1) 规范化：在每一对相邻 off-curve 点之间插入中点（含首尾环绕）；
 *   2) 旋转到某个 on-curve 点作为起点（规范化后必然存在）；
 *   3) 走 on -> (off -> on) 的二次贝塞尔，最后**显式闭合**。
 *
 * 第 3 步的显式闭合也不能省：扫描线填充是按"相邻点连线 + 收尾闭合边"建的边表，
 * 漏掉闭合边会让轮廓最后一段永远填不上（表现为字形缺一角）。
 */
export function flattenContours(contours, scale, ox, oy, stepsPerCurve = 12) {
  const paths = [];
  // 字体坐标 y 向上，画布 y 向下 -> 取负
  const P = (q) => [ox + q.x * scale, oy - q.y * scale];

  for (const raw of contours) {
    if (!raw || raw.length < 2) continue;

    // 1) 插入隐含中点，保证规范化后不存在相邻两个 off-curve 点
    const n = raw.length;
    const norm = [];
    for (let i = 0; i < n; i++) {
      const cur = raw[i], nxt = raw[(i + 1) % n];
      norm.push(cur);
      if (!cur.on && !nxt.on) {
        norm.push({ x: (cur.x + nxt.x) / 2, y: (cur.y + nxt.y) / 2, on: true });
      }
    }

    // 2) 旋转到某个 on-curve 点开头
    let s = -1;
    for (let i = 0; i < norm.length; i++) if (norm[i].on) { s = i; break; }
    if (s < 0) continue;
    const rot = norm.slice(s).concat(norm.slice(0, s));
    const len = rot.length;

    // 3) on -> (off -> on) 的二次贝塞尔
    const pts = [P(rot[0])];
    let i = 1;
    while (i < len) {
      const p = rot[i];
      if (p.on) { pts.push(P(p)); i++; continue; }
      const target = (i + 1 < len) ? rot[i + 1] : rot[0];   // 环绕回起点
      const p0 = pts[pts.length - 1], p1 = P(p), p2 = P(target);
      for (let k = 1; k <= stepsPerCurve; k++) {
        const t = k / stepsPerCurve, u = 1 - t;
        pts.push([
          u * u * p0[0] + 2 * u * t * p1[0] + t * t * p2[0],
          u * u * p0[1] + 2 * u * t * p1[1] + t * t * p2[1],
        ]);
      }
      i += 2;
    }

    // 4) 显式闭合
    const last = pts[pts.length - 1];
    if (last[0] !== pts[0][0] || last[1] !== pts[0][1]) pts.push([pts[0][0], pts[0][1]]);
    paths.push(pts);
  }
  return paths;
}

/** 绕原点旋转折线集合（画布坐标 y 向下，正角 = 顺时针） */
export function rotatePaths(paths, angle) {
  const ca = Math.cos(angle), sa = Math.sin(angle);
  return paths.map((p) => p.map(([x, y]) => [x * ca - y * sa, x * sa + y * ca]));
}

/** 平移折线集合 */
export function translatePaths(paths, tx, ty) {
  return paths.map((p) => p.map(([x, y]) => [x + tx, y + ty]));
}

/** 一个矩形（闭合折线），给底衬/柱状之类的用途 */
export function rectPath(x, y, w, h) {
  return [[x, y], [x + w, y], [x + w, y + h], [x, y + h], [x, y]];
}

/** 折线集合的包围盒 */
export function pathsBounds(paths) {
  let x0 = Infinity, y0 = Infinity, x1 = -Infinity, y1 = -Infinity;
  for (const p of paths) for (const [x, y] of p) {
    if (x < x0) x0 = x;
    if (x > x1) x1 = x;
    if (y < y0) y0 = y;
    if (y > y1) y1 = y;
  }
  return { x0, y0, x1, y1, w: x1 - x0, h: y1 - y0 };
}

// ══════════════════════════════════════════════════════════════════════
//  五、扫描线填充（nonzero winding）+ 超采样抗锯齿
// ══════════════════════════════════════════════════════════════════════
//
// 这是通用的"折线 -> 覆盖率位图"光栅化器，字形和普通多边形都用它
// （render.js 里价格区间那条填充带也走这里）。
//
// ⚠️ 另一个踩过的坑：**不要在收集边的时候把 (x0,y0)/(x1,y1) 交换成 y0<y1**。
// 交换之后 `y1 > y0` 恒为真，所有交点都被记成 +1 winding，nonzero 规则就退化成
// "每个轮廓都实心填充"—— 于是「日」变实心方块、「钛」变一坨黑、字形的封闭区域
// 全部丢失。范围判断要用 min/max，方向判断必须用**原始** y0/y1。

/**
 * @param {Array<Array<[number,number]>>} paths 闭合折线集合
 * @param {number} ss 超采样倍率
 * @param {number} pad 包围盒外扩（像素）
 * @returns {{mask:Uint8Array,x:number,y:number,w:number,h:number}|null}
 */
export function fillPaths(paths, ss = 4, pad = 1) {
  let bx0 = Infinity, by0 = Infinity, bx1 = -Infinity, by1 = -Infinity;
  for (const p of paths) for (const [x, y] of p) {
    if (x < bx0) bx0 = x;
    if (x > bx1) bx1 = x;
    if (y < by0) by0 = y;
    if (y > by1) by1 = y;
  }
  if (!(bx1 >= bx0) || !(by1 >= by0)) return null;

  const ox = Math.floor(bx0 - pad), oy = Math.floor(by0 - pad);
  const W = Math.ceil(bx1 + pad) - ox;
  const H = Math.ceil(by1 + pad) - oy;
  if (W <= 0 || H <= 0 || W > 16384 || H > 16384) return null;

  const SW = W * ss, SH = H * ss;

  // 边表（平移到 bbox 原点后乘 ss）
  const edges = [];
  for (const p of paths) {
    const np = p.length;
    if (np < 2) continue;
    for (let i = 0; i < np; i++) {
      const a = p[i], b = p[(i + 1) % np];        // 含收尾闭合边
      const x0 = (a[0] - ox) * ss, y0 = (a[1] - oy) * ss;
      const x1 = (b[0] - ox) * ss, y1 = (b[1] - oy) * ss;
      if (y0 === y1) continue;                   // 水平边不产生交点
      edges.push(x0, y0, x1, y1);
    }
  }
  if (!edges.length) return null;

  const cov = new Uint16Array(W * H);
  const nEdges = edges.length / 4;
  const xs = new Float64Array(nEdges);
  const dirs = new Int8Array(nEdges);
  const order = new Int32Array(nEdges);

  for (let sy = 0; sy < SH; sy++) {
    const yc = sy + 0.5;
    let cnt = 0;
    for (let e = 0; e < nEdges; e++) {
      const k = e * 4;
      const x0 = edges[k], y0 = edges[k + 1], x1 = edges[k + 2], y1 = edges[k + 3];
      const lo = y0 < y1 ? y0 : y1, hi = y0 < y1 ? y1 : y0;
      if (yc < lo || yc >= hi) continue;          // [lo,hi) 半开，避免顶点被算两次
      const t = (yc - y0) / (y1 - y0);
      xs[cnt] = x0 + t * (x1 - x0);
      dirs[cnt] = y1 > y0 ? 1 : -1;               // 方向必须用原始 y0/y1
      order[cnt] = cnt;
      cnt++;
    }
    if (cnt < 2) continue;

    // 按 x 插入排序（交点通常已经接近有序，插入排序在这种数据上最快）
    const ord = order.subarray(0, cnt);
    for (let i = 1; i < cnt; i++) {
      const oi = ord[i], xi = xs[oi];
      let j = i - 1;
      while (j >= 0 && xs[ord[j]] > xi) { ord[j + 1] = ord[j]; j--; }
      ord[j + 1] = oi;
    }

    const rowPix = ((sy / ss) | 0) * W;
    let wind = 0;
    for (let i = 0; i + 1 < cnt; i++) {
      wind += dirs[ord[i]];
      if (wind === 0) continue;
      const xa = xs[ord[i]], xb = xs[ord[i + 1]];
      let pa = Math.ceil(xa - 0.5);
      if (pa < 0) pa = 0;
      let pb = Math.floor(xb - 0.5);
      if (pb > SW - 1) pb = SW - 1;
      for (let px = pa; px <= pb; px++) {
        const idx = rowPix + ((px / ss) | 0);
        if (cov[idx] < 255) cov[idx]++;
      }
    }
  }

  const maxC = ss * ss;
  const mask = new Uint8Array(W * H);
  let any = false;
  for (let i = 0; i < W * H; i++) {
    const c = cov[i];
    if (!c) continue;
    any = true;
    mask[i] = c >= maxC ? 255 : Math.round((c / maxC) * 255);
  }
  return any ? { mask, x: ox, y: oy, w: W, h: H } : null;
}

// ══════════════════════════════════════════════════════════════════════
//  六、位图 blit
// ══════════════════════════════════════════════════════════════════════

/**
 * 把覆盖率位图 source-over 到目标画布。
 * 直接操作 target.raw + target.rowOff(y)，不做逐像素方法调用。
 */
export function blitMask(target, m, x, y, r, g, b, alpha = 1) {
  const W = target.width, H = target.height;
  let painted = 0;
  for (let yy = 0; yy < m.h; yy++) {
    const cy = y + yy;
    if (cy < 0 || cy >= H) continue;
    const base = target.rowOff(cy);
    const srcRow = yy * m.w;
    for (let xx = 0; xx < m.w; xx++) {
      let a = m.mask[srcRow + xx] / 255;
      if (a <= 0) continue;
      const cx = x + xx;
      if (cx < 0 || cx >= W) continue;
      a *= alpha;
      painted++;
      const i = base + cx * 4, ia = 1 - a;
      target.raw[i] = (target.raw[i] * ia + r * a + 0.5) | 0;
      target.raw[i + 1] = (target.raw[i + 1] * ia + g * a + 0.5) | 0;
      target.raw[i + 2] = (target.raw[i + 2] * ia + b * a + 0.5) | 0;
    }
  }
  return painted;
}

/** 光栅化折线集合后直接画到目标画布（填充多边形用） */
export function paintPaths(target, paths, rgb, alpha = 1, ss = 4) {
  const m = fillPaths(paths, ss);
  if (!m) return 0;
  return blitMask(target, m, m.x, m.y, rgb[0], rgb[1], rgb[2], alpha);
}

// ══════════════════════════════════════════════════════════════════════
//  七、抗锯齿折线（距离场法）
// ══════════════════════════════════════════════════════════════════════

/**
 * 用"每像素到线段的距离"做抗锯齿描边。
 *
 * 为什么用距离场而不是扫描线：折线有 round join/cap、宽度只有 2px，
 * 扫描线填充要处理斜接/圆角，代码多还容易在接缝处露白。距离场法对每个线段
 * 取包围盒、盒内逐像素算距离、按覆盖率混合，天然带圆角、天然抗锯齿，
 * 而且**线段之间不会互相覆盖出深色接缝**（重叠处 source-over 会加深，
 * 但 2px 线在整数网格上重叠极少，实测看不出来）。
 *
 * 性能关键：先用**平方距离**剔除，只有落在带内的像素才开 sqrt。
 * 实测 1630x900、365 点 x 3 条线：15~38ms（1087 个线段段）。
 *
 * @param {import('./png.js').Canvas} target
 * @param {Array<[number,number]|null>} pts 允许 null（缺测断开）
 */
export function strokePolyline(target, pts, rgb, lineWidth, alpha = 1) {
  const [r, g, b] = rgb;
  const half = lineWidth / 2;
  const rMax = half + 0.5, rMax2 = rMax * rMax;
  const W = target.width, H = target.height;

  for (let s = 0; s + 1 < pts.length; s++) {
    const a = pts[s], c = pts[s + 1];
    if (!a || !c) continue;
    const x0 = a[0], y0 = a[1], x1 = c[0], y1 = c[1];
    const dx = x1 - x0, dy = y1 - y0, len2 = dx * dx + dy * dy;

    const minX = Math.max(0, Math.floor(Math.min(x0, x1) - rMax));
    const maxX = Math.min(W - 1, Math.ceil(Math.max(x0, x1) + rMax));
    const minY = Math.max(0, Math.floor(Math.min(y0, y1) - rMax));
    const maxY = Math.min(H - 1, Math.ceil(Math.max(y0, y1) + rMax));

    for (let py = minY; py <= maxY; py++) {
      const outRow = target.rowOff(py);
      const cy = py + 0.5 - y0;
      for (let px = minX; px <= maxX; px++) {
        const cx = px + 0.5 - x0;
        let t = len2 > 0 ? (cx * dx + cy * dy) / len2 : 0;
        if (t < 0) t = 0; else if (t > 1) t = 1;
        const ex = cx - t * dx, ey = cy - t * dy;
        const d2 = ex * ex + ey * ey;
        if (d2 >= rMax2) continue;
        const cov = (rMax - Math.sqrt(d2)) * alpha;
        if (cov <= 0) continue;
        const i = outRow + px * 4, ia = 1 - cov;
        target.raw[i] = (target.raw[i] * ia + r * cov + 0.5) | 0;
        target.raw[i + 1] = (target.raw[i + 1] * ia + g * cov + 0.5) | 0;
        target.raw[i + 2] = (target.raw[i + 2] * ia + b * cov + 0.5) | 0;
      }
    }
  }
}
