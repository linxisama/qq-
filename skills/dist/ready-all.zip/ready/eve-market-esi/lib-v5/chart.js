// 走势图：把 ESI 的逐日历史画成 PNG。
//
// ───────────────── 为什么现在才做得成 ─────────────────
//
// 这个功能之前删掉过一次，因为当时的数据源（ceve-market）**给不出逐日历史**：
// 它只保留约 80 天的聚合值，价格序列不管按 24h/6h/1h 切片都只有 5~6 个不同值，
// 拿它画"近一年走势"只能靠差分反推，画出来的曲线是抖动的锯齿，精度不够。
//
// 换成网易官方 ESI 之后有了**真正的逐日数据**（402 天，一天不差），
// 图才有意义：高点低点是当天真实成交区间，成交量是当天真实成交量。
//
// ───────────────── 两条数据线怎么来的 ─────────────────
//
// 上子图：**最高价**与**最低价**（ESI 的 daily highest / lowest）。
//         两者之间填一条淡色带，一眼看出"当天价格区间有多宽"。
// 下子图：**成交量**（股数）—— 这是 ESI 相比 ceve 的实质改进，
//         ceve 的 volume 是挂单深度，当时只能标成"挂单量"。
//
// 参考线：全区间最高/最低价（虚线）+ 近一年均价（白色虚线），
//         这样不用盯着看数字也能判断"现在是偏高还是偏低"。

// 渲染：**纯 JS**，不再 spawn PowerShell。
//
// 历史：这里原来是 `spawn('powershell.exe', ['-File', 'draw-chart.ps1'])` 走 GDI+。
// 之所以换掉，是因为 `.ps1` 是 Skill 市场明令禁止的文件后缀
// （文档 skill-reference.md §13.3），带它就永远上不了架。详见 renderChart 的注释。
//
// 三个模块都只依赖 `node:zlib` / `node:fs`，无第三方包。
//
// ⚠️⚠️ 这里的导入**必须是动态 import + 同一个版本查询串**，不能写静态 `import`。
// 原因是一个实测踩到的静默失效：`index.js` 用 `?lib=<库最新mtime>` 导入本文件，
// 但如果本文件内部用**静态裸 URL** 导入 `render.js`，那么当只改了 `render.js`、
// 没动 `chart.js` 时 —— `chart.js` 的 URL 不变 → Node 复用缓存里那份 chart.js
// → 它内部解析出的 `render.js`（裸 URL）也命中缓存 → **永远加载不到新渲染器**。
// 表现为"代码明明落盘了、测试也全绿，线上就是没变化"，极难排查。
import { importLib } from './lib-version.js';

const { marketHistory } = await importLib('./esi.js');
const { render } = await importLib('./render.js');

const PALETTE = {
  high: '#26A69A',      // 青绿：最高价（涨）
  low: '#EF5350',       // 红：最低价（跌）
  volume: '#1E88E5',    // 蓝：成交量
  // 均值线原来用浅灰 #9E9E9E，在浅色背景上对比度偏弱、虚线几乎糊掉。
  // 换成中灰蓝（既不抢青绿/红，又看得清）。
  avg: '#78909C',
  peak: '#FFA726'
};

function round2(v) { return Math.round(v * 100) / 100; }

/**
 * 决定价格纵轴要不要裁掉离群值，返回裁剪后的上下界。
 *
 * **为什么要有这一步**：阿贝拉 SW-900-I 只有 46 天历史，开头有个 3.5亿 的上市
 * 峰值，此后价格稳定在 1亿 上下 —— 纵轴被那个峰值顶到 0~4亿，于是全年真实波动
 * 被压成贴着轴底的一条平线，图等于白画。三钛合金没这问题（价格本身均匀），
 * 所以这是**只在有极端离群值时**才出现的缺陷。
 *
 * 判据用"中位数 + 6×MAD"（中位数绝对偏差）。为什么不用常见的 1.5×IQR：
 * 价格序列的 IQR 往往极小（三钛合金全年只在 9~10 之间晃），1.5×IQR 会把
 * **正常波动**也当离群值裁掉，反而误导；6×MAD 宽容得多，只裁真正的尖刺。
 *
 * 收益判据：只有把**轴范围**（不是数据范围）压到原来 60% 以下才裁。
 * ⚠️ 这个判据踩过坑：早先比较数据范围、阈值取 1/1.8，阿贝拉实测只差 0.5% 没过，
 * 裁剪被静默跳过。数据范围≠观感 —— 轴还要按刻度吸附取整，真正决定"波动看不看得清"
 * 的是吸附后的轴范围。
 *
 * 放在 JS 里而不是渲染脚本里，是为了**可测**：PowerShell 里的数值逻辑没法单测，
 * 而"该不该裁"是个需要回归保护的判断。
 *
 * `maxDropFrac`：**裁掉的比例上限**。超过就不裁 —— 双峰数据里"一半的点离中位数很远"，
 * 那是数据的形状而不是离群值（伊甸币实测：裁掉 56%，图上全成了平顶）。
 * @returns {{clipLo:number, clipHi:number, clipped:boolean, dropped:number, ratio:number}}
 */
export function decideClip(values, { yTicks = 7, minCount = 8, k = 6, gain = 0.6, maxDropFrac = 0.25 } = {}) {
  const sorted = values.filter(Number.isFinite).slice().sort((a, b) => a - b);
  const none = { clipLo: NaN, clipHi: NaN, clipped: false, dropped: 0 };
  if (sorted.length < minCount) return none;

  const mid = Math.floor(sorted.length / 2);
  const median = sorted.length % 2 === 0 ? (sorted[mid - 1] + sorted[mid]) / 2 : sorted[mid];
  const devs = sorted.map((x) => Math.abs(x - median)).sort((a, b) => a - b);
  const dmid = Math.floor(devs.length / 2);
  const mad = devs.length % 2 === 0 ? (devs[dmid - 1] + devs[dmid]) / 2 : devs[dmid];
  if (!(mad > 0)) return none;

  const loFence = median - k * mad;
  const hiFence = median + k * mad;
  const kept = sorted.filter((x) => x >= loFence && x <= hiFence);
  if (kept.length < 2) return none;

  const kLo = kept[0];
  const kHi = kept[kept.length - 1];
  if (!(kHi > kLo)) return none;

  // 轴吸附范围（与渲染脚本 NiceStep **同一套规则**）：这才是"能省多少空间"的真实度量。
  //
  // ⚠️ 必须与 draw-chart.ps1 里的实现保持一致，否则算出的"能省多少"和实际画出来的不符。
  // 规则：取第一个使步长 ≥ span/max 的乘数（最小的够用步长），再用 span/min 兜底。
  const niceStep = (span, min, max) => {
    if (!(span > 0)) return 1;
    const lo = span / max;
    const hi = span / min;
    const mag = Math.pow(10, Math.floor(Math.log10(lo)));
    for (const m of [1, 2, 2.5, 5, 10, 20, 25, 50, 100]) {
      const s = m * mag;
      if (s >= lo) return Math.min(s, hi);
    }
    return hi;
  };
  const dataLo = sorted[0];
  const dataHi = sorted[sorted.length - 1];
  const stepRaw = niceStep(dataHi - dataLo, 3, yTicks);
  const spanRaw = Math.ceil(dataHi / stepRaw) * stepRaw - Math.floor(dataLo / stepRaw) * stepRaw;
  const stepCut = niceStep(kHi - kLo, 3, yTicks);
  const spanCut = Math.ceil(kHi / stepCut) * stepCut - Math.floor(kLo / stepCut) * stepCut;
  const ratio = spanRaw > 0 ? spanCut / spanRaw : 1;

  if (!(ratio <= gain)) return { ...none, ratio };
  const dropped = sorted.filter((x) => x < kLo || x > kHi).length;
  if (!(dropped > 0)) return { ...none, ratio };

  // ── 裁掉的比例太高 → 那不是"离群值"，那是数据的形状 ──
  //
  // 实测踩到：伊甸币的历史是**双峰**的（25 天里有一半点的高价冲到 2400 万，
  // 另一半只有 2240 万）。中位数 + 6×MAD 把那一半全判成离群值 → 裁掉 14/25（56%），
  // 于是图上出现一整排平顶、坐标范围只剩 60 万，**比不裁还难读**。
  //
  // 真正的离群值是"少数几个离群点"：阿贝拉是 2/46（4%）、三钛合金 2/365（0.5%）。
  // 25% 这道线能把两者干净分开，所以取它。
  const maxDropped = Math.floor(sorted.length * maxDropFrac);
  if (dropped > maxDropped) return { ...none, ratio, dropped };
  return { clipLo: kLo, clipHi: kHi, clipped: true, dropped, ratio };
}

/**
 * 中文数量级缩写，和图上纵轴用的是**同一套规则**（见 draw-chart.ps1 的 FmtBig/FmtPrice）。
 *
 * 为什么必须统一：实测成交量合计写成 `413,400,348,951 股` 时，13 位数字读者要一位位
 * 数才知道是 4134 亿；而纵轴同一张图上写的是 `70亿`。同一张图两种精度，反而更难读。
 */
function abbreviate(v, { decimals = 2 } = {}) {
  const a = Math.abs(v);
  const f = (x) => x.toFixed(decimals).replace(/\.?0+$/, '');
  if (a >= 1e12) return `${f(v / 1e12)}万亿`;
  if (a >= 1e8) return `${f(v / 1e8)}亿`;
  if (a >= 1e4) return `${f(v / 1e4)}万`;
  return f(v);
}

/** 价格：两位小数 + 千分位；太长就缩写。与纵轴 FmtPrice 一致。 */
function fmtPrice(v) {
  const s = Number(v).toLocaleString('zh-CN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  return s.length <= 12 ? s : abbreviate(v);
}

/**
 * 日期标签：**月份粒度**（用户要求"下面日期写月份就行了"）。
 *
 * 原来是一天一个标签（`MM-DD`，年份变化处带年份）。一年 365 个标签本来就只能
 * 抽样画十几个，而带"日"的信息在图上根本读不出来（横轴挤到 70px 一个），
 * 反而把 45° 斜排文字撑得很长、逼着锚点下移。
 *
 * ② 第一版改成"每月第一天的标签带年份"，结果 46 天那张变成
 *    `2026-08 / 8月 / 8月 / 2026-09 / 9月 / 9月 …` —— 一行里重复写同一件事，
 *    而且抽样常常**正好跳过**带年份的那个，于是整行既没年份又全是重复。
 *
 * 现在的规则：**只有跨度跨年时**才写年份。不跨年就纯 `N月`（干净）；
 * 跨年时必须带年份，否则两个"10月"没法区分。
 *
 * 数组仍是**一天一项**（渲染层按索引抽样，索引必须和数据点对齐），
 * 所以同一月份内的多天会得到相同文案 —— 抽样后自然只显示一个。
 */
function dateLabels(rows) {
  const years = new Set(rows.map((r) => String(r.date).split('-')[0]));
  const spansYears = years.size > 1;
  return rows.map((r) => {
    const [y, m, d] = String(r.date).split('-');
    // 用户要求"日期间隔改成 10 天"，所以标签回到**天粒度**，格式 `MM-DD`。
    // `MM-DD` 只有 5 个字符，比 `YYYY-MM` 短一半，斜排后占的横向宽度也更小
    // —— 这正是"每 10 天一个还不挤"的前提（抽样步长在渲染层按像素间距算）。
    // 跨年时补上年份，否则两个"10-08"分不清是哪一年。
    return spansYears ? `${m}-${d}` : `${m}-${d}`;
  });
}

/**
 * 取历史并裁成"最近 days 天"。
 *
 * ⚠️ `base`（服务器基址）**必须一路透传**到 marketHistory。忘传的话会静默拿到
 * 默认服务器（晨曦）的数据 —— 表现是"两个服的走势图一模一样"，而报价卡片却是
 * 对的（报价走的是另一条路径），所以只看卡片完全发现不了。这个 bug 真的出现过，
 * 是"两服均价必须不同"那条断言抓出来的。
 *
 * @returns {{rows:Array, total:number}} total 是 ESI 实际给了多少天
 */
export async function loadHistory(fetchImpl, typeId, { regionId, days = 365, signal, base } = {}) {
  const all = await marketHistory(fetchImpl, typeId, { regionId, signal, base });
  const n = Math.max(2, Math.min(Number(days) || 365, all.length));
  return { rows: all.slice(-n), total: all.length };
}

/**
 * 组装给 draw-chart.ps1 的 spec。
 * 纯函数（不触网、不画图），便于单测。
 */
export function buildChartSpec({ itemName, rows, caption, updatedAt, width = 1740, height = 1040, superSample = 2 }) {
  if (!Array.isArray(rows) || rows.length < 2) throw new Error('历史数据不足，无法画图');

  const closes = rows.map((r) => Number(r.average)).filter(Number.isFinite);
  const highs = rows.map((r) => Number(r.highest)).filter(Number.isFinite);
  const lows = rows.map((r) => Number(r.lowest)).filter(Number.isFinite);
  if (!highs.length || !lows.length) throw new Error('历史数据里没有有效价格');

  const peak = Math.max(...highs);
  const trough = Math.min(...lows);
  const avg = closes.length ? closes.reduce((a, b) => a + b, 0) / closes.length : (peak + trough) / 2;
  const peakAt = rows[highs.indexOf(peak)]?.date ?? '';
  const troughAt = rows[lows.indexOf(trough)]?.date ?? '';

  const first = rows[0].date;
  const last = rows[rows.length - 1].date;
  const totalVol = rows.reduce((a, r) => a + (Number(r.volume) || 0), 0);

  // 参考线标签：价格长的物品（阿贝拉 1 亿上下）用千分位会写出
  // "最低 10,030,000.00（2026-08-20）" 这么长一条，横着压住纵轴刻度。
  // 所以标签里的价格用 fmtPrice（超长就缩写），与纵轴同一套规则。
  const annotations = [
    { value: round2(avg), color: PALETTE.avg, label: `一年均价 ${fmtPrice(avg)}` }
  ];
  // 最高/最低价离得够远时才标，否则两个标签会叠在一起
  const span = peak - trough || 1;
  if (peak - avg > span * 0.06) {
    annotations.push({ value: round2(peak), color: PALETTE.peak, label: `最高 ${fmtPrice(peak)}（${peakAt}）` });
  }
  if (avg - trough > span * 0.06) {
    annotations.push({ value: round2(trough), color: PALETTE.high, label: `最低 ${fmtPrice(trough)}（${troughAt}）` });
  }

  // ── 最新价 ────────────────────────────────────────────────────────────
  //
  // 这是这张图**最该有却一直缺**的信息：群友看图想知道的是"现在是贵还是便宜"，
  // 而原来只有历史高低点和均值，唯一的当前价线索是右边缘那条线 —— 读不出数值。
  //
  // 用"最近一天的成交均价"而不是当时的挂单价：挂单价每秒都在变，画进历史图里
  // 会和"逐日成交"这个口径混淆；日均价才是同一条时间轴上可比的点。
  const lastRow = rows[rows.length - 1];
  const lastClose = Number(lastRow.average);
  const prevClose = rows.length >= 2 ? Number(rows[rows.length - 2].average) : NaN;
  const delta = Number.isFinite(prevClose) && prevClose > 0 ? (lastClose - prevClose) / prevClose : NaN;
  const deltaText = Number.isFinite(delta)
    ? ` ${delta >= 0 ? '▲' : '▼'}${(Math.abs(delta) * 100).toFixed(1)}%`
    : '';
  if (Number.isFinite(lastClose)) {
    annotations.push({
      value: round2(lastClose),
      // 涨绿跌红（EVE/欧美习惯，与图上"最高价青绿、最低价红"一致，不引入第三套配色）
      color: delta >= 0 ? PALETTE.high : PALETTE.low,
      label: `最新 ${fmtPrice(lastClose)}${deltaText}（${lastRow.date}）`,
      strong: true          // 画粗一点：它是主角
    });
  }

  // 成交量标签改成**日均 + 单日最高**。"一年合计"位数太多读不动，而且答非所问 ——
  // 判断"这物品好不好出手"要看的是每天能成交多少，不是一年总共多少。
  const daysWithVol = rows.filter((r) => Number(r.volume) > 0).length || 1;
  const avgVol = totalVol / daysWithVol;
  const maxVol = Math.max(...rows.map((r) => Number(r.volume) || 0));

  // 价格纵轴要不要裁掉离群值（判据在 decideClip，可单测）。把结果**随 spec 传给**
  // 渲染脚本，而不是让脚本自己算 —— 这样"该不该裁"有测试保护，脚本只负责画。
  const clip = decideClip([...highs, ...lows]);

  return {
    width, height, superSample,
    title: itemName,
    spanText: `${first} ~ ${last}（${rows.length} 天）`,
    updatedText: updatedAt ? `更新于 ${updatedAt}` : '',
    caption: caption ?? '',
    dates: dateLabels(rows),
    // ⚠️ 不裁时给的是 `{ clipped: false }` 而**不是 `null`**。
    // `null` 会和"调用方没给信息"混在一起，渲染器那边会走本地保底再裁一遍
    // （那份保底没有"裁太多就不裁"的保护），表现为"改了 chart.js 图却没变"。
    priceAxis: clip.clipped
      ? { clipped: true, clipLo: clip.clipLo, clipHi: clip.clipHi, clipNote: `已裁 ${clip.dropped} 个离群点` }
      : { clipped: false },
    price: {
      annotations,
      series: [
        { label: '最高价', color: PALETTE.high, type: 'line', values: rows.map((r) => (Number.isFinite(Number(r.highest)) ? Number(r.highest) : null)) },
        { label: '最低价', color: PALETTE.low, type: 'line', values: rows.map((r) => (Number.isFinite(Number(r.lowest)) ? Number(r.lowest) : null)) }
      ]
    },
    volume: {
      series: [
        {
          label: `日均成交 ${abbreviate(avgVol)}（单日最高 ${abbreviate(maxVol)}）`,
          color: PALETTE.volume,
          type: 'bar',
          values: rows.map((r) => (Number.isFinite(Number(r.volume)) ? Number(r.volume) : null))
        }
      ]
    },
    // 给调用方/测试看的关键数字（PowerShell 不读这些，但它们对断言有用）
    stats: {
      peak, trough, avg, peakAt, troughAt, totalVol, days: rows.length, first, last,
      lastClose, lastDate: lastRow.date, delta, avgVol, maxVol
    }
  };
}

/**
 * 渲染成 PNG，返回 base64。
 *
 * ───────────────── 为什么从 PowerShell 换成了纯 JS ─────────────────
 *
 * 原实现 spawn `powershell.exe -File draw-chart.ps1`（GDI+ 渲染）。能跑，但有个
 * 硬伤：**上架 Skill 市场时 `.ps1` 是被禁止的文件后缀**
 * （官方文档 skill-reference.md §13.3：`exe dll bat cmd ps1 vbs sh`）。
 * 也就是说带 `.ps1` 的包永远上不了市场 —— 而走势图是这个技能的核心功能之一。
 *
 * 换成三个自包含模块后：
 *   · `png.js`    纯 JS 的 PNG 编码（`node:zlib` 的 deflate + CRC32 + chunk）
 *   · `font.js`   自己解析 TrueType/TTC（cmap → glyf/loca 轮廓 → 栅格化）
 *   · `render.js` 按 spec 画图（替代 draw-chart.ps1）
 * 好处不只是"合规"：
 *   · 不再起子进程 —— 实测整图 200~290ms，**比原来还快**（省掉 PowerShell 启动）
 *   · 不用临时文件、不用 `-File`、不用 UTF-8 BOM 那套编码约束
 *   · 错误直接是 JS 异常，不再靠退出码 + stderr 猜
 *   · 依赖没有变多：原来靠 GDI+（系统字体），现在靠同一批系统字体文件
 *
 * ⚠️ 唯一新增的运行时依赖是**系统字体文件**。`font.js` 有一条回退链
 * （msyh → msyhbd → simhei → simsun → Deng → NotoSansSC），全都不在时会抛
 * 一个列出所有候选与失败原因的错，而不是画出一张没有字的图。
 */
/** 宿主日志回调（由 index.js 注入），用于把渲染自检写进 app 日志页。 */
let logSink = null;
export function setChartLogSink(fn) { logSink = typeof fn === 'function' ? fn : null; }

export function renderChart(spec) {
  let buf;
  try {
    buf = render(spec);
  } catch (e) {
    return Promise.reject(new Error(`画图失败：${e?.message ?? e}`));
  }
  // PNG 魔数校验：免得把半个字节流当图片发出去
  if (!Buffer.isBuffer(buf) || buf.length < 100
      || buf[0] !== 0x89 || buf[1] !== 0x50 || buf[2] !== 0x4e || buf[3] !== 0x47) {
    return Promise.reject(new Error('画图输出不是 PNG'));
  }
  // 每次画图都记一行**自检日志**（不再藏在 CHART_DEBUG 后面）。
  //
  // 为什么必须常驻：出现过"代码落盘了、宿主日志也显示加载了新版本，但画出来的图
  // 仍是旧格式"的情况，排查方向全靠猜。这行日志把**运行时真实生效的参数**写进
  // app 的日志里 —— 尺寸、日期标签的样式、参考线条数。一看日志就知道跑的是哪一版，
  // 不用再靠"文件 mtime / 加载日志"间接推断。
  const diagLine = `[chart] ${spec.width}x${spec.height} ${buf.length}B `
    + `日期样式="${(spec.dates ?? []).slice(0, 1)[0] ?? '?'}" `
    + `标签数=${(spec.dates ?? []).length} 参考线=${(spec.price?.annotations ?? []).length} `
    + `裁剪=${spec.priceAxis?.clipNote ?? '无'}`;
  console.error(diagLine);
  // 同时走宿主日志（api.log）—— 这样"运行中到底跑的是哪一版"可以直接在
  // app 的日志页里看到，不用再靠文件 mtime / 加载记录间接推断。
  if (typeof logSink === 'function') logSink(diagLine);
  return Promise.resolve({ base64: buf.toString('base64'), bytes: buf.length });
}

/**
 * 一步到位：取历史 → 组装 → 渲染。
 * `base` 是服务器基址，**必须传**（漏了会静默查默认服务器，见 loadHistory 的说明）。
 */
export async function generateChart(fetchImpl, {
  typeId, itemName, regionId, days = 365, caption, updatedAt, signal, superSample, base,
  width, height
}) {
  const { rows } = await loadHistory(fetchImpl, typeId, { regionId, days, signal, base });
  if (rows.length < 2) throw new Error('这个物品的历史数据不足 2 天，画不了图');
  // width/height 透传给 buildChartSpec：查价时附带的那张图用小一号尺寸
  // （一轮可能连发两张，小些更清爽、传输也省；独立查图时用默认的 1630×900）。
  const spec = buildChartSpec({ itemName, rows, caption, updatedAt, superSample, width, height });
  const png = await renderChart(spec);
  return { ...png, spec };
}

// 渲染器入口一并导出，方便测试直接拿它做"渲染器是否可加载"的检查。
// （原来这里导出的是 `CHART_SCRIPT`（.ps1 的路径），换成 JS 后没必要再暴露路径。）
export { render as renderSpec };
