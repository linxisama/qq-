// render.js —— 纯 JS 走势图渲染器（draw-chart.ps1 的等价实现）
//
// 输入：和 chart.js 的 buildChartSpec() 产出**完全一致**的 spec 对象。
// 输出：Buffer(PNG)。
//
// 只依赖 node:zlib / node:fs（通过 png.js 和 font.js）。
//
// ═══════════════════════════════════════════════════════════════════════
//  从 draw-chart.ps1 逐条搬过来的排版约定 —— 每一条都是被用户指出后修好的，
//  改动前请先读对应的注释，不要"顺手简化"。
// ═══════════════════════════════════════════════════════════════════════
//
//  1. 绘图区里**不出现任何文字**。参考线标签、裁剪说明放两个面板之间那条带子里；
//     日期放成交量面板下方；图例放各面板**上方**。原来是画在绘图区左上角的，
//     白色底衬直接把数据线盖住了（用户原话："左字挡住线条了"）。
//
//  2. 45° 斜排日期的锚点必须**下移** `maxLabelW * 0.72 + 8k`。
//     原因：GDI+ 的 RotateTransform(-45) 之后文字是**向右上**延伸的，横向宽度 W
//     会贡献 W/√2 ≈ 0.707W 的**向上**高度。日期串约 90~110px 宽，不补偿就会
//     往上侵入面板 64~78px，正好压在最右边几个数据点上。
//     （用户原话："下面日期挡住线条了"）
//
//  3. 日期采样**强制包含最后一天**。步进采样在 n 不是 labelEvery 整数倍时正好
//     跳过最后一天，于是"到哪天为止"这个信息就缺了（阿贝拉那张 10-07 没画出来）。
//
//  4. 纵轴裁剪（spec.priceAxis.clipLo/clipHi）必须生效，且**只作用于价格面板**。
//     成交量面板是 zeroBase（必须从 0 起），套用价格的下界会让刻度变成
//     9.28/29.28/49.28亿（既不是整数、也不从 0 起）—— 实测踩过。
//     超界的数据点用 yDraw **钳制**在面板内绘制（否则被裁掉的 3.5亿 会画到面板
//     上方伸进标题区），再在边缘画 ▲/▼ 箭头，并在带子里写明裁剪说明
//     （裁了却不说，读者会把轴顶当成真实最高价 —— 那是骗人）。
//
//  5. 成交量面板用 power=0.55 变换（分布是"大量小值 + 少数巨峰"，线性轴下
//     小柱子只有零点几像素完全看不见），柱子从 0 起。
//
//  6. 2× 超采样再降采样。GDI+ 对 2px 细线**几乎不做抗锯齿**，斜段就是硬阶梯；
//     按 2 倍画再缩回来等于 4 倍覆盖的降采样。本实现里折线自己带距离场抗锯齿，
//     超采样主要救的是字形和填充多边形。
//
//  7. 价格涨=青绿 #26A69A、跌=红 #EF5350（EVE/欧美惯例）。

import {
  loadFontChain, DEFAULT_FONT_CHAIN,
  paintPaths, rotatePaths, rectPath, strokePolyline,
} from './font.js';
// ⚠️ 动态导入 + 版本串：静态裸 import 会让父模块的缓存拖出旧的 png.js（见 lib-version.js）
import { importLib } from './lib-version.js';
const { Canvas, downsample, inspectPNG } = await importLib('./png.js');

// ─────────────────────────── 常量 ───────────────────────────

/** GDI+ 的 Font 构造函数默认单位是 Point；96 DPI 下 1pt = 4/3 px */
const PT = 4 / 3;
const TITLE_PX = 22 * PT;   // 22pt
const LABEL_PX = 15 * PT;   // 15pt
const AXIS_PX = 12 * PT;    // 12pt（纵轴刻度、图例、参考线标签）
  // 日期标签单独一档、略小：一年要放 37 个（每 10 天一个），
  // 用 12pt 时「10-08」的水平占用 82px、37 个需要 3000px+，刚好放不下。
  // 缩到 0.78 后占用降到约 66px，37 个约 2440px，稳稳放下。
  const DATE_PX = 12 * PT * 0.78;
const CAP_PX = 12 * PT;     // 12pt

const INK = [51, 51, 51];       // #333333
const DIM = [136, 136, 136];    // #888888
const GRID = [230, 230, 230];   // #E6E6E6
const AXIS = [187, 187, 187];   // #BBBBBB

/** 标题用的粗体回退链；都拿不到就退回正文字体（标题只是不加粗，不会崩） */
const BOLD_CHAIN = [
  'C:\\Windows\\Fonts\\msyhbd.ttc',   // 微软雅黑 Bold
  'C:\\Windows\\Fonts\\simhei.ttf',   // 黑体（本身就偏粗）
  'C:\\Windows\\Fonts\\Dengb.ttf',    // 等线 Bold
];

// ─────────────────────────── 小工具 ───────────────────────────

function num(v) {
  if (v == null) return null;
  const d = Number(v);
  return Number.isFinite(d) ? d : null;
}

function arr(v) { return v == null ? [] : (Array.isArray(v) ? v : [v]); }

/** '#RRGGBB' -> [r,g,b]；解析不了给灰色（和 ps1 的 Col 一致） */
function col(hex, fallback = [128, 128, 128]) {
  const h = String(hex == null ? '' : hex).trim().replace(/^#/, '');
  if (h.length !== 6 || !/^[0-9a-fA-F]{6}$/.test(h)) return fallback;
  return [parseInt(h.slice(0, 2), 16), parseInt(h.slice(2, 4), 16), parseInt(h.slice(4, 6), 16)];
}

/**
 * 千分位 + 固定小数位。**不依赖 ICU**（toLocaleString 的行为随 Node 的 ICU 编译
 * 选项变化，渲染结果必须可复现）。
 */
function groupThousands(v, decimals) {
  const neg = v < 0;
  const s = Math.abs(v).toFixed(decimals);
  const dot = s.indexOf('.');
  const ip = dot < 0 ? s : s.slice(0, dot);
  const fp = dot < 0 ? '' : s.slice(dot);
  return (neg ? '-' : '') + ip.replace(/\B(?=(\d{3})+(?!\d))/g, ',') + fp;
}

/**
 * 中文数量级缩写（**轴刻度专用**，要短）。
 *
 * ⚠️ 小数位按量级收敛，不能一律两位。原来固定两位，于是成交量轴出现
 * `2168.45万 / 1445.64万 / 722.82万` 这种又长又啰嗦的刻度 ——
 * 十来个字符把左边距撑宽、绘图区被挤窄（用户截图里就是这个）。
 * 轴刻度是给人**定位**用的（精确数字在图例里），所以：
 * 上万后不要小数、上千后一位、再小才两位。
 *
 * 图例里的「日均成交 244.69万」走的是另一个函数（chart.js 的 abbreviate），
 * 那里保留两位小数 —— **那是要读数的**，不能一起改。
 */
function fmtBig(v) {
  const a = Math.abs(v);
  const trim = (x, d) => x.toFixed(d).replace(/\.?0+$/, '');
  const digits = (x) => (Math.abs(x) >= 1000 ? 0 : Math.abs(x) >= 100 ? 1 : 2);
  if (a >= 1e12) { const x = v / 1e12; return trim(x, digits(x)) + '万亿'; }
  if (a >= 1e8) { const x = v / 1e8; return trim(x, digits(x)) + '亿'; }
  if (a >= 1e4) { const x = v / 1e4; return trim(x, digits(x)) + '万'; }
  return trim(v, 2);
}

/** 价格：两位小数 + 千分位；超过 12 字符就缩写（否则会撑破左边距） */
function fmtPrice(v) {
  const s = groupThousands(v, 2);
  return s.length <= 12 ? s : fmtBig(v);
}

function fmtAxisLabel(v, bigNumbers) {
  // 0 一律写 "0"：价格轴两位小数会写 "0.00"、成交量轴写 "0"，
  // 同一张图上同一个值两种写法看着像两个刻度
  if (Math.abs(v) < 1e-9) return '0';
  return bigNumbers ? fmtBig(v) : fmtPrice(v);
}

/**
 * 刻度步长：在 1/2/2.5/5/10/20/25/50/100 × 10^n 里挑**第一个 >= span/maxTicks 的**。
 *
 * ⚠️ 必须是"第一个够用的最小步长"，不能在表里找"满足区间的那个"。
 * 早先的写法用 lo = span/max 推量级再找乘数，而成交量动辄几十亿、轴底又接近 0，
 * span 可能比 span/max 大 7 个数量级，于是永远找不到"落进区间"的乘数、一路滑到
 * 兜底的 hi，返回一个**过大**的步长 → 刻度数从 7 变成十几个 → 标签叠成一团（实测）。
 */
function niceStep(span, minTicks, maxTicks) {
  if (!(span > 0) || !Number.isFinite(span)) return 1;
  const lo = span / maxTicks;
  const hi = span / minTicks;
  const mag = Math.pow(10, Math.floor(Math.log10(lo)));
  for (const m of [1, 2, 2.5, 5, 10, 20, 25, 50, 100]) {
    const s = m * mag;
    if (s >= lo) return Math.min(s, hi);
  }
  return hi;
}

/** 截断到指定宽度，超出加省略号 */
function ellipsize(font, text, sizePx, maxW) {
  if (maxW <= 0) return '';
  if (font.measure(text, sizePx) <= maxW) return text;
  const chars = [...text];
  for (let n = chars.length - 1; n > 0; n--) {
    const t = chars.slice(0, n).join('') + '…';
    if (font.measure(t, sizePx) <= maxW) return t;
  }
  return '…';
}

// ─────────────────────────── 纵轴范围 ───────────────────────────

/**
 * 纵轴范围 + 刻度步长。同一子图的多条线共用一个轴，才对得上同一个刻度。
 * 这是 draw-chart.ps1 里 Get-AxisRange 的逐行等价实现。
 */
function getAxisRange(series, yTicks, zeroBase, maxTicks, priceAxis, k) {
  let lo = Infinity, hi = -Infinity;
  let varyingLo = Infinity, varyingHi = -Infinity;

  for (const s of arr(series)) {
    const vals = arr(s.values).map(num).filter((v) => v !== null);
    if (!vals.length) continue;
    const sLo = Math.min(...vals), sHi = Math.max(...vals);
    if (sLo < lo) lo = sLo;
    if (sHi > hi) hi = sHi;
    // 恒定序列（全年一个价）不参与定轴：它占着一整条轴却零信息量，还会把其他线挤扁
    if (sHi > sLo) {
      if (sLo < varyingLo) varyingLo = sLo;
      if (sHi > varyingHi) varyingHi = sHi;
    }
  }
  if (!Number.isFinite(lo)) { lo = 0; hi = 1; }
  if (!Number.isFinite(varyingLo)) {
    const mid = (lo + hi) / 2;
    const half = Math.max(Math.abs(mid) * 0.05, 0.5);
    varyingLo = mid - half; varyingHi = mid + half;
  }

  const dataLo = varyingLo, dataHi = varyingHi;

  // ── 裁剪范围 ──
  // 上下界由 chart.js 的 decideClip() 在 JS 侧算好随 spec.priceAxis 传进来。
  // 这里**不再重复实现一遍裁剪算法** —— 两份实现必然漂移（而且真的漂移过，见下）。
  //
  // ⚠️ `priceAxis` 的三种取值必须区分清楚，早先 `null` 承担了两种含义，出过 bug：
  //   · `undefined` —— 调用方**没给**信息（手工拼 spec 调试）→ 走下面的本地保底
  //   · `{ clipped: false }` —— 调用方**明确决定不裁** → 用原始数据范围，**不要**保底
  //   · `{ clipLo, clipHi }` —— 按给定范围裁
  //
  // 踩的坑：chart.js 判定"不该裁"时曾返回 `priceAxis: null`，而 `null` 又落进
  // 本地保底分支 —— 保底那份实现**没有"裁太多就不裁"的保护**，于是把伊甸币
  // （双峰数据，一半的点离中位数很远）又裁了一遍，图上全是平顶。
  // 症状是"改了 chart.js 但图没变"，因为渲染器自己另算了一套。
  let clipLo = dataLo, clipHi = dataHi, clipNote = '';
  let skipLocalClip = false;

  // ⚠️ 只在**非 zeroBase**（价格）面板上应用
  if (priceAxis && !zeroBase) {
    if (priceAxis.clipped === false) {
      skipLocalClip = true;                       // 明确不裁
    } else {
      const a = num(priceAxis.clipLo), b = num(priceAxis.clipHi);
      if (a !== null && b !== null && b > a) {
        clipLo = a; clipHi = b;
        clipNote = priceAxis.clipNote == null ? '' : String(priceAxis.clipNote);
        skipLocalClip = true;
      }
    }
  }

  // 保底路径：调用方没给 priceAxis（手工拼 spec 调试）时，本地算一次
  if (!zeroBase && !skipLocalClip) {
    const vals = [];
    for (const s of arr(series)) for (const v of arr(s.values)) { const d = num(v); if (d !== null) vals.push(d); }
    if (vals.length >= 8) {
      const sorted = vals.slice().sort((a, b) => a - b);
      const mid = Math.floor(sorted.length / 2);
      const median = sorted.length % 2 === 0 ? (sorted[mid - 1] + sorted[mid]) / 2 : sorted[mid];
      const devs = sorted.map((x) => Math.abs(x - median)).sort((a, b) => a - b);
      const dmid = Math.floor(devs.length / 2);
      const mad = devs.length % 2 === 0 ? (devs[dmid - 1] + devs[dmid]) / 2 : devs[dmid];
      if (mad > 0) {
        const loFence = median - 6 * mad, hiFence = median + 6 * mad;
        const kept = sorted.filter((x) => x >= loFence && x <= hiFence);
        if (kept.length >= 2) {
          const kLo = kept[0], kHi = kept[kept.length - 1];
          const kSpan = kHi - kLo;
          // 收益判据拿**最终吸附后的轴范围**比，而不是数据范围。
          // 早先比数据范围、阈值 1/1.8，阿贝拉实测只差 0.5% 没过、裁剪被静默跳过。
          const stepRaw = niceStep(dataHi - dataLo, 3, yTicks);
          const spanRaw = Math.ceil(dataHi / stepRaw) * stepRaw - Math.floor(dataLo / stepRaw) * stepRaw;
          const stepCut = niceStep(kHi - kLo, 3, yTicks);
          const spanCut = Math.ceil(kHi / stepCut) * stepCut - Math.floor(kLo / stepCut) * stepCut;
          const ratio = spanRaw > 0 ? spanCut / spanRaw : 1;
          if (kSpan > 0 && ratio <= 0.6) {
            clipLo = kLo; clipHi = kHi;
            const dropped = vals.length - kept.length;
            if (dropped > 0) clipNote = `已裁 ${dropped} 个离群点`;
          }
        }
      }
    }
  }

  if (zeroBase) {
    lo = 0; hi = dataHi;
  } else {
    const span2 = clipHi - clipLo;
    let pad = span2 * 0.08;
    if (pad <= 0) pad = Math.max(Math.abs(clipHi) * 0.06, 0.5);
    lo = clipLo - pad; hi = clipHi + pad;
    if (lo < 0 && lo > -2 * pad) lo = 0;
  }

  // 刻度数上限由调用方按**面板高度**算好传进来：标签高约 22px，面板不够高时
  // 7 个刻度会叠在一起（成交量面板实测踩过）
  if (maxTicks < 2) maxTicks = 3;
  const step = niceStep(hi - lo, 3, maxTicks);
  const snapLo = Math.floor(lo / step) * step;
  const snapHi = Math.ceil(hi / step) * step;
  const visSpan = clipHi - clipLo;

  if (visSpan <= 0 || (snapHi - snapLo) <= visSpan * 1.6) {
    // 不让上下界都吸到整数刻度：数据 9.21~11.21 吸成 9.00~11.50 后只占轴的 71%，
    // 看着就是"线挤成一条"。只在"吸完不超过数据跨度 1.6 倍"时才吸。
    lo = snapLo; hi = snapHi > snapLo ? snapHi : snapLo + step;
  } else {
    // 不整体吸附时下限仍做一次浅吸附 —— 否则会出现 -0.17 这种非整起点，
    // 于是轴上最下面那条刻度是 "0.00" 而基线在它下面，贴底的线会和标签叠成重影
    const loSnap = Math.floor(lo / step) * step;
    if ((hi - loSnap) <= visSpan * 1.6) lo = loSnap;
  }
  if (hi <= lo) hi = lo + step;

  return { lo, hi, step, span: hi - lo, clipNote, dataLo, dataHi };
}

// ─────────────────────────── 面板绘制 ───────────────────────────

function makeTransform(rect, axis, power) {
  const { lo, hi } = axis;
  const p = power > 0 ? power : 1;
  const tx = p === 1
    ? (v) => v
    : (v) => Math.pow(Math.max(0, v - lo), p);
  const txHi = tx(hi);
  let txSpan = txHi - tx(lo);
  if (!(txSpan > 0)) txSpan = 1;
  const yOf = (v) => rect.y + (txHi - tx(v)) / txSpan * rect.h;
  // 画线专用：钳制在面板内。超出轴范围的值用纯数学映射会算到面板外，
  // 启用离群值裁剪后那个被裁掉的 3.5亿 会被画到面板上方、伸进标题区（实测踩到）。
  const yDraw = (v) => {
    const y = yOf(v);
    if (y < rect.y) return rect.y;
    const bot = rect.y + rect.h;
    if (y > bot) return bot;
    return y;
  };
  return { yOf, yDraw };
}

/** 虚线水平线（参考线用）。GDI+ DashStyle::Dash 的近似。 */
function dashedHLine(cv, x0, x1, y, rgb, alpha, lineWidth, k) {
  const on = 6 * k, off = 4 * k;
  const yc = Math.round(y);
  const half = Math.max(0.5, lineWidth / 2);
  const yA = Math.round(y - half + 0.5), yB = Math.round(y + half - 0.5);
  let x = x0, draw = true;
  while (x < x1) {
    const seg = Math.min(draw ? on : off, x1 - x);
    if (draw) {
      for (let yy = yA; yy <= yB; yy++) cv.hLine(x, x + seg - 1, yy, rgb, alpha);
    }
    x += seg;
    draw = !draw;
  }
}

function drawClipMark(cv, x, y, up, rgb, k) {
  const h = 7 * k, w = 5.5 * k;
  const tri = up
    ? [[x, y - h], [x - w, y + h * 0.4], [x + w, y + h * 0.4], [x, y - h]]
    : [[x, y + h], [x - w, y - h * 0.4], [x + w, y - h * 0.4], [x, y + h]];
  paintPaths(cv, [tri], rgb, 1, 4);
}

/**
 * 画一个子图。
 * @returns {{markLabels:Array<{text:string,color:number[],w:number,h:number}>}}
 */
/**
 * 决定日期轴上该画哪些标签（返回索引数组）。
 *
 * **抽成纯函数是为了能被测试** —— 这段逻辑原来内联在 drawPanel 里，
 * "标签会不会挤在一起"没有任何断言守着，只能靠肉眼看图（而我就是这么发现
 * 写死的 `/30` 不够用的：365 天和 46 天都恰好踩在临界上，末尾几个日期开始互相压）。
 *
 * 密度按**像素间距**算，不按点数：45° 斜排文字占的横向宽度不是字号，而是它的
 * 投影 —— 旋转 -45° 后横幅占 `w·cos45 ≈ 0.707w`（日期串约 100px → 约 71px）。
 * 所以"最多画 30 个"这种按点数定的上限根本管不住，字号一变就失效。
 *
 * @param {number} n        数据点数（= 天数）
 * @param {number} plotW    绘图区宽度（未乘超采样系数，即逻辑像素）
 * @param {number} maxLabelW 最长日期串的**像素**宽度
 * @param {number} k        缩放系数（超采样倍率）
 */
export function pickDateLabelIndices(n, plotW, maxLabelW, k = 1, maxLabelH = 0) {
  if (!(n > 0)) return [];
  // ⚠️ 水平占用必须算 **(宽 + 高) × 0.707**，不能只算宽度。
  // 45° 斜排文字的水平投影 = W·cos45 + H·sin45 = (W+H)·0.707 ——
  // 只算 W 会少算约一个行高（实测「10-08」85.8px 宽 + 31px 高：
  // 按 61px 排、实际需要 82px，于是标签**紧贴甚至重叠**）。
  // 余量 8k 只是防抗锯齿。
  const minSpacing = (maxLabelW + maxLabelH) * Math.SQRT1_2 + 8 * k;
  const maxLabels = Math.max(2, Math.floor(plotW / minSpacing));
  // 目标步长 **10 天**（数据是逐日的，所以 10 个点 = 10 天）—— 用户要求"间隔改成 10 天"。
  // 像素间距不够时才被迫放大步长（那是安全下限，不是目标）。
  // 之所以 10 天放得下：标签格式是 `MM-DD`（5 字符，投影后约 55px），
  // 一年 37 个标签 × 55px ≈ 2000px < 绘图区 ~3300px；换成 `YYYY-MM` 就放不下了。
  const TARGET_EVERY = 10;
  const labelEvery = Math.max(TARGET_EVERY, Math.ceil(n / maxLabels));
  const idx = [];
  for (let i = 0; i < n; i += labelEvery) idx.push(i);
  // **最后一天一定画** —— 否则"数据到哪天为止"这个信息会缺（实测阿贝拉那张 10-07 没画出来）。
  if (idx.length === 0 || idx[idx.length - 1] !== n - 1) {
    // 和已画的最后一个挨太近就替换掉它，免得两个日期叠在一起
    if (idx.length > 0 && (n - 1) - idx[idx.length - 1] < Math.max(1, Math.floor(labelEvery / 2))) {
      idx[idx.length - 1] = n - 1;
    } else {
      idx.push(n - 1);
    }
  }
  return idx;
}

/**
 * 柱状图的柱宽（逻辑像素）。与 pickDateLabelIndices 同理抽出来供测试。
 *
 * 留出可见间隙：一年 365 根若贴成实心块，单日数据点就看不出边界，
 * 而"哪天放量了"正是下子图要回答的问题。
 */
/**
 * 版面常量导出给测试用。
 *
 * ⚠️ 为什么不干脆让测试去读源码解析常量：实测 `readFileSync(new URL(...), 'utf8')`
 * 在这条路径上没按预期返回文本，正则拿到 undefined，于是字号算成 NaN，
 * 断言全变成"间距 ≥ NaNpx"（恒真）——**测试看着在跑，其实什么都没验**。
 * 直接把值导出，测试拿到的就是渲染时真正用的那份。
 */
export const METRICS = { PT, TITLE_PX, LABEL_PX, AXIS_PX, CAP_PX };

/**
 * 柱宽（**设备像素**）。
 *
 * ⚠️ 签名里为什么要分开 `k` 和 `zs`：这是修一个真缺陷。
 *
 * 原来只有 `k` 一个参数，下限写成 `2.2 * k` —— 只跟超采样倍率挂钩，**不跟画布宽度走**。
 * 于是画布越宽，`slot` 越小、柱子被动跟着变细，下限却纹丝不动：
 * 附图从 1480 宽提到 1680 宽之后，`slot` 从 4.8 掉到 4.2，`slot*0.55 = 2.3` 刚好压到下限，
 * 柱子只剩 **2px**（之前 4.4px），比改动前还细 —— 用户看到的就是"柱子更糊、更花"。
 *
 * 现在下限按 `k * zs` 走（= 与画布等比），柱子在不同尺寸的画布上**观感一致**。
 * 上限仍是 `slot * 0.55` 且给相邻柱留 1px 缝，保证不糊成一块。
 */
export function barWidthFor(slot, k = 1, zs = 1) {
  return Math.max(2.6 * k * zs, Math.min(slot * 0.55, slot - 1 * k * zs));
}

/**
 * 一根柱子的纵向几何：`{ y, h }`，两个值都**已取整**为整数像素。
 *
 * ⚠️ 抽出来是因为这里踩过一个"只能看图才发现"的 bug：
 * 原实现是 `fillRect(round(x), round(y), bw, hh)`，其中 `hh = base - y` 是**浮点**。
 * 顶边取整了、高度没取整 → 实际底边 = `round(y) + (base - y) ≈ base ± 0.5`，
 * **每根柱子差半个像素**。表现是柱子底部参差不齐、冒出抗锯齿的锯齿缺口
 * （用户报的"下方图最左边贴图错误"属于这类）。
 *
 * 现在顶边和底边**各自取整后再算高度**，底边严格落在基线上、所有柱子对齐。
 *
 * @param {number} yRaw    柱顶的未取整 y
 * @param {number} baseRaw 基线的未取整 y
 */
export function barSpan(yRaw, baseRaw) {
  const y = Math.round(yRaw);
  const h = Math.max(1, Math.round(baseRaw) - y);
  return { y, h };
}

/**
 * 柱子的横向几何：`{ x, w }`，左闭右开的整数像素区间。
 *
 * ⚠️ 这个函数修的是一个"看图才发现"的缺陷：原来只取整左边界和宽度
 * （`round(cx - barW/2)`、`round(barW)`），柱子实宽只有 4~5px 时左右边界会
 * **落在像素中间**，两侧各留一条 50% 蓝 + 50% 白的软边。
 * 细柱子本来就窄，这两条软边等于从柱子上啃掉两侧；相邻几根柱子的软边连起来，
 * 看起来就是"柱子底部被挖掉一个白色三角"（用户报的"贴图错误"）。
 *
 * 按**边界**取整（左右各自 round，宽度 = 右 - 左）之后，边缘干净、无软边。
 */
export function barSpanX(cxRaw, barWRaw) {
  const left = Math.round(cxRaw - barWRaw / 2);
  const right = Math.round(cxRaw + barWRaw / 2);
  return { x: left, w: Math.max(1, right - left) };
}

/** 版面设计基准宽度。字号/边距都以它为准等比缩放。 */
export const DESIGN_W = 1740;

/**
 * 版面缩放因子 = 画布宽度 / 设计宽度，下限 0.72。
 *
 * 抽成纯函数是为了**能被测试** —— 这个因子的缺失是一个真实缺陷：
 * 原来字号只乘超采样倍率 `k`、与画布尺寸无关，于是"查价时附的那张小图"
 * （原 1180×660）上文字相对画布大得离谱 —— 纵轴刻度 `69.28亿` 把左边距撑到画布的 25%
 * （1740 那张只占 16%），绘图区被挤扁：横轴只放得下 9 个日期、
 * 成交量图例和纵轴挨在一起。**用户看到的现象是"优化没生效"，因为他日常看的正是那张附图。**
 *
 * 有了它，同一套字号/边距在 1180 / 1480 / 1740 宽的画布上观感一致。
 */
export function layoutScale(outW) {
  return Math.max(0.72, Number(outW) / DESIGN_W);
}

/**
 * 去掉**相邻重复文案**的日期标签索引。
 *
 * 为什么需要单抽一层：日期标签是月份粒度，46 天那张里连续 30 个索引的文案都是
 * 「9月」。`pickDateLabelIndices` 按索引步进（它只保证索引的像素间距够），
 * 会连续命中同一个月，画出 `8月 8月 8月 8月 9月 9月 …` —— 实测出现过，
 * 用户完全会当成 bug。
 *
 * 两个约束分开管：**间距**归 pickDateLabelIndices，**文案去重**归这里。
 */
export function dedupeDateLabels(indices, labels) {
  const out = [];
  let last = null;
  for (const i of indices) {
    const t = String(labels[i]);
    if (t === last) continue;
    last = t;
    out.push(i);
  }
  return out;
}

function drawPanel(ctx, rect, series, dateLabels, bigNumbers, unit, axis, withDates, power, opts) {
  const { cv, font, k, W, H, mTop, botRect, n, state } = ctx;
  const series0 = arr(series);
  const { yOf, yDraw } = makeTransform(rect, axis, power);
  const xOf = (i) => rect.x + rect.w * i / (n - 1);
  const markLabels = [];

  // 面板底 + 边框
  cv.fillRect(rect.x, rect.y, rect.w, rect.h, [255, 255, 255], 1);
  const bw1 = Math.max(1, Math.round(k));
  for (let t = 0; t < bw1; t++) {
    cv.hLine(rect.x, rect.x + rect.w, rect.y + t, AXIS, 1);
    cv.hLine(rect.x, rect.x + rect.w, rect.y + rect.h - t, AXIS, 1);
    cv.vLine(rect.x + t, rect.y, rect.y + rect.h, AXIS, 1);
    cv.vLine(rect.x + rect.w - t, rect.y, rect.y + rect.h, AXIS, 1);
  }

  // 竖网格：先画，让数据线压在上面。贯穿两个面板。
  const tickEvery = Math.max(1, Math.ceil(n / 14));
  const gridBottom = botRect.y + botRect.h;
  for (let i = 0; i < n; i += tickEvery) {
    cv.vLine(Math.round(xOf(i)), mTop, gridBottom, GRID, 1);
  }

  // 横网格 + 纵轴刻度标签
  const tickTexts = [];
  {
    let v = axis.hi, guard = 0;
    while (v >= axis.lo - 1e-9 && guard < 200) {
      const y = yOf(v);
      if (v > axis.lo + 1e-9) cv.hLine(rect.x, rect.x + rect.w, y, GRID, 1);
      const txt = fmtAxisLabel(v, bigNumbers);
      tickTexts.push(txt);
      const tw = font.measure(txt, AXIS_PX * k);
      const th = font.lineHeight(AXIS_PX * k);
      font.drawText(cv, txt, AXIS_PX * k, rect.x - 12 * k - tw, y - th / 2, INK);
      v -= axis.step;
      guard++;
    }
  }
  if (ctx.debug) {
    console.error(`DBG ticks(unit=${unit || '-'}): ${tickTexts.join(' | ')}`);
  }

  // 单位写**右上角内侧**。左下角会撞上贴底的线；左上角外侧会和最高刻度标签挤
  // 在同一行（"ISK" 被刻度的白色底衬压掉一半，看起来像乱码）。右上角是唯一空着的角落。
  if (unit) {
    const uw = font.measure(unit, AXIS_PX * k);
    const uh = font.lineHeight(AXIS_PX * k);
    const ux = rect.x + rect.w - uw - 6 * k;
    const uy = rect.y + 4 * k;
    cv.fillRect(ux - 4 * k, uy - 2 * k, uw + 8 * k, uh + 4 * k, [255, 255, 255], 232 / 255);
    font.drawText(cv, unit, AXIS_PX * k, ux, uy, DIM);
  }

  const slot = rect.w / n;

  // ── 高低价之间填一条淡色带 ──
  // alpha 用 12 实测**几乎看不见**（大多数日子当日高低差很小，在量程里只有
  // 3~7 像素，再被两条各 2px 的描边盖住就完全消失）。改成 34。
  if (opts.bandFill && series0.length === 2
      && String(series0[0].type) === 'line' && String(series0[1].type) === 'line') {
    const up = arr(series0[0].values), dn = arr(series0[1].values);
    let ok = true;
    const top = [];
    for (let i = 0; i < n; i++) {
      const a = num(up[i]), b = num(dn[i]);
      if (a === null || b === null) { ok = false; break; }
      top.push([xOf(i), yDraw(a)]);
    }
    const poly = top.slice();
    if (ok) {
      for (let i = n - 1; i >= 0; i--) {
        const b = num(dn[i]);
        if (b === null) { ok = false; break; }
        poly.push([xOf(i), yDraw(b)]);
      }
    }
    if (ok && poly.length >= 4) {
      poly.push(poly[0]);   // 闭合
      const bandColor = col(series0[0].color);
      paintPaths(cv, [poly], bandColor, 34 / 255, 2);
      // 紧贴两条线各描一条极淡的同色线，把"带子的边界"和"线本身"焊在一起，
      // 免得细窄处看起来只是一条模糊的粗线
      const edge = 0.8 * k;
      for (let i = 0; i + 1 < top.length; i++) {
        strokePolyline(cv, [top[i], top[i + 1]], bandColor, Math.max(1, edge), 70 / 255);
      }
    }
  }

  // ── 数据系列 ──
  for (const s of series0) {
    const vals = arr(s.values);
    const color = col(s.color);

    if (String(s.type) === 'bar') {
      // 柱宽逻辑见 barWidthFor()（抽出去是为了能被单测）
      // ⚠️ 第 3 个参数传 1：`slot` 进入本函数时是**未除 zs** 的设备像素宽度，
      // 它本身就带着版面缩放，所以下限按 slot 推出即可。
      // 之前误传 `zs`（那是 render() 的局部变量，这里根本没有）→ 直接 `zs is not defined`、
      // 画图失败并静默退回纯文本。这是同一个作用域坑的第二次，故记在这里。
      const barW = barWidthFor(slot, k, 1);
      const base = rect.y + rect.h;                 // 基线（柱子都从这里往上长）
      for (let i = 0; i < n; i++) {
        const d = num(vals[i]);
        if (d === null) continue;
        const x = rect.x + (i + 0.5) * slot;
        // 顶边/底边各自取整后算高度 —— 见 barSpan() 的说明（差半像素会让柱底参差）
        const { y: yT, h: hh } = barSpan(yOf(d), base);
        // ⚠️ 柱子的**左右边缘也各自吸附到整数像素**，不能只取整左边界+取整宽度。
        //
        // 原来写的是 `fillRect(round(cx - barW/2), yT, round(barW), hh)`：
        // 柱子实宽只有 4~5px 时，取整后的左右边界会**落在像素中间**，
        // 于是两侧各留一条 `rgb(143,196,242)`（50% 蓝 + 50% 白）的软边。
        // 细柱子本来就窄，这两条软边视觉上等于**从柱子上啃掉两侧**；
        // 相邻几根柱子的软边连起来，看起来就是"柱子底部被挖掉一个白色三角"
        // —— 用户报的"下方图贴图错误"就是这个（我一开始误判成裁剪标记/日期底衬）。
        //
        // 按边界取整（左闭右开）之后，柱宽是 4px 或 5px 的整数，边缘干净、无软边。
        const { x: xL, w: bwi } = barSpanX(x, barW);
        cv.fillRect(xL, yT, bwi, hh, color, 1);
      }
      continue;
    }

    // 折线
    const penW = (s.quiet ? 1.4 : 2.0) * k;
    const clipUp = [], clipDown = [];
    let run = [];
    const flush = () => {
      if (run.length >= 2) strokePolyline(cv, run, color, penW, 1);
      run = [];
    };
    for (let i = 0; i < n; i++) {
      const d = num(vals[i]);
      if (d === null) { flush(); continue; }
      const px = xOf(i), py = yDraw(d);
      run.push([px, py]);
      // 超界判定用**原始值**和轴范围比，而不是看钳制后的坐标
      // （钳制后就分不出"刚好在边界"和"冲出去了"）
      if (d > axis.hi) clipUp.push(px);
      else if (d < axis.lo) clipDown.push(px);
    }
    flush();

    // 被裁掉的极值：贴边缘画箭头。**每个方向只画一个**（画满会变成一排噪点），
    // 取该方向里离中位数最远的那个点，也就是"最夸张的那次"。
    if (clipUp.length) {
      clipUp.sort((a, b) => a - b);
      drawClipMark(cv, clipUp[Math.floor(clipUp.length / 2)], rect.y + 3 * k, true, color, k);
    }
    if (clipDown.length) {
      clipDown.sort((a, b) => a - b);
      drawClipMark(cv, clipDown[Math.floor(clipDown.length / 2)], rect.y + rect.h - 3 * k, false, color, k);
    }
  }

  // ── 参考线（只在价格面板）──
  // 标签**不画在绘图区里**（那会挡住数据线），统一收集起来交给调用方，
  // 放到两个面板之间的空白带里。
  if (opts.bandFill) {
    for (const an of arr(ctx.spec.price && ctx.spec.price.annotations)) {
      const av = num(an.value);
      if (av === null) continue;
      const my = yOf(av);
      const acol = col(an.color);
      const aw = Math.max(1, (an.strong ? 2.0 : 1.2) * k);
      // 超出面板范围的参考线不画线（那个值被裁掉了），但标签仍然要出现 ——
      // 否则读者不知道还有这么一条线存在
      if (my >= rect.y && my <= rect.y + rect.h) {
        dashedHLine(cv, rect.x + 1, rect.x + rect.w - 1, my, acol, 1, aw, k);
      }
      const mtxt = String(an.label == null ? '' : an.label);
      if (mtxt) {
        markLabels.push({
          text: mtxt, color: acol,
          w: font.measure(mtxt, AXIS_PX * k),
          h: font.lineHeight(AXIS_PX * k),
        });
      }
    }
  }

  // 下子图全为 0 时（冷门货常见）：整片空白会被当成图坏了，写一句说明
  if (opts.emptyText) {
    const etxt = String(opts.emptyText);
    const ew = font.measure(etxt, LABEL_PX * k);
    font.drawText(cv, etxt, LABEL_PX * k,
      rect.x + (rect.w - ew) / 2, rect.y + rect.h / 2 - font.lineHeight(LABEL_PX * k) / 2, DIM);
  }

  // ── 日期轴：45° 斜排，**只给最下面那个子图画** ──
  // 每个子图都画的话，斜排文字会从下子图一路斜穿进上子图的数据区，
  // 看起来像斜线，会误判成数据出错（实测）。
  if (withDates) {
    const axisBase = rect.y + rect.h;
    // 日期标签的字号单独一档（比纵轴刻度略小）—— 一年要放 37 个（每 10 天一个），
    // 用刻度那档字号时「10-08」的水平占用 82px、37 个需要 3000px 出头，刚好放不下。
    const datePx = DATE_PX * k;
    let maxLabelW = 0;
    for (const dl of dateLabels) {
      const w = font.measure(String(dl), datePx);
      if (w > maxLabelW) maxLabelW = w;
    }
    const labelH = font.lineHeight(datePx);
    // ⚠️ 传给间距公式的是**字形高度**，不是 `lineHeight()`。
    // `lineHeight` 是排版用的行盒（含行距），「10-08」实测 31.8px，
    // 而数字的实际墨迹高度只有约 `0.75 × 字号` ≈ 18px —— 用行盒会把
    // 需要的间距算大约 10px，一年就少放 3 个标签、步长从 10 天涨到 11 天。
    // 这里要回答的是"两串斜排文字会不会**碰到**"，就该用墨迹范围。
    const glyphH = datePx * 0.75;

    // 索引间距（pickDateLabelIndices）+ 文案去重（dedupeDateLabels），两件事分开管。
    //
    // ⚠️ `rect.w` 直接用，**不要除以 k** —— 同量纲要求：
    //    `maxLabelW` 是按 `datePx`（设备像素）量的，函数内部也按设备像素算。
    //    原来传的是 `rect.w / k`（逻辑像素），两者差 k 倍 → maxLabels 少算一半，
    //    步长被迫放大到 20 多天（用户要 10 天，实际画出来 22 天）。
    //    这类"量纲混用"不报错、只是结果悄悄偏小，只能按公式手算一遍才发现。
    const idx = dedupeDateLabels(
      pickDateLabelIndices(n, rect.w, maxLabelW, k, glyphH), dateLabels);

    // ── 锚点下移量 ──
    //
    // ⚠️⚠️ 这个量必须覆盖**斜排版面框的最高点**，否则日期的白色底衬会从基线下方
    // 斜插进成交量柱子里 —— 那就是用户反复报的"下图贴图 bug"。
    //
    // 版面框（见 font.js 的 drawText）：局部坐标 x 从 -6k 到 w+6k、
    // y 从 -(ascent+4k) 到 (labelH+6k-ascent-4k)。旋转 -45° 后 y' = 0.707·(y - x)，
    // 最高点出现在 **x 最大、y 最小**那个角：
    //     drop ≥ 0.707 · (ascent + 4k + w + 6k) = 0.707 · (w + ascent + 10k)
    //
    // 实测「10-08」：w≈67、ascent≈18、k≈1.93 → 需要 73.7px，
    // 而旧公式 `w * 0.72 + 8k` 只给 63.6px —— **少 10px**，于是每个日期标签
    // 都在柱子底部啃出一个白色三角（标签每 10 天一个，缺口就每 10 天一个）。
    // 旧公式只考虑文字的**宽度**，漏了版面框旋转后由**高度**贡献的那一份。
    const ascent = font.ascent(datePx);
    const drop = (maxLabelW + ascent + 10 * k) * Math.SQRT1_2 + 4 * k;
    const anchorY = axisBase + drop;
    const angle = -Math.PI / 4;
    for (const i of idx) {
      const txt = String(dateLabels[i]);
      const w = font.measure(txt, datePx);
      const x = xOf(i);
      // 斜排文字下面垫半透明白：不垫底下的网格线会穿透，读不清。
      // 底衬矩形按 DrawString 的版面框定义（-6k,-4k, w+12k, 24k），
      // 换算到本模块的"基线在 0"局部坐标就是 y 从 -ascent-4k 起。
      const local = rectPath(-6 * k, -ascent - 4 * k, w + 12 * k, labelH + 6 * k);
      const rotated = rotatePaths([local], angle).map((p) => p.map(([px, py]) => [px + x, py + anchorY]));
      paintPaths(cv, rotated, [255, 255, 255], 244 / 255, 2);
      font.drawText(cv, txt, datePx, x, anchorY, INK, { angle });
    }
  }

  return { markLabels };
}

function drawLegend(cv, font, k, rect, items) {
  const list = arr(items);
  if (!list.length) return;
  const boxW = 26 * k, itemGap = 30 * k;
  const widths = list.map((it) => font.measure(String(it.label), LABEL_PX * k));
  let total = 0;
  for (const w of widths) total += boxW + 6 * k + w;
  total += itemGap * (list.length - 1);
  let x = rect.x + (rect.w - total) / 2;
  const y = rect.y - 32 * k;
  for (let i = 0; i < list.length; i++) {
    cv.fillRect(Math.round(x), Math.round(y), Math.round(boxW), Math.round(16 * k), col(list[i].color), 1);
    font.drawText(cv, String(list[i].label), LABEL_PX * k, x + boxW + 6 * k, y - 4 * k, INK);
    x += boxW + 6 * k + widths[i] + itemGap;
  }
}

// ─────────────────────────── 字体加载（模块级缓存）───────────────────────────

let _fonts = null;

/**
 * 懒加载字体。第一次调用会走回退链，之后复用。
 * @returns {{regular:import('./font.js').Font, bold:import('./font.js').Font, picked:string, boldPicked:string, tried:Array}}
 */
export function getFonts(chain = DEFAULT_FONT_CHAIN) {
  if (_fonts) return _fonts;
  const { font: regular, tried } = loadFontChain(chain);
  let bold = regular, boldPicked = regular.file + ' (回退到正文)';
  try {
    const b = loadFontChain(BOLD_CHAIN);
    bold = b.font; boldPicked = b.picked;
  } catch { /* 没有粗体就用正文，标题只是不加粗 */ }
  _fonts = { regular, bold, picked: regular.file, boldPicked, tried };
  return _fonts;
}

/** 清掉字体缓存（测试用） */
export function resetFonts() { _fonts = null; }

// ─────────────────────────── 主入口 ───────────────────────────

/**
 * 渲染走势图。
 *
 * @param {object} spec 与 chart.js 的 buildChartSpec() 产出同构
 * @param {{fonts?:{regular:object,bold:object}, debug?:boolean}} [opts]
 * @returns {Buffer} PNG
 */
export function render(spec, opts = {}) {
  if (!spec || typeof spec !== 'object') throw new Error('render: spec 必须是对象');
  const dates = arr(spec.dates);
  if (dates.length < 2) throw new Error('render: spec.dates 至少需要 2 个点');
  if (spec.price == null || spec.volume == null) throw new Error('render: spec.price / spec.volume 缺失');

  const fonts = opts.fonts || getFonts();
  const font = fonts.regular;
  const boldFont = fonts.bold || fonts.regular;

  const outW = Number(spec.width) || 1630;
  const outH = Number(spec.height) || 900;
  const n = dates.length;

  // 超采样倍率。上限同时受画布尺寸约束（3600x2400 是 GDI+ 那版的经验上限，
  // 这里保留是为了内存与耗时可预期）。
  let ss = Number(spec.superSample) || 1;
  if (ss < 1) ss = 1;
  if (ss > 3) ss = 3;
  if (outW * ss > 3600 || outH * ss > 2400) ss = 1;

  const k = ss;                 // 超采样倍率。字号/线宽/边距/偏移都要乘它**和** zs
  const W = outW * ss, H = outH * ss;

  /**
   * 版面缩放因子：**字号与边距按画布宽度等比缩放**。
   *
   * ⚠️ 这个因子是补一个真实缺陷：原来字号/边距只乘 `k`（超采样倍率），与画布尺寸无关。
   * 于是"查价时附的那张小图"（1180×660）上，文字相对画布**大得离谱** ——
   * 纵轴刻度 `69.28亿` 在 32px 下约 200px 宽，把左边距撑到画布的 25%
   * （1740 那张只占 16%），绘图区被挤扁：横轴只能塞下 9 个日期、成交量图例和轴挨在一起。
   * 用户看到的就是"优化没生效"——因为**他日常看的正是这张附图**。
   *
   * 有了它，同一套字号/边距在 1180 / 1480 / 1740 宽的画布上观感一致。
   * 下限 0.72 是防止极窄画布把字压到读不出来。
   *
   * ⚠️ 变量名刻意叫 `zs` 而不是 `s`：本文件里 `s` 已经被 `for (const s of series0)`
   * 用作循环变量，用 `s` 会被**遮蔽**，在循环里静默取到 series 对象、
   * 算出 NaN 或错误尺寸（实测踩到：裁剪标记被误乘成了 `7 * k * s`）。
   */
  const zs = layoutScale(outW);

  const cv = new Canvas(W, H);
  cv.fill(255, 255, 255);

  const pSeries = arr(spec.price.series);
  const vSeries = arr(spec.volume.series);

  // ── 版面先算出来（面板高度决定纵轴能放几个刻度），再算轴范围，最后才定左边距 ──
  // 顺序不能反：早先轴范围在版面之前算，只能把刻度数写死成 7，而成交量面板矮，
  // 7 个刻度的标签会叠在一起（实测）。
  const mRight = 44 * k * zs;
  const mBottom = 150 * k * zs;
  // 两个面板之间的间距。原来 130k 留了一大块空白（图上看着是浪费），价格面板才是主角。
  // 84k → 108k：这条带子现在要放参考线标签（最多两行）+ 裁剪说明。
  const gap = 88 * k * zs;
  // 顶部要同时装下：标题(34k 起笔) + 副标题(最多两行) + 图例。
  // ⚠️ 副标题是 12pt、行高约 22px(×k)、起笔在 78k，两行就到 122k ——
  //    mTop 取小了第二行会压住图例（实测踩过）。
  const mTop = 152 * k * zs;

  const availH = H - mTop - mBottom - gap;
  // 价格面板给到 0.76（原 0.68）：用户要"上方走势图调高一点、大一点"。
  // 同时把面板间距从 108k 收到 88k —— 那段带子只放参考线标签+裁剪说明，
  // 108 是当初为了"放得下两行"留的余量，实测一行就够（标签短、不再带日期），
  // 收窄后省下的高度直接归价格面板。
  // 成交量面板从 0.32 降到 0.24：它是辅助信息，够看出"哪天放量"即可。
  const panelTopH = Math.floor(availH * 0.76);
  const panelBotH = Math.floor(availH * 0.24);

  // 面板高度决定纵轴能放几个刻度：标签高约 22k px，留 1.6 倍余量
  const tickFit = (panelH) => {
    const per = 22.0 * k * zs * 1.6;
    const c = Math.floor(panelH / per);
    return c < 3 ? 3 : (c > 8 ? 8 : c);
  };
  const topMaxTicks = tickFit(panelTopH);
  const botMaxTicks = tickFit(panelBotH);

  const topAxis = getAxisRange(pSeries, 7, false, topMaxTicks, spec.priceAxis, k);
  const botAxis = getAxisRange(vSeries, 7, true, botMaxTicks, null, k);

  if (opts.debug || process.env.CHART_DEBUG === '1') {
    console.error(`DBG top: lo=${topAxis.lo} hi=${topAxis.hi} step=${topAxis.step} maxTicks=${topMaxTicks} clipNote=[${topAxis.clipNote}]`);
    console.error(`DBG bot: lo=${botAxis.lo} hi=${botAxis.hi} step=${botAxis.step} maxTicks=${botMaxTicks}`);
  }

  // 左边距由**最宽的那个刻度标签**决定 —— 否则 "100,000,000.00" 会把左边距撑破、压到绘图区上
  const widestTick = (axis, big) => {
    let widest = 0;
    let v = axis.hi, guard = 0;
    while (v >= axis.lo - 1e-9 && guard < 200) {
      const w = font.measure(fmtAxisLabel(v, big), AXIS_PX * k * zs);
      if (w > widest) widest = w;
      v -= axis.step;
      guard++;
    }
    return widest;
  };
  let tickW = Math.max(widestTick(topAxis, false), widestTick(botAxis, true));
  if (!(tickW > 0)) tickW = 60 * k * zs;

  const mLeft = Math.ceil(tickW + 34 * k * zs);
  const plotW = W - mLeft - mRight;
  if (plotW <= 10) throw new Error(`render: 绘图区宽度算出来是 ${plotW}，画布太窄或刻度标签太宽`);

  const topRect = { x: mLeft, y: mTop, w: plotW, h: panelTopH };
  const botRect = { x: mLeft, y: mTop + panelTopH + gap, w: plotW, h: panelBotH };

  // ── 标题 / 副标题 ──
  if (spec.title) {
    boldFont.drawText(cv, String(spec.title), TITLE_PX * k * zs, mLeft, 34 * k * zs, INK);
  }

  const sub = [];
  if (spec.spanText) sub.push(String(spec.spanText));
  if (spec.updatedText) sub.push(String(spec.updatedText));
  if (sub.length) {
    const subMaxW = W - mLeft - mRight;
    const topSubY = 78 * k * zs;
    const subLineH = font.lineHeight(CAP_PX * k * zs) + 4 * k * zs;
    const legendBandTop = mTop - 40 * k * zs;
    const subMaxH = Math.max(0, legendBandTop - topSubY);
    const subText = sub.join('   ·   ');
    if (font.measure(subText, CAP_PX * k * zs) <= subMaxW) {
      font.drawText(cv, subText, CAP_PX * k * zs, mLeft, topSubY, DIM);
    } else if (sub.length > 1 && subMaxH >= subLineH * 2) {
      // 折两行：副标题太长时会和图例叠在一起（实测），所以先折行、再截断
      const line1 = sub[0];
      const line2 = sub.slice(1).join('   ·   ');
      if (font.measure(line1, CAP_PX * k * zs) <= subMaxW) {
        font.drawText(cv, line1, CAP_PX * k * zs, mLeft, topSubY, DIM);
        font.drawText(cv, ellipsize(font, line2, CAP_PX * k * zs, subMaxW), CAP_PX * k * zs, mLeft, topSubY + subLineH, DIM);
      } else {
        font.drawText(cv, ellipsize(font, subText, CAP_PX * k * zs, subMaxW), CAP_PX * k * zs, mLeft, topSubY, DIM);
      }
    } else {
      font.drawText(cv, ellipsize(font, subText, CAP_PX * k * zs, subMaxW), CAP_PX * k * zs, mLeft, topSubY, DIM);
    }
  }

  // ── 两个面板 ──
  const ctx = { cv, font, k: k * zs, W, H, mTop, botRect, n, spec, debug: !!(opts.debug || process.env.CHART_DEBUG === '1') };

  const topRes = drawPanel(ctx, topRect, pSeries, dates, false, 'ISK', topAxis, false, 1.0,
    { bandFill: true, emptyText: '' });

  // 成交量：分布常是"大量小值 + 少数巨峰"。0.5 试过偏猛（柱子都长得差不多，
  // 反而看不出哪个是大单），0.55 保留了"大柱子明显更高"的层次。
  let volMax = 0;
  for (const s of vSeries) for (const v of arr(s.values)) { const d = num(v); if (d !== null && d > volMax) volMax = d; }
  const botRes = drawPanel(ctx, botRect, vSeries, dates, true, '', botAxis, true, 0.55,
    { bandFill: false, emptyText: volMax <= 0 ? '这段时间没有成交记录' : '' });

  // ── 图例（各面板上方）──
  drawLegend(cv, font, k * zs, topRect, pSeries.map((s) => ({ label: s.label, color: s.color })));
  drawLegend(cv, font, k * zs, botRect, vSeries.map((s) => ({ label: s.label, color: s.color })));

  // ── 面板之间那条带子：参考线标签 + 裁剪说明 ──
  // 这条带子原来是纯空白，现在承载**所有**本来会压住数据线的文字。
  // 每条标签前画一小段同色短横线，读者靠颜色和面板里的虚线对应。
  let bandTop = topRect.y + topRect.h + 6 * k * zs;
  const bandGap = 22 * k * zs, ledW = 12 * k * zs;
  let markX = topRect.x;
  const bandRight = topRect.x + topRect.w;
  for (const m of arr(topRes.markLabels)) {
    const need = ledW + 5 * k * zs + m.w;
    // 放不下就换行（标签最坏情况有 4 条，换行后仍在带内）
    if ((markX + need) > bandRight && markX > topRect.x) {
      markX = topRect.x;
      bandTop += m.h + 5 * k * zs;
    }
    const ly = bandTop + m.h * 0.55;
    cv.hLine(markX, markX + ledW, Math.round(ly), m.color, 1);
    font.drawText(cv, m.text, AXIS_PX * k * zs, markX + ledW + 5 * k * zs, bandTop, m.color);
    markX += need + bandGap;
  }

  // 裁剪说明：跟在参考线标签的**同一行**（放右下角会压线，实测）。
  // **必须写出来** —— 裁了却不说，读者会把轴顶当成真实最高价（那是骗人）。
  if (topAxis.clipNote) {
    const txt = topAxis.clipNote + '（▲ 见最高/▼ 见最低）';
    const tw = font.measure(txt, CAP_PX * k * zs);
    const th = font.lineHeight(CAP_PX * k * zs);
    const need = tw + 8 * k * zs;
    if ((markX + need) > bandRight && markX > topRect.x) {
      markX = topRect.x;
      bandTop += th + 5 * k * zs;
    }
    cv.fillRect(markX - 3 * k * zs, bandTop - 1 * k * zs, tw + 8 * k * zs, th + 3 * k * zs, [242, 245, 248], 232 / 255);
    font.drawText(cv, txt, CAP_PX * k * zs, markX, bandTop, DIM);
  }

  // ── 底部说明 ──
  if (spec.caption) {
    const cy = Math.min(H - 24, botRect.y + botRect.h + 106 * k * zs);
    font.drawText(cv, String(spec.caption), CAP_PX * k * zs, mLeft, cy, DIM);
  }

  // ── 降采样回目标尺寸 ──
  const final = downsample(cv, outW, outH, ss);
  return final.toPNG(6);
}

/** render 的便捷包装：直接返回 {base64, bytes}，和旧 renderChart() 的返回形状一致 */
export function renderToBase64(spec, opts = {}) {
  const buf = render(spec, opts);
  const info = inspectPNG(buf);
  if (!info.ok) throw new Error(`render 产出的不是合法 PNG：${info.reason}`);
  return { base64: buf.toString('base64'), bytes: buf.length, width: info.width, height: info.height };
}
