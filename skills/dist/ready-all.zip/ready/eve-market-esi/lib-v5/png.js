// png.js —— 纯 Node 内置模块实现的 PNG 编码器 + 绘图画布
//
// 只依赖 node:zlib。没有第三方包。
//
// PNG 的构成（本项目用到的部分）：
//   8 字节魔数 89 50 4E 47 0D 0A 1A 0A
//   IHDR 块：宽、高、位深 8、颜色类型 6（RGBA）、压缩/滤波/隔行都是 0
//   IDAT 块：zlib.deflateSync(每行前缀一个 filter 字节 + RGBA 像素)
//   IEND 块
// 每个块 = 长度(4, BE) + 类型(4, ASCII) + 数据 + CRC32(4, BE，覆盖 类型+数据)
//
// 实测（1630x900 纯色，level 9）：7156 字节，27ms。
// 用 System.Drawing（GDI+，完全独立的解码实现）能正常打开，像素值逐位一致。

import zlib from 'node:zlib';

// ─────────────────────────── CRC32 ───────────────────────────
// PNG 规范附录 D：多项式 0xEDB88320（反射形式），初值/终值都取反。
const CRC_TABLE = (() => {
  const t = new Int32Array(256);
  for (let n = 0; n < 256; n++) {
    let c = n;
    for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    t[n] = c;
  }
  return t;
})();

export function crc32(buf, start = 0, end = buf.length) {
  let c = 0xffffffff;
  for (let i = start; i < end; i++) c = CRC_TABLE[(c ^ buf[i]) & 0xff] ^ (c >>> 8);
  return (c ^ 0xffffffff) >>> 0;
}

function chunk(type, data) {
  const out = Buffer.allocUnsafe(12 + data.length);
  out.writeUInt32BE(data.length, 0);
  out.write(type, 4, 'latin1');
  data.copy(out, 8);
  out.writeUInt32BE(crc32(out, 4, 8 + data.length), 8 + data.length);
  return out;
}

const PNG_MAGIC = Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]);

/**
 * 把紧密排列的 RGBA 像素编码成 PNG。
 * @param {number} width
 * @param {number} height
 * @param {Uint8Array|Buffer} rgba 长度必须是 width*height*4
 * @param {number} level zlib 压缩级别 0..9（默认 6）
 * @returns {Buffer}
 */
export function encodePNG(width, height, rgba, level = 6) {
  const need = width * height * 4;
  if (rgba.length !== need) throw new Error(`encodePNG: 像素长度 ${rgba.length} != ${width}x${height}x4 = ${need}`);

  // 加 filter 字节。这里固定用 filter 0（None）：
  // 换成 Paeth/Sub 能把照片类内容压小 ~15%，但本项目的图大面积是纯白，
  // deflate 自己就能吃掉，换 filter 反而多一遍逐像素运算，不划算。
  const stride = width * 4;
  const raw = Buffer.allocUnsafe((stride + 1) * height);
  const src = Buffer.isBuffer(rgba) ? rgba : Buffer.from(rgba.buffer, rgba.byteOffset, need);
  for (let y = 0; y < height; y++) {
    raw[y * (stride + 1)] = 0;
    src.copy(raw, y * (stride + 1) + 1, y * stride, y * stride + stride);
  }
  return encodeRawPNG(width, height, raw, level);
}

/**
 * 直接编码**已经带 filter 字节**的扫描线缓冲。
 * Canvas 就按这个布局分配内存，于是渲染路径上完全不需要那次整块拷贝
 * （1630x900 实测省掉约 25ms）。
 */
export function encodeRawPNG(width, height, raw, level = 6) {
  const ihdr = Buffer.allocUnsafe(13);
  ihdr.writeUInt32BE(width, 0);
  ihdr.writeUInt32BE(height, 4);
  ihdr[8] = 8;    // bit depth
  ihdr[9] = 6;    // color type 6 = truecolour with alpha
  ihdr[10] = 0;   // compression = deflate
  ihdr[11] = 0;   // filter method 0
  ihdr[12] = 0;   // interlace = none

  return Buffer.concat([
    PNG_MAGIC,
    chunk('IHDR', ihdr),
    chunk('IDAT', zlib.deflateSync(raw, { level })),
    chunk('IEND', Buffer.alloc(0)),
  ]);
}

/** 校验一段 Buffer 是不是 PNG，并读出尺寸。调用方拿它当"渲染成功"的守门员。 */
export function inspectPNG(buf) {
  if (!buf || buf.length < 24) return { ok: false, reason: 'too short' };
  for (let i = 0; i < 8; i++) if (buf[i] !== PNG_MAGIC[i]) return { ok: false, reason: 'bad magic' };
  const width = buf.readUInt32BE(16), height = buf.readUInt32BE(20);
  return { ok: true, width, height, bytes: buf.length };
}

// ─────────────────────────── 画布 ───────────────────────────
/**
 * RGBA 画布。
 *
 * ⚠️ 内部缓冲**按 PNG 扫描线布局**分配：每行开头多一个 filter 字节（恒为 0）。
 * 这样 toPNG() 可以零拷贝直接 deflate。任何直接操作 .raw 的代码都必须用
 * rowOff(y) 拿行首偏移，**不要**用 y*width*4。
 */
export class Canvas {
  constructor(width, height) {
    this.width = width;
    this.height = height;
    this.stride = width * 4;
    this.rowStride = this.stride + 1;
    this.raw = Buffer.alloc(this.rowStride * height);
    // filter 字节全 0 = filter None

    // ⚠️ alpha 通道**必须**初始化成 255。
    // Buffer.alloc 是全 0，而 blend() 只做 source-over 混 RGB、从不写 alpha
    // （这是对的：alpha 混合不该改目标 alpha）。于是"只调 blend、没先 fill()"
    // 的画布会整张 alpha=0 —— 图片在任何查看器里都是**全透明/全白**，
    // 而 RGB 数据其实完好，非常难查。这里一次性铺好，去掉这个坑。
    for (let y = 0; y < height; y++) {
      const o = y * this.rowStride + 1;
      for (let x = 0; x < width; x++) this.raw[o + x * 4 + 3] = 255;
    }
  }

  /** 第 y 行第 0 个像素的字节偏移（已跳过 filter 字节） */
  rowOff(y) { return y * this.rowStride + 1; }

  fill(r, g, b, a = 255) {
    for (let y = 0; y < this.height; y++) {
      const o = this.rowOff(y);
      for (let x = 0; x < this.width; x++) {
        const i = o + x * 4;
        this.raw[i] = r; this.raw[i + 1] = g; this.raw[i + 2] = b; this.raw[i + 3] = a;
      }
    }
  }

  /**
   * source-over 混合单个像素（整数坐标）。
   * 注意：**不改目标的 alpha** —— 目标 alpha 由构造函数初始化为 255、
   * 或用 fill() 显式设置。本项目的图都是不透明输出。
   */
  blend(x, y, r, g, b, a) {
    if (a <= 0) return;
    if (x < 0 || y < 0 || x >= this.width || y >= this.height) return;
    if (a > 1) a = 1;
    const i = this.rowOff(y) + x * 4, ia = 1 - a;
    this.raw[i] = (this.raw[i] * ia + r * a + 0.5) | 0;
    this.raw[i + 1] = (this.raw[i + 1] * ia + g * a + 0.5) | 0;
    this.raw[i + 2] = (this.raw[i + 2] * ia + b * a + 0.5) | 0;
  }

  fillRect(x0, y0, w, h, rgb, alpha = 1) {
    const [r, g, b] = rgb;
    const xa = Math.max(0, Math.round(x0)), xb = Math.min(this.width, Math.round(x0 + w));
    const ya = Math.max(0, Math.round(y0)), yb = Math.min(this.height, Math.round(y0 + h));
    if (xb <= xa || yb <= ya) return;
    for (let y = ya; y < yb; y++) {
      const o = this.rowOff(y);
      for (let x = xa; x < xb; x++) {
        const i = o + x * 4, ia = 1 - alpha;
        this.raw[i] = (this.raw[i] * ia + r * alpha + 0.5) | 0;
        this.raw[i + 1] = (this.raw[i + 1] * ia + g * alpha + 0.5) | 0;
        this.raw[i + 2] = (this.raw[i + 2] * ia + b * alpha + 0.5) | 0;
      }
    }
  }

  /** 水平 1px 线（网格/边框用；整数坐标，不需要抗锯齿） */
  hLine(x0, x1, y, rgb, alpha = 1) {
    const yi = Math.round(y);
    if (yi < 0 || yi >= this.height) return;
    const [r, g, b] = rgb;
    const a = Math.max(0, Math.min(1, alpha)), ia = 1 - a;
    const o = this.rowOff(yi);
    const xa = Math.max(0, Math.round(Math.min(x0, x1)));
    const xb = Math.min(this.width - 1, Math.round(Math.max(x0, x1)));
    for (let x = xa; x <= xb; x++) {
      const i = o + x * 4;
      this.raw[i] = (this.raw[i] * ia + r * a + 0.5) | 0;
      this.raw[i + 1] = (this.raw[i + 1] * ia + g * a + 0.5) | 0;
      this.raw[i + 2] = (this.raw[i + 2] * ia + b * a + 0.5) | 0;
    }
  }

  vLine(x, y0, y1, rgb, alpha = 1) {
    const xi = Math.round(x);
    if (xi < 0 || xi >= this.width) return;
    const [r, g, b] = rgb;
    const a = Math.max(0, Math.min(1, alpha)), ia = 1 - a;
    const ya = Math.max(0, Math.round(Math.min(y0, y1)));
    const yb = Math.min(this.height - 1, Math.round(Math.max(y0, y1)));
    for (let y = ya; y <= yb; y++) {
      const i = this.rowOff(y) + xi * 4;
      this.raw[i] = (this.raw[i] * ia + r * a + 0.5) | 0;
      this.raw[i + 1] = (this.raw[i + 1] * ia + g * a + 0.5) | 0;
      this.raw[i + 2] = (this.raw[i + 2] * ia + b * a + 0.5) | 0;
    }
  }

  toPNG(level = 6) {
    return encodeRawPNG(this.width, this.height, this.raw, level);
  }

  /** 取一个像素（用来做测试断言） */
  getPixel(x, y) {
    const i = this.rowOff(y) + x * 4;
    return [this.raw[i], this.raw[i + 1], this.raw[i + 2], this.raw[i + 3]];
  }
}

// ─────────────────────────── 降采样 ───────────────────────────
/**
 * 整数倍盒式降采样：把 (w*ss, h*ss) 缩回 (w, h)。
 *
 * 为什么用盒式而不是双三次：超采样倍率是**整数**，盒式平均正好是"每个输出像素
 * 取 ss×ss 个子样本的均值"，也就是超采样的定义本身，没有额外振铃。
 * GDI+ 那版用 HighQualityBicubic，在整数倍缩小上效果接近，但双三次会引入轻微
 * 过冲（白底黑线边缘出现一圈比背景更白的亮边），盒式没有。
 *
 * @param {Canvas} src 源画布（尺寸必须是 dstW*ss × dstH*ss）
 * @param {number} dstW
 * @param {number} dstH
 * @param {number} ss
 * @returns {Canvas}
 */
export function downsample(src, dstW, dstH, ss) {
  if (ss === 1) return src;
  const out = new Canvas(dstW, dstH);
  const n = ss * ss;
  const half = n >> 1;
  for (let y = 0; y < dstH; y++) {
    const oo = out.rowOff(y);
    for (let x = 0; x < dstW; x++) {
      let r = 0, g = 0, b = 0;
      for (let dy = 0; dy < ss; dy++) {
        const so = src.rowOff(y * ss + dy) + (x * ss) * 4;
        for (let dx = 0; dx < ss; dx++) {
          const i = so + dx * 4;
          r += src.raw[i]; g += src.raw[i + 1]; b += src.raw[i + 2];
        }
      }
      const i = oo + x * 4;
      out.raw[i] = (r + half) / n | 0;
      out.raw[i + 1] = (g + half) / n | 0;
      out.raw[i + 2] = (b + half) / n | 0;
      out.raw[i + 3] = 255;
    }
  }
  return out;
}
