// 本地「中文名 → type_id」索引。
//
// ───────────────── 为什么需要它 ─────────────────
//
// 网易 ESI（官方）**没有开放按名字搜索的接口**：
//   · GET  /search/?search=xxx        → 404（这条路径没开）
//   · POST /universe/ids/             → 只有 14KB，能批量，但**只认英文名**
//                                       （中文会被当成**角色名**匹配，返回 characters）
//   · POST /universe/names/           → 反过来：给 ID 要中文名，可用
//
// 而群友说的是中文名（「三钛合金」「阿贝拉」）。所以做法是：
//   **把 ESI 里所有物品的中文名一次性拉到本地，自己建索引、自己搜。**
//
// 代价与收益：
//   · 建索引 = 57 页 ID（每页 1000）+ 57 次批量反查 = 114 个请求，约 10~20 秒
//   · 之后**完全脱离第三方**（原来是靠 ceve 的 searchname 才能搜中文）
//   · 搜索在本地做，比网络搜索快，还能做模糊/别名匹配
//   · 索引按天缓存（ESI 的 universe 数据本身有 12 小时缓存头）
//
// 索引文件落在系统临时目录，7 天自动过期重建。约 1.5~2.5 MB。

import { readFileSync, writeFileSync, mkdirSync, existsSync, rmSync, statSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
// ⚠️ 动态导入 + 版本串：静态裸 import 会让父模块的缓存拖出旧的 esi.js（见 lib-version.js）
import { importLib } from './lib-version.js';
const { typesPage, namesByIds } = await importLib('./esi.js');

const CACHE_MS = 24 * 3600 * 1000;      // 索引 24 小时内直接用
const RETRY_MS = 10 * 60 * 1000;        // 上次失败后 10 分钟内不重试（避免反复打上游）
const MAX_PAGES = 60;                   // 兜住：目前 57 页

function indexPath() {
  const dir = join(tmpdir(), 'qq-agent-eve-market');
  try { mkdirSync(dir, { recursive: true }); } catch { /* 落不了盘就退化成纯内存 */ }
  return join(dir, 'esi-types-zh.json');
}

/** 内存里的索引：{ at, list: [{typeId,name}], byName: Map } */
let cache = null;
let lastFailAt = 0;
let building = null;

function buildLookup(list) {
  const byName = new Map();
  const byLower = new Map();
  for (const it of list) {
    if (!byName.has(it.name)) byName.set(it.name, []);
    byName.get(it.name).push(it);
    const lower = it.name.toLowerCase();
    if (!byLower.has(lower)) byLower.set(lower, []);
    byLower.get(lower).push(it);
  }
  return { byName, byLower };
}

function adopt(raw) {
  if (!raw || !Array.isArray(raw.list) || raw.list.length < 1000) return null;
  cache = { at: Number(raw.at) || 0, list: raw.list, ...buildLookup(raw.list) };
  return cache;
}

function readDisk() {
  try {
    const p = indexPath();
    if (!existsSync(p)) return null;
    return JSON.parse(readFileSync(p, 'utf8'));
  } catch { return null; }
}

function writeDisk(list) {
  try {
    const p = indexPath();
    writeFileSync(p, JSON.stringify({ at: Date.now(), list }), 'utf8');
    return true;
  } catch { return false; }
}

/**
 * 确保索引可用。首次会去 ESI 拉（约 10~20 秒），之后走缓存。
 * @returns {Promise<{ok:boolean, count:number, built:boolean, error?:string}>}
 */
export async function ensureIndex(fetchImpl, { force = false, log } = {}) {
  // 1) 内存
  if (!force && cache && Date.now() - cache.at < CACHE_MS) {
    return { ok: true, count: cache.list.length, built: false };
  }
  // 2) 一个进程内只允许一次构建，避免并发打上游
  if (building) return building;

  building = (async () => {
    try {
      // 3) 磁盘
      if (!force) {
        const disk = readDisk();
        if (disk && Date.now() - (Number(disk.at) || 0) < CACHE_MS && adopt(disk)) {
          return { ok: true, count: cache.list.length, built: false, fromDisk: true };
        }
      }
      // 失败冷却：刚失败过就别再打
      if (!force && lastFailAt && Date.now() - lastFailAt < RETRY_MS) {
        return { ok: false, count: cache?.list.length ?? 0, built: false, error: '上次构建失败，稍后再试' };
      }

      log?.('正在从 ESI 拉取物品中文名索引…');
      const first = await typesPage(fetchImpl, 1);
      const pages = Math.min(first.pages || 1, MAX_PAGES);
      const allIds = [...first.ids];
      for (let p = 2; p <= pages; p++) {
        const r = await typesPage(fetchImpl, p);
        allIds.push(...r.ids);
      }

      // 批量反查中文名：一次 1000 个
      const list = [];
      const BATCH = 1000;
      for (let i = 0; i < allIds.length; i += BATCH) {
        const chunk = allIds.slice(i, i + BATCH);
        try {
          const named = await namesByIds(fetchImpl, chunk);
          list.push(...named);
        } catch { /* 单批失败不影响整体，后面还有别的批次 */ }
      }

      if (list.length < 1000) {
        lastFailAt = Date.now();
        return { ok: false, count: list.length, built: false, error: `只取到 ${list.length} 个物品名` };
      }

      cache = { at: Date.now(), list, ...buildLookup(list) };
      const persisted = writeDisk(list);
      log?.(`中文名索引就绪：${list.length} 个物品（${persisted ? '已缓存到本地' : '仅内存'}）`);
      return { ok: true, count: list.length, built: true, persisted };
    } catch (error) {
      lastFailAt = Date.now();
      return { ok: false, count: cache?.list.length ?? 0, built: false, error: String(error?.message ?? error) };
    } finally {
      building = null;
    }
  })();

  return building;
}

/** 索引状态（不触网）。 */
export function indexStatus() {
  return {
    ready: Boolean(cache && cache.list.length),
    count: cache?.list.length ?? 0,
    at: cache?.at ?? 0,
    ageMs: cache ? Date.now() - cache.at : null
  };
}

/**
 * 干扰词：这些后缀的商品在"按名字搜"时几乎从不是要找的那个。
 *
 * 实测：搜「地狱天使级」时「地狱天使级残骸 / 蓝图 / 涂装」和真船一样匹配，
 * 但群友问「地狱天使级」想问的是船。把这些压到后面，**但不丢弃** ——
 * 群友真问「地狱天使级蓝图」时，那是完整匹配、照样排第一。
 */
const NOISE_SUFFIX = /(蓝图|涂装|残骸|纪念品|皮肤|SKIN|Blueprint|Skin)$/i;

/**
 * 按名字搜物品。
 *
 * 排序规则（贴合 EVE 的命名习惯 + 实测调出来的）：
 *   1. 完全相同
 *   2. 以关键词开头
 *   3. 包含关键词
 * 同级内：**非干扰词优先**，然后**短名优先** —— 搜「胡蜂」时「胡蜂 I」要排在
 * 「加达里海军胡蜂」前面，因为前者才是群友大概率想问的。
 *
 * @returns {Array<{typeId:number, name:string}>} 最多 limit 条
 */
export function searchByName(query, { limit = 20 } = {}) {
  const q = String(query ?? '').trim();
  if (!q || !cache) return [];
  const qLower = q.toLowerCase();
  const qIsNoisy = NOISE_SUFFIX.test(q);   // 群友自己要的就是蓝图/涂装 → 别压

  const scored = [];
  const seen = new Set();
  const push = (it, score) => {
    if (seen.has(it.typeId)) return;
    seen.add(it.typeId);
    scored.push({ ...it, score, noisy: !qIsNoisy && NOISE_SUFFIX.test(it.name) ? 1 : 0 });
  };

  for (const it of cache.byName.get(q) ?? []) push(it, 0);
  for (const it of cache.list) {
    if (seen.has(it.typeId)) continue;
    const name = it.name;
    if (name.startsWith(q)) push(it, 1);
    else if (name.toLowerCase().includes(qLower)) push(it, 2);
  }

  return scored
    .sort((a, b) => (a.score - b.score)
      || (a.noisy - b.noisy)
      || (a.name.length - b.name.length)
      || a.name.localeCompare(b.name, 'zh-Hans-CN'))
    .slice(0, limit)
    .map(({ typeId, name }) => ({ typeId, name }));
}

/** 按 ID 取中文名（索引里有就直接拿，避免再打网络）。 */
export function nameOf(typeId) {
  const id = Number(typeId);
  if (!cache) return null;
  for (const it of cache.list) if (it.typeId === id) return it.name;
  return null;
}

/** 给测试/排障用：清掉内存与磁盘索引。 */
export function clearIndex() {
  cache = null;
  lastFailAt = 0;
  try { rmSync(indexPath(), { force: true }); } catch { /* 没有就算了 */ }
}

export function indexFile() { return indexPath(); }

export function indexFileAgeMs() {
  try { return Date.now() - statSync(indexPath()).mtimeMs; } catch { return null; }
}
