// 网易晨曦（国服）官方 ESI 客户端。
//
// 基址：https://ali-esi.evepc.163.com/latest
// 这是官方接口，比第三方镜像权威：**有真正的逐日历史**（402 天，含真实成交量），
// 挂单还带 order_id / issued（第三方镜像没有）。
//
// ───────────────── 与旧数据源（ceve-market）的关键差异 ─────────────────
//
// 1) **历史是现成的。** ceve 只有"截止现在往前 N 天"的聚合值，要靠差分反推、
//    而且只保留约 80 天。ESI 直接给逐日 high/low/average/volume/order_count，
//    402 天一天不差。所以"近一年走势图"到这一步才真正可能。
//
// 2) **volume 是真实成交量（股数），不是挂单量。** ceve 的 volume 是订单簿深度，
//    当时只能标成"挂单深度"。ESI 这个是当天成交了多少股，口径终于对了。
//
// 3) **没有"按中文名搜索"接口。** `/search/` 返回 404（这条路径网易没开放），
//    `/universe/ids/` 只认英文名。中文名靠 `?language=zh` 与
//    `POST /universe/names/` 拿 —— 所以品名解析走 lib-v5/names.js 的本地索引。
//
// 4) **挂单要自己按 system_id 过滤。** ESI 没有 ceve 的 `usesystem` 参数，
//    `/markets/{region}/orders/` 返回**整个星域**的挂单（带 system_id），
//    想看吉他就要筛 `system_id === 30000142`。
//
// 5) **带缓存头。** universe 类 12 小时、market 类约 1 小时。别频繁打，
//    本地也要缓存（见 lib-v5/names.js 与 index.js 的行情缓存）。

// ───────────────── 两个服务器的 ESI 基址 ─────────────────
//
//   chenxi  晨曦（国服）→ 网易官方 ESI（用户指定）
//   tq      欧服（宁静）→ CCP 官方 ESI
//
// 两边接口形状**完全一致**（都是标准 ESI），换服只换域名。
// 实测两边都给 402 天逐日历史，同一件货价格不同（三钛合金 8.47 vs 3.78），
// 说明确实是两个独立的经济体。
//
// 为什么没有第三个服：**曙光服的 ESI 找不到** —— 试过
// `esi.tiancity.com`、`serenity-esi.evepc.163.com` 都是 ENOTFOUND（DNS 不存在）。
// 所以设置里不留曙光项，免得出现"能配但永远查不到"的坑。
export const SERVERS = {
  chenxi: {
    key: 'chenxi',
    label: '晨曦',
    base: 'https://ali-esi.evepc.163.com/latest',
    aliases: ['晨曦', '国服', '网易', 'serenity', 'chenxi']
  },
  tq: {
    key: 'tq',
    label: '欧服',
    base: 'https://esi.evetech.net/latest',
    aliases: ['欧服', '宁静', '世界服', '国际服', 'tranquility', 'tq']
  }
};

export const DEFAULT_SERVER = 'chenxi';

/** 默认服务器基址（定义在 SERVERS 之后，不能提到前面去 —— 会撞暂时性死区）。 */
const ESI_BASE = SERVERS[DEFAULT_SERVER].base;

/** 服务器别名表（中文叫法 → key）。单一来源，避免两处定义漂移。 */
export function serverAliases() {
  const out = {};
  for (const s of Object.values(SERVERS)) {
    out[s.key] = s.key;
    for (const a of s.aliases) out[a.toLowerCase()] = s.key;
  }
  return out;
}

/** 认服务器：别名优先，认不出退回默认（不抛错，报价卡片总得有来源）。 */
export function resolveServer(name) {
  const raw = String(name ?? '').trim();
  if (!raw) return SERVERS[DEFAULT_SERVER];
  const key = serverAliases()[raw.toLowerCase()];
  return SERVERS[key] ?? SERVERS[DEFAULT_SERVER];
}

/** 常用贸易 hub。systemId 用于筛挂单，regionId 用于星域级接口。 */
export const HUBS = {
  jita: { key: 'jita', label: '吉他', systemId: 30000142, regionId: 10000002, stationId: 60003760 },
  amarr: { key: 'amarr', label: '艾玛', systemId: 30002187, regionId: 10000043 },
  dodixie: { key: 'dodixie', label: '多迪谢', systemId: 30002659, regionId: 10000032 },
  rens: { key: 'rens', label: '伦斯', systemId: 30002510, regionId: 10000030 },
  hek: { key: 'hek', label: '赫克', systemId: 30002053, regionId: 10000042 }
};

/** 地点对照表：给前缀解析用（认得出才是地点，认不出就不猜）。 */
export const LOCTABLE = HUBS;

const REGION_FORGE = 10000002;   // 伏尔戈（吉他所在星域）

export function resolveHub(input) {
  const raw = String(input ?? '').trim();
  if (!raw) return { ...HUBS.jita, assumed: true };
  const lower = raw.toLowerCase();
  if (HUBS[lower]) return { ...HUBS[lower] };
  for (const h of Object.values(HUBS)) {
    if (h.label === raw) return { ...h };
  }
  if (/^\d+$/.test(raw)) {
    const n = Number(raw);
    return {
      key: raw,
      label: `星系 ${raw}`,
      systemId: n < 10000000 ? n : undefined,
      regionId: n >= 10000000 ? n : REGION_FORGE
    };
  }
  return { key: raw, label: raw, regionId: REGION_FORGE };
}

const UA = { 'user-agent': 'qq-agent-eve-market/1.0 (+qq-agent skill)', accept: 'application/json' };

async function getJson(fetchImpl, url, { signal } = {}) {
  const res = await fetchImpl(url, { headers: UA, signal });
  if (!res.ok) {
    const body = await res.text().catch(() => '');
    throw new Error(`HTTP ${res.status}${body ? `：${body.slice(0, 100)}` : ''}`);
  }
  return res.json();
}

async function postJson(fetchImpl, url, payload, { signal } = {}) {
  const res = await fetchImpl(url, {
    method: 'POST',
    headers: { ...UA, 'content-type': 'application/json' },
    body: JSON.stringify(payload),
    signal
  });
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  return res.json();
}

/**
 * 逐日历史（**这是换源的核心收益**）。
 * @returns {Array<{date,highest,lowest,average,volume,order_count}>} 按日期升序
 */
export async function marketHistory(fetchImpl, typeId, { regionId = REGION_FORGE, base = SERVERS[DEFAULT_SERVER].base, signal } = {}) {
  const url = `${base}/markets/${regionId}/history/?type_id=${encodeURIComponent(typeId)}`;
  const data = await getJson(fetchImpl, url, { signal });
  if (!Array.isArray(data)) return [];
  return data
    .map((d) => ({
      date: String(d.date ?? ''),
      highest: Number(d.highest),
      lowest: Number(d.lowest),
      average: Number(d.average),
      volume: Number(d.volume) || 0,
      order_count: Number(d.order_count) || 0
    }))
    .filter((d) => d.date && Number.isFinite(d.highest) && Number.isFinite(d.lowest))
    .sort((a, b) => (a.date < b.date ? -1 : a.date > b.date ? 1 : 0));
}

/**
 * 星域级挂单（**含整个星域**，要自己按 system_id 过滤）。
 * 分页：响应头 x-pages 给总页数。
 * @returns {Array<order>} 已过滤到指定星系（给了 systemId 时）
 */
export async function regionOrders(fetchImpl, typeId, {
  regionId = REGION_FORGE, systemId, orderType, signal, maxPages = 5,
  base = SERVERS[DEFAULT_SERVER].base
} = {}) {
  const out = [];
  let page = 1;
  let pages = 1;
  do {
    const params = new URLSearchParams({ type_id: String(typeId), page: String(page) });
    if (orderType) params.set('order_type', orderType);
    const url = `${base}/markets/${regionId}/orders/?${params.toString()}`;
    const res = await fetchImpl(url, { headers: UA, signal });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    pages = Math.min(Number(res.headers.get('x-pages')) || 1, maxPages);
    const data = await res.json();
    if (!Array.isArray(data)) break;
    for (const o of data) {
      if (systemId && Number(o.system_id) !== Number(systemId)) continue;   // ← 只看目标星系
      out.push({
        orderId: o.order_id,
        price: Number(o.price),
        volumeRemain: Number(o.volume_remain),
        volumeTotal: Number(o.volume_total),
        minVolume: Number(o.min_volume) || 1,
        isBuy: Boolean(o.is_buy_order),
        locationId: o.location_id,
        systemId: o.system_id,
        issued: String(o.issued ?? ''),
        duration: Number(o.duration) || 0        // 挂单天数（90/30…），可算到期
      });
    }
    page++;
  } while (page <= pages);
  return out;
}

/** 单个物品的基础信息（含中文名：加 ?language=zh）。 */
export async function typeInfo(fetchImpl, typeId, {
  language = 'zh', base = SERVERS[DEFAULT_SERVER].base, signal
} = {}) {
  const q = language ? `?language=${encodeURIComponent(language)}` : '';
  const d = await getJson(fetchImpl, `${base}/universe/types/${encodeURIComponent(typeId)}/${q}`, { signal });
  return { typeId: Number(d.type_id), name: String(d.name ?? ''), groupId: d.group_id, volume: d.volume };
}

/** 批量 ID → 中文名（POST /universe/names/，一次可传很多）。 */
export async function namesByIds(fetchImpl, ids, { base = SERVERS[DEFAULT_SERVER].base, signal } = {}) {
  if (!Array.isArray(ids) || !ids.length) return [];
  const data = await postJson(fetchImpl, `${base}/universe/names/`, ids, { signal });
  if (!Array.isArray(data)) return [];
  return data
    .filter((x) => x?.category === 'inventory_type')
    .map((x) => ({ typeId: Number(x.id), name: String(x.name ?? '') }))
    .filter((x) => Number.isFinite(x.typeId) && x.name);
}

/** 名字 → ID（POST /universe/ids/）。**只认英文名**，中文会被当成角色名。 */
export async function idsByNames(fetchImpl, names, { base = SERVERS[DEFAULT_SERVER].base, signal } = {}) {
  if (!Array.isArray(names) || !names.length) return [];
  const data = await postJson(fetchImpl, `${base}/universe/ids/`, names, { signal });
  const list = Array.isArray(data?.inventory_types) ? data.inventory_types : [];
  return list.map((x) => ({ typeId: Number(x.id), name: String(x.name ?? '') }))
    .filter((x) => Number.isFinite(x.typeId));
}

/** 全部物品 ID 的一页（建中文名索引用；共 57 页 × 1000）。 */
export async function typesPage(fetchImpl, page, { base = SERVERS[DEFAULT_SERVER].base, signal } = {}) {
  const res = await fetchImpl(`${base}/universe/types/?page=${page}`, { headers: UA, signal });
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  const pages = Number(res.headers.get('x-pages')) || 1;
  const ids = await res.json();
  return { ids: Array.isArray(ids) ? ids.map(Number).filter(Number.isFinite) : [], pages };
}

/**
 * 全局参考价表：`/markets/prices/` 一次拿全，`type_id → average_price`。
 *
 * **为什么需要这个**：伊甸币（PLEX，type_id 44992）**不在常规挂单市场里** ——
 * 两个服的所有星域查挂单都是 0 条（实测：伏尔戈前 30000 条挂单里一条都没有）。
 * 它是 EVE 里的特殊物品，走独立的 PLEX 市场，ESI 的 `/markets/{region}/orders/`
 * 不提供它。`/markets/prices/` 是唯一能拿到它价格的地方（CCP 维护的参考均价）。
 *
 * 实测两个服的差异很大，别搞混：
 *   · 晨曦（网易）：均价 23,435,746 ISK，且有 25 天历史（到 2025-09-25，日成交几千个）
 *   · 欧服（CCP）  ：均价  4,712,023 ISK，**历史 0 天**（没有任何逐日数据）
 *
 * 整表 1.2~1.6 万项，比较重，所以这里缓存 1 小时（与 ESI 的 cache 头一致）。
 */
const priceTableCache = new Map();   // base -> { at, map }
export const PRICE_TABLE_TTL_MS = 60 * 60 * 1000;

export async function marketPrices(fetchImpl, { base = SERVERS[DEFAULT_SERVER].base, signal, force = false } = {}) {
  const hit = priceTableCache.get(base);
  if (!force && hit && Date.now() - hit.at < PRICE_TABLE_TTL_MS) return hit.map;
  const data = await getJson(fetchImpl, `${base}/markets/prices/`, { signal });
  const map = new Map();
  if (Array.isArray(data)) {
    for (const d of data) {
      const id = Number(d?.type_id);
      if (Number.isFinite(id)) map.set(id, Number(d.average_price) || 0);
    }
  }
  priceTableCache.set(base, { at: Date.now(), map });
  return map;
}

/** 单件物品的参考均价。表里没有就返回 null（**不要退化成 0**，那会被当成免费）。 */
export async function referencePrice(fetchImpl, typeId, { base = SERVERS[DEFAULT_SERVER].base, signal } = {}) {
  const map = await marketPrices(fetchImpl, { base, signal });
  const v = map.get(Number(typeId));
  return Number.isFinite(v) && v > 0 ? v : null;
}

/** 空间站名（中文）。挂单里只有 location_id，要写"哪个空间站"得查这个。 */
export async function stationName(fetchImpl, stationId, { base = SERVERS[DEFAULT_SERVER].base, signal } = {}) {
  try {
    const d = await getJson(fetchImpl, `${base}/universe/stations/${encodeURIComponent(stationId)}/?language=zh`, { signal });
    return String(d.name ?? '');
  } catch {
    return '';
  }
}

export { ESI_BASE, REGION_FORGE };