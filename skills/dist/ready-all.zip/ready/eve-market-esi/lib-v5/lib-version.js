// lib-v5 内部模块互相导入时用的**版本查询串**。
//
// ───────────────── 这个文件解决什么问题 ─────────────────
//
// Node 的 ESM 按 **URL** 缓存模块。技能重载只给**入口**加了时间戳
// （加载器里是 `import(`${entryUrl}?t=${Date.now()}`)`），所以：
//
//   入口是新的，但它内部 `import './lib-v5/chart.js'` 如果再静态 `import './render.js'`，
//   那一层的 URL 就永远是裸的 → 命中进程里的旧模块 → **改了没生效**。
//
// 实测踩到的具体形态：只改了 `render.js`、没动 `chart.js`，于是
// `chart.js` 的 URL 不变、被复用，它内部拉出来的还是**旧 render.js**。
// 代码明明落盘了、测试也全绿（测试每次新建进程），但线上就是旧行为 —— 极难排查。
//
// 本模块的 `QS` 取"`lib-v5/` 下所有 .js 的最新 mtime"。**任何**库文件一变，
// 所有库文件的导入 URL 一起变，上面那类漏洞就不存在了。
//
// 为什么不依赖"父模块 URL 上的查询串"：那样要求 index.js 必须记得给每个库文件加串，
// 一旦漏掉就静默退回裸 URL —— 又变回难查的状态。这里自己算，与加载方式无关。
//
// 代价：每次模块求值多做几次 statSync（6 个文件，微秒级）。库一次重载只求值一次。
import { statSync, readdirSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { join, dirname } from 'node:path';

export const HERE = dirname(fileURLToPath(import.meta.url));

/** `lib-v5/` 下所有 .js 里最新的 mtime；拿不到返回 0（调用方退回裸导入）。 */
export function libVersion() {
  try {
    let newest = 0;
    for (const f of readdirSync(HERE)) {
      if (!f.endsWith('.js')) continue;
      const m = statSync(join(HERE, f)).mtimeMs;
      if (m > newest) newest = m;
    }
    return newest;
  } catch {
    return 0;
  }
}

/** 形如 `?lib=1791478...`；取不到 mtime 时是空串（退回裸导入，行为降级但不崩）。 */
export const QS = (() => {
  const v = libVersion();
  return v ? `?lib=${v}` : '';
})();

/**
 * 导入同目录下的另一个库文件，带上版本串。
 *
 * 用法：`const { render } = await importLib('./render.js');`
 * ⚠️ 库内**不要**写静态 `import './xxx.js'`，那正是本文件要防的坑。
 */
export function importLib(relative) {
  return import(new URL(`${relative}${QS}`, import.meta.url).href);
}
