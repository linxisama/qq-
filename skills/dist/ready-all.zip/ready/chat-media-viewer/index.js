/**
 * 聊天记录看图看片 —— 把一条消息里的图片 / 动图 / 视频一次取全。
 *
 * ── 为什么要有这个插件（以及它和旧 chat-media 的区别）──────────────────────
 * 旧版把「图片」一律当静态图发出去，于是 GIF / 动态 WebP 到了模型眼里只剩第一帧
 * —— 群里表现就是「人家只看到第一帧诶」。动图的关键信息全在帧与帧之间，
 * 当静态图发等于丢掉了 90% 的内容。
 *
 * 这里的做法是**先认出它是动图**，再交给 video-watch 的 video.watch 能力展开成
 * 联络表（N 列 × M 行、每格带帧号、覆盖完整时间轴）。模型看到的是「一张网格」，
 * 读图顺序就是时间顺序，中间过程和结尾都在。
 *
 * ── 另外三件顺手做掉的事 ──────────────────────────────────────────────────
 * 1. 转发要先展开才拿得到里面的媒体。而群消息 id 是负数时，SnowLuma 会在
 *    get_forward_msg 里把负 id 当 res_id 用，恒报 "payload is empty"。所以先用
 *    get_msg 从消息段里捞出真正的 res_id，再带着它去展开（见 expandForward）。
 * 2. QQ 图床直链带 rkey，约 1 小时过期。直链挂了就用 file id 调 get_image
 *    让协议端换一份（可能是本地缓存，也可能是新直链）。
 * 3. 转发里套转发（套娃）很常见，里面还藏着媒体。按设置钻进去一起取。
 *
 * ── 能力依赖 ─────────────────────────────────────────────────────────────
 * video.watch      动图展开成联络表（**软依赖**：拿不到就退回当静态图，并说明原因）
 * video.frames     视频抽帧（软依赖，同上）
 * 两个都没有时本插件照常工作，只是画面取不到、如实告诉模型。
 */

import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

/** 运行时注入的 fetch（声明了 web_fetch 权限才有）。见 setup()。 */
let fetchImpl = null;

/**
 * 运行时注入的能力调用器（来自 setup(api) 的 api.capability / api.hasCapability）。
 *
 * 为什么存成模块级而不是塞进 ctx：工具 execute(ctx, args) 里的 ctx 是核心
 * 自己拼的（chatKey/onebot/store/videoReader/…），**没有 api**。而 video.watch
 * 是软依赖，只能在 setup 那一刻拿到入口，所以在这里接住。
 */
let capabilityFn = null;
let hasCapabilityFn = null;

/**
 * 转发正文的默认截断长度（字）。
 *
 * 以前是写死的 4000。改成可配置（settings.transcriptChars）后这条只作兜底：
 * 长转发（实测有 60 条、几百行的）不截断会把上下文撑爆，截太短又读不全，
 * 所以交给用户按自己的模型上下文权衡。
 */
const DEFAULT_TRANSCRIPT_CHARS = 4000;

// ── 清单 / 生命周期 ────────────────────────────────────────────────────────

export function available() {
  // 纯工具型：没有外部依赖，永远可用。
  // ⚠️ 必须同步返回（返回 Promise 是 truthy，会被当成"可用"而真的去调）。
  return { ok: true };
}

export function setup(api) {
  fetchImpl = api.fetch || null;
  capabilityFn = typeof api.capability === 'function' ? api.capability.bind(api) : null;
  hasCapabilityFn = typeof api.hasCapability === 'function' ? api.hasCapability.bind(api) : null;
  const cfg = () => ({ ...DEFAULTS, ...(api.config?.() ?? {}) });

  api.registerTool({
    id: 'view_media',
    name: '看聊天记录里的图与片',
    description:
      '把一条聊天记录里的图片、动图、视频一次看全，包括合并转发（转发的聊天记录）里面的，也包括转发里套着的转发。'
      + '动图会展开成带帧号的联络表（看得到中间过程和结尾）；视频会给抽帧截图。'
      + '参数 messageId 填那条消息在聊天记录里的 #数字。'
      + '消息里出现 [合并转发聊天记录] / [转发消息 …]，或几小时前的图现在点开 404 时用这个。'
      + '单独发来的图用 get_message_images、单独发来的视频用 read_video，不用这个工具。',
    category: 'query',
    icon: '🖼️',
    parameters: {
      type: 'object',
      properties: {
        messageId: {
          type: ['integer', 'string'],
          description: '那条消息自己的 QQ 消息 id（聊天记录里每条消息前面的 #数字，可能为负数）'
        },
        images: { type: 'integer', description: '这次最多看几张静态图，不填用设置里的默认值' },
        gifs: { type: 'integer', description: '这次最多展开几个动图，不填用设置里的默认值' },
        videos: { type: 'integer', description: '这次最多看几段视频，不填用设置里的默认值' },
        transcript: { type: 'boolean', description: '是否同时把转发里的文字一并给出，默认给' }
      },
      required: ['messageId']
    },
    async execute(ctx, args) {
      try {
        return await handleViewMedia(ctx, args || {}, cfg());
      } catch (error) {
        return {
          content: `取聊天记录里的画面失败：${error?.message ?? error}`,
          isError: true
        };
      }
    }
  });

  api.registerTool({
    id: 'repair_forwards',
    name: '补回打不开的转发',
    description:
      '把本会话里之前没展开成功的合并转发（存档里只剩 [合并转发聊天记录] 空壳的那些）重新取回来。'
      + '群友说"这个转发打不开"、或你想翻之前某条转发却只看到占位符时用。'
      + '不带参数就自动扫最近一批待修复的；带 messageId 只修指定的那条。',
    category: 'query',
    icon: '🩹',
    parameters: {
      type: 'object',
      properties: {
        messageId: { type: ['integer', 'string'], description: '只修指定的那条（聊天记录里的 #数字）' },
        limit: { type: 'integer', description: '自动扫的时候最多修几条，默认 10，最大 30' }
      }
    },
    async execute(ctx, args) {
      try {
        return await handleRepairForwards(ctx, args || {});
      } catch (error) {
        return { content: `补回转发失败：${error?.message ?? error}`, isError: true };
      }
    }
  });
}

export function dispose() {}

// ── 工具实现：看媒体 ──────────────────────────────────────────────────────

async function handleViewMedia(ctx, args, c) {
  const mid = Number(args.messageId);
  if (!Number.isFinite(mid)) {
    return { content: `messageId 得是聊天记录里的 #数字（可能是负数），你给的是「${args.messageId}」。`, isError: true };
  }

  const entry = ctx.store?.findByMid?.(ctx.chatKey, mid);
  if (!entry) {
    return {
      content: `当前会话的消息记录里找不到 ${mid}。`
        + 'id 要用聊天记录里每条消息前面那个 #数字，别自己编；想看更早的消息先用查看历史消息工具翻一下。',
      isError: true
    };
  }

  // ── 1) 收集媒体 ──
  const buckets = { images: [], gifs: [], videos: [] };
  const notes = [];
  const text = String(entry.text || '');
  const isForward = /\[合并转发|\[转发消息/.test(text);

  let transcript = '';
  let nodeCount = 0;

  if (isForward) {
    const ex = await expandForward(ctx, entry, c);
    if (ex.error) notes.push(ex.error);
    transcript = ex.transcript || '';
    nodeCount = ex.count || 0;
    // 转发展开出来的这一批**内部不去重**：同名文件是不同消息里的不同媒体
    for (const m of ex.media || []) pushMedia(buckets, m);
  }
  // 存档里那份是「同一条消息的另一个副本」，和上面撞了才去重
  const seen = new Set();
  for (const b of [buckets.images, buckets.gifs, buckets.videos]) for (const x of b) seen.add(mediaKey(x));
  for (const m of entry.media || []) pushMedia(buckets, m, seen);

  const total = buckets.images.length + buckets.gifs.length + buckets.videos.length;
  if (!total) {
    return {
      content: `消息 ${mid} 里没有取到图片、动图或视频`
        + `${isForward ? '（转发展开了但里面没有媒体，或内容已被 QQ 服务端丢弃）' : ''}。`,
      isError: false
    };
  }

  // ── 2) 取画面 ──
  const parts = [];
  const failed = [];
  const wantImages = clamp(pickNum(args.images, c.maxImages, 6), 0, 10);
  const wantGifs = clamp(pickNum(args.gifs, c.maxGifs, 3), 0, 6);
  const wantVideos = clamp(pickNum(args.videos, c.maxVideos, 2), 0, 4);

  for (const item of buckets.images.slice(0, wantImages)) {
    try {
      const dataUrl = await imageToDataUrl(ctx, item, c);
      if (dataUrl) parts.push({ type: 'image_url', image_url: { url: dataUrl } });
      else failed.push('一张图取不到（内容为空）');
    } catch (error) {
      failed.push(`一张图取不到：${short(error)}`);
    }
  }
  if (buckets.images.length > wantImages) {
    notes.push(`还有 ${buckets.images.length - wantImages} 张静态图没取（本次上限 ${wantImages} 张）`);
  }

  for (const item of buckets.gifs.slice(0, wantGifs)) {
    const r = await gifParts(ctx, item, c);
    parts.push(...r.parts);
    notes.push(...r.notes);
    failed.push(...r.failed);
  }
  if (buckets.gifs.length > wantGifs) {
    notes.push(`还有 ${buckets.gifs.length - wantGifs} 个动图没展开（本次上限 ${wantGifs} 个）`);
  }

  for (const item of buckets.videos.slice(0, wantVideos)) {
    const r = await videoParts(ctx, item, c);
    parts.push(...r.parts);
    notes.push(...r.notes);
    failed.push(...r.failed);
  }
  if (buckets.videos.length > wantVideos) {
    notes.push(`还有 ${buckets.videos.length - wantVideos} 段视频没处理（本次上限 ${wantVideos} 段）`);
  }

  // ── 3) 组装说明 ──
  const head = [];
  head.push(
    `消息 ${mid}${isForward ? `（合并转发，共 ${nodeCount} 条）` : ''}：`
    + `找到 ${buckets.images.length} 张静态图、${buckets.gifs.length} 个动图、${buckets.videos.length} 段视频。`
  );
  for (const n of notes) head.push(`· ${n}`);
  if (failed.length) head.push(`· 未取到：${failed.join('；')}`);

  const wantTranscript = args.transcript !== undefined ? Boolean(args.transcript) : c.includeTranscript !== false;
  if (wantTranscript && transcript) {
    // 上限可配（settings.transcriptChars）。被截断时必须说明，否则模型会把
    // "转发只到这里" 当成事实，后面几十条的内容就凭空消失了。
    const cap = clamp(pickNum(null, c.transcriptChars, DEFAULT_TRANSCRIPT_CHARS), 200, 100000);
    const body = transcript.length > cap ? transcript.slice(0, cap) : transcript;
    head.push('—— 转发正文 ——');
    head.push(body);
    if (transcript.length > cap) {
      head.push(`（正文太长，只给了前 ${cap} 字，后面还有 ${transcript.length - cap} 字没给。`
        + '想知道后面说了什么，可以调大「转发文字最多给多少字」，或者针对具体某一条再问。）');
    }
  }

  if (parts.length) {
    head.push('下面的画面就是里面的内容。动图是「联络表」：每格左上角的数字是帧号，从左到右、从上到下就是时间顺序，帧与帧之间看不到；视频给的是抽帧截图，同理。');
  } else {
    head.push('画面没能取到，只能给你上面这些信息。');
  }

  const textPart = { type: 'text', text: head.join('\n') };
  if (!parts.length) {
    return { content: head.join('\n'), isError: !transcript && !nodeCount };
  }

  // ── 4) 顺手把展开结果写回存档（失败不影响本次结果）──
  if (isForward && transcript && !/^\[合并转发 共\d+条\]/.test(text)) {
    try {
      if (typeof ctx.store?.updateByMid === 'function') {
        const media = [
          ...buckets.images.map((i) => ({ kind: 'image', file: i.file, url: i.url })),
          ...buckets.gifs.map((g) => ({ kind: 'image', file: g.file, url: g.url, gif: true })),
          ...buckets.videos.map((v) => ({ kind: 'video', file: v.file, url: v.url, path: v.path }))
        ];
        ctx.store.updateByMid(ctx.chatKey, entry.mid, {
          text: `[合并转发 共${nodeCount || '?'}条]\n${transcript}`,
          appendMedia: media
        });
      }
    } catch (error) {
      notes.push(`（写回存档失败，不影响本次结果：${short(error)}）`);
    }
  }

  // ── 5) 可选：把「取到了什么」发一条到群里 ──
  // 默认关闭。模型本来就会在回复里说看懂了什么，额外一条汇报只在
  // 用户想确认"工具真的跑了"时有用，所以做成开关而不是默认行为。
  if (c.sendInfoToChat === true && typeof ctx.sender === 'function') {
    try {
      const brief = `（看图看片：${isForward ? `转发展开 ${nodeCount} 条，` : ''}`
        + `静态图 ${Math.min(buckets.images.length, wantImages)}/${buckets.images.length}、`
        + `动图 ${Math.min(buckets.gifs.length, wantGifs)}/${buckets.gifs.length}、`
        + `视频 ${Math.min(buckets.videos.length, wantVideos)}/${buckets.videos.length}）`;
      await ctx.sender(brief);
    } catch { /* 发不出去不影响本次结果 */ }
  }

  return { content: [textPart, ...parts] };
}

// ── 工具实现：补回空壳转发 ────────────────────────────────────────────────

async function handleRepairForwards(ctx, args) {
  const limit = clamp(Number(args.limit) || 10, 1, 30);

  let targets;
  if (args.messageId != null && String(args.messageId).trim() !== '') {
    const mid = Number(args.messageId);
    if (!Number.isFinite(mid)) return { content: `messageId 得是 #数字，你给的是「${args.messageId}」。`, isError: true };
    const entry = ctx.store?.findByMid?.(ctx.chatKey, mid);
    if (!entry) return { content: `当前会话找不到消息 ${mid}。`, isError: true };
    targets = [entry];
  } else {
    const all = ctx.store?.recent?.(ctx.chatKey, { limit: 400 }) ?? [];
    targets = [];
    for (let i = all.length - 1; i >= 0 && targets.length < limit; i--) {
      const t = String(all[i]?.text ?? '');
      if (/^\[(合并转发|转发消息)/.test(t) && !/^\[合并转发 共\d+条\]/.test(t)) targets.push(all[i]);
    }
    if (!targets.length) {
      return { content: '本会话没有待补的转发，存档里的转发都是完整的。', isError: false };
    }
  }

  const repaired = [];
  const failures = [];
  for (const t of targets) {
    try {
      const ex = await expandForward(ctx, t, { includeNested: true, maxNestedDepth: 1 });
      const body = String(ex.transcript || '').trim();
      if (ex.error || !body) {
        failures.push({ messageId: t.mid, reason: ex.error || '这条转发里没有任何可读内容' });
        continue;
      }
      const newText = `[合并转发 共${ex.count || '?'}条]\n${body}`;
      if (typeof ctx.store?.updateByMid === 'function') {
        ctx.store.updateByMid(ctx.chatKey, t.mid, {
          text: newText,
          appendMedia: (ex.media || []).map((m) => ({
            kind: m.kind, file: m.file, url: m.url, path: m.path
          }))
        });
      }
      repaired.push({
        messageId: t.mid,
        lines: ex.count,
        media: (ex.media || []).length,
        preview: newText.split('\n').slice(0, 3).join(' / ').slice(0, 140)
      });
    } catch (error) {
      failures.push({ messageId: t.mid, reason: short(error) });
    }
  }

  const out = [`补回结果：成功 ${repaired.length} 条，失败 ${failures.length} 条。`];
  if (repaired.length) {
    out.push('—— 已补回 ——');
    for (const r of repaired) out.push(`· #${r.messageId}（${r.lines} 条，${r.media} 个媒体）：${r.preview}`);
    out.push('这些已经写回存档，以后直接读就能看到内容，不用再补。');
  }
  if (failures.length) {
    out.push('—— 补不回来 ——');
    for (const f of failures) out.push(`· #${f.messageId}：${f.reason}`);
    out.push('这些是 QQ 服务端已经把内容清掉了，只能如实说取不到。');
  }
  return { content: out.join('\n'), isError: false };
}

// ── 展开合并转发 ──────────────────────────────────────────────────────────

/**
 * 展开一条合并转发消息，返回 { transcript, media, count }。
 *
 * **必须优先用 res_id**（SnowLuma 的参数名是 `id`）：协议端只在 message_id 是
 * 正整数时才拿它去查 res_id；群消息 id 是负数，于是它把负 id 当 res_id 发给
 * QQ，恒报 retcode=100 "download forward message payload is empty"。
 * 所以先用 get_msg 把 res_id 捞出来。
 */
async function expandForward(ctx, entry, c = {}, depth = 0) {
  const media = [];
  try {
    const nodes = await fetchForwardNodes(ctx, entry.mid);
    if (!nodes.length) return { transcript: '', media, count: 0, error: '这条转发里没有任何可读内容' };

    const lines = [];
    for (const n of nodes) {
      const uid = String(n?.sender?.user_id ?? n?.user_id ?? '').trim();
      const who = String(n?.sender?.card || n?.sender?.nickname || uid || '?');
      const label = uid && uid !== who ? `${who}(QQ:${uid})` : who;
      const segs = Array.isArray(n?.message) ? n.message : (Array.isArray(n?.content) ? n.content : []);
      const body = segs.map(segmentText).join('').replace(/\s+/g, ' ').trim();
      if (body) lines.push(`${label}: ${body}`);

      for (const s of segs) {
        const d = s?.data ?? {};
        const type = String(s?.type);
        if (type === 'image') media.push({ kind: 'image', file: String(d.file ?? ''), url: String(d.url ?? '') });
        else if (type === 'mface') {
          // 商城表情（贴纸）：有的协议端给 url，有的只给 emoji id。
          // 老版 chat-media 完全不认这个段，转发里的表情包就全丢了。
          const u = String(d.url ?? d.emoji_url ?? '');
          if (u) media.push({ kind: 'image', file: String(d.file ?? ''), url: u, mface: true });
        } else if (type === 'video') {
          media.push({ kind: 'video', file: String(d.file ?? ''), url: String(d.url ?? ''), path: String(d.path ?? '') });
        } else if (type === 'forward' && c.includeNested !== false && depth < (Number(c.maxNestedDepth) || 1)) {
          // 转发里套转发：钻进去，把它里面的媒体也捞出来
          const nestedId = Number(n?.message_id ?? n?.real_id ?? 0) || null;
          if (nestedId) {
            const ex = await expandForward(ctx, { mid: nestedId }, c, depth + 1);
            if (ex.media?.length) media.push(...ex.media);
            if (ex.transcript) lines.push(`  [嵌套转发] ${ex.transcript.slice(0, 400)}`);
          }
        }
      }
    }
    return { transcript: lines.join('\n'), media, count: nodes.length };
  } catch (error) {
    return { transcript: '', media, count: 0, error: `转发展开失败：${short(error)}` };
  }
}

/**
 * 取转发的节点数组。两条路都试：
 *   A. get_forward_msg({ message_id }) —— 对正整数 id 有效
 *   B. get_msg 抠出 res_id → get_forward_msg({ id: res_id }) —— 对负数 id 有效
 */
async function fetchForwardNodes(ctx, midRaw) {
  const mid = Number(midRaw);
  if (!Number.isFinite(mid)) return [];
  const pick = (r) => (Array.isArray(r?.messages) ? r.messages : (Array.isArray(r?.data?.messages) ? r.data.messages : []));

  let firstError = null;
  try {
    const nodes = pick(await ctx.onebot.call('get_forward_msg', { message_id: mid }));
    if (nodes.length) return nodes;
  } catch (error) {
    firstError = error;
  }

  let resId = null;
  try {
    const msg = await ctx.onebot.call('get_msg', { message_id: mid });
    const segs = Array.isArray(msg?.message) ? msg.message : [];
    for (const s of segs) {
      if (String(s?.type) === 'forward') {
        const id = String(s?.data?.id ?? s?.data?.res_id ?? s?.data?.forward_id ?? '').trim();
        if (id) { resId = id; break; }
      }
    }
  } catch (error) {
    if (!firstError) firstError = error;
  }

  if (resId) {
    try {
      const nodes = pick(await ctx.onebot.call('get_forward_msg', { id: resId }));
      if (nodes.length) return nodes;
    } catch (error) {
      throw new Error(`${firstError?.message ?? 'message_id 取不到'}；换 res_id 也失败：${short(error)}`);
    }
  }

  if (firstError) throw firstError;
  return [];
}

/** 消息段 → 一行可读文本（和核心口径一致，够用即可）。 */
function segmentText(seg) {
  const d = seg?.data ?? {};
  switch (String(seg?.type)) {
    case 'text': return String(d.text ?? '');
    case 'at': return d.qq === 'all' ? '@全体成员' : `@${d.qq ?? ''}`;
    case 'image': return '[图片]';
    case 'mface': return '[表情]';
    case 'video': return '[视频]';
    case 'record': return '[语音]';
    case 'face': return '[表情]';
    case 'file': return `[文件${d.name ? ` ${d.name}` : ''}]`;
    case 'reply': return '[引用]';
    case 'forward': return '[嵌套转发]';
    case 'json': case 'xml': return '[卡片]';
    default: return seg?.type ? `[${seg.type}]` : '';
  }
}

// ── 媒体归类：这里是「动图不再被当静态图」的关键 ────────────────────────────

/** file id 优先（同一张图直链换过几次，file id 都不变）。 */
function mediaKey(m) {
  return String(m?.file || '').trim() || String(m?.url || '').trim();
}

/**
 * 按真实类型把一条媒体放进 静态图 / 动图 / 视频 三个桶。
 *
 * ⚠️ 去重规则：只在**同一个来源内部**去重（同一条媒体既从存档来、又从转发展开
 * 来，file/url 完全相同 → 算一条）。但**不能按 file 跨节点去重**：
 * 实测一条转发里有两段视频都叫 `nya.mp4`，那是两条独立消息里的两个视频，
 * 按 file 去重会把 4 段算成 3 段 —— 用户的感知就是"少了一段"。
 * 所以 seen 集合由调用方按来源维护，这里只归类、不去重。
 */
function pushMedia(buckets, m, seen = null) {
  if (!m || typeof m !== 'object') return null;
  const url = String(m.url || '');
  const file = String(m.file || '');
  const key = mediaKey(m);
  if (!key) return null;

  let bucket;
  if (m.kind === 'video') bucket = buckets.videos;
  else if (isAnimated(file, url)) bucket = buckets.gifs;
  else bucket = buckets.images;

  if (seen) {
    if (seen.has(key)) return null;
    seen.add(key);
  }
  bucket.push(m);
  return bucket;
}

/**
 * 判断一个图片资源是不是动图。
 *
 * 光看扩展名不够：QQ 经常把 GIF 存成 `.image` 或一串 hash，扩展名里什么都不代表；
 * 反过来 `?term=2` 之类的查询串会让 endsWith('.gif') 失效。所以两头都看：
 * 扩展名（去掉 query/hash）+ 路径里出现的动图标志。
 */
function isAnimated(file, url) {
  const strip = (s) => String(s || '').split(/[?#]/)[0].toLowerCase();
  const cands = [strip(file), strip(url)];

  for (const p of cands) {
    if (!p) continue;
    if (p.endsWith('.gif') || p.endsWith('.webp') || p.endsWith('.apng')) return true;
    // QQ 的一些内部命名会在路径里带 OriGIF / AnimatedImage 这类标记
    if (/\/(origif|animatedimage)\b/i.test(p)) return true;
    if (/[?&](term|isgif)=2\b/i.test(String(url || ''))) return true;
  }
  return false;
}

// ── 动图：交给 video-watch 展开成联络表 ─────────────────────────────────────

/**
 * 动图 → 联络表。
 *
 * 这是整个插件存在的理由。旧版把 gif 当 png/jpeg 发出去，模型只解第一帧。
 * 这里调 video.watch 能力（video-watch 技能提供），拿回一张
 * 「N 列 × M 行、每格带帧号、覆盖完整时间轴」的网格图。
 *
 * 拿不到能力时**退化成静态图**，并在说明里讲清楚"只给了首帧"，
 * 而不是假装看到了全部 —— 宁可少说，也别让模型编造中间发生了什么。
 */
async function gifParts(ctx, item, c) {
  const parts = [];
  const notes = [];
  const failed = [];

  let buf;
  try {
    buf = await imageBytes(ctx, item, c);
  } catch (error) {
    failed.push(`一个动图取不到：${short(error)}`);
    return { parts, notes, failed };
  }
  if (!buf?.length) {
    failed.push('一个动图取不到（内容为空）');
    return { parts, notes, failed };
  }

  // 真的 GIF 才值得展开；动态 webp 也走同一条路（vw.py 认 gif/webp）。
  const realGif = buf.length > 3 && buf[0] === 0x47 && buf[1] === 0x49 && buf[2] === 0x46;
  const realWebp = buf.length > 11 && buf.toString('ascii', 8, 12) === 'WEBP';
  if (!realGif && !realWebp) {
    // 名字像动图但其实是一张静态图 —— 按静态图发，别浪费一次展开
    parts.push({ type: 'image_url', image_url: { url: toDataUrl(buf) } });
    return { parts, notes, failed };
  }

  /**
   * 动图铺图的格数与列数。
   *
   * ⚠️ 上限 36 是**下游** video-watch 的硬限制，不是这里随便定的：
   *    `gifDetailSheet` 里写的是 `Math.min(36, ...)`。在设置里允许填更大的数
   *    却跑出 36 格，用户会以为设置没生效（实测 64 → 只出 36 格）。
   *    所以这里先按 36 夹一次，让行为和上限一致；填超了会明确告知。
   */
  const GIF_FRAMES_MAX = 36;
  const askedFrames = clamp(pickNum(null, c.gifFrames, 25), 4, 64);
  const GIF_COLS_MAX = 8;
  const frames = Math.min(askedFrames, GIF_FRAMES_MAX);
  const cols = clamp(pickNum(null, c.gifCols, 5), 2, GIF_COLS_MAX);
  if (askedFrames > GIF_FRAMES_MAX) {
    notes.push(`动图格数填的是 ${askedFrames}，超过上限 ${GIF_FRAMES_MAX}，已按 ${GIF_FRAMES_MAX} 格铺（再多每格就小到看不清了）`);
  }

  const workDir = makeWorkDir();
  const file = path.join(workDir, realGif ? 'input.gif' : 'input.webp');
  try {
    fs.writeFileSync(file, buf);
  } catch (error) {
    failed.push(`一个动图存不下来：${short(error)}`);
    cleanup(workDir);
    return { parts, notes, failed };
  }

  let sheet = null;
  if (videoWatchReady()) {
    try {
      const r = await callVideoWatch({ filePath: file, frames, cols, outDir: workDir });
      if (r?.ok && typeof r.sheet === 'string' && r.sheet.startsWith('data:image/')) sheet = r;
    } catch (error) {
      notes.push(`动图展开失败（${short(error)}），只能给首帧`);
    }
  } else {
    notes.push('动图展开能力（video-watch 技能）没开，只能给首帧');
  }

  if (sheet) {
    parts.push({ type: 'image_url', image_url: { url: sheet.sheet } });
    const tiles = Number(sheet.manifest?.tiles?.length) || frames;
    const t = sheet.manifest?.tiles || [];
    const span = t.length > 1
      ? `${Number(t[0]?.t ?? 0).toFixed(2)}~${Number(t[t.length - 1]?.t ?? 0).toFixed(2)} 秒`
      : '';
    const dur = Number(sheet.manifest?.duration);
    notes.push(
      `动图已展开成联络表：${sheet.manifest?.cols || cols} 列 × ${Math.ceil(tiles / (sheet.manifest?.cols || cols))} 行共 ${tiles} 格`
      + `${span ? `，覆盖 ${span}` : (Number.isFinite(dur) && dur ? `，总长 ${dur.toFixed(2)} 秒` : '')}`
      + '（格内左上角数字是帧号，按从左到右、从上到下就是时间顺序）'
    );
  } else {
    // 降级：首帧。必须说清楚，否则模型会以为这就是全部。
    parts.push({ type: 'image_url', image_url: { url: toDataUrl(buf) } });
    notes.push('这个动图只给了第一帧，中间过程和结尾看不到 —— 别编造后面发生了什么');
  }

  cleanup(workDir);
  return { parts, notes, failed };
}

// ── 视频：走核心的视频理解链路 ────────────────────────────────────────────

async function videoParts(ctx, item, c) {
  const parts = [];
  const notes = [];
  const failed = [];
  const reader = ctx.videoReader;
  if (!reader?.probe) {
    failed.push('这个上下文里没有视频读取服务，视频画面取不到');
    return { parts, notes, failed };
  }

  const want = clamp(pickNum(null, c.videoFrames, 12), 2, 30);
  let info = null;
  try {
    info = await reader.probe(item, { count: want });
  } catch (error) {
    failed.push(`视频读取失败：${short(error)}`);
    return { parts, notes, failed };
  }

  if (info?.route === 'frames' && Array.isArray(info.frames) && info.frames.length) {
    for (const f of info.frames) parts.push({ type: 'image_url', image_url: { url: f } });
    const dur = Number(info.durationSec) ? `，时长 ${Number(info.durationSec).toFixed(1)} 秒` : '';
    notes.push(`视频抽了 ${info.frames.length} 帧截图${dur}（截图不是连续视频，帧之间看不到）`);
  } else if (info?.route === 'native' && info.nativeUrl) {
    parts.push({ type: 'video_url', video_url: { url: info.nativeUrl } });
    notes.push('视频按原生视频输入发送');
  } else {
    failed.push(info?.note || info?.routeReason || '视频画面取不到（抽帧能力不可用），只拿到了元信息');
  }
  return { parts, notes, failed };
}

// ── 能力软依赖：video.watch / video.frames ─────────────────────────────────

/**
 * 动图展开能力在不在。
 *
 * 注意 `api.capability(name,args)` 是「**调用**」而不是「注册」：
 * 它遍历 `getCapabilityProviders(name,{})` 取第一个 provider 直接执行，
 * 没有 provider 时返回 undefined。所以它不能当探测用 —— 必须先用
 * `hasCapability` 判断，再调。否则会白跑一次真抽帧。
 */
function videoWatchReady() {
  if (!capabilityFn) return false;
  try {
    return hasCapabilityFn ? Boolean(hasCapabilityFn('video.watch')) : true;
  } catch {
    return false;
  }
}

/**
 * 调 video.watch（video-watch 技能提供）。
 *
 * 契约（见 skills/video-watch/index.js 的 providers）：
 *   入参 { filePath, frames, cols, outDir, t0, t1 }
 *   出参 { ok, image, sheet(dataUrl), manifest, workDir, text }
 * ⚠️ workDir 在返回前已被 cleanup，`image` 是一条**已失效的路径**，
 *    只能用 `sheet`。这是旧版 chat-media 拿不到画面的另一个坑。
 */
function callVideoWatch(args) {
  if (!capabilityFn) return null;
  return capabilityFn('video.watch', args);
}

// ── 取图片字节：直链 → 协议端缓存/新直链 ───────────────────────────────────

/**
 * 取一张图片的字节。
 *
 * QQ 图床直链带 rkey，约 1 小时过期；几小时后再回头看必然 404。
 * 直链失败时用 file id 调 get_image —— 协议端可能给本地缓存文件，
 * 也可能给一条新直链，两种都接着。
 */
async function imageBytes(ctx, item, c) {
  const maxBytes = clamp(Number(c.maxMediaMb) || 12, 1, 30) * 1024 * 1024;

  if (item.url) {
    try {
      const buf = await downloadBytes(item.url, maxBytes);
      if (buf?.length) return buf;
    } catch { /* 落到协议端那条路 */ }
  }

  if (item.file) {
    try {
      const ret = await ctx.onebot.call('get_image', { file: String(item.file) });
      const local = ret?.file && fs.existsSync(String(ret.file)) ? String(ret.file) : '';
      if (local) {
        const buf = fs.readFileSync(local);
        if (buf?.length) return buf;
      }
      const fresh = String(ret?.url || (/^https?:/i.test(String(ret?.file || '')) ? ret.file : '')).trim();
      if (fresh) {
        const buf = await downloadBytes(fresh, maxBytes);
        if (buf?.length) return buf;
      }
    } catch { /* 交给上层报错 */ }
  }

  throw new Error('直链已过期，协议端也没有缓存');
}

async function imageToDataUrl(ctx, item, c) {
  return toDataUrl(await imageBytes(ctx, item, c));
}

/** 下载字节：只走 http(s)，带体积上限，挡掉明显的内网/环回字面量。 */
async function downloadBytes(url, maxBytes) {
  const u = String(url || '').trim();
  if (!/^https?:\/\//i.test(u)) throw new Error('地址不是 http(s)');
  let host = '';
  try { host = new URL(u).hostname.toLowerCase(); } catch { throw new Error('地址解析失败'); }
  if (!host || host === 'localhost' || host.endsWith('.local')
    || /^(127\.|10\.|192\.168\.|169\.254\.|0\.0\.0\.0$)/.test(host) || host === '::1' || host === '[::1]') {
    throw new Error('地址指向本机/内网，已拒绝');
  }
  const res = await fetchUrl(u);
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  const buf = Buffer.from(await res.arrayBuffer());
  if (!buf.length) throw new Error('内容为空');
  if (buf.length > maxBytes) {
    throw new Error(`文件太大（${(buf.length / 1048576).toFixed(1)}MB，上限 ${(maxBytes / 1048576).toFixed(0)}MB）`);
  }
  return buf;
}

function fetchUrl(url) {
  const fn = fetchImpl || globalThis.fetch;
  return fn(url, { redirect: 'follow' });
}

/** 按 magic bytes 猜类型（不信响应头）。 */
function toDataUrl(buf) {
  let mime = 'image/jpeg';
  if (buf.length > 3 && buf[0] === 0x89 && buf[1] === 0x50 && buf[2] === 0x4e && buf[3] === 0x47) mime = 'image/png';
  else if (buf.length > 3 && buf[0] === 0x47 && buf[1] === 0x49 && buf[2] === 0x46) mime = 'image/gif';
  else if (buf.length > 11 && buf.toString('ascii', 8, 12) === 'WEBP') mime = 'image/webp';
  return `data:${mime};base64,${buf.toString('base64')}`;
}

// ── 杂项 ──────────────────────────────────────────────────────────────────

/**
 * 代码里的兜底默认值。
 *
 * ⚠️ 必须和 skill.json 的 settings 保持一致 —— 这里是"用户没配置过"时的最后一道
 * 保底，skill.json 那份是 UI 表单里显示的初值。两处不一致时用户会看到
 * "设置里写着 25，实际却按别的数字跑"，极难排查。
 */
const DEFAULTS = {
  maxImages: 6,
  maxGifs: 3,
  maxVideos: 2,
  gifFrames: 25,
  gifCols: 5,
  videoFrames: 12,
  maxMediaMb: 12,
  includeTranscript: true,
  transcriptChars: DEFAULT_TRANSCRIPT_CHARS,
  includeNested: true,
  maxNestedDepth: 1,
  sendInfoToChat: false
};

function clamp(n, lo, hi) {
  const v = Number.isFinite(Number(n)) ? Number(n) : lo;
  return Math.min(hi, Math.max(lo, Math.round(v)));
}

/** 参数优先 → 设置 → 兜底。0 是合法值（表示"这次不看"），不能被当成没填。 */
function pickNum(explicit, configured, fallback) {
  if (explicit != null && Number.isFinite(Number(explicit))) return Number(explicit);
  if (configured != null && Number.isFinite(Number(configured))) return Number(configured);
  return fallback;
}

function short(error) {
  return String(error?.message ?? error ?? '').slice(0, 160);
}

/**
 * 临时工作目录。
 *
 * ⚠️ 不能用 process.cwd()：Electron 启动时 cwd 是 System32 或用户目录，
 *    跟在哪儿双击启动有关，写进去要么权限失败、要么散落一地。
 *    优先级：环境变量 → 插件目录往上两级（= resources/app）下的 data。
 */
function makeWorkDir() {
  const appRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..', '..');
  const base = path.join(
    process.env.QQ_AGENT_DATA_DIR || path.join(appRoot, 'data'),
    'chat-media-viewer'
  );
  const dir = path.join(base, `job-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`);
  fs.mkdirSync(dir, { recursive: true });
  return dir;
}

function cleanup(dir) {
  try { fs.rmSync(dir, { recursive: true, force: true }); } catch { /* 删不掉就留着 */ }
}

// ── 内部导出（便于离线测试，不参与运行时）───────────────────────────────────
export const internals = {
  isAnimated,
  pushMedia,
  mediaKey,
  segmentText,
  fetchForwardNodes,
  expandForward,
  toDataUrl,
  clamp,
  pickNum,
  videoWatchReady,
  callVideoWatch,
  DEFAULTS
};
