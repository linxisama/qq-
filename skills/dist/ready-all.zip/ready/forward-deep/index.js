// forward-deep —— QQ Agent Skill：深度转发展开
//
// 修的是核心 read_forward 的两个硬伤：
//   1) 嵌套转发不展开：核心 onebot.js 的 expandForwardNodes 把节点里的 forward 段
//      显式清成 `{ type:'forward', data:{} }`，注释写明「深度 1 封顶，套娃截断」，
//      所以「转发里还套着转发」在文本里只剩一行 [合并转发聊天记录]。
//   2) 转发里的图片看不到：expandForwardNodes 确实把图片提进了 media 并写回存档，
//      但 read_forward 只回一个 `images: N` 计数，模型手里没有图；而 get_message_images
//      的触发条件写的是「消息文本出现 [图片]」，转发那条消息的文本里没有 [图片]，
//      模型也就不会去调它。
//
// 为什么做成 Skill（skills/）而不是插件（plugins/）：
//   · 插件注册工具会被 plugin-loader.js 强制加 `skillId__` 前缀，**覆盖不了**核心
//     工具 id，所以没法替换 read_forward；
//   · tool.guard 是「可用性否决」钩子（tool-registry.js 只读它的返回值判断能不能
//     用这个工具），拿不到、也改不了工具的执行结果，所以也没法给 read_forward
//     的返回值打补丁。
//   结论：唯一可行的插件化路线就是**新增一个工具** + 提示词引导模型优先用它。
//   核心 read_forward 保持原样（本技能被关掉时仍有降级路径）。
//
// 实测事实（2026-10-08，本机 SnowLuma / OneBot HTTP 127.0.0.1:3000）：
//   · 顶层转发：get_forward_msg { message_id: <QQ消息id> } → 2 节点
//   · 节点里的 forward 段带 data.id（长 res_id 一串）
//   · 用该 id 再调 get_forward_msg { id } → 200 retcode=0，拿回嵌套内容（文本 + 图片）
//   · { message_id: <res_id串> } 同样可用；{ res_id } / { forward_id } 报 retcode 1400
//   所以递归是成立的：嵌套层用 { id } 取。
//
// 图片下载（2026-10-08 实测）：
//   · QQ 图床（multimedia.nt.qq.com.cn）**要求带正常 User-Agent**，裸 fetch 会被 400；
//     核心 safe-fetch.js 的 requestOnce 自带 UA，所以走它没问题。
//   · 本机是 Clash fake-ip：DNS 把所有域名解析到 198.18.0.0/15，核心 isPrivateIp()
//     把该段判成内网 → SSRF 防护误拦，任何图片都下不来（核心 get_message_images 同理）。
//     正解是 security.allowPrivateImageHosts=true（本机已开）；本技能额外带一层
//     fake-ip 兜底：仅当「域名全部解析到 198.18.0.0/15」时才直连，真实私网地址照旧拒绝。
import dns from 'node:dns/promises';
import http from 'node:http';
import https from 'node:https';
import { segmentsToText } from '../../src/onebot.js';
import { validateImageUrl, safeFetchBinary } from '../../src/safe-fetch.js';
import { compressImage } from '../../src/image-compress.js';
import { getConfig } from '../../src/config.js';

let cfg = () => ({});
let log = () => {};

const DEFAULTS = { maxDepth: 3, maxNodes: 60, maxChars: 6000, maxImages: 6, maxImageMB: 8, nodeTextChars: 300 };

function settings() {
  const c = cfg() || {};
  const num = (v, d, lo, hi) => {
    const n = Number(v);
    return Number.isFinite(n) ? Math.min(hi, Math.max(lo, Math.round(n))) : d;
  };
  return {
    maxDepth: num(c.maxDepth, DEFAULTS.maxDepth, 1, 5),
    maxNodes: num(c.maxNodes, DEFAULTS.maxNodes, 1, 200),
    maxChars: num(c.maxChars, DEFAULTS.maxChars, 500, 20000),
    maxImages: num(c.maxImages, DEFAULTS.maxImages, 0, 40),
    maxImageMB: num(c.maxImageMB, DEFAULTS.maxImageMB, 1, 20),
    nodeTextChars: num(c.nodeTextChars, DEFAULTS.nodeTextChars, 50, 2000)
  };
}

// ── OneBot 取节点 ──────────────────────────────────────────────────────

/** 从 forward 段的 data 里取可再次请求的转发 id（与核心 forwardIdFromData 同口径）。 */
function forwardIdOf(d) {
  const raw = d?.id ?? d?.res_id ?? d?.forward_id ?? d?.data_id;
  if (raw == null || String(raw).trim() === '') return null;
  return String(raw);
}

/**
 * 取一个转发的节点数组。ref 既可以是 QQ 消息 id（数字），也可以是 res_id 串。
 * 数字优先走 { message_id }，串优先走 { id }；两条都试一遍，谁先成功用谁。
 */
function nodesOf(r) {
  return Array.isArray(r?.messages) ? r.messages
    : (Array.isArray(r?.data?.messages) ? r.data.messages : []);
}

/**
 * 把一个消息 id 解析成真正的转发 res_id —— 这是 get_forward_msg 唯一可靠的钥匙。
 *
 * 实测（2026-10-08，SnowLuma 1.14.19-node / protocol v11）：
 *   · get_forward_msg { message_id: <负数> } → retcode=100 download forward message payload is empty
 *   · get_forward_msg { id: "<负数串>" }      → 同样 retcode=100
 *   · 但同一条消息 get_msg { message_id: <负数> } → retcode=0，转发段的 data.id 就是 res_id
 *   · get_forward_msg { id: <res_id> }        → retcode=0，拿回节点
 *   负数 message_id 是协议端本地生成的 id（私聊、以及部分群聊消息都是负数，属常态），
 *   不是「转发过期」。真过期的转发，用 res_id 也一样取不到。
 */
async function resolveResId(onebot, mid) {
  const raw = String(mid ?? '').trim();
  if (!raw) return null;
  const params = /^-?\d+$/.test(raw) ? { message_id: Number(raw) } : { message_id: raw };
  try {
    const r = await onebot.call('get_msg', params);
    const segs = r?.message ?? r?.data?.message ?? [];
    if (Array.isArray(segs)) {
      for (const seg of segs) {
        if (seg?.type === 'forward') {
          const rid = forwardIdOf(seg.data);
          if (rid) return rid;
        }
      }
    }
  } catch { /* 取不到就走后面的兜底报错 */ }
  return null;
}

/**
 * 取一个转发的节点数组。ref 既可以是 QQ 消息 id（数字），也可以是 res_id 串。
 * 数字优先走 { message_id }，串优先走 { id }；两条都试一遍，谁先成功用谁。
 * 全挂之后：把消息 id 解析成 res_id 再取一次（负数 message_id 的唯一出路）。
 */
async function fetchNodes(onebot, ref) {
  const s = String(ref ?? '').trim();
  if (!s) return { ok: false, nodes: [], error: '空转发 id' };
  const numeric = /^-?\d+$/.test(s);
  const attempts = numeric ? [{ message_id: Number(s) }, { id: s }] : [{ id: s }, { message_id: s }];
  let lastErr = '';
  for (const params of attempts) {
    try {
      const nodes = nodesOf(await onebot.call('get_forward_msg', params));
      if (nodes.length) return { ok: true, nodes };
    } catch (error) {
      lastErr = String(error?.message ?? error);
    }
  }
  if (numeric) {
    const resId = await resolveResId(onebot, s);
    if (resId && resId !== s) {
      for (const params of [{ id: resId }, { message_id: resId }]) {
        try {
          const nodes = nodesOf(await onebot.call('get_forward_msg', params));
          if (nodes.length) return { ok: true, nodes, viaResId: true };
        } catch (error) {
          lastErr = String(error?.message ?? error);
        }
      }
    }
  }
  return { ok: false, nodes: [], error: lastErr || '接口返回空' };
}

// ── 递归展开 ───────────────────────────────────────────────────────────

function nodeName(n) {
  const raw = String(n?.sender?.card || n?.sender?.nickname || n?.user_id || '?');
  const id = String(n?.sender?.user_id ?? n?.user_id ?? '').trim();
  return id && id !== raw ? `${raw}(QQ:${id})` : raw;
}

function stripCq(text) {
  return String(text ?? '').replace(/\[CQ:[^\]]*\]/g, '').replace(/\s+/g, ' ').trim();
}

/**
 * 渲染一个节点的 message 段数组。
 * 非 forward 段交给核心 segmentsToText（占位口径与主历史一致：@/引用/表情/视频…），
 * forward 段自己处理：能取到就递归展开，取不到就保留占位。
 * 顺序保持：按段遍历，遇到 forward 先把前面的普通段 flush 掉再插嵌套块。
 */
async function renderSegments(segs, args) {
  const { onebot, depth, st, state } = args;
  const out = [];
  let buf = [];
  const flush = async () => {
    if (!buf.length) return;
    const t = await segmentsToText(buf, {});
    if (t) out.push(t);
    buf = [];
  };
  for (const seg of segs) {
    if (seg?.type === 'forward') {
      await flush();
      const fid = forwardIdOf(seg.data);
      if (depth < st.maxDepth && fid) {
        const r = await fetchNodes(onebot, fid);
        if (r.ok) {
          const sub = await expandNodes(onebot, r.nodes, { ...args, depth: depth + 1 });
          out.push(`[转发 共${r.nodes.length}条 ↓]\n${sub.lines.join('\n')}\n[↑ 转发结束]`);
        } else {
          out.push('[合并转发聊天记录·取不到]');
        }
      } else {
        // 到层数上限 / 没有 id：保留占位，并在文本里说明为什么没展开
        out.push(depth >= st.maxDepth ? '[合并转发聊天记录·已达层数上限]' : '[合并转发聊天记录]');
      }
      continue;
    }
    if (seg?.type === 'image') {
      const url = String(seg.data?.url ?? '');
      if (url) state.media.push({ kind: 'image', url, file: String(seg.data?.file ?? '') });
    }
    buf.push(seg);
  }
  await flush();
  return out.filter(Boolean).join(' ');
}

/** 展开一批节点 → { lines, media }。state 跨层共享，用于全局封顶。 */
async function expandNodes(onebot, nodes, args) {
  const { depth, st, state } = args;
  const lines = [];
  for (const n of nodes) {
    if (state.nodes >= st.maxNodes) { state.truncated = true; break; }
    state.nodes += 1;
    const name = nodeName(n);
    const nm = n?.message ?? n?.content;
    let body = '';
    if (typeof nm === 'string') {
      body = stripCq(nm);
    } else if (Array.isArray(nm)) {
      body = await renderSegments(nm, args);
    }
    body = String(body).replace(/\s+/g, ' ').trim().slice(0, st.nodeTextChars);
    if (!body) continue;
    const prefix = depth > 1 ? `${'  '.repeat(depth - 1)}↳ ` : '';
    lines.push(`${prefix}${name}: ${body}`);
    if (lines.join('\n').length > st.maxChars) { state.truncated = true; break; }
  }
  return { lines };
}

// ── 图片下载 ───────────────────────────────────────────────────────────

function sniffMime(buf) {
  if (!buf || buf.length < 12) return null;
  if (buf[0] === 0x89 && buf[1] === 0x50) return 'image/png';
  if (buf[0] === 0xff && buf[1] === 0xd8) return 'image/jpeg';
  if (buf.toString('ascii', 0, 3) === 'GIF') return 'image/gif';
  if (buf.toString('ascii', 0, 4) === 'RIFF' && buf.toString('ascii', 8, 12) === 'WEBP') return 'image/webp';
  return null;
}

/** Clash fake-ip 段（RFC 2544 基准测试段 198.18.0.0/15），本机 DNS 把所有域名都指到这里。 */
function isFakeIp(ip) {
  const p = String(ip || '').split('.').map(Number);
  return p.length === 4 && p.every((x) => Number.isInteger(x)) && p[0] === 198 && (p[1] === 18 || p[1] === 19);
}

/** 域名是否「全部」解析到 fake-ip 段；只有这种才允许走兜底直连。 */
async function resolvesOnlyToFakeIp(hostname) {
  try {
    const addrs = await dns.lookup(hostname, { all: true, verbatim: true });
    if (!addrs.length) return false;
    return addrs.every((a) => isFakeIp(a.address));
  } catch {
    return false;
  }
}

/** 与核心 requestOnce 同口径的单次二进制请求（带 UA，否则 QQ 图床回 400）。 */
function requestOnceBinary(url, ip, maxBytes) {
  return new Promise((resolve, reject) => {
    const mod = url.protocol === 'https:' ? https : http;
    const port = url.port || (url.protocol === 'https:' ? 443 : 80);
    const req = mod.request({
      hostname: ip,
      port,
      path: url.pathname + url.search,
      method: 'GET',
      headers: {
        host: url.host,
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) qq-agent/1.0',
        accept: 'image/avif,image/webp,image/png,image/jpeg,*/*;q=0.8',
        'accept-language': 'zh-CN,zh;q=0.9'
      },
      servername: url.protocol === 'https:' ? url.hostname : undefined,
      rejectUnauthorized: url.protocol === 'https:',
      timeout: 20000
    }, (res) => {
      const statusCode = res.statusCode || 0;
      if ([301, 302, 303, 307, 308].includes(statusCode)) {
        res.resume();
        resolve({ statusCode, redirect: String(res.headers.location || '') });
        return;
      }
      const chunks = [];
      let total = 0;
      let done = false;
      const finish = (fn, v) => { if (!done) { done = true; fn(v); } };
      res.on('data', (chunk) => {
        if (done) return;
        total += chunk.length;
        chunks.push(chunk);
        if (total >= maxBytes) {
          try { res.destroy(); } catch { /* ignore */ }
          finish(resolve, { statusCode, body: Buffer.concat(chunks).subarray(0, maxBytes), contentType: String(res.headers['content-type'] || '') });
        }
      });
      res.on('end', () => finish(resolve, { statusCode, body: Buffer.concat(chunks), contentType: String(res.headers['content-type'] || '') }));
      res.on('error', (err) => finish(reject, err));
    });
    req.on('timeout', () => req.destroy(new Error(`请求超时：${url.hostname}`)));
    req.on('error', reject);
    req.end();
  });
}

/** fake-ip 兜底：逐跳确认「只解析到 198.18.0.0/15」才直连，真实私网照旧拒绝。 */
async function fetchBinaryViaFakeIp(rawUrl, maxBytes) {
  let url;
  try {
    url = new URL(String(rawUrl ?? '').trim());
  } catch {
    throw new Error('图片地址不合法');
  }
  for (let i = 0; i <= 5; i++) {
    if (!['http:', 'https:'].includes(url.protocol)) throw new Error('只允许 http(s) 图片地址');
    if (!(await resolvesOnlyToFakeIp(url.hostname))) {
      throw new Error('域名不是 Clash fake-ip（198.18.0.0/15），拒绝绕过 SSRF 防护');
    }
    const ip = (await dns.lookup(url.hostname, { all: true }))[0].address;
    const r = await requestOnceBinary(url, ip, maxBytes);
    if ([301, 302, 303, 307, 308].includes(r.statusCode)) {
      if (!r.redirect) throw new Error(`重定向缺少 Location: ${r.statusCode}`);
      url = new URL(r.redirect, url);
      continue;
    }
    if (r.statusCode !== 200) throw new Error(`HTTP ${r.statusCode}`);
    return { buffer: r.body, contentType: r.contentType };
  }
  throw new Error('重定向次数过多，已停止');
}

/** 走核心同一条下载链路（SSRF 校验 + 体积上限 + 压缩）拿到 data URL；fake-ip 环境自动兜底。 */
async function fetchImageDataUrl(url, maxBytes) {
  let buffer;
  let contentType = '';
  try {
    const safeUrl = await validateImageUrl(url);
    ({ buffer, contentType } = await safeFetchBinary(safeUrl, maxBytes));
  } catch (error) {
    const msg = String(error?.message ?? error);
    // 只有「被 SSRF 误判为内网」这一种情况才兜底；其它错误（404/超时/白名单）原样抛出
    if (!/内网|本机地址/.test(msg)) throw error;
    ({ buffer, contentType } = await fetchBinaryViaFakeIp(url, maxBytes));
  }
  if (!buffer || !buffer.length) throw new Error('图片内容为空');
  const c = await compressImage(buffer);
  const buf = c?.compressed ? c.buffer : buffer;
  const mime = (c?.compressed ? c.mime : null) || sniffMime(buffer)
    || String(contentType || 'image/jpeg').split(';')[0] || 'image/jpeg';
  return `data:${mime};base64,${buf.toString('base64')}`;
}

// ── 工具 ───────────────────────────────────────────────────────────────

function err(message) {
  return { content: `错误：${message}`, isError: true };
}

function recentMids(ctx, limit = 60) {
  try {
    return ctx.store.recent(ctx.chatKey, { limit })
      .map((m) => ({ mid: m.mid, text: String(m.text || '') }))
      .filter((x) => x.mid != null);
  } catch {
    return [];
  }
}

function midHint(ctx) {
  const mids = recentMids(ctx).slice(-20).map((x) => x.mid);
  return mids.length ? `当前会话可见的 #id：${mids.join('、')}` : '';
}

/** 没给 messageId 时，猜最近一条「看起来是转发」的消息。 */
function guessForwardMid(ctx) {
  const list = recentMids(ctx);
  for (let i = list.length - 1; i >= 0; i--) {
    if (/\[合并转发|\[转发消息|\[转发\s/.test(list[i].text)) return list[i].mid;
  }
  return null;
}

export function setup(api) {
  cfg = typeof api.config === 'function' ? api.config : () => ({});
  log = typeof api.log === 'function' ? api.log : () => {};

  api.registerTool({
    id: 'forward_deep',
    name: '深度转发展开',
    description:
      '展开合并转发消息（read_forward 的增强版）：递归展开嵌套的转发（转发里还套着转发），'
      + '并把转发里包含的图片直接交给你看。消息文本出现 [合并转发聊天记录] / [转发消息 …] '
      + '占位符、而你需要看里面的内容或图片时用它。参数填那条转发消息前的 #数字'
      + '（千万别用方括号里那串长 id，会过期报错）；不填则自动取最近一条转发。'
      + '展开结果会写回存档，不用重复调。',
    category: 'query',
    icon: '📨',
    parameters: {
      type: 'object',
      properties: {
        messageId: { type: ['integer', 'string'], description: '转发消息自己的 QQ 消息 id（聊天记录里的 #数字，可能为负）；不填则自动取最近一条转发' }
      },
      required: []
    },
    async execute(ctx, args) {
      const st = settings();
      try {
        let mid = args?.messageId;
        if (mid == null || String(mid).trim() === '') mid = guessForwardMid(ctx);
        if (mid == null) return err(`没给 #id，当前会话里也没找到看起来是转发的消息。${midHint(ctx)}`);

        const entry = ctx.store.findByMid(ctx.chatKey, mid);
        if (!entry) return err(`当前会话找不到消息 ${mid}。${midHint(ctx)}`);

        const state = { nodes: 0, truncated: false, media: [] };
        const top = await fetchNodes(ctx.onebot, entry.mid);
        let text = '';
        let media = [];
        let fromArchive = false;

        if (top.ok) {
          const res = await expandNodes(ctx.onebot, top.nodes, { onebot: ctx.onebot, depth: 1, st, state });
          const tag = st.maxDepth > 1 ? ' · 已深度展开' : '';
          text = `[合并转发 共${top.nodes.length}条${tag}]\n${res.lines.join('\n')}`;
          if (state.truncated) text += `\n…（已达展开上限 ${st.maxNodes} 条 / ${st.maxChars} 字符，剩余未展开）`;
          media = state.media;
          // 写回存档：一次展开永久升级这条记录（核心 read_forward 也是这么做的）
          try { ctx.store.updateByMid(ctx.chatKey, entry.mid, { text, appendMedia: media }); } catch { /* 存档失败不影响本次返回 */ }
        } else {
          // 取不到（发送时间太久被服务端丢弃）→ 退回存档里已有的文本 + 图片
          const stored = String(entry.text || '');
          if (!stored.startsWith('[合并转发 共')) {
            return err(`打不开这条转发：协议端没取回转发载荷，且存档里没有展开记录。负数 message_id（协议端本地 id）是主因——核心 read_forward 与 ingest 都只认 message_id，所以必挂；本技能已自动改用 res_id 重试，仍失败说明该转发确实已被 QQ 服务端回收。${top.error ? `（${top.error}）` : ''}`);
          }
          fromArchive = true;
          text = stored;
          media = (entry.media || []).filter((m) => m.kind === 'image' && m.url);
        }

        // 图片：去重 → 按上限取前 N 张 → 下载成 data URL
        const parts = [{ type: 'text', text }];
        const notes = [];
        if (fromArchive) notes.push('这次读的是存档里已展开的内容（QQ 侧已取不到原始转发）');
        if (media.length) {
          const uniq = [];
          const seen = new Set();
          for (const m of media) {
            if (m.url && !seen.has(m.url)) { seen.add(m.url); uniq.push(m); }
          }
          const visionOn = getConfig()?.api?.vision !== false;
          const cap = visionOn ? st.maxImages : 0;
          const failed = [];
          for (const m of uniq.slice(0, cap)) {
            try {
              parts.push({ type: 'image_url', image_url: { url: await fetchImageDataUrl(m.url, st.maxImageMB * 1024 * 1024) } });
            } catch (error) {
              failed.push(String(error?.message ?? error));
            }
          }
          if (cap === 0) notes.push(`转发里有 ${uniq.length} 张图片，但当前模型不支持看图（视觉未开启），只给了文本`);
          else if (uniq.length > cap) notes.push(`转发里共 ${uniq.length} 张图片，只取了前 ${cap} 张`);
          if (failed.length) notes.push(`${failed.length} 张图片下载失败（${failed.slice(0, 2).join('；')}）`);
        }
        if (notes.length) parts[0].text += `\n（${notes.join('；')}）`;
        return { content: parts };
      } catch (error) {
        return err(`展开失败：${error?.message ?? error}`);
      }
    }
  });
}

// 便于离线自测（不经过 LLM）：node -e "import(...).then(m => m.internals.expandNodes(...))"
export const internals = { expandNodes, renderSegments, fetchNodes, resolveResId, nodesOf, forwardIdOf, fetchImageDataUrl, fetchBinaryViaFakeIp, isFakeIp, settings };
