# forward-deep · 深度转发展开

## 解决什么问题

核心 `read_forward`（`src/tools.js` 注册的内置工具）只能读「一层」转发：

| 场景 | read_forward | forward_deep |
|---|---|---|
| 普通合并转发（转发里都是文本/图片） | ✅ 展开 | ✅ 展开 |
| **嵌套转发**（转发里还套着转发） | ❌ 只剩 `[合并转发聊天记录]` 占位 | ✅ 递归展开（默认 3 层） |
| **转发里的图片** | ❌ 只回 `images: N` 计数，模型看不到图 | ✅ 直接下载成图片交给模型看 |

根因（读码确认，非猜测）：

- `src/onebot.js` 的 `expandForwardNodes` 把节点里的 forward 段显式清成
  `{ type:'forward', data:{} }`，注释写明「深度 1 封顶，套娃截断」。
- `expandForwardNodes` 其实**有**把图片提进 `media` 并写回存档，但 `read_forward`
  只返回 `images: N`；而 `get_message_images` 的触发条件是「消息文本出现 [图片]」，
  转发那条消息的文本里没有 `[图片]`，模型不会想到去调它。

## 为什么是 Skill 而不是插件

- 插件注册工具会被 `src/plugin-loader.js` 强制加 `skillId__` 前缀，**覆盖不了**
  核心工具 id → 无法替换 `read_forward`。
- `tool.guard` 是「可用性否决」钩子（`src/tool-registry.js` 只读它的返回值判断
  工具能不能用），拿不到也改不了工具的**执行结果** → 无法给 `read_forward` 打补丁。

所以唯一可行的插件化路线是：**新增一个工具** + 提示词引导模型优先用它。
核心 `read_forward` 保持原样，本技能被关闭时仍有降级路径。

## 实测事实（2026-10-08，本机 SnowLuma）

```
get_forward_msg { message_id: <转发消息id> }        → retcode 0，2 节点
  节点 0：forward 段，data.id = <res_id 前缀…>  ← 嵌套转发
  节点 1：image 段
get_forward_msg { id: "<res_id 前缀…>" }        → retcode 0，拿回嵌套内容（文本 + 图片）
get_forward_msg { message_id: "<res_id 前缀…>" } → retcode 0（同样可用）
get_forward_msg { res_id: ... } / { forward_id: ... } → retcode 1400（不支持）
```

即：嵌套层用 `{ id }` 取，递归成立。

## 设置项

见 `skill.json` 的 `configSchema`（最大嵌套层数 / 条数 / 字符数 / 取图张数 / 单图体积上限 / 单条截断长度）。

## 维护注意

本技能通过相对路径直接复用核心模块：

```js
import { segmentsToText } from '../../src/onebot.js';
import { validateImageUrl, safeFetchBinary } from '../../src/safe-fetch.js';
import { compressImage } from '../../src/image-compress.js';
import { getConfig } from '../../src/config.js';
```

这些是**安装目录内**的源码（`resources/app/src/`）。应用大版本更新若挪动了
这些文件或改了导出名，本技能会在加载时报「加载失败」并在技能页显示原因——
修法是同步这几行 import。功能本身不依赖核心是否被打过补丁。

---

## 追加实测：负数 message_id 与 "payload is empty"（2026-10-08）

报错 `OneBot get_forward_msg 失败: retcode=100 download forward message payload is empty`
**不是**「转发过期」，也**不是**发送者昵称为空导致的。真正原因是协议端 id 命名空间：

| 调用 | 结果 |
| --- | --- |
| `get_forward_msg { message_id: <负数消息id> }` | retcode=100 payload is empty |
| `get_forward_msg { id: "<负数消息id>" }` | retcode=100 payload is empty |
| `get_msg { message_id: <负数消息id> }` | retcode=0，`message[0].data.id` = res_id |
| `get_forward_msg { id: <res_id> }` | retcode=0，节点拿回 |

- SnowLuma 给**私聊消息、以及机器人自己发出/部分群聊消息**分配负数 message_id（实测：
  某个私聊会话里过半消息是负数；某个群聊会话里过半消息是负数）。
  这类 id 在 `get_forward_msg` 里查不到载荷，与消息新旧无关。
- 同一张转发卡片，用 message_id 报错、用 res_id 成功 —— 证明载荷一直在服务端，不存在「被丢弃」。
- 因此 `fetchNodes` 现在会：正数优先 `{message_id}` → 失败后 `get_msg` 取 res_id → `get_forward_msg {id: res_id}`。
  正数 id 走原路径，不多发一次请求。

核心侧同一根因已同步修补（`src/onebot.js` 新增 `fetchForwardNodes`，`src/app.js` ingest 与
`src/tools.js` 的 `read_forward` 改用它），需重启应用生效；应用更新会覆盖 `src/` 与 `skills/`。
