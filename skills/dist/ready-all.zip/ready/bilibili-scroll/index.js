/**
 * bilibili-scroll —— 登录并操作 B 站账号（LLM 型技能 / skill.json + index.js）
 *
 * 为什么是「技能」而不是「插件」：
 *   「什么时候该点赞/投币/收藏/关注/评论/发动态」取决于群里在聊什么、
 *   用户是不是在叫它做 —— 这是自然语言判断，规则写不死。
 *   所以注册工具交给模型决定；确定性的权限、限额、确认模式在工具内部强制。
 *
 * 安全边界（重要）：
 *   · Cookie/SESSDATA 只保存在本机 data/bilibili-scroll/session.json，权限 0600；
 *     日志与工具返回值里不会出现 Cookie。
 *   · 所有写操作都过「开关 + 自动模式 + 每日限额 + 最小间隔 + 去重」五道闸。
 *   · 评论/发动态默认是 confirm 模式（要用户明确同意），可在设置里改成 auto。
 *   · 不绕过 ctx.sender 发消息；登录二维码走发送队列。
 *
 * v1.1 新增「每日刷视频」：
 *   · 按 tag/关键词搜索候选视频（WBI 搜索），或退到排行榜；每天看够指定数量。
 *   · "观看"= click + heartbeat 上报，会进 B 站观看历史；不下载视频、不占带宽。
 *   · 看视频本身不算写操作，但自动点赞 / 自动评论仍走原来的五道闸；
 *     定时自动评论还额外要求「高风险模式 = auto」（confirm 在无人应答的定时器里没法确认）。
 *   · 观看计划存 data/bilibili-scroll/plan.json，优先级高于设置页 —— 这样才能用
 *     "每天帮我看 5 个原神的视频，早上九点刷"这种一句话直接改。
 */

import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { createRequire } from 'node:module';
import { fileURLToPath } from 'node:url';

// 技能目录：<app>/skills/bilibili-scroll/index.js。自己推导数据目录，不 import 核心模块，
// 这样这个技能目录是自包含的（复制到别的 skills/ 根目录也能跑）。
const APP_ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..', '..');
const PROFILE_ID = /^\d+$/.test(String(process.env.QQ_AGENT_PROFILE ?? '').trim())
  ? String(process.env.QQ_AGENT_PROFILE).trim()
  : '';
const DATA_DIR = process.env.QQ_AGENT_DATA_DIR || path.join(APP_ROOT, `data${PROFILE_ID ? `-${PROFILE_ID}` : ''}`);

const require = createRequire(import.meta.url);
let qrLib = null;
function getQrLib() {
  if (!qrLib) qrLib = require('./lib/qrcode.cjs');
  return qrLib;
}

// 加载器的热重载只给 index.js 加 ?t=...，静态 import 的 ./lib/bili-api.js
// 会被 Node 缓存住 —— 改了 lib 之后旧模块不会重新求值，表现为“新 index 找不到新导出”。
// 这里用同一个 t 做动态 import，让 lib 跟着 index 一起刷新。
const BUST = new URL(import.meta.url).searchParams.get('t') || String(Date.now());
const {
  BiliApiError, randomBuvid3, cookieString, qrGenerate, qrPoll, fetchBuvid,
  nav, navStat, extractVideoRef, resolveVideo, videoInfo, videoState,
  likeVideo, coinVideo, tripleVideo, favFolders, favDeal,
  followUser, postComment, postDynamicText, postDynamicTextV2, deleteDynamic,
  searchVideos, searchUsers, rankingVideos, clickVideo, heartbeatVideo, parseDurationText,
  replyVisible
} = await import(`./lib/bili-api.js?t=${encodeURIComponent(BUST)}`);

const STORE_DIR = path.join(DATA_DIR, 'bilibili-scroll');
const SESSION_FILE = path.join(STORE_DIR, 'session.json');
const STATE_FILE = path.join(STORE_DIR, 'state.json');
const PLAN_FILE = path.join(STORE_DIR, 'plan.json');
// 回复人设：出厂版在技能目录里（随技能走、可直接改），
// 想让它活得比升级久就复制一份到 data/bilibili-scroll/persona.md，那份优先。
const SKILL_DIR = path.dirname(fileURLToPath(import.meta.url));
const PERSONA_SHIPPED = path.join(SKILL_DIR, 'persona.md');
const PERSONA_USER = path.join(STORE_DIR, 'persona.md');
const NAV_TTL_MS = 60 * 1000;
const DEDUPE_WINDOW_MS = 10 * 60 * 1000;
const HIGH_RISK_DEDUPE_MS = 30 * 60 * 1000;
const LOGIN_POLL_MS = 3000;
const LOGIN_TTL_MS = 175 * 1000;
// 观看计划：每 30 秒看一眼是不是到了该刷的时间。粒度够用，也不用精确到秒。
const WATCH_TICK_MS = 30 * 1000;
// 同一个视频多久内不重复看（天）
const WATCH_KEEP_DAYS = 7;

/**
 * 「只在固定时段刷」用的时段表 —— 写死，不给改。
 *
 * 为什么不做成可配置：时段是给人省心的，不是让人调参的。
 * 之前留了「每天几点刷」和自由时段两套写法，结果设置页、一句话设置、
 * 状态输出三处各说一套，用户自己都要猜当前到底按哪个跑。
 * 现在只有两条：开关开 = 只在这两段里刷；开关关 = 24 小时都可能刷。
 *
 * 18:00-09:00 跨零点，归同一个实例（见 windowInstance）。
 */
const WATCH_WINDOWS = [
  { key: '12:00-14:00', start: 12 * 60, end: 14 * 60 },
  { key: '18:00-09:00', start: 18 * 60, end: 9 * 60 }
];
// 24 小时模式下两轮之间至少隔多久（随机 20~50 分钟），别一有额度就连续刷完
const WATCH_AUTO_GAP_MIN_MS = 20 * 60 * 1000;
const WATCH_AUTO_GAP_MAX_MS = 50 * 60 * 1000;

const state = {
  loginPoll: null,
  navCache: null,
  buvidCache: null,
  writeChain: Promise.resolve(),
  // 观看任务串行：定时器和手动触发可能撞在一起
  watchChain: Promise.resolve(),
  watchTimer: null,
  watchRunning: false,
  lastSender: null
};

let cfg = () => ({});
let log = () => {};
let warn = () => {};

// ── 配置 ────────────────────────────────────────────────────────────────

function cleanCookie(v) {
  let s = String(v ?? '').trim();
  if (!s || s === '******') return '';
  s = s.replace(/^(SESSDATA|bili_jct|DedeUserID|buvid3)=/i, '');
  if ((s.startsWith('"') && s.endsWith('"')) || (s.startsWith("'") && s.endsWith("'"))) s = s.slice(1, -1);
  return s.trim();
}

function settings() {
  const c = cfg() || {};
  const bool = (k, d) => (typeof c[k] === 'boolean' ? c[k] : d);
  const num = (k, d) => {
    const n = Number(c[k]);
    return Number.isFinite(n) ? n : d;
  };
  const str = (k, d) => (c[k] === undefined || c[k] === null ? d : String(c[k]));
  const oneOf = (k, allowed, d) => {
    const v = str(k, d);
    return allowed.includes(v) ? v : d;
  };
  return {
    autonomy: oneOf('autonomy', ['off', 'confirm', 'auto'], 'auto'),
    highRiskAutonomy: oneOf('highRiskAutonomy', ['off', 'confirm', 'auto'], 'confirm'),
    allowLike: bool('allowLike', true),
    allowCoin: bool('allowCoin', true),
    allowFavorite: bool('allowFavorite', true),
    allowFollow: bool('allowFollow', true),
    allowComment: bool('allowComment', true),
    allowDynamic: bool('allowDynamic', true),
    coinCount: Math.max(1, Math.min(2, Math.round(num('coinCount', 1)))),
    favoriteFolderId: str('favoriteFolderId', '').trim(),
    maxWritesPerDay: Math.max(0, Math.round(num('maxWritesPerDay', 30))),
    maxCommentsPerDay: Math.max(0, Math.round(num('maxCommentsPerDay', 5))),
    maxDynamicsPerDay: Math.max(0, Math.round(num('maxDynamicsPerDay', 2))),
    minSecondsBetweenWrites: Math.max(0, Math.round(num('minSecondsBetweenWrites', 8))),
    qrToPrivate: bool('qrToPrivate', true),
    announceActions: bool('announceActions', false),
    // ── 每日刷视频（v1.1）────────────────────────────────────────────
    watchEnabled: bool('watchEnabled', false),
    dailyWatchCount: Math.max(1, Math.min(50, Math.round(num('dailyWatchCount', 6)))),
    watchTags: str('watchTags', ''),
    watchOrder: oneOf('watchOrder', ['random', 'pubdate', 'click'], 'random'),
    watchSeconds: Math.max(10, Math.min(600, Math.round(num('watchSeconds', 90)))),
    watchMaxDurationMin: Math.max(1, Math.min(300, Math.round(num('watchMaxDurationMin', 30)))),
    watchPeakValley: bool('watchPeakValley', true),
    watchAutoLike: bool('watchAutoLike', false),
    watchNotify: bool('watchNotify', true),
    recommendCommentEnabled: bool('recommendCommentEnabled', false),
    recommendAtUid: str('recommendAtUid', '').trim(),
    recommendAtName: str('recommendAtName', '').trim(),
    recommendCommentTemplate: str('recommendCommentTemplate', '这个挺好看的，推给你：{title}\n{url}'),
    sessdata: cleanCookie(str('sessdata', '')),
    biliJct: cleanCookie(str('biliJct', '')),
    dedeUserId: cleanCookie(str('dedeUserId', '')),
    buvid3: cleanCookie(str('buvid3', ''))
  };
}

function bjHour() {
  return new Date(Date.now() + 8 * 3600 * 1000).getUTCHours();
}

function todayKey() {
  const d = new Date(Date.now() + 8 * 3600 * 1000);
  return `${d.getUTCFullYear()}-${String(d.getUTCMonth() + 1).padStart(2, '0')}-${String(d.getUTCDate()).padStart(2, '0')}`;
}

/** 北京时间的 HH:MM。 */
function bjClock() {
  const d = new Date(Date.now() + 8 * 3600 * 1000);
  return `${String(d.getUTCHours()).padStart(2, '0')}:${String(d.getUTCMinutes()).padStart(2, '0')}`;
}

/** "原神，崩坏 星穹铁道, 王者" → ['原神','崩坏 星穹铁道','王者'] */
function parseTags(raw, limit = 10) {
  const out = [];
  const seen = new Set();
  for (const part of String(raw ?? '').split(/[,，、;；\n]+/)) {
    const t = part.trim();
    if (!t) continue;
    const k = t.toLowerCase();
    if (seen.has(k)) continue;
    seen.add(k);
    out.push(t);
    if (out.length >= limit) break;
  }
  return out;
}

// ── 观看计划（plan.json） ───────────────────────────────────────────────
//
// 为什么单独一份文件而不是写回 config.json：
//   ① 技能没有写配置的权限（api 只给了 config() 读）；
//   ② config.json 是主人手工维护的，插件回写容易把手工改动冲掉。
// 所以「用一句话改计划」落在 plan.json 上，读的时候盖在设置页默认值之上。

const PLAN_FIELDS = {
  watchEnabled: 'bool',
  dailyWatchCount: 'count',
  watchTags: 'tags',
  watchOrder: 'order',
  watchSeconds: 'seconds',
  watchMaxDurationMin: 'minutes',
  // ⚠️ watchPeakValley 故意不在这里：峰谷开关只听技能设置页。
  // 布尔值只有两态，用「快照比对」判断设置页有没有改过会失灵（改回原值就分辨不出），
  // 一旦 plan 压住它，设置页那个开关就会变成"点了没反应"。宁可不给聊天改，也不能骗人。
  watchAutoLike: 'bool',
  watchNotify: 'bool',
  recommendCommentEnabled: 'bool',
  recommendAtUid: 'uid',
  recommendAtName: 'text',
  recommendCommentTemplate: 'template'
};

function normalizePlanValue(field, value) {
  const kind = PLAN_FIELDS[field];
  switch (kind) {
    case 'bool': return value === true;
    case 'count': return Math.max(1, Math.min(50, Math.round(Number(value) || 6)));
    case 'seconds': return Math.max(10, Math.min(600, Math.round(Number(value) || 90)));
    case 'minutes': return Math.max(1, Math.min(300, Math.round(Number(value) || 30)));
    case 'order': return ['random', 'pubdate', 'click'].includes(String(value)) ? String(value) : 'random';
    case 'tags': return Array.isArray(value) ? value.join(',') : String(value ?? '');
    case 'uid': return String(value ?? '').replace(/\D/g, '').slice(0, 15);
    case 'template': return String(value ?? '').slice(0, 500);
    case 'text': return String(value ?? '').trim().slice(0, 40);
    default: return value;
  }
}

function loadPlan() {
  const raw = readJson(PLAN_FILE, null);
  if (!raw || typeof raw !== 'object') return {};
  const out = {};
  for (const field of Object.keys(PLAN_FIELDS)) {
    if (raw[field] === undefined || raw[field] === null || raw[field] === '') continue;
    out[field] = normalizePlanValue(field, raw[field]);
  }
  // base：写 plan 时各项在设置页里的原值（用于判断设置页后来有没有被改过）
  if (raw.base && typeof raw.base === 'object') {
    const base = {};
    for (const [k, v] of Object.entries(raw.base)) {
      if (PLAN_FIELDS[k] && v !== undefined) base[k] = v;
    }
    if (Object.keys(base).length) out.base = base;
  }
  return out;
}

function savePlan(patch) {
  const next = { ...loadPlan() };
  const s = settings();
  const base = { ...(next.base || {}) };
  for (const [field, value] of Object.entries(patch || {})) {
    if (!PLAN_FIELDS[field]) continue;
    if (value === undefined || value === null) {
      delete next[field];
      delete base[field];
      continue;
    }
    next[field] = normalizePlanValue(field, value);
    // 记下写这一笔时设置页是什么值 —— 以后设置页一改，这一项就让位（见 planPick）
    base[field] = s[field];
  }
  if (Object.keys(base).length) next.base = base; else delete next.base;
  writeJson(PLAN_FILE, { version: 1, updatedAt: Date.now(), ...next });
  return next;
}

/**
 * plan.json 的覆盖只在「设置页没动过这一项」时才生效。
 * 判据是写入时记下的 base 快照：设置页当前值与快照对不上 = 用户后来在设置页改过 → 以设置页为准。
 * 没有这一层，plan 会把设置页对应项永久压住：在设置里改了数量/tag/开关，机器人照旧按旧值跑，
 * 看起来就像"设置页坏了"。（这正是之前踩过的坑，现在从机制上修掉。）
 */
function planPick(plan, s) {
  return (k) => {
    const v = plan[k];
    if (v === undefined) return s[k];
    const b = plan.base ? plan.base[k] : undefined;
    if (b !== undefined && s[k] !== b) return s[k];
    return v;
  };
}

/** 设置页默认值 + plan.json 覆盖 → 最终生效的观看计划。 */
function watchPlan() {
  const s = settings();
  const p = loadPlan();
  const pick = planPick(p, s);
  const tags = parseTags(pick('watchTags'));
  // 峰谷开关只读设置页（见 PLAN_FIELDS 的注释），plan 里不参与覆盖
  const peakValley = s.watchPeakValley !== false;   // 默认开：只在固定时段刷
  const overridden = Object.keys(p).filter((k) => k !== 'base' && pick(k) === p[k]);
  return {
    enabled: pick('watchEnabled') === true,
    dailyCount: Math.max(1, Math.min(50, Math.round(Number(pick('dailyWatchCount')) || 6))),
    tags,
    order: pick('watchOrder'),
    watchSeconds: Math.max(10, Math.min(600, Math.round(Number(pick('watchSeconds')) || 90))),
    maxDurationSec: Math.max(60, Math.round((Number(pick('watchMaxDurationMin')) || 30) * 60)),
    // 开关：开 = 只在 WATCH_WINDOWS 的两段里刷；关 = 24 小时都可能刷
    peakValley,
    windows: peakValley ? WATCH_WINDOWS : [],
    windowsText: WATCH_WINDOWS.map((w) => w.key).join('、'),
    // 每轮分几段：开时段 = 两段各跑一次；不限时段 = 仍分 2 次跑完当天额度
    // （一轮就把额度刷光太像脚本，分两次、中间隔 20~50 分钟更像真人）
    segments: peakValley ? WATCH_WINDOWS.length : 2,
    autoLike: pick('watchAutoLike') === true,
    notify: pick('watchNotify') === true,
    comment: {
      enabled: pick('recommendCommentEnabled') === true,
      atUid: String(pick('recommendAtUid') || '').trim(),
      atName: String(pick('recommendAtName') || '').trim(),
      // 留空 = 按 persona.md 的句式库现写；填了就当理由段用（可用 {fact} {title} {up} {at} 等）
      template: String(pick('recommendCommentTemplate') || '')
    },
    overridden
  };
}

// ── 文件 ────────────────────────────────────────────────────────────────

function ensureStoreDir() {
  try { fs.mkdirSync(STORE_DIR, { recursive: true }); } catch (e) { warn(`创建数据目录失败：${e?.message ?? e}`); }
}

function readJson(file, fallback) {
  try { return JSON.parse(fs.readFileSync(file, 'utf8')); } catch { return fallback; }
}

function writeJson(file, data) {
  ensureStoreDir();
  fs.writeFileSync(file, JSON.stringify(data, null, 2), { encoding: 'utf8', mode: 0o600 });
}

function loadStoredSession() {
  const raw = readJson(SESSION_FILE, null);
  if (!raw || typeof raw !== 'object') return { version: 1, cookies: {} };
  return { version: 1, ...raw, cookies: (raw.cookies && typeof raw.cookies === 'object') ? raw.cookies : {} };
}

function saveStoredSession(session) {
  writeJson(SESSION_FILE, { version: 1, savedAt: Date.now(), ...session });
}

function clearStoredSession() {
  try { fs.rmSync(SESSION_FILE, { force: true }); } catch (e) { warn(`清除登录态失败：${e?.message ?? e}`); }
}

function emptyState(day) {
  return {
    day,
    writes: 0,
    comments: 0,
    dynamics: 0,
    lastWriteAt: 0,
    recent: [],
    // 观看相关（跨天归零的只有计数，历史列表按天保留 7 天做去重）
    watchCount: 0,
    watchSlots: [],
    watchTargets: {},
    watchAttempts: {},
    watched: [],
    lastWatchAt: 0,
    // 我们发出去的推荐评论（rpid 是唯一能回头定位那条评论的东西；跨天也要留，做去重和复核）
    commentLog: []
  };
}

function loadState() {
  const raw = readJson(STATE_FILE, null);
  const today = todayKey();
  if (!raw || typeof raw !== 'object') return emptyState(today);
  const num = (v) => Math.max(0, Number(v) || 0);
  const sameDay = raw.day === today;
  const cutoff = Date.now() - WATCH_KEEP_DAYS * 24 * 3600 * 1000;
  const watched = (Array.isArray(raw.watched) ? raw.watched : [])
    .filter((x) => x && Number(x.at || 0) > cutoff)
    .slice(-200);
  return {
    day: today,
    writes: sameDay ? num(raw.writes) : 0,
    comments: sameDay ? num(raw.comments) : 0,
    dynamics: sameDay ? num(raw.dynamics) : 0,
    lastWriteAt: sameDay ? num(raw.lastWriteAt) : 0,
    recent: sameDay && Array.isArray(raw.recent) ? raw.recent : [],
    watchCount: sameDay ? num(raw.watchCount) : 0,
    watchSlots: sameDay && Array.isArray(raw.watchSlots) ? raw.watchSlots.filter((x) => typeof x === 'string') : [],
    // 时段模式下"这一轮打算在几点几分跑"的目标时刻（毫秒）；跨天即作废
    watchTargets: sameDay && raw.watchTargets && typeof raw.watchTargets === 'object'
      ? Object.fromEntries(Object.entries(raw.watchTargets).filter(([, v]) => Number(v) > 0))
      : {},
    // 这一轮最近一次尝试的时间：失败（没登录 / 风控 / 没搜到）后要退避，
    // 否则定时器每 30 秒重试一次，日志和接口都会被刷爆。
    watchAttempts: sameDay && raw.watchAttempts && typeof raw.watchAttempts === 'object'
      ? Object.fromEntries(Object.entries(raw.watchAttempts).filter(([, v]) => Number(v) > 0))
      : {},
    watched,
    lastWatchAt: num(raw.lastWatchAt),
    // 评论记录不按天清 —— 复核 / 去重要能回看到更早的。
    // 注意：rpid=0 的记录也要留着（说明确实发过、只是没拿到号），别当没发过。
    commentLog: Array.isArray(raw.commentLog)
      ? raw.commentLog.filter((x) => x && x.bvid).slice(-100)
      : []
  };
}

function saveState(st) {
  writeJson(STATE_FILE, st);
}

// ── 会话 ────────────────────────────────────────────────────────────────

function effectiveSession() {
  const s = settings();
  const stored = loadStoredSession();
  const cookies = { ...(stored.cookies || {}) };

  // 手动 Cookie 覆盖文件；如果手动 SESSDATA 与文件里的不是同一个号，
  // 不要把文件里的旧 bili_jct 混进来（否则 csrf 必然不配套）。
  const manualSess = s.sessdata;
  if (manualSess) {
    if (manualSess !== cookies.SESSDATA && !s.biliJct) delete cookies.bili_jct;
    cookies.SESSDATA = manualSess;
  }
  if (s.biliJct) cookies.bili_jct = s.biliJct;
  if (s.dedeUserId) cookies.DedeUserID = s.dedeUserId;
  if (s.buvid3) cookies.buvid3 = s.buvid3;

  if (state.buvidCache) {
    if (!cookies.buvid3) cookies.buvid3 = state.buvidCache.buvid3;
    if (!cookies.buvid4) cookies.buvid4 = state.buvidCache.buvid4;
  }

  return {
    stored,
    cookies,
    hasLogin: Boolean(String(cookies.SESSDATA || '').trim()),
    hasCsrf: Boolean(String(cookies.bili_jct || '').trim())
  };
}

async function ensureBuvid(session) {
  if (session.cookies.buvid3) {
    state.buvidCache = { buvid3: session.cookies.buvid3, buvid4: session.cookies.buvid4 || '' };
    return;
  }
  try {
    const b = await fetchBuvid(fetch);
    if (b.buvid3) {
      session.cookies.buvid3 = b.buvid3;
      session.cookies.buvid4 = b.buvid4;
      state.buvidCache = { buvid3: b.buvid3, buvid4: b.buvid4 };
      if (session.stored?.cookies && Object.keys(session.stored.cookies).length) {
        session.stored.cookies = { ...session.stored.cookies, buvid3: b.buvid3, buvid4: b.buvid4 };
        saveStoredSession(session.stored);
      }
      return;
    }
  } catch (e) {
    warn(`获取 buvid 失败（用随机值兜底）：${e?.message ?? e}`);
  }
  const b3 = randomBuvid3();
  session.cookies.buvid3 = b3;
  state.buvidCache = { buvid3: b3, buvid4: '' };
}

async function apiAuth() {
  const session = effectiveSession();
  if (!session.hasLogin) throw new BiliApiError(-101, '还没登录 B 站账号');
  await ensureBuvid(session);
  return { ...session, cookie: cookieString(session.cookies) };
}

async function getNav({ force = false } = {}) {
  const session = effectiveSession();
  if (!session.hasLogin) return { loggedIn: false, reason: '还没有登录 B 站账号' };
  await ensureBuvid(session);
  const cookie = cookieString(session.cookies);
  if (!force && state.navCache && state.navCache.cookie === cookie && Date.now() - state.navCache.at < NAV_TTL_MS) {
    return state.navCache.value;
  }
  let payload;
  try {
    payload = await nav(fetch, cookie);
  } catch (e) {
    return { loggedIn: false, reason: friendly(e), error: e };
  }
  if (payload?.code === 0 && payload?.data?.isLogin) {
    const value = { loggedIn: true, data: payload.data, cookie };
    state.navCache = { at: Date.now(), cookie, value };
    if (session.stored?.cookies && Object.keys(session.stored.cookies).length) {
      session.stored.mid = payload.data.mid;
      session.stored.uname = payload.data.uname;
      saveStoredSession(session.stored);
    }
    return value;
  }
  return {
    loggedIn: false,
    reason: payload?.code === -101 ? 'SESSDATA 已失效或未登录' : (payload?.message || '登录状态异常'),
    payload
  };
}

async function requireAccount() {
  const a = await getNav({ force: true });
  if (!a.loggedIn) throw new BiliApiError(-101, a.reason || '还没登录 B 站账号');
  return a;
}

// ── 错误文案 ────────────────────────────────────────────────────────────

const ERROR_TEXT = {
  '-1': 'B站请求失败',
  '-101': '账号未登录或登录已失效，请重新让我扫码登录',
  '-102': '账号被封停',
  '-104': '硬币不足',
  '-111': 'csrf 校验失败（bili_jct 与 SESSDATA 不配套或已过期）',
  '-352': '触发 B 站风控（-352），请稍后再试或换个网络',
  '-400': '请求参数不对',
  '-403': '账号异常，操作被拒绝',
  '-412': '触发 B 站风控（412），请稍后再试',
  '-509': '请求过于频繁',
  '65004': '还没点赞，无法取消',
  '65006': '已经点过赞了',
  '10003': '视频不存在或已删除',
  '11201': '已经收藏过了',
  '11202': '还没收藏，无法取消',
  '11203': '收藏夹已达上限',
  '22001': '不能对自己进行这个操作',
  '22013': '账号已注销，无法操作',
  '22014': '已经关注过这个 UP 主了',
  '34002': '不能给自己投币',
  '34003': '投币数量不合法（只能是 1 或 2）',
  '34004': '投币间隔太短，稍后再试',
  '34005': '这个视频的投币数已达上限',
  '40061': '用户不存在',
  '12002': '评论区已关闭',
  '12015': '需要验证码，暂时无法评论',
  '12016': '评论包含敏感信息，被 B 站拒绝',
  '12025': '评论字数过多',
  '12051': '评论重复，请勿刷屏',
  '12035': '该账号被 UP 主列入评论黑名单',
  '4126021': '账号未绑定手机，无法发布动态',
  '500406': '这条动态不是当前账号的，不能删除'
};

function friendly(e) {
  if (!e) return '未知错误';
  if (Number(e.status) === 412) return ERROR_TEXT['-412'];
  const code = Number(e.code);
  if (ERROR_TEXT[String(code)]) return ERROR_TEXT[String(code)];
  return e.message || String(e);
}

function errorWithCode(e) {
  const text = friendly(e);
  const code = Number(e?.code);
  if (code && !text.includes(String(code))) return `${text}（错误码 ${code}）`;
  return text;
}

// ── 限额 / 闸门 ─────────────────────────────────────────────────────────

function quotaStatus() {
  const st = loadState();
  const s = settings();
  return {
    writes: st.writes,
    maxWrites: s.maxWritesPerDay,
    comments: st.comments,
    maxComments: s.maxCommentsPerDay,
    dynamics: st.dynamics,
    maxDynamics: s.maxDynamicsPerDay,
    lastWriteAt: st.lastWriteAt
  };
}

function isRecent(key, windowMs) {
  const st = loadState();
  const now = Date.now();
  return st.recent.some((r) => r && r.key === key && now - Number(r.at || 0) < windowMs);
}

function markRecent(st, key) {
  const now = Date.now();
  st.recent = [
    ...(st.recent || []).filter((r) => r && now - Number(r.at || 0) < 24 * 3600 * 1000),
    { key, at: now }
  ].slice(-50);
}

function bumpQuota(kind, key) {
  const st = loadState();
  st.writes += 1;
  if (kind === 'comment') st.comments += 1;
  if (kind === 'dynamic') st.dynamics += 1;
  st.lastWriteAt = Date.now();
  if (key) markRecent(st, key);
  saveState(st);
}

/**
 * 写操作闸门。
 * @param {'write'|'comment'|'dynamic'} kind
 * @param {object} s settings()
 * @param {boolean} confirm 用户是否明确同意
 * @param {{highRisk?: boolean}} opts
 */
function gateWrite(kind, s, confirm, opts = {}) {
  const highRisk = opts.highRisk ?? (kind === 'comment' || kind === 'dynamic');
  const mode = highRisk ? s.highRiskAutonomy : s.autonomy;

  if (mode === 'off') {
    return { ok: false, reason: highRisk ? '评论/发动态的自动操作已关闭（高风险操作 = off）' : '自动操作已关闭（自动模式 = off）' };
  }
  if (mode === 'confirm' && confirm !== true) {
    return {
      ok: false,
      reason: highRisk
        ? '这一步会以你的账号公开发言。请先在群里明确问一句并得到同意，再调用（confirm=true）。'
        : '这一步会改动你的 B 站账号。请先得到用户明确同意，再调用（confirm=true）。'
    };
  }
  // 写闸只剩三道：模式 → 每日限额 → 最小间隔（静默时段已移除）

  const st = loadState();
  if (s.maxWritesPerDay > 0 && st.writes >= s.maxWritesPerDay) {
    return { ok: false, reason: `今天的写操作已达上限（${st.writes}/${s.maxWritesPerDay}）` };
  }
  if (kind === 'comment' && s.maxCommentsPerDay > 0 && st.comments >= s.maxCommentsPerDay) {
    return { ok: false, reason: `今天的评论已达上限（${st.comments}/${s.maxCommentsPerDay}）` };
  }
  if (kind === 'dynamic' && s.maxDynamicsPerDay > 0 && st.dynamics >= s.maxDynamicsPerDay) {
    return { ok: false, reason: `今天的动态已达上限（${st.dynamics}/${s.maxDynamicsPerDay}）` };
  }

  const gap = Math.max(0, s.minSecondsBetweenWrites) * 1000;
  const wait = st.lastWriteAt ? Math.max(0, gap - (Date.now() - st.lastWriteAt)) : 0;
  if (wait > 12000) return { ok: false, reason: `操作太频繁，请 ${Math.ceil(wait / 1000)} 秒后再试` };
  return { ok: true, wait };
}

function withWriteLock(fn) {
  const run = state.writeChain.then(fn, fn);
  state.writeChain = run.catch(() => {});
  return run;
}

// ── 小工具 ──────────────────────────────────────────────────────────────

function ok(content) { return { content: String(content) }; }
function fail(content) { return { content: String(content), isError: true }; }
function sleep(ms) { return new Promise((r) => setTimeout(r, Math.max(0, ms))); }
function clamp(n, lo, hi) { return Math.min(hi, Math.max(lo, Math.round(Number(n) || 0))); }

function fmtDuration(sec) {
  const s = Math.max(0, Math.round(Number(sec) || 0));
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const ss = s % 60;
  const p = (n) => String(n).padStart(2, '0');
  return h > 0 ? `${h}:${p(m)}:${p(ss)}` : `${m}:${p(ss)}`;
}

function hashText(text) {
  return crypto.createHash('sha256').update(String(text)).digest('hex').slice(0, 16);
}

function pickDefaultFolder(folders) {
  if (!Array.isArray(folders) || !folders.length) return null;
  return folders.find((f) => (Number(f.attr) & 2) === 0) || folders[0];
}

async function sendReceipt(ctx, text) {
  if (!settings().announceActions) return;
  try {
    await ctx.sender.sendTextBatch(ctx.chatKey, [String(text)]);
  } catch (e) {
    warn(`发送操作回执失败：${e?.message ?? e}`);
  }
}

async function myMid(auth) {
  if (auth?.stored?.mid) return Number(auth.stored.mid);
  const a = await requireAccount();
  return Number(a.data.mid);
}

// ── 登录 ────────────────────────────────────────────────────────────────

function makeQrDataUrl(url) {
  const lib = getQrLib();
  let lastError = null;
  for (const level of ['M', 'L']) {
    try {
      const qr = lib(0, level);
      qr.addData(String(url));
      qr.make();
      return qr.createDataURL(8, 32);
    } catch (e) { lastError = e; }
  }
  throw new Error(`二维码生成失败：${lastError?.message ?? lastError}`);
}

function getSenderId(ctx) {
  const entries = Array.isArray(ctx?.session?.trigger) ? ctx.session.trigger : [];
  const hit = entries.find((x) => x && !x.self && x.senderId);
  return hit ? String(hit.senderId) : '';
}

async function sendQr(ctx, dataUrl, text) {
  const s = settings();
  const senderId = getSenderId(ctx);
  const targets = [];
  if (s.qrToPrivate && ctx.kind === 'group' && senderId) targets.push(`private:${senderId}`);
  targets.push(ctx.chatKey);
  let lastError = null;
  for (const key of targets) {
    try {
      await ctx.sender.sendImage(key, { dataUrl }, { note: 'B站登录二维码' });
      await ctx.sender.sendTextBatch(key, [text]);
      return key;
    } catch (e) {
      lastError = e;
      warn(`二维码发送到 ${key} 失败：${e?.message ?? e}`);
    }
  }
  throw new Error(`二维码发送失败：${lastError?.message ?? lastError}`);
}

async function notifyLogin(sender, chatKey, text) {
  try {
    await sender.sendTextBatch(chatKey, [String(text)]);
  } catch (e) {
    warn(`登录状态通知发送失败：${e?.message ?? e}`);
  }
}

async function pollLoginOnce(qrcodeKey) {
  const r = await qrPoll(fetch, qrcodeKey);
  if (r.statusCode === 0) {
    const session = effectiveSession();
    const cookies = { ...session.cookies, ...r.cookies };
    if (!cookies.buvid3) {
      try {
        const b = await fetchBuvid(fetch);
        if (b.buvid3) { cookies.buvid3 = b.buvid3; cookies.buvid4 = b.buvid4; }
      } catch { /* 用随机值兜底 */ }
    }
    if (!cookies.buvid3) cookies.buvid3 = randomBuvid3();

    const stored = { version: 1, cookies, refreshToken: r.refreshToken, savedAt: Date.now() };
    let account = null;
    try {
      const payload = await nav(fetch, cookieString(cookies));
      if (payload?.code === 0 && payload?.data?.isLogin) {
        account = payload.data;
        stored.mid = account.mid;
        stored.uname = account.uname;
      }
    } catch (e) {
      warn(`登录成功但读取账号资料失败：${e?.message ?? e}`);
    }
    saveStoredSession(stored);
    state.navCache = null;
    state.buvidCache = { buvid3: cookies.buvid3, buvid4: cookies.buvid4 || '' };
    return { status: 'success', account, cookies };
  }
  if (r.statusCode === 86090) return { status: 'scanned' };
  if (r.statusCode === 86038) return { status: 'expired' };
  if (r.statusCode === 86101) return { status: 'waiting' };
  return { status: 'error', message: r.message || `扫码状态异常（${r.statusCode}）` };
}

function stopLoginPoll(reason) {
  if (state.loginPoll?.timer) {
    clearInterval(state.loginPoll.timer);
    log(`停止扫码轮询（${reason}）`);
  }
  state.loginPoll = null;
}

function startLoginPoll({ qrcodeKey, chatKey, sender }) {
  stopLoginPoll('restart');
  const started = Date.now();
  let scanned = false;
  let polling = false;
  const timer = setInterval(async () => {
    if (polling) return;
    polling = true;
    try {
      if (Date.now() - started > LOGIN_TTL_MS) {
        stopLoginPoll('expired');
        await notifyLogin(sender, chatKey, '二维码已过期，请重新让我发一张。');
        return;
      }
      const r = await pollLoginOnce(qrcodeKey);
      if (r.status === 'success') {
        stopLoginPoll('success');
        const name = r.account?.uname ? `${r.account.uname}（UID ${r.account.mid}）` : 'B站账号';
        await notifyLogin(sender, chatKey, `登录成功：${name}。现在可以让我点赞、投币、收藏、关注、评论或发动态了。`);
      } else if (r.status === 'scanned' && !scanned) {
        scanned = true;
        await notifyLogin(sender, chatKey, '已扫码，请在手机上点“确认登录”。');
      } else if (r.status === 'expired') {
        stopLoginPoll('expired');
        await notifyLogin(sender, chatKey, '二维码已过期，请重新让我发一张。');
      }
    } catch (e) {
      warn(`扫码轮询失败（稍后重试）：${e?.message ?? e}`);
    } finally {
      polling = false;
    }
  }, LOGIN_POLL_MS);
  state.loginPoll = { timer, qrcodeKey, chatKey, started };
}

async function loginStart(ctx, force) {
  if (settings().sessdata) {
    return fail('技能设置里填了手动 SESSDATA，它会覆盖扫码登录结果。请先在设置里清空 SESSDATA 和 bili_jct，再扫码；或者继续用手动 Cookie。');
  }
  if (!force) {
    const cur = await getNav({ force: true });
    if (cur.loggedIn) {
      return ok(`已经登录：${cur.data.uname}（UID ${cur.data.mid}）。如果要换号，再让我“强制重新登录”。`);
    }
  }
  if (!ctx?.sender?.sendImage || !ctx?.chatKey) return fail('当前会话没有发送通道，发不了二维码。');

  const qr = await qrGenerate(fetch);
  const dataUrl = makeQrDataUrl(qr.url);
  const text = 'B站登录二维码：请用 B 站手机 App 扫码，并在手机上确认。二维码 3 分钟内有效。只给主人扫，别转发。扫完我会自动回你。';
  const chatKey = await sendQr(ctx, dataUrl, text);
  startLoginPoll({ qrcodeKey: qr.qrcode_key, chatKey, sender: ctx.sender });
  return ok(`二维码已经发到${chatKey.startsWith('private:') ? '你的私聊' : '本群'}了。请在 3 分钟内用 B 站 App 扫码并确认；扫完我会自动告诉你结果。`);
}

async function loginCheck() {
  if (state.loginPoll) {
    const r = await pollLoginOnce(state.loginPoll.qrcodeKey);
    if (r.status === 'success') {
      stopLoginPoll('success');
      const name = r.account?.uname ? `${r.account.uname}（UID ${r.account.mid}）` : 'B站账号';
      return ok(`登录成功：${name}。`);
    }
    if (r.status === 'scanned') return ok('已经扫码，但还没在手机上确认。请在 B 站 App 里点“确认登录”。');
    if (r.status === 'waiting') return ok('还没扫码。二维码还在有效期内，请用 B 站 App 扫刚才那张图。');
    if (r.status === 'expired') {
      stopLoginPoll('expired');
      return fail('二维码已过期，请重新让我发一张。');
    }
    return fail(r.message || '扫码状态异常');
  }
  const cur = await getNav({ force: true });
  if (cur.loggedIn) return ok(`已经登录：${cur.data.uname}（UID ${cur.data.mid}）。`);
  return fail(`还没登录：${cur.reason}。先让我发二维码。`);
}

// ── 工具实现 ────────────────────────────────────────────────────────────

async function accountSummary() {
  const cur = await getNav({ force: true });
  if (!cur.loggedIn) {
    return ok(`还没登录 B 站账号（${cur.reason}）。\n先调用 bilibili-scroll__login 让我发二维码，或在技能设置里填手动 Cookie。`);
  }
  const d = cur.data;
  let stat = null;
  try {
    const r = await navStat(fetch, cur.cookie);
    if (r?.code === 0) stat = r.data;
  } catch { /* 统计失败不影响主信息 */ }
  const s = settings();
  const q = quotaStatus();
  const lines = [
    `已登录：${d.uname}（UID ${d.mid}）`,
    `等级：Lv${d.level_info?.current_level ?? '?'}　硬币：${d.money ?? '?'}`,
    stat ? `关注：${stat.following}　粉丝：${stat.follower}　动态：${stat.dynamic_count}` : '',
    `自动模式：${s.autonomy}　高风险（评论/动态）：${s.highRiskAutonomy}`,
    `允许：点赞=${s.allowLike ? '开' : '关'} 投币=${s.allowCoin ? '开' : '关'} 收藏=${s.allowFavorite ? '开' : '关'} 关注=${s.allowFollow ? '开' : '关'} 评论=${s.allowComment ? '开' : '关'} 动态=${s.allowDynamic ? '开' : '关'}`,
    `今日额度：写操作 ${q.writes}/${q.maxWrites}　评论 ${q.comments}/${q.maxComments}　动态 ${q.dynamics}/${q.maxDynamics}`,
    watchLine()
  ].filter(Boolean);
  return ok(lines.join('\n'));
}

function watchLine() {
  const plan = watchPlan();
  if (!plan.enabled) return '每日看视频：关（可以用“每天帮我看 N 个 xx 的视频”打开）';
  const st = loadState();
  const tags = plan.tags.length ? plan.tags.join('、') : '全站排行榜';
  const cmt = plan.comment.enabled
    ? `；看完评论推荐${plan.comment.atName || plan.comment.atUid ? `并 @ ${plan.comment.atName || plan.comment.atUid}` : ''}`
    : '';
  const when = plan.peakValley ? `时段 ${plan.windowsText}` : '不限时段（24 小时）';
  return `每日看视频：今天 ${st.watchCount}/${plan.dailyCount}　${when}　来源 ${tags}${cmt}`;
}

async function videoInfoTool(args) {
  const target = String(args?.target ?? '').trim();
  if (!target) return fail('缺少 target：请给 B 站视频链接或 BV 号。');
  const ref = await resolveVideo(fetch, target);
  const session = effectiveSession();
  let cookie = '';
  if (session.hasLogin) {
    await ensureBuvid(session);
    cookie = cookieString(session.cookies);
  }
  const info = await videoInfo(fetch, { ...ref, cookie });
  let st = null;
  if (session.hasLogin) {
    try { st = await videoState(fetch, { aid: info.aid, cookie }); } catch { /* 状态查不到不影响信息 */ }
  }
  const lines = [
    `《${info.title}》`,
    `UP主：${info.author}（UID ${info.mid}）　时长：${fmtDuration(info.duration)}`,
    `播放 ${info.stat.view}　弹幕 ${info.stat.danmaku}　评论 ${info.stat.reply}　点赞 ${info.stat.like}　投币 ${info.stat.coin}　收藏 ${info.stat.favorite}`,
    `链接：${info.url}`,
    st
      ? `你的状态：${st.liked ? '已点赞' : '未点赞'}；${st.coins === null ? '投币状态未知' : `已投 ${st.coins} 枚`}；${st.favored === null ? '收藏状态未知' : (st.favored ? '已收藏' : '未收藏')}`
      : '（还没登录，看不到“我有没有赞过/投过/收藏过”）'
  ];
  return ok(lines.join('\n'));
}

async function favFoldersTool() {
  const a = await requireAccount();
  const folders = await favFolders(fetch, { mid: a.data.mid, cookie: a.cookie });
  if (!folders.length) return ok('你的 B 站账号还没有收藏夹（或者都是私密且接口没返回）。');
  const lines = folders.map((f, i) => `${i + 1}. ${f.title}（id=${f.id}${(Number(f.attr) & 2) === 0 ? '，默认' : ''}，${f.media_count ?? 0} 个视频）`);
  return ok(lines.join('\n'));
}

async function videoActionTool(ctx, args) {
  const target = String(args?.target ?? '').trim();
  const action = String(args?.action ?? '').trim();
  const confirm = args?.confirm === true;
  if (!target) return fail('缺少 target：请给视频链接或 BV 号。');
  const allowed = ['like', 'unlike', 'coin', 'favorite', 'unfavorite', 'triple'];
  if (!allowed.includes(action)) return fail(`action 只能是：${allowed.join(' / ')}`);

  const s = settings();
  const labelMap = {
    like: '点赞', unlike: '取消点赞', coin: '投币', favorite: '收藏', unfavorite: '取消收藏', triple: '一键三连'
  };
  const label = labelMap[action];
  if ((action === 'like' || action === 'unlike') && !s.allowLike) return fail('设置里没开「点赞」，这次不操作。');
  if (action === 'coin' && !s.allowCoin) return fail('设置里没开「投币」，这次不操作。');
  if ((action === 'favorite' || action === 'unfavorite') && !s.allowFavorite) return fail('设置里没开「收藏」，这次不操作。');
  if (action === 'triple' && (!s.allowLike || !s.allowCoin || !s.allowFavorite)) {
    return fail('一键三连需要同时开启「点赞」「投币」「收藏」三个开关。');
  }

  const ref = await resolveVideo(fetch, target);
  const auth = await apiAuth();
  const info = await videoInfo(fetch, { ...ref, cookie: auth.cookie });
  const dedupeKey = `${action}:${info.aid}`;
  const windowMs = action === 'triple' ? HIGH_RISK_DEDUPE_MS : DEDUPE_WINDOW_MS;
  if (isRecent(dedupeKey, windowMs)) return fail(`《${info.title}》刚刚已经${label}过了，这次不重复。`);

  return withWriteLock(async () => {
    const gate = gateWrite('write', s, confirm);
    if (!gate.ok) return fail(gate.reason);
    if (gate.wait) await sleep(gate.wait);
    if (!auth.hasCsrf) return fail('缺少 bili_jct（CSRF），不能做写操作。请在设置里补上，或重新扫码登录。');

    const jct = String(auth.cookies.bili_jct || '').trim();
    const results = [];
    let changed = false;
    let firstError = null;

    const run = async (name, fn, alreadyCodes = []) => {
      try {
        await fn();
        changed = true;
        results.push(`${name}成功`);
      } catch (e) {
        if (alreadyCodes.includes(Number(e?.code))) {
          results.push(`${name}：${friendly(e)}`);
        } else {
          if (!firstError) firstError = e;
          results.push(`${name}失败：${friendly(e)}`);
        }
      }
    };

    if (action === 'like' || action === 'unlike') {
      await run(label, () => likeVideo(fetch, {
        aid: info.aid, like: action === 'like', csrf: jct, cookie: auth.cookie
      }), action === 'like' ? [65006] : [65004]);
    } else if (action === 'coin') {
      const count = clamp(Number(args?.coinCount) || s.coinCount, 1, 2);
      await run(`投币 ${count} 枚`, () => coinVideo(fetch, {
        aid: info.aid, multiply: count, selectLike: 0, csrf: jct, cookie: auth.cookie
      }));
    } else if (action === 'favorite' || action === 'unfavorite') {
      const mid = await myMid(auth);
      const folders = await favFolders(fetch, { mid, cookie: auth.cookie });
      const folderArg = String(args?.folderId || s.favoriteFolderId || '').trim();
      if (action === 'favorite') {
        const folder = folderArg ? folders.find((f) => String(f.id) === folderArg) : pickDefaultFolder(folders);
        if (!folder) return fail('找不到可用的收藏夹。先用 bilibili-scroll__fav_folders 看看有哪些，或在设置里填收藏夹 id。');
        await run(`收藏到「${folder.title}」`, () => favDeal(fetch, {
          aid: info.aid, add: String(folder.id), csrf: jct, cookie: auth.cookie
        }), [11201]);
      } else {
        const all = folders.map((f) => String(f.id)).filter(Boolean).join(',');
        if (!all) return fail('没有收藏夹可取消。');
        await run('取消收藏', () => favDeal(fetch, {
          aid: info.aid, del: all, csrf: jct, cookie: auth.cookie
        }), [11202]);
      }
    } else if (action === 'triple') {
      const count = clamp(Number(args?.coinCount) || s.coinCount, 1, 2);
      const folderArg = String(args?.folderId || s.favoriteFolderId || '').trim();
      if (count === 2 && !folderArg) {
        await run('一键三连', () => tripleVideo(fetch, { aid: info.aid, csrf: jct, cookie: auth.cookie }));
      } else {
        await run('点赞', () => likeVideo(fetch, {
          aid: info.aid, like: true, csrf: jct, cookie: auth.cookie
        }), [65006]);
        await run(`投币 ${count} 枚`, () => coinVideo(fetch, {
          aid: info.aid, multiply: count, selectLike: 0, csrf: jct, cookie: auth.cookie
        }));
        const mid = await myMid(auth);
        const folders = await favFolders(fetch, { mid, cookie: auth.cookie });
        const folder = folderArg ? folders.find((f) => String(f.id) === folderArg) : pickDefaultFolder(folders);
        if (folder) {
          await run(`收藏到「${folder.title}」`, () => favDeal(fetch, {
            aid: info.aid, add: String(folder.id), csrf: jct, cookie: auth.cookie
          }), [11201]);
        } else {
          results.push('收藏跳过：没有可用收藏夹');
        }
      }
    }

    if (changed) bumpQuota('write', dedupeKey);
    const text = `《${info.title}》\n${results.join('\n')}`;
    if (changed) await sendReceipt(ctx, `已处理《${info.title}》：${results.filter((x) => x.includes('成功')).join('；')}`);
    if (firstError && !changed) return fail(`${text}\n${errorWithCode(firstError)}`);
    return ok(text);
  });
}

async function resolveFollowMid(target) {
  const s = String(target ?? '').trim();
  if (!s) throw new BiliApiError(-400, '缺少 target：请给 UP 主 UID、空间链接或 ta 的视频链接。');
  if (/^\d{1,15}$/.test(s)) return Number(s);
  const m = s.match(/space\.bilibili\.com\/(\d+)/) || s.match(/[?&]mid=(\d+)/) || s.match(/^mid[:：](\d+)$/i);
  if (m) return Number(m[1]);
  if (extractVideoRef(s)) {
    const ref = await resolveVideo(fetch, s);
    const info = await videoInfo(fetch, { ...ref });
    if (info.mid) return Number(info.mid);
  }
  throw new BiliApiError(-400, '请给 UP 主的 UID（数字）、空间链接，或 ta 的视频链接。');
}

async function followTool(ctx, args) {
  const target = String(args?.target ?? '').trim();
  const action = String(args?.action ?? '').trim();
  const confirm = args?.confirm === true;
  const follow = action === 'follow';
  if (action !== 'follow' && action !== 'unfollow') return fail('action 只能是 follow 或 unfollow。');
  const s = settings();
  if (!s.allowFollow) return fail('设置里没开「关注/取关」，这次不操作。');
  if (!target) return fail('缺少 target：请给 UP 主 UID、空间链接或视频链接。');

  const fid = await resolveFollowMid(target);
  const cur = await getNav();
  if (cur.loggedIn && Number(cur.data?.mid) === fid) return fail('不能关注/取关自己。');
  const dedupeKey = `follow:${fid}:${follow ? 1 : 0}`;
  if (isRecent(dedupeKey, DEDUPE_WINDOW_MS)) return fail(`刚刚已经${follow ? '关注' : '取关'}过 UID ${fid} 了，这次不重复。`);

  return withWriteLock(async () => {
    const gate = gateWrite('write', s, confirm);
    if (!gate.ok) return fail(gate.reason);
    if (gate.wait) await sleep(gate.wait);
    const auth = await apiAuth();
    if (!auth.hasCsrf) return fail('缺少 bili_jct（CSRF），不能做写操作。请在设置里补上，或重新扫码登录。');
    try {
      await followUser(fetch, {
        fid, follow, csrf: String(auth.cookies.bili_jct || '').trim(), cookie: auth.cookie
      });
      bumpQuota('write', dedupeKey);
      await sendReceipt(ctx, follow ? `已关注 UID ${fid}` : `已取关 UID ${fid}`);
      return ok(follow ? `已关注 UID ${fid}。` : `已取关 UID ${fid}。`);
    } catch (e) {
      if (follow && Number(e?.code) === 22014) return ok(`已经关注过 UID ${fid} 了。`);
      return fail(errorWithCode(e));
    }
  });
}

async function commentTool(ctx, args) {
  const target = String(args?.target ?? '').trim();
  const message = String(args?.message ?? '').trim();
  const confirm = args?.confirm === true;
  const s = settings();
  if (!s.allowComment) return fail('设置里没开「评论」，这次不操作。');
  if (!target) return fail('缺少 target：请给视频链接或 BV 号。');
  if (!message) return fail('评论内容不能为空。');
  if (message.length > 1000) return fail('评论最多 1000 个字符。');

  const ref = await resolveVideo(fetch, target);
  const auth = await apiAuth();
  const info = await videoInfo(fetch, { ...ref, cookie: auth.cookie });
  const dedupeKey = `comment:${info.aid}:${hashText(message)}`;
  if (isRecent(dedupeKey, HIGH_RISK_DEDUPE_MS)) return fail('这条评论刚刚已经发过了，这次不重复。');

  return withWriteLock(async () => {
    const gate = gateWrite('comment', s, confirm);
    if (!gate.ok) return fail(gate.reason);
    if (gate.wait) await sleep(gate.wait);
    if (!auth.hasCsrf) return fail('缺少 bili_jct（CSRF），不能发评论。请在设置里补上，或重新扫码登录。');

    const replyTo = String(args?.replyTo || '').trim();
    const root = String(args?.root || replyTo || '').trim();
    const parent = String(args?.parent || replyTo || '').trim();
    try {
      const payload = await postComment(fetch, {
        aid: info.aid,
        message,
        csrf: String(auth.cookies.bili_jct || '').trim(),
        cookie: auth.cookie,
        root,
        parent
      });
      const rpid = payload?.data?.rpid_str || payload?.data?.rpid || '';
      bumpQuota('comment', dedupeKey);
      await sendReceipt(ctx, `已在《${info.title}》下发评论`);
      return ok(`评论已发出。\n视频：《${info.title}》\n评论 id：${rpid || '未知'}\n链接：${info.url}${rpid ? `#reply${rpid}` : ''}`);
    } catch (e) {
      return fail(errorWithCode(e));
    }
  });
}

async function dynamicTool(ctx, args) {
  const action = String(args?.action ?? 'post').trim();
  const confirm = args?.confirm === true;
  const s = settings();
  if (!s.allowDynamic) return fail('设置里没开「发动态/删动态」，这次不操作。');

  if (action === 'post') {
    const content = String(args?.content ?? '').trim();
    if (!content) return fail('动态内容不能为空。');
    if (content.length > 2000) return fail('动态正文最多 2000 个字符。');
    const dedupeKey = `dynamic:post:${hashText(content)}`;
    if (isRecent(dedupeKey, HIGH_RISK_DEDUPE_MS)) return fail('这条动态刚刚已经发过了，这次不重复。');
    return withWriteLock(async () => {
      const gate = gateWrite('dynamic', s, confirm);
      if (!gate.ok) return fail(gate.reason);
      if (gate.wait) await sleep(gate.wait);
      const auth = await apiAuth();
      if (!auth.hasCsrf) return fail('缺少 bili_jct（CSRF），不能发动态。请在设置里补上，或重新扫码登录。');
      try {
        let payload;
        try {
          payload = await postDynamicText(fetch, {
            content, csrf: String(auth.cookies.bili_jct || '').trim(), cookie: auth.cookie
          });
        } catch (legacyError) {
          // 旧接口失败时用新版接口兜底（两者返回字段不同）。
          try {
            payload = await postDynamicTextV2(fetch, {
              content, csrf: String(auth.cookies.bili_jct || '').trim(), cookie: auth.cookie
            });
          } catch {
            throw legacyError;
          }
        }
        const id = payload?.data?.dynamic_id_str || payload?.data?.dyn_id_str
          || payload?.data?.dynamic_id || payload?.data?.dyn_id || '';
        bumpQuota('dynamic', dedupeKey);
        await sendReceipt(ctx, '已发布一条 B 站动态');
        return ok(`动态已发布。${id ? `\n动态 id：${id}\n链接：https://t.bilibili.com/${id}` : ''}`);
      } catch (e) {
        return fail(errorWithCode(e));
      }
    });
  }

  if (action === 'delete') {
    const dynamicId = String(args?.dynamicId ?? '').trim();
    if (!/^\d+$/.test(dynamicId)) return fail('缺少 dynamicId，或它不是纯数字的动态 id。');
    const dedupeKey = `dynamic:delete:${dynamicId}`;
    return withWriteLock(async () => {
      const gate = gateWrite('write', s, confirm, { highRisk: true });
      if (!gate.ok) return fail(gate.reason);
      if (gate.wait) await sleep(gate.wait);
      const auth = await apiAuth();
      if (!auth.hasCsrf) return fail('缺少 bili_jct（CSRF），不能删动态。请在设置里补上，或重新扫码登录。');
      try {
        await deleteDynamic(fetch, {
          dynamicId, csrf: String(auth.cookies.bili_jct || '').trim(), cookie: auth.cookie
        });
        bumpQuota('write', dedupeKey);
        await sendReceipt(ctx, `已删除动态 ${dynamicId}`);
        return ok(`动态 ${dynamicId} 已删除。`);
      } catch (e) {
        return fail(errorWithCode(e));
      }
    });
  }

  return fail('action 只能是 post 或 delete。');
}

// ── 每日刷视频 ──────────────────────────────────────────────────────────
//
// 一条视频的"观看"= 点击上报 + 若干次心跳上报。心跳的 played_time / realtime
// 必须单调递增，否则会被判成异常流量（表现为上报成功但不进历史）。
// 这里不下载视频：真正的视频流下载既费流量又没必要，B 站记录观看看的是心跳。

function shuffle(list) {
  const arr = [...list];
  for (let i = arr.length - 1; i > 0; i -= 1) {
    const j = Math.floor(Math.random() * (i + 1));
    [arr[i], arr[j]] = [arr[j], arr[i]];
  }
  return arr;
}

/** 候选池：先按 tag 搜，搜不够用排行榜兜底；已看过的（7 天内）排除。 */
async function collectCandidates(plan, cookie, want) {
  const st = loadState();
  const seen = new Set(st.watched.map((w) => Number(w?.aid)).filter(Boolean));
  const out = [];
  const push = (v) => {
    if (!v || !v.aid || seen.has(Number(v.aid))) return;
    if (!v.durationSec || v.durationSec < 30) return;      // 直播/异常条目
    if (plan.maxDurationSec && v.durationSec > plan.maxDurationSec) return;
    seen.add(Number(v.aid));
    out.push(v);
  };
  const order = plan.order === 'random' ? 'totalrank' : plan.order;
  const errors = [];

  if (plan.tags.length) {
    for (const tag of plan.tags) {
      if (out.length >= want * 2) break;
      try {
        const list = await searchVideos(fetch, { keyword: tag, page: 1, pageSize: 20, order, cookie });
        list.forEach(push);
      } catch (e) { errors.push(`搜「${tag}」失败：${friendly(e)}`); }
    }
    // 不够就翻第二页再来一轮
    if (out.length < want) {
      for (const tag of plan.tags) {
        if (out.length >= want) break;
        try {
          const list = await searchVideos(fetch, { keyword: tag, page: 2, pageSize: 20, order, cookie });
          list.forEach(push);
        } catch (e) { errors.push(`搜「${tag}」第 2 页失败：${friendly(e)}`); }
      }
    }
  }

  if (out.length < want) {
    try {
      const list = await rankingVideos(fetch, { rid: 0, cookie });
      list.forEach(push);
    } catch (e) { errors.push(`取排行榜失败：${friendly(e)}`); }
  }

  const picked = plan.order === 'random' ? shuffle(out) : out;
  return { list: picked.slice(0, want), errors, poolSize: out.length };
}

/** 看一个视频：点击 + 3 次心跳。返回本次实际"看了"多少秒。 */
async function watchOneVideo(auth, video, plan) {
  const info = await videoInfo(fetch, { bvid: video.bvid, aid: video.aid, cookie: auth.cookie });
  if (!info.cid) throw new BiliApiError(-1, '这个视频拿不到 cid，跳过');
  const mid = Number(auth.stored?.mid || 0) || Number((await getNav({ force: false }))?.data?.mid || 0);
  if (!mid) throw new BiliApiError(-101, '拿不到你的 UID，无法上报观看');
  const csrf = String(auth.cookies.bili_jct || '').trim();

  // 上报时长不能超过视频本身，否则一眼假
  const cap = Math.max(10, info.duration - 3);
  const target = Math.min(plan.watchSeconds, cap);
  const startTs = Math.floor(Date.now() / 1000);

  await clickVideo(fetch, { aid: info.aid, cid: info.cid, mid, csrf, cookie: auth.cookie, startTs });

  const beats = 3;
  const step = Math.max(1, Math.round(target / beats));
  let played = 0;
  let real = 0;
  for (let i = 0; i < beats; i += 1) {
    await sleep(4000 + Math.floor(Math.random() * 3000));
    played = Math.min(cap, played + step);
    real = Math.min(target, real + step + Math.floor(Math.random() * 3));
    await heartbeatVideo(fetch, {
      aid: info.aid,
      cid: info.cid,
      mid,
      csrf,
      cookie: auth.cookie,
      playedTime: played,
      realtime: real,
      startTs,
      videoDuration: info.duration,
      lastPlayTime: played
    });
  }
  // desc / stat / tag 是给评论找"为什么值得刷"用的（见 pickReasonFact）。
  // tag 来自搜索结果（videoInfo 不带 tag），所以两个都带上。
  return {
    aid: info.aid,
    bvid: info.bvid,
    title: info.title,
    author: info.author,
    url: info.url,
    duration: info.duration,
    played,
    desc: info.desc,
    pubdate: info.pubdate,
    stat: info.stat,
    tag: String(video?.tag || '')
  };
}

// ── 回复人设（persona.md） ──────────────────────────────────────────────
//
// 为什么是一个 md 文件而不是写死在代码里：评论是替主人在公开场合说话，
// 语气、句式、禁词这种东西只有主人自己知道该怎么调。放进 persona.md 之后，
// 改文件 = 改它说话的样子，下一轮就生效，不用碰代码、不用重启。
//
// 程序只读两节：`## 句式库`（评论壳子）和 `## 禁用词`（不许出现的词）。
// 其余段落是给模型看的原则 —— bilibili-scroll__persona 会把全文读给模型。

const DEFAULT_PERSONA_SENTENCES = [
  '这条值得刷：{fact}',
  '值得刷，{fact}',
  '刷到这条不亏，{fact}'
];
const DEFAULT_PERSONA_FALLBACK = '这条我说不上哪好，但我确实没快进';

/** 人设文件的生效路径：data 下有一份就用它（能扛住升级覆盖），否则用技能里那份。 */
function personaPath() {
  try { if (fs.existsSync(PERSONA_USER)) return PERSONA_USER; } catch { /* 读不到就用出厂版 */ }
  return PERSONA_SHIPPED;
}

/** 从 markdown 里只挑出「句式库」「禁用词」两节的 bullet。 */
function parsePersona(text) {
  const out = { sentences: [], banned: [], fallback: '' };
  let section = '';
  for (const line of String(text || '').split(/\r?\n/)) {
    const h = line.match(/^##\s+(.+?)\s*$/);
    if (h) { section = h[1]; continue; }
    const m = line.match(/^\s*[-*]\s+(.+?)\s*$/);
    if (!m) continue;
    const item = m[1].trim();
    if (!item || item.startsWith('<!--') || item.startsWith('|')) continue;
    if (section.startsWith('句式库')) out.sentences.push(item);
    else if (section.startsWith('兜底句')) { if (!out.fallback) out.fallback = item; }
    else if (section.startsWith('禁用词')) {
      for (const w of item.split(/[,，、;；\s]+/)) {
        const t = w.trim();
        if (t && t.length <= 12) out.banned.push(t);
      }
    }
  }
  return out;
}

function loadPersona() {
  const file = personaPath();
  let raw = '';
  try { raw = fs.readFileSync(file, 'utf8'); }
  catch (e) { warn(`读不到人设文件 ${file}：${e?.message ?? e}（改用默认句式）`); }
  const parsed = parsePersona(raw);
  return {
    file,
    raw,
    sentences: parsed.sentences.length ? parsed.sentences : DEFAULT_PERSONA_SENTENCES,
    banned: parsed.banned,
    fallback: parsed.fallback || DEFAULT_PERSONA_FALLBACK,
    exists: Boolean(raw)
  };
}

function hasBanned(text, banned) {
  const s = String(text || '');
  return banned.some((w) => w && s.includes(w));
}

/** 随机挑一句"壳"，跳过含禁用词的（禁用词是主人写的红线，不拿它开玩笑）。 */
function pickShell(persona) {
  const pool = persona.sentences.filter((s) => !hasBanned(s, persona.banned));
  const list = pool.length ? pool : DEFAULT_PERSONA_SENTENCES;
  return list[Math.floor(Math.random() * list.length)];
}

function fillPlaceholders(tpl, vars) {
  return String(tpl || '').replace(/\{(\w+)\}/g, (all, key) => (vars[key] !== undefined ? String(vars[key]) : all));
}

function fmtCount(n) {
  const v = Math.max(0, Number(n) || 0);
  if (v >= 100000000) return `${(v / 100000000).toFixed(1).replace(/\.0$/, '')}亿`;
  if (v >= 10000) return `${(v / 10000).toFixed(1).replace(/\.0$/, '')}万`;
  return String(v);
}

/**
 * 「这视频为什么值得刷 / 有什么亮点」—— 只用视频的真实信息说，不编。
 * 命中多条时随机挑一条（不然每天的评论都是同一个开头，一眼机器人）。
 */
function pickReasonFact(info, plan) {
  const tags = Array.isArray(plan?.tags) ? plan.tags : [];
  const tagList = String(info?.tag || '').split(/[,，]/).map((s) => s.trim()).filter(Boolean);
  const hitTag = tagList.find((t) => tags.some((k) => t === k || t.includes(k) || k.includes(t)));
  const view = Number(info?.stat?.view || info?.play || 0);
  const like = Number(info?.stat?.like || 0);
  const pub = Number(info?.pubdate || 0) * 1000;
  const dur = Number(info?.duration || 0);
  const facts = [];

  if (hitTag) facts.push({ key: 'tag', text: `tag 里挂着「${hitTag}」，对口` });
  if (pub && Date.now() - pub < 3 * 86400000) facts.push({ key: 'new', text: '刚发出来没几天，还热乎' });
  if (view >= 500000) facts.push({ key: 'view', text: `播放已经 ${fmtCount(view)} 了，不是我一个人在吹` });
  else if (view >= 10000 && like / view >= 0.06) facts.push({ key: 'like', text: '点赞占比不低，不像刷出来的' });
  if (dur > 0 && dur <= 300) facts.push({ key: 'short', text: `时长 ${fmtDuration(dur)}，刷完不占时间` });

  const firstLine = String(info?.desc || '')
    .split(/\r?\n/).map((s) => s.trim()).find((s) => s.length >= 8 && s.length <= 60 && !/^https?:/i.test(s));
  if (firstLine) {
    const quote = firstLine.replace(/[「」“”"]/g, '').replace(/[,，。.、;；:：\s]+$/, '').slice(0, 20);
    facts.push({ key: 'desc', text: `简介里那句「${quote}」就够了` });
  }

  if (facts.length) {
    const pick = facts[Math.floor(Math.random() * facts.length)];
    return { text: pick.text, key: pick.key, tag: hitTag || '' };
  }
  return { text: '这条我说不上哪好，但我确实没快进', key: 'none', tag: hitTag || '' };
}

/**
 * 评论正文。格式是写死的（见 persona.md「评论格式」）：
 *   第一段 @对方  →  第二段一句「为什么值得刷 / 亮点」
 * 设置里填了 recommendCommentTemplate 时，那段文案当作理由段整体替换（老行为保留）。
 */
function buildRecommendText(plan, info) {
  const persona = loadPersona();
  const atName = String(plan.comment.atName || '').trim();
  const fact = pickReasonFact(info, plan);
  const vars = {
    at: atName ? `@${atName}` : '',
    fact: fact.text,
    up: info.author || '',
    title: info.title || '',
    tag: fact.tag || String(info.tag || '').split(/[,，]/)[0] || '',
    duration: fmtDuration(info.duration),
    url: info.url || ''
  };

  const override = String(plan.comment.template || '').trim();
  let body;
  if (override) {
    body = fillPlaceholders(override, vars).trim();
    // 老模板一般自带 {at}；没写就补在前面，保证"艾特"这一位不缺席。
    if (atName && !body.includes(`@${atName}`)) body = `@${atName}\n${body}`;
  } else {
    // 一条真实亮点都找不到时不硬套壳子 —— 那句兜底本身就是完整的句子，
    // 再包一层就成了"亮点就在这：我说不上哪好"这种怪话。
    const reason = fact.key === 'none'
      ? (persona.fallback || fact.text)
      : fillPlaceholders(pickShell(persona), vars).trim();
    body = atName ? `@${atName}\n${reason}` : reason;
  }

  body = body.replace(/[ \t]+\n/g, '\n').replace(/\n{3,}/g, '\n\n').trim().slice(0, 900);
  // B 站的 @ 后面要有分隔符才会被解析成提及；换行本身就是分隔符，这里再保险一个空格。
  return `${body} `;
}


/** 在视频下发一条"@某人 + 推荐"的评论。返回 'sent' | 跳过原因。 */
async function postRecommendComment(auth, info, plan) {
  const s = settings();
  if (!s.allowComment) return { ok: false, reason: '设置里没开「评论」' };
  if (s.highRiskAutonomy !== 'auto') {
    return { ok: false, reason: '定时任务里没法问你，自动评论需要把「高风险模式」改成 auto' };
  }
  const message = buildRecommendText(plan, info);
  if (!message.trim()) return { ok: false, reason: '评论模板是空的' };
  const dedupeKey = `comment:${info.aid}:${hashText(message)}`;
  if (isRecent(dedupeKey, HIGH_RISK_DEDUPE_MS)) return { ok: false, reason: '这条评论刚发过' };

  const gate = gateWrite('comment', s, false);
  if (!gate.ok) return { ok: false, reason: gate.reason };
  if (gate.wait) await sleep(gate.wait);

  const csrf = String(auth.cookies.bili_jct || '').trim();
  const atUid = plan.comment.atUid;
  const send = (withAt) => postComment(fetch, {
    aid: info.aid,
    message,
    csrf,
    cookie: auth.cookie,
    atUids: withAt ? atUid : ''
  });
  try {
    let result;
    try {
      result = await send(Boolean(atUid));
    } catch (e) {
      // at_uids 与正文不匹配时部分账号会返回参数错误 —— 去掉它，保留正文 @ 再试一次
      if (!atUid || Number(e?.code) !== -400) throw e;
      result = await send(false);
    }
    bumpQuota('comment', dedupeKey);
    // rpid 是后面唯一能回头定位这条评论的凭据（复核公开可见、判重、将来回评论）。
    // 接口没给就留 0，绝不自己编一个号 —— 编了会核到别人身上。
    const rpid = Number(result?.data?.rpid || result?.data?.rpid_str || result?.rpid || 0) || 0;
    return { ok: true, message: message.trim(), rpid };
  } catch (e) {
    return { ok: false, reason: friendly(e) };
  }
}

function watchSummaryText(result) {
  const lines = [];
  if (result.error) {
    lines.push(`这轮刷视频没跑成：${result.error}`);
    return lines.join('\n');
  }
  lines.push(`今天看了 ${result.totalToday}/${result.dailyCount} 个视频（本轮 ${result.watched.length} 个）。`);
  if (result.watched.length) {
    for (const w of result.watched.slice(0, 8)) {
      lines.push(`· ${w.title}（${fmtDuration(w.duration)}，${w.author}）`);
    }
  }
  if (result.comment?.ok) {
    lines.push(`已在《${result.comment.title}》下发了推荐评论并 @ 了对方${result.comment.rpid ? `（rpid ${result.comment.rpid}）` : ''}。`);
    lines.push('提示：接口回成功不等于对方看得到，说「复核评论」可以确认是否公开显示。');
  }
  else if (result.comment?.reason) lines.push(`评论没发：${result.comment.reason}`);
  if (result.errors?.length) lines.push(`有 ${result.errors.length} 个小问题：${result.errors.slice(0, 2).join('；')}`);
  return lines.join('\n');
}

/**
 * 跑一轮。
 * @param {{trigger?:'timer'|'manual', slot?:string, count?:number, ctx?:object}} opts
 */
async function runWatchRound(opts = {}) {
  const trigger = opts.trigger || 'manual';
  const plan = watchPlan();
  if (trigger === 'timer' && !plan.enabled) {
    return { skipped: '观看计划没开启', error: '' };
  }
  const st = loadState();
  const remain = Math.max(0, plan.dailyCount - st.watchCount);
  if (remain <= 0) {
    return { skipped: `今天已经看够 ${plan.dailyCount} 个了`, watched: [], totalToday: st.watchCount, dailyCount: plan.dailyCount };
  }
  const perSlot = Math.max(1, Math.ceil(plan.dailyCount / Math.max(1, plan.segments)));
  const want = Math.max(1, Math.min(remain, Math.round(Number(opts.count) || perSlot)));

  const auth = await apiAuth();
  if (!auth.hasCsrf) {
    return { skipped: '', error: '缺少 bili_jct（CSRF），看视频要上报观看状态，先在设置里补上或重新扫码登录' };
  }

  const { list, errors } = await collectCandidates(plan, auth.cookie, want + 4);
  if (!list.length) {
    return { skipped: '', error: `没找到可看的视频（${plan.tags.length ? `tag：${plan.tags.join('、')}` : '排行榜'}）${errors.length ? `；${errors[0]}` : ''}` };
  }

  const watched = [];
  let commentResult = null;
  let commentedTitle = '';
  for (const video of list) {
    if (watched.length >= want) break;
    try {
      const w = await watchOneVideo(auth, video, plan);
      watched.push(w);
      st.watchCount += 1;
      st.lastWatchAt = Date.now();
      st.watched = [...st.watched, { aid: w.aid, bvid: w.bvid, title: w.title, at: Date.now(), commented: false }].slice(-200);
      saveState(st);
      log(`已观看：${w.title}（上报 ${w.played}s）`);

      // 自动点赞（走原来的写闸：开关 + 限额 + 频率）
      if (plan.autoLike && settings().allowLike) {
        const s = settings();
        const gate = gateWrite('write', s, false);
        if (gate.ok) {
          if (gate.wait) await sleep(gate.wait);
          try {
            await likeVideo(fetch, { aid: w.aid, like: true, csrf: String(auth.cookies.bili_jct || '').trim(), cookie: auth.cookie });
            bumpQuota('write', `like:${w.aid}`);
          } catch { /* 点不上就算了，不影响观看 */ }
        }
      }

      // 本轮第一个视频用来发推荐评论
      if (plan.comment.enabled && !commentResult && watched.length === 1) {
        commentResult = await postRecommendComment(auth, w, plan);
        commentedTitle = w.title;
        if (commentResult.ok) {
          st.watched = st.watched.map((x) => (x.aid === w.aid ? { ...x, commented: true } : x));
          st.commentLog = [...(st.commentLog || []), {
            aid: w.aid,
            bvid: w.bvid,
            rpid: Number(commentResult.rpid) || 0,
            at: Date.now(),
            text: String(commentResult.message || '').slice(0, 40)
          }].slice(-100);
          saveState(st);
        }
      }
    } catch (e) {
      errors.push(`《${video.title}》失败：${friendly(e)}`);
    }
    // 视频之间留点间隔，别看起来像脚本扫库
    if (watched.length < want) await sleep(8000 + Math.floor(Math.random() * 12000));
  }

  // 一个都没看成不算跑过这一段（靠 30 分钟退避重试），避免"失败也算完成"。
  // 不限时段模式没有"段"的概念（slot='auto'），完成情况只看 watchCount。
  if (opts.slot && opts.slot !== 'auto' && watched.length) {
    st.watchSlots = [...new Set([...st.watchSlots, String(opts.slot)])];
    saveState(st);
  }

  const result = {
    watched,
    errors,
    comment: commentResult ? { ...commentResult, title: commentedTitle } : null,
    totalToday: st.watchCount,
    dailyCount: plan.dailyCount
  };
  // 只有定时任务需要主动发回执（手动触发时模型自己会回话，别重复刷两条）
  // 凌晨刷的那一轮不发回执，免得半夜弹消息 —— 记录照样写进 state。
  const hour = bjHour();
  if (plan.notify && trigger === 'timer' && hour >= 8 && hour <= 23) {
    const text = watchSummaryText(result);
    const chatKey = opts.ctx?.chatKey ? String(opts.ctx.chatKey) : state.lastSender?.chatKey;
    const sender = opts.ctx?.sender?.sendTextBatch ? opts.ctx.sender : state.lastSender?.sender;
    if (chatKey && sender?.sendTextBatch) {
      try { await sender.sendTextBatch(chatKey, [text]); } catch (e) { warn(`发观看回执失败：${e?.message ?? e}`); }
    }
  }
  return result;
}

function withWatchLock(fn) {
  const run = state.watchChain.then(fn, fn);
  state.watchChain = run.catch(() => {});
  return run;
}

/**
 * 某个时段在"现在"属于哪一个实例（同一时段每天一次）。
 * 支持跨零点：18:00-09:00 在 20:00 和次日 02:00 都算，且归属同一个实例。
 */
function windowInstance(w, nowMs) {
  const bj = new Date(nowMs + 8 * 3600 * 1000);
  // 北京日期的零点换算成 UTC 时间戳要减掉 8 小时 ——
  // Date.UTC(y,m,d) 是"UTC 零点"，而我们要的是"北京零点"。
  const dayStart = Date.UTC(bj.getUTCFullYear(), bj.getUTCMonth(), bj.getUTCDate()) - 8 * 3600 * 1000;
  const dur = ((w.end - w.start + 1440) % 1440) || 1440;
  for (const offset of [0, -86400000]) {
    const start = dayStart + offset + w.start * 60000;
    const end = start + dur * 60000;
    if (nowMs >= start && nowMs < end) {
      return { start, end, key: `win:${w.key}@${start}` };
    }
  }
  return null;
}

function fireWatchRound(slot) {
  state.watchRunning = true;
  log(`开始刷视频（${slot === 'auto' ? '不限时段' : slot}），这一轮…`);
  withWatchLock(() => runWatchRound({ trigger: 'timer', slot }))
    .catch((e) => warn(`定时刷视频失败：${e?.message ?? e}`))
    .finally(() => {
      state.watchRunning = false;
      // 记一次尝试时间：失败要退避 30 分钟，别让定时器每 30 秒重来一遍
      try {
        const st = loadState();
        st.watchAttempts = { ...st.watchAttempts, [slot]: Date.now() };
        saveState(st);
      } catch { /* 落盘失败不影响下一轮 */ }
    });
}

/** 同一段失败后要等多久才重试（毫秒）。 */
const WATCH_RETRY_BACKOFF_MS = 30 * 60 * 1000;

/** 定时器的一拍：判断"该刷了没"。 */
function watchTick() {
  try {
    const plan = watchPlan();
    if (!plan.enabled) return;
    if (state.watchRunning) return;
    const st = loadState();
    if (st.watchCount >= plan.dailyCount) return;
    const now = Date.now();

    // ① 只在固定时段刷（开关开着）：进入时段后随机等一小段再刷，避免每天同一分钟
    if (plan.peakValley) {
      for (const w of plan.windows) {
        const inst = windowInstance(w, now);
        if (!inst || st.watchSlots.includes(inst.key)) continue;
        const lastTry = Number(st.watchAttempts[inst.key]) || 0;
        if (lastTry && now - lastTry < WATCH_RETRY_BACKOFF_MS) continue;
        let target = Number(st.watchTargets[inst.key]) || 0;
        if (!target) {
          // 抖动范围：时段总长的 1/4，最多 2 小时、最少 20 分钟。
          // 2 小时的时段 = 前后半小时内刷；15 小时的时段 = 头两小时内刷。
          // 时段已经过去很久（应用中途才启动）就直接刷，别等到快结束。
          const span = inst.end - inst.start;
          const cap = Math.min(2 * 3600000, Math.max(20 * 60000, Math.floor(span / 4)));
          const from = Math.max(now, inst.start);
          const room = Math.max(0, inst.end - from);
          const jitter = now > inst.start + cap ? 0 : Math.min(cap, room);
          target = from + Math.floor(Math.random() * Math.max(jitter, 1));
          if (target > inst.end - 60000) target = now;
          st.watchTargets = { ...st.watchTargets, [inst.key]: target };
          saveState(st);
        }
        if (now >= target) { fireWatchRound(inst.key); return; }
      }
      return;
    }

    // ② 不限时段（开关关着）：24 小时都可能刷。
    //    有余额就刷，但两轮之间隔 20~50 分钟 —— 否则配额会在启动后几分钟内一口气刷完，
    //    既不自然，也容易被风控盯上。
    const nextAt = Number(st.watchTargets.auto) || 0;
    if (nextAt && now < nextAt) return;
    const lastTry = Number(st.watchAttempts.auto) || 0;
    if (lastTry && now - lastTry < WATCH_RETRY_BACKOFF_MS) return;
    // 先把"下一轮之前要等多久"记下来再开刷：跑一轮要几十秒，别让下一拍又进来
    const gap = WATCH_AUTO_GAP_MIN_MS + Math.floor(Math.random() * (WATCH_AUTO_GAP_MAX_MS - WATCH_AUTO_GAP_MIN_MS));
    st.watchTargets = { ...st.watchTargets, auto: now + gap };
    saveState(st);
    fireWatchRound('auto');
  } catch (e) {
    warn(`观看调度出错：${e?.message ?? e}`);
  }
}

function startWatchTimer() {
  stopWatchTimer();
  state.watchTimer = setInterval(watchTick, WATCH_TICK_MS);
  state.watchTimer.unref?.();       // 不因为这个定时器拖住进程退出
  const plan = watchPlan();
  const when = plan.peakValley ? `只在 ${plan.windowsText} 刷` : '不限时段（24 小时）';
  log(`观看调度已启动：${plan.enabled ? `每天 ${plan.dailyCount} 个，${when}` : '观看计划当前关闭（仍会定时检查开关状态）'}`);
  // 启动时补跑一次：应用可能是重启后才到点的
  setTimeout(watchTick, 20 * 1000)?.unref?.();
}

function stopWatchTimer() {
  if (state.watchTimer) {
    clearInterval(state.watchTimer);
    state.watchTimer = null;
  }
}

// ── 观看计划的读写工具 ──────────────────────────────────────────────────

function planText(plan, title) {
  const rows = [
    `${title}：${plan.enabled ? '已开启' : '已关闭'}`,
    `每天观看：${plan.dailyCount} 个（分 ${plan.segments} 段，每段约 ${Math.max(1, Math.ceil(plan.dailyCount / Math.max(1, plan.segments)))} 个）`,
    plan.peakValley
      ? `峰谷时段开关：开 → 只在 ${plan.windowsText} 刷（北京时间；进入时段后随机挑时刻，18:00-09:00 跨零点算同一段；开关在技能设置页）`
      : '峰谷时段开关：关 → 24 小时都可能刷（两轮之间隔 20~50 分钟；开关在技能设置页）',
    `视频来源：${plan.tags.length ? `tag/关键词 ${plan.tags.join('、')}` : '全站排行榜（没设 tag）'}，排序 ${plan.order}`,
    `每个视频上报观看 ${plan.watchSeconds} 秒；超过 ${Math.round(plan.maxDurationSec / 60)} 分钟的视频跳过`,
    `看完自动点赞：${plan.autoLike ? '开' : '关'}`,
    plan.comment.enabled
      ? `自动推荐评论：开 → 本轮第一个视频${plan.comment.atUid || plan.comment.atName ? `，@ ${plan.comment.atName || plan.comment.atUid}${plan.comment.atUid ? `（UID ${plan.comment.atUid}）` : ''}` : '（还没设 @ 谁）'}`
      : `自动推荐评论：关${plan.comment.atUid || plan.comment.atName ? `（已预填 @ ${plan.comment.atName || plan.comment.atUid}${plan.comment.atUid ? `（UID ${plan.comment.atUid}）` : ''}，打开就能用）` : ''}`,
    plan.comment.enabled
      ? (plan.comment.template
        ? `评论写法：用你填的文案 → ${plan.comment.template.replace(/\n/g, ' ⏎ ')}`
        : `评论写法：按人设句式现写（${personaPath()}）→「@对方」换行 + 一句为什么值得刷`)
      : '',
    plan.overridden.length ? `（其中 ${plan.overridden.length} 项是聊天里设的：设置页没动过这些项时以它们为准，设置页改过就从设置页）` : ''
  ].filter(Boolean);
  return rows.join('\n');
}

async function findUserByKeyword(keyword, auth) {
  const kw = String(keyword || '').trim();
  if (!kw) return null;
  if (/^\d{4,15}$/.test(kw)) return { mid: kw, uname: '' };
  const list = await searchUsers(fetch, { keyword: kw, cookie: auth?.cookie || '' });
  if (!list.length) return null;
  return list[0];
}

async function watchPlanTool(args = {}) {
  const action = String(args.action || 'get');
  if (action !== 'set') return ok(planText(watchPlan(), '当前观看计划'));

  const patch = {};
  if (typeof args.enabled === 'boolean') patch.watchEnabled = args.enabled;
  if (args.count !== undefined && args.count !== null && args.count !== '') patch.dailyWatchCount = args.count;
  if (args.tags !== undefined) patch.watchTags = parseTags(args.tags).join(',');
  if (args.peakValley !== undefined) {
    // 峰谷开关只有一个来源：技能设置页。这里明确拒绝，而不是假装改成功。
    return fail('峰谷时段开关在「技能设置 → B站账号助手 → 峰谷时段开关」里，那边点了立即生效，聊天里改不了。要不要现在关掉/打开，你在设置页点一下就行。');
  }
  if (args.order) {
    const o = String(args.order);
    if (!['random', 'pubdate', 'click'].includes(o)) return fail('order 只能是 random / pubdate / click。');
    patch.watchOrder = o;
  }
  if (args.seconds !== undefined && args.seconds !== null && args.seconds !== '') patch.watchSeconds = args.seconds;
  if (args.maxMinutes !== undefined && args.maxMinutes !== null && args.maxMinutes !== '') patch.watchMaxDurationMin = args.maxMinutes;
  if (typeof args.autoLike === 'boolean') patch.watchAutoLike = args.autoLike;
  if (typeof args.notify === 'boolean') patch.watchNotify = args.notify;
  if (typeof args.comment === 'boolean') patch.recommendCommentEnabled = args.comment;
  if (args.template !== undefined && args.template !== '') patch.recommendCommentTemplate = args.template;

  let atNote = '';
  if (args.atUser !== undefined && args.atUser !== null && String(args.atUser).trim() !== '') {
    const kw = String(args.atUser).trim();
    let auth = null;
    try { auth = await apiAuth(); } catch { /* 没登录就只能按数字 UID 处理 */ }
    const user = await findUserByKeyword(kw, auth).catch(() => null);
    if (!user) {
      if (/^\d{4,15}$/.test(kw)) { patch.recommendAtUid = kw; patch.recommendAtName = String(args.atName || ''); }
      else return fail(`没搜到「${kw}」这个 B 站用户。可以直接给 ta 的 UID（纯数字），或者先在设置里填 recommendAtUid。`);
    } else {
      patch.recommendAtUid = String(user.mid);
      patch.recommendAtName = String(args.atName || user.uname || '');
      atNote = `\n@ 目标：${user.uname || '（无昵称）'}（UID ${user.mid}）`;
      if (!patch.recommendAtName) atNote += '；建议同时给 atName（正文里要显示的名字），否则 @ 可能解析不出来';
    }
  } else if (args.atName !== undefined) {
    patch.recommendAtName = String(args.atName).trim();
  }

  if (!Object.keys(patch).length) return fail('没识别出要改哪项。可用：enabled/count/tags/order/seconds/autoLike/notify/comment/atUser/atName/template。峰谷时段开关只在技能设置页里，这里改不了。');
  savePlan(patch);
  return ok(`${planText(watchPlan(), '观看计划已更新')}${atNote}`);
}

function fmtClock(ms) {
  const d = new Date(Number(ms) + 8 * 3600 * 1000);
  return `${String(d.getUTCHours()).padStart(2, '0')}:${String(d.getUTCMinutes()).padStart(2, '0')}`;
}

function watchStatusTool() {
  const plan = watchPlan();
  const st = loadState();
  let timing;
  if (plan.peakValley) {
    const parts = plan.windows.map((w) => {
      const inst = windowInstance(w, Date.now());
      if (!inst) return `${w.key}（现在不在这个时段）`;
      if (st.watchSlots.includes(inst.key)) return `${w.key}（这一段已刷完）`;
      const target = Number(st.watchTargets[inst.key]) || 0;
      return target ? `${w.key}（进行中，约 ${fmtClock(target)} 开刷）` : `${w.key}（进行中，等待随机时刻）`;
    });
    timing = `时段：${parts.join('；')}`;
  } else {
    const nextAt = Number(st.watchTargets.auto) || 0;
    timing = st.watchCount >= plan.dailyCount
      ? '不限时段（今天的额度已经看完）'
      : nextAt && nextAt > Date.now()
        ? `不限时段（24 小时都可能刷，下一轮最早 ${fmtClock(nextAt)}）`
        : '不限时段（24 小时都可能刷，随时可能开下一轮）';
  }
  const recent = st.watched.slice(-6).reverse();
  const lines = [
    `今天：已看 ${st.watchCount}/${plan.dailyCount} 个`,
    `当前时间：${bjClock()}（北京时间）　${timing}`,
    `最近观看：${recent.length ? '' : '还没看过'}`,
    ...recent.map((w) => `· ${w.title}${w.commented ? '（已评论推荐）' : ''}`),
    state.watchRunning ? '状态：正在刷…' : '',
    `回执会话：${state.lastSender?.chatKey ? state.lastSender.chatKey : '还没有（机器人得先在目标会话里说过话才能主动汇报）'}`
  ].filter(Boolean);
  return ok(lines.join('\n'));
}

async function watchNowTool(ctx, args = {}) {
  if (state.watchRunning) return fail('上一轮还在刷，等它跑完。');
  const plan = watchPlan();
  if (!plan.enabled && args.force !== true) {
    return fail('观看计划是关着的。要临时刷一轮就传 force=true；要长期开启就用 bilibili-scroll__watch_plan 把 enabled 设为 true。');
  }
  state.watchRunning = true;
  try {
    const r = await withWatchLock(() => runWatchRound({
      trigger: 'manual',
      count: args.count,
      ctx,
      slot: ''
    }));
    if (r.skipped) return ok(r.skipped);
    if (r.error) return fail(r.error);
    return ok(watchSummaryText(r));
  } finally {
    state.watchRunning = false;
  }
}

// ── 人设工具的读写（bilibili-scroll__persona） ──────────────────────────────────────

/** data 下没有自定义人设时，先把出厂版复制过来 —— 之后所有修改都写这份（升级不覆盖）。 */
function ensureUserPersona() {
  ensureStoreDir();
  if (fs.existsSync(PERSONA_USER)) return PERSONA_USER;
  let base = '';
  try { base = fs.readFileSync(PERSONA_SHIPPED, 'utf8'); } catch { /* 出厂版丢了就现造一份 */ }
  if (!base.trim()) {
    base = '# B站回复人设\n\n## 句式库\n\n- 这条值得刷：{fact}\n- 值得刷，{fact}\n';
  }
  fs.writeFileSync(PERSONA_USER, base, { encoding: 'utf8', mode: 0o600 });
  return PERSONA_USER;
}

/** 往「## 句式库」那一节的末尾插一句（只动那一节，别把别的段落搅乱）。 */
function appendPersonaSentence(sentence) {
  const file = ensureUserPersona();
  const line = `- ${String(sentence).trim()}`;
  let raw = fs.readFileSync(file, 'utf8');
  const head = raw.match(/^##\s*句式库[^\n]*$/m);
  if (!head) {
    raw = `${raw.replace(/\s+$/, '')}\n\n## 句式库\n\n${line}\n`;
  } else {
    const start = head.index + head[0].length;
    const rest = raw.slice(start);
    const nextIdx = rest.search(/^##\s/m);
    const end = nextIdx === -1 ? raw.length : start + nextIdx;
    const section = raw.slice(start, end);
    // 紧跟在最后一条 `- ` 后面 —— 否则会跑到那一节末尾的说明文字下面，看着像没归类
    const lines = section.split('\n');
    let lastBullet = -1;
    lines.forEach((l, i) => { if (/^\s*[-*]\s+\S/.test(l)) lastBullet = i; });
    if (lastBullet >= 0) lines.splice(lastBullet + 1, 0, line);
    else lines.push('', line);
    const rebuilt = lines.join('\n').replace(/\n{3,}/g, '\n\n').replace(/\s+$/, '');
    raw = `${raw.slice(0, start)}\n\n${rebuilt.replace(/^\n+/, '')}\n\n${raw.slice(end)}`;
  }
  fs.writeFileSync(file, raw, { encoding: 'utf8', mode: 0o600 });
  return file;
}

function personaSummary(persona) {
  return `人设文件：${persona.file}\n可用句式：${persona.sentences.length} 句　兜底句：${persona.fallback}\n禁用词：${persona.banned.length ? persona.banned.join('、') : '没设'}`;
}

async function personaTool(args = {}) {
  const action = String(args.action || 'get').trim();

  if (action === 'get') {
    const p = loadPersona();
    const note = p.file === PERSONA_USER
      ? '（data 下的自定义版，优先于技能里的出厂版）'
      : '（技能自带的出厂版；想改得扛住升级，用 action=set 或 add_sentence，会写到 data/bilibili-scroll/persona.md）';
    return ok(`${personaSummary(p)}${note}\n\n---\n\n${p.raw || '（文件读不到或为空）'}`);
  }

  if (action === 'preview') {
    const plan = watchPlan();
    const info = {
      title: String(args.title || '').trim(),
      author: String(args.up || '').trim(),
      tag: String(args.tag || '').trim(),
      desc: String(args.desc || ''),
      duration: Number(args.duration) || 0,
      pubdate: Number(args.pubdate) || 0,
      stat: { view: Number(args.play) || 0, like: Number(args.like) || 0 },
      url: `https://www.bilibili.com/video/${String(args.bvid || 'BV1xx411c7mD')}`
    };
    if (!info.title) {
      const st = loadState();
      info.title = st.watched[st.watched.length - 1]?.title || '示例视频标题';
    }
    const at = String(args.at || plan.comment.atName || '').trim();
    const p = loadPersona();
    const draft = buildRecommendText({
      ...plan,
      comment: { ...plan.comment, atName: at }
    }, info).trim();
    const hitBanned = p.banned.filter((w) => draft.includes(w));
    return ok([
      '（只是预览，没有发出去）',
      '',
      draft,
      '',
      `—— 共 ${draft.length} 字（B站上限 1000）`,
      at ? `@ 的是：${at}` : '⚠️ 没设 @ 谁，这条评论不会带 @（设置页「艾特显示的名字」或 bilibili-scroll__watch_plan atUser）',
      hitBanned.length ? `⚠️ 含禁用词：${hitBanned.join('、')}（这在 persona.md 的「禁用词」里）` : '禁用词：无',
      `人设：${p.file}`
    ].join('\n'));
  }

  if (action === 'set') {
    const content = String(args.content ?? '').trim();
    if (!content) return fail('content 不能为空。要整体重写人设就传完整 markdown。');
    const parsed = parsePersona(content);
    ensureStoreDir();
    fs.writeFileSync(PERSONA_USER, `${content}\n`, { encoding: 'utf8', mode: 0o600 });
    const warnLine = parsed.sentences.length
      ? ''
      : '\n⚠️ 这份内容里没读到「## 句式库」（或那一节没有 `- ` 开头的句子），自动评论会用内置的 3 句默认句式。';
    return ok(`人设已写入 ${PERSONA_USER}（优先于技能里的出厂版，升级不会覆盖）。\n句式 ${parsed.sentences.length} 句　禁用词 ${parsed.banned.length} 个　立即生效，不用重启。${warnLine}`);
  }

  if (action === 'add_sentence') {
    const sentence = String(args.sentence ?? '').trim();
    if (!sentence) return fail('sentence 不能为空。比如「刷到就是赚到，{fact}」。');
    if (!/\{fact\}/.test(sentence)) {
      return fail('这句里没有 {fact} 占位符 —— 没有它，评论就说不出"为什么值得刷"。请把 {fact} 放进句子里再试。');
    }
    const file = appendPersonaSentence(sentence);
    const p = loadPersona();
    return ok(`已加进句式库：${sentence}\n文件：${file}\n现在共 ${p.sentences.length} 句，下一轮评论就可能用到。`);
  }

  return fail('action 只能是 get（看人设）/ preview（预演一条评论）/ set（整体重写）/ add_sentence（加一句句式）。');
}

// ── 生命周期 / 注册 ─────────────────────────────────────────────────────

export function setup(api) {
  if (typeof api?.config === 'function') cfg = api.config;
  if (typeof api?.log === 'function') log = api.log;
  if (typeof api?.warn === 'function') warn = api.warn;

  api.registerTool({
    id: 'login',
    name: '登录B站账号（扫码）',
    description: '生成 B 站扫码登录二维码并发到当前会话，然后自动等待扫码结果。当用户说“登录B站”“绑定B站账号”“扫码登录”时使用。已经在登录状态时默认直接返回当前账号；只有用户明确要换号才传 force=true。',
    category: 'system',
    icon: '🔐',
    parameters: {
      type: 'object',
      properties: {
        force: { type: 'boolean', description: '已经登录时是否强制重新扫码换号，默认 false。' }
      }
    },
    async execute(ctx, args) {
      try { return await loginStart(ctx, args?.force === true); }
      catch (e) { return fail(`登录失败：${errorWithCode(e)}`); }
    }
  });

  api.registerTool({
    id: 'login_check',
    name: '检查B站登录结果',
    description: '检查刚才的扫码登录结果，或查询当前 B 站账号登录状态。用户说“扫好了”“登录上了吗”“登录成功没”时使用。',
    category: 'system',
    icon: '✅',
    parameters: { type: 'object', properties: {} },
    async execute() {
      try { return await loginCheck(); }
      catch (e) { return fail(`检查登录失败：${errorWithCode(e)}`); }
    }
  });

  api.registerTool({
    id: 'logout',
    name: '退出B站账号（本机）',
    description: '清除本机保存的 B 站扫码登录态。只影响这个机器人，不会让 B 站网页端退出。用户说“退出B站”“解绑B站账号”时使用。',
    category: 'system',
    icon: '🚪',
    parameters: { type: 'object', properties: {} },
    async execute() {
      stopLoginPoll('logout');
      clearStoredSession();
      state.navCache = null;
      state.buvidCache = null;
      return ok('已清除本机保存的扫码登录态。如果技能设置里还填着手动 SESSDATA/bili_jct，那些仍然生效，需要去设置里清空。');
    }
  });

  api.registerTool({
    id: 'account',
    name: '查询B站账号状态',
    description: '查询当前 B 站账号是否登录、昵称、UID、等级、硬币、关注/粉丝数，以及本技能允许哪些操作和今天还剩多少额度。做任何写操作前先用它确认登录状态。',
    category: 'query',
    icon: '👤',
    parameters: { type: 'object', properties: {} },
    async execute() {
      try { return await accountSummary(); }
      catch (e) { return fail(`查询账号失败：${errorWithCode(e)}`); }
    }
  });

  api.registerTool({
    id: 'video_info',
    name: '查B站视频信息',
    description: '查一个 B 站视频的标题、UP 主、播放/点赞/投币/收藏数，以及当前账号是否赞过、投过、收藏过。当群友发 B 站链接、或你准备对某个视频操作前，先用它看清内容。参数 target 可以是链接、BV 号或 av 号。',
    category: 'query',
    icon: '🎬',
    parameters: {
      type: 'object',
      properties: {
        target: { type: 'string', description: 'B 站视频链接、BV 号（如 BV1xx411c7mD）或 av 号。' }
      },
      required: ['target']
    },
    async execute(_ctx, args) {
      try { return await videoInfoTool(args); }
      catch (e) { return fail(`查视频失败：${errorWithCode(e)}`); }
    }
  });

  api.registerTool({
    id: 'fav_folders',
    name: '查B站收藏夹',
    description: '列出当前 B 站账号的收藏夹（名称、id、是否默认、视频数）。收藏视频前如果用户指定了收藏夹，先用它查 id。',
    category: 'query',
    icon: '📁',
    parameters: { type: 'object', properties: {} },
    async execute() {
      try { return await favFoldersTool(); }
      catch (e) { return fail(`查收藏夹失败：${errorWithCode(e)}`); }
    }
  });

  api.registerTool({
    id: 'video_action',
    name: 'B站视频互动（赞/币/藏/三连）',
    description: '对 B 站视频点赞、取消点赞、投币、收藏、取消收藏或一键三连。当用户明确要求，或自动模式下看到群友分享的视频值得互动时使用。参数 target 是链接/BV 号；action 选 like/unlike/coin/favorite/unfavorite/triple；coinCount 1 或 2；favorite 可传 folderId。写操作受设置开关、每日限额和自动模式约束。',
    category: 'messaging',
    icon: '👍',
    parameters: {
      type: 'object',
      properties: {
        target: { type: 'string', description: 'B 站视频链接、BV 号或 av 号。' },
        action: { type: 'string', enum: ['like', 'unlike', 'coin', 'favorite', 'unfavorite', 'triple'], description: 'like=点赞，unlike=取消赞，coin=投币，favorite=收藏，unfavorite=取消收藏，triple=一键三连。' },
        coinCount: { type: 'integer', description: '投币数量，1 或 2，默认用设置里的值。' },
        folderId: { type: 'string', description: '收藏夹 id（可选）。不填就用默认收藏夹或设置里的收藏夹 id。' },
        confirm: { type: 'boolean', description: '只有用户在当前对话里明确同意这次操作时才传 true；自动模式 auto 下可忽略。' }
      },
      required: ['target', 'action']
    },
    async execute(ctx, args) {
      try { return await videoActionTool(ctx, args); }
      catch (e) { return fail(`视频操作失败：${errorWithCode(e)}`); }
    }
  });

  api.registerTool({
    id: 'follow',
    name: 'B站关注/取关UP主',
    description: '关注或取关一个 B 站 UP 主。当用户明确说“关注这个 UP”“取关他”，或自动模式下你判断值得关注时使用。参数 target 可以是 UP 主 UID（数字）、空间链接，或 ta 的视频链接；action 选 follow/unfollow。',
    category: 'messaging',
    icon: '➕',
    parameters: {
      type: 'object',
      properties: {
        target: { type: 'string', description: 'UP 主 UID、空间链接（space.bilibili.com/数字）或 ta 的视频链接/BV 号。' },
        action: { type: 'string', enum: ['follow', 'unfollow'], description: 'follow=关注，unfollow=取关。' },
        confirm: { type: 'boolean', description: '只有用户明确同意时才传 true；自动模式 auto 下可忽略。' }
      },
      required: ['target', 'action']
    },
    async execute(ctx, args) {
      try { return await followTool(ctx, args); }
      catch (e) { return fail(`关注操作失败：${errorWithCode(e)}`); }
    }
  });

  api.registerTool({
    id: 'comment',
    name: 'B站发评论',
    description: '在 B 站视频下以当前账号发评论或回复评论。只在用户明确要求、或高风险模式允许且内容确实合适时使用。参数 target 是视频链接/BV 号；message 是评论正文（≤1000 字）；replyTo 是要回复的评论 rpid（可选）。这是公开发言，默认需要用户确认。',
    category: 'messaging',
    icon: '💬',
    parameters: {
      type: 'object',
      properties: {
        target: { type: 'string', description: 'B 站视频链接、BV 号或 av 号。' },
        message: { type: 'string', description: '评论正文，最多 1000 字。' },
        replyTo: { type: 'string', description: '要回复的评论 rpid（可选）。' },
        root: { type: 'string', description: '根评论 rpid（回复二级评论时可选）。' },
        parent: { type: 'string', description: '父评论 rpid（回复二级评论时可选）。' },
        confirm: { type: 'boolean', description: '只有用户明确同意发这条评论时才传 true。' }
      },
      required: ['target', 'message']
    },
    async execute(ctx, args) {
      try { return await commentTool(ctx, args); }
      catch (e) { return fail(`发评论失败：${errorWithCode(e)}`); }
    }
  });

  api.registerTool({
    id: 'persona',
    name: 'B站回复人设（看/改/预演）',
    description: '机器人替主人在 B 站说话时的人设，放在技能的 persona.md 里。用户说“把回复人设改成…”“评论别用某某词”“加一句这样的评论”“看看现在什么语气”“先给我看看会发成什么样”时用它。action=get 看全文；preview 预演一条自动评论（不发）；set 整体重写；add_sentence 往句式库加一句（必须含 {fact} 占位符）。你把评论/回复文案写给人看时，也先 action=get 读一遍人设再写，别用默认腔调。',
    category: 'system',
    icon: '🎭',
    parameters: {
      type: 'object',
      properties: {
        action: { type: 'string', enum: ['get', 'preview', 'set', 'add_sentence'], description: 'get=读人设（默认）；preview=预演一条自动评论；set=整体重写人设；add_sentence=往句式库加一句。' },
        content: { type: 'string', description: 'action=set 时的完整 markdown 内容。' },
        sentence: { type: 'string', description: 'action=add_sentence 时的句式，必须含 {fact}，可用 {up} {title} {tag} {duration}。' },
        at: { type: 'string', description: 'preview 时临时假设要 @ 的名字（不传就用设置里的）。' },
        title: { type: 'string', description: 'preview 用的视频标题（不传就用最近看过的那条）。' },
        up: { type: 'string', description: 'preview 用的 UP 主名字。' },
        tag: { type: 'string', description: 'preview 用的视频 tag（逗号分隔）。' },
        desc: { type: 'string', description: 'preview 用的视频简介。' },
        play: { type: 'integer', description: 'preview 用的播放量。' },
        like: { type: 'integer', description: 'preview 用的点赞数。' },
        duration: { type: 'integer', description: 'preview 用的时长（秒）。' },
        bvid: { type: 'string', description: 'preview 用的 BV 号（只用来拼链接）。' }
      }
    },
    async execute(ctx, args) {
      try { return await personaTool(args || {}); }
      catch (e) { return fail(`人设操作失败：${e?.message ?? e}`); }
    }
  });

  api.registerTool({
    id: 'dynamic',
    name: 'B站发/删动态',
    description: '以当前账号发布纯文本 B 站动态，或删除自己的一条动态。只在用户明确要求、或高风险模式允许且内容确实合适时使用。action=post 时传 content；action=delete 时传 dynamicId。这是公开发言，默认需要用户确认。',
    category: 'messaging',
    icon: '📝',
    parameters: {
      type: 'object',
      properties: {
        action: { type: 'string', enum: ['post', 'delete'], description: 'post=发动态，delete=删动态。' },
        content: { type: 'string', description: '动态正文，最多 2000 字（action=post 时必填）。' },
        dynamicId: { type: 'string', description: '要删除的动态 id（action=delete 时必填）。' },
        confirm: { type: 'boolean', description: '只有用户明确同意时才传 true。' }
      },
      required: ['action']
    },
    async execute(ctx, args) {
      try { return await dynamicTool(ctx, args); }
      catch (e) { return fail(`动态操作失败：${errorWithCode(e)}`); }
    }
  });

  api.registerTool({
    id: 'watch_plan',
    name: '每日看视频计划（查/改）',
    description: '查询或修改「每天自动看视频」的计划：开关、每天看几个、看什么 tag、每个视频看多久、看完是否自动点赞、是否自动发评论并 @ 某人推荐视频。峰谷时段开关不在这里（在技能设置页），用户要切峰谷时让他去设置页点。用户说“每天帮我看 5 个原神的视频”“只在晚上刷”“全天都能刷”“看完评论并 @ 小明”时用它。不传 action 或 action=get 只查询。',
    category: 'messaging',
    icon: '📺',
    parameters: {
      type: 'object',
      properties: {
        action: { type: 'string', enum: ['get', 'set'], description: 'get=查询当前计划（默认），set=修改。' },
        enabled: { type: 'boolean', description: '是否开启每日自动观看。' },
        count: { type: 'integer', description: '每天看几个视频（1-50）。' },
        tags: { type: 'string', description: '想看什么：tag 或关键词，逗号分隔，如“原神,崩坏星穹铁道,猫meme”。留空字符串=用全站排行榜。' },
        order: { type: 'string', enum: ['random', 'pubdate', 'click'], description: '挑选顺序：random 随机 / pubdate 最新 / click 播放最多。' },
        seconds: { type: 'integer', description: '每个视频上报观看多少秒（10-600，默认 90）。' },
        maxMinutes: { type: 'integer', description: '超过多少分钟的视频跳过（默认 30）。' },
        autoLike: { type: 'boolean', description: '看完是否自动点赞（仍受“允许点赞”和写操作限额约束）。' },
        comment: { type: 'boolean', description: '本轮第一个视频看完后，是否自动发评论推荐并 @ 人。' },
        atUser: { type: 'string', description: '要 @ 的人：B 站 UID 或昵称（昵称会自动搜 mid）。' },
        atName: { type: 'string', description: '正文里显示的 @ 名字（可选，不乱码用）。' },
        template: { type: 'string', description: '评论模板，可用 {title} {url} {up} {duration} {at} 占位符。' },
        notify: { type: 'boolean', description: '定时刷完是否在会话里发一条回执。' }
      }
    },
    async execute(ctx, args) {
      try { rememberSender(ctx); return await watchPlanTool(args || {}); }
      catch (e) { return fail(`改观看计划失败：${errorWithCode(e)}`); }
    }
  });

  api.registerTool({
    id: 'watch_now',
    name: '立刻刷一轮视频',
    description: '马上按当前观看计划看一轮视频（不受时段限制，但仍受每日总量限制）。用户说“现在就看几个视频”“马上刷一轮”时用。计划关着时传 force=true 可以临时刷。',
    category: 'messaging',
    icon: '▶️',
    parameters: {
      type: 'object',
      properties: {
        count: { type: 'integer', description: '这一轮看几个（可选，默认按时段分段的数量）。' },
        force: { type: 'boolean', description: '计划没开启时也强行刷一轮。' }
      }
    },
    async execute(ctx, args) {
      try { rememberSender(ctx); return await watchNowTool(ctx, args || {}); }
      catch (e) { return fail(`刷视频失败：${errorWithCode(e)}`); }
    }
  });

  api.registerTool({
    id: 'watch_status',
    name: '看视频进度',
    description: '查询今天的观看进度（已看几个/计划几个）、已跑过的时段、下次什么时候、最近看过哪些视频。用户问“今天看了几个”“刷到哪了”“下次什么时候刷”时用。',
    category: 'query',
    icon: '📊',
    parameters: { type: 'object', properties: {} },
    async execute() {
      try { return watchStatusTool(); }
      catch (e) { return fail(`查观看进度失败：${errorWithCode(e)}`); }
    }
  });

  api.registerTool({
    id: 'find_user',
    name: '按昵称查B站用户',
    description: '按昵称搜索 B 站用户，拿到 mid（UID）。配置“评论里 @ 某人”但只有昵称时用它。参数 keyword 是昵称。',
    category: 'query',
    icon: '🔍',
    parameters: {
      type: 'object',
      properties: {
        keyword: { type: 'string', description: 'B 站昵称或 UID。' }
      },
      required: ['keyword']
    },
    async execute(_ctx, args) {
      const kw = String(args?.keyword ?? '').trim();
      if (!kw) return fail('缺少 keyword：请给 B 站昵称。');
      try {
        let auth = null;
        try { auth = await apiAuth(); } catch { /* 未登录也能搜，只是结果少 */ }
        const list = await searchUsers(fetch, { keyword: kw, cookie: auth?.cookie || '' });
        if (!list.length) return ok(`没搜到「${kw}」相关的 B 站用户。`);
        const lines = list.slice(0, 6).map((u, i) => `${i + 1}. ${u.uname}　UID ${u.mid}　粉丝 ${u.fans}`);
        return ok(`「${kw}」的搜索结果：\n${lines.join('\n')}`);
      } catch (e) {
        return fail(`搜用户失败：${errorWithCode(e)}`);
      }
    }
  });

  api.registerTool({
    id: 'comment_check',
    name: '复核评论是否公开可见',
    description: '检查自己最近发的推荐评论到底有没有公开显示。接口回“成功”不等于别人看得到——新号或触发风控时评论会进审核，@ 了也没人收到。用户问“评论发出去了吗”“对方能收到吗”时用。参数 limit 是查最近几条（默认 5）。',
    category: 'query',
    icon: '🔎',
    parameters: {
      type: 'object',
      properties: {
        limit: { type: 'number', description: '查最近几条评论，默认 5，最多 10。' }
      }
    },
    async execute(_ctx, args) {
      try {
        const limit = Math.max(1, Math.min(10, Math.round(Number(args?.limit) || 5)));
        const auth = await apiAuth();
        const st = loadState();
        const rows = (st.commentLog || []).slice(-limit).reverse();
        if (!rows.length) {
          return ok('还没有发过推荐评论，没什么可复核的。');
        }
        const lines = [];
        for (const r of rows) {
          if (!r.rpid) {
            lines.push(`· ${r.bvid} —— 当时没拿到 rpid，无法复核（可能还在审核）`);
            continue;
          }
          try {
            const v = await replyVisible(fetch, { aid: r.aid, rpid: r.rpid, cookie: auth.cookie });
            const when = new Date(r.at).toLocaleString('zh-CN', { hour12: false });
            lines.push(v.visible === true
              ? `· ${r.bvid}（${when}）—— 公开可见，赞 ${v.likes ?? 0}　依据：${v.how}`
              : `· ${r.bvid}（${when}）—— 没查到　依据：${v.how}；${v.note}`);
          } catch (e) {
            lines.push(`· ${r.bvid} —— 查询失败：${friendly(e)}`);
          }
          await sleep(700);
        }
        lines.push('', '「没查到」不等于没发出去：可能还在审核，也可能只是翻页看不到。');
        return ok(lines.join('\n'));
      } catch (e) {
        return fail(`复核评论失败：${errorWithCode(e)}`);
      }
    }
  });
}

export function available() {
  return true;
}

/**
 * 记下当前会话的发送通道。
 *
 * 定时任务到点时没有 ctx，而全站出站消息都必须走 SendQueue（ctx.sender）。
 * 模块层拿不到 sender 单例，所以只能在每次有会话时"顺手捡"一个引用存着 ——
 * 这样回执也经过限频与留档，不会变成绕过管道的野消息。
 * 代价是：机器人从没在任何会话里说过话时，回执发不出去（功能本身不受影响）。
 */
function rememberSender(ctx) {
  try {
    const key = String(ctx?.chatKey || '');
    if (!key || !ctx?.sender?.sendTextBatch) return;
    state.lastSender = { sender: ctx.sender, chatKey: key, at: Date.now() };
  } catch { /* 捡不到就算了，回执降级 */ }
}

export const hooks = {
  async 'after-response'(ctx = {}) {
    rememberSender(ctx);
  }
};

export async function activate() {
  startWatchTimer();
}

export async function deactivate() {
  stopWatchTimer();
  stopLoginPoll('deactivated');
}

export function dispose() {
  stopWatchTimer();
  stopLoginPoll('dispose');
}
