// 断箭单位查询（LLM 型 Skill）
//
// 数据来自玩家自建站 dash.batrace.top 的公开接口（无需登录）：
//   GET /api/dek/db-version                 当前数据库版本
//   GET /api/dek/units?country_id=…&ver=…   某国全部单位（轻量字段）
//   GET /api/dek/units/<id>?ver=…           单个单位 + 变体/改装选项
//   中文名没有独立接口，从 /units 页面里内嵌的 unitNames 字典里取（失败就只用英文名）。
//
// 只做查询与格式化；「鼓励/批评」两条评价由模型按提示词生成。

const BASE = 'https://dash.batrace.top';
const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36';

const state = { at: 0, versionId: '', units: null, names: {} };

async function getJson(path, timeoutMs = 15000) {
  const res = await fetch(BASE + path, {
    headers: { 'user-agent': UA, accept: 'application/json' },
    signal: AbortSignal.timeout(timeoutMs)
  });
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  return res.json();
}

/** 从 /units 页面里抠出中文名表：payload 里是被转义的 JSON 字符串。 */
async function fetchChineseNames(versionId) {
  try {
    const res = await fetch(`${BASE}/units?spec=12&ver=${encodeURIComponent(versionId)}`, {
      headers: { 'user-agent': UA },
      signal: AbortSignal.timeout(20000)
    });
    if (!res.ok) return {};
    const html = await res.text();
    const marker = '\\"unitNames\\":{';
    const i = html.indexOf(marker);
    if (i < 0) return {};
    const start = i + marker.length - 1;
    let depth = 0;
    let end = -1;
    for (let p = start; p < html.length; p++) {
      const c = html[p];
      if (c === '{') depth++;
      else if (c === '}') {
        depth--;
        if (depth === 0) { end = p; break; }
      }
    }
    if (end < 0) return {};
    const raw = html.slice(start, end + 1).replace(/\\"/g, '"').replace(/\\\\/g, '\\');
    return JSON.parse(raw);
  } catch {
    return {};
  }
}

async function ensureData(cacheMinutes) {
  const ttl = Math.max(1, Number(cacheMinutes) || 10) * 60000;
  if (state.units && Date.now() - state.at < ttl) return state;

  const v = await getJson('/api/dek/db-version');
  const versionId = String(v?.versionId || '');
  if (!versionId) throw new Error('没拿到单位数据库版本');

  const [ru, us] = await Promise.all([
    getJson(`/api/dek/units?country_id=1&ver=${encodeURIComponent(versionId)}`),
    getJson(`/api/dek/units?country_id=2&ver=${encodeURIComponent(versionId)}`)
  ]);
  const units = [
    ...(Array.isArray(ru?.units) ? ru.units : []).map((u) => ({ ...u, countryName: '俄罗斯' })),
    ...(Array.isArray(us?.units) ? us.units : []).map((u) => ({ ...u, countryName: '美国' }))
  ];
  const names = await fetchChineseNames(versionId);
  Object.assign(state, { at: Date.now(), versionId, units, names });
  return state;
}

function norm(s) {
  return String(s || '').toLowerCase().replace(/\s+/g, ' ').trim();
}

function scoreUnit(unit, names, query) {
  const zh = norm(names[String(unit.id)] || '');
  const fields = [norm(unit.name), norm(unit.hudName), zh].filter(Boolean);
  const q = norm(query);
  if (!q) return 0;
  let best = 0;
  for (const f of fields) {
    if (f === q) best = Math.max(best, 100);
    else if (f.startsWith(q) || f.includes(q)) best = Math.max(best, 70);
    else {
      const tokens = q.split(' ').filter(Boolean);
      if (tokens.length > 1 && tokens.every((t) => f.includes(t))) best = Math.max(best, 50);
    }
  }
  return best;
}

function countryId(name) {
  const s = norm(name);
  if (!s) return 0;
  if (['russia', 'ru', '俄', '俄罗斯', '苏', '苏联'].includes(s)) return 1;
  if (['usa', 'us', '美', '美国'].includes(s)) return 2;
  return 0;
}

async function getUnitDetail(id, versionId) {
  return getJson(`/api/dek/units/${id}?ver=${encodeURIComponent(versionId)}`);
}

function formatUnit(unit, zhName) {
  const en = unit.name || unit.hudName || `#${unit.id}`;
  const title = zhName ? `${zhName}（${en}）` : en;
  const bits = [`国家：${unit.countryName}`, `价格：${unit.cost ?? '未知'}`];
  if (unit.hudName && unit.hudName !== en) bits.push(`HUD 名：${unit.hudName}`);
  return `【${title}】${bits.join(' ｜ ')}`;
}

function optionLabel(option) {
  if (option?.replaceUnitName) return String(option.replaceUnitName);
  const ui = String(option?.uiName || '').replace(/^Custom_Option_/i, '').replace(/_/g, ' ').trim();
  if (ui) return ui;
  const name = String(option?.name || '').trim();
  return name || `#${option?.id}`;
}

function formatVariants(detail) {
  const mods = detail?.unit?.modifications;
  if (!Array.isArray(mods) || !mods.length) return '';
  const seen = new Set();
  const items = [];
  for (const mod of mods) {
    for (const option of Array.isArray(mod?.options) ? mod.options : []) {
      const label = optionLabel(option);
      const cost = Number(option?.cost);
      const text = Number.isFinite(cost) && cost !== 0 ? `${label}（${cost > 0 ? '+' : ''}${cost}）` : label;
      if (seen.has(text)) continue;
      seen.add(text);
      items.push(text);
    }
  }
  if (!items.length) return '';
  return `变体：${items.slice(0, 10).join(' / ')}`;
}

/** 查询入口（也导出给离线自测用）。 */
export async function queryUnits(query, { country = '', maxResults = 3, includeVariants = true, cacheMinutes = 10 } = {}) {
  const q = String(query || '').trim();
  if (!q) return '错误：请给出单位名或关键词。';

  const data = await ensureData(cacheMinutes);
  const cf = countryId(country);
  const pool = cf ? data.units.filter((u) => u.countryId === cf) : data.units;
  const scored = pool
    .map((u) => ({ unit: u, score: scoreUnit(u, data.names, q) }))
    .filter((x) => x.score > 0)
    .sort((a, b) => b.score - a.score || (Number(a.unit.cost) || 0) - (Number(b.unit.cost) || 0));

  if (!scored.length) {
    return `没找到和「${q}」匹配的单位。换个更短的关键词试试（比如只打「通古斯卡」），或者用英文名（Tunguska / T-90M）。`;
  }

  const limit = Math.max(1, Math.min(5, Number(maxResults) || 3));
  const top = scored.slice(0, limit);
  const out = [];
  for (const { unit } of top) {
    out.push(formatUnit(unit, data.names[String(unit.id)]));
    if (includeVariants) {
      try {
        const detail = await getUnitDetail(unit.id, data.versionId);
        const variants = formatVariants(detail);
        if (variants) out.push(variants);
      } catch { /* 变体拿不到不影响主结果 */ }
    }
  }
  if (scored.length > top.length) out.push(`（还有 ${scored.length - top.length} 个相近结果，关键词再具体一点能缩小范围）`);
  return out.join('\n\n');
}

export function register(api) {
  api.registerTool({
    id: 'lookup',
    name: '查断箭单位',
    description: '查询 Broken Arrow（断箭）的单位：支持中文名、英文名或关键词，返回国家、价格、可选变体等公开数据。',
    category: 'knowledge',
    icon: '🎯',
    parameters: {
      type: 'object',
      properties: {
        query: { type: 'string', description: '单位名或关键词，中英文都行（如 通古斯卡 / Tunguska / T-90M / 阿帕奇）' },
        country: { type: 'string', description: '可选：russia / usa，只在同名单位分属两国时用来收窄' },
        maxResults: { type: 'number', description: '最多返回几个匹配，默认 3，上限 5' }
      },
      required: ['query']
    },
    async execute(_ctx, args) {
      try {
        const cfg = api.config ? api.config() : {};
        if (cfg.enabled === false) return { content: '断箭单位查询已在设置里关闭。', isError: true };
        const text = await queryUnits(args?.query, {
          country: args?.country,
          maxResults: args?.maxResults ?? cfg.maxResults,
          includeVariants: cfg.includeVariants !== false,
          cacheMinutes: cfg.cacheMinutes
        });
        return { content: text };
      } catch (error) {
        return { content: `断箭单位查询失败：${error?.message ?? error}`, isError: true };
      }
    }
  });
}
