// MiMo 声音克隆（云端 · 小米 MiMo TTS）：用一段**本地录音**当音色样本，克隆出这个声音说话。
//
// 数据流：模型调用 mimo-voiceclone__say(text, style?)
//         → 读本地样本音频 → 转成 base64 DataURL
//         → POST {baseUrl}/chat/completions（model=mimo-v2.5-tts-voiceclone，audio.voice=DataURL）
//         → 拿到 base64 音频 → ctx.sender.sendMedia() 发一条 record 段 → QQ 里是一颗语音气泡。
// 接口文档：https://mimo.mi.com/docs/zh-CN/api/audio/tts
//
// ── 这个模型和「MiMo 语音说话」的区别（踩过坑，记下来）─────────────────
//   · 模型名必须是 mimo-v2.5-tts-voiceclone。
//   · audio.voice **必填**，且**必须是一个 DataURL**（`data:audio/mpeg;base64,...`）。
//     直接塞裸 base64 会被拒：`audio.voice must be a DataURL for voice clone model`。
//   · 只接受 mp3 / wav 两种样本格式；其它格式先自己转一下。
//   · 要念的文字仍然放在 role=assistant 的 content 里；role=user 可以放语气指令（实测 200 OK）。
//
// ── 音色从哪里来 ────────────────────────────────────────────────────────
//   样本文件路径 = 设置里的 sampleFile（相对技能目录，或绝对路径）。
//   默认 voice-sample.mp3（随技能附带一段示例）。换音色 = 换这个文件 / 改这个设置。
//   文件名按扩展名决定 MIME：.mp3 → audio/mpeg，.wav → audio/wav。
//
// ── 发送为什么走 ctx.sender.sendMedia ───────────────────────────────────
//   协议端会自己做 record 段的 silk 转码（snowluma 的 loadPtt → encodeSilk，自带 ffmpeg）。
//   直接调 onebot 发会跳过发送队列的限频/去重/留档，表现为"发着发着就发不出话"。

import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

let cfg = () => ({});
let log = () => {};
let apiFetch = null;

/** 技能目录（index.js 所在目录），用来解析相对路径的样本文件。 */
const SKILL_DIR = path.dirname(fileURLToPath(import.meta.url));

const DEFAULT_BASE = 'https://api.xiaomimimo.com/v1';
const MODEL = 'mimo-v2.5-tts-voiceclone';
const DEFAULT_SAMPLE = 'voice-sample.mp3';
/** 扩展名 → MIME。voiceclone 只支持这两种。 */
const SAMPLE_MIME = new Map([
  ['.mp3', 'audio/mpeg'],
  ['.wav', 'audio/wav']
]);

/** 样本 DataURL 的内存缓存：同一文件（路径+大小+修改时间不变）只读一次。 */
const sampleCache = { key: '', dataUrl: '' };

/**
 * 把设置里的样本路径解析成绝对路径。
 * 相对路径按**技能目录**解析（这样把录音丢进技能目录就能用）。
 */
export function resolveSamplePath(raw) {
  const value = String(raw || '').trim() || DEFAULT_SAMPLE;
  return path.isAbsolute(value) ? value : path.join(SKILL_DIR, value);
}

/**
 * 配置清洗（纯函数）。执行时调用，保证改了设置立刻生效。
 * @param {object} raw 技能设置
 */
export function readConfig(raw) {
  const c = raw && typeof raw === 'object' ? raw : {};
  const baseUrl = (String(c.baseUrl || '').trim() || DEFAULT_BASE).replace(/\/+$/, '');
  const apiKey = String(c.apiKey || '').trim();
  const samplePath = resolveSamplePath(c.sampleFile);
  const format = String(c.audioFormat || 'mp3').trim().toLowerCase() === 'wav' ? 'wav' : 'mp3';
  const maxChars = Math.min(1000, Math.max(20, Math.floor(Number(c.maxChars)) || 120));
  const timeoutMs = Math.min(300000, Math.max(5000, Math.floor(Number(c.timeoutMs)) || 60000));
  const maxSampleMB = Math.min(50, Math.max(1, Math.floor(Number(c.maxSampleMB)) || 20));
  return {
    baseUrl,
    apiKey,
    samplePath,
    format,
    maxChars,
    timeoutMs,
    maxSampleMB,
    alsoSendText: c.alsoSendText === true
  };
}

/**
 * 读样本文件并转成 DataURL。带体积/格式校验与内存缓存。
 * @returns {{ dataUrl: string, bytes: number, ext: string }}
 */
export function readSampleDataUrl(samplePath, maxSampleMB = 20) {
  const p = String(samplePath || '');
  if (!p) throw new Error('没有配置音色样本文件');
  let stat;
  try {
    stat = fs.statSync(p);
  } catch {
    throw new Error(`找不到音色样本文件：${p}。把 mp3/wav 放进技能目录，或把「音色样本文件」改成绝对路径`);
  }
  if (!stat.isFile()) throw new Error(`音色样本不是文件：${p}`);
  if (stat.size <= 0) throw new Error(`音色样本是空文件：${p}`);

  const ext = path.extname(p).toLowerCase();
  const mime = SAMPLE_MIME.get(ext);
  if (!mime) throw new Error(`音色样本只支持 mp3 / wav（当前：${ext || '无扩展名'}）。先把它转成 mp3 再试`);

  const limit = Math.max(1, Number(maxSampleMB) || 20) * 1024 * 1024;
  if (stat.size > limit) {
    throw new Error(`音色样本太大（${(stat.size / 1048576).toFixed(1)}MB，上限 ${maxSampleMB}MB）。截一段 5~30 秒的清晰人声就够了`);
  }

  const key = `${p}|${stat.size}|${stat.mtimeMs}`;
  if (sampleCache.key === key && sampleCache.dataUrl) {
    return { dataUrl: sampleCache.dataUrl, bytes: stat.size, ext };
  }

  const b64 = fs.readFileSync(p).toString('base64');
  const dataUrl = `data:${mime};base64,${b64}`;
  sampleCache.key = key;
  sampleCache.dataUrl = dataUrl;
  return { dataUrl, bytes: stat.size, ext };
}

/**
 * 把模型给的 text 洗成"适合念出来"的样子（去 markdown/表情/裸链接，换行变逗号）。
 * 和「MiMo 语音说话」同一套规则，保持一致的手感。
 */
export function normalizeSpeakText(input) {
  let s = String(input ?? '');
  s = s.replace(/```[\s\S]*?```/g, ' ');            // 代码块整段丢掉（念不了）
  s = s.replace(/`([^`]*)`/g, '$1');                // 行内代码保留内容
  s = s.replace(/!\[[^\]]*\]\([^)]*\)/g, ' ');      // 图片
  s = s.replace(/\[([^\]]*)\]\([^)]*\)/g, '$1');    // 链接保留文字
  s = s.replace(/https?:\/\/\S+/gi, '链接');         // 裸链接念出来很糟
  s = s.replace(/^\s{0,3}#{1,6}\s*/gm, '');         // 标题
  s = s.replace(/^\s{0,3}(?:[-*+]|\d+[.)])\s+/gm, ''); // 列表符号
  s = s.replace(/[*_~]{1,3}([^*_~]+)[*_~]{1,3}/g, '$1'); // 加粗/斜体/删除线
  s = s.replace(/[*_~#>|]/g, ' ');                  // 残留符号
  s = s.replace(/[\r\n]+/g, '，');                   // 换行 → 逗号停顿
  s = s.replace(/[ \t\u3000]+/g, ' ');
  s = s.replace(/，{2,}/g, '，').replace(/^[，、\s]+|[，、\s]+$/g, '');
  return s.trim();
}

/** 响应体压成一行短摘要（别把整页 HTML 灌进日志）。 */
function snippet(text, max = 200) {
  const s = String(text ?? '').replace(/\s+/g, ' ').trim();
  return s.length > max ? `${s.slice(0, max)}…` : s;
}

/** HTTP 状态码 → 能直接照做的提示。 */
function httpHint(status) {
  if (status === 401 || status === 403) return '（API Key 不对或没权限：确认 apiKey 与「接口地址」是同一家的）';
  if (status === 404) return '（接口地址不对，或该地址不提供音频模型：改回 https://api.xiaomimimo.com/v1）';
  if (status === 429) return '（调用太频繁，或额度/余额用尽）';
  if (status === 400) return '（参数被拒：voiceclone 的 audio.voice 必须是 DataURL，样本只能是 mp3/wav）';
  if (status >= 500) return '（MiMo 服务端异常，稍后自己会好）';
  return '';
}

/** 短指纹：给发送队列做去重键，避免同一句话在去重窗口内被念两遍。 */
function fingerprint(text) {
  let h = 0x811c9dc5;
  const s = String(text);
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = (h + ((h << 1) + (h << 4) + (h << 7) + (h << 8) + (h << 24))) >>> 0;
  }
  return h.toString(16);
}

/**
 * 合成一段克隆语音。返回 { audioB64, spoken, text }。
 * @param {object} args { text, style }
 * @param {object} deps { fetchImpl }（自检时注入假 fetch）
 */
export async function synthesize({ text, style } = {}, { fetchImpl } = {}) {
  const c = readConfig(cfg());
  if (!c.apiKey) throw new Error('还没填 MiMo API Key（技能设置 → apiKey）');

  const spoken = normalizeSpeakText(text);
  if (!spoken) throw new Error('要说的内容是空的（去掉表情/markdown 之后什么都没剩下）');
  if (spoken.length > c.maxChars) {
    throw new Error(`这句话太长（${spoken.length} 字，上限 ${c.maxChars} 字）。拆成几条短句分别调用，或改用打字回复`);
  }

  const doFetch = fetchImpl || apiFetch;
  if (typeof doFetch !== 'function') throw new Error('缺少 fetch（清单里需要声明 web_fetch 权限）');

  // 样本 → DataURL（voiceclone 只认 DataURL，裸 base64 会被 400 拒掉）
  const { dataUrl } = readSampleDataUrl(c.samplePath, c.maxSampleMB);

  // 要念的文字必须在 assistant；user 只放这一句的语气微调（实测 voiceclone 接受）
  const messages = [];
  const extra = String(style || '').trim();
  if (extra) messages.push({ role: 'user', content: `这一句的语气：${extra}` });
  messages.push({ role: 'assistant', content: spoken });

  const res = await doFetch(`${c.baseUrl}/chat/completions`, {
    method: 'POST',
    headers: { 'api-key': c.apiKey, 'Content-Type': 'application/json' },
    body: JSON.stringify({
      model: MODEL,
      messages,
      audio: { format: c.format, voice: dataUrl },
      stream: false
    }),
    signal: AbortSignal.timeout(c.timeoutMs)
  });

  const body = await res.text();
  if (!res.ok) throw new Error(`MiMo 返回 HTTP ${res.status}${httpHint(res.status)}：${snippet(body)}`);

  let data = null;
  try { data = JSON.parse(body); } catch { throw new Error(`MiMo 返回的不是 JSON：${snippet(body)}`); }
  if (data?.error) {
    const e = data.error;
    const msg = typeof e === 'string' ? e : (e.message || e.code || JSON.stringify(e));
    throw new Error(`MiMo 报错：${snippet(msg)}${String(msg).includes('DataURL') ? '（audio.voice 必须是 data:audio/mpeg;base64,... 形式）' : ''}`);
  }

  const msg = data?.choices?.[0]?.message;
  const b64 = String(msg?.audio?.data || '').trim();
  if (!b64) throw new Error(`没拿到音频数据${snippet(body, 120) ? `（原始响应：${snippet(body, 120)}）` : ''}`);

  log(`声音克隆合成完成：${spoken.length} 字，格式 ${c.format}，样本=${path.basename(c.samplePath)}`);
  return { audioB64: b64, spoken, text: spoken };
}

// ── 技能生命周期 ──────────────────────────────────────────────────────────

export function setup(api) {
  cfg = api.config;
  log = api.log || (() => {});
  apiFetch = api.fetch;

  api.registerTool({
    id: 'say',
    name: '用克隆的声音说话',
    category: 'media',
    icon: '🎙️',
    description: '用一段录音克隆出来的音色，把一句话说成真正的QQ语音消息（不是文字）。只在用户明确要你用语音、点名要「我的声音/这个音色」说话、要念一段东西，或语音明显比文字更合适时用。一次只适合一两句短话；发完不要再把同一句话用文字发一遍。',
    parameters: {
      type: 'object',
      additionalProperties: false,
      properties: {
        text: {
          type: 'string',
          description: '要说出口的话。会被逐字念出来，所以别写表情符号、markdown、括号里的动作描写；一两句、60 字内最好。'
        },
        style: {
          type: 'string',
          description: '可选：只针对这一句的语气微调，自然语言。例如「压低声音，装正经」「带点笑意，语速更快」。不填就用样本本身的语气。'
        },
        replyToMessageId: {
          type: ['integer', 'string'],
          description: '可选：要引用/回复的消息 id（聊天记录里每条消息前的 #数字）'
        }
      },
      required: ['text']
    },
    async execute(ctx, args) {
      try {
        if (!ctx?.chatKey) return { content: '错误：当前环境没有会话上下文，无法发语音', isError: true };
        if (typeof ctx.sender?.sendMedia !== 'function') {
          return { content: '错误：当前环境缺少发送接口（sender.sendMedia），语音没发出去', isError: true };
        }

        const { audioB64, spoken } = await synthesize({ text: args?.text, style: args?.style });

        await ctx.sender.sendMedia(ctx.chatKey, [{ type: 'record', data: { file: `base64://${audioB64}` } }], {
          label: `[语音]${spoken.slice(0, 30)}`,
          dedupeKey: `voiceclone:${fingerprint(spoken)}`,
          replyToMessageId: args?.replyToMessageId ?? null
        });

        if (readConfig(cfg()).alsoSendText) {
          try { await ctx.sender.sendTextBatch(ctx.chatKey, [spoken], {}); }
          catch (error) { log(`语音已发出，但补发的文字失败：${error?.message ?? error}`); }
        }

        // 会话页留痕（与内置发图/发表情工具同一口径）；失败不影响主流程
        try {
          ctx.session?.sent?.push({
            type: 'voice',
            text: `[语音]${spoken.slice(0, 40)}`,
            at: new Date().toLocaleTimeString('zh-CN', { hour12: false })
          });
          ctx.emit?.('session-update', ctx.session?.id);
        } catch { /* 留痕失败不影响这条语音已经发出去的事实 */ }

        return {
          content: `已用克隆的声音说出：「${spoken}」。这条语音已经直接发到会话里了——不要再把同一句话用文字发一遍，也不要向用户汇报"已发送"。`
        };
      } catch (error) {
        const msg = String(error?.message ?? error);
        log(`克隆语音失败：${msg}`);
        return { content: `语音发送失败：${msg}。可以改用文字回复，不要立刻重复调用本工具。`, isError: true };
      }
    }
  });

  const c = readConfig(cfg());
  log(`MiMo 声音克隆已注册（样本=${c.samplePath}，输出=${c.format}）`);
}

/**
 * 自检：必须同步返回（返回 Promise 会被当成"可用"）。
 * 只做本地校验（配置 + 样本文件是否存在/是否可读），不发网络请求。
 */
export function available() {
  let c;
  try { c = readConfig(cfg()); } catch (error) { return { ok: false, reason: `配置读不出来：${error?.message ?? error}` }; }
  if (!c.apiKey) return { ok: false, reason: '还没填 MiMo API Key（设置里的 apiKey）' };
  if (!/^https?:\/\//i.test(c.baseUrl)) return { ok: false, reason: `接口地址要以 http(s):// 开头（当前：${c.baseUrl}）` };
  try {
    const stat = fs.statSync(c.samplePath);
    if (!stat.isFile() || stat.size <= 0) return { ok: false, reason: `音色样本不可用：${c.samplePath}` };
  } catch {
    return { ok: false, reason: `找不到音色样本文件：${c.samplePath}（放进技能目录，或改成绝对路径）` };
  }
  return { ok: true };
}

export const internals = { synthesize, readConfig, resolveSamplePath, readSampleDataUrl, normalizeSpeakText, fingerprint };
