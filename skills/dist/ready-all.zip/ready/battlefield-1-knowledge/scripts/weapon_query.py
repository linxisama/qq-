#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""战地风云1 武器数据快速检索工具。

用法:
    python weapon_query.py                # 列出全部条目
    python weapon_query.py M1916          # 关键词检索
    python weapon_query.py 致死距离        # 检索含该词的行
    python weapon_query.py --class scout  # 列出某兵种段落
    python weapon_query.py --list-classes # 列出可用兵种

仅依赖标准库，无需安装第三方包。
"""

import argparse
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
REF_DIR = os.path.join(os.path.dirname(HERE), "references")
WEAPONS_MD = os.path.join(REF_DIR, "weapons.md")

CLASS_KEYWORDS = {
    "assault": ["突击兵"],
    "medic": ["医疗兵"],
    "support": ["支援兵"],
    "scout": ["侦察兵"],
    "sidearm": ["手枪", "配枪"],
    "elite": ["精英兵"],
}


def read_lines():
    if not os.path.isfile(WEAPONS_MD):
        sys.stderr.write("找不到数据文件: %s\n" % WEAPONS_MD)
        sys.exit(1)
    with open(WEAPONS_MD, encoding="utf-8") as fh:
        return fh.read().splitlines()


def is_table_row(line):
    s = line.strip()
    return s.startswith("|") and s.endswith("|") and "---" not in s


def section_of(lines):
    """Return list of (heading, [rows]) preserving order."""
    sections = []
    current = ("(前言)", [])
    for line in lines:
        if line.startswith("#"):
            sections.append(current)
            current = (line.lstrip("#").strip(), [])
        else:
            current[1].append(line)
    sections.append(current)
    return sections


def cmd_list_classes():
    print("可用兵种/类别关键词:")
    for key, words in sorted(CLASS_KEYWORDS.items()):
        print("  %-8s -> %s" % (key, " / ".join(words)))


def cmd_class(name):
    key = name.lower()
    if key not in CLASS_KEYWORDS:
        sys.stderr.write("未知兵种: %s (用 --list-classes 查看)\n" % name)
        sys.exit(2)
    words = CLASS_KEYWORDS[key]
    sections = section_of(read_lines())
    hit = False
    for head, body in sections:
        if any(w in head for w in words):
            hit = True
            print("## %s" % head)
            for row in body:
                if is_table_row(row) or row.strip() == "":
                    print(row)
                else:
                    print(row)
            print()
    if not hit:
        print("该兵种暂无独立段落，尝试关键词检索。")


def cmd_search(keyword):
    lines = read_lines()
    pat = re.compile(re.escape(keyword), re.IGNORECASE)
    head = "(前言)"
    found = 0
    for line in lines:
        if line.startswith("#"):
            head = line.lstrip("#").strip()
        if pat.search(line):
            found += 1
            print("[%s] %s" % (head, line.strip()))
    if not found:
        print("未找到与 %r 匹配的内容。" % keyword)
    else:
        print("\n共 %d 条匹配。" % found)


def cmd_dump():
    for line in read_lines():
        print(line)


def main():
    ap = argparse.ArgumentParser(
        description="战地风云1 武器数据检索", add_help=True)
    ap.add_argument("keyword", nargs="?", help="检索关键词")
    ap.add_argument("--class", dest="cls", help="按兵种列出")
    ap.add_argument("--list-classes", action="store_true", help="列出可用兵种")
    ap.add_argument("--all", action="store_true", help="输出完整数据表")
    args = ap.parse_args()

    if args.list_classes:
        cmd_list_classes()
    elif args.cls:
        cmd_class(args.cls)
    elif args.all:
        cmd_dump()
    elif args.keyword:
        cmd_search(args.keyword)
    else:
        cmd_dump()


if __name__ == "__main__":
    main()
