# 数据来源 (Sources)

本知识库数据整理自公开的游戏资料站、玩家社区与官方说明。数值以 **BF1 最终平衡版本**为基准。

## 中文来源

| 来源 | 内容 | 链接 |
| --- | --- | --- |
| 萌娘百科 | 《战地风云 1》条目（地图总表、行动战役、模式规则、载具列表、精英兵） | https://moegirl.icu/zh-mo/%E6%88%98%E5%9C%B0%E9%A3%8E%E4%BA%91_1 |
| 九游 | 战地1全载具详解及兵种武器推荐 | https://www.9game.cn/news/1233265.html |
| 九游 | 战地1空中载具介绍及使用心得 | https://www.9game.cn/news/1339593.html |
| 九游 | 战地风云1战争巨兽怎么打 | https://www.9game.cn/news/10013160.html |
| 九游 | 战地1 DLC加入4张新地图、新模式 | https://www.9game.cn/news/1964322.html |
| 九游 | 战地1誓死坚守DLC新情报 | https://www.9game.cn/news/1556580.html |
| 3DM | 战地1征服模式新手玩法（计分规则） | https://www.3dmgame.com/gl/3613198_2.html |
| 3DM | 战地1副武器及近战武器伤害判定分析 | https://www.3dmgame.com/gl/3604785.html |
| 3DM | 战地1进攻坦克圣沙蒙新手怎么玩 | https://www.3dmgame.com/gl/3833589.html |
| 游民星空 | 战地1征服模式据点位置与打法技巧 | https://www.gamersky.com/handbook/201612/842652_2.shtml |
| 游侠网 | 战地1多人模式载具使用指南（变体官方译名、飞艇、无畏舰） | https://3g.ali213.net/gl/html/143943_8.html |
| 游侠网 | 战地1近战武器属性及伤害解析 | https://gl.ali213.net/html/2016-10/138673.html |
| 锐派 replays.net | 《战地1》枪械武器数据分析（变体词缀释义，转 Symthic） | http://www.replays.net/mip/guides/201709/78539.html |
| 电玩帮 | 战地1新手向武器推荐（霰弹枪机制） | https://www.vgover.com/news/7581 |
| 雷神加速器 | 战地1支援兵用什么武器 | https://www.leigod.com/news/59817.html |
| 雷神加速器 | 战地1中的医疗兵使用什么武器 | https://www.leigod.com/news/59818.html |
| 新浪电竞 | 《战地1》九张地图及六种游戏模式详情公布 | http://dj.sina.com.cn/article/fxvykwk5334577.shtml |

## 官方与英文来源

| 来源 | 内容 | 链接 |
| --- | --- | --- |
| EA 官方 | Break Through Enemy Lines with Elite Classes in Battlefield 1 | https://www.ea.com/en-gb/games/battlefield/news/battlefield-1-elite-classes |
| EA 官方 | Introducing Specializations in Battlefield 1（战地升级完整列表） | https://www.ea.com/en-gb/games/battlefield/news/introducing-specializations-in-battlefield-1 |
| EA 官方 | 准备迎接 Battlefield 1：启示录（5 张地图） | https://www.ea.com/zh-tw/games/battlefield/news/battlefield-1-apocalypse-coming-february |
| EA 官方 | 前线模式：所有须知事项 | https://www.ea.com/zh-tw/games/battlefield/news/frontlines-mode-all-you-need-to-know |
| EA 官方 | Join the Ranks with Battlefield 1 Revolution | https://www.ea.com/games/battlefield/news/battlefield-1-revolution-available-now |
| Battlefield 1 Wiki (日文) | 载具座位/武器/弹药精确表格 | https://bf1.swiki.jp/ |
| Eurogamer | Battlefield 1 Elite Classes | https://www.eurogamer.net/battlefield-1-elite-classes-flame-trooper-sentry-and-tank-hunter-pickups-loadouts-and-more-4790 |
| Eurogamer | Battlefield 1 Maps, Behemoths, Vehicles, Modes | https://www.eurogamer.net/battlefield-1-maps-behemoths-vehicles-modes-4790 |
| Eurogamer | DICE reveals Battlefield 1 launch maps and modes | https://www.eurogamer.net/dice-reveals-battlefield-1-launch-maps-and-modes |
| Gamereactor | Battlefield 1: Turning Tides' launch plans confirmed | https://www.gamereactor.eu/battlefield-1-turning-tides-launch-plans-confirmed/ |
| OC3D | EA is giving away Battlefield 1's Premium Pass for free | https://overclock3d.net/news/software/ea-is-giving-away-battlefield-1s-premium-pass-for-free-for-a-limited-time/ |

## 技能包格式规范来源

| 来源 | 内容 | 链接 |
| --- | --- | --- |
| 腾讯云官方文档 | 腾讯云智能体开发平台 — Skills 文件规范 | https://cloud.tencent.com/document/product/1759/134602 |
| Agent Skills 规范讨论 | Add skill.json as optional package-level metadata file | https://github.com/agentskills/agentskills/discussions/214 |
| OpenClaw 文档 | Skill 格式说明 | https://docs.openclaw.ai/es/clawhub/skill-format |
| QQ-agent 项目 | skill-development.md 技能开发文档 | https://github.com/K0nd1us/QQ-agent/blob/main/doc/extend_development/skill-development.md |

---

## 数据可信度说明

- **来源冲突时**：本知识库在正文中**并列列出相互冲突的数值**，而非择一断言。已知冲突项包括：
  - **Gewehr 98 致死距离**：3DM（2016-10）给 **80–118m**；九游（2024-06）给 **80–125m**。疑似平衡补丁改动。
  - **lMG 08/18 过热量**：一说 31 发，一说 30 发。
  - **精英兵折算血量**：萌娘百科给出的「83% 减伤 ≈ 600 血」为**社区折算值**，非官方数据。
- **未收录项**：莫辛-纳甘、勒贝尔 M1886、卡尔卡诺 M91、维塔利、春田实验型的致死距离，以及 RSC 1917、RSC SMG、Chauchat 的具体数值，均**未取得可靠来源**，正文中已明确标注「未收录」，**不提供推测值**。
- **伤害数值精度**：手枪与主武器的具体数值来自站点级汇总文章，**原始数据多转引自 Symthic**；本知识库无法逐值溯源到官方文件。
- **版本漂移**：BF1 经历多次平衡补丁，不同时期资料可能相差 ±1~2 点伤害或小幅射速调整。
- **不列出的内容**：载具具体 HP 数值，因公开来源之间冲突严重且随版本调整。

> 所有来源均为公开资料，仅用于游戏理解与教学目的。游戏名称、武器名称与相关商标归 EA / DICE 所有。
