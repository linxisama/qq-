// 战地风云1 知识库 —— QQ Agent Skill 入口
//
// 本 Skill 是「知识型」：不改写核心行为，只做两件事：
//   1. 通过 manifest.prompt.sections 注入方法论提示词（声明在 skill.json）
//   2. 提供一个检索工具，让模型能精确查到武器数值，避免凭记忆作答
//
// 入口约定（依据 src/plugin-loader.js 与 src/tool-registry.js 实现）：
//   · 默认入口 index.js，可被 skill.json 的 "entry" 覆盖
//   · 必须导出 setup(api) / register(api) / hooks / providers / activate 之一
//   · api.registerTool(def) 的 def 必填：id、name、execute(ctx, args)
//     - id 会成为 OpenAI function name，字符集 [a-zA-Z0-9_-]{1,64}
//     - execute 返回 { content, isError }；content 为字符串或 parts 数组

import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const REF_DIR = path.join(HERE, 'references');

/** 读取知识库某个参考文件；文件名白名单校验，禁止路径穿越。 */
function readReference(name) {
  const safe = String(name || '').trim();
  if (!/^[a-z0-9_-]+(\.md)?$/i.test(safe)) {
    return { ok: false, error: '文件名不合法，只允许 references/ 下的简单文件名' };
  }
  const file = safe.endsWith('.md') ? safe : `${safe}.md`;
  const full = path.join(REF_DIR, file);
  // 二次防线：解析后必须仍在 references/ 内
  const rel = path.relative(REF_DIR, full);
  if (rel.startsWith('..') || path.isAbsolute(rel)) {
    return { ok: false, error: '路径越界' };
  }
  if (!fs.existsSync(full)) {
    return { ok: false, error: `参考文件不存在：${file}`, available: listReferences() };
  }
  return { ok: true, file, content: fs.readFileSync(full, 'utf8') };
}

/** 列出全部参考文件。 */
function listReferences() {
  if (!fs.existsSync(REF_DIR)) return [];
  return fs.readdirSync(REF_DIR)
    .filter((n) => n.toLowerCase().endsWith('.md'))
    .sort();
}

const FILE_GUIDE = {
  weapons: '武器数值（伤害/射速/弹速/致死距离/弹容）、配枪、变体词缀',
  classes: '兵种职责、精英兵种、小队、战地升级、解锁机制',
  vehicles: '坦克/装甲车/飞机/舰船/机械巨兽的座位、武器、变体与战术',
  'maps-modes': '31 张地图、10 种模式、计分规则、常见错误译名更正',
  tactics: '高级战术、兵种协同、常见误区、术语表',
  sources: '全部数据来源、冲突说明与可信度分级'
};

/** 把结果序列化成给模型看的文本。 */
function render(payload) {
  return JSON.stringify(payload, null, 2);
}

/** 工具定义。id 只用 [a-zA-Z0-9_-]，注册时会被自动加 skillId 前缀。 */
const TOOL = {
  id: 'bf1_lookup',
  name: '战地1知识库检索',
  category: 'query',
  icon: '🎖️',
  defaultEnabled: true,
  description:
    '检索《战地风云1》(Battlefield 1) 专业知识库。'
    + '可读取某个参考文件全文，或按关键词在参考文件中搜索并返回命中行。'
    + '凡涉及武器数值（伤害/射速/弹速/致死距离/弹容）、兵种配装、精英兵、'
    + '载具变体、地图与游戏模式规则的问题，都应先调用本工具取回真实数据，'
    + '不要凭记忆作答。',
  parameters: {
    type: 'object',
    properties: {
      file: {
        type: 'string',
        enum: ['weapons', 'classes', 'vehicles', 'maps-modes', 'tactics', 'sources'],
        description: '要读取的参考文件。省略则返回文件清单与说明。'
      },
      query: {
        type: 'string',
        description:
          '关键词。给定后在指定文件（未指定则全部文件）中搜索，'
          + '返回命中的原文行而非整篇内容，适合精确定位某把枪或某个数值。'
      },
      maxLines: {
        type: 'number',
        description: '搜索时最多返回的命中行数，默认 40，上限 200。'
      }
    },
    required: []
  },
  async execute(_ctx, args = {}) {
    try {
      const { file, query, maxLines } = args || {};

      // 无参数：返回清单，让模型知道能查什么
      if (!file && !query) {
        return {
          content: render({
            ok: true,
            references: listReferences().map((f) => ({
              file: f.replace(/\.md$/, ''),
              about: FILE_GUIDE[f.replace(/\.md$/, '')] || ''
            })),
            hint: '传入 file 读取全文，或传入 query 做关键词检索。'
          })
        };
      }

      const files = file ? [file] : listReferences();

      // 纯读取
      if (!query) {
        const r = readReference(files[0]);
        if (!r.ok) return { content: render(r), isError: true };
        return {
          content: render({
            ok: true,
            file: r.file,
            bytes: r.content.length,
            content: r.content
          })
        };
      }

      // 关键词检索：返回命中行（带文件名与行号），避免整篇塞进上下文
      const limit = Math.min(200, Math.max(1, Number(maxLines) || 40));
      const needle = String(query).toLowerCase();
      const hits = [];
      const scanned = [];

      for (const f of files) {
        const r = readReference(f);
        if (!r.ok) continue;
        scanned.push(r.file);
        const lines = r.content.split(/\r?\n/);
        for (let i = 0; i < lines.length; i++) {
          if (lines[i].toLowerCase().includes(needle)) {
            hits.push({ file: r.file, line: i + 1, text: lines[i].trim() });
            if (hits.length >= limit) break;
          }
        }
        if (hits.length >= limit) break;
      }

      return {
        content: render({
          ok: true,
          query: String(query),
          scanned,
          hitCount: hits.length,
          truncated: hits.length >= limit,
          hits,
          ...(hits.length ? {} : {
            hint: '未命中。可换用英文名、简称（如 M1916 / 致死距离），'
              + '或不带 query 读取整份文件。'
          })
        })
      };
    } catch (error) {
      return {
        content: `战地1知识库检索失败：${error?.message ?? error}`,
        isError: true
      };
    }
  }
};

/** 新入口。 */
export async function setup(api) {
  api.registerTool(TOOL);
  api.log?.(`[bf1] 已注册工具 ${TOOL.id}，参考文件 ${listReferences().length} 个`);
}

/** 兼容旧插件入口名。 */
export const register = setup;
