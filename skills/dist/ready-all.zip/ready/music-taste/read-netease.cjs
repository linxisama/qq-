'use strict';
/**
 * 读取本机网易云「我喜欢的音乐」歌单，输出 JSON 到 stdout。
 * 由 skills/music-taste/index.js 用 app 自带的 node.exe（snowluma/node.exe，v22，
 * 自带 node:sqlite）作为子进程调用 —— 因为 QQ Agent 的 Electron 内置 Node 没有 node:sqlite。
 *
 * 输出格式（一行 JSON）：
 *   { "playlistName": "...", "songs": [{"name","artist","album"}, ...] }
 *   或 { "error": "..." }
 */

const { DatabaseSync } = require('node:sqlite');
const fs = require('node:fs');
const path = require('node:path');

function findDb() {
  const cands = [];
  if (process.env.LOCALAPPDATA) {
    cands.push(path.join(process.env.LOCALAPPDATA, 'Netease', 'CloudMusic', 'Library', 'webdb.dat'));
  }
  for (const root of ['D:', 'C:']) {
    cands.push(path.join(root, 'Program Files (x86)', 'Netease', 'CloudMusic', 'Library', 'webdb.dat'));
    cands.push(path.join(root, 'Program Files', 'Netease', 'CloudMusic', 'Library', 'webdb.dat'));
  }
  for (const c of cands) if (fs.existsSync(c)) return c;
  return null;
}

function emit(obj) {
  process.stdout.write(JSON.stringify(obj));
}

function main() {
  const dbPath = findDb();
  if (!dbPath) { emit({ error: '未找到网易云音乐数据库（Library/webdb.dat）。请确认已安装网易云客户端并至少登录运行过一次。' }); return; }

  let db;
  try { db = new DatabaseSync(dbPath, { readOnly: true }); }
  catch (e) { emit({ error: '打开网易云数据库失败：' + e.message }); return; }

  try {
    let pid = null;
    for (const row of db.prepare('SELECT jsonStr FROM persistentModel').all()) {
      const s = row.jsonStr;
      if (!s || !s.includes('starPlaylistId')) continue;
      try {
        const d = JSON.parse(s);
        pid = d && d.data && d.data.starPlaylistId;
        if (pid) { pid = String(pid); break; }
      } catch { /* 忽略解析失败的行 */ }
    }
    if (!pid) { emit({ error: '未能在网易云数据中找到「我喜欢的音乐」歌单 ID。' }); return; }

    let name = '我喜欢的音乐';
    const nr = db.prepare('SELECT jsonStr FROM historyPlaylists WHERE id=?').get(pid);
    if (nr) { try { name = JSON.parse(nr.jsonStr).name || name; } catch { /* 用默认名 */ } }

    const tr = db.prepare('SELECT jsonStr FROM playlistTrackIds WHERE id=?').get(pid);
    if (!tr) { emit({ error: '未找到歌单的歌曲列表（playlistTrackIds）。' }); return; }
    let ids = [];
    try {
      ids = (JSON.parse(tr.jsonStr).trackIds || []).map((t) => String(t.id));
    } catch (e) { emit({ error: '解析歌单歌曲列表失败：' + e.message }); return; }

    const songs = [];
    const seen = new Set();
    for (const tid of ids) {
      const rr = db.prepare('SELECT jsonStr FROM dbTrack WHERE id=?').get(tid);
      if (!rr) continue;
      try {
        const d = JSON.parse(rr.jsonStr);
        const song = String(d.name || '').trim();
        const artist = (d.artists || []).map((a) => a.name).filter(Boolean).join(' / ');
        const album = (d.album && d.album.name) || '';
        if (!song) continue;
        const key = (song + '|' + artist).toLowerCase();
        if (seen.has(key)) continue;
        seen.add(key);
        songs.push({ name: song, artist, album });
      } catch { /* 忽略无法解析的歌 */ }
    }
    emit({ playlistName: name, songs });
  } finally {
    try { db.close(); } catch { /* ignore */ }
  }
}

main();
