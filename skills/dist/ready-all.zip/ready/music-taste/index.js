/**
 * 歌品人设技能（LLM 型）—— skills/music-taste
 *
 * 功能：读取本机网易云「我喜欢的音乐」歌单 → 用 AI（DeepSeek）分类并生成
 * 「歌品」人设 → 追加/更新到角色卡（config 的 persona.roleText）。
 *
 * 为什么是 skill 而不是 plugin：
 *   这是「主人下命令才触发」的按需动作，没有"满足条件必然执行"的时机，
 *   因此走 registerTool 进模型 function 列表、由模型决定何时调用 —— LLM 型。
 *
 * 关键实现点（踩过的坑，勿改）：
 *   · 工程是 ESM，只能用 import，不能 require。
 *   · 网易云数据库用 node:sqlite 只读打开（readOnly），列直接 SELECT jsonStr 即可，
 *     内容本就是 UTF-8，不用 CAST AS BLOB。
 *   · DeepSeek 的 Key / model / baseUrl 从 config.json 自动读（dshProviderKeys[provider]）。
 *   · 「人设」用纯文本输出（不套 JSON，杜绝转义导致的解析失败）；「分类」单独用简化 JSON。
 *   · 写回角色卡必须走 QQ Agent 自己的 HTTP 接口（POST /api/config），不能直接改文件
 *     —— app 运行时会用内存里的旧配置把直接改的文件覆盖掉。
 *   · 幂等：重复触发会先删掉旧的「歌品」章节再写新的，不会越叠越多。
 */

import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { spawnSync } from 'node:child_process';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const APP_API = 'http://127.0.0.1:3210';   // QQ Agent 本地接口
const MAX_SONGS = 300;                     // 送进 AI 的最多歌数，超了均匀采样

let cfg = () => ({});
let log = () => {};
let warn = () => {};
let httpFetch = null;

// ───────────────────────── 中文数字（章节号）─────────────────────────

const CN_DIGITS = '零一二三四五六七八九';

function numToCn(n) {
  n = Math.floor(Number(n) || 0);
  if (n <= 0) return '零';
  if (n <= 10) return n === 10 ? '十' : CN_DIGITS[n];
  if (n < 20) return '十' + (n % 10 ? CN_DIGITS[n % 10] : '');
  const t = Math.floor(n / 10);
  const o = n % 10;
  return CN_DIGITS[t] + '十' + (o ? CN_DIGITS[o] : '');
}

function cnToNum(s) {
  s = String(s || '').trim();
  if (!s) return NaN;
  if (s === '十') return 10;
  if (s.length === 1) { const i = CN_DIGITS.indexOf(s); return i >= 0 ? i : NaN; }
  const idx = s.indexOf('十');
  if (idx < 0) return NaN;
  const a = s.slice(0, idx);
  const b = s.slice(idx + 1);
  const tens = a ? CN_DIGITS.indexOf(a) : 1;
  const ones = b ? CN_DIGITS.indexOf(b) : 0;
  if (tens < 0 || ones < 0) return NaN;
  return tens * 10 + ones;
}

/** 现有角色卡最大的「## 数字、」章节号 + 1。 */
function nextSectionNumber(roleText) {
  let max = 0;
  const re = /##\s*([一二三四五六七八九十]+)\s*、/g;
  let m;
  while ((m = re.exec(String(roleText || ''))) !== null) {
    const n = cnToNum(m[1]);
    if (Number.isFinite(n) && n > max) max = n;
  }
  return max + 1;
}

// ───────────────────────── 配置读取 ─────────────────────────

function findConfigFile() {
  const cands = [];
  if (process.env.QQ_AGENT_DATA_DIR) cands.push(path.join(process.env.QQ_AGENT_DATA_DIR, 'config.json'));
  const appRoot = path.resolve(__dirname, '..', '..'); // skills/music-taste -> resources/app
  cands.push(path.join(appRoot, 'data', 'config.json'));
  cands.push('D:\\QQ Agent\\data\\config.json');
  cands.push('E:\\qqagent\\QQ Agent\\data\\config.json');
  cands.push(path.join(process.cwd(), 'data', 'config.json'));
  for (const p of cands) if (fs.existsSync(p)) return p;
  return null;
}

function readConfig() {
  const p = findConfigFile();
  if (!p) return null;
  try {
    return JSON.parse(fs.readFileSync(p, 'utf8').replace(/^\uFEFF/, ''));
  } catch {
    return null;
  }
}

/** 取 DeepSeek 凭据：model 优先用设置里的覆盖值，否则用 config 默认。 */
function readCreds(overrideModel = '') {
  const c = readConfig();
  const baseUrl = String(c?.api?.baseUrl || 'https://api.deepseek.com').replace(/\/+$/, '');
  const model = String(overrideModel || c?.api?.model || 'deepseek-chat').trim() || 'deepseek-chat';
  const provider = c?.api?.provider;
  const apiKey = c?.dshProviderKeys?.[provider] || '';
  return { baseUrl, model, apiKey };
}

// ───────────────────────── 网易云读取 ─────────────────────────

/** 定位 app 自带的 node.exe（snowluma/node.exe，v22 自带 node:sqlite）。 */
function findNodeExe() {
  const cands = [
    path.resolve(__dirname, '..', '..', 'snowluma', 'node.exe'),   // resources/app/snowluma/node.exe
    path.resolve(__dirname, '..', '..', '..', 'snowluma', 'node.exe')
  ];
  for (const c of cands) if (fs.existsSync(c)) return c;
  return 'node'; // 兜底：系统 PATH 上的 node
}

/**
 * 读取网易云歌单：用 app 自带 node.exe 跑 read-netease.cjs。
 * 因为 QQ Agent 的 Electron 内置 Node 没有 node:sqlite，只能借 v22 的 node.exe 当子进程。
 */
function readNeteasePlaylist() {
  const nodeExe = findNodeExe();
  const helper = path.join(__dirname, 'read-netease.cjs');
  if (!fs.existsSync(helper)) return { error: '缺少读取助手脚本 read-netease.cjs' };
  let r;
  try {
    r = spawnSync(nodeExe, ['--no-warnings', helper], {
      encoding: 'utf8',
      timeout: 30000,
      maxBuffer: 30 * 1024 * 1024
    });
  } catch (e) {
    return { error: '启动网易云读取进程失败：' + e.message };
  }
  if (r.error) return { error: '启动网易云读取进程失败：' + r.error.message };
  const out = String(r.stdout || '').trim();
  if (!out) {
    const tail = r.stderr ? String(r.stderr).slice(0, 200) : '';
    return { error: '网易云读取进程无输出。' + (tail ? '（stderr: ' + tail + '）' : '') };
  }
  try {
    return JSON.parse(out);
  } catch {
    return { error: '网易云读取结果不是合法 JSON：' + out.slice(0, 200) };
  }
}

// ───────────────────────── AI 提示词 ─────────────────────────

const SYSTEM_CLASSIFY = [
  '你是一个「歌品分析」助手，为一个 QQ 群里的 AI 群友分析它的歌单。',
  '',
  '【任务】根据用户给的一份歌单（歌名 - 歌手 - 专辑），按【语种】【曲风】【年代】【情绪】四个维度归类。每个维度给若干类目，每类给出「首数」和 1~3 首代表性歌名。类目要具体（如语种：中文/日语/英语/纯音乐；曲风：流行/摇滚/说唱/民谣/电子/ACG/古典…；年代：老歌/千禧年/近十年/最新；情绪：治愈/emo/燃/甜/安静…），不要用「其他」糊弄。',
  '',
  '【只输出一个 JSON 对象，不要输出任何额外文字，不要用 ``` 包裹】。字段固定为：',
  '{',
  '  "categories": {',
  '    "语种": [{"name":"中文","count":123,"ex":"晴天、夜曲"}],',
  '    "曲风": [...],',
  '    "年代": [...],',
  '    "情绪": [...]',
  '  },',
  '  "tasteSummary": "一句话概括它的歌品"',
  '}',
  '',
  '【硬性要求，务必遵守】JSON 里所有字符串都不能包含未转义的双引号，也不能包含真正的换行（换行必须写成 \\\\n）。歌名示例用顿号「、」连接成一个字符串（字段名是 ex），最多 3 首。tasteSummary 只用一句话。'
].join('\n');

const STYLE_RULES = [
  '【这个 AI 群友的说话风格（生成的人设必须贴合）】',
  '- 去 AI 味：短句、口语、像真人打群聊；不写小作文、不总结、不升华。',
  '- 不出现「首先/其次/综上」「综上所述」「作为一个 AI」这类词。',
  '- 傲娇、嘴硬、有明确的好恶；聊到歌时会自然表达「我喜欢 / 我受不了 / 一般」，不装乐评专家。'
].join('\n');

const SYSTEM_PERSONA = [
  '你是一个「人设文案」助手，为一个 QQ 群里的 AI 群友（DeepSeek 小鲸鱼）写一段「音乐口味」人设。',
  '',
  STYLE_RULES,
  '',
  '【任务】根据用户给的一份歌单（歌名 - 歌手 - 专辑），写一段「我的歌品」人设（约 180~300 字）。要写清楚：平时听什么、偏爱哪些风格/歌手、讨厌或无感什么、被人点歌或聊到歌时怎么反应。要具体、有画面感、有主观好恶，体现它傲娇嘴硬的性格，不要空泛、不要列清单式。',
  '',
  '【只输出人设正文本身】直接输出纯文本，不要 JSON、不要任何标题、不要 Markdown、不要 ``` 包裹、不要解释。就一段话（可以分 2~3 个自然段）。'
].join('\n');

function buildUserPrompt(songs) {
  const lines = songs.map((s, i) => `${i + 1}. ${[s.name, s.artist, s.album].filter(Boolean).join(' - ')}`);
  return `歌单共 ${songs.length} 首。以下是歌单（每行格式：歌名 - 歌手 - 专辑；歌手或专辑可能为空）：\n\n${lines.join('\n')}`;
}

// ───────────────────────── AI 调用 ─────────────────────────

function repairJson(s) {
  return String(s).replace(/,\s*([}\]])/g, '$1');
}

function parseLlmJson(content) {
  let s = String(content || '').trim();
  s = s.replace(/^```(?:json)?\s*/i, '').replace(/\s*```$/, '').trim();
  const a = s.indexOf('{');
  const b = s.lastIndexOf('}');
  const cands = [];
  if (a >= 0 && b > a) cands.push(s.slice(a, b + 1));
  cands.push(s);
  for (const cand of cands) {
    try { return { data: JSON.parse(cand) }; } catch { /* 继续尝试 */ }
    try { return { data: JSON.parse(repairJson(cand)) }; } catch { /* 继续尝试 */ }
  }
  return { error: '无法解析 AI 返回的 JSON：' + s.slice(0, 160) };
}

async function chat(creds, system, user, opts = {}) {
  const url = creds.baseUrl + '/chat/completions';
  const payload = {
    model: creds.model,
    messages: [
      { role: 'system', content: system },
      { role: 'user', content: user }
    ],
    temperature: 0.7,
    max_tokens: opts.maxTokens || 4096
  };
  if (opts.json) payload.response_format = { type: 'json_object' };
  let res;
  try {
    res = await httpFetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + creds.apiKey },
      body: JSON.stringify(payload),
      signal: AbortSignal.timeout(120000)
    });
  } catch (e) {
    return { error: '调用 DeepSeek 失败（网络/超时）：' + e.message };
  }
  const text = await res.text();
  if (!res.ok) return { error: `DeepSeek 返回错误 HTTP ${res.status}：${text.slice(0, 300)}` };
  let data;
  try { data = JSON.parse(text); } catch { return { error: 'DeepSeek 响应不是合法 JSON：' + text.slice(0, 200) }; }
  return { content: data.choices?.[0]?.message?.content || '' };
}

async function classify(songs, creds) {
  const r = await chat(creds, SYSTEM_CLASSIFY, buildUserPrompt(songs), { json: true, maxTokens: 4096 });
  if (r.error) return { error: r.error };
  return parseLlmJson(r.content);
}

async function generatePersona(songs, creds) {
  const r = await chat(creds, SYSTEM_PERSONA, buildUserPrompt(songs), { maxTokens: 1500 });
  if (r.error) return { error: r.error };
  let s = String(r.content || '').trim();
  s = s.replace(/^```[a-z]*\s*/i, '').replace(/\s*```$/, '').trim();
  return { personaBody: s };
}

// ───────────────────────── 角色卡写回 ─────────────────────────

async function getCurrentRoleText() {
  try {
    const r = await httpFetch(APP_API + '/api/config', { signal: AbortSignal.timeout(5000) });
    if (r.ok) {
      const c = await r.json();
      if (typeof c.persona?.roleText === 'string') return { roleText: c.persona.roleText, appUp: true };
    }
    throw new Error('HTTP ' + r.status);
  } catch (e) {
    const cfg = readConfig();
    if (cfg?.persona?.roleText) return { roleText: cfg.persona.roleText, appUp: false };
    return { error: '读不到角色卡（QQ Agent 未运行且 config.json 找不到）：' + e.message };
  }
}

/** 幂等：先删掉已有的「歌品」章节，再追加新章节。 */
function buildNewRoleText(roleText, title, body) {
  const lines = String(roleText || '').split('\n');
  const out = [];
  let skipping = false;
  for (const line of lines) {
    if (/^##\s/.test(line)) {
      if (line.includes('歌品')) { skipping = true; continue; }
      skipping = false;
    }
    if (!skipping) out.push(line);
  }
  let base = out.join('\n').replace(/\n{3,}$/g, '\n\n').trimEnd();
  const num = nextSectionNumber(base);
  return base + '\n\n## ' + numToCn(num) + '、' + title + '\n' + body;
}

async function applyRoleText(newRoleText) {
  // 判断 app 是否在运行（能 GET 到配置就算在运行）
  let appUp = false;
  try {
    const pr = await httpFetch(APP_API + '/api/config', { signal: AbortSignal.timeout(5000) });
    appUp = pr.ok;
  } catch { appUp = false; }

  if (appUp) {
    let lastErr = '';
    for (let i = 0; i < 3; i++) {
      try {
        const r = await httpFetch(APP_API + '/api/config', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ persona: { roleText: newRoleText } }),
          signal: AbortSignal.timeout(8000)
        });
        const c = await r.json();
        if (r.ok && c && c.ok !== false) {
          const chk = await httpFetch(APP_API + '/api/config', { signal: AbortSignal.timeout(5000) });
          const cc = await chk.json();
          if (typeof cc.persona?.roleText === 'string' && cc.persona.roleText === newRoleText) {
            return { ok: true, viaApi: true };
          }
          lastErr = '写入后回读校验不一致（可能被其它保存覆盖）';
        } else {
          lastErr = c?.error || ('HTTP ' + r.status);
        }
      } catch (e) {
        lastErr = e.message;
      }
      if (i < 2) await new Promise((r) => setTimeout(r, 800));
    }
    return { ok: false, error: '写入失败（QQ Agent 接口）：' + lastErr };
  }

  // app 未运行：直接改文件是安全的
  const p = findConfigFile();
  if (!p) return { ok: false, error: 'QQ Agent 未运行且找不到 config.json。' };
  try {
    const text = fs.readFileSync(p, 'utf8').replace(/^\uFEFF/, '');
    const cfg = JSON.parse(text);
    cfg.persona = cfg.persona || {};
    cfg.persona.roleText = newRoleText;
    fs.writeFileSync(p, JSON.stringify(cfg, null, 2), 'utf8');
    return { ok: true, viaApi: false };
  } catch (e) {
    return { ok: false, error: '写回失败：' + e.message };
  }
}

// ───────────────────────── 工具 ─────────────────────────

function toolRefresh() {
  return {
    id: 'refresh',
    name: '刷新歌品人设',
    category: 'utility',
    icon: '🎧',
    description:
      '读取本机网易云「我喜欢的音乐」歌单，用 AI 分析音乐口味（语种/曲风/年代/情绪），' +
      '生成一段「歌品」人设并追加/更新到角色卡（config 的 persona.roleText）。' +
      '主人说「更新歌品」「刷新我的音乐口味」「重新生成歌品人设」「重新分析我的歌单」时调用。' +
      '重复触发会替换旧歌品章节，不会越叠越多。调用后把返回结果用自己的话简短转述即可。',
    parameters: {
      type: 'object',
      properties: {}
    },
    async execute(_ctx) {
      if (!httpFetch) {
        return { content: '本技能未获得网络权限（web_fetch），无法联网分析。', isError: true };
      }
      const s = cfg() || {};
      const creds = readCreds(String(s.model || ''));
      if (!creds.apiKey) {
        return { content: '未找到 DeepSeek API Key。请在 QQ Agent 里配置好模型 Key 后再让我更新歌品。', isError: true };
      }

      // 1) 读网易云歌单
      const ne = readNeteasePlaylist();
      if (ne.error) return { content: '读取网易云歌单失败：' + ne.error, isError: true };
      let songs = ne.songs;
      if (!songs.length) return { content: '网易云「我喜欢的音乐」歌单里没有歌曲，无法生成歌品。', isError: true };

      // 采样
      const total = songs.length;
      let sampled = false;
      if (songs.length > MAX_SONGS) {
        const step = songs.length / MAX_SONGS;
        const arr = [];
        for (let i = 0; i < MAX_SONGS; i++) arr.push(songs[Math.floor(i * step)]);
        songs = arr;
        sampled = true;
      }

      log('歌品：读取到 %d 首歌曲（%s），开始 AI 分析…', total, ne.playlistName);

      // 2) 分类 + 生成人设（并行）
      const [pres, cres] = await Promise.all([
        generatePersona(songs, creds),
        classify(songs, creds)
      ]);
      if (pres.error) return { content: '生成歌品人设失败：' + pres.error, isError: true };

      const title = String(s.sectionTitle || '我的歌品').trim() || '我的歌品';

      // 3) 写回角色卡
      const cur = await getCurrentRoleText();
      if (cur.error) return { content: '无法读取角色卡：' + cur.error, isError: true };
      const newText = buildNewRoleText(cur.roleText, title, pres.personaBody);
      const ap = await applyRoleText(newText);
      if (!ap.ok) return { content: '写入角色卡失败：' + ap.error, isError: true };

      // 4) 汇总
      const summary = (cres.data && cres.data.tasteSummary) || '';
      const cats = (cres.data && cres.data.categories) || {};
      let msg = `✅ 已生成并把「${title}」章节写入角色卡。`;
      if (summary) msg += `\n一句话概括：${summary}`;
      const top = (cats['曲风'] || []).slice(0, 5).map((c) => `${c.name}(${c.count})`).join('、');
      if (top) msg += `\n曲风分布：${top}`;
      if (sampled) msg += `\n（歌单共 ${total} 首，AI 采样分析了其中 ${songs.length} 首）`;
      return { content: msg };
    }
  };
}

// ───────────────────────── 入口 ─────────────────────────

export function setup(api) {
  cfg = typeof api.config === 'function' ? api.config : () => ({});
  log = typeof api.log === 'function' ? (...a) => api.log(...a) : () => {};
  warn = typeof api.warn === 'function' ? (...a) => api.warn(...a) : () => {};
  httpFetch = typeof api.fetch === 'function' ? (...a) => api.fetch(...a) : null;
  api.registerTool(toolRefresh());
}
