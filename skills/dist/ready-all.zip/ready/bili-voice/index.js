// B站点歌（语音条）—— LLM 型技能（skills/）。
//
// 为什么用 B 站当音源：酷狗/网易云的会员歌在接口层就被掐死了（酷狗直接
// 回"需要付费"，网易云带账号拿到的链接下载还会 403，详见之前的实测）。
// B 站是本次唯一"能真下到文件"的路：搜视频 → 取流 → 下 mp4 → ffmpeg 抽音频 → 发语音条。
// 代价是它属于 UP 主上传的 MV/音频，不是官方音源，可能带片头，所以默认跳过开头 15 秒。
//
// ── 两个硬约束 ──────────────────────────────────────────────────────────
// 1. "只在我让他发的时候才发"：工具拆成 bili_search（只搜不发）和 bili_voice（真发），
//    提示词里明确"只说不发"；另有可选 ownerIds，填了就只有主人能点。
// 2. "发完自动清理"：下载的 mp4、抽出的 mp3 在发送成功后立刻删除（autoCleanup，默认开）。
//    注意时机 —— 必须等 sendMedia 返回之后再删：协议端读文件是发送过程的一部分，
//    提前删会把消息发成空壳。
//
// ── 为什么复制一份 bili-api.js 而不是 import 隔壁技能 ────────────────────
// 项目约定每个技能自包含（bili-share 里那份也是这么来的）。互相 import 的话，
// 隔壁技能被删/改名，这边就静默坏掉，而且 loader 的"每个目录自包含"假设也没了。
//
// ⚠️ 静态 import 会被 Node 的模块缓存钉死（改了不生效），所以走 setup 里的动态
// import + 时间戳 —— 点歌技能当年就踩过这个坑。

import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { pathToFileURL } from 'node:url';
import { spawn, spawnSync } from 'node:child_process';

/** QQ 语音条的硬上限。 */
const HARD_MAX_SECONDS = 60;
/** 标题里出现这些字样 ⇒ 大概率不是原唱（翻奏/教学/片段），要扣分。 */
const BAD_TITLE = /(吉他|指弹|钢琴|尤克里里|小提琴|口琴|二胡|古筝|翻奏|演奏|教学|教程|谱|DJ|remix|伴奏|纯音乐|cover|翻唱|恶搞|鬼畜|混剪|合集|串烧|片段|试听)/i;
/** 下载/转码的工作目录（系统临时目录，发完即删）。 */
const WORK_DIR = path.join(os.tmpdir(), 'qq-agent-bili-voice');

let bili = null;      // ./bili-api.js 的导出，setup 里动态 import 填充
let cfg = () => ({});
let log = () => {};

const ok = (payload) => ({ content: JSON.stringify(payload, null, 1) });
const err = (message) => ({ content: String(message), isError: true });
const clamp = (v, min, max) => Math.max(min, Math.min(max, v));

function normalizeText(s) {
  return String(s ?? '').toLowerCase().replace(/[\s\p{P}\p{S}]+/gu, '');
}

// ── ffmpeg 探测 ───────────────────────────────────────────────────────────
// 必须是同步的：available() 是同步接口，技能页靠它显示"为什么不能用"。
// 结果缓存 60 秒 —— 用户装好 ffmpeg 后不用重启应用。
const ffState = { at: 0, ok: false, path: '' };

function ffmpegReady(force = false) {
  if (!force && ffState.at && Date.now() - ffState.at < 60000) return ffState;
  const configured = String(cfg().ffmpegPath ?? '').trim();
  const candidates = configured
    ? [configured]
    : ['ffmpeg', path.join(os.homedir(), 'ffmpeg', 'bin', 'ffmpeg.exe'), 'C:\\ffmpeg\\bin\\ffmpeg.exe'];
  let found = '';
  for (const cmd of candidates) {
    try {
      const r = spawnSync(cmd, ['-version'], { windowsHide: true, timeout: 5000 });
      if (r && r.status === 0) { found = cmd; break; }
    } catch { /* 换下一个候选 */ }
  }
  ffState.at = Date.now();
  ffState.ok = Boolean(found);
  ffState.path = found;
  return ffState;
}

/** 技能可用性：没有 ffmpeg 就明说，而不是等到点歌时静默失败。 */
export function available() {
  const st = ffmpegReady();
  if (!st.ok) {
    return { ok: false, reason: '没找到 ffmpeg：B 站的音源是 mp4，没有它就抽不出音频（装一个或在本技能设置里填 ffmpegPath）' };
  }
  return { ok: true };
}

/** 调外部命令，只看退出码。 */
function run(cmd, args, timeoutMs = 120000) {
  return new Promise((resolve) => {
    let done = false;
    const finish = (v) => { if (!done) { done = true; resolve(v); } };
    let child;
    try {
      child = spawn(cmd, args, { windowsHide: true });
    } catch (error) {
      return finish({ ok: false, error: String(error?.message ?? error) });
    }
    let stderr = '';
    child.stderr?.on('data', (b) => { stderr = (stderr + String(b)).slice(-1500); });
    child.on('error', (error) => finish({ ok: false, error: String(error?.message ?? error) }));
    const timer = setTimeout(() => {
      try { child.kill(); } catch { /* 已退出 */ }
      finish({ ok: false, error: `超时（${timeoutMs}ms）` });
    }, timeoutMs);
    child.on('close', (code) => { clearTimeout(timer); finish({ ok: code === 0, code, stderr }); });
  });
}

// ── 搜索结果打分 ──────────────────────────────────────────────────────────
// B 站的"搜歌"其实是搜视频：同一首歌会有 MV、4K 修复、翻唱、指弹改编、教学……
// 不打分的话，机器人很可能给你放一段吉他指弹（实测搜《江南》首条就是）。
// 规则（可解释、可预期）：
//   · 关键词按空格拆成 token，标题里命中一个 +3
//   · 多个 token 全中再 +4（歌名+歌手都出现，最像正主）
//   · 标题带翻奏/教学/片段类字样 -8（基本一票否决）
//   · 时长 <60 秒（片花）或 >7 分钟（合集/演唱会）扣分
// 判定：2 个以上 token 时必须全中；分数 <3 视为不可靠，不自动发。

function scoreItem(item, tokens) {
  const title = normalizeText(item.title);
  const hit = tokens.filter((t) => title.includes(t)).length;
  let score = hit * 3;
  if (tokens.length > 1 && hit === tokens.length) score += 4;
  if (BAD_TITLE.test(String(item.title ?? ''))) score -= 8;
  const dur = Number(item.durationSec) || 0;
  if (dur && dur < 60) score -= 6;
  if (dur && dur > 420) score -= 2;
  return { score, hit };
}

function rankItems(items, keyword) {
  const tokens = String(keyword ?? '').split(/[\s,，、]+/).map(normalizeText).filter(Boolean);
  return (items || [])
    .map((item) => {
      const { score, hit } = scoreItem(item, tokens);
      const trusted = tokens.length >= 2
        ? hit === tokens.length && score >= 3
        : hit >= 1 && score >= 3;
      return { item, score, trusted };
    })
    .sort((a, b) => b.score - a.score);
}

// ── 下载 + 抽音频 ─────────────────────────────────────────────────────────

/**
 * 规划要发几段、从哪开始、每段多长。
 *
 *   deliveryMode = 'full'（默认）：整首按 partSeconds 切开，最后一段可能短一点。
 *   deliveryMode = 'clip'        ：只发一段。
 *
 * 为什么要分段：QQ 一条语音条最多 60 秒，整首 4 分钟的歌必然发不完。
 * 段数用 maxParts 兜住 —— 一首 40 分钟的 live 不能真发 40 条把群刷爆。
 */
function planParts(total, opts = {}) {
  const dur = Math.max(1, Math.round(Number(total) || 0));
  const part = clamp(Math.round(Number(opts.partSeconds) || 55), 10, HARD_MAX_SECONDS);
  const maxParts = clamp(Math.round(Number(opts.maxParts) || 10), 1, 30);
  const start = clamp(Math.round(Number(opts.skipIntro) || 0), 0, Math.max(0, dur - 5));
  const available = Math.max(1, dur - start);
  if (String(opts.mode ?? 'full') === 'clip') {
    return { start, partSeconds: Math.min(part, available), count: 1, truncated: false, available };
  }
  let count = Math.ceil(available / part);
  let truncated = false;
  if (count > maxParts) { count = maxParts; truncated = true; }
  // 只有一段时按实际可用的时长算（短歌不该报"55 秒"）
  const partSeconds = count === 1 ? Math.min(part, available) : part;
  return { start, partSeconds, count, truncated, available };
}

/**
 * 下载并切出音频分段。
 * files 由调用方传入，路径一创建就登记进去 —— 这样"下载成功但转码失败"这种
 * 半途而废的情况也会被清理（原来只在成功返回后才登记，失败就漏文件）。
 * 返回 { parts: [mp3 路径...], plan }。
 */
async function buildParts(item, { startSeconds, files } = {}) {
  const info = await bili.fetchVideoInfo(item.bvid);
  const cid = info?.cid || info?.info?.cid;
  if (!cid) throw new Error('拿不到视频 cid（这可能是番剧/受限视频，换一个结果试试）');

  const play = await bili.getPlayUrl(item.bvid, cid, { qn: 16 });
  if (!play?.ok) throw new Error(play?.error || '取流失败');

  // 体积上限：0（或填错）＝ 不限制。不限制时下载超时也要放宽，
  // 否则大文件会在 60 秒处被 fetch 的 AbortSignal 掐断，表现成"下载请求失败"。
  const rawMB = Math.round(Number(cfg().maxVideoMB));
  const unlimited = !Number.isFinite(rawMB) || rawMB <= 0;
  const maxMB = unlimited ? 0 : clamp(rawMB, 5, 5000);
  if (!unlimited && play.sizeBytes && play.sizeBytes > maxMB * 1048576) {
    throw new Error(`视频有 ${(play.sizeBytes / 1048576).toFixed(0)}MB，超过设置的 ${maxMB}MB 上限（想放这类就在设置里把上限设成 0）`);
  }

  fs.mkdirSync(WORK_DIR, { recursive: true });
  const tag = `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
  const videoPath = path.join(WORK_DIR, `${tag}.mp4`);
  if (Array.isArray(files)) files.push(videoPath);

  const dl = await bili.downloadVideo(play.urls, videoPath, {
    maxBytes: unlimited ? Number.MAX_SAFE_INTEGER : maxMB * 1048576,
    // 大文件下载本来就要几分钟，60 秒的默认超时会把它掐死
    timeoutMs: unlimited || maxMB > 60 ? 300000 : 120000
  });
  if (!dl?.ok) throw new Error(dl?.error || '下载失败');

  const st = ffmpegReady();
  if (!st.ok) throw new Error('没找到 ffmpeg，抽不出音频');

  const plan = planParts(item.durationSec, {
    partSeconds: cfg().partSeconds ?? cfg().maxSeconds,
    // 模型可以指定起点（"从 1 分 20 秒开始放"），否则用设置里的"跳过开头"
    skipIntro: startSeconds == null ? cfg().skipIntro : startSeconds,
    mode: cfg().deliveryMode,
    maxParts: cfg().maxParts
  });

  // -ss 放在 -i 前面：直接跳到目标位置再解码，比解完整首再切快一个数量级
  const front = ['-hide_banner', '-loglevel', 'error', '-y', '-ss', String(plan.start), '-i', videoPath];
  // 单声道 24k 32kbps：SILK 本来就是这档，码率给高了对语音条没意义，还拖慢上传
  const encode = ['-vn', '-ac', '1', '-ar', '24000', '-b:a', '32k'];
  const args = plan.count === 1
    ? [...front, '-t', String(plan.partSeconds), ...encode, '-f', 'mp3', path.join(WORK_DIR, `${tag}-000.mp3`)]
    // 一次 ffmpeg 切多段：比逐段调用快得多，也不会重复解码
    : [...front, ...encode, '-f', 'segment', '-segment_time', String(plan.partSeconds),
      '-reset_timestamps', '1', path.join(WORK_DIR, `${tag}-%03d.mp3`)];

  const conv = await run(st.path, args);
  if (!conv.ok) throw new Error(`抽音频失败：${conv.error || conv.code || 'ffmpeg 返回非 0'}`);

  const produced = fs.readdirSync(WORK_DIR)
    .filter((n) => n.startsWith(`${tag}-`) && n.endsWith('.mp3'))
    .sort()
    .map((n) => path.join(WORK_DIR, n));
  if (!produced.length) throw new Error('抽音频失败：没有产出文件');
  for (const p of produced) if (Array.isArray(files) && !files.includes(p)) files.push(p);

  // 段数兜底：超过 maxParts 的部分直接丢掉（歌曲太长时会发生）
  const parts = produced.slice(0, plan.count);
  for (const p of produced.slice(plan.count)) { try { fs.unlinkSync(p); } catch { /* 忽略 */ } }
  for (const p of parts) {
    if (!fs.existsSync(p) || fs.statSync(p).size < 1024) throw new Error('抽音频失败：分段文件为空');
  }
  return { parts, plan };
}

/** 删掉本次产生的临时文件；返回实际删掉的个数（另顺手清扫超过 1 小时的残留）。 */
function cleanup(files, { sweep = false } = {}) {
  let removed = 0;
  for (const f of files || []) {
    try {
      if (fs.existsSync(f)) { fs.unlinkSync(f); removed += 1; }
    } catch (error) {
      log(`清理临时文件失败（${path.basename(f)}）：${error?.message ?? error}`);
    }
  }
  if (sweep) {
    // 极端情况（进程崩在发送中途）会留残骸，顺手扫掉一小时前的
    try {
      const cutoff = Date.now() - 3600 * 1000;
      for (const name of fs.readdirSync(WORK_DIR)) {
        const p = path.join(WORK_DIR, name);
        const st = fs.statSync(p);
        if (st.isFile() && st.mtimeMs < cutoff) fs.unlinkSync(p);
      }
    } catch { /* 目录不存在或别的东西在用，忽略 */ }
  }
  return removed;
}

// ── 谁能点歌 ──────────────────────────────────────────────────────────────

/** 从本轮触发消息里找发起人 QQ 号（ctx 没直接给 speaker，走 session.trigger）。 */
function callerId(ctx) {
  const trigger = ctx?.session?.trigger;
  if (!Array.isArray(trigger) || !trigger.length) return '';
  for (let i = trigger.length - 1; i >= 0; i -= 1) {
    const e = trigger[i];
    if (e && !e.self && e.senderId) return String(e.senderId);
  }
  return '';
}

function ownerGate(ctx) {
  const list = String(cfg().ownerIds ?? '')
    .split(/[,，\s;；]+/)
    .map((s) => s.replace(/[^\d]/g, ''))
    .filter(Boolean);
  if (!list.length) return { ok: true };
  const who = callerId(ctx);
  if (!who) return { ok: false, reason: '认不出是谁发的（没拿到发送者 QQ 号）' };
  return list.includes(who)
    ? { ok: true }
    : { ok: false, reason: `这个会话里只有主人能点歌（当前 ${who} 不在名单里）` };
}

// ── 生命周期 ──────────────────────────────────────────────────────────────

export async function setup(api) {
  cfg = api.config;
  log = api.log;
  const stamp = Date.now();
  bili = await import(`./bili-api.js?t=${stamp}`);

  // 启动时清一次上一轮崩掉留下的残骸（正常情况下这里不会有东西）
  cleanup([], { sweep: true });

  // ── 只搜不发 ────────────────────────────────────────────────────────────
  api.registerTool({
    id: 'bili_search',
    name: 'B站搜歌',
    description: '在 B 站搜歌，只返回候选列表，**不会发送任何东西**。对方说"找找/搜一下/有没有"、或者要点歌但歌名模糊、同名版本多时用它。返回里每条带 index、标题、UP 主、时长和 score（越大越像正主；trusted=false 表示怀疑是翻奏/片段）。确认是哪条之后用 bili_voice 发（传 index 或 bvid 即可，不用重搜）。',
    category: 'media',
    icon: '🅱️',
    parameters: {
      type: 'object',
      properties: {
        keyword: { type: 'string', description: '歌名，最好带上歌手（如"晴天 周杰伦"），空格分隔' },
        limit: { type: 'integer', description: '返回几条，默认取技能设置（5），最多 10' }
      },
      required: ['keyword']
    },
    async execute(ctx, args) {
      try {
        const keyword = String(args.keyword ?? '').trim();
        if (!keyword) return err('搜索关键词是空的，先告诉我歌名');
        const limit = clamp(Math.round(Number(args.limit) || Number(cfg().maxResults) || 5), 1, 10);
        const res = await bili.searchVideos(keyword, { limit, log });
        if (!res?.ok) return err(`B 站搜索失败：${res?.error ?? '未知错误'}`);
        const ranked = rankItems(res.items, keyword).slice(0, limit);
        if (!ranked.length) {
          return ok({ found: false, note: `B 站没搜到「${keyword}」。换个关键词，或者把歌手名一起带上；别编造歌名。` });
        }
        return ok({
          found: true,
          keyword,
          count: ranked.length,
          songs: ranked.map((r, i) => ({
            index: i + 1,
            bvid: r.item.bvid,
            title: r.item.title,
            author: r.item.author,
            duration: r.item.duration,
            score: r.score,
            trusted: r.trusted,
            note: r.trusted ? '' : '可能不是原唱（翻奏/片段/合集）'
          })),
          note: '这些只是候选，**还没有发出去**。要发语音条就用 bili_voice（传 index 或 bvid），别用文字念歌单。'
        });
      } catch (error) {
        return err(`搜索出错：${error?.message ?? error}`);
      }
    }
  });

  // ── 搜 + 发语音条 ───────────────────────────────────────────────────────
  api.registerTool({
    id: 'bili_voice',
    name: 'B站点歌发语音条',
    description: '在 B 站搜到那首歌，取流下载、抽音频，按每段 60 秒上限切成多条语音条，把整首依次发到当前会话（4 分钟的歌大概 4~5 条），发完自动删掉下载的文件。**只在对方明确要求"发/放/来一首"时才用**；只是让找一找就别发（用 bili_search）。歌名清楚可以直接传 keyword；已经搜过就用之前返回的 index 或 bvid。一次点一首，不要连发。',
    category: 'media',
    icon: '🎤',
    parameters: {
      type: 'object',
      properties: {
        keyword: { type: 'string', description: '歌名，最好带歌手（如"晴天 周杰伦"）' },
        index: { type: 'integer', description: '用最近一次 bili_search 结果里的第几条（从 1 开始）' },
        bvid: { type: 'string', description: 'B 站视频号（bili_search 返回的那个），最精确' },
        startSeconds: { type: 'integer', description: '可选：从第几秒开始截（覆盖默认的"跳过开头"，对方说"从 1 分 20 秒那段"时用）' }
      }
    },
    async execute(ctx, args) {
      const gate = ownerGate(ctx);
      if (!gate.ok) return err(`没发：${gate.reason}。可以只搜不发，或者直接说明这里不接别人的点歌。`);

      let built = null;
      let sentParts = 0;      // 已经发出去的段数（中途失败要如实报）
      const tempFiles = [];   // 一创建就登记，失败路径也能清干净
      let result;
      try {
        const keyword = String(args.keyword ?? '').trim();
        if (!keyword) return err('要给歌名（keyword）');

        const limit = clamp(Math.round(Number(cfg().maxResults) || 5), 1, 10);
        const res = await bili.searchVideos(keyword, { limit, log });
        if (!res?.ok) return err(`B 站搜索失败：${res?.error ?? '未知错误'}`);
        const ranked = rankItems(res.items, keyword);
        if (!ranked.length) {
          return ok({ delivered: false, note: `B 站没搜到「${keyword}」。换个关键词再试，或者如实说没找到；别编造。` });
        }

        // 指定了 bvid / index 就用它，否则取打分最高的一条
        const wantedBvid = String(args.bvid ?? '').trim();
        const idx = Number(args.index) || 0;
        let picked = null;
        if (wantedBvid) picked = ranked.find((r) => r.item.bvid === wantedBvid) || { item: { bvid: wantedBvid }, trusted: true, score: -1 };
        else if (idx >= 1 && ranked[idx - 1]) picked = ranked[idx - 1];
        else picked = ranked[0];

        if (!picked.trusted) {
          // 分数太低 = 疑似翻奏/片段/合集。宁可不发，也不能把指弹当成原唱发出去。
          const top = ranked.slice(0, 3).map((r, i) => `${i + 1}. ${r.item.title}（${r.item.author}）`).join('；');
          return err(`没发：搜「${keyword}」出来的都不太像原唱（可能是翻奏/片段/合集）——${top}。换个关键词，或者先跟对方确认要哪个版本。`);
        }

        built = await buildParts(picked.item, { startSeconds: args.startSeconds, files: tempFiles });
        const total = built.parts.length;
        const name = picked.item.title.slice(0, 24);

        // 一段一条，按顺序发。某一段失败就停下 —— 已经发出去的不回滚，
        // 但要如实告诉模型发了几个、卡在第几个。
        for (let i = 0; i < total; i += 1) {
          await ctx.sender.sendMedia(
            ctx.chatKey,
            [{ type: 'record', data: { file: pathToFileURL(built.parts[i]).href } }],
            {
              label: total > 1 ? `[语音:${name} ${i + 1}/${total}]` : `[语音:${name}]`,
              dedupeKey: `bili-voice:${picked.item.bvid}:${built.plan.start}:${i}`
            }
          );
          sentParts = i + 1;
        }

        try {
          ctx.session?.sent?.push({ type: 'voice', text: `[语音:${name} ×${total}]`, delivered: 'voice' });
          ctx.emit?.('session-update', ctx.session?.id);
        } catch { /* 留档失败不影响已发出的消息 */ }

        const truncatedNote = built.plan.truncated
          ? `（这首歌太长，按设置只发了前 ${total} 段，没放完）`
          : '';
        result = ok({
          delivered: 'voice',
          title: picked.item.title,
          author: picked.item.author,
          bvid: picked.item.bvid,
          parts: total,
          partSeconds: built.plan.partSeconds,
          from: `${built.plan.start}s`,
          score: picked.score,
          note: total > 1
            ? `整首歌已分成 ${total} 条语音条依次发出（每条约 ${built.plan.partSeconds} 秒，从第 ${built.plan.start} 秒开始）${truncatedNote}。用一句话带过就行（比如「整首给你发过去了，分了几条」），不要逐条点评、不要复述歌词、不要贴 B 站链接。`
            : `语音条已发出（${built.plan.partSeconds} 秒，从第 ${built.plan.start} 秒开始）。用一句话带过就行，不要复述歌词、不要贴 B 站链接、也不用解释是怎么弄出来的。`
        });
      } catch (error) {
        result = sentParts > 0
          ? err(`发到第 ${sentParts + 1} 段时出错了：${error?.message ?? error}（前面 ${sentParts} 段已经发出去了，别当没发过）`)
          : err(`没发成：${error?.message ?? error}。如实告诉对方，不要假装发了。`);
      } finally {
        // 自动清理：发送成功、发送失败、下载到一半失败 —— 一律删。
        // 时机是"发送结束之后"：协议端读文件属于发送过程的一部分，提前删会发成空壳。
        if (tempFiles.length) {
          if (cfg().autoCleanup !== false) {
            const removed = cleanup(tempFiles, { sweep: true });
            log(`已清理临时文件 ${removed}/${tempFiles.length} 个`);
          } else {
            log(`autoCleanup 已关闭，文件留在：${tempFiles.join(', ')}`);
          }
        }
      }
      return result;
    }
  });
}

/** 纯函数导出，只给离线自测用（加载器不消费它）。 */
export const internals = { planParts, scoreItem, rankItems, cleanup, normalizeText };
