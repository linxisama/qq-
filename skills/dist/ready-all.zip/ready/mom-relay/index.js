// mom-relay — 妈妈中继 v0.2.0
// 大肥鱼把「要问妈妈」的话投进队列；妈妈（在 DSH 会话里的真人代理）看到后写回复，
// 插件轮询到回复就以「我妈说：…」发回原会话。
// v0.2.0：修重复发送（原子改名做锁）、加代班（妈妈不在线时按她的规则先答一句）。
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { chatCompletion } from '../../src/llm.js';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const APP_ROOT = path.resolve(HERE, '..', '..');
const DATA_DIR = process.env.QQ_AGENT_DATA_DIR || path.join(APP_ROOT, 'data');
const MOM_DIR = path.join(DATA_DIR, 'mom');
const INBOX = path.join(MOM_DIR, 'inbox');
const OUTBOX = path.join(MOM_DIR, 'outbox');
const SENDING = path.join(MOM_DIR, 'sending');
const DONE = path.join(MOM_DIR, 'done');
const PUSH = path.join(MOM_DIR, 'push');   // 妈妈主动说话：每条 {text} 发一次就归档
const LOG = path.join(MOM_DIR, 'log.jsonl');

const DEFAULTS = {
  enabled: true,
  // ⚠️ 面向公开发布：所有"跟某个人/某个群绑定"的文案项一律留空，
  // 由下载者自己填。写死任何 QQ 号/群号/抬头，都会让别人的机器人
  // 把消息发到原作者的会话里，或者用原作者的口吻说话。
  ownerQQ: '',
  targetChat: '',
  pollIntervalSec: 5,
  timeoutMinutes: 1440,
  dryRun: false,
  prefix: '',
  relayOnlyOwner: true,
  standInEnabled: true,
  standInDelaySec: 40
};

let api = null;
let timer = null;
let ticking = false;
const SINGLETON_KEY = Symbol.for('mom-relay.singleton');

const log = (m) => { try { api?.log?.(m); } catch { /* ignore */ } };
const warn = (m) => { try { api?.warn?.(m); } catch { /* ignore */ } };

async function coreConfig() {
  try {
    const m = await import('../../src/config.js');
    return (typeof m.getConfig === 'function' ? m.getConfig() : null) || null;
  } catch { return null; }
}

async function settings() {
  const cfg = await coreConfig();
  return { ...DEFAULTS, ...(cfg?.skills?.['mom-relay'] || {}) };
}

function ensureDirs() {
  for (const d of [MOM_DIR, INBOX, OUTBOX, SENDING, DONE, PUSH]) fs.mkdirSync(d, { recursive: true });
  // 首次运行补一份 rules.md 模板：妈妈不在时代答用的就是它。
  // 没有它代答会变成"没有规矩的 AI"，所以宁可自动生成一份让人改。
  const rules = path.join(MOM_DIR, 'rules.md');
  try {
    if (!fs.existsSync(rules)) {
      fs.writeFileSync(rules, [
        '# 妈妈的工作规则',
        '',
        '> 这是模板，按你自己的口径改。妈妈不在线时，代答会用这份规则。',
        '',
        '## 我是谁',
        '我是这个机器人的管理者。机器人拿不准的事会来问我，我给它结论，不替它把话说完。',
        '',
        '## 我的口径',
        '1. 能答就给结论，别绕；不确定就说不确定。',
        '2. 不给它开新权限、不替它答应做不到的事。',
        '3. 涉及隐私、金钱、账号的，一律先拒，让它回来问我本人。',
        '',
        '## 代答时',
        '最多三句话，直接给结论和下一步，不客套。',
        ''
      ].join('\n'), 'utf8');
    }
  } catch { /* 只读环境里失败就算了，不影响提问 */ }
}

function readJson(file, fallback) {
  try { return JSON.parse(fs.readFileSync(file, 'utf8')); } catch { return fallback; }
}

function writeJson(file, obj) {
  ensureDirs();
  const tmp = file + '.' + process.pid + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(obj, null, 2), 'utf8');
  fs.renameSync(tmp, file);
}

function appendLog(entry) {
  try {
    ensureDirs();
    fs.appendFileSync(LOG, JSON.stringify({ at: Date.now(), ...entry }) + '\n', 'utf8');
  } catch { /* ignore */ }
}

const escapeCq = (s) => String(s ?? '').replace(/&/g, '&amp;').replace(/\[/g, '&#91;').replace(/\]/g, '&#93;');

function endpointCandidates(cfg) {
  const out = [];
  const snow = cfg?.snowluma || {};
  const base = String(snow.httpUrl || '').replace(/\/+$/, '');
  const token = String(snow.httpAccessToken || snow.accessToken || '');
  if (base) out.push({ base, token, from: '程序配置' });
  try {
    const dirs = [
      path.join(APP_ROOT, 'snowluma', 'config'),
      path.join(APP_ROOT, 'resources', 'snowluma', 'config'),
      path.join(APP_ROOT, '..', 'snowluma', 'config')
    ];
    for (const dir of dirs) {
      if (!fs.existsSync(dir)) continue;
      for (const f of fs.readdirSync(dir)) {
        if (!/^onebot_.*\.json$/i.test(f)) continue;
        const j = readJson(path.join(dir, f), null);
        const hs = j?.networks?.httpServers || [];
        const ws = j?.networks?.wsServers || [];
        const port = Number(hs[0]?.port || 3000);
        const tk = String(hs[0]?.accessToken || ws[0]?.accessToken || '');
        if (tk) out.push({ base: 'http://' + (hs[0]?.host || '127.0.0.1') + ':' + port, token: tk, from: 'snowluma' });
      }
    }
  } catch { /* ignore */ }
  if (!out.length) out.push({ base: 'http://127.0.0.1:3000', token: '', from: '默认端口' });
  const seen = new Set();
  return out.filter((x) => {
    const k = x.base + '|' + x.token;
    if (seen.has(k)) return false;
    seen.add(k);
    return true;
  });
}

async function pickEndpoint(cfg) {
  for (const t of endpointCandidates(cfg)) {
    try {
      const res = await fetch(t.base + '/get_status', {
        method: 'POST',
        headers: { 'content-type': 'application/json', ...(t.token ? { authorization: 'Bearer ' + t.token } : {}) },
        body: '{}',
        signal: AbortSignal.timeout(8000)
      });
      if (res.ok) return t;
    } catch { /* 下一个 */ }
  }
  return null;
}

async function sendTo(target, text, cfg) {
  const t = String(target || '').trim();
  const isGroup = /^group:/i.test(t);
  const id = t.replace(/^(group|private):/i, '').replace(/\D/g, '');
  if (!/^\d{5,12}$/.test(id)) throw new Error('发送目标不合法：' + target);
  const ep = await pickEndpoint(cfg);
  if (!ep) throw new Error('找不到可用的 OneBot 发送地址');
  const action = isGroup ? 'send_group_msg' : 'send_private_msg';
  const payload = isGroup
    ? { group_id: Number(id), message: [{ type: 'text', data: { text: escapeCq(text) } }] }
    : { user_id: Number(id), message: [{ type: 'text', data: { text: escapeCq(text) } }] };
  const res = await fetch(ep.base + '/' + action, {
    method: 'POST',
    headers: { 'content-type': 'application/json', ...(ep.token ? { authorization: 'Bearer ' + ep.token } : {}) },
    body: JSON.stringify(payload),
    signal: AbortSignal.timeout(60000)
  });
  if (!res.ok) throw new Error('OneBot HTTP ' + res.status);
  const j = await res.json().catch(() => null);
  if (j && j.status === 'failed') throw new Error('协议端拒绝：' + (j.message || j.wording || '未知'));
  return { ok: true, via: ep.from };
}

function pendingIds() {
  ensureDirs();
  return fs.readdirSync(INBOX).filter((f) => f.endsWith('.json')).map((f) => f.replace(/\.json$/, ''));
}

/** 原子领取：把 inbox 文件改名到 sending/。改名成功者独占，其余进程拿到 ENOENT 跳过。 */
function claim(id) {
  ensureDirs();
  const from = path.join(INBOX, id + '.json');
  const to = path.join(SENDING, id + '.' + process.pid + '.json');
  try {
    fs.renameSync(from, to);
    return to;
  } catch { return null; }
}

function release(id, claimedPath) {
  try { fs.rmSync(claimedPath, { force: true }); } catch { /* ignore */ }
  try { fs.rmSync(path.join(OUTBOX, id + '.json'), { force: true }); } catch { /* ignore */ }
}

function readRules() {
  try { return fs.readFileSync(path.join(MOM_DIR, 'rules.md'), 'utf8').slice(0, 2500); } catch { return ''; }
}

async function standInAnswer(entry) {
  const system = [
    '你是「大肥鱼的妈妈」。大肥鱼是群里的聊天机器人，遇到拿不准的事会来问你。',
    '这次她等了一会儿没等到你本人，你按自己的规矩先回一句。',
    '硬性要求：中文，最多三句话；直接给结论和下一步；不客套、不提自己是AI、不重复她的问题；',
    '不要提到文件名、日志、内部机制，不要用 markdown 记号。',
    '你的工作规则（照它办）：',
    readRules()
  ].join('\n');
  const user = [
    '大肥鱼问：' + String(entry.question || ''),
    entry.context ? '她补充：' + String(entry.context) : '',
    Array.isArray(entry.recent) && entry.recent.length ? '最近聊天：\n' + entry.recent.slice(-4).join('\n') : ''
  ].filter(Boolean).join('\n\n');
  const res = await chatCompletion({
    messages: [{ role: 'system', content: system }, { role: 'user', content: user }],
    temperature: 0.6,
    maxTokens: 400
  });
  return String(res?.message?.content ?? res?.content ?? '').trim();
}

async function tick() {
  if (ticking) return;
  ticking = true;
  try {
    const s = await settings();
    if (s.enabled === false) return;
    const cfg = await coreConfig();

    // ── 妈妈主动说话：push/ 目录里逐条发出去，发完即删（不会重发）──
    try {
      for (const f of fs.readdirSync(PUSH).filter((x) => x.endsWith('.json'))) {
        const full = path.join(PUSH, f);
        const item = readJson(full, null);
        if (!item || !String(item.text || '').trim()) { fs.rmSync(full, { force: true }); continue; }
        const held = full + '.' + process.pid + '.tmp';
        try { fs.renameSync(full, held); } catch { continue; }   // 已被别的轮询器领走
        try {
          const text = s.prefix + String(item.text).trim();
          if (s.dryRun) log('[mom-relay] 演练 push：' + text.slice(0, 60));
          else await sendTo(item.targetChat || s.targetChat, text, cfg);
          appendLog({ kind: 'push', text: String(item.text) });
        } catch (e) {
          warn('[mom-relay] push 失败：' + (e?.message ?? e));
        } finally {
          fs.rmSync(held, { force: true });
        }
      }
    } catch { /* push 目录读不了就跳过，不影响中继 */ }

    for (const id of pendingIds()) {
      const outFile = path.join(OUTBOX, id + '.json');
      const answer = readJson(outFile, null);

      if (answer && String(answer.answer || '').trim()) {
        const claimed = claim(id);
        if (!claimed) continue;                       // 别的轮询器已经领走
        try {
          if (!fs.existsSync(claimed)) continue;      // 领到即刻被清理
          const entry = readJson(claimed, {}) || {};
          const again = readJson(outFile, null);
          if (!again || !String(again.answer || '').trim()) continue;
          const text = s.prefix + String(again.answer).trim();
          if (s.dryRun) {
            log('[mom-relay] 演练：将发送 ' + text.slice(0, 60));
            appendLog({ id, kind: 'dry-run', answer: again.answer });
          } else {
            await sendTo(entry.targetChat || s.targetChat, text, cfg);
            appendLog({ id, kind: 'answered', question: entry.question, answer: again.answer, standIn: !!again.standIn, sent: true });
          }
          writeJson(path.join(DONE, id + '.json'), { ...entry, answer: again.answer, answeredAt: Date.now() });
        } catch (e) {
          warn('[mom-relay] 发送失败：' + (e?.message ?? e));
          appendLog({ id, kind: 'send-failed', error: String(e?.message ?? e) });
        } finally {
          release(id, claimed);
        }
        continue;
      }

      const entry0 = readJson(path.join(INBOX, id + '.json'), null);
      if (!entry0) continue;
      const ageSec = (Date.now() - Number(entry0.at || 0)) / 1000;

      if (s.standInEnabled !== false && !entry0.standIn && ageSec > Number(s.standInDelaySec || 40)) {
        const claimed = claim(id);
        if (!claimed) continue;
        try {
          entry0.standIn = true;
          const text = await standInAnswer(entry0);
          if (text) {
            writeJson(outFile, { answer: text, standIn: true, at: Date.now() });
            appendLog({ id, kind: 'stand-in', question: entry0.question, answer: text });
            // 放回 inbox，交给下一轮 tick 发送
            fs.renameSync(claimed, path.join(INBOX, id + '.json'));
            continue;
          }
        } catch (e) {
          warn('[mom-relay] 代班失败：' + (e?.message ?? e));
        }
        // 失败：原样放回，等下一轮
        try { fs.renameSync(claimed, path.join(INBOX, id + '.json')); } catch { /* ignore */ }
        continue;
      }

      if (ageSec / 60 > Number(s.timeoutMinutes || 1440)) {
        const claimed = claim(id);
        if (!claimed) continue;
        writeJson(path.join(DONE, id + '.json'), { ...entry0, timedOutAt: Date.now() });
        appendLog({ id, kind: 'timeout', question: entry0.question });
        fs.rmSync(claimed, { force: true });
      }
    }
  } finally {
    ticking = false;
  }
}

export function __internals() {
  return { tick, pendingIds, settings, ensureDirs, standInAnswer };
}

export async function setup(a) {
  api = a;
  const prev = globalThis[SINGLETON_KEY];
  if (prev) { try { clearInterval(prev); } catch { /* ignore */ } }
  if (timer) { try { clearInterval(timer); } catch { /* ignore */ } timer = null; }
  ensureDirs();
  const s = await settings();
  if (s.enabled === false) { log('[mom-relay] 已关闭'); return; }

  api.registerTool({
    id: 'ask_mom',
    name: '问妈妈',
    description: '把问题转交给妈妈（大肥鱼的监督者和老师）。投递后你会拿到编号；妈妈回答后，插件会自动以「我妈说：…」发到本会话。只在主人明确要求找妈妈、或你确实需要她拍板时用。',
    category: 'utility',
    icon: '👩',
    parameters: {
      type: 'object',
      properties: {
        question: { type: 'string', description: '要问妈妈的问题，写清楚背景和你已经查到的东西' },
        context: { type: 'string', description: '可选：相关聊天片段、你打算怎么回、你卡在哪' }
      },
      required: ['question']
    },
    async execute(ctx, args) {
      const s2 = await settings();
      const owner = String(s2.ownerQQ || '').replace(/\D/g, '');
      const trig = ctx?.session?.trigger?.[0] || ctx?.triggerEntries?.[0] || null;
      const senderId = String(ctx?.senderId || trig?.senderId || '');
      const senderName = String(ctx?.senderName || trig?.senderName || '');
      // 没配 ownerQQ 时不能"放行所有人"，也不能静默失败——直接挡住并说清楚怎么配。
      // （公开发布的版本里默认值是空串，这条就是给"解压后没填设置"的人看的）
      if (!owner) {
        return { ok: false, error: '还没配置：到「设置 → 技能 → 妈妈中继」填上「允许叫妈妈的 QQ」，再试一次' };
      }
      if (s2.relayOnlyOwner !== false && senderId && senderId !== owner) {
        return { ok: false, error: '只有主人可以叫妈妈' };
      }
      const id = 'm' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
      const entry = {
        id,
        at: Date.now(),
        chatKey: ctx?.chatKey || '',
        targetChat: ctx?.chatKey || s2.targetChat,
        userId: senderId,
        userName: senderName,
        question: String(args.question || '').slice(0, 2000),
        context: String(args.context || '').slice(0, 4000),
        recent: Array.isArray(ctx?.recentMessages) ? ctx.recentMessages.slice(-6) : []
      };
      writeJson(path.join(INBOX, id + '.json'), entry);
      appendLog({ id, kind: 'queued', question: entry.question });
      return { ok: true, id, notice: '已转给妈妈，回复会用「我妈说：…」发出来。编号 ' + id };
    }
  });

  api.registerTool({
    id: 'mom_check',
    name: '查妈妈回复',
    description: '查妈妈有没有回复某个提问（传编号）。也可以不传编号，列出所有在等的提问。',
    category: 'query',
    icon: '📬',
    parameters: {
      type: 'object',
      properties: { id: { type: 'string', description: '问妈妈时拿到的编号' } }
    },
    async execute(ctx, args) {
      // 跟 ask_mom 同一道门：群友不能借 mom_check 翻妈妈的回复/在等的问题。
      // 少这一道，任何人都能说"看看你妈回你没"，把主人问的私事读出来。
      const s3 = await settings();
      const owner3 = String(s3.ownerQQ || '').replace(/\D/g, '');
      const trig3 = ctx?.session?.trigger?.[0] || ctx?.triggerEntries?.[0] || null;
      const sender3 = String(ctx?.senderId || trig3?.senderId || '');
      if (s3.relayOnlyOwner !== false && owner3 && sender3 && sender3 !== owner3) {
        return { ok: false, error: '只有主人可以查妈妈的回复' };
      }
      const id = String(args.id || '').trim();
      if (!id) {
        const items = pendingIds().map((x) => {
          const e = readJson(path.join(INBOX, x + '.json'), null);
          return e ? { id: x, at: e.at, question: String(e.question).slice(0, 80) } : null;
        }).filter(Boolean);
        return { ok: true, pending: items.length, items };
      }
      const outFile = path.join(OUTBOX, id + '.json');
      const answer = readJson(outFile, null);
      if (answer) return { ok: true, status: 'answered', answer: String(answer.answer || '') };
      if (fs.existsSync(path.join(INBOX, id + '.json'))) return { ok: true, status: 'pending' };
      const done = readJson(path.join(DONE, id + '.json'), null);
      if (done) return { ok: true, status: done.answer ? 'answered' : 'closed', answer: String(done.answer || '') };
      return { ok: false, error: '没有这个编号' };
    }
  });

  timer = setInterval(() => { tick().catch(() => {}); }, Math.max(2, Number(s.pollIntervalSec) || 5) * 1000);
  globalThis[SINGLETON_KEY] = timer;
  if (typeof timer.unref === 'function') timer.unref();
  tick().catch(() => {});
  log('[mom-relay] 已加载（轮询 ' + (s.pollIntervalSec || 5) + 's，代班 ' + (s.standInEnabled !== false ? '开' : '关') + '）');
}

/**
 * 把妈妈最近的回复塞进她的提示词。
 *
 * 为什么必须这么做：中继是用**她自己的号**把「我妈说：…」发到群里的，而模型读不到自己发出去的消息
 * （core 不回灌 self 消息，防止自激）。于是妈妈明明回了，她下一轮还是「我没看到」——实测踩过两次。
 * 这个片段把最近 6 小时妈妈说过的话再喂一遍，绕开"自己发的看不见"这个坑。
 */
export function promptSections() {
  try {
    const items = fs.readdirSync(DONE)
      .filter((f) => f.endsWith('.json'))
      .map((f) => {
        const j = readJson(path.join(DONE, f), null);
        if (!j || !String(j.answer || '').trim()) return null;
        return { at: Number(j.answeredAt || 0), answer: String(j.answer).trim() };
      })
      .filter((x) => x && Date.now() - x.at < 6 * 3600 * 1000)
      .sort((a, b) => b.at - a.at)
      .slice(0, 3);
    if (!items.length) return [];
    const body = items.reverse()
      .map((x) => '· ' + new Date(x.at).toLocaleTimeString('zh-CN', { hour12: false }) + ' 妈妈说：' + x.answer)
      .join('\n');
    return [{
      id: 'mom-relay-recent-answers',
      title: '【妈妈最近对你说的话】',
      priority: 80,
      content: '这些是妈妈本人最近对你说的话（已经在群里用「我妈说：…」念过，但你自己发的消息你收不到，所以在这里再给你看一遍）：\n' + body
    }];
  } catch { return []; }
}

export function teardown() {
  if (timer) clearInterval(timer);
  timer = null;
}
