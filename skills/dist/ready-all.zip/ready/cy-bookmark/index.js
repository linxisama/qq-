// cy 收藏夹（cy-bookmark）—— 技能（LLM 型，注册工具）。
//
// ── 为什么是技能（skills/）而不是插件（plugins/）─────────────────────────────
// 「cy」这个触发词本身能写死，但真正决定这个功能成败的两件事都写不死：
//   ① 存哪条 —— 可能是紧挨着的上一条，可能是三条前那个链接，也可能是他**引用**的那条；
//      「他指的是哪个」要理解人话。
//   ② 存下来怎么描述、日后怎么找回 —— note 写得好不好直接决定以后搜不搜得到，
//      而「上次那个做吉他的视频」这种问法只能靠语义匹配。
// 插件的定义是「条件满足必跑」的确定性代码，这里没有一条能写死的规则，所以做成技能：
// 注册工具进模型的 function 列表，存哪条、怎么写、怎么找，由模型判断。
// 另外「@ + cy」本来就会唤醒机器人（1 档仅 @ 响应），不需要靠钩子抢执行权；
// 而钩子也拿不到 sender/store（before-llm-messages 的上下文里没有），发不出话。
//
// ── 数据落在哪 ──────────────────────────────────────────────────────────
//   <DATA_DIR>/cy-bookmark/bookmarks.json —— 唯一的写入点。
//   DATA_DIR 必须与 src/config.js 同口径：QQ_AGENT_DATA_DIR（electron/main.js 启动时
//   写入，安装版指向 <安装目录>/data）> QQ_AGENT_PROFILE 推导 > 默认 data/。
//   按技能目录自己推算会写进 resources/app/data/ —— 那个目录没有任何人会读。
//   （本技能目录本身是只读的发布物，自动更新会覆盖，所以状态一律不写这里。）
//
// ⚠️ 自带依赖只有 Node 内置模块；不 import 任何核心 src/ 内部文件，
//    核心改动不会把这个技能一起带崩。

import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

/* ── 位置 ────────────────────────────────────────────────────────────── */

const HERE = path.dirname(fileURLToPath(import.meta.url));
const APP_ROOT = path.resolve(HERE, '..', '..');

/** 与 src/profile.js 同源：QQ_AGENT_PROFILE=2 → 数据目录 data-2/。 */
function profileSuffix() {
  const raw = String(process.env.QQ_AGENT_PROFILE ?? '').trim();
  return /^\d+$/.test(raw) ? `-${raw}` : '';
}

const DATA_DIR = process.env.QQ_AGENT_DATA_DIR || path.join(APP_ROOT, `data${profileSuffix()}`);
const STORE_DIR = path.join(DATA_DIR, 'cy-bookmark');
const STORE_FILE = path.join(STORE_DIR, 'bookmarks.json');

/* ── 常量 ────────────────────────────────────────────────────────────── */

const MAX_NOTE = 200;
const MAX_TAGS = 8;
const MAX_STORED_TEXT = 2000;
const MAX_SEND_TEXT = 800;
const MAX_MEDIA = 9;
const MAX_OFFSET = 20;
const SCAN_LIMIT = 60;

const DEFAULT_SETTINGS = {
  maxItems: 300,
  scope: 'user',
  searchLimit: 5,
  listLimit: 10,
  allowRemove: true,
  sendOriginalText: true
};

/** 清单里每行摘要的长度上限（太长会在群里折成一大坨）。 */
const MAX_SUMMARY = 32;
const LIST_MAX = 20;

/** 清单里每行的类型图标。 */
const TYPE_ICON = { text: '📄', image: '🖼️', video: '🎬', link: '🔗', card: '🔗', mixed: '🗂️' };

/**
 * 「存一下」的意图词，两种用途：
 *   · 定位默认收藏对象（见 isInvocationOnly）—— 纯命令消息**不是**收藏对象，
 *     它的内容恰恰是"它前面那条"；
 *   · 发送前清理正文 —— 原文只剩这些词时说明它只是命令，没必要重发。
 *
 * 判定故意从严（只认整体就是一句命令的短消息），因为两种判错的代价不对等：
 *   · 漏判（把命令当内容）→ save 会以"没有可收藏的内容"报错并附上最近消息清单，
 *     模型据此重试一次即可，是**自愈**的；
 *   · 误判（把内容当命令）→ 默认会去存更早的那条，等于默默存错东西。
 * 所以宁可漏判。
 */
const COMMAND_EXACT = /^(?:cy|mark|插眼|眼|码住|记住|记一下|记下|记下来|收藏|收一下|存一下|存下|存个|保存|保存一下|留个眼|留眼|留痕|remember|save|cy列表|插眼列表|眼列表|收藏列表|收藏夹|我的收藏|查看收藏|看看眼|查眼|列表)[\s~～!！。.·]*$/i;
/** 「帮我记住这个」这类带前后缀的短命令。刻意不含 cy，避免命中英文单词里的子串。 */
const COMMAND_PHRASE = /^(?:请|帮我|帮忙|麻烦|给我)?[^，,。；;]{0,6}(?:记住|记一下|记下|收藏|存一下|存下|保存|码住|插眼|mark|remember|save)[^，,。；;]{0,4}$/i;

/** 纯占位符正文（[图片]/[表情]…）：发出去只是噪音，一律跳过。 */
const PLACEHOLDER_ONLY = /^(\s*\[(图片|表情|视频|语音|文件|转发消息|动画表情|合并转发聊天记录|卡片消息)\]\s*)+$/;

let cfg = () => ({});

/* ── 小工具 ──────────────────────────────────────────────────────────── */

const clamp = (n, lo, hi) => Math.min(hi, Math.max(lo, Math.round(Number(n) || 0)));

/** 检索用的归一化：小写 + 去空白（中文之间加不加空格都算同一个词）。 */
const normText = (s) => String(s ?? '').toLowerCase().replace(/\s+/g, '');

const clip = (s, n) => {
  const t = String(s ?? '');
  return t.length > n ? `${t.slice(0, n)}…` : t;
};

const ok = (content) => ({ content });
const err = (content) => ({ content, isError: true });

const TYPE_LABEL = {
  text: '文字', image: '图片', video: '视频', link: '链接', card: '分享卡片', mixed: '图文混合'
};
const typeLabel = (k) => TYPE_LABEL[String(k)] || String(k || '内容');

/* ── 存储 ────────────────────────────────────────────────────────────── */

// 内存缓存 + mtime 失效：既避免每次工具调用都读盘，又保证用户手改 json 后能立刻生效。
// 注意工具执行是同步读-改-写全程无 await，Node 单线程下天然不会和另一次写交叉。
let cache = null;
let cacheMtime = 0;

function readStore() {
  try {
    const st = fs.statSync(STORE_FILE);
    if (cache && st.mtimeMs === cacheMtime) return cache;
    const raw = JSON.parse(fs.readFileSync(STORE_FILE, 'utf8'));
    const items = Array.isArray(raw?.items) ? raw.items.filter((x) => x && x.id) : [];
    cache = { version: 1, seq: Number(raw?.seq) || items.length, items };
    cacheMtime = st.mtimeMs;
    return cache;
  } catch {
    // 文件不存在 / JSON 坏了：从空收藏夹开始。
    // 不抛错 —— 收藏夹读不出来不该让整个工具炸掉。
    if (cache) return cache;
    cache = { version: 1, seq: 0, items: [] };
    cacheMtime = 0;
    return cache;
  }
}

function writeStore(store) {
  const max = clamp(Number(cfg()?.maxItems) || DEFAULT_SETTINGS.maxItems, 10, 5000);
  if (store.items.length > max) {
    // 超限丢最旧的：收藏夹是"近期用得上"的东西，不是档案馆
    store.items.sort((a, b) => (b.savedAt || 0) - (a.savedAt || 0));
    store.items = store.items.slice(0, max);
  }
  fs.mkdirSync(STORE_DIR, { recursive: true });
  // 原子写：先落 .tmp 再 rename。直接覆盖时断电/崩溃会留下半个 JSON，
  // 而半截 JSON 会让 readStore 走 catch 分支 → 整个收藏夹"凭空消失"。
  const tmp = `${STORE_FILE}.tmp`;
  fs.writeFileSync(tmp, JSON.stringify(store, null, 2), 'utf8');
  fs.renameSync(tmp, STORE_FILE);
  cache = store;
  try { cacheMtime = fs.statSync(STORE_FILE).mtimeMs; } catch { cacheMtime = 0; }
}

/**
 * 这次是谁在操作（插眼的人 / 要清单的人 / 说要发哪条的人）。
 *
 * ctx 里没有现成的"触发者"字段，但有两个可靠来源：
 *   ① ctx.session.trigger —— **本次触发批**（就是唤醒这次处理的那几条未读消息），
 *      里面带 senderId 与 atMe（core 按 @ 段的 QQ 号判定，能区分同名）。最权威。
 *   ② 退路：存档里最近一条 @ 了机器人的消息。
 * 全程只认 **QQ 号**，不认昵称 —— 昵称会改也会撞，QQ 号是唯一稳定的身份锚点
 * （与核心 speaker-format / 记忆系统同一套口径）。
 *
 * @returns {{id: string, name: string}} 身份认不出来时 id 为空串（调用方必须保守处理）
 */
function currentUser(ctx) {
  const pick = (m) => ({ id: String(m.senderId || ''), name: String(m.senderName || '') });

  // ① 本次触发批里 @ 机器人的那个人 —— 最权威
  const trig = Array.isArray(ctx?.session?.trigger) ? ctx.session.trigger : [];
  for (let i = trig.length - 1; i >= 0; i -= 1) {
    const m = trig[i];
    if (m && m.atMe === true && m.senderId) return pick(m);
  }

  // ② 触发批里最后一条群友消息 —— 也就是"这次唤醒我的那句话"。
  // 走这条是为了**关键词触发**（响应档位较高时，群友不 @ 机器人、只打「cy列表」也能唤醒）：
  // 那时批里没有任何 atMe 消息，若退到"去存档里找最近 @ 过机器人的消息"，
  // 就会把**更早 @ 过的另一个人**当成这次的操作者（本机实测档位就是这么触发的）。
  // 用触发批本身作答，比翻历史可靠得多。
  for (let i = trig.length - 1; i >= 0; i -= 1) {
    const m = trig[i];
    if (m && !m.self && m.senderId) return pick(m);
  }

  // ③ 私聊：对面就是操作者（私聊不需要 @，上面两条也可能拿不到）
  if (String(ctx?.kind) === 'private' && ctx?.chatId) {
    return { id: String(ctx.chatId), name: '' };
  }

  // ④ 触发批拿不到（老版本核心 / session 里没有 trigger）：退到存档。
  // 这条退路是"尽力而为"，可能有偏差，所以放在最后。
  const list = ctx?.store?.recent?.(ctx.chatKey, { limit: 20, includeSelf: false }) || [];
  for (let i = list.length - 1; i >= 0; i -= 1) {
    const m = list[i];
    if (m && m.atMe === true && m.senderId) return pick(m);
  }
  for (let i = list.length - 1; i >= 0; i -= 1) {
    const m = list[i];
    if (m && m.atMe == null && m.senderId && mentionsBot(ctx, m)) return pick(m);
  }
  return { id: '', name: '' };
}

/**
 * 一条收藏归谁。
 * 新条目存 ownerId（**插眼的人**）；早期条目只有 senderId（内容的作者），
 * 用它兜底 —— 这样升级之前存的收藏不会凭空消失，也不用去改用户的数据文件。
 */
const ownerOf = (it) => String(it?.ownerId || it?.senderId || '');

/** 当前设置下，这个范围的说明文案（清单标题 / 搜不到时的提示都用它）。 */
function scopeLabel(ctx) {
  const scope = String(cfg()?.scope || DEFAULT_SETTINGS.scope).toLowerCase();
  if (scope === 'global') return '全部会话';
  if (scope === 'user') return '你';
  return '本群';
}

/**
 * 按设置过滤可见范围。
 *
 *   chat   （默认过去的行为）每个群各自一份 —— A 群存的不会在 B 群被搜出来
 *   user   跟着**人**走：同一个人在任何群里插的眼都能搜到（跨群），别人看不到
 *   global 所有会话共用一份
 *
 * ⚠️ user 模式下认不出身份时**退回"本群"**，而不是返回空：
 * 范围宁可小，也不能让收藏"凭空消失"（那是最难排查的一类故障）。
 */
function scopeItems(store, ctx) {
  const scope = String(cfg()?.scope || DEFAULT_SETTINGS.scope).toLowerCase();
  if (scope === 'global') return store.items;
  if (scope === 'user') {
    const me = currentUser(ctx);
    if (me.id) return store.items.filter((it) => ownerOf(it) === me.id);
  }
  return store.items.filter((it) => String(it.chatKey) === String(ctx?.chatKey));
}

/** bm-3 / 3 / #3 都认，避免模型把前缀抄丢。 */
function findItem(store, ctx, raw) {
  const key = String(raw ?? '').trim().toLowerCase().replace(/^#/, '');
  if (!key) return null;
  const pool = scopeItems(store, ctx);
  return pool.find((it) => String(it.id).toLowerCase() === key)
    || pool.find((it) => String(it.id).toLowerCase() === `bm-${key}`)
    || pool.find((it) => String(it.seq) === key)
    || null;
}

/* ── 正文处理 ────────────────────────────────────────────────────────── */

function splitTags(raw) {
  return String(raw ?? '')
    .split(/[,，、;；\s]+/)
    .map((s) => s.trim())
    .filter(Boolean)
    .slice(0, MAX_TAGS);
}

/**
 * 切开开头的引用块。[引用 张三(QQ:123)：[图片]]cy → { quote, rest }。
 *
 * 必须按**括号配对**切，不能用 /\[引用[^\]]*\]/：引用摘要本身常带方括号
 * （引用一张图就是 [图片]），正则会在图片的 `]` 上提前收尾，把 "cy" 当成引用内容。
 * 这段逻辑与 src/prompt.js 的 stripReplyBlocks 同款。
 */
function splitQuotePrefix(text) {
  const s = String(text ?? '');
  if (!s.startsWith('[引用')) return { quote: '', rest: s };
  let depth = 0;
  for (let i = 0; i < s.length; i += 1) {
    if (s[i] === '[') depth += 1;
    else if (s[i] === ']') {
      depth -= 1;
      if (depth === 0) return { quote: s.slice(1, i), rest: s.slice(i + 1).trim() };
    }
  }
  return { quote: s.slice(1), rest: '' };
}

/**
 * 剥掉 @ 标记 / CQ 码后的正文。
 *
 * ⚠️ @ 的渲染有**两种形态**，两种都必须剥掉：
 *   · 装了 speaker-identity 技能：`@昵称(QQ:123)`（由 message.inline-at-normalize 能力补）
 *   · 没装（本机实测就是这种）：`@昵称`，**没有** QQ 后缀
 * 只按带 QQ 的那一种写，会让「@机器人 cy」判不出是命令 —— 实测后果是
 * 把 "cy" 这条命令本身当成收藏对象存了下来，之后"发来"把 `@机器人 cy` 原样发进群。
 *
 * 顺带把 @ 一律去掉也是对的：重发时不该再 @ 一次别人（会误 ping 人）。
 */
function cleanBody(text) {
  return String(text ?? '')
    .replace(/@[^\s@(]*\(QQ:\d+\)/g, ' ')   // 先吃带 QQ 的形态，避免只吃掉 "@昵称" 剩个 "(QQ:1)"
    .replace(/@全体成员/g, ' ')
    .replace(/@[^\s@]+/g, ' ')              // 再吃裸 "@昵称"
    .replace(/\[CQ:[^\]]*\]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

/** 这段文字整体是不是一句「存一下」的命令（短、且只有命令语义）。 */
function isCommandText(t) {
  const s = String(t ?? '').trim();
  if (!s || s.length > 16) return false;
  return COMMAND_EXACT.test(s) || COMMAND_PHRASE.test(s);
}

/** 这条消息有没有 @ 机器人。atMe 是 core 按 @ 段 QQ 号给的权威标记（能区分同名）。 */
function mentionsBot(ctx, entry) {
  // core 已经给出明确结论时直接采信 —— 这是最可靠的来源（按 @ 段的 QQ 号判定）。
  if (entry?.atMe === true) return true;
  if (entry?.atMe === false) return false;
  // atMe 为 null（老存档没标）才退文本判断：两种 @ 形态都认。
  const t = String(entry?.text || '');
  const selfId = String(ctx?.selfId || '');
  if (selfId && t.includes(`(QQ:${selfId})`)) return true;
  return /@[^\s@]/.test(t);
}

/**
 * 这条消息是不是"纯命令"（只负责下指令，内容在别处）。
 *
 * 三个否定条件都有实际来由：
 *   · 带媒体 → 它自己就是内容（"发张图 + cy" 一条搞定）；
 *   · 带引用 → 引用里很可能才是内容，交给 recoverQuoted，绝不能当命令跳掉；
 *   · 没 @ 机器人 → 单说一句 cy 唤不醒机器人，多半是聊天里的一句话，不当命令。
 */
function isInvocationOnly(ctx, entry) {
  if (mediaOf(entry).length) return false;
  const { quote, rest } = splitQuotePrefix(entry?.text);
  if (quote) return false;
  const t = cleanBody(rest);
  if (!t) return true;                    // 只有 @、没有正文
  if (!isCommandText(t)) return false;
  return mentionsBot(ctx, entry);
}

/**
 * 这条消息是不是一条「cy」命令 —— 用于**定位锚点**（要收藏的是它上面那条）。
 *
 * 与 isInvocationOnly 的区别（这个区别是必须的）：
 *   · isInvocationOnly   问"这条消息自己有没有可收藏的内容" —— 带引用时为 false（引用里可能是内容）
 *   · isCommandAnchor    问"这条消息是不是一条插眼指令" —— 带引用时**也是** true
 *     （"引用某条 + cy" 是最常见的玩法之一，它既是命令、又自带内容载体）
 * 两者判定条件相同，只有"带引用"这一处分叉。
 */
function isCommandAnchor(ctx, entry) {
  const t = cleanBody(splitQuotePrefix(entry?.text).rest);
  if (!t) return false;                 // 只有 @、没有正文 → 不是明确的命令
  if (!isCommandText(t)) return false;
  return mentionsBot(ctx, entry);
}

/**
 * 这条消息**值得发出去**的正文。没有就返回 ''。
 * 去掉引用前缀、@ 标记、CQ 码之后，如果只剩占位符或一句「cy」，那就没必要发。
 */
function meaningfulText(text) {
  const t = cleanBody(splitQuotePrefix(text).rest);
  if (!t) return '';
  if (isCommandText(t)) return '';
  if (PLACEHOLDER_ONLY.test(t)) return '';
  return t;
}

/**
 * 卡片消息 → 适合重发的文本：一行标题 + 链接。
 *
 * 为什么需要它：QQ 小程序 / 分享卡片**没法原样重发** —— 协议端没有"再造一张卡片"的接口，
 * 卡片里的封面图也不是消息段（extractMediaFromSegments 取不到），所以存档里只剩一行文本：
 *   `[卡片消息｜标题：哔哩哔哩｜文字：【免费教学】…｜来源：（QQ小程序）…｜https://b23.tv/xxx ]`
 * 直接把这一长串方括号发出去，群里看到的就是一坨噪音。真正有用的是**里面的链接**：
 * 把标题和链接发出去，QQ 自己会把预览卡片渲染出来 —— 观感最接近"把卡片再发一次"。
 *
 * 标题优先取「文字」（B 站这类卡片的「标题」只是"哔哩哔哩"这种来源名，
 * 真正的内容标题在「文字」里）。
 */
function cardSendText(text) {
  const m = /\[卡片消息([^\]]*)\]/.exec(String(text || ''));
  if (!m) return '';
  const body = m[1];
  const field = (label) => (((new RegExp(`${label}：([^｜]*)`)).exec(body) || [])[1] || '').trim();
  const head = field('文字') || field('标题');
  // URL 字符类要排掉全角竖线，否则会把卡片字段分隔符一起吃进链接里
  const url = (/https?:\/\/[^\s｜"'\]]+/.exec(body) || [])[0] || '';
  if (!url) return head;
  if (!head || url.includes(head)) return url;
  return `${head}\n${url}`;
}

/** 重发时该发什么文本：卡片走 cardSendText，其余走普通正文清洗。 */
function sendableText(item) {
  const raw = String(item?.text || '');
  if (/\[卡片消息/.test(raw)) {
    const card = cardSendText(raw);
    if (card) return card;
  }
  return meaningfulText(raw);
}

/* ── 媒体 ────────────────────────────────────────────────────────────── */

function mediaOf(entry) {
  return (Array.isArray(entry?.media) ? entry.media : [])
    .filter((m) => m && (m.url || m.file))
    .slice(0, MAX_MEDIA)
    .map((m) => ({
      kind: String(m.kind || 'image'),
      file: String(m.file || ''),
      url: String(m.url || ''),
      summary: String(m.summary || '')
    }));
}

function mergeMedia(...lists) {
  const out = [];
  const seen = new Set();
  for (const list of lists) {
    for (const m of list || []) {
      const key = `${m.kind}|${m.url || m.file}`;
      if (seen.has(key)) continue;
      seen.add(key);
      out.push(m);
      if (out.length >= MAX_MEDIA) return out;
    }
  }
  return out;
}

/**
 * 协议端给的 file 能不能当本地路径用。
 * 三类要排除：http(s) 链接（那是 url 的活）、base64:// 内联、空值。
 * 剩下两类都留着：本进程能 stat 到的绝对路径（最理想，body 只有百来字节），
 * 以及「协议端自己数据目录里的相对文件名」—— 本进程看不到，但协议端能解析，
 * 属于该试一次的，不能因为这里判不出来就把路堵死。
 */
function usableFile(raw) {
  const s = String(raw ?? '').trim();
  if (!s) return '';
  if (/^(https?|base64):\/\//i.test(s)) return '';
  if (/^file:\/\//i.test(s)) return s;
  try { if (fs.existsSync(s)) return s; } catch { /* stat 失败按相对名处理 */ }
  if (/[\\/]/.test(s) || /\.[a-z0-9]{2,5}$/i.test(s)) return s;
  return '';
}

/**
 * 图片的候选发送方式，按"最可能成功"排序。
 *
 * ⚠️ 两个候选必须是**不同的引用形式**，不能合成 { file, url }：
 *    sendImage 的去重键是 url || file，两个字段都给就等于只认 url，
 *    于是"同一张图 8 秒内被要求发第二次"时，两个候选会撞在同一个去重键上、
 *    双双被挡，用户看到的是"图发不出来"。
 *    拆成 { file } / { url } 后，前者被去重挡住时后者能照常发出。
 */
function imageRefs(m) {
  const out = [];
  const file = usableFile(m?.file);
  const url = /^https?:\/\//i.test(String(m?.url || '')) ? String(m.url).trim() : '';
  if (file) out.push({ file });
  if (url) out.push({ url });
  return out;
}

function videoRefs(m) {
  const out = [];
  const file = usableFile(m?.file);
  const url = /^https?:\/\//i.test(String(m?.url || '')) ? String(m.url).trim() : '';
  if (file) out.push(file);
  if (url) out.push(url);
  return out;
}

/* ── 定位要收藏的那条消息 ────────────────────────────────────────────── */

/**
 * 找出"要存的那条"。
 *
 * 1) 给了 messageId → 精确取（模型从聊天记录里读到 #数字 时走这条）。
 * 2) 没给 → 从**最新一条有内容的消息**往回数 offset 条（默认 0 = 就取那一条）。
 *    定位时会先跳掉最新的一串"纯命令"消息（见 isInvocationOnly）——
 *    因为「@机器人 cy」这条命令本身不是收藏对象，它的内容是"它前面那条"。
 *    跳掉之后默认值就自然落在正确的位置上，模型不需要自己找 id：
 *      [视频, @bot cy]              → 取视频
 *      [视频, @bot cy, @bot cy]     → 取视频（连发两次也不会落到 cy 上）
 *      [引用 某人的图 + @bot cy]     → 取这一条，再靠 recoverQuoted 把图找回来
 *
 * 只取 !self 的：cy 一定是群友发的，机器人自己的消息不可能是收藏对象。
 */
function pickTarget(ctx, args) {
  const raw = args?.messageId;
  if (raw !== undefined && raw !== null && String(raw).trim() !== '') {
    const mid = String(raw).trim();
    const entry = ctx?.store?.findByMid?.(ctx.chatKey, mid);
    if (!entry) {
      return { error: `在当前会话的存档里找不到消息 #${mid}（可能太旧已被清理，或者 id 抄错了）。${recentHint(ctx)}` };
    }
    // 显式指定也要过这一关：把「cy」这条命令本身存下来是纯粹的错，而且错得**很隐蔽** ——
    // 存的当下是成功的，只有日后有人喊"发来"时，才会把 `@机器人 cy` 原样发进群（本机实测踩过）。
    if (isInvocationOnly(ctx, entry)) {
      return {
        error: `#${mid} 是那条「cy」命令本身，不是要收藏的内容 —— 要存的是它**前面**那条。`
          + `把 messageId 去掉直接重试（默认就会取到内容），或者按下面清单换一个你真正想存的目标。${recentHint(ctx)}`
      };
    }
    return { entry };
  }

  const offset = clamp(Number(args?.offset), 0, MAX_OFFSET);
  const list = ctx?.store?.recent?.(ctx.chatKey, { limit: MAX_OFFSET + 14, includeSelf: true }) || [];
  const incoming = list.filter((m) => m && !m.self).reverse();   // 新的在前

  // ── 锚点：这一批里最新的那条「cy」命令 ──────────────────────────────
  // 「插眼」的语义是"标记**我上面**那条"，所以必须**以命令为锚点往前找**，
  // 而不是"跳过命令、取最新的有内容消息"。两者只在"命令恰好是最新消息"时等价；
  // 一旦用户在 cy **之后**又补一句说明（本机实测就是这么用的：cy 之后 8 秒发"琵琶亭旅行照片"），
  // 后者会把那句说明当成收藏对象 —— 又一次静默存错。
  const cmdIdx = incoming.findIndex((m) => isCommandAnchor(ctx, m));

  if (cmdIdx >= 0) {
    const cmd = incoming[cmdIdx];
    // 引用型插眼：命令自身携带内容（"引用某条 + cy"），目标就是它自己。
    // 引用捞不回来（原文已滚出存档）就当它没有内容，继续往前找，别硬存一条空的。
    if (splitQuotePrefix(cmd.text).quote && recoverQuoted(ctx, cmd)) return { entry: cmd };

    let seen = 0;
    for (let i = cmdIdx + 1; i < incoming.length; i += 1) {
      if (isInvocationOnly(ctx, incoming[i])) continue;   // 夹在中间的其它命令不占位次
      if (seen === offset) return { entry: incoming[i] };
      seen += 1;
    }
    return {
      error: `「cy」上面没有可收藏的内容了（往回数了 ${seen} 条有内容的消息）。${recentHint(ctx)}`
    };
  }

  // 这一批里根本没有 cy 命令（模型误调、或触发方式不是插眼）：退回"取最新的有内容消息"。
  let seen = 0;
  for (let i = 0; i < incoming.length; i += 1) {
    if (isInvocationOnly(ctx, incoming[i])) continue;
    if (seen === offset) return { entry: incoming[i] };
    seen += 1;
  }
  return {
    error: '最近没有可收藏的内容（收到的最新几条都是「cy」这类只有命令、没有正文也没有图片/视频的消息）。'
      + recentHint(ctx)
  };
}

/** 失败时把最近几条连同 #id 一起给出，让模型能自己纠正重试，而不是死在同一处。 */
function recentHint(ctx) {
  try {
    const list = (ctx?.store?.recent?.(ctx.chatKey, { limit: 8, includeSelf: false }) || []).reverse();
    if (!list.length) return '当前会话没有任何群友消息。';
    const lines = list.map((m, i) => {
      const id = (m.mid !== null && m.mid !== undefined && String(m.mid) !== '') ? `#${m.mid}` : '(无id)';
      const kinds = (m.media || []).filter((x) => x && (x.url || x.file)).map((x) => x.kind);
      const body = String(m.text || '').replace(/\s+/g, ' ').slice(0, 50);
      return `  ${i + 1}. ${id} ${m.senderName || m.senderId || '?'}：${body || '(空)'}${kinds.length ? `（含${kinds.join('/')}）` : ''}`;
    });
    return `最近 8 条群友消息（新的在前，序号是往回数的位次）：\n${lines.join('\n')}\n`
      + '可以改用 offset=位次，或把某条的 #数字 当 messageId 传进来。';
  } catch {
    return '';
  }
}

/**
 * 引用型「cy」的补救：常见玩法是**引用**一条消息再发「cy」。
 *
 * 被引用的内容已经被 core 渲染进本条文本（`[引用 张三(QQ:1)：…]`），但**媒体不会**
 * 跟着过来 —— src/onebot.js 的 extractMediaFromSegments 只看本条消息自己的段。
 * 所以引用一张图时说 cy，只存本条会得到"记下了、但重发时发不出图"。
 *
 * 这里按「引用摘要里那个人的 QQ 号 + 引用文字」回存档里把原文捞出来。
 * 纯尽力而为：捞不到就当没有，绝不影响主流程；只认**时间早于本条**的消息，
 * 从新往旧找，避免匹配到好几天前碰巧同名的那条。
 */
function recoverQuoted(ctx, entry) {
  try {
    const { quote } = splitQuotePrefix(entry?.text);
    if (!quote) return null;
    const body = quote.replace(/^引用\s*/, '');
    const sep = body.indexOf('：');
    if (sep < 0) return null;
    const senderLabel = body.slice(0, sep);
    const quotedText = body.slice(sep + 1).trim();
    const qq = (/\(QQ:(\d+)\)/.exec(senderLabel) || [])[1] || '';
    const want = String(quotedText).replace(/\s+/g, ' ').trim();
    if (!want) return null;

    const list = ctx?.store?.recent?.(ctx.chatKey, { limit: SCAN_LIMIT, includeSelf: false }) || [];
    for (let i = list.length - 1; i >= 0; i -= 1) {
      const m = list[i];
      if (!m || m === entry) continue;
      if (Number(m.ts) >= Number(entry.ts)) continue;          // 只能是被引用的"更早那条"
      if (qq && String(m.senderId) !== qq) continue;           // 有 QQ 号就必须对上人
      const have = String(m.text || '').replace(/\s+/g, ' ').trim();
      if (!have) continue;
      if (have === want) return m;
      // 没拿到 QQ 号时放宽会有误伤风险，所以只认完全相等；有 QQ 号才允许包含关系。
      if (qq && (have.includes(want) || (want.length >= 6 && want.includes(have)))) return m;
    }
    return null;
  } catch {
    return null;
  }
}

/* ── 分类 / 检索 / 展示 ──────────────────────────────────────────────── */

/**
 * 按"最近存的在前"排序。seq 作次级键：同一毫秒存进去的两条也有稳定顺序
 * （清单的编号对得上，靠的就是排序稳定 + 编号永不重用）。
 */
function sortNewest(pool) {
  return [...(pool || [])].sort((a, b) => (Number(b.savedAt) || 0) - (Number(a.savedAt) || 0)
    || (Number(b.seq) || 0) - (Number(a.seq) || 0));
}

/**
 * 清单里显示的摘要。
 *
 * ⚠️ 必须把开头的"某某发的"去掉：note 是模型写的，它习惯以发送人开头
 * （"胡萝卜丝清蒸鸡腿发的照片：…"），而清单每行末尾本来就会显示发言人 ——
 * 不去掉的话，长昵称会把 32 字的摘要额度吃掉一大半，看着全是人名。
 */
function summaryOf(it) {
  const raw = String(it.note || it.text || '').replace(/\s+/g, ' ').trim();
  const who = String(it.senderName || '').trim();
  if (!who || !raw.startsWith(who)) return raw;
  // 去掉名字，再顺手去掉紧随其后的"发的 / 的了 / ："这类连接词
  const rest = raw.slice(who.length).replace(/^[发的了：:，,、\s]+/, '').trim();
  return rest || raw;   // 备注里只有名字时保留原样，别显示成空
}

/** 清单里的一行：`#7 🔗 摘要 ｜ 谁发的 10/9` */
function listRow(it) {
  const d = new Date(Number(it.savedAt) || Number(it.ts) || Date.now());
  const when = `${d.getMonth() + 1}/${d.getDate()}`;
  const icon = TYPE_ICON[it.kind] || '📄';
  const who = clip(String(it.senderName || it.senderId || '?'), 10);
  return `#${it.seq} ${icon} ${clip(summaryOf(it), MAX_SUMMARY)} ｜ ${who} ${when}`;
}

/**
 * 分页切片。清单和检索共用，保证"第几页"的口径只有一处。
 *
 * ⚠️ 传入的**必须已经排好序**，这里不再排 —— 清单要按时间倒序、检索要按相关度，
 * 两种顺序不同；如果这里自己 sortNewest 一下，检索结果的相关度排序就被冲掉了。
 * 页码越界一律夹到有效范围（群友「下一页」说多了不至于报错）。
 */
function pageSlice(sorted, limit, page) {
  const all = Array.isArray(sorted) ? sorted : [];
  const per = Math.max(1, Number(limit) || 1);
  const pages = Math.max(1, Math.ceil(all.length / per));
  const p = Math.min(Math.max(1, Math.floor(Number(page)) || 1), pages);
  return { all, per, pages, page: p, shown: all.slice((p - 1) * per, p * per) };
}

/** 标签概览：`教程(12) 图片(30)`，按条数降序，最多 max 个。 */
function tagOverview(pool, max = 8) {
  const counts = new Map();
  for (const it of pool) for (const t of it.tags || []) counts.set(t, (counts.get(t) || 0) + 1);
  return [...counts.entries()]
    .sort((a, b) => b[1] - a[1])
    .slice(0, max)
    .map(([t, n]) => `${t}(${n})`);
}

/**
 * 生成发给群友的清单文案。
 *
 * 编号用 **seq**（就是 bm-N 里的 N），不用"第1、第2"这种位次：
 * 位次会随着新插的眼整体后移，而本项目是**无状态会话**（每次处理都是新会话，
 * 模型不记得上一轮发过什么清单）—— 用户看到清单后隔一会儿回"第2个"，
 * 期间只要有人新插一条，位次就串了，会发错东西。
 * seq 单调递增、永不重用，所以「#7」永远指同一条，隔多久、中间插了多少条都不会变。
 *
 * 分页：超过一页时标题写「第 X/Y 页」，末尾提示「说『下一页』看第 X+1 页」。
 * 无状态会话下翻页照样能用 —— 机器人发的清单会进聊天存档，
 * 模型下次处理时能从【已读信息】里读到当前是第几页，照着 +1 即可。
 */
function buildListText(pool, limit, scopeLabel, page = 1, tag = '') {
  const scopeText = tag ? `${scopeLabel}「${tag}」标签下的眼` : `${scopeLabel}插的眼`;
  const { all, pages, page: p, shown } = pageSlice(sortNewest(pool), limit, page);

  if (!all.length) {
    return tag
      ? `📌 ${scopeLabel}没有打过「${tag}」标签的收藏。\n说「cy列表」可以看全部。`
      : `📌 ${scopeText}还没插过眼。\n在群里 @我 发「cy」，我就把上一条消息存进来。`;
  }

  const lines = [`📌 ${scopeText}（共 ${all.length} 条${pages > 1 ? `，第 ${p}/${pages} 页` : ''}）`];
  lines.push(...shown.map(listRow));

  const tips = [];
  if (p < pages) tips.push(`还有 ${all.length - p * shown.length} 条更早的 —— 说「下一页」看第 ${p + 1} 页`);
  if (p > 1) tips.push(`说「上一页」回到第 ${p - 1} 页`);
  // 第一页且不止一页时给标签概览：光靠翻页找东西很累，按标签缩小范围快得多
  if (p === 1 && pages > 1) {
    const ov = tagOverview(all, 8);
    if (ov.length) tips.push(`也可以按标签看：${ov.join(' ')} —— 说「看教程的」这类就行`);
  }
  if (tips.length) lines.push(...tips.map((t) => `（${t}）`));
  lines.push(`回复编号就行，比如「发 #${shown[0].seq}」`);
  return lines.join('\n');
}

function kindOf(text, media) {
  const kinds = new Set(media.map((m) => m.kind));
  if (/\[卡片消息/.test(String(text || ''))) return 'card';
  if (kinds.has('video') && kinds.has('image')) return 'mixed';
  if (kinds.has('video')) return 'video';
  if (kinds.has('image')) return 'image';
  if (media.length) return 'mixed';
  if (/https?:\/\//i.test(String(text || ''))) return 'link';
  return 'text';
}

/**
 * 打分检索。
 * note 权重最高 —— 它是模型专门为"日后检索"写的一句话；
 * 原文次之（用户可能记得原话），发言人再次（"张三发的那条"）。
 */
function scoreItem(item, q) {
  if (!q) return 1;
  const note = normText(item.note);
  const tags = normText((item.tags || []).join(''));
  const text = normText(item.text);
  const who = normText(item.senderName);
  let score = 0;
  if (note === q) score += 100;
  else if (note.includes(q)) score += 60;
  if (tags.includes(q)) score += 45;
  if (who.includes(q)) score += 35;
  if (text.includes(q)) score += 25;

  // 兜底：中文口语常把关键词散在长句里（「那个做吉他的」）。逐字覆盖率够高也算命中，
  // 但只给低分，保证排在精确命中之后。
  if (!score && q.length >= 2) {
    const chars = [...new Set([...q])].filter((c) => /[\u4e00-\u9fa5a-z0-9]/.test(c));
    if (chars.length >= 2) {
      const hay = `${note}${tags}${text}${who}`;
      const hits = chars.filter((c) => hay.includes(c)).length;
      if (hits / chars.length >= 0.7) score += 12;
    }
  }
  return score;
}

function formatItem(it) {
  const d = new Date(Number(it.ts) || Number(it.savedAt) || Date.now());
  const date = `${d.getFullYear()}/${d.getMonth() + 1}/${d.getDate()}`;
  const kinds = (it.media || []).map((m) => m.kind);
  const lines = [
    `${it.id} ｜ ${typeLabel(it.kind)}${kinds.length ? `（${kinds.join('/')}×${kinds.length}）` : ''} ｜ ${date} ${it.senderName || it.senderId || '?'}`,
    `    存的是：${it.note}`
  ];
  if (it.tags?.length) lines.push(`    标签：${it.tags.join('、')}`);
  const preview = String(it.text || '').replace(/\s+/g, ' ').trim().slice(0, 60);
  if (preview) lines.push(`    原文：${preview}`);
  return lines.join('\n');
}

function tagsInUse(pool) {
  const counts = new Map();
  for (const it of pool) for (const t of it.tags || []) counts.set(t, (counts.get(t) || 0) + 1);
  return [...counts.entries()].sort((a, b) => b[1] - a[1]).slice(0, 20).map(([t]) => t);
}

/** 搜不到时的回话素材：现有条数 + 常用标签，让模型能换个说法再搜一次。 */
function fallbackHint(pool) {
  if (!pool.length) return '这个收藏夹还是空的 —— 还没人插过眼。';
  const tags = tagsInUse(pool);
  return `收藏夹里一共有 ${pool.length} 条`
    + (tags.length ? `，常用标签：${tags.join('、')}。` : '。')
    + '可以换个更贴近内容的说法（主题词 / 谁发的 / 类型）再搜一次。';
}

/* ── 发送 ────────────────────────────────────────────────────────────── */

function markSent(ctx, type, text) {
  try {
    ctx.session?.sent?.push({ type, text, at: new Date().toLocaleTimeString('zh-CN', { hour12: false }) });
    if (ctx.session?.id) ctx.emit?.('session-update', ctx.session.id);
  } catch { /* 留档失败不影响已经发出去的消息 */ }
}

async function sendImageRef(ctx, item, m) {
  const refs = imageRefs(m);
  if (!refs.length) {
    throw new Error('这条收藏里的图片既没有能用的本地文件、也没有 http 链接（协议端给的地址通常几小时后就失效）');
  }
  let firstErr = null;
  for (const ref of refs) {
    try {
      await ctx.sender.sendImage(ctx.chatKey, ref, { note: m.summary || String(item.note || '').slice(0, 20) });
      markSent(ctx, 'image', `[图片:${String(item.note || '').slice(0, 40)}]`);
      return;
    } catch (error) {
      if (!firstErr) firstErr = error;
    }
  }
  throw firstErr;
}

async function sendVideoRef(ctx, item, m) {
  const refs = videoRefs(m);
  if (!refs.length) {
    throw new Error('这条收藏里的视频既没有能用的本地文件、也没有 http 链接（协议端给的地址通常几小时后就失效）');
  }
  let firstErr = null;
  for (let i = 0; i < refs.length; i += 1) {
    try {
      await ctx.sender.sendMedia(ctx.chatKey, [{ type: 'video', data: { file: refs[i] } }], {
        label: `[视频:${String(item.note || '收藏').slice(0, 20)}]`,
        dedupeKey: `${item.id}:video:${i}`
      });
      markSent(ctx, 'media', `[视频:${String(item.note || '').slice(0, 40)}]`);
      return;
    } catch (error) {
      if (!firstErr) firstErr = error;
    }
  }
  throw firstErr;
}

/**
 * 把一条收藏发到当前会话（永远只发当前会话 —— 与核心"工具天然绑定会话"的边界一致）。
 * 返回结构化结果：哪部分成功、哪部分失败、失败原因，交给调用方拼成人话。
 */
async function sendItem(ctx, item) {
  const c = cfg() || {};
  const done = [];
  const failed = [];

  const text = sendableText(item);
  if (c.sendOriginalText !== false && text) {
    try {
      await ctx.sender.sendTextBatch(ctx.chatKey, [clip(text, MAX_SEND_TEXT)], {});
      markSent(ctx, 'text', text);
      done.push('文字');
    } catch (error) {
      failed.push({ what: '文字', error: error?.message ?? error });
    }
  }

  const media = Array.isArray(item.media) ? item.media : [];
  for (const m of media) {
    if (m.kind === 'image') {
      try { await sendImageRef(ctx, item, m); done.push('图片'); }
      catch (error) { failed.push({ what: '图片', error: error?.message ?? error, url: m.url }); }
    } else if (m.kind === 'video') {
      try { await sendVideoRef(ctx, item, m); done.push('视频'); }
      catch (error) { failed.push({ what: '视频', error: error?.message ?? error, url: m.url }); }
    }
  }

  const unsupported = media.filter((m) => m.kind !== 'image' && m.kind !== 'video').map((m) => m.kind);
  return { done, failed, unsupported };
}

/* ── 入口 ────────────────────────────────────────────────────────────── */

export function setup(api) {
  cfg = api.config;

  /* ── 收藏 ── */
  api.registerTool({
    id: 'save',
    name: '收藏这条消息（插眼）',
    description: '把当前会话里的一条消息存进收藏夹，跨运行长期保留。用在群里有人 @ 你并说「cy」「插眼」「眼」「记住」「记一下」「收藏」「存一下」的时候 —— 他要的是把**他前面那条消息**存起来。'
      + '默认不用传 messageId 直接调即可：会以那条「cy」命令为锚点，取它**上面**那条有内容的消息。'
      + '所以即使他在 cy 之后又补了一句说明（很常见），也不会存错成那句说明。'
      + '只有当默认取错了（比如他指的是更早的那条）才需要传 offset 或 messageId 重试；报错信息里会带最近消息的 #id 清单。'
      + 'note 是必填，也是这个工具最重要的参数：写成一句「日后能靠它找回来」的话（什么内容、谁发的、什么类型），例如「张三发的赛博朋克电吉他DIY视频（B站）」。'
      + '对同一条消息重复插眼是**安全**的：只会把它的备注/标签更新掉，不会变成两条；想改备注就直接再调一次，'
      + '**不要**先删掉再存（删了之后万一存失败就真没了）。'
      + '存好回一句自然的短话确认（「眼已插👌」），不要念 bm 编号、不要报工具名。',
    category: 'memory',
    icon: '🔖',
    parameters: {
      type: 'object',
      properties: {
        note: { type: 'string', description: '必填。一句话说明这条收藏是什么（内容主题 / 谁发的 / 类型），日后就靠它检索。别写「一条消息」这种没信息量的话。' },
        messageId: { type: ['string', 'integer'], description: '要收藏的那条消息的 id（聊天记录里的 #数字）。仅当默认取错、而你能从聊天记录确认是哪条时才传。' },
        offset: { type: ['number', 'string'], description: '不传 messageId 时用：从「cy」那条命令往上数第几条有内容的消息，0=紧挨着它上面那条（默认，推荐），1=再往上一条，以此类推。' },
        tags: { type: 'string', description: '可选：标签，逗号分隔，例如「教程,视频,B站」' },
        force: { type: 'boolean', description: '可选：同一条消息已经收藏过时是否再存一份（默认 false，会直接返回已有的那条）' }
      },
      required: ['note']
    },
    async execute(ctx, args) {
      try {
        const note = String(args?.note ?? '').trim().slice(0, MAX_NOTE);
        if (!note) {
          return err('缺少 note，没有存。note 是日后找回这条收藏的唯一线索：用一句话写清「这是什么内容、谁发的、什么主题/类型」，然后重试。');
        }
        if (!ctx?.store || !ctx?.sender) return err('当前上下文缺少存档或发送能力，存不了。');

        const picked = pickTarget(ctx, args);
        if (picked.error) return err(picked.error);
        const entry = picked.entry;

        const store = readStore();

        // 同一条重复插眼：**就地更新**，绝不新增第二条、也不要让模型走"删掉重存"。
        //
        // 为什么必须是"更新"而不是"回一句已存在"：
        // 无状态会话下，"照片 + cy + 补一句说明"这种连发很常见，而每条补充说明都会触发
        // 一次新处理 —— 模型于是会反复 save 同一条；且它常常第一次备注写得泛
        // （"…发的图片"），看懂内容后又想写准（"瀑布风景照…"）。
        // 早期版本对重复只回一句"已经在收藏夹里了"，实测把模型带偏了：它以为没存上，
        // 接着 search → remove → 换个姿势再 save（本机 21:29 那次会话就是这么走的）。
        // 那条路径有真实风险 —— **remove 成功、save 失败就真丢了**。
        // 现在重复 save 一律落到"更新备注/标签"，想改只需再调一次，不必删。
        if (!args?.force && entry.mid !== null && entry.mid !== undefined && String(entry.mid) !== '') {
          const dup = scopeItems(store, ctx).find((it) => String(it.messageId) === String(entry.mid));
          if (dup) {
            const nextTags = splitTags(args?.tags);
            const noteChanged = note !== dup.note;
            const tagsChanged = nextTags.length > 0
              && JSON.stringify(nextTags) !== JSON.stringify(dup.tags || []);
            if (!noteChanged && !tagsChanged) {
              return ok(`这条消息已经在收藏夹里了：${dup.id}（${typeLabel(dup.kind)}）｜${dup.note}\n`
                + '这次给的备注和已有的一模一样，什么都没改。回一句自然的确认话即可，不用念 bm 编号。');
            }
            const snapshot = { note: dup.note, tags: [...(dup.tags || [])] };
            dup.note = note;
            if (nextTags.length) dup.tags = nextTags;
            try {
              writeStore(store);
            } catch (error) {
              dup.note = snapshot.note;      // 写盘失败就还原，别让内存和磁盘不一致
              dup.tags = snapshot.tags;
              return err(`更新收藏备注失败：${error?.message ?? error}`);
            }
            return ok(`这条消息之前就收藏过（${dup.id}），已把备注更新为：${dup.note}\n`
              + '（同一条消息只会有一条收藏，重复插眼＝改备注。**不要再删掉重存**，也不用新增第二条。）\n'
              + '回一句自然的确认话即可。');
          }
        }

        const quoted = recoverQuoted(ctx, entry);
        const media = mergeMedia(mediaOf(entry), quoted ? mediaOf(quoted) : []);
        // 正文存在哪：优先自己那条；自己只剩命令/占位符时用**被引用**那条的正文
        //（"引用一条纯文字消息 + cy" 时正文只存在于引用里，不这样处理会存不下来）。
        const ownBody = sendableText({ text: entry.text });
        const quotedBody = quoted ? sendableText({ text: quoted.text }) : '';
        const text = clip(ownBody ? entry.text : (quotedBody ? quoted.text : entry.text), MAX_STORED_TEXT);
        if (!media.length && !ownBody && !quotedBody) {
          return err(`这条消息里没有可收藏的内容（既没有文字也没有图片/视频）。${recentHint(ctx)}`);
        }

        const seq = (Number(store.seq) || 0) + 1;
        store.seq = seq;
        const me = currentUser(ctx);
        const item = {
          id: `bm-${seq}`,
          seq,
          chatKey: String(ctx.chatKey || ''),
          messageId: (entry.mid !== null && entry.mid !== undefined) ? String(entry.mid) : '',
          // 内容的作者
          senderId: String(entry.senderId || ''),
          senderName: String(entry.senderName || ''),
          // 收藏归谁：**插眼的那个人**，不是内容的作者。
          // 张三发图、李四 @ 你 cy —— 这条该归李四（他才是想记住的人）。
          // 认不出身份时留空，由 ownerOf 回退到 senderId，老数据也照常能用。
          ownerId: me.id || '',
          ownerName: me.name || '',
          ts: Number(entry.ts) || Date.now(),
          savedAt: Date.now(),
          kind: kindOf(text, media),
          note,
          tags: splitTags(args?.tags),
          text,
          media,
          quotedFrom: quoted
            ? {
              messageId: (quoted.mid !== null && quoted.mid !== undefined) ? String(quoted.mid) : '',
              senderName: String(quoted.senderName || ''),
              text: clip(quoted.text, MAX_STORED_TEXT)
            }
            : null
        };
        store.items.push(item);

        try {
          writeStore(store);
        } catch (error) {
          // 回滚内存里的这一条：写盘失败还留着的话，下一个工具调用会以为它已经存好了
          store.items = store.items.filter((x) => x.id !== item.id);
          return err(`写入收藏夹失败：${error?.message ?? error}（文件：${STORE_FILE}）`);
        }

        const pieces = [
          `已收藏 ${item.id}（${typeLabel(item.kind)}）：${item.note}`,
          `来源：${item.senderName || item.senderId || '未知'}`
            + (media.length ? `，含 ${media.length} 个媒体（${media.map((m) => m.kind).join('/')}）` : '，纯文字')
            + (quoted ? '，内容取自他引用的那条消息' : ''),
          `本群收藏夹现有 ${scopeItems(store, ctx).length} 条。`,
          '（回话时用一句自然的短话确认即可，例如「眼已插👌」；不要念 bm 编号、不要报工具名。）'
        ];
        return ok(pieces.join('\n'));
      } catch (error) {
        return err(`收藏失败：${error?.message ?? error}`);
      }
    }
  });

  /* ── 查 ── */
  api.registerTool({
    id: 'search',
    name: '查收藏夹',
    description: '在收藏夹里找以前存过的东西。用在有人问「上次那个xx」「之前那条链接」「你存的那张图」「插的眼呢」的时候。'
      + 'query 填关键词或一句话描述（主题词 / 谁发的 / 类型都行）；留空则列出最近收藏的几条。'
      + '拿到结果后把某条的 id 传给 cy-bookmark__send 就能发到群里。找到多条时把有哪几条讲清楚让用户挑，不要自己替他选。'
      + '⚠️ 如果对方只是想"看看都存了什么"、要一张能挑的清单（说「cy列表」「收藏列表」「看看眼」这类），'
      + '用 cy-bookmark__list（它会自己把清单发到群里），不要用本工具代发。',
    category: 'memory',
    icon: '🔍',
    parameters: {
      type: 'object',
      properties: {
        query: { type: 'string', description: '要找什么：主题词、描述、或者谁发的。例如「吉他」「上次那个视频」「张三」。留空 = 列出最近的收藏。' },
        sender: { type: 'string', description: '可选：只看某个人存的/发的（名字或 QQ 号）' },
        limit: { type: ['number', 'string'], description: '可选：每页几条，1~20，默认用设置里的值（5）' },
        page: { type: ['number', 'string'], description: '可选：第几页，从 1 开始（默认 1）。命中很多条、需要继续看时传 page+1。' }
      }
    },
    async execute(ctx, args) {
      try {
        const c = cfg() || {};
        const q = normText(args?.query ?? '');
        const limit = clamp(Number(args?.limit) || Number(c.searchLimit) || DEFAULT_SETTINGS.searchLimit, 1, 20);
        const store = readStore();
        let pool = scopeItems(store, ctx);

        if (args?.sender !== undefined && String(args.sender).trim() !== '') {
          const sw = normText(args.sender);
          const sid = String(args.sender).trim();
          pool = pool.filter((it) => normText(it.senderName).includes(sw) || String(it.senderId) === sid);
        }

        // 先排出**完整**结果（清单按时间倒序、检索按相关度），再分页 ——
        // 光看前 N 条就丢掉其余的话，收藏一多就永远够不着更早的了。
        const ranked = !q
          ? sortNewest(pool)
          : pool
            .map((it) => ({ it, score: scoreItem(it, q) }))
            .filter((x) => x.score > 0)
            .sort((a, b) => b.score - a.score || (b.it.savedAt || 0) - (a.it.savedAt || 0))
            .map((x) => x.it);

        if (!ranked.length) {
          const label = scopeLabel(ctx);
          return ok(`收藏夹（${label}的范围）里没找到${q ? `和「${args.query}」相关的` : ''}条目。\n${fallbackHint(pool)}`);
        }

        const page = Math.max(1, clamp(Number(args?.page) || 1, 1, 9999));
        const slice = pageSlice(ranked, limit, page);
        const body = slice.shown.map(formatItem).join('\n');
        const head = q ? `找到 ${ranked.length} 条` : `最近收藏的 ${ranked.length} 条`;
        const pageNote = slice.pages > 1 ? `（第 ${slice.page}/${slice.pages} 页，每页 ${slice.per} 条）` : '';
        const moreNote = slice.page < slice.pages
          ? `\n（还有 ${ranked.length - slice.page * slice.per} 条匹配 —— 要看更多就把 page=${slice.page + 1} 再搜一次；`
            + '或者给群友一句更具体的话，缩小范围。）'
          : '';
        return ok(`${head}${pageNote}：\n${body}${moreNote}\n\n`
          + '要把哪条发出去，就用 cy-bookmark__send 传它的 id（如 bm-3）。'
          + '对方要的是「发出来看看」，不是「念一遍」—— 搜到就直接发，别只把描述打出来。');
      } catch (error) {
        return err(`查收藏夹失败：${error?.message ?? error}`);
      }
    }
  });

  /* ── 列清单（直接把清单发到群里让群友挑）── */
  api.registerTool({
    id: 'list',
    name: '把收藏清单发到群里',
    description: '把最近收藏的东西列成一张清单**直接发到当前会话**，让群友看着挑。'
      + '用在有人 @ 你并说「cy列表」「插眼列表」「眼列表」「收藏列表」「收藏夹」「我的收藏」「看看眼」「查眼」的时候。'
      + '⚠️ 清单由本工具**自己发出**，你不需要也不能再发第二遍、不要复述清单内容。'
      + '清单里每条带 #编号；群友接着说「发 5」「第2个」「#6」时，把清单里对应的编号传给 cy-bookmark__send 的 id。'
      + '收藏多于一页时清单标题会写「第 X/Y 页」：群友说「下一页」「还有呢」就把 page 传成 X+1（当前页码在聊天记录里那张清单上能看到）；'
      + '说「看教程的」「只看图片」这类就带 tag。标题和末尾的提示是本工具自动生成的，照着念就会很自然。'
      + '不要用这个工具回答"上次那个xx"这类具体问题 —— 那种用 cy-bookmark__search。',
    category: 'memory',
    icon: '📋',
    parameters: {
      type: 'object',
      properties: {
        limit: { type: ['number', 'string'], description: '可选：每页几条，1~20，默认用设置里的值（10）' },
        page: { type: ['number', 'string'], description: '可选：第几页，从 1 开始（默认 1）。群友说「下一页」「还有呢」时传当前页码 +1。' },
        tag: { type: 'string', description: '可选：只看某个标签的条目，例如「教程」「图片」「B站」。群友说「看教程的」这类时用它。' }
      }
    },
    async execute(ctx, args) {
      try {
        if (!ctx?.sender) return err('当前上下文拿不到发送能力，发不出去。');
        const c = cfg() || {};
        const limit = clamp(Number(args?.limit) || Number(c.listLimit) || DEFAULT_SETTINGS.listLimit, 1, LIST_MAX);
        const page = Math.max(1, clamp(Number(args?.page) || 1, 1, 9999));
        const tag = String(args?.tag ?? '').trim().slice(0, 24);
        const pool = scopeItems(readStore(), ctx);
        const filtered = tag
          ? pool.filter((it) => (it.tags || []).some((t) => {
            const nt = normText(t);
            const q = normText(tag);
            return nt && (nt === q || nt.includes(q) || q.includes(nt));
          }))
          : pool;
        const label = scopeLabel(ctx);
        const text = buildListText(filtered, limit, label, page, tag);

        try {
          await ctx.sender.sendTextBatch(ctx.chatKey, [text], {});
          markSent(ctx, 'text', text);
        } catch (error) {
          const m = String(error?.message ?? error);
          // 发送管道有 8 秒内容去重（防模型刷屏）。连点两次清单会撞上它 ——
          // 这不是故障，如实说明，别让它以为发失败了反复重试。
          if (/刚刚发过|已跳过/.test(m)) {
            return err('这份清单刚刚已经发过一次了（发送去重挡住了短时间内完全相同的内容）。'
              + '不要再重发同一份清单；如果群友还要看，过几秒再说，或者先把这份清单的内容当作已经发过了。');
          }
          return err(`发清单失败：${m}`);
        }

        // 清单已经发出去了。这里把**编号对照**也给模型一份 ——
        // 群友下一句"第2个"要能对上号（无状态会话里，模型不会记得清单内容）。
        // 刻意给的是紧凑对照而不是完整清单文案，降低"照着再发一遍"的概率。
        const slice = pageSlice(sortNewest(filtered), limit, page);
        const rows = slice.shown.map((it) => `#${it.seq} ${clip(String(it.note || ''), 24)}`);
        return ok(`已把清单发到本群（**不要再发一遍**）。`
          + `这${slice.pages > 1 ? `是第 ${slice.page}/${slice.pages} 页，` : ''}覆盖 ${slice.shown.length} 条。\n`
          + (rows.length ? `编号对照（供你理解群友说的「第2个」指的是哪条）：\n${rows.join('\n')}\n` : '')
          + (slice.page < slice.pages
            ? `群友说「下一页」时，把 page=${slice.page + 1} 再调一次本工具（tag=${tag || '（不传）'}）。\n`
            : '已经到最后一页了，再有人要也没有更早的了。\n')
          + '群友说「发 6」「#6」「第2个」时，把对应编号传给 cy-bookmark__send 的 id。');
      } catch (error) {
        return err(`列清单失败：${error?.message ?? error}`);
      }
    }
  });

  /* ── 发 ── */
  api.registerTool({
    id: 'send',
    name: '把收藏发到群里',
    description: '按 id 把收藏夹里的某一条重新发到当前会话：文字照发，图片/视频按原样重发。'
      + '用在查到了、对方说「发出来看看」的时候。id 来自 cy-bookmark__search 或 cy-bookmark__list 的结果 —— '
      + '清单里「#7」这种编号就直接传 7（也认 bm-7）。'
      + '只能发到当前会话，发不到别的群。'
      + '⚠️ 分享卡片/小程序卡片**没法原样重发**（协议端不支持再造一张卡片），会发成「标题 + 链接」——'
      + '链接发出去 QQ 会自己渲染预览卡片，观感接近原样。这种情况要如实告诉对方"卡片发不了、链接给你"，不要假装卡片发出去了。',
    category: 'memory',
    icon: '📤',
    parameters: {
      type: 'object',
      properties: {
        id: { type: 'string', description: '要发的那条收藏的 id，例如 bm-3（search 结果里的编号）' }
      },
      required: ['id']
    },
    async execute(ctx, args) {
      try {
        const id = String(args?.id ?? '').trim();
        if (!id) return err('缺少 id：先用 cy-bookmark__search 找到要发的那条，再把它的编号传进来。');
        if (!ctx?.sender) return err('当前上下文拿不到发送能力，发不出去。');

        const store = readStore();
        const item = findItem(store, ctx, id);
        if (!item) {
          const pool = scopeItems(store, ctx);
          return err(`收藏夹里没有 ${id}。${fallbackHint(pool)}`);
        }

        const r = await sendItem(ctx, item);

        const lines = [];
        if (r.done.length) lines.push(`已把 ${item.id} 发到本群：${r.done.join('、')}。`);
        if (r.failed.length) {
          for (const f of r.failed) {
            lines.push(`${f.what}没发出去：${f.error}`
              + (f.url ? `（原链接：${f.url}，可以直接把链接发给他）` : ''));
          }
        }
        if (r.unsupported.length) {
          lines.push(`这条里还有 ${[...new Set(r.unsupported)].join('、')} 类型的媒体没法原样重发，`
            + '如果原文里有链接，就把它作为文字发出去。');
        }
        if (!lines.length) lines.push(`${item.id} 里没有可发送的正文或媒体（原文只是占位符）。`);
        lines.push('（不要向群友描述"我正在调用工具/我从收藏夹里找"；就像随手把东西再发一次那样自然。）');
        return ok(lines.join('\n'));
      } catch (error) {
        return err(`发送失败：${error?.message ?? error}`);
      }
    }
  });

  /* ── 删 ── */
  api.registerTool({
    id: 'remove',
    name: '删除收藏',
    description: '按 id 从收藏夹里删掉一条。只在用户明确说「删了那个」「不用记了」的时候用；先 cy-bookmark__search 或 cy-bookmark__list 确认是哪条再删，不要凭印象删。'
      + '⚠️ **不要为了改备注/改标签而删除重存** —— 想改备注直接再调一次 cy-bookmark__save 就会更新那一条；'
      + '删掉之后如果重新保存失败，东西就真的没了。',
    category: 'memory',
    icon: '🗑️',
    parameters: {
      type: 'object',
      properties: {
        id: { type: 'string', description: '要删掉的收藏 id，例如 bm-3' }
      },
      required: ['id']
    },
    async execute(ctx, args) {
      try {
        const c = cfg() || {};
        if (c.allowRemove === false) {
          return err('当前设置不允许机器人删除收藏（设置 → 技能 → cy 收藏夹 → 「允许机器人删除收藏」是关的），请让用户自己在控制台处理。');
        }
        const id = String(args?.id ?? '').trim();
        if (!id) return err('缺少 id：先用 cy-bookmark__search 确认要删的是哪一条。');

        const store = readStore();
        const item = findItem(store, ctx, id);
        if (!item) return err(`收藏夹里没有 ${id}，没删任何东西。${fallbackHint(scopeItems(store, ctx))}`);

        store.items = store.items.filter((x) => x !== item);
        try {
          writeStore(store);
        } catch (error) {
          store.items.push(item);   // 写盘失败就当没删过
          return err(`删除写入失败：${error?.message ?? error}`);
        }
        return ok(`已删除 ${item.id}（${typeLabel(item.kind)}）：${item.note}\n`
          + `本群收藏夹还剩 ${scopeItems(store, ctx).length} 条。（回一句自然的确认话即可，不用念编号。）`);
      } catch (error) {
        return err(`删除失败：${error?.message ?? error}`);
      }
    }
  });
}

/** 无外部依赖（不需要 Key / 二进制 / 特定模型），永远可用。 */
export function available() {
  return { ok: true };
}

/** 自测用：不注册工具，直接调这些函数即可（store 相关需要自己造 ctx）。 */
export const internals = {
  readStore,
  writeStore,
  scopeItems,
  scopeLabel,
  ownerOf,
  currentUser,
  findItem,
  pickTarget,
  recentHint,
  recoverQuoted,
  splitQuotePrefix,
  cleanBody,
  isCommandText,
  isInvocationOnly,
  isCommandAnchor,
  mentionsBot,
  meaningfulText,
  cardSendText,
  sendableText,
  mediaOf,
  mergeMedia,
  imageRefs,
  videoRefs,
  usableFile,
  kindOf,
  scoreItem,
  formatItem,
  sortNewest,
  listRow,
  summaryOf,
  pageSlice,
  tagOverview,
  buildListText,
  splitTags,
  paths: { DATA_DIR, STORE_DIR, STORE_FILE }
};
