/**
 * dfttk —— 三角洲行动「改枪码」推荐（烽火地带 / sol）
 *
 * ── 数据从哪来 ─────────────────────────────────────────────────────────
 *   https://dfttk.com/data/recommendations/loadouts.json
 *   （这是推荐页自己加载的那个文件；不在 /data/v3/manifest.json 里，所以容易漏）
 *   实测字段（2026-10-19 抓取，846 个方案 / 68 把枪）：
 *     id / weaponId / weaponName / name / code(改枪码) / mode / author / price /
 *     image / panels{damage,armorDamage,rpm,range,recoil,handling,stability,hipfire} /
 *     partItemIds / unmappedPartIds / partsComplete / applyNum / likeNum
 *   846 个方案的 code **全部唯一**（命名有 22 个重复，所以身份只能认 code）。
 *
 * ── 地图口径：为什么是我们自己算的 ─────────────────────────────────────
 *   站点页面有一排地图标签（航天基地/零号大坝/巴克什/潮汐监狱/AZ3），但 2026-10-20
 *   用真浏览器逐个点击实测：卡片内容完全不变、不产生任何新请求、标签也不高亮；
 *   而且 loadouts.json 里**没有地图字段**。结论：站点的地图筛选没做完。
 *   所以这里按"交火距离"给 panels 加权（室内近战偏腰射/操控、中远对枪偏射程/后座），
 *   回复里会明确注明这是本插件的口径，不冒充站点官方分类。
 *
 * ── 安全边界 ───────────────────────────────────────────────────────────
 *   · 只读 GET，只允许 dfttk.com 一个域名
 *   · 拿不到数据就如实说拿不到，绝不用记忆里的枪械数据凑数
 */
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
// ⚠️ 子模块必须用「带 cache-buster 的动态 import」：
//    应用的技能加载器只给入口 index.js 加 `?t=…`，静态 import 的 calc.js 会被 Node 的 ESM 缓存
//    永久保留 —— 结果是改了 calc.js 也不生效（实测：pipe 修复加载进应用后仍报 WebSocket is not defined）。
//    改成动态 import 之后，每次热更新都会拿到最新代码。
let calcMod = null;
async function loadCalc() {
  if (!calcMod) calcMod = await import(`./calc.js?v=${Date.now()}`);
  return calcMod;
}

const SOURCE = 'https://dfttk.com/data/recommendations/loadouts.json';
const ALLOWED_HOST = 'dfttk.com';
const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36';
const WAN = 10000;

/** 地图 → 交火距离口径。值是我们自己的加权，不是站点数据。 */
const MAP_PROFILES = {
  零号大坝: { label: '室内近战', weights: { hipfire: 3, handling: 2, stability: 1 } },
  巴克什: { label: '室内近战', weights: { hipfire: 3, handling: 2, stability: 1 } },
  潮汐监狱: { label: '室内近战', weights: { hipfire: 3, handling: 2, stability: 1 } },
  航天基地: { label: '中远对枪', weights: { range: 3, recoil: 2, stability: 1 } },
  AZ3: { label: '中远对枪', weights: { range: 3, recoil: 2, stability: 1 } },
  近战: { label: '室内近战', weights: { hipfire: 3, handling: 2, stability: 1 } },
  室内: { label: '室内近战', weights: { hipfire: 3, handling: 2, stability: 1 } },
  中远: { label: '中远对枪', weights: { range: 3, recoil: 2, stability: 1 } },
  远: { label: '中远对枪', weights: { range: 3, recoil: 2, stability: 1 } }
};

let api = null;
let cfg = () => ({});
let cache = null;                 // { solutions, fetchedAt, stale? }
const recent = new Map();         // chatKey → [code, ...]（只留最近 5 个，防连续重复）

function log(...args) {
  try { api?.log?.(...args); } catch { /* ignore */ }
}
function warn(...args) {
  try { api?.warn?.(...args); } catch { /* ignore */ }
}

function settings() {
  return { ...{ refreshHours: 6, topPercent: 30, defaultCount: 1 }, ...(cfg() || {}) };
}

function dataDir() {
  const base = String(process.env.QQ_AGENT_DATA_DIR || '').trim() || path.join(os.tmpdir(), 'qq-agent-data');
  return path.join(base, 'dfttk');
}
const cacheFile = () => path.join(dataDir(), 'loadouts-sol.json');

// ── 数据层 ────────────────────────────────────────────────────────────

/** 拿数据：缓存新鲜就用缓存，否则重抓；重抓失败退回旧缓存。 */
async function ensureData(force = false) {
  if (!force && cache) return cache;
  const cf = cacheFile();
  const hours = Math.max(1, Number(settings().refreshHours) || 6);

  if (!force && fs.existsSync(cf)) {
    try {
      const ageH = (Date.now() - fs.statSync(cf).mtimeMs) / 3600000;
      if (ageH < hours) {
        const j = JSON.parse(fs.readFileSync(cf, 'utf8'));
        cache = { solutions: j.solutions || [], fetchedAt: j.fetchedAt || '' };
        return cache;
      }
    } catch { /* 缓存坏了就走网络 */ }
  }

  const url = new URL(SOURCE);
  if (url.hostname !== ALLOWED_HOST) return { error: `数据源域名不在白名单：${url.hostname}` };

  try {
    const ctl = new AbortController();
    const timer = setTimeout(() => ctl.abort(), 20000);
    const res = await fetch(SOURCE, {
      headers: { 'user-agent': UA, accept: 'application/json' },
      signal: ctl.signal
    });
    clearTimeout(timer);
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const j = await res.json();
    const solutions = (j.solutions || []).filter((s) => s && s.code && s.weaponName);
    if (!solutions.length) throw new Error('数据里没有可用方案');
    fs.mkdirSync(dataDir(), { recursive: true });
    fs.writeFileSync(cf, JSON.stringify({ fetchedAt: j.fetchedAt || '', solutions }), 'utf8');
    cache = { solutions, fetchedAt: j.fetchedAt || '' };
    log(`[dfttk] 数据已更新：${solutions.length} 个方案（${j.fetchedAt || '时间未知'}）`);
    return cache;
  } catch (e) {
    const reason = e?.name === 'AbortError' ? '请求超时' : String(e?.message ?? e);
    if (fs.existsSync(cf)) {
      try {
        const j = JSON.parse(fs.readFileSync(cf, 'utf8'));
        cache = { solutions: j.solutions || [], fetchedAt: j.fetchedAt || '', stale: true };
        warn(`[dfttk] 更新失败（${reason}），改用旧缓存（${cache.solutions.length} 个方案）`);
        return cache;
      } catch { /* ignore */ }
    }
    return { error: `拿不到改枪数据：${reason}` };
  }
}

// ── 条件解析 ──────────────────────────────────────────────────────────

/** 价位文本 → {min,max,label}（单位：元）。认 "15-35万" / "15万到35万" / "35万以上" / "60万以内" / "35" */
function parseBudget(text) {
  const t = String(text ?? '').replace(/[,，\s]/g, '').replace(/万/g, 'w');
  if (!t) return null;
  const num = (s) => Number(String(s).replace(/w$/, '')) * WAN;

  const range = /(\d+(?:\.\d+)?)w?\D{0,3}[~\-至到]\D{0,3}(\d+(?:\.\d+)?)w?/.exec(t);
  if (range) {
    const a = num(range[1]), b = num(range[2]);
    return { min: Math.min(a, b), max: Math.max(a, b), label: `${range[1]}~${range[2]}万` };
  }
  const above = /(\d+(?:\.\d+)?)w?\D{0,2}(以上|往上|起|\+)/.exec(t);
  if (above) return { min: num(above[1]), max: Infinity, label: `${above[1]}万以上` };
  const below = /(\d+(?:\.\d+)?)w?\D{0,2}(以内|以下|不到|之内)/.exec(t);
  if (below) return { min: 0, max: num(below[1]), label: `${below[1]}万以内` };
  const single = /(\d+(?:\.\d+)?)w?/.exec(t);
  if (single) return { min: 0, max: num(single[1]), label: `${single[1]}万以内` };
  return null;
}

/** 地图文本 → {key,label,weights}；认地图名，也认"近战/中远"。 */
function resolveMap(text) {
  const t = String(text ?? '').trim();
  if (!t) return null;
  for (const key of Object.keys(MAP_PROFILES)) {
    if (t.includes(key)) return { key, ...MAP_PROFILES[key] };
  }
  return null;
}

/** 常见叫法 → 数据里的枪名前缀（数据里的名字带枪种后缀，如 "M4A1突击步枪"）。 */
const WEAPON_ALIASES = { '95式': 'qbz95', '95-1': 'qbz95', 'm4': 'm4a1', 'scar': 'scar-h', 'ak47': 'akm' };

/** 去掉枪种后缀："M4A1突击步枪" → "M4A1"。 */
function stripTypeSuffix(name) {
  return String(name || '').replace(
    /(突击步枪|战斗步枪|射手步枪|精确射手步枪|狙击步枪|冲锋枪|轻机枪|通用机枪|霰弹枪|左轮|杠杆式步枪|复合弓|手枪)$/,
    ''
  );
}

/**
 * 按名字找枪（用户可能说 "M4A1"、"m4"、"95式"，而数据里是 "M4A1突击步枪"）。
 * 返回 { matches:[weaponName...], picked?:weaponName, hint?:string }
 */
function findWeapons(solutions, text) {
  const q0 = String(text ?? '').trim();
  if (!q0) return { matches: [] };
  const norm = (s) => String(s || '').toLowerCase().replace(/\s+/g, '');
  const q = norm(q0);
  const names = [...new Set(solutions.map((s) => s.weaponName).filter(Boolean))];
  const aliased = WEAPON_ALIASES[q] || q;

  let hits = names.filter((n) => norm(n) === q || norm(n) === aliased);
  if (!hits.length) hits = names.filter((n) => norm(stripTypeSuffix(n)) === q || norm(stripTypeSuffix(n)) === aliased);
  if (!hits.length && q.length >= 2) {
    hits = names.filter((n) => norm(n).includes(q) || norm(stripTypeSuffix(n)).includes(q));
  }
  if (!hits.length && aliased !== q && aliased.length >= 3) {
    hits = names.filter((n) => norm(n).includes(aliased));
  }
  return { matches: hits };
}

/** 按口径给方案打分（0~100 量级的面板均值，权重加权）。 */
function scoreSolution(s, profile) {
  const p = s?.panels || {};
  let sum = 0;
  let wsum = 0;
  for (const [k, w] of Object.entries(profile.weights)) {
    const v = Number(p[k]);
    if (Number.isFinite(v)) { sum += v * w; wsum += w; }
  }
  return wsum ? sum / wsum : 0;
}

// ── 浏览/筛选（枪种、描述词、热门/冷门、价位排行、提供者）─────────────────

/** 枪种关键词 → weaponName 里的后缀。 */
const WEAPON_CLASSES = ['突击步枪', '战斗步枪', '精确射手步枪', '射手步枪', '狙击步枪', '冲锋枪', '通用机枪', '轻机枪', '霰弹枪', '手枪', '左轮', '复合弓', '杠杆式步枪'];

function resolveClass(text) {
  const t = String(text ?? '').trim();
  if (!t) return '';
  if (WEAPON_CLASSES.includes(t)) return t;
  const alias = {
    突击: '突击步枪', 战斗: '战斗步枪', 精确射手: '精确射手步枪', 射手: '射手步枪',
    狙: '狙击步枪', 狙击: '狙击步枪', 冲锋: '冲锋枪', 机枪: '通用机枪',
    喷子: '霰弹枪', 霰弹: '霰弹枪', 手枪: '手枪', 左轮: '左轮'
  };
  if (alias[t]) return alias[t];
  const hit = WEAPON_CLASSES.find((c) => c.includes(t) || t.includes(c));
  return hit || t;
}

/** 排序方式。 */
function resolveSort(text) {
  const t = String(text ?? '').trim().toLowerCase();
  if (!t) return null;
  if (/热门|最火|hot|使用多|常用/.test(t)) return { key: 'hot', label: '使用次数（热门）', cmp: (a, b) => (Number(b.applyNum) || 0) - (Number(a.applyNum) || 0) };
  if (/冷门|小众|cold|用得少/.test(t)) return { key: 'cold', label: '使用次数（冷门）', cmp: (a, b) => (Number(a.applyNum) || 0) - (Number(b.applyNum) || 0) };
  if (/贵|最高价|expensive/.test(t)) return { key: 'expensive', label: '价格从高到低', cmp: (a, b) => (Number(b.price) || 0) - (Number(a.price) || 0) };
  if (/便宜|最低价|cheap/.test(t)) return { key: 'cheap', label: '价格从低到高', cmp: (a, b) => (Number(a.price) || 0) - (Number(b.price) || 0) };
  if (/点赞|like|好评/.test(t)) return { key: 'like', label: '点赞数', cmp: (a, b) => (Number(b.likeNum) || 0) - (Number(a.likeNum) || 0) };
  return null;
}

/** 按枪种/描述词/提供者/价位筛，再按指定方式排序，取前 N 套。 */
function browse({ solutions, cls, keyword, author, sort, budget, limit = 5 }) {
  let pool = solutions;
  if (cls) pool = pool.filter((s) => String(s.weaponName || '').includes(cls));
  if (keyword) {
    const k = String(keyword).toLowerCase();
    pool = pool.filter((s) => String(s.name || '').toLowerCase().includes(k));
  }
  if (author) pool = pool.filter((s) => String(s.author || '').includes(String(author)));
  if (budget) {
    pool = pool.filter((s) => {
      const p = Number(s.price);
      return Number.isFinite(p) && p >= budget.min && p <= budget.max;
    });
  }
  const cmp = sort?.cmp || ((a, b) => (Number(b.applyNum) || 0) - (Number(a.applyNum) || 0));
  const n = Math.max(1, Math.min(10, limit));
  return { list: pool.slice().sort(cmp).slice(0, n), poolSize: pool.length };
}

// ── 其它数据源（全枪排行 / 配件库）────────────────────────────────────────

const DATA_BASE = 'https://dfttk.com/data/v3/';
const ATTR_CN = {
  effectiveRange: '有效射程', recoilControl: '后坐力控制', waistAccuracy: '腰射精度',
  handling: '操控', stability: '稳定性', fireRate: '射速', internalAttribute0: '（内部属性）'
};

/** 带本地缓存地取一个 JSON；网络失败退回旧缓存。 */
async function fetchJsonCached(url, filename, hours = null) {
  const dir = dataDir();
  const file = path.join(dir, filename);
  const maxAge = Math.max(1, Number(hours) || Number(settings().refreshHours) || 6) * 3600000;
  if (fs.existsSync(file)) {
    try {
      if (Date.now() - fs.statSync(file).mtimeMs < maxAge) return JSON.parse(fs.readFileSync(file, 'utf8'));
    } catch { /* 走网络 */ }
  }
  try {
    const ctl = new AbortController();
    const timer = setTimeout(() => ctl.abort(), 45000);
    const res = await fetch(url, { headers: { 'user-agent': UA, accept: 'application/json' }, signal: ctl.signal });
    clearTimeout(timer);
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const j = await res.json();
    fs.mkdirSync(dir, { recursive: true });
    fs.writeFileSync(file, JSON.stringify(j), 'utf8');
    return j;
  } catch (e) {
    try { return JSON.parse(fs.readFileSync(file, 'utf8')); } catch {
      throw new Error(`拿不到数据（${filename}）：${e?.message ?? e}`);
    }
  }
}

/** 排行索引 + 指定场景明细。 */
async function ensureRanking(scenarioId = '') {
  const idx = await fetchJsonCached(DATA_BASE + 'rankings/firefight/index.json', 'ranking-index.json');
  const scenarios = idx.scenarios || [];
  if (!scenarios.length) throw new Error('站点没有排行场景');
  const sc = scenarios.find((s) => s.id === scenarioId)
    || scenarios.find((s) => s.id === 'armor-3-ammo-3-default')
    || scenarios[0];
  const detail = await fetchJsonCached(DATA_BASE + sc.file, `ranking-${sc.id}.json`);
  return { idx, sc, detail };
}

/** 在一组 (距离, BTK) 采样点里求指定距离的值：能插值就线性插值（站点每把枪只有 0m/5x m 两个点）。 */
function btkAt(samples, distance) {
  const pts = (samples || [])
    .map(([d, v]) => [Number(d), Number(v)])
    .filter(([d, v]) => Number.isFinite(d) && Number.isFinite(v))
    .sort((a, b) => a[0] - b[0]);
  if (!pts.length) return null;
  const first = pts[0];
  const last = pts[pts.length - 1];
  if (distance <= first[0]) return { btk: first[1], at: first[0], interpolated: false };
  if (distance >= last[0]) return { btk: last[1], at: last[0], interpolated: false };
  for (let i = 1; i < pts.length; i++) {
    const [d0, v0] = pts[i - 1];
    const [d1, v1] = pts[i];
    if (distance <= d1) {
      const t = (distance - d0) / (d1 - d0 || 1);
      return { btk: v0 + (v1 - v0) * t, at: distance, interpolated: true };
    }
  }
  return { btk: last[1], at: last[0], interpolated: false };
}

/** 全枪 BTK 排行：候选按"某一距离的期望击杀弹数"升序（越小越强）。 */
async function rankByBtk({ scenarioId = '', distance = 30, limit = 10, cls = '' } = {}) {
  const { idx, sc, detail } = await ensureRanking(scenarioId);
  // 站点排行里的枪名是短名（"M4A1"），要用改枪库里的全名（"M4A1突击步枪"）才能按枪种筛
  const data = await ensureData();
  const nameById = new Map();
  if (!data.error) {
    for (const s of data.solutions || []) {
      if (s.weaponId) nameById.set(String(s.weaponId), s.weaponName);
    }
  }
  const cand = new Map();
  for (const p of idx.catalog?.profiles || []) {
    const full = nameById.get(String(p.weaponId)) || p.name;
    for (const c of p.candidates || []) {
      cand.set(c.candidateId, { name: full, shortName: p.name, weaponId: p.weaponId, ammo: c.ammoName, level: c.ammoLevel });
    }
  }
  const rows = [];
  const allNames = [];
  for (const [cid, samples] of detail.candidateMetrics || []) {
    const meta = cand.get(cid);
    if (!meta) continue;
    allNames.push(meta.name);
    if (cls && !String(meta.name).includes(cls)) continue;
    const t = btkAt(samples, distance);
    if (!t) continue;
    rows.push({ ...meta, btk: t.btk, interpolated: t.interpolated });
  }
  rows.sort((a, b) => a.btk - b.btk);
  // 这个排行里实际有哪些枪种（提示用）
  const presentClasses = [...new Set(allNames.map((n) => WEAPON_CLASSES.find((c) => String(n).includes(c)) || '其他'))];
  return {
    scenario: sc,
    total: rows.length,
    rows: rows.slice(0, Math.max(1, Math.min(30, limit))),
    distance,
    presentClasses,
    hitProb: sc.probability?.summary || ''
  };
}

/** 配件 itemId → {name, category}（给智能改枪翻译配件清单与精校用）。 */
async function partNameResolver() {
  try {
    const lib = await fetchJsonCached(DATA_BASE + 'library/sol.json', 'library-sol.json');
    const parts = lib.parts || {};
    return (id) => {
      const p = parts[String(id)];
      return p ? { name: p.name || '', category: p.category || '' } : { name: '', category: '' };
    };
  } catch {
    return () => ({ name: '', category: '' });
  }
}

/** 配件效果查询：名字模糊搜，把 effects 里的 DisplayAttrValues.N 翻成中文属性。 */
async function partEffects({ name } = {}) {
  const q = String(name ?? '').trim();
  if (!q) return { error: '没给配件名' };
  const lib = await fetchJsonCached(DATA_BASE + 'library/sol.json', 'library-sol.json');
  const common = await fetchJsonCached(DATA_BASE + 'common.json', 'common.json');
  const attrs = common.mainAttributes || {};
  const parts = lib.parts || {};
  const hits = Object.values(parts).filter((p) => String(p.name || '').includes(q)).slice(0, 3);
  if (!hits.length) {
    const names = Object.values(parts).map((p) => p.name).filter(Boolean);
    return { error: `没找到配件「${q}」。库里共 ${names.length} 个配件，例如：${names.slice(0, 10).join('、')}` };
  }
  const fmt = (p) => {
    const ops = [];
    for (const blk of p.effects || []) {
      for (const op of blk?.data?.operations || []) {
        const m = /^DisplayAttrValues\.(\d+)$/.exec(String(op.target || ''));
        if (!m) continue;
        const meta = attrs[m[1]];
        if (!meta || meta.visibility === 'internal') continue;
        const cn = ATTR_CN[meta.key] || meta.key;
        const v = Number(op.value);
        if (!Number.isFinite(v) || v === 0) continue;
        if (op.modifier === 'Mult_A') ops.push(`${cn} ×${(1 + v).toFixed(2)}`);
        else if (op.modifier === 'Addend') ops.push(`${cn} ${v > 0 ? '+' : ''}${v}`);
        else if (op.modifier === 'Mult_B') ops.push(`${cn} ＋${v}%`);
        else ops.push(`${cn} ${op.modifier} ${v}`);
      }
    }
    return ops.length ? [...new Set(ops)].slice(0, 8).join(' · ') : '（这个配件不改面板属性）';
  };
  return {
    parts: hits.map((p) => ({
      name: p.name,
      category: p.category,
      rarity: p.rarity,
      weapons: (p.weaponIds || []).length,
      effects: fmt(p)
    }))
  };
}

// ── 挑选 ──────────────────────────────────────────────────────────────

function pick({ solutions, budget, map, chatKey = 'default', count = 1 }) {
  let pool = solutions;
  if (budget) {
    pool = pool.filter((s) => {
      const p = Number(s.price);
      return Number.isFinite(p) && p >= budget.min && p <= budget.max;
    });
  }
  if (!pool.length) return { error: `这个条件下没有方案${budget ? `（${budget.label}）` : ''}` };

  if (map) {
    const ranked = pool
      .map((s) => ({ s, score: scoreSolution(s, map) }))
      .sort((a, b) => b.score - a.score);
    const pct = Math.min(100, Math.max(5, Number(settings().topPercent) || 30));
    const topN = Math.max(1, Math.ceil(ranked.length * (pct / 100)));
    pool = ranked.slice(0, topN).map((x) => x.s);
  }

  // 防连续重复：优先挑最近没推过的
  const used = new Set(recent.get(chatKey) || []);
  const fresh = pool.filter((s) => !used.has(s.code));
  const from = fresh.length ? fresh : pool;

  const bag = [...from];
  const out = [];
  const n = Math.min(Math.max(1, count), bag.length);
  while (out.length < n) {
    out.push(bag.splice(Math.floor(Math.random() * bag.length), 1)[0]);
  }
  const r = recent.get(chatKey) || [];
  for (const s of out) r.push(s.code);
  recent.set(chatKey, r.slice(-5));
  return { solutions: out, poolSize: pool.length };
}

// ── 输出 ──────────────────────────────────────────────────────────────

const wan = (n) => `${(Number(n) / WAN).toFixed(1)}万`;
const cnt = (n) => {
  const v = Number(n);
  if (!Number.isFinite(v)) return '未知';
  return v >= WAN ? `${(v / WAN).toFixed(1)}万` : String(v);
};

/** 提供者（= 站点 author 字段）→ 他一共提供了多少套方案。 */
function authorSummary(solutions) {
  const m = new Map();
  for (const s of solutions) {
    const k = String(s.author || '').trim() || '未知';
    m.set(k, (m.get(k) || 0) + 1);
  }
  return m;
}

function formatSolution(s, counts = null) {
  const p = s.panels || {};
  const author = String(s.author || '').trim() || '未知';
  const n = counts?.get(author);
  const byline = `${author}${n > 1 ? `（共 ${n} 套）` : ''}`;
  return [
    `方案名：${s.name}`,
    `武器：${s.weaponName} ｜ 价格：${wan(s.price)}`,
    `面板：射程${p.range ?? '?'} 后座${p.recoil ?? '?'} 操控${p.handling ?? '?'} 稳定${p.stability ?? '?'} 腰射${p.hipfire ?? '?'}`,
    `提供者：${byline} ｜ 配件 ${(s.partItemIds || []).length} 件 ｜ 已用 ${cnt(s.applyNum)}`,
    `改枪码：${s.code}`
  ].join('\n');
}

// ── 工具本体 ──────────────────────────────────────────────────────────

async function runTool(ctx, args = {}) {
  const data = await ensureData();
  if (data.error) {
    return { content: `读取失败：${data.error}。过一会儿再问一次就行。`, isError: true };
  }

  // ── 指定枪名 ──
  // · 只给枪名          → 这把枪**所有**方案（按使用次数排序）
  // · 枪名 + 价位/地图  → "给我配一套 XX 万的 XX" → 只挑 1 套（价位过滤后取最常用的几套里随机）
  const weaponText = args?.weapon ?? args?.枪 ?? args?.枪械 ?? args?.weaponName ?? args?.name;
  if (weaponText) {
    const found = findWeapons(data.solutions, weaponText);
    if (!found.matches.length) {
      const all = [...new Set(data.solutions.map((s) => s.weaponName))].sort();
      return {
        content: `没找到「${weaponText}」这把枪。数据里有 ${all.length} 把，可以试试：${all.slice(0, 14).join('、')}${all.length > 14 ? ' …' : ''}`,
        isError: true
      };
    }
    // 匹配到多把时（如 "AK" → AKM / AK-12），按方案数取最多的那把，并提示其它
    const byName = new Map();
    for (const s of data.solutions) {
      if (!found.matches.includes(s.weaponName)) continue;
      if (!byName.has(s.weaponName)) byName.set(s.weaponName, []);
      byName.get(s.weaponName).push(s);
    }
    const ranked = [...byName.entries()].sort((a, b) => b[1].length - a[1].length);
    const [gunName, list] = ranked[0];
    const counts = authorSummary(data.solutions);
    const when = String(data.fetchedAt || '').slice(0, 19).replace('T', ' ');
    const budget = parseBudget(args?.budget ?? args?.价位 ?? args?.价格);
    const map = resolveMap(args?.map ?? args?.地图);

    let pool = list.slice().sort((a, b) => (Number(b.applyNum) || 0) - (Number(a.applyNum) || 0));
    if (budget) pool = pool.filter((s) => Number(s.price) >= budget.min && Number(s.price) <= budget.max);

    // 带条件 = 要"配一套"
    if (budget || map) {
      if (!pool.length) {
        const prices = list.map((s) => Number(s.price)).filter(Number.isFinite);
        return {
          content: `「${gunName}」在 ${budget ? budget.label : map.key} 这个条件下没有现成方案。`
            + `它有 ${list.length} 套，价格从 ${wan(Math.min(...prices))} 到 ${wan(Math.max(...prices))}。换个价位试试？`,
          isError: true
        };
      }
      const top = pool.slice(0, Math.min(5, pool.length));
      const pickOne = top[Math.floor(Math.random() * top.length)];
      return {
        content: [
          `【${gunName}】按要求配了一套${budget ? `（价位 ${budget.label}）` : ''}${map ? `（${map.key} · ${map.label}口径）` : ''}，共 ${pool.length} 套符合条件`,
          '',
          formatSolution(pickOne, counts),
          '',
          `（数据 dfttk.com${when ? `，站点数据 ${when}` : ''}；要这套枪的全部 ${pool.length} 套就直接说「${gunName} 的所有改枪码」）`
        ].join('\n')
      };
    }

    const lines = pool.map((s, i) => {
      const p = s.panels || {};
      const author = String(s.author || '').trim() || '未知';
      const n = counts.get(author);
      const who = `${author}${n > 1 ? `（共${n}套）` : ''}`;
      return `${i + 1}. ${s.name} ｜ ${wan(s.price)} ｜ 射${p.range ?? '?'} 后座${p.recoil ?? '?'} 操${p.handling ?? '?'} 稳${p.stability ?? '?'} 腰${p.hipfire ?? '?'} ｜ 提供者 ${who} ｜ 已用${cnt(s.applyNum)}\n   改枪码：${s.code}`;
    });
    const others = ranked.slice(1).map(([n, v]) => `${n}（${v.length}套）`);
    return {
      content: [
        `【${gunName}】共 ${lines.length} 套改枪方案（按使用次数排序）`,
        '',
        lines.join('\n'),
        '',
        `（数据 dfttk.com${when ? `，站点数据 ${when}` : ''}${data.stale ? '，⚠️ 本次用的是旧缓存' : ''}）`,
        ...(others.length ? [`还想看：${others.join('、')} —— 说具体枪名就行`] : []),
        '【回复群友时请把每一套的「方案名 / 提供者 / 改枪码」都带上，不要只发码】'
      ].join('\n')
    };
  }

  // ── 浏览模式：枪种 / 描述词 / 提供者 / 排序（热门冷门、价位排行）──
  const clsText = args?.class ?? args?.枪种 ?? args?.类型;
  const kwText = args?.keyword ?? args?.描述 ?? args?.关键词;
  const sortText = args?.sort ?? args?.排序;
  const authorText = args?.author ?? args?.提供者;
  if (clsText || kwText || sortText || authorText) {
    const cls = resolveClass(clsText);
    const sort = resolveSort(sortText);
    const budget0 = parseBudget(args?.budget ?? args?.价位 ?? args?.价格);
    const limit = Math.min(10, Math.max(1, Math.round(Number(args?.count) || 5)));
    const r = browse({ solutions: data.solutions, cls, keyword: kwText, author: authorText, sort, budget: budget0, limit });
    const cond = [cls && `枪种 ${cls}`, kwText && `描述含「${kwText}」`, authorText && `提供者 ${authorText}`, budget0 && `价位 ${budget0.label}`].filter(Boolean).join(' · ');
    if (!r.poolSize) {
      return { content: `没找到符合条件的方案${cond ? `（${cond}）` : ''}。换个条件试试？`, isError: true };
    }
    const countsB = authorSummary(data.solutions);
    const whenB = String(data.fetchedAt || '').slice(0, 19).replace('T', ' ');
    return {
      content: [
        `【三角洲 · 烽火地带】${cond || '全部方案'} ｜ 按${sort?.label || '使用次数'}排序`,
        `共 ${r.poolSize} 套符合，列出前 ${r.list.length} 套：`,
        '',
        ...r.list.map((s) => formatSolution(s, countsB)),
        '',
        `（数据 dfttk.com${whenB ? `，站点数据 ${whenB}` : ''}）`,
        '【回复群友时请把「方案名 / 提供者 / 改枪码」三样都带上，不要只发码】'
      ].join('\n')
    };
  }

  const budget = parseBudget(args?.budget ?? args?.价位 ?? args?.价格);
  const map = resolveMap(args?.map ?? args?.地图);
  const want = Math.min(3, Math.max(1, Math.round(Number(args?.count) || Number(settings().defaultCount) || 1)));
  const picked = pick({ solutions: data.solutions, budget, map, chatKey: ctx?.chatKey || 'default', count: want });
  if (picked.error) return { content: `没找到符合条件的方案：${picked.error}`, isError: true };

  const headBits = ['三角洲 · 烽火地带'];
  if (budget) headBits.push(`价位 ${budget.label}`);
  if (map) headBits.push(`${map.key}（按${map.label}口径）`);
  const counts = authorSummary(data.solutions);
  const blocks = picked.solutions.map((s) => formatSolution(s, counts));
  const when = String(data.fetchedAt || '').slice(0, 19).replace('T', ' ');
  const tail = [
    `（数据 dfttk.com，候选 ${picked.poolSize} 套${when ? `，站点数据 ${when}` : ''}${data.stale ? '，⚠️ 本次用的是旧缓存' : ''}）`
  ];
  if (map) {
    tail.push(`口径说明：站点没有地图分类（它的地图标签点了没反应），这里是按「${map.label}」给面板加权筛出来的，不是站点官方分类。`);
  }
  tail.push('【回复群友时请把「方案名 / 提供者 / 改枪码」三样都带上，不要只发码】');
  return { content: [`【${headBits.join(' · ')}】`, ...blocks, tail.join('\n')].join('\n\n') };
}

export function setup(skillApi) {
  api = skillApi;
  cfg = skillApi.config;
  skillApi.registerTool({
    id: 'recommend',
    name: '推荐三角洲改枪',
    description:
      '【三角洲改枪码】从 dfttk.com 的烽火地带改枪方案库拿现成方案，直接给出能复制进游戏的改枪码。'
      + '\n触发关键词：改枪码、改枪、推荐把枪、推一把、来个改枪、怎么改、配一套（现成的）、XX的改枪码、XX的改法、什么枪好用、价位/预算、地图（大坝/巴克什/潮汐监狱/航天基地/AZ3）。'
      + '\n行为：'
      + '① 只给枪名（如"配一套 40万 M4A1"里的 M4A1）= 带价位过滤后只挑 1 套；'
      + '② 只给枪名不给条件 = 返回该枪全部方案（按使用次数排序）；'
      + '③ 什么都不给 = 随机 1 套；'
      + '④ 可按价位（15-35万 / 35万以上 / 60万以内）和地图筛选。'
      + '\n每套都带：方案名（描述词，如「56W高射速K437」）、武器、价格、五项面板（射程/后座/操控/稳定/腰射）、提供者（站点 author + 他共提供多少套）、配件数、使用次数、改枪码。'
      + '\n⚠️ 转述给群友时，**必须把「方案名 / 提供者 / 改枪码」一起发**，不要只发码。'
      + '\n⚠️ 分工：本工具只给**站点现成的方案**。如果用户说「自己写 / 定制 / 自己配 / 自己搭 / DIY / 从零配 / 按预算算一套」，那要用 **builder（智能改枪）**，不要用本工具。',
    category: 'utility',
    icon: '🔫',
    parameters: {
      type: 'object',
      properties: {
        weapon: { type: 'string', description: '枪名，例如 "M4A1"、"AKM"、"95式"；填了就返回这把枪的全部改枪码（配 budget 则只挑 1 套）' },
        budget: { type: 'string', description: '价位区间，例如 "15-35万"、"35万以上"、"60万以内"；不填=不限价位' },
        map: { type: 'string', description: '地图名（零号大坝/巴克什/潮汐监狱/航天基地/AZ3）或 "近战"/"中远"；不填=不按地图筛' },
        count: { type: 'integer', description: '要几套：随机模式 1~3（默认1）；浏览模式 1~10（默认5）' },
        class: { type: 'string', description: '枪种筛选：突击步枪 / 战斗步枪 / 射手步枪 / 狙击步枪 / 冲锋枪 / 轻机枪 / 通用机枪 / 霰弹枪 / 手枪（也认"突击""狙""冲锋""机枪""喷子"）' },
        keyword: { type: 'string', description: '按描述词搜索方案名，例如 "高射速"、"腰射"、"满改"、"性价比"、"全距离"' },
        author: { type: 'string', description: '按提供者筛选，例如 "洋洋"、"羊驼"、"杨齐家"' },
        sort: { type: 'string', description: '浏览模式的排序：热门/最常用、冷门、便宜/价格从低到高、贵/价格从高到低、点赞' }
      },
      required: []
    },
    async execute(ctx, args) {
      return runTool(ctx, args);
    }
  });

  skillApi.registerTool({
    id: 'calc',
    name: '三角洲配枪计算',
    description:
      '【三角洲配枪计算 / TTK】调 dfttk 网站自己的智能配枪计算器（它没有 HTTP 接口，只能开无头浏览器调页面里的 window.DFTTK_AI），按"枪 + 距离"算出期望 TTK、期望击杀弹数、TTK 分布。'
      + '\n触发关键词（命中任意一个就用这个工具）：算TTK、TTK、配枪计算、伤害计算、打几枪、几枪死、几枪打死、多少秒打死、期望TTK、帮我算一下、算算、对比一下、30米、50米这种"枪+距离"的说法。'
      + '\n⚠️ 需要启动浏览器，通常 3~10 秒；单次计算上限 7 分钟、总时限 8 分钟，超时自动取消并如实告知失败。'
      + '\n只在用户要"算伤害/TTK/对比"时用；纯要改枪码请用 recommend 工具。',
    category: 'utility',
    icon: '🧮',
    parameters: {
      type: 'object',
      properties: {
        weapon: { type: 'string', description: '枪名，如 "M4A1"' },
        distance: { type: 'integer', description: '交火距离（米），默认 30' },
        ammo: { type: 'string', description: '弹药 itemId（可选，留空用站点默认弹药；要指定弹药就让用户在话里说清弹种）' },
        compareWith: { type: 'string', description: '要对比的另一把枪名（如 "M4A1" 对 "AKM" 就填 "AKM"）；填了就返回两/多把枪同距离的 TTK 对比' }
      },
      required: ['weapon']
    },
    async execute(ctx, args) {
      const t0 = Date.now();
      const { compareOnSite, calculateOnSite, DEFAULT_TOTAL_MS } = await loadCalc();
      const compareWith = String(args?.compareWith ?? args?.对比 ?? '').trim();
      const secs = () => Math.round((Date.now() - t0) / 1000);

      if (compareWith) {
        const names = [args?.weapon, compareWith].map((x) => String(x ?? '').trim()).filter(Boolean);
        log(`[dfttk] 开始两枪对比：${names.join(' vs ')} @ ${args?.distance ?? 30}m`);
        const r = await compareOnSite({
          weapons: names,
          distance: args?.distance ?? 30,
          timeoutMs: DEFAULT_TOTAL_MS,
          log: (m) => log(m)
        });
        if (!r.ok) {
          warn(`[dfttk] 对比失败（${secs()}s）：${r.reason}`);
          return { content: `对比失败${r.timedOut ? '（超时已取消）' : ''}：${r.reason}。用了 ${secs()} 秒。`, isError: true };
        }
        return { content: `${r.text}\n\n（由 dfttk.com 页面里的计算器完成，用时 ${secs()} 秒）` };
      }

      log(`[dfttk] 开始配枪计算：${args?.weapon} @ ${args?.distance ?? 30}m`);
      const r = await calculateOnSite({
        weapon: args?.weapon,
        distance: args?.distance ?? 30,
        ammo: args?.ammo ?? '',
        timeoutMs: DEFAULT_TOTAL_MS,
        browserExe: '',
        log: (m) => log(m)
      });
      if (!r.ok) {
        warn(`[dfttk] 配枪失败（${secs()}s）：${r.reason}`);
        return {
          content: `配枪失败${r.timedOut ? '（超时已取消）' : ''}：${r.reason}。用了 ${secs()} 秒。可以稍后重试，或者先用"推荐三角洲改枪"直接拿一套现成改枪码。`,
          isError: true
        };
      }
      return { content: `${r.text}\n\n（计算由 dfttk.com 页面里的计算器完成，用时 ${secs()} 秒）` };
    }
  });

  // ── 全枪 BTK 排行（站点排行页的数据）──
  skillApi.registerTool({
    id: 'rank',
    name: '三角洲全枪排行',
    description:
      '【三角洲全枪 BTK 排行】用 dfttk 排行页的数据，按"某一距离的期望击杀弹数（BTK）"给所有参评枪械排序 —— BTK 越小代表杀人越快。'
      + '\n触发关键词：排行、最强、谁杀人快、哪把枪最强、BTK、击杀弹数、当前版本什么枪强、全枪排行。'
      + '\n场景默认是「3套 · 3弹 · 实战概率」（三级甲/头 + 三级弹，按实战命中部位概率加权），可换 4套4弹/5套5弹 等。'
      + '\n纯数据，不需要浏览器，毫秒级返回。',
    category: 'utility',
    icon: '🏆',
    parameters: {
      type: 'object',
      properties: {
        distance: { type: 'integer', description: '按多少米排序（默认 30，站点数据覆盖 0~80 米）' },
        limit: { type: 'integer', description: '列出前几名（默认 10，最多 30）' },
        class: { type: 'string', description: '只看某个枪种，如 "狙击步枪"、"突击步枪"' },
        scenario: { type: 'string', description: '场景 id，例如 "armor-3-ammo-3-default"（默认）、"armor-4-ammo-4-default"、"armor-5-ammo-5-default"' }
      },
      required: []
    },
    async execute(ctx, args) {
      try {
        const r = await rankByBtk({
          scenarioId: String(args?.scenario ?? '').trim(),
          distance: Number(args?.distance) || 30,
          limit: Number(args?.limit) || 10,
          cls: resolveClass(args?.class ?? args?.枪种 ?? '')
        });
        const sc = r.scenario || {};
        if (!r.total) {
          const cls = resolveClass(args?.class ?? args?.枪种 ?? '');
          return {
            content: `这个排行里没有「${cls}」类的枪。本场景（${sc.label || '默认'}）实际包含的枪种：${(r.presentClasses || []).join('、')}。去掉枪种条件再试，或者换个场景。`,
            isError: true
          };
        }
        const head = `【烽火地带 · 全枪 BTK 排行】${sc.label || '默认场景'} ｜ 距离 ${r.distance}m\n`
          + `参评 ${r.total} 个候选（BTK = 期望击杀弹数，越小越快；≈ 表示按 0m/5x m 两点线性插值）${r.hitProb ? `\n命中分布：${r.hitProb}` : ''}`;
        const lines = r.rows.map((x, i) => `${String(i + 1).padStart(2, ' ')}. ${x.name} ｜ ${x.ammo}(L${x.level}) ｜ ${x.interpolated ? '≈' : ''}${x.btk.toFixed(2)} 发`);
        return {
          content: [head, '', ...lines, '', '（数据 dfttk.com 排行页；BTK 是概率加权后的期望值，会有小数）'].join('\n')
        };
      } catch (e) {
        return { content: `排行查询失败：${e?.message ?? e}`, isError: true };
      }
    }
  });

  // ── 配件效果查询 ──
  skillApi.registerTool({
    id: 'part',
    name: '三角洲配件效果',
    description:
      '【三角洲配件效果】按名字查某个配件（577 个配件库）：类别、品质、适配多少把枪，以及它对面板属性的影响（有效射程 / 后坐力控制 / 腰射精度 / 操控 / 稳定性 的加减或倍率）。'
      + '\n触发关键词：配件、XX握把有什么用、XX枪管加多少、XX弹匣、配件效果、XX消音器、后坐力、腰射精度。'
      + '\n纯数据，毫秒级返回；找不到会给相近的配件名。',
    category: 'utility',
    icon: '🔧',
    parameters: {
      type: 'object',
      properties: {
        name: { type: 'string', description: '配件名（可只给关键词），如 "幻影后握把"、"加百列长枪管"、"消音"' }
      },
      required: ['name']
    },
    async execute(ctx, args) {
      try {
        const r = await partEffects({ name: args?.name ?? args?.配件 });
        if (r.error) return { content: r.error, isError: true };
        const blocks = r.parts.map((p) => [
          `【${p.name}】类别 ${p.category || '?'} ｜ 品质 ${p.rarity || '?'} ｜ 适配 ${p.weapons} 把枪`,
          `效果：${p.effects}`
        ].join('\n'));
        return { content: `${blocks.join('\n\n')}\n\n（数据 dfttk.com 配件库）` };
      } catch (e) {
        return { content: `配件查询失败：${e?.message ?? e}`, isError: true };
      }
    }
  });

  // ── 智能改枪（改装页测试版，慢通道）──
  skillApi.registerTool({
    id: 'builder',
    name: '三角洲智能改枪',
    description:
      '【智能改枪 / 定制配装】调 dfttk 枪械改装页里的"智能改枪"：给一个总预算（可选枪名、弹匣容量、屏息），它**从零搜出** 2~3 套新配装方案（更好控枪 / 均衡 / 上限更高），每套带**配件清单 + 精校参数** + 总价值、预算余量、面板变化。'
      + '\n★ 只要用户表达的是"**要一套新的/自己指定的配装**"，就用这个工具，典型说法：'
      + '自己写、自己写一套、定制、定制一套、定做、自己配、自己配一套、自己搭、自己搭一套、自己组装、自己搞一套、DIY、'
      + '从零配、从零开始配、按预算自己弄、按预算算一套、按预算设计、帮我设计一套、帮我配一套新的、'
      + '不要现成的、想要非现成的、我要算出来的方案、智能改枪、改装页那个智能配枪。'
      + '\n（区别：用户只想要**现成改枪码**时用 recommend，别用这个。）'
      + '\n⚠️ **很慢**：站点算法要 4~7 分钟（实测 233s / 285s / 421s 都出现过），单次上限 **10 分钟**，超时会取消并如实报失败。'
      + '\n输出包含：3 套方案（更好控枪/均衡/上限更高）+ **每套的配件清单与精校**（放在最前面）+ 总价值、预算余量、面板与后坐倍率。'
      + '\n⚠️ **一次调用就返回全部数据**：不要把"再调一次拿配件"当办法（每次都要重算 4~7 分钟，且拿不到上一次的结果）。要复述就直接引用这次的输出。'
      + '\n⚠️ 枪名可随意指定（不填就用页面默认的 M4A1）；这条流程只产出配件配置与精校，**不给改枪码**（要码用 recommend）；纯界面操作，站点改版可能失效。',
    category: 'utility',
    icon: '🧪',
    parameters: {
      type: 'object',
      properties: {
        budget: { type: 'integer', description: '总预算（游戏币，例如 300000 = 30万）' },
        weapon: { type: 'string', description: '枪名（可选，默认 M4A1），例如 "AKM"、"M7"、"K437"；会先切到这把枪再算' },
        magazine: { type: 'integer', description: '弹匣容量：30 / 45 / 60（默认 30）' },
        breath: { type: 'boolean', description: '是否按"全程屏息"计算（默认 false）' }
      },
      required: ['budget']
    },
    async execute(ctx, args) {
      const { buildOnSite } = await loadCalc();
      const raw = String(args?.budget ?? args?.预算 ?? '').trim();
      const budget = /万/.test(raw) ? Math.round(Number(String(raw).replace(/[^\d.]/g, '')) * 10000) : Math.round(Number(raw) || 0);
      const t0 = Date.now();
      const weaponName = String(args?.weapon ?? args?.枪 ?? args?.枪械 ?? '').trim();
      // 枪名 → weaponId（改装页靠 localStorage 里的 weaponId 决定编辑哪把枪）
      let weaponId = '';
      let weaponLabel = weaponName;
      if (weaponName) {
        const data = await ensureData();
        if (!data.error) {
          const found = findWeapons(data.solutions, weaponName);
          const hit = found.matches.length ? data.solutions.find((s) => found.matches.includes(s.weaponName)) : null;
          if (hit) { weaponId = String(hit.weaponId || ''); weaponLabel = hit.weaponName; }
          else log(`[dfttk] 智能改枪：数据里没找到「${weaponName}」，用页面默认武器`);
        }
      }
      log(`[dfttk] 智能改枪：预算 ${budget} ｜ 弹匣 ${args?.magazine ?? 30} ｜ 武器 ${weaponLabel || '(默认 M4A1)'}${weaponId ? ` (${weaponId})` : ''}`);
      const r = await buildOnSite({
        budget,
        weapon: weaponLabel,
        weaponId,
        magazine: Number(args?.magazine) || 30,
        breath: Boolean(args?.breath),
        timeoutMs: 10 * 60 * 1000,
        log: (m) => log(m),
        resolvePartName: await partNameResolver()
      });
      if (!r.ok) {
        const secs = Math.round((Date.now() - t0) / 1000);
        warn(`[dfttk] 智能改枪失败（${secs}s）：${r.reason}`);
        return {
          content: `智能改枪失败${r.timedOut ? '（超时已取消）' : ''}：${r.reason}。用了 ${secs} 秒。可以用 recommend 工具直接拿现成改枪码（快得多）。`,
          isError: true
        };
      }
      return { content: r.text };
    }
  });

  log('[dfttk] 已加载：三角洲改枪助手 v1.5.0（推荐 · 浏览 · 计算/对比 · 排行 · 配件 · 智能改枪）');
}

export function available() {
  return { ok: true };
}

/** 给测试用（不影响运行）。 */
export const internals = {
  ensureData, parseBudget, resolveMap, scoreSolution, pick, formatSolution, runTool,
  findWeapons, stripTypeSuffix, WEAPON_ALIASES, resolveClass, resolveSort, browse,
  rankByBtk, partEffects, fetchJsonCached, ensureRanking,
  MAP_PROFILES, SOURCE, dataDir, loadCalc
};
