# dsh-heart-qq 心情系统插件包（QQ 控制台）

把「心情系统」装进 WhaleGirlQQ（QQ 控制台）：14 项情绪数值、模式开关、睡眠闸门、
五维滑杆，外加一套会随对话变化、并注入到 AI 提示词里的情绪状态。

控制台标签栏会多出一个「🫀 心情」页，面板就嵌在那里；单独打开 `http://127.0.0.1:8090/heart` 也能用。

---

## 目录结构

```
qq插件/
├─ install.py                安装 / 卸载器（默认只预演）
├─ verify.py                 只读校验器（装完/出问题时跑一下）
├─ README.md                 本文件
├─ dsh-heart-qq-0.1.0.zip    整个目录的压缩分发件（内容与本目录一致）
├─ dsh-heart-qq/             插件包本体 → 装进 custom_plugins/
│  ├─ plugin.json            清单（id=dsh-heart-qq，目录名必须一致）
│  ├─ heart_qq.py            入口：引擎 + 钩子 + 面板接口
│  ├─ web/heart.html         面板页面（由宿主路由发给浏览器）
│  └─ README.md              插件自身的说明（数值规则、钩子行为）
└─ host/
   └─ heart_api.py           宿主新增模块 → 装进 src/heart_api.py
```

## 为什么要改宿主

插件层**没有**注册 HTTP 路由的钩子（`register_tool` 注册的是 AI 工具，不是路由），
所以面板的 `/heart` 与 `/api/heart/*` 只能由宿主提供。`install.py` 会做四件事：

| # | 目标 | 改动 |
|---|------|------|
| 1 | `data/qq-only/custom_plugins/dsh-heart-qq/` | 整个插件目录拷进去（目录包不需要登记 `custom_plugins.json`） |
| 2 | `src/heart_api.py` | 新增模块：发面板页 + 转发动作，自带本机访问校验与 `x-dsh-heart` 头防跨站 |
| 3 | `src/qq_app.py` | 在 `install_log_routes(app)` 之后插 3 行，装配上面的路由 |
| 4 | `src/web/static/qq.html` + `qq.js` | 标签栏第 6 个按钮、`tab-heart` 面板（iframe）、插件页入口、懒加载与重载逻辑 |

不打第 3、4 步插件照样算数值、照样注入提示词，只是没有面板。

## 安装

```bash
cd "D:/插件/打包好的插件/qq插件"

# 1. 先预演，看清楚要动哪些文件（不写盘）
python install.py

# 2. 确认后真装
python install.py --apply

# 3. 重启控制台
cd D:/qq机器人5.0 && .venv-qq/Scripts/python.exe qq_main.py
```

打开 `http://127.0.0.1:8090/`，点标签栏的「🫀 心情」。

### 参数

| 参数 | 作用 |
|------|------|
| （无） | 预演，只打印计划 |
| `--apply` | 真写盘 |
| `--overwrite` | 覆盖已存在的插件目录（整个挪成 `.bak-dsh-heart-<8位>`） |
| `--uninstall` | 反向卸载：删插件目录、删 `src/heart_api.py`、回滚三处静态文件 |
| `--dir <路径>` | 指定 `custom_plugins` 目录（默认问控制台 `GET /api/plugins/custom`） |
| `--host-dir <路径>` | 指定宿主源码根（默认由插件库位置反推） |
| `--url <地址>` | 控制台地址，默认 `http://127.0.0.1:8090` |

### 目标目录怎么定的

1. `--dir` 显式指定；
2. 否则问正在运行的控制台 `GET /api/plugins/custom` 的 `dir` 字段（唯一权威答案）；
3. 否则在候选路径里**优先挑真有插件的那一个** —— 安装版会在
   `%LOCALAPPDATA%/WhaleGirlQQ/...` 建一个空目录，空目录优先会把插件装到没人读的地方。

## 校验

装完（或面板不出东西时）跑这个，只读不写盘：

```bash
python verify.py                                  # 只查文件与补丁
python verify.py --url http://127.0.0.1:8090      # 额外探运行态
```

三层检查：文件层（插件四件齐、`plugin.json` 的 id 等于目录名、`src/heart_api.py` 内容一致）、
补丁层（10 条逐条判 applied / pending / conflict）、运行层（`GET /heart` 与
`GET /api/heart/state`，并确认返回 14 项数值）。全通过退出码 0，否则 1 并逐条列问题。

## 卸载

```bash
python install.py --apply --uninstall
```

`plugin_state/dsh_heart/` 会保留（删掉它等于重置心情）；要彻底清干净再手动删这个目录。
卸载同样幂等：没打过的补丁跳过，回滚前也会备份。

## 安全约定

- **默认只预演**，`--apply` 才动磁盘。
- 覆盖任何文件前先备份成 `<原名>.bak-dsh-heart-<8位随机>`。
- 每条补丁都靠「干净文件里的唯一锚点」定位，并留一个 marker 判断是否已打过：
  打过就跳过，锚点不唯一或缺失就报 `跳过（锚点不唯一或缺失）` 而不是乱插。
- 保留原文件行尾（`qq_app.py` 是 CRLF，`qq.html`/`qq.js` 是 LF）。

## 已验证

- **干净宿主上真装一次**：用 `dist/5.2.112` 里的原始 `qq.html`/`qq.js` 加去掉补丁的
  `qq_app.py` 造了一棵临时宿主树，`--apply` 之后三个文件与当前真宿主**逐字节一致**，
  `src/heart_api.py` 与插件目录也一致。
- **幂等**：紧接着再跑一次 `--apply`，12 项全部「跳过（已打过）」，无任何写盘。
- **卸载可回滚**：`--uninstall` 后三个文件逐字节回到 pristine，模块与插件目录删除干净。
- **功能**：`tests/test_heart_api.py` + `tests/test_heart_tab.py` 共 43 用例全绿；
  真机验证过标签页加载、总开关、滑杆改值落盘、重新加载面板、切走再切回不重复请求。
- **压缩分发件可独立使用**：`dsh-heart-qq-0.1.0.zip` 解压到任意目录，直接跑其中的
  `install.py`/`verify.py` 即可（不依赖本目录），已实测装出来的树与真宿主逐字节一致。
- **`verify.py` 双向验证**：真宿主上 RC=0（补丁 10 项 ok、运行层 14 项数值）；
  未安装的干净宿主上 RC=1 并列出 12 个问题。

## 前置要求

- 宿主版本 **5.2.112**（补丁锚点按这个版本的源码写的；版本不符会报锚点冲突而不是乱改）。
- Python 3.9+（宿主自带的 `.venv-qq` 即可）。
- 控制台只监听本机 `127.0.0.1:8090`，面板路由沿用宿主既有的 `local_admin` 中间件，
  非本机访问一律 403。

## 排查

| 现象 | 原因 |
|------|------|
| 标签页点开是空白 + 「这里空白说明插件没加载」 | 插件没装好，或插件设置里「网页面板」关着 —— 到「插件」页检查 `dsh_heart` |
| `/heart` 返回 503 | 插件实例没找到（管理器里没有 `dsh_heart`），重启控制台 |
| `/heart` 返回 403 | 不是从本机访问，或缺 `x-dsh-heart` 头（写请求才有此要求） |
| 装了但标签栏没变化 | 静态文件被浏览器缓存 —— 硬刷新（Ctrl+F5），或重开控制台 |
| 安装时报「锚点不唯一或缺失」 | 宿主不是 5.2.112，或那几个文件被别的补丁改过；按提示手动确认 |
