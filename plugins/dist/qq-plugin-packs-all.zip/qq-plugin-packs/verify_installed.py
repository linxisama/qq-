"""验证 install.py 真装出来的目录能被宿主原样加载。

跟 verify.py 的区别：verify.py 直接读 packs/overrides 产物，这里读**安装后**的
custom_plugins 目录（含 custom_plugins.json 登记），模拟用户装完重启那一刻。
"""
from __future__ import annotations

import json
import sys
import time
from pathlib import Path

HOST = Path(r"D:\qq机器人5.0")
sys.path.insert(0, str(HOST))

from src.plugins.manager import PluginManager  # noqa: E402

# 默认验生产安装目录；也可显式传一个装了插件的目录（如 <data-root>/data/qq-only）。
TARGET = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(r"D:\qq机器人5.0\data\qq-only")
INDEX = json.loads(Path(r"D:\插件\qq-plugin-packs\INDEX.json").read_text(encoding="utf-8"))


def main() -> int:
    data = TARGET
    t0 = time.perf_counter()
    mgr = PluginManager(data)
    elapsed = time.perf_counter() - t0

    expected = {e["id"]: e for e in INDEX["plugins"]}
    mounted = set(mgr._plugins)
    missing = sorted(set(expected) - mounted)
    # 多出来的不一定是问题：用户自己装的插件（demo_probe、dsh_heart 之类）本来就不在包里。
    # 只把「与内置同名的额外项」当异常，那才说明覆盖通道漏了。
    extra = sorted(mounted - set(expected))

    wrong = []
    for pid, e in expected.items():
        inst = mgr._plugins.get(pid)
        if inst is None:
            continue
        is_mod = bool(mgr._is_mod(inst))
        if is_mod != (e["channel"] == "mod"):
            wrong.append((pid, e["channel"], "mod" if is_mod else "override"))

    # 裸 .py 必须在清单里，目录包必须不在清单里
    registered = set(mgr.custom_plugin_ids())
    mod_dirs = {e["pack_id"] for e in INDEX["plugins"] if e["channel"] == "mod"}
    reg_problems = []
    for pid, e in expected.items():
        if e["channel"] == "override" and pid not in registered:
            reg_problems.append(f"{pid}: 裸 .py 未登记，重启后会消失")
        if e["channel"] == "mod" and pid in registered:
            reg_problems.append(f"{pid}: 目录包被误登记进 custom_plugins.json")

    print(f"=== 安装目录 {data} ===")
    print(f"宿主加载耗时 {elapsed:.2f}s｜挂载 {len(mounted)}/{len(expected)}")
    print(f"  missing={missing}")
    print(f"  extra={extra}")
    print(f"  wrong_channel={wrong}")
    print(f"  refusals={dict(mgr._mod_refusals)}")
    print(f"  load_problems={list(getattr(mgr, '_load_problems', []) or [])}")
    print(f"  last_import_error={getattr(mgr, '_last_import_error', None)!r}")
    print(f"  裸 .py 登记数={len(registered & set(expected))}"
          f"｜目录包目录数={len(mod_dirs)}")
    for p in reg_problems:
        print(f"  登记问题: {p}")

    ok = not missing and not wrong and not reg_problems \
        and not mgr._mod_refusals and not getattr(mgr, "_load_problems", None)
    print(f"\n结论：{'通过' if ok else '有问题'}")
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
