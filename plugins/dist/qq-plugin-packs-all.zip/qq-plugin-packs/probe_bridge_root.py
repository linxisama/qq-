"""验证 qqagent_bridge 的补丁不会比原版差。

桥解析宿主脚本有两条路径：

1. `_pack_repo_root()` → `REPO_ROOT` / `RUNTIME_HOST_SCRIPT` —— 纯文件位置探测，
   只在插件位于宿主仓库内（或同构目录）时有效；
2. `_resolve_paths(conf)` —— 桥真正在用的入口，先走 `_host_root(conf)`，
   能吃到用户填的 `hostRoot` 与 `src.qqagent_host.resolve_host_root()` 的结果。

关键结论（本脚本的判定基准）：**原版在没有 hostRoot 配置、且宿主根未 materialize 时
同样返回空 host_script**——因为 `_resolve_paths` 只在 `if root:` 分支里填 host_script。
所以补丁的验收标准不是「无配置也能跑」，而是「每个落点上都不比原版差」：

  * 仓库布局：两者都命中；
  * 装到独立数据目录：两者都空（这是宿主根没 materialize 的既有行为，不是回归）；
  * 填了 hostRoot：两者都命中。

补丁真正修的是 `REPO_ROOT` 指向数据目录这种「指错但看起来有值」的情况。

宿主仓库是只读的（沙箱 workspace-write 不允许写 src/），所以这里用**同构副本**代替
真仓库：`<scratch>/repo_like/src/plugins/` + `<scratch>/repo_like/runtime/qqagent-host/`。
"""
from __future__ import annotations

import importlib.util
import sys
from pathlib import Path

HOST = Path(r"D:\qq机器人5.0")
sys.path.insert(0, str(HOST))

ORIGINAL = (HOST / "src" / "plugins" / "qqagent_bridge.py").read_text(encoding="utf-8")
PATCHED = Path(r"D:\插件\qq-plugin-packs\overrides\qqagent_bridge.py").read_text(encoding="utf-8")
# 注意：桥说的「宿主根」是 **JS 宿主根**（含 src/config.js + src/plugin-loader.js），
# 即 runtime/qqagent-host/，不是 Python 仓库根 D:\qq机器人5.0。填错会一直被
# _is_host_root 判否，然后静默回退到空字符串。
JS_HOST_ROOT = HOST / "runtime" / "qqagent-host"
WANT = JS_HOST_ROOT / "host-one.mjs"
SCRATCH = Path(r"D:\插件\_audit\tmp\bridge")

REPO_LIKE = SCRATCH / "repo_like"
PLACES = {
    "仓库布局（同构副本）": REPO_LIKE / "src" / "plugins" / "qqagent_bridge.py",
    "custom_plugins 目录包": SCRATCH / "custom_plugins" / "pack_qqagent_bridge" / "qqagent_bridge.py",
    "custom_plugins 裸 .py": SCRATCH / "custom_plugins" / "qqagent_bridge.py",
}


def make_repo_like() -> None:
    """造一个和真仓库同构的最小目录：src/plugins/ + runtime/qqagent-host/host-one.mjs。"""
    marker = REPO_LIKE / "runtime" / "qqagent-host" / "host-one.mjs"
    marker.parent.mkdir(parents=True, exist_ok=True)
    if not marker.is_file():
        marker.write_text("// probe marker\n", encoding="utf-8")
    (REPO_LIKE / "src" / "plugins").mkdir(parents=True, exist_ok=True)


def load(path: Path, code: str, tag: str):
    path.parent.mkdir(parents=True, exist_ok=True)
    if not path.is_file() or path.read_text(encoding="utf-8") != code:
        path.write_text(code, encoding="utf-8")
    spec = importlib.util.spec_from_file_location(f"_probe_{tag}", path)
    mod = importlib.util.module_from_spec(spec)
    mod.__package__ = "src.plugins"          # 宿主加载器就是这么设的
    spec.loader.exec_module(mod)
    sys.modules.pop(spec.name, None)
    return mod


def run(path: Path, code: str, tag: str, conf: dict | None) -> tuple[bool, str]:
    """conf=None 走自动解析；否则把 conf 当用户设置。返回 (是否命中, 说明)。"""
    mod = load(path, code, tag)
    resolved = mod._resolve_paths(conf or {}, data_dir=None)
    script = resolved["host_script"]
    hit = bool(script) and Path(script).is_file()
    return hit, script or "（空）"


def main() -> int:
    make_repo_like()
    scenarios = [
        ("无配置（宿主根未 materialize）", None),
        ("填 hostRoot", {"hostRoot": str(JS_HOST_ROOT)}),
    ]
    problems = []
    for title, conf in scenarios:
        print(f"\n场景：{title}")
        print(f"  {'落点':24} {'原版':>8}  {'补丁版':>8}  判定")
        for label, path in PLACES.items():
            o_hit, o_script = run(path, ORIGINAL, f"o_{abs(hash(label + title))}", conf)
            p_hit, p_script = run(path, PATCHED, f"p_{abs(hash(label + title))}", conf)
            verdict = "不差于原版" if p_hit >= o_hit else "退化！"
            if p_hit < o_hit:
                problems.append(f"{title} / {label}: 原版命中，补丁版未命中")
            print(f"  {label:24} {'命中' if o_hit else '未命中':>8}  "
                  f"{'命中' if p_hit else '未命中':>8}  {verdict}")
            if o_hit != p_hit:
                print(f"  {'':24} 原版={o_script}")
                print(f"  {'':24} 补丁={p_script}")

    # 真仓库里的原文件（未打补丁）在仓库内必须命中——这是「没被我们搞坏」的基线
    repo_hit, repo_script = run(PLACES["仓库布局（同构副本）"], PATCHED, "final_repo", None)
    mod = load(PLACES["仓库布局（同构副本）"], PATCHED, "final_repo2")
    ok_repo = Path(mod.REPO_ROOT) == REPO_LIKE and Path(mod.RUNTIME_HOST_SCRIPT).is_file()
    print(f"\n补丁版在仓库布局下：REPO_ROOT={mod.REPO_ROOT}")
    print(f"  host-one.mjs 存在={Path(mod.RUNTIME_HOST_SCRIPT).is_file()}  与预期一致={ok_repo}")

    print(f"\n结论：{'通过' if not problems and ok_repo else '有问题'}")
    for p in problems:
        print(f"  {p}")
    return 0 if not problems and ok_repo else 1


if __name__ == "__main__":
    sys.exit(main())
